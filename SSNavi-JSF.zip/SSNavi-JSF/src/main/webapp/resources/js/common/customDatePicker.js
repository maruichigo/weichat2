/* 
 * customDatePicker.js 
 
 * Copyright (c) Shared System Inc.
 */
var holidays = ["20180620"];

$(document).ready(function () {
    $.datepicker.setDefaults({
        prevText: '<前',
        nextText: '次>',
        closeText: '閉じる',
        currentText: '今日',
        monthNames: ['1月','2月','3月','4月','5月','6月', '7月','8月','9月','10月','11月','12月'],
        monthNamesShort: ['1月','2月','3月','4月','5月','6月', '7月','8月','9月','10月','11月','12月'],
        dayNames: ['日曜日','月曜日','火曜日','水曜日','木曜日','金曜日','土曜日'],
        dayNamesShort: ['日','月','火','水','木','金','土'],
        dayNamesMin: ['日','月','火','水','木','金','土'],
        weekHeader: '週',
        dateFormat: 'yyyy/mm/dd',
        firstDay: 0,
        isRTL: false,
        showMonthAfterYear: true,
        yearSuffix: '年',
        changeYear: true,  // 年選択をプルダウン化
        changeMonth: true,  // 月選択をプルダウン化
        showOtherMonths: true,
        beforeShowDay: holidays
    });

    $('#Date').datepicker({                       // 土日祝日色変更
        beforeShowDay: function(date) {
            for (var i = 0; i < holidays.length; i++) {
                var holiday = new Date();
                holiday.setTime(Date.parse(holidays[i]));   // 祝日を日付型に変換

                if (holiday.getYear() == date.getYear() &&  // 祝日の判定
                    holiday.getMonth() == date.getMonth() &&
                    holiday.getDate() == date.getDate()) {
                    return [true, 'class-holiday', '祝日'];
                }
            }
            if (date.getDay() == 0) {                     // 日曜日
                return [true, 'class-sunday', '日曜日'];
            } else if (date.getDay() == 6) {              // 土曜日
                return [true, 'class-saturday', '土曜日'];
            } else {                                      // 平日
                return [true, 'class-weekday', '平日'];
            }
        }
    });        
    $.extend(jQuery.datepicker, {
        _selectDate: function (id, dateStr) {
            var onSelect,
                    target = $(id),
                    inst = this._getInst(target[0]);

            dateStr = (dateStr != null ? dateStr : this._formatDate(inst));
            if (inst.input) {
                inst.input.val(dateStr);
            }
            this._updateAlternate(inst);

            onSelect = this._get(inst, "onSelect");
            if (onSelect) {
                onSelect.apply((inst.input ? inst.input[0] : null), [dateStr, inst]);  // trigger custom callback
            } else if (inst.input) {
                inst.input.trigger("change"); 
            }

            if (inst.inline) {
                this._updateDatepicker(inst);
            } else {
                this._hideDatepicker();
                inst.input.focus();
            }
        }
    });
});


