jQuery(document).ready(function() {
	
    alert('test custom js.');
//    jQuery('#shp_000shp_100rpt_DCL_SHIPMENT_ORDER_RSMILE_CSV_DOWNLOAD').on('click', function() {
//
//    });
	
});