/*
 * TestBean.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.wbb.jsf.beans.mst;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import jp.co.sharedsys.wbb.jsf.exception.LogicException;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;
import jp.co.sharedsys.wbb.jsf.process.Mst451InitProcess;
import lombok.Getter;

/**
 *
 * @author lihaoyi
 */
@ManagedBean(name = "mst451HenshuBean")
@SessionScoped
public class Mst451HenshuBean implements Serializable {

    @Getter
    public List<Mst451Model> roleModelList;
    
    public void search() throws LogicException, SystemException, IOException {
        Mst451InitProcess initProcess = new Mst451InitProcess();
        initProcess.onService(this);
        List<Map<String, Object>> searchResult = initProcess.getSearchResult();
        roleModelList = new ArrayList();
        for (Map input : searchResult) {
            Mst451Model roleModel = new Mst451Model();
            roleModel.setLocalCode((String) input.get("listRoleCd"));
            roleModel.setLocalName((String) input.get("listRoleMeisho"));
            roleModelList.add(roleModel);
        }
        ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();
        ec.redirect(ec.getRequestContextPath() + "/contents/mst/mst451_2.xhtml");
    }
    
}
