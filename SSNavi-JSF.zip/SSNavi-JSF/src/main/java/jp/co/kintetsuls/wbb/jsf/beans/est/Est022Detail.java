/*
 * MenuModelBean.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.wbb.jsf.beans.est;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.event.ActionEvent;
import javax.faces.event.FacesEvent;
import javax.faces.model.SelectItem;
import jp.co.kintetsuls.common.MessageDataModel;
import jp.co.sharedsys.wbb.jsf.exception.LogicException;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;
import org.primefaces.component.commandbutton.CommandButton;
import jp.co.sharedsys.wbb.jsf.beans.SSNaviManagedBean;
import org.primefaces.event.MenuActionEvent;


/**
 * Svf出力機能
 * @author 
 */
public class Est022Detail implements Serializable {

    //ランクボラタンコンポーネントIDX
    private final int RANK_BUTTON_IDX = 1;

    //運賃テーブルカラム関連
    private final int DEFAULT_UNCHIN_COL_WIDTH = 338;

    /**
     * 見積り画面起動時の初期処理
     * @param bean
     * @param event
     * @param md
     * @param flg
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    public void init(SSNaviManagedBean bean,
                     FacesEvent event,
                     MessageDataModel md,
                     Boolean flg )
                     throws LogicException, SystemException {}



    /**
     * 見積り画面起動時の初期処理
     * @param bean
     * @param event
     * @param md
     * @param flg
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    public void close(SSNaviManagedBean bean,
                     FacesEvent event,
                     MessageDataModel md,
                     Boolean flg )
                     throws LogicException, SystemException {

        Map<String, Map<String, Object>> values = bean.getValues();
        //画面メイン部
        values.put("EST022-main", 
                   new HashMap<String, Object>() {
                        {put("tabs", new ArrayList()); }                // tabList
                        {put("cntPack", Integer.valueOf(0)); }          // TAB カウンタ(パック)
                        {put("cntNormal", Integer.valueOf(0)); }        // TAB カウンタ(ノーマル)
                        {put("cntCharter", Integer.valueOf(0)); }       // TAB カウンタ(チャーター)
                        {put("cntIncidental", Integer.valueOf(0)); }    // TAB カウンタ(付帯)
                        {put("tabIndex", Integer.valueOf(-1)); }        // TAB Index
                        {put("activeTab", Integer.valueOf(0)); }        // アクティブタブIndex
                        {put("viewsw", "01"); }        // fixme
                   }
               );

        //見積り提案情報部
        values.put("EST022-suggestion", 
                   new HashMap<String, Object>() {
                        {put("tes", ""); }                              // tabList
                   }
               );

    }



    /**
     * 見積り画面にTabを追加するメソッド
     * @param bean
     * @param event
     * @param md
     * @param flg
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
     public void addDetailTab(SSNaviManagedBean bean,
                              FacesEvent event,
                              MessageDataModel md,
                              Boolean flg )
                              throws LogicException, SystemException {

        String id = ((CommandButton)event.getSource()).getId();
        Map<String, Map<String, Object>> values = bean.getValues();
        ArrayList obj = bean.getObjectValues();
        Map map = values.get("EST022-main");
        List<EstimationTab > tabs = (ArrayList) map.get("tabs");
        int index = (int) map.get("tabIndex");

        //パック
        if(id!=null && id.equals("SBT_PACK")) {
            int cnt = (int) map.get("cntPack");
            tabs.add(new EstimationTab("パック料金" + String.valueOf(++cnt),"./est022_pack_detail.xhtml", ++index));
            map.put("cntPack", cnt);
            initPack(obj, index);

        //ノーマル
        } else if (id!=null && id.equals("SBT_NORMAL")) {
            int cnt = (int) map.get("cntNormal");
            tabs.add(new EstimationTab("ノーマル運賃" + String.valueOf(++cnt),"./est022_normal_detail.xhtml", ++index));
            map.put("cntNormal", cnt);
            initNormal(obj, index);

        //チャーター
        } else if (id!=null && id.equals("SBT_CHARTER")) {
            int cnt = (int) map.get("cntCharter");
            tabs.add(new EstimationTab("チャーター料金" + String.valueOf(++cnt),"./est022_charter_detail.xhtml", ++index));
            map.put("cntCharter", cnt);
            initCharter(obj, index);

        //付帯
        } else if (id!=null && id.equals("SBT_INCIDENTAL")) {
            int cnt = (int) map.get("cntIncidental");
            tabs.add(new EstimationTab("付帯料金" + String.valueOf(++cnt),"./est022_incidental_detail.xhtml", ++index));
            map.put("cntIncidental", cnt);
            initIncidental(obj, index);
        }
        map.put("tabIndex", index);
        map.put("activeTab", index);
    }



    /**
     * パック料金設定画面　初期処理（Tab追加時）
     * @param obj
     * @param index
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    private void initPack(List obj, int index) throws LogicException, SystemException {

        //見積り基本部 項目
        HashMap<String, HashMap> items = new HashMap<>();
        initEstimationBasic(items);

        //パック料金設定部 項目初期化
        items.put("EST022-pack", 
                new HashMap<String, Object>() {
                    {put("regions", new ArrayList<>()); }                                       // 発着地域リスト
                    {put("regionItems", new ArrayList<>()); }                                   // 発着地域リスト(selectItem)
                    {put("regIndex", Integer.valueOf(0)); }                                     // 発着地域リスト(regIndex)
                    {put("packs", new ArrayList<>()); }                                         // 着地別パック情報格納リスト
                    {put("remarksMode", "01"); }                                                // 備考表示切替
                    {put("BIKO", ""); }                                                         // 備考(1列用)
                    {put("BIKO_1", ""); }                                                       // 備考(2列用-1)
                    {put("BIKO_2", ""); }                                                       // 備考(2列用-2)
               });
        obj.add(items);

        //着地別パック情報
        List packs = (ArrayList)items.get("EST022-pack").get("packs");
        //着地別パック情報
        Map<String, Object>  packinfo = 
                new HashMap<String, Object>() {
                    {put("ranks", new ArrayList<>()); }                                         // ランク別設定情報
                    {put("columns", new ArrayList<>()); }                                       // 料金表Columns
                    {put("prices", new ArrayList<>()); }                                        // 料金
                    {put("prefectures1", new ArrayList<>()); }                                  // 都道府県リスト１
                    {put("prefectures2", new ArrayList<>()); }                                  // 都道府県リスト２
                    {put("prefectures3", new ArrayList<>()); }                                  // 都道府県リスト３
                    {put("municipalities", new ArrayList<>()); }                                // 市区町村リスト
                    {put("unchinWidth", Integer.valueOf(DEFAULT_UNCHIN_COL_WIDTH)); }           // 料金表・表示幅
                    {put("draggableColumns", false); }                                          // 料金表ドラッグ＆ドロップ制御フラグ
                    {put("viewsw", "01"); }                                                     // 地図・一覧表示切替
                    {put("inputRank", ""); }                                                    // fixme rank
                    {put("columnCount", ""); }                                                  // fixme rank
        };
        packs.add(packinfo);

        //都道府県リスト１～３セット
        setPackPrefectures((List<EstimatePackCityPrefectures>) packinfo.get("prefectures1"),
                           (List<EstimatePackCityPrefectures>) packinfo.get("prefectures2"),
                           (List<EstimatePackCityPrefectures>) packinfo.get("prefectures3"));

        //市区町村リストセット
        setPackMunicipalities((List<EstimatePackCityMunicipality>) packinfo.get("municipalities"));

        //ランク別設定情報セット
        setPackRanks((List<EstimatePackRank>) packinfo.get("ranks"),
                     (List<EstimateColumnModel>) packinfo.get("columns"));

        //料金セット
        setPackPrices((List<List<BigDecimal>>) packinfo.get("prices"));

        // 発着地域リストセット
        setPackRegion((List<EstimatePackRank>) items.get("EST022-pack").get("regions"),
                      (List<SelectItem>) items.get("EST022-pack").get("regionItems"));

    }


    /**
     * ノーマル運賃設定画面　初期処理（Tab追加時）
     * @param obj
     * @param index
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    private void initNormal(List obj, int index) throws LogicException, SystemException {

        //見積り基本部 項目
        HashMap<String, HashMap> items = new HashMap<>();
        initEstimationBasic(items);

        //ノーマル運賃設定部 項目初期化
        items.put("EST022-normal", 
                new HashMap<String, Object>() {
                    {put("tes", ""); }                                          // ランク別設定情報
               });
        obj.add(items);
    }



    /**
     * チャーター料金設定画面　初期処理（Tab追加時）
     * @param obj
     * @param index
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    private void initCharter(List obj, int index) throws LogicException, SystemException {

        //見積り基本部 項目
        HashMap<String, HashMap> items = new HashMap<>();
        initEstimationBasic(items);

        //チャーター料金設定部 項目初期化
        items.put("EST022-charter", 
                new HashMap<String, Object>() {
                    {put("tes", ""); }                                          // ランク別設定情報
               });
        obj.add(items);
    }



    /**
     * 付帯料金設定画面　初期処理（Tab追加時）
     * @param obj
     * @param index
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    private void initIncidental(List obj, int index) throws LogicException, SystemException {

        //見積り基本部 項目
        HashMap<String, HashMap> items = new HashMap<>();
        initEstimationBasic(items);

        //付帯料金設定部 項目初期化
        items.put("EST022-incidental", 
                new HashMap<String, Object>() {
                    {put("tes", ""); }                                          // ランク別設定情報
               });
        obj.add(items);
    }



    /**
     * 見積り基本情報（共通部）　初期処理（Tab追加時）
     * @param item
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    private void initEstimationBasic(HashMap<String, HashMap> items) throws LogicException, SystemException {

        items.put("EST022-estimation-basic", 
                new HashMap<String, Object>() {
                    {put("MITSUMORI_NO", "test1"); }    // 見積No
                    {put("MITSUMORI_MEMO", ""); }       // 見積メモ
                    {put("NEBIKI_WARIMDS", ""); }       // 値引(割増)/割戻
                    {put("MITSUMORI_TITLE", ""); }      // 見積りタイトル
                    {put("EIGYO_TANTO", ""); }          // 営業担当者
                    {put("KOSHIN_USER", ""); }          // 更新ユーザー
                    {put("KOSHIN_NICHIJI", ""); }       // 更新ユーザー
               });
    }



    /**
     * 都道府県リストに初期値をセットするメソッド
     * @param prefectures1
     * @param prefectures2
     * @param prefectures3
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    private void setPackPrefectures(List<EstimatePackCityPrefectures> list1,
                                    List<EstimatePackCityPrefectures> list2,
                                    List<EstimatePackCityPrefectures> list3)
                                    throws LogicException, SystemException {

        list1.add(new EstimatePackCityPrefectures("01","北海道",null,null,false));
        list1.add(new EstimatePackCityPrefectures("02","青森県",null,null,false));
        list1.add(new EstimatePackCityPrefectures("03","岩手県",null,null,false));
        list1.add(new EstimatePackCityPrefectures("04","宮城県",null,null,false));
        list1.add(new EstimatePackCityPrefectures("05","秋田県",null,null,false));
        list1.add(new EstimatePackCityPrefectures("06","山形県",null,null,false));
        list1.add(new EstimatePackCityPrefectures("07","福島県",null,null,false));
        list1.add(new EstimatePackCityPrefectures("08","茨城県",null,null,false));
        list1.add(new EstimatePackCityPrefectures("09","栃木県",null,null,false));
        list1.add(new EstimatePackCityPrefectures("10","群馬県",null,null,false));
        list1.add(new EstimatePackCityPrefectures("11","埼玉県",null,null,false));
        list1.add(new EstimatePackCityPrefectures("12","千葉県",null,null,false));
        list1.add(new EstimatePackCityPrefectures("13","東京都",null,null,false));
        list1.add(new EstimatePackCityPrefectures("14","神奈川県",null,null,false));
        list1.add(new EstimatePackCityPrefectures("15","新潟県",null,null,false));
        list1.add(new EstimatePackCityPrefectures("16","富山県",null,null,false));

        list2.add(new EstimatePackCityPrefectures("17","石川県",null,null,false));
        list2.add(new EstimatePackCityPrefectures("18","福井県",null,null,false));
        list2.add(new EstimatePackCityPrefectures("19","山梨県",null,null,false));
        list2.add(new EstimatePackCityPrefectures("20","長野県",null,null,false));
        list2.add(new EstimatePackCityPrefectures("21","岐阜県",null,null,false));
        list2.add(new EstimatePackCityPrefectures("22","静岡県",null,null,false));
        list2.add(new EstimatePackCityPrefectures("23","愛知県",null,null,false));
        list2.add(new EstimatePackCityPrefectures("24","三重県",null,null,false));
        list2.add(new EstimatePackCityPrefectures("25","滋賀県",null,null,false));
        list2.add(new EstimatePackCityPrefectures("26","京都府",null,null,false));
        list2.add(new EstimatePackCityPrefectures("27","大阪府",null,null,false));
        list2.add(new EstimatePackCityPrefectures("28","兵庫県",null,null,false));
        list2.add(new EstimatePackCityPrefectures("29","奈良県",null,null,false));
        list2.add(new EstimatePackCityPrefectures("30","和歌山県",null,null,false));
        list2.add(new EstimatePackCityPrefectures("31","鳥取県",null,null,false));
        list2.add(new EstimatePackCityPrefectures("32","島根県",null,null,false));

        list3.add(new EstimatePackCityPrefectures("33","岡山県",null,null,false));
        list3.add(new EstimatePackCityPrefectures("34","広島県",null,null,false));
        list3.add(new EstimatePackCityPrefectures("35","山口県",null,null,false));
        list3.add(new EstimatePackCityPrefectures("36","徳島県",null,null,false));
        list3.add(new EstimatePackCityPrefectures("37","香川県",null,null,false));
        list3.add(new EstimatePackCityPrefectures("38","愛媛県",null,null,false));
        list3.add(new EstimatePackCityPrefectures("39","高知県",null,null,false));
        list3.add(new EstimatePackCityPrefectures("40","福岡県",null,null,false));
        list3.add(new EstimatePackCityPrefectures("41","佐賀県",null,null,false));
        list3.add(new EstimatePackCityPrefectures("42","長崎県",null,null,false));
        list3.add(new EstimatePackCityPrefectures("43","熊本県",null,null,false));
        list3.add(new EstimatePackCityPrefectures("44","大分県",null,null,false));
        list3.add(new EstimatePackCityPrefectures("45","宮崎県",null,null,false));
        list3.add(new EstimatePackCityPrefectures("46","鹿児島県",null,null,false));
        list3.add(new EstimatePackCityPrefectures("47","沖縄県",null,null,false));
    }



    /**
     * 市区町村リストに初期値をセットるメソッド
     * @param municipalities
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    private void setPackMunicipalities(List<EstimatePackCityMunicipality> list) 
                                       throws LogicException, SystemException {

        list.add(new EstimatePackCityMunicipality("201","山形市","A",null,null,"備考メモ"));
        list.add(new EstimatePackCityMunicipality("202","米沢市","G",null,null,null));
        list.add(new EstimatePackCityMunicipality("203","鶴岡市","I",null,null,"備考メモ"));
        list.add(new EstimatePackCityMunicipality("204","酒田市","J",null,null,null));
        list.add(new EstimatePackCityMunicipality("205","新庄市","D",null,null,"備考メモ"));

    }



    /**
     * 地域リストにセットするメソッド
     * @param regions
     * @param items
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    private void setPackRegion(List<EstimatePackRank> list,
                               List<SelectItem> items) 
                               throws LogicException, SystemException {

        //test data
        EstimatePackRank ar = new EstimatePackRank();
        ar.setRegindex(0);
        ar.setRegion("着地１");
        list.add(ar);

        ar = new EstimatePackRank();
        ar.setRegindex(1);
        ar.setRegion("着地２");
        list.add(ar);

        //引取の場合は、画面にて着地域を設定させる
        for(EstimatePackRank reg: list) {
            items.add(new SelectItem(reg.getRegindex(), reg.getRegion()));
        }

        //引取以外は顧客の市区町村の名称を表示


    }



    /**
     * ランク別設定情報に初期値をセットするメソッド
     * @param ranks
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    private void setPackRanks(List<EstimatePackRank> ranks,
                              List<EstimateColumnModel> columns) 
                              throws LogicException, SystemException {

        //ランク別情報初期化
        EstimatePackRank rank = new EstimatePackRank();
        rank.setRankColor(EstimateRankColor.getColor(0));
        ranks.add(rank);

        //Columns初期化
        List<EstimateColumnModel> list2 = new ArrayList<>();
        columns.add(new EstimateColumnModel("dumy", "dumy"));
    }



    /**
     * 料金表に初期値をセットするメソッド
     * @param prefectures1
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    private void setPackPrices(List<List<BigDecimal>> prices) 
                              throws LogicException, SystemException {

        //料金初期化
        List<BigDecimal> rowItem = new ArrayList<>();
        BigDecimal price = new BigDecimal("0");
        rowItem.add(price);
        prices.add(rowItem);

        //建値初期化 fixme

    }



    public class EstimationTab implements Serializable {

        private String title;
        private String url;
        private int index =-1;

        public EstimationTab(String title, String url, int index) {
            this.title = title;
            this.url = url;
            this.index = index;
        }

        public String getTitle() {
            return title;
        }

        public String getUrl() {
            return url;
        }

        public int getIndex() {
            return index;
        }

    }
}