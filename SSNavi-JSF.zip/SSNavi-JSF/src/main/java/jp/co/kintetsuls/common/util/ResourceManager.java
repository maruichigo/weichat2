/*
 * ResourceManager.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.common.util;

import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import jp.co.kintetsuls.wbb.jsf.beans.common.PageSessionBean;

/**
 *
 * @author malei
 */
public class ResourceManager {
    
    
    public static PageSessionBean getPageSession() {
        HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);
        if (session.getAttribute("pageSessionBean") != null) {
            PageSessionBean conMap = (PageSessionBean) session.getAttribute("pageSessionBean");
            return conMap;
        }
        return null;
    }

    public static MessageProperty getMessageProperty() {
            ServletContext application = (ServletContext)FacesContext.getCurrentInstance().getExternalContext().getContext();
            MessageProperty messageProp = (MessageProperty)application.getAttribute("messageProperty");
            return messageProp;
    }
    
}
