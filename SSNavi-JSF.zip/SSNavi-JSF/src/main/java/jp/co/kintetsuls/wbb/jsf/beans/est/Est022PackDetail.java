/*
 * EstimatePackDetailBean.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.wbb.jsf.beans.est;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.event.FacesEvent;
import jp.co.kintetsuls.common.MessageDataModel;
import jp.co.sharedsys.wbb.jsf.exception.LogicException;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;
import org.primefaces.component.api.DynamicColumn;
import org.primefaces.component.api.UIColumn;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.event.CellEditEvent;
import org.primefaces.event.SelectEvent;
import jp.co.sharedsys.wbb.jsf.beans.SSNaviManagedBean;


/**
 *
 * @author
 */
public class Est022PackDetail implements Serializable {

//=============================================================================
//【Pack料金一覧部

//-----------------------------------------------------------------------------
    //ランクボラタンコンポーネントIDX
    private final int RANK_BUTTON_IDX = 1;

    //料金表テーブルコンポーネントID
    private final String PACK_UNCHIN_DT_ID = "estimationForm:estimationTab:unchin";

    //料金表テーブル・ヘッダ部 コンポーネントKEY
    private final String PACK_UNCHIN_HEADER_KEY = "header";

    //運賃テーブルカラム関連
    private final int UNCHIN_COL_WIDTH = 148;
    private final int UNCHIN_COL_MAX = 10;
    private final int UNCHIN_COL_SIDE = 190;

    //地図初期背景色
    private final String MAP_DEF_COLOR = "#cfcfcf";

//-----------------------------------------------------------------------------

    //ランク別設定
    private List<EstimatePackRank> ranks;

    //動的な列生成用
    private List<EstimateColumnModel> columns;

    //建値設定設定
//    private List<EstimatePackPricePattern> pricePatterns;

    //料金設定
    private List<List<BigDecimal>> prices;

    //都道府県リスト１
    private List<EstimatePackCityPrefectures> prefectures1;

    //都道府県リスト２
    private List<EstimatePackCityPrefectures> prefectures2;

    //都道府県リスト３
    private List<EstimatePackCityPrefectures> prefectures3;

    //市区町村リスト
    private List<EstimatePackCityMunicipality> municipalities;

    //運賃テーブル幅
    private int unchinWidth;

    //料金表ドラッグ＆ドロップモード
    private boolean draggableColumns;



    public Est022PackDetail() {
    }

    public void addCol(int idx) throws LogicException, SystemException, InvocationTargetException {
    }

    public void dummyw(int index) throws LogicException, SystemException, InvocationTargetException {
    }



    /**
     * 料金表の明細行を追加する
     * @param bean
     * @param event
     * @param md
     * @param flg
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    public void addRow(SSNaviManagedBean bean,
                       FacesEvent event,
                       MessageDataModel md,
                       Boolean flg)
                       throws LogicException, SystemException {
        //パラメータ取得
        Map<String, String> param = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
        int tabindex = Integer.parseInt(param.get("tabIndex"));
        int regindex = Integer.parseInt(param.get("regIndex"));
        ArrayList obj = bean.getObjectValues();
        Map pack = getPackInfo(obj, tabindex, regindex);

        FacesContext ctx = FacesContext.getCurrentInstance();
        DataTable table = ( DataTable ) ctx.getViewRoot().findComponent(PACK_UNCHIN_DT_ID);
        List<UIColumn> cols = table.getColumns();
        String key = String.valueOf(cols.size());

        //料金行追加
        List row = new ArrayList();
        for (int i=0; cols.size()>i; i++) {
            BigDecimal price = new BigDecimal("0");
            row.add(price);
        }
        prices.add(row);

        //建値行追加
   }



    /**
     * 画面で選択された発着地名を取得するメソッド
     * @param event
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    public void selectedRegion(SelectEvent event) throws LogicException, SystemException{
//        selectedRegion = (String)event.getObject();
    }



    /**
     * 発着地名を印刷用発着地名に転記するメソッド
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    public void setPrintRegion() throws LogicException, SystemException{

        //未選択の場合は以降SKIP
//        if(selectedRegion==null) return;

        //rankを逆引きする
/*        EstimatePackRank rank = getSelectedCityRank(selectedRegion);
        if(rank==null) return;

        if(rank.getPrintRegion1()==null || rank.getPrintRegion1().equals("")) {
            rank.setPrintRegion1(selectedRegion);
        } else if (rank.getPrintRegion2()==null || rank.getPrintRegion2().equals("")) {
            rank.setPrintRegion2(selectedRegion);
        } else if (rank.getPrintRegion3()==null || rank.getPrintRegion3().equals("")) {
            rank.setPrintRegion3(selectedRegion);
        } else if (rank.getPrintRegion4()==null || rank.getPrintRegion4().equals("")) {
            rank.setPrintRegion4(selectedRegion);
        } else if (rank.getPrintRegion5()==null || rank.getPrintRegion5().equals("")) {
            rank.setPrintRegion5(selectedRegion);
        } else if (rank.getPrintRegion6()==null || rank.getPrintRegion6().equals("")) {
            rank.setPrintRegion6(selectedRegion);
        } else if (rank.getPrintRegion7()==null || rank.getPrintRegion7().equals("")) {
            rank.setPrintRegion7(selectedRegion);
        } else if (rank.getPrintRegion8()==null || rank.getPrintRegion8().equals("")) {
            rank.setPrintRegion8(selectedRegion);
        }
*/
    }



    /**
     * RegionからRankを逆引きするメソッド
     * @param region
     * @return rank object
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    private EstimatePackRank getSelectedCityRank(String region) throws LogicException, SystemException {

        EstimatePackRank result = null;
/*
        looptop:
        for(EstimatePackRank rank : ranks) {
            for(String city : rank.getCities()) {
                if (city.equals(region)) {
                    result = rank;
                    break looptop;
                }
            }
        }
*/
        return result;
   }













    /**
     * 都道府県一覧で選択されたランクを一括更新する
     * @param bean
     * @param event
     * @param md
     * @param flg
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    public void setRankSelectPrefectures(SSNaviManagedBean bean,
                                         FacesEvent event,
                                         MessageDataModel md,
                                         Boolean flg)
                                         throws LogicException, SystemException {

        //パラメータ取得
        Map<String, String> param = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
        int tabindex = Integer.parseInt(param.get("tabIndex"));
        int regindex = Integer.parseInt(param.get("regIndex"));
        int mode = Integer.parseInt(param.get("mode"));

        //ObjectValues取得
        ArrayList obj = bean.getObjectValues();
        Map pack = getPackInfo(obj, tabindex, regindex);

        String inputRank = (String) pack.get("inputRank");

        //都道府県一覧selection1
        List<EstimatePackCityPrefectures> selectedPrefectures = bean.getUniversalList1();
        for (EstimatePackCityPrefectures city : selectedPrefectures) {
            //ランク設定済の場合は解除する
            if(city.getRank()!=null && !city.getRank().equals("")) {
                deleteCityList(city.getRank(), city.getJisCode(), 1);
            }
            //ランク設定
            if(mode == 1) {
                setRankPrefectures(inputRank, city);
            }
        }

        //都道府県一覧selection2
        selectedPrefectures = bean.getUniversalList2();
        for (EstimatePackCityPrefectures city : selectedPrefectures) {
            //ランク設定済の場合は解除する
            if(city.getRank()!=null && !city.getRank().equals("")) {
                deleteCityList(city.getRank(), city.getJisCode(), 2);
            }
            //ランク設定
            if(mode == 1) {
                setRankPrefectures(inputRank, city);
            }
        }

        //都道府県一覧selection3
        selectedPrefectures = bean.getUniversalList3();
        for (EstimatePackCityPrefectures city : selectedPrefectures) {
            //ランク設定済の場合は解除する
            if(city.getRank()!=null && !city.getRank().equals("")) {
                deleteCityList(city.getRank(), city.getJisCode(), 3);
            }
            //ランク設定
            if(mode == 1) {
                setRankPrefectures(inputRank, city);
            }
        }

        bean.setUniversalList1(new ArrayList());
        bean.setUniversalList2(new ArrayList());
        bean.setUniversalList3(new ArrayList());
        pack.put("inputRank", "");

    }



    /**
     * 都道府県をランクに反映する
     * @param ranknum
     * @param city
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    private void setRankPrefectures(String ranknum, EstimatePackCityPrefectures city) throws LogicException, SystemException {

        //入力されたランクの有無をチェックして要素取得
        EstimatePackRank inpRank = getInputRank(ranknum);

        //都道府県地図／一覧の要素取得
        if(inpRank != null) {
            String name = city.getCityName();
            String code = city.getJisCode();
            List<String> cities = inpRank.getCities();
            cities.add(code + ":" + name + ":" + "P");
            city.setColor(inpRank.getRankColor());
            city.setRank(ranknum);
        }
    }



    /**
     * ランクColumnを追加するメソッド
     * @param bean
     * @param event
     * @param md
     * @param flg
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
     public void addColumn2(SSNaviManagedBean bean,
                           FacesEvent event,
                           MessageDataModel md,
                           Boolean flg)
                           throws LogicException, SystemException {

        //fixme debug 
        long start = System.nanoTime();

        //パラメータ取得
        Map<String, String> param = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
        int tabindex = Integer.parseInt(param.get("tabIndex"));
        int regindex = Integer.parseInt(param.get("regIndex"));

        //ObjectValues取得
        ArrayList obj = bean.getObjectValues();
        Map pack = getPackInfo(obj, tabindex, regindex);

        //Column数
        int count = Integer.parseInt((String)pack.get("columnCount"));

        for(int j=0; count>j; j++) {

            //カラム生成
            columns.add(new EstimateColumnModel("Dummy", "Dummy"));
            int colindex = columns.size() - 1;
 
            //ヘッダ生成
            EstimatePackRank rank = new EstimatePackRank();
            rank.setRankColor(EstimateRankColor.getColor(colindex+1));
            ranks.add(rank);
 
            //料金に新規Columnを追加
            BigDecimal price;
            for (int i=0; prices.size()>i; i++) {
                List row = prices.get(i);
                price = new BigDecimal("0");
                row.add(price);
            }
        }

        int size = columns.size();
        //テーブル幅算出
        if(size < UNCHIN_COL_MAX) {
            unchinWidth = UNCHIN_COL_SIDE + UNCHIN_COL_WIDTH * (size) ;
        } else {
            unchinWidth = UNCHIN_COL_SIDE + UNCHIN_COL_WIDTH * UNCHIN_COL_MAX;
        }
        pack.put("unchinWidth", unchinWidth);

        //fixme debug 
        long end = System.nanoTime();
        System.out.println("PackDetail::::: " + (end-start) +"ns");

    }



    /**
     * 日本地図の背景色を返却するメソッド
     * @param values
     * @param obj
     * @param md
     * @param code
     * @param tabindex
     * @param regindex
     * @return color
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    public String getPrefecturesMapColor(HashMap<String, HashMap<String, Object>> values,
                                        ArrayList obj,
                                        MessageDataModel md,
                                        String code,
                                        Integer tabindex,
                                        Integer regindex) 
                                        throws LogicException, SystemException {








        Map pack = getPackInfo(obj, tabindex, regindex);
        String result = null;
        EstimatePackCityPrefectures city = getPrefectures(code, 0);
        if(city != null) {
            result = city.getColor();
        }
        return (result==null ? MAP_DEF_COLOR:result);




    }










/*----------------------------------------------------------------------------------------------------------------------------------*/



    /**
     * 都道府県一覧でランクの更新・削除を映するメソッド
     * @param bean
     * @param event
     * @param md
     * @param flg
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    public void changeRowPrefecturesRank(SSNaviManagedBean bean,
                                          FacesEvent event,
                                          MessageDataModel md,
                                          Boolean flg)
                                          throws LogicException, SystemException {


        //fixme debug 
        long start = System.nanoTime();


        //パラメータ取得
        Map<String, String> param = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
        int tabindex = Integer.parseInt(param.get("tabIndex"));
        int regindex = Integer.parseInt(param.get("regIndex"));
        int listnum  = Integer.parseInt(param.get("listnum"));

        //ObjectValues取得
        ArrayList obj = bean.getObjectValues();
        Map pack = getPackInfo(obj, tabindex, regindex);

        String code = null;
        if(listnum == 1) {
            code = prefectures1.get(((CellEditEvent)event).getRowIndex()).getJisCode();
        } else if(listnum == 2) {
            code = prefectures2.get(((CellEditEvent)event).getRowIndex()).getJisCode();
        } else if(listnum == 3) {
            code = prefectures3.get(((CellEditEvent)event).getRowIndex()).getJisCode();
        }

        String newRank = (String)((CellEditEvent)event).getNewValue();
        String oldRank = (String)((CellEditEvent)event).getOldValue();
        if(newRank == null || newRank.equals("")) {
            deleteCityList(oldRank, code, listnum);
        } else {
            setPrefecturesList(newRank, code, listnum);
        }


        //fixme debug 
        long end = System.nanoTime();
        System.out.println("PackDetail::::: " + (end-start) +"ns");



    }



    /**
     * 都道府県一覧・市区町村一覧でランクが削除された場合の処理
     * @param ranknum
     * @param code
     * @param listnum
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    private void deleteCityList(String ranknum, String code, int listnum) throws LogicException, SystemException {

        //削除される前のランクの有無をチェックして要素取得
        EstimatePackRank inpRank = getInputRank(ranknum);

        //都道府県・市区町村の削除
        if(inpRank != null) {
            for(String targetCity : inpRank.getCities()) {
                String[] cityProperty = targetCity.split(":");
                if(cityProperty[0].equals(code)) {
                    inpRank.getCities().remove(targetCity);
                    if(cityProperty[2].equals("P")) {
                        releasePrefectures(code, listnum);
                    } else {
                        //fixme
                    }
                    break;
                }
            }
        }
    }



    /**
     * 都道府県一覧・市区町村一覧でランクが更新された場合の処理
     * @param ranknum
     * @param code
     * @param listnum
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    public void setPrefecturesList(String ranknum, String code, int listnum) throws LogicException, SystemException {

        //入力されたランクの有無をチェックして要素取得
        EstimatePackRank inpRank = getInputRank(ranknum);

            //都道府県地図／一覧の要素取得
        if(inpRank != null) {
            EstimatePackCityPrefectures city = getPrefectures(code, listnum);
            if(city != null) {
                //ランクに当道府県を追加
                String name = city.getCityName();
                List<String> cities = inpRank.getCities();
                cities.add(code + ":" + name + ":" + "P");
                city.setColor(inpRank.getRankColor());
            }
        }
    }



    /**
     * 都道府県一覧で入力されたランク返却するメソッド
     * @param listnum
     * @return rank object
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    private EstimatePackRank getInputRank(String ranknum) throws LogicException, SystemException {

        EstimatePackRank result = null;
        for (EstimatePackRank rank : ranks) {
            if (rank.getRank().equals(ranknum)) {
                result = rank;
                break;
            }
        }
        return result;
   }



    /**
     * ランクColumnを追加するメソッド
     * @param bean
     * @param event
     * @param md
     * @param flg
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
     public void addColumn(SSNaviManagedBean bean,
                           FacesEvent event,
                           MessageDataModel md,
                           Boolean flg)
                           throws LogicException, SystemException {

        //fixme debug 
        long start = System.nanoTime();

        //パラメータ取得
        Map<String, String> param = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
        int tabindex = Integer.parseInt(param.get("tabIndex"));
        int regindex = Integer.parseInt(param.get("regIndex"));
        int colindex = Integer.parseInt(param.get("colIndex"));

        //ObjectValues取得
        ArrayList obj = bean.getObjectValues();
        Map pack = getPackInfo(obj, tabindex, regindex);

        //最終列以外 or 列ドラッグ＆ドロップ可のときは生成しない
        if(ranks.size()-1 != colindex || draggableColumns) return;

        //カラム生成
        columns.add(new EstimateColumnModel("Dummy", "Dummy"));

        //ヘッダ生成
        EstimatePackRank rank = new EstimatePackRank();
        rank.setRankColor(EstimateRankColor.getColor(colindex+1));
        ranks.add(rank);

        //料金に新規Columnを追加
        BigDecimal price;
        for (int i=0; prices.size()>i; i++) {
            List row = prices.get(i);
            price = new BigDecimal("0");
            row.add(price);
        }

        //テーブル幅算出
        if(colindex < UNCHIN_COL_MAX-1) {
            unchinWidth = UNCHIN_COL_SIDE + UNCHIN_COL_WIDTH * (colindex+2) ;
        } else {
            unchinWidth = UNCHIN_COL_SIDE + UNCHIN_COL_WIDTH * UNCHIN_COL_MAX;
        }
        pack.put("unchinWidth", unchinWidth);

        //fixme debug 
        long end = System.nanoTime();
        System.out.println("PackDetail::::: " + (end-start) +"ns");

    }



    /**
     * ランク設定ボタンを選択／未選択状態にするメソッド
     * @param bean
     * @param event
     * @param md
     * @param flg
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    public void selectRank(SSNaviManagedBean bean,
                           FacesEvent event,
                           MessageDataModel md,
                           Boolean flg)
                           throws LogicException, SystemException {

        //パラメータ取得
        Map<String, String> param = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
        String city = param.get("cityCode");
        int tabindex = Integer.parseInt(param.get("tabIndex"));
        int regindex = Integer.parseInt(param.get("regIndex"));
        int colindex = Integer.parseInt(param.get("colIndex"));
        boolean sw = Boolean.parseBoolean(param.get("sw"));

        //ObjectValues取得
        ArrayList obj = bean.getObjectValues();
        Map pack = getPackInfo(obj, tabindex, regindex);

        if(sw) {
            for (int i=0; ranks.size()>i; i++) {
                if(colindex == i) {
                    (ranks.get(i)).setSelected(true);
                } else {
                    (ranks.get(i)).setSelected(false);
                }
            }
        } else {
            ranks.get(colindex).setSelected(false);
        }
    }



    /**
     * 地図で選択した都道府県を料金表の発着地域に反映するメソッド
     * @param bean
     * @param event
     * @param md
     * @param flg
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
     public void setPrefectures(SSNaviManagedBean bean,
                                FacesEvent event,
                                MessageDataModel md,
                                Boolean flg)
                                throws LogicException, SystemException {

        //パラメータ取得
        Map<String, String> param = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
        String code = param.get("pcode");
        int tabindex = Integer.parseInt(param.get("tabIndex"));
        int regindex = Integer.parseInt(param.get("regIndex"));

        //ObjectValues取得
        ArrayList obj = bean.getObjectValues();
        Map pack = getPackInfo(obj, tabindex, regindex);

        //都道府県地図／一覧の要素取得
        EstimatePackCityPrefectures city = getPrefectures(code, 0);

        //既に選択されている都道府県は解除
        if(city.getRank()!=null && !city.getRank().equals("")) {
            for(EstimatePackRank r : ranks) {
                List<String> cities = r.getCities();
                for(String targetCity: cities) {
                    String[] cityProperty = targetCity.split(":");
                    if(cityProperty[0].equals(code)) {
                        cities.remove(targetCity);
                        releasePrefectures(code, 0);
                        break;
                    }
                }
            }

        //ランクに当道府県を追加
        } else {
            EstimatePackRank selRank = getSelectRank();
            String name = city.getCityName();
            List<String> cities = selRank.getCities();
            cities.add(code + ":" + name + ":" + "P");
            city.setRank(selRank.getRank());
            city.setColor(selRank.getRankColor());
        }
    }



    /**
     * 都道府県・市区町村を料金表の発着地域から削除するメソッド
     * @param bean
     * @param event
     * @param md
     * @param flg
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    public void deleteCity(SSNaviManagedBean bean,
                           FacesEvent event,
                           MessageDataModel md,
                           Boolean flg)
                           throws LogicException, SystemException {

        //パラメータ取得
        Map<String, String> param = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
        String city = param.get("cityCode");
        int tabindex = Integer.parseInt(param.get("tabIndex"));
        int regindex = Integer.parseInt(param.get("regIndex"));
        int colindex = Integer.parseInt(param.get("colIndex"));

        //ObjectValues取得
        ArrayList obj = bean.getObjectValues();
        Map pack = getPackInfo(obj, tabindex, regindex);

        //料金表のランクから削除する
        List<String> cities = (ranks.get(colindex)).getCities();
        for(String targetCity: cities) {
            String[] cityProperty = targetCity.split(":");
            if(cityProperty[0].equals(city)) {
                cities.remove(targetCity);
                //地図・一覧の情報を初期化する
                if(cityProperty[2].equals("P")) {
                    releasePrefectures(city, 0);
                } else {
                    //fixme
                }
                break;
            }
        }
    }



    /**
     * ランクColumnの並び順を保存するメソッド
     * @param bean
     * @param event
     * @param md
     * @param flg
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    public void onColumnReorder(SSNaviManagedBean bean,
                                FacesEvent event,
                                MessageDataModel md,
                                Boolean flg)
                                throws LogicException, SystemException {

        //パラメータ取得
        Map<String, String> param = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
        int tabindex = Integer.parseInt(param.get("tabIndex"));
        int regindex = Integer.parseInt(param.get("regIndex"));

        //ObjectValues取得
        ArrayList obj = bean.getObjectValues();
        Map pack = getPackInfo(obj, tabindex, regindex);

        //UIColumn取得
        FacesContext ctx = FacesContext.getCurrentInstance();
        DataTable table = ( DataTable ) ctx.getViewRoot().findComponent(PACK_UNCHIN_DT_ID);
        List<UIColumn> cols = table.getColumns();

        int cnt = 0;
        for (UIColumn col: cols) {
            DynamicColumn dc = (DynamicColumn)col;
            ranks.get(dc.getIndex()).setColOrder(++cnt);
        }
    }



    /**
     * 地図/一覧で選択された都道府県を解除するメソッド
     * @param code
     * @param listnum
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    private void releasePrefectures(String code, int listnum) throws LogicException, SystemException {

        //都道府県地図／一覧の要素取得
        EstimatePackCityPrefectures city = getPrefectures(code, listnum);

        //都道府県要素初期化
        if(city != null) {
            city.setRank(null);
            city.setColor(null);
        }
    }





    /**
     * 「設定中」のランク返却するメソッド
     * @param listnum
     * @return rank object
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    private EstimatePackRank getSelectRank() throws LogicException, SystemException {

        EstimatePackRank result = null;
        for (EstimatePackRank rank : ranks) {
            if (rank.getSelected()) {
                result = rank;
                break;
            }
        }
        return result;
   }



    /**
     * 指定された都道府県を返却するメソッド
     * @param code
     * @param listnum
     * @return prefectures info
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    private EstimatePackCityPrefectures getPrefectures(String code, int listnum) throws LogicException, SystemException {

        EstimatePackCityPrefectures result = null;

        if((listnum==0&&result==null) || listnum==1) {
            for (EstimatePackCityPrefectures city : prefectures1) {
                if (city.getJisCode().equals(code)) {
                    result = city;
                    break;
                }
            }
        }
        if((listnum==0&&result==null) || listnum==2) {
            for (EstimatePackCityPrefectures city : prefectures2) {
                if (city.getJisCode().equals(code)) {
                    result = city;
                    break;
                }
            }
        }
        if((listnum==0&&result==null) || listnum==3) {
            for (EstimatePackCityPrefectures city : prefectures3) {
                if (city.getJisCode().equals(code)) {
                    result = city;
                    break;
                }
            }
        }
        return result;
    }



    /**
     * パック情報をObjectValuesから取得するメソッド(SSNavi乗せ換え対応のため)
     * @param obj
     * @param tabindex
     * @param regindex
     * @return pack
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    private Map getPackInfo(ArrayList obj, int tabindex, int regindex) throws LogicException, SystemException {

        //各種Obj取得
        Map pack = (HashMap)((ArrayList)((HashMap)((HashMap) obj.get(tabindex)).get("EST022-pack")).get("packs")).get(regindex);
        //ランク別設定
        ranks = (List<EstimatePackRank>) pack.get("ranks");
        //動的な列生成用
        columns = (List<EstimateColumnModel>) pack.get("columns");
        //建値設定設定
//      pricePatterns = (List<EstimatePackPricePattern>) pack.get("pricePatterns");
        //料金設定
        prices = (List<List<BigDecimal>>) pack.get("prices");
        //都道府県リスト１
        prefectures1 = (List<EstimatePackCityPrefectures>) pack.get("prefectures1");
        //都道府県リスト２
        prefectures2 = (List<EstimatePackCityPrefectures>) pack.get("prefectures2");
        //都道府県リスト３
        prefectures3 = (List<EstimatePackCityPrefectures>) pack.get("prefectures3");
        //市区町村リスト
        municipalities = (List<EstimatePackCityMunicipality>) pack.get("municipalities");
        //運賃テーブル幅
        unchinWidth = (Integer) pack.get("unchinWidth");
        //料金表ドラッグ＆ドロップモード
        draggableColumns = (Boolean) pack.get("draggableColumns");
        return pack;
    }

}