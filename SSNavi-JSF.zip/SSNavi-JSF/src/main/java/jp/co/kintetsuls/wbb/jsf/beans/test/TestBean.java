/*
 * MenuModelBean.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.wbb.jsf.beans.test;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import javax.faces.event.ActionEvent;

/**
 *
 * @author 
 */
public class TestBean implements Serializable {

    private TestDataModel testDataModel;
    public TestBean() {
        testDataModel = new TestDataModel();
    }

     public void init(HashMap<String, HashMap<String, Object>> values, ActionEvent event, ArrayList<Object> obj) throws Exception {
        if(obj.isEmpty()){
            testDataModel.setStr("777");
            obj.add(testDataModel);
        }        
        if( obj.get(0) instanceof TestDataModel == false ){
            return;
        }
        TestDataModel tb = (TestDataModel)obj.get(0);
        tb.setStr("666");
        obj.add(values);
    }   
}
