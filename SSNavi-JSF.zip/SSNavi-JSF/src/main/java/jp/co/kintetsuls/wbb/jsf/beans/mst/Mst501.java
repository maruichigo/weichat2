/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.wbb.jsf.beans.mst;

import java.io.Serializable;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.event.FacesEvent;
import jp.co.kintetsuls.common.MessageDataModel;
import jp.co.kintetsuls.common.util.MessageProperty;
import jp.co.kintetsuls.wbb.jsf.beans.common.PageSessionBean;
import jp.co.sharedsys.wbb.jsf.beans.SSNaviManagedBean;
import jp.co.sharedsys.wbb.jsf.process.MsgExec;
import jp.co.kintetsuls.common.util.ResourceManager;
import lombok.Getter;
import lombok.Setter;

/**
 * 仕向地名マスタ画面
 *
 * @author MaLei (MBP)
 * @version 2019/1/6 新規作成
 */
@ManagedBean(name = "Mst501")
@ViewScoped
public class Mst501 implements Serializable {

    private static final long serialVersionUID = 1L;

    @ManagedProperty(value = "#{pageSessionBean}")
    private PageSessionBean pageSessionBean;

    @ManagedProperty(value = "#{messageProperty}")
    @Getter
    @Setter
    private MessageProperty messageProperty;

    /**
     * メッセージID：COME0029.
     */
    private static final String MSG_ID_COME0029 = "COME0029";

    /**
     * 定数：画面ID.
     */
    private static final String PAGEID_MST501 = "Mst501";

    /**
     * 定数：遷移元画面ID.
     */
    private static final String PAGEID_MST031 = "Mst031";

    /**
     * ワーク.営業所コード
     */
    private String conEigyoshoCd;

    /**
     * ワーク.顧客コード
     */
    private String conKokyakuCd;

    public PageSessionBean getPageSessionBean() {
        return pageSessionBean;
    }

    public void setPageSessionBean(PageSessionBean pageSessionBean) {
        this.pageSessionBean = pageSessionBean;
    }

    public String getConEigyoshoCd() {
        return conEigyoshoCd;
    }

    public void setConEigyoshoCd(String conEigyoshoCd) {
        this.conEigyoshoCd = conEigyoshoCd;
    }

    public String getConKokyakuCd() {
        return conKokyakuCd;
    }

    public void setConKokyakuCd(String conKokyakuCd) {
        this.conKokyakuCd = conKokyakuCd;
    }

    public Mst501() {
    }

    /**
     * 初期処理
     *
     * @param bean
     */
    public void init(SSNaviManagedBean bean) {

        PageSessionBean pageSession = ResourceManager.getPageSession();
        // 遷移元ID
        if (pageSession != null && pageSession.getPageConData(PAGEID_MST501) != null) {
            String senMotoId = pageSession.getSeniMotoId().get(PAGEID_MST501);
            pageSession.setSaiKensakuFlg(PageSessionBean.SAIKENSAKU); //ToDo 下に移動すべき
            // 戻ってきた場合
            if (PAGEID_MST031.equals(senMotoId)) {
                // 進んできた場合
                // 検索パラメータがある場合、再検索に設定する

            }
        }
    }

    /**
     * 検索処理
     *
     * @param bean
     * @param event
     * @param messageData
     * @param backFlag
     */
    public void search(SSNaviManagedBean bean, FacesEvent event, MessageDataModel messageData, Boolean backFlag) {

        // 入力チェック
        String conShimukeChiMei = (String) bean.getValues().get("detail").get("conShimukeChiMei");
        if (conShimukeChiMei.isEmpty()) {
            MessageProperty messageProp = ResourceManager.getMessageProperty();
            new MsgExec().message("ERROR", MSG_ID_COME0029, messageProp.getProperty(MSG_ID_COME0029));
        }

        // 検索条件をセッションから取得する
        PageSessionBean pageSession = ResourceManager.getPageSession();

        if (PageSessionBean.SAIKENSAKU.equals(pageSession.getSaiKensakuFlg())) {
            bean.setValues(pageSession.getPageConData(PAGEID_MST501));
            pageSession.setSaiKensakuFlg(PageSessionBean.NO_SAIKENSAKU);
        }

        // 検索パラメータをセッションに保存する
        pageSession.setPageConData(PAGEID_MST501, bean.getValues());
    }

    public void clear(SSNaviManagedBean bean, FacesEvent event, MessageDataModel messageData, Boolean backFlag) {
    }

}
