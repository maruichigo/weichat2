/*
 * RoleModel.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.wbb.jsf.beans.mst;

/**
 *
 * @author lihaoyi
 */
public class Mst451Model {
    public String localCode;
    public String localName;
    public String listKinoCd;
    public String listKinoMeisho;
    public String listKinoShubetsu;

    public String getListKinoCd() {
        return listKinoCd;
    }

    public void setListKinoCd(String listKinoCd) {
        this.listKinoCd = listKinoCd;
    }

    public String getListKinoMeisho() {
        return listKinoMeisho;
    }

    public void setListKinoMeisho(String listKinoMeisho) {
        this.listKinoMeisho = listKinoMeisho;
    }

    public String getListKinoShubetsu() {
        return listKinoShubetsu;
    }

    public void setListKinoShubetsu(String listKinoShubetsu) {
        this.listKinoShubetsu = listKinoShubetsu;
    }
    
    public String getLocalCode() {
        return localCode;
    }

    public void setLocalCode(String localCode) {
        this.localCode = localCode;
    }

    public String getLocalName() {
        return localName;
    }

    public void setLocalName(String localName) {
        this.localName = localName;
    }
    
}
