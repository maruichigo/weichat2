/*
 * CommentDialogDataModel.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.wbb.jsf.beans.common;

import javax.xml.bind.annotation.XmlElement;

/**
 * コメントダイアログで使用する情報のModelクラスです。
 *
 * @author sharedSystem
 */
public class CommentDialogDataModel
{
    // 取得後コメント情報
    private String comment;             // コメント

    // コメント更新先情報
    private String tableName;           // テーブル名   例:TR_YUSO_URIAGE
    private String keyColumnName1;      // キー項目名1  例:URIAGE_ID
    private String keyColumnName2;      // キー項目名2  例:
    private String keyColumnName3;      // キー項目名3  例:
    private String updateColumnName;    // 更新項目名   例:URIAGE_COMMENT

    public void CommentDialogDataModel()
    {
        this.comment = "";
        this.tableName = "";
        this.keyColumnName1 = "";
        this.keyColumnName2 = "";
        this.keyColumnName3 = "";
        this.updateColumnName = "";
    }

    @XmlElement(name = "comment")
    public String getComment()
    {
        return comment;
    }

    public void setComment(String comment)
    {
        this.comment = comment;
    }

    @XmlElement(name = "tableName")
    public String getTableName()
    {
        return tableName;
    }

    public void setTableName(String tableName)
    {
        this.tableName = tableName;
    }

    @XmlElement(name = "keyColumnName1")
    public String getKeyColumnName1()
    {
        return keyColumnName1;
    }

    public void setKeyColumnName1(String keyColumnName1)
    {
        this.keyColumnName1 = keyColumnName1;
    }

    @XmlElement(name = "keyColumnName2")
    public String getKeyColumnName2()
    {
        return keyColumnName2;
    }

    public void setKeyColumnName2(String keyColumnName2)
    {
        this.keyColumnName2 = keyColumnName2;
    }

    @XmlElement(name = "keyColumnName3")
    public String getKeyColumnName3()
    {
        return keyColumnName3;
    }

    public void setKeyColumnName3(String keyColumnName3)
    {
        this.keyColumnName3 = keyColumnName3;
    }

    @XmlElement(name = "updateColumnName")
    public String getUpdateColumnName()
    {
        return updateColumnName;
    }

    public void setUpdateColumnName(String updateColumnName)
    {
        this.updateColumnName = updateColumnName;
    }

}