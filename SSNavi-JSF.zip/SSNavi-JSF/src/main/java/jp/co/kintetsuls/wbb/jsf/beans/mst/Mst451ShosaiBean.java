/*
 * TestBean.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.wbb.jsf.beans.mst;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import jp.co.sharedsys.wbb.jsf.exception.LogicException;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;
import jp.co.sharedsys.wbb.jsf.process.Mst451ShosaiProcess;
import lombok.Getter;

/**
 *
 * @author lihaoyi
 */
@ManagedBean(name = "mst451ShosaiBean")
@SessionScoped
public class Mst451ShosaiBean implements Serializable {

    @Getter
    public List<Mst451Model> kinoModelList;
    
    public void search() throws LogicException, SystemException, IOException {
        Mst451ShosaiProcess shosaiProcess = new Mst451ShosaiProcess();
        shosaiProcess.onService(this);
        List<Map<String, Object>> searchResult = shosaiProcess.getSearchResult();
        kinoModelList = new ArrayList();
        for (Map input : searchResult) {
            Mst451Model kinoModel = new Mst451Model();
            kinoModel.setListKinoCd((String) input.get("listKinoCd"));
            kinoModel.setListKinoMeisho((String) input.get("listKinoMeisho"));
            kinoModel.setListKinoShubetsu((String) input.get("listKinoShubetsu"));
            kinoModelList.add(kinoModel);
        }
        ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();
        ec.redirect(ec.getRequestContextPath() + "/contents/mst/mst451_1.xhtml");
    }
    
}
