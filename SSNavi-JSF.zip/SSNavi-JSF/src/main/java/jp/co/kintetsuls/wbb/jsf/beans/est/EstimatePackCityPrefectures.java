/*
 * EstimatePackCityPrefectures.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.wbb.jsf.beans.est;

import java.io.Serializable;

public class EstimatePackCityPrefectures implements Serializable {

    //JISコード
    private String jisCode;

    public String getJisCode() {
        return jisCode;
    }

    public void setJisCode(String value) {
        this.jisCode = value;
    }

    //都道府県名
    private String cityName;

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String value) {
        this.cityName = value;
    }

    //ランク
    private String rank;

    public String getRank() {
        return rank;
    }

    public void setRank(String value) {
        this.rank = value;
    }

    //ランクカラーコード
    private String color;

    public String getColor() {
        return color;
    }

    public void setColor(String value) {
        this.color = value;
    }

    //詳細有無
    private boolean detail;

    public boolean getDetail() {
        return detail;
    }

    public void setDetail(boolean value) {
        this.detail = value;
    }


    public EstimatePackCityPrefectures(String jisCode, String cityName, String rank, String color, boolean detail) {
        this.jisCode = jisCode;
        this.cityName = cityName;
        this.rank = rank;
        this.color = color;
        this.detail = detail;
    }

    public EstimatePackCityPrefectures() {
        this.jisCode = null;
        this.cityName = null;
        this.rank = null;
        this.color = null;
        this.detail = false;
    }
}