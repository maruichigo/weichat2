/*
 * ExternalAuthTokenClientHeader.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.external.general;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.client.ClientRequestContext;
import javax.ws.rs.client.ClientRequestFilter;

/**
 *
 * @author saihara
 */
public class ExternalAuthTokenClientHeader implements ClientRequestFilter {
	private static final String P_EXTERNAL_ACCEPT = "external-accept";

    @Override
    public void filter(ClientRequestContext requestContext) throws IOException {
        // TODO Tokenの取得..
        List<Object> exAccept = new ArrayList<>();
        exAccept.add("571379a6afc692cc5887a89eba692beeb3628a9c816aec11");
        requestContext.getHeaders().put(P_EXTERNAL_ACCEPT, exAccept);
    }
}
