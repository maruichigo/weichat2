/*
 * ExternalInitProcess.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.process;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.wbb.jsf.beans.mst.Mst451HenshuBean;
import jp.co.sharedsys.wbb.jsf.beans.AuthorityConfBean;
import jp.co.sharedsys.wbb.jsf.exception.LogicException;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;
import jp.co.sharedsys.wbb.jsf.reports.ReportConst;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang.StringUtils;

/**
 *
 * @author lihaoyi
 */
public class Mst451InitProcess  extends AbstractExternalProcess<Mst451HenshuBean> {

    @Setter
    private AuthorityConfBean authConf;
    @Getter
    private List<Map<String, Object>> searchResult;
    
    @Override
    public void onService(Mst451HenshuBean mst451HenshuBean) throws LogicException, SystemException {
 
        // 機能モード(SEARCH)
        String modeName = "SEARCH";
        String loginId = "Axis";
        List<String> userGroupCode = new ArrayList<>();
        userGroupCode.add("SYSTEM_ADMIN");
        String service = "JohmonWebService";
        String function = "MST451_HENSHU";
        String tableName = "";
        Map<String, Object> params = new HashMap<>();
         try {
            ServiceInterfaceBean dto = this.requestExternalService(service, params, function, tableName, loginId, userGroupCode, false);

            // Json結果データをMapに変換
            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> jsonResMap = null;

            if (StringUtils.equals(modeName, ReportConst.EditMode.SEARCH)) {
                try {
                    List searchResult = mapper.readValue(dto.getJson(), List.class);
                    this.searchResult = searchResult;
                } catch (IOException e) {
                    logger.error("サービス側から意図しないパラメータが返ってきています。");
                    logger.error(e.getMessage(), e);
                    return ;
                }
            }
        }catch (SystemException e) {
            logger.error(e.getMessage(), e);
        }
    }

}
