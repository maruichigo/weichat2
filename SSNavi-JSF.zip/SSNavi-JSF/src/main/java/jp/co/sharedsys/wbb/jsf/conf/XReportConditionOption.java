package jp.co.sharedsys.wbb.jsf.conf;

import lombok.Data;

@Data
public class XReportConditionOption {
    private String label = "";
    private String value = "";
    private String checked = "";
    private String connection = "";
    private String templateFile = "";

    private String service;
    private String functionCode;
    private String serviceParameter;

    // 2012.11.08 for roots
    private String matchKey = "";
    private String tableName = "";
	
}
