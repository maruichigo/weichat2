package jp.co.sharedsys.wbb.jsf.reports;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import jp.co.sharedsys.bb.ReportFileFilter;

import org.apache.commons.beanutils.BeanComparator;
import org.apache.commons.digester.Digester;
import org.apache.commons.digester.xmlrules.DigesterLoader;
import org.apache.commons.io.comparator.NameFileComparator;
import org.apache.commons.lang.StringUtils;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import jp.co.sharedsys.wbb.jsf.exception.SystemException;
import jp.co.sharedsys.wbb.jsf.conf.XReport;
import jp.co.sharedsys.wbb.jsf.conf.XReportButton;
import jp.co.sharedsys.wbb.jsf.conf.XReportColumn;
import jp.co.sharedsys.wbb.jsf.conf.XReportColumnOption;
import jp.co.sharedsys.wbb.jsf.conf.XReportCondition;
import jp.co.sharedsys.wbb.jsf.conf.XReportConditionOption;
import jp.co.sharedsys.wbb.jsf.conf.XReportFormat;
import jp.co.sharedsys.wbb.jsf.conf.XReportSql;
import jp.co.sharedsys.wbb.jsf.modules.PdfConfigReader;
import jp.co.sharedsys.wbb.jsf.process.ExternalGetAuthorityProcess;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ReportContext {
    private static Map instances = new HashMap();
    private Map<String,ReportConfig> configs = new HashMap<>();
    private Map<String, String> screenCodes = new HashMap<>();
    private Map<String, List<ReportConfig>> configListMap = new HashMap<>();
    private List<ReportAppConfig> repordirs = new ArrayList<>();
    private String confDirectory = null;
    private static final String confName = "report_rule.xml";
    private static final String appConfName = "rep_description_rule.xml";
    private boolean isExternalRefresh = false;
    private Logger logger;
    
    public ReportContext(){
    }

    // JSFのApplicationScopedクラスに持たせるため、Singletonを止める
//	public static ReportContext getInstance(String key){
//		synchronized (instances) {
//			if (instances.containsKey(key)){
//				return (ReportContext) instances.get(key);
//			}else{
//				ReportContext instance = new ReportContext();
//				instances.put(key, instance);
//				return instance;
//			}
//		}
//	}

    public void addReport(String group,ReportConfig report){
    }

    public void init(){
        configs.clear();
        configListMap.clear();
        repordirs.clear();
        logger = LoggerFactory.getLogger("system");
    }


    public void loadDir(File reportapp) throws SystemException {
        Digester d = null;
        ReportAppConfig app = new ReportAppConfig();
        try {
            d = DigesterLoader.createDigester(new InputSource(new FileReader(new File(this.getConfDirectory() + "/conf/" + appConfName))));
            logger.info("DESCRIPTION LOAD START:" + reportapp.getName());
            app = (ReportAppConfig) d.parse(new File(reportapp,"description.xml"));
            app.setDirectory(reportapp.getName());
            logger.info("SHOW-IN-MENU(" + app.getTitle() + "):" + app.isAvailableInMenu() + "/" + app.getShowInMenu());
        } catch (FileNotFoundException e) {
            logger.warn("Report descrition file was not found.[" + reportapp.getPath() + "]");
            app.setDirectory(reportapp.getName());
            app.setTitle(reportapp.getName());
            app.setDescription("No Description");
            app.setShowInMenu("false");
        } catch (IOException e) {
            logger.warn("Error reading report description", e);
            app.setDirectory(reportapp.getName());
            app.setTitle(reportapp.getName());
            app.setDescription("No Description");
            app.setShowInMenu("false");
        } catch (SAXException e) {
            logger.warn("Error reading report description", e);
            app.setDirectory(reportapp.getName());
            app.setTitle(reportapp.getName());
            app.setDescription("No Description");
            app.setShowInMenu("false");
        } finally {
            logger.info("DESCRIPTION LOAD END:" + reportapp.getName());
        }
        this.repordirs.add(app);
        File[] reports = reportapp.listFiles(new ReportFileFilter());
        List reportslist = new ArrayList();
        if (reports != null){
            reportslist = Arrays.asList(reports);
        }
        Collections.sort(reportslist,NameFileComparator.NAME_COMPARATOR);

        configListMap.put(reportapp.getName(), new ArrayList());
        for (Iterator ite = reportslist.iterator();ite.hasNext();){
        //for (int i = 0;i < reports.length;i++){
            loadFile(reportapp,(File) ite.next());
        }
    }

    public synchronized void loadFile(File reportapp,File reportConfig) throws SystemException{
        Digester d = null;

        try {
                d = DigesterLoader.createDigester(new InputSource(new FileReader(new File(this.getConfDirectory() + "/conf/" + confName))));
        } catch (FileNotFoundException e) {
                throw new SystemException(e);
        }
        try {
//Logger.getInstance("").info("!!!!!!!!!!!!!!!!!! name : " + reportConfig.getName());
            XReport xreport = (XReport) d.parse(reportConfig);
            //Initialize reportconfig instance with xml paramters
            ReportConfig report  = new ReportConfig();
            report.setConfigFilePath(reportConfig.getPath());
            report.setConfigDirectory(reportapp.getName());
            report.setConfigFileName(reportConfig.getName());
            report.setLastModified(reportConfig.lastModified());
            report.setTitle(xreport.getTitle());
            if (xreport.getShortTitle() != null){
                report.setShortTitle(xreport.getShortTitle());
            }
            if (xreport.getStyle() != null){
                report.setStyle(xreport.getStyle());
            }
            if (xreport.getParameterPageTemplate() != null) {
                report.setParameterPageTemplate(xreport.getParameterPageTemplate());
            }
            if (xreport.getIcon() != null){
                report.setIcon(xreport.getIcon());
            }
            report.setDescription(xreport.getDescription());
            report.setReportType(xreport.getReportType());
            report.setShowInMenu("true".equalsIgnoreCase(xreport.getShowInMenu()));
            report.setExcelTemplate(xreport.getExcelTemplate());
            report.setCsvTemplate(xreport.getCsvTemplate());
            report.setPageTemplate(xreport.getPageTemplate());
            report.setReloadCondition("true".equalsIgnoreCase(xreport.getReloadCondition()));
            report.setFileSaveScope(xreport.getFileSaveScope());
            report.setFileNameToSave(xreport.getFileNameToSave());
            report.setFilePathToSave(xreport.getFilePathToSave());
            // 2012.12.27 S.Komaji Add
            report.setNullZero("true".equalsIgnoreCase(xreport.getNullZero()));
            report.setScreenCode(xreport.getScreenCode());
            try {
                String pc = xreport.getParameterCheckClass();
                IParameterChecker checker = (IParameterChecker) Class.forName(pc).newInstance();
                report.setParamChecker(checker);
            }catch (Exception ex){
//		logger.warn("Parameter check class [" + xreport.getParameterCheckClass() + "] was not found.");
            }

            for (Iterator ite = xreport.getConditions().iterator();ite.hasNext();){
                XReportCondition xcondition = (XReportCondition) ite.next();
                ReportCondition condition = new ReportCondition();
                condition.setName(xcondition.getName());
                condition.setDisplayName(xcondition.getDisplayName());
                condition.setControlType(xcondition.getControlType());
                condition.setDataType(xcondition.getDataType());
                condition.setDefaultValue(xcondition.getDefaultValue());
                condition.setRequired("true".equalsIgnoreCase(xcondition.getRequired()));
                condition.setCombination(xcondition.getCombination());
                condition.setToolTip(xcondition.getToolTip());
                condition.setSkipIfBlank("true".equals(xcondition.getSkipIfBlank()));
                condition.setApplyTo(xcondition.getApplyTo());
                // 2012.11.08 for roots
                condition.setTargetDynamic(xcondition.getTargetDynamic());
                condition.setImeMode(xcondition.getImeMode());
                condition.setHeaderWidth(xcondition.getHeaderWidth());
                condition.setSize(xcondition.getSize());
                condition.setWidth(xcondition.getWidth());
                condition.setHeight(xcondition.getHeight());
                condition.setLineEnd("true".equalsIgnoreCase(StringUtils.isEmpty(xcondition.getLineEnd()) ? "true" : xcondition.getLineEnd()));
                condition.setPrevColPosition(xcondition.getPrevColPosition());
                condition.setColspan(xcondition.getColspan());
                condition.setSection(xcondition.getSection());
                condition.setEnable("true".equalsIgnoreCase(StringUtils.isEmpty(xcondition.getEnable()) ? "true" : xcondition.getEnable()));
                condition.setVisible("true".equalsIgnoreCase(StringUtils.isEmpty(xcondition.getVisible()) ? "true" : xcondition.getVisible()));
                condition.setExtra1(xcondition.getExtra1());
                condition.setExtra2(xcondition.getExtra2());
                condition.setExtra3(xcondition.getExtra3());
                condition.setExtra4(xcondition.getExtra4());
                condition.setExtra5(xcondition.getExtra5());               

                if (xcondition.getCache() != null && xcondition.getCache().length() > 0){
                        condition.setCache("true".equalsIgnoreCase(xcondition.getCache()));
                }
                try {
                        condition.setMinLength(Integer.parseInt(xcondition.getMinLength()));
                }catch(Exception ex){
                }
                try {
                        condition.setMaxLength(Integer.parseInt(xcondition.getMaxLength()));
                }catch(Exception ex){
                }
                boolean condOptChecked = false;
                for (Iterator oite = xcondition.getOptions().iterator();oite.hasNext();){
                    XReportConditionOption xoption = (XReportConditionOption) oite.next();
                    ReportConditionOption option = new ReportConditionOption();
                    option.setLabel(xoption.getLabel());
                    option.setValue(xoption.getValue());
                    // 2012.11.08 for roots
                    boolean checked = "true".equalsIgnoreCase(xoption.getChecked());
                    if (checked) condOptChecked = checked;
                    option.setMatchKey(xoption.getMatchKey());
                    option.setChecked(checked);
                    option.setConnection(xoption.getConnection());
                    option.setTemplateFile(xoption.getTemplateFile());
                    option.setService(xoption.getService());
                    option.setFunctionCode(xoption.getFunctionCode());
                    option.setTableName(xoption.getTableName());
                    option.setServiceParameter(xoption.getServiceParameter());
                    condition.getOptions().add(option);
                    condition.getOriginalOptions().add(option);
                }
                if (!condOptChecked && !condition.getOptions().isEmpty()) {
                    condition.getOptions().get(0).setChecked(true);
                    condition.getOriginalOptions().get(0).setChecked(true);
                }
                report.getConditions().add(condition);
            }

            for (Iterator ite = xreport.getSqls().iterator();ite.hasNext();){
                XReportSql xsql = (XReportSql) ite.next();
                ReportSql sql = new ReportSql();
                sql.setName(xsql.getName());
                sql.setDescription(xsql.getDescription());
//                sql.setConnection(xsql.getConnection());
                sql.setTemplateFile(xsql.getTemplateFile());
//                sql.setPreparedStatementType("PREPARED-STATEMENT".equalsIgnoreCase(xsql.getStatementType()));
//                sql.setCustomClassType("CUSTOM-MODULE".equalsIgnoreCase(xsql.getStatementType()));
//                sql.setModuleName(xsql.getModuleName());
                if (xsql.getShowResult() == null || "".equals(xsql.getShowResult())){
                    xsql.setShowResult("true");
                }
//                sql.setShowResult("true".equalsIgnoreCase(xsql.getShowResult()));
                if (xsql.getDownloadable() == null || "".equals(xsql.getDownloadable())){
                        xsql.setDownloadable("true");
                }
//                sql.setDownloadable("true".equalsIgnoreCase(xsql.getDownloadable()));
//                sql.setShowAddRowButton("true".equalsIgnoreCase(xsql.getShowAddRowButton()));
//                sql.setShowDelRowButton("true".equalsIgnoreCase(xsql.getShowDelRowButton()));

//                sql.setDataClass(xsql.getDataClass());
//                if (StringUtils.isEmpty(sql.getDataClass())) {
//                        sql.setDataClass(ReportConst.DATA_CLASS.header.name());
//                }
//                sql.setDetailMode(xsql.getDetailMode());
//                if (StringUtils.isEmpty(sql.getDetailMode())) {
//                        sql.setDetailMode(ReportConst.DETAIL_MODE.line.name());
//                }

                sql.setService(xsql.getService());
                sql.setFunctionCode(xsql.getFunctionCode());
                sql.setTableName(xsql.getTableName());
                report.getSqls().add(sql);
            }

            for (Iterator ite = xreport.getButtons().iterator();ite.hasNext();){
                XReportButton xbutton = (XReportButton) ite.next();
                ReportButton button = new ReportButton();
                button.setName(xbutton.getName());
                button.setValue(xbutton.getValue());
                button.setAction(xbutton.getAction());
                button.setRptFile(xbutton.getRptFile());
                button.setRptDir(xbutton.getRptDir());
                button.setService(xbutton.getService());
                button.setTabTitle(xbutton.getTabTitle());
                button.setFunctionCode(xbutton.getFunctionCode());

                // 2015.09.08 add Pdf settings
                if (!StringUtils.isEmpty(xbutton.getPdfGroupFile())) {
                        button.setPdfGroups(PdfConfigReader.get(xbutton.getPdfGroupFile()));
                }
                button.setPosition(xbutton.getPosition());
                for (Iterator oite = xbutton.getOptions().iterator();oite.hasNext();){
                    XReportConditionOption xoption = (XReportConditionOption) oite.next();
                    ReportConditionOption option = new ReportConditionOption();
                    option.setLabel(xoption.getLabel());
                    option.setValue(xoption.getValue());
                    // 2012.11.08 for roots
                    option.setMatchKey(xoption.getMatchKey());
                    option.setChecked("true".equalsIgnoreCase(xoption.getChecked()));
                    option.setConnection(xoption.getConnection());
                    option.setTemplateFile(xoption.getTemplateFile());
                    option.setService(xoption.getService());
                    option.setFunctionCode(xoption.getFunctionCode());
                    option.setServiceParameter(xoption.getServiceParameter());
                    button.getOptions().add(option);
                    button.getOriginalOptions().add(option);
                }

                report.getButtons().add(button);
            }

            for (Iterator ite = xreport.getFormats().iterator();ite.hasNext();){
                XReportFormat xformat = (XReportFormat) ite.next();
                ReportFormat format = new ReportFormat();
                format.setFieldName(xformat.getFieldName());
                format.setType(xformat.getType());
                format.setPattern(xformat.getPattern());
                report.getFormats().add(format);
            }

            // 2012.08.13 N.Ichijo Add
            ReportModification mod = new ReportModification();
            if(xreport.getModification() != null){
                mod.setDefaultLine(xreport.getModification().getDefaultLine());
                mod.setDelete(xreport.getModification().getDelete());
                mod.setInsert(xreport.getModification().getInsert());
                mod.setMode(xreport.getModification().getMode());
                mod.setUpdate(xreport.getModification().getUpdate());
                report.setModification(mod);
                for (Iterator ite = xreport.getModification().getColumns().iterator();ite.hasNext();){
                    XReportColumn xcolumn = (XReportColumn) ite.next();
                    ReportColumn column = new ReportColumn();
                    column.setName(xcolumn.getName());
                    column.setDisplayName(xcolumn.getDisplayName());
                    column.setControlType(xcolumn.getControlType());
                    column.setDataType(xcolumn.getDataType());
                    column.setDefaultValue(xcolumn.getDefaultValue());
                    column.setRequired("true".equalsIgnoreCase(xcolumn.getRequired()));
                    column.setCombination(xcolumn.getCombination());
                    column.setToolTip(xcolumn.getToolTip());
                    column.setSkipIfBlank("true".equals(xcolumn.getSkipIfBlank()));
                    column.setApplyTo(xcolumn.getApplyTo());
                    // 2012.11.08 for roots
                    column.setTargetDynamic(xcolumn.getTargetDynamic());
                    if (xcolumn.getCache() != null && xcolumn.getCache().length() > 0){
                            column.setCache("true".equalsIgnoreCase(xcolumn.getCache()));
                    }
                    try {
                            column.setMinLength(Integer.parseInt(xcolumn.getMinLength()));
                    }catch(Exception ex){
                    }
                    try {
                            column.setMaxLength(Integer.parseInt(xcolumn.getMaxLength()));
                    }catch(Exception ex){
                    }
                    column.setPrefix(xcolumn.getPrefix());
                    column.setSuffix(xcolumn.getSuffix());
                    try {
                            column.setSortIndex(Integer.parseInt(xcolumn.getSortIndex()));
                    }catch(Exception ex){
                    }
                    try {
                            column.setTabIndex(Integer.parseInt(xcolumn.getTabIndex()));
                    }catch(Exception ex){
                    }
                    column.setReadonly("true".equalsIgnoreCase(xcolumn.getReadonly()));
                    column.setLineEnd("true".equalsIgnoreCase(xcolumn.getLineEnd()));
                    column.setPk("true".equalsIgnoreCase(xcolumn.getPk()));
                    boolean columnOptChecked = false;
                    for (Iterator oite = xcolumn.getOptions().iterator();oite.hasNext();){
                        XReportColumnOption xoption = (XReportColumnOption) oite.next();
                        ReportColumnOption option = new ReportColumnOption();
                        boolean checked = "true".equalsIgnoreCase(xoption.getChecked());
                        if (checked) columnOptChecked = true;
                        option.setLabel(xoption.getLabel());
                        option.setValue(xoption.getValue());
                        option.setChecked(checked);
                        option.setConnection(xoption.getConnection());
                        option.setTemplateFile(xoption.getTemplateFile());
                        option.setService(xoption.getService());
                        option.setFunctionCode(xoption.getFunctionCode());
                        option.setServiceParameter(xoption.getServiceParameter());
                        column.getOptions().add(option);
                        column.getOriginalOptions().add(option);
                    }
                    if (!columnOptChecked && !column.getOptions().isEmpty()) {
                        column.getOptions().get(0).setChecked(true);
                        column.getOriginalOptions().get(0).setChecked(true);
                    }
                    column.setTransferRptFile(xcolumn.getTransferRptFile());
                    column.setTransferRptDir(xcolumn.getTransferRptDir());
                    column.setTransferTabTitle(xcolumn.getTransferTabTitle());
                    column.setTableName(xcolumn.getTableName());
                    column.setImeMode(xcolumn.getImeMode());
                    column.setHeaderWidth(xcolumn.getHeaderWidth());
                    column.setSize(xcolumn.getSize());
                    column.setWidth(xcolumn.getWidth());
                    column.setHeight(xcolumn.getHeight());
                    column.setPrevColPosition(xcolumn.getPrevColPosition());
                    column.setConfirmRequired("true".equalsIgnoreCase(xcolumn.getConfirmRequired()));
                    column.setTableEnd("true".equalsIgnoreCase(xcolumn.getTableEnd()));
                    column.setTableBreak("true".equalsIgnoreCase(xcolumn.getTableBreak()));
                    column.setColspan(xcolumn.getColspan());
                    column.setRowspan(xcolumn.getRowspan());
                    column.setEnterKeyEventServiceRun("true".equalsIgnoreCase(xcolumn.getEnterKeyEventServiceRun()));
                    column.setService(xcolumn.getService());
                    column.setFunctionCode(xcolumn.getFunctionCode());
                    column.setRemoveTableHeader("true".equalsIgnoreCase(xcolumn.getRemoveTableHeader()));
                    column.setExtra1(xcolumn.getExtra1());
                    column.setExtra2(xcolumn.getExtra2());
                    column.setExtra3(xcolumn.getExtra3());
                    column.setExtra4(xcolumn.getExtra4());
                    column.setExtra5(xcolumn.getExtra5());
                    column.setSection(xcolumn.getSection());
                    column.setEnable("true".equalsIgnoreCase(StringUtils.isEmpty(xcolumn.getEnable()) ? "true" : xcolumn.getEnable()));
                    column.setVisible("true".equalsIgnoreCase(StringUtils.isEmpty(xcolumn.getVisible()) ? "true" : xcolumn.getVisible()));
                    report.getModification().getColumns().add(column);
		}
            }
            // 2012.08.13 N.Ichijo End
            // タブ順をキレイに揃える
            List<ReportColumn> colList = report.getModification().getColumns();
            Collections.sort(colList,  new BeanComparator("tabIndex"));
            int tabidx = 1;
            for(ReportColumn col : colList) {
                if (StringUtils.equals("HIDDEN", col.getControlType())
                    || StringUtils.equals("LABEL", col.getControlType())) {
                    // HIDDENとLABELはタブ順の設定はしないため、-1をセット
                    col.setTabIndex(-1);
                } else {
                    if (col.getTabIndex() < 0) {
                        col.setTabIndex(col.getTabIndex());
                    } else {
                        col.setTabIndex(tabidx);
                        tabidx++;
                    }
                }
            }

            //Reload時用の処理
//			configs.put(reportapp.getName() + "." + reportConfig.getName() , report);
            this.configs.put(report.getScreenCode(), report);
            this.screenCodes.put(reportapp.getName() + "." + reportConfig.getName(), report.getScreenCode());
            
            List<ReportConfig> reportList = configListMap.get(reportapp.getName());
            boolean modified = false;
            for (int i = 0;i < reportList.size();i++){
                //登録済みのReportConfigがあった場合、新規の読み込んだものと差し替え
                ReportConfig reportconfig = reportList.get(i);
                if (reportconfig.getConfigFilePath().equals(report.getConfigFilePath())){
                    reportList.set(i, report);
                    modified = true;
                }
            }
            //前回の読み込みからファイルが増えている
            if (!modified){
                    reportList.add(report);
            }

        } catch (IOException e) {
            throw new SystemException(e);
        } catch (SAXException e) {
            throw new SystemException(e);
        }
    }

    /**
     * 外部からのメニュー情報取得
     * @param externalService exservice name
     * @param externalFunction function code
     * @param externalUser username
     */
    public void loadExternal(String externalService, String externalFunction, String externalUser) {
        // 更新は1回のみ。既にされていたら何もしない
        if (isExternalRefresh) return;
        ExternalGetAuthorityProcess process = new ExternalGetAuthorityProcess();
        List<Map<String, Object>> result = process.externalService(externalUser, Arrays.asList(new String[]{"dummy"}), externalService, externalFunction, "", this.createGetAuthParameter(externalUser));
        this.buildDbMenuList(result);
        isExternalRefresh = true;
    }
    private List<Map<String, Object>> createGetAuthParameter(String externalUser) {
        List<Map<String, Object>> prmList = new ArrayList<>();
	Map<String, Object> data = new HashMap<>();
        prmList.add(data);
        data.put("userId", externalUser);

        return prmList;
    }

    public Map<String, List<Map<String, List<String>>>> getMenuMap() {
        return menuMap;
    }

    public Map<String, String> getIconMap() {
        return iconMap;
    }

    public Map<String, String> getGroupNameMap() {
        return groupNameMap;
    }

    private Map<String, List<Map<String, List<String>>>> menuMap = new LinkedHashMap<>();
    private Map<String, String> iconMap = new HashMap<>();
    private Map<String, String> groupNameMap = new HashMap<>();    
    
    private void buildDbMenuList(List<Map<String, Object>> authResult) {
        Map<String, List<String>> result = new LinkedHashMap<>();
        List<ReportAppConfig> reportDirs = this.getRepordirs();
        Map<String, List<ReportConfig>> configs = this.getConfigListMap();
        Map<String, ReportAppConfig> appMap = new HashMap<>();
        for (Map<String, Object> auth : authResult) {
            List<String> inMenu = null;
            String parent = (String)auth.get("parentFunctionCode");
            String functionType = (String)auth.get("functionType");
            String rptDirectory = (String)auth.get("rptDirectory");
            String description = (String)auth.get("description");
            String title = (String)auth.get("title");

            if ("MENU".equals(functionType)) {
                // functionTypeがMENUなら、カテゴリのリストを作る
                String categoryCode = (String)auth.get("functionCode");
                if (result.get(categoryCode) == null) {
                    inMenu = new ArrayList<>();
                    result.put(categoryCode, inMenu);
                }
                // ReportAppConfig check
                ReportAppConfig app = null;
                for (int i = 0; i < reportDirs.size(); i++) {
                    ReportAppConfig tmpapp = (ReportAppConfig)reportDirs.get(i);
                    if (tmpapp != null && tmpapp.getScreenCode().equals(categoryCode)) {
                        app = tmpapp;
                        break;
                    }
                }
                if (app == null) {
                    app = new ReportAppConfig();
                    app.setShowInMenu("true");
                    reportDirs.add(app);
                }
                // DBの内容でdescription,title,directoryを書き換える
                app.setDescription(description);
                app.setTitle(title);
                app.setDirectory(rptDirectory);
                app.setScreenCode(categoryCode);
                appMap.put(categoryCode, app);
                // ReportAppConfig check end
                continue;
            }

            if ("SCREEN".equals(functionType)) {
                inMenu = result.get(parent);
                // リストが作られていればカテゴリ直下の画面Function
                if (inMenu == null) {
                    continue;
                }
                inMenu.add((String)auth.get("functionCode"));

                // ReportConfig check
                String catDirectory = appMap.get(parent).getDirectory();
                List<ReportConfig> catConfigList = configs.get(catDirectory);
                if (catConfigList == null) {
                    catConfigList = new ArrayList<>();
                    configs.put(catDirectory, catConfigList);
                }
                ReportConfig config = null;
                ReportConfig tmpconf = null;
                List<ReportConfig> configList = configs.get(rptDirectory);
                if (configList == null) {
                        continue;
                }
                for (int i = 0; i < configList.size(); i++) {
                    tmpconf = configList.get(i);
                    if (tmpconf != null && tmpconf.getConfigFileName().equals((String)auth.get("rptFileName"))) {
                            break;
                    }
                    tmpconf = null;
                }
                if (tmpconf == null) {
                    // rptファイルなし
                    continue;
                }
                if (!catDirectory.equals(rptDirectory)) {
                    // MENUで指定されているDirectoryとSCREENのDirectoryが違う場合はリストに追加
                    config = (ReportConfig)tmpconf.clone();
                    catConfigList.add(config);
                } else {
                    config = tmpconf;
                }

                // DBの内容でdescription,title,screenCodeを書き換える
                config.setTitle(title);
                config.setDescription(description);
                config.setScreenCode((String)auth.get("screenCode"));
                config.setShowInMenu(true);
                this.configs.put(config.getScreenCode(), config);
                this.screenCodes.put(config.getConfigDirectory() + "." + config.getConfigFileName(), config.getScreenCode());
                // ReportConfig check end
            }
        }
    }

    public String getConfDirectory() {
        return confDirectory;
    }

    public void setConfDirectory(String confDirectory) {
        this.confDirectory = confDirectory;
    }

    public Map<String, ReportConfig> getConfigs() {
        return configs;
    }
    public Map<String, String> getScreenCodes() {
        return screenCodes;
    }

    public Map<String, List<ReportConfig>> getConfigListMap() {
        return configListMap;
    }

    public List<ReportAppConfig> getRepordirs() {
        return repordirs;
    }

    public String getGroupName(String groupId){
	return groupNameMap.get(groupId);
    }    
    
}
