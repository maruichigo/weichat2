package jp.co.sharedsys.wbb.jsf.reports;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import jp.co.sharedsys.wbb.jsf.exception.LogicException;

public class Input implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 7267143181558166402L;
    public static final String TYPE_DATE = "DATE";
    public static final String TYPE_DATETIME = "DATETIME";
    public static final String TYPE_INTEGER = "INTEGER";
    public static final String TYPE_DOUBLE = "DOUBLE";
    public static final String TYPE_LONG = "LONG";
    public static final String TYPE_TEXT = "TEXT";

    private String name = null;
    private List values = new ArrayList();
    private String type = null;
    private String applyTo = "";
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public List getValues() {
        return values;
    }

    public Object getValue(){
        if (values.size() > 0){
            return values.get(0);
        }else{
            return null;
        }
    }

    public void validateType(boolean ignoreifblank) throws LogicException{
        for (Iterator ite = values.iterator();ite.hasNext();){
            String v = (String) ite.next();
            if (ignoreifblank) {
                if(v == null || "".equals(v)){
                    return;
                }
            }
            if (TYPE_TEXT.equalsIgnoreCase(this.getType())){
                return;
            }else if (TYPE_DATE.equalsIgnoreCase(this.getType())){
                try {
                    new SimpleDateFormat("yyyy/MM/dd").parse(v);
                }catch(Exception ex){
                    throw new LogicException("invalid format");
                }
            }else if (TYPE_DATETIME.equalsIgnoreCase(this.getType())){
                try {
                    new SimpleDateFormat("yyyy/MM/dd hh:mm:ss").parse(v);
                }catch(Exception ex){
                    throw new LogicException("invalid format");
                }
            }else if (TYPE_INTEGER.equalsIgnoreCase(this.getType())){
                try {
                    Integer.parseInt(v);
                }catch(Exception ex){
                    throw new LogicException("invalid format");
                }
            }else if (TYPE_LONG.equalsIgnoreCase(this.getType())){
                try {
                    Long.parseLong(v);
                }catch(Exception ex){
                        throw new LogicException("invalid format");
                }
            }else if (TYPE_DOUBLE.equalsIgnoreCase(this.getType())){
                try {
                    Double.parseDouble(v);
                }catch(Exception ex){
                    throw new LogicException("invalid format");
                }
            }
        }
    }
    public String getApplyTo() {
        return applyTo;
    }
    public void setApplyTo(String applyTo) {
        this.applyTo = applyTo;
    }

    public void clearValues() {
        this.values.clear();
    }
}
