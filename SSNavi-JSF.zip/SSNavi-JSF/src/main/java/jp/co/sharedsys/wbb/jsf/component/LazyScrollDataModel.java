/*
 * LazyScrollDataModel.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.component;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.model.DataModelEvent;
import javax.faces.model.DataModelListener;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SelectableDataModel;
import org.primefaces.model.SortMeta;
import org.primefaces.model.SortOrder;

/**
 *
 * @author saihara
 */
public abstract class LazyScrollDataModel<T> extends LazyDataModel<T> implements SelectableDataModel<T>, Serializable{
    // Class Variables
    private boolean cachingRowData;
    private Map<String, Object> filters;
    private int first;
    private List<SortMeta> multiSortMeta;
    private int pageSize;
    private transient Map<Integer, T> rowDataCache;
    private int rowCount;
    private int rowIndex;
    private SortOrder sortOrder;
    private String sortField;

    /**
     * Constructor
     */
    public LazyScrollDataModel(){
        super();
        this.rowIndex = -1;
    }

    /**
     * Creates a new Row Data Cache up to [N] Rows at a time; N being the
     * Page / Scroll Size defined when the DataModel is loaded.
     */
    private void createRowDataCache(){
        this.rowDataCache = new LinkedHashMap<Integer, T>(getPageSize()){
            @Override
            protected boolean removeEldestEntry(Map.Entry<Integer, T> eldest){
                return size() > getPageSize();
            }
        };
    }

    /**
     * Returns the Filters that were applied to the DataModel when it was loaded
     * @return the Filters that were applied to the DataModel when it was loaded
     */
    public Map<String, Object> getFilters(){
        return filters;
    }

    /**
     * Returns the Row Index of the First Row to load the in the DataModel
     * <p>
     * This will change during each LiveScroll.<br>
     * 0 - Initial<br>
     * Scroll (Scroll Size 15)<br>
     * 15 - Secondary<br>
     * Scroll<br>
     * 30 - etc...
     *
     * @return the Row Index of the First Row to load the in the DataModel
     */
    public int getFirst(){
        return first;
    }

    /**
     * Returns the Last Available Row Index in the DataModel
     * <p>
     * This will either be the [First Row Index + the Page Size] or
     * the [Total Row Count] if the former exceeds the total row count.
     *
     * @return the Last Available Row Index in the DataModel
     */
    public int getLast(){
        return ((getFirst() + getPageSize()) > getRowCount() ? getRowCount() : (getFirst() + getPageSize())) - 1;
    }

    /**
     * Returns the MultiSortMeta that was applied to the DataModel when it was loaded
     * @return the MultiSortMeta that was applied to the DataModel when it was loaded
     */
    public List<SortMeta> getMultiSortMeta(){
        return multiSortMeta;
    }

    /**
     * Returns the DataModel Page / Scroll Size
     * @return the DataModel Page / Scroll Size
     */
    @Override
    public int getPageSize(){
        return pageSize;
    }

    /**
     * Returns the Total Amount of Rows expected to be available within the DataModel
     * @return the Total Amount of Rows expected to be available within the DataModel
     */
    @Override
    public int getRowCount(){
        return rowCount;
    }

    /**
     * Returns the Object associated with the Current Row Index within the DataModel
     * <p>
     * This method has been modified for LiveScrolling.  It will initially
     * look in the Wrapped Cache for the Row Data.  If the Row Data cannot be found
     * then proceed to look in the Row Data Cache.  If the Row Data still cannot
     * be found then create a Row Data Cache in blocks of [Page Size] and return
     * the Data from the newly created Cache.
     *
     * @return the Object associated with the Current Row Index within the DataModel
     */
    @Override
    public T getRowData(){
        if(getRowIndex() >= getFirst() && getRowIndex() <= getLast()){ // Wrapped Cache
            return ((List<T>) getWrappedData()).get(getRowIndex() % getPageSize());
        }
        else if(getRowDataCache() != null && getRowDataCache().containsKey(getRowIndex())){ // Row Data Cache
            return getRowDataCache().get(getRowIndex());
        }
        else{ // DataSource Call Necessary - Create Row Data Cache
            // Initialize Row Data Cache if preload() wasn't called
            if(getRowDataCache() == null){
                createRowDataCache();
            }

            // Create Row Data Cache
            this.cachingRowData = true;
            List<T> data = getMultiSortMeta() != null ?
                           load(getRowIndex(), getPageSize(), getMultiSortMeta(), getFilters()) :
                           load(getRowIndex(), getPageSize(), getSortField(), getSortOrder(), getFilters());
            this.cachingRowData = false;
            for(int i = 0, j = getRowIndex(), n = data.size(); i < n; i++, j++){
                getRowDataCache().put(j, data.get(i));
            }
            return getRowDataCache().get(getRowIndex());
        }
    }

    /**
     * Returns the Row Data Cache
     * <p>
     * This will contain Row Data for [N] Rows (N being the Page / Scroll Size
     * defined when the DataModel is loaded.)
     *
     * @return the Row Data Cache
     */
    public Map<Integer, T> getRowDataCache(){
        return rowDataCache;
    }

    /**
     * Returns the current Row Index
     * @return the current Row Index
     */
    @Override
    public int getRowIndex(){
        return rowIndex;
    }

    /**
     * Returns the Sort Order that was applied to the DataModel when it was loaded
     * @return the Sort Order that was applied to the DataModel when it was loaded
     */
    public SortOrder getSortOrder(){
        return sortOrder;
    }

    /**
     * Returns the Sort Field that was applied to the DataModel when it was loaded
     * @return the Sort Field that was applied to the DataModel when it was loaded
     */
    public String getSortField(){
        return sortField;
    }

    /**
     * Returns whether the DataModel is "re"loading data using one of the
     * load() methods for the purpose of Caching Row Data in order to properly
     * process child components
     *
     * @return true if caching row data; false otherwise
     */
    private boolean isCachingRowData(){
        return cachingRowData;
    }

    /**
     * Returns whether the Row is Available
     * <p>
     * The row will never be available if there is no Wrapped Data.
     * <p>
     * Otherwise this method has been modified for LiveScrolling to expand
     * the definition of the availability for the row to include all Data
     * instead of just within the Wrapped Data.
     *
     * @return true if the row is exists; false otherwise
     */
    @Override
    public boolean isRowAvailable(){
        // Never Loaded
        if(getWrappedData() == null){
            return false;
        }

        // Modified to include all Data instead of just the Wrapped Data
        return getRowIndex() >= 0 && getRowIndex() <= getLast();
    }

    /**
     * Loads the DataModel for the given parameters
     * <p>
     * When implementing this method for LiveScrolling, you must first call
     * {@link #preload(int, int, java.lang.String, org.primefaces.model.SortOrder, java.util.Map)}.
     * This will solve restoration problems with the RowEditor feature and
     * fix broken Command Buttons/Links.
     * <p>
     * You should set the Total Row Count within this method.
     *
     * @param first the Row Index of the First Row to load the in the DataModel
     * @param pageSize the DataModel Page / Scroll Size
     * @param sortField the Sort Field that is to be applied to the DataModel
     * @param sortOrder the Sort Order that is to be applied to the DataModel
     * @param filters the Filters that are to be applied to the DataModel
     * @return the loaded data
     */
    @Override
    public List<T> load(int first, int pageSize, String sortField, SortOrder sortOrder, Map<String,Object> filters) {
        throw new UnsupportedOperationException("Lazy loading is not implemented.");
    }

    /**
     * Loads the DataModel for the given parameters
     * <p>
     * When implementing this method for LiveScrolling, you must first call
     * {@link #preload(int, int, java.util.List, java.util.Map)}.
     * This will solve restoration problems with the RowEditor feature and
     * fix broken Command Buttons/Links.
     * <p>
     * You should set the Total Row Count within this method.
     *
     * @param first the Row Index of the First Row to load the in the DataModel
     * @param pageSize the DataModel Page / Scroll Size
     * @param multiSortMeta the MultiSortMeta that is to be applied to the DataModel
     * @param filters the Filters that are to be applied to the DataModel
     * @return the loaded data
     */
    @Override
    public List<T> load(int first, int pageSize, List<SortMeta> multiSortMeta, Map<String,Object> filters) {
        throw new UnsupportedOperationException("Lazy loading is not implemented.");
    }

    /**
     * Initializes the Row Data Cache and stores the Load Values that will
     * be used when loading the Row Data Cache
     *
     * @param first the Row Index of the First Row to load the in the DataModel
     * @param pageSize the DataModel Page / Scroll Size
     * @param sortField the Sort Field that is to be applied to the DataModel
     * @param sortOrder the Sort Order that is to be applied to the DataModel
     * @param filters the Filters that are to be applied to the DataModel
     */
    public void preload(int first, int pageSize, String sortField, SortOrder sortOrder, Map<String,Object> filters){
        // Remember Load Values for Reloading Row Data Cache
        if(!isCachingRowData()){
            this.first = first;
            this.pageSize = pageSize;
            this.sortField = sortField;
            this.sortOrder = sortOrder;
            this.filters = filters;
        }

        // Create the Row Data Cache once for the first load.
        if(!isCachingRowData() && first == 0){
            createRowDataCache();
        }
    }

    /**
     * Initializes the Row Data Cache and stores the Load Values that will
     * be used when loading the Row Data Cache
     *
     * @param first the Row Index of the First Row to load the in the DataModel
     * @param pageSize the DataModel Page / Scroll Size
     * @param multiSortMeta the MultiSortMeta that is to be applied to the DataModel
     * @param filters the Filters that are to be applied to the DataModel
     */
    public void preload(int first, int pageSize, List<SortMeta> multiSortMeta, Map<String,Object> filters){
        // Remember Load Values for Reloading Row Data Cache
        if(!isCachingRowData()){
            this.first = first;
            this.pageSize = pageSize;
            this.multiSortMeta = multiSortMeta;
            this.filters = filters;
        }

        // Create the Row Data Cache once for the first load.
        if(!isCachingRowData() && first == 0){
            createRowDataCache();
        }
    }

    /**
     * Sets the DataModel Page / Scroll Size
     * @param pageSize the given size
     */
    @Override
    public void setPageSize(int pageSize){
        this.pageSize = pageSize;
    }

    /**
     * Sets the Total Amount of Rows expected to be available within the DataModel
     * @param rowCount the given row count
     */
    @Override
    public void setRowCount(int rowCount){
        if(!isCachingRowData())
            this.rowCount = rowCount;
    }

    /**
     * Sets the current Row Index
     * <p>
     * This method has been modifed for LiveScrolling to prevent the
     * Row Index from being modifed for Pagination
     *
     * @param rowIndex the given index
     */
    @Override
    public void setRowIndex(int rowIndex){
        int oldIndex = this.rowIndex;

        if(rowIndex == -1 || getPageSize() == 0)
            this.rowIndex = -1;
        else // Don't Adjust the Row Index for Pagination
            this.rowIndex = rowIndex;

        if(getWrappedData() == null){
            return;
        }

        DataModelListener[] listeners = getDataModelListeners();
        if(listeners != null && oldIndex != this.rowIndex){
            Object rowData = null;
            if(isRowAvailable()){
                rowData = getRowData();
            }

            DataModelEvent dataModelEvent = new DataModelEvent(this, rowIndex, rowData);
            for(DataModelListener listener : listeners){
                listener.rowSelected(dataModelEvent);
            }
        }
    }
}
