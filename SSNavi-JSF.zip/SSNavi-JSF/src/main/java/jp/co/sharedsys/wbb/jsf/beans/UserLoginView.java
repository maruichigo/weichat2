/*
 * UserLoginView.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.beans;

import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import jp.co.sharedsys.wbb.jsf.exception.LogicException;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;
import jp.co.sharedsys.wbb.jsf.process.ExternalGetAuthorityProcess;
import jp.co.sharedsys.wbb.jsf.process.MenuCreationProcess;
import lombok.Data;
import org.primefaces.context.RequestContext;

/**
 *
 * @author saihara
 */
@ManagedBean
@RequestScoped
@Data
public class UserLoginView {
     
    private String username;
    private String password;
    private String message = "";
    private boolean loggedIn;
    private String status;
    private String extMessage;
    private List<String> userGroupCodes;
    //private List<String> dataGroupCodes;
    
    @ManagedProperty(value="#{ssconfig}")
    private JsfSatteliteApplicationBean ssconfig;
    @ManagedProperty(value="#{pageBean}")
    private SSNaviManagedBean pageBean;

    @ManagedProperty(value = "#{menuBean}")
    private MenuBean menuBean;
    @ManagedProperty(value = "#{authConf}")
    private AuthorityConfBean authConf;
    
    public String login() throws SystemException, LogicException {
        RequestContext context = RequestContext.getCurrentInstance();
        FacesMessage message = null;
        setTimeout(); 
         
        this.message = "";
        String resultPage = "";
        if(username != null &&  password != null) {
            if (username.equals("axis")) {
                loggedIn = true;
                message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Welcome", username);
                authConf.setAdmin(true);
            }
            // TODO fortest
//           userGroupCodes = Arrays.asList(new String[]{"SYSTEM_ADMIN"});
           userGroupCodes = Arrays.asList(new String[]{"TEST"});
            // fortest end
            resultPage = afterLogin();
        } else {
            loggedIn = false;
            message = new FacesMessage(FacesMessage.SEVERITY_WARN, "Login Error", "Invalid ID or password.");
            this.message = "";
            FacesContext.getCurrentInstance().addMessage(null, message);
        }
         
        context.addCallbackParam("loggedIn", loggedIn);
        
        return resultPage;
    }
    
    private String afterLogin() throws SystemException, LogicException {        

        ExternalGetAuthorityProcess authProcess = new ExternalGetAuthorityProcess();
        MenuCreationProcess rule = new MenuCreationProcess();
        try {
            // 権限情報の取得
            //authProcess.onService(this);
            // Menuの組み立て
            //rule.onService(this);
            return pageBean.init();
        } catch (SystemException ex) {
            Logger.getLogger(UserLoginView.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        }
    }
    // web.xml - session-timeout の設定値を取得し、ssconfig内のsessionTimeoutに渡す
    private void setTimeout() {
        if (ssconfig.getSessionTimeout() == null) {
//            System.out.println("getSessionTimeout ⇒ null");
            HttpSession session = (HttpSession)  FacesContext.getCurrentInstance().getExternalContext().getSession(false);
//            System.out.println("getMaxInactiveInterval : " + String.valueOf(session.getMaxInactiveInterval()));

            ssconfig.setSessionTimeout(String.valueOf(session.getMaxInactiveInterval() * 1000)); 
//        } else {
//            System.out.println("getSessionTimeout ⇒ not null");
        }
    }
}