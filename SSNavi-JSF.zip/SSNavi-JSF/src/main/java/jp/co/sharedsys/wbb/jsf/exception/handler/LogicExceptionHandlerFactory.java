/*
 * LogicExceptionHandlerFactory.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.exception.handler;

import javax.faces.context.ExceptionHandler;
import javax.faces.context.ExceptionHandlerFactory;

/**
  * カスタム例外ハンドラファクトリの実装
 *
 * @author saihara
 */
public class LogicExceptionHandlerFactory extends ExceptionHandlerFactory {

    private ExceptionHandlerFactory parent;

    public LogicExceptionHandlerFactory(ExceptionHandlerFactory parent) {
        this.parent = parent;
    }
	
    @Override
    public ExceptionHandler getExceptionHandler() {
        ExceptionHandler handler = new LogicExceptionHandler(parent.getExceptionHandler());
        return handler;
    }
}    
