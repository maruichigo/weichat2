package jp.co.sharedsys.bb;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ApplicationManager {

    public static final String DIR_APP = "batchapps";
    public static final String DIR_CONF = "conf";

    private String homeDirectory = null;

    private static ApplicationManager instance = new ApplicationManager();

    private Map workspaces = new HashMap();

    private Logger logger = LoggerFactory.getLogger("system");
    private ApplicationManager(){
    }

    public static ApplicationManager getInstance(){
        return instance;
    }

    public void init(){
        workspaces.clear();
    }

    /**
     * @return workspaces
     */
    public Map getWorkspaces() {
        return workspaces;
    }

    public void startup(){
        for (Iterator ite = workspaces.keySet().iterator();ite.hasNext();){
            Object key = ite.next();
//          Workspace work = (Workspace) workspaces.get(key);
//          work.startup();
        }
    }

    /**
     * @return homeDirectory
     */
    public String getHomeDirectory() {
        return homeDirectory;
    }

    /**
     * @param homeDirectory homeDirectory
     */
    public void setHomeDirectory(String homeDirectory) {
        this.homeDirectory = homeDirectory;
    }

    public Date getSystemDate(){
        return new Date();
    }

    private List stack = new ArrayList();
//	public void addToStack(Application app){
//		synchronized(stack) {
//			stack.add(app);
//			while (stack.size() > 0){
//				Application application = (Application) stack.remove(0);
//				logger.info("Synchronized execution:" + application.getTitle() + " started.(" + stack.size() + ")");
//				try{
//					application.run();
//				}catch(Exception ex){
//					//can not stop...
//					logger.error(ex.getMessage(),ex);
//				}
//				logger.info("Synchronized execution:" + application.getTitle() + " end.(" + stack.size() + ")");
//			}
//		}
//	}
//
//	private List apps = new ArrayList();
//	public void synchroDeletionStack(Application app){
//		for(int i=0;i<apps.size();i++){
//			if (apps.get(i) == app) {
//				logger.info("起動中の処理のため実行しません。 [" + app.getTitle() +"]");
//				return;
//			}
//		}
//		apps.add(app);
//		logger.info("execution:" + app.getTitle() + " started.");
//		try{
//			app.run();
//		}catch(Exception ex){
//			logger.error(ex.getMessage(), ex);
//		}
//		apps.remove(app);
//		logger.info("execution:" + app.getTitle() + " end.");
//	}

}
