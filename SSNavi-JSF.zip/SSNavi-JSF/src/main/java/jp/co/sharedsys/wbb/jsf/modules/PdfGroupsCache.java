package jp.co.sharedsys.wbb.jsf.modules;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.sharedsys.wbb.jsf.reports.ReportPdfGroup;

public class PdfGroupsCache {

    private static Map<String, PdfGroupsCache> instances = new HashMap<String, PdfGroupsCache>();
	
    public static void clearInstances(){
        instances.clear();
    }
	
    public static PdfGroupsCache getInstance(String type){
        PdfGroupsCache rule = null;
        if (instances.containsKey(type)){
            rule = (PdfGroupsCache) instances.get(type);
        } else {
            rule = new PdfGroupsCache();
            instances.put(type,rule);
        }
        return rule;
    }
	
    private Map<String, List<ReportPdfGroup>> pdfGroups = new HashMap<String, List<ReportPdfGroup>>();

    public Map<String, List<ReportPdfGroup>> getPdfGroups() {
        return pdfGroups;
    }
	
    public List<ReportPdfGroup> getPdfGroupByName(String name){
        List<ReportPdfGroup> r = pdfGroups.get(name);
        if (r==null){
            r = new ArrayList<ReportPdfGroup>();
        }
        return r;
    }
}
