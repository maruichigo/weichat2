/*
 * ExternalServiceExecuter2.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.process;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.LinkedHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.wbb.jsf.beans.AuthorityConfBean;
import jp.co.sharedsys.wbb.jsf.beans.SSNaviManagedBean;
import jp.co.sharedsys.wbb.jsf.exception.LogicException;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;
import jp.co.sharedsys.wbb.jsf.reports.ReportConst.F_EXECUTER;
import jp.co.sharedsys.wbb.jsf.reports.ReportConst;

/**
 * SQL実行処理
 * @author klsproj
 */
public class ExternalServiceExecuter2 extends AbstractExternalProcess<SSNaviManagedBean> {

    /**
     * パラメータを渡してSQL実行を行う
     * @param pageBean
     * @throws LogicException
     * @throws SystemException 
     */
    public void dbProcess(SSNaviManagedBean pageBean) throws LogicException, SystemException {
        try {
            onService(pageBean);
        } catch (LogicException | SystemException ex) {
            //システムエラー
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            new MsgExec().message("ERROR", "エラー", ex.getMessage());
            throw ex;
        }
    }

    @Override
    public void onService(SSNaviManagedBean pageBean) throws LogicException, SystemException {
        //シングルsqlidのみ対応
        Map<String, Object> target = pageBean.getTargetServices().get(0);
        
        //◆1.パラメータ取得
        String servicename = (String)target.get(F_EXECUTER.E_SERVICE_NAME); //画面データを変換するために使用していた。
        String service = (String)target.get(F_EXECUTER.E_SERVICE_URL);
        String functionCode = (String)target.get(F_EXECUTER.E_FUNCTION);
        String modeName = (String)target.get(F_EXECUTER.P_EDIT_MODE_NAME); 
        //String tact = (String)target.get(F_EXECUTER.P_EDIT_ACTIVITY_NAME);
        String tableName = (String)target.get(F_EXECUTER.E_SQL);
        Object inputParams = target.get(F_EXECUTER.P_SEND_PARAMETER);
        
        //◆2.SQL実行
        AuthorityConfBean authConf = pageBean.getAuthConf();
        ServiceInterfaceBean dto = this.requestExternalService(service, inputParams, functionCode, tableName, authConf.getUserCd(), authConf.getUserGroup(), false);
        
        //◆3.値取得
        try {
            //Json結果データ(jsonString)を変換する準備
            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> jsonResMap = null;

            //存在チェック形式
            String tablelist = dto.getJsonResultTableList();
            String resultmap = dto.getJsonResultMap();
            if (!"".equals(tablelist)){
                List searchResult = mapper.readValue(tablelist, List.class);
                pageBean.getReportResult().put(servicename, searchResult);
            }
            if (!"".equals(resultmap)){
                jsonResMap = mapper.readValue(resultmap, Map.class);
                pageBean.setExternalAttribute(jsonResMap);   
            }
            
            //モード形式(従来通りdto.getJson()を見る。)
            if ("{}".equals(dto.getJson()) || "".equals(dto.getJson())){
				//返却なし
			} else {
                switch (modeName) {
                    case ReportConst.F_BTNACT.SEARCH:
                    {
                        //リストを返却
                        List searchResult = mapper.readValue(dto.getJson(), List.class);
                        pageBean.getReportResult().put(servicename, searchResult);
                    }
                    break;
                    default:
                    {
                        jsonResMap = mapper.readValue(dto.getJson(), Map.class);
                        pageBean.setExternalAttribute(jsonResMap);   
                    }
                }
            }
        } catch (IOException e) {
            logger.error("サービス側から意図しないパラメータが返ってきています。");
            logger.error(e.getMessage(), e);
            return;
        }

        //◆4.後処理

        //◆5.メッセージ出力
        MsgExec.message(dto.getMessages());
    }

    /**
     * 簡易SQL結果取得
     * @param pageBean
     * @param function
     * @return 
     */
    public List<Map<String, Object>> simpleSql(SSNaviManagedBean pageBean, String function){
        try {
            Map<String, Object> target = new LinkedHashMap<>();
            String serviceName = "simple";
            target.put(F_EXECUTER.E_SERVICE_NAME, serviceName);
            target.put(F_EXECUTER.E_SERVICE_URL, "JohmonWebService");
            target.put(F_EXECUTER.E_FUNCTION,  function);
            target.put(F_EXECUTER.P_EDIT_MODE_NAME, "SEARCH");
            target.put(F_EXECUTER.P_SEND_PARAMETER, null);

            pageBean.getTargetServices().add(0, target);
            onService(pageBean);
            if (pageBean.getReportResult().containsKey(serviceName)){
                return pageBean.getReportResult().get(serviceName);
            }
            
        } catch (LogicException | SystemException ex) {
            //システムエラー
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            new MsgExec().message("ERROR", "エラー", ex.getMessage());
        }
        return null;
    }

}