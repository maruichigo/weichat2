package jp.co.sharedsys.wbb.jsf.api;


public class CurrentPath implements IAPI {

    public String getAPI() {
        return "@CURRENTPATH@";
    }

    public String execute() {
        String p = System.getProperty("user.dir","");
        return p.replaceAll("[\\\\]","/");
    }
}
