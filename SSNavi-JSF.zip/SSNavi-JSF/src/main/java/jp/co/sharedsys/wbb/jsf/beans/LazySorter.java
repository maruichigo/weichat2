/*
 * LazySorter.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.beans;

import java.util.Comparator;
import java.util.Map;
import org.primefaces.model.SortOrder;
import org.slf4j.LoggerFactory;

/**
 *
 * @author saihara
 */
public class LazySorter implements Comparator<Map<String, Object>> {
    private String sortField;
     
    private SortOrder sortOrder;
     
    public LazySorter(String sortField, SortOrder sortOrder) {
        this.sortField = sortField;
        this.sortOrder = sortOrder;
    }
 
    public int compare(Map<String, Object> val1, Map<String, Object> val2) {
        try {
            Object value1 = val1.get(sortField);
            Object value2 = val2.get(sortField);

            // nullの場合は空文字に置き換える
            if(value1 == null){
                value1 = "";
            }
            if(value2 == null){
                value2 = "";
            }           
            int value = ((Comparable)value1).compareTo(value2);
             
            return SortOrder.ASCENDING.equals(sortOrder) ? value : -1 * value;
        } catch(Exception e) {
            LoggerFactory.getLogger(this.getClass()).error(e.getMessage(), e);
            throw new RuntimeException();
        }
    }    
}
