package jp.co.sharedsys.wbb.jsf.process;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;

import jp.co.sharedsys.bb.Message;
import jp.co.sharedsys.wbb.jsf.exception.LogicException;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;
import jp.co.sharedsys.wbb.jsf.beans.AuthorityConfBean;
import jp.co.sharedsys.wbb.jsf.beans.SSNaviManagedBean;
import static jp.co.sharedsys.wbb.jsf.process.ExternalServiceExecuter.E_TARGET_CONFIG;
import static jp.co.sharedsys.wbb.jsf.process.ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME;
import static jp.co.sharedsys.wbb.jsf.process.ExternalServiceExecuter.P_EDIT_MODE_NAME;
import jp.co.sharedsys.wbb.jsf.reports.Input;
import jp.co.sharedsys.wbb.jsf.reports.ReportColumn;
import jp.co.sharedsys.wbb.jsf.reports.ReportCondition;
import jp.co.sharedsys.wbb.jsf.reports.ReportConfig;
import jp.co.sharedsys.wbb.jsf.reports.ReportConst;
import jp.co.sharedsys.wbb.jsf.reports.ReportConst.ControlType;
import jp.co.sharedsys.wbb.jsf.reports.ReportConst.DataType;
import jp.co.sharedsys.wbb.jsf.reports.ReportModification;
import jp.co.sharedsys.wbb.jsf.util.StringUtil;

public class ExternalServiceParameterCheck  {


    public void onService(SSNaviManagedBean pageBean) throws LogicException,	SystemException {
//      String pid = parameter.getParameter(P_REPORTIDPARAM);
//      String papp = parameter.getParameter(P_KEY);
//      String repid = (String) parameter.getExternalParameter().get(pid);
        String repid = pageBean.getR();
                ReportConfig config;
        if (pageBean.getTargetServices().get(0).get(E_TARGET_CONFIG) != null) {
            config = (ReportConfig)pageBean.getTargetServices().get(0).get(E_TARGET_CONFIG);
        } else {
            config = pageBean.getConfig();
        }
        if (config == null) {
                throw new LogicException("Specified report-id was not found.[" + repid + "]");
        }

        Map<String, Object> target = pageBean.getTargetServices().get(0);
        String modeName = (String)target.get(P_EDIT_MODE_NAME);
        modeName = modeName == null ? "" : modeName;
        String activityName = (String)target.get(P_EDIT_ACTIVITY_NAME);
        activityName = activityName == null ? "" : activityName;

        AuthorityConfBean authConf = pageBean.getAuthConf();

        List<Input> condList = new ArrayList<Input>();

        // 入力項目をJSON形式に変換できる形にする
        ReportModification mod = config.getModification();
        if (StringUtils.equals(ReportConst.EditMode.DETAIL_DELETE, modeName)
                || StringUtils.equals(ReportConst.EditMode.DETAIL_UPDATE, modeName)) {
            // 明細削除・更新
            if (config.getSqls().size() > 2) {
                // 複数明細の場合、Mapに明細リストを詰めて渡す
                Map<String, Object> editMap = new HashMap<String, Object>();
                for (int i = 1; i < config.getSqls().size(); i++) {
                    List<Map<String, Object>> detailList = this.createDetailList(authConf, pageBean, mod, config.getSqls().get(i).getName());
                    String detailName = "";
                    List<ReportColumn> sortedColumns = mod.getColumnsSort(config.getSqls().get(i).getName());
                    for (ReportColumn col : sortedColumns) {
                        if (StringUtils.isNotEmpty(col.getTableName())) {
                            // 明細の名称は、「{テーブル名}s」
                            detailName = StringUtil.camelize(col.getTableName()) + "s";
                            break ;
                        }
                    }
                    if (detailList.size() > 0) {
                        Object obj = editMap.get(detailName);
                        if (obj != null) {
                            // 同じ明細リストがあった場合、追加する
                            List<Map<String, Object>> wkList = (List<Map<String, Object>>) obj;
                            for (Map<String, Object> d : detailList) {
                                    wkList.add(d);
                            }
                        } else {
                            editMap.put(detailName, detailList);
                        }
                    }
                }
                target.put(ExternalServiceExecuter.P_SEND_PARAMETER, editMap);
            } else if (config.getSqls().size() == 2) {
                // 単一明細の場合、明細リストで渡す
                List<Map<String, Object>> detailList = this.createDetailList(authConf, pageBean, mod, config.getSqls().get(1).getName());
                target.put(ExternalServiceExecuter.P_SEND_PARAMETER, detailList);
            }
        } else if (StringUtils.equals(ReportConst.EditMode.LIST_EDIT_UPDATE, modeName)
                || StringUtils.equals(ReportConst.EditMode.LIST_UPDATE, modeName)) {
            // リスト編集画面での更新
            List<Map<String, Object>> prmList = new ArrayList<Map<String, Object>>();
            List<ReportColumn> sortedColumns = mod.getColumnsSort();
            List<Map<String, Object>> list;
            if (StringUtils.equals(ReportConst.EditMode.LIST_EDIT_UPDATE, modeName)) {
                list = pageBean.getSelectableResult().getDatasource();
            } else {
                list = pageBean.getSelectReportResult();
            }
            for (int i = 0; i < list.size(); i++){
                for (ReportColumn col : sortedColumns) {
                    if (StringUtils.isEmpty(col.getTableName())) {
                        // テーブル名が空のものはパラメータとして渡さない
                        continue;
                    }
                    // 項目名のフォーマットは、LIST-{カラム名}となっている
//                    String prmName = "LIST-" + col.getName();
                    String prmName = col.getName();
                    String prmVal = String.valueOf(list.get(i).get(prmName));
                    Map<String, Object> data = new HashMap<String, Object>();
                    if (prmList.size() > i) {
                        data = prmList.get(i);
                    } else {
                        data = new HashMap<String, Object>();
                    }
                    String name = StringUtil.camelize(col.getName());
                    if (StringUtils.equals(DataType.DATE, col.getDataType())
                            || StringUtils.equals(DataType.DATE_TIMESTAMP, col.getDataType())) {
                        try {
                            Date date = DateUtils.parseDate(prmVal, new String[] {"yyyy/MM/dd", "yyyy/MM/dd HH:mm:ss"});
                            data.put(name, date);
                        } catch (ParseException e) {
                            data.put(name, null);
                        }
                    } else if (StringUtils.equals(ControlType.SELECT, col.getControlType())
                            || StringUtils.equals(ControlType.SELECT_DYNAMIC, col.getControlType())
                            || StringUtils.equals(ControlType.SELECT_MULTI, col.getControlType())) {
                        if (!StringUtils.equals("ALLDATA", prmVal)) {
                                data.put(name, prmVal);
                        }
                    } else if (StringUtils.equals(DataType.INT, col.getDataType())
                            || StringUtils.equals(DataType.DECIMAL, col.getDataType())) {
                        data.put(name, StringUtils.replace(prmVal, ",", ""));
                    } else {
                        data.put(name, prmVal);
                    }

                    if (prmList.size() <= i) {
                            prmList.add(data);
                    }
                }
            }
            target.put(ExternalServiceExecuter.P_SEND_PARAMETER, prmList);
        } else {
            //それ以外
            Map<String, Object> editMap = new HashMap<String, Object>();
            List<ReportColumn> sortedColumns = null;
            // まずはヘッダから設定する
            sortedColumns = mod.getColumnsSort(config.getSqls().get(0).getName());
            for (ReportColumn col : sortedColumns) {
                if (StringUtils.isEmpty(col.getTableName())) {
                    // テーブル名が空のものはパラメータとして渡さない
                    continue;
                }
//                String prmName = col.getApplyTo() + "-" + col.getName();
                String prmName = col.getName();
                List<Object> values = new ArrayList<>();

                String prmVal = (String)pageBean.getValues().get(col.getApplyTo()).get(prmName);
                if (StringUtils.isNotEmpty(prmVal)) {
                    if (StringUtils.equals(DataType.DATE, col.getDataType())
                            || StringUtils.equals(DataType.DATE_TIMESTAMP, col.getDataType())) {
                        try {
                            Date date = DateUtils.parseDate(prmVal, new String[] {"yyyy/MM/dd", "yyyy/MM/dd HH:mm:ss"});
                            values.add(date);
                        } catch (ParseException e) {
                            values.add(null);
                        }
                    } else if (StringUtils.equals(ControlType.SELECT, col.getControlType())
                            || StringUtils.equals(ControlType.SELECT_DYNAMIC, col.getControlType())
                            || StringUtils.equals(ControlType.SELECT_MULTI, col.getControlType())) {
                        if (!StringUtils.equals("ALLDATA", prmVal)) {
                            values.add(prmVal);
                        }
                    } else if (StringUtils.equals(DataType.INT, col.getDataType())
                            || StringUtils.equals(DataType.DECIMAL, col.getDataType())) {
                        values.add(StringUtils.replace(prmVal, ",", ""));
                    } else {
                        values.add(prmVal);
                    }
                }

                String name = StringUtil.camelize(col.getName());
                if (values.size() > 1) {
                    editMap.put(name, values);
                } else if (values.size() == 1) {
                    editMap.put(name, values.get(0));
                }
            }
            // 次はDetailのリストを作成する
            for (int i = 1; i < config.getSqls().size(); i++) {
                List<Map<String, Object>> detailList = this.createDetailList(authConf, pageBean, mod, config.getSqls().get(i).getName());
                String detailName = "";
                sortedColumns = mod.getColumnsSort(config.getSqls().get(i).getName());
                for (ReportColumn col : sortedColumns) {
                    if (StringUtils.isNotEmpty(col.getTableName())) {
                        // 明細の名称は、「{テーブル名}s」
                        detailName = StringUtil.camelize(col.getTableName()) + "s";
                        break ;
                    }
                }
                if (detailList.size() > 0) {
                    if (detailList.size() == 1) {
                        if (detailList.get(0).size() == 0) {
                            // 何も入ってない場合はセットしない
                            continue ;
                        }
                    }
                    Object obj = editMap.get(detailName);
                    if (obj != null) {
                        // 同じ明細リストがあった場合、追加する
                        List<Map<String, Object>> wkList = (List<Map<String, Object>>) obj;
                        for (Map<String, Object> d : detailList) {
                            wkList.add(d);
                        }
                    } else {
                        editMap.put(detailName, detailList);
                    }
                }
            }
            target.put(ExternalServiceExecuter.P_SEND_PARAMETER, editMap);
        }
    }

    /**
     * setCondListをpublicで使用する
     * @param parameter
     * @param config
     * @param condList
     * @param prefix
     */
    public void collaborationSetCondList(Message parameter, ReportConfig config, List<Input> condList, String prefix) {
        this.setCondList(parameter, config, condList, prefix);
    }

    /**
     * 検索条件情報の設定
     * @param parameter
     * @param config
     * @param condList
     */
    private void setCondList(Message parameter, ReportConfig config, List<Input> condList, String prefix) {
        for (Object obj : config.getConditions()) {
            ReportCondition cond = (ReportCondition) obj;

            if ("RANGE".equalsIgnoreCase(cond.getControlType())) {
                Input ins = new Input();
                Input ine = new Input();
                ins.setName(prefix + cond.getNameStart());
                ine.setName(prefix + cond.getNameEnd());
                ins.setType(cond.getDataType());
                ine.setType(cond.getDataType());
                ins.setApplyTo(cond.getApplyTo());
                ine.setApplyTo(cond.getApplyTo());
                for (Iterator<String> vite = parameter.getExternalParameter().valueIterator(prefix + cond.getNameStart());vite.hasNext();) {
                    String pv = vite.next();
                    pv = pv == null ? "" : pv;
                    ins.getValues().add(pv);
                }
                for (Iterator<String> vite = parameter.getExternalParameter().valueIterator(prefix + cond.getNameEnd());vite.hasNext();){
                    String pv = vite.next();
                    pv = pv == null ? "" : pv;
                    ine.getValues().add(pv);
                }

                condList.add(ine);

            } else {
                String pn = cond.getName();
                Input in = new Input();
                in.setName(prefix + pn);
                in.setType(cond.getDataType());
                in.setApplyTo(cond.getApplyTo());
                for (Iterator<String> vite = parameter.getExternalParameter().valueIterator(prefix + pn);vite.hasNext();){
                    String pv = vite.next();
                    in.getValues().add(pv);
                }
                if (in.getValues().size() > 0) {
                    condList.add(in);
                }
            }
        }
    }

    /**
     * 明細リストの作成
     * @param authConf
     * @param pageBean
     * @param mod
     * @param applyTo
     * @return
     */
    private List<Map<String, Object>> createDetailList(AuthorityConfBean authConf, SSNaviManagedBean pageBean, ReportModification mod, String applyTo) {
        List<Map<String, Object>> detailList = new ArrayList<Map<String, Object>>();
        List<ReportColumn> sortedColumns = mod.getColumnsSort(applyTo);
        List<Map<String, Object>> list = pageBean.getListValues().get(applyTo);
        for (int i = 0; i < list.size(); i++){
            for (ReportColumn col : sortedColumns) {
                if (StringUtils.isEmpty(col.getTableName())) {
                    // テーブル名が空のものはパラメータとして渡さない
                    continue;
                }
//                String prmName = col.getApplyTo() + "-" + col.getName();
                String prmName = col.getName();
                String prmVal = String.valueOf(list.get(i).get(prmName));
                Map<String, Object> detail = new HashMap<String, Object>();
                if (detailList.size() > i) {
                    detail = detailList.get(i);
                } else {
                    detail = new HashMap<String, Object>();
                }

                if (StringUtils.isNotEmpty(prmVal)) {
                    String name = StringUtil.camelize(col.getName());
                    if (StringUtils.equals(DataType.DATE, col.getDataType())
                            || StringUtils.equals(DataType.DATE_TIMESTAMP, col.getDataType())) {
                        try {
                            Date date = DateUtils.parseDate(prmVal, new String[] {"yyyy/MM/dd", "yyyy/MM/dd HH:mm:ss"});
                            detail.put(name, date);
                        } catch (ParseException e) {
                            detail.put(name, null);
                        }
                    } else if (StringUtils.equals(ControlType.SELECT, col.getControlType())
                            || StringUtils.equals(ControlType.SELECT_DYNAMIC, col.getControlType())
                            || StringUtils.equals(ControlType.SELECT_MULTI, col.getControlType())) {
                        if (!StringUtils.equals("ALLDATA", prmVal)) {
                                detail.put(name, prmVal);
                        }
                    } else if (StringUtils.equals(DataType.INT, col.getDataType())
                            || StringUtils.equals(DataType.DECIMAL, col.getDataType())) {
                        detail.put(name, StringUtils.replace(prmVal, ",", ""));
                    } else {
                        detail.put(name, prmVal);
                    }
                }

                if (detailList.size() <= i) {
                        detailList.add(detail);
                }
            }
        }
        return detailList;
    }
}