package jp.co.sharedsys.wbb.jsf.conf;

import lombok.Data;

@Data
public class XReportSql {
    private String connection = null;
    private String name = null;
    private String description = null;
    private String templateFile = null;
    private String statementType = null;
    private String moduleName = null;
    private String showResult = null;
    private String downloadable = "true";
    private String showAddRowButton;
    private String showDelRowButton;
    private String dataClass;
    private String detailMode;
    private String tableName;
    private String service;
    private String functionCode;
}
