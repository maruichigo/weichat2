package jp.co.sharedsys.wbb.jsf.conf;

import java.util.ArrayList;
import java.util.List;

public class XReport {

    private String title = null;
    private String shortTitle = null;
    private String description = null;
    private String style = null;
    private String parameterPageTemplate = null;
    private String icon = null;
    private String reportType = null;
    private String showInMenu = null;
    private String excelTemplate = null;
    private String csvTemplate = null;
    private String pageTemplate = null;
    private String parameterCheckClass = null;
    private String screenCode;

    private String version = null;

    private String reloadCondition = null;

    private String fileSaveScope = "private";
    private String filePathToSave = "/@date@/";
    private String fileNameToSave = null;


    private List conditions = new ArrayList();
    private List sqls = new ArrayList();
    private List buttons = new ArrayList();
    private List formats = new ArrayList();
    // 2012.08.10 N.Ichijo Add
    private XReportModification modification = null;
    // 2012.08.10 N.Ichijo End
    // 2012.12.27 S.Komaji Add
    private String nullZero = null;
    // 2012.12.27 S.Komaji End

    public String getScreenSize() {
        return screenSize;
    }

    public String getLineDisp() {
        return lineDisp;
    }

    public void setScreenSize(String screenSize) {
        this.screenSize = screenSize;
    }

    public void setLineDisp(String lineDisp) {
        this.lineDisp = lineDisp;
    }

    private String screenSize = null;           //RC22
    private String lineDisp = null;             //RC23	
	
    public String getTitle() {
            return title;
    }
    public void setTitle(String title) {
            this.title = title;
    }
    public String getDescription() {
            return description;
    }
    public void setDescription(String description) {
            this.description = description;
    }
    public String getReportType() {
            return reportType;
    }
    public void setReportType(String reportType) {
            this.reportType = reportType;
    }
    public String getShowInMenu() {
            return showInMenu;
    }
    public void setShowInMenu(String showInMenu) {
            this.showInMenu = showInMenu;
    }
    public String getExcelTemplate() {
            return excelTemplate;
    }
    public void setExcelTemplate(String excelTemplate) {
            this.excelTemplate = excelTemplate;
    }
    public List getConditions() {
            return conditions;
    }
    public void setConditions(List conditions) {
            this.conditions = conditions;
    }
    public void addCondition(XReportCondition condition){
            this.conditions.add(condition);
    }
    public List getSqls() {
            return sqls;
    }
    public void setSqls(List sqls) {
            this.sqls = sqls;
    }
    public void addSql(XReportSql sql){
            this.sqls.add(sql);
    }
    public List getButtons() {
            return buttons;
    }
    public void setButtons(List buttons) {
            this.buttons = buttons;
    }
    public void addButton(XReportButton button){
            this.buttons.add(button);
    }
    public String getPageTemplate() {
            return pageTemplate;
    }
    public void setPageTemplate(String pageTemplate) {
            this.pageTemplate = pageTemplate;
    }
    public String getParameterCheckClass() {
            return parameterCheckClass;
    }
    public void setParameterCheckClass(String parameterCheckClass) {
            this.parameterCheckClass = parameterCheckClass;
    }
    public List getFormats() {
            return formats;
    }
    public void setFormats(List formats) {
            this.formats = formats;
    }
    public void addFormat(XReportFormat format){
            this.formats.add(format);
    }
    public String getVersion() {
            return version;
    }
    public void setVersion(String version) {
            this.version = version;
    }
    public String getReloadCondition() {
            return reloadCondition;
    }
    public void setReloadCondition(String reloadCondition) {
            this.reloadCondition = reloadCondition;
    }
    public String getParameterPageTemplate() {
            return parameterPageTemplate;
    }
    public void setParameterPageTemplate(String parameterPageTemplate) {
            this.parameterPageTemplate = parameterPageTemplate;
    }
    public String getShortTitle() {
            return shortTitle;
    }
    public void setShortTitle(String shortTitle) {
            this.shortTitle = shortTitle;
    }
    public String getStyle() {
            return style;
    }
    public void setStyle(String style) {
            this.style = style;
    }
    public String getIcon() {
            return icon;
    }
    public void setIcon(String icon) {
            this.icon = icon;
    }
    public String getFileNameToSave() {
            return fileNameToSave;
    }
    public void setFileNameToSave(String fileNameToSave) {
            this.fileNameToSave = fileNameToSave;
    }
    public String getFilePathToSave() {
            return filePathToSave;
    }
    public void setFilePathToSave(String filePathToSave) {
            this.filePathToSave = filePathToSave;
    }
    public String getFileSaveScope() {
            return fileSaveScope;
    }
    public void setFileSaveScope(String fileSaveScope) {
            this.fileSaveScope = fileSaveScope;
    }
    public String getCsvTemplate() {
            return csvTemplate;
    }
    public void setCsvTemplate(String csvTemplate) {
            this.csvTemplate = csvTemplate;
    }
    // 2012.08.10 N.Ichijo Add
    public XReportModification getModification() {
            return modification;
    }
    public void setModification(XReportModification modification) {
            this.modification = modification;
    }
    // 2012.08.10 N.Ichijo End
    // 2012.12.27 S.Komaji Add
    public String getNullZero() {
            return nullZero;
    }
    public void setNullZero(String nullZero) {
            this.nullZero = nullZero;
    }
    // 2012.12.27 S.Komaji End
    public String getScreenCode() {
            return screenCode;
    }
    public void setScreenCode(String screenCode) {
            this.screenCode = screenCode;
    }
}
