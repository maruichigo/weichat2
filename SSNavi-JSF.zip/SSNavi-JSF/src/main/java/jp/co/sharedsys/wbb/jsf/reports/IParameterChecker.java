package jp.co.sharedsys.wbb.jsf.reports;

import jp.co.sharedsys.wbb.jsf.exception.LogicException;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;

public interface IParameterChecker {

    public void setReportConfig(ReportConfig config);
	
    public void check() throws LogicException,SystemException;
	
}
