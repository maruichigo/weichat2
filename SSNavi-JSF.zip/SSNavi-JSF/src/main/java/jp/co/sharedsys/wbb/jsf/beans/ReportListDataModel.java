/*
 * ReportListDataModel.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import jp.co.sharedsys.wbb.jsf.reports.ReportColumn;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortMeta;
import org.primefaces.model.SortOrder;

/**
 * 検索結果一覧画面での行選択を有効にする為のModelクラスです。
 *
 * @author saihara
 */
public class ReportListDataModel extends LazyDataModel<Map<String, Object>> implements Serializable {
        private List<Map<String, Object>> datasource;
        private boolean firstLoad;
        private List<Map<String, Object>> selectedList;
        
        private boolean cachingRowData;
        private Map<String, Object> filters;
        private int first;
        private List<SortMeta> multiSortMeta;
        private int pageSize;
        private transient Map<Integer, Map<String, Object>> rowDataCache;
        private SortOrder sortOrder;
        private String sortField;
        private static final String UNIQUE_KEY = "UNIQUE_KEY";
        private int count = 0;
		//private List<ReportColumn> columns;
		private Map<String, Boolean> columnfilmap;
    
    public ReportListDataModel(List<Map<String, Object>> datas, String reportColPk, List<ReportColumn> columns) {
        super();
        
        for (int i = 0; i<datas.size();i++){
            Map<String, Object> data = datas.get(i);
            data.put(UNIQUE_KEY, Integer.toString(i));
        }
        setColumnfilmap(datas, columns);
        datasource = datas;
        firstLoad = true;
        selectedList = new ArrayList<>();
        count = datasource.size();
    }
    
	/**
	 * フィルタ対象外リストを作成する
	 * @param datas
	 * @param columns 
	 */
	private void setColumnfilmap(List<Map<String, Object>> datas, List<ReportColumn> columns){
		columnfilmap = new LinkedHashMap<String, Boolean>();
		
		if (0 == datas.size()) return;
		//sql結果でrptにないものはフィルタ対象外
		for(Map.Entry<String, Object> entry : datas.get(0).entrySet()) {
			columnfilmap.put(entry.getKey(), false);
		}
		//hiddenのものと、visibleがfalseのものは対象外
		for(int i = 0; i<columns.size();i++){
			ReportColumn column = columns.get(i);
			String name = column.getName();
			boolean bool = true;// デフォルト ＝対象
			if (i == 0){
				bool = false;
			} else if ("HIDDEN".equals(column.getControlType())){
				bool = false;
			} else if ("CONTEXT".equals(column.getControlType())){
				bool = false;
			} else if (!column.isVisible()){
				bool = false;
			}
			columnfilmap.put(name, bool);
		}
	}
	
    @Override
    public Map<String, Object> getRowData(String rowKey) {
        // 選択イベントが発生した場合、p:dataTable属性のrowKeyからユニークキーが送信されるので、
        // datasourceから該当するデータを返却する
        for (Map<String, Object> data : datasource){
            if (rowKey.equals(data.get(UNIQUE_KEY))){
               selectedList.add(data);
                return data; 
            }        
        }
        return null;
    }

    @Override
    public Object getRowKey(Map<String, Object> column) {
        return column.get(UNIQUE_KEY);
    }

    // シングルソート
    @Override
    public List<Map<String, Object>> load(int first, int pageSize, String sortField, SortOrder sortOrder, Map<String,Object> filters) {
        List<Map<String, Object>> data = new ArrayList<>();

        if (getDatasource() == null) return data;
        //filter
        for (Map<String, Object> src : getDatasource()) {
            boolean match = true;

            if (filters != null) {
                Object gFilter = filters.get("globalFilter");
                if (gFilter != null && gFilter.toString().length() != 0) {
                    match = false;
                    try {
                        Object filterValue = gFilter;
                        for (Iterator<String> ite = src.keySet().iterator(); ite.hasNext();) {
                            String filterProperty = ite.next();
                            if (!columnfilmap.get(filterProperty)) { //対象外フィルタ
                                continue;
                            }
                            String fieldValue = String.valueOf(src.get(filterProperty));
                            if (fieldValue.contains(filterValue.toString())) {
                                match = true;
                                break;
                            }
                        }
                    } catch (Exception e) {
                        match = false;
                    }
                } else {
                    for (Iterator<String> it = filters.keySet().iterator(); it.hasNext();) {
                        try {
                            String filterProperty = it.next();
                            Object filterValue = filters.get(filterProperty);
                            String fieldValue = String.valueOf(src.get(filterProperty));

                            if (filterValue == null || fieldValue.contains(filterValue.toString())) {
                                match = true;
                            } else {
                                match = false;
                                break;
                            }
                        } catch (Exception e) {
                            match = false;
                        }
                    }
                }
            }

            if (match) {
                data.add(src);
            }
        }

        //sort
        if (sortField != null) {
            Collections.sort(data, new LazySorter(sortField, sortOrder));
        }

        //rowCount //件数を設定
        int dataSize = data.size();
        this.setRowCount(dataSize);
        this.setWrappedData(data);
        
        //paginate
        if (dataSize > pageSize) {
            try {
                return data.subList(first, first + pageSize);
            } catch (IndexOutOfBoundsException e) {
                return data.subList(first, first + (dataSize % pageSize));
            }
        } else {
            return data;
        }
    }  
    
    // マルチソート
    @Override
    public List<Map<String, Object>> load(int first, int pageSize, List<SortMeta> multiSortMeta, Map<String, Object> filters){
       List<Map<String, Object>> data = new ArrayList<>();

        if (getDatasource() == null) return data;

        if (firstLoad) {
            this.preload(first, pageSize, multiSortMeta, filters);
            firstLoad = false;
        }

        //filter
        for (Map<String, Object> src : getDatasource()) {
            boolean match = true;

            if (filters != null) {
                Object gFilter = filters.get("globalFilter");
                if (gFilter != null && gFilter.toString().length() != 0) {
                    match = false;
                    try {
                        Object filterValue = gFilter;
                        for (Iterator<String> ite = src.keySet().iterator(); ite.hasNext();) {
                            String filterProperty = ite.next();
                            if (!columnfilmap.get(filterProperty)) { //対象外フィルタ
                                continue;
                            }
                            String fieldValue = String.valueOf(src.get(filterProperty));
                            if (fieldValue.contains(filterValue.toString())) {
                                match = true;
                                break;
                            }
                        }
                    } catch (Exception e) {
                        match = false;
                    }
                    
                    if (match){
                        for (Iterator<String> it = filters.keySet().iterator(); it.hasNext();) {
                            try {
                                String filterProperty = it.next();
                                if ("globalFilter".equals(filterProperty)) { //グローバルの場合は対象外
                                    continue;
                                }
                                Object filterValue = filters.get(filterProperty);
                                String fieldValue = String.valueOf(src.get(filterProperty));

                                if (filterValue == null || fieldValue.contains(filterValue.toString())) {
                                    match = true;
                                } else {
                                    match = false;
                                    break;
                                }
                            } catch (Exception e) {
                                match = false;
                            }
                        }
                    }

                } else {
                    for (Iterator<String> it = filters.keySet().iterator(); it.hasNext();) {
                        try {
                            String filterProperty = it.next();
                            Object filterValue = filters.get(filterProperty);
                            String fieldValue = String.valueOf(src.get(filterProperty));

                            if (filterValue == null || fieldValue.contains(filterValue.toString())) {
                                match = true;
                            } else {
                                match = false;
                                break;
                            }
                        } catch (Exception e) {
                            match = false;
                        }
                    }
                }
            }

            if (match) {
                data.add(src);
            }
        }

        //sort
        if (multiSortMeta != null){
            if (multiSortMeta.get(0).getSortField() != null && multiSortMeta.get(0).getSortOrder() != null) {
                Collections.sort(data, new LazySorter(multiSortMeta.get(0).getSortField(), multiSortMeta.get(0).getSortOrder()));
            }
        }

        //rowCount //件数を設定
        int dataSize = data.size();
        setRowCount(dataSize);
        setWrappedData(data);
        
        //paginate
        if (dataSize > pageSize) {
            try {
                return data.subList(first, first + pageSize);
            } catch (IndexOutOfBoundsException e) {
                return data.subList(first, first + (dataSize % pageSize));
            }
        } else {
            return data;
        }
    }
           
    /**
     * Initializes the Row Data Cache and stores the Load Values that will
     * be used when loading the Row Data Cache
     *
     * @param first the Row Index of the First Row to load the in the DataModel
     * @param pageSize the DataModel Page / Scroll Size
     * @param multiSortMeta the MultiSortMeta that is to be applied to the DataModel
     * @param filters the Filters that are to be applied to the DataModel
     */
    public void preload(int first, int pageSize, List<SortMeta> multiSortMeta, Map<String,Object> filters){
        // Remember Load Values for Reloading Row Data Cache
        if(!isCachingRowData()){
            this.first = first;
            this.pageSize = pageSize;
            this.multiSortMeta = multiSortMeta;
            this.filters = filters;
        }

        // Create the Row Data Cache once for the first load.
        if(!isCachingRowData() && first == 0){
            createRowDataCache();
        }
    }
                
    /**
    * Returns whether the DataModel is "re"loading data using one of the
    * load() methods for the purpose of Caching Row Data in order to properly
    * process child components
    *
    * @return true if caching row data; false otherwise
    */
   private boolean isCachingRowData(){
       return cachingRowData;
   }  

   /**
    * Creates a new Row Data Cache up to [N] Rows at a time; N being the
    * Page / Scroll Size defined when the DataModel is loaded.
    */
   private void createRowDataCache(){
       this.rowDataCache = new LinkedHashMap<Integer, Map<String, Object>>(getPageSize()){
           @Override
           protected boolean removeEldestEntry(Map.Entry<Integer, Map<String, Object>> eldest){
               return size() > getPageSize();
           }
       };
   }
   
    /**
     * Returns the Filters that were applied to the DataModel when it was loaded
     * @return the Filters that were applied to the DataModel when it was loaded
     */
    public Map<String, Object> getFilters(){
        return filters;
    }

    /**
     * @param filters the filters to set
     */
    public void setFilters(Map<String, Object> filters) {
        this.filters = filters;
    }   
   
    /**
    * Returns the MultiSortMeta that was applied to the DataModel when it was loaded
    * @return the MultiSortMeta that was applied to the DataModel when it was loaded
    */
    public List<SortMeta> getMultiSortMeta(){
       return multiSortMeta;
    }

    /**
     * @param multiSortMeta the multiSortMeta to set
     */
    public void setMultiSortMeta(List<SortMeta> multiSortMeta) {
       this.multiSortMeta = multiSortMeta;
    }
    
    /**
     * Returns the Sort Order that was applied to the DataModel when it was loaded
     * @return the Sort Order that was applied to the DataModel when it was loaded
     */
    public SortOrder getSortOrder(){
        return sortOrder;
    }

    /**
     * @param sortOrder the sortOrder to set
     */
    public void setSortOrder(SortOrder sortOrder) {
        this.sortOrder = sortOrder;
    }
    
    /**
     * Returns the Sort Field that was applied to the DataModel when it was loaded
     * @return the Sort Field that was applied to the DataModel when it was loaded
     */
    public String getSortField(){
        return sortField;
    }

    /**
     * @param sortField the sortField to set
     */
    public void setSortField(String sortField) {
        this.sortField = sortField;
    }    

    /**
     * Returns the Row Data Cache
     * <p>
     * This will contain Row Data for [N] Rows (N being the Page / Scroll Size
     * defined when the DataModel is loaded.)
     *
     * @return the Row Data Cache
     */
    public Map<Integer, Map<String, Object>> getRowDataCache(){
        return rowDataCache;
    }

    /**
     * @return the datasource
     */
    public List<Map<String, Object>> getDatasource() {
        return datasource;
    }

    /**
     * @param datasource the datasource to set
     */
    public void setDatasource(List<Map<String, Object>> datasource) {
        this.datasource = datasource;
    }

    public int getCount(){
        return this.count;
    }
    public void setCount(int count) {
        this.count = count;
    }
    /**
     * Returns the Total Amount of Rows expected to be available within the DataModel
     * @return the Total Amount of Rows expected to be available within the DataModel
     */
    /*
    @Override
    public int getRowCount(){
        return rowCount;
    }
    
    /**
     * Returns the current Row Index
     * @return the current Row Index
     */
    /*
    @Override
    public int getRowIndex(){
        return rowIndex;
    }

    /**
     * Returns the DataModel Page / Scroll Size
     * @return the DataModel Page / Scroll Size
     */
    /*
    @Override
    public int getPageSize(){
        return pageSize;
    }

    /**
     * Returns the Row Index of the First Row to load the in the DataModel
     * <p>
     * This will change during each LiveScroll.<br>
     * 0 - Initial<br>
     * Scroll (Scroll Size 15)<br>
     * 15 - Secondary<br>
     * Scroll<br>
     * 30 - etc...
     *
     * @return the Row Index of the First Row to load the in the DataModel
     */
    /*
    public int getFirst(){
        return first;
    }

    /**
     * Returns the Last Available Row Index in the DataModel
     * <p>
     * This will either be the [First Row Index + the Page Size] or
     * the [Total Row Count] if the former exceeds the total row count.
     *
     * @return the Last Available Row Index in the DataModel
     */
    /*
    public int getLast(){
        return ((getFirst() + getPageSize()) > getRowCount() ? getRowCount() : (getFirst() + getPageSize())) - 1;
    }

    /**
     * Returns the Object associated with the Current Row Index within the DataModel
     * <p>
     * This method has been modified for LiveScrolling.  It will initially
     * look in the Wrapped Cache for the Row Data.  If the Row Data cannot be found
     * then proceed to look in the Row Data Cache.  If the Row Data still cannot
     * be found then create a Row Data Cache in blocks of [Page Size] and return
     * the Data from the newly created Cache.
     *
     * @return the Object associated with the Current Row Index within the DataModel
     */
    /*
    @Override
    public Map<String, Object> getRowData(){
        if(getRowIndex() >= getFirst() && getRowIndex() <= getLast()){ // Wrapped Cache
            return ((List<Map<String, Object>>) getWrappedData()).get(getRowIndex() % getPageSize());
        }
        else if(getRowDataCache() != null && getRowDataCache().containsKey(getRowIndex())){ // Row Data Cache
            return getRowDataCache().get(getRowIndex());
        }
        else{ // DataSource Call Necessary - Create Row Data Cache
            // Initialize Row Data Cache if preload() wasn't called
            if(getRowDataCache() == null){
                createRowDataCache();
            }

            // Create Row Data Cache
            this.cachingRowData = true;
            List<Map<String, Object>> data = getMultiSortMeta() != null ?
                           load(getRowIndex(), getPageSize(), getMultiSortMeta(), getFilters()) :
                           load(getRowIndex(), getPageSize(), getSortField(), getSortOrder(), getFilters());
            this.cachingRowData = false;
            for(int i = 0, j = getRowIndex(), n = data.size(); i < n; i++, j++){
                getRowDataCache().put(j, data.get(i));
            }
            return getRowDataCache().get(getRowIndex());
        }
    }

    /**
     * Returns whether the Row is Available
     * <p>
     * The row will never be available if there is no Wrapped Data.
     * <p>
     * Otherwise this method has been modified for LiveScrolling to expand
     * the definition of the availability for the row to include all Data
     * instead of just within the Wrapped Data.
     *
     * @return true if the row is exists; false otherwise
     */
    /*
    @Override
    public boolean isRowAvailable(){
        // Never Loaded
        if(getWrappedData() == null){
            return false;
        }

        // Modified to include all Data instead of just the Wrapped Data
         return getRowIndex() >= 0 && getRowIndex() <= getLast();
        //return super.isRowAvailable();
    }    

    /**
     * Sets the current Row Index
     * <p>
     * This method has been modifed for LiveScrolling to prevent the
     * Row Index from being modifed for Pagination
     *
     * @param rowIndex the given index
     */
    /*
    @Override
    public void setRowIndex(int rowIndex){

        int oldIndex = this.rowIndex;

        if(rowIndex == -1 || getPageSize() == 0)
            this.rowIndex = -1;
        else // Don't Adjust the Row Index for Pagination
            this.rowIndex = rowIndex;

        if(getWrappedData() == null){
            return;
        }

        DataModelListener[] listeners = getDataModelListeners();
        if(listeners != null && oldIndex != this.rowIndex){
            Object rowData = null;
            if(isRowAvailable()){
                rowData = getRowData();
            }

            DataModelEvent dataModelEvent = new DataModelEvent(this, rowIndex, rowData);
            for(DataModelListener listener : listeners){
                listener.rowSelected(dataModelEvent);
            }
        }
    }
*/     
}
