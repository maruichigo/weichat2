/*
 * pageViewDefault.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.component;

import java.util.*;
import jp.co.sharedsys.wbb.jsf.reports.ReportColumn;
import jp.co.sharedsys.wbb.jsf.reports.ReportCondition;
import jp.co.sharedsys.wbb.jsf.reports.ReportConfig;
import javax.faces.context.FacesContext;
import javax.faces.application.FacesMessage;
import jp.co.sharedsys.wbb.jsf.reports.AbstractReportOption;
import org.apache.commons.lang3.StringUtils;
import jp.co.sharedsys.wbb.jsf.reports.AbstractReportCondition;
import jp.co.sharedsys.wbb.jsf.reports.ReportSql;
import jp.co.sharedsys.wbb.jsf.process.MsgExec;

/**
 * デフォルト値の設定を行う
 * @author klsproj
 */
public class PageViewDefault {
        
    public PageViewDefault(){
        
    }
    
    /**
     * rptのconditions用
     * @param values
     * @param config 
     */
    public void setReportCondition(Map<String, Map<String, Object>> values , ReportConfig config,Map<String, Object> defConds){

        valuesInit(values, config);
        
        for (ReportCondition condition : config.getConditions()) {
            String applyto = condition.getApplyTo();
            if ((null == applyto || "".equals(applyto)) || 
                (!values.containsKey(applyto))){
                //指定したapplytoがsql-nameタグに存在しない場合
                applyto = config.getDefaultSqlId();
                condition.setApplyTo(applyto);
            } 

            //一致するマップを取得
            Map<String, Object> valueit = values.get(applyto);
            String controltype = condition.getControlType();//rpt-control-type
            String datatype = condition.getDataType();//rpt-data-type
            String name = condition.getName();
            String defval = (String) defConds.get(name);
            List<AbstractReportOption> options = condition.getOptions();
	    if(controltype.startsWith("AUTOCOMPLETE") && defval.length() == 0){
		condition.setLabelValue("");
	    }
            
            setValue(controltype, datatype, defval, name, options, condition, valueit);
            values.put(applyto, valueit);
        }
    }
    
    /**
     * rptのmodification用
     * @param values
     * @param config 
     */
    public void setModification(Map<String, Map<String, Object>> values , ReportConfig config){

        valuesInit(values, config);
        for (ReportColumn column : config.getModification().getColumns()){
            String applyto = column.getApplyTo();
            if ((null == applyto || "".equals(applyto)) || 
                (!values.containsKey(applyto))){
                //指定しない場合はsqlの一番目に紐づけ
                applyto = config.getDefaultSqlId();
                column.setApplyTo(applyto);
            }
            
            //一致するマップを取得
            Map<String, Object> valueit = values.get(applyto);
            String controltype = column.getControlType();//rpt-control-type
            String datatype = column.getDataType();//rpt-data-type
            String defval = column.getDefaultValue();
            String name = column.getName();
             List<AbstractReportOption> options = column.getOptions();            
            AbstractReportCondition condition = (AbstractReportCondition)column;
            
            setValue(controltype, datatype, defval, name, options, condition, valueit);
            values.put(applyto, valueit);
        }
    }
    
    /**
     * rptのmodificationのうち、PKに指定された項目のみに適用
     * @param values
     * @param config 
     */
    public void setPkModification(Map<String, Map<String, Object>> values , ReportConfig config){

        valuesInit(values, config);
        for (ReportColumn column : config.getModification().getPkList()){
            String applyto = column.getApplyTo();
            if ((null == applyto || "".equals(applyto)) || 
                (!values.containsKey(applyto))){
                //指定しない場合はsqlの一番目に紐づけ
                applyto = config.getDefaultSqlId();
                column.setApplyTo(applyto);
            }
            
            //一致するマップを取得
            Map<String, Object> valueit = values.get(applyto);
            String controltype = column.getControlType();//rpt-control-type
            String datatype = column.getDataType();//rpt-data-type
            String defval = column.getDefaultValue();
            String name = column.getName();
             List<AbstractReportOption> options = column.getOptions();            
            AbstractReportCondition condition = (AbstractReportCondition)column;
            
            setValue(controltype, datatype, defval, name, options, condition, valueit);
            values.put(applyto, valueit);
        }
    }
    
    /**
     * //valuesに対して存在しないmapkey(SQLID:applyto)初期化
     * @param config
     * @return 
     */
    private void valuesInit(Map<String, Map<String, Object>> values, ReportConfig config){
        for(ReportSql sql :config.getSqls()){
            String sqlid = sql.getName();
			if (null == sqlid){
				sqlid = config.getDefaultSqlId();
			}
            if (!values.containsKey(sqlid)){
                Map<String, Object> map = new HashMap<>();
                values.put(sqlid,map); 
            }        
        }

        if (config.getSqls().size() == 0){
            String sqlid = config.getDefaultSqlId();
            Map<String, Object> map = new HashMap<>();
            values.put(sqlid,map); 
        }
    }
    
    /**
     * valuitにデータを格納する
     * checkbox multhはcondition.setItemValueに格納する。
     * @param controltype
     * @param datatype
     * @param defval
     * @param name
     * @param options
     * @param condition
     * @param valueit 
     */
    private void setValue(String controltype, String datatype, String defval, String name, List<AbstractReportOption> options,AbstractReportCondition condition, Map<String, Object> valueit){
        if (null == defval || "".equals(defval)){
            defval = "";
        }
        switch (controltype) { //除外するものはbreak
            case "HIDDEN":
                valueit.put(name, defval);
                break;
            case "HTML":    
            case "LABEL":
                valueit.put(name, defval);
                break;
            case "TEXT":
            case "TEXTAREA":
                valueit.put(name, defval);
                break;
            case "RADIO":
                try{// 配列に存在する数字が入っている場合のみ、デフォルト値として採用。
                    if ("".equals(defval)){
                        valueit.put(name, "");
                        break;
                    }
                    int r = Integer.parseInt(defval);
                    options.get(r);
                    valueit.put(name, r);
                    } catch (Exception e){
                        String msg = name + " " + defval +" RADIOのデフォルト値の指定が間違えています。";
						new MsgExec().message("ERROR", "エラー", msg);
                    }
                    break;
            case "CHECKBOX":
            case "SELECT_CHECKBOX_MENU":  
                if(controltype.equals("CHECKBOX") && "SINGLE".equals(datatype)){//selectBooleanCheckbox  value="#{condition.defaultValue}"
                    if ("true".equals(defval) || "false".equals(defval)){
                        condition.setDefaultValue(Boolean.valueOf(defval).toString());
                    } else {    
                        condition.setDefaultValue("false");
                    }
                } else { //MULTI selectManyCheckbox value="#{condition.itemValue}"
                    try {
                        defval = defval.replaceAll(" ", "");
                        String[] deflist = defval.split(",", -1);
                        List vallist = new ArrayList<>();
                        for(AbstractReportOption opt: options)
                        {
                            String label = StringUtils.strip(opt.getValue(), " 　");//全角半角トリム。
                            vallist.add(label);
                        }
                        for(String str : deflist)
                        {
                            str = StringUtils.strip(str, " 　");//全角半角トリム。
                            if("".equals(str)){
                                continue;
                            }
                            if(!vallist.contains(str)){
                                String msg = "CHECKBOX MULTIのデフォルト値に存在しない値が指定されました。";
								new MsgExec().message("ERROR", "エラー", msg);
                                return;
                            }
                        }
                        condition.setItemValue(deflist);
                    } catch (Exception e){
                        String msg = "CHECKBOX MULTIのデフォルト値の指定が間違えています。";
						new MsgExec().message("ERROR", "エラー", msg);
                    }
                    //代入はこの中で行うので返却はしない
                }
                break;
            case "SELECT":  
            case "SELECT_DYNAMIC":      
            case "SELECT_MULTI":  
            case "DOUBLECOMBO_OUT":      
            case "DOUBLECOMBO_IN":   
                valueit.put(name, defval);
                break;
            case "RANGE":    
            {
                String namestart = condition.getNameStart();
                String nameend = condition.getNameEnd();
                valueit.put(namestart, "");
                valueit.put(nameend, "");
            }
            break;
            case "BUTTON":
                break;
            case "POSTAL":
            case "TRANS":
            case "EDIT":
            case "SPLIT":
                condition.setDefaultValue(defval);
                break;
            case "AUTOCOMPLETE":
            case "AUTOCOMPLETE_DYNAMIC":
            case "AUTOCOMPLETE_MULTI":
                valueit.put(name, defval);
                break;                
            default:     
                valueit.put(name, defval);
        }       
    }
}
