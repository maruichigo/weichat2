package jp.co.sharedsys.wbb.jsf.conf;

import java.util.ArrayList;
import java.util.List;

public class XReportButton {
    private String name = null;
    private String value = null;
    private String action = null;
    private String rptFile = null;
    private String rptDir = null;
    private String service = null;
    private String tabTitle = null;
    private String functionCode = null;

    private String pdfGroupFile = null;
    private String position = null;
    private List options = new ArrayList();

    public void addOption(XReportConditionOption option) {
        this.options.add(option);
    }
    public List getOptions() {
        return options;
    }
    public void setOptions(List options) {
        this.options = options;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getValue() {
        return value;
    }
    public void setValue(String value) {
        this.value = value;
    }
    public String getAction() {
        return action;
    }
    public void setAction(String action) {
        this.action = action;
    }
    public String getRptFile() {
        return rptFile;
    }
    public void setRptFile(String rptFile) {
        this.rptFile = rptFile;
    }
    public String getRptDir() {
        return rptDir;
    }
    public void setRptDir(String rptDir) {
        this.rptDir = rptDir;
    }
    public String getService() {
        return service;
    }
    public void setService(String service) {
        this.service = service;
    }
    public String getTabTitle() {
        return tabTitle;
    }
    public void setTabTitle(String tabTitle) {
        this.tabTitle = tabTitle;
    }
    public String getPdfGroupFile() {
        return pdfGroupFile;
    }
    public void setPdfGroupFile(String pdfGroup) {
        this.pdfGroupFile = pdfGroup;
    }
    public String getPosition() {
        return position;
    }
    public void setPosition(String position) {
        this.position = position;
    }
    public void setFunctionCode(String functionCode) {
        this.functionCode = functionCode;
    }
    public String getFunctionCode() {
        return functionCode;
    }
}
