package jp.co.sharedsys.wbb.jsf.conf;

import java.util.ArrayList;
import java.util.List;

public class XReportModification {
    private String mode = null;
    private String defaultLine = null;
    private String insert = null;
    private String update = null;
    private String delete = null;

    private List columns = new ArrayList();

    public String getMode() {
        return mode;
    }
    public void setMode(String mode) {
        this.mode = mode;
    }
    public String getDefaultLine() {
        return defaultLine;
    }
    public void setDefaultLine(String defaultLine) {
        this.defaultLine = defaultLine;
    }
    public String getInsert() {
        return insert;
    }
    public void setInsert(String insert) {
        this.insert = insert;
    }
    public String getUpdate() {
        return update;
    }
    public void setUpdate(String update) {
        this.update = update;
    }
    public String getDelete() {
        return delete;
    }
    public void setDelete(String delete) {
        this.delete = delete;
    }
    public void addColumn(XReportColumn column) {
        this.columns.add(column);
    }
    public List getColumns() {
        return columns;
    }
}
