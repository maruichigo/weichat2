  /*
 * SSNaviManagedBean.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.beans;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.FacesEvent;
import javax.faces.event.ValueChangeEvent;
import jp.co.kintetsuls.common.MessageDataModel;
import jp.co.kintetsuls.common.UpLoadFileDataModel;
import jp.co.kintetsuls.common.svf.PrintReport;
import jp.co.kintetsuls.common.svf.SvfDataModel;
import jp.co.sharedsys.common.methods.SSCommonUtil;
import jp.co.sharedsys.wbb.jsf.exception.LogicException;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;
import jp.co.sharedsys.wbb.jsf.external.general.ExternalServiceProperty;
import jp.co.sharedsys.wbb.jsf.process.ExternalServiceExecuter;
import jp.co.sharedsys.wbb.jsf.process.ExternalServiceExecuterForMultipart;
import jp.co.sharedsys.wbb.jsf.process.ExternalServiceParameterCheck;
import jp.co.sharedsys.wbb.jsf.process.OptionsFinder;
import jp.co.sharedsys.wbb.jsf.reports.AbstractReportCondition;
import jp.co.sharedsys.wbb.jsf.reports.AbstractReportOption;
import jp.co.sharedsys.wbb.jsf.reports.ReportButton;
import jp.co.sharedsys.wbb.jsf.reports.ReportColumn;
import jp.co.sharedsys.wbb.jsf.reports.ReportCondition;
import jp.co.sharedsys.wbb.jsf.reports.ReportConditionOption;
import jp.co.sharedsys.wbb.jsf.reports.ReportConfig;
import jp.co.sharedsys.wbb.jsf.reports.ReportConst;
import jp.co.sharedsys.wbb.jsf.reports.ReportListColumn;
import jp.co.sharedsys.wbb.jsf.reports.ReportPdfGroup;
import jp.co.sharedsys.wbb.jsf.reports.ReportSql;
import jp.co.sharedsys.wbb.jsf.util.bean.PagePropertiesBean;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.primefaces.component.api.UIData;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.context.RequestContext;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.event.MenuActionEvent;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.primefaces.model.TreeNode;
import org.primefaces.model.menu.MenuItem;
import jp.co.sharedsys.wbb.jsf.component.PageViewDefault;
import jp.co.sharedsys.wbb.jsf.component.PageParameterGetter;
import jp.co.sharedsys.wbb.jsf.component.PageTableSelected;
import jp.co.sharedsys.wbb.jsf.process.ExternalServiceExecuter2;
import jp.co.sharedsys.wbb.jsf.process.MsgExec;
import jp.co.sharedsys.wbb.jsf.modules.CloneCls;
import jp.co.sharedsys.wbb.jsf.process.ExternalServiceExecuterForHolidays;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.primefaces.model.UploadedFile;

/**
 *
 * @author saihara
 */
@ManagedBean(name = "pageBean")
@ViewScoped
public class SSNaviManagedBean extends AbstractSSNaviManagedBean {

    @ManagedProperty(value = "#{menuBean}")
    private MenuBean menuBean;
    @ManagedProperty(value = "#{authConf}")
    private AuthorityConfBean authConf;
    @ManagedProperty(value = "#{ssconfig}")
    private JsfSatteliteApplicationBean ssconfig;
    @ManagedProperty(value = "#{breadCrumbBean}")
    private BreadCrumbBean breadCrumbBean;
    // Handsontable section start
    @ManagedProperty(value = "#{parentWindowSize}")
    private String parentWindowSize;
    @ManagedProperty(value = "#{handsontableVal}")
    private String handsontableVal;
    @ManagedProperty(value = "#{popupBean}")
    private PopUpDeliveryBean popupBean;
    
    private ReportConfig config;
    private ReportConfig oldConfig;
    private Map<String, Object> defConds = new HashMap();
    // 共通メンテナンス画面用可変config
    private ReportConfig maintConfig;
    private ReportConfig oldMaintConfig;

    private String testText;
    private String r;
    private String isSearch;
    private String isTrans;

    // 現在のテンプレートXHTML
    private String curXhtml;
    // 現在の画面モード
    private String editMode;
    // 一時的に画面モードを変更した際に、現在の画面モードを保存する領域
    private String editModeTemp;
    // 一覧検索結果の格納先
    private Map<String, List<Map<String, Object>>> reportResult;
    private Map<String, List<Map<String, Object>>> oldReportResult;
    // 一覧結果のフィルタON/OFF管理
    private Map<String, List<Boolean>> visibleFilter;
    // 一覧検索結果をチェックボックスで選択可能とするためのクラス
    private ReportListDataModel selectableResult;
    private ReportListDataModel oldSelectableResult;
    // contextメニュー用リスト
    private List<ReportColumn> oldColumnList;
    private Map<String, List<Map<String, Object>>> contextResult;
    private ReportListDataModel contextMenuResult;
    private ReportListDataModel contextTableResult;    
    
    private ReportListDataModel columnLists;
    private Map<String, List> optionLists;
    // 一覧検索結果をチェックボックスで選択可能とするためのクラス
    private ReportListTreeDataModel selectableTreeResult;
    // 一覧検索結果をチェックボックスで選択可能とするためのクラス(複数定義用)
    private Map<String, ReportListDataModel> selectableResults;
    // 一覧検索結果をチェックボックスで選択可能とするためのクラス(Tree,複数定義用)
    private TreeNode[] selectedNodes;
    // 画面で選択された行の格納先
    private List<Map<String, Object>> selectReportResult;
    private List<Map<String, Object>> oldSelectReportResult;
    // 画面で選択された行の格納先(編集画面)
    private Map<String, List<Map<String, Object>>> selectEditReportResult;
    // サイドバー検索結果の格納先
    private Map<String, List<Map<String, Object>>> reportSidebarResult;
    // マスタ選択項目格納先
    private String selectMaster;
    private String oldSelectMaster;
    // マスタ選択項目設定格納先
    private AbstractReportCondition condMaster;
    // ソート順選択項目格納先
    private List<Map<String, Object>> sortVal;
    // ソート順、selectOneMenuで選択された格納先
    private String selectedSort;

    // 押下されたボタンのReportButton(f:setPropertyActionListenerで設定される)
    private ReportButton execButton;

    // 印刷実施ボタンの、selectOneMenuで選択された項目格納先
    private Map<String, ReportPdfGroup> selectedPdf;

    // 画面からアップロードされたファイルの格納先
    private List<File> uploadFiles;

    // 外部サービスのレスポンス情報格納先
    private Map<String, Object> externalAttribute;

    private Map<String, UIComponent> idBind;

    // 画面からの入力値を受け付けるプロパティ
    private Map<String, Map<String, Object>> values;
    private ArrayList<Object> objectValues;
    private Map<String, Map<String, Object>> oldValues;
    private ArrayList<Object> oldObjectValues;
    private Map<String, Object> selectedLine;
    // Datatable内データ入力値受付の為のプロパティ
    private Map<String, List<Map<String, Object>>> listValues;
    // Dialog表示時に使用するパラメータ
    private List<Map<String, String>> dialogParams;

    // 外部サービス呼出の為のパラメータ
    private List<Map<String, Object>> targetServices;
    // アップロード用 アップロード方法格納先
    private String wayOfUpload;
    // 共通アップロード用　アップロードチェック件数格納先
    private Map<String,Object> uploadStatuses;
    // 共通アップロード用　アップロードファイル定義格納先
    private List<Map<String, Object>> uploadFileDef;
    // アップロードファイル名格納先
    private List<String> uploadFileName;
    // 共通アップロード用　ヘッダー名格納先
    private String headerName;
    // 共通アップロード用　一覧内変更情報格納先
    private String isChange;
    // SVF用　SVF出力情報格納先
    private SvfDataModel svfData;
    // アップロードファイル
    private ArrayList<UpLoadFileDataModel> upLoadFileStream;
    private UploadedFile file;
    //ViewScope内で参照するクラス、メソッド
    private String viewClass;
    private String viewMethod;
    // 休日管理用jsonファイル
    private String holidayFilePath = "C:\\KLS_APP_SSNAVI_SNAPSHOT_1221\\SSNavi-JSF\\src\\main\\webapp\\contents\\holidays.json";
    
    // DataTableの行クリックイベントに使用
    private Object selectedValue = "";
    public Object getSelectedValue() {
        return selectedValue;
    }
    public void setSelectedValue(Object selectedValue) {
        this.selectedValue = selectedValue;
    }
    
    public SSNaviManagedBean() {
        parameterInitialization();
    }

    private List universalList1;
    public List getUniversalList1() {
        return universalList1;
    }
    public void setUniversalList1(List value) {
        this.universalList1 = value;
    }

    private List universalList2;
    public List getUniversalList2() {
        return universalList2;
    }
    public void setUniversalList2(List value) {
        this.universalList2 = value;
    }

    private List universalList3;
    public List getUniversalList3() {
        return universalList3;
    }
    public void setUniversalList3(List value) {
        this.universalList3 = value;
    }    
    
    /**
     * ログイン後のトップページを表示する
     * @return menu page xhtml
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    public String init() throws SystemException {
        parameterInitialization();

        setTestText("is this show??");
        setCurXhtml("/contents/main_content.xhtml");
        setConfig(new ReportConfig());
        getConfig().setScreenCode("top_page");
        return "main.xhtml";
    }

    /**
     * メニューから選択された時に、テンプレートを決定するメソッド
     * menubarで指定されるel式にReportIDを引数で渡す。
     * @param event ActionEvent
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    public void gotoNext(ActionEvent event) throws LogicException, SystemException {

        // 項目初期化
        parameterInitialization();
        // 2018/10/10 Kobayashi 初期化項目を追加
        setDefConds(new HashMap<>());

        this.authConf.setUserCd("admin");
        this.authConf.setUserGroup(Arrays.asList(new String[]{"TEST"}));     			
		
        // 表示する画面のReportConfigを取得
        MenuItem menuItem = ((MenuActionEvent) event).getMenuItem();
        String repid = (String)menuItem.getParams().get("repid").get(0);
        ReportConfig tmpConfig = getSsconfig().getConfigs().get(repid);
        // init filter on/off
        tmpConfig.setFilterShow("filter_on");

        //深い階層のディープコピーを行う
        setConfig(CloneCls.deepcopy(tmpConfig));	
		
        //初期化処理
        if (null == config.getBridge()){
            gotoNextInit(getConfig(), repid);
        } else {
            Map<String, Object> eventmap = event.getComponent().getAttributes();
            eventmap.put("timing", "next");
            eventmap.put("cls", config.getBridge());
            eventmap.put("method", "init");
            callBusinessLogic(event);
            gotoNextInit(config, repid);
            eventmap.put("face","faceend");
            eventmap.put("endcls", config.getBridge());
            eventmap.put("endmethod", "close");
            callBusinessLogic(event);
            eventmap.remove("timing");
        }

        try {
        // パンくず構築
                getBreadCrumbBean().gotoFirst(repid, this);
        } catch (IllegalAccessException | InvocationTargetException ex) {
                Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
                throw new SystemException(ex);
        }
    }

	/**
	 * 画面初期化
	 * @param tmpConfig
	 * @param repid
	 * @throws LogicException
	 * @throws SystemException 
	 */
    private void gotoNextInit(ReportConfig tmpConfig, String repid) throws LogicException, SystemException {
            logger.debug("ReportID:" + repid);
            
            if (tmpConfig == null) {
                throw new LogicException("Specified report-id was not found.[" + repid + "]");
            }

            // 初回展開時にデフォルト検索結果を表示するためのコード
            if (!tmpConfig.isReady() || tmpConfig.isReloadCondition()){
                //if config status is not ready, there needs to create option values
                synchronized(tmpConfig){
                    this.generateOption(tmpConfig, getAuthConf());
                    this.generateOptionByModification(tmpConfig, getAuthConf());
                    tmpConfig.setReady(true);
                }
            }

            //デフォルトのsqlidを設定
            new PageParameterGetter().setDefaultSqlid(tmpConfig);
            //新規遷移系(gotoNext)は、新しいinstansが渡され、次遷移系(Trans)は前回のtmpconfigのinstansが渡される
            config = tmpConfig;

            if (authConf.getAuthScCompoMap().containsKey(repid)){
                //コンポーネント権限がある場合は取得
                Map <String, Integer> authCompo = authConf.getAuthScCompoMap().get(repid);
                config.setAuthCompo(authCompo);
            }

            //初期化用のdeconfigを保持
            for (ReportCondition cond : getConfig().getConditions()) {
                getDefConds().put(cond.getName(), cond.getDefaultValue());
            }

            
            // 遷移先テンプレートXHTML決定
            if (getCurXhtml() != null && getCurXhtml().equals(this.getConfig().getPageTemplate())) {
                // Datatableのリセット
                UIComponent pcomponent = FacesContext.getCurrentInstance().getViewRoot().findComponent(":main_section");
                if(pcomponent != null) {
                    resetDatatable(pcomponent.getChildren());
                }
            }
            setCurXhtml(this.getConfig().getPageTemplate());
            setSelectableTreeResult(new ReportListTreeDataModel());

            for (ReportCondition condition : getConfig().getConditions()) {
                // マスタ選択値の場合(マスタ選択領域があるもの用)
                if (condition.getName().equals("_TARGET_MASTER")) {
                    setCondMaster(condition);
                    break;
                }
            }
	    
            //初期値(defaultvalue)を代入する
            PageViewDefault pageViewDefault = new PageViewDefault();
            pageViewDefault.setModification(values, config);
            pageViewDefault.setReportCondition(values ,  config, getDefConds());

            //画面作成時にコンテキストメニュー作成
            config.setContexts();

            //アップロード画面はオリジナル変数を保有
            if (config.getScreenCode().equals(ReportConst.F_SCREEN.UPLOAD)){
                setSelectMaster("");
                setMaintConfig(null);
                setUploadStatuses(null);
                setUploadFileDef(null);
            }
    }

    /**
     * 共通メンテナンス画面がメニューから選択された時に実行されるメソッド
     * menubarで指定されるel式にReportIDを引数で渡す。
     * @param event ActionEvent
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
/* 共通メンテはアップロード以外を使用しないためコメント化
    public void gotoNextForComMaint(ActionEvent event) throws LogicException, SystemException {
        // 項目初期化
        parameterInitialization();
        // 表示する画面のReportConfigを取得
        MenuItem menuItem = ((MenuActionEvent) event).getMenuItem();
        String repid = (String)menuItem.getParams().get("repid").get(0);
        ReportConfig tmpConfig = getSsconfig().getConfigs().get(repid);
        // init filter on/off
        tmpConfig.setFilterShow("filter_on");
//		if (parameter.getExternalParameter().get("scrcode") != null) {
//			config.setCurrentScreenCode((String)parameter.getExternalParameter().get("scrcode"));
//		}
//		ReportConfig config = (ReportConfig) ReportContext.getInstance(pkey).getConfigs().get((String) parameter.getExternalParameter().get("scrcode"));
//		if (config == null) {
//			config = (ReportConfig) ReportContext.getInstance(pkey).getConfigs().get(repid);
//		}
        logger.debug("ReportID:" + repid);
        if (tmpConfig == null) {
            throw new LogicException("Specified report-id was not found.[" + repid + "]");
        }

        // 初回展開時にデフォルト検索結果を表示するためのコード
//        if (!"true".equalsIgnoreCase(parameter.getParameter(P_SKIPOPTION))) {
	if (!tmpConfig.isReady() || tmpConfig.isReloadCondition()){
            //if config status is not ready, there needs to create option values
	    synchronized(tmpConfig){
                this.generateOption(tmpConfig, getAuthConf());
                tmpConfig.setReady(true);
            }
        }
//		}

        this.setConfig(tmpConfig.clone());
        // condition に applyToを入れておく(入力値の値取得に、applyToの設定が必要)
        getConfig().getConditions().forEach((condition) -> {
            condition.setApplyTo(getConfig().getSqls().get(0).getName());
        });

        getValues().put(getConfig().getSqls().get(0).getName(), new HashMap<>());
        // 遷移先テンプレートXHTML決定
        if (getCurXhtml() != null && getCurXhtml().equals(this.getConfig().getPageTemplate())) {
            // Datatableのリセット
            UIComponent pcomponent = FacesContext.getCurrentInstance().getViewRoot().findComponent(":main_section");
            if(pcomponent != null) {
                resetDatatable(pcomponent.getChildren());
            }
        }
        setCurXhtml(this.getConfig().getPageTemplate());
        setSelectableTreeResult(new ReportListTreeDataModel());

        for (ReportCondition condition : getConfig().getConditions()) {
            // マスタ選択値の場合(マスタ選択領域があるもの用)
            if (condition.getName().equals("_TARGET_MASTER")) {
                setCondMaster(condition);
                break;
            }
        }
        
        try {
            // パンくず構築
            getBreadCrumbBean().gotoFirst(repid, this);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw new SystemException(ex);
        }
    }
*/

    /**
     * DataTableの初期化メソッド
     * @param components List<UIComponent>
     */    
    private void resetDatatable(List<UIComponent> components) {
        components.forEach((component) -> {
            if (component instanceof DataTable) {
                ((DataTable)component).clearLazyCache();
                ((DataTable)component).clearInitialState();
                ((DataTable)component).reset();
                ((DataTable)component).resetValue();
                ((DataTable)component).restoreTableState();
            } else {
                resetDatatable(component.getChildren());
            }
        });
    }

    /**
     * ダイアログ画面クローズ時処理
     * @param event 
     */
    public void popClose(ActionEvent event){
        if ( getOldConfig() != null ){
            this.getConfig().getModification().getColumns().clear();   
            for(ReportColumn clm : getOldColumnList()) {
                this.getConfig().getModification().getColumns().add(clm);
            }
            getOldColumnList().clear();
            setOldConfig(new ReportConfig());
        }
        if( getOldMaintConfig() != null ) {
            this.getMaintConfig().getModification().getColumns().clear();   
            for(ReportColumn clm : getOldColumnList()) {
                this.getMaintConfig().getModification().getColumns().add(clm);
            }
            getOldColumnList().clear();
            setOldMaintConfig(new ReportConfig());
        }
    }        

    /**
     * 一覧検索画面で指定されたパラメータをもとに、外部サービスから
     * データ検索結果を取得する。
     * @param event
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     * @throws java.lang.IllegalAccessException
     * @throws java.lang.reflect.InvocationTargetException
     */
/* 古いバージョンなのでいったんコメント化⇒不要であれば削除
    public void executeSearch(ActionEvent event) throws LogicException, SystemException, IllegalAccessException, InvocationTargetException {
        
        // 業務個別ロジック呼び出し
        callBusinessLogic(event);

        // 一覧検索画面は、1つ目のSql定義使用を強制する
        ReportSql targetDef = getConfig().getSqls().get(0);
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
        target.put(ExternalServiceExecuter.E_FUNCTION, targetDef.getFunctionCode());
        target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);

        Map<String, Object> sendParams = new HashMap<>();
        for(ReportCondition cond : getConfig().getConditions()) {
            if ( cond.getOptions().size() > 0 ) {
                // チェックボックス、セレクト、ラジオボタン以外の場合
                if (!cond.getControlType().equals("CHECKBOX") && !cond.getControlType().equals("RADIO") 
                        && !cond.getControlType().equals("RADIO_DYNAMIC") && !cond.getControlType().equals("SELECT_CHECKBOX_MENU") ) {
                    
                    for( String key : getValues().keySet() ){
                        if(getValues().get(key).get(cond.getName()) instanceof ReportConditionOption){
                            ReportConditionOption op = (ReportConditionOption)getValues().get(key).get(cond.getName());
                            if ( op != null) {
                                sendParams.put(cond.getName(), (String)op.getValue() );
                                getValues().get(key).replace(cond.getName(), (String)op.getValue());
                            }    
                        }else{
                            sendParams.put(cond.getName(), getValues().get(key).get(cond.getName()));
                        };
                    }
                } else {
                    // チェックボックス、ラジオボタンの場合
                    // 画面上でチェックされた内容を検索条件にセットする
                    if(cond.getItemValue() != null) {
                        sendParams.put(cond.getName(), cond.getItemValue());

                        for (AbstractReportOption op : cond.getOptions()) {
                            for (String itemValue : cond.getItemValue()) {
                                if (itemValue.equals(op.getValue())) {
                                    sendParams.put(cond.getName() + "_" +op.getValue(), itemValue);
                                    break;
                                }
                            }  
                        }  
                    } else {
                        sendParams.put(cond.getName(), "");
                    }
                }
            }else{
                if(cond.getDefaultValue() != null) {
                  sendParams.put(cond.getName(), cond.getDefaultValue());
                  
                }
            }
        }
        
        target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);
        this.getTargetServices().add(target);
        searchProcess();

        setSelectableResult(new ReportListDataModel(this.getReportResult().get(targetDef.getName()), this.colPkName()));
       
        // 一覧のOption項目を取得する
        synchronized(this.getConfig()){
            this.generateOptionByModification(this.getConfig(), getAuthConf());
            this.getConfig().setReady(true);
        }
        setOldConfig(getConfig());
        setOldColumnList(new ArrayList<>());
        for(ReportColumn clm : this.getConfig().getModification().getColumns()) {
            getOldColumnList().add(clm);
        }
            
        // contextメニュー作成
        if( getConfig().getSqls().size() > 1) {
            this.executeContextSearch(1);   
        }
        
        // 明細行用
        getConfig().getSqls().forEach((sql) -> {
            // 入力値受付パラメータに、検索結果をdeep copy
            getListValues().put(sql.getName(), new ArrayList<>(getReportResult().get(sql.getName())));
        });        
    }
*/
    
    /**
     * attributeタグで指定されている場合は、該当のrpt-sql-nameタグのSQL情報を使用。
     * 指定されていない場合はrpt-sql-nameタグ0番目のSQL情報を使用。
     * @param event
     * @return 
     */
    public ReportSql buttonActGetReportSql(FacesEvent event){
        //attributeタグで指定されている場合は、該当のsqlnameタグを使用。指定されていない場合は0番目を使用。
        ReportSql targetDef = getConfig().getSqls().get(0);
        Map<String ,Object> attribute = event.getComponent().getAttributes();
        if (attribute.containsKey("applyTo")){
            String applyTo = (String)event.getComponent().getAttributes().get("applyTo");
            for (ReportSql rs: getConfig().getSqls()){
                if (applyTo.equals(rs.getName())){
                    targetDef = rs;
                    break;
                }
            }
        }
        return targetDef;
    }

    /**
     * 一覧検索画面で指定されたパラメータをもとに、外部サービスから
     * データ検索結果を取得する。
     * @param event
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException
     * @throws java.lang.reflect.InvocationTargetException
     * @throws java.lang.IllegalAccessException
     */
    public void executeSearch(FacesEvent event) throws LogicException, SystemException, IllegalAccessException, InvocationTargetException {
        // 業務個別ロジック呼び出し
        this.authConf.setUserCd("admin");
        this.authConf.setUserGroup(Arrays.asList(new String[]{"TEST"}));  
        callBusinessLogic(event);   
        //attributeタグで指定されている場合は、該当のsqlnameタグを使用。指定されていない場合は0番目を使用。
        ReportSql targetDef = buttonActGetReportSql(event);        
        List<Map<String, Object>> resultlist = callSql(targetDef, null);
        setSelectableResult(new ReportListDataModel(resultlist, this.colPkName(), config.getModification().getColumns()));
        if (0 == resultlist.size()){
            return;
        }
        
        // 一覧のOption項目を取得する
        synchronized(this.getConfig()){
            this.generateOptionByModification(this.getConfig(), getAuthConf());
            this.getConfig().setReady(true);
        }
        setOldConfig(getConfig());
        setOldColumnList(new ArrayList<>());
        for(ReportColumn clm : this.getConfig().getModification().getColumns()) {
            getOldColumnList().add(clm);
        }
            
        // contextメニュー作成
        if( getConfig().getSqls().size() > 1) {
            this.executeContextSearch(1);   
        }
        
        // 明細行用
        getConfig().getSqls().forEach((sql) -> {
            // 入力値受付パラメータに、検索結果をdeep copy
            getListValues().put(sql.getName(), new ArrayList<>(getReportResult().get(sql.getName())));
        });        
     }

    /**
     * 一覧検索画面で指定されたパラメータをもとに、外部サービスから
     * データ検索結果を取得する。Tree,またはTreeTable用データバインド
	 * s_furutani
     * @param event
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException
     */
    public void executeSearchForTree(FacesEvent event) throws LogicException, SystemException {
        // 業務個別ロジック呼び出し
        callBusinessLogic(event);
        
        boolean isCheckbox = true;
        ReportSql targetDef = buttonActGetReportSql(event);
        List<Map<String, Object>> resultlist = callSql(targetDef, null);
        getSelectableTreeResult().init(resultlist, this.colPkName(), isCheckbox);
    }

    /**
     * 一覧検索画面で指定されたパラメータをもとに、外部サービスから
     * データ検索結果を取得する。(共通メンテナンス用)
     * @param event
     */
/* 共通メンテはアップロード以外を使用しないためコメント化
    public void executeSearchForMaint(ActionEvent event) throws Exception {
        // 業務個別ロジック呼び出し
        callBusinessLogic(event);
        
        //confirm検知
        if ( getConfig().getModification().isUpdateFlg() ) {
            // callbackで判定戻し（編集中）
            RequestContext context = RequestContext.getCurrentInstance();  
            context.addCallbackParam("updateFlg", getConfig().getModification().isUpdateFlg());
            context.addCallbackParam("cfType", "sch");
        }else{
            // 検索処理
            ReportSql targetDef = getConfig().getSqls().get(0);
            Map<String, Object> target = new HashMap<>();
            this.setTargetServices(new ArrayList<>());
            target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
            target.put(ExternalServiceExecuter.E_FUNCTION, targetDef.getFunctionCode());
            target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
            target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
            target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);

            Map<String, Object> sendParams = new HashMap<>();
            for(ReportCondition cond : getMaintConfig().getConditions()) {
                if( cond.getDefaultValue() != null ) {
                    if ( cond.getOptions().size() > 0 ) {
                        for( String key : getValues().keySet() ){
                            //optionsを優先取得し、optionではない場合はvalueitを取得させる対応
                            if(getValues().get(key).get(cond.getName()) instanceof ReportConditionOption){
                                ReportConditionOption op = (ReportConditionOption)getValues().get(key).get(cond.getName());
                                if ( op != null) {
                                    sendParams.put(cond.getName(), (String)op.getValue() );
                                    getValues().get(key).replace(cond.getName(), (String)op.getValue());
                                }    
                            }else{
                                sendParams.put(cond.getName(), getValues().get(key).get(cond.getName()));
                            };                            
                        }
                    }else{
                        sendParams.put(cond.getName(), cond.getDefaultValue());
                    }
                }
            }

            sendParams.put("TABLE_NAME", this.getSelectMaster());
            if (getSortVal().size() > 0) {
                sendParams.put("searchOption", getSortVal().size()==1 ? getSortVal().get(0).get("VALUE") : this.getSelectedSort() );
            }
            
            target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);
            this.getTargetServices().add(target);

            searchProcess();

            setSelectableResult(new ReportListDataModel(this.getReportResult().get(targetDef.getName()), this.colPkName(this.getMaintConfig())));
            // contextメニュー作成
            this.executeContextSearch(0);
            // 一覧部リスト作成
            this.executeMainListSearch();
           
            //
            setOldMaintConfig(getMaintConfig());
            setOldColumnList(new ArrayList<>());
            for(ReportColumn clm : this.getMaintConfig().getModification().getColumns()) {
                getOldColumnList().add(clm);
            }

            // 明細行用
            getMaintConfig().getSqls().forEach((sql) -> {
                // 入力値受付パラメータに、検索結果をdeep copy
                getListValues().put(sql.getName(), new ArrayList<>(getReportResult().get(sql.getName())));
            });              
        }
    }
*/
    
    /**
     * DataTableの一覧の履歴用に、コンテキストメニュー取得する。（ポップアップ表示される履歴一覧のSQL情報）
     * @param type
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException
     * @throws java.lang.IllegalAccessException
     * @throws java.lang.reflect.InvocationTargetException
     */
    public void executeContextSearch(int type) throws LogicException, SystemException, IllegalAccessException, InvocationTargetException, InvocationTargetException {
  
        ReportSql targetDef = getConfig().getSqls().get(type);
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
        target.put(ExternalServiceExecuter.E_FUNCTION, "SS_COM_MAINT_SUB_SEARCH");
        target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);

        // 画面構成リストのバックアップ
        if (getSelectableResult() != null) {
            setOldSelectableResult(new ReportListDataModel(null, null, null));
            BeanUtils.copyProperties(getOldSelectableResult(), getSelectableResult());
        }
        
        setOldReportResult(new HashMap<>());
        for ( String key : getReportResult().keySet() ){
            getOldReportResult().put(key, getReportResult().get(key) );
        }        
        // 画面チェック状態のバックアップ
        setOldSelectReportResult(new ArrayList<>());
        if ( getSelectReportResult() != null ) {
            for ( Map map : getSelectReportResult() ) {
                getOldSelectReportResult().add( map );
            }
        }
        // 画面からの入力値のバックアップ
        setOldValues(new HashMap<>());
        if ( getValues() != null ) {
            for ( String key : getValues().keySet() ) {
                if (!values.get(key).isEmpty()) {
                    getOldValues().put(key, getValues().get(key));
                }
            }            
        }

        setOldObjectValues(new ArrayList<>());
        if ( getObjectValues() != null ) {
            for (int i=0; i<objectValues.size(); i++) {
                    oldObjectValues.add(objectValues.get(i));
            }            
        }
        
        Map<String, Object> sendParams = new HashMap<>();
        String tableName = "";
        if( !this.selectMaster.isEmpty() ) {
            tableName = this.getSelectMaster();
        } else {
            tableName = targetDef.getTableName();
        }
        sendParams.put("TABLE_NAME", tableName);     
        target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);

        this.getTargetServices().add(target);
        
        searchProcess();
        
        setContextMenuResult(new ReportListDataModel(this.getReportResult().get(targetDef.getName()), this.colPkName(), config.getModification().getColumns()));        
        
        this.resetList();
    }
    
    /**
     * 検索実行時に、一覧部用Listを作成する(共通メンテナンス用)
     * @throws LogicException
     * @throws SystemException
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     */
/* 共通メンテはアップロード以外を使用しないためコメント化
    public void executeMainListSearch() throws LogicException, SystemException, IllegalAccessException, InvocationTargetException, InvocationTargetException {

        setOldReportResult(new HashMap<>());
        for ( String key : getReportResult().keySet() ){
            getOldReportResult().put(key, getReportResult().get(key) );
        }        
        
        ReportSql targetDef = getConfig().getSqls().get(0);
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
        target.put(ExternalServiceExecuter.E_FUNCTION, "SS_COM_MAINT_COLUMN_LIST");
        target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);

        // 画面構成リストのバックアップ
        if (getSelectableResult() != null) {
            setOldSelectableResult(new ReportListDataModel(null, null));
            BeanUtils.copyProperties(getOldSelectableResult(), getSelectableResult());
        }
        
        setOldReportResult(new HashMap<>());
        for ( String key : getReportResult().keySet() ){
            getOldReportResult().put(key, getReportResult().get(key) );
        }        
        // 画面チェック状態のバックアップ
        if ( getSelectReportResult() != null ) {
            setOldSelectReportResult(new ArrayList<>());
            for ( Map map : getSelectReportResult() ) {
                getOldSelectReportResult().add( map );
            }
        }
        // 画面からの入力値のバックアップ
        setOldValues(new HashMap<>());
        for ( String key : getValues().keySet() ) {
            if (!values.get(key).isEmpty()) {
                getOldValues().put(key, getValues().get(key));
            }
        }
        
        setOldObjectValues(new ArrayList<>());
        if ( getObjectValues() != null ) {
            for (int i=0; i<objectValues.size(); i++) {
                    oldObjectValues.add(objectValues.get(i));
            }            
        }
        
        Map<String, Object> sendParams = new HashMap<>();
        sendParams.put("TABLE_NAME", this.getSelectMaster());
        target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);
        this.getTargetServices().add(target);
        searchProcess();
        setColumnLists(new ReportListDataModel(this.getReportResult().get(targetDef.getName()), this.colPkName(this.getMaintConfig())));
        setOptionLists((Map<String, List>) new HashMap());

        for ( Map map : getColumnLists().getDatasource() ) {
            
            targetDef = getConfig().getSqls().get(0);
            target = new HashMap<>();
            this.setTargetServices(new ArrayList<>());
            target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
            target.put(ExternalServiceExecuter.E_FUNCTION, (String)map.get("searchOptFuncName") + "_COMLIST");
            target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
            target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
            target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);
            sendParams = new HashMap<>();
            sendParams.put("TABLE_NAME", (String)map.get("tableName"));
            target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);
            this.getTargetServices().add(target);
            searchProcess();

            List<AbstractReportOption> list = new ArrayList();
            for (Map op : this.getReportResult().get(targetDef.getName()) ) {
                AbstractReportOption option = new ReportConditionOption();            
                option.setValue( (String)op.get("VALUE") );
                option.setLabel( (String)op.get("LABEL") );
                String[] spVal = op.get("LABEL").toString().split(":");
                if( spVal.length > 1) {
                    option.getRelationValues().put( "pval", spVal[1] );
                } else {
                    option.getRelationValues().put( "pval", (String)op.get("LABEL") );
                }
                
                list.add(option);
            }
            getOptionLists().put( (String)map.get("columnName"), list );
        }
        
        setSelectForTable();
        this.resetList();    
    }    
    
    /**
     * Tableから取得したリストをカラム情報に渡す(一覧用）
     */
/* 共通メンテはアップロード以外を使用しないためコメント化
    private void setSelectForTable() {
        int i = 0;
        for( ReportColumn clm : this.getMaintConfig().getModification().getColumns() ) {
            if ( getOptionLists().get(clm.getName()) != null ) {
                this.getMaintConfig().getModification().getColumns().get(i).setOptions(getOptionLists().get(clm.getName()) );
            }
            i++;
        }        
    }
*/
    
    /**
     * 検索条件から取得したリストをカラム情報に渡す(一覧用）
     * 親切機能なので敢えて未導入
     */
//    @Deprecated
/* 未使用なのでコメント化
    private void setSelectForSearch() {
        for ( ReportCondition rc : this.getMaintConfig().getConditions() ) {
            if ( rc.getControlType().equals( ReportConst.ControlType.SELECT )) {
                int i = 0;
                for( ReportColumn clm : this.getMaintConfig().getModification().getColumns() ) {
                    if ( clm.getName().equals( rc.getName() )) {
                        this.getMaintConfig().getModification().getColumns().get(i).setOptions( rc.getOptions() );
                    }
                    i++;
                }
            }
        }
    }
*/
    
    /**
     * コンテキストメニューにセットされているSQLを実行する。
     * @param sql
     * @throws LogicException
     * @throws SystemException 
     * @throws java.lang.IllegalAccessException 
     * @throws java.lang.reflect.InvocationTargetException 
     */
    public void executeSql(String sql) throws LogicException, SystemException, IllegalAccessException, InvocationTargetException {

        ReportSql targetDef = getConfig().getSqls().get(0);
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
        target.put(ExternalServiceExecuter.E_FUNCTION, "SS_COM_MAINT_EXEC_SQL");
        target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);
        
        Map<String, Object> sendParams = new HashMap<>();
        String tableName = "";
        if( this.getSelectMaster() != null) {
            tableName = this.getSelectMaster();
        } else {
            tableName = targetDef.getTableName();
        }
        sendParams.put("TABLE_NAME", tableName);
        sendParams.put(ExternalServiceExecuter.E_SQL, createWhereSection(sql));
        target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);
        
        this.getTargetServices().add(target);
        
        searchProcess();
        
        // ReportColumnの組み立て
        createcolumn (this.getReportResult().get(targetDef.getName()) , "");     
        setContextTableResult(new ReportListDataModel(this.getReportResult().get(targetDef.getName()), this.colPkName(), config.getModification().getColumns()));
        
    }    
    
    /**
     * order by句を動的作成する
     * @param sql
     * @return 
     */
    private String createWhereSection(String sql) {
        String[] col = null;
        String upSql = StringUtils.upperCase(sql);
        if ( upSql.contains( "WHERE" ) ) {
            col = upSql.split("WHERE");
        } else {
            return upSql;
        }
        
        String val = "";
        // バインド対象個所があれば処理する
        if (sql.contains("=")) {
            String[] str = col[1].split("=");

            String key = StringUtils.deleteWhitespace(str[0]);
            if ( str[1].contains("?") ) {
                for(Map map : getSelectReportResult()) {
                    if ( map.keySet().contains( key.toLowerCase() ) ) {
                        val = (String)map.get(StringUtils.deleteWhitespace(str[0].toLowerCase()));
                    } else {
                        // SQLに想定外のカラムが設定されている
                    }
                }
            }
        }
        return StringUtils.swapCase(upSql.replace("?", val) );        
    }
        
    /**
     * 画面上で選択されたアップロードデータタイプに対し、外部サービスから
     * 一時保存データ検索結果を取得する。(共通アップロード用)
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    public void executeSearchForUploadTmp() throws LogicException, SystemException {
        ReportSql targetDef = getConfig().getSqls().get(0);
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
        target.put(ExternalServiceExecuter.E_FUNCTION, targetDef.getFunctionCode());
        target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);

        Map<String, Object> sendParams = new HashMap<>();
        sendParams.put("selectMaster", this.getSelectMaster());
        target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);
        this.getTargetServices().add(target);

        searchProcess();
        createUploadColumns();

        setSelectableResult(new ReportListDataModel(this.getReportResult().get(targetDef.getName()), this.colPkName(this.getMaintConfig()), config.getModification().getColumns()));
    }

    /**
     * 一覧検索画面で指定されたパラメータをもとに、外部サービスから
     * データ検索結果を取得する。(共通レポート用)
     * @param event
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
/* 共通メンテはアップロード以外を使用しないためコメント化
    public void executeSearchForReport(ActionEvent event) throws LogicException, SystemException {
        // 業務個別ロジック呼び出し
        callBusinessLogic(event);
        
        ReportSql targetDef = getConfig().getSqls().get(0);
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
        target.put(ExternalServiceExecuter.E_FUNCTION, targetDef.getFunctionCode());
        target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);

        Map<String, Object> sendParams = new HashMap<>();
        sendParams.put("TABLE_NAME", this.getSelectMaster());
        target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);
        this.getTargetServices().add(target);

        searchProcess();

        // ReportColumnの組み立て
        List<Map<String, Object>> reportMaps = this.getReportResult().get(targetDef.getName());
        if (reportMaps != null && !reportMaps.isEmpty()) {
            this.getMaintConfig().getModification().getColumns().clear();
            int i = 1;
            for (String key : reportMaps.get(0).keySet()) {
                ReportColumn column = new ReportColumn();
                column.setName(key);
                column.setDisplayName(key);
                column.setTableName(this.getSelectMaster());
                column.setControlType("LABEL");
                column.setReadonly(true);
                column.setSortIndex(i++);
                column.setVisible(true);

                this.getMaintConfig().getModification().getColumns().add(column);
            }
        }

        FontFactory.defaultEncoding = "UniJIS-UCS2-H";

        setSelectableResult(new ReportListDataModel(this.getReportResult().get(targetDef.getName()), this.colPkName(this.getMaintConfig())));
    }
*/

    /**
     * 検索実行用にonServiceを呼ぶメソッド
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */    
    private void searchProcess() throws LogicException, SystemException {

        ExternalServiceExecuter exec = new ExternalServiceExecuter();
        try {
            exec.onService(this);
        } catch (LogicException | SystemException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        }
    }
  
    /**
     * 入力された検索条件を全てクリア
     */
    public void clear() {
		if (new BreadCrumbBean().checkBUpdateFlg()){ //callbackで判定戻し（編集中）
            return;
        }
        this.targetClear(this.getConfig());
    }
    
    /**
     * 入力された検索条件を全てクリア(config指定,共通メンテナンスで使用)
     * @param tconfig
     */
    public void targetClear(ReportConfig tconfig) {
        PageViewDefault pageViewDefault = new PageViewDefault();
        pageViewDefault.setReportCondition(values ,  config, getDefConds());
    }
	
    /**
     * 個別画面対応: conditionでない項目のクリア処理
     * @param applyTo 
     */
    public void modificationClear(String applyTo) {
        ReportConfig tconfig = this.getConfig();
        for (ReportColumn column: tconfig.getModification().getColumns()) {
            if (applyTo.equals(column.getApplyTo())){
                getValues().get(applyTo).replace(column.getName(), column.getDefaultValue());
                column.setLabelValue("");
            }
        }
    }
  
    /**
     * 登録、更新などのデータベース更新用のボタン押下時イベント
     * @param event
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException
     */
    public void executeEventForMaint(ActionEvent event) throws LogicException, SystemException {

        // 業務個別ロジック呼び出し
        callBusinessLogic(event);   
        
        //画面のattributeの情報をtargetDefに設定
        ReportSql targetDef = new ReportSql();
        ReportButton rb = (ReportButton)event.getComponent().getAttributes().get("btn"); 
        targetDef.setFunctionCode(rb.getFunctionCode());
        targetDef.setService(rb.getService());
        targetDef.setEditModeName(ReportConst.EditMode.LIST_EDIT_UPDATE);
        targetDef.setEditActivityName(ReportConst.Act.EXECUTE);
        targetDef.setConfig(getMaintConfig());
        
        List<Map<String, Object>> resultlist = callSql(targetDef, null);
        setSelectableResult(new ReportListDataModel(resultlist, this.colPkName(), config.getModification().getColumns()));
        if (0 == resultlist.size()){
            return;
        }

        try {
            ExternalServiceParameterCheck paramCheck = new ExternalServiceParameterCheck();
            paramCheck.onService(this);

            Map<String, Object> sendParams = new HashMap<>();
            sendParams.put("TABLE_NAME", this.getSelectMaster());
            sendParams.put(this.getSelectMaster(), getSelectableResult().getDatasource());
 //           target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);

            ExternalServiceExecuter exec = new ExternalServiceExecuter();
            exec.onService(this);
        } catch (LogicException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        } catch (SystemException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        }

        // TODO 現ページをパンくず情報をもとに取り直す
//        selectableResult = new ReportListDataModel(this.reportResult.get(targetDef.getName()), this.colPkName());
        
    }
    /**
     * メンテナンス画面のボタン押下時イベント(CHKLIST_UPDATE)
     * @param action
     * @param service
     * @param functionCode
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException
     */
    public void executeChkListEventForMaint(String action, String service, String functionCode) throws LogicException, SystemException {
        
        // 業務個別ロジック呼び出し
        //callBusinessLogic(event);   
        
        // 一覧検索画面は、1つ目のSql定義使用を強制する
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, service);
        target.put(ExternalServiceExecuter.E_FUNCTION, functionCode);
//        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.LIST_UPDATE);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);
        target.put(ExternalServiceExecuter.E_TARGET_CONFIG, getMaintConfig());
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.LIST_UPDATE);
        this.getTargetServices().add(target);

        try {
            ExternalServiceParameterCheck paramCheck = new ExternalServiceParameterCheck();
            paramCheck.onService(this);

            Map<String, Object> sendParams = new HashMap<>();
            sendParams.put("TABLE_NAME", this.getSelectMaster());
            sendParams.put(this.getSelectMaster(), this.getSelectReportResult());
            target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);

            ExternalServiceExecuter exec = new ExternalServiceExecuter();
            exec.onService(this);
        } catch (LogicException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        } catch (SystemException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        }
        
        // TODO 現ページをパンくず情報をもとに取り直す
//        selectableResult = new ReportListDataModel(this.reportResult.get(SSNaviManagedBean.class.getName()), this.colPkName());
        setSelectReportResult(new ArrayList<>());
                }
            
    /**
     * 共通アップロード画面のボタン押下時イベント(CHKLIST_UPDATE)
     * @param action
     * @param service
     * @param functionCode
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException
     */
    public void executeChkListEventForUpload(String action, String service, String functionCode) throws LogicException, SystemException {
        
        if (getSelectReportResult() == null || getSelectReportResult().isEmpty()) {
			new MsgExec().message("ERROR", "エラー", "アップロードデータが選択されていません。");
            return;
        }
        // 一覧検索画面は、1つ目のSql定義使用を強制する
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, service);
        target.put(ExternalServiceExecuter.E_FUNCTION, functionCode);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);
        target.put(ExternalServiceExecuter.E_TARGET_CONFIG, getMaintConfig());
        if ("SS_COM_MAINT_DELETE".equals(functionCode)) {
            target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.DETAIL_DELETE);
        } else {
            target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.LIST_UPDATE);
        }
        this.getTargetServices().add(target);

        try {
            ExternalServiceParameterCheck paramCheck = new ExternalServiceParameterCheck();
            paramCheck.onService(this);

            Map<String, Object> sendParams = new HashMap<>();
            sendParams.put("TABLE_NAME", this.getSelectMaster()); // ここで、MS_UPLOAD_FILE_TEIGIのUPLOAD_KINO_CDが入ってきている
            sendParams.put(this.getSelectMaster(), this.getSelectReportResult());
            target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);

            ExternalServiceExecuter exec = new ExternalServiceExecuter();
            exec.onService(this);
        } catch (LogicException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        } catch (SystemException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        }
        if (functionCode.equals("SS_COM_UPLOAD_SAVE")){
			new MsgExec().message("INFO", "登録完了", "登録処理が完了しました");
        } else if(functionCode.equals("SS_COM_UPLOAD_VALIDATE")) {
			new MsgExec().message("INFO", "バリデーションチェック完了", "バリデーションチェック処理が完了しました");
        }
        System.out.println("サービス側メッセージ　： " + this.getExternalAttribute().get("exec-res-msg-attribute-name"));
        
        // selectReportResultの初期化
        setSelectReportResult(new ArrayList<>());

        // 登録ボタン押下時は、登録結果メッセージ表示、件数/一覧の更新を行う⇒バリデーションチェック時も再検索実施
        if (functionCode.equals("SS_COM_UPLOAD_SAVE")){
            boolean isErr =false;
            // 登録処理成功時はアップロードファイルを登録済フォルダに移動
            if (!isErr) {
                try {
                    Path sourcePath = Paths.get(""); // 取得元
                    Path targetPath = Paths.get(""); // 完了ファイル格納先
                    Files.move(sourcePath, targetPath);
                } catch (IOException ex) {
                    Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            
            functionCode = "SS_COM_UPLOAD_FILE_PROC_EX";
            service = "JohmonWebServiceForMultipart";

            target = new HashMap<>();
            this.setTargetServices(new ArrayList<>());
            target.put(ExternalServiceExecuter.E_SERVICE_URL, service);
            target.put(ExternalServiceExecuter.E_FUNCTION, functionCode);
            target.put(ExternalServiceExecuter.E_SERVICE_NAME, this.getConfig().getSqls().get(0).getName());
            target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.LIST_UPDATE);
            target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);
            Map<String, Object> params = new HashMap<>();
            params.put("wayOfUpload", this.getWayOfUpload());
            params.put("selectMaster", this.getSelectMaster());
            params.put("fileName", this.getUploadFileName());
            target.put(ExternalServiceExecuter.P_SEND_PARAMETER, params);
            this.getTargetServices().add(target);

            try {
                ExternalServiceExecuterForMultipart exec = new ExternalServiceExecuterForMultipart();
                exec.onService(this);
            } catch (LogicException ex) {
                Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
                throw ex;
            } catch (SystemException ex) {
                Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
                throw ex;
            }
            // 取得したLISTの最後を別変数に格納し、LISTの該当箇所を削除する。(件数表示領域更新)
            setUploadStatuses(this.getReportResult().get(this.getConfig().getSqls().get(0).getName()).get(this.getReportResult().get(this.getConfig().getSqls().get(0).getName()).size() - 1));
            this.getReportResult().get(this.getConfig().getSqls().get(0).getName()).remove(this.getReportResult().get(this.getConfig().getSqls().get(0).getName()).size() - 1);
            createUploadColumns();

            List<Map<String, Object>> selectedRowParam;
            selectedRowParam = this.getReportResult().get(this.getConfig().getSqls().get(0).getName());

            Iterator<Map<String, Object>> ite = selectedRowParam.iterator();
            while(ite.hasNext()){
                Map<String, Object> i = ite.next();
                if (!i.get("TOROKU_STATUS").equals("4") && !i.get("TOROKU_STATUS").equals("5")) {
                    getSelectReportResult().add(i);
                }
            }
            setIsChange("false");
            setSelectableResult(new ReportListDataModel(this.getReportResult().get(this.getConfig().getSqls().get(0).getName()), this.colPkName(this.getMaintConfig()) ,config.getModification().getColumns()));
        }
    }
    
    /**
     * 共通アップロード画面　ファンクションボタン活性/非活性変更
     */
    public void chkCellChange(String cngFlg){
        setIsChange(cngFlg);
        String compName = ":btn_" + this.getConfig().getFormId() + ":chklistvalidate_" + this.getConfig().getFormId();
        UIComponent component = FacesContext.getCurrentInstance().getViewRoot().findComponent(compName);
        if(component != null) {
            disableAll(component.getChildren(), true);
        }
    }
    
    /**
     * チェックイベント（ON）
     * @param event
     * @throws IllegalAccessException
     * @throws InvocationTargetException 
     */
    public void check(SelectEvent event) throws IllegalAccessException, InvocationTargetException {
        //System.out.print(event.getObject());
		new PageTableSelected().check(selectReportResult, config.getModification().getColumns());
    }
 
    /**
     * チェックイベント（OFF）
     * @param event 
     */
    public void uncheck(UnselectEvent event) {
		new PageTableSelected().check(selectReportResult, config.getModification().getColumns());   
    }
    
    /**
     * 共通アップロード　行選択イベント拡張版
     * @param event
     */
    public void onRowSelectEx(SelectEvent event) {
        System.out.println("--- row select ---");
        System.out.print(event.getObject());
        getSelectReportResult().clear();
        getSelectReportResult().add((Map<String, Object>)event.getObject());

//        this.selectReportResult.add((Map)event.getObject());
        System.out.println("check: " + this.getSelectReportResult());
    }

    /**
     * modification内定義ボタンの押下時イベントなど(共通系）
     * @param act action
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    public void executeButton(String act) throws Exception {
	// 当メソッドは使用しなくなりましたので後で削除します。
	
        logger.debug("廃止：executeButton(String act) は削除予定のメソッドです");
	new MsgExec().message("INFO", "廃止済みコマンド", "executeButton(String act) は削除予定のメソッドため使用できません");

	/*
	if ("INSERT".equals(getExecButton().getAction())) {
            execInsert();
        }        
       
        if ( "SEARCH".equals(act) ) {
            getConfig().getSqls().get(0).setFunctionCode("SEARCH_SAVED");
//            executeSearch();
        }

        //　顧客集約設定マスタ用として追加
        if ("CHKLIST_UPDATE".equals(act)) {
            if (getSelectReportResult() == null || getSelectReportResult().isEmpty()) {
				new MsgExec().message("ERROR", "エラー", "削除対象行が選択されていません。");
                return;
            }
            this.executeChkListEventForMaint(act, "JohmonWebService", "SS_COM_MAINT_DELETE");
        }
        //　顧客集約設定マスタ用として追加
        if ("CHKLIST_UPDATE".equals(act)) {
            if (getSelectReportResult() == null || getSelectReportResult().isEmpty()) {
				new MsgExec().message("ERROR", "エラー", "削除対象行が選択されていません。");
                return;
            }
            this.executeChkListEventForMaint(act, "JohmonWebService", "SS_COM_MAINT_DELETE");
        }
        if ("SS_COMMON_UPLOAD".equals(act)) {
            String sCode = "SS_COMMON_UPLOAD";
            String xhtml = "/templates/common_d_upload.xhtml";
            String title = "共通アップロード";
            this.forward(sCode, xhtml, title);
            // 初期選択させたいマスタ名を選択
            if (getCondMaster() != null){
                for (ReportCondition condition : getConfig().getConditions()) {
                    // マスタ選択値の場合(マスタ選択領域があるもの用)
                    if (condition.getName().equals("_TARGET_MASTER")) {
                        setCondMaster(condition);
                        break;
                    }
                }
                // 動作確認のため、他画面からのパラメータとして、仮で代理店マスタ(reseller_master)としている
                //　selectMaster = "reseller_master";
            }
        }
	*/
    }

    /**
     * 画面遷移
     * @param sCode
     * @param xhtml
     * @param title
     * @throws Exception
     */
    public void forward(String sCode, String xhtml, String title) throws Exception {

        PagePropertiesBean oldPageParam = new PagePropertiesBean();
        BeanUtils.copyProperties(oldPageParam, this);

        parameterInitialization();

        setConfig(new ReportConfig());
        getConfig().setPageTemplate(xhtml);
        getConfig().setScreenCode(sCode);
        getConfig().setTitle(title);
        setCurXhtml(this.getConfig().getPageTemplate());

        getBreadCrumbBean().gotoBreadNext(this, oldPageParam);
        }
    
    protected void execInsert() throws LogicException, SystemException {
        // パンくず用プロパティ値コピー
        PagePropertiesBean oldPageParam = new PagePropertiesBean();
        try {
            BeanUtils.copyProperties(oldPageParam, this);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw new SystemException(ex);
        }

        // 項目初期化
        parameterInitialization();
        // 表示する画面のReportConfigを取得
        String screenCode = getExecButton().getRptDir() + "." + getExecButton().getRptFile();
//	ReportConfig tmpConfig = ssconfig.getConfigs().get(screenCode);
        ReportConfig tmpConfig = getSsconfig().getConfigs().get(getSsconfig().getScreenCodesMap().get(screenCode));
        logger.debug("ReportID:" + screenCode);
        if (tmpConfig == null) {
                throw new LogicException("Specified report-id was not found.[" + screenCode + "]");
        }

        // 初回展開時にデフォルト検索結果を表示するためのコード
//        if (!"true".equalsIgnoreCase(parameter.getParameter(P_SKIPOPTION))) {
            if (!tmpConfig.isReady() || tmpConfig.isReloadCondition()){
                //if config status is not ready, there needs to create option values
                synchronized(tmpConfig){
                    this.generateOptionByModification(tmpConfig, getAuthConf());
                    tmpConfig.setReady(true);
                }
            }
//	}

        this.setConfig(tmpConfig);
        // editMode設定（INSERT)
        setEditMode("INSERT");
        // 画面項目初期化
        for (ReportSql sql : getConfig().getSqls()) {
            this.getReportResult().put(sql.getName(), new ArrayList<>());
            this.getReportResult().get(sql.getName()).add(new HashMap<>());
            this.getValues().put(sql.getName(), new HashMap<>());
        }

        // 遷移先テンプレートXHTML決定
        setCurXhtml(this.getConfig().getPageTemplate());

        try {
            // パンくず構築
            getBreadCrumbBean().gotoBreadNext(this, oldPageParam);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw new SystemException(ex);
        }
    }

    /**
     * 一覧検索画面の行ボタン押下時の動作
     * @param transferRptDir reportDir
     * @param transferRptFile reportFile
     * @param dataType dataType
     * @throws LogicException logic
     * @throws SystemException  system
     */
    public void executeEditTrans(String transferRptDir, String transferRptFile, String dataType) throws LogicException, SystemException {
	// 当メソッドは使用しなくなりましたので後で削除します。
	// public void executeEditTrans(ActionEvent event) を使用してください
	
        logger.debug("廃止：executeEditTrans(String transferRptDir, String transferRptFile, String dataType)");
	logger.debug("　⇒　executeEditTrans(ActionEvent event) を使用してください");
	new MsgExec().message("INFO", "廃止済みコマンド", "代わりにexecuteEditTrans(ActionEvent event) を使用してください");
	
// パンくず用プロパティ値コピー
/*        PagePropertiesBean oldPageParam = new PagePropertiesBean();
        try {
            BeanUtils.copyProperties(oldPageParam, this);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw new SystemException(ex);
        }

        // 遷移先データ取得のためのキー項目組み立て(1件のみ実行) datatable用
        Map<String, Object> tmpValues = new HashMap<>();
        if (!selectReportResult.isEmpty()) {
            if (selectReportResult.size() >1){
				new MsgExec().message("ERROR", "エラー", "選択は一か所のみ行ってください。");
                return;
            }
            List<ReportColumn> pklist = this.getConfig().getModification().getPkList();
            for (ReportColumn rcol : pklist){
                tmpValues.put(rcol.getName(), selectReportResult.get(0).get(rcol.getName()));
            }
        }
        // 遷移先データ取得のためのキー項目組み立て(1件のみ実行) datatree用
        List<Map<String, Object>> selectdatas = selectableTreeResult.selectedmap(selectedNodes);
        if (selectdatas.size() != 0){
            List<ReportColumn> pklist = this.getConfig().getModification().getPkList();
            for (ReportColumn rcol : pklist){
                tmpValues.put(rcol.getName(), selectdatas.get(0).get(rcol.getName())); 
            }
        }

        // 表示する画面のReportConfigを取得		
        String screenCode = transferRptDir + "." + transferRptFile;
//		ReportConfig tmpConfig = ssconfig.getConfigs().get(screenCode);
        ReportConfig tmpConfig = getSsconfig().getConfigs().get(getSsconfig().getScreenCodesMap().get(screenCode));
        // 項目初期化
        parameterInitialization();

//		if (parameter.getExternalParameter().get("scrcode") != null) {
//			config.setCurrentScreenCode((String)parameter.getExternalParameter().get("scrcode"));
//		}
//		ReportConfig config = (ReportConfig) ReportContext.getInstance(pkey).getConfigs().get((String) parameter.getExternalParameter().get("scrcode"));
//		if (config == null) {
//			config = (ReportConfig) ReportContext.getInstance(pkey).getConfigs().get(repid);
//		}
        logger.debug("ReportID:" + screenCode);
        if (tmpConfig == null) {
            throw new LogicException("Specified report-id was not found.[" + screenCode + "]");
        }

        // 初回展開時にデフォルト検索結果を表示するためのコード
//        if (!"true".equalsIgnoreCase(parameter.getParameter(P_SKIPOPTION))) {
			if (!tmpConfig.isReady() || tmpConfig.isReloadCondition()){
            //if config status is not ready, there needs to create option values
				synchronized(tmpConfig){
                this.generateOptionByModification(tmpConfig, getAuthConf());
                tmpConfig.setReady(true);
            }
        }
//		}

        this.setConfig(tmpConfig);

        // editMode判定
        if ("EDIT".equals(dataType)) {
            setEditMode("UPDATE");
        } else if ("COPY".equals(dataType)) {
            setEditMode("INSERT");
        }

        // 遷移先テンプレートXHTML決定
//        menuBean.setCurXhtml(this.config.getPageTemplate());
        setCurXhtml(this.getConfig().getPageTemplate());

        // 遷移先データ表示のための検索
        this.setTargetServices(new ArrayList<>());
        getConfig().getSqls().forEach((targetDef) -> {
            Map<String, Object> target = new HashMap<>();
            target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
            target.put(ExternalServiceExecuter.E_FUNCTION, targetDef.getFunctionCode());
            target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
            target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
            target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);

            // 遷移元から受け取るパラメータの組み立て
            if (getValues().get(targetDef.getName()) == null) {
                getValues().put(targetDef.getName(), new HashMap<>());
            }
            tmpValues.keySet().forEach((key) -> {
                getValues().get(targetDef.getName()).put(key, tmpValues.get(key));
            });

            this.getTargetServices().add(target);
        });

        searchProcess();
        if (getReportResult() != null && !reportResult.isEmpty()) {
            for (String key : getReportResult().keySet()) {
                getSelectableResults().put(key, new ReportListDataModel(getReportResult().get(key), colPkName(key), config.getModification().getColumns()));
                getSelectEditReportResult().put(key, new ArrayList<>());
                // 検索結果をvaluesにセット
                if (getReportResult().get(key) != null && !reportResult.get(key).isEmpty()) {
                    getValues().put(key, getReportResult().get(key).get(0));

//                    Map<String, Object> resultmap = values.get(key);
//                    for (Iterator<String> itf = resultmap.keySet().iterator(); itf.hasNext();) {
//                        String mapKey = itf.next();
//                        AbstractReportCondition column = config.getModification().getColumnSoft(key, mapKey);
//                        if (column.getControlType().startsWith("AUTOCOMPLETE")) {
//                            for (AbstractReportOption opt : column.getOptions()) {
//                                
//                            }
//                        }
//                    }
                }
            }
            // 明細行用
            getConfig().getSqls().forEach((sql) -> {
                // 入力値受付パラメータに、検索結果をdeep copy
                getListValues().put(sql.getName(), new ArrayList<>(getReportResult().get(sql.getName())));
            });
        }

        try {
            // パンくず構築
            getBreadCrumbBean().gotoNext(this, oldPageParam);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw new SystemException(ex);
        }
	
	*/
    }

    public void executePopup(ActionEvent event) throws Exception {
        String name = (String)event.getComponent().getAttributes().get("function");
        String service = (String)event.getComponent().getAttributes().get("service");
        String lineNo = String.valueOf(((Integer)event.getComponent().getAttributes().get("lineNo"))+1);
        setSelectedLine((Map<String, Object>)event.getComponent().getAttributes().get("selectedLine"));

        this.setDialogParams(new ArrayList<>());
        // 遷移先データ取得のためのキー項目組み立て
        Map<String, Object> tmpValues = new HashMap<>();
        this.getMaintConfig().getModification().getPkList().forEach((pkKey) -> {
            tmpValues.put(pkKey.getName(), getSelectedLine().get(pkKey.getName()));
        });
        ReportSql targetDef = this.getConfig().getSqls().get(0);
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, service);
        target.put(ExternalServiceExecuter.E_FUNCTION, name);
        target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH_ONE);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);
        Map<String, Object> params = new HashMap<>();
        params.put("selectMaster", this.getSelectMaster());
        params.put("lineNo", lineNo);
        params.put("yomikomiId", getSelectableResult().getDatasource().get(0).get("YOMIKOMI_ID"));
        target.put(ExternalServiceExecuter.P_SEND_PARAMETER, params);

        this.getTargetServices().add(target);
        tmpValues.keySet().forEach((key) -> {
            getValues().get(targetDef.getName()).put(key, tmpValues.get(key));
        });

        try {
            searchProcess();
        } catch (LogicException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        } catch (SystemException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        }
        Map<String, String> rawData = new HashMap<>();
        rawData.put("ATTR_01", SSCommonUtil.ifnull(this.getExternalAttribute().get("gyoNaiyo"), "")); // 共通アップロードの元データ表示用()
        this.getDialogParams().add(rawData);
    }
    
    /**
     * 共通アップロード用ポップアップ画面表示
     */
    public void executePopupForUpContext(ActionEvent event) throws Exception {
        String name = (String) event.getComponent().getAttributes().get("function");
        String service = (String) event.getComponent().getAttributes().get("service");
        String lineNo = String.valueOf(((Integer) event.getComponent().getAttributes().get("lineNo")));
        setSelectedLine((Map<String, Object>) event.getComponent().getAttributes().get("selectedLine"));

        this.setDialogParams(new ArrayList<>());
        // 遷移先データ取得のためのキー項目組み立て
        Map<String, Object> tmpValues = new HashMap<>();
        this.getMaintConfig().getModification().getPkList().forEach((pkKey) -> {
            tmpValues.put(pkKey.getName(), getSelectedLine().get(pkKey.getName()));
        });
        ReportSql targetDef = this.getConfig().getSqls().get(0);
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, service);
        target.put(ExternalServiceExecuter.E_FUNCTION, name);
        target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH_ONE);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);
        Map<String, Object> params = new HashMap<>();
        params.put("selectMaster", this.getSelectMaster());
        params.put("lineNo", lineNo);
        target.put(ExternalServiceExecuter.P_SEND_PARAMETER, params);

        this.getTargetServices().add(target);
        tmpValues.keySet().forEach((key) -> {
            getValues().get(targetDef.getName()).put(key, tmpValues.get(key));
        });

        try {
            searchProcess();
        } catch (LogicException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        } catch (SystemException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        }
        Map<String, String> rawData = new HashMap<>();
        rawData.put("ATTR_01", SSCommonUtil.ifnull(this.getExternalAttribute().get("gyoNaiyo"), ""));
        this.getDialogParams().add(rawData);
    }

    /**
     * 参照モード切替用
     * @param editFlg
     */
    public void chgMode(boolean editFlg){
        if(editFlg) {
            getConfig().setEditFlg(false);
        }else{
            getConfig().setEditFlg(true);
        }
    }
    
    /**
     * 行追加を行うイベント（行追加ボタン）
     * @param ptn
     * @throws IllegalAccessException
     * @throws InvocationTargetException 
     */
    public void addRowMaint(String ptn) throws IllegalAccessException, InvocationTargetException {
        
        if ( "cmn".equals(ptn) ) {
            this.resetList();
        }
        
        ReportSql targetDef = getConfig().getSqls().get(0);
        
        Map<String, Object> orgrow = this.getReportResult().get(targetDef.getName()).get(0);
        Map<String, Object> addrow = new HashMap<>();
        for (Iterator<String> ite = orgrow.keySet().iterator(); ite.hasNext();) {
            addrow.put(ite.next(), "");
        }
        addrow.put("newrow", true);
        this.getReportResult().get(targetDef.getName()).add(addrow);
//        selectableResult = new ReportListDataModel(this.reportResult.get(targetDef.getName()), this.colPkName());
    }

    /**
     * コンテキストメニューから行追加を行うイベント
     * @param ptn
     * @throws IllegalAccessException
     * @throws InvocationTargetException 
     */
    public void addRowMaintForCon(String ptn) throws IllegalAccessException, InvocationTargetException {
        
        if ( "cmn".equals(ptn) ) {
            this.resetList();
        }
        ReportSql targetDef = getConfig().getSqls().get(0);
        Map<String, Object> orgrow = this.getReportResult().get(targetDef.getName()).get(0);
        Map<String, Object> addrow = new HashMap<>();        
        for (Iterator<String> ite = orgrow.keySet().iterator(); ite.hasNext();) {
            addrow.put(ite.next(), "");
        }        
            addrow.put( "newrow", true );
        for ( Iterator ite = this.getSelectReportResult().iterator(); ite.hasNext(); ) {
            Object obj = ite.next();
            int pos = this.getReportResult().get( targetDef.getName() ).indexOf( obj );
            this.getReportResult().get( targetDef.getName() ).add( pos, addrow );
        }
//        selectableResult = new ReportListDataModel( this.reportResult.get( targetDef.getName() ), this.colPkName() );
//        selectReportResult = new ArrayList<>();
    }

    /**
     * 共通画面で行複製を行うイベント
     * @param ptn
     * @throws IllegalAccessException
     * @throws InvocationTargetException 
     */
    public void copyRowMaint(String ptn) throws IllegalAccessException, InvocationTargetException {
        
        if ( "cmn".equals(ptn) ) {
            this.resetList();
        }
        ReportSql targetDef = getConfig().getSqls().get(0);
        Map<String, Object> addrow;
        for ( Iterator ite = this.getSelectReportResult().iterator(); ite.hasNext(); ) {
            addrow = new HashMap<>();
            Object obj = ite.next();
            addrow.putAll( (Map)obj );
            addrow.put( "newrow", true );
            int pos = this.getReportResult().get( targetDef.getName() ).indexOf( obj );
            this.getReportResult().get( targetDef.getName() ).add( pos, addrow );
        }
//        selectableResult = new ReportListDataModel( this.reportResult.get( targetDef.getName() ), this.colPkName() );
//        selectReportResult = new ArrayList<>();
    }

    /**
     * 履歴画面「close」処理
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     */
    public void resetList() throws IllegalAccessException, InvocationTargetException {
        // 履歴表示時に取得した元画面情報を戻す
        
        boolean chkFlg = false;
        
        if ( getOldSelectableResult() != null ) {
            setSelectableResult(new ReportListDataModel(null, null, null));
            BeanUtils.copyProperties(getSelectableResult(), getOldSelectableResult());    
            chkFlg = true;
        }

        if ( getOldReportResult().size() > 0 ) {
            setReportResult(new HashMap<>());
            for ( String key : getOldReportResult().keySet() ){
                getReportResult().put(key, getOldReportResult().get(key) );
            }
            chkFlg = true;            
        }
        
        if ( getOldSelectReportResult().size() > 0 ) {
            setSelectReportResult(new ArrayList<>());
            for ( Map map : getOldSelectReportResult() ) {
                getSelectReportResult().add( map );
            }
            chkFlg = true;            
        }
        
        if ( getOldValues().size() > 0 ) {
            setValues(new HashMap<>());
            for ( String key : getOldValues().keySet() ) {
                getValues().put(key, getOldValues().get(key));
            }
            chkFlg = true;            
        }

        if ( getOldObjectValues().size() > 0 ) {
            setObjectValues(new ArrayList<>());
            for (int i=0; i<oldObjectValues.size(); i++) {
                    objectValues.add(oldObjectValues.get(i));
            }            
        }
        if ( chkFlg ) {
            createcolumn (this.getReportResult().get(getConfig().getSqls().get(0).getName() ) , "");
        }
    }
   
    // ReportColumnの組み立て
    public void createcolumn( List<Map<String, Object>> reportMaps, String type ) {
         ReportSql targetDef = new ReportSql(); 
        if (getConfig().getSqls().size() > 2 ){
            targetDef = getConfig().getSqls().get(1);
         }
         
        if (reportMaps != null && !reportMaps.isEmpty()) {
            this.getConfig().getModification().getColumns().clear();
            int i = 1;
            for (String key : reportMaps.get(0).keySet()) {
                ReportColumn column = new ReportColumn();
                column.setName(key);
                column.setDisplayName(key);
                
                if( !this.selectMaster.isEmpty() ) {
                    column.setTableName(this.getSelectMaster());
                } else {
                    column.setTableName( targetDef.getTableName() );
                }                
                column.setControlType("LABEL");
                column.setReadonly(true);
                column.setSortIndex(i++);
                column.setVisible(true);

                this.getConfig().getModification().getColumns().add(column);
            }
        }
    }

    /**
     * メンテナンスBのDatatableで行選択をした時の動作
     * @param event
     * @throws LogicException
     * @throws SystemException 
     * @throws java.lang.reflect.InvocationTargetException 
     * @throws java.lang.IllegalAccessException 
     */
    public void onRowSelect(SelectEvent event) 
            throws LogicException, SystemException, InvocationTargetException, IllegalAccessException {
        Map<String, Object> row = ((Map<String, Object>) event.getObject());
        setSelectedLine(row);
        
        this.check(event);
    }
    /**
     * メンテナンスBのDatatableで行選択を解除した時の動作
     * @param event 
     */
/* 共通メンテはアップロード以外を使用しないためコメント化
    public void unRowSelect(UnselectEvent event) {
        setSelectedLine(new HashMap<String, Object>());
    
        this.uncheck(event);
    }
 */

/* 共通メンテはアップロード以外を使用しないためコメント化    
    public void onModifyPopClose() {
        String rowKeyData = (String)this.getSelectedLine().get(this.colPkName(this.getMaintConfig()));
        Map<String, Object> target = this.getSelectableResult().getRowData(rowKeyData);
        target.keySet().forEach((key) -> {
            if (getSelectedLine().get(key) != null) {
                target.put(key, getSelectedLine().get(key));
            }
        });
    }
 */
    
    /**
     * 共通系画面でマスタ選択された時に動作するハンドラー
     * @param event
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException
     **/
    public void handleMasterChange(SelectEvent event) throws LogicException, SystemException, IllegalAccessException, InvocationTargetException {
        // カラムレイアウトの初期化
        if ( this.getMaintConfig() != null ) {
             setMaintConfig(new ReportConfig());
             setOldMaintConfig(new ReportConfig());
             getConfig().getModification().getListColumnLayout().clear();
             getConfig().getModification().getColumns().clear();
             setOldConfig(new ReportConfig());
             setSelectableResults(new HashMap<>());
             setReportResult(new HashMap<>());
             setSelectableResult(null);
        }
                
        String reportType = (String)event.getComponent().getAttributes().get("report_type");
        String selectedValue = (String)event.getObject();

        if (selectedValue == null || selectedValue.isEmpty()) {
            // 値が無ければ終了
            setSelectMaster("");
            setMaintConfig(null);
            setUploadStatuses(null);
            return;
        }
        // 外部サービスから取得する。
        OptionsFinder process = new OptionsFinder();
        process.setAuthConf(getAuthConf());
        List<Map<String, Object>> columnResult = null;
        try {
            AbstractReportOption option = new ReportConditionOption();
            option.setFunctionCode("SS_COM_MAINT_SETTING");
            option.setService(this.getConfig().getSqls().get(0).getService());
            option.setServiceParameter("COM_MAINT_COLUMN," + selectedValue);
            process.onService(option);
            columnResult = process.getSearchResult();
            if (columnResult == null || columnResult.isEmpty()) {
                logger.info(option.getValue() + " function-code:" + option.getFunctionCode() + " is NoResult..");
                return;
            }
        } catch (LogicException | SystemException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            return;
        }

        // 入力値クリア
//        values = new HashMap<>();
        
        // configをdeep copy
        //this.setMaintConfig((ReportConfig) SerializationUtils.clone(getConfig()));
        this.setMaintConfig(CloneCls.deepcopy(getConfig()));
        this.getMaintConfig().getModification().getColumns().clear();
        // 定義されているcolumn(checkbox,button等)をコピー
        this.getConfig().getModification().getColumns().forEach((column) -> {
            this.getMaintConfig().getModification().getColumns().add(column);
        });

        // 検索条件の並び順
        Collections.sort(columnResult, new Comparator<Map<String, Object>>(){
            @Override
            public int compare(Map<String, Object> rec1, Map<String, Object> rec2) {
                String colName1 = (String)rec1.get("schSortIndex");
                String colName2 = (String)rec2.get("schSortIndex");
                return colName1.compareTo(colName2);
            }    
        });        
        
        // 検索条件、一覧組み立て
        for (int i = 0; i < columnResult.size(); i++) {
            Map<String, Object> one = columnResult.get(i);
            String columnName = String.valueOf(one.get("columnName"));
            String subColumn = String.valueOf(one.get("subColumn"));
            String columnDescription = String.valueOf(one.get("columnDescription"));
            String controlInd = String.valueOf(one.get("controlInd"));
            String searchColumnInd = String.valueOf(one.get("searchColumnInd"));
            String searchColType = null;
            String searchDataType = null;
            if (one.get("searchComponent") != null) {
                String[] component = String.valueOf(one.get("searchComponent")).split("::");
                searchColType = component[0];
                searchDataType = component.length > 1 ? component[1] : "";
            }
            String pk = String.valueOf(one.get("pk"));

            if ("1".equals(searchColumnInd) || ( ("0").equals(searchColumnInd) && !searchColType.isEmpty() )) {
                // 検索条件作成
                this.getMaintConfig().getConditions().add( createCondition( one, searchColumnInd ) );
            }
            if (!StringUtils.isEmpty(controlInd) && !"report".equals(reportType)) {
                // 共通メンテナス画面の場合、ここでカラムを組み立てる
                ReportColumn column = new ReportColumn();
                column.setApplyTo(this.getConfig().getSqls().get(0).getName());
                column.setName(columnName);
                column.setDisplayName(columnDescription);
                column.setTableName(this.getSelectMaster());
                if ("2".equals(controlInd)) {
                    if ( ReportConst.ControlType.SELECT.equals(searchColType) ) {
                        column.setControlType(ReportConst.ControlType.SELECT);
                        
                    } else if ( ReportConst.ControlType.DOUBLECOMBO_IN.equals(searchColType) 
                            || ReportConst.ControlType.DOUBLECOMBO_OUT.equals(searchColType) ){    
                        column.setControlType(searchColType);
                        
                    } else if ( ReportConst.ControlType.AUTOCOMPLETE.equals(searchColType)
                            || ReportConst.ControlType.AUTOCOMPLETE_DYNAMIC.equals(searchColType)
                            || ReportConst.ControlType.AUTOCOMPLETE_MULTI.equals(searchColType) ) {
                        column.setControlType(searchColType);
                        column.setExtra1(subColumn);
                        
                    } else {
                        column.setControlType(ReportConst.ControlType.TEXT);                        
                    }
                    column.setReadonly(false);
                } else if ("1".equals(controlInd)) {
                    // controlInd = 1(表示のみ)
                    column.setControlType(ReportConst.ControlType.LABEL);
                    column.setReadonly(true);
                } else {
                    column.setControlType(ReportConst.ControlType.HIDDEN);
                }
                column.setSortIndex(i + 2);
                column.setVisible(true);
                // 入力項目を縦並べ
                if ("1".equals(pk)) column.setPk(true);

                this.getMaintConfig().getModification().getColumns().add(column);
            }
        }
        // 検索条件のOption項目を取得する
        synchronized(this.getMaintConfig()){
            this.generateOption(this.getMaintConfig(), getAuthConf());
            this.getMaintConfig().setReady(true);
            createSortList();
        }

        for (ReportCondition cond : getMaintConfig().getConditions()) {
            getDefConds().put(cond.getName(), cond.getDefaultValue());
        }        
    }

    /**
     * 検索条件作成
     * @param one
     * @return 
     */
    private ReportCondition createCondition( Map<String, Object> one, String searchColumnInd) {

        String columnName = String.valueOf(one.get("columnName"));
        String columnDescription = String.valueOf(one.get("columnDescription"));
        String searchColType = null;
        String searchDataType = null;
        if (one.get("searchComponent") != null) {
            String[] component = String.valueOf(one.get("searchComponent")).split("::");
            searchColType = component[0];
            searchDataType = component.length > 1 ? component[1] : "";
        }
        String searchOptFuncName = SSCommonUtil.ifnull(one.get("searchOptFuncName"), "");
        String searchOptParam = SSCommonUtil.ifnull(one.get("searchOptParam"), "");
        String defaultValue = String.valueOf(one.get("defaultValue"));
        
        ReportCondition condition = new ReportCondition();
        condition.setDisplayName(columnDescription);
        condition.setName(columnName);
        condition.setControlType(searchColType);
        condition.setDataType(searchDataType);
        condition.setSection(String.valueOf(one.get("section")).equals("0")?"main":"sub");
        condition.setApplyTo(this.getConfig().getSqls().get(0).getName());

        // TODO 
        // 検索条件の表示制御(営業所権限：1／本社権限：1,2）
        if( "SYSTEM_ADMIN".equals(getAuthConf().getUserGroup().get(0) )) {
            if ( searchColumnInd.equals("0") ) {
                condition.setVisible(false);
            } else {
                condition.setVisible(true);
            }
        } else {
            if (searchColumnInd.equals("1")) {
                condition.setVisible(true);
            } else {
                condition.setVisible(false);
            }
        }
        condition.setDefaultValue(selDefaultVal(defaultValue));
        if (!searchOptFuncName.isEmpty()) {
            AbstractReportOption spaceOpt = new ReportConditionOption();
            spaceOpt.setValue("");
            spaceOpt.setLabel("");
            condition.getOptions().add(spaceOpt);
            condition.getOriginalOptions().add(spaceOpt);
            AbstractReportOption option = new ReportConditionOption();
            option.setService(this.getConfig().getSqls().get(0).getService());
            option.setFunctionCode(searchOptFuncName);
            option.setServiceParameter(searchOptParam);
            condition.getOptions().add(option);
            condition.getOriginalOptions().add(option);
        }
        return condition;
    }

    /**
     * デフォルト値の設定
     */
    private String selDefaultVal(String defaultVal) {
        
        String val = "";
        if (defaultVal.equals("userGroup")) {
            val = getAuthConf().getUserGroup().get(0);
        } else {
            val = defaultVal;
        }
        return val;
    }
    
    /**
     * selectBox連携
     * @param event
     * @throws LogicException
     * @throws SystemException
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     */
/* TargetDynamicを使用しなくなったのでコメント化
    public void changeItemSearch( SelectEvent event ) throws LogicException, SystemException, IllegalAccessException, InvocationTargetException {
        
        String subColumn = "";
        String tableName = "";
        
        for ( ReportCondition con : getConfig().getConditions() ) {
            if (StringUtils.isNotEmpty(con.getTargetDynamic()) ) {
                subColumn = con.getTargetDynamic();
                tableName = con.getTableName();                
                break;
            }
        }
            
        for ( ReportCondition cond : getConfig().getConditions() ) {
            if (StringUtils.isNotEmpty(subColumn)
                    && StringUtils.equals(subColumn, cond.getName() )) {
                ReportSql targetDef = getConfig().getSqls().get(0);
                Map<String, Object> target = new HashMap<>();
                this.setTargetServices(new ArrayList<>());
                target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
                target.put(ExternalServiceExecuter.E_FUNCTION, cond.getOriginalOptions().get(1).getFunctionCode() );
                target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
                target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
                target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);
                Map<String, Object> sendParams = new HashMap<>();
                sendParams.put("TABLE_NAME", tableName);
                if (StringUtils.isNotEmpty((String)event.getObject())) {
                    sendParams.put("pCode",event.getObject());
                }
                
                target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);
                this.getTargetServices().add(target);
                searchProcess();

                List<AbstractReportOption> list = new ArrayList();
                int i = 0;
                for (Map op : this.getReportResult().get(targetDef.getName()) ) {
                    AbstractReportOption option = new ReportConditionOption();
                    if ( i==0 ) {
                        option.setValue("");
                        option.setLabel("");
                        list.add(option);
                        option = new ReportConditionOption();
                    }                    
                    
                    option.setValue( (String)op.get("VALUE") );
                    option.setLabel( (String)op.get("LABEL") );
                    list.add(option);
                    i++;
                }
                cond.setOptions(list);
            }
        }
    }
*/
/* SelectBoxの値をAjaxで取得しなくなったため未使用になった
   public void changeItemList( SelectEvent event ) throws LogicException, SystemException, IllegalAccessException, InvocationTargetException, InvocationTargetException {
        
        String subColumn = "";
        String tableName = "";
//        String pkName = columnLists.getReportColPk();
        
        for ( ReportColumn col : getConfig().getModification().getColumns() ) {
            if (StringUtils.isNotEmpty(col.getTargetDynamic()) ) {
                subColumn = col.getTargetDynamic();
                tableName = col.getTableName();                
                break;
            }
        }

        for ( ReportColumn col : getConfig().getModification().getColumns() ) {
            if (StringUtils.isNotEmpty(subColumn)
                    && StringUtils.equals(subColumn, col.getName() )) {
                
                ReportSql targetDef = getConfig().getSqls().get(0);
                Map<String, Object> target = new HashMap<>();
                this.setTargetServices(new ArrayList<>());
                target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
                target.put(ExternalServiceExecuter.E_FUNCTION, col.getOriginalOptions().get(1).getFunctionCode() );
                target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
                target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
                target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);
                Map<String, Object> sendParams = new HashMap<>();
                sendParams.put("TABLE_NAME", tableName);
                if (StringUtils.isNotEmpty((String)event.getObject())) {
                    sendParams.put("pCode",event.getObject());
                }
                
                target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);
                this.getTargetServices().add(target);
                searchProcess();

                List<AbstractReportOption> list = new ArrayList();
                int i = 0;
                for (Map op : this.getReportResult().get(targetDef.getName()) ) {
                    AbstractReportOption option = new ReportConditionOption();
                    if ( i==0 ) {
                        option.setValue("");
                        option.setLabel("");
                        list.add(option);
                        option = new ReportConditionOption();
                    }                    
                    
                    option.setValue( (String)op.get("VALUE") );
                    option.setLabel( (String)op.get("LABEL") );
                    list.add(option);
                    i++;
                }
                col.setOptions(list);
//                JSONObject json = new JSONObject();
//                json.put("list", list);                
//                RequestContext context = RequestContext.getCurrentInstance();  
//                context.addCallbackParam("itemList", json);
//                context.addCallbackParam("targetColumn", subColumn);
            }
        }
    }    
*/
    
    /**
     * 共通アップロード画面でマスタ選択された時に動作するハンドラー
     *
     * @param event
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException
     */
    public void handleMasterChangeForComUpload(SelectEvent event) throws LogicException, SystemException {
        String selectedValue = (String) event.getObject();

        if (selectedValue == null || selectedValue.isEmpty()) {
            // 値が無ければ終了
            setSelectMaster("");
            setMaintConfig(null);
            setUploadStatuses(null);
            setSelectableResult(null);
            setUploadFileDef(null);
            return;
        }
        if (!selectedValue.equals(oldSelectMaster)) {
            setMaintConfig(null);
            setUploadStatuses(null);
            setSelectableResult(null);
        }
        setOldSelectMaster(selectedValue);
        // 外部サービスから取得する。(選択されたデータファイルのアップロードファイル定義を取得)
        OptionsFinder process = new OptionsFinder();
        process.setAuthConf(getAuthConf());
        List<Map<String, Object>> upFileDefResult = null;
        try {
            AbstractReportOption option = new ReportConditionOption();
            option.setFunctionCode("SS_COM_UPLOAD_SEARCH");
            option.setService(this.getConfig().getSqls().get(0).getService());
            option.setServiceParameter("COM_UPLOAD_DEF," + selectedValue);
            process.onService(option);
            upFileDefResult = process.getSearchResult();
            if (upFileDefResult == null || upFileDefResult.isEmpty()) {
                logger.info(option.getValue() + " function-code:" + option.getFunctionCode() + " is NoResult..");
                return;
            }
        } catch (LogicException | SystemException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            return;
        }
        setUploadFileDef(upFileDefResult);
    }
    
    /**
     * 共通アップロード画面用　一覧内値変更検知
     * @param event
     */
    public void doValueChange(ValueChangeEvent event){
        System.out.println(event.getOldValue() + "⇒" + event.getNewValue());
        UIData data = (UIData) event.getComponent().findComponent(":List" + this.getConfig().getFormId() + ":tablesorter_" + this.getConfig().getFormId());
        DataTable dataTable = (DataTable) FacesContext.getCurrentInstance().getViewRoot().findComponent(":List" + this.getConfig().getFormId() + ":tablesorter_" + this.getConfig().getFormId());
        List<org.primefaces.component.api.UIColumn> column = dataTable.getColumns();
//        for (org.primefaces.component.api.UIColumn uiColumn : column) {
//            System.out.println(uiColumn.getHeaderText());  
//        } 
//        System.out.println("header :" + headerName);
//        int rowIndex = data.getRowIndex();
        setIsChange("true");
    }
        
    /**
     * 検索条件にソート順のリストを表示する
     * @throws LogicException
     * @throws SystemException
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     */
    private void createSortList() throws LogicException, SystemException, IllegalAccessException, InvocationTargetException {
              
        ReportSql targetDef = getConfig().getSqls().get(0);
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
        target.put(ExternalServiceExecuter.E_FUNCTION, "SS_SORT_ORDER_LIST");
        target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);

        Map<String, Object> sendParams = new HashMap<>();
        sendParams.put("TABLE_NAME", this.getSelectMaster());
        sendParams.put("FUNCTION_CODE", targetDef.getFunctionCode());
        target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);
        
        this.getTargetServices().add(target);
        
        searchProcess();
        
        setSortVal(this.getReportResult().get(targetDef.getName()));  
    }

    /**
     * 履歴表示用のサイドバーのイベント
     * @param event
     */
    public void executeSidebar(ActionEvent event) {
        String name = (String)event.getComponent().getAttributes().get("name");
        String service = (String)event.getComponent().getAttributes().get("service");

        // 現在サイドバーが開いている場合は、editModeを元に戻して処理を終了する
        if ("SIDEBAR_UP".equals(getEditMode()) || "SIDEBAR_CLOSE".equals(getEditMode())) {
            setEditMode(getEditModeTemp());
            return;
        } else {
            setEditModeTemp(getEditMode());
            setEditMode("SIDEBAR_UP");
        }

        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, service);
        target.put(ExternalServiceExecuter.E_FUNCTION, name);
        target.put(ExternalServiceExecuter.E_SERVICE_NAME, this.getConfig().getSqls().get(0).getName());
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH_SIDEBAR);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);
        this.getTargetServices().add(target);

        try {
            searchProcess();
        } catch (LogicException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
//            throw ex;
        } catch (SystemException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
//            throw ex;
        }
        getSelectableResults().put("sidebar", new ReportListDataModel(this.getReportSidebarResult().get(target.get(ExternalServiceExecuter.E_SERVICE_NAME)), this.colPkNameForSidebar("sidebar"),config.getModification().getColumns()));

    }
    
    /**
     * 履歴表示用のサイドバーで行選択イベント
     * @param event
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException
     */    
    public void onSidebarRowSelect(SelectEvent event) throws LogicException, SystemException {
        Map<String, Object> row = ((Map<String, Object>) event.getObject());
        Map<String, Object> tmpValues = new HashMap<>();
        ReportColumn pkcol = null;
        for (ReportColumn pkKey : this.getConfig().getModification().getPkListForSidebar()) {
            tmpValues.put(pkKey.getName(), row.get(pkKey.getName()));
            if (pkcol == null) pkcol = pkKey;
            }
        // データ表示のための検索
        this.setTargetServices(new ArrayList<>());
        getConfig().getSqls().forEach((targetDef) -> {
            Map<String, Object> target = new HashMap<>();
            target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
            target.put(ExternalServiceExecuter.E_FUNCTION, targetDef.getFunctionCode());
            target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
            target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
            target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);

            // パラメータの組み立て
            getValues().put(targetDef.getName(), new HashMap<>());
            tmpValues.keySet().forEach((key) -> {
                getValues().get(targetDef.getName()).put(key, tmpValues.get(key));
            });

            this.getTargetServices().add(target);
        });

        searchProcess();
        if (getReportResult() != null && !reportResult.isEmpty()) {
            for (String key : getReportResult().keySet()) {
                getSelectableResults().put(key, new ReportListDataModel(getReportResult().get(key), colPkName(key), config.getModification().getColumns()));
                getSelectEditReportResult().put(key, new ArrayList<>());
                // 検索結果をvaluesにセット
                if (getReportResult().get(key) != null && !reportResult.get(key).isEmpty()) {
                    getValues().put(key, getReportResult().get(key).get(0));

//                    Map<String, Object> resultmap = values.get(key);
//                    for (Iterator<String> itf = resultmap.keySet().iterator(); itf.hasNext();) {
//                        String mapKey = itf.next();
//                        AbstractReportCondition column = config.getModification().getColumnSoft(key, mapKey);
//                        if (column.getControlType().startsWith("AUTOCOMPLETE")) {
//                            for (AbstractReportOption opt : column.getOptions()) {
//                                
//                            }
//                        }
//                    }
                }
            }
            // 明細行用
            getConfig().getSqls().forEach((sql) -> {
                // 入力値受付パラメータに、検索結果をdeep copy
                getListValues().put(sql.getName(), new ArrayList<>(getReportResult().get(sql.getName())));
            });
        }
        // サイドバーは閉じるがモードは終了しない（モードを SIDEBAR_CLOSE に変更
        if ("SIDEBAR_UP".equals(getEditMode())) {
            setEditMode("SIDEBAR_CLOSE");
            getSelectableResults().put("sidebar", new ReportListDataModel(new ArrayList<>(), this.colPkNameForSidebar("sidebar"), config.getModification().getColumns()));
        }
    }
    
    /**
     * SELECT_DYNAMIC,SELECT_MULTI の値が選択されたとき、紐づく値を各項目に展開する。
     * @param event event
     */
    public void onChangeDynamic(SelectEvent event) {
        String applyTo = (String)event.getComponent().getAttributes().get("applyTo");
        AbstractReportOption option = (AbstractReportOption)event.getObject();

        if (option.getRelationValues().isEmpty()) {
            // 値展開先が無ければ終了
            return;
        }
        // 値の展開
        option.getRelationValues().keySet().forEach((key) -> {
            this.getValues().get(applyTo).put(key, option.getRelationValues().get(key));
        });
    }
    
    /**
     * SELECT_DYNAMIC,SELECT_MULTI の値が選択されたとき、紐づく値を各項目に展開する。(明細用)
     * @param event event
     */
    public void onChangeDynamicForLine(SelectEvent event) {
        AbstractReportOption option = (AbstractReportOption)event.getObject();
        String applyTo = (String)event.getComponent().getAttributes().get("applyTo");
        Integer rowIndex = (Integer)event.getComponent().getAttributes().get("rowIndex");
        AbstractReportCondition column = (AbstractReportCondition)event.getComponent().getAttributes().get("condition");

        if (option.getRelationValues().isEmpty()) {
            // 値展開先が無ければ終了
            return;
        }
        // 値の展開
        option.getRelationValues().keySet().forEach((key) -> {
            this.getListValues().get(applyTo).get(rowIndex).put(key, option.getRelationValues().get(key));
        });
    }

    /**
     * AUTOCOMPLETE の値が選択されたとき、紐づく値を各項目に展開する。
     * @param event event
     */
    public void onAutoCompSelected(SelectEvent event) {
        String applyTo = (String)event.getComponent().getAttributes().get("applyTo");
        AbstractReportOption option = (AbstractReportOption)event.getObject();
        AbstractReportCondition column = (AbstractReportCondition)event.getComponent().getAttributes().get("condition");

        // 共通部品の場合はコードと名称を分割して表示
        if (column.getExtra2() != null){
            if (column.getExtra2().equals("1") || column.getExtra2().equals("2") || column.getExtra2().equals("3")) {
                column.setTextValue(option.getValue());
                column.setLabelValue(option.getRelationValues().get("LABEL_VALUE"));
            }
        }
        this.getValues().get(applyTo).put(column.getName(), option.getValue());

        if (option.getRelationValues().isEmpty()) {
            // 値展開先が無ければ終了
            return;
        }
        // 値の展開
/*        option.getRelationValues().keySet().forEach((key) -> {
            this.getValues().get(applyTo).put(key, option.getRelationValues().get(key));
        });
  */  }
     
    /**
     * AUTOCOMPLETE の値が選択されたとき、紐づく値を各項目に展開する。(明細用)
     * @param event event
     */
    public void onAutoCompSelectedForLine(SelectEvent event) {
        AbstractReportOption option = (AbstractReportOption)event.getObject();
        String applyTo = (String)event.getComponent().getAttributes().get("applyTo");
        Integer rowIndex = (Integer)event.getComponent().getAttributes().get("rowIndex");
        AbstractReportCondition column = (AbstractReportCondition)event.getComponent().getAttributes().get("condition");

        this.getListValues().get(applyTo).get(rowIndex).put(column.getName(), option.getValue());

        if (option.getRelationValues().isEmpty()) {
            // 値展開先が無ければ終了
            return;
        }
        // 値の展開
        option.getRelationValues().keySet().forEach((key) -> {
            this.getListValues().get(applyTo).get(rowIndex).put(key, option.getRelationValues().get(key));
        });
    }
    
    /**
     * AUTOCOMPLETE_MULTIの値が選択された時に、紐づく値を渡す.
     * @param event 
     */
    public void onAtCmpCdSelectedForLine(SelectEvent event) {
        for( ReportColumn clm : getMaintConfig().getModification().getColumns() ) {
            if( "AUTOCOMPLETE_MULTI".equals(clm.getControlType()) ) {
                for( AbstractReportOption option : clm.getOptions() ) {
                    if ( event.getObject().equals(option.getValue()) ) {
                        String applyTo = (String)event.getComponent().getAttributes().get("applyTo");
                        Integer rowIndex = (Integer)event.getComponent().getAttributes().get("rowIndex");
                        AbstractReportCondition column = (AbstractReportCondition)event.getComponent().getAttributes().get("condition");

                        this.getListValues().get(applyTo).get(rowIndex).put(column.getName(), option.getValue());

                        if (option.getRelationValues().isEmpty()) {
                            // 値展開先が無ければ終了
                            return;
                        }
                        // 値の展開
                        option.getRelationValues().keySet().forEach((key) -> {
                            this.getListValues().get(applyTo).get(rowIndex).put(key, option.getRelationValues().get(key));
                        });                    
                        return;
                    }
                }                
            }
        }
    } 

    /**
     * FileUpload時に実行されるイベント(アップロードボタンから)
     * @param event event
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException
     * @throws java.io.IOException
     */
    public void handleFileUpload(FileUploadEvent event) throws LogicException, SystemException, IOException {
        File file = null;
        setUploadFileName(new ArrayList<>());
        try {
            getUploadFileName().add(event.getFile().getFileName());

            file = File.createTempFile("updtmp_", event.getFile().getFileName(), new File("./")); // 一時ファイル作成
            file.deleteOnExit(); // ファイルが存在したら削除する
            Files.copy(event.getFile().getInputstream(), file.toPath(), StandardCopyOption.REPLACE_EXISTING); //　ファイルを上書き保存する

            setUploadFiles(new ArrayList<>());
            getUploadFiles().add(file);
        } catch (IOException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        }
        String function = "SS_COM_UPLOAD_FILE_PROC_EX";
        String service = "JohmonWebServiceForMultipart";

        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, service);
        target.put(ExternalServiceExecuter.E_FUNCTION, function);
        target.put(ExternalServiceExecuter.E_SERVICE_NAME, this.getConfig().getSqls().get(0).getName());
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.LIST_UPDATE);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);
        Map<String, Object> params = new HashMap<>();
        params.put("wayOfUpload", this.getWayOfUpload());
        params.put("selectMaster", this.getSelectMaster());
        params.put("fileName", this.getUploadFileName());
        target.put(ExternalServiceExecuter.P_SEND_PARAMETER, params);
        this.getTargetServices().add(target);

        try {
            ExternalServiceExecuterForMultipart exec = new ExternalServiceExecuterForMultipart();
            exec.onService(this);
        } catch (LogicException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        } catch (SystemException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        }
        setSelectReportResult(new ArrayList<>());
        // 取得したLISTの最後を別変数に格納し、LISTの該当箇所を削除する。
        setUploadStatuses(this.getReportResult().get(this.getConfig().getSqls().get(0).getName()).get(this.getReportResult().get(this.getConfig().getSqls().get(0).getName()).size() - 1));
        this.getReportResult().get(this.getConfig().getSqls().get(0).getName()).remove(this.getReportResult().get(this.getConfig().getSqls().get(0).getName()).size() - 1);
        createUploadColumns();
        
        List<Map<String, Object>> selectedRowParam;
        selectedRowParam = this.getReportResult().get(this.getConfig().getSqls().get(0).getName());
        
        Iterator<Map<String, Object>> ite = selectedRowParam.iterator();
        while(ite.hasNext()){
            Map<String, Object> i = ite.next();
            if (!i.get("TOROKU_STATUS").equals("4") && !i.get("TOROKU_STATUS").equals("5") && !i.get("TOROKU_STATUS").equals("6")) {
                getSelectReportResult().add(i);
            }
        }
        setIsChange("false");
        setSelectableResult(new ReportListDataModel(this.getReportResult().get(this.getConfig().getSqls().get(0).getName()), this.colPkName(this.getMaintConfig()), config.getModification().getColumns()));
      
        // 画面構成リストのバックアップ
        setOldSelectableResult(new ReportListDataModel(null, null, null));
        try {
            BeanUtils.copyProperties(getOldSelectableResult(), getSelectableResult());
        } catch (IllegalAccessException | InvocationTargetException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
        }
        setOldReportResult(new HashMap<>());
        for ( String key : getReportResult().keySet() ){
            getOldReportResult().put(key, getReportResult().get(key) );
        }        
        // 画面チェック状態のバックアップ
        setOldSelectReportResult(new ArrayList<>());
        for ( Map map : getSelectReportResult() ) {
            getOldSelectReportResult().add( map );
        }
        // 画面からの入力値のバックアップ
        setOldValues(new HashMap<>());
        for ( String key : getValues().keySet() ) {
            getOldValues().put(key, getValues().get(key));
        } 

        setOldObjectValues(new ArrayList<>());
        for (int i=0; i<objectValues.size(); i++) {
                oldObjectValues.add(objectValues.get(i));
        }                   
        
        DataTable pDt = (DataTable)FacesContext.getCurrentInstance().getViewRoot().findComponent(":List" + this.getConfig().getFormId() + ":tablesorter_" + this.getConfig().getFormId());
        System.out.println(pDt.getSelection());
    }

    private void createUploadColumns() {
        // configをdeep copy
        //this.setMaintConfig((ReportConfig) SerializationUtils.clone(getConfig()));
        this.setMaintConfig(CloneCls.deepcopy(getConfig()));
        this.getMaintConfig().getModification().getColumns().clear();
        // 定義されているcolumn(checkbox,button等)をコピー
        this.getConfig().getModification().getColumns().forEach((column) -> {
            this.getMaintConfig().getModification().getColumns().add(column);
        });
        // 1行目からcolumn定義を取る
        Map columnSetting = this.getReportResult().get(this.getConfig().getSqls().get(0).getName()).get(0);
        // 2行目(一時保存データ)から、カラムを作成
        Map columnsBase = this.getReportResult().get(this.getConfig().getSqls().get(0).getName()).get(1);
        int i = 1;
        for (Iterator ite = columnsBase.keySet().iterator(); ite.hasNext();) {
            String columnName = (String)ite.next();
            
            ReportColumn column = new ReportColumn();
            String columnDescription = null;
            if (columnSetting.get(columnName) != null) {
                columnDescription = (String)columnSetting.get(columnName);
                column.setControlType("LABEL");
                column.setPk(false);
            } else {
                columnDescription = columnName;
                column.setControlType("HIDDEN");
                column.setPk(true);
            }
            column.setName(columnName);
            column.setDisplayName(columnDescription);
            column.setTableName(this.getSelectMaster());
            column.setReadonly(true);
            column.setSortIndex(i + 5);
            column.setVisible(true);

            this.getMaintConfig().getModification().getColumns().add(column);
        }
        this.getReportResult().get(this.getConfig().getSqls().get(0).getName()).remove(0);
    }
    
    /**
     * ツリーのノードを全て閉じる
     */
    public void collapseAll() {
        setExpandedRecursively(getSelectableTreeResult().getRoot(), false);
    }
    /**
     * ツリーのノードを全て開く
     */
    public void expandAll() {
        setExpandedRecursively(getSelectableTreeResult().getRoot(), true);
    }
    private void setExpandedRecursively(final TreeNode node, final boolean expanded) {
        node.getChildren().forEach((child) -> {
            setExpandedRecursively(child, expanded);
        });
        node.setExpanded(expanded);
    }

    public void disableUIComponent() {
        disableUIComponentProc(true);
    }
    public void unDisableUIComponent() {
        disableUIComponentProc(false);
    }
    private void disableUIComponentProc(boolean isDisable) {
        // ヘッダ部
        String compName = ":h_" + this.getConfig().getFormId() + ":headerTitle_" + this.getConfig().getFormId();
        UIComponent component = FacesContext.getCurrentInstance().getViewRoot().findComponent(compName);
        if(component != null) {
            disableAll(component.getChildren(), isDisable);
        }
        // 明細部
        for (ReportSql sql : this.getConfig().getSqls()) {
            String compDlName = ":dl_" + this.getConfig().getFormId() + ":headerTitle_" + this.getConfig().getFormId() + "_" + sql.getName();
            UIComponent componentDl = FacesContext.getCurrentInstance().getViewRoot().findComponent(compDlName);
            if(componentDl != null) {
                disableAll(componentDl.getChildren(), isDisable);
            }
        }
    }

    private void disableAll(List<UIComponent> components, boolean isDisable) {
        components.stream().map((component) -> {
            if (component instanceof UIInput) {
                try {
                    Method m = component.getClass().getMethod("setDisabled", boolean.class);
                    m.invoke(component, isDisable);
                    try {
                        setStyleClass(component, "StyleClass", isDisable);
                    } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException ex) {
                    }
                    // inputStyleClassがあるコンポーネントはこちらが優先されCSSが効く
                    try {
                        setStyleClass(component, "InputStyleClass", isDisable);
                    } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException ex) {
                    }
                } catch (NoSuchMethodException | SecurityException ex) {
                    // untarget component
                } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
                    Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            return component;
        }).forEachOrdered((component) -> {
            disableAll(component.getChildren(), isDisable);
        });
    }
    private void setStyleClass(UIComponent component, String method, boolean isDisable) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        final String disableStyle = "disabledForHistory";
        String style = null;
        Method m2get = component.getClass().getMethod("get" + method);
        Object styleRaw = m2get.invoke(component);
        if (styleRaw != null) {
            style = (String)styleRaw;
        }

        Method m2 = component.getClass().getMethod("set" + method, String.class);
        if (isDisable) {
            m2.invoke(component, style + " " + disableStyle);
        } else {
            if (style != null && style.indexOf(disableStyle) > 1) {
                m2.invoke(component, style.substring(0, style.indexOf(disableStyle)-1));
            } else {
                m2.invoke(component, "");
            }
        }

    }

    public void selectOneAddress(Map<String, String> add) {
        add.keySet().stream().filter((targetField) -> (!targetField.equals("DISP_ADDRESS") && !targetField.equals("applyTo"))).forEachOrdered((targetField) -> {
            this.getValues().get(add.get("applyTo")).put(targetField, add.get(targetField));
        });
    }

    /**
     * 権限によるボタン制御（上部ボタン）
     * @return 
     */    
    public List<ReportButton> authorizedTopButtons() {
        List<ReportButton> result = new ArrayList<>();
        getConfig().getTopButtons().forEach((btn) -> {
            if (!authConf.isAllEnabledFunction() && !authConf.getFunctionList().containsKey(btn.getName())) {
                // 権限制御によるボタン非表示
            } else if ("INSERT".equals(getEditMode()) && (btn.getAction().equals("UPDATE") || btn.getAction().equals("CONFIRM") || btn.getAction().equals("UNCONFIRM") || btn.getAction().equals("UPDATE2") || btn.getAction().equals("CHKLIST_UPDATE") || btn.getAction().equals("PAGER_PREV") || btn.getAction().equals("PAGER_NEXT") || btn.getAction().equals("CREATE_NEW"))) {
                // 新規時は確定と確定解除は表示しない
            } else if ("UPDATE".equals(getEditMode()) && (btn.getAction().equals("INSERT"))) {
                // 更新時は新規登録ボタンを表示しない
            } else {
                result.add(btn);
            }
        });
        return result;
    }
    
    /**
     * 権限によるボタン制御（下部ボタン）
     * @return 
     */ 
    public List<ReportButton> authorizedBottomButtons() {
        List<ReportButton> result = new ArrayList<>();
        getConfig().getBottomButtons().forEach((btn) -> {
            if (!authConf.isAllEnabledFunction() && !authConf.getFunctionList().containsKey(btn.getName())) {
                // 権限制御によるボタン非表示
            } else if ("INSERT".equals(getEditMode()) && (btn.getAction().equals("UPDATE") || btn.getAction().equals("CONFIRM") || btn.getAction().equals("UNCONFIRM") || btn.getAction().equals("UPDATE2") || btn.getAction().equals("CHKLIST_UPDATE") || btn.getAction().equals("PAGER_PREV") || btn.getAction().equals("PAGER_NEXT") || btn.getAction().equals("CREATE_NEW"))) {
                // 新規時は確定と確定解除は表示しない
            } else if ("UPDATE".equals(getEditMode()) && (btn.getAction().equals("INSERT"))) {
                // 更新時は新規登録ボタンを表示しない
            } else {
                result.add(btn);
            }
        });
        return result;
    }

/* 現在未使用のためコメント、必要であればコメント解除    
    public String getChkVal(Map<String, String> line) {
        StringBuffer chkVal = new StringBuffer();
        this.getConfig().getModification().getPkList().forEach((column) -> {
            String val = line.get(column.getName());
            if (chkVal.length() != 0) {
                chkVal.append("&");
            }
            chkVal.append("LIST-").append(column.getName()).append("=").append(val);
        });
        return chkVal.toString();
    }
*/

/* 現在未使用のためコメント、必要であればコメント解除
    public String getPkParam(Map<String, String> line) {
        return getPkParam(line, null);
    }
*/

/* 現在未使用のためコメント、必要であればコメント解除    
    public String getPkParam(Map<String, String> line, String applyTo) {
        StringBuffer pkParam = new StringBuffer();
        this.getConfig().getModification().getPkList(applyTo).forEach((column) -> {
            String val = line.get(column.getName());
            if (pkParam.length() != 0) {
                pkParam.append("&");
            }
            pkParam.append("P_").append(column.getName()).append("=").append(val);
        });
        return pkParam.toString();
    }
*/

/* 現在未使用のためコメント、必要であればコメント解除    
    public String getHdnList(Map<String, String> line) {
        return getHdnList(line, null);
    }
*/

/* 現在未使用のためコメント、必要であればコメント解除        
    public String getHdnList(Map<String, String> line, String applyTo) {
        StringBuffer hdnList = new StringBuffer();
        this.getConfig().getModification().getHiddenList(applyTo).forEach((column) -> {
            String val = line.get(column.getName());
            if (hdnList.length() != 0) {
                hdnList.append("&");
            }
            hdnList.append("P_").append(column.getName()).append("=").append(val);
        });
        return hdnList.toString();
    }
*/
    
    public String colPkName() {
        return colPkName(null, null, this.getConfig());
    }
    public String colPkName(String applyTo) {
        return colPkName(applyTo, null, this.getConfig());
    }
    public String colPkName(ReportConfig targetConfig) {
        return colPkName(null, null, targetConfig);
    }
    public String colPkNameForSidebar(String applyTo) {
        return colPkName(applyTo, ReportConst.SECTION.HISTORY, this.getConfig());
    }
    public String colPkName(String applyTo, String section, ReportConfig targetConfig) {
        String result = null;
        for (ReportListColumn listCol : targetConfig.getModification().getListColumnLayout(applyTo, section)) {
            for (ReportColumn column : listCol.getCols()) {
                if (column.isPk()) {
                    result = column.getName();
                    break;
                }
            }
            if (result != null) break;
            }

        if (result == null) {
            for (ReportColumn column : targetConfig.getModification().getHiddenList(applyTo, section)) {
                if (column.isPk()) {
                    result = column.getName();
                    break;
                }
            }
        }
        return result;
    }

    public String getJsContent() {
        return this.getConfig().getJsContent(getSsconfig().getRcontext().getConfDirectory());
    }

    public String getJsFilePath() {
        return this.getConfig().getJsFilePath(getSsconfig().getRcontext().getConfDirectory());
    }

    public ReportSql getHeaderSql() {
        return getConfig().getSqls().get(0);
    }

    private void parameterInitialization() {
        setExternalAttribute(new HashMap<>());
        setValues(new HashMap<>());
        setObjectValues(new ArrayList<>());
        setIdBind(new HashMap<>());
        setReportResult(new HashMap<>());
        setSelectReportResult(new ArrayList<>());
        setSelectEditReportResult(new HashMap<>());
        setSelectableResult(null);
        setSelectableResults(new HashMap<>());
        setReportSidebarResult(new HashMap<>());
        setTargetServices(new ArrayList<>());
        setSelectedPdf(new HashMap<>());
        setListValues(new HashMap<>());
        setDialogParams(new ArrayList<>());
        setEditModeTemp("");
        setSelectedLine(new HashMap<>());
        setMaintConfig(null);
        setSelectMaster("");
        setWayOfUpload("upd");
        setOldSelectMaster("");        
        setUploadStatuses(null);
        setUpLoadFileStream(new ArrayList<>());
    }

    public void viewHandson() {
        Map<String,Object> options = new HashMap<>();
        options.put("resizable", false);
        options.put("modal", true);
        options.put("closable", false);
        options.put("width", "95%");
        options.put("height", Double.parseDouble(getParentWindowSize()) * 0.8);
        options.put("contentWidth", "100%");
        options.put("contentHeight", "100%");
//        options.put("widgetVar", "handson_grid_dlg");
//        handsontableVal = new ArrayList<>();
        RequestContext.getCurrentInstance().openDialog("/contents/handson_dialog", options, null);
    }

    public void closeHandson() {
        RequestContext.getCurrentInstance().closeDialog(null);
    }

    public void submitHandson(SelectEvent event) throws IOException, LogicException {
        if (event.getObject() == null) {
            // クローズボタン押下時動作
            return;
        }
        String tableVal = (String)event.getObject();
        ObjectMapper mapper = new ObjectMapper();
        List<List<String>> handsonResultList = mapper.readValue(tableVal, List.class);

        if (handsonResultList.size() < 1) {
            throw new LogicException("入力データがありません。");
        }

        if (this.getReportResult() == null) {
            this.setReportResult(new HashMap<>());
        }
        if (this.getReportResult().get(this.getConfig().getSqls().get(0).getName()) == null) {
            this.getReportResult().put(this.getConfig().getSqls().get(0).getName(), new ArrayList<>());
        }

        List<Map<String, Object>> tmpReportResult = new ArrayList<>();

        // 1行目からcolumn定義を取る(左詰めで設定されていることが条件)
//        List<String> columnSetting = handsonResultList.get(0);
//        // 2行目から、カラム名を取る(左詰めで設定されていることが条件)
//        List<String> columnBase = handsonResultList.get(1);
//        Map<String, Object> columnNames = new LinkedHashMap<>();
//        Map<String, Object> columnDisplays = new LinkedHashMap<>();
//        for (int i = 0; i < columnSetting.size(); i++) {
//            String columnName = columnSetting.get(i);
//            if (columnName.isEmpty()) continue;
//            columnNames.put(columnName, columnName);
//            columnDisplays.put(columnName, columnBase.get(i));
//        }
        Map<String, Object> columnNames = new LinkedHashMap<>();
        Map<String, Object> columnDisplays = new LinkedHashMap<>();
        if (!this.reportResult.get(this.config.getSqls().get(0).getName()).isEmpty()) {
            for (String key : columnDisplays.keySet()) {
                columnDisplays.put(key, "");
            }
        } else {
            List<String> columnBase = handsonResultList.get(0);
            for (int i = 0; i < columnBase.size(); i++) {
                String column = columnBase.get(i);
                if (column.isEmpty()) continue;
                columnDisplays.put("value" + i, "列" + i);
            }
        }

        for (int i = 2; i < handsonResultList.size(); i++) {
            List<String> oneLine = handsonResultList.get(i);
            Map<String, Object> line = new LinkedHashMap<>();
            int j = 0;
            for (String key : columnDisplays.keySet()) {
                line.put(key, oneLine.get(j++));
            }
            tmpReportResult.add(line);
        }

        if (this.getMaintConfig() == null) {
            tmpReportResult.add(0, columnDisplays);
            this.getReportResult().get(this.getConfig().getSqls().get(0).getName()).addAll(tmpReportResult);
            createUploadColumns();
        } else {
            this.getReportResult().get(this.getConfig().getSqls().get(0).getName()).addAll(tmpReportResult);
        }
        setSelectableResult(new ReportListDataModel(this.getReportResult().get(this.getConfig().getSqls().get(0).getName()), this.colPkName(this.getMaintConfig()),config.getModification().getColumns()));

//        System.out.println("handsonResultList : " + handsonResultList);
    }

    public void handleReturn() {
        RequestContext.getCurrentInstance().closeDialog(this.getHandsontableVal());

//        HttpServletRequest request = null;
//        HttpSession session = request.getSession(false);
//        HttpSession session = (HttpSession)  FacesContext.getCurrentInstance().getExternalContext().getSession(false);
//        if (session == null) {
//            response.sendRedirect("/WEB-INF/errorpages/expired.xhtml");
//            
//        }

    }
    // Handsontable section end

    /**
     * セッション継続のための空処理用メソッド
     */
    public void resetSessionTimeout() {
    }

    public void redirectLogin() throws IOException{
        FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
        FacesContext.getCurrentInstance().getExternalContext().redirect("/WEB-INF/errorpages/expired.xhtml");
    }

    /**
     * Excel帳票に罫線を引く（サンプル）
     * @param document 
     */
    public void ppMethod(Object document) {
        HSSFWorkbook wb = (HSSFWorkbook) document;
        HSSFSheet sheet = wb.getSheetAt(0);
        HSSFRow header = sheet.getRow(0);        
/*        
        HSSFCellStyle cellStyle = wb.createCellStyle();  
        cellStyle.setFillForegroundColor(HSSFColor.GREEN.index);
        cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

        cellStyle.setBorderTop(cellStyle.BORDER_DASHED);
        cellStyle.setBorderBottom(cellStyle.BORDER_DOUBLE);
        cellStyle.setBorderLeft(cellStyle.BORDER_MEDIUM_DASH_DOT);
        cellStyle.setBorderRight(cellStyle.BORDER_MEDIUM);          
        
        for(int i=0; i < header.getPhysicalNumberOfCells();i++) {
            HSSFCell cell = header.getCell(i);
             
            cell.setCellStyle(cellStyle);
        }
        */
    }
    
    public List<String> getDivList(){
	List<String> divList = new ArrayList<String>();
	getConfig().getModification().getColumnsSort().forEach((column) -> {
	    if(!divList.contains(column.getApplyTo()) && column.getApplyTo().length() > 0){
		divList.add(column.getApplyTo());
	    }
        });
	return divList;
    }

/* 現在未使用のためコメント、必要であればコメント解除      
    public List<Object> getDivColumns(String div){
	List<Object> divColumns = new ArrayList<Object>();
	getConfig().getModification().getColumnsSort().forEach((column) -> {
	    if(div == column.getApplyTo() && div.length() > 0){
		divColumns.add(column);
	    }
	});	
	return divColumns;
    }
*/
    
 /**
     * 自分ボタン押下時に自分の情報を取得(担当者コード：担当者名を反映)
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     * @param  event
     * @throws java.lang.reflect.InvocationTargetException
     */
    public void selectSelfInfo(ActionEvent event) throws LogicException, SystemException, InvocationTargetException {
   
        String applyTo = (String)event.getComponent().getAttributes().get("applyTo");
        AbstractReportCondition column = (AbstractReportCondition)event.getComponent().getAttributes().get("condition");

        ReportSql targetDef = getConfig().getSqls().get(0);
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
        target.put(ExternalServiceExecuter.E_FUNCTION, "COM_SEARCH");
        target.put(ExternalServiceExecuter.E_SQL, "USER_SELF_SEARCH");
        target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);
       
        Map<String, Object> sendParams = new HashMap<>();       
        target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);
        this.getTargetServices().add(target);
        searchProcess();
        setSelectableResult(new ReportListDataModel(this.getReportResult().get(targetDef.getName()), this.colPkName(), config.getModification().getColumns()));
        this.getValues().get(applyTo).put(column.getName(), getSelectableResult().getDatasource().get(0).get("VALUE").toString());
        column.setLabelValue(getSelectableResult().getDatasource().get(0).get("LABEL_VALUE").toString());

    }
       
    /**
     * 指定されたサービスのSQL呼び出しだけを行う
     * s_furutani
     * @param targetDef
     * @param sendParams 検索条件以外の任意データ、ない場合はnull指定。
     * @return select結果
     * @throws LogicException
     * @throws SystemException 
     */
    public List<Map<String, Object>> callSql(ReportSql targetDef, Map<String, Object> sendParams) throws LogicException, SystemException {
            
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
        target.put(ExternalServiceExecuter.E_FUNCTION, targetDef.getFunctionCode());
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, targetDef.getEditModeName());
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, targetDef.getEditActivityName());
        target.put(ExternalServiceExecuter.E_TARGET_CONFIG, targetDef.getConfig());
        this.getTargetServices().add(target);
        
        Map<String, Map<String, Object>> paramsmap = new PageParameterGetter().getParamMap(values, config);
        Map<String, Object> formParams = paramsmap.get(targetDef.getName());
        if (null == sendParams){//送付されたデータが空の場合
            sendParams = new HashMap<>();
        }
        //任意データ+formデータをパラメータとして送信
        if (null != formParams){
            sendParams.putAll(formParams);
        }
        
        //必須チェックrequired＞trueのものチェック
/* サービス側で行うのでコメント化
        String errcolumn = requiredValidate(sendParams);
        if (!"".equals(errcolumn)){
            new MsgExec().message("ERROR", "エラー", errcolumn + ": 必須項目が未入力です。");
            return new ArrayList<Map<String, Object>>();
        }
*/
        //明細データ取得
        switch (targetDef.getEditModeName()) { 
            case ReportConst.F_BTNACT.INSERT:
            case ReportConst.F_BTNACT.UPDATE:
            {
                if (!(null == this.selectableResult || 0 == selectableResult.getDatasource().size())){
                    sendParams.put(ReportConst.F_SQLDATA.TABLEALL_NODE, selectableResult.getDatasource()); 
                }
                if (!(null == this.selectableTreeResult || null == selectableTreeResult.getDatasource() || 0 == selectableTreeResult.getDatasource().size())){
                    sendParams.put(ReportConst.F_SQLDATA.TABLEALL_NODE, selectableTreeResult.getDatasource()); 
                }
            }
            case ReportConst.F_BTNACT.CHKLIST_UPDATE:   
            {
                //明細チェック操作データ (list or tree)
                if (!(null == this.selectReportResult || 0 == selectReportResult.size())){
                    sendParams.put(ReportConst.F_SQLDATA.SELECTED_NODE, this.selectReportResult);
                }
                if (!(null == this.selectableTreeResult || null == selectableTreeResult.getDatasource() || 0 == selectableTreeResult.getDatasource().size())){
                    List<Map<String, Object>> selectdatas = selectableTreeResult.selectedmap(selectedNodes);
                    if (0 != selectdatas.size()){
                        sendParams.put(ReportConst.F_SQLDATA.SELECTED_NODE, selectdatas); 
                    }
                }
            }
            break;
            default://サーチなどは明細行を取得しない
        }

        //検索の場合は前回のデータを消去
        if (ReportConst.EditMode.SEARCH.equals(targetDef.getEditModeName())){
            getReportResult().put(targetDef.getName(), new ArrayList<>());
            //選択された行を消去
            this.selectReportResult = new ArrayList<>();
        } 
        
        target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);
        //searchProcess();
        new ExternalServiceExecuter2().dbProcess(this);
        
        if (this.getReportResult().containsKey(targetDef.getName())){
            return this.getReportResult().get(targetDef.getName());
        } else {
            //データが取得できない、または取得する必要が無い場合
            this.getReportResult().put(targetDef.getName(), new ArrayList<Map<String, Object>>());
            return new ArrayList<Map<String, Object>>();
        }
    } 

    /**
     * 必須チェックrequired＞trueチェック
	 * s_furutani
     */
/* サービス側で行うのでコメント化
    private String requiredValidate(Map<String, Object> sendParams){
        //必須チェックrequired＞trueのものチェック
        String targetcolumn = null;
        StringBuffer sb = new StringBuffer();
        for(ReportCondition cond : getConfig().getConditions()) {
            if(cond.isRequired()){
                Object obj = sendParams.get(cond.getName());
                if (obj == null){
                    sb.append(cond.getName()).append(",");
                    continue;
                } else if (obj instanceof String){
                    if ("".equals((String)obj)){
                        sb.append(cond.getName()).append(",");
                        continue;
                    }
                }
            }
        }
        return sb.toString();
    }
*/    
    /**
     * サブボタンのボタン動作(チェックリスト用)
     * @param act rpt.button.action
     * @throws Exception 
	 * s_furutani
     */
    public void executeChkListUpDate(FacesEvent event) throws Exception {

        Map<String ,Object> attribute = event.getComponent().getAttributes();
        ReportButton btn = (ReportButton)attribute.get("btn");

        // 業務個別ロジック呼び出し前
        callBusinessLogic(event);

        String act = btn.getAction();
        switch (act) { 
            case ReportConst.F_BTNACT.CHKLIST_UPDATE:   
            {
                //データ未選択
                if ((getSelectedNodes() == null || getSelectedNodes().length == 0) &&
                (getSelectReportResult() == null || getSelectReportResult().isEmpty())){
                    new MsgExec().eErrorMessage("対象行が選択されていません。");
                    return;
                }
                //更新処理
                ReportSql targetDef = new ReportSql();
                targetDef.setName(btn.getName());
                targetDef.setFunctionCode(btn.getFunctionCode());
                targetDef.setEditModeName(act);
                this.callSql(targetDef, null);
                //再検索
                if (null == getSelectedNodes()){
                    executeSearch(event);//datatableの実行
                } else {
                    executeSearchForTree(event);//treetableの実行
                }
            }
            break;
            default: //なにもしない
        }

        // 業務個別ロジック呼び出し画面初期化後
        attribute.put("face","faceend");
        callBusinessLogic(event);
    }
	
    /**
     * サブボタンのボタン動作(INSERT,UPDATE用)
     * @param act rpt.button.action
     * @throws Exception 
	 * s_furutani
     */
    public void executeUpDate(FacesEvent event) throws Exception {

        Map<String ,Object> attribute = event.getComponent().getAttributes();
        ReportButton btn = (ReportButton)attribute.get("btn");

        // 業務個別ロジック呼び出し前
        callBusinessLogic(event);

        String act = btn.getAction();
        switch (act) { 
            case ReportConst.F_BTNACT.INSERT:
            case ReportConst.F_BTNACT.UPDATE:   
            {
                //更新処理
                ReportSql targetDef = new ReportSql();
                targetDef.setName(btn.getName());
                targetDef.setFunctionCode(btn.getFunctionCode());
                targetDef.setEditModeName(act);
                this.callSql(targetDef, null);
            }
            break;
            default: //なにもしない
        }
        // 業務個別ロジック呼び出し画面初期化後
        attribute.put("face","faceend");
        callBusinessLogic(event);
    }

	/**
	 * 一覧検索画面の行に含まれるボタン押下時の遷移動作
	 * A -B1 -Cと遷移しており、Bに遷移した場合は、A -B1 -C -B2とし、画面とパンくずを作成する。
	 * s_furutani
	 */
    public void executeEditTrans(ActionEvent event) throws LogicException, SystemException {

        BreadCrumbBean bread = getBreadCrumbBean();
        if (bread.checkBUpdateFlg()){ //callbackで判定戻し（編集中）
            return;
        }
	
        PagePropertiesBean oldProp = new PageParameterGetter().getPagePropertiesBean(this, event);

        Map<String ,Object> eventmap = event.getComponent().getAttributes();
        //attributeにcolumn属性がある場合は取得
        String nextRptfile = "";
        try {//columnを指定しない場合でもエラーにしない。
            ReportColumn column = (ReportColumn)eventmap.get("column");
            if (null != column.getTransferRptDir() && null != column.getTransferRptFile()){
                nextRptfile = column.getTransferRptDir() + "." + column.getTransferRptFile();
            }
        } catch (Exception ex) {}

        // 業務個別ロジック呼び出し画面表示前
        callBusinessLogic(event);

        String nextScreenCode ="";
        if (ssconfig.getScreenCodesMap().containsKey(nextRptfile)) {
            nextScreenCode = getSsconfig().getScreenCodesMap().get(nextRptfile);
        } else {
            if (eventmap.containsKey("screencode")){
                nextScreenCode = (String)eventmap.get("screencode");
            }
        }
        if (!ssconfig.getConfigs().containsKey(nextScreenCode)){
            new MsgExec().message("ERROR", "エラー", "rptファイルに遷移先が指定されていません。");
            return;
        }

        //画面ファイル読み出し
        ReportConfig tmpConfig = getSsconfig().getConfigs().get(nextScreenCode);
        setConfig(CloneCls.deepcopy(tmpConfig));

        //ブリッジ初期処理
        eventmap.put("timing", "next");
        eventmap.put("cls", getConfig().getBridge());
        eventmap.put("method", "init");
        callBusinessLogic(event);

        //初期化処理
        parameterInitialization();
        gotoNextInit(getConfig(), nextScreenCode);

        //ブリッジ後処理
        eventmap.put("face","faceend");
        eventmap.put("endcls", tmpConfig.getBridge());
        eventmap.put("endmethod", "close");
        callBusinessLogic(event);
        eventmap.remove("timing");

        try {
            // パンくず構築
            getBreadCrumbBean().gotoBreadNext(this, oldProp);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw new SystemException(ex);
        }
        // 業務個別ロジック呼び出し画面初期化後
        eventmap.put("face","faceend");
        callBusinessLogic(event);
    }

    /**
     * 共通UPLoad遷移
     * @param event
     * @throws LogicException
     * @throws SystemException 
     */
    public void executeUploadTrans(ActionEvent event) throws LogicException, SystemException {
        // 画面からselectMaster情報を読み込むクラス、メソッド、オブジェクトの受け取る
        Map<String, Object> eventmap = event.getComponent().getAttributes();
        String kinocd;
        try {
            kinocd = (String)eventmap.get("uploadkinocd");
        }catch (Exception e){
            //UPLOAD_KINO_CDが指定されていない場合
            new MsgExec().message("ERROR", "エラー", "xhtml に kinocd属性 が指定されていません。");
            return;
        }

        eventmap.put("screencode", ReportConst.F_SCREEN.UPLOAD);
        executeEditTrans(event);
        selectMaster = kinocd;
        config.getConditions().get(0).setReadonly(true);
    }
	/**
	 * 前画面へボタン押下時の遷移動作
	 * A -B1 -C -B2と遷移しており、前画面をクリック時は、C以降のパンくず及びデータを削除。Cのデータを復元。
	 * s_furutani
	 */
    public void executeBackTrans(ActionEvent event) throws LogicException, SystemException {
        BreadCrumbBean bread = getBreadCrumbBean();
        if (bread.checkBUpdateFlg()){ //callbackで判定戻し（編集中）
            return;
        }
        //現在のメニュー数 -2が前画面。
        int index = bread.getModel().getElements().size() - 2;

        //戻りの初期化処理
        executeBackInit(event,  bread, index);
	}

    /**
     * パンくずメニュー押下時の遷移動作
     * A -B1 -C -B2と遷移しており、B1をクリックした場合は、B1以降のパンくず及びデータを削除。B1のデータを復元。
     * s_furutani
     * @param event
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException
     */
    public void transAtCrumb(ActionEvent event) throws SystemException {

        BreadCrumbBean bread = getBreadCrumbBean();
        if (bread.checkBUpdateFlg()){ //callbackで判定戻し（編集中）
            return;
        }

        MenuItem menuItem = ((MenuActionEvent) event).getMenuItem();
        int index = bread.getMenuIndex(menuItem);

        //戻りの初期化処理
        executeBackInit(event,  bread, index);
    }

    /**
     * 画面を戻る場合の初期化処理共通
     * s_furutani
     */
    private void executeBackInit(ActionEvent event, BreadCrumbBean bread, int index) throws SystemException {
        //topページの場合は初期化
        if (index == 0) {
            this.init();
            bread.init();
            return;
        }

        // 画面初期化処理
        PagePropertiesBean nextProp = bread.getPageProperties(index);
        String nextScreenCode = nextProp.getScreenCode();
        ReportConfig tmpConfig = getSsconfig().getConfigs().get(nextScreenCode);
        
        try {
            //ブリッジ初期処理
            Map<String, Object> eventmap = event.getComponent().getAttributes();
	    eventmap.put("timing", "back");
	    eventmap.put("cls", tmpConfig.getBridge());
	    eventmap.put("method", "init");
	    callBusinessLogic(event);

            //初期化処理
            parameterInitialization();
            gotoNextInit(tmpConfig, nextScreenCode);
            //前回ファイル上書き
            config = nextProp.getConfig();
            values = nextProp.getValues();
            config.setEditFlg(false);

            //ブリッジ後処理
	    eventmap.put("face","faceend");
	    eventmap.put("endcls", tmpConfig.getBridge());
	    eventmap.put("endmethod", "close");
	    callBusinessLogic(event);

	} catch (LogicException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw new SystemException(ex);
        }
        bread.crumbIdRestructure(index);
    }
    
    /**
     * 各業務ロジック呼び出し(FacesEvent対応)
     * @param event
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException
     */
    public void callBusinessLogic(FacesEvent event) throws SystemException {

        MessageDataModel messageData = new MessageDataModel();
        ArrayList kbn;
        ArrayList message;

        // 画面からクラス、メソッド、オブジェクトの受け取る
        Map<String, Object> eventmap = event.getComponent().getAttributes();
        String strCls = "";
        String strMt = "";
        String face = "";

        //faceにより現段階のメソッドを実行する。
        if (eventmap.containsKey("face")){
            face = (String)eventmap.get("face");
            eventmap.remove("face");
        }
        if ("".equals(face)){//face未入力
            if (eventmap.containsKey("cls")){
                strCls = (String)eventmap.get("cls");
                //eventmap.remove("cls");
            }
            if (eventmap.containsKey("method")){
                strMt = (String)eventmap.get("method");
                //eventmap.remove("method");
            }
        } else if ("faceend".equals(face)){
            if (eventmap.containsKey("endcls")){
                strCls = (String)eventmap.get("endcls");
                //eventmap.remove("endcls");
            }
            if (eventmap.containsKey("endmethod")){
                strMt = (String)eventmap.get("endmethod");
                //eventmap.remove("endmethod");
               }
        }

        if(!StringUtils.defaultString(strCls).equals("") && !StringUtils.defaultString(strMt).equals("")){

            try{
                // クラスのインスタンスを作成してメソッドを実行
                Class<?> cls;
                cls = Class.forName(ExternalServiceProperty.getInstance().getProperty("businesssource") + strCls);
                Object obj = cls.newInstance();

                Method mt;
                Boolean bool = false;
                if (eventmap.containsKey("timing")){
                    //next遷移時、戻り遷移時
                    String timing = (String)eventmap.get("timing");
                    bool = timing.equals("back");
                }
                mt = cls.getMethod(strMt, this.getClass(), FacesEvent.class, messageData.getClass(), Boolean.class);
                mt.invoke(obj, this, event, messageData, bool);

            }catch(ClassNotFoundException 
                    | IllegalAccessException
                    | IllegalArgumentException 
                    | InstantiationException 
                    | NoSuchMethodException
                    | SecurityException 
                    | InvocationTargetException ex){
                Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
                throw new SystemException(ex);
            }

            // メッセージ出力
            MsgExec.message(messageData);
        }
    }

/**
     * SVF出力
     * @param event
     * @return 
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException
     * @throws java.io.IOException
     * @throws jp.co.kintetsuls.exception.SystemException
     * @throws jp.co.kintetsuls.exception.LogicException
     */
    public void svfOutput(ActionEvent event) throws SystemException, IOException, jp.co.kintetsuls.exception.SystemException, jp.co.kintetsuls.exception.LogicException, InterruptedException {
        
        MessageDataModel messageData = new MessageDataModel();
        ArrayList kbn;
        ArrayList message;
        String strCls, strMt;
        
        int ret = 0;
        setSvfData(new SvfDataModel());  // SVF情報
        
        // 画面から出力パターンを受け取る
        String strOutPtn = (String)event.getComponent().getAttributes().get("outPtn");
        
        // 印刷の場合はポップアップ経由のためpopUpBeanから取得。印刷以外はAttributesで取得
        if (strOutPtn.equals(getSvfData().getPTN_PRINT())) {
            svfData = (SvfDataModel)popupBean.getPopupValues().get("PrintInfo").get("svfData");
            strCls = svfData.getSvfBizClass();
            strMt = svfData.getSvfBizMethod();
        } else {
            strCls = (String)event.getComponent().getAttributes().get("cls");
            strMt = (String)event.getComponent().getAttributes().get("method"); 
            svfData.setFileFormat(strOutPtn);
        }
        
	// 個別の業務処理によって帳票用のCSVを作成		
        if(!StringUtils.defaultString(strCls).equals("") && !StringUtils.defaultString(strMt).equals("")){
            try{
                // クラスのインスタンスを作成してメソッドを実行　SVF出力する情報を生成する
                Class<?> cls;
                cls = Class.forName(ExternalServiceProperty.getInstance().getProperty("businesssource") + strCls);
                Object obj = cls.newInstance();
                Method mt = cls.getMethod(strMt, SSNaviManagedBean.class, messageData.getClass());
                mt.invoke(obj, this, messageData);

            }catch(ClassNotFoundException 
                    | IllegalAccessException
                    | IllegalArgumentException 
                    | InstantiationException 
                    | NoSuchMethodException
                    | SecurityException 
                    | InvocationTargetException ex){
                Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);            
                throw new SystemException(ex);
                
            }catch(Exception ex){
                Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
				new MsgExec().message("ERROR", "エラー", ex.getStackTrace().toString());
                throw new SystemException(ex);
            }
                       
            // メソッドの取得結果を反映してSVF出力を実行
            PrintReport rep = new PrintReport();
  
            // ExcelとPdf、Prev、Printで処理を分ける
            if (strOutPtn.equals(getSvfData().getPTN_EXCEL()) || strOutPtn.equals(getSvfData().getPTN_PDF())) {
                // Excel、Pdfの場合
                rep.outputFile(getSvfData()); 

            } else if (strOutPtn.equals(getSvfData().getPTN_PREV())) {
                // プレビューの場合
                rep.preview(getSvfData());
                // 正常の場合
                if (ret == 0) {
                    objectValues.add(getSvfData());
                }
            } else {
                // 印刷の場合
                rep.outputPrint(getSvfData());
                
                // ポップアップ用の印刷情報をクリア
                popupBean.getPopupValues().remove("PrintInfo");
                if(popupBean.getPopupValues().isEmpty()) {
                    // 他のポップアップ情報が無いのでポップアップフラグをfalseにする
                    popupBean.setPouUpOpenFlag(false);
                }
            }
            
            // メッセージ出力
            //MsgExec.message(messageData);
        }
    }

/**
     * SVF印刷設定取得
     * @param event
     * @return 
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException
     * @throws java.io.IOException
     * @throws jp.co.kintetsuls.exception.SystemException
     * @throws jp.co.kintetsuls.exception.LogicException
     */
    public int svfPrintSetting(FacesEvent event) throws SystemException, IOException, jp.co.kintetsuls.exception.SystemException, jp.co.kintetsuls.exception.LogicException, InterruptedException {
        
        MessageDataModel messageData = new MessageDataModel();
        ArrayList kbn;
        ArrayList message;
        String ptn;
        int ret = 0;
        setSvfData(new SvfDataModel());  // SVF情報

        // 画面からクラス、メソッドを受け取る
        String strCls = (String)event.getComponent().getAttributes().get("cls");
        String strMt = (String)event.getComponent().getAttributes().get("method");
			
        if(!StringUtils.defaultString(strCls).equals("") && !StringUtils.defaultString(strMt).equals("")){
            try{
                // 印刷処理に必要な情報を取得する(ユーザーコードがキー)
                PrintReport rep = new PrintReport();  
                rep.getPrintSetting(this, messageData);   

            }catch(ClassNotFoundException 
                    | IllegalAccessException
                    | IllegalArgumentException 
                    | InstantiationException 
                    | NoSuchMethodException
                    | SecurityException 
                    | InvocationTargetException ex){
                Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);            
                throw new SystemException(ex);
                
            }catch(Exception ex){
                Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
                FacesContext.getCurrentInstance().addMessage("messages", new FacesMessage(FacesMessage.SEVERITY_ERROR, "エラー", "かきくけこ"));
                throw new SystemException(ex);
            }
            
            // メッセージ出力
            //MsgExec.message(messageData);

            // 初期化後にポップアップ用に印刷情報を設定
            if(popupBean.getPopupValues().containsKey("PrintInfo")) {
                popupBean.getPopupValues().get("PrintInfo").clear();
            } 
            Map<String,Object> mapValues = new HashMap();
            Map<String, Map<String, Object>> popUpValues = new HashMap();
            this.getSvfData().setSvfBizClass(strCls);
            this.getSvfData().setSvfBizMethod(strMt);
            mapValues.put("svfData", this.getSvfData());
            popUpValues.put("PrintInfo", mapValues);        
            popupBean.setPopupValues(popUpValues);
            popupBean.setPouUpOpenFlag(true); 
            
            //「直接印刷」、「印刷設定画面」、「プレビュー」のどれかパラメータで返す
            RequestContext context = RequestContext.getCurrentInstance();
            if (svfData.isPrevFlag() == false && svfData.isPrinterSetFlag() == false) {
                // 印刷確認画面
                ptn = "print";
            } else {
                // 印刷設定、プレビュー画面
                ptn = "printSetting";
            }
            context.addCallbackParam("ptn", ptn);

        }
    
        return ret;
    }

    /**
     * ファイルアップロード(PrimeFacesのファイルアップロードを使用)
     * @param event
     * @throws java.io.IOException
     */
    public void fileUpload(FileUploadEvent event) throws IOException, Exception {
        
        MessageDataModel messageData = new MessageDataModel();
        UpLoadFileDataModel upModel = new UpLoadFileDataModel();
        InputStream inputStr = null;
        String fileName;

        try{
            // ファイル情報を取得(マルチ対応)
            List<UploadedFile> uploadFiles = new LinkedList<UploadedFile>();
            uploadFiles.add(event.getFile());

            // アップロードしたファイル数分対応
            for(int i=0; i<uploadFiles.size(); i++) {
                // ストリーム情報を取得
                fileName = FilenameUtils.getName(uploadFiles.get(i).getFileName());
                inputStr = uploadFiles.get(i).getInputstream();
                upModel.setFileStream(inputStr);
                upModel.setFilePath(fileName);
                upLoadFileStream.add(upModel);

            }   
            
        }catch(Exception ex){
            messageData.addFacesMessage(ReportConst.MsgType.MSGTYPE_FATAL, "異常", ex.getMessage());
            throw new SystemException(ex);  
        }
        
        messageData.addFacesMessage(ReportConst.MsgType.MSGTYPE_INFO, "正常", "アップロード完了");
        MsgExec.message(messageData);
 
    }
/* まとめてアップロード 後で削除します*/
    public void allUpload() throws IOException, Exception {
        MessageDataModel messageData = new MessageDataModel();
        
        try {
            String directory = ExternalServiceProperty.getInstance().getProperty("upload-tmp-dir"); // ファイル置き場

            // ストリームの情報を全てアップロード
            for(UpLoadFileDataModel ufs : getUpLoadFileStream()) {
                 File destFile = new File(directory, ufs.getFilePath());
                 FileUtils.copyInputStreamToFile(ufs.getFileStream(), destFile);
            }
            
        } catch(Exception ex) {
            messageData.addFacesMessage(ReportConst.MsgType.MSGTYPE_FATAL, "異常", ex.getMessage());
            throw new SystemException(ex);       
        }
        
        // アップロード情報をクリア
        this.upLoadFileStream.clear();
        
    }    
    public void upload() {
            FacesMessage message = new FacesMessage("Succesful", " is uploaded.");
            FacesContext.getCurrentInstance().addMessage(null, message);

    }  

      /**
     * エクセル出力前処理 
     * @param document
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException
     */      
    public void preProcessXLS(Object document) throws SystemException {

        MessageDataModel messageData = new MessageDataModel();

        // 画面からクラス、メソッド、オブジェクトの受け取る
        if(!StringUtils.defaultString(viewClass).equals("") && !StringUtils.defaultString(viewMethod).equals("")){

            try{
                // クラスのインスタンスを作成してメソッドを実行
                Class<?> cls;
                cls = Class.forName(ExternalServiceProperty.getInstance().getProperty("businesssource") + viewClass);
                Object obj = cls.newInstance();

                Method mt;
                mt = cls.getMethod(viewMethod, this.getClass(), document.getClass(), messageData.getClass());
                mt.invoke(obj, this, document, messageData);

            }catch(ClassNotFoundException 
                    | IllegalAccessException
                    | IllegalArgumentException 
                    | InstantiationException 
                    | NoSuchMethodException
                    | InvocationTargetException
                    | SecurityException ex){
                Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
                throw new SystemException(ex);
            }

            // メッセージ出力
            MsgExec.message(messageData);
        }
    }

     /**
     * エクセル出力後処理 
     * @param document
     */    
    public void postProcessXLS(Object document) {
        //後処理を記載
      
    }
    
     /**
     * eventが引数設定できない処理にクラスとメソッドを設定
     * @param event
     */    
    public void setClassMethod(FacesEvent event) {
       Map<String, Object> eventmap = event.getComponent().getAttributes();
            viewClass = (String)eventmap.get("cls");
            viewMethod = (String)eventmap.get("method");      
    }
    
     /**
     * @return the menuBean
     */
    public MenuBean getMenuBean() {
        return menuBean;
    }

    /**
     * @param menuBean the menuBean to set
     */
    public void setMenuBean(MenuBean menuBean) {
        this.menuBean = menuBean;
    }

    /**
     * @return the authConf
     */
    public AuthorityConfBean getAuthConf() {
        return authConf;
    }

    /**
     * @param authConf the authConf to set
     */
    public void setAuthConf(AuthorityConfBean authConf) {
        this.authConf = authConf;
    }

    /**
     * @return the ssconfig
     */
    public JsfSatteliteApplicationBean getSsconfig() {
        return ssconfig;
    }

    /**
     * @param ssconfig the ssconfig to set
     */
    public void setSsconfig(JsfSatteliteApplicationBean ssconfig) {
        this.ssconfig = ssconfig;
    }

    /**
     * @return the breadCrumbBean
     */
    public BreadCrumbBean getBreadCrumbBean() {
        return breadCrumbBean;
    }

    /**
     * @param breadCrumbBean the breadCrumbBean to set
     */
    public void setBreadCrumbBean(BreadCrumbBean breadCrumbBean) {
        this.breadCrumbBean = breadCrumbBean;
    }

    /**
     * @return the config
     */
    public ReportConfig getConfig() {
        return config;
    }

    /**
     * @param config the config to set
     */
    public void setConfig(ReportConfig config) {
        this.config = config;
    }

    /**
     * @return the oldConfig
     */
    public ReportConfig getOldConfig() {
        return oldConfig;
    }

    /**
     * @param oldConfig the oldConfig to set
     */
    public void setOldConfig(ReportConfig oldConfig) {
        this.oldConfig = oldConfig;
    }

    /**
     * @return the defConds
     */
    public Map<String, Object> getDefConds() {
        return defConds;
    }

    /**
     * @param defConds the defConds to set
     */
    public void setDefConds(Map<String, Object> defConds) {
        this.defConds = defConds;
    }

    /**
     * @return the maintConfig
     */
    public ReportConfig getMaintConfig() {
        return maintConfig;
    }

    /**
     * @param maintConfig the maintConfig to set
     */
    public void setMaintConfig(ReportConfig maintConfig) {
        this.maintConfig = maintConfig;
    }

    /**
     * @return the oldMaintConfig
     */
    public ReportConfig getOldMaintConfig() {
        return oldMaintConfig;
    }

    /**
     * @param oldMaintConfig the oldMaintConfig to set
     */
    public void setOldMaintConfig(ReportConfig oldMaintConfig) {
        this.oldMaintConfig = oldMaintConfig;
    }

    /**
     * @return the testText
     */
    public String getTestText() {
        return testText;
    }

    /**
     * @param testText the testText to set
     */
    public void setTestText(String testText) {
        this.testText = testText;
    }

    /**
     * @return the r
     */
    public String getR() {
        return r;
    }

    /**
     * @param r the r to set
     */
    public void setR(String r) {
        this.r = r;
    }

    /**
     * @return the isSearch
     */
    public String getIsSearch() {
        return isSearch;
    }

    /**
     * @param isSearch the isSearch to set
     */
    public void setIsSearch(String isSearch) {
        this.isSearch = isSearch;
    }

    /**
     * @return the isTrans
     */
    public String getIsTrans() {
        return isTrans;
    }

    /**
     * @param isTrans the isTrans to set
     */
    public void setIsTrans(String isTrans) {
        this.isTrans = isTrans;
    }

    /**
     * @return the curXhtml
     */
    public String getCurXhtml() {
        return curXhtml;
    }

    /**
     * @param curXhtml the curXhtml to set
     */
    public void setCurXhtml(String curXhtml) {
        this.curXhtml = curXhtml;
    }

    /**
     * @return the editMode
     */
    public String getEditMode() {
        return editMode;
    }

    /**
     * @param editMode the editMode to set
     */
    public void setEditMode(String editMode) {
        this.editMode = editMode;
    }

    /**
     * @return the editModeTemp
     */
    public String getEditModeTemp() {
        return editModeTemp;
    }

    /**
     * @param editModeTemp the editModeTemp to set
     */
    public void setEditModeTemp(String editModeTemp) {
        this.editModeTemp = editModeTemp;
    }

    /**
     * @return the reportResult
     */
    public Map<String, List<Map<String, Object>>> getReportResult() {
        return reportResult;
    }

    /**
     * @param reportResult the reportResult to set
     */
    public void setReportResult(Map<String, List<Map<String, Object>>> reportResult) {
        this.reportResult = reportResult;
    }

    /**
     * @return the oldReportResult
     */
    public Map<String, List<Map<String, Object>>> getOldReportResult() {
        return oldReportResult;
    }

    /**
     * @param oldReportResult the oldReportResult to set
     */
    public void setOldReportResult(Map<String, List<Map<String, Object>>> oldReportResult) {
        this.oldReportResult = oldReportResult;
    }

    /**
     * @return the visibleFilter
     */
    public Map<String, List<Boolean>> getVisibleFilter() {
        return visibleFilter;
    }

    /**
     * @param visibleFilter the visibleFilter to set
     */
    public void setVisibleFilter(Map<String, List<Boolean>> visibleFilter) {
        this.visibleFilter = visibleFilter;
    }

    /**
     * @return the selectableResult
     */
    public ReportListDataModel getSelectableResult() {
        return selectableResult;
    }

    /**
     * @param selectableResult the selectableResult to set
     */
    public void setSelectableResult(ReportListDataModel selectableResult) {
        this.selectableResult = selectableResult;
    }

    /**
     * @return the oldSelectableResult
     */
    public ReportListDataModel getOldSelectableResult() {
        return oldSelectableResult;
    }

    /**
     * @param oldSelectableResult the oldSelectableResult to set
     */
    public void setOldSelectableResult(ReportListDataModel oldSelectableResult) {
        this.oldSelectableResult = oldSelectableResult;
    }

    /**
     * @return the oldColumnList
     */
    public List<ReportColumn> getOldColumnList() {
        return oldColumnList;
    }

    /**
     * @param oldColumnList the oldColumnList to set
     */
    public void setOldColumnList(List<ReportColumn> oldColumnList) {
        this.oldColumnList = oldColumnList;
    }

    /**
     * @return the contextResult
     */
    public Map<String, List<Map<String, Object>>> getContextResult() {
        return contextResult;
    }

    /**
     * @param contextResult the contextResult to set
     */
    public void setContextResult(Map<String, List<Map<String, Object>>> contextResult) {
        this.contextResult = contextResult;
    }

    /**
     * @return the contextMenuResult
     */
    public ReportListDataModel getContextMenuResult() {
        return contextMenuResult;
    }

    /**
     * @param contextMenuResult the contextMenuResult to set
     */
    public void setContextMenuResult(ReportListDataModel contextMenuResult) {
        this.contextMenuResult = contextMenuResult;
    }

    /**
     * @return the contextTableResult
     */
    public ReportListDataModel getContextTableResult() {
        return contextTableResult;
    }

    /**
     * @param contextTableResult the contextTableResult to set
     */
    public void setContextTableResult(ReportListDataModel contextTableResult) {
        this.contextTableResult = contextTableResult;
    }

    /**
     * @return the columnLists
     */
    public ReportListDataModel getColumnLists() {
        return columnLists;
    }

    /**
     * @param columnLists the columnLists to set
     */
    public void setColumnLists(ReportListDataModel columnLists) {
        this.columnLists = columnLists;
    }

    /**
     * @return the optionLists
     */
    public Map<String, List> getOptionLists() {
        return optionLists;
    }

    /**
     * @param optionLists the optionLists to set
     */
    public void setOptionLists(Map<String, List> optionLists) {
        this.optionLists = optionLists;
    }

    /**
     * @return the selectableTreeResult
     */
    public ReportListTreeDataModel getSelectableTreeResult() {
        return selectableTreeResult;
    }

    /**
     * @param selectableTreeResult the selectableTreeResult to set
     */
    public void setSelectableTreeResult(ReportListTreeDataModel selectableTreeResult) {
        this.selectableTreeResult = selectableTreeResult;
    }

    /**
     * @return the selectableResults
     */
    public Map<String, ReportListDataModel> getSelectableResults() {
        return selectableResults;
    }

    /**
     * @param selectableResults the selectableResults to set
     */
    public void setSelectableResults(Map<String, ReportListDataModel> selectableResults) {
        this.selectableResults = selectableResults;
    }

    /**
     * @return the selectedNodes
     */
    public TreeNode[] getSelectedNodes() {
        return selectedNodes;
    }

    /**
     * @param selectedNodes the selectedNodes to set
     */
    public void setSelectedNodes(TreeNode[] selectedNodes) {
        this.selectedNodes = selectedNodes;
    }

    /**
     * @return the selectReportResult
     */
    public List<Map<String, Object>> getSelectReportResult() {
        return selectReportResult;
    }

    /**
     * @param selectReportResult the selectReportResult to set
     */
    public void setSelectReportResult(List<Map<String, Object>> selectReportResult) {
        this.selectReportResult = selectReportResult;
    }

    /**
     * @return the oldSelectReportResult
     */
    public List<Map<String, Object>> getOldSelectReportResult() {
        return oldSelectReportResult;
    }

    /**
     * @param oldSelectReportResult the oldSelectReportResult to set
     */
    public void setOldSelectReportResult(List<Map<String, Object>> oldSelectReportResult) {
        this.oldSelectReportResult = oldSelectReportResult;
    }

    /**
     * @return the selectEditReportResult
     */
    public Map<String, List<Map<String, Object>>> getSelectEditReportResult() {
        return selectEditReportResult;
    }

    /**
     * @param selectEditReportResult the selectEditReportResult to set
     */
    public void setSelectEditReportResult(Map<String, List<Map<String, Object>>> selectEditReportResult) {
        this.selectEditReportResult = selectEditReportResult;
    }

    /**
     * @return the reportSidebarResult
     */
    public Map<String, List<Map<String, Object>>> getReportSidebarResult() {
        return reportSidebarResult;
    }

    /**
     * @param reportSidebarResult the reportSidebarResult to set
     */
    public void setReportSidebarResult(Map<String, List<Map<String, Object>>> reportSidebarResult) {
        this.reportSidebarResult = reportSidebarResult;
    }

    /**
     * @return the selectMaster
     */
    public String getSelectMaster() {
        return selectMaster;
    }

    /**
     * @param selectMaster the selectMaster to set
     */
    public void setSelectMaster(String selectMaster) {
        this.selectMaster = selectMaster;
    }

    /**
     * @return the oldSelectMaster
     */
    public String getOldSelectMaster() {
        return oldSelectMaster;
    }

    /**
     * @param oldSelectMaster the oldSelectMaster to set
     */
    public void setOldSelectMaster(String oldSelectMaster) {
        this.oldSelectMaster = oldSelectMaster;
    }

    /**
     * @return the condMaster
     */
    public AbstractReportCondition getCondMaster() {
        return condMaster;
    }

    /**
     * @param condMaster the condMaster to set
     */
    public void setCondMaster(AbstractReportCondition condMaster) {
        this.condMaster = condMaster;
    }

    /**
     * @return the sortVal
     */
    public List<Map<String, Object>> getSortVal() {
        return sortVal;
    }

    /**
     * @param sortVal the sortVal to set
     */
    public void setSortVal(List<Map<String, Object>> sortVal) {
        this.sortVal = sortVal;
    }

    /**
     * @return the selectedSort
     */
    public String getSelectedSort() {
        return selectedSort;
    }

    /**
     * @param selectedSort the selectedSort to set
     */
    public void setSelectedSort(String selectedSort) {
        this.selectedSort = selectedSort;
    }

    /**
     * @return the execButton
     */
    public ReportButton getExecButton() {
        return execButton;
    }

    /**
     * @param execButton the execButton to set
     */
    public void setExecButton(ReportButton execButton) {
        this.execButton = execButton;
    }

    /**
     * @return the selectedPdf
     */
    public Map<String, ReportPdfGroup> getSelectedPdf() {
        return selectedPdf;
    }

    /**
     * @param selectedPdf the selectedPdf to set
     */
    public void setSelectedPdf(Map<String, ReportPdfGroup> selectedPdf) {
        this.selectedPdf = selectedPdf;
    }

    /**
     * @return the uploadFiles
     */
    public List<File> getUploadFiles() {
        return uploadFiles;
    }

    /**
     * @param uploadFiles the uploadFiles to set
     */
    public void setUploadFiles(List<File> uploadFiles) {
        this.uploadFiles = uploadFiles;
    }

    /**
     * @return the externalAttribute
     */
    public Map<String, Object> getExternalAttribute() {
        return externalAttribute;
    }

    /**
     * @param externalAttribute the externalAttribute to set
     */
    public void setExternalAttribute(Map<String, Object> externalAttribute) {
        this.externalAttribute = externalAttribute;
    }

    /**
     * @return the idBind
     */
    public Map<String, UIComponent> getIdBind() {
        return idBind;
    }

    /**
     * @param idBind the idBind to set
     */
    public void setIdBind(Map<String, UIComponent> idBind) {
        this.idBind = idBind;
    }

    /**
     * @return the values
     */
    public Map<String, Map<String, Object>> getValues() {
        return values;
    }

    /**
     * @param values the values to set
     */
    public void setValues(Map<String, Map<String, Object>> values) {
        this.values = values;
    }

    /**
     * @return the oldValues
     */
    public Map<String, Map<String, Object>> getOldValues() {
        return oldValues;
    }

    /**
     * @param oldValues the oldValues to set
     */
    public void setOldValues(Map<String, Map<String, Object>> oldValues) {
        this.oldValues = oldValues;
    }

    /**
     * @return the selectedLine
     */
    public Map<String, Object> getSelectedLine() {
        return selectedLine;
    }

    /**
     * @param selectedLine the selectedLine to set
     */
    public void setSelectedLine(Map<String, Object> selectedLine) {
        this.selectedLine = selectedLine;
    }

    /**
     * @return the listValues
     */
    public Map<String, List<Map<String, Object>>> getListValues() {
        return listValues;
    }

    /**
     * @param listValues the listValues to set
     */
    public void setListValues(Map<String, List<Map<String, Object>>> listValues) {
        this.listValues = listValues;
    }

    /**
     * @return the dialogParams
     */
    public List<Map<String, String>> getDialogParams() {
        return dialogParams;
    }

    /**
     * @param dialogParams the dialogParams to set
     */
    public void setDialogParams(List<Map<String, String>> dialogParams) {
        this.dialogParams = dialogParams;
    }

    /**
     * @return the targetServices
     */
    public List<Map<String, Object>> getTargetServices() {
        return targetServices;
    }

    /**
     * @param targetServices the targetServices to set
     */
    public void setTargetServices(List<Map<String, Object>> targetServices) {
        this.targetServices = targetServices;
    }

    /**
     * @return the wayOfUpload
     */
    public String getWayOfUpload() {
        return wayOfUpload;
    }

    /**
     * @param wayOfUpload the wayOfUpload to set
     */
    public void setWayOfUpload(String wayOfUpload) {
        this.wayOfUpload = wayOfUpload;
    }

    /**
     * @return the uploadStatuses
     */
    public Map<String,Object> getUploadStatuses() {
        return uploadStatuses;
    }

    /**
     * @param uploadStatuses the uploadStatuses to set
     */
    public void setUploadStatuses(Map<String,Object> uploadStatuses) {
        this.uploadStatuses = uploadStatuses;
    }

    /**
     * @return the uploadFileDef
     */
    public List<Map<String, Object>> getUploadFileDef() {
        return uploadFileDef;
    }

    /**
     * @param uploadFileDef the uploadFileDef to set
     */
    public void setUploadFileDef(List<Map<String, Object>> uploadFileDef) {
        this.uploadFileDef = uploadFileDef;
    }

    /**
     * @return the uploadFileName
     */
    public List<String> getUploadFileName() {
        return uploadFileName;
    }

    /**
     * @param uploadFileName the uploadFileName to set
     */
    public void setUploadFileName(List<String> uploadFileName) {
        this.uploadFileName = uploadFileName;
    }

    /**
     * @return the headerName
     */
    public String getHeaderName() {
        return headerName;
    }

    /**
     * @param headerName the headerName to set
     */
    public void setHeaderName(String headerName) {
        this.headerName = headerName;
    }

    /**
     * @return the isChange
     */
    public String getIsChange() {
        return isChange;
    }

    /**
     * @param isChange the isChange to set
     */
    public void setIsChange(String isChange) {
        this.isChange = isChange;
    }

    /**
     * @return the parentWindowSize
     */
    public String getParentWindowSize() {
        return parentWindowSize;
    }

    /**
     * @param parentWindowSize the parentWindowSize to set
     */
    public void setParentWindowSize(String parentWindowSize) {
        this.parentWindowSize = parentWindowSize;
    }

    /**
     * @return the handsontableVal
     */
    public String getHandsontableVal() {
        return handsontableVal;
    }

    /**
     * @param handsontableVal the handsontableVal to set
     */
    public void setHandsontableVal(String handsontableVal) {
        this.handsontableVal = handsontableVal;
    }

    /**
     * @return the objectValues
     */
    public ArrayList<Object> getObjectValues() {
        return objectValues;
    }

    /**
     * @param objectValues the objectValues to set
     */
    public void setObjectValues(ArrayList<Object> objectValues) {
        this.objectValues = objectValues;
    }

    /**
     * @return the oldObjectValues
     */
    public ArrayList<Object> getOldObjectValues() {
        return oldObjectValues;
    }

    /**
     * @param oldObjectValues the oldObjectValues to set
     */
    public void setOldObjectValues(ArrayList<Object> oldObjectValues) {
        this.oldObjectValues = oldObjectValues;
    }
    
    /**
     * columnTogglerが実行されたときに呼び出されます。
     * カラムのvisibleを更新します。
     */
    public void onToggle(org.primefaces.event.ToggleEvent e) {
        //ReportColumn rmod = config.getModification().getColumns().get((Integer)e.getData());
        //rmod.setVisible(e.getVisibility() == org.primefaces.model.Visibility.VISIBLE);
    }

    /**
     * @return the svfData
     */
    public SvfDataModel getSvfData() {
        return svfData;
    }

    /**
     * @param svfData the svfData to set
     */
    public void setSvfData(SvfDataModel svfData) {
        this.svfData = svfData;
    }
	
    // 一覧画面の履歴表示処理
    // タスクの割り込みにより開発途中
    public void showHistoryPopup(FacesEvent event) throws SystemException, LogicException{
        
        // ポップアップ表示許可初期化
        config.setShowPopupFlag(false);
        
        // 複数行が選択されている場合エラーメッセージを表示する
        if(selectReportResult.size() > 1){
            new MsgExec().message("ERROR", "エラー", "複数行が選択されています。");
            return;
        }
        
        // 選択行の情報を元に履歴情報を取得
        Map<String ,Object> attribute = event.getComponent().getAttributes();
        String componentId = attribute.get("component_id").toString();
        
        ReportSql target = new ReportSql();
        target.setName("HISTORY");
        target.setFunctionCode(componentId);
        target.setEditModeName("SEARCH");
        List<Map<String, Object>> resultlist = this.callSql(target, selectReportResult.get(0));
        
        // 取得結果が0件の場合エラーメッセージを表示する
        if(resultlist.isEmpty()){
            new MsgExec().message("ERROR", "エラー", "履歴がありません。");
            return;
        }
        // ポップアップ画面表示用情報の設定
        List<Map<String, String>> historyMapList = new ArrayList();
        for(Map<String, Object> paramMap: resultlist){
            Map <String, String> historyMap = new HashMap();
            historyMapList.add(historyMap);
            for(Map.Entry<String, Object> param: paramMap.entrySet()){
                historyMap.put(param.getKey(), param.getValue().toString());
            }
        }        
        Map<String, Object> mapValues = new HashMap();
        mapValues.put("HistoryValues", historyMapList);
        Map<String, Map<String, Object>> popupValues = new HashMap();
        popupValues.put("HistoryForList", mapValues);
        popupBean.setPopupValues(popupValues);
        popupBean.setPouUpOpenFlag(true);
        
        // ポップアップ表示許可
        config.setShowPopupFlag(true);
    } 
    
    /**
     * <p>新規登録ボタン処理
     * <br>パターンC画面:共通ファンクション
     * <p>単票明細部分の初期化処理を行う。
     * <br>パラメータに"cls","method"が含まれている場合、
     * <br>初期化処理後に該当メソッドの呼び出しを行う。
     * @param event
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException 
     */
    public void createNewPage(FacesEvent event) throws SystemException{

        // 単票明細部の初期化処理
        PageViewDefault pageViewDefault = new PageViewDefault();
        pageViewDefault.setModification(values, config);

        // 個別処理呼び出し
        callBusinessLogic(event);
    }
    	
    /**
     * <p>複写ボタン処理
     * <br>パターンC画面:共通ファンクション
     * <p>単票明細部分のPK項目処理を行う。
     * <br>パラメータに"cls","method"が含まれている場合、
     * <br>初期化処理後に該当メソッドの呼び出しを行う。
     * @param event
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException 
     */
    public void copyNewPage(FacesEvent event) throws SystemException{
        
        // 単票明細部分のPK項目の初期化
        PageViewDefault pageViewDefault = new PageViewDefault();
        pageViewDefault.setPkModification(values, config);
        //config.getModification().getPkList().forEach((reportConfig) -> values.get(reportConfig.getApplyTo()).put(reportConfig.getName(), ""));

        // 個別処理呼び出し
        callBusinessLogic(event);
    }
    
    /**
     * <p>SQL実行ボタン処理
     * <br>パターンC画面：共通ファンクション
     * <p>ボタンに紐づくFanctionCOdeをコンポーネントに持つServiceを実行する。
     * <br>パラメータとして画面入力情報をMap形式で引き渡す
     * @param event
     * @throws SystemException
     * @throws LogicException 
     */
    public void executeUpdateForSingleReport(FacesEvent event) throws SystemException, LogicException{
        
        // 業務個別ロジック呼び出し
        callBusinessLogic(event);   

        // 実行ボタン情報の取得
        Map<String ,Object> attribute = event.getComponent().getAttributes();
        ReportButton btn = (ReportButton)attribute.get("btn");

        // 更新対象データの取得
        ReportSql targetDef = buttonActGetReportSql(event);
        Map<String, Object> targetValues = values.get(targetDef.getName());

        //更新処理
        ReportSql target = new ReportSql();
        target.setName(btn.getName());
        target.setFunctionCode(btn.getFunctionCode());
        target.setEditModeName(btn.getAction());
        this.callSql(target, targetValues);
    }
    	
    /**
     * <p>履歴サイドバー表示時イベント
     * <p>履歴表示モードへの切り替えと、個別処理の呼び出しを行う。
     * @param event 
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException 
     */
    public void showHistorySidebar(FacesEvent event) throws SystemException{
        
        // 画面入力情報の保持 
        setOldValues(getValues());
        //TODO -> values以外にデータが紐づいているコンポーネントを未考慮
        
        // 個別処理の呼び出し
        callBusinessLogic(event);
    }
	

    /**
     * @return the popupBean
     */
    public PopUpDeliveryBean getPopupBean() {
        return popupBean;
    }

    /**
     * @param popupBean the popupBean to set
     */
    public void setPopupBean(PopUpDeliveryBean popupBean) {
        this.popupBean = popupBean;
    }

    /**
     * @return the upLoadFileStream
     */
    public ArrayList<UpLoadFileDataModel> getUpLoadFileStream() {
        return upLoadFileStream;
    }

    /**
     * @param upLoadFileStream the upLoadFileStream to set
     */
    public void setUpLoadFileStream(ArrayList<UpLoadFileDataModel> upLoadFileStream) {
        this.upLoadFileStream = upLoadFileStream;
    }

    /**
     * @return the file
     */
    public UploadedFile getFile() {
        return file;
    }

    /**
     * @param file the file to set
     */
    public void setFile(UploadedFile file) {
        this.file = file;
    }
    
    public void revocationPopupDate(FacesEvent event){
        // 選択行の情報を元に履歴情報を取得
        Map<String ,Object> attribute = event.getComponent().getAttributes();
        String param = attribute.get("keyName").toString();
        //String param = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("keyName");
        popupBean.getPopupValues().remove(param);
        if(popupBean.getPopupValues().isEmpty()){
            popupBean.setPouUpOpenFlag(false);
        }
    }

    /**
     * 祝日リスト(JSON)を読み込み、画面側に戻す
     */
    public void getHolidays(){
        File inputFile = new File(holidayFilePath);
        BufferedReader bufferedReader;
        try {
            bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputFile)));
            StringBuilder stringBuilder = new StringBuilder();
            int val;
            while ((val = bufferedReader.read()) != -1) {
                stringBuilder.append((char) val);
            }

            RequestContext context = RequestContext.getCurrentInstance();
            context.addCallbackParam("data", stringBuilder.toString());

        } catch (FileNotFoundException ex) {
            java.util.logging.Logger.getLogger(JsfSatteliteApplicationBean.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(JsfSatteliteApplicationBean.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }

    /**
     * @return the viewClass
     */
    public String getViewClass() {
        return viewClass;
    }

    /**
     * @param viewClass the viewClass to set
     */
    public void setViewClass(String viewClass) {
        this.viewClass = viewClass;
    }

    /**
     * @return the viewMethod
     */
    public String getViewMethod() {
        return viewMethod;
    }

    /**
     * @param viewMethod the viewMethod to set
     */
    public void setViewMethod(String viewMethod) {
        this.viewMethod = viewMethod;
    }

   /**
     * 画面側から呼び出され、営業日カレンダーマスタの内容でholidays.jsonを更新する
     * 
     * @param event
     * @throws Exception 
     */
    public void callGetHolidays(FacesEvent event) throws Exception {
        Map<String ,Object> attribute = event.getComponent().getAttributes();
        ReportButton btn = (ReportButton)attribute.get("btn");

        //更新処理
        ReportSql targetDef = new ReportSql();
        targetDef.setName(btn.getName());
        targetDef.setFunctionCode(btn.getFunctionCode());

        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        
        Map<String, Map<String, Object>> paramsmap = new PageParameterGetter().getParamMap(values, config);
        Map<String, Object> formParams = paramsmap.get(config.getSqls().get(0).getName());

        target.put(ExternalServiceExecuter.E_SERVICE_NAME, "calender");
        target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
        target.put(ExternalServiceExecuter.E_FUNCTION, btn.getFunctionCode());
        target.put(ExternalServiceExecuter.E_SQL, "getHolidays");
        target.put(ExternalServiceExecuter.P_SEND_PARAMETER, formParams);
        
        this.getTargetServices().add(target);
        
        //searchProcess();
        new ExternalServiceExecuterForHolidays().dbProcess(this);
    } 

    public String getHolidayFilePath(){
        return holidayFilePath;
    }
    
}
