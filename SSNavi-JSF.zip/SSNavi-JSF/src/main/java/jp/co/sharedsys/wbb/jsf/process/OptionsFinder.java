package jp.co.sharedsys.wbb.jsf.process;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;


import org.apache.commons.lang.StringUtils;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.wbb.jsf.exception.LogicException;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;
import jp.co.sharedsys.wbb.jsf.beans.AuthorityConfBean;
import jp.co.sharedsys.wbb.jsf.reports.AbstractReportOption;

import jp.co.sharedsys.wbb.jsf.reports.ReportConst;
import lombok.Getter;
import lombok.Setter;


public class OptionsFinder extends AbstractExternalProcess<AbstractReportOption> {

    private static final String P_EDIT_ACTIVITY_EXECUTE = "EXECUTE";
    private static final String P_EXEC_RES_STATUS_ATTRIBUTE = "execResStatus";

    @Setter
    private AuthorityConfBean authConf;
    @Getter
    private List<Map<String, Object>> searchResult;
    
    @Override
    public void onService(AbstractReportOption option) throws LogicException, SystemException {

        // 機能モード(SEARCH)
        String modeName = "SEARCH";

        String actName = P_EDIT_ACTIVITY_EXECUTE;

        // サービス呼出時パラメータ取得
//	List<Input> params = (List<Input>) parameter.getAttribute(pattribute);
	Map<String, String> request = new HashMap<>();
        if (option.getServiceParameter() != null && !option.getServiceParameter().isEmpty()) {
            List<String> params = Arrays.asList(option.getServiceParameter().split(","));
            for (int i = 0; i < params.size(); i++) {
                String in = params.get(i);
                request.put(String.valueOf(i), in);
            }
        }

	// ログイン情報取得
//	Map login = new HashMap();
//	login.put(SecurityUtils.TOKEN_UserCd, (SecurityToken) listUserCd.get(0));

	/** メイン処理 */
        Object inputParams = request;
        // サービス名取得
        String service = option.getService();
        String functionCode = option.getFunctionCode();
        String tableName = option.getTableName();
        /**** SSNavi : Service request ****/
        try {
            ServiceInterfaceBean dto = this.requestExternalService(service, inputParams, functionCode, tableName, authConf.getUserCd(), authConf.getUserGroup(), false);

            // Json結果データをMapに変換
            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> jsonResMap = null;

            if (StringUtils.equals(modeName, ReportConst.EditMode.SEARCH)) {
                try {
                    List searchResult = mapper.readValue(dto.getJson(), List.class);
                    this.searchResult = searchResult;
                } catch (IOException e) {
                    logger.error("サービス側から意図しないパラメータが返ってきています。");
                    logger.error(e.getMessage(), e);
//                    pageBean.getExternalAttribute().put(P_EXEC_RES_STATUS_ATTRIBUTE, "9");
//                    pageBean.getExternalAttribute().put(P_EXEC_RES_MSG_ATTRIBUTE, ReportConst.Msg.SYSTEM_ERROR);
                    return ;
                }
            }
        }catch (SystemException e) {
            logger.error(e.getMessage(), e);
//            pageBean.getExternalAttribute().put(P_EXEC_RES_STATUS_ATTRIBUTE, "9");
//            pageBean.getExternalAttribute().put(P_EXEC_RES_MSG_ATTRIBUTE, ReportConst.Msg.SYSTEM_ERROR);
        }
    }
}
