package jp.co.sharedsys.wbb.jsf.reports;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

public class ReportButton implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 6751792560974448363L;
    private String name = null;
    private String value = null;
    private String action = null;
    private String rptFile = null;
    private String rptDir = null;
    private String service = null;
    private String tabTitle = null;
    private String functionCode = null;

    @Getter @Setter
    protected List<AbstractReportOption> options = new ArrayList<>();
    @Getter @Setter
    protected List<AbstractReportOption> originalOptions = new ArrayList<>();

    private List<ReportPdfGroup> pdfGroups = new ArrayList<ReportPdfGroup>();;
    private String position = null;

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getValue() {
        return value;
    }
    public void setValue(String value) {
        this.value = value;
    }
    public String getAction() {
        return action;
    }
    public void setAction(String action) {
        this.action = action;
    }
    public String getRptFile() {
        return rptFile;
    }
    public void setRptFile(String rptFile) {
        this.rptFile = rptFile;
    }
    public String getRptDir() {
        return rptDir;
    }
    public void setRptDir(String rptDir) {
        this.rptDir = rptDir;
    }
    public String getService() {
        return service;
    }
    public void setService(String service) {
        this.service = service;
    }
    public String getTabTitle() {
        return tabTitle;
    }
    public void setTabTitle(String tabTitle) {
        this.tabTitle = tabTitle;
    }
    public List<ReportPdfGroup> getPdfGroups() {
        return pdfGroups;
    }
    public void setPdfGroups(List<ReportPdfGroup> pdfGroups) {
        this.pdfGroups = pdfGroups;
    }
    public String getPosition() {
        return position;
    }
    public void setPosition(String position) {
        this.position = position;
    }
    public void setFunctionCode(String functionCode) {
        this.functionCode = functionCode;
    }

    public String getFunctionCode() {
        return functionCode;
    }

    
    public List<AbstractReportOption> splitButtons() {
        List<AbstractReportOption> filtered = new ArrayList<>();
        for (AbstractReportOption option : options) {
//          if (option.getLabel().contains(query)) {
                filtered.add(option);
//          }
        }
        return filtered;
    }
}
