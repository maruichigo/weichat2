package jp.co.sharedsys.wbb.jsf.reports;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ReportPdfGroup implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 5884430387525067476L;
    private String name = null;
    private String description = null;
    private List<ReportPdfConfig> pdfs = new ArrayList<ReportPdfConfig>();
    private String selected = null;

    private String afterExecService = null;

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public List<ReportPdfConfig> getPdfs() {
        return pdfs;
    }
    public void setPdfs(List<ReportPdfConfig> pdfs) {
        this.pdfs = pdfs;
    }
    public String getSelected() {
        return selected;
    }
    public void setSelected(String selected) {
        this.selected = selected;
    }
    public String getAfterExecService() {
        return afterExecService;
    }
    public void setAfterExecService(String afterExecService) {
        this.afterExecService = afterExecService;
    }
}
