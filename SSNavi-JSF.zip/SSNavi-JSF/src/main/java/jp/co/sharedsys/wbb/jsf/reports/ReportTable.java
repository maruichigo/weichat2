package jp.co.sharedsys.wbb.jsf.reports;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ReportTable implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 8855882081161240878L;
    private String position;
    private List<List<List<AbstractReportCondition>>> lines = new ArrayList<>();
    public String getPosition() {
        return position;
    }
    public void setPosition(String position) {
        this.position = position;
    }
    public List<List<List<AbstractReportCondition>>> getLines() {
        return lines;
    }
    public void setLines(List<List<List<AbstractReportCondition>>> lines) {
        this.lines = lines;
    }
}
