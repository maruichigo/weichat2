package jp.co.sharedsys.wbb.jsf.reports;

public class ReportColumnOption extends AbstractReportOption {
	/**
	 * 
	 */
	private static final long serialVersionUID = 91526818894842054L;
}
