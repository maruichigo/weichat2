package jp.co.sharedsys.wbb.jsf.conf;

import lombok.Data;

@Data
public class XReportColumnOption {
    private String label = "";
    private String value = "";
    private String checked = "";
    private String connection = "";
    private String templateFile = "";
    private String service;
    private String functionCode;
    private String serviceParameter;   
}
