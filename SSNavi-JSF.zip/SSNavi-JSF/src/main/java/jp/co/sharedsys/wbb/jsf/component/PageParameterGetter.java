/*
 * PageParameterGetter.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.component;
import java.util.LinkedHashMap;
import java.util.Map;
import jp.co.sharedsys.wbb.jsf.reports.ReportConfig;
import java.util.*;
import jp.co.sharedsys.wbb.jsf.reports.ReportColumn;
import jp.co.sharedsys.wbb.jsf.reports.ReportCondition;
import jp.co.sharedsys.wbb.jsf.reports.ReportConfig;
import javax.faces.context.FacesContext;
import javax.faces.application.FacesMessage;
import javax.faces.event.FacesEvent;
import jp.co.sharedsys.wbb.jsf.beans.ReportListTreeDataModel;
import jp.co.sharedsys.wbb.jsf.reports.AbstractReportOption;
import org.apache.commons.lang3.StringUtils;
import jp.co.sharedsys.wbb.jsf.reports.AbstractReportCondition;
import jp.co.sharedsys.wbb.jsf.reports.ReportSql;
import jp.co.sharedsys.wbb.jsf.util.bean.PagePropertiesBean;
import org.primefaces.model.TreeNode;
import jp.co.sharedsys.wbb.jsf.beans.SSNaviManagedBean;
import jp.co.sharedsys.wbb.jsf.reports.ReportConst;

/**
 * 画面の情報を取得してparameterに格納する。 
 * @author s_furutani
 */
public class PageParameterGetter {
    
	private static String PKLISTKEY = "pklist";
	
    public PageParameterGetter(){
    }

	
    /**
     * 画面の情報を取得してparametermapを返却
     * @param values
     * @param config
     */
    public Map<String, Map<String, Object>> getParamMap(Map<String, Map<String, Object>> values , ReportConfig config){
        Map<String, Map<String, Object>> parammap = new HashMap<>();
 
        //該当しない場合に紐づけるSQLID;
        String defid = config.getDefaultSqlId();
 		initParamMap(parammap, defid, config);
		
        setReportCondition(parammap, defid, values , config);
		setPklist(parammap, defid, config);
        setModification(parammap, defid, values , config);
		
        return parammap;
    }
	
    /**
     * rptのconditions用
     * @param values
     * @param config 
     */
    public void setReportCondition(Map<String, Map<String, Object>> parammap, String defid, Map<String, Map<String, Object>> values , ReportConfig config){

        for (ReportCondition condition : config.getConditions()) {
            String applyto = condition.getApplyTo();
            if ((null == applyto || "".equals(applyto))
                || (!parammap.containsKey(applyto))){
                //一致しない場合はdefid;
                applyto = defid;
            }

            //一致するマップを取得
            Map<String, Object> param = parammap.get(applyto);
            Map<String, Object> valueit = values.get(applyto);
            String controltype = condition.getControlType();//rpt-control-type
            String datatype = condition.getDataType();//rpt-data-type
            String defval = condition.getDefaultValue();
            String name = condition.getName();
            List<AbstractReportOption> options = condition.getOptions();
            
            setParam(controltype, datatype, defval, name, options, condition, valueit, param);
            parammap.put(applyto, param);
        }
    }
    
    /**
     * rptのmodification用
     * @param values
     * @param config 
     */
    public void setModification(Map<String, Map<String, Object>> parammap, String defid, Map<String, Map<String, Object>> values , ReportConfig config){
		
		for (ReportColumn column : config.getModification().getColumns()){
            String applyto = column.getApplyTo();
            if ((null == applyto || "".equals(applyto))
                || (!parammap.containsKey(applyto))){
                //一致しない場合はdefid;
                applyto = defid;
            }
            //一致するマップを取得
            Map<String, Object> valueit = values.get(applyto);
            Map<String, Object> param = parammap.get(applyto);
            String controltype = column.getControlType();//rpt-control-type
            String datatype = column.getDataType();//rpt-data-type
            String defval = column.getDefaultValue();
            String name = column.getName();
            List<AbstractReportOption> options = column.getOptions();            
            AbstractReportCondition condition = (AbstractReportCondition)column;
            setParam(controltype, datatype, defval, name, options, condition, valueit, param);
			
			//テーブルのpkリスト
			if (column.isPk()){
				List<String> pklist;
				if (!param.containsKey(PKLISTKEY)){
					pklist = new ArrayList<>();//なければ新規作成
				} else {
					pklist = (List<String>)param.get(PKLISTKEY);
				}
				if (!pklist.contains(column.getName())){
					pklist.add(column.getName());
				}
				param.put(PKLISTKEY, pklist);
			}
            parammap.put(applyto, param);
        }
    }

    /**
     * valuitに返却するデータを返す
     * @param controltype
     * @param datatype
     * @param defval
     * @param name
     * @param options
     * @param condition
     * @param valueit
     * @param param 
     */
    private void setParam(String controltype, String datatype, String defval, String name,  List<AbstractReportOption> options,AbstractReportCondition condition, Map<String, Object> valueit, Map<String, Object> param){
        Object result = new Object();
        switch (controltype) { //除外するものはbreak
            case "HIDDEN":
                break;
            case "HTML":    
            case "LABEL":
                param.put(name, valueit.get(name));
                break;
            case "TEXT":
            case "TEXTAREA":
            case "RADIO":
                param.put(name, valueit.get(name));
                break;
            case "CHECKBOX": 
                if("SINGLE".equals(datatype)){
                    param.put(name,defval);
                } else if("MULTI".equals(datatype)){
                    //multiはstring[]の形と
                    param.put(name, condition.getItemValue()); 
                    //個別string形式(name_00,name_01)の形で受け取る。
                    for (AbstractReportOption op : condition.getOptions()) {
                        for (String itemValue : condition.getItemValue()) {
                            if (itemValue.equals(op.getValue())) {
                                param.put(condition.getName() + "_" +op.getValue(), itemValue);
                            }
                        }  
                    }                    
                } else {
                    param.put(name,defval);
                }
                break;
            case "SELECT_CHECKBOX_MENU": 
                //string[]の形と
                param.put(name, condition.getItemValue()); 
                //個別string形式(name_00,name_01)の形で受け取る。
                for (AbstractReportOption op : condition.getOptions()) {
                    for (String itemValue : condition.getItemValue()) {
                        if (itemValue.equals(op.getValue())) {
                            param.put(condition.getName() + "_" +op.getValue(), itemValue);
                        }
                    }  
                }                    
                break;   
            case "SELECT":  
            case "SELECT_DYNAMIC":      
            case "SELECT_MULTI":  
            case "DOUBLECOMBO_OUT":      
            case "DOUBLECOMBO_IN":   
                param.put(name, valueit.get(name));
                break;
            case "RANGE":    
            {
                String namestart = condition.getNameStart();
                String nameend = condition.getNameEnd();
                param.put(namestart, valueit.get(namestart));
                param.put(nameend, valueit.get(nameend));
            }
            break;
            case "BUTTON":
                break;
            case "POSTAL":
            case "TRANS":
            case "EDIT":
            case "SPLIT":
                param.put(name,defval);
                break;
            case "AUTOCOMPLETE":
            case "AUTOCOMPLETE_DYNAMIC":
            case "AUTOCOMPLETE_MULTI":
                param.put(name, valueit.get(name)); 
                break;                
            default:            
        }
    }
  
	/**
	 * 該当しない場合に紐づけるSQLIDの設定値
	 * @param config 
	 */
	public void setDefaultSqlid(ReportConfig config){
		//sqlidが未設定、または1件も取得できない場合、
		if (null == config.getSqls() || config.getSqls().size() == 0){
			config.setDefaultSqlId(ReportConst.F_APPLYTO);
		} else if (config.getSqls().size() == 1 && null == config.getSqls().get(0).getName()){
			//または1件しかなく、nameが未入力の場合
			config.setDefaultSqlId(ReportConst.F_APPLYTO);
		} else {
			config.setDefaultSqlId(config.getSqls().get(0).getName());
		}
	}
	
	/** パラメータの初期化処理 */
	private Map<String, Map<String, Object>> initParamMap(Map<String, Map<String, Object>> parammap, String defid, ReportConfig config){
		if (null == parammap){
			parammap = new HashMap<>();
		}
        for(ReportSql sql :config.getSqls()){
			String applyto = sql.getName();
			if (null == applyto){
				applyto = config.getDefaultSqlId();
			}
			if (!parammap.containsKey(applyto)){
				Map<String, Object> valuemap = new LinkedHashMap<>();
				parammap.put(applyto,valuemap);  
			}
        }
		if (0 == parammap.size()){
			Map<String, Object> valuemap = new LinkedHashMap<>();
			parammap.put(defid,valuemap);  
		}
		return parammap;
	}

	/** columnで指定したapplytoがsqlタグに存在するかどうかを調べる */
	public boolean checkApplyto(ReportConfig config, String sqlid){
		boolean flg = false;
		for (ReportCondition condition : config.getConditions()) {
            String applyto = condition.getApplyTo();
            if (sqlid.equals(applyto)) {
                flg = true;
            }
		}
		return flg;
	}

	/**
	 * テーブル部分(Modification)のPklistを取得
	 * @param config
	 * @return pklist =map,get(applyto)
	 */
	public Map<String, Map<String, Object>> getPklist(ReportConfig config){
		Map<String, Map<String, Object>> parammap = new HashMap<>();
		String defid = config.getDefaultSqlId();
		setPklist(parammap, defid, config);
		return parammap;
	}

	/**
	 * パラメーターにpkのlistを返却
	 * @param parammap
	 * @param defid
	 * @param config 
	 * @return Map<String, Map<String, Object>> parammap
	 */
	private void setPklist(Map<String, Map<String, Object>> parammap, String defid, ReportConfig config){
		initParamMap(parammap, defid, config);
		
		for (ReportColumn column : config.getModification().getColumns()){
			String applyto = column.getApplyTo();
            if ((null == applyto || "".equals(applyto))
                || (!parammap.containsKey(applyto))){
                //一致しない場合はdefid;
                applyto = defid;
            }
			
			//テーブルのpkリスト
			if (column.isPk()){
				List<String> pklist;
				Map<String, Object> param = parammap.get(applyto);
				if (!param.containsKey(PKLISTKEY)){
					pklist = new ArrayList<>();//なければ新規作成
				} else {
					pklist = (List<String>)param.get(PKLISTKEY);
				}
				if (!pklist.contains(column.getName())){
					pklist.add(column.getName());
				}
				param.put(PKLISTKEY, pklist);
				parammap.put(applyto, param);
			}
		}
	}


	
	/**
	 * 画面データをPagePropertiesBeanに格納
	 * @param values
	 * @param sqlid
	 * @return 
	 */
	public PagePropertiesBean getPagePropertiesBean(SSNaviManagedBean page, FacesEvent event){
		Map<String, Map<String, Object>> values = page.getValues();		
		ReportConfig config = page.getConfig();
		List<Map<String, Object>> selectReportResult = page.getSelectReportResult();
		TreeNode[] selectedNodes = page.getSelectedNodes();

		PagePropertiesBean resbean = new PagePropertiesBean();
		
		//SQLに渡されるformパラメータ
		resbean.setParamsmap(getParamMap(values, config));
		//テーブルのpkリストMAP
		resbean.setPklistdatas(getPklist(config));
		//検索条件formのデータ1
		resbean.setValues(values);
		//検索条件formのデータ2 (condition.getDefaultValue,condition.getItemValue)
		resbean.setConfig(config);
		
		//テーブルで選択されたデータ
		{
			List<Map<String, Object>> selecteddatas = null;
			//明細選択データ (datatable)
			if (!selectReportResult.isEmpty()) {
				selecteddatas = selectReportResult;
			}
			//明細選択データ (treetable)
			List<Map<String, Object>> selecttree = new ReportListTreeDataModel().selectedmap(selectedNodes);
			if (0 != selecttree.size()){
				selecteddatas = selecttree;
			}
			resbean.setSelectdatas(selecteddatas);
		}

		//選択SQLID columnで取得したapplytoがsqlタグに存在しない場合は、デフォルトsqlidに紐づける。
		Map<String, Object> eventmap = event.getComponent().getAttributes();
		if (eventmap.containsKey("column")){
			ReportColumn column = (ReportColumn)eventmap.get("column");
			String sqlid = column.getApplyTo();
			if(!checkApplyto(config, sqlid)){
				sqlid = config.getDefaultSqlId();
			}
			resbean.setSqlId(sqlid);
		}

		//選択画面ファイル名
		resbean.setFilename(config.getConfigFileName());
		
		//選択画面スクリーンコード
		resbean.setScreenCode(config.getScreenCode());
		
		return resbean;
	}
}
