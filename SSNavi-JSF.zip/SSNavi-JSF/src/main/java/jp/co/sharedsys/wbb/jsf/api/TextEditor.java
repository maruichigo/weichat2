package jp.co.sharedsys.wbb.jsf.api;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class TextEditor {
    private static final List apis;

    static {
            apis = new ArrayList();
            apis.add(new DateTime());
            apis.add(new DateYMD());
            apis.add(new Time());
            apis.add(new CurrentPath());
            apis.add(new CurrentRawPath());
            apis.add(new DateyyyyMMddHHmmss());
            apis.add(new DateyyyyMMdd_HHmmss());
            apis.add(new FirstDateYMDOfMonth());
            apis.add(new LastDateYMDOfMonth());
            apis.add(new CurrentYearYYYY());
            apis.add(new CurrentMonthMM());
            apis.add(new CurrentDayDD());
            apis.add(new CurrentYearYY());
            apis.add(new YesterDayyyMMdd());
            apis.add(new YesterDayyyyyMMdd());
            apis.add(new YesterDayyyyMMddSlashed());
    }
	
    public static String replace(String text){

        if (text == null){
            return text;
        }
        if (text.indexOf("@") == -1){
            return text;
        }
        String buf = text;
        for (Iterator ite = apis.iterator();ite.hasNext();){
            IAPI a =  (IAPI) ite.next();
            buf = buf.replaceAll(a.getAPI(),a.execute());
            if (buf.indexOf("@") == -1){
                break;
            }
        }
        return buf;
    }
	
    // TODO 渡すパラメータを、Message から別物のものに変更してからメソッドを復活させる。
//	public static String replaceByAttributeValue(String text,Message parameter){
//		if (text == null){
//			return text;
//		}
//		if (text.indexOf("%") == -1){
//			return text;
//		}
//		String buf = text;
//		for (Iterator ite = parameter.attributeKeySet().iterator();ite.hasNext();){
//			Object key = ite.next();
//			Object value = parameter.getAttribute(key);
//			
//			if (!(key instanceof String)){
//				continue;
//			}
//			if (!(value instanceof String)){
//				continue;
//			}
//			buf = buf.replaceAll("%" + (String)key + "%", (String)value);
//			if (buf.indexOf("%") == -1){
//				break;
//			}
//		}
//		buf = buf.replaceAll("%", "");
//		return buf;
//	}
//
//	
//	public static String replaceByExternalParameter(String text,Message parameter){
//		if (text == null){
//			return text;
//		}
//		if (text.indexOf("#") == -1){
//			return text;
//		}
//		String buf = text;
//		for (Iterator ite = parameter.getExternalParameter().keySet().iterator();ite.hasNext();){
//			Object key = ite.next();
//			Object value = parameter.getExternalParameter().get(key);
//			
//			if (!(key instanceof String)){
//				continue;
//			}
//			if (!(value instanceof String)){
//				continue;
//			}
//			if (value != null && ((String)value).indexOf("$") == -1) {
//				buf = buf.replaceAll("#" + (String)key + "#", (String)value);
//			}
//			if (buf.indexOf("#") == -1){
//				break;
//			}
//		}
//		buf = buf.replaceAll("#", "");
//		return buf;
//	}
	
}
