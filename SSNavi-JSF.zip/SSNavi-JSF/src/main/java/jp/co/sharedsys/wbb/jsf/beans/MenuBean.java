/*
 * MenuModelBean.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.beans;

import java.io.Serializable;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import lombok.Getter;
import lombok.Setter;
import org.primefaces.model.menu.MenuModel;

/**
 *
 * @author saihara
 */
@ManagedBean
@SessionScoped
public class MenuBean implements Serializable {

    @Getter @Setter
    private MenuModel model;
    @Getter @Setter
    private boolean mUpdateFlg;
    
    public MenuBean() {
    }
    
    public MenuBean(MenuModel model) {
        if (model != null) {
            this.model = model;
        }
        
    }
}