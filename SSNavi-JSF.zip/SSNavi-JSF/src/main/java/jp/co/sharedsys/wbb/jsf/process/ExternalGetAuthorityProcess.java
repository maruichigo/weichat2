package jp.co.sharedsys.wbb.jsf.process;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jp.co.sharedsys.wbb.jsf.exception.LogicException;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;
import jp.co.sharedsys.wbb.jsf.reports.ReportAppConfig;
import jp.co.sharedsys.wbb.jsf.beans.AuthorityConfBean;
import jp.co.sharedsys.wbb.jsf.beans.UserLoginView;
import java.util.LinkedHashMap;
import java.util.logging.Level;
import jp.co.sharedsys.wbb.jsf.beans.SSNaviManagedBean;
import jp.co.sharedsys.wbb.jsf.external.general.ExternalServiceProperty;
import jp.co.sharedsys.wbb.jsf.reports.ReportConst;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import jp.co.sharedsys.wbb.jsf.process.ExternalServiceExecuter2;

public class ExternalGetAuthorityProcess extends AbstractExternalProcess<UserLoginView> {
    public static final String P_REPSYS = "application-attribute";
    public static final String P_REPSYSCONFIGS = "usesysconfig-attribute";
    public static final String P_KEY = "application-key";
    public static final String USER_GROUP_CODE = "UserGroupCode";
    public static final String ROLE_GROUP_CODE = "RoleGroupCode";
    public static final String FUNCTION_CODE = "FunctionCode";
    public static final String SYSTEM_CODE = "SystemCode";
    public static final String SYSTEM_GROUP_NAME = "SystemGroupName";
    public static final String DISPLAY_POSITION = "DisplayPosition";
    public static final String SYSTEM_NAME = "SystemName";
    public static final String ACCESS_KEY = "AccessKey";
    public static final String SYSTEM_MULTIPLE = "SystemMulti";
    private final static String RECEIVE_CHARSET = "UTF-8";
    public static final String USE_SYSTEMS = "USESYSTEM";
    public static final String USE_ACCESS_KEY = "USEACCESSKEY";
    private static final String STATUS_PASS_WILL_EXPIRE = "6";
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public void onService(UserLoginView userLogin) throws LogicException, SystemException {
        ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
        HttpServletRequest request = (HttpServletRequest) externalContext.getRequest();
        HttpSession session = request.getSession();
        String loginId = userLogin.getUsername();
        List<String> userGroupCode = userLogin.getUserGroupCodes();
        //List<String> dataGroupCode = userLogin.getDataGroupCodes();
        logger.info("ID [" + loginId + "] UserGroupCode [" + userGroupCode + "]");

        // 外部サービスから帰ってきたメッセージをparameterに格納するキー
        String atrResMsg = "exMsg";
        String message = null;

        // 既にメッセージが入ってたら処理をやらない
        String loginMes = userLogin.getExtMessage();
        if (loginMes != null && loginMes.length() != 0) {
                return;
        }
        // ステータスがSTATUS_PASS_WILL_EXPIRE(ワンタイムパスワード)だったら処理をやらない
        String loginStatus = userLogin.getStatus();
        if (loginStatus != null && loginStatus.equals(STATUS_PASS_WILL_EXPIRE)) {
                userLogin.setExtMessage("change");
                return;
        }

        try {
            String service = ExternalServiceProperty.getInstance().getProperty("external-service");
            String function = ExternalServiceProperty.getInstance().getProperty("auth-func");
            String tableName = "";
            List<Map<String, Object>> authResult = externalService(loginId, userGroupCode, service, function, tableName, this.createGetAuthParameter(loginId, userGroupCode));

            Map<String, Object> comRes = authResult.get(0);
            String status = (String)comRes.get(this.EXTERNAL_STATUS);
            String externalMsg = (String)comRes.get(this.EXTERNAL_MESSAGE);

            if (status != null && (status.equals("1") || status.equals(STATUS_PASS_WILL_EXPIRE))) {
				
//		boolean isSystemUse = false;
//		// ログイン権限データが取得出来なかった場合
//              if (!isSystemUse) {
//                  userLogin.setMessage(ReportConst.Msg.SYSTEM_ERROR);
//                  return;
//		}
                // メッセージがあれば終了
                if (externalMsg != null && externalMsg.length() != 0) {
                        userLogin.setExtMessage(externalMsg);
                        return;
                }

//              parameter.setAttribute(parameter.getParameter(P_REPSYSCONFIGS), useSysList);
//		parameter.setAttribute(parameter.getParameter(P_REPSYS), sysList);
		userLogin.setMessage((String)comRes.get(this.EXTERNAL_MESSAGE));

//      	logger.info("Can use Menu : " + useSysList.size());
//		logger.info("Can use Functions : " + sysList.size());

                // for D-Frame authority
                String pkey = "";
                pkey = pkey == null || "".equals(pkey) ? "default" : pkey;
				
                // TODO セッションに認証情報を保存する
                request.changeSessionId();
                AuthorityConfBean authConf = userLogin.getAuthConf();
//		authConf.setAdmin(true);
                authConf.setUserCd(loginId);
                authConf.setUserGroup(userGroupCode);
                //authConf.setDataGroup(dataGroupCode);
                authConf.setFunctionList(getFunctionList(authResult));
		authConf.setMenuCategories(getMenuList(authResult));
                authConf.setAuthMenu(getAuthMenuList(authResult));

                session.setAttribute(ReportConst.SESSION_AUTH_CONF, authConf);

                // 権限リストとReport配置ファイルの突き合わせチェック
                if (!this.checkAuthAndDirs(authConf, userLogin.getSsconfig().getRcontext())) {
                    // 利用権限が無い(ユーザコードまたはパスワードがないという通知を画面にする)
                    logger.info("UserCd[" + authConf.getUserCd() + "] 利用権限と設定機能がマッチしていません");
                    userLogin.setMessage("ユーザーIDまたはパスワードが違います。");
                    return;
                }
                logger.info("token set OK ----------------------");
				
                Map<String, Object> makerRes = authResult.get(0);
                String mexternalMsg = (String)makerRes.get(this.EXTERNAL_MESSAGE);
                // メッセージがあれば終了
                if (mexternalMsg != null && mexternalMsg.length() != 0) {
                    userLogin.setMessage(externalMsg);
                    return;
                }
				
                // warning message
                if(status.equals(STATUS_PASS_WILL_EXPIRE)){
//                  SimpleNote note = new SimpleNote();
//                  note.setSubject("Warning");
//                  note.setText((String)comRes.get(this.EXTERNAL_MESSAGE));
//                  Corkboard.getInstance().setLoginWarning(session, note);
                }
            } else {
                // 外部サービスからのメッセージ
                message = (String)comRes.get(this.EXTERNAL_MESSAGE); 
            }
				
        } catch (Exception e) {
            e.printStackTrace();
            message = e.getMessage();
//          throw new SystemException(e);
        } finally {
        }
        userLogin.setExtMessage(message);
        
        authComponentSetting(userLogin);
        officeListSetting(userLogin);
    }

    public List<Map<String, Object>> externalService(String loginId, List<String> userGroupCode, String service, String function, String tableName, List<Map<String,Object>> list) {
        List<Map<String, Object>> authResult = (List<Map<String, Object>>)this.externalExecute(service, function, tableName, loginId, userGroupCode, list, true);
        return authResult;
    }

    private Map<String, List<String>> getAuthMenuList(List<Map<String, Object>> authResult) {
        Map<String, List<String>> result = new LinkedHashMap<>();
        for (Map<String, Object> auth : authResult) {
            List<String> inMenu = null;
            String parent = (String)auth.get("parentFunctionCode");
            String functionType = (String)auth.get("functionType");
			
            if ("MENU".equals(functionType)) {
                // functionTypeがMENUなら、カテゴリのリストを作る
                String categoryCode = (String)auth.get("functionCode");
                if (result.get(categoryCode) == null) {
                    inMenu = new ArrayList<>();
                    result.put(categoryCode, inMenu);
                }
                continue;
            }
			
            if ("SCREEN".equals(functionType)) {
                inMenu = result.get(parent);
                // リストが作られていればカテゴリ直下の画面Function
                if (inMenu == null) {
                        continue;
                }
                inMenu.add((String)auth.get("functionCode"));
            }
			
        }
        return result;
    }

    private Map<String, String> getFunctionList(List<Map<String, Object>> authResult) {
        Map<String, String> result = new HashMap<>();
        for (Map<String, Object> auth : authResult) {
            String functionType = (String)auth.get("functionType");
            if ("FUNC".equals(functionType)) {
                result.put((String)auth.get("functionCode"), (String)auth.get("permission"));
            }
        }		
        return result;
    }

    private List<String> getMenuList(List<Map<String, Object>> authResult) {
        List<String> result = new ArrayList<>();
        for (Map<String, Object> auth : authResult) {
            String functionType = (String)auth.get("functionType");
            if ("MENU".equals(functionType)) {
                result.add((String)auth.get("functionCode"));
            }
        }		
        return result;
    }
    
    
    private List<Map<String, Object>> createGetAuthParameter(String loginId, List<String> userGroupCode) {
        List<Map<String, Object>> prmList = new ArrayList<>();

        // TODO fortest
        if (userGroupCode == null || userGroupCode.isEmpty()) {
            Map<String, Object> data = new HashMap<>();
            prmList.add(data);
            data.put("userCd", loginId);
            data.put("userGroupCode", "SYSTEM_ADMIN");
            return prmList;
        }
        
        for (String userGroup : userGroupCode) {
            Map<String, Object> data = new HashMap<>();
            prmList.add(data);
            data.put("userCd", loginId);
            data.put("userGroupCode", userGroup);
        }
        return prmList;
    }

    /** 
     * ユーザコンポーネント権限
     * ss_furutani
     * @param userLogin
     */
    private void authComponentSetting(UserLoginView userLogin){
        String loginId = userLogin.getUsername();
        List<String> userGroupCode = userLogin.getUserGroupCodes();
        List<Map<String, Object>> authResult = null;

        try {
            //SQL問い合わせ
            String service = ExternalServiceProperty.getInstance().getProperty("external-service");
            String function = ExternalServiceProperty.getInstance().getProperty("authcomponent-func");
            String tableName = "";
            authResult = externalService(loginId, userGroupCode, service, function, tableName, this.createGetAuthParameter(loginId, userGroupCode));
        } catch (Exception e) {
            java.util.logging.Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, e);
            throw e;
        }
        
        try {
            Map<String ,Map <String, Integer>> authScCompoMap = new LinkedHashMap<>();
            //SQL取得結果の格納処理
            for (Map<String, Object> map : authResult){
                String screenCode = (String)map.get("screenCode");
                String componentName = (String)map.get("componentName");
                int riyoSettei = (int) map.get("riyoSettei");
            
                Map<String ,Integer> compoMap = null;
                if (authScCompoMap.containsKey(screenCode)){
                    compoMap = authScCompoMap.get(screenCode);
                } else {
                    compoMap = new LinkedHashMap<>();
                }
                compoMap.put(componentName, riyoSettei);
                authScCompoMap.put(screenCode, compoMap);
                userLogin.getAuthConf().setAuthScCompoMap(authScCompoMap);
            }
        } catch (Exception e) {
            java.util.logging.Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, e);
            throw e;
        }
    }

    /** 
     * ユーザ営業所一覧を取得
     * ss_furutani
     * @param userLogin
     */
    private void officeListSetting(UserLoginView userLogin){
        String loginId = userLogin.getUsername();
        List<String> userGroupCode = userLogin.getUserGroupCodes();
        List authResult = null;

        try {
            String service = ExternalServiceProperty.getInstance().getProperty("external-service");
            String function = ExternalServiceProperty.getInstance().getProperty("loadoffice-func");
            String tableName = "";
            authResult = externalService(loginId, userGroupCode, service, function, tableName, this.createGetAuthParameter(loginId, userGroupCode));
        } catch (Exception e) {
            java.util.logging.Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, e);
            throw e;
        }

        try {
            Map<String, String> defmap = (Map<String, String>)authResult.get(0);
            String defaultEigyosh = (String)defmap.get("eigyoshoCd");
            userLogin.getAuthConf().setDefaultEigyosho(defaultEigyosh);
            authResult.remove(0);
            
            userLogin.getAuthConf().setEigyoshoList((List<Map<String, String>>)authResult);
        } catch (Exception e) {
            java.util.logging.Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, e);
            throw e;
        }
    }
}
