package jp.co.sharedsys.wbb.jsf.api;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateTime implements IAPI {

    public String execute() {
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        return format.format(new Date());
    }

    public String getAPI() {
        return "@DATETIME@";
    }
}
