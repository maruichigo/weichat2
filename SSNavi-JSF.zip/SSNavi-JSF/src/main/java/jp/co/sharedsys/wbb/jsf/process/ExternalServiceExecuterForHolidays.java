package jp.co.sharedsys.wbb.jsf.process;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.wbb.jsf.api.HolidayProvider;
import jp.co.sharedsys.wbb.jsf.exception.LogicException;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;
import jp.co.sharedsys.wbb.jsf.beans.AuthorityConfBean;

import jp.co.sharedsys.wbb.jsf.beans.SSNaviManagedBean;
import jp.co.sharedsys.wbb.jsf.reports.Input;
import jp.co.sharedsys.wbb.jsf.reports.ReportColumn;
import jp.co.sharedsys.wbb.jsf.reports.ReportConfig;
import jp.co.sharedsys.wbb.jsf.reports.ReportConst;
import jp.co.sharedsys.wbb.jsf.reports.ReportModification;
import jp.co.sharedsys.wbb.jsf.util.StringUtil;


public class ExternalServiceExecuterForHolidays extends AbstractExternalProcess<SSNaviManagedBean> {
    public static final String P_REPORTIDPARAM = "id-parameter-name";
    public static final String P_KEY = "application-key";
    public static final String P_ATTRIBUTE = "parameter-attribute-name";
    public static final String P_SEND_PARAMETER = "send_parameters";
    public static final String P_EDIT_MODE_NAME = "edit-name";
    public static final String P_EDIT_MODE_INSERT = "edit-name-value-insert";
    public static final String P_EDIT_MODE_UPDATE = "edit-name-value-update";
    public static final String P_EDIT_MODE_DELETE = "edit-name-value-delete";
    public static final String P_EDIT_ACTIVITY_NAME = "act";
    public static final String P_EDIT_ACTIVITY_INIT = "INIT";
    public static final String P_EDIT_ACTIVITY_ERROR = "ERROR";
    public static final String P_EDIT_ACTIVITY_EXECUTE = "EXECUTE";
    public static final String P_INPUT_ATTRIBUTE = "input_parameter";
    public static final String PREFIX_COND_PARAM = "P_";
    public static final String P_EXEC_RES_STATUS_ATTRIBUTE = "execResStatus";
    public static final String P_EXEC_RES_MSG_ATTRIBUTE = "execResMsg";
    public static final String P_IS_SEARCH = "isSearch";
    public static final String P_CURRENT_PAGE = "current-page";
    public static final String P_ALL_PAGE     = "all-page";
    public static final String P_LIMIT_PAGE   = "limit-page";
    public static final String P_RESULT_DATA_COUNT = "result-data-count";
    public static final String E_SERVICE_URL = "target_service_url";
    public static final String E_FUNCTION = "target_function";
    public static final String E_SERVICE_NAME = "target_service_name";
    public static final String E_TARGET_CONFIG = "target_config";
    public static final String E_SQL = "exec_sql";

    
    /**
     * パラメータを渡してSQL実行を行う
     * @param pageBean
     * @throws LogicException
     * @throws SystemException 
     */
    public void dbProcess(SSNaviManagedBean pageBean) throws LogicException, SystemException {
        try {
            onService(pageBean);
        } catch (LogicException | SystemException ex) {
            //システムエラー
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            new MsgExec().message("ERROR", "エラー", ex.getMessage());
            throw ex;
        }
    }
    
    @Override
    public void onService(SSNaviManagedBean pageBean) throws LogicException, SystemException {
        
        String json = "";
        
        //シングルsqlidのみ対応
        Map<String, Object> target = pageBean.getTargetServices().get(0);
        
        //◆1.パラメータ取得
        String servicename = (String)target.get(ReportConst.F_EXECUTER.E_SERVICE_NAME); //画面データを変換するために使用していた。
        String service = (String)target.get(ReportConst.F_EXECUTER.E_SERVICE_URL);
        String functionCode = (String)target.get(ReportConst.F_EXECUTER.E_FUNCTION);
        String tableName = (String)target.get(ReportConst.F_EXECUTER.E_SQL);
        Object inputParams = target.get(ReportConst.F_EXECUTER.P_SEND_PARAMETER);
        
        //◆2.SQL実行
        AuthorityConfBean authConf = pageBean.getAuthConf();
        ServiceInterfaceBean dto = this.requestExternalService(service, inputParams, functionCode, tableName, authConf.getUserCd(), authConf.getUserGroup(), false);
        
        //◆3.値取得
        try {
            //Json結果データ(jsonString)を変換する準備
            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> jsonResMap = null;

            //存在チェック形式
            String tablelist = dto.getJsonResultTableList();
            String resultmap = dto.getJsonResultMap();
            if (!"".equals(tablelist)){
                List searchResult = mapper.readValue(tablelist, List.class);
                pageBean.getReportResult().put(servicename, searchResult);
            }
            if (!"".equals(resultmap)){
                jsonResMap = mapper.readValue(resultmap, Map.class);
                pageBean.setExternalAttribute(jsonResMap);   
            }
            
            //モード形式(従来通りdto.getJson()を見る。)
            if ("{}".equals(dto.getJson()) || "".equals(dto.getJson())){
				//返却なし
			} else {
                    json = dto.getJson();

            }
        } catch (IOException e) {
            logger.error("サービス側から意図しないパラメータが返ってきています。");
            logger.error(e.getMessage(), e);
            return;
        }

        //◆4.後処理
        // holidays.jsonを最新化する (起動時は不要かも)
        HolidayProvider hp = new HolidayProvider(pageBean.getHolidayFilePath());
        hp.getHolidays(json);

        //◆5.メッセージ出力
        MsgExec.message(dto.getMessages());

        
    }
}
