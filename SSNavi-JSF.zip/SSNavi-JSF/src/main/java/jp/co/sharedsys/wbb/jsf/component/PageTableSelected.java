package jp.co.sharedsys.wbb.jsf.component;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import jp.co.sharedsys.wbb.jsf.reports.ReportColumn;
import org.primefaces.context.RequestContext;

/**
 * dataTable上でチェックされた場合に発生
 * 非表示カラムなどを対象外にし、javascriptで受け取れるようにする。
 * @author s_furutani
 */
public class PageTableSelected {
	
	/**
	 * テーブルのチェックイベントが発生した場合に呼び出される。
	 * selectされた値はcheck
	 */
	public void check(List<Map<String, Object>> selectReportResult, List<ReportColumn> columns){
		
		Map<String, Object> data = new LinkedHashMap<>();
		// hiddenデータも含んだチェックデータ
        String checkparam = "";
		// hiddenデータを含まないチェックデータ
		String viewParam = ""; 
        for(Map<String, Object> map : selectReportResult){
            if ( !checkparam.isEmpty() ) {
				checkparam += "\r\n";
            }
			
			checkparam += map.values();
			for(int i = 0; i<columns.size();i++){
				ReportColumn column = columns.get(i);
				
				if (i == 0){
					continue;
				} else if ("HIDDEN".equals(column.getControlType())){
					continue;
				} else if ("CONTEXT".equals(column.getControlType())){
					continue;
				} else if (!column.isVisible()){
					continue;
				}
				String name = column.getName();
				Object val = map.get(name);
				if (null == val){
					val = "";
				}
				data.put(name, val);
			}
			
			viewParam += data.values();
        }
        RequestContext context = RequestContext.getCurrentInstance();
        context.addCallbackParam("checkParam", checkparam);
		context.addCallbackParam("viewParam", viewParam);
	}
}
