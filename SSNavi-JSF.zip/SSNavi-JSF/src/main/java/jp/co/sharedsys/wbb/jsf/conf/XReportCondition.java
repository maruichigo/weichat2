package jp.co.sharedsys.wbb.jsf.conf;

import java.util.ArrayList;
import java.util.List;

public class XReportCondition {
    private String name = null;
    private String displayName = null;
    private String controlType = null;
    private String dataType = null;
    private String defaultValue = null;
    private String required = null;
    private String combination = null;
    private String toolTip = null;
    private String minLength = null;
    private String maxLength = null;
    private String applyTo = null;
    private String cache = null;
    private String imeMode = null;
    private String headerWidth = null;
    private String size = null;
    private String width = null;
    private String height = null;
    private String tabIndex = null;//30TabIndex〇
    private List options = new ArrayList();
    private String skipIfBlank = null;
    private String lineEnd = null;
    private String prevColPosition;
    private String colspan;

    // 2012.11.08 for roots
    private String targetDynamic;
    private String section;
    private String visible;
    private String enable;
    
    private String extra1;
    private String extra2;
    private String extra3; 
    private String extra4;
    private String extra5;
    
    private String align = null;//5配置〇	
	
	
    public String getTabIndex() {
        return tabIndex;
    }
    public void setTabIndex(String tabIndex) {
        this.tabIndex = tabIndex;
    }
	
    /**
     * @return the align
     */
    public String getAlign() {
        return align;
    }

    /**
     * @param align the align to set
     */
    public void setAlign(String align) {
        this.align = align;
    }	
	
    public void setVisible(String visible) {
        this.visible = visible;
    }

    public void setEnable(String enable) {
        this.enable = enable;
    }

    public String getVisible() {
        return visible;
    }

    public String getEnable() {
        return enable;
    }
    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getDisplayName() {
        return displayName;
    }
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }
    public String getControlType() {
        return controlType;
    }
    public void setControlType(String controlType) {
        this.controlType = controlType;
    }
    public String getDataType() {
        return dataType;
    }
    public void setDataType(String dataType) {
        this.dataType = dataType;
    }
    public String getDefaultValue() {
        return defaultValue;
    }
    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }
    public String getRequired() {
        return required;
    }
    public void setRequired(String required) {
        this.required = required;
    }
    public String getCombination() {
        return combination;
    }
    public void setCombination(String combination) {
        this.combination = combination;
    }
    public String getToolTip() {
        return toolTip;
    }
    public void setToolTip(String toolTip) {
        this.toolTip = toolTip;
    }
    public String getMinLength() {
        return minLength;
    }
    public void setMinLength(String minLength) {
        this.minLength = minLength;
    }
    public String getMaxLength() {
        return maxLength;
    }
    public void setMaxLength(String maxLength) {
        this.maxLength = maxLength;
    }
    public void addOption(XReportConditionOption option) {
        this.options.add(option);
    }
    public List getOptions() {
        return options;
    }
    public String getSkipIfBlank() {
        return skipIfBlank;
    }
    public void setSkipIfBlank(String skipIfBlank) {
        this.skipIfBlank = skipIfBlank;
    }
    public String getApplyTo() {
        return applyTo;
    }
    public void setApplyTo(String applyTo) {
        this.applyTo = applyTo;
    }
    public String getCache() {
        return cache;
    }
    public void setCache(String cache) {
        this.cache = cache;
    }
    public String getTargetDynamic() {
        return targetDynamic;
    }
    public void setTargetDynamic(String targetDynamic) {
        this.targetDynamic = targetDynamic;
    }
    public String getImeMode() {
        return imeMode;
    }
    public void setImeMode(String imeMode) {
        this.imeMode = imeMode;
    }
    public String getHeaderWidth() {
        return headerWidth;
    }
    public void setHeaderWidth(String headerWidth) {
        this.headerWidth = headerWidth;
    }
    public String getSize() {
        return size;
    }
    public void setSize(String size) {
        this.size = size;
    }
    public String getWidth() {
        return width;
    }
    public void setWidth(String width) {
        this.width = width;
    }
    public String getHeight() {
        return height;
    }
    public void setHeight(String height) {
        this.height = height;
    }
    public String getLineEnd() {
        return lineEnd;
    }
    public void setLineEnd(String lineEnd) {
        this.lineEnd = lineEnd;
    }
    public String getPrevColPosition() {
        return prevColPosition;
    }
    public String getColspan() {
        return colspan;
    }
    public void setPrevColPosition(String prevColPosition) {
        this.prevColPosition = prevColPosition;
    }
    public void setColspan(String colspan) {
        this.colspan = colspan;
    }   

    public String getExtra1() {
        return extra1;
    }

    public void setExtra1(String extra1) {
        this.extra1 = extra1;
    }

    public String getExtra2() {
        return extra2;
    }

    public void setExtra2(String extra2) {
        this.extra2 = extra2;
    }

    public String getExtra3() {
        return extra3;
    }

    public void setExtra3(String extra3) {
        this.extra3 = extra3;
    }

    public String getExtra4() {
        return extra4;
    }

    public void setExtra4(String extra4) {
        this.extra4 = extra4;
    }

    public String getExtra5() {
        return extra5;
    }

    public void setExtra5(String extra5) {
        this.extra5 = extra5;
    }
}
