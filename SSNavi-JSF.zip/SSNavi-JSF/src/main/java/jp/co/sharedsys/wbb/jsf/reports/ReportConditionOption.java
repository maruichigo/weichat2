package jp.co.sharedsys.wbb.jsf.reports;

public class ReportConditionOption extends AbstractReportOption {
    /**
     * 
     */
    private static final long serialVersionUID = 824510364158987633L;
}
