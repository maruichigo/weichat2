package jp.co.sharedsys.bb;

import java.io.File;
import java.io.FilenameFilter;

public class ReportFileFilter implements FilenameFilter {

    public boolean accept(File file, String path) {
        return path.endsWith(".rpt");
    }
}
