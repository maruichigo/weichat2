/*     */ package jp.co.tokyo_gas.cisfw.web;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.enterprise.context.SessionScoped;
/*     */ import javax.faces.event.ActionEvent;
/*     */ import javax.inject.Inject;
/*     */ import javax.inject.Named;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.token.FwTokenUtils;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.message.FwMessage;
/*     */ import jp.co.tokyo_gas.cisfw.exception.CfwRuntimeException;
/*     */ import jp.co.tokyo_gas.cisfw.logger.CfwLogger;
/*     */ import jp.co.tokyo_gas.cisfw.web.taglib.component.CfwComponentUtils;
/*     */ import org.primefaces.context.RequestContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Named("cfwAppDialog")
/*     */ @SessionScoped
/*     */ public class CfwAppDialog
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   @Inject
/*     */   private CfwLogger log;
/*     */   @Inject
/*     */   private FwTokenUtils utils;
/*     */   private String title;
/*     */   private List<String> messages;
/*     */   private Button button1;
/*     */   private Button button2;
/*     */   private Button button3;
/*     */   private Button button4;
/*     */   
/*     */   public void setUp()
/*     */   {
/*  69 */     this.title = "確認ダイアログ";
/*  70 */     this.messages = new ArrayList();
/*  71 */     this.button1 = new Button();
/*  72 */     this.button2 = new Button();
/*  73 */     this.button3 = new Button();
/*  74 */     this.button4 = new Button();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setButton1(String label, String callbackKey)
/*     */   {
/*  83 */     this.button1.build(label, callbackKey, "100px");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setButton1(String label, String callbackKey, String width)
/*     */   {
/*  93 */     this.button1.build(label, callbackKey, width);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setButton2(String label, String callbackKey)
/*     */   {
/* 102 */     this.button2.build(label, callbackKey, "100px");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setButton2(String label, String callbackKey, String width)
/*     */   {
/* 112 */     this.button2.build(label, callbackKey, width);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setButton3(String label, String callbackKey)
/*     */   {
/* 121 */     this.button3.build(label, callbackKey, "100px");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setButton3(String label, String callbackKey, String width)
/*     */   {
/* 131 */     this.button3.build(label, callbackKey, width);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setButton4(String label, String callbackKey)
/*     */   {
/* 140 */     this.button4.build(label, callbackKey, "100px");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setButton4(String label, String callbackKey, String width)
/*     */   {
/* 150 */     this.button4.build(label, callbackKey, width);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addMessage(String messageID, String... params)
/*     */   {
/* 159 */     FwMessage fwMessage = FwMessage.getInstance();
/* 160 */     String message = fwMessage.getMessage(messageID, (Object[])params);
/* 161 */     if (message == null) {
/* 162 */       throw new CfwRuntimeException("指定メッセージIDに対応するメッセージが存在しません。 : %s", new Object[] { messageID });
/*     */     }
/* 164 */     this.messages.add(message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getMessages()
/*     */   {
/* 172 */     return this.messages;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTitle(String title)
/*     */   {
/* 180 */     this.title = title;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTitle()
/*     */   {
/* 188 */     return this.title;
/*     */   }
/*     */   
/*     */   public void init() {
/* 192 */     this.log.debug("CfwAppDialogBean#init()");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void button1Event(ActionEvent event)
/*     */   {
/* 201 */     RequestContext.getCurrentInstance().closeDialog(this.button1.getCallbackKey());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void button2Event(ActionEvent event)
/*     */   {
/* 210 */     RequestContext.getCurrentInstance().closeDialog(this.button2.getCallbackKey());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void button3Event(ActionEvent event)
/*     */   {
/* 219 */     RequestContext.getCurrentInstance().closeDialog(this.button3.getCallbackKey());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void button4Event(ActionEvent event)
/*     */   {
/* 228 */     RequestContext.getCurrentInstance().closeDialog(this.button4.getCallbackKey());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void open()
/*     */   {
/* 235 */     open(400, 120);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void open(int width)
/*     */   {
/* 243 */     open(width, 120);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void open(int width, int height)
/*     */   {
/* 254 */     Map<String, Object> dialogOptions = new HashMap();
/* 255 */     dialogOptions.put("modal", Boolean.valueOf(true));
/* 256 */     dialogOptions.put("resizable", Boolean.valueOf(false));
/* 257 */     dialogOptions.put("draggable", Boolean.valueOf(true));
/* 258 */     dialogOptions.put("closable", Boolean.valueOf(true));
/* 259 */     dialogOptions.put("contentWidth", Integer.valueOf(width));
/* 260 */     dialogOptions.put("contentHeight", Integer.valueOf(height));
/*     */     
/*     */ 
/* 263 */     Map<String, List<String>> params = new HashMap();
/* 264 */     this.utils.addParamsForDialog(params);
/*     */     
/*     */ 
/* 267 */     RequestContext.getCurrentInstance().openDialog("/jsf/cfwAppDialog", dialogOptions, params);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Button getButton1()
/*     */   {
/* 275 */     return this.button1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Button getButton2()
/*     */   {
/* 283 */     return this.button2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Button getButton3()
/*     */   {
/* 291 */     return this.button3;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Button getButton4()
/*     */   {
/* 299 */     return this.button4;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public class Button
/*     */   {
/*     */     private String width;
/*     */     
/*     */ 
/*     */ 
/*     */     private String label;
/*     */     
/*     */ 
/*     */ 
/*     */     private String callbackKey;
/*     */     
/*     */ 
/*     */ 
/*     */     private boolean visible;
/*     */     
/*     */ 
/*     */ 
/*     */     public Button()
/*     */     {
/* 325 */       this.visible = false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void build(String label, String callbackKey, String width)
/*     */     {
/* 335 */       this.label = label;
/* 336 */       this.width = width;
/* 337 */       this.callbackKey = callbackKey;
/* 338 */       this.width = width;
/* 339 */       this.visible = true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getWidth()
/*     */     {
/* 347 */       return CfwComponentUtils.getInstance().toWidth(this.width);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getLabel()
/*     */     {
/* 355 */       return this.label;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getCallbackKey()
/*     */     {
/* 363 */       return this.callbackKey;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean getVisible()
/*     */     {
/* 371 */       return this.visible;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isVisible()
/*     */     {
/* 379 */       return this.visible;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\CfwAppDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */