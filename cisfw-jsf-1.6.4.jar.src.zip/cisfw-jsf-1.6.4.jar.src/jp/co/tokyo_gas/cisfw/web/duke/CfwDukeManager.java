/*     */ package jp.co.tokyo_gas.cisfw.web.duke;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import javax.enterprise.context.RequestScoped;
/*     */ import javax.inject.Inject;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.adapter.duke.FwDuke;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.adapter.duke.FwDukeAuthException;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.adapter.duke.FwDukeAuthException.AuthErrType;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.adapter.duke.FwDukeException;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.adapter.duke.FwDukeInitialPasswordException;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.adapter.duke.FwDukeManager;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.adapter.duke.FwDukeUserInfo;
/*     */ import jp.co.tokyo_gas.cisfw.exception.CfwApplicationException;
/*     */ import jp.co.tokyo_gas.cisfw.exception.CfwDukeInitialPasswordException;
/*     */ import jp.co.tokyo_gas.cisfw.exception.CfwRuntimeException;
/*     */ import jp.co.tokyo_gas.cisfw.logger.CfwLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @RequestScoped
/*     */ public class CfwDukeManager
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   @Inject
/*     */   private CfwLogger log;
/*     */   @Inject
/*     */   private FwDukeManager manager;
/*     */   private FwDukeUserInfo info;
/*     */   
/*     */   public void authenticate(String dukeId, String password)
/*     */     throws CfwApplicationException, CfwDukeInitialPasswordException
/*     */   {
/*  56 */     String result = null;
/*     */     
/*     */     try
/*     */     {
/*  60 */       FwDuke duke = this.manager.connect();Throwable localThrowable3 = null;
/*     */       try {
/*  62 */         this.info = duke.authenticate(dukeId, password);
/*  63 */         result = "SUCCESS";
/*     */       }
/*     */       catch (Throwable localThrowable1)
/*     */       {
/*  60 */         localThrowable3 = localThrowable1;throw localThrowable1;
/*     */       }
/*     */       finally
/*     */       {
/*  64 */         if (duke != null) if (localThrowable3 != null) try { duke.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else duke.close(); } } catch (FwDukeAuthException e) { String LOG_FORMAT;
/*  65 */       if (FwDukeAuthException.AuthErrType.INVALID_ID_OR_PSWD.name().equals(e.getErrType().name()))
/*     */       {
/*  67 */         result = "CXXM99002E";
/*  68 */         throw new CfwApplicationException("CXXM99002E", new String[0]); }
/*  69 */       if (FwDukeAuthException.AuthErrType.PSWD_EXPIRED.name().equals(e.getErrType().name()))
/*     */       {
/*  71 */         result = "CXXM99004E";
/*  72 */         throw new CfwApplicationException("CXXM99004E", new String[0]); }
/*  73 */       if (FwDukeAuthException.AuthErrType.ACCOUNT_LOCK.name().equals(e.getErrType().name()))
/*     */       {
/*  75 */         result = "CXXM99001E";
/*  76 */         throw new CfwApplicationException("CXXM99001E", new String[0]);
/*     */       }
/*     */       
/*  79 */       result = "CXXM99006E";
/*  80 */       throw new CfwApplicationException("CXXM99006E", new String[0]);
/*     */     }
/*     */     catch (FwDukeInitialPasswordException e)
/*     */     {
/*  84 */       result = "CXXM99005E";
/*  85 */       throw new CfwDukeInitialPasswordException("CXXM99005E", new String[0]);
/*     */     }
/*     */     catch (FwDukeException e) {
/*  88 */       result = "ERROR";
/*  89 */       throw new CfwRuntimeException(e.getMessage(), new Object[0]);
/*     */     }
/*     */     finally {
/*  92 */       String LOG_FORMAT = "[{}] [{}] ";
/*  93 */       this.log.info("[{}] [{}] ", dukeId, result);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDukePasswordExpiring()
/*     */   {
/* 104 */     return this.info.isDukePasswordExpiring();
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\duke\CfwDukeManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */