/*    */ package jp.co.tokyo_gas.cisfw.web;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import javax.enterprise.context.ApplicationScoped;
/*    */ import javax.ws.rs.ApplicationPath;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.rs.FwRSApplication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ApplicationPath("cisfw")
/*    */ @ApplicationScoped
/*    */ public class CfwRestApplication
/*    */   extends FwRSApplication
/*    */ {
/*    */   protected Class<? extends Annotation> getAnnotation()
/*    */   {
/* 18 */     return CfwRest.class;
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\CfwRestApplication.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */