/*     */ package jp.co.tokyo_gas.cisfw.web;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import javax.annotation.PostConstruct;
/*     */ import javax.faces.view.ViewScoped;
/*     */ import javax.inject.Inject;
/*     */ import javax.inject.Named;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.config.FwConfig;
/*     */ import jp.co.tokyo_gas.cisfw.logger.CfwLogger;
/*     */ import jp.co.tokyo_gas.cisfw.version.CfwVersionProperty;
/*     */ import org.primefaces.context.RequestContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Named("cfwHeaderBean")
/*     */ @ViewScoped
/*     */ public class CfwHeaderBean
/*     */   extends CfwBaseBean
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   @Inject
/*     */   private FwConfig fwConfig;
/*     */   @Inject
/*     */   private CfwSession session;
/*     */   @Inject
/*     */   private CfwLogger log;
/*     */   private String trackingPreID;
/*     */   private String loginScreen;
/*     */   @Inject
/*     */   private CfwVersionProperty versionProperty;
/*     */   
/*     */   @PostConstruct
/*     */   public void setup()
/*     */   {
/*  55 */     this.trackingPreID = this.fwConfig.get("tgfw.tracking.pre");
/*  56 */     this.loginScreen = this.fwConfig.get("LOGIN");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTrackingPreID()
/*     */   {
/*  65 */     return this.trackingPreID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void writeSession()
/*     */   {
/*  72 */     this.session.writeSession();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLoginScreen()
/*     */   {
/*  81 */     return this.loginScreen;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String bookmark(String url, String title)
/*     */   {
/*  92 */     this.log.debug("url=" + url);
/*  93 */     this.log.debug("title=" + title);
/*  94 */     RequestContext.getCurrentInstance().execute("bookmark('" + url + "', '" + title + "');");
/*     */     
/*  96 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCSS()
/*     */   {
/* 105 */     return this.fwConfig.get("css.file", "template.css");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getVersion()
/*     */   {
/* 115 */     return this.versionProperty.getCIRIUS("");
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\CfwHeaderBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */