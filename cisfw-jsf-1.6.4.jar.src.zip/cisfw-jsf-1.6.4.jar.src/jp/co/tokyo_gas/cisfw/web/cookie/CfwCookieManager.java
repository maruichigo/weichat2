/*    */ package jp.co.tokyo_gas.cisfw.web.cookie;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import javax.enterprise.context.RequestScoped;
/*    */ import javax.inject.Inject;
/*    */ import javax.servlet.http.Cookie;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.config.FwConfig;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.FwFacesContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @RequestScoped
/*    */ public class CfwCookieManager
/*    */   implements Serializable
/*    */ {
/*    */   private static final String COOKIE_USERID_KEY = "CFW_USER_ID";
/*    */   private static final String COOKIE_USERID_RETENTION_DAYS = "userid.retention.days";
/*    */   private static final long serialVersionUID = 1L;
/*    */   @Inject
/*    */   private HttpServletRequest request;
/*    */   @Inject
/*    */   private FwConfig fwConfig;
/*    */   
/*    */   public String getUserId()
/*    */   {
/* 50 */     String cookieUserId = null;
/* 51 */     Cookie[] cookies = this.request.getCookies();
/* 52 */     if (cookies != null) {
/* 53 */       for (Cookie cookie : cookies) {
/* 54 */         if (cookie.getName().equals("CFW_USER_ID")) {
/* 55 */           cookieUserId = cookie.getValue();
/* 56 */           break;
/*    */         }
/*    */       }
/*    */     }
/*    */     
/* 61 */     return cookieUserId;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setUserId(String userId)
/*    */   {
/* 74 */     String saveDays = this.fwConfig.get("userid.retention.days", "30");
/* 75 */     int cookieSaveDays = Integer.valueOf(saveDays).intValue();
/*    */     
/*    */ 
/* 78 */     Cookie cookie = new Cookie("CFW_USER_ID", userId);
/*    */     
/* 80 */     int second = 60;
/* 81 */     int minutes = 60;
/* 82 */     int hour = 24;
/* 83 */     cookie.setMaxAge(86400 * cookieSaveDays);
/* 84 */     cookie.setHttpOnly(true);
/*    */     
/*    */ 
/* 87 */     HttpServletResponse response = FwFacesContext.getResponse();
/* 88 */     response.addCookie(cookie);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void clearUserId()
/*    */   {
/* 96 */     HttpServletResponse response = FwFacesContext.getResponse();
/* 97 */     Cookie cookie = new Cookie("CFW_USER_ID", "");
/* 98 */     cookie.setMaxAge(0);
/* 99 */     response.addCookie(cookie);
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\cookie\CfwCookieManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */