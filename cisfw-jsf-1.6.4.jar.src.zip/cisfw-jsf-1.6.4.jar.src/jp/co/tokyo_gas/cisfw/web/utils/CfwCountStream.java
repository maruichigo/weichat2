/*    */ package jp.co.tokyo_gas.cisfw.web.utils;
/*    */ 
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CfwCountStream
/*    */   extends OutputStream
/*    */ {
/*    */   private int count;
/*    */   
/*    */   public CfwCountStream()
/*    */   {
/* 27 */     this.count = 0;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void write(int b)
/*    */   {
/* 36 */     this.count += 1;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public int size()
/*    */   {
/* 44 */     return this.count;
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\utils\CfwCountStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */