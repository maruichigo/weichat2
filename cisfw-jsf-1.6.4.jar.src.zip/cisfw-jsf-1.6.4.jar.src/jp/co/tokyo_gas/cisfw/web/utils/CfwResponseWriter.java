/*    */ package jp.co.tokyo_gas.cisfw.web.utils;
/*    */ 
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.net.URLEncoder;
/*    */ import javax.enterprise.context.RequestScoped;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.response.FwResponseWriterForJSF;
/*    */ import jp.co.tokyo_gas.cisfw.exception.CfwRuntimeException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @RequestScoped
/*    */ public class CfwResponseWriter
/*    */   extends FwResponseWriterForJSF
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public void outputResponse(byte[] data, String fileName)
/*    */   {
/*    */     try
/*    */     {
/* 35 */       String newFileName = URLEncoder.encode(fileName, "UTF-8");
/* 36 */       super.outputResponse(data, newFileName);
/*    */     }
/*    */     catch (UnsupportedEncodingException e)
/*    */     {
/* 40 */       throw new CfwRuntimeException("ファイル名の変換に失敗しました。", e, new Object[0]);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\utils\CfwResponseWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */