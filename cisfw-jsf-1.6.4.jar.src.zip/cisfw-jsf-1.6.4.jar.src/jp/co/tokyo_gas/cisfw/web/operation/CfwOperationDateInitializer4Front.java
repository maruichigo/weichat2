/*    */ package jp.co.tokyo_gas.cisfw.web.operation;
/*    */ 
/*    */ import javax.annotation.PostConstruct;
/*    */ import javax.enterprise.context.ApplicationScoped;
/*    */ import javax.inject.Inject;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.config.FwConfig;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.init.FwInitializer;
/*    */ import jp.co.tokyo_gas.cisfw.exception.CfwRuntimeException;
/*    */ import jp.co.tokyo_gas.cisfw.logger.CfwLogger;
/*    */ import jp.co.tokyo_gas.cisfw.utils.CfwDateUtils;
/*    */ import jp.co.tokyo_gas.cisfw.web.operation.client.CfwOperationDateService;
/*    */ import jp.co.tokyo_gas.cisfw.web.operation.client.CfwOperationDateServiceService;
/*    */ import jp.co.tokyo_gas.cisfw.web.ws.CfwServiceFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ApplicationScoped
/*    */ public class CfwOperationDateInitializer4Front
/*    */   implements FwInitializer
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   @Inject
/*    */   private CfwServiceFactory factory;
/*    */   @Inject
/*    */   private FwConfig config;
/*    */   @Inject
/*    */   private CfwLogger logger;
/*    */   
/*    */   @PostConstruct
/*    */   public void initialize()
/*    */   {
/* 46 */     if ("true".equals(this.config.get("ear.integration", "false"))) {
/* 47 */       this.logger.debug("初期化スキップします。対象クラス={}", getClass().getName());
/* 48 */       return;
/*    */     }
/*    */     
/*    */     try
/*    */     {
/* 53 */       CfwOperationDateService service = (CfwOperationDateService)this.factory.createSEI(CfwOperationDateServiceService.class, CfwOperationDateService.class);
/*    */       
/*    */ 
/* 56 */       CfwDateUtils.setOperationDate(service.get());
/*    */     } catch (Exception e) {
/* 58 */       throw new CfwRuntimeException("アプリケーション初期化処理に失敗しました。", e, new Object[0]);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\operation\CfwOperationDateInitializer4Front.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */