/*     */ package jp.co.tokyo_gas.cisfw.web.operation.client;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.net.URL;
/*     */ import java.util.Map;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.ws.BindingProvider;
/*     */ import javax.xml.ws.Dispatch;
/*     */ import javax.xml.ws.Service.Mode;
/*     */ import javax.xml.ws.soap.SOAPBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CfwOperationDateServicePortProxy
/*     */ {
/*     */   protected Descriptor _descriptor;
/*     */   
/*     */   public class Descriptor
/*     */   {
/*  35 */     private CfwOperationDateServiceService _service = null;
/*  36 */     private CfwOperationDateService _proxy = null;
/*  37 */     private Dispatch<Source> _dispatch = null;
/*  38 */     private boolean _useJNDIOnly = false;
/*     */     
/*     */ 
/*     */ 
/*     */     public Descriptor()
/*     */     {
/*  44 */       init();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Descriptor(URL wsdlLocation, QName serviceName)
/*     */     {
/*  53 */       this._service = new CfwOperationDateServiceService(wsdlLocation, serviceName);
/*  54 */       initCommon();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void init()
/*     */     {
/*  61 */       this._service = null;
/*  62 */       this._proxy = null;
/*  63 */       this._dispatch = null;
/*     */       try
/*     */       {
/*  66 */         InitialContext ctx = new InitialContext();
/*  67 */         this._service = ((CfwOperationDateServiceService)ctx.lookup("java:comp/env/service/CfwOperationDateServiceService"));
/*     */       }
/*     */       catch (NamingException e)
/*     */       {
/*  71 */         if ("true".equalsIgnoreCase(System.getProperty("DEBUG_PROXY"))) {
/*  72 */           System.out.println("JNDI lookup failure: javax.naming.NamingException: " + e.getMessage());
/*  73 */           e.printStackTrace(System.out);
/*     */         }
/*     */       }
/*     */       
/*  77 */       if ((this._service == null) && (!this._useJNDIOnly))
/*  78 */         this._service = new CfwOperationDateServiceService();
/*  79 */       initCommon();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private void initCommon()
/*     */     {
/*  86 */       this._proxy = this._service.getCfwOperationDateServicePort();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public CfwOperationDateService getProxy()
/*     */     {
/*  94 */       return this._proxy;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void useJNDIOnly(boolean useJNDIOnly)
/*     */     {
/* 102 */       this._useJNDIOnly = useJNDIOnly;
/* 103 */       init();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Dispatch<Source> getDispatch()
/*     */     {
/* 111 */       if (this._dispatch == null) {
/* 112 */         QName portQName = new QName("", "CfwOperationDateServicePort");
/* 113 */         this._dispatch = this._service.createDispatch(portQName, Source.class, Service.Mode.MESSAGE);
/*     */         
/* 115 */         String proxyEndpointUrl = getEndpoint();
/* 116 */         BindingProvider bp = this._dispatch;
/* 117 */         String dispatchEndpointUrl = (String)bp.getRequestContext().get("javax.xml.ws.service.endpoint.address");
/* 118 */         if (!dispatchEndpointUrl.equals(proxyEndpointUrl))
/* 119 */           bp.getRequestContext().put("javax.xml.ws.service.endpoint.address", proxyEndpointUrl);
/*     */       }
/* 121 */       return this._dispatch;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getEndpoint()
/*     */     {
/* 129 */       BindingProvider bp = (BindingProvider)this._proxy;
/* 130 */       return (String)bp.getRequestContext().get("javax.xml.ws.service.endpoint.address");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setEndpoint(String endpointUrl)
/*     */     {
/* 138 */       BindingProvider bp = (BindingProvider)this._proxy;
/* 139 */       bp.getRequestContext().put("javax.xml.ws.service.endpoint.address", endpointUrl);
/*     */       
/* 141 */       if (this._dispatch != null) {
/* 142 */         bp = this._dispatch;
/* 143 */         bp.getRequestContext().put("javax.xml.ws.service.endpoint.address", endpointUrl);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setMTOMEnabled(boolean enable)
/*     */     {
/* 152 */       SOAPBinding binding = (SOAPBinding)((BindingProvider)this._proxy).getBinding();
/* 153 */       binding.setMTOMEnabled(enable);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public CfwOperationDateServicePortProxy()
/*     */   {
/* 161 */     this._descriptor = new Descriptor();
/* 162 */     this._descriptor.setMTOMEnabled(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwOperationDateServicePortProxy(URL wsdlLocation, QName serviceName)
/*     */   {
/* 171 */     this._descriptor = new Descriptor(wsdlLocation, serviceName);
/* 172 */     this._descriptor.setMTOMEnabled(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Descriptor _getDescriptor()
/*     */   {
/* 180 */     return this._descriptor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String get()
/*     */   {
/* 188 */     return _getDescriptor().getProxy().get();
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\operation\client\CfwOperationDateServicePortProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */