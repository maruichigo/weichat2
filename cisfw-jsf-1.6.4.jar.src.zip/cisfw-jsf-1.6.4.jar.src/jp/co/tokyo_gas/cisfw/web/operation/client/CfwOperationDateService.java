package jp.co.tokyo_gas.cisfw.web.operation.client;

import javax.jws.WebMethod;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

@WebService(name="CfwOperationDateService", targetNamespace="http://provider.operation.cisfw.tokyo_gas.co.jp/")
@XmlSeeAlso({ObjectFactory.class})
public abstract interface CfwOperationDateService
{
  @WebMethod
  @WebResult(targetNamespace="")
  @RequestWrapper(localName="get", targetNamespace="http://provider.operation.cisfw.tokyo_gas.co.jp/", className="jp.co.tokyo_gas.cisfw.web.operation.client.Get")
  @ResponseWrapper(localName="getResponse", targetNamespace="http://provider.operation.cisfw.tokyo_gas.co.jp/", className="jp.co.tokyo_gas.cisfw.web.operation.client.GetResponse")
  public abstract String get();
}


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\operation\client\CfwOperationDateService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */