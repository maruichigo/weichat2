/*    */ package jp.co.tokyo_gas.cisfw.web.operation.client;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="getResponse", propOrder={"_return"})
/*    */ public class GetResponse
/*    */ {
/*    */   @XmlElement(name="return")
/*    */   protected String _return;
/*    */   
/*    */   public String getReturn()
/*    */   {
/* 33 */     return this._return;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setReturn(String value)
/*    */   {
/* 41 */     this._return = value;
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\operation\client\GetResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */