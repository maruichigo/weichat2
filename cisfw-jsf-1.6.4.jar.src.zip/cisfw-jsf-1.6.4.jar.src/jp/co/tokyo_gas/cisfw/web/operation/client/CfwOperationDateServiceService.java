/*     */ package jp.co.tokyo_gas.cisfw.web.operation.client;
/*     */ 
/*     */ import java.net.URL;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.ws.Service;
/*     */ import javax.xml.ws.WebEndpoint;
/*     */ import javax.xml.ws.WebServiceClient;
/*     */ import javax.xml.ws.WebServiceException;
/*     */ import javax.xml.ws.WebServiceFeature;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @WebServiceClient(name="CfwOperationDateServiceService", targetNamespace="http://provider.operation.cisfw.tokyo_gas.co.jp/", wsdlLocation="WEB-INF/wsdl/CfwOperationDateServiceService.wsdl")
/*     */ public class CfwOperationDateServiceService
/*     */   extends Service
/*     */ {
/*     */   private static final URL CFWOPERATIONDATESERVICESERVICE_WSDL_LOCATION;
/*     */   private static final WebServiceException CFWOPERATIONDATESERVICESERVICE_EXCEPTION;
/*  33 */   private static final QName CFWOPERATIONDATESERVICESERVICE_QNAME = new QName("http://provider.operation.cisfw.tokyo_gas.co.jp/", "CfwOperationDateServiceService");
/*     */   
/*     */   static {
/*  36 */     CFWOPERATIONDATESERVICESERVICE_WSDL_LOCATION = CfwOperationDateServiceService.class.getResource("/WEB-INF/wsdl/CfwOperationDateServiceService.wsdl");
/*  37 */     WebServiceException e = null;
/*  38 */     if (CFWOPERATIONDATESERVICESERVICE_WSDL_LOCATION == null) {
/*  39 */       e = new WebServiceException("Cannot find 'WEB-INF/wsdl/CfwOperationDateServiceService.wsdl' wsdl. Place the resource correctly in the classpath.");
/*     */     }
/*  41 */     CFWOPERATIONDATESERVICESERVICE_EXCEPTION = e;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public CfwOperationDateServiceService()
/*     */   {
/*  48 */     super(__getWsdlLocation(), CFWOPERATIONDATESERVICESERVICE_QNAME);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwOperationDateServiceService(WebServiceFeature... features)
/*     */   {
/*  56 */     super(__getWsdlLocation(), CFWOPERATIONDATESERVICESERVICE_QNAME, features);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwOperationDateServiceService(URL wsdlLocation)
/*     */   {
/*  64 */     super(wsdlLocation, CFWOPERATIONDATESERVICESERVICE_QNAME);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwOperationDateServiceService(URL wsdlLocation, WebServiceFeature... features)
/*     */   {
/*  73 */     super(wsdlLocation, CFWOPERATIONDATESERVICESERVICE_QNAME, features);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwOperationDateServiceService(URL wsdlLocation, QName serviceName)
/*     */   {
/*  82 */     super(wsdlLocation, serviceName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwOperationDateServiceService(URL wsdlLocation, QName serviceName, WebServiceFeature... features)
/*     */   {
/*  92 */     super(wsdlLocation, serviceName, features);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @WebEndpoint(name="CfwOperationDateServicePort")
/*     */   public CfwOperationDateService getCfwOperationDateServicePort()
/*     */   {
/* 101 */     return (CfwOperationDateService)super.getPort(new QName("http://provider.operation.cisfw.tokyo_gas.co.jp/", "CfwOperationDateServicePort"), CfwOperationDateService.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @WebEndpoint(name="CfwOperationDateServicePort")
/*     */   public CfwOperationDateService getCfwOperationDateServicePort(WebServiceFeature... features)
/*     */   {
/* 111 */     return (CfwOperationDateService)super.getPort(new QName("http://provider.operation.cisfw.tokyo_gas.co.jp/", "CfwOperationDateServicePort"), CfwOperationDateService.class, features);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static URL __getWsdlLocation()
/*     */   {
/* 119 */     if (CFWOPERATIONDATESERVICESERVICE_EXCEPTION != null) {
/* 120 */       throw CFWOPERATIONDATESERVICESERVICE_EXCEPTION;
/*     */     }
/* 122 */     return CFWOPERATIONDATESERVICESERVICE_WSDL_LOCATION;
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\operation\client\CfwOperationDateServiceService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */