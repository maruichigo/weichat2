/*    */ package jp.co.tokyo_gas.cisfw.web.operation;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import javax.inject.Inject;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import jp.co.tokyo_gas.cisfw.logger.CfwLogger;
/*    */ import jp.co.tokyo_gas.cisfw.operation.CfwOperationDateManager;
/*    */ import jp.co.tokyo_gas.cisfw.utils.CfwDateUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CfwOperationDateServlet
/*    */   extends HttpServlet
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   @Inject
/*    */   private CfwOperationDateManager manager;
/*    */   @Inject
/*    */   private CfwLogger log;
/*    */   
/*    */   public void doGet(HttpServletRequest req, HttpServletResponse res)
/*    */     throws ServletException, IOException
/*    */   {
/* 45 */     this.log.debug("OP日取得処理開始");
/*    */     
/* 47 */     String opDate = CfwDateUtils.getOperationDate();
/*    */     
/* 49 */     String responseJson = "{\"opdate\":\"" + opDate + "\"}";
/* 50 */     this.log.debug("response={}", responseJson);
/*    */     
/* 52 */     res.setContentType("application/json;charset=UTF-8");
/*    */     
/* 54 */     PrintWriter out = res.getWriter();
/* 55 */     out.print(responseJson);
/* 56 */     this.log.debug("OP日取得処理終了");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void doPut(HttpServletRequest req, HttpServletResponse res)
/*    */     throws ServletException, IOException
/*    */   {
/* 67 */     this.log.debug("OP日更新処理開始");
/*    */     
/* 69 */     String opDate = this.manager.get();
/* 70 */     CfwDateUtils.setOperationDate(opDate);
/*    */     
/*    */ 
/* 73 */     doGet(req, res);
/*    */     
/* 75 */     this.log.debug("OP日更新処理終了");
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\operation\CfwOperationDateServlet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */