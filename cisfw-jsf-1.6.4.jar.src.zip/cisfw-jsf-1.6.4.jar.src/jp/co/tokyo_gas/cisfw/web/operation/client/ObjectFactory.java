/*    */ package jp.co.tokyo_gas.cisfw.web.operation.client;
/*    */ 
/*    */ import javax.xml.bind.JAXBElement;
/*    */ import javax.xml.bind.annotation.XmlElementDecl;
/*    */ import javax.xml.bind.annotation.XmlRegistry;
/*    */ import javax.xml.namespace.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlRegistry
/*    */ public class ObjectFactory
/*    */ {
/* 21 */   private static final QName _Get_QNAME = new QName("http://provider.operation.cisfw.tokyo_gas.co.jp/", "get");
/* 22 */   private static final QName _GetResponse_QNAME = new QName("http://provider.operation.cisfw.tokyo_gas.co.jp/", "getResponse");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public GetResponse createGetResponse()
/*    */   {
/* 35 */     return new GetResponse();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Get createGet()
/*    */   {
/* 43 */     return new Get();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   @XmlElementDecl(namespace="http://provider.operation.cisfw.tokyo_gas.co.jp/", name="get")
/*    */   public JAXBElement<Get> createGet(Get value)
/*    */   {
/* 53 */     return new JAXBElement(_Get_QNAME, Get.class, null, value);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   @XmlElementDecl(namespace="http://provider.operation.cisfw.tokyo_gas.co.jp/", name="getResponse")
/*    */   public JAXBElement<GetResponse> createGetResponse(GetResponse value)
/*    */   {
/* 63 */     return new JAXBElement(_GetResponse_QNAME, GetResponse.class, null, value);
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\operation\client\ObjectFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */