/*    */ package jp.co.tokyo_gas.cisfw.web.constantmaster.client;
/*    */ 
/*    */ import javax.xml.bind.JAXBElement;
/*    */ import javax.xml.bind.annotation.XmlElementDecl;
/*    */ import javax.xml.bind.annotation.XmlRegistry;
/*    */ import javax.xml.namespace.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlRegistry
/*    */ public class ObjectFactory
/*    */ {
/* 21 */   private static final QName _GetCfwTransferConstantTypeInfoListResponse_QNAME = new QName("http://provider.constantmaster.cisfw.tokyo_gas.co.jp/", "getCfwTransferConstantTypeInfoListResponse");
/* 22 */   private static final QName _GetCfwTransferConstantTypeInfoList_QNAME = new QName("http://provider.constantmaster.cisfw.tokyo_gas.co.jp/", "getCfwTransferConstantTypeInfoList");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public GetCfwTransferConstantTypeInfoListResponse createGetCfwTransferConstantTypeInfoListResponse()
/*    */   {
/* 35 */     return new GetCfwTransferConstantTypeInfoListResponse();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public GetCfwTransferConstantTypeInfoList createGetCfwTransferConstantTypeInfoList()
/*    */   {
/* 43 */     return new GetCfwTransferConstantTypeInfoList();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public CfwConstantInfo createCfwConstantInfo()
/*    */   {
/* 51 */     return new CfwConstantInfo();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public CfwTransferConstantTypeInfo createCfwTransferConstantTypeInfo()
/*    */   {
/* 59 */     return new CfwTransferConstantTypeInfo();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   @XmlElementDecl(namespace="http://provider.constantmaster.cisfw.tokyo_gas.co.jp/", name="getCfwTransferConstantTypeInfoListResponse")
/*    */   public JAXBElement<GetCfwTransferConstantTypeInfoListResponse> createGetCfwTransferConstantTypeInfoListResponse(GetCfwTransferConstantTypeInfoListResponse value)
/*    */   {
/* 68 */     return new JAXBElement(_GetCfwTransferConstantTypeInfoListResponse_QNAME, GetCfwTransferConstantTypeInfoListResponse.class, null, value);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   @XmlElementDecl(namespace="http://provider.constantmaster.cisfw.tokyo_gas.co.jp/", name="getCfwTransferConstantTypeInfoList")
/*    */   public JAXBElement<GetCfwTransferConstantTypeInfoList> createGetCfwTransferConstantTypeInfoList(GetCfwTransferConstantTypeInfoList value)
/*    */   {
/* 77 */     return new JAXBElement(_GetCfwTransferConstantTypeInfoList_QNAME, GetCfwTransferConstantTypeInfoList.class, null, value);
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\constantmaster\client\ObjectFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */