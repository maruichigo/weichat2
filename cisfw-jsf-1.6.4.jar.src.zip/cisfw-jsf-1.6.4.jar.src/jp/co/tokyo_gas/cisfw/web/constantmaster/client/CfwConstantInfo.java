/*     */ package jp.co.tokyo_gas.cisfw.web.constantmaster.client;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name="cfwConstantInfo", propOrder={"code", "name", "shortName", "subdivisionConstantList", "type", "updateEnabled"})
/*     */ public class CfwConstantInfo
/*     */ {
/*     */   protected String code;
/*     */   protected String type;
/*     */   protected String name;
/*     */   protected String shortName;
/*     */   @XmlElement(nillable=true)
/*     */   protected List<CfwConstantInfo> subdivisionConstantList;
/*     */   protected boolean updateEnabled;
/*     */   
/*     */   public String getCode()
/*     */   {
/*  54 */     return this.code;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCode(String value)
/*     */   {
/*  62 */     this.code = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getType()
/*     */   {
/*  70 */     return this.type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setType(String value)
/*     */   {
/*  78 */     this.type = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/*  86 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setName(String value)
/*     */   {
/*  94 */     this.name = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getShortName()
/*     */   {
/* 102 */     return this.shortName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setShortName(String value)
/*     */   {
/* 110 */     this.shortName = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<CfwConstantInfo> getSubdivisionConstantList()
/*     */   {
/* 118 */     if (this.subdivisionConstantList == null) {
/* 119 */       this.subdivisionConstantList = new ArrayList();
/*     */     }
/* 121 */     return this.subdivisionConstantList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isUpdateEnabled()
/*     */   {
/* 129 */     return this.updateEnabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUpdateEnabled(boolean value)
/*     */   {
/* 137 */     this.updateEnabled = value;
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\constantmaster\client\CfwConstantInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */