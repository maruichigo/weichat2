package jp.co.tokyo_gas.cisfw.web.constantmaster.client;

import java.util.List;
import javax.jws.WebMethod;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

@WebService(name="CfwConstantMasterService", targetNamespace="http://provider.constantmaster.cisfw.tokyo_gas.co.jp/")
@XmlSeeAlso({ObjectFactory.class})
public abstract interface CfwConstantMasterService
{
  @WebMethod
  @WebResult(targetNamespace="")
  @RequestWrapper(localName="getCfwTransferConstantTypeInfoList", targetNamespace="http://provider.constantmaster.cisfw.tokyo_gas.co.jp/", className="jp.co.tokyo_gas.cisfw.web.constantmaster.client.GetCfwTransferConstantTypeInfoList")
  @ResponseWrapper(localName="getCfwTransferConstantTypeInfoListResponse", targetNamespace="http://provider.constantmaster.cisfw.tokyo_gas.co.jp/", className="jp.co.tokyo_gas.cisfw.web.constantmaster.client.GetCfwTransferConstantTypeInfoListResponse")
  public abstract List<CfwTransferConstantTypeInfo> getCfwTransferConstantTypeInfoList();
}


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\constantmaster\client\CfwConstantMasterService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */