/*     */ package jp.co.tokyo_gas.cisfw.web.constantmaster.client;
/*     */ 
/*     */ import java.net.URL;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.ws.Service;
/*     */ import javax.xml.ws.WebEndpoint;
/*     */ import javax.xml.ws.WebServiceClient;
/*     */ import javax.xml.ws.WebServiceException;
/*     */ import javax.xml.ws.WebServiceFeature;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @WebServiceClient(name="CfwConstantMasterServiceService", targetNamespace="http://provider.constantmaster.cisfw.tokyo_gas.co.jp/", wsdlLocation="WEB-INF/wsdl/CfwConstantMasterServiceService.wsdl")
/*     */ public class CfwConstantMasterServiceService
/*     */   extends Service
/*     */ {
/*     */   private static final URL CFWCONSTANTMASTERSERVICESERVICE_WSDL_LOCATION;
/*     */   private static final WebServiceException CFWCONSTANTMASTERSERVICESERVICE_EXCEPTION;
/*  33 */   private static final QName CFWCONSTANTMASTERSERVICESERVICE_QNAME = new QName("http://provider.constantmaster.cisfw.tokyo_gas.co.jp/", "CfwConstantMasterServiceService");
/*     */   
/*     */   static {
/*  36 */     CFWCONSTANTMASTERSERVICESERVICE_WSDL_LOCATION = CfwConstantMasterServiceService.class.getResource("/WEB-INF/wsdl/CfwConstantMasterServiceService.wsdl");
/*  37 */     WebServiceException e = null;
/*  38 */     if (CFWCONSTANTMASTERSERVICESERVICE_WSDL_LOCATION == null) {
/*  39 */       e = new WebServiceException("Cannot find 'WEB-INF/wsdl/CfwConstantMasterServiceService.wsdl' wsdl. Place the resource correctly in the classpath.");
/*     */     }
/*  41 */     CFWCONSTANTMASTERSERVICESERVICE_EXCEPTION = e;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public CfwConstantMasterServiceService()
/*     */   {
/*  48 */     super(__getWsdlLocation(), CFWCONSTANTMASTERSERVICESERVICE_QNAME);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwConstantMasterServiceService(WebServiceFeature... features)
/*     */   {
/*  56 */     super(__getWsdlLocation(), CFWCONSTANTMASTERSERVICESERVICE_QNAME, features);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwConstantMasterServiceService(URL wsdlLocation)
/*     */   {
/*  64 */     super(wsdlLocation, CFWCONSTANTMASTERSERVICESERVICE_QNAME);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwConstantMasterServiceService(URL wsdlLocation, WebServiceFeature... features)
/*     */   {
/*  73 */     super(wsdlLocation, CFWCONSTANTMASTERSERVICESERVICE_QNAME, features);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwConstantMasterServiceService(URL wsdlLocation, QName serviceName)
/*     */   {
/*  82 */     super(wsdlLocation, serviceName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwConstantMasterServiceService(URL wsdlLocation, QName serviceName, WebServiceFeature... features)
/*     */   {
/*  92 */     super(wsdlLocation, serviceName, features);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @WebEndpoint(name="CfwConstantMasterServicePort")
/*     */   public CfwConstantMasterService getCfwConstantMasterServicePort()
/*     */   {
/* 101 */     return (CfwConstantMasterService)super.getPort(new QName("http://provider.constantmaster.cisfw.tokyo_gas.co.jp/", "CfwConstantMasterServicePort"), CfwConstantMasterService.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @WebEndpoint(name="CfwConstantMasterServicePort")
/*     */   public CfwConstantMasterService getCfwConstantMasterServicePort(WebServiceFeature... features)
/*     */   {
/* 111 */     return (CfwConstantMasterService)super.getPort(new QName("http://provider.constantmaster.cisfw.tokyo_gas.co.jp/", "CfwConstantMasterServicePort"), CfwConstantMasterService.class, features);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static URL __getWsdlLocation()
/*     */   {
/* 119 */     if (CFWCONSTANTMASTERSERVICESERVICE_EXCEPTION != null) {
/* 120 */       throw CFWCONSTANTMASTERSERVICESERVICE_EXCEPTION;
/*     */     }
/* 122 */     return CFWCONSTANTMASTERSERVICESERVICE_WSDL_LOCATION;
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\constantmaster\client\CfwConstantMasterServiceService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */