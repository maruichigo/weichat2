/*     */ package jp.co.tokyo_gas.cisfw.web.constantmaster.client;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.net.URL;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.ws.BindingProvider;
/*     */ import javax.xml.ws.Dispatch;
/*     */ import javax.xml.ws.Service.Mode;
/*     */ import javax.xml.ws.soap.SOAPBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CfwConstantMasterServicePortProxy
/*     */ {
/*     */   protected Descriptor _descriptor;
/*     */   
/*     */   public class Descriptor
/*     */   {
/*  36 */     private CfwConstantMasterServiceService _service = null;
/*  37 */     private CfwConstantMasterService _proxy = null;
/*  38 */     private Dispatch<Source> _dispatch = null;
/*  39 */     private boolean _useJNDIOnly = false;
/*     */     
/*     */ 
/*     */ 
/*     */     public Descriptor()
/*     */     {
/*  45 */       init();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Descriptor(URL wsdlLocation, QName serviceName)
/*     */     {
/*  54 */       this._service = new CfwConstantMasterServiceService(wsdlLocation, serviceName);
/*  55 */       initCommon();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void init()
/*     */     {
/*  62 */       this._service = null;
/*  63 */       this._proxy = null;
/*  64 */       this._dispatch = null;
/*     */       try
/*     */       {
/*  67 */         InitialContext ctx = new InitialContext();
/*  68 */         this._service = ((CfwConstantMasterServiceService)ctx.lookup("java:comp/env/service/CfwConstantMasterServiceService"));
/*     */       }
/*     */       catch (NamingException e)
/*     */       {
/*  72 */         if ("true".equalsIgnoreCase(System.getProperty("DEBUG_PROXY"))) {
/*  73 */           System.out.println("JNDI lookup failure: javax.naming.NamingException: " + e.getMessage());
/*  74 */           e.printStackTrace(System.out);
/*     */         }
/*     */       }
/*     */       
/*  78 */       if ((this._service == null) && (!this._useJNDIOnly))
/*  79 */         this._service = new CfwConstantMasterServiceService();
/*  80 */       initCommon();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private void initCommon()
/*     */     {
/*  87 */       this._proxy = this._service.getCfwConstantMasterServicePort();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public CfwConstantMasterService getProxy()
/*     */     {
/*  95 */       return this._proxy;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void useJNDIOnly(boolean useJNDIOnly)
/*     */     {
/* 103 */       this._useJNDIOnly = useJNDIOnly;
/* 104 */       init();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Dispatch<Source> getDispatch()
/*     */     {
/* 112 */       if (this._dispatch == null) {
/* 113 */         QName portQName = new QName("", "CfwConstantMasterServicePort");
/* 114 */         this._dispatch = this._service.createDispatch(portQName, Source.class, Service.Mode.MESSAGE);
/*     */         
/* 116 */         String proxyEndpointUrl = getEndpoint();
/* 117 */         BindingProvider bp = this._dispatch;
/* 118 */         String dispatchEndpointUrl = (String)bp.getRequestContext().get("javax.xml.ws.service.endpoint.address");
/* 119 */         if (!dispatchEndpointUrl.equals(proxyEndpointUrl))
/* 120 */           bp.getRequestContext().put("javax.xml.ws.service.endpoint.address", proxyEndpointUrl);
/*     */       }
/* 122 */       return this._dispatch;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getEndpoint()
/*     */     {
/* 130 */       BindingProvider bp = (BindingProvider)this._proxy;
/* 131 */       return (String)bp.getRequestContext().get("javax.xml.ws.service.endpoint.address");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setEndpoint(String endpointUrl)
/*     */     {
/* 139 */       BindingProvider bp = (BindingProvider)this._proxy;
/* 140 */       bp.getRequestContext().put("javax.xml.ws.service.endpoint.address", endpointUrl);
/*     */       
/* 142 */       if (this._dispatch != null) {
/* 143 */         bp = this._dispatch;
/* 144 */         bp.getRequestContext().put("javax.xml.ws.service.endpoint.address", endpointUrl);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setMTOMEnabled(boolean enable)
/*     */     {
/* 153 */       SOAPBinding binding = (SOAPBinding)((BindingProvider)this._proxy).getBinding();
/* 154 */       binding.setMTOMEnabled(enable);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public CfwConstantMasterServicePortProxy()
/*     */   {
/* 162 */     this._descriptor = new Descriptor();
/* 163 */     this._descriptor.setMTOMEnabled(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwConstantMasterServicePortProxy(URL wsdlLocation, QName serviceName)
/*     */   {
/* 172 */     this._descriptor = new Descriptor(wsdlLocation, serviceName);
/* 173 */     this._descriptor.setMTOMEnabled(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Descriptor _getDescriptor()
/*     */   {
/* 181 */     return this._descriptor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<CfwTransferConstantTypeInfo> getCfwTransferConstantTypeInfoList()
/*     */   {
/* 189 */     return _getDescriptor().getProxy().getCfwTransferConstantTypeInfoList();
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\constantmaster\client\CfwConstantMasterServicePortProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */