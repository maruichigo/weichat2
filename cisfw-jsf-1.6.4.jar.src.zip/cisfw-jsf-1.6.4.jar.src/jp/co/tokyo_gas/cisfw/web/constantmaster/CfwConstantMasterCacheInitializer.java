/*     */ package jp.co.tokyo_gas.cisfw.web.constantmaster;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.annotation.PostConstruct;
/*     */ import javax.enterprise.context.ApplicationScoped;
/*     */ import javax.inject.Inject;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.config.FwConfig;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.init.FwInitializer;
/*     */ import jp.co.tokyo_gas.cisfw.constantmaster.CfwConstantMasterCache;
/*     */ import jp.co.tokyo_gas.cisfw.exception.CfwRuntimeException;
/*     */ import jp.co.tokyo_gas.cisfw.logger.CfwLogger;
/*     */ import jp.co.tokyo_gas.cisfw.web.constantmaster.client.CfwConstantMasterService;
/*     */ import jp.co.tokyo_gas.cisfw.web.constantmaster.client.CfwConstantMasterServiceService;
/*     */ import jp.co.tokyo_gas.cisfw.web.ws.CfwServiceFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ApplicationScoped
/*     */ public class CfwConstantMasterCacheInitializer
/*     */   implements FwInitializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   @Inject
/*     */   private CfwLogger logger;
/*     */   @Inject
/*     */   private CfwConstantMasterCache constantMasterCache;
/*     */   @Inject
/*     */   private CfwServiceFactory factory;
/*     */   @Inject
/*     */   private FwConfig config;
/*     */   
/*     */   @PostConstruct
/*     */   public void initialize()
/*     */   {
/*  56 */     if ("true".equals(this.config.get("ear.integration", "false"))) {
/*  57 */       this.logger.debug("初期化スキップします。対象クラス={}", getClass().getName());
/*  58 */       return;
/*     */     }
/*     */     try
/*     */     {
/*  62 */       this.logger.debug("コンスタントマスタキャッシュ初期化開始");
/*     */       
/*     */ 
/*  65 */       CfwConstantMasterService service = (CfwConstantMasterService)this.factory.createSEI(CfwConstantMasterServiceService.class, CfwConstantMasterService.class);
/*     */       
/*     */ 
/*  68 */       List<jp.co.tokyo_gas.cisfw.web.constantmaster.client.CfwTransferConstantTypeInfo> transferConstanttypeInfoList = service.getCfwTransferConstantTypeInfoList();
/*     */       
/*     */ 
/*  71 */       Map<String, List<jp.co.tokyo_gas.cisfw.constantmaster.CfwConstantInfo>> constantInfoMap = new HashMap();
/*     */       
/*  73 */       for (jp.co.tokyo_gas.cisfw.web.constantmaster.client.CfwTransferConstantTypeInfo transferConstantTypeInfo : transferConstanttypeInfoList)
/*     */       {
/*  75 */         jp.co.tokyo_gas.cisfw.constantmaster.CfwTransferConstantTypeInfo info = new jp.co.tokyo_gas.cisfw.constantmaster.CfwTransferConstantTypeInfo();
/*  76 */         info.setType(transferConstantTypeInfo.getType());
/*     */         
/*  78 */         List<jp.co.tokyo_gas.cisfw.constantmaster.CfwConstantInfo> constantInfoList = convert(transferConstantTypeInfo.getInfo());
/*     */         
/*  80 */         constantInfoMap.put(transferConstantTypeInfo.getType(), constantInfoList);
/*     */       }
/*     */       
/*     */ 
/*  84 */       this.constantMasterCache.setConstantMasterMap(constantInfoMap);
/*     */       
/*  86 */       this.logger.debug("コンスタントマスタキャッシュ初期化終了");
/*     */     }
/*     */     catch (Exception e) {
/*  89 */       throw new CfwRuntimeException("アプリケーション初期化処理に失敗しました。", e, new Object[0]);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<jp.co.tokyo_gas.cisfw.constantmaster.CfwConstantInfo> convert(List<jp.co.tokyo_gas.cisfw.web.constantmaster.client.CfwConstantInfo> list)
/*     */   {
/*  99 */     List<jp.co.tokyo_gas.cisfw.constantmaster.CfwConstantInfo> results = new ArrayList();
/* 100 */     for (jp.co.tokyo_gas.cisfw.web.constantmaster.client.CfwConstantInfo clientConstantInfo : list) {
/* 101 */       jp.co.tokyo_gas.cisfw.constantmaster.CfwConstantInfo constantInfo = new jp.co.tokyo_gas.cisfw.constantmaster.CfwConstantInfo();
/* 102 */       constantInfo.setCode(clientConstantInfo.getCode());
/* 103 */       constantInfo.setType(clientConstantInfo.getType());
/* 104 */       constantInfo.setName(clientConstantInfo.getName());
/* 105 */       constantInfo.setShortName(clientConstantInfo.getShortName());
/* 106 */       constantInfo.setUpdateEnabled(clientConstantInfo.isUpdateEnabled());
/* 107 */       constantInfo.setSubdivisionConstantList(convert(clientConstantInfo.getSubdivisionConstantList()));
/* 108 */       results.add(constantInfo);
/*     */     }
/* 110 */     return results;
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\constantmaster\CfwConstantMasterCacheInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */