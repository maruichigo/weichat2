/*    */ package jp.co.tokyo_gas.cisfw.web.constantmaster.client;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="cfwTransferConstantTypeInfo", propOrder={"info", "type"})
/*    */ public class CfwTransferConstantTypeInfo
/*    */ {
/*    */   @XmlElement(nillable=true)
/*    */   protected List<CfwConstantInfo> info;
/*    */   protected String type;
/*    */   
/*    */   public List<CfwConstantInfo> getInfo()
/*    */   {
/* 39 */     if (this.info == null) {
/* 40 */       this.info = new ArrayList();
/*    */     }
/* 42 */     return this.info;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getType()
/*    */   {
/* 50 */     return this.type;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setType(String value)
/*    */   {
/* 58 */     this.type = value;
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\constantmaster\client\CfwTransferConstantTypeInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */