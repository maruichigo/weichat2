/*     */ package jp.co.tokyo_gas.cisfw.web.ws;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.enterprise.context.RequestScoped;
/*     */ import javax.enterprise.inject.Instance;
/*     */ import javax.enterprise.inject.spi.CDI;
/*     */ import javax.faces.component.UIViewRoot;
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.ws.handler.MessageContext;
/*     */ import javax.xml.ws.handler.soap.SOAPHandler;
/*     */ import javax.xml.ws.handler.soap.SOAPMessageContext;
/*     */ import jp.co.tokyo_gas.cisfw.converter.CfwJSONConverter;
/*     */ import jp.co.tokyo_gas.cisfw.sql.CfwDBInfoHolder;
/*     */ import jp.co.tokyo_gas.cisfw.web.CfwSession;
/*     */ import jp.co.tokyo_gas.cisfw.web.CfwUserInfo;
/*     */ import jp.co.tokyo_gas.cisfw.ws.CfwCommunicationLogInfoHolder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @RequestScoped
/*     */ public class CfwClientUserInfoHandler
/*     */   implements SOAPHandler<SOAPMessageContext>
/*     */ {
/*     */   public boolean handleMessage(SOAPMessageContext context)
/*     */   {
/*  47 */     Boolean messageOutboundProperty = (Boolean)context.get("javax.xml.ws.handler.message.outbound");
/*  48 */     if (messageOutboundProperty.booleanValue())
/*     */     {
/*     */ 
/*  51 */       CfwSession session = (CfwSession)CDI.current().select(CfwSession.class, new Annotation[0]).get();
/*     */       
/*  53 */       CfwDBInfoHolder holder = (CfwDBInfoHolder)CDI.current().select(CfwDBInfoHolder.class, new Annotation[0]).get();
/*     */       
/*  55 */       CfwCommunicationLogInfoHolder communicationHolder = (CfwCommunicationLogInfoHolder)CDI.current().select(CfwCommunicationLogInfoHolder.class, new Annotation[0]).get();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  60 */       HashMap<String, List<String>> headerMap = (HashMap)context.get("FW_REQUEST_HEADERS");
/*     */       
/*  62 */       if (headerMap == null) {
/*  63 */         headerMap = new HashMap();
/*     */       }
/*     */       
/*     */ 
/*  67 */       headerMap.put("X-CFW-DB-SWITCH", Arrays.asList(new String[] { holder.getDatasourceSwitch() }));
/*     */       
/*  69 */       headerMap.put("X-START-FUNCTION-ID", Arrays.asList(new String[] { communicationHolder.getStartFunctionId() }));
/*     */       
/*  71 */       if ((isGetUserInfoEnable()) && 
/*  72 */         (session.getUserInfo() != null))
/*     */       {
/*  74 */         headerMap.put("X-DUKE-ID", Arrays.asList(new String[] { toJSON(toMap(session.getUserInfo())) }));
/*     */         
/*  76 */         headerMap.put("X-READ-ONLY_FLG", Arrays.asList(new String[] { session.getUserInfo().getDefaultNonUpdatableFlg() }));
/*     */       }
/*     */       
/*     */ 
/*  80 */       context.put("FW_REQUEST_HEADERS", headerMap);
/*     */     }
/*     */     
/*  83 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isGetUserInfoEnable()
/*     */   {
/*  91 */     FacesContext context = FacesContext.getCurrentInstance();
/*  92 */     if (context == null) {
/*  93 */       return false;
/*     */     }
/*  95 */     UIViewRoot viewRoot = context.getViewRoot();
/*  96 */     if (viewRoot == null) {
/*  97 */       return false;
/*     */     }
/*  99 */     String viewId = viewRoot.getViewId();
/* 100 */     if (viewId == null) {
/* 101 */       return false;
/*     */     }
/* 103 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Map<String, Object> toMap(CfwUserInfo info)
/*     */   {
/* 112 */     Map<String, Object> infoMap = new HashMap();
/* 113 */     infoMap.put("dukeId", info.getDukeId());
/* 114 */     infoMap.put("compKbn", info.getCompKbn());
/* 115 */     infoMap.put("compCd", info.getCompCd());
/* 116 */     infoMap.put("officeCd", info.getOfficeCd());
/* 117 */     infoMap.put("departmentCd", info.getDepartmentCd());
/* 118 */     infoMap.put("workplaceCd", info.getWorkplaceCd());
/* 119 */     infoMap.put("nwPlaceCd", info.getNwPlaceCd());
/* 120 */     infoMap.put("allowedAuthorityCd", info.getAllowedAuthorityCd());
/* 121 */     return infoMap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String toJSON(Map<String, Object> map)
/*     */   {
/* 130 */     CfwJSONConverter<Map> converter = CfwJSONConverter.getConverter(Map.class);
/* 131 */     return converter.encode(map);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean handleFault(SOAPMessageContext context)
/*     */   {
/* 141 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close(MessageContext context) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<QName> getHeaders()
/*     */   {
/* 160 */     return Collections.emptySet();
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\ws\CfwClientUserInfoHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */