/*    */ package jp.co.tokyo_gas.cisfw.web.ws;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import javax.enterprise.context.Dependent;
/*    */ import javax.inject.Inject;
/*    */ import javax.xml.ws.Service;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.ws.client.FwWSClientFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Dependent
/*    */ public class CfwServiceFactory
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   @Inject
/*    */   private transient FwWSClientFactory factory;
/*    */   
/*    */   public <T extends Service, K> K createSEI(Class<T> serviceClass, Class<K> serviceEndpointInterface)
/*    */   {
/* 46 */     K endPoint = this.factory.createSEI(serviceClass, serviceEndpointInterface);
/* 47 */     return endPoint;
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\ws\CfwServiceFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */