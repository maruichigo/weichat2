/*     */ package jp.co.tokyo_gas.cisfw.web;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import javax.enterprise.context.SessionScoped;
/*     */ import javax.faces.context.ExternalContext;
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.faces.lifecycle.ClientWindow;
/*     */ import javax.inject.Inject;
/*     */ import javax.inject.Named;
/*     */ import jp.co.tokyo_gas.cisfw.converter.CfwJSONConverter;
/*     */ import jp.co.tokyo_gas.cisfw.exception.CfwRuntimeException;
/*     */ import jp.co.tokyo_gas.cisfw.logger.CfwLogger;
/*     */ import jp.co.tokyo_gas.cisfw.web.print.CfwPrintSession;
/*     */ import jp.co.tokyo_gas.cisfw.web.utils.CfwCountStream;
/*     */ import org.apache.commons.lang3.SerializationUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Named("cfwSession")
/*     */ @SessionScoped
/*     */ public class CfwSession
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   public static final String MAIN_WINDOW = "CFW_MAIN_WINDOW";
/*     */   private CfwUserInfo userInfo;
/*     */   private Map<String, CfwAppData> appDataMap;
/*     */   private Map<String, String> windowKeyMap;
/*     */   private Date loginTime;
/*     */   @Inject
/*     */   private transient CfwLogger log;
/*     */   @Inject
/*     */   private CfwPrintSession cfwPrintSession;
/*     */   
/*     */   public CfwSession()
/*     */   {
/*  67 */     this.appDataMap = new HashMap();
/*  68 */     this.windowKeyMap = new HashMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwUserInfo getUserInfo()
/*     */   {
/*  77 */     return this.userInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getLoginTime()
/*     */   {
/*  87 */     return this.loginTime;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLoginTime(Date time)
/*     */   {
/*  97 */     this.loginTime = time;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/* 105 */     this.loginTime = null;
/* 106 */     this.userInfo = null;
/*     */     
/* 108 */     this.appDataMap.clear();
/* 109 */     this.windowKeyMap.clear();
/*     */     
/* 111 */     this.cfwPrintSession.clearAll();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object get(Object key)
/*     */   {
/* 121 */     return getCfwSessionData().get(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void put(Object key, Object value)
/*     */   {
/* 131 */     getCfwSessionData().put(key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean removeSessionData(Object key)
/*     */   {
/* 141 */     return getCfwSessionData().remove(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void removeAll(String clientId)
/*     */   {
/* 151 */     removeAll();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeAll()
/*     */   {
/* 161 */     this.appDataMap.clear();
/*     */     
/*     */ 
/* 164 */     this.appDataMap.put("CFW_MAIN_WINDOW", new CfwAppData());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String peekScreen(String windowKey)
/*     */   {
/* 174 */     CfwAppData appData = (CfwAppData)this.appDataMap.get(windowKey);
/* 175 */     if ((appData == null) || (appData.getScreenStack() == null)) {
/* 176 */       return null;
/*     */     }
/*     */     
/* 179 */     Stack<String> stack = appData.getScreenStack();
/* 180 */     if (stack.isEmpty()) {
/* 181 */       return null;
/*     */     }
/* 183 */     return (String)stack.peek();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int size()
/*     */   {
/* 193 */     CfwCountStream counter = new CfwCountStream();
/* 194 */     SerializationUtils.serialize(this, counter);
/* 195 */     return counter.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   protected void pushScreen(String screenId, String clientId) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String popScreen(String windowKey)
/*     */   {
/* 218 */     CfwAppData appData = (CfwAppData)this.appDataMap.get(windowKey);
/* 219 */     if ((appData == null) || (appData.getScreenStack() == null)) {
/* 220 */       return null;
/*     */     }
/*     */     
/* 223 */     Stack<String> stack = appData.getScreenStack();
/* 224 */     if (stack.isEmpty()) {
/* 225 */       return null;
/*     */     }
/* 227 */     return (String)stack.pop();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUserInfo(CfwUserInfo userInfo)
/*     */   {
/* 237 */     this.userInfo = userInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLog(CfwLogger log)
/*     */   {
/* 246 */     this.log = log;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<Object, Object> getSessionData()
/*     */   {
/* 255 */     return getCfwSessionData().getData();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public Map<String, Stack<String>> getScreenStackMap()
/*     */   {
/* 265 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwSessionData getCfwSessionData()
/*     */   {
/* 274 */     return getCfwSessionData("CFW_MAIN_WINDOW");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwSpecificCustomerInfo getCfwSpecificCustomerInfo()
/*     */   {
/* 283 */     return getCfwSpecificCustomerInfo("CFW_MAIN_WINDOW");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwSearchConditionInfo getCfwSearchConditionInfo()
/*     */   {
/* 292 */     return getCfwSearchConditionInfo("CFW_MAIN_WINDOW");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getCurrent(Object key)
/*     */   {
/* 302 */     return getCurrentCfwSessionData().get(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void putCurrent(Object key, Object value)
/*     */   {
/* 312 */     getCurrentCfwSessionData().put(key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean removeCurrentSessionData(Object key)
/*     */   {
/* 321 */     return getCurrentCfwSessionData().remove(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Stack<String> getScreenStack()
/*     */   {
/* 330 */     return getScreenStack("CFW_MAIN_WINDOW");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String popScreen()
/*     */   {
/* 339 */     return popScreen(getWindowKey());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String peekScreen()
/*     */   {
/* 347 */     return peekScreen(getWindowKey());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<Object, Object> getSessionData(String windowKey)
/*     */   {
/* 356 */     return getCfwSessionData(windowKey).getData();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Stack<String> getScreenStack(String windowKey)
/*     */   {
/* 366 */     CfwAppData appData = getCfwAppData(windowKey);
/* 367 */     return appData.getScreenStack();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwSessionData getCfwSessionData(String windowKey)
/*     */   {
/* 377 */     CfwAppData appData = getCfwAppData(windowKey);
/* 378 */     return appData.getCfwSessionData();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwSpecificCustomerInfo getCfwSpecificCustomerInfo(String windowKey)
/*     */   {
/* 388 */     CfwAppData appData = getCfwAppData(windowKey);
/* 389 */     return appData.getCfwSpecificCustomerInfo();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwSearchConditionInfo getCfwSearchConditionInfo(String windowKey)
/*     */   {
/* 399 */     CfwAppData appData = getCfwAppData(windowKey);
/* 400 */     return appData.getCfwSearchConditionInfo();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<Object, Object> getCurrentSessionData()
/*     */   {
/* 409 */     return getCurrentCfwSessionData().getData();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Stack<String> getCurrentScreenStack()
/*     */   {
/* 418 */     CfwAppData appData = getCfwAppData(getWindowKey());
/* 419 */     return appData.getScreenStack();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwSessionData getCurrentCfwSessionData()
/*     */   {
/* 428 */     return getCfwSessionData(getWindowKey());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwSpecificCustomerInfo getCurrentCfwSpecificCustomerInfo()
/*     */   {
/* 437 */     return getCfwSpecificCustomerInfo(getWindowKey());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwSearchConditionInfo getCurrentCfwSearchConditionInfo()
/*     */   {
/* 446 */     return getCfwSearchConditionInfo(getWindowKey());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void createSession()
/*     */   {
/* 454 */     this.appDataMap.put("CFW_MAIN_WINDOW", new CfwAppData());
/* 455 */     this.windowKeyMap.put(getClientWindowId(), "CFW_MAIN_WINDOW");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void createWindowSession(String windowKey)
/*     */   {
/* 464 */     CfwAppData appData = (CfwAppData)this.appDataMap.get(windowKey);
/* 465 */     if (appData != null) {
/* 466 */       appData.clear();
/* 467 */       this.appDataMap.remove(windowKey);
/*     */     }
/* 469 */     this.appDataMap.put(windowKey, new CfwAppData());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void putWindowKeyMap(String windowKey)
/*     */   {
/* 478 */     this.windowKeyMap.put(getClientWindowId(), windowKey);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getWindowKey()
/*     */   {
/* 486 */     return (String)this.windowKeyMap.get(getClientWindowId());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getClientWindowId()
/*     */   {
/* 495 */     FacesContext context = FacesContext.getCurrentInstance();
/* 496 */     ClientWindow clientWindow = context.getExternalContext().getClientWindow();
/*     */     
/* 498 */     String clientWindowId = "clientId";
/* 499 */     if (clientWindow != null) {
/* 500 */       clientWindowId = clientWindow.getId();
/*     */     }
/*     */     
/* 503 */     return clientWindowId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void removeWindowKeyMap(String clientId)
/*     */   {
/* 511 */     this.windowKeyMap.remove(clientId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeSession()
/*     */   {
/* 520 */     this.log.info("userInfo={}", toJSON(this.userInfo));
/*     */     
/* 522 */     Iterator<String> keys = this.appDataMap.keySet().iterator();
/* 523 */     while (keys.hasNext()) {
/* 524 */       String key = (String)keys.next();
/* 525 */       this.log.info("[{}]={}", key, toJSON(this.appDataMap.get(key)));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private <T> String toJSON(T t)
/*     */   {
/* 537 */     if (t == null) {
/* 538 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 543 */     CfwJSONConverter<T> converter = CfwJSONConverter.getConverter(t.getClass());
/* 544 */     return converter.encode(t);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, CfwAppData> getAppDataMap()
/*     */   {
/* 552 */     return this.appDataMap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private CfwAppData getCfwAppData(String windowKey)
/*     */   {
/* 562 */     if (windowKey == null) {
/* 563 */       windowKey = "CFW_MAIN_WINDOW";
/*     */     }
/*     */     
/* 566 */     CfwAppData data = (CfwAppData)this.appDataMap.get(windowKey);
/* 567 */     if (data == null)
/*     */     {
/* 569 */       if ("CFW_MAIN_WINDOW".equals(windowKey)) {
/* 570 */         createSession();
/* 571 */         data = (CfwAppData)this.appDataMap.get(windowKey);
/*     */       } else {
/* 573 */         throw new CfwRuntimeException(String.format("[%s]に対応するセッション領域がありません。", new Object[] { windowKey }), new Object[0]);
/*     */       }
/*     */     }
/* 576 */     return data;
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\CfwSession.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */