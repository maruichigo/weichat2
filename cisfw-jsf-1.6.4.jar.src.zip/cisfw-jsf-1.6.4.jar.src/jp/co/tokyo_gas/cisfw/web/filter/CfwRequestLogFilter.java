/*     */ package jp.co.tokyo_gas.cisfw.web.filter;
/*     */ 
/*     */ import javax.inject.Inject;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.config.FwConfig;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.logger.FwMDC;
/*     */ import jp.co.tokyo_gas.cisfw.logger.CfwLogger;
/*     */ import jp.co.tokyo_gas.cisfw.utils.CfwLogHelper;
/*     */ import jp.co.tokyo_gas.cisfw.web.CfwSession;
/*     */ import jp.co.tokyo_gas.cisfw.web.CfwUserInfo;
/*     */ import jp.co.tokyo_gas.cisfw.web.menu.CfwMenuUtil;
/*     */ import jp.co.tokyo_gas.cisfw.ws.CfwCommunicationLogInfoHolder;
/*     */ 
/*     */ public class CfwRequestLogFilter
/*     */   implements Filter
/*     */ {
/*     */   @Inject
/*     */   private CfwLogger log;
/*     */   @Inject
/*     */   private CfwLogger statisticsLog;
/*     */   @Inject
/*     */   private CfwSession session;
/*     */   @Inject
/*     */   private CfwCommunicationLogInfoHolder holder;
/*     */   @Inject
/*     */   private FwConfig fwConfig;
/*     */   @Inject
/*     */   private CfwLogHelper helper;
/*     */   @Inject
/*     */   private FwMDC mdc;
/*     */   @Inject
/*     */   private CfwMenuUtil util;
/*     */   
/*     */   public void destroy() {}
/*     */   
/*     */   public void init(FilterConfig config) {}
/*     */   
/*     */   /* Error */
/*     */   public void doFilter(javax.servlet.ServletRequest request, javax.servlet.ServletResponse response, javax.servlet.FilterChain chain)
/*     */     throws java.io.IOException, javax.servlet.ServletException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: invokestatic 4	jp/co/tokyo_gas/cisfw/logger/impl/CfwLoggerFactory:getFactory	()Ljp/co/tokyo_gas/cisfw/logger/impl/CfwLoggerFactory;
/*     */     //   3: astore 4
/*     */     //   5: aload_0
/*     */     //   6: aload 4
/*     */     //   8: new 5	java/lang/StringBuilder
/*     */     //   11: dup
/*     */     //   12: invokespecial 6	java/lang/StringBuilder:<init>	()V
/*     */     //   15: aload_0
/*     */     //   16: invokevirtual 7	java/lang/Object:getClass	()Ljava/lang/Class;
/*     */     //   19: invokevirtual 8	java/lang/Class:getName	()Ljava/lang/String;
/*     */     //   22: invokevirtual 9	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   25: ldc 10
/*     */     //   27: invokevirtual 9	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   30: invokevirtual 11	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   33: invokevirtual 12	jp/co/tokyo_gas/cisfw/logger/impl/CfwLoggerFactory:createCfwLogger	(Ljava/lang/String;)Ljp/co/tokyo_gas/cisfw/logger/CfwLogger;
/*     */     //   36: putfield 13	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:statisticsLog	Ljp/co/tokyo_gas/cisfw/logger/CfwLogger;
/*     */     //   39: aload_1
/*     */     //   40: checkcast 14	javax/servlet/http/HttpServletRequest
/*     */     //   43: astore 5
/*     */     //   45: aload 5
/*     */     //   47: ldc 15
/*     */     //   49: invokeinterface 16 2 0
/*     */     //   54: astore 6
/*     */     //   56: aload 6
/*     */     //   58: invokestatic 17	jp/co/tokyo_gas/aion/tgfw/parts/string/FwStringValidator:isEmpty	(Ljava/lang/String;)Z
/*     */     //   61: ifeq +10 -> 71
/*     */     //   64: ldc 18
/*     */     //   66: astore 6
/*     */     //   68: goto +42 -> 110
/*     */     //   71: aload 6
/*     */     //   73: ldc 19
/*     */     //   75: invokevirtual 20	java/lang/String:split	(Ljava/lang/String;)[Ljava/lang/String;
/*     */     //   78: astore 7
/*     */     //   80: aload 7
/*     */     //   82: aload 7
/*     */     //   84: arraylength
/*     */     //   85: iconst_1
/*     */     //   86: isub
/*     */     //   87: aaload
/*     */     //   88: astore 6
/*     */     //   90: ldc 21
/*     */     //   92: aload 6
/*     */     //   94: invokevirtual 22	java/lang/String:equals	(Ljava/lang/Object;)Z
/*     */     //   97: ifeq +13 -> 110
/*     */     //   100: aload 7
/*     */     //   102: aload 7
/*     */     //   104: arraylength
/*     */     //   105: iconst_2
/*     */     //   106: isub
/*     */     //   107: aaload
/*     */     //   108: astore 6
/*     */     //   110: aload_0
/*     */     //   111: aload 5
/*     */     //   113: invokevirtual 23	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:isExcludePattern	(Ljavax/servlet/http/HttpServletRequest;)Z
/*     */     //   116: ifeq +12 -> 128
/*     */     //   119: aload_3
/*     */     //   120: aload_1
/*     */     //   121: aload_2
/*     */     //   122: invokeinterface 24 3 0
/*     */     //   127: return
/*     */     //   128: invokestatic 25	java/lang/System:currentTimeMillis	()J
/*     */     //   131: lstore 7
/*     */     //   133: aload 5
/*     */     //   135: invokeinterface 26 1 0
/*     */     //   140: astore 9
/*     */     //   142: aload_0
/*     */     //   143: aload 5
/*     */     //   145: invokevirtual 27	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:getHttpSessionId	(Ljavax/servlet/http/HttpServletRequest;)Ljava/lang/String;
/*     */     //   148: astore 10
/*     */     //   150: aconst_null
/*     */     //   151: astore 11
/*     */     //   153: aload 5
/*     */     //   155: ldc 28
/*     */     //   157: invokeinterface 29 2 0
/*     */     //   162: astore 12
/*     */     //   164: aload 12
/*     */     //   166: invokestatic 17	jp/co/tokyo_gas/aion/tgfw/parts/string/FwStringValidator:isEmpty	(Ljava/lang/String;)Z
/*     */     //   169: ifne +21 -> 190
/*     */     //   172: aload 12
/*     */     //   174: ldc 30
/*     */     //   176: invokevirtual 20	java/lang/String:split	(Ljava/lang/String;)[Ljava/lang/String;
/*     */     //   179: astore 13
/*     */     //   181: aload 13
/*     */     //   183: iconst_0
/*     */     //   184: aaload
/*     */     //   185: astore 11
/*     */     //   187: goto +12 -> 199
/*     */     //   190: aload 5
/*     */     //   192: invokeinterface 31 1 0
/*     */     //   197: astore 11
/*     */     //   199: aload_0
/*     */     //   200: aload_0
/*     */     //   201: getfield 32	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:session	Ljp/co/tokyo_gas/cisfw/web/CfwSession;
/*     */     //   204: invokevirtual 33	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:getDukeId	(Ljp/co/tokyo_gas/cisfw/web/CfwSession;)Ljava/lang/String;
/*     */     //   207: astore 13
/*     */     //   209: aload_0
/*     */     //   210: getfield 34	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:fwConfig	Ljp/co/tokyo_gas/aion/tgfw/parts/config/FwConfig;
/*     */     //   213: ldc 36
/*     */     //   215: invokevirtual 37	jp/co/tokyo_gas/aion/tgfw/parts/config/FwConfig:get	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   218: astore 14
/*     */     //   220: aload_0
/*     */     //   221: aload 5
/*     */     //   223: invokeinterface 38 1 0
/*     */     //   228: invokevirtual 39	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:getScreenFileName	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   231: astore 15
/*     */     //   233: new 40	java/util/StringJoiner
/*     */     //   236: dup
/*     */     //   237: ldc 41
/*     */     //   239: invokespecial 42	java/util/StringJoiner:<init>	(Ljava/lang/CharSequence;)V
/*     */     //   242: astore 16
/*     */     //   244: aload_0
/*     */     //   245: getfield 43	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:helper	Ljp/co/tokyo_gas/cisfw/utils/CfwLogHelper;
/*     */     //   248: invokevirtual 44	jp/co/tokyo_gas/cisfw/utils/CfwLogHelper:getKeys	()[Ljava/lang/String;
/*     */     //   251: astore 17
/*     */     //   253: aload 17
/*     */     //   255: arraylength
/*     */     //   256: istore 18
/*     */     //   258: iconst_0
/*     */     //   259: istore 19
/*     */     //   261: iload 19
/*     */     //   263: iload 18
/*     */     //   265: if_icmpge +171 -> 436
/*     */     //   268: aload 17
/*     */     //   270: iload 19
/*     */     //   272: aaload
/*     */     //   273: astore 20
/*     */     //   275: aload 5
/*     */     //   277: invokeinterface 45 1 0
/*     */     //   282: invokeinterface 46 1 0
/*     */     //   287: invokeinterface 47 1 0
/*     */     //   292: astore 21
/*     */     //   294: aload 21
/*     */     //   296: invokeinterface 48 1 0
/*     */     //   301: ifeq +129 -> 430
/*     */     //   304: aload 21
/*     */     //   306: invokeinterface 49 1 0
/*     */     //   311: checkcast 50	java/lang/String
/*     */     //   314: astore 22
/*     */     //   316: aload 22
/*     */     //   318: aload 20
/*     */     //   320: invokevirtual 51	java/lang/String:contains	(Ljava/lang/CharSequence;)Z
/*     */     //   323: ifeq +104 -> 427
/*     */     //   326: aload 5
/*     */     //   328: aload 22
/*     */     //   330: invokeinterface 52 2 0
/*     */     //   335: astore 23
/*     */     //   337: aload 23
/*     */     //   339: ifnull +88 -> 427
/*     */     //   342: new 40	java/util/StringJoiner
/*     */     //   345: dup
/*     */     //   346: ldc 30
/*     */     //   348: invokespecial 42	java/util/StringJoiner:<init>	(Ljava/lang/CharSequence;)V
/*     */     //   351: astore 24
/*     */     //   353: aload 23
/*     */     //   355: astore 25
/*     */     //   357: aload 25
/*     */     //   359: arraylength
/*     */     //   360: istore 26
/*     */     //   362: iconst_0
/*     */     //   363: istore 27
/*     */     //   365: iload 27
/*     */     //   367: iload 26
/*     */     //   369: if_icmpge +24 -> 393
/*     */     //   372: aload 25
/*     */     //   374: iload 27
/*     */     //   376: aaload
/*     */     //   377: astore 28
/*     */     //   379: aload 24
/*     */     //   381: aload 28
/*     */     //   383: invokevirtual 53	java/util/StringJoiner:add	(Ljava/lang/CharSequence;)Ljava/util/StringJoiner;
/*     */     //   386: pop
/*     */     //   387: iinc 27 1
/*     */     //   390: goto -25 -> 365
/*     */     //   393: aload 16
/*     */     //   395: new 5	java/lang/StringBuilder
/*     */     //   398: dup
/*     */     //   399: invokespecial 6	java/lang/StringBuilder:<init>	()V
/*     */     //   402: aload 20
/*     */     //   404: invokevirtual 9	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   407: ldc 19
/*     */     //   409: invokevirtual 9	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   412: aload 24
/*     */     //   414: invokevirtual 54	java/util/StringJoiner:toString	()Ljava/lang/String;
/*     */     //   417: invokevirtual 9	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   420: invokevirtual 11	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   423: invokevirtual 53	java/util/StringJoiner:add	(Ljava/lang/CharSequence;)Ljava/util/StringJoiner;
/*     */     //   426: pop
/*     */     //   427: goto -133 -> 294
/*     */     //   430: iinc 19 1
/*     */     //   433: goto -172 -> 261
/*     */     //   436: aload_0
/*     */     //   437: getfield 55	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:holder	Ljp/co/tokyo_gas/cisfw/ws/CfwCommunicationLogInfoHolder;
/*     */     //   440: aload 15
/*     */     //   442: invokevirtual 56	jp/co/tokyo_gas/cisfw/ws/CfwCommunicationLogInfoHolder:setStartFunctionId	(Ljava/lang/String;)V
/*     */     //   445: aload_0
/*     */     //   446: getfield 57	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:mdc	Ljp/co/tokyo_gas/aion/tgfw/parts/logger/FwMDC;
/*     */     //   449: ldc 58
/*     */     //   451: aload 13
/*     */     //   453: invokevirtual 59	jp/co/tokyo_gas/aion/tgfw/parts/logger/FwMDC:put	(Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   456: aload_0
/*     */     //   457: getfield 57	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:mdc	Ljp/co/tokyo_gas/aion/tgfw/parts/logger/FwMDC;
/*     */     //   460: ldc 60
/*     */     //   462: aload 14
/*     */     //   464: invokevirtual 59	jp/co/tokyo_gas/aion/tgfw/parts/logger/FwMDC:put	(Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   467: aload_0
/*     */     //   468: getfield 57	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:mdc	Ljp/co/tokyo_gas/aion/tgfw/parts/logger/FwMDC;
/*     */     //   471: ldc 61
/*     */     //   473: aload 10
/*     */     //   475: invokevirtual 59	jp/co/tokyo_gas/aion/tgfw/parts/logger/FwMDC:put	(Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   478: aload_0
/*     */     //   479: getfield 57	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:mdc	Ljp/co/tokyo_gas/aion/tgfw/parts/logger/FwMDC;
/*     */     //   482: ldc 62
/*     */     //   484: aload 11
/*     */     //   486: invokevirtual 59	jp/co/tokyo_gas/aion/tgfw/parts/logger/FwMDC:put	(Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   489: aload_0
/*     */     //   490: getfield 63	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:log	Ljp/co/tokyo_gas/cisfw/logger/CfwLogger;
/*     */     //   493: ldc 64
/*     */     //   495: bipush 10
/*     */     //   497: anewarray 65	java/lang/Object
/*     */     //   500: dup
/*     */     //   501: iconst_0
/*     */     //   502: ldc 66
/*     */     //   504: aastore
/*     */     //   505: dup
/*     */     //   506: iconst_1
/*     */     //   507: ldc 67
/*     */     //   509: aastore
/*     */     //   510: dup
/*     */     //   511: iconst_2
/*     */     //   512: aload 9
/*     */     //   514: aastore
/*     */     //   515: dup
/*     */     //   516: iconst_3
/*     */     //   517: aload 6
/*     */     //   519: aastore
/*     */     //   520: dup
/*     */     //   521: iconst_4
/*     */     //   522: aload 13
/*     */     //   524: aastore
/*     */     //   525: dup
/*     */     //   526: iconst_5
/*     */     //   527: ldc 68
/*     */     //   529: aastore
/*     */     //   530: dup
/*     */     //   531: bipush 6
/*     */     //   533: ldc 68
/*     */     //   535: aastore
/*     */     //   536: dup
/*     */     //   537: bipush 7
/*     */     //   539: aload 10
/*     */     //   541: aastore
/*     */     //   542: dup
/*     */     //   543: bipush 8
/*     */     //   545: aload 11
/*     */     //   547: aastore
/*     */     //   548: dup
/*     */     //   549: bipush 9
/*     */     //   551: aload 16
/*     */     //   553: aastore
/*     */     //   554: invokeinterface 69 3 0
/*     */     //   559: aload_0
/*     */     //   560: getfield 63	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:log	Ljp/co/tokyo_gas/cisfw/logger/CfwLogger;
/*     */     //   563: invokeinterface 70 1 0
/*     */     //   568: ifeq +59 -> 627
/*     */     //   571: aload_0
/*     */     //   572: getfield 43	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:helper	Ljp/co/tokyo_gas/cisfw/utils/CfwLogHelper;
/*     */     //   575: aload 5
/*     */     //   577: invokeinterface 45 1 0
/*     */     //   582: invokevirtual 71	jp/co/tokyo_gas/cisfw/utils/CfwLogHelper:toJSON	(Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   585: astore 17
/*     */     //   587: aload_0
/*     */     //   588: getfield 63	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:log	Ljp/co/tokyo_gas/cisfw/logger/CfwLogger;
/*     */     //   591: ldc 72
/*     */     //   593: iconst_5
/*     */     //   594: anewarray 65	java/lang/Object
/*     */     //   597: dup
/*     */     //   598: iconst_0
/*     */     //   599: ldc 73
/*     */     //   601: aastore
/*     */     //   602: dup
/*     */     //   603: iconst_1
/*     */     //   604: ldc 67
/*     */     //   606: aastore
/*     */     //   607: dup
/*     */     //   608: iconst_2
/*     */     //   609: aload 9
/*     */     //   611: aastore
/*     */     //   612: dup
/*     */     //   613: iconst_3
/*     */     //   614: aload 6
/*     */     //   616: aastore
/*     */     //   617: dup
/*     */     //   618: iconst_4
/*     */     //   619: aload 17
/*     */     //   621: aastore
/*     */     //   622: invokeinterface 74 3 0
/*     */     //   627: aload_3
/*     */     //   628: aload_1
/*     */     //   629: aload_2
/*     */     //   630: invokeinterface 24 3 0
/*     */     //   635: invokestatic 25	java/lang/System:currentTimeMillis	()J
/*     */     //   638: lload 7
/*     */     //   640: lsub
/*     */     //   641: lstore 17
/*     */     //   643: aload_0
/*     */     //   644: getfield 55	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:holder	Ljp/co/tokyo_gas/cisfw/ws/CfwCommunicationLogInfoHolder;
/*     */     //   647: invokevirtual 75	jp/co/tokyo_gas/cisfw/ws/CfwCommunicationLogInfoHolder:getMessageId	()Ljava/lang/String;
/*     */     //   650: astore 19
/*     */     //   652: aload_0
/*     */     //   653: getfield 63	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:log	Ljp/co/tokyo_gas/cisfw/logger/CfwLogger;
/*     */     //   656: ldc 76
/*     */     //   658: bipush 10
/*     */     //   660: anewarray 65	java/lang/Object
/*     */     //   663: dup
/*     */     //   664: iconst_0
/*     */     //   665: ldc 77
/*     */     //   667: aastore
/*     */     //   668: dup
/*     */     //   669: iconst_1
/*     */     //   670: ldc 67
/*     */     //   672: aastore
/*     */     //   673: dup
/*     */     //   674: iconst_2
/*     */     //   675: aload 9
/*     */     //   677: aastore
/*     */     //   678: dup
/*     */     //   679: iconst_3
/*     */     //   680: aload 6
/*     */     //   682: aastore
/*     */     //   683: dup
/*     */     //   684: iconst_4
/*     */     //   685: aload 13
/*     */     //   687: aastore
/*     */     //   688: dup
/*     */     //   689: iconst_5
/*     */     //   690: aload 19
/*     */     //   692: aastore
/*     */     //   693: dup
/*     */     //   694: bipush 6
/*     */     //   696: lload 17
/*     */     //   698: invokestatic 78	java/lang/Long:valueOf	(J)Ljava/lang/Long;
/*     */     //   701: aastore
/*     */     //   702: dup
/*     */     //   703: bipush 7
/*     */     //   705: ldc 68
/*     */     //   707: aastore
/*     */     //   708: dup
/*     */     //   709: bipush 8
/*     */     //   711: ldc 68
/*     */     //   713: aastore
/*     */     //   714: dup
/*     */     //   715: bipush 9
/*     */     //   717: ldc 68
/*     */     //   719: aastore
/*     */     //   720: invokeinterface 69 3 0
/*     */     //   725: aload 9
/*     */     //   727: aload 9
/*     */     //   729: ldc 79
/*     */     //   731: invokevirtual 80	java/lang/String:lastIndexOf	(Ljava/lang/String;)I
/*     */     //   734: iconst_1
/*     */     //   735: iadd
/*     */     //   736: invokevirtual 81	java/lang/String:substring	(I)Ljava/lang/String;
/*     */     //   739: astore 20
/*     */     //   741: aload 20
/*     */     //   743: iconst_0
/*     */     //   744: aload 20
/*     */     //   746: ldc 82
/*     */     //   748: invokevirtual 80	java/lang/String:lastIndexOf	(Ljava/lang/String;)I
/*     */     //   751: invokevirtual 83	java/lang/String:substring	(II)Ljava/lang/String;
/*     */     //   754: astore 20
/*     */     //   756: aload_0
/*     */     //   757: getfield 13	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:statisticsLog	Ljp/co/tokyo_gas/cisfw/logger/CfwLogger;
/*     */     //   760: ldc 84
/*     */     //   762: iconst_5
/*     */     //   763: anewarray 65	java/lang/Object
/*     */     //   766: dup
/*     */     //   767: iconst_0
/*     */     //   768: ldc 67
/*     */     //   770: aastore
/*     */     //   771: dup
/*     */     //   772: iconst_1
/*     */     //   773: aload 20
/*     */     //   775: aastore
/*     */     //   776: dup
/*     */     //   777: iconst_2
/*     */     //   778: aload 6
/*     */     //   780: aastore
/*     */     //   781: dup
/*     */     //   782: iconst_3
/*     */     //   783: aload 13
/*     */     //   785: aastore
/*     */     //   786: dup
/*     */     //   787: iconst_4
/*     */     //   788: lload 17
/*     */     //   790: invokestatic 78	java/lang/Long:valueOf	(J)Ljava/lang/Long;
/*     */     //   793: aastore
/*     */     //   794: invokeinterface 69 3 0
/*     */     //   799: aload_0
/*     */     //   800: getfield 57	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:mdc	Ljp/co/tokyo_gas/aion/tgfw/parts/logger/FwMDC;
/*     */     //   803: ldc 58
/*     */     //   805: invokevirtual 85	jp/co/tokyo_gas/aion/tgfw/parts/logger/FwMDC:remove	(Ljava/lang/String;)V
/*     */     //   808: aload_0
/*     */     //   809: getfield 57	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:mdc	Ljp/co/tokyo_gas/aion/tgfw/parts/logger/FwMDC;
/*     */     //   812: ldc 60
/*     */     //   814: invokevirtual 85	jp/co/tokyo_gas/aion/tgfw/parts/logger/FwMDC:remove	(Ljava/lang/String;)V
/*     */     //   817: aload_0
/*     */     //   818: getfield 57	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:mdc	Ljp/co/tokyo_gas/aion/tgfw/parts/logger/FwMDC;
/*     */     //   821: ldc 61
/*     */     //   823: invokevirtual 85	jp/co/tokyo_gas/aion/tgfw/parts/logger/FwMDC:remove	(Ljava/lang/String;)V
/*     */     //   826: aload_0
/*     */     //   827: getfield 57	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:mdc	Ljp/co/tokyo_gas/aion/tgfw/parts/logger/FwMDC;
/*     */     //   830: ldc 62
/*     */     //   832: invokevirtual 85	jp/co/tokyo_gas/aion/tgfw/parts/logger/FwMDC:remove	(Ljava/lang/String;)V
/*     */     //   835: goto +208 -> 1043
/*     */     //   838: astore 29
/*     */     //   840: invokestatic 25	java/lang/System:currentTimeMillis	()J
/*     */     //   843: lload 7
/*     */     //   845: lsub
/*     */     //   846: lstore 30
/*     */     //   848: aload_0
/*     */     //   849: getfield 55	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:holder	Ljp/co/tokyo_gas/cisfw/ws/CfwCommunicationLogInfoHolder;
/*     */     //   852: invokevirtual 75	jp/co/tokyo_gas/cisfw/ws/CfwCommunicationLogInfoHolder:getMessageId	()Ljava/lang/String;
/*     */     //   855: astore 32
/*     */     //   857: aload_0
/*     */     //   858: getfield 63	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:log	Ljp/co/tokyo_gas/cisfw/logger/CfwLogger;
/*     */     //   861: ldc 76
/*     */     //   863: bipush 10
/*     */     //   865: anewarray 65	java/lang/Object
/*     */     //   868: dup
/*     */     //   869: iconst_0
/*     */     //   870: ldc 77
/*     */     //   872: aastore
/*     */     //   873: dup
/*     */     //   874: iconst_1
/*     */     //   875: ldc 67
/*     */     //   877: aastore
/*     */     //   878: dup
/*     */     //   879: iconst_2
/*     */     //   880: aload 9
/*     */     //   882: aastore
/*     */     //   883: dup
/*     */     //   884: iconst_3
/*     */     //   885: aload 6
/*     */     //   887: aastore
/*     */     //   888: dup
/*     */     //   889: iconst_4
/*     */     //   890: aload 13
/*     */     //   892: aastore
/*     */     //   893: dup
/*     */     //   894: iconst_5
/*     */     //   895: aload 32
/*     */     //   897: aastore
/*     */     //   898: dup
/*     */     //   899: bipush 6
/*     */     //   901: lload 30
/*     */     //   903: invokestatic 78	java/lang/Long:valueOf	(J)Ljava/lang/Long;
/*     */     //   906: aastore
/*     */     //   907: dup
/*     */     //   908: bipush 7
/*     */     //   910: ldc 68
/*     */     //   912: aastore
/*     */     //   913: dup
/*     */     //   914: bipush 8
/*     */     //   916: ldc 68
/*     */     //   918: aastore
/*     */     //   919: dup
/*     */     //   920: bipush 9
/*     */     //   922: ldc 68
/*     */     //   924: aastore
/*     */     //   925: invokeinterface 69 3 0
/*     */     //   930: aload 9
/*     */     //   932: aload 9
/*     */     //   934: ldc 79
/*     */     //   936: invokevirtual 80	java/lang/String:lastIndexOf	(Ljava/lang/String;)I
/*     */     //   939: iconst_1
/*     */     //   940: iadd
/*     */     //   941: invokevirtual 81	java/lang/String:substring	(I)Ljava/lang/String;
/*     */     //   944: astore 33
/*     */     //   946: aload 33
/*     */     //   948: iconst_0
/*     */     //   949: aload 33
/*     */     //   951: ldc 82
/*     */     //   953: invokevirtual 80	java/lang/String:lastIndexOf	(Ljava/lang/String;)I
/*     */     //   956: invokevirtual 83	java/lang/String:substring	(II)Ljava/lang/String;
/*     */     //   959: astore 33
/*     */     //   961: aload_0
/*     */     //   962: getfield 13	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:statisticsLog	Ljp/co/tokyo_gas/cisfw/logger/CfwLogger;
/*     */     //   965: ldc 84
/*     */     //   967: iconst_5
/*     */     //   968: anewarray 65	java/lang/Object
/*     */     //   971: dup
/*     */     //   972: iconst_0
/*     */     //   973: ldc 67
/*     */     //   975: aastore
/*     */     //   976: dup
/*     */     //   977: iconst_1
/*     */     //   978: aload 33
/*     */     //   980: aastore
/*     */     //   981: dup
/*     */     //   982: iconst_2
/*     */     //   983: aload 6
/*     */     //   985: aastore
/*     */     //   986: dup
/*     */     //   987: iconst_3
/*     */     //   988: aload 13
/*     */     //   990: aastore
/*     */     //   991: dup
/*     */     //   992: iconst_4
/*     */     //   993: lload 30
/*     */     //   995: invokestatic 78	java/lang/Long:valueOf	(J)Ljava/lang/Long;
/*     */     //   998: aastore
/*     */     //   999: invokeinterface 69 3 0
/*     */     //   1004: aload_0
/*     */     //   1005: getfield 57	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:mdc	Ljp/co/tokyo_gas/aion/tgfw/parts/logger/FwMDC;
/*     */     //   1008: ldc 58
/*     */     //   1010: invokevirtual 85	jp/co/tokyo_gas/aion/tgfw/parts/logger/FwMDC:remove	(Ljava/lang/String;)V
/*     */     //   1013: aload_0
/*     */     //   1014: getfield 57	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:mdc	Ljp/co/tokyo_gas/aion/tgfw/parts/logger/FwMDC;
/*     */     //   1017: ldc 60
/*     */     //   1019: invokevirtual 85	jp/co/tokyo_gas/aion/tgfw/parts/logger/FwMDC:remove	(Ljava/lang/String;)V
/*     */     //   1022: aload_0
/*     */     //   1023: getfield 57	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:mdc	Ljp/co/tokyo_gas/aion/tgfw/parts/logger/FwMDC;
/*     */     //   1026: ldc 61
/*     */     //   1028: invokevirtual 85	jp/co/tokyo_gas/aion/tgfw/parts/logger/FwMDC:remove	(Ljava/lang/String;)V
/*     */     //   1031: aload_0
/*     */     //   1032: getfield 57	jp/co/tokyo_gas/cisfw/web/filter/CfwRequestLogFilter:mdc	Ljp/co/tokyo_gas/aion/tgfw/parts/logger/FwMDC;
/*     */     //   1035: ldc 62
/*     */     //   1037: invokevirtual 85	jp/co/tokyo_gas/aion/tgfw/parts/logger/FwMDC:remove	(Ljava/lang/String;)V
/*     */     //   1040: aload 29
/*     */     //   1042: athrow
/*     */     //   1043: return
/*     */     // Line number table:
/*     */     //   Java source line #113	-> byte code offset #0
/*     */     //   Java source line #114	-> byte code offset #5
/*     */     //   Java source line #117	-> byte code offset #39
/*     */     //   Java source line #118	-> byte code offset #45
/*     */     //   Java source line #120	-> byte code offset #56
/*     */     //   Java source line #121	-> byte code offset #64
/*     */     //   Java source line #123	-> byte code offset #71
/*     */     //   Java source line #124	-> byte code offset #80
/*     */     //   Java source line #126	-> byte code offset #90
/*     */     //   Java source line #127	-> byte code offset #100
/*     */     //   Java source line #131	-> byte code offset #110
/*     */     //   Java source line #132	-> byte code offset #119
/*     */     //   Java source line #133	-> byte code offset #127
/*     */     //   Java source line #136	-> byte code offset #128
/*     */     //   Java source line #139	-> byte code offset #133
/*     */     //   Java source line #140	-> byte code offset #142
/*     */     //   Java source line #141	-> byte code offset #150
/*     */     //   Java source line #142	-> byte code offset #153
/*     */     //   Java source line #144	-> byte code offset #164
/*     */     //   Java source line #145	-> byte code offset #172
/*     */     //   Java source line #146	-> byte code offset #181
/*     */     //   Java source line #147	-> byte code offset #187
/*     */     //   Java source line #148	-> byte code offset #190
/*     */     //   Java source line #151	-> byte code offset #199
/*     */     //   Java source line #152	-> byte code offset #209
/*     */     //   Java source line #153	-> byte code offset #220
/*     */     //   Java source line #155	-> byte code offset #233
/*     */     //   Java source line #156	-> byte code offset #244
/*     */     //   Java source line #157	-> byte code offset #275
/*     */     //   Java source line #158	-> byte code offset #316
/*     */     //   Java source line #159	-> byte code offset #326
/*     */     //   Java source line #160	-> byte code offset #337
/*     */     //   Java source line #161	-> byte code offset #342
/*     */     //   Java source line #162	-> byte code offset #353
/*     */     //   Java source line #163	-> byte code offset #379
/*     */     //   Java source line #162	-> byte code offset #387
/*     */     //   Java source line #165	-> byte code offset #393
/*     */     //   Java source line #168	-> byte code offset #427
/*     */     //   Java source line #156	-> byte code offset #430
/*     */     //   Java source line #170	-> byte code offset #436
/*     */     //   Java source line #173	-> byte code offset #445
/*     */     //   Java source line #174	-> byte code offset #456
/*     */     //   Java source line #175	-> byte code offset #467
/*     */     //   Java source line #176	-> byte code offset #478
/*     */     //   Java source line #179	-> byte code offset #489
/*     */     //   Java source line #182	-> byte code offset #559
/*     */     //   Java source line #183	-> byte code offset #571
/*     */     //   Java source line #184	-> byte code offset #587
/*     */     //   Java source line #188	-> byte code offset #627
/*     */     //   Java source line #190	-> byte code offset #635
/*     */     //   Java source line #192	-> byte code offset #643
/*     */     //   Java source line #194	-> byte code offset #652
/*     */     //   Java source line #197	-> byte code offset #725
/*     */     //   Java source line #198	-> byte code offset #741
/*     */     //   Java source line #199	-> byte code offset #756
/*     */     //   Java source line #201	-> byte code offset #799
/*     */     //   Java source line #202	-> byte code offset #808
/*     */     //   Java source line #203	-> byte code offset #817
/*     */     //   Java source line #204	-> byte code offset #826
/*     */     //   Java source line #205	-> byte code offset #835
/*     */     //   Java source line #190	-> byte code offset #838
/*     */     //   Java source line #192	-> byte code offset #848
/*     */     //   Java source line #194	-> byte code offset #857
/*     */     //   Java source line #197	-> byte code offset #930
/*     */     //   Java source line #198	-> byte code offset #946
/*     */     //   Java source line #199	-> byte code offset #961
/*     */     //   Java source line #201	-> byte code offset #1004
/*     */     //   Java source line #202	-> byte code offset #1013
/*     */     //   Java source line #203	-> byte code offset #1022
/*     */     //   Java source line #204	-> byte code offset #1031
/*     */     //   Java source line #205	-> byte code offset #1040
/*     */     //   Java source line #206	-> byte code offset #1043
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	1044	0	this	CfwRequestLogFilter
/*     */     //   0	1044	1	request	javax.servlet.ServletRequest
/*     */     //   0	1044	2	response	javax.servlet.ServletResponse
/*     */     //   0	1044	3	chain	javax.servlet.FilterChain
/*     */     //   3	4	4	logFactory	jp.co.tokyo_gas.cisfw.logger.impl.CfwLoggerFactory
/*     */     //   43	533	5	req	HttpServletRequest
/*     */     //   54	930	6	eventId	String
/*     */     //   78	25	7	splitArray	String[]
/*     */     //   131	713	7	startTimeMills	long
/*     */     //   140	793	9	url	String
/*     */     //   148	392	10	httpSessionId	String
/*     */     //   151	395	11	ip	String
/*     */     //   162	11	12	xForwardedFor	String
/*     */     //   179	3	13	splitIp	String[]
/*     */     //   207	782	13	userId	String
/*     */     //   218	245	14	serverId	String
/*     */     //   231	210	15	screenFileName	String
/*     */     //   242	310	16	joiner	java.util.StringJoiner
/*     */     //   251	18	17	arrayOfString1	String[]
/*     */     //   585	35	17	json	String
/*     */     //   641	148	17	time	long
/*     */     //   256	10	18	i	int
/*     */     //   259	172	19	j	int
/*     */     //   650	41	19	messageId	String
/*     */     //   273	130	20	item	String
/*     */     //   739	35	20	xhtmlName	String
/*     */     //   292	13	21	localIterator	java.util.Iterator
/*     */     //   314	15	22	key	String
/*     */     //   335	19	23	customerNos	String[]
/*     */     //   351	62	24	valueJoiner	java.util.StringJoiner
/*     */     //   355	18	25	arrayOfString2	String[]
/*     */     //   360	10	26	k	int
/*     */     //   363	25	27	m	int
/*     */     //   377	5	28	customerNo	String
/*     */     //   838	203	29	localObject	Object
/*     */     //   846	148	30	time	long
/*     */     //   855	41	32	messageId	String
/*     */     //   944	35	33	xhtmlName	String
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   627	635	838	finally
/*     */     //   838	840	838	finally
/*     */   }
/*     */   
/*     */   boolean isExcludePattern(HttpServletRequest req)
/*     */   {
/* 216 */     String jsfEvent = req.getParameter("javax.faces.partial.event");
/* 217 */     if ((jsfEvent != null) && (jsfEvent.equals("blur"))) {
/* 218 */       return true;
/*     */     }
/* 220 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   String getHttpSessionId(HttpServletRequest req)
/*     */   {
/* 233 */     HttpSession httpSession = req.getSession(false);
/* 234 */     String sessionId = httpSession == null ? "" : httpSession.getId();
/* 235 */     return sessionId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   String getDukeId(CfwSession cfwSession)
/*     */   {
/* 248 */     String defaultValue = "";
/* 249 */     CfwUserInfo userInfo = cfwSession.getUserInfo();
/* 250 */     if (userInfo == null) {
/* 251 */       return "";
/*     */     }
/* 253 */     String userId = userInfo.getDukeId();
/* 254 */     if (userId == null) {
/* 255 */       return "";
/*     */     }
/* 257 */     return userId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   String getScreenFileName(String pathInfo)
/*     */   {
/* 290 */     if (pathInfo == null)
/*     */     {
/*     */ 
/* 293 */       return "";
/*     */     }
/*     */     
/*     */ 
/* 297 */     String gmnId = this.util.menuDefToDBDefScreenId(this.util.trimXhtmlIfNeed(pathInfo));
/* 298 */     return gmnId;
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\filter\CfwRequestLogFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */