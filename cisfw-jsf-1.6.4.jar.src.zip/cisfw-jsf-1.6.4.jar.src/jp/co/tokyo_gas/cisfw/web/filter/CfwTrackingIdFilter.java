/*    */ package jp.co.tokyo_gas.cisfw.web.filter;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.inject.Inject;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.string.FwStringValidator;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.tracking.FwTrackingIdManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CfwTrackingIdFilter
/*    */   implements Filter
/*    */ {
/*    */   @Inject
/*    */   private FwTrackingIdManager manager;
/*    */   
/*    */   public void destroy() {}
/*    */   
/*    */   public void init(FilterConfig config) {}
/*    */   
/*    */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*    */     throws IOException, ServletException
/*    */   {
/* 60 */     HttpServletRequest httpRequest = (HttpServletRequest)request;
/*    */     
/* 62 */     String clientWindow = httpRequest.getParameter("javax.faces.ClientWindow");
/*    */     
/*    */ 
/* 65 */     if (FwStringValidator.isEmpty(clientWindow)) {
/* 66 */       String trackingid = (String)httpRequest.getSession().getAttribute("cfw_trackingid");
/*    */       
/*    */ 
/* 69 */       if (FwStringValidator.isEmpty(trackingid)) {
/* 70 */         this.manager.get();
/*    */       } else {
/* 72 */         this.manager.put(trackingid);
/*    */       }
/*    */       
/*    */     }
/*    */     else
/*    */     {
/* 78 */       String partialEvent = httpRequest.getParameter("javax.faces.partial.event");
/*    */       
/*    */ 
/* 81 */       if ((!FwStringValidator.isEmpty(partialEvent)) && ("dialogReturn".equals(partialEvent))) {
/* 82 */         String trackingid = (String)httpRequest.getSession().getAttribute("cfw_trackingid");
/* 83 */         this.manager.put(trackingid);
/*    */       }
/*    */       else
/*    */       {
/* 87 */         String trackingid = this.manager.get();
/* 88 */         httpRequest.getSession().setAttribute("cfw_trackingid", trackingid);
/*    */       }
/*    */     }
/*    */     
/* 92 */     chain.doFilter(request, response);
/*    */     
/* 94 */     this.manager.remove();
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\filter\CfwTrackingIdFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */