/*    */ package jp.co.tokyo_gas.cisfw.web.authcheck.client;
/*    */ 
/*    */ import javax.xml.bind.JAXBElement;
/*    */ import javax.xml.bind.annotation.XmlElementDecl;
/*    */ import javax.xml.bind.annotation.XmlRegistry;
/*    */ import javax.xml.namespace.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlRegistry
/*    */ public class ObjectFactory
/*    */ {
/* 27 */   private static final QName _GetCfwComponentAuthorityInfoList_QNAME = new QName("http://provider.authcheck.cisfw.tokyo_gas.co.jp/", "getCfwComponentAuthorityInfoList");
/* 28 */   private static final QName _GetCfwComponentAuthorityInfoListResponse_QNAME = new QName("http://provider.authcheck.cisfw.tokyo_gas.co.jp/", "getCfwComponentAuthorityInfoListResponse");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public GetCfwComponentAuthorityInfoList createGetCfwComponentAuthorityInfoList()
/*    */   {
/* 42 */     return new GetCfwComponentAuthorityInfoList();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public GetCfwComponentAuthorityInfoListResponse createGetCfwComponentAuthorityInfoListResponse()
/*    */   {
/* 50 */     return new GetCfwComponentAuthorityInfoListResponse();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public CfwComponentAuthorityMasterEntity createCfwComponentAuthorityMasterEntity()
/*    */   {
/* 58 */     return new CfwComponentAuthorityMasterEntity();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   @XmlElementDecl(namespace="http://provider.authcheck.cisfw.tokyo_gas.co.jp/", name="getCfwComponentAuthorityInfoList")
/*    */   public JAXBElement<GetCfwComponentAuthorityInfoList> createGetCfwComponentAuthorityInfoList(GetCfwComponentAuthorityInfoList value)
/*    */   {
/* 67 */     return new JAXBElement(_GetCfwComponentAuthorityInfoList_QNAME, GetCfwComponentAuthorityInfoList.class, null, value);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   @XmlElementDecl(namespace="http://provider.authcheck.cisfw.tokyo_gas.co.jp/", name="getCfwComponentAuthorityInfoListResponse")
/*    */   public JAXBElement<GetCfwComponentAuthorityInfoListResponse> createGetCfwComponentAuthorityInfoListResponse(GetCfwComponentAuthorityInfoListResponse value)
/*    */   {
/* 76 */     return new JAXBElement(_GetCfwComponentAuthorityInfoListResponse_QNAME, GetCfwComponentAuthorityInfoListResponse.class, null, value);
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\authcheck\client\ObjectFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */