package jp.co.tokyo_gas.cisfw.web.authcheck.client;

import java.util.List;
import javax.jws.WebMethod;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

@WebService(name="CfwComponentAuthorityMasterService", targetNamespace="http://provider.authcheck.cisfw.tokyo_gas.co.jp/")
@XmlSeeAlso({ObjectFactory.class})
public abstract interface CfwComponentAuthorityMasterService
{
  @WebMethod
  @WebResult(targetNamespace="")
  @RequestWrapper(localName="getCfwComponentAuthorityInfoList", targetNamespace="http://provider.authcheck.cisfw.tokyo_gas.co.jp/", className="jp.co.tokyo_gas.cisfw.web.authcheck.client.GetCfwComponentAuthorityInfoList")
  @ResponseWrapper(localName="getCfwComponentAuthorityInfoListResponse", targetNamespace="http://provider.authcheck.cisfw.tokyo_gas.co.jp/", className="jp.co.tokyo_gas.cisfw.web.authcheck.client.GetCfwComponentAuthorityInfoListResponse")
  public abstract List<CfwComponentAuthorityMasterEntity> getCfwComponentAuthorityInfoList();
}


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\authcheck\client\CfwComponentAuthorityMasterService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */