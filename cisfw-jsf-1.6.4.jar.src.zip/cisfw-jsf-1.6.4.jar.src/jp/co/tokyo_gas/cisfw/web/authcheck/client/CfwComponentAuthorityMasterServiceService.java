/*    */ package jp.co.tokyo_gas.cisfw.web.authcheck.client;
/*    */ 
/*    */ import java.net.URL;
/*    */ import javax.xml.namespace.QName;
/*    */ import javax.xml.ws.Service;
/*    */ import javax.xml.ws.WebEndpoint;
/*    */ import javax.xml.ws.WebServiceClient;
/*    */ import javax.xml.ws.WebServiceException;
/*    */ import javax.xml.ws.WebServiceFeature;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @WebServiceClient(name="CfwComponentAuthorityMasterServiceService", targetNamespace="http://provider.authcheck.cisfw.tokyo_gas.co.jp/", wsdlLocation="WEB-INF/wsdl/CfwComponentAuthorityMasterServiceService.wsdl")
/*    */ public class CfwComponentAuthorityMasterServiceService
/*    */   extends Service
/*    */ {
/*    */   private static final URL CFWCOMPONENTAUTHORITYMASTERSERVICESERVICE_WSDL_LOCATION;
/*    */   private static final WebServiceException CFWCOMPONENTAUTHORITYMASTERSERVICESERVICE_EXCEPTION;
/* 26 */   private static final QName CFWCOMPONENTAUTHORITYMASTERSERVICESERVICE_QNAME = new QName("http://provider.authcheck.cisfw.tokyo_gas.co.jp/", "CfwComponentAuthorityMasterServiceService");
/*    */   
/*    */   static {
/* 29 */     CFWCOMPONENTAUTHORITYMASTERSERVICESERVICE_WSDL_LOCATION = CfwComponentAuthorityMasterServiceService.class.getResource("/WEB-INF/wsdl/CfwComponentAuthorityMasterServiceService.wsdl");
/* 30 */     WebServiceException e = null;
/* 31 */     if (CFWCOMPONENTAUTHORITYMASTERSERVICESERVICE_WSDL_LOCATION == null) {
/* 32 */       e = new WebServiceException("Cannot find 'WEB-INF/wsdl/CfwComponentAuthorityMasterServiceService.wsdl' wsdl. Place the resource correctly in the classpath.");
/*    */     }
/* 34 */     CFWCOMPONENTAUTHORITYMASTERSERVICESERVICE_EXCEPTION = e;
/*    */   }
/*    */   
/*    */   public CfwComponentAuthorityMasterServiceService() {
/* 38 */     super(__getWsdlLocation(), CFWCOMPONENTAUTHORITYMASTERSERVICESERVICE_QNAME);
/*    */   }
/*    */   
/*    */   public CfwComponentAuthorityMasterServiceService(WebServiceFeature... features) {
/* 42 */     super(__getWsdlLocation(), CFWCOMPONENTAUTHORITYMASTERSERVICESERVICE_QNAME, features);
/*    */   }
/*    */   
/*    */   public CfwComponentAuthorityMasterServiceService(URL wsdlLocation) {
/* 46 */     super(wsdlLocation, CFWCOMPONENTAUTHORITYMASTERSERVICESERVICE_QNAME);
/*    */   }
/*    */   
/*    */   public CfwComponentAuthorityMasterServiceService(URL wsdlLocation, WebServiceFeature... features) {
/* 50 */     super(wsdlLocation, CFWCOMPONENTAUTHORITYMASTERSERVICESERVICE_QNAME, features);
/*    */   }
/*    */   
/*    */   public CfwComponentAuthorityMasterServiceService(URL wsdlLocation, QName serviceName) {
/* 54 */     super(wsdlLocation, serviceName);
/*    */   }
/*    */   
/*    */   public CfwComponentAuthorityMasterServiceService(URL wsdlLocation, QName serviceName, WebServiceFeature... features) {
/* 58 */     super(wsdlLocation, serviceName, features);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   @WebEndpoint(name="CfwComponentAuthorityMasterServicePort")
/*    */   public CfwComponentAuthorityMasterService getCfwComponentAuthorityMasterServicePort()
/*    */   {
/* 68 */     return (CfwComponentAuthorityMasterService)super.getPort(new QName("http://provider.authcheck.cisfw.tokyo_gas.co.jp/", "CfwComponentAuthorityMasterServicePort"), CfwComponentAuthorityMasterService.class);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   @WebEndpoint(name="CfwComponentAuthorityMasterServicePort")
/*    */   public CfwComponentAuthorityMasterService getCfwComponentAuthorityMasterServicePort(WebServiceFeature... features)
/*    */   {
/* 80 */     return (CfwComponentAuthorityMasterService)super.getPort(new QName("http://provider.authcheck.cisfw.tokyo_gas.co.jp/", "CfwComponentAuthorityMasterServicePort"), CfwComponentAuthorityMasterService.class, features);
/*    */   }
/*    */   
/*    */   private static URL __getWsdlLocation() {
/* 84 */     if (CFWCOMPONENTAUTHORITYMASTERSERVICESERVICE_EXCEPTION != null) {
/* 85 */       throw CFWCOMPONENTAUTHORITYMASTERSERVICESERVICE_EXCEPTION;
/*    */     }
/* 87 */     return CFWCOMPONENTAUTHORITYMASTERSERVICESERVICE_WSDL_LOCATION;
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\authcheck\client\CfwComponentAuthorityMasterServiceService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */