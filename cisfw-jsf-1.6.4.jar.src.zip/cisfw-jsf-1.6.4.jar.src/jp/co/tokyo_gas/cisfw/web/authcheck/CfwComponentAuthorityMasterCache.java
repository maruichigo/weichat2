/*     */ package jp.co.tokyo_gas.cisfw.web.authcheck;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.annotation.PostConstruct;
/*     */ import javax.enterprise.context.ApplicationScoped;
/*     */ import javax.enterprise.inject.Instance;
/*     */ import javax.enterprise.inject.spi.CDI;
/*     */ import javax.enterprise.util.AnnotationLiteral;
/*     */ import javax.inject.Inject;
/*     */ import javax.inject.Named;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.config.FwConfig;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.init.FwInitializer;
/*     */ import jp.co.tokyo_gas.cisfw.authcheck.provider.CfwComponentAuthorityMasterManager;
/*     */ import jp.co.tokyo_gas.cisfw.converter.CfwBeanConverter;
/*     */ import jp.co.tokyo_gas.cisfw.init.CfwQualifier;
/*     */ import jp.co.tokyo_gas.cisfw.web.CfwSession;
/*     */ import jp.co.tokyo_gas.cisfw.web.CfwUserInfo;
/*     */ import jp.co.tokyo_gas.cisfw.web.authcheck.client.CfwComponentAuthorityMasterService;
/*     */ import jp.co.tokyo_gas.cisfw.web.authcheck.client.CfwComponentAuthorityMasterServiceService;
/*     */ import jp.co.tokyo_gas.cisfw.web.ws.CfwServiceFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ApplicationScoped
/*     */ @Named("componentAuthorityCache")
/*     */ public class CfwComponentAuthorityMasterCache
/*     */   implements FwInitializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private Map<String, Map<String, List<String>>> componentAuthorityMasterMap;
/*     */   @Inject
/*     */   private CfwServiceFactory factory;
/*     */   @Inject
/*     */   private CfwSession session;
/*     */   @Inject
/*     */   private FwConfig config;
/*     */   
/*     */   public boolean checkAuth(String screenId, String componentId)
/*     */   {
/*  67 */     List<String> authorityCdList = this.session.getUserInfo().getAllowedAuthorityCd();
/*     */     
/*  69 */     if (authorityCdList == null) {
/*  70 */       return false;
/*     */     }
/*     */     
/*     */ 
/*  74 */     boolean isExistScreenId = this.componentAuthorityMasterMap.containsKey(screenId);
/*  75 */     List<String> authList = null;
/*  76 */     if (isExistScreenId)
/*     */     {
/*  78 */       authList = (List)((Map)this.componentAuthorityMasterMap.get(screenId)).get(componentId);
/*     */     }
/*     */     
/*     */ 
/*  82 */     if (authList == null) {
/*  83 */       return false;
/*     */     }
/*     */     
/*     */ 
/*  87 */     for (Iterator localIterator1 = authorityCdList.iterator(); localIterator1.hasNext();) { auth = (String)localIterator1.next();
/*  88 */       for (String authority : authList) {
/*  89 */         if (auth.equals(authority)) {
/*  90 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     String auth;
/*  96 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @PostConstruct
/*     */   public void initialize()
/*     */   {
/* 107 */     List<jp.co.tokyo_gas.cisfw.web.authcheck.client.CfwComponentAuthorityMasterEntity> entityList = getCfwComponentAuthorityMasterEntityList();
/*     */     
/* 109 */     this.componentAuthorityMasterMap = new HashMap();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 115 */     for (jp.co.tokyo_gas.cisfw.web.authcheck.client.CfwComponentAuthorityMasterEntity entity : entityList) {
/*     */       Map<String, List<String>> componentIdMap;
/*     */       Map<String, List<String>> componentIdMap;
/* 118 */       if (this.componentAuthorityMasterMap.containsKey(entity.getScreenId())) {
/* 119 */         componentIdMap = (Map)this.componentAuthorityMasterMap.get(entity.getScreenId());
/*     */       } else {
/* 121 */         componentIdMap = new HashMap();
/*     */       }
/*     */       List<String> authList;
/*     */       List<String> authList;
/* 125 */       if (componentIdMap.containsKey(entity.getComponentId())) {
/* 126 */         authList = (List)componentIdMap.get(entity.getComponentId());
/*     */       } else {
/* 128 */         authList = new ArrayList();
/*     */       }
/*     */       
/* 131 */       authList.add(entity.getAuthorityCode());
/* 132 */       componentIdMap.put(entity.getComponentId(), authList);
/* 133 */       this.componentAuthorityMasterMap.put(entity.getScreenId(), componentIdMap);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private List<jp.co.tokyo_gas.cisfw.web.authcheck.client.CfwComponentAuthorityMasterEntity> getCfwComponentAuthorityMasterEntityList()
/*     */   {
/* 143 */     List<jp.co.tokyo_gas.cisfw.web.authcheck.client.CfwComponentAuthorityMasterEntity> entityList = new ArrayList();
/*     */     
/* 145 */     if ("true".equals(this.config.get("ear.integration", "false")))
/*     */     {
/* 147 */       CfwComponentAuthorityMasterManager manager = (CfwComponentAuthorityMasterManager)getManager();
/*     */       
/*     */ 
/* 150 */       List<jp.co.tokyo_gas.cisfw.authcheck.dao.CfwComponentAuthorityMasterEntity> cfwComponentAuthorityMasterEntityList = new ArrayList();
/* 151 */       cfwComponentAuthorityMasterEntityList = manager.getCfwComponentAuthorityInfoList();
/*     */       
/* 153 */       for (jp.co.tokyo_gas.cisfw.authcheck.dao.CfwComponentAuthorityMasterEntity cfwComponentAuthorityMasterEntity : cfwComponentAuthorityMasterEntityList)
/*     */       {
/*     */ 
/* 156 */         jp.co.tokyo_gas.cisfw.web.authcheck.client.CfwComponentAuthorityMasterEntity authority = new jp.co.tokyo_gas.cisfw.web.authcheck.client.CfwComponentAuthorityMasterEntity();
/*     */         
/* 158 */         CfwBeanConverter<jp.co.tokyo_gas.cisfw.authcheck.dao.CfwComponentAuthorityMasterEntity, jp.co.tokyo_gas.cisfw.web.authcheck.client.CfwComponentAuthorityMasterEntity> converter = CfwBeanConverter.getConverter(jp.co.tokyo_gas.cisfw.authcheck.dao.CfwComponentAuthorityMasterEntity.class, jp.co.tokyo_gas.cisfw.web.authcheck.client.CfwComponentAuthorityMasterEntity.class);
/* 159 */         converter.propertyCopy(cfwComponentAuthorityMasterEntity, authority);
/* 160 */         entityList.add(authority);
/*     */       }
/*     */     }
/*     */     else {
/* 164 */       CfwComponentAuthorityMasterService service = (CfwComponentAuthorityMasterService)this.factory.createSEI(CfwComponentAuthorityMasterServiceService.class, CfwComponentAuthorityMasterService.class);
/*     */       
/* 166 */       entityList = service.getCfwComponentAuthorityInfoList();
/*     */     }
/*     */     
/* 169 */     return entityList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object getManager()
/*     */   {
/* 177 */     CDI.current().select(CfwComponentAuthorityMasterManager.class, new Annotation[] { new AnnotationLiteral() {} }).get();
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\authcheck\CfwComponentAuthorityMasterCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */