/*     */ package jp.co.tokyo_gas.cisfw.web.authcheck.client;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name="cfwComponentAuthorityMasterEntity", propOrder={"authorityCode", "componentId", "screenId"})
/*     */ public class CfwComponentAuthorityMasterEntity
/*     */ {
/*     */   protected String authorityCode;
/*     */   protected String componentId;
/*     */   protected String screenId;
/*     */   
/*     */   public String getAuthorityCode()
/*     */   {
/*  51 */     return this.authorityCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAuthorityCode(String value)
/*     */   {
/*  63 */     this.authorityCode = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getComponentId()
/*     */   {
/*  75 */     return this.componentId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setComponentId(String value)
/*     */   {
/*  87 */     this.componentId = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getScreenId()
/*     */   {
/*  99 */     return this.screenId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScreenId(String value)
/*     */   {
/* 111 */     this.screenId = value;
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\authcheck\client\CfwComponentAuthorityMasterEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */