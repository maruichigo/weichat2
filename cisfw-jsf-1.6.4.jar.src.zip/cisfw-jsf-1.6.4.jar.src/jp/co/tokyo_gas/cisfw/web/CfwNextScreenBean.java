/*    */ package jp.co.tokyo_gas.cisfw.web;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CfwNextScreenBean
/*    */ {
/*    */   private String screenPath;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private boolean returnDestination;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CfwNextScreenBean(String screenPath)
/*    */   {
/* 28 */     this.screenPath = screenPath;
/* 29 */     this.returnDestination = true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getScreenPath()
/*    */   {
/* 37 */     return this.screenPath;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isStack()
/*    */   {
/* 45 */     return this.returnDestination;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setNotPageBackCurrentScreen()
/*    */   {
/* 52 */     this.returnDestination = false;
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\CfwNextScreenBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */