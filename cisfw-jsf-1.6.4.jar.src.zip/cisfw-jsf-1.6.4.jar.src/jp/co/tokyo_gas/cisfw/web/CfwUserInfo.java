/*     */ package jp.co.tokyo_gas.cisfw.web;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CfwUserInfo
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String dukeId;
/*     */   private String loginName;
/*     */   private String loginNameKana;
/*     */   private String compKbn;
/*     */   private String compCd;
/*     */   private String officeCd;
/*     */   private String departmentCd;
/*     */   private String workplaceCd;
/*     */   private String nwPlaceCd;
/*     */   private String organizationName;
/*     */   private List<String> allowedAuthorityCd;
/*     */   private String defaultNonUpdatableFlg;
/*     */   private List<String> allowedScreenId;
/*     */   
/*     */   public String getDukeId()
/*     */   {
/*  66 */     return this.dukeId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDukeId(String dukeId)
/*     */   {
/*  75 */     this.dukeId = dukeId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLoginName()
/*     */   {
/*  84 */     return this.loginName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLoginName(String loginName)
/*     */   {
/*  93 */     this.loginName = loginName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLoginNameKana()
/*     */   {
/* 102 */     return this.loginNameKana;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLoginNameKana(String loginNameKana)
/*     */   {
/* 111 */     this.loginNameKana = loginNameKana;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCompKbn()
/*     */   {
/* 120 */     return this.compKbn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCompKbn(String compKbn)
/*     */   {
/* 129 */     this.compKbn = compKbn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCompCd()
/*     */   {
/* 138 */     return this.compCd;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCompCd(String compCd)
/*     */   {
/* 147 */     this.compCd = compCd;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getOfficeCd()
/*     */   {
/* 156 */     return this.officeCd;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOfficeCd(String officeCd)
/*     */   {
/* 165 */     this.officeCd = officeCd;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDepartmentCd()
/*     */   {
/* 174 */     return this.departmentCd;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDepartmentCd(String departmentCd)
/*     */   {
/* 183 */     this.departmentCd = departmentCd;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getWorkplaceCd()
/*     */   {
/* 192 */     return this.workplaceCd;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWorkplaceCd(String workplaceCd)
/*     */   {
/* 201 */     this.workplaceCd = workplaceCd;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getNwPlaceCd()
/*     */   {
/* 210 */     return this.nwPlaceCd;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNwPlaceCd(String nwPlaceCd)
/*     */   {
/* 219 */     this.nwPlaceCd = nwPlaceCd;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getOrganizationName()
/*     */   {
/* 228 */     return this.organizationName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOrganizationName(String organizationName)
/*     */   {
/* 237 */     this.organizationName = organizationName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getAllowedAuthorityCd()
/*     */   {
/* 246 */     return this.allowedAuthorityCd;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAllowedAuthorityCd(List<String> allowedAuthorityCd)
/*     */   {
/* 255 */     this.allowedAuthorityCd = allowedAuthorityCd;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDefaultNonUpdatableFlg()
/*     */   {
/* 264 */     return this.defaultNonUpdatableFlg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultNonUpdatableFlg(String defaultNonUpdatableFlg)
/*     */   {
/* 273 */     this.defaultNonUpdatableFlg = defaultNonUpdatableFlg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getAllowedScreenId()
/*     */   {
/* 282 */     return this.allowedScreenId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAllowedScreenId(List<String> allowedScreenId)
/*     */   {
/* 291 */     this.allowedScreenId = allowedScreenId;
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\CfwUserInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */