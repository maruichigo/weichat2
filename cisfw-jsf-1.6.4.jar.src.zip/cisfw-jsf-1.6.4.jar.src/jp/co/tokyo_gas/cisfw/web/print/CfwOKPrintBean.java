/*    */ package jp.co.tokyo_gas.cisfw.web.print;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import javax.faces.view.ViewScoped;
/*    */ import javax.inject.Inject;
/*    */ import javax.inject.Named;
/*    */ import jp.co.tokyo_gas.cisfw.exception.CfwApplicationException;
/*    */ import jp.co.tokyo_gas.cisfw.exception.CfwErrorMessage;
/*    */ import jp.co.tokyo_gas.cisfw.file.CfwTemporaryFileUtil;
/*    */ import jp.co.tokyo_gas.cisfw.logger.CfwLogger;
/*    */ import jp.co.tokyo_gas.cisfw.web.CfwBaseBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Named("cfwOKPrint")
/*    */ @ViewScoped
/*    */ public class CfwOKPrintBean
/*    */   extends CfwBaseBean
/*    */   implements Serializable
/*    */ {
/* 33 */   private boolean success = false;
/*    */   
/*    */ 
/*    */ 
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */ 
/*    */ 
/*    */   @Inject
/*    */   private CfwPrintSession cfwPrintSession;
/*    */   
/*    */ 
/*    */   @Inject
/*    */   private CfwTemporaryFileUtil cfwTemporaryFileUtil;
/*    */   
/*    */ 
/*    */   @Inject
/*    */   private CfwLogger log;
/*    */   
/*    */ 
/*    */ 
/*    */   public void init()
/*    */     throws CfwApplicationException
/*    */   {
/* 57 */     CfwPrintDto dto = this.cfwPrintSession.getDto();
/* 58 */     String fileId = dto.getFileId();
/* 59 */     String sheetId = dto.getSheetId();
/* 60 */     this.cfwTemporaryFileUtil.deleteFile(fileId);
/* 61 */     String warningPrinterName = dto.getWarningPrinterName();
/*    */     
/* 63 */     String clientId = this.cfwPrintSession.getClientId();
/* 64 */     this.cfwPrintSession.clear(clientId);
/* 65 */     if (warningPrinterName == null) {
/* 66 */       this.success = true;
/* 67 */       this.log.debug("直接印刷に成功しました。層間ファイルId:{},帳票Id:{}", fileId, sheetId);
/*    */     } else {
/* 69 */       this.success = false;
/* 70 */       CfwErrorMessage errors = new CfwErrorMessage("CXXM90055E", new String[] { warningPrinterName });
/* 71 */       throw new CfwApplicationException(new CfwErrorMessage[] { errors });
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isSuccess()
/*    */   {
/* 80 */     return this.success;
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\print\CfwOKPrintBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */