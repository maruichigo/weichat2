/*     */ package jp.co.tokyo_gas.cisfw.web.print;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import javax.faces.view.ViewScoped;
/*     */ import javax.inject.Inject;
/*     */ import javax.inject.Named;
/*     */ import jp.co.tokyo_gas.cisfw.exception.CfwApplicationException;
/*     */ import jp.co.tokyo_gas.cisfw.exception.CfwErrorMessage;
/*     */ import jp.co.tokyo_gas.cisfw.file.CfwTemporaryFileUtil;
/*     */ import jp.co.tokyo_gas.cisfw.logger.CfwLogger;
/*     */ import jp.co.tokyo_gas.cisfw.utils.CfwStringConverter;
/*     */ import jp.co.tokyo_gas.cisfw.web.CfwBaseBean;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Named("cfwNGPrint")
/*     */ @ViewScoped
/*     */ public class CfwNGPrintBean
/*     */   extends CfwBaseBean
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   @Inject
/*     */   private CfwLogger log;
/*     */   @Inject
/*     */   private CfwPrintSession cfwPrintSession;
/*     */   @Inject
/*     */   private CfwTemporaryFileUtil cfwTemporaryFileUtil;
/*     */   
/*     */   public void init()
/*     */     throws CfwApplicationException
/*     */   {
/*  59 */     CfwPrintDto dto = this.cfwPrintSession.getDto();
/*     */     
/*  61 */     String fileId = null;
/*  62 */     if (dto != null) {
/*  63 */       fileId = dto.getFileId();
/*     */       
/*     */ 
/*  66 */       this.cfwTemporaryFileUtil.deleteFile(fileId);
/*     */     }
/*     */     
/*     */ 
/*  70 */     String errcd = getRequestParameter("SVFWC_ERR_ERRCODE");
/*     */     
/*  72 */     String errms = getRequestParameter("SVFWC_ERR_MESSAGE");
/*     */     
/*  74 */     String errapinm = getRequestParameter("SVFWC_ERR_APINAME");
/*     */     
/*  76 */     logIfNeed(errcd, errms, errapinm, dto);
/*     */     
/*     */ 
/*  79 */     CfwErrorMessage errors = new CfwErrorMessage("CXXM90056E", new String[] { fileId == null ? "" : fileId });
/*  80 */     String clientId = this.cfwPrintSession.getClientId();
/*  81 */     if (clientId != null) {
/*  82 */       this.cfwPrintSession.clear(clientId);
/*     */     }
/*  84 */     throw new CfwApplicationException(new CfwErrorMessage[] { errors });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void logIfNeed(String errcd, String errms, String errapinm, CfwPrintDto dto)
/*     */   {
/*  96 */     if ((StringUtils.isNotBlank(errcd)) || (StringUtils.isNotBlank(errms)) || (StringUtils.isNotBlank(errapinm)))
/*     */     {
/*  98 */       errcd = errcd == null ? "" : CfwStringConverter.replaceCrlf(errcd, "");
/*  99 */       errms = errms == null ? "" : CfwStringConverter.replaceCrlf(errms, "");
/* 100 */       errapinm = errapinm == null ? "" : CfwStringConverter.replaceCrlf(errapinm, "");
/* 101 */       String fileId = dto == null ? "" : dto.getFileId();
/* 102 */       String sheetId = dto == null ? "" : dto.getSheetId();
/*     */       
/* 104 */       String msg = "直接印刷で、ActiveX内でのエラーが発生しました。層間ファイルID:{};帳票ID:{};エラーコード:{};API名:{};";
/* 105 */       this.log.warn(msg, new Object[] { fileId, sheetId, errcd, errapinm });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\print\CfwNGPrintBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */