/*    */ package jp.co.tokyo_gas.cisfw.web.print;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import javax.faces.view.ViewScoped;
/*    */ import javax.inject.Inject;
/*    */ import javax.inject.Named;
/*    */ import jp.co.tokyo_gas.cisfw.file.CfwTemporaryFileUtil;
/*    */ import jp.co.tokyo_gas.cisfw.web.CfwBaseBean;
/*    */ import jp.co.tokyo_gas.cisfw.web.utils.CfwResponseWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Named("cfwPrintDataResponse")
/*    */ @ViewScoped
/*    */ public class CfwPrintDataResponseBean
/*    */   extends CfwBaseBean
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   @Inject
/*    */   private CfwResponseWriter cfwResponseWriter;
/*    */   @Inject
/*    */   private CfwPrintSession cfwPrintSession;
/*    */   @Inject
/*    */   private CfwTemporaryFileUtil cfwTemporaryFileUtil;
/*    */   
/*    */   public void init()
/*    */   {
/* 44 */     CfwPrintDto dto = this.cfwPrintSession.getDto();
/*    */     
/* 46 */     String fileId = dto.getFileId();
/* 47 */     byte[] bytes = this.cfwTemporaryFileUtil.getFile(fileId);
/*    */     
/* 49 */     String sheetName = dto.getSheetName();
/* 50 */     this.cfwResponseWriter.outputResponse(bytes, sheetName);
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\print\CfwPrintDataResponseBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */