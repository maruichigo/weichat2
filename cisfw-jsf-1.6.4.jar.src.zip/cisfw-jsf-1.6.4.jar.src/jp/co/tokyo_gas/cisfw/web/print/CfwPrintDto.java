/*     */ package jp.co.tokyo_gas.cisfw.web.print;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CfwPrintDto
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String fileId;
/*     */   private String sheetId;
/*     */   private String sheetName;
/*     */   private String printerName;
/*     */   private String warningPrinterName;
/*     */   
/*     */   public CfwPrintDto() {}
/*     */   
/*     */   public CfwPrintDto(String fileId, String sheetId)
/*     */   {
/*  47 */     this.fileId = fileId;
/*  48 */     this.sheetId = sheetId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFileId()
/*     */   {
/*  57 */     return this.fileId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFileId(String fileId)
/*     */   {
/*  66 */     this.fileId = fileId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSheetId()
/*     */   {
/*  75 */     return this.sheetId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSheetId(String sheetId)
/*     */   {
/*  84 */     this.sheetId = sheetId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSheetName()
/*     */   {
/*  93 */     return this.sheetName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSheetName(String sheetName)
/*     */   {
/* 102 */     this.sheetName = sheetName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPrinterName()
/*     */   {
/* 111 */     return this.printerName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPrinterName(String printerName)
/*     */   {
/* 120 */     this.printerName = printerName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getWarningPrinterName()
/*     */   {
/* 129 */     return this.warningPrinterName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWarningPrinterName(String warningPrinterName)
/*     */   {
/* 138 */     this.warningPrinterName = warningPrinterName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 148 */     return "CfwPrintDto [fileId=" + this.fileId + ", sheetId=" + this.sheetId + ", sheetName=" + this.sheetName + ", printerName=" + this.printerName + ", warningPrinterName=" + this.warningPrinterName + "]";
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\print\CfwPrintDto.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */