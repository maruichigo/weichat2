/*     */ package jp.co.tokyo_gas.cisfw.web.print;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import javax.enterprise.context.SessionScoped;
/*     */ import javax.faces.context.ExternalContext;
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.faces.lifecycle.ClientWindow;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.FwFacesContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SessionScoped
/*     */ public class CfwPrintSession
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  41 */   private BlockingQueue<CfwPrintDto> mainToSubDto = new LinkedBlockingQueue();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  47 */   private Map<String, CfwPrintDto> dto = new ConcurrentHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addMainToSub(CfwPrintDto cfwPrintDto)
/*     */   {
/*  56 */     this.mainToSubDto.add(cfwPrintDto);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwPrintDto pollMainToSub()
/*     */   {
/*  67 */     return (CfwPrintDto)this.mainToSubDto.poll();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void putDto(String clientId, CfwPrintDto cfwPrintDto)
/*     */   {
/*  77 */     this.dto.put(clientId, cfwPrintDto);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwPrintDto getDto()
/*     */   {
/*  86 */     String clientId = getClientId();
/*  87 */     return (CfwPrintDto)this.dto.get(clientId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearAll()
/*     */   {
/*  95 */     this.mainToSubDto.clear();
/*  96 */     this.dto.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clear(String clientId)
/*     */   {
/* 107 */     this.dto.remove(clientId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   String getClientId()
/*     */   {
/* 117 */     FacesContext context = FwFacesContext.getFacesContext();
/* 118 */     ClientWindow clientWindow = context.getExternalContext().getClientWindow();
/*     */     
/* 120 */     if (clientWindow != null) {
/* 121 */       String clientId = clientWindow.getId();
/* 122 */       return clientId;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 127 */     String clientId = "clientId";
/* 128 */     return "clientId";
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\print\CfwPrintSession.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */