/*    */ package jp.co.tokyo_gas.cisfw.web.print;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import jp.co.tokyo_gas.cisfw.web.CfwBaseForm;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CfwPrinterDecideForm
/*    */   extends CfwBaseForm
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private boolean rendered;
/*    */   private String jfwid;
/*    */   private String printerName;
/*    */   
/*    */   public String getPrinterName()
/*    */   {
/* 36 */     return this.printerName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setPrinterName(String printerName)
/*    */   {
/* 45 */     this.printerName = printerName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getJfwid()
/*    */   {
/* 55 */     return this.jfwid;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setJfwid(String jfwid)
/*    */   {
/* 65 */     this.jfwid = jfwid;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isRendered()
/*    */   {
/* 76 */     return this.rendered;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setRendered(boolean render)
/*    */   {
/* 85 */     this.rendered = render;
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\print\CfwPrinterDecideForm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */