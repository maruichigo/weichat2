/*     */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.faces.application.ResourceDependencies;
/*     */ import javax.faces.component.FacesComponent;
/*     */ import javax.faces.component.StateHelper;
/*     */ import javax.faces.context.FacesContext;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.taglib.input.FwInputDateTime;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.message.FwMessage;
/*     */ import jp.co.tokyo_gas.cisfw.web.taglib.converter.CfwInputDateTimeConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FacesComponent("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwInputDateTime")
/*     */ @ResourceDependencies({@javax.faces.application.ResourceDependency(library="primefaces", name="primefaces.css"), @javax.faces.application.ResourceDependency(library="primefaces", name="jquery/jquery.js"), @javax.faces.application.ResourceDependency(library="primefaces", name="primefaces.js"), @javax.faces.application.ResourceDependency(library="primefaces", name="jquery/jquery-plugins.js"), @javax.faces.application.ResourceDependency(library="tgfw_js", name="tgfw.js"), @javax.faces.application.ResourceDependency(library="tgfw_css", name="tgfw.css"), @javax.faces.application.ResourceDependency(library="js", name="cisfw-component.js")})
/*     */ public class CfwInputDateTime
/*     */   extends FwInputDateTime
/*     */ {
/*     */   public static final String EVENT_DATESELECT = "dateSelect";
/*     */   public static final String COMPONENT_TYPE = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwInputDateTime";
/*     */   public static final String DEFAULT_RENDERER = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwInputDateTimeRenderer";
/*     */   public static final String COMPONENT_FAMILY = "jp.co.tokyo_gas.cisfw";
/*     */   
/*     */   public static enum PropertyKeys
/*     */   {
/*  61 */     width, 
/*     */     
/*     */ 
/*  64 */     messageParam, 
/*     */     
/*     */ 
/*  67 */     top, 
/*     */     
/*     */ 
/*  70 */     right, 
/*     */     
/*     */ 
/*  73 */     bottom, 
/*     */     
/*     */ 
/*  76 */     left;
/*     */     
/*     */     String toString;
/*     */     
/*     */     private PropertyKeys(String toString) {
/*  81 */       this.toString = toString;
/*     */     }
/*     */     
/*     */ 
/*     */     private PropertyKeys() {}
/*     */     
/*     */ 
/*     */     public String toString()
/*     */     {
/*  90 */       return this.toString != null ? this.toString : super.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public CfwInputDateTime()
/*     */   {
/*  98 */     setRendererType("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwInputDateTimeRenderer");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFamily()
/*     */   {
/* 107 */     return "jp.co.tokyo_gas.cisfw";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWidth(String width)
/*     */   {
/* 115 */     getStateHelper().put(PropertyKeys.width, width);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getWidth()
/*     */   {
/* 123 */     return (String)getStateHelper().eval(PropertyKeys.width, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMessageParam(String messageParam)
/*     */   {
/* 131 */     getStateHelper().put(PropertyKeys.messageParam, messageParam);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessageParam()
/*     */   {
/* 139 */     return (String)getStateHelper().eval(PropertyKeys.messageParam, "値");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTop()
/*     */   {
/* 147 */     return (String)getStateHelper().eval(PropertyKeys.top, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTop(String top)
/*     */   {
/* 155 */     getStateHelper().put(PropertyKeys.top, top);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRight()
/*     */   {
/* 163 */     return (String)getStateHelper().eval(PropertyKeys.right, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRight(String right)
/*     */   {
/* 171 */     getStateHelper().put(PropertyKeys.right, right);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBottom()
/*     */   {
/* 179 */     return (String)getStateHelper().eval(PropertyKeys.bottom, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBottom(String bottom)
/*     */   {
/* 187 */     getStateHelper().put(PropertyKeys.bottom, bottom);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLeft()
/*     */   {
/* 195 */     return (String)getStateHelper().eval(PropertyKeys.left, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLeft(String left)
/*     */   {
/* 203 */     getStateHelper().put(PropertyKeys.left, left);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void encodeEnd(FacesContext context)
/*     */     throws IOException
/*     */   {
/* 212 */     if (isRendered()) {
/* 213 */       CfwComponentUtils utils = CfwComponentUtils.getInstance();
/*     */       
/*     */ 
/* 216 */       String margin = utils.createMarginStyle(getTop(), getRight(), getBottom(), getLeft());
/* 217 */       setStyle(utils.addStyle(getStyle(), margin));
/*     */       
/*     */ 
/* 220 */       setStyle(utils.addStyle(getStyle(), "display:inline-block"));
/*     */       
/*     */ 
/*     */ 
/* 224 */       String code = utils.isDescendantOfCfwGrid(this) ? "CXXM90001E" : "CXXM90000E";
/* 225 */       setRequiredMessage(FwMessage.getInstance().getMessage(code, new Object[] { getMessageParam() }));
/*     */       
/*     */ 
/* 228 */       setConverter(new CfwInputDateTimeConverter());
/*     */       
/*     */ 
/* 231 */       setAjaxValidator(Boolean.valueOf(true));
/*     */     }
/*     */     
/* 234 */     super.encodeEnd(context);
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwInputDateTime.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */