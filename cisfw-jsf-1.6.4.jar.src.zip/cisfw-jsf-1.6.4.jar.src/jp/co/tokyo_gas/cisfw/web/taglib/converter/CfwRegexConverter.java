/*    */ package jp.co.tokyo_gas.cisfw.web.taglib.converter;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.util.Map;
/*    */ import javax.enterprise.inject.Instance;
/*    */ import javax.enterprise.inject.spi.CDI;
/*    */ import javax.faces.component.UIComponent;
/*    */ import javax.faces.context.FacesContext;
/*    */ import javax.faces.convert.Converter;
/*    */ import javax.faces.convert.FacesConverter;
/*    */ import jp.co.tokyo_gas.cisfw.utils.CfwRegexFormat;
/*    */ import jp.co.tokyo_gas.cisfw.utils.CfwStringValidator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FacesConverter("cisfw.faces.regex")
/*    */ public class CfwRegexConverter
/*    */   implements Converter
/*    */ {
/*    */   public static final String CONVERTER_ID = "cisfw.faces.regex";
/*    */   private static final String ATTR_KEY = "patternKey";
/*    */   private CfwRegexFormat format;
/*    */   
/*    */   public CfwRegexConverter()
/*    */   {
/* 39 */     this.format = ((CfwRegexFormat)CDI.current().select(CfwRegexFormat.class, new Annotation[0]).get());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getAsString(FacesContext context, UIComponent component, Object value)
/*    */   {
/* 53 */     if ((value == null) || (CfwStringValidator.isEmpty((String)value))) {
/* 54 */       return (String)value;
/*    */     }
/*    */     
/*    */ 
/* 58 */     Object valueOfAttr = component.getAttributes().get("patternKey");
/* 59 */     if (valueOfAttr == null) {
/* 60 */       return (String)value;
/*    */     }
/*    */     
/* 63 */     return this.format.format((String)value, (String)valueOfAttr);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Object getAsObject(FacesContext context, UIComponent component, String value)
/*    */   {
/* 77 */     if (CfwStringValidator.isEmpty(value)) {
/* 78 */       return value;
/*    */     }
/*    */     
/*    */ 
/* 82 */     Object valueOfAttr = component.getAttributes().get("patternKey");
/* 83 */     if (valueOfAttr == null) {
/* 84 */       return value;
/*    */     }
/*    */     
/* 87 */     return this.format.parse(value, (String)valueOfAttr);
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\converter\CfwRegexConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */