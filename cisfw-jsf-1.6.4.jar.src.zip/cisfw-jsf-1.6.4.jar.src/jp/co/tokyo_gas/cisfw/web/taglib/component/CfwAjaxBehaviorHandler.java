/*    */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*    */ 
/*    */ import javax.faces.view.facelets.BehaviorConfig;
/*    */ import javax.faces.view.facelets.FaceletContext;
/*    */ import org.primefaces.behavior.ajax.AjaxBehavior;
/*    */ import org.primefaces.behavior.ajax.AjaxBehaviorHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CfwAjaxBehaviorHandler
/*    */   extends AjaxBehaviorHandler
/*    */ {
/*    */   public CfwAjaxBehaviorHandler(BehaviorConfig config)
/*    */   {
/* 25 */     super(config);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public AjaxBehavior createBehavior(FaceletContext ctx, String eventName)
/*    */   {
/* 36 */     AjaxBehavior behavior = super.createBehavior(ctx, eventName);
/*    */     
/*    */ 
/* 39 */     if (behavior.getUpdate() == null) {
/* 40 */       behavior.setUpdate("@form");
/*    */     }
/*    */     
/* 43 */     return behavior;
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwAjaxBehaviorHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */