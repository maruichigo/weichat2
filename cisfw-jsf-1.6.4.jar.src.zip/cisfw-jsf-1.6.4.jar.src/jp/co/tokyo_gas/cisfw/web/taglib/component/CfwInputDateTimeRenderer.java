/*    */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.faces.context.FacesContext;
/*    */ import javax.faces.context.ResponseWriter;
/*    */ import javax.faces.render.FacesRenderer;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.string.FwStringValidator;
/*    */ import org.primefaces.component.calendar.Calendar;
/*    */ import org.primefaces.component.calendar.CalendarRenderer;
/*    */ import org.primefaces.config.ConfigContainer;
/*    */ import org.primefaces.context.ApplicationContext;
/*    */ import org.primefaces.context.RequestContext;
/*    */ import org.primefaces.util.HTML;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FacesRenderer(rendererType="jp.co.tokyo_gas.cisfw.web.taglib.component.CfwInputDateTimeRenderer", componentFamily="jp.co.tokyo_gas.cisfw")
/*    */ public class CfwInputDateTimeRenderer
/*    */   extends CalendarRenderer
/*    */ {
/*    */   protected void encodeInput(FacesContext context, Calendar calendar, String id, String value, boolean popup)
/*    */     throws IOException
/*    */   {
/* 42 */     ResponseWriter writer = context.getResponseWriter();
/* 43 */     String type = popup ? "text" : "hidden";
/*    */     
/* 45 */     boolean disabled = calendar.isDisabled();
/*    */     
/* 47 */     writer.startElement("input", null);
/* 48 */     writer.writeAttribute("id", id, null);
/* 49 */     writer.writeAttribute("name", id, null);
/* 50 */     writer.writeAttribute("type", type, null);
/*    */     
/* 52 */     if (calendar.isRequired()) {
/* 53 */       writer.writeAttribute("aria-required", "true", null);
/*    */     }
/*    */     
/* 56 */     if (!isValueBlank(value)) {
/* 57 */       writer.writeAttribute("value", value, null);
/*    */     }
/*    */     
/* 60 */     if (popup) {
/* 61 */       String inputStyleClass = "ui-inputfield ui-widget ui-state-default ui-corner-all";
/*    */       
/* 63 */       if (disabled) {
/* 64 */         inputStyleClass = inputStyleClass + " ui-state-disabled";
/*    */       }
/*    */       
/* 67 */       if (!calendar.isValid()) {
/* 68 */         inputStyleClass = inputStyleClass + " ui-state-error";
/*    */       }
/*    */       
/* 71 */       writer.writeAttribute("class", inputStyleClass, null);
/*    */       
/* 73 */       if ((calendar.isReadonly()) || (calendar.isReadonlyInput())) {
/* 74 */         writer.writeAttribute("readonly", "readonly", null);
/*    */       }
/*    */       
/* 77 */       if (calendar.isDisabled()) {
/* 78 */         writer.writeAttribute("disabled", "disabled", null);
/*    */       }
/*    */       
/*    */ 
/* 82 */       CfwComponentUtils utils = CfwComponentUtils.getInstance();
/* 83 */       CfwInputDateTime dateTime = (CfwInputDateTime)calendar;
/* 84 */       if (!FwStringValidator.isEmpty(dateTime.getWidth())) {
/* 85 */         String width = utils.toWidth(dateTime.getWidth(), -10);
/* 86 */         writer.writeAttribute("style", utils.createAttr("width", width), null);
/*    */       }
/*    */       
/* 89 */       renderPassThruAttributes(context, calendar, HTML.INPUT_TEXT_ATTRS_WITHOUT_EVENTS);
/* 90 */       renderDomEvents(context, calendar, HTML.INPUT_TEXT_EVENTS);
/*    */     }
/*    */     
/* 93 */     if (RequestContext.getCurrentInstance().getApplicationContext().getConfig().isClientSideValidationEnabled()) {
/* 94 */       renderValidationMetadata(context, calendar);
/*    */     }
/*    */     
/* 97 */     writer.endElement("input");
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwInputDateTimeRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */