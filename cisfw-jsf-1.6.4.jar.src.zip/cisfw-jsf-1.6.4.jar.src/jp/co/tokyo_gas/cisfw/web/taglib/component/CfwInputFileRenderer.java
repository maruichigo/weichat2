/*     */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.faces.context.ResponseWriter;
/*     */ import javax.faces.render.FacesRenderer;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.string.FwStringValidator;
/*     */ import org.primefaces.component.fileupload.FileUpload;
/*     */ import org.primefaces.component.fileupload.FileUploadRenderer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FacesRenderer(componentFamily="jp.co.tokyo_gas.cisfw", rendererType="jp.co.tokyo_gas.cisfw.web.taglib.component.CfwInputFileRenderer")
/*     */ public class CfwInputFileRenderer
/*     */   extends FileUploadRenderer
/*     */ {
/*     */   protected void encodeAdvancedMarkup(FacesContext context, FileUpload fileUpload)
/*     */     throws IOException
/*     */   {
/*  35 */     ResponseWriter writer = context.getResponseWriter();
/*  36 */     String clientId = fileUpload.getClientId(context);
/*  37 */     String styleClass = fileUpload.getStyleClass();
/*  38 */     styleClass = "ui-fileupload ui-widget " + styleClass;
/*     */     
/*  40 */     writer.startElement("div", fileUpload);
/*  41 */     writer.writeAttribute("id", clientId, "id");
/*  42 */     writer.writeAttribute("class", styleClass, styleClass);
/*  43 */     String style = fileUpload.getStyle();
/*  44 */     if (style != null) {
/*  45 */       writer.writeAttribute("style", style, "style");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  50 */     writer.startElement("div", null);
/*  51 */     writer.writeAttribute("class", "ui-fileupload-content ui-widget-content ui-corner-bottom", null);
/*  52 */     CfwComponentUtils utils = CfwComponentUtils.getInstance();
/*  53 */     CfwInputFile inputFile = (CfwInputFile)fileUpload;
/*     */     
/*     */ 
/*  56 */     if (!FwStringValidator.isEmpty(inputFile.getHeight())) {
/*  57 */       String height = utils.createAttr("height", utils.toHeight(inputFile.getHeight()));
/*  58 */       writer.writeAttribute("style", height + "overflow-y: auto;", null);
/*     */     }
/*     */     
/*     */ 
/*  62 */     writer.startElement("table", null);
/*  63 */     writer.writeAttribute("class", "ui-fileupload-files", null);
/*  64 */     writer.startElement("tbody", null);
/*  65 */     writer.endElement("tbody");
/*  66 */     writer.endElement("table");
/*     */     
/*  68 */     writer.endElement("div");
/*     */     
/*  70 */     renderChildren(context, fileUpload);
/*     */     
/*     */ 
/*     */ 
/*  74 */     writer.startElement("div", fileUpload);
/*  75 */     writer.writeAttribute("class", "ui-fileupload-buttonbar ui-widget-header ui-corner-top", null);
/*     */     
/*  77 */     boolean disabled = fileUpload.isDisabled();
/*     */     
/*  79 */     encodeChooseButton(context, fileUpload, disabled);
/*     */     
/*  81 */     if (!fileUpload.isAuto()) {
/*  82 */       encodeButton(context, fileUpload.getUploadLabel(), "ui-fileupload-upload", "ui-icon-arrowreturnthick-1-n");
/*  83 */       encodeButton(context, fileUpload.getCancelLabel(), "ui-fileupload-cancel", "ui-icon-cancel");
/*     */     }
/*     */     
/*  86 */     writer.endElement("div");
/*     */     
/*  88 */     writer.endElement("div");
/*     */   }
/*     */   
/*     */   protected void encodeChooseButton(FacesContext context, FileUpload fileUpload, boolean disabled) throws IOException
/*     */   {
/*  93 */     ResponseWriter writer = context.getResponseWriter();
/*  94 */     String clientId = fileUpload.getClientId(context);
/*  95 */     String cssClass = "ui-button ui-widget ui-state-default ui-corner-all ui-button-text-icon-left ui-fileupload-choose";
/*  96 */     if (disabled) {
/*  97 */       cssClass = cssClass + " ui-state-disabled";
/*     */     }
/*     */     
/* 100 */     writer.startElement("span", null);
/* 101 */     writer.writeAttribute("class", cssClass, null);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 106 */     writer.startElement("span", null);
/* 107 */     writer.writeAttribute("class", "ui-button-text ui-c", null);
/* 108 */     writer.writeText(fileUpload.getLabel(), "value");
/* 109 */     writer.endElement("span");
/*     */     
/* 111 */     if (!disabled) {
/* 112 */       encodeInputField(context, fileUpload, clientId + "_input");
/*     */     }
/*     */     
/* 115 */     writer.endElement("span");
/*     */   }
/*     */   
/*     */   protected void encodeButton(FacesContext context, String label, String styleClass, String icon) throws IOException
/*     */   {
/* 120 */     ResponseWriter writer = context.getResponseWriter();
/* 121 */     String cssClass = "ui-button ui-widget ui-state-default ui-corner-all ui-button-text-icon-left ui-state-disabled " + styleClass;
/*     */     
/* 123 */     writer.startElement("button", null);
/* 124 */     writer.writeAttribute("type", "button", null);
/* 125 */     writer.writeAttribute("class", cssClass, null);
/* 126 */     writer.writeAttribute("disabled", "disabled", null);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 131 */     writer.startElement("span", null);
/* 132 */     writer.writeAttribute("class", "ui-button-text ui-c", null);
/* 133 */     writer.writeText(label, "value");
/* 134 */     writer.endElement("span");
/*     */     
/* 136 */     writer.endElement("button");
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwInputFileRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */