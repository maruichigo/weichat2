/*     */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.faces.context.ResponseWriter;
/*     */ import javax.faces.render.FacesRenderer;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.string.FwStringValidator;
/*     */ import org.primefaces.component.spinner.Spinner;
/*     */ import org.primefaces.component.spinner.SpinnerRenderer;
/*     */ import org.primefaces.config.ConfigContainer;
/*     */ import org.primefaces.context.ApplicationContext;
/*     */ import org.primefaces.context.RequestContext;
/*     */ import org.primefaces.util.ComponentUtils;
/*     */ import org.primefaces.util.HTML;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FacesRenderer(componentFamily="jp.co.tokyo_gas.cisfw", rendererType="jp.co.tokyo_gas.cisfw.web.taglib.component.CfwInputNumberRenderer")
/*     */ public class CfwInputNumberRenderer
/*     */   extends SpinnerRenderer
/*     */ {
/*     */   protected void encodeMarkup(FacesContext context, Spinner spinner)
/*     */     throws IOException
/*     */   {
/*  44 */     String styleClass = spinner.getStyleClass();
/*  45 */     styleClass = "ui-spinner ui-widget ui-corner-all " + styleClass;
/*  46 */     styleClass = spinner.isDisabled() ? styleClass + " " + "ui-state-disabled" : styleClass;
/*     */     
/*     */ 
/*     */ 
/*  50 */     ResponseWriter writer = context.getResponseWriter();
/*  51 */     String clientId = spinner.getClientId(context);
/*     */     
/*  53 */     writer.startElement("span", null);
/*  54 */     writer.writeAttribute("id", clientId, null);
/*  55 */     writer.writeAttribute("class", styleClass, null);
/*  56 */     if (spinner.getStyle() != null) {
/*  57 */       writer.writeAttribute("style", spinner.getStyle(), null);
/*     */     }
/*     */     
/*  60 */     encodeInput(context, spinner);
/*     */     
/*     */ 
/*     */ 
/*  64 */     writer.endElement("span");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void encodeInput(FacesContext context, Spinner spinner)
/*     */     throws IOException
/*     */   {
/*  77 */     ResponseWriter writer = context.getResponseWriter();
/*  78 */     String inputId = spinner.getClientId(context) + "_input";
/*  79 */     String inputClass = spinner.isValid() ? "ui-spinner-input ui-inputfield ui-state-default ui-corner-all" : "ui-spinner-input ui-inputfield ui-state-default ui-corner-all ui-state-error";
/*     */     
/*  81 */     writer.startElement("input", null);
/*  82 */     writer.writeAttribute("id", inputId, null);
/*  83 */     writer.writeAttribute("name", inputId, null);
/*  84 */     writer.writeAttribute("type", "text", null);
/*  85 */     writer.writeAttribute("class", inputClass, null);
/*  86 */     writer.writeAttribute("autocomplete", "off", null);
/*     */     
/*  88 */     CfwInputNumber inputNumber = (CfwInputNumber)spinner;
/*  89 */     CfwComponentUtils utils = CfwComponentUtils.getInstance();
/*     */     
/*     */ 
/*  92 */     String inputStyle = utils.addStyle("padding-right:4px;", "width", utils.toWidth(inputNumber.getWidth(), -10));
/*  93 */     writer.writeAttribute("style", inputStyle, null);
/*     */     
/*  95 */     String valueToRender = ComponentUtils.getValueToRender(context, inputNumber);
/*  96 */     if (!FwStringValidator.isEmpty(valueToRender)) {
/*  97 */       valueToRender = inputNumber.getPrefix() != null ? inputNumber.getPrefix() + valueToRender : valueToRender;
/*     */       
/*     */ 
/* 100 */       valueToRender = inputNumber.getSuffix() != null ? valueToRender + inputNumber.getSuffix() : valueToRender;
/* 101 */       writer.writeAttribute("value", valueToRender, null);
/*     */     }
/*     */     
/* 104 */     renderPassThruAttributes(context, inputNumber, HTML.INPUT_TEXT_ATTRS_WITHOUT_EVENTS);
/* 105 */     renderDomEvents(context, inputNumber, HTML.INPUT_TEXT_EVENTS);
/*     */     
/* 107 */     if (inputNumber.isDisabled()) {
/* 108 */       writer.writeAttribute("disabled", "disabled", null);
/*     */     }
/* 110 */     if (inputNumber.isReadonly()) {
/* 111 */       writer.writeAttribute("readonly", "readonly", null);
/*     */     }
/* 113 */     if (inputNumber.isRequired()) {
/* 114 */       writer.writeAttribute("aria-required", "true", null);
/*     */     }
/*     */     
/*     */ 
/* 118 */     if (RequestContext.getCurrentInstance().getApplicationContext().getConfig().isClientSideValidationEnabled()) {
/* 119 */       renderValidationMetadata(context, inputNumber);
/*     */     }
/*     */     
/* 122 */     writer.endElement("input");
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwInputNumberRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */