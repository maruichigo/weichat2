/*    */ package jp.co.tokyo_gas.cisfw.web.taglib.validator;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ import java.util.regex.PatternSyntaxException;
/*    */ import javax.faces.application.FacesMessage;
/*    */ import javax.faces.component.UIComponent;
/*    */ import javax.faces.context.FacesContext;
/*    */ import javax.faces.validator.ValidatorException;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.message.FwMessage;
/*    */ import jp.co.tokyo_gas.cisfw.exception.CfwRuntimeException;
/*    */ import jp.co.tokyo_gas.cisfw.web.taglib.component.CfwComponentUtils;
/*    */ import org.primefaces.validate.RegexValidator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CfwRegexValidator
/*    */   extends RegexValidator
/*    */ {
/*    */   public void validate(FacesContext context, UIComponent component, Object value)
/*    */   {
/* 42 */     if (context == null) {
/* 43 */       throw new CfwRuntimeException("context is null", new Object[0]);
/*    */     }
/*    */     
/* 46 */     if (component == null) {
/* 47 */       throw new CfwRuntimeException("component is null", new Object[0]);
/*    */     }
/*    */     
/* 50 */     if (value == null) {
/* 51 */       return;
/*    */     }
/*    */     
/* 54 */     String regex = getPattern();
/*    */     
/* 56 */     if ((regex == null) || (regex.length() == 0))
/*    */     {
/* 58 */       throw new ValidatorException(getFacesMessage(component));
/*    */     }
/*    */     try
/*    */     {
/* 62 */       Pattern pattern = Pattern.compile(regex);
/* 63 */       Matcher matcher = pattern.matcher((String)value);
/*    */       
/* 65 */       if (!matcher.matches())
/*    */       {
/* 67 */         throw new ValidatorException(getFacesMessage(component));
/*    */       }
/*    */     }
/*    */     catch (PatternSyntaxException pse)
/*    */     {
/* 72 */       throw new ValidatorException(getFacesMessage(component), pse);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private FacesMessage getFacesMessage(UIComponent component)
/*    */   {
/* 83 */     CfwComponentUtils utils = CfwComponentUtils.getInstance();
/*    */     
/*    */ 
/* 86 */     String code = utils.isDescendantOfCfwGrid(component) ? "CXXM90047E" : "CXXM90046E";
/*    */     
/*    */ 
/* 89 */     String messageParam = (String)component.getAttributes().get("messageParam");
/*    */     
/* 91 */     FwMessage fwMessage = FwMessage.getInstance();
/* 92 */     String messageStr = fwMessage.getMessage(code, new Object[] { messageParam != null ? messageParam : "値" });
/*    */     
/* 94 */     return new FacesMessage(FacesMessage.SEVERITY_ERROR, messageStr, messageStr);
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\validator\CfwRegexValidator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */