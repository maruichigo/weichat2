/*     */ package jp.co.tokyo_gas.cisfw.web.taglib.converter;
/*     */ 
/*     */ import java.util.Map;
/*     */ import javax.faces.component.UIComponent;
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.faces.convert.Converter;
/*     */ import javax.faces.convert.FacesConverter;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.converter.FwPaddingConverter;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.converter.FwTrimConverter;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.string.FwStringValidator;
/*     */ import jp.co.tokyo_gas.cisfw.utils.CfwStringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FacesConverter("cisfw.faces.cfwInputText")
/*     */ public class CfwInputTextConverter
/*     */   implements Converter
/*     */ {
/*     */   public static final String CONVERTER_ID = "cisfw.faces.cfwInputText";
/*     */   
/*     */   public Object getAsObject(FacesContext context, UIComponent component, String value)
/*     */   {
/*     */     String uppercase;
/*     */     String uppercase;
/*  39 */     if (component.getAttributes().get("uppercase") == null) {
/*  40 */       uppercase = "true";
/*     */     } else {
/*  42 */       uppercase = (String)component.getAttributes().get("uppercase");
/*     */     }
/*     */     
/*     */     String patternKey;
/*     */     String patternKey;
/*  47 */     if (component.getAttributes().get("patternKey") == null) {
/*  48 */       patternKey = null;
/*     */     } else {
/*  50 */       patternKey = (String)component.getAttributes().get("patternKey");
/*     */     }
/*     */     
/*     */     String trim;
/*     */     String trim;
/*  55 */     if (component.getAttributes().get("trim") == null) {
/*  56 */       trim = "";
/*     */     } else {
/*  58 */       trim = (String)component.getAttributes().get("trim");
/*     */     }
/*     */     
/*     */     Character padding;
/*     */     Character padding;
/*  63 */     if (component.getAttributes().get("paddingLength") == null) {
/*  64 */       padding = null;
/*     */     } else {
/*  66 */       padding = (Character)component.getAttributes().get("padding");
/*     */     }
/*     */     String paddingLength;
/*     */     String paddingLength;
/*  70 */     if (component.getAttributes().get("paddingLength") == null) {
/*  71 */       paddingLength = null;
/*     */     } else {
/*  73 */       paddingLength = (String)component.getAttributes().get("paddingLength");
/*     */     }
/*     */     
/*  76 */     String paddingType = (String)component.getAttributes().get("paddingType");
/*  77 */     if (component.getAttributes().get("paddingType") == null) {
/*  78 */       paddingType = "right";
/*     */     } else {
/*  80 */       paddingType = (String)component.getAttributes().get("paddingType");
/*     */     }
/*     */     
/*  83 */     if (!FwStringValidator.isEmpty(value))
/*     */     {
/*     */ 
/*  86 */       if (!FwStringValidator.isEmpty(patternKey)) {
/*  87 */         CfwRegexConverter conv = new CfwRegexConverter();
/*  88 */         value = (String)conv.getAsObject(context, component, value);
/*     */       }
/*     */       
/*     */ 
/*  92 */       if ("true".equals(uppercase)) {
/*  93 */         value = CfwStringConverter.replaceAlphaHalfToUpperCase(value);
/*     */       }
/*     */       
/*     */ 
/*  97 */       if (("right".equals(trim)) || ("left".equals(trim)) || ("both".equals(trim))) {
/*  98 */         FwTrimConverter converter = new FwTrimConverter();
/*  99 */         value = (String)converter.getAsObject(context, component, value);
/*     */       }
/*     */       
/*     */ 
/* 103 */       if ((padding != null) && (FwStringValidator.isHalfWidthNum(paddingLength)) && (
/* 104 */         ("right".equals(paddingType)) || ("left".equals(paddingType)))) {
/* 105 */         FwPaddingConverter converter = new FwPaddingConverter();
/* 106 */         converter.setPadding(padding.charValue());
/* 107 */         converter.setLength(Integer.parseInt(paddingLength));
/* 108 */         converter.setType(paddingType);
/* 109 */         value = (String)converter.getAsObject(context, component, value);
/*     */       }
/*     */     }
/*     */     
/* 113 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAsString(FacesContext context, UIComponent component, Object value)
/*     */   {
/* 125 */     String valueStr = (String)value;
/*     */     
/*     */     String patternKey;
/*     */     String patternKey;
/* 129 */     if (component.getAttributes().get("patternKey") == null) {
/* 130 */       patternKey = null;
/*     */     } else {
/* 132 */       patternKey = (String)component.getAttributes().get("patternKey");
/*     */     }
/*     */     
/*     */     String trim;
/*     */     String trim;
/* 137 */     if (component.getAttributes().get("trim") == null) {
/* 138 */       trim = "";
/*     */     } else {
/* 140 */       trim = (String)component.getAttributes().get("trim");
/*     */     }
/*     */     
/*     */     Character padding;
/*     */     Character padding;
/* 145 */     if (component.getAttributes().get("paddingLength") == null) {
/* 146 */       padding = null;
/*     */     } else {
/* 148 */       padding = (Character)component.getAttributes().get("padding");
/*     */     }
/*     */     String paddingLength;
/*     */     String paddingLength;
/* 152 */     if (component.getAttributes().get("paddingLength") == null) {
/* 153 */       paddingLength = null;
/*     */     } else {
/* 155 */       paddingLength = (String)component.getAttributes().get("paddingLength");
/*     */     }
/*     */     
/* 158 */     String paddingType = (String)component.getAttributes().get("paddingType");
/* 159 */     if (component.getAttributes().get("paddingType") == null) {
/* 160 */       paddingType = "right";
/*     */     } else {
/* 162 */       paddingType = (String)component.getAttributes().get("paddingType");
/*     */     }
/*     */     
/* 165 */     if (!FwStringValidator.isEmpty(valueStr))
/*     */     {
/*     */ 
/* 168 */       if (!FwStringValidator.isEmpty(patternKey)) {
/* 169 */         CfwRegexConverter conv = new CfwRegexConverter();
/* 170 */         valueStr = conv.getAsString(context, component, value);
/*     */       }
/*     */       
/*     */ 
/* 174 */       if (("right".equals(trim)) || ("left".equals(trim)) || ("both".equals(trim))) {
/* 175 */         FwTrimConverter converter = new FwTrimConverter();
/* 176 */         valueStr = converter.getAsString(context, component, value);
/*     */       }
/*     */       
/*     */ 
/* 180 */       if ((padding != null) && (FwStringValidator.isHalfWidthNum(paddingLength)) && (
/* 181 */         ("right".equals(paddingType)) || ("left".equals(paddingType)))) {
/* 182 */         FwPaddingConverter converter = new FwPaddingConverter();
/* 183 */         converter.setPadding(padding.charValue());
/* 184 */         converter.setLength(Integer.parseInt(paddingLength));
/* 185 */         converter.setType(paddingType);
/* 186 */         valueStr = converter.getAsString(context, component, value);
/*     */       }
/*     */     }
/*     */     
/* 190 */     return valueStr;
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\converter\CfwInputTextConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */