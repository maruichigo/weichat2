/*     */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.faces.application.FacesMessage;
/*     */ import javax.faces.application.FacesMessage.Severity;
/*     */ import javax.faces.component.UIComponent;
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.faces.context.ResponseWriter;
/*     */ import javax.faces.render.FacesRenderer;
/*     */ import org.primefaces.component.messages.Messages;
/*     */ import org.primefaces.component.messages.MessagesRenderer;
/*     */ import org.primefaces.config.ConfigContainer;
/*     */ import org.primefaces.context.ApplicationContext;
/*     */ import org.primefaces.context.RequestContext;
/*     */ import org.primefaces.expression.SearchExpressionFacade;
/*     */ import org.primefaces.util.IteratorChain;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FacesRenderer(componentFamily="jp.co.tokyo_gas.cisfw", rendererType="jp.co.tokyo_gas.cisfw.web.taglib.component.CfwMessagesRenderer")
/*     */ public class CfwMessagesRenderer
/*     */   extends MessagesRenderer
/*     */ {
/*     */   public void encodeEnd(FacesContext context, UIComponent component)
/*     */     throws IOException
/*     */   {
/*  41 */     Messages uiMessages = (Messages)component;
/*  42 */     Map<String, List<FacesMessage>> messagesMap = new HashMap();
/*  43 */     boolean globalOnly = uiMessages.isGlobalOnly();
/*  44 */     String containerClass = uiMessages.isShowIcon() ? "ui-messages ui-widget" : "ui-messages ui-messages-noicon ui-widget";
/*  45 */     String styleClass = uiMessages.getStyleClass();
/*  46 */     styleClass = containerClass + " " + styleClass;
/*     */     
/*  48 */     String fora = uiMessages.getFor();
/*     */     Iterator<FacesMessage> messages;
/*  50 */     if (fora != null)
/*     */     {
/*  52 */       Iterator<FacesMessage> messages = context.getMessages(fora);
/*     */       
/*     */ 
/*  55 */       UIComponent forComponent = SearchExpressionFacade.resolveComponent(context, uiMessages, fora, 2);
/*     */       
/*  57 */       if (forComponent != null) {
/*  58 */         Iterator<FacesMessage> temp = context.getMessages(forComponent.getClientId(context));
/*  59 */         if ((temp != null) && (temp.hasNext())) {
/*  60 */           messages = new IteratorChain(messages, temp);
/*     */         }
/*     */       }
/*     */     } else {
/*  64 */       messages = uiMessages.isGlobalOnly() ? context.getMessages(null) : context.getMessages();
/*     */     }
/*     */     
/*  67 */     while (messages.hasNext()) {
/*  68 */       FacesMessage message = (FacesMessage)messages.next();
/*  69 */       FacesMessage.Severity severity = message.getSeverity();
/*     */       
/*  71 */       if (severity.equals(FacesMessage.SEVERITY_INFO)) {
/*  72 */         addMessage(uiMessages, message, messagesMap, "info");
/*  73 */       } else if (severity.equals(FacesMessage.SEVERITY_WARN)) {
/*  74 */         addMessage(uiMessages, message, messagesMap, "warn");
/*  75 */       } else if (severity.equals(FacesMessage.SEVERITY_ERROR)) {
/*  76 */         addMessage(uiMessages, message, messagesMap, "error");
/*  77 */       } else if (severity.equals(FacesMessage.SEVERITY_FATAL)) {
/*  78 */         addMessage(uiMessages, message, messagesMap, "fatal");
/*     */       }
/*     */     }
/*  81 */     ResponseWriter writer = context.getResponseWriter();
/*  82 */     String clientId = uiMessages.getClientId(context);
/*     */     
/*  84 */     writer.startElement("div", uiMessages);
/*  85 */     writer.writeAttribute("id", clientId, "id");
/*  86 */     writer.writeAttribute("class", styleClass, null);
/*     */     
/*  88 */     String style = uiMessages.getStyle();
/*  89 */     if (style != null) {
/*  90 */       writer.writeAttribute("style", style, null);
/*     */     }
/*     */     
/*  93 */     writer.writeAttribute("aria-live", "polite", null);
/*     */     
/*  95 */     if (RequestContext.getCurrentInstance().getApplicationContext().getConfig().isClientSideValidationEnabled()) {
/*  96 */       writer.writeAttribute("data-global", String.valueOf(globalOnly), null);
/*  97 */       writer.writeAttribute("data-summary", Boolean.valueOf(uiMessages.isShowSummary()), null);
/*  98 */       writer.writeAttribute("data-detail", Boolean.valueOf(uiMessages.isShowDetail()), null);
/*  99 */       writer.writeAttribute("data-severity", getClientSideSeverity(uiMessages.getSeverity()), null);
/* 100 */       writer.writeAttribute("data-redisplay", String.valueOf(uiMessages.isRedisplay()), null);
/*     */     }
/*     */     
/* 103 */     for (String severity : messagesMap.keySet()) {
/* 104 */       List<FacesMessage> severityMessages = (List)messagesMap.get(severity);
/*     */       
/* 106 */       if (severityMessages.size() > 0) {
/* 107 */         encodeSeverityMessages(context, uiMessages, severity, severityMessages);
/*     */       }
/*     */     }
/*     */     
/* 111 */     writer.endElement("div");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void encodeSeverityMessages(FacesContext context, Messages uiMessages, String severity, List<FacesMessage> messages)
/*     */     throws IOException
/*     */   {
/* 125 */     ResponseWriter writer = context.getResponseWriter();
/* 126 */     boolean escape = uiMessages.isEscape();
/*     */     
/*     */ 
/* 129 */     writer.startElement("div", null);
/* 130 */     writer.writeAttribute("class", "cisfw-messages", null);
/* 131 */     String style = "";
/* 132 */     CfwComponentUtils utils = CfwComponentUtils.getInstance();
/* 133 */     if ("info".equals(severity)) {
/* 134 */       style = utils.addStyle(style, "background-color", "#d9edf7");
/* 135 */       style = utils.addStyle(style, "border-color", "#bce8f1");
/* 136 */     } else if ("warn".equals(severity)) {
/* 137 */       style = utils.addStyle(style, "background-color", "#fcf8e3");
/* 138 */       style = utils.addStyle(style, "border-color", "#fbeed5");
/* 139 */     } else if ("error".equals(severity)) {
/* 140 */       style = utils.addStyle(style, "background-color", "#f2dede");
/* 141 */       style = utils.addStyle(style, "border-color", "#eed3d7");
/* 142 */     } else if ("fatal".equals(severity)) {
/* 143 */       style = utils.addStyle(style, "background-color", "#f2dede");
/* 144 */       style = utils.addStyle(style, "border-color", "#eed3d7");
/*     */     }
/* 146 */     writer.writeAttribute("style", style, null);
/*     */     
/* 148 */     writer.startElement("div", null);
/* 149 */     String styleClassPrefix = "ui-messages-" + severity;
/* 150 */     writer.writeAttribute("class", styleClassPrefix + " ui-corner-all", null);
/*     */     
/* 152 */     if (uiMessages.isClosable()) {
/* 153 */       encodeCloseIcon(context, uiMessages);
/*     */     }
/*     */     
/* 156 */     if (uiMessages.isShowIcon()) {
/* 157 */       writer.startElement("span", null);
/* 158 */       writer.writeAttribute("class", styleClassPrefix + "-icon", null);
/* 159 */       writer.endElement("span");
/*     */     }
/*     */     
/* 162 */     writer.startElement("ul", null);
/*     */     
/* 164 */     for (FacesMessage msg : messages) {
/* 165 */       writer.startElement("li", null);
/*     */       
/* 167 */       String summary = msg.getSummary() != null ? msg.getSummary() : "";
/* 168 */       String detail = msg.getDetail() != null ? msg.getDetail() : summary;
/*     */       
/* 170 */       if (uiMessages.isShowSummary()) {
/* 171 */         writer.startElement("span", null);
/* 172 */         writer.writeAttribute("class", styleClassPrefix + "-summary", null);
/*     */         
/* 174 */         if (escape) {
/* 175 */           writer.writeText(summary, null);
/*     */         } else {
/* 177 */           writer.write(summary);
/*     */         }
/* 179 */         writer.endElement("span");
/*     */       }
/*     */       
/* 182 */       if (uiMessages.isShowDetail()) {
/* 183 */         writer.startElement("span", null);
/* 184 */         writer.writeAttribute("class", styleClassPrefix + "-detail", null);
/*     */         
/* 186 */         if (escape) {
/* 187 */           writer.writeText(detail, null);
/*     */         } else {
/* 189 */           writer.write(detail);
/*     */         }
/*     */         
/* 192 */         writer.endElement("span");
/*     */       }
/*     */       
/* 195 */       writer.endElement("li");
/*     */       
/* 197 */       msg.rendered();
/*     */     }
/*     */     
/* 200 */     writer.endElement("ul");
/*     */     
/* 202 */     writer.endElement("div");
/* 203 */     writer.endElement("div");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void encodeCloseIcon(FacesContext context, Messages uiMessages)
/*     */     throws IOException
/*     */   {
/* 214 */     ResponseWriter writer = context.getResponseWriter();
/*     */     
/* 216 */     writer.startElement("a", null);
/* 217 */     writer.writeAttribute("href", "#", null);
/* 218 */     writer.writeAttribute("class", "ui-messages-close", null);
/*     */     
/* 220 */     writer.writeAttribute("onclick", "$(this).parent().parent().slideUp();return false;", null);
/*     */     
/* 222 */     writer.startElement("span", null);
/* 223 */     writer.writeAttribute("class", "ui-icon ui-icon-close", null);
/* 224 */     writer.endElement("span");
/*     */     
/* 226 */     writer.endElement("a");
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwMessagesRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */