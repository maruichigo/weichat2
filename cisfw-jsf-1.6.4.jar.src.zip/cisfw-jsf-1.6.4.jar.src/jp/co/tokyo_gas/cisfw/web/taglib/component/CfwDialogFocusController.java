/*     */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*     */ 
/*     */ import java.util.Map;
/*     */ import javax.faces.application.ResourceDependencies;
/*     */ import javax.faces.component.FacesComponent;
/*     */ import javax.faces.component.StateHelper;
/*     */ import javax.faces.component.UIComponentBase;
/*     */ import javax.faces.component.UINamingContainer;
/*     */ import javax.faces.context.FacesContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ResourceDependencies({@javax.faces.application.ResourceDependency(library="primefaces", name="jquery/jquery.js"), @javax.faces.application.ResourceDependency(library="primefaces", name="primefaces.js"), @javax.faces.application.ResourceDependency(library="primefaces", name="jquery/jquery-plugins.js"), @javax.faces.application.ResourceDependency(library="js", name="cisfw-component.js")})
/*     */ @FacesComponent("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwDialogFocusController")
/*     */ public class CfwDialogFocusController
/*     */   extends UIComponentBase
/*     */ {
/*     */   public static final String COMPONENT_TYPE = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwDialogFocusController";
/*     */   public static final String COMPONENT_FAMILY = "jp.co.tokyo_gas.cisfw";
/*     */   public static final String DEFAULT_RENDERER = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwDialogFocusControllerRenderer";
/*     */   
/*     */   public static enum PropertyKeys
/*     */   {
/*  41 */     start, 
/*     */     
/*     */ 
/*  44 */     end;
/*     */     
/*     */     String toString;
/*     */     
/*     */     private PropertyKeys(String toString) {
/*  49 */       this.toString = toString;
/*     */     }
/*     */     
/*     */ 
/*     */     private PropertyKeys() {}
/*     */     
/*     */ 
/*     */     public String toString()
/*     */     {
/*  58 */       return this.toString != null ? this.toString : super.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public CfwDialogFocusController()
/*     */   {
/*  66 */     setRendererType("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwDialogFocusControllerRenderer");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFamily()
/*     */   {
/*  75 */     return "jp.co.tokyo_gas.cisfw";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStart(String start)
/*     */   {
/*  83 */     getStateHelper().put(PropertyKeys.start, start);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getStart()
/*     */   {
/*  91 */     return (String)getStateHelper().eval(PropertyKeys.start, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEnd(String end)
/*     */   {
/*  99 */     getStateHelper().put(PropertyKeys.end, end);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getEnd()
/*     */   {
/* 107 */     return (String)getStateHelper().eval(PropertyKeys.end, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String resolveWidgetVar()
/*     */   {
/* 115 */     FacesContext context = getFacesContext();
/* 116 */     String userWidgetVar = (String)getAttributes().get("widgetVar");
/*     */     
/* 118 */     if (userWidgetVar != null) {
/* 119 */       return userWidgetVar;
/*     */     }
/*     */     
/* 122 */     return "widget_" + getClientId(context).replaceAll(new StringBuilder().append("-|").append(UINamingContainer.getSeparatorChar(context)).toString(), "_");
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwDialogFocusController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */