/*    */ package jp.co.tokyo_gas.cisfw.web.taglib.converter;
/*    */ 
/*    */ import javax.faces.component.UIComponent;
/*    */ import javax.faces.context.FacesContext;
/*    */ import javax.faces.convert.Converter;
/*    */ import javax.faces.convert.FacesConverter;
/*    */ import jp.co.tokyo_gas.cisfw.exception.CfwRuntimeException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FacesConverter("cisfw.faces.toLowerCase")
/*    */ public class CfwToLowerCaseConverter
/*    */   implements Converter
/*    */ {
/*    */   public static final String CONVERTER_ID = "cisfw.faces.toLowerCase";
/*    */   
/*    */   public String getAsString(FacesContext context, UIComponent component, Object value)
/*    */   {
/* 35 */     if (value == null) {
/* 36 */       throw new CfwRuntimeException("value is null", new Object[0]);
/*    */     }
/*    */     
/* 39 */     return ((String)value).toLowerCase();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Object getAsObject(FacesContext context, UIComponent component, String value)
/*    */   {
/* 52 */     if (value == null) {
/* 53 */       throw new CfwRuntimeException("value is null", new Object[0]);
/*    */     }
/*    */     
/* 56 */     return value.toLowerCase();
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\converter\CfwToLowerCaseConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */