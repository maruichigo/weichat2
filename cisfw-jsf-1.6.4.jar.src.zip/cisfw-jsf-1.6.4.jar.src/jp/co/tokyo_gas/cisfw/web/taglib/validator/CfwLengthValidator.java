/*    */ package jp.co.tokyo_gas.cisfw.web.taglib.validator;
/*    */ 
/*    */ import java.util.Map;
/*    */ import javax.faces.application.FacesMessage;
/*    */ import javax.faces.component.UIComponent;
/*    */ import javax.faces.context.FacesContext;
/*    */ import javax.faces.validator.ValidatorException;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.message.FwMessage;
/*    */ import jp.co.tokyo_gas.cisfw.exception.CfwRuntimeException;
/*    */ import jp.co.tokyo_gas.cisfw.web.taglib.component.CfwComponentUtils;
/*    */ import org.primefaces.validate.LengthValidator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CfwLengthValidator
/*    */   extends LengthValidator
/*    */ {
/*    */   public void validate(FacesContext context, UIComponent component, Object value)
/*    */     throws ValidatorException
/*    */   {
/* 38 */     if (context == null) {
/* 39 */       throw new CfwRuntimeException("context is null", new Object[0]);
/*    */     }
/*    */     
/* 42 */     if (component == null) {
/* 43 */       throw new CfwRuntimeException("component is null", new Object[0]);
/*    */     }
/*    */     
/* 46 */     if (value != null) {
/* 47 */       String converted = (String)value;
/* 48 */       int maximum = getMaximum();
/* 49 */       int minimum = getMinimum();
/*    */       
/*    */ 
/* 52 */       String messageParam = (String)component.getAttributes().get("messageParam");
/*    */       
/* 54 */       FacesMessage msg = null;
/* 55 */       String msgStr = null;
/*    */       
/*    */ 
/* 58 */       FwMessage message = FwMessage.getInstance();
/*    */       
/* 60 */       CfwComponentUtils utils = CfwComponentUtils.getInstance();
/*    */       
/* 62 */       if ((maximum != 0) && (converted.length() > maximum))
/*    */       {
/* 64 */         String code = utils.isDescendantOfCfwGrid(component) ? "CXXM90009E" : "CXXM90008E";
/*    */         
/* 66 */         msgStr = message.getMessage(code, new Object[] { messageParam != null ? messageParam : "値", Integer.valueOf(maximum) });
/* 67 */         msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msgStr, null);
/* 68 */         throw new ValidatorException(msg);
/*    */       }
/*    */       
/* 71 */       if ((minimum != 0) && (converted.length() < minimum))
/*    */       {
/* 73 */         String code = utils.isDescendantOfCfwGrid(component) ? "CXXM90011E" : "CXXM90010E";
/*    */         
/* 75 */         msgStr = message.getMessage(code, new Object[] { messageParam != null ? messageParam : "値", Integer.valueOf(minimum) });
/* 76 */         msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msgStr, null);
/* 77 */         throw new ValidatorException(msg);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\validator\CfwLengthValidator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */