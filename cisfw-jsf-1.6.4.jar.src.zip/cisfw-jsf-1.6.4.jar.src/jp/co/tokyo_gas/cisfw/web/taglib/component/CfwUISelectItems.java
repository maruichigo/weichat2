/*     */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.enterprise.inject.Instance;
/*     */ import javax.enterprise.inject.spi.CDI;
/*     */ import javax.faces.component.FacesComponent;
/*     */ import javax.faces.component.StateHelper;
/*     */ import javax.faces.component.UISelectItems;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.string.FwStringValidator;
/*     */ import jp.co.tokyo_gas.cisfw.constantmaster.CfwConstantInfo;
/*     */ import jp.co.tokyo_gas.cisfw.constantmaster.CfwConstantMasterCache;
/*     */ import jp.co.tokyo_gas.cisfw.utils.CfwStringConverter;
/*     */ import jp.co.tokyo_gas.cisfw.web.cache.CfwCache;
/*     */ import jp.co.tokyo_gas.cisfw.web.cache.CfwSelectItem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FacesComponent("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwUISelectItems")
/*     */ public class CfwUISelectItems
/*     */   extends UISelectItems
/*     */ {
/*     */   public static final String COMPONENT_TYPE = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwUISelectItems";
/*     */   public static final String COMPONENT_FAMILY = "jp.co.tokyo_gas.cisfw";
/*     */   
/*     */   static enum PropertyKeys
/*     */   {
/*  40 */     cacheKey, 
/*     */     
/*     */ 
/*  43 */     type, 
/*     */     
/*     */ 
/*  46 */     shortName, 
/*     */     
/*     */ 
/*  49 */     entry, 
/*     */     
/*     */ 
/*  52 */     display;
/*     */     
/*     */ 
/*     */     private PropertyKeys() {}
/*     */   }
/*     */   
/*     */   public CfwUISelectItems()
/*     */   {
/*  60 */     setRendererType(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFamily()
/*     */   {
/*  70 */     return "jp.co.tokyo_gas.cisfw";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCacheKey()
/*     */   {
/*  79 */     return (String)getStateHelper().eval(PropertyKeys.cacheKey, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCacheKey(String cacheKey)
/*     */   {
/*  88 */     getStateHelper().put(PropertyKeys.cacheKey, cacheKey);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getType()
/*     */   {
/*  97 */     return (String)getStateHelper().eval(PropertyKeys.type, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setType(String type)
/*     */   {
/* 106 */     getStateHelper().put(PropertyKeys.type, type);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Boolean isShortName()
/*     */   {
/* 115 */     return (Boolean)getStateHelper().eval(PropertyKeys.shortName, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setShortName(Boolean shortName)
/*     */   {
/* 124 */     getStateHelper().put(PropertyKeys.shortName, shortName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Boolean isEntry()
/*     */   {
/* 133 */     return (Boolean)getStateHelper().eval(PropertyKeys.entry, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEntry(boolean entry)
/*     */   {
/* 142 */     getStateHelper().put(PropertyKeys.entry, Boolean.valueOf(entry));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDisplay()
/*     */   {
/* 151 */     return (String)getStateHelper().eval(PropertyKeys.display, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDisplay(String display)
/*     */   {
/* 160 */     getStateHelper().put(PropertyKeys.display, display);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void cacheKeyToValue()
/*     */   {
/* 167 */     String cacheKey = getCacheKey();
/*     */     
/* 169 */     if (!FwStringValidator.isEmpty(cacheKey)) {
/* 170 */       CfwCache cache = (CfwCache)CDI.current().select(CfwCache.class, new Annotation[0]).get();
/* 171 */       setValue(cache.get(cacheKey));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void constantMasterCache()
/*     */   {
/* 181 */     if (null == isShortName()) {
/* 182 */       setShortName(Boolean.valueOf(false));
/*     */     }
/*     */     
/*     */ 
/* 186 */     if (null == isEntry()) {
/* 187 */       setEntry(false);
/*     */     }
/*     */     
/*     */ 
/* 191 */     if (FwStringValidator.isEmpty(getDisplay())) {
/* 192 */       setDisplay("1");
/*     */     }
/*     */     
/*     */ 
/* 196 */     String display = getDisplay();
/*     */     
/* 198 */     if (!FwStringValidator.isEmpty(getType()))
/*     */     {
/* 200 */       List<CfwSelectItem> itemList = new ArrayList();
/*     */       
/*     */ 
/*     */ 
/* 204 */       CfwConstantMasterCache masterCache = (CfwConstantMasterCache)CDI.current().select(CfwConstantMasterCache.class, new Annotation[0]).get();
/*     */       
/*     */ 
/* 207 */       List<CfwConstantInfo> infoList = masterCache.getConstantInfoList(CfwStringConverter.trimRightSpaces(getType()), isEntry().booleanValue());
/*     */       
/* 209 */       if (infoList != null) {
/* 210 */         for (CfwConstantInfo info : infoList)
/*     */         {
/* 212 */           CfwSelectItem item = new CfwSelectItem();
/* 213 */           item.setValue(info.getCode());
/*     */           
/* 215 */           if ("2".equals(display)) {
/* 216 */             item.setLabel(info.getCode());
/* 217 */           } else if ("3".equals(display))
/*     */           {
/* 219 */             if (isShortName().booleanValue()) {
/* 220 */               item.setLabel(info.getCode() + ":" + info.getShortName());
/*     */             } else {
/* 222 */               item.setLabel(info.getCode() + ":" + info.getName());
/*     */             }
/*     */             
/*     */ 
/*     */           }
/* 227 */           else if (isShortName().booleanValue()) {
/* 228 */             item.setLabel(info.getShortName());
/*     */           } else {
/* 230 */             item.setLabel(info.getName());
/*     */           }
/*     */           
/* 233 */           itemList.add(item);
/*     */         }
/*     */       }
/*     */       
/* 237 */       setValue(itemList);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwUISelectItems.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */