/*     */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.faces.application.ResourceDependencies;
/*     */ import javax.faces.component.UIComponent;
/*     */ import javax.faces.component.UIInput;
/*     */ import javax.faces.component.UISelectItem;
/*     */ import javax.faces.component.UISelectItems;
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.faces.context.ResponseWriter;
/*     */ import javax.faces.convert.Converter;
/*     */ import javax.faces.model.SelectItem;
/*     */ import javax.faces.model.SelectItemGroup;
/*     */ import javax.faces.render.FacesRenderer;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.string.FwStringValidator;
/*     */ import jp.co.tokyo_gas.cisfw.web.cache.CfwSelectItem;
/*     */ import org.primefaces.component.selectonemenu.SelectOneMenu;
/*     */ import org.primefaces.component.selectonemenu.SelectOneMenuRenderer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ResourceDependencies({@javax.faces.application.ResourceDependency(library="tgfw_js", name="tgfw.js"), @javax.faces.application.ResourceDependency(library="js", name="cisfw-component.js")})
/*     */ @FacesRenderer(componentFamily="jp.co.tokyo_gas.cisfw", rendererType="jp.co.tokyo_gas.cisfw.web.taglib.component.CfwSelectOneMenuRenderer")
/*     */ public class CfwSelectOneMenuRenderer
/*     */   extends SelectOneMenuRenderer
/*     */ {
/*     */   protected List<SelectItem> getSelectItems(FacesContext context, UIInput component)
/*     */   {
/*  59 */     List<SelectItem> selectItems = new ArrayList();
/*     */     
/*  61 */     for (UIComponent child : component.getChildren())
/*     */     {
/*  63 */       if ((child instanceof UISelectItem)) {
/*  64 */         UISelectItem uiSelectItem = (UISelectItem)child;
/*  65 */         Object selectItemValue = uiSelectItem.getValue();
/*     */         
/*  67 */         if (selectItemValue == null)
/*     */         {
/*     */ 
/*  70 */           if ((uiSelectItem instanceof CfwUISelectItem)) {
/*  71 */             CfwUISelectItem cfwUISelectItem = (CfwUISelectItem)uiSelectItem;
/*  72 */             selectItems.add(new CfwSelectItem(cfwUISelectItem.getItemValue(), cfwUISelectItem
/*  73 */               .getItemLabel(), cfwUISelectItem.getItemDescription(), cfwUISelectItem
/*  74 */               .isItemDisabled(), cfwUISelectItem.isItemEscaped(), cfwUISelectItem
/*  75 */               .isNoSelectionOption(), cfwUISelectItem.getCondition()));
/*     */           }
/*     */           else {
/*  78 */             selectItems.add(new SelectItem(uiSelectItem.getItemValue(), uiSelectItem
/*  79 */               .getItemLabel(), uiSelectItem.getItemDescription(), uiSelectItem
/*  80 */               .isItemDisabled(), uiSelectItem.isItemEscaped(), uiSelectItem
/*  81 */               .isNoSelectionOption()));
/*     */           }
/*     */         }
/*     */         else {
/*  85 */           selectItems.add((SelectItem)selectItemValue);
/*     */         }
/*     */       }
/*  88 */       else if ((child instanceof UISelectItems))
/*     */       {
/*     */ 
/*  91 */         if ((child instanceof CfwUISelectItems)) {
/*  92 */           ((CfwUISelectItems)child).constantMasterCache();
/*     */         }
/*     */         
/*     */ 
/*  96 */         if (((child instanceof CfwUISelectItems)) && (FwStringValidator.isEmpty(((CfwUISelectItems)child).getType()))) {
/*  97 */           ((CfwUISelectItems)child).cacheKeyToValue();
/*     */         }
/*     */         
/* 100 */         uiSelectItems = (UISelectItems)child;
/*     */         
/* 102 */         Object value = uiSelectItems.getValue();
/*     */         
/* 104 */         if (value != null)
/* 105 */           if ((value instanceof SelectItem)) {
/* 106 */             selectItems.add((SelectItem)value);
/*     */           }
/* 108 */           else if (value.getClass().isArray()) {
/* 109 */             for (int i = 0; i < Array.getLength(value); i++) {
/* 110 */               Object item = Array.get(value, i);
/*     */               
/* 112 */               if ((item instanceof SelectItem)) {
/* 113 */                 selectItems.add((SelectItem)item);
/*     */               }
/*     */               else
/* 116 */                 selectItems.add(createSelectItem(context, uiSelectItems, item, null));
/*     */             }
/*     */           } else { Map<?, ?> map;
/*     */             Iterator<?> it;
/* 120 */             if ((value instanceof Map)) {
/* 121 */               map = (Map)value;
/*     */               
/* 123 */               for (it = map.keySet().iterator(); it.hasNext();) {
/* 124 */                 Object key = it.next();
/*     */                 
/* 126 */                 selectItems.add(createSelectItem(context, uiSelectItems, map
/* 127 */                   .get(key), String.valueOf(key)));
/*     */               }
/*     */             }
/* 130 */             else if ((value instanceof Collection)) {
/* 131 */               Collection<?> collection = (Collection)value;
/*     */               
/* 133 */               for (it = collection.iterator(); it.hasNext();) {
/* 134 */                 Object item = it.next();
/* 135 */                 if ((item instanceof SelectItem)) {
/* 136 */                   selectItems.add((SelectItem)item);
/*     */                 }
/*     */                 else
/* 139 */                   selectItems.add(createSelectItem(context, uiSelectItems, item, null));
/*     */               }
/*     */             }
/*     */           }
/*     */       } }
/*     */     UISelectItems uiSelectItems;
/*     */     Iterator<?> it;
/* 146 */     return selectItems;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void encodeOption(FacesContext context, SelectOneMenu menu, SelectItem option, Object values, Object submittedValues, Converter converter)
/*     */     throws IOException
/*     */   {
/* 162 */     ResponseWriter writer = context.getResponseWriter();
/*     */     
/* 164 */     if ((option instanceof SelectItemGroup)) {
/* 165 */       SelectItemGroup group = (SelectItemGroup)option;
/*     */       
/* 167 */       for (SelectItem groupItem : group.getSelectItems()) {
/* 168 */         encodeOption(context, menu, groupItem, values, submittedValues, converter);
/*     */       }
/*     */     }
/*     */     else {
/* 172 */       String itemValueAsString = getOptionAsString(context, menu, converter, option.getValue());
/*     */       
/*     */       Object itemValue;
/*     */       Object valuesArray;
/*     */       Object itemValue;
/* 177 */       if (submittedValues != null) {
/* 178 */         Object valuesArray = submittedValues;
/* 179 */         itemValue = itemValueAsString;
/*     */       }
/*     */       else {
/* 182 */         valuesArray = values;
/* 183 */         itemValue = option.getValue();
/*     */       }
/*     */       
/* 186 */       writer.startElement("option", null);
/* 187 */       writer.writeAttribute("value", itemValueAsString, null);
/*     */       
/* 189 */       boolean disabled = option.isDisabled();
/*     */       
/* 191 */       if (disabled) {
/* 192 */         writer.writeAttribute("disabled", "disabled", null);
/*     */       }
/*     */       
/* 195 */       boolean selected = isSelected(context, menu, itemValue, valuesArray, converter);
/*     */       
/* 197 */       if (selected) {
/* 198 */         writer.writeAttribute("selected", "selected", null);
/*     */       }
/*     */       
/*     */ 
/* 202 */       if ((option instanceof CfwSelectItem)) {
/* 203 */         CfwSelectItem cfwSelectItem = (CfwSelectItem)option;
/* 204 */         String condition = cfwSelectItem.getCondition();
/*     */         
/* 206 */         if (condition != null) {
/* 207 */           writer.writeAttribute("condition", condition, null);
/*     */         }
/*     */       }
/*     */       
/* 211 */       if (!isValueBlank(option.getLabel()))
/*     */       {
/* 213 */         if (option.isEscape()) {
/* 214 */           writer.writeText(option.getLabel(), "value");
/*     */         }
/*     */         else {
/* 217 */           writer.write(option.getLabel());
/*     */         }
/*     */       }
/*     */       
/* 221 */       writer.endElement("option");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwSelectOneMenuRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */