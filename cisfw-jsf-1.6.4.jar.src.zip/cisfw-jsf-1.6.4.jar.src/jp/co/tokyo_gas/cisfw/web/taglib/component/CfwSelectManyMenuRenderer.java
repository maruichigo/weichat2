/*     */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.faces.application.ResourceDependencies;
/*     */ import javax.faces.component.UIComponent;
/*     */ import javax.faces.component.UIInput;
/*     */ import javax.faces.component.UISelectItem;
/*     */ import javax.faces.component.UISelectItems;
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.faces.context.ResponseWriter;
/*     */ import javax.faces.convert.Converter;
/*     */ import javax.faces.model.SelectItem;
/*     */ import javax.faces.render.FacesRenderer;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.string.FwStringValidator;
/*     */ import jp.co.tokyo_gas.cisfw.web.cache.CfwSelectItem;
/*     */ import org.primefaces.component.selectmanymenu.SelectManyMenu;
/*     */ import org.primefaces.component.selectmanymenu.SelectManyMenuRenderer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FacesRenderer(rendererType="jp.co.tokyo_gas.cisfw.web.taglib.component.CfwSelectManyMenuRenderer", componentFamily="jp.co.tokyo_gas")
/*     */ @ResourceDependencies({@javax.faces.application.ResourceDependency(library="tgfw_js", name="tgfw.js"), @javax.faces.application.ResourceDependency(library="js", name="cisfw-component.js")})
/*     */ public class CfwSelectManyMenuRenderer
/*     */   extends SelectManyMenuRenderer
/*     */ {
/*     */   protected List<SelectItem> getSelectItems(FacesContext context, UIInput component)
/*     */   {
/*  58 */     List<SelectItem> selectItems = new ArrayList();
/*     */     
/*  60 */     for (UIComponent child : component.getChildren())
/*     */     {
/*  62 */       if ((child instanceof UISelectItem)) {
/*  63 */         UISelectItem uiSelectItem = (UISelectItem)child;
/*  64 */         Object selectItemValue = uiSelectItem.getValue();
/*     */         
/*  66 */         if (selectItemValue == null)
/*     */         {
/*     */ 
/*  69 */           if ((uiSelectItem instanceof CfwUISelectItem)) {
/*  70 */             CfwUISelectItem cfwUISelectItem = (CfwUISelectItem)uiSelectItem;
/*  71 */             selectItems.add(new CfwSelectItem(cfwUISelectItem.getItemValue(), cfwUISelectItem
/*  72 */               .getItemLabel(), cfwUISelectItem.getItemDescription(), cfwUISelectItem
/*  73 */               .isItemDisabled(), cfwUISelectItem.isItemEscaped(), cfwUISelectItem
/*  74 */               .isNoSelectionOption(), cfwUISelectItem.getCondition()));
/*     */           }
/*     */           else {
/*  77 */             selectItems.add(new SelectItem(uiSelectItem.getItemValue(), uiSelectItem
/*  78 */               .getItemLabel(), uiSelectItem.getItemDescription(), uiSelectItem
/*  79 */               .isItemDisabled(), uiSelectItem.isItemEscaped(), uiSelectItem
/*  80 */               .isNoSelectionOption()));
/*     */           }
/*     */         }
/*     */         else {
/*  84 */           selectItems.add((SelectItem)selectItemValue);
/*     */         }
/*     */       }
/*  87 */       else if ((child instanceof UISelectItems))
/*     */       {
/*     */ 
/*  90 */         if ((child instanceof CfwUISelectItems)) {
/*  91 */           ((CfwUISelectItems)child).constantMasterCache();
/*     */         }
/*     */         
/*     */ 
/*  95 */         if (((child instanceof CfwUISelectItems)) && (FwStringValidator.isEmpty(((CfwUISelectItems)child).getType()))) {
/*  96 */           ((CfwUISelectItems)child).cacheKeyToValue();
/*     */         }
/*     */         
/*  99 */         uiSelectItems = (UISelectItems)child;
/*     */         
/* 101 */         Object value = uiSelectItems.getValue();
/*     */         
/* 103 */         if (value != null)
/* 104 */           if ((value instanceof SelectItem)) {
/* 105 */             selectItems.add((SelectItem)value);
/*     */           }
/* 107 */           else if (value.getClass().isArray()) {
/* 108 */             for (int i = 0; i < Array.getLength(value); i++) {
/* 109 */               Object item = Array.get(value, i);
/*     */               
/* 111 */               if ((item instanceof SelectItem)) {
/* 112 */                 selectItems.add((SelectItem)item);
/*     */               }
/*     */               else
/* 115 */                 selectItems.add(createSelectItem(context, uiSelectItems, item, null));
/*     */             }
/*     */           } else { Map<?, ?> map;
/*     */             Iterator<?> it;
/* 119 */             if ((value instanceof Map)) {
/* 120 */               map = (Map)value;
/*     */               
/* 122 */               for (it = map.keySet().iterator(); it.hasNext();) {
/* 123 */                 Object key = it.next();
/*     */                 
/* 125 */                 selectItems.add(createSelectItem(context, uiSelectItems, map
/* 126 */                   .get(key), String.valueOf(key)));
/*     */               }
/*     */             }
/* 129 */             else if ((value instanceof Collection)) {
/* 130 */               Collection<?> collection = (Collection)value;
/*     */               
/* 132 */               for (it = collection.iterator(); it.hasNext();) {
/* 133 */                 Object item = it.next();
/* 134 */                 if ((item instanceof SelectItem)) {
/* 135 */                   selectItems.add((SelectItem)item);
/*     */                 }
/*     */                 else
/* 138 */                   selectItems.add(createSelectItem(context, uiSelectItems, item, null));
/*     */               }
/*     */             }
/*     */           }
/*     */       } }
/*     */     UISelectItems uiSelectItems;
/*     */     Iterator<?> it;
/* 145 */     return selectItems;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void encodeOption(FacesContext context, SelectManyMenu menu, SelectItem option, Object values, Object submittedValues, Converter converter)
/*     */     throws IOException
/*     */   {
/* 158 */     ResponseWriter writer = context.getResponseWriter();
/* 159 */     String itemValueAsString = getOptionAsString(context, menu, converter, option.getValue());
/*     */     
/*     */     Object itemValue;
/*     */     Object valuesArray;
/*     */     Object itemValue;
/* 164 */     if (submittedValues != null) {
/* 165 */       Object valuesArray = submittedValues;
/* 166 */       itemValue = itemValueAsString;
/*     */     }
/*     */     else {
/* 169 */       valuesArray = values;
/* 170 */       itemValue = option.getValue();
/*     */     }
/*     */     
/* 173 */     boolean selected = isSelected(context, menu, itemValue, valuesArray, converter);
/*     */     
/* 175 */     if ((option.isNoSelectionOption()) && (values != null) && (!selected)) {
/* 176 */       return;
/*     */     }
/*     */     
/* 179 */     writer.startElement("option", null);
/* 180 */     writer.writeAttribute("value", itemValueAsString, null);
/*     */     
/* 182 */     boolean disabled = (option.isDisabled()) || (menu.isDisabled());
/*     */     
/* 184 */     if (disabled) {
/* 185 */       writer.writeAttribute("disabled", "disabled", null);
/*     */     }
/*     */     
/* 188 */     if (selected) {
/* 189 */       writer.writeAttribute("selected", "selected", null);
/*     */     }
/*     */     
/*     */ 
/* 193 */     if ((option instanceof CfwSelectItem)) {
/* 194 */       CfwSelectItem cfwSelectItem = (CfwSelectItem)option;
/* 195 */       String condition = cfwSelectItem.getCondition();
/*     */       
/* 197 */       if (condition != null) {
/* 198 */         writer.writeAttribute("condition", condition, null);
/*     */       }
/*     */     }
/*     */     
/* 202 */     writer.write(option.getLabel());
/*     */     
/* 204 */     writer.endElement("option");
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwSelectManyMenuRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */