/*     */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.StringJoiner;
/*     */ import javax.el.ValueExpression;
/*     */ import javax.faces.FacesException;
/*     */ import javax.faces.application.ResourceDependencies;
/*     */ import javax.faces.component.UIComponent;
/*     */ import javax.faces.context.ExternalContext;
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.faces.context.ResponseWriter;
/*     */ import javax.faces.model.DataModel;
/*     */ import javax.faces.render.FacesRenderer;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.string.FwStringValidator;
/*     */ import org.apache.commons.beanutils.PropertyUtils;
/*     */ import org.apache.commons.lang3.BooleanUtils;
/*     */ import org.primefaces.component.api.DynamicColumn;
/*     */ import org.primefaces.component.api.UIColumn;
/*     */ import org.primefaces.component.column.Column;
/*     */ import org.primefaces.component.datatable.DataTable;
/*     */ import org.primefaces.component.datatable.DataTableRenderer;
/*     */ import org.primefaces.component.datatable.feature.DataTableFeatureKey;
/*     */ import org.primefaces.component.datatable.feature.RowExpandFeature;
/*     */ import org.primefaces.component.subtable.SubTable;
/*     */ import org.primefaces.model.SortMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FacesRenderer(componentFamily="jp.co.tokyo_gas.cisfw", rendererType="jp.co.tokyo_gas.cisfw.web.taglib.component.CfwGridRenderer")
/*     */ @ResourceDependencies({@javax.faces.application.ResourceDependency(library="tgfw_js", name="tgfw.js"), @javax.faces.application.ResourceDependency(library="js", name="cisfw-component.js")})
/*     */ public class CfwGridRenderer
/*     */   extends DataTableRenderer
/*     */ {
/*     */   public void encodeEnd(FacesContext context, UIComponent component)
/*     */     throws IOException
/*     */   {
/*  73 */     CfwGrid dataTable = (CfwGrid)component;
/*     */     
/*     */ 
/*  76 */     dataTable.setScrollable(true);
/*     */     
/*     */ 
/*  79 */     dataTable.setResizableColumns(true);
/*  80 */     dataTable.setFirst(0);
/*     */     
/*     */ 
/*  83 */     dataTable.setCaseSensitiveSort(true);
/*     */     
/*     */ 
/*  86 */     dataTable.setSortMode("single");
/*     */     
/*     */ 
/*  89 */     if (!BooleanUtils.isFalse(dataTable.isRenderedGridHeader()))
/*     */     {
/*  91 */       dataTable.setPaginator(true);
/*     */       
/*     */ 
/*  94 */       dataTable.setPaginatorTemplate("{CurrentPageReport} {FirstPageLink} {PreviousPageLink} {PageLinks} {NextPageLink} {LastPageLink} {RowsPerPageDropdown}");
/*     */       
/*     */ 
/*  97 */       if (dataTable.getRows() == 0)
/*     */       {
/*  99 */         dataTable.setRows(20);
/*     */       }
/*     */       else {
/* 102 */         dataTable.setRows(dataTable.getRows());
/*     */       }
/*     */       
/*     */ 
/* 106 */       String selectRows = dataTable.getSelectRows();
/*     */       
/* 108 */       if (!FwStringValidator.isEmpty(selectRows))
/*     */       {
/* 110 */         dataTable.setRowsPerPageTemplate(selectRows);
/*     */       }
/*     */       else {
/* 113 */         dataTable.setRowsPerPageTemplate("10, 20, 30");
/*     */       }
/*     */       
/*     */ 
/* 117 */       dataTable.setPageLinks(5);
/*     */       
/*     */ 
/* 120 */       dataTable.setPaginatorPosition("top");
/*     */       
/*     */ 
/* 123 */       if (FwStringValidator.isEmpty(dataTable.getPageReport()))
/*     */       {
/* 125 */         dataTable.setCurrentPageReportTemplate("{totalRecords}件中 {startRecord}件 ～ {endRecord}件");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 132 */     dataTable.setRowSelectMode("add");
/*     */     
/* 134 */     if (!dataTable.isSelectionEnabled()) {
/* 135 */       dataTable.setSelection(new Object());
/*     */     }
/*     */     
/* 138 */     super.encodeEnd(context, dataTable);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void encodeMarkup(FacesContext context, DataTable table)
/*     */     throws IOException
/*     */   {
/* 151 */     CfwGrid component = (CfwGrid)table;
/* 152 */     CfwComponentUtils utils = CfwComponentUtils.getInstance();
/*     */     
/*     */ 
/* 155 */     if (!FwStringValidator.isEmpty(component.getWidth())) {
/* 156 */       component.setStyle(utils.addStyle(component.getStyle(), "width", utils.toWidth(component.getWidth())));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 161 */     component.setStyle(utils.addStyle(component.getStyle(), "display", "inline-block"));
/* 162 */     component.setStyle(utils.addStyle(component.getStyle(), "line-height", "normal"));
/*     */     
/*     */ 
/* 165 */     String margin = utils.createMarginStyle(component.getTop(), component.getRight(), component.getBottom(), component.getLeft());
/*     */     
/* 167 */     if (!FwStringValidator.isEmpty(component.getStyle())) {
/* 168 */       component.setStyle(utils.addStyle(component.getStyle(), margin));
/*     */     } else {
/* 170 */       component.setStyle(margin);
/*     */     }
/*     */     
/* 173 */     if (component.isSelectionEnabled()) {
/* 174 */       DataModel<?> model = component.getDataModel();
/*     */       
/*     */ 
/* 177 */       ValueExpression ve = (ValueExpression)component.getLazyRowKey();
/*     */       
/*     */ 
/* 180 */       if (ve == null)
/*     */       {
/* 182 */         ve = component.getValueExpression("rowKey");
/*     */       }
/*     */       
/*     */ 
/* 186 */       String rowKeyName = component.resolveStaticField(ve);
/*     */       
/* 188 */       if (rowKeyName != null) {
/* 189 */         StringJoiner sj = new StringJoiner(",");
/*     */         
/*     */ 
/* 192 */         Collection<?> collection = (Collection)model.getWrappedData();
/*     */         
/* 194 */         Iterator<?> ite = collection.iterator();
/* 195 */         while (ite.hasNext()) {
/* 196 */           Object row = ite.next();
/*     */           try {
/* 198 */             Object rowKey = PropertyUtils.getProperty(row, rowKeyName);
/* 199 */             if (rowKey != null) {
/* 200 */               sj.add(rowKey.toString());
/*     */             }
/*     */           }
/*     */           catch (Exception e) {}
/*     */         }
/*     */         
/*     */ 
/* 207 */         encodeStateHolder(context, table, table.getClientId(context) + "_selection_cfw", sj.toString());
/*     */       }
/*     */     }
/* 210 */     super.encodeMarkup(context, component);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void encodeTbody(FacesContext context, DataTable table, boolean dataOnly, int columnStart, int columnEnd, String tbodyId)
/*     */     throws IOException
/*     */   {
/* 228 */     ResponseWriter writer = context.getResponseWriter();
/*     */     
/* 230 */     CfwGrid cfwDataTable = (CfwGrid)table;
/*     */     
/* 232 */     String clientId = cfwDataTable.getClientId(context);
/*     */     
/* 234 */     SubTable subTable = cfwDataTable.getSubTable();
/* 235 */     String tbodyClientId = tbodyId == null ? clientId + "_data" : tbodyId;
/*     */     
/* 237 */     if (cfwDataTable.isSelectionEnabled()) {
/* 238 */       cfwDataTable.findSelectedRowKeys();
/*     */     }
/*     */     
/*     */ 
/* 242 */     int rows = cfwDataTable.getRows();
/* 243 */     int first = cfwDataTable.getFirst();
/* 244 */     int rowCount = cfwDataTable.getRowCount();
/*     */     
/* 246 */     int rowCountToRender = rows == 0 ? rowCount : cfwDataTable.isLiveScroll() ? cfwDataTable.getScrollRows() + cfwDataTable.getScrollOffset() : rows;
/* 247 */     int frozenRows = cfwDataTable.getFrozenRows();
/*     */     
/* 249 */     boolean hasData = rowCount > 0;
/* 250 */     if ((first == 0) && (frozenRows > 0)) {
/* 251 */       first += frozenRows;
/*     */     }
/*     */     
/* 254 */     if (!dataOnly) {
/* 255 */       writer.startElement("tbody", null);
/* 256 */       writer.writeAttribute("id", tbodyClientId, null);
/* 257 */       writer.writeAttribute("class", "ui-datatable-data ui-widget-content", null);
/*     */     }
/*     */     
/* 260 */     if (hasData) {
/* 261 */       if (subTable != null) {
/* 262 */         encodeSubTable(context, cfwDataTable, subTable, first, first + rowCountToRender);
/*     */       }
/*     */       else {
/* 265 */         encodeRows(context, cfwDataTable, first, first + rowCountToRender, columnStart, columnEnd);
/*     */       }
/*     */     }
/*     */     
/* 269 */     if (!dataOnly) {
/* 270 */       writer.endElement("tbody");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 275 */     table.setRowIndex(-1);
/* 276 */     String rowIndexVar = cfwDataTable.getRowIndexVar();
/* 277 */     if (rowIndexVar != null) {
/* 278 */       context.getExternalContext().getRequestMap().remove(rowIndexVar);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void encodeColumnHeader(FacesContext context, DataTable table, UIColumn column)
/*     */     throws IOException
/*     */   {
/* 293 */     if (!column.isRendered()) {
/* 294 */       return;
/*     */     }
/*     */     
/* 297 */     ValueExpression columnSortByVE = column.getValueExpression("sortBy");
/*     */     
/*     */ 
/* 300 */     boolean sortable = (columnSortByVE != null) && (column.isSortable());
/*     */     
/*     */ 
/* 303 */     boolean filterable = (column.getValueExpression("filterBy") != null) && (column.isFilterable());
/*     */     
/* 305 */     String selectionMode = column.getSelectionMode();
/* 306 */     String sortIcon = null;
/*     */     
/* 308 */     boolean resizable = (table.isResizableColumns()) && (column.isResizable());
/*     */     
/* 310 */     String columnClass = sortable ? "ui-state-default ui-sortable-column" : "ui-state-default";
/*     */     
/*     */ 
/* 313 */     columnClass = filterable ? columnClass + " " + "ui-filter-column" : columnClass;
/* 314 */     columnClass = selectionMode != null ? columnClass + " " + "ui-selection-column" : columnClass;
/* 315 */     columnClass = resizable ? columnClass + " " + "ui-resizable-column" : columnClass;
/* 316 */     columnClass = !column.isToggleable() ? columnClass + " " + "ui-static-column" : columnClass;
/*     */     
/* 318 */     columnClass = !column.isVisible() ? columnClass + " " + "ui-helper-hidden" : columnClass;
/*     */     
/* 320 */     columnClass = column.getStyleClass() != null ? columnClass + " " + column.getStyleClass() : columnClass;
/*     */     
/*     */ 
/* 323 */     int priority = column.getPriority();
/*     */     
/* 325 */     if (priority > 0) {
/* 326 */       columnClass = columnClass + " ui-column-p-" + priority;
/*     */     }
/*     */     
/* 329 */     if (sortable) {
/* 330 */       ValueExpression tableSortByVE = table.getValueExpression("sortBy");
/* 331 */       Object tableSortBy = table.getSortBy();
/* 332 */       boolean defaultSorted = (tableSortByVE != null) || (tableSortBy != null);
/*     */       
/* 334 */       if (defaultSorted) {
/* 335 */         if (table.isMultiSort()) {
/* 336 */           List<SortMeta> sortMeta = table.getMultiSortMeta();
/*     */           
/* 338 */           if (sortMeta != null) {
/* 339 */             for (SortMeta meta : sortMeta) {
/* 340 */               sortIcon = resolveDefaultSortIcon(column, meta);
/*     */               
/* 342 */               if (sortIcon != null) {
/*     */                 break;
/*     */               }
/*     */               
/*     */             }
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 351 */           sortIcon = resolveDefaultSortIcon(table, column, table.getSortOrder());
/*     */         }
/*     */       }
/*     */       
/* 355 */       if (sortIcon == null) {
/* 356 */         sortIcon = "ui-sortable-column-icon ui-icon ui-icon-carat-2-n-s";
/*     */       } else {
/* 358 */         columnClass = columnClass + " ui-state-active";
/*     */       }
/*     */     }
/*     */     
/* 362 */     CfwColumn cfwColumn = (CfwColumn)column;
/* 363 */     String style = cfwColumn.getStyle();
/* 364 */     String width = cfwColumn.getWidth();
/*     */     
/* 366 */     if (!FwStringValidator.isEmpty(width)) {
/* 367 */       CfwComponentUtils utils = CfwComponentUtils.getInstance();
/*     */       
/*     */ 
/* 370 */       width = utils.toWidth(width, -20);
/*     */       
/* 372 */       if (style != null) {
/* 373 */         style = style + ";width:" + width;
/*     */       } else {
/* 375 */         style = "width:" + width;
/*     */       }
/*     */     }
/*     */     
/* 379 */     String clientId = column.getContainerClientId(context);
/*     */     
/* 381 */     ResponseWriter writer = context.getResponseWriter();
/* 382 */     writer.startElement("th", null);
/* 383 */     writer.writeAttribute("id", clientId, null);
/* 384 */     writer.writeAttribute("class", columnClass, null);
/* 385 */     writer.writeAttribute("role", "columnheader", null);
/*     */     
/* 387 */     if (style != null) {
/* 388 */       writer.writeAttribute("style", style, null);
/*     */     }
/*     */     
/* 391 */     if (column.getRowspan() != 1) {
/* 392 */       writer.writeAttribute("rowspan", Integer.valueOf(column.getRowspan()), null);
/*     */     }
/*     */     
/*     */ 
/* 396 */     if (column.getColspan() != 1) {
/* 397 */       writer.writeAttribute("colspan", Integer.valueOf(column.getColspan()), null);
/*     */     }
/*     */     
/*     */ 
/* 401 */     if (filterable) {
/* 402 */       table.enableFiltering();
/*     */       
/* 404 */       String filterPosition = column.getFilterPosition();
/*     */       
/* 406 */       if ("bottom".equals(filterPosition)) {
/* 407 */         encodeColumnHeaderContent(context, column, sortIcon);
/*     */       }
/* 409 */       else if ("top".equals(filterPosition)) {
/* 410 */         encodeFilter(context, table, column);
/* 411 */         encodeColumnHeaderContent(context, column, sortIcon);
/*     */       }
/*     */       else {
/* 414 */         throw new FacesException(filterPosition + " is an invalid option for filterPosition, valid values are 'bottom' or 'top'.");
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 419 */       encodeColumnHeaderContent(context, column, sortIcon);
/*     */     }
/*     */     
/* 422 */     if ((selectionMode != null) && (selectionMode.equalsIgnoreCase("multiple"))) {
/* 423 */       encodeCheckbox(context, table, false, false, "ui-chkbox ui-chkbox-all ui-widget");
/*     */     }
/*     */     
/*     */ 
/* 427 */     writer.endElement("th");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean encodeRow(FacesContext context, DataTable table, String clientId, int rowIndex, int columnStart, int columnEnd)
/*     */     throws IOException
/*     */   {
/* 445 */     CfwGrid cfwDatatable = (CfwGrid)table;
/* 446 */     boolean selectionEnabled = cfwDatatable.isSelectionEnabled();
/*     */     
/* 448 */     Object rowKey = null;
/* 449 */     List<UIColumn> columns = table.getColumns();
/*     */     
/* 451 */     if (selectionEnabled)
/*     */     {
/* 453 */       rowKey = table.getRowKey();
/*     */       
/*     */ 
/* 456 */       if (rowKey == null) {
/* 457 */         rowKey = table.getRowKeyFromModel(table.getRowData());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 464 */     boolean selected = cfwDatatable.getSelectedRowKeys().contains(rowKey);
/*     */     
/* 466 */     String rowStyleClass = rowIndex % 2 == 0 ? "ui-widget-content ui-datatable-even" : "ui-widget-content ui-datatable-odd";
/*     */     
/*     */ 
/* 469 */     if ((selectionEnabled) && (!table.isDisabledSelection())) {
/* 470 */       rowStyleClass = rowStyleClass + " " + "ui-datatable-selectable";
/*     */     }
/*     */     
/*     */ 
/* 474 */     if (selected) {
/* 475 */       rowStyleClass = rowStyleClass + " ui-state-highlight";
/*     */     }
/*     */     
/*     */ 
/* 479 */     if (table.isEditingRow()) {
/* 480 */       rowStyleClass = rowStyleClass + " " + "ui-row-editing";
/*     */     }
/*     */     
/*     */ 
/* 484 */     String userRowStyleClass = table.getRowStyleClass();
/* 485 */     if (userRowStyleClass != null) {
/* 486 */       rowStyleClass = rowStyleClass + " " + userRowStyleClass;
/*     */     }
/*     */     
/*     */ 
/* 490 */     for (int i = columnStart; i < columnEnd; i++) {
/* 491 */       UIColumn column = (UIColumn)columns.get(i);
/*     */       
/* 493 */       if ((column instanceof Column)) {
/* 494 */         if (column.isRendered()) {
/* 495 */           encodeCell(context, table, column, clientId, selected, i, rowIndex, rowKey, rowStyleClass, columnStart, columnEnd);
/*     */         }
/*     */       }
/* 498 */       else if ((column instanceof DynamicColumn)) {
/* 499 */         DynamicColumn dynamicColumn = (DynamicColumn)column;
/* 500 */         dynamicColumn.applyModel();
/*     */         
/* 502 */         encodeCell(context, table, dynamicColumn, null, false);
/*     */       }
/*     */     }
/*     */     
/* 506 */     if (table.isExpandedRow())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 511 */       ((RowExpandFeature)table.getFeature(DataTableFeatureKey.ROW_EXPAND)).encodeExpansion(context, this, table, rowIndex);
/*     */     }
/*     */     
/*     */ 
/* 515 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void encodeCell(FacesContext context, DataTable table, UIColumn column, String clientId, boolean selected, int columnIndex, int rowIndex, Object rowKey, String rowStyleClass, int columnStart, int columnEnd)
/*     */     throws IOException
/*     */   {
/* 537 */     if (!column.isRendered()) {
/* 538 */       return;
/*     */     }
/*     */     
/* 541 */     ResponseWriter writer = context.getResponseWriter();
/* 542 */     boolean selectionEnabled = column.getSelectionMode() != null;
/*     */     
/*     */ 
/* 545 */     String styleClass = column.getCellEditor() != null ? "ui-editable-column" : selectionEnabled ? "ui-selection-column" : null;
/*     */     
/*     */ 
/* 548 */     styleClass = styleClass + " " + "ui-column-unselectable";
/*     */     
/*     */ 
/* 551 */     styleClass = styleClass + " " + "ui-helper-hidden";
/*     */     
/*     */ 
/* 554 */     String userStyleClass = column.getStyleClass();
/*     */     
/* 556 */     styleClass = styleClass + " " + userStyleClass;
/*     */     
/*     */ 
/* 559 */     int priority = column.getPriority();
/*     */     
/*     */ 
/* 562 */     if (priority > 0) {
/* 563 */       styleClass = styleClass + " ui-column-p-" + priority;
/*     */     }
/*     */     
/* 566 */     CfwGrid cfwDartaTable = (CfwGrid)table;
/* 567 */     List<Integer> switchIndexList = cfwDartaTable.getSwitchIndexList();
/*     */     
/*     */ 
/* 570 */     int frozenColumns = cfwDartaTable.getFrozenColumns();
/*     */     
/*     */ 
/* 573 */     boolean hasFrozenColumns = frozenColumns > 0;
/*     */     
/*     */ 
/*     */ 
/* 577 */     if (((hasFrozenColumns == true) && (columnIndex == columnStart)) || ((!hasFrozenColumns) && 
/* 578 */       (switchIndexList.contains(Integer.valueOf(columnIndex)))))
/*     */     {
/* 580 */       writer.startElement("tr", null);
/* 581 */       writer.writeAttribute("data-ri", Integer.valueOf(rowIndex), null);
/*     */       
/* 583 */       if (rowKey != null) {
/* 584 */         writer.writeAttribute("data-rk", rowKey, null);
/*     */       }
/*     */       
/*     */ 
/* 588 */       rowStyleClass = rowStyleClass + " cfwDataTable" + rowIndex;
/* 589 */       writer.writeAttribute("class", rowStyleClass, null);
/* 590 */       writer.writeAttribute("role", "row", null);
/*     */       
/* 592 */       if (selectionEnabled) {
/* 593 */         writer.writeAttribute("aria-selected", String.valueOf(selected), null);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 598 */     CfwColumn cfwColumn = (CfwColumn)column;
/*     */     
/* 600 */     writer.startElement("td", null);
/*     */     
/* 602 */     writer.writeAttribute("role", "gridcell", null);
/* 603 */     String style = column.getStyle();
/*     */     
/* 605 */     int colspan = column.getColspan();
/* 606 */     int rowspan = column.getRowspan();
/*     */     
/* 608 */     String align = cfwColumn.getAlign();
/*     */     
/* 610 */     if (!FwStringValidator.isEmpty(align)) {
/* 611 */       CfwComponentUtils utils = CfwComponentUtils.getInstance();
/* 612 */       style = utils.addStyle(style, "text-align", align);
/*     */     }
/*     */     
/* 615 */     if (colspan != 1) {
/* 616 */       writer.writeAttribute("colspan", Integer.valueOf(colspan), null);
/*     */     }
/*     */     
/* 619 */     if (rowspan != 1) {
/* 620 */       writer.writeAttribute("rowspan", Integer.valueOf(rowspan), null);
/*     */     }
/*     */     
/* 623 */     if (style != null) {
/* 624 */       writer.writeAttribute("style", style, null);
/*     */     }
/*     */     
/* 627 */     if (styleClass != null) {
/* 628 */       writer.writeAttribute("class", styleClass, null);
/*     */     }
/*     */     
/* 631 */     if (selectionEnabled) {
/* 632 */       encodeColumnSelection(context, table, clientId, column, selected);
/*     */     }
/*     */     
/* 635 */     column.renderChildren(context);
/*     */     
/* 637 */     writer.endElement("td");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void encodeScrollableTable(FacesContext context, DataTable table)
/*     */     throws IOException
/*     */   {
/* 649 */     String tableStyle = table.getTableStyle();
/*     */     
/*     */ 
/* 652 */     CfwGrid cfwDataTable = (CfwGrid)table;
/*     */     
/*     */ 
/* 655 */     CfwComponentUtils utils = CfwComponentUtils.getInstance();
/*     */     
/* 657 */     String tableStyleClass = table.getTableStyleClass();
/* 658 */     int frozenColumns = table.getFrozenColumns();
/*     */     
/*     */ 
/* 661 */     boolean hasFrozenColumns = frozenColumns != 0;
/*     */     
/* 663 */     ResponseWriter writer = context.getResponseWriter();
/* 664 */     String clientId = table.getClientId(context);
/* 665 */     int columnsCount = table.getColumns().size();
/*     */     
/* 667 */     if (hasFrozenColumns) {
/* 668 */       writer.startElement("table", null);
/* 669 */       writer.startElement("tbody", null);
/* 670 */       writer.startElement("tr", null);
/*     */       
/*     */ 
/* 673 */       writer.startElement("td", null);
/*     */       
/* 675 */       writer.writeAttribute("class", "ui-datatable-frozenlayout-left", null);
/*     */       
/*     */ 
/* 678 */       writer.writeAttribute("style", "width:" + utils.toWidth(cfwDataTable.getFrozenColumnWidth()), null);
/* 679 */       writer.startElement("div", null);
/* 680 */       writer.writeAttribute("class", "ui-datatable-frozen-container", null);
/*     */       
/* 682 */       encodeScrollAreaStart(context, table, "ui-widget-header ui-datatable-scrollable-header", "ui-datatable-scrollable-header-box", tableStyle, tableStyleClass);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 687 */       encodeThead(context, table, 0, frozenColumns, clientId + "_frozenThead", "frozenHeader");
/* 688 */       encodeScrollAreaEnd(context);
/*     */       
/* 690 */       encodeScrollBody(context, table, tableStyle, tableStyleClass, 0, frozenColumns, clientId + "_frozenTbody");
/*     */       
/* 692 */       encodeScrollAreaStart(context, table, "ui-widget-header ui-datatable-scrollable-footer", "ui-datatable-scrollable-footer-box", tableStyle, tableStyleClass);
/*     */       
/*     */ 
/*     */ 
/* 696 */       encodeTFoot(context, table, 0, frozenColumns, "frozenFooter");
/* 697 */       encodeScrollAreaEnd(context);
/*     */       
/* 699 */       writer.endElement("div");
/* 700 */       writer.endElement("td");
/*     */       
/*     */ 
/* 703 */       writer.startElement("td", null);
/* 704 */       writer.writeAttribute("class", "ui-datatable-frozenlayout-right", null);
/* 705 */       writer.startElement("div", null);
/* 706 */       writer.writeAttribute("class", "ui-datatable-scrollable-container", null);
/*     */       
/* 708 */       encodeScrollAreaStart(context, table, "ui-widget-header ui-datatable-scrollable-header", "ui-datatable-scrollable-header-box", tableStyle, tableStyleClass);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 713 */       encodeThead(context, table, frozenColumns, table.getColumnsCount(), clientId + "_scrollableThead", "scrollableHeader");
/* 714 */       encodeScrollAreaEnd(context);
/*     */       
/* 716 */       encodeScrollBody(context, table, tableStyle, tableStyleClass, frozenColumns, columnsCount, clientId + "_scrollableTbody");
/*     */       
/* 718 */       encodeScrollAreaStart(context, table, "ui-widget-header ui-datatable-scrollable-footer", "ui-datatable-scrollable-footer-box", tableStyle, tableStyleClass);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 723 */       encodeTFoot(context, table, frozenColumns, columnsCount, "scrollableFooter");
/* 724 */       encodeScrollAreaEnd(context);
/*     */       
/* 726 */       writer.endElement("div");
/* 727 */       writer.endElement("td");
/*     */       
/* 729 */       writer.endElement("tr");
/* 730 */       writer.endElement("tbody");
/* 731 */       writer.endElement("table");
/*     */     }
/*     */     else {
/* 734 */       encodeScrollAreaStart(context, table, "ui-widget-header ui-datatable-scrollable-header", "ui-datatable-scrollable-header-box", tableStyle, tableStyleClass);
/*     */       
/* 736 */       encodeThead(context, table);
/* 737 */       encodeScrollAreaEnd(context);
/*     */       
/* 739 */       encodeScrollBody(context, table, tableStyle, tableStyleClass, 0, columnsCount, null);
/*     */       
/* 741 */       encodeScrollAreaStart(context, table, "ui-widget-header ui-datatable-scrollable-footer", "ui-datatable-scrollable-footer-box", tableStyle, tableStyleClass);
/*     */       
/*     */ 
/* 744 */       encodeTFoot(context, table);
/* 745 */       encodeScrollAreaEnd(context);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void encodeScrollBody(FacesContext context, DataTable table, String tableStyle, String tableStyleClass, int columnStart, int columnEnd, String tbodyId)
/*     */     throws IOException
/*     */   {
/* 766 */     ResponseWriter writer = context.getResponseWriter();
/* 767 */     columnEnd = table.getColumnsCount();
/*     */     
/* 769 */     writer.startElement("div", null);
/* 770 */     writer.writeAttribute("class", "ui-datatable-scrollable-body", null);
/*     */     
/*     */ 
/* 773 */     writer.writeAttribute("tabindex", "-1", null);
/*     */     
/* 775 */     String scrollHeight = table.getScrollHeight();
/*     */     
/*     */ 
/* 778 */     CfwComponentUtils utils = CfwComponentUtils.getInstance();
/*     */     
/*     */ 
/* 781 */     if ((scrollHeight != null) && (scrollHeight.indexOf("%") == -1)) {
/* 782 */       if ((!FwStringValidator.isEmpty(tbodyId)) && 
/* 783 */         (tbodyId.contains("_frozenTbody"))) {
/* 784 */         writer.writeAttribute("style", "height:" + utils.toHeight(scrollHeight, -17), null);
/*     */       }
/*     */       
/* 787 */       writer.writeAttribute("style", "height:" + utils.toHeight(scrollHeight), null);
/*     */     }
/*     */     
/* 790 */     writer.startElement("table", null);
/* 791 */     writer.writeAttribute("role", "grid", null);
/*     */     
/* 793 */     if (tableStyle != null) {
/* 794 */       writer.writeAttribute("style", tableStyle, null);
/*     */     }
/*     */     
/* 797 */     if (table.getTableStyleClass() != null) {
/* 798 */       writer.writeAttribute("class", tableStyleClass, null);
/*     */     }
/*     */     
/*     */ 
/* 802 */     if (!FwStringValidator.isEmpty(tbodyId)) {
/* 803 */       List<UIColumn> columns = table.getColumns();
/* 804 */       int columnStartIndex = 0;
/* 805 */       int columnEndIndex = 0;
/* 806 */       if (tbodyId.contains("frozen"))
/*     */       {
/* 808 */         for (UIColumn column : columns) {
/* 809 */           if ((column.isRendered() == true) && (columnStartIndex <= table.getFrozenColumns())) {
/*     */             break;
/*     */           }
/* 812 */           columnStartIndex++;
/*     */         }
/* 814 */         for (UIColumn column : columns) {
/* 815 */           if ((column.isRendered() == true) && (columnEndIndex < table.getFrozenColumns())) {
/* 816 */             columnEndIndex++;
/*     */           }
/*     */         }
/*     */         
/* 820 */         encodeTbody(context, table, false, columnStartIndex, columnEndIndex, tbodyId);
/*     */       } else {
/* 822 */         for (UIColumn column : columns) {
/* 823 */           if ((column.isRendered() == true) && (columnStartIndex >= table.getFrozenColumns()) && (columnStartIndex <= columnEnd)) {
/*     */             break;
/*     */           }
/* 826 */           columnStartIndex++;
/*     */         }
/* 828 */         for (UIColumn column : columns) {
/* 829 */           if (column.isRendered() == true) {
/* 830 */             columnEndIndex++;
/*     */           }
/*     */         }
/* 833 */         encodeTbody(context, table, false, columnStartIndex, columnEndIndex, tbodyId);
/*     */       }
/*     */     }
/*     */     else {
/* 837 */       encodeTbody(context, table, false, columnStart, columnEnd, tbodyId);
/*     */     }
/*     */     
/* 840 */     writer.endElement("table");
/* 841 */     writer.endElement("div");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void encodeColumnHeaderContent(FacesContext context, UIColumn column, String sortIcon)
/*     */     throws IOException
/*     */   {
/* 853 */     ResponseWriter writer = context.getResponseWriter();
/*     */     
/* 855 */     CfwColumn cfwColumn = (CfwColumn)column;
/* 856 */     super.encodeColumnHeaderContent(context, cfwColumn, sortIcon);
/* 857 */     if ((cfwColumn.isRequired() != null) && (cfwColumn.isRequired().booleanValue())) {
/* 858 */       writer.startElement("span", null);
/* 859 */       writer.writeAttribute("class", "ui-column-title", null);
/* 860 */       writer.writeAttribute("style", "color:red;", null);
/* 861 */       writer.write(" *");
/* 862 */       writer.endElement("span");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void encodeTbody(FacesContext context, DataTable table, boolean dataOnly)
/*     */     throws IOException
/*     */   {
/* 876 */     CfwGrid cfwDartaTable = (CfwGrid)table;
/*     */     
/* 878 */     int frozenColumns = cfwDartaTable.getFrozenColumns();
/*     */     
/* 880 */     boolean hasFrozenColumns = frozenColumns > 0;
/* 881 */     if (hasFrozenColumns) {
/* 882 */       List<UIColumn> columns = table.getColumns();
/* 883 */       int columnStartIndex = 0;
/*     */       
/* 885 */       for (UIColumn column : columns) {
/* 886 */         if ((column.isRendered() == true) && (columnStartIndex <= table.getFrozenColumns())) {
/*     */           break;
/*     */         }
/* 889 */         columnStartIndex++;
/*     */       }
/* 891 */       encodeTbody(context, table, dataOnly, columnStartIndex, table.getColumnsCount(), null);
/*     */     }
/*     */     else {
/* 894 */       encodeTbody(context, table, dataOnly, 0, table.getColumnsCount(), null);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwGridRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */