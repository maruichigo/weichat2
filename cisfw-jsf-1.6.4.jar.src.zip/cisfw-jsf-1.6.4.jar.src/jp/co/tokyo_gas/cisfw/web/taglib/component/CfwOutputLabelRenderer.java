/*     */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ import javax.el.ValueExpression;
/*     */ import javax.enterprise.inject.Instance;
/*     */ import javax.enterprise.inject.spi.CDI;
/*     */ import javax.faces.component.UIComponent;
/*     */ import javax.faces.component.UIInput;
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.faces.context.ResponseWriter;
/*     */ import javax.faces.render.FacesRenderer;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.string.FwStringValidator;
/*     */ import jp.co.tokyo_gas.cisfw.constantmaster.CfwConstantMasterCache;
/*     */ import jp.co.tokyo_gas.cisfw.exception.CfwRuntimeException;
/*     */ import jp.co.tokyo_gas.cisfw.utils.CfwStringConverter;
/*     */ import jp.co.tokyo_gas.cisfw.utils.CfwStringValidator;
/*     */ import jp.co.tokyo_gas.cisfw.web.cache.CfwCache;
/*     */ import jp.co.tokyo_gas.cisfw.web.taglib.converter.CfwRegexConverter;
/*     */ import org.apache.commons.lang3.BooleanUtils;
/*     */ import org.primefaces.component.api.InputHolder;
/*     */ import org.primefaces.component.outputlabel.OutputLabelRenderer;
/*     */ import org.primefaces.expression.SearchExpressionFacade;
/*     */ import org.primefaces.util.ComponentUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FacesRenderer(componentFamily="jp.co.tokyo_gas.cisfw", rendererType="jp.co.tokyo_gas.cisfw.web.taglib.component.CfwOutputLabelRenderer")
/*     */ public class CfwOutputLabelRenderer
/*     */   extends OutputLabelRenderer
/*     */ {
/*     */   protected static enum Months
/*     */   {
/*  57 */     Jan("01"),  Feb("02"),  Mar("03"),  Apr("04"),  May("05"),  Jun("06"),  Jul("07"),  Aug("08"),  Sep("09"),  Oct("10"),  Nov("11"),  Dec("12");
/*     */     
/*     */ 
/*     */ 
/*     */     private String value;
/*     */     
/*     */ 
/*     */ 
/*     */     private Months(String n)
/*     */     {
/*  67 */       this.value = n;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getValue()
/*     */     {
/*  76 */       return this.value;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void encodeEnd(FacesContext context, UIComponent component)
/*     */     throws IOException
/*     */   {
/*  90 */     ResponseWriter writer = context.getResponseWriter();
/*  91 */     CfwOutputLabel label = (CfwOutputLabel)component;
/*     */     
/*     */ 
/*  94 */     if (("Regex".equals(label.getType())) && (!CfwStringValidator.isEmpty(label.getPatternKey()))) {
/*  95 */       CfwRegexConverter conv = new CfwRegexConverter();
/*  96 */       label.setConverter(conv);
/*     */     }
/*     */     
/*  99 */     String value = ComponentUtils.getValueToRender(context, label);
/* 100 */     UIComponent target = null;
/* 101 */     String targetClientId = null;
/* 102 */     UIInput input = null;
/* 103 */     String styleClass = label.getStyleClass();
/* 104 */     styleClass = "ui-outputlabel ui-widget " + styleClass;
/* 105 */     String clientId = label.getClientId();
/* 106 */     String targetFor = label.getFor();
/*     */     
/* 108 */     if (null == label.isShortName()) {
/* 109 */       label.setShortName(Boolean.valueOf(false));
/*     */     }
/*     */     
/* 112 */     if (targetFor != null) {
/* 113 */       target = SearchExpressionFacade.resolveComponent(context, label, targetFor);
/* 114 */       targetClientId = (target instanceof InputHolder) ? ((InputHolder)target).getInputClientId() : target.getClientId(context);
/*     */       
/* 116 */       if ((target instanceof UIInput)) {
/* 117 */         input = (UIInput)target;
/*     */         
/* 119 */         if ((value != null) && ((input.getAttributes().get("label") == null) || (input.getValueExpression("label") == null))) {
/* 120 */           ValueExpression ve = label.getValueExpression("value");
/*     */           
/* 122 */           if (ve != null) {
/* 123 */             input.setValueExpression("label", ve);
/*     */           } else {
/* 125 */             String labelString = value;
/* 126 */             int colonPos = labelString.lastIndexOf(":");
/*     */             
/* 128 */             if (colonPos != -1) {
/* 129 */               labelString = labelString.substring(0, colonPos);
/*     */             }
/*     */             
/* 132 */             input.getAttributes().put("label", labelString);
/*     */           }
/*     */         }
/*     */         
/* 136 */         if (!input.isValid()) {
/* 137 */           styleClass = styleClass + " ui-state-error";
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 142 */     writer.startElement("label", label);
/* 143 */     writer.writeAttribute("id", clientId, "id");
/* 144 */     writer.writeAttribute("class", styleClass, "id");
/*     */     
/* 146 */     if (target != null) {
/* 147 */       writer.writeAttribute("for", targetClientId, "for");
/*     */     }
/*     */     
/*     */ 
/* 151 */     CfwComponentUtils utils = CfwComponentUtils.getInstance();
/*     */     
/*     */ 
/* 154 */     label.setStyle(utils.addStyle(label.getStyle(), "display", "inline-block"));
/*     */     
/*     */ 
/* 157 */     if (!FwStringValidator.isEmpty(label.getWidth())) {
/* 158 */       String width = utils.toWidth(label.getWidth());
/* 159 */       label.setStyle(utils.addStyle(label.getStyle(), "width", width));
/*     */     }
/*     */     
/*     */ 
/* 163 */     if (!FwStringValidator.isEmpty(label.getHeight())) {
/* 164 */       String height = utils.toHeight(label.getHeight());
/* 165 */       label.setStyle(utils.addStyle(label.getStyle(), "line-height", height));
/*     */     }
/*     */     
/*     */ 
/* 169 */     if (!FwStringValidator.isEmpty(label.getAlign())) {
/* 170 */       String align = label.getAlign();
/* 171 */       label.setStyle(utils.addStyle(label.getStyle(), "text-align", align));
/*     */     }
/*     */     
/*     */ 
/* 175 */     if (!FwStringValidator.isEmpty(label.getBgcolor())) {
/* 176 */       String backGroundColor = label.getBgcolor();
/* 177 */       label.setStyle(utils.addStyle(label.getStyle(), "background-Color", backGroundColor));
/*     */     }
/*     */     
/*     */ 
/* 181 */     if (!FwStringValidator.isEmpty(label.getColor())) {
/* 182 */       String color = label.getColor();
/* 183 */       label.setStyle(utils.addStyle(label.getStyle(), "color", color));
/*     */     }
/*     */     
/*     */ 
/* 187 */     String margin = utils.createMarginStyle(label.getTop(), label.getRight(), label.getBottom(), label.getLeft());
/* 188 */     if (!FwStringValidator.isEmpty(label.getStyle())) {
/* 189 */       label.setStyle(utils.addStyle(label.getStyle(), margin));
/*     */     } else {
/* 191 */       label.setStyle(margin);
/*     */     }
/*     */     
/*     */ 
/* 195 */     writer.writeAttribute("style", label.getStyle(), null);
/*     */     
/* 197 */     if (value != null)
/*     */     {
/* 199 */       String pattern = label.getPattern();
/*     */       
/* 201 */       if (!FwStringValidator.isEmpty(pattern))
/*     */       {
/* 203 */         String type = label.getType();
/* 204 */         if ("Date".equals(type))
/*     */         {
/* 206 */           String[] dateArray = value.split(" ");
/*     */           
/*     */ 
/* 209 */           String year = dateArray[5];
/*     */           
/*     */ 
/* 212 */           String month = "";
/* 213 */           for (Months m : Months.values()) {
/* 214 */             if (m.name().equals(dateArray[1])) {
/* 215 */               month = m.getValue();
/*     */             }
/*     */           }
/*     */           
/*     */ 
/* 220 */           String date = dateArray[2];
/*     */           
/*     */ 
/* 223 */           SimpleDateFormat sf = new SimpleDateFormat(pattern);
/*     */           try
/*     */           {
/* 226 */             convertDate = toDate(year + "/" + month + "/" + date);
/*     */           } catch (ParseException e) { Date convertDate;
/* 228 */             throw new CfwRuntimeException("日付形式変換に失敗しました。設定した値はDateオブジェクトとして有効ではありません。", new Object[0]); }
/*     */           Date convertDate;
/* 230 */           value = sf.format(convertDate);
/*     */         }
/* 232 */         else if ("Number".equals(type))
/*     */         {
/* 234 */           DecimalFormat df = new DecimalFormat(pattern);
/* 235 */           value = df.format(new Double(value));
/*     */         } else {
/* 237 */           throw new CfwRuntimeException("type属性にはDateまたはNumberを指定してください。", new Object[0]);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 242 */       String prefix = label.getPrefix();
/*     */       
/* 244 */       String suffix = label.getSuffix();
/*     */       
/* 246 */       StringBuilder builder = new StringBuilder();
/*     */       
/*     */ 
/* 249 */       if (!FwStringValidator.isEmpty(prefix)) {
/* 250 */         builder.append(prefix);
/*     */       }
/*     */       
/* 253 */       builder.append(value);
/*     */       
/*     */ 
/* 256 */       if (!FwStringValidator.isEmpty(suffix)) {
/* 257 */         builder.append(suffix);
/*     */       }
/*     */       
/* 260 */       value = builder.toString();
/*     */       
/*     */ 
/*     */ 
/* 264 */       String constType = label.getConstType();
/*     */       
/* 266 */       String cacheKey = label.getCacheKey();
/*     */       
/* 268 */       CfwConstantMasterCache constCache = (CfwConstantMasterCache)CDI.current().select(CfwConstantMasterCache.class, new Annotation[0]).get();
/*     */       
/* 270 */       if (!FwStringValidator.isEmpty(constType))
/*     */       {
/*     */ 
/* 273 */         constType = CfwStringConverter.trimRightSpaces(constType);
/*     */         
/*     */ 
/* 276 */         boolean shortName = label.isShortName().booleanValue();
/*     */         
/*     */ 
/* 279 */         if (shortName) {
/* 280 */           value = constCache.getShortName(constType, value);
/* 281 */           value = FwStringValidator.isEmpty(value) ? "" : value;
/*     */         } else {
/* 283 */           value = constCache.getName(constType, value);
/* 284 */           value = FwStringValidator.isEmpty(value) ? "" : value;
/*     */         }
/*     */       }
/*     */       
/* 288 */       if ((FwStringValidator.isEmpty(constType)) && (!FwStringValidator.isEmpty(cacheKey)))
/*     */       {
/* 290 */         CfwCache cache = (CfwCache)CDI.current().select(CfwCache.class, new Annotation[0]).get();
/*     */         
/* 292 */         value = cache.get(cacheKey, value);
/* 293 */         value = FwStringValidator.isEmpty(value) ? "" : value;
/*     */       }
/*     */       
/* 296 */       if (label.isEscape()) {
/* 297 */         writer.writeText(value, "value");
/*     */       } else {
/* 299 */         writer.write(value);
/*     */       }
/*     */     }
/*     */     
/* 303 */     renderChildren(context, label);
/*     */     
/*     */ 
/* 306 */     if (BooleanUtils.isTrue(label.isRequired())) {
/* 307 */       writer.startElement("span", label);
/* 308 */       writer.writeAttribute("class", "ui-outputlabel-rfi", null);
/* 309 */       writer.writeAttribute("style", "color:red;", null);
/* 310 */       writer.write("*");
/* 311 */       writer.endElement("span");
/*     */     }
/*     */     
/* 314 */     if ((input != null) && (input.isRequired()) && (label.isIndicateRequired())) {
/* 315 */       writer.startElement("span", label);
/* 316 */       writer.writeAttribute("class", "ui-outputlabel-rfi", null);
/* 317 */       writer.write("*");
/* 318 */       writer.endElement("span");
/*     */     }
/*     */     
/* 321 */     writer.endElement("label");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Date toDate(String value, String format)
/*     */     throws ParseException
/*     */   {
/* 333 */     if (FwStringValidator.isNull(value)) {
/* 334 */       return null;
/*     */     }
/*     */     
/* 337 */     if (FwStringValidator.isNull(format)) {
/* 338 */       format = "yyyy/MM/dd";
/*     */     }
/*     */     
/*     */ 
/* 342 */     SimpleDateFormat dateFormat = new SimpleDateFormat(format);
/*     */     
/*     */ 
/* 345 */     dateFormat.setLenient(false);
/*     */     
/*     */ 
/* 348 */     return dateFormat.parse(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Date toDate(String value)
/*     */     throws ParseException
/*     */   {
/* 359 */     return toDate(value, "yyyy/MM/dd");
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwOutputLabelRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */