/*     */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*     */ 
/*     */ import javax.faces.component.FacesComponent;
/*     */ import javax.faces.component.StateHelper;
/*     */ import javax.faces.component.UIComponentBase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FacesComponent("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwLayout")
/*     */ public class CfwLayout
/*     */   extends UIComponentBase
/*     */ {
/*     */   public static final String COMPONENT_TYPE = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwLayout";
/*     */   public static final String COMPONENT_FAMILY = "jp.co.tokyo_gas.cisfw";
/*     */   public static final String DEFAULT_RENDERER = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwLayoutRenderer";
/*     */   
/*     */   public static enum PropertyKeys
/*     */   {
/*  32 */     width, 
/*     */     
/*     */ 
/*  35 */     align;
/*     */     
/*     */     String toString;
/*     */     
/*     */     private PropertyKeys(String toString) {
/*  40 */       this.toString = toString;
/*     */     }
/*     */     
/*     */ 
/*     */     private PropertyKeys() {}
/*     */     
/*     */ 
/*     */     public String toString()
/*     */     {
/*  49 */       return this.toString != null ? this.toString : super.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public CfwLayout()
/*     */   {
/*  57 */     setRendererType("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwLayoutRenderer");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFamily()
/*     */   {
/*  66 */     return "jp.co.tokyo_gas.cisfw";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWidth(String width)
/*     */   {
/*  75 */     getStateHelper().put(PropertyKeys.width, width);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getWidth()
/*     */   {
/*  84 */     return (String)getStateHelper().eval(PropertyKeys.width, "100%");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAlign(String align)
/*     */   {
/*  93 */     getStateHelper().put(PropertyKeys.align, align);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAlign()
/*     */   {
/* 102 */     return (String)getStateHelper().eval(PropertyKeys.align, null);
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */