/*     */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*     */ 
/*     */ import javax.faces.component.FacesComponent;
/*     */ import javax.faces.component.StateHelper;
/*     */ import org.primefaces.component.column.Column;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FacesComponent("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwTd")
/*     */ public class CfwTd
/*     */   extends Column
/*     */ {
/*     */   public static final String COMPONENT_TYPE = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwTd";
/*     */   
/*     */   protected static enum PropertyKeys
/*     */   {
/*  29 */     align, 
/*     */     
/*     */ 
/*  32 */     valign, 
/*     */     
/*     */ 
/*  35 */     height, 
/*     */     
/*     */ 
/*  38 */     bgcolor;
/*     */     
/*     */     String toString;
/*     */     
/*     */     private PropertyKeys(String toString) {
/*  43 */       this.toString = toString;
/*     */     }
/*     */     
/*     */     private PropertyKeys() {}
/*     */     
/*     */     public String toString()
/*     */     {
/*  50 */       return this.toString != null ? this.toString : super.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFamily()
/*     */   {
/*  60 */     return "org.primefaces.component";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHeight()
/*     */   {
/*  68 */     return (String)getStateHelper().eval(PropertyKeys.height, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHeight(String height)
/*     */   {
/*  76 */     getStateHelper().put(PropertyKeys.height, height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBgcolor()
/*     */   {
/*  84 */     return (String)getStateHelper().eval(PropertyKeys.bgcolor, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBgcolor(String bgcolor)
/*     */   {
/*  92 */     getStateHelper().put(PropertyKeys.bgcolor, bgcolor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAlign()
/*     */   {
/* 100 */     return (String)getStateHelper().eval(PropertyKeys.align, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAlign(String align)
/*     */   {
/* 108 */     getStateHelper().put(PropertyKeys.align, align);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getValign()
/*     */   {
/* 116 */     return (String)getStateHelper().eval(PropertyKeys.valign, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValign(String valign)
/*     */   {
/* 124 */     getStateHelper().put(PropertyKeys.valign, valign);
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwTd.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */