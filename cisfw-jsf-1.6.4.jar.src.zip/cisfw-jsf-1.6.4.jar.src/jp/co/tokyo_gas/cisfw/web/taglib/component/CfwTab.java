/*    */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*    */ 
/*    */ import javax.faces.component.FacesComponent;
/*    */ import org.primefaces.component.tabview.Tab;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FacesComponent("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwTab")
/*    */ public class CfwTab
/*    */   extends Tab
/*    */ {
/*    */   public static final String COMPONENT_TYPE = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwTab";
/*    */   public static final String COMPONENT_FAMILY = "jp.co.tokyo_gas.cisfw";
/*    */   
/*    */   public CfwTab()
/*    */   {
/* 28 */     super.setRendererType(null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getFamily()
/*    */   {
/* 37 */     return "jp.co.tokyo_gas.cisfw";
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwTab.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */