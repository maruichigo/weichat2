/*    */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*    */ 
/*    */ import javax.faces.component.FacesComponent;
/*    */ import javax.faces.component.StateHelper;
/*    */ import javax.faces.component.UISelectItem;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FacesComponent("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwUISelectItem")
/*    */ public class CfwUISelectItem
/*    */   extends UISelectItem
/*    */ {
/*    */   public static final String COMPONENT_TYPE = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwUISelectItem";
/*    */   public static final String COMPONENT_FAMILY = "jp.co.tokyo_gas.cisfw";
/*    */   
/*    */   static enum PropertyKeys
/*    */   {
/* 30 */     condition;
/*    */     
/*    */ 
/*    */     private PropertyKeys() {}
/*    */   }
/*    */   
/*    */   public CfwUISelectItem()
/*    */   {
/* 38 */     setRendererType(null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getFamily()
/*    */   {
/* 47 */     return "jp.co.tokyo_gas.cisfw";
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getCondition()
/*    */   {
/* 55 */     return (String)getStateHelper().eval(PropertyKeys.condition, null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setCondition(String condition)
/*    */   {
/* 63 */     getStateHelper().put(PropertyKeys.condition, condition);
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwUISelectItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */