/*    */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*    */ 
/*    */ import java.util.Map;
/*    */ import javax.el.ELContext;
/*    */ import javax.el.ExpressionFactory;
/*    */ import javax.el.MethodExpression;
/*    */ import javax.faces.application.Application;
/*    */ import javax.faces.component.FacesComponent;
/*    */ import javax.faces.component.UINamingContainer;
/*    */ import javax.faces.context.FacesContext;
/*    */ import javax.faces.event.AjaxBehaviorEvent;
/*    */ import jp.co.tokyo_gas.cisfw.exception.CfwRuntimeException;
/*    */ import org.primefaces.event.SelectEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FacesComponent("CfwAjaxEventContainer")
/*    */ public class CfwAjaxEventContainer
/*    */   extends UINamingContainer
/*    */ {
/*    */   static final String CFW_AJAXEVENT = "ajaxEvent";
/*    */   static final String CFW_SELECTEVENT = "callbackListener";
/*    */   
/*    */   public void ajaxEvent(AjaxBehaviorEvent event)
/*    */   {
/* 41 */     FacesContext context = FacesContext.getCurrentInstance();
/* 42 */     ELContext elContext = context.getELContext();
/* 43 */     MethodExpression listener = (MethodExpression)getAttributes().get("ajaxEvent");
/*    */     
/* 45 */     MethodExpression argListener = context.getApplication().getExpressionFactory().createMethodExpression(elContext, listener.getExpressionString(), null, new Class[] { event.getClass() });
/* 46 */     argListener.invoke(elContext, new Object[] { event });
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void callbackListener(SelectEvent event)
/*    */   {
/* 56 */     FacesContext context = FacesContext.getCurrentInstance();
/* 57 */     ELContext elContext = context.getELContext();
/* 58 */     MethodExpression listener = (MethodExpression)getAttributes().get("callbackListener");
/* 59 */     if (listener == null) {
/* 60 */       throw new CfwRuntimeException("callbackListenerが設定されていません。", new Object[0]);
/*    */     }
/*    */     
/* 63 */     MethodExpression argListener = context.getApplication().getExpressionFactory().createMethodExpression(elContext, listener.getExpressionString(), null, new Class[] { event.getClass() });
/* 64 */     argListener.invoke(elContext, new Object[] { event });
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwAjaxEventContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */