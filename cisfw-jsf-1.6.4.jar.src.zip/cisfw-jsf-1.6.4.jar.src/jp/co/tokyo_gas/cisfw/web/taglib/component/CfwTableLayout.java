/*     */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*     */ 
/*     */ import javax.faces.application.ResourceDependencies;
/*     */ import javax.faces.component.FacesComponent;
/*     */ import javax.faces.component.StateHelper;
/*     */ import org.primefaces.component.panelgrid.PanelGrid;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ResourceDependencies({@javax.faces.application.ResourceDependency(library="css", name="template.css")})
/*     */ @FacesComponent("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwTableLayout")
/*     */ public class CfwTableLayout
/*     */   extends PanelGrid
/*     */ {
/*     */   public static final String COMPONENT_TYPE = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwTableLayout";
/*     */   public static final String COMPONENT_FAMILY = "jp.co.tokyo_gas.cisfw";
/*     */   public static final String DEFAULT_RENDERER = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwTableLayoutRenderer";
/*     */   public static final String BORDER_ON = "1";
/*     */   
/*     */   protected static enum PropertyKeys
/*     */   {
/*  37 */     border, 
/*     */     
/*     */ 
/*  40 */     bgcolor, 
/*     */     
/*     */ 
/*  43 */     width, 
/*     */     
/*     */ 
/*  46 */     height, 
/*     */     
/*     */ 
/*  49 */     align, 
/*     */     
/*     */ 
/*  52 */     margin, 
/*     */     
/*     */ 
/*  55 */     padding, 
/*     */     
/*     */ 
/*  58 */     top, 
/*     */     
/*     */ 
/*  61 */     right, 
/*     */     
/*     */ 
/*  64 */     bottom, 
/*     */     
/*     */ 
/*  67 */     left;
/*     */     
/*     */     String toString;
/*     */     
/*     */     private PropertyKeys(String toString) {
/*  72 */       this.toString = toString;
/*     */     }
/*     */     
/*     */     private PropertyKeys() {}
/*     */     
/*     */     public String toString()
/*     */     {
/*  79 */       return this.toString != null ? this.toString : super.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwTableLayout()
/*     */   {
/*  93 */     setRendererType("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwTableLayoutRenderer");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFamily()
/*     */   {
/* 102 */     return "jp.co.tokyo_gas.cisfw";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPadding()
/*     */   {
/* 110 */     return (String)getStateHelper().eval(PropertyKeys.padding, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPadding(String padding)
/*     */   {
/* 118 */     getStateHelper().put(PropertyKeys.padding, padding);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMargin()
/*     */   {
/* 126 */     return (String)getStateHelper().eval(PropertyKeys.margin, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMargin(String margin)
/*     */   {
/* 134 */     getStateHelper().put(PropertyKeys.margin, margin);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAlign()
/*     */   {
/* 142 */     return (String)getStateHelper().eval(PropertyKeys.align, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAlign(String align)
/*     */   {
/* 150 */     getStateHelper().put(PropertyKeys.align, align);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHeight()
/*     */   {
/* 158 */     return (String)getStateHelper().eval(PropertyKeys.height, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHeight(String height)
/*     */   {
/* 166 */     getStateHelper().put(PropertyKeys.height, height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getWidth()
/*     */   {
/* 174 */     return (String)getStateHelper().eval(PropertyKeys.width, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWidth(String width)
/*     */   {
/* 182 */     getStateHelper().put(PropertyKeys.width, width);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBgcolor()
/*     */   {
/* 190 */     return (String)getStateHelper().eval(PropertyKeys.bgcolor, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBgcolor(String bgcolor)
/*     */   {
/* 198 */     getStateHelper().put(PropertyKeys.bgcolor, bgcolor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBorder()
/*     */   {
/* 206 */     return (String)getStateHelper().eval(PropertyKeys.border, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBorder(String border)
/*     */   {
/* 214 */     getStateHelper().put(PropertyKeys.border, border);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTop()
/*     */   {
/* 222 */     return (String)getStateHelper().eval(PropertyKeys.top, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTop(String top)
/*     */   {
/* 230 */     getStateHelper().put(PropertyKeys.top, top);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRight()
/*     */   {
/* 238 */     return (String)getStateHelper().eval(PropertyKeys.right, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRight(String right)
/*     */   {
/* 246 */     getStateHelper().put(PropertyKeys.right, right);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBottom()
/*     */   {
/* 254 */     return (String)getStateHelper().eval(PropertyKeys.bottom, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBottom(String bottom)
/*     */   {
/* 262 */     getStateHelper().put(PropertyKeys.bottom, bottom);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLeft()
/*     */   {
/* 270 */     return (String)getStateHelper().eval(PropertyKeys.left, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLeft(String left)
/*     */   {
/* 278 */     getStateHelper().put(PropertyKeys.left, left);
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwTableLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */