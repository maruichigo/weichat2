/*     */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.faces.application.Application;
/*     */ import javax.faces.application.ResourceDependencies;
/*     */ import javax.faces.component.FacesComponent;
/*     */ import javax.faces.component.StateHelper;
/*     */ import javax.faces.context.FacesContext;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.message.FwMessage;
/*     */ import org.primefaces.behavior.ajax.AjaxBehavior;
/*     */ import org.primefaces.component.selectoneradio.SelectOneRadio;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ResourceDependencies({@javax.faces.application.ResourceDependency(library="primefaces", name="primefaces.css"), @javax.faces.application.ResourceDependency(library="primefaces", name="jquery/jquery.js"), @javax.faces.application.ResourceDependency(library="primefaces", name="primefaces.js")})
/*     */ @FacesComponent("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwSelectOneRadio")
/*     */ public class CfwSelectOneRadio
/*     */   extends SelectOneRadio
/*     */ {
/*     */   public static final String CHANGE = "change";
/*     */   public static final String COMPONENT_TYPE = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwSelectOneRadio";
/*     */   
/*     */   public static enum PropertyKeys
/*     */   {
/*  50 */     messageParam, 
/*     */     
/*     */ 
/*  53 */     top, 
/*     */     
/*     */ 
/*  56 */     right, 
/*     */     
/*     */ 
/*  59 */     bottom, 
/*     */     
/*     */ 
/*  62 */     left;
/*     */     
/*     */     String toString;
/*     */     
/*     */     private PropertyKeys(String toString) {
/*  67 */       this.toString = toString;
/*     */     }
/*     */     
/*     */ 
/*     */     private PropertyKeys() {}
/*     */     
/*     */ 
/*     */     public String toString()
/*     */     {
/*  76 */       return this.toString != null ? this.toString : super.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessageParam()
/*     */   {
/*  86 */     return (String)getStateHelper().eval(PropertyKeys.messageParam, "値");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMessageParam(String messageParam)
/*     */   {
/*  95 */     getStateHelper().put(PropertyKeys.messageParam, messageParam);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTop()
/*     */   {
/* 104 */     return (String)getStateHelper().eval(PropertyKeys.top, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTop(String top)
/*     */   {
/* 113 */     getStateHelper().put(PropertyKeys.top, top);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRight()
/*     */   {
/* 122 */     return (String)getStateHelper().eval(PropertyKeys.right, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRight(String right)
/*     */   {
/* 131 */     getStateHelper().put(PropertyKeys.right, right);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBottom()
/*     */   {
/* 140 */     return (String)getStateHelper().eval(PropertyKeys.bottom, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBottom(String bottom)
/*     */   {
/* 149 */     getStateHelper().put(PropertyKeys.bottom, bottom);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLeft()
/*     */   {
/* 158 */     return (String)getStateHelper().eval(PropertyKeys.left, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLeft(String left)
/*     */   {
/* 167 */     getStateHelper().put(PropertyKeys.left, left);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void encodeEnd(FacesContext context)
/*     */     throws IOException
/*     */   {
/* 176 */     AjaxBehavior ajaxBehavior = null;
/*     */     
/* 178 */     if (isRendered())
/*     */     {
/*     */ 
/* 181 */       CfwComponentUtils utils = CfwComponentUtils.getInstance();
/* 182 */       setStyle(utils.addStyle(getStyle(), "display", "inline-block"));
/* 183 */       setStyle(utils.addStyle(getStyle(), "vertical-align", "middle"));
/*     */       
/*     */ 
/* 186 */       setStyle(utils.addStyle(getStyle(), utils.createMarginStyle(getTop(), getRight(), getBottom(), getLeft())));
/*     */       
/*     */ 
/* 189 */       setRequiredMessage(FwMessage.getInstance().getMessage("CXXM90000E", new Object[] { getMessageParam() }));
/*     */       
/*     */ 
/* 192 */       if (((getClientBehaviors().get("change") == null) || (((List)getClientBehaviors().get("change")).size() == 0)) && 
/* 193 */         (getValueChangeListeners().length > 0)) {
/* 194 */         ajaxBehavior = (AjaxBehavior)context.getApplication().createBehavior("org.primefaces.component.AjaxBehavior");
/* 195 */         ajaxBehavior.setUpdate("@this");
/*     */         
/* 197 */         addClientBehavior("change", ajaxBehavior);
/*     */       }
/*     */     }
/*     */     
/* 201 */     super.encodeEnd(context);
/*     */     
/* 203 */     if (ajaxBehavior != null) {
/* 204 */       ((List)getClientBehaviors().get("change")).remove(ajaxBehavior);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwSelectOneRadio.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */