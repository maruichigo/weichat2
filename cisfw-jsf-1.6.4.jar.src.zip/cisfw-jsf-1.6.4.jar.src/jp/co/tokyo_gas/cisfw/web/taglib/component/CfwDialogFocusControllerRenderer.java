/*    */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.faces.component.UIComponent;
/*    */ import javax.faces.context.FacesContext;
/*    */ import javax.faces.render.FacesRenderer;
/*    */ import org.primefaces.renderkit.CoreRenderer;
/*    */ import org.primefaces.util.WidgetBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FacesRenderer(rendererType="jp.co.tokyo_gas.cisfw.web.taglib.component.CfwDialogFocusControllerRenderer", componentFamily="jp.co.tokyo_gas.cisfw")
/*    */ public class CfwDialogFocusControllerRenderer
/*    */   extends CoreRenderer
/*    */ {
/*    */   public void encodeEnd(FacesContext context, UIComponent component)
/*    */     throws IOException
/*    */   {
/* 31 */     CfwDialogFocusController controller = (CfwDialogFocusController)component;
/* 32 */     encodeScript(context, controller);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void encodeScript(FacesContext context, CfwDialogFocusController controller)
/*    */     throws IOException
/*    */   {
/* 42 */     String clientId = controller.getClientId();
/* 43 */     WidgetBuilder wb = getWidgetBuilder(context);
/*    */     
/* 45 */     wb.initWithDomReady("CfwDialogFocusController", controller.resolveWidgetVar(), clientId)
/* 46 */       .attr("start", controller.getStart(), null)
/* 47 */       .attr("end", controller.getEnd(), null)
/* 48 */       .finish();
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwDialogFocusControllerRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */