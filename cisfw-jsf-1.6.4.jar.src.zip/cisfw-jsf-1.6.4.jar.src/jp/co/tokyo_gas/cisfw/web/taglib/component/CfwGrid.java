/*     */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.faces.component.FacesComponent;
/*     */ import javax.faces.component.StateHelper;
/*     */ import javax.faces.component.UIComponent;
/*     */ import javax.faces.component.UINamingContainer;
/*     */ import javax.faces.context.ExternalContext;
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.faces.model.DataModel;
/*     */ import org.primefaces.component.api.DynamicColumn;
/*     */ import org.primefaces.component.api.UIColumn;
/*     */ import org.primefaces.component.column.Column;
/*     */ import org.primefaces.component.columns.Columns;
/*     */ import org.primefaces.component.datatable.DataTable;
/*     */ import org.primefaces.component.row.Row;
/*     */ import org.primefaces.component.subtable.SubTable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FacesComponent("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwGrid")
/*     */ public class CfwGrid
/*     */   extends DataTable
/*     */ {
/*     */   public static final String COMPONENT_TYPE = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwGrid";
/*     */   public static final String DEFAULT_RENDERER = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwGridRenderer";
/*     */   private List<Integer> switchIndexList;
/*     */   private List<UIColumn> columns;
/*  48 */   private List<Object> selectedRowKeys = new ArrayList();
/*     */   
/*     */ 
/*  51 */   private int columnsCount = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwGrid()
/*     */   {
/*  58 */     setRendererType("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwGridRenderer");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected static enum PropertyKeys
/*     */   {
/*  65 */     pageReport, 
/*     */     
/*     */ 
/*  68 */     frozenColumnWidth, 
/*     */     
/*     */ 
/*  71 */     renderedGridHeader, 
/*     */     
/*     */ 
/*  74 */     width, 
/*     */     
/*     */ 
/*  77 */     top, 
/*     */     
/*     */ 
/*  80 */     right, 
/*     */     
/*     */ 
/*  83 */     bottom, 
/*     */     
/*     */ 
/*  86 */     left, 
/*     */     
/*     */ 
/*  89 */     selectRows, 
/*     */     
/*     */ 
/*  92 */     lazyRowKey;
/*     */     
/*     */     String toString;
/*     */     
/*     */     private PropertyKeys(String toString) {
/*  97 */       this.toString = toString;
/*     */     }
/*     */     
/*     */ 
/*     */     private PropertyKeys() {}
/*     */     
/*     */ 
/*     */     public String toString()
/*     */     {
/* 106 */       return this.toString != null ? this.toString : super.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFamily()
/*     */   {
/* 117 */     return "jp.co.tokyo_gas.cisfw";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPageReport(String pageReport)
/*     */   {
/* 126 */     getStateHelper().put(PropertyKeys.pageReport, pageReport);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPageReport()
/*     */   {
/* 135 */     return (String)getStateHelper().eval(PropertyKeys.pageReport, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFrozenColumnWidth(String frozenColumnWidth)
/*     */   {
/* 144 */     getStateHelper().put(PropertyKeys.frozenColumnWidth, frozenColumnWidth);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFrozenColumnWidth()
/*     */   {
/* 153 */     return (String)getStateHelper().eval(PropertyKeys.frozenColumnWidth, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRenderedGridHeader(Boolean renderedGridHeader)
/*     */   {
/* 162 */     getStateHelper().put(PropertyKeys.renderedGridHeader, renderedGridHeader);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Boolean isRenderedGridHeader()
/*     */   {
/* 171 */     return (Boolean)getStateHelper().eval(PropertyKeys.renderedGridHeader, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWidth(String width)
/*     */   {
/* 180 */     getStateHelper().put(PropertyKeys.width, width);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getWidth()
/*     */   {
/* 189 */     return (String)getStateHelper().eval(PropertyKeys.width, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Object> getSelectedRowKeys()
/*     */   {
/* 200 */     return this.selectedRowKeys;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTop()
/*     */   {
/* 209 */     return (String)getStateHelper().eval(PropertyKeys.top, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTop(String top)
/*     */   {
/* 218 */     getStateHelper().put(PropertyKeys.top, top);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRight()
/*     */   {
/* 227 */     return (String)getStateHelper().eval(PropertyKeys.right, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRight(String right)
/*     */   {
/* 236 */     getStateHelper().put(PropertyKeys.right, right);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBottom()
/*     */   {
/* 245 */     return (String)getStateHelper().eval(PropertyKeys.bottom, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBottom(String bottom)
/*     */   {
/* 254 */     getStateHelper().put(PropertyKeys.bottom, bottom);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLeft()
/*     */   {
/* 263 */     return (String)getStateHelper().eval(PropertyKeys.left, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLeft(String left)
/*     */   {
/* 272 */     getStateHelper().put(PropertyKeys.left, left);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSelectRows()
/*     */   {
/* 281 */     return (String)getStateHelper().eval(PropertyKeys.selectRows, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSelectRows(String selectRows)
/*     */   {
/* 290 */     getStateHelper().put(PropertyKeys.selectRows, selectRows);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setColumns(List<UIColumn> columns)
/*     */   {
/* 300 */     this.columns = columns;
/*     */   }
/*     */   
/*     */ 
/*     */   public List<UIColumn> getColumns()
/*     */   {
/*     */     FacesContext context;
/*     */     
/*     */     char separator;
/*     */     int tdCount;
/* 310 */     if (this.columns == null)
/*     */     {
/* 312 */       this.columns = new ArrayList();
/*     */       
/* 314 */       context = getFacesContext();
/* 315 */       separator = UINamingContainer.getSeparatorChar(context);
/*     */       
/*     */ 
/* 318 */       tdCount = 0;
/*     */       
/* 320 */       for (UIComponent childRow : getChildren())
/*     */       {
/* 322 */         if ((childRow instanceof Row))
/*     */         {
/* 324 */           if (this.switchIndexList == null) {
/* 325 */             this.switchIndexList = new ArrayList();
/*     */           }
/*     */           
/*     */ 
/* 329 */           this.switchIndexList.add(Integer.valueOf(tdCount));
/*     */           
/*     */ 
/* 332 */           int switchIndex = 0;
/* 333 */           for (UIComponent childColumn : childRow.getChildren()) {
/* 334 */             if (childColumn.isRendered()) {
/* 335 */               this.switchIndexList.add(Integer.valueOf(switchIndex));
/* 336 */               break;
/*     */             }
/* 338 */             switchIndex++;
/*     */           }
/*     */           
/* 341 */           for (UIComponent childColumn : childRow.getChildren())
/*     */           {
/* 343 */             tdCount++;
/*     */             
/* 345 */             if ((childColumn instanceof Column))
/*     */             {
/* 347 */               this.columns.add((UIColumn)childColumn);
/* 348 */             } else if ((childColumn instanceof Columns))
/*     */             {
/* 350 */               Columns uiColumns = (Columns)childColumn;
/* 351 */               String uiColumnsClientId = uiColumns.getClientId(context);
/*     */               
/* 353 */               for (int i = 0; i < uiColumns.getRowCount(); i++)
/*     */               {
/* 355 */                 DynamicColumn dynaColumn = new DynamicColumn(i, uiColumns);
/* 356 */                 dynaColumn.setColumnKey(uiColumnsClientId + separator + i);
/* 357 */                 this.columns.add(dynaColumn);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 364 */     return this.columns;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSwitchIndexList(List<Integer> switchIndexList)
/*     */   {
/* 373 */     this.switchIndexList = switchIndexList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Integer> getSwitchIndexList()
/*     */   {
/* 382 */     return this.switchIndexList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getColumnSelectionMode()
/*     */   {
/* 393 */     for (UIComponent childRow : getChildren())
/*     */     {
/* 395 */       for (UIComponent childColumn : childRow.getChildren())
/*     */       {
/* 397 */         if ((childColumn.isRendered()) && ((childColumn instanceof Column)))
/*     */         {
/* 399 */           String selectionMode = ((Column)childColumn).getSelectionMode();
/*     */           
/* 401 */           if (selectionMode != null) {
/* 402 */             return selectionMode;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 407 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumnsCount()
/*     */   {
/*     */     Iterator localIterator1;
/*     */     
/*     */ 
/* 418 */     if (this.columnsCount == -1) {
/* 419 */       this.columnsCount = 0;
/*     */       
/* 421 */       for (localIterator1 = getChildren().iterator(); localIterator1.hasNext();) { childRow = (UIComponent)localIterator1.next();
/*     */         
/* 423 */         for (UIComponent childColumn : childRow.getChildren())
/*     */         {
/* 425 */           if ((childColumn instanceof Columns))
/*     */           {
/* 427 */             int dynamicColumnsCount = ((Columns)childRow).getRowCount();
/*     */             
/* 429 */             if (dynamicColumnsCount > 0)
/*     */             {
/* 431 */               this.columnsCount += dynamicColumnsCount;
/*     */             }
/*     */           }
/* 434 */           else if ((childColumn instanceof Column))
/*     */           {
/* 436 */             this.columnsCount += 1;
/* 437 */           } else if ((childColumn instanceof SubTable))
/*     */           {
/* 439 */             SubTable subTable = (SubTable)childRow;
/*     */             
/* 441 */             for (UIComponent subTableKid : subTable.getChildren())
/*     */             {
/* 443 */               if ((subTableKid.isRendered()) && ((subTableKid instanceof Column)))
/* 444 */                 this.columnsCount += 1;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     UIComponent childRow;
/* 451 */     return this.columnsCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void findSelectedRowKeys()
/*     */   {
/* 459 */     Object selection = getSelection();
/* 460 */     this.selectedRowKeys = new ArrayList();
/*     */     
/* 462 */     boolean hasRowKeyVe = getValueExpression("rowKey") != null;
/*     */     
/* 464 */     String var = getVar();
/* 465 */     Map<String, Object> requestMap = getFacesContext().getExternalContext().getRequestMap();
/*     */     
/* 467 */     if ((isSelectionEnabled()) && (selection != null)) {
/*     */       Iterator<? extends Object> it;
/* 469 */       if (isSingleSelectionMode())
/*     */       {
/* 471 */         addToSelectedRowKeys(selection, requestMap, var, hasRowKeyVe);
/*     */ 
/*     */       }
/* 474 */       else if (selection.getClass().isArray())
/*     */       {
/* 476 */         for (int i = 0; i < Array.getLength(selection); i++)
/*     */         {
/* 478 */           addToSelectedRowKeys(Array.get(selection, i), requestMap, var, hasRowKeyVe);
/*     */         }
/*     */       }
/*     */       else {
/* 482 */         List<?> list = (List)selection;
/*     */         
/* 484 */         for (it = list.iterator(); it.hasNext();)
/*     */         {
/* 486 */           addToSelectedRowKeys(it.next(), requestMap, var, hasRowKeyVe);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 491 */       requestMap.remove(var);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addToSelectedRowKeys(Object object, Map<String, Object> map, String var, boolean hasRowKey)
/*     */   {
/* 506 */     if (hasRowKey)
/*     */     {
/* 508 */       map.put(var, object);
/* 509 */       Object rowKey = getRowKey();
/*     */       
/* 511 */       if (rowKey != null)
/*     */       {
/* 513 */         this.selectedRowKeys.add(rowKey);
/*     */       }
/*     */     }
/*     */     else {
/* 517 */       Object rowKey = getRowKeyFromModel(object);
/*     */       
/* 519 */       if (rowKey != null)
/*     */       {
/* 521 */         this.selectedRowKeys.add(rowKey);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataModel getDataModel()
/*     */   {
/* 531 */     return super.getDataModel();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getLazyRowKey()
/*     */   {
/* 540 */     return getStateHelper().eval(PropertyKeys.lazyRowKey, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLazyRowKey(Object rowKey)
/*     */   {
/* 549 */     getStateHelper().put(PropertyKeys.lazyRowKey, rowKey);
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwGrid.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */