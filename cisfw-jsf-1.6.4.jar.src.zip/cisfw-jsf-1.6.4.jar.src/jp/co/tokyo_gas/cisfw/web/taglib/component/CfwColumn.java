/*    */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*    */ 
/*    */ import javax.faces.component.FacesComponent;
/*    */ import javax.faces.component.StateHelper;
/*    */ import org.primefaces.component.column.Column;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FacesComponent("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwColumn")
/*    */ public class CfwColumn
/*    */   extends Column
/*    */ {
/*    */   public static final String COMPONENT_TYPE = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwColumn";
/*    */   
/*    */   protected static enum PropertyKeys
/*    */   {
/* 28 */     required, 
/*    */     
/*    */ 
/* 31 */     align;
/*    */     
/*    */     String toString;
/*    */     
/*    */     private PropertyKeys(String toString) {
/* 36 */       this.toString = toString;
/*    */     }
/*    */     
/*    */ 
/*    */     private PropertyKeys() {}
/*    */     
/*    */ 
/*    */     public String toString()
/*    */     {
/* 45 */       return this.toString != null ? this.toString : super.toString();
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Boolean isRequired()
/*    */   {
/* 55 */     return (Boolean)getStateHelper().eval(PropertyKeys.required, null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setRequired(Boolean required)
/*    */   {
/* 64 */     getStateHelper().put(PropertyKeys.required, required);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setAlign(String align)
/*    */   {
/* 73 */     getStateHelper().put(PropertyKeys.align, align);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getAlign()
/*    */   {
/* 82 */     return (String)getStateHelper().eval(PropertyKeys.align, null);
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwColumn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */