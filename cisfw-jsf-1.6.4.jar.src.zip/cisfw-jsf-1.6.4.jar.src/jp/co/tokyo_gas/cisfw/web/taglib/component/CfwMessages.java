/*    */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*    */ 
/*    */ import javax.faces.component.FacesComponent;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.taglib.output.FwMessages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FacesComponent("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwMessages")
/*    */ public class CfwMessages
/*    */   extends FwMessages
/*    */ {
/*    */   public static final String COMPONENT_TYPE = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwMessages";
/*    */   public static final String COMPONENT_FAMILY = "jp.co.tokyo_gas.cisfw";
/*    */   public static final String DEFAULT_RENDERER = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwMessagesRenderer";
/*    */   
/*    */   public CfwMessages()
/*    */   {
/* 32 */     setRendererType("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwMessagesRenderer");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getFamily()
/*    */   {
/* 42 */     return "jp.co.tokyo_gas.cisfw";
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwMessages.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */