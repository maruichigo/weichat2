/*     */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*     */ 
/*     */ import javax.faces.component.FacesComponent;
/*     */ import javax.faces.component.StateHelper;
/*     */ import org.primefaces.component.outputlabel.OutputLabel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FacesComponent("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwOutputLabel")
/*     */ public class CfwOutputLabel
/*     */   extends OutputLabel
/*     */ {
/*     */   public static final String COMPONENT_TYPE = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwOutputLabel";
/*     */   public static final String COMPONENT_FAMILY = "jp.co.tokyo_gas.cisfw";
/*     */   public static final String DEFAULT_RENDERER = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwOutputLabelRenderer";
/*     */   
/*     */   protected static enum PropertyKeys
/*     */   {
/*  36 */     prefix, 
/*     */     
/*     */ 
/*  39 */     suffix, 
/*     */     
/*     */ 
/*  42 */     pattern, 
/*     */     
/*     */ 
/*  45 */     type, 
/*     */     
/*     */ 
/*  48 */     cacheKey, 
/*     */     
/*     */ 
/*  51 */     height, 
/*     */     
/*     */ 
/*  54 */     width, 
/*     */     
/*     */ 
/*  57 */     align, 
/*     */     
/*     */ 
/*  60 */     bgcolor, 
/*     */     
/*     */ 
/*  63 */     color, 
/*     */     
/*     */ 
/*  66 */     top, 
/*     */     
/*     */ 
/*  69 */     right, 
/*     */     
/*     */ 
/*  72 */     bottom, 
/*     */     
/*     */ 
/*  75 */     left, 
/*     */     
/*     */ 
/*  78 */     constType, 
/*     */     
/*     */ 
/*  81 */     shortName, 
/*     */     
/*     */ 
/*  84 */     required, 
/*     */     
/*     */ 
/*  87 */     patternKey;
/*     */     
/*     */     String toString;
/*     */     
/*     */     private PropertyKeys(String toString) {
/*  92 */       this.toString = toString;
/*     */     }
/*     */     
/*     */ 
/*     */     private PropertyKeys() {}
/*     */     
/*     */ 
/*     */     public String toString()
/*     */     {
/* 101 */       return this.toString != null ? this.toString : super.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public CfwOutputLabel()
/*     */   {
/* 109 */     setRendererType("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwOutputLabelRenderer");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFamily()
/*     */   {
/* 119 */     return "jp.co.tokyo_gas.cisfw";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPattern()
/*     */   {
/* 128 */     return (String)getStateHelper().eval(PropertyKeys.pattern, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPattern(String pattern)
/*     */   {
/* 137 */     getStateHelper().put(PropertyKeys.pattern, pattern);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPrefix()
/*     */   {
/* 146 */     return (String)getStateHelper().eval(PropertyKeys.prefix, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPrefix(String prefix)
/*     */   {
/* 155 */     getStateHelper().put(PropertyKeys.prefix, prefix);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSuffix()
/*     */   {
/* 164 */     return (String)getStateHelper().eval(PropertyKeys.suffix, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSuffix(String suffix)
/*     */   {
/* 173 */     getStateHelper().put(PropertyKeys.suffix, suffix);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getType()
/*     */   {
/* 182 */     return (String)getStateHelper().eval(PropertyKeys.type, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setType(String type)
/*     */   {
/* 191 */     getStateHelper().put(PropertyKeys.type, type);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCacheKey()
/*     */   {
/* 200 */     return (String)getStateHelper().eval(PropertyKeys.cacheKey, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCacheKey(String cacheKey)
/*     */   {
/* 209 */     getStateHelper().put(PropertyKeys.cacheKey, cacheKey);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHeight()
/*     */   {
/* 218 */     return (String)getStateHelper().eval(PropertyKeys.height, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHeight(String height)
/*     */   {
/* 227 */     getStateHelper().put(PropertyKeys.height, height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getWidth()
/*     */   {
/* 236 */     return (String)getStateHelper().eval(PropertyKeys.width, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWidth(String width)
/*     */   {
/* 245 */     getStateHelper().put(PropertyKeys.width, width);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAlign()
/*     */   {
/* 254 */     return (String)getStateHelper().eval(PropertyKeys.align, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAlign(String align)
/*     */   {
/* 263 */     getStateHelper().put(PropertyKeys.align, align);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBgcolor()
/*     */   {
/* 272 */     return (String)getStateHelper().eval(PropertyKeys.bgcolor, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBgcolor(String bgcolor)
/*     */   {
/* 281 */     getStateHelper().put(PropertyKeys.bgcolor, bgcolor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getColor()
/*     */   {
/* 290 */     return (String)getStateHelper().eval(PropertyKeys.color, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setColor(String color)
/*     */   {
/* 299 */     getStateHelper().put(PropertyKeys.color, color);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTop()
/*     */   {
/* 307 */     return (String)getStateHelper().eval(PropertyKeys.top, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTop(String top)
/*     */   {
/* 315 */     getStateHelper().put(PropertyKeys.top, top);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRight()
/*     */   {
/* 323 */     return (String)getStateHelper().eval(PropertyKeys.right, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRight(String right)
/*     */   {
/* 331 */     getStateHelper().put(PropertyKeys.right, right);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBottom()
/*     */   {
/* 339 */     return (String)getStateHelper().eval(PropertyKeys.bottom, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBottom(String bottom)
/*     */   {
/* 347 */     getStateHelper().put(PropertyKeys.bottom, bottom);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLeft()
/*     */   {
/* 355 */     return (String)getStateHelper().eval(PropertyKeys.left, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLeft(String left)
/*     */   {
/* 363 */     getStateHelper().put(PropertyKeys.left, left);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Boolean isRequired()
/*     */   {
/* 372 */     return (Boolean)getStateHelper().eval(PropertyKeys.required, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRequired(Boolean required)
/*     */   {
/* 381 */     getStateHelper().put(PropertyKeys.required, required);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getConstType()
/*     */   {
/* 390 */     return (String)getStateHelper().eval(PropertyKeys.constType, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConstType(String constType)
/*     */   {
/* 399 */     getStateHelper().put(PropertyKeys.constType, constType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Boolean isShortName()
/*     */   {
/* 408 */     return (Boolean)getStateHelper().eval(PropertyKeys.shortName, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setShortName(Boolean shortName)
/*     */   {
/* 417 */     getStateHelper().put(PropertyKeys.shortName, shortName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPatternKey(String patternKey)
/*     */   {
/* 426 */     getStateHelper().put(PropertyKeys.patternKey, patternKey);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPatternKey()
/*     */   {
/* 435 */     return (String)getStateHelper().eval(PropertyKeys.patternKey, null);
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwOutputLabel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */