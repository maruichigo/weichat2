/*     */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.faces.application.Application;
/*     */ import javax.faces.application.ResourceDependencies;
/*     */ import javax.faces.component.FacesComponent;
/*     */ import javax.faces.component.StateHelper;
/*     */ import javax.faces.context.FacesContext;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.taglib.FwTaglibUtils;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.taglib.input.FwSelectOneMenu;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.message.FwMessage;
/*     */ import org.primefaces.behavior.ajax.AjaxBehavior;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ResourceDependencies({@javax.faces.application.ResourceDependency(library="primefaces", name="primefaces.css"), @javax.faces.application.ResourceDependency(library="primefaces", name="jquery/jquery.js"), @javax.faces.application.ResourceDependency(library="primefaces", name="primefaces.js"), @javax.faces.application.ResourceDependency(library="primefaces", name="jquery/jquery-plugins.js"), @javax.faces.application.ResourceDependency(library="tgfw_js", name="tgfw.js"), @javax.faces.application.ResourceDependency(library="js", name="cisfw-component.js")})
/*     */ @FacesComponent("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwSelectOneMenu")
/*     */ public class CfwSelectOneMenu
/*     */   extends FwSelectOneMenu
/*     */ {
/*     */   public static final String CHANGE = "change";
/*     */   public static final String COMPONENT_TYPE = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwSelectOneMenu";
/*     */   public static final String DEFAULT_RENDERER = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwSelectOneMenuRenderer";
/*     */   public static final String COMPONENT_FAMILY = "jp.co.tokyo_gas.cisfw";
/*     */   
/*     */   protected static enum PropertyKeys
/*     */   {
/*  63 */     filterBy, 
/*     */     
/*     */ 
/*  66 */     width, 
/*     */     
/*     */ 
/*  69 */     messageParam, 
/*     */     
/*     */ 
/*  72 */     top, 
/*     */     
/*     */ 
/*  75 */     right, 
/*     */     
/*     */ 
/*  78 */     bottom, 
/*     */     
/*     */ 
/*  81 */     left;
/*     */     
/*     */     String toString;
/*     */     
/*  85 */     private PropertyKeys(String toString) { this.toString = toString; }
/*     */     
/*     */ 
/*     */ 
/*     */     private PropertyKeys() {}
/*     */     
/*     */ 
/*     */     public String toString()
/*     */     {
/*  94 */       return this.toString != null ? this.toString : super.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public CfwSelectOneMenu()
/*     */   {
/* 102 */     setRendererType("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwSelectOneMenuRenderer");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFamily()
/*     */   {
/* 111 */     return "jp.co.tokyo_gas.cisfw";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFilterBy(String filterBy)
/*     */   {
/* 119 */     getStateHelper().put(PropertyKeys.filterBy, filterBy);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFilterBy()
/*     */   {
/* 127 */     return (String)getStateHelper().eval(PropertyKeys.filterBy, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWidth(String width)
/*     */   {
/* 135 */     getStateHelper().put(PropertyKeys.width, width);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getWidth()
/*     */   {
/* 143 */     return (String)getStateHelper().eval(PropertyKeys.width, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMessageParam(String messageParam)
/*     */   {
/* 151 */     getStateHelper().put(PropertyKeys.messageParam, messageParam);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessageParam()
/*     */   {
/* 159 */     return (String)getStateHelper().eval(PropertyKeys.messageParam, "値");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTop()
/*     */   {
/* 167 */     return (String)getStateHelper().eval(PropertyKeys.top, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTop(String top)
/*     */   {
/* 175 */     getStateHelper().put(PropertyKeys.top, top);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRight()
/*     */   {
/* 183 */     return (String)getStateHelper().eval(PropertyKeys.right, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRight(String right)
/*     */   {
/* 191 */     getStateHelper().put(PropertyKeys.right, right);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBottom()
/*     */   {
/* 199 */     return (String)getStateHelper().eval(PropertyKeys.bottom, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBottom(String bottom)
/*     */   {
/* 207 */     getStateHelper().put(PropertyKeys.bottom, bottom);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLeft()
/*     */   {
/* 215 */     return (String)getStateHelper().eval(PropertyKeys.left, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLeft(String left)
/*     */   {
/* 223 */     getStateHelper().put(PropertyKeys.left, left);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void encodeEnd(FacesContext context)
/*     */     throws IOException
/*     */   {
/* 232 */     AjaxBehavior ajaxBehavior = null;
/*     */     
/* 234 */     if (isRendered())
/*     */     {
/*     */ 
/* 237 */       FwTaglibUtils.setDataFwAttribute(this, PropertyKeys.filterBy.toString(), getFilterBy());
/*     */       
/* 239 */       CfwComponentUtils utils = CfwComponentUtils.getInstance();
/*     */       
/*     */ 
/* 242 */       setStyle(utils.addStyle(getStyle(), "line-height", "normal"));
/* 243 */       setStyle(utils.addStyle(getStyle(), "vertical-align", "middle"));
/* 244 */       setStyle(utils.addStyle(getStyle(), "margin-bottom", "3px"));
/*     */       
/*     */ 
/* 247 */       setStyle(utils.addStyle(getStyle(), "width", utils.toWidth(getWidth(), -2)));
/*     */       
/*     */ 
/* 250 */       String margin = utils.createMarginStyle(getTop(), getRight(), getBottom(), getLeft());
/* 251 */       setStyle(utils.addStyle(getStyle(), margin));
/*     */       
/*     */ 
/* 254 */       String filterBy = getFilterBy();
/* 255 */       if (("label".equals(filterBy)) || ("condition".equals(filterBy)) || ("both".equals(filterBy))) {
/* 256 */         setFilter(true);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 261 */       String code = utils.isDescendantOfCfwGrid(this) ? "CXXM90001E" : "CXXM90000E";
/* 262 */       setRequiredMessage(FwMessage.getInstance().getMessage(code, new Object[] { getMessageParam() }));
/*     */       
/*     */ 
/* 265 */       if (((getClientBehaviors().get("change") == null) || (((List)getClientBehaviors().get("change")).size() == 0)) && 
/* 266 */         (getValueChangeListeners().length > 0)) {
/* 267 */         ajaxBehavior = (AjaxBehavior)context.getApplication().createBehavior("org.primefaces.component.AjaxBehavior");
/* 268 */         ajaxBehavior.setUpdate("@this");
/* 269 */         ajaxBehavior.setProcess("@this");
/* 270 */         ajaxBehavior.setPartialSubmit(true);
/*     */         
/* 272 */         addClientBehavior("change", ajaxBehavior);
/*     */       }
/*     */     }
/*     */     
/* 276 */     super.encodeEnd(context);
/*     */     
/* 278 */     if (ajaxBehavior != null) {
/* 279 */       ((List)getClientBehaviors().get("change")).remove(ajaxBehavior);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwSelectOneMenu.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */