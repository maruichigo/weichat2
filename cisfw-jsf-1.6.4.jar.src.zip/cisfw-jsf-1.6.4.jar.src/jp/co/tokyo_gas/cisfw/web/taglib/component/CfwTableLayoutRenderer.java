/*     */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import javax.faces.component.UIComponent;
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.faces.context.ResponseWriter;
/*     */ import javax.faces.render.FacesRenderer;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.string.FwStringValidator;
/*     */ import org.primefaces.component.column.Column;
/*     */ import org.primefaces.component.panelgrid.PanelGrid;
/*     */ import org.primefaces.component.panelgrid.PanelGridRenderer;
/*     */ import org.primefaces.component.row.Row;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FacesRenderer(componentFamily="jp.co.tokyo_gas.cisfw", rendererType="jp.co.tokyo_gas.cisfw.web.taglib.component.CfwTableLayoutRenderer")
/*     */ public class CfwTableLayoutRenderer
/*     */   extends PanelGridRenderer
/*     */ {
/*  39 */   private String tableBgcolor = "";
/*     */   
/*  41 */   private String trBgcolor = "";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void encodeTableLayout(FacesContext context, PanelGrid grid)
/*     */     throws IOException
/*     */   {
/*  52 */     String styleClass = grid.getStyleClass();
/*     */     
/*  54 */     styleClass = "ui-panelgrid ui-widget " + styleClass;
/*     */     
/*  56 */     CfwTableLayout tableLayout = (CfwTableLayout)grid;
/*  57 */     setTableBgcolor(tableLayout.getBgcolor());
/*  58 */     if ("1".equals(tableLayout.getBorder())) {
/*  59 */       styleClass = styleClass + " cfw-ui-tableLayout";
/*     */     }
/*     */     
/*  62 */     ResponseWriter writer = context.getResponseWriter();
/*  63 */     String clientId = grid.getClientId(context);
/*     */     
/*  65 */     writer.startElement("table", grid);
/*  66 */     writer.writeAttribute("id", clientId, "id");
/*  67 */     writer.writeAttribute("class", styleClass, "styleClass");
/*     */     
/*  69 */     CfwComponentUtils util = CfwComponentUtils.getInstance();
/*  70 */     String style = util.addSemicolon(grid.getStyle());
/*  71 */     String tableStyle = createTableStyle(grid);
/*     */     
/*  73 */     if (tableStyle != null) {
/*  74 */       if (style != null) {
/*  75 */         writer.writeAttribute("style", style + tableStyle, "style");
/*     */       } else {
/*  77 */         writer.writeAttribute("style", tableStyle, "style");
/*     */       }
/*     */     }
/*  80 */     else if (style != null) {
/*  81 */       writer.writeAttribute("style", style, "style");
/*     */     }
/*     */     
/*     */ 
/*  85 */     int columns = grid.getColumns();
/*  86 */     encodeTableFacet(context, grid, columns, "header", "thead", "ui-panelgrid-header");
/*  87 */     encodeTableFacet(context, grid, columns, "footer", "tfoot", "ui-panelgrid-footer");
/*  88 */     encodeTableBody(context, grid, columns);
/*     */     
/*  90 */     writer.endElement("table");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String createTableStyle(PanelGrid panelGrid)
/*     */   {
/* 100 */     CfwTableLayout tableLayout = (CfwTableLayout)panelGrid;
/* 101 */     String style = "";
/*     */     
/* 103 */     CfwComponentUtils utils = CfwComponentUtils.getInstance();
/*     */     
/* 105 */     String color = getStyleBgColor(tableLayout.getBgcolor());
/* 106 */     if (color != null) {
/* 107 */       style = style + color;
/*     */     }
/*     */     
/* 110 */     String width = getStyleWidth(tableLayout.getWidth());
/* 111 */     if (!FwStringValidator.isEmpty(width)) {
/* 112 */       style = utils.addStyle(style, width);
/*     */     }
/*     */     
/* 115 */     String height = getStyleHeight(tableLayout.getHeight());
/* 116 */     if (!FwStringValidator.isEmpty(height)) {
/* 117 */       style = utils.addStyle(style, height);
/*     */     }
/*     */     
/* 120 */     String align = getStyleAlign(tableLayout.getAlign());
/* 121 */     if (!FwStringValidator.isEmpty(align)) {
/* 122 */       style = utils.addStyle(style, align);
/*     */     }
/*     */     
/* 125 */     String margin = utils.createMarginStyle(tableLayout
/* 126 */       .getTop(), tableLayout.getRight(), tableLayout.getBottom(), tableLayout.getLeft());
/* 127 */     style = utils.addStyle(style, margin);
/*     */     
/* 129 */     return "".equals(style) ? null : style;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getTableBgcolor()
/*     */   {
/* 137 */     return this.tableBgcolor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setTableBgcolor(String bgcolor)
/*     */   {
/* 145 */     this.tableBgcolor = bgcolor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getTrColor()
/*     */   {
/* 153 */     return this.trBgcolor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setTrcolor(String bgcolor)
/*     */   {
/* 161 */     this.trBgcolor = bgcolor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void encodeRow(FacesContext context, Row row, String columnRole, String rowClass, String columnClass)
/*     */     throws IOException
/*     */   {
/* 175 */     ResponseWriter writer = context.getResponseWriter();
/*     */     
/* 177 */     writer.startElement("tr", null);
/* 178 */     if (shouldWriteId(row)) {
/* 179 */       writer.writeAttribute("id", row.getClientId(context), null);
/*     */     }
/*     */     
/* 182 */     writer.writeAttribute("class", rowClass, null);
/* 183 */     writer.writeAttribute("role", "row", null);
/*     */     
/* 185 */     CfwTr tr = (CfwTr)row;
/* 186 */     setTrcolor(tr.getBgcolor());
/*     */     
/*     */ 
/* 189 */     String trStyle = createTrStyle(row);
/* 190 */     if (trStyle != null) {
/* 191 */       writer.writeAttribute("style", trStyle, null);
/*     */     }
/*     */     
/*     */ 
/* 195 */     for (UIComponent child : row.getChildren()) {
/* 196 */       if (((child instanceof CfwTd)) && (child.isRendered())) {
/* 197 */         CfwTd column = (CfwTd)child;
/* 198 */         String userStyleClass = column.getStyleClass();
/*     */         
/* 200 */         writer.startElement("td", null);
/* 201 */         if (shouldWriteId(column)) {
/* 202 */           writer.writeAttribute("id", column.getClientId(context), null);
/*     */         }
/*     */         
/* 205 */         String styleClass = columnClass + " " + userStyleClass;
/*     */         
/* 207 */         styleClass = styleClass + " cfw-td-border";
/* 208 */         writer.writeAttribute("role", columnRole, null);
/* 209 */         writer.writeAttribute("class", styleClass, null);
/*     */         
/* 211 */         CfwComponentUtils util = CfwComponentUtils.getInstance();
/* 212 */         String style = util.addSemicolon(column.getStyle());
/* 213 */         String tdStyle = createTdStyle(column);
/* 214 */         if (tdStyle != null) {
/* 215 */           if (style != null) {
/* 216 */             writer.writeAttribute("style", style + tdStyle, null);
/*     */           } else {
/* 218 */             writer.writeAttribute("style", tdStyle, null);
/*     */           }
/*     */         }
/* 221 */         else if (style != null) {
/* 222 */           writer.writeAttribute("style", style, null);
/*     */         }
/*     */         
/*     */ 
/* 226 */         if (column.getColspan() > 1) {
/* 227 */           writer.writeAttribute("colspan", Integer.valueOf(column.getColspan()), null);
/*     */         }
/*     */         
/* 230 */         if (column.getRowspan() > 1) {
/* 231 */           writer.writeAttribute("rowspan", Integer.valueOf(column.getRowspan()), null);
/*     */         }
/*     */         
/* 234 */         renderChildren(context, column);
/*     */         
/* 236 */         writer.endElement("td");
/*     */       }
/*     */     }
/*     */     
/* 240 */     writer.endElement("tr");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void renderChildren(FacesContext context, UIComponent component)
/*     */     throws IOException
/*     */   {
/* 253 */     if (component.getChildCount() > 0) {
/* 254 */       for (int i = 0; i < component.getChildCount(); i++) {
/* 255 */         UIComponent child = (UIComponent)component.getChildren().get(i);
/* 256 */         if (((child instanceof CfwTableLayout)) && (child.isRendered())) {
/* 257 */           CfwTableLayout cfwTableLayout = (CfwTableLayout)child;
/*     */           
/* 259 */           String styleClass = "display:inline-table;" + cfwTableLayout.getStyleClass();
/* 260 */           cfwTableLayout.setStyle(styleClass);
/*     */         }
/* 262 */         renderChild(context, child);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String createTrStyle(Row row)
/*     */   {
/* 274 */     CfwTr tr = (CfwTr)row;
/* 275 */     String style = "";
/*     */     
/* 277 */     CfwComponentUtils utils = CfwComponentUtils.getInstance();
/* 278 */     String align = getStyleAlign(tr.getAlign());
/* 279 */     if (!FwStringValidator.isEmpty(align)) {
/* 280 */       style = utils.addStyle(style, align);
/*     */     }
/* 282 */     return "".equals(style) ? null : style;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String createTdStyle(Column column)
/*     */   {
/* 292 */     CfwTd td = (CfwTd)column;
/* 293 */     String style = "";
/*     */     
/* 295 */     CfwComponentUtils utils = CfwComponentUtils.getInstance();
/*     */     
/* 297 */     String width = getStyleWidth(td.getWidth());
/* 298 */     if (!FwStringValidator.isEmpty(width)) {
/* 299 */       style = utils.addStyle(style, width);
/*     */     }
/*     */     
/* 302 */     String height = getStyleHeight(td.getHeight());
/* 303 */     if (!FwStringValidator.isEmpty(height)) {
/* 304 */       style = utils.addStyle(style, height);
/*     */     }
/*     */     
/* 307 */     String align = getStyleAlign(td.getAlign());
/* 308 */     if (!FwStringValidator.isEmpty(align)) {
/* 309 */       style = utils.addStyle(style, align);
/*     */     }
/*     */     
/* 312 */     String valign = getStyleValign(td.getValign());
/* 313 */     if (!FwStringValidator.isEmpty(valign)) {
/* 314 */       style = utils.addStyle(style, valign);
/*     */     }
/*     */     
/*     */ 
/* 318 */     String bgColor = "";
/* 319 */     if (FwStringValidator.isEmpty(td.getBgcolor())) {
/* 320 */       if (FwStringValidator.isEmpty(getTrColor())) {
/* 321 */         bgColor = getStyleBgColor(getTableBgcolor());
/*     */       } else {
/* 323 */         bgColor = getStyleBgColor(getTrColor());
/*     */       }
/*     */     } else {
/* 326 */       bgColor = getStyleBgColor(td.getBgcolor());
/*     */     }
/* 328 */     if (!FwStringValidator.isEmpty(bgColor)) {
/* 329 */       style = utils.addStyle(style, bgColor);
/*     */     }
/* 331 */     return "".equals(style) ? null : style;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getStyleValign(String valign)
/*     */   {
/* 340 */     String style = "";
/* 341 */     CfwComponentUtils utils = CfwComponentUtils.getInstance();
/* 342 */     if (!FwStringValidator.isEmpty(valign)) {
/* 343 */       style = utils.addStyle(style, "vertical-align", valign);
/*     */     }
/* 345 */     return "".equals(style) ? null : style;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getStyleAlign(String align)
/*     */   {
/* 354 */     String style = "";
/* 355 */     CfwComponentUtils utils = CfwComponentUtils.getInstance();
/* 356 */     if (!FwStringValidator.isEmpty(align)) {
/* 357 */       style = utils.addStyle(style, "text-align", align);
/*     */     }
/* 359 */     return "".equals(style) ? null : style;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getStyleHeight(String value)
/*     */   {
/* 368 */     String style = "";
/* 369 */     CfwComponentUtils utils = CfwComponentUtils.getInstance();
/* 370 */     String height = utils.toHeight(value);
/* 371 */     if (!FwStringValidator.isEmpty(height)) {
/* 372 */       style = utils.addStyle(style, "height", height);
/*     */     }
/* 374 */     return "".equals(style) ? null : style;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getStyleWidth(String value)
/*     */   {
/* 383 */     String style = "";
/* 384 */     CfwComponentUtils utils = CfwComponentUtils.getInstance();
/* 385 */     String width = utils.toWidth(value);
/* 386 */     if (!FwStringValidator.isEmpty(width)) {
/* 387 */       style = utils.addStyle(style, "width", width);
/*     */     }
/* 389 */     return "".equals(style) ? null : style;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getStyleBgColor(String bgColor)
/*     */   {
/* 398 */     String style = "";
/* 399 */     CfwComponentUtils utils = CfwComponentUtils.getInstance();
/* 400 */     if (!FwStringValidator.isEmpty(bgColor)) {
/* 401 */       style = utils.addStyle(style, "background-color", bgColor);
/*     */     }
/* 403 */     return "".equals(style) ? null : style;
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwTableLayoutRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */