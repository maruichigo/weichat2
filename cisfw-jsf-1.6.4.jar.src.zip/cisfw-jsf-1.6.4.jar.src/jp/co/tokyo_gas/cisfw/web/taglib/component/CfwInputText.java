/*     */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.faces.application.ResourceDependencies;
/*     */ import javax.faces.component.FacesComponent;
/*     */ import javax.faces.component.StateHelper;
/*     */ import javax.faces.context.FacesContext;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.taglib.input.FwInputText;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.message.FwMessage;
/*     */ import jp.co.tokyo_gas.cisfw.web.taglib.converter.CfwInputTextConverter;
/*     */ import jp.co.tokyo_gas.cisfw.web.taglib.validator.CfwLengthValidator;
/*     */ import jp.co.tokyo_gas.cisfw.web.taglib.validator.CfwRegexValidator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ResourceDependencies({@javax.faces.application.ResourceDependency(library="primefaces", name="primefaces.css"), @javax.faces.application.ResourceDependency(library="primefaces", name="jquery/jquery.js"), @javax.faces.application.ResourceDependency(library="primefaces", name="primefaces.js"), @javax.faces.application.ResourceDependency(library="tgfw_js", name="tgfw.js")})
/*     */ @FacesComponent("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwInputText")
/*     */ public class CfwInputText
/*     */   extends FwInputText
/*     */ {
/*     */   public static final String BLUR = "blur";
/*     */   public static final String COMPONENT_TYPE = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwInputText";
/*     */   
/*     */   protected static enum PropertyKeys
/*     */   {
/*  60 */     width, 
/*     */     
/*     */ 
/*  63 */     validateMinLength, 
/*     */     
/*     */ 
/*  66 */     validateMaxLength, 
/*     */     
/*     */ 
/*  69 */     regex, 
/*     */     
/*     */ 
/*  72 */     padding, 
/*     */     
/*     */ 
/*  75 */     paddingType, 
/*     */     
/*     */ 
/*  78 */     paddingLength, 
/*     */     
/*     */ 
/*  81 */     messageParam, 
/*     */     
/*     */ 
/*  84 */     patternKey, 
/*     */     
/*     */ 
/*  87 */     top, 
/*     */     
/*     */ 
/*  90 */     right, 
/*     */     
/*     */ 
/*  93 */     bottom, 
/*     */     
/*     */ 
/*  96 */     left, 
/*     */     
/*     */ 
/*  99 */     uppercase;
/*     */     
/*     */     String toString;
/*     */     
/*     */     private PropertyKeys(String toString) {
/* 104 */       this.toString = toString;
/*     */     }
/*     */     
/*     */ 
/*     */     private PropertyKeys() {}
/*     */     
/*     */ 
/*     */     public String toString()
/*     */     {
/* 113 */       return this.toString != null ? this.toString : super.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWidth(String width)
/*     */   {
/* 122 */     getStateHelper().put(PropertyKeys.width, width);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getWidth()
/*     */   {
/* 130 */     return (String)getStateHelper().eval(PropertyKeys.width, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValidateMinLength(String validateMinLength)
/*     */   {
/* 138 */     getStateHelper().put(PropertyKeys.validateMinLength, validateMinLength);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getValidateMinLength()
/*     */   {
/* 146 */     return (String)getStateHelper().eval(PropertyKeys.validateMinLength, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValidateMaxLength(String validateMaxLength)
/*     */   {
/* 154 */     getStateHelper().put(PropertyKeys.validateMaxLength, validateMaxLength);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getValidateMaxLength()
/*     */   {
/* 162 */     return (String)getStateHelper().eval(PropertyKeys.validateMaxLength, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRegex(String regex)
/*     */   {
/* 170 */     getStateHelper().put(PropertyKeys.regex, regex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRegex()
/*     */   {
/* 178 */     return (String)getStateHelper().eval(PropertyKeys.regex, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPadding(Character padding)
/*     */   {
/* 186 */     getStateHelper().put(PropertyKeys.padding, padding);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Character getPadding()
/*     */   {
/* 194 */     return (Character)getStateHelper().eval(PropertyKeys.padding, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPaddingType(String paddingType)
/*     */   {
/* 202 */     getStateHelper().put(PropertyKeys.paddingType, paddingType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPaddingType()
/*     */   {
/* 210 */     return (String)getStateHelper().eval(PropertyKeys.paddingType, "right");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPaddingLength(String paddingLength)
/*     */   {
/* 218 */     getStateHelper().put(PropertyKeys.paddingLength, paddingLength);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPaddingLength()
/*     */   {
/* 226 */     return (String)getStateHelper().eval(PropertyKeys.paddingLength, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMessageParam(String messageParam)
/*     */   {
/* 234 */     getStateHelper().put(PropertyKeys.messageParam, messageParam);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessageParam()
/*     */   {
/* 242 */     return (String)getStateHelper().eval(PropertyKeys.messageParam, "値");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPatternKey(String patternKey)
/*     */   {
/* 251 */     getStateHelper().put(PropertyKeys.patternKey, patternKey);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPatternKey()
/*     */   {
/* 260 */     return (String)getStateHelper().eval(PropertyKeys.patternKey, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTop()
/*     */   {
/* 268 */     return (String)getStateHelper().eval(PropertyKeys.top, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTop(String top)
/*     */   {
/* 276 */     getStateHelper().put(PropertyKeys.top, top);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRight()
/*     */   {
/* 284 */     return (String)getStateHelper().eval(PropertyKeys.right, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRight(String right)
/*     */   {
/* 292 */     getStateHelper().put(PropertyKeys.right, right);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBottom()
/*     */   {
/* 300 */     return (String)getStateHelper().eval(PropertyKeys.bottom, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBottom(String bottom)
/*     */   {
/* 308 */     getStateHelper().put(PropertyKeys.bottom, bottom);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLeft()
/*     */   {
/* 316 */     return (String)getStateHelper().eval(PropertyKeys.left, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLeft(String left)
/*     */   {
/* 324 */     getStateHelper().put(PropertyKeys.left, left);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUppercase(String uppercase)
/*     */   {
/* 332 */     getStateHelper().put(PropertyKeys.uppercase, uppercase);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUppercase()
/*     */   {
/* 340 */     return (String)getStateHelper().eval(PropertyKeys.uppercase, "true");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validateValue(FacesContext context, Object newValue)
/*     */   {
/* 352 */     String max = getValidateMaxLength();
/* 353 */     String min = getValidateMinLength();
/*     */     
/* 355 */     CfwLengthValidator lengthValidator = new CfwLengthValidator();
/*     */     
/* 357 */     if ((max != null) || (min != null)) {
/* 358 */       if (max != null) {
/* 359 */         lengthValidator.setMaximum(Integer.parseInt(max));
/*     */       }
/*     */       
/* 362 */       if (min != null) {
/* 363 */         lengthValidator.setMinimum(Integer.parseInt(min));
/*     */       }
/*     */       
/* 366 */       super.addValidator(lengthValidator);
/*     */     }
/*     */     
/*     */ 
/* 370 */     String regex = getRegex();
/*     */     
/* 372 */     CfwRegexValidator regexValidator = new CfwRegexValidator();
/*     */     
/* 374 */     if ((regex != null) && (regex.length() != 0)) {
/* 375 */       regexValidator.setPattern(regex);
/* 376 */       super.addValidator(regexValidator);
/*     */     }
/*     */     
/*     */ 
/* 380 */     super.validateValue(context, newValue);
/*     */     
/*     */ 
/* 383 */     super.removeValidator(lengthValidator);
/* 384 */     super.removeValidator(regexValidator);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void encodeEnd(FacesContext context)
/*     */     throws IOException
/*     */   {
/* 393 */     if (isRendered())
/*     */     {
/*     */ 
/* 396 */       setAjaxValidator(Boolean.valueOf(true));
/*     */       
/* 398 */       CfwComponentUtils utils = CfwComponentUtils.getInstance();
/*     */       
/*     */ 
/* 401 */       setStyle(utils.addStyle(getStyle(), "width", utils.toWidth(getWidth(), -10)));
/*     */       
/*     */ 
/* 404 */       String margin = utils.createMarginStyle(getTop(), getRight(), getBottom(), getLeft());
/* 405 */       setStyle(utils.addStyle(getStyle(), margin));
/*     */       
/*     */ 
/* 408 */       if ("rtl".equals(getDir())) {
/* 409 */         setDir(null);
/* 410 */         setStyle(utils.addStyle(getStyle(), "text-align", "right"));
/*     */       }
/*     */       
/*     */ 
/* 414 */       setConverter(new CfwInputTextConverter());
/*     */       
/*     */ 
/* 417 */       String code = utils.isDescendantOfCfwGrid(this) ? "CXXM90001E" : "CXXM90000E";
/* 418 */       setRequiredMessage(FwMessage.getInstance().getMessage(code, new Object[] { getMessageParam() }));
/*     */     }
/*     */     
/* 421 */     super.encodeEnd(context);
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwInputText.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */