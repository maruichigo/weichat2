/*     */ package jp.co.tokyo_gas.cisfw.web.taglib.converter;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.faces.application.FacesMessage;
/*     */ import javax.faces.component.UIComponent;
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.faces.convert.Converter;
/*     */ import javax.faces.convert.ConverterException;
/*     */ import javax.faces.convert.FacesConverter;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.message.FwMessage;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.string.FwStringValidator;
/*     */ import jp.co.tokyo_gas.cisfw.web.taglib.component.CfwComponentUtils;
/*     */ import jp.co.tokyo_gas.cisfw.web.taglib.component.CfwInputDateTime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FacesConverter("cisfw.faces.cfwInputDateTime")
/*     */ public class CfwInputDateTimeConverter
/*     */   implements Converter
/*     */ {
/*     */   public static final String CONVERTER_ID = "cisfw.faces.cfwInputDateTime";
/*  34 */   private boolean isYYYYMMDD = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getAsObject(FacesContext context, UIComponent component, String value)
/*     */   {
/*  45 */     if (FwStringValidator.isEmpty(value)) {
/*  46 */       throw new ConverterException("value is empty");
/*     */     }
/*     */     
/*  49 */     CfwInputDateTime dateTime = (CfwInputDateTime)component;
/*     */     
/*     */ 
/*  52 */     String patternVal = (String)component.getAttributes().get("pattern");
/*  53 */     if (FwStringValidator.isEmpty(patternVal))
/*     */     {
/*  55 */       this.isYYYYMMDD = true;
/*  56 */       patternVal = "yyyy/MM/dd";
/*     */     } else {
/*  58 */       this.isYYYYMMDD = patternVal.contains("dd");
/*     */     }
/*     */     
/*     */ 
/*  62 */     String submittedValue = getDateStr(value);
/*     */     
/*  64 */     SimpleDateFormat format = new SimpleDateFormat(dateTime.calculatePattern(), dateTime.calculateLocale(context));
/*  65 */     format.setLenient(false);
/*  66 */     format.setTimeZone(dateTime.calculateTimeZone());
/*     */     
/*     */     try
/*     */     {
/*  70 */       return format.parse(submittedValue);
/*     */     }
/*     */     catch (ParseException e)
/*     */     {
/*  74 */       dateTime.setConversionFailed(true);
/*     */       
/*  76 */       String msgId = null;
/*  77 */       CfwComponentUtils utils = CfwComponentUtils.getInstance();
/*  78 */       if (this.isYYYYMMDD)
/*     */       {
/*  80 */         msgId = utils.isDescendantOfCfwGrid(dateTime) ? "CXXM90025E" : "CXXM90024E";
/*     */       } else {
/*  82 */         msgId = utils.isDescendantOfCfwGrid(dateTime) ? "CXXM90064E" : "CXXM90063E";
/*     */       }
/*     */       
/*     */ 
/*  86 */       throw new ConverterException(new FacesMessage(FacesMessage.SEVERITY_ERROR, FwMessage.getInstance().getMessage(msgId, new Object[] { dateTime.getMessageParam() }), null));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAsString(FacesContext context, UIComponent component, Object value)
/*     */   {
/* 102 */     if (value == null) {
/* 103 */       throw new ConverterException("value is null");
/*     */     }
/*     */     
/* 106 */     CfwInputDateTime dateTime = (CfwInputDateTime)component;
/* 107 */     SimpleDateFormat dateFormat = new SimpleDateFormat(dateTime.calculatePattern(), dateTime.calculateLocale(context));
/* 108 */     dateFormat.setTimeZone(dateTime.calculateTimeZone());
/*     */     
/* 110 */     return dateFormat.format(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getDateStr(String value)
/*     */   {
/* 120 */     StringBuilder builder = new StringBuilder(value);
/*     */     
/*     */ 
/* 123 */     if (Pattern.compile("^\\d{8}$").matcher(value).matches()) {
/* 124 */       return builder.insert(4, '/').insert(7, '/').toString();
/*     */     }
/*     */     
/*     */ 
/* 128 */     if (Pattern.compile("^\\d{6}$").matcher(value).matches()) {
/* 129 */       return builder.insert(4, '/').toString();
/*     */     }
/*     */     
/* 132 */     return String.valueOf(value);
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\converter\CfwInputDateTimeConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */