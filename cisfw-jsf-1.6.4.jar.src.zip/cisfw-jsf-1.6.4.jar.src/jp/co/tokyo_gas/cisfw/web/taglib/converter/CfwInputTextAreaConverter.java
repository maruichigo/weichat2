/*    */ package jp.co.tokyo_gas.cisfw.web.taglib.converter;
/*    */ 
/*    */ import java.util.Map;
/*    */ import javax.faces.component.UIComponent;
/*    */ import javax.faces.context.FacesContext;
/*    */ import javax.faces.convert.Converter;
/*    */ import javax.faces.convert.FacesConverter;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.string.FwStringValidator;
/*    */ import jp.co.tokyo_gas.cisfw.utils.CfwStringConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FacesConverter("cisfw.faces.cfwInputTextArea")
/*    */ public class CfwInputTextAreaConverter
/*    */   implements Converter
/*    */ {
/*    */   public static final String CONVERTER_ID = "cisfw.faces.cfwInputTextArea";
/*    */   public static final String CRLF_REGEX = "\r\n|\r|\n";
/*    */   
/*    */   public Object getAsObject(FacesContext context, UIComponent component, String value)
/*    */   {
/* 39 */     boolean isRemoveLineFeed = ((Boolean)component.getAttributes().get("removeLineFeed")).booleanValue();
/* 40 */     boolean isUppercase = ((Boolean)component.getAttributes().get("uppercase")).booleanValue();
/*    */     
/*    */ 
/* 43 */     if (!FwStringValidator.isEmpty(value)) {
/* 44 */       if (isRemoveLineFeed) {
/* 45 */         value = value.replaceAll("\r\n|\r|\n", "");
/*    */       }
/*    */       
/*    */ 
/* 49 */       if (isUppercase) {
/* 50 */         value = CfwStringConverter.replaceAlphaHalfToUpperCase(value);
/*    */       }
/*    */     }
/*    */     
/* 54 */     return value;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getAsString(FacesContext context, UIComponent component, Object value)
/*    */   {
/* 67 */     return String.valueOf(value);
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\converter\CfwInputTextAreaConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */