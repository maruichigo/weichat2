/*     */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.faces.application.ResourceDependencies;
/*     */ import javax.faces.component.FacesComponent;
/*     */ import javax.faces.component.StateHelper;
/*     */ import javax.faces.context.FacesContext;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.taglib.input.FwInputNumber;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.message.FwMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FacesComponent("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwInputNumber")
/*     */ @ResourceDependencies({@javax.faces.application.ResourceDependency(library="primefaces", name="primefaces.css"), @javax.faces.application.ResourceDependency(library="primefaces", name="jquery/jquery.js"), @javax.faces.application.ResourceDependency(library="primefaces", name="primefaces.js"), @javax.faces.application.ResourceDependency(library="primefaces", name="jquery/jquery-plugins.js"), @javax.faces.application.ResourceDependency(library="tgfw_js", name="tgfw.js"), @javax.faces.application.ResourceDependency(library="js", name="cisfw-component.js")})
/*     */ public class CfwInputNumber
/*     */   extends FwInputNumber
/*     */ {
/*     */   public static final String COMPONENT_TYPE = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwInputNumber";
/*     */   public static final String COMPONENT_FAMILY = "jp.co.tokyo_gas.cisfw";
/*     */   public static final String DEFAULT_RENDERER = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwInputNumberRenderer";
/*     */   
/*     */   protected static enum PropertyKeys
/*     */   {
/*  56 */     width, 
/*     */     
/*     */ 
/*  59 */     messageParam, 
/*     */     
/*     */ 
/*  62 */     top, 
/*     */     
/*     */ 
/*  65 */     right, 
/*     */     
/*     */ 
/*  68 */     bottom, 
/*     */     
/*     */ 
/*  71 */     left;
/*     */     
/*     */     String toString;
/*     */     
/*     */     private PropertyKeys(String toString) {
/*  76 */       this.toString = toString;
/*     */     }
/*     */     
/*     */ 
/*     */     private PropertyKeys() {}
/*     */     
/*     */ 
/*     */     public String toString()
/*     */     {
/*  85 */       return this.toString != null ? this.toString : super.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public CfwInputNumber()
/*     */   {
/*  93 */     setRendererType("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwInputNumberRenderer");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFamily()
/*     */   {
/* 102 */     return "jp.co.tokyo_gas.cisfw";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWidth(String width)
/*     */   {
/* 110 */     getStateHelper().put(PropertyKeys.width, width);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getWidth()
/*     */   {
/* 118 */     return (String)getStateHelper().eval(PropertyKeys.width, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMessageParam(String messageParam)
/*     */   {
/* 126 */     getStateHelper().put(PropertyKeys.messageParam, messageParam);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessageParam()
/*     */   {
/* 134 */     return (String)getStateHelper().eval(PropertyKeys.messageParam, "値");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTop()
/*     */   {
/* 142 */     return (String)getStateHelper().eval(PropertyKeys.top, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTop(String top)
/*     */   {
/* 150 */     getStateHelper().put(PropertyKeys.top, top);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRight()
/*     */   {
/* 158 */     return (String)getStateHelper().eval(PropertyKeys.right, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRight(String right)
/*     */   {
/* 166 */     getStateHelper().put(PropertyKeys.right, right);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBottom()
/*     */   {
/* 174 */     return (String)getStateHelper().eval(PropertyKeys.bottom, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBottom(String bottom)
/*     */   {
/* 182 */     getStateHelper().put(PropertyKeys.bottom, bottom);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLeft()
/*     */   {
/* 190 */     return (String)getStateHelper().eval(PropertyKeys.left, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLeft(String left)
/*     */   {
/* 198 */     getStateHelper().put(PropertyKeys.left, left);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void encodeEnd(FacesContext context)
/*     */     throws IOException
/*     */   {
/* 207 */     if (isRendered()) {
/* 208 */       CfwComponentUtils utils = CfwComponentUtils.getInstance();
/*     */       
/*     */ 
/* 211 */       setStyle(utils.addStyle(getStyle(), "line-height:0px;margin-bottom:3px;"));
/*     */       
/*     */ 
/* 214 */       setStyle(utils.addStyle(getStyle(), utils.createMarginStyle(getTop(), getRight(), getBottom(), getLeft())));
/*     */       
/* 216 */       FwMessage message = FwMessage.getInstance();
/* 217 */       String param = getMessageParam();
/*     */       
/*     */ 
/*     */ 
/* 221 */       String code = utils.isDescendantOfCfwGrid(this) ? "CXXM90001E" : "CXXM90000E";
/* 222 */       setRequiredMessage(message.getMessage(code, new Object[] { param }));
/*     */       
/*     */ 
/*     */ 
/* 226 */       String code2 = utils.isDescendantOfCfwGrid(this) ? "CXXM90045E" : "CXXM90044E";
/* 227 */       setConverterMessage(message.getMessage(code2, new Object[] { param }));
/*     */       
/*     */ 
/* 230 */       setAjaxValidator(Boolean.valueOf(true));
/*     */     }
/*     */     
/* 233 */     super.encodeEnd(context);
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwInputNumber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */