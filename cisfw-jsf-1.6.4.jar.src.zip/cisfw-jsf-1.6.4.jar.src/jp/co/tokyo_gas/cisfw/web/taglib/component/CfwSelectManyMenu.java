/*     */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.faces.application.Application;
/*     */ import javax.faces.application.ResourceDependencies;
/*     */ import javax.faces.component.FacesComponent;
/*     */ import javax.faces.component.StateHelper;
/*     */ import javax.faces.context.FacesContext;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.taglib.FwTaglibUtils;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.message.FwMessage;
/*     */ import org.primefaces.behavior.ajax.AjaxBehavior;
/*     */ import org.primefaces.component.selectmanymenu.SelectManyMenu;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ResourceDependencies({@javax.faces.application.ResourceDependency(library="primefaces", name="primefaces.css"), @javax.faces.application.ResourceDependency(library="primefaces", name="jquery/jquery.js"), @javax.faces.application.ResourceDependency(library="primefaces", name="primefaces.js")})
/*     */ @FacesComponent("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwSelectManyMenu")
/*     */ public class CfwSelectManyMenu
/*     */   extends SelectManyMenu
/*     */ {
/*     */   public static final String CHANGE = "change";
/*     */   public static final String COMPONENT_TYPE = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwSelectManyMenu";
/*     */   public static final String COMPONENT_FAMILY = "jp.co.tokyo_gas";
/*     */   public static final String DEFAULT_RENDERER = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwSelectManyMenuRenderer";
/*     */   
/*     */   public static enum PropertyKeys
/*     */   {
/*  60 */     filterBy, 
/*     */     
/*     */ 
/*  63 */     width, 
/*     */     
/*     */ 
/*  66 */     messageParam, 
/*     */     
/*     */ 
/*  69 */     top, 
/*     */     
/*     */ 
/*  72 */     right, 
/*     */     
/*     */ 
/*  75 */     bottom, 
/*     */     
/*     */ 
/*  78 */     left;
/*     */     
/*     */     String toString;
/*     */     
/*     */     private PropertyKeys(String toString) {
/*  83 */       this.toString = toString;
/*     */     }
/*     */     
/*     */ 
/*     */     private PropertyKeys() {}
/*     */     
/*     */ 
/*     */     public String toString()
/*     */     {
/*  92 */       return this.toString != null ? this.toString : super.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public CfwSelectManyMenu()
/*     */   {
/* 100 */     setRendererType("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwSelectManyMenuRenderer");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFamily()
/*     */   {
/* 110 */     return "jp.co.tokyo_gas";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFilterBy(String filterBy)
/*     */   {
/* 119 */     getStateHelper().put(PropertyKeys.filterBy, filterBy);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFilterBy()
/*     */   {
/* 128 */     return (String)getStateHelper().eval(PropertyKeys.filterBy, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWidth(String width)
/*     */   {
/* 137 */     getStateHelper().put(PropertyKeys.width, width);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getWidth()
/*     */   {
/* 146 */     return (String)getStateHelper().eval(PropertyKeys.width, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMessageParam(String messageParam)
/*     */   {
/* 155 */     getStateHelper().put(PropertyKeys.messageParam, messageParam);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessageParam()
/*     */   {
/* 164 */     return (String)getStateHelper().eval(PropertyKeys.messageParam, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTop()
/*     */   {
/* 173 */     return (String)getStateHelper().eval(PropertyKeys.top, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTop(String top)
/*     */   {
/* 182 */     getStateHelper().put(PropertyKeys.top, top);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRight()
/*     */   {
/* 191 */     return (String)getStateHelper().eval(PropertyKeys.right, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRight(String right)
/*     */   {
/* 200 */     getStateHelper().put(PropertyKeys.right, right);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBottom()
/*     */   {
/* 209 */     return (String)getStateHelper().eval(PropertyKeys.bottom, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBottom(String bottom)
/*     */   {
/* 218 */     getStateHelper().put(PropertyKeys.bottom, bottom);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLeft()
/*     */   {
/* 227 */     return (String)getStateHelper().eval(PropertyKeys.left, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLeft(String left)
/*     */   {
/* 236 */     getStateHelper().put(PropertyKeys.left, left);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void encodeEnd(FacesContext context)
/*     */     throws IOException
/*     */   {
/* 245 */     AjaxBehavior ajaxBehavior = null;
/*     */     
/* 247 */     if (isRendered())
/*     */     {
/*     */ 
/* 250 */       FwTaglibUtils.setDataFwAttribute(this, PropertyKeys.filterBy.toString(), getFilterBy());
/*     */       
/*     */ 
/* 253 */       setRequiredMessage(FwMessage.getInstance().getMessage("CXXM90000E", new Object[] { getMessageParam() }));
/*     */       
/* 255 */       CfwComponentUtils utils = CfwComponentUtils.getInstance();
/*     */       
/*     */ 
/* 258 */       setStyle(utils.addStyle(getStyle(), "display:inline-block;vertical-align:top;"));
/*     */       
/*     */ 
/* 261 */       setStyle(utils.addStyle(getStyle(), "width", utils.toWidth(getWidth(), -6)));
/*     */       
/*     */ 
/* 264 */       setStyle(utils.addStyle(getStyle(), utils.createMarginStyle(getTop(), getRight(), getBottom(), getLeft())));
/*     */       
/*     */ 
/* 267 */       String filterBy = getFilterBy();
/* 268 */       if (("label".equals(filterBy)) || ("condition".equals(filterBy)) || ("both".equals(filterBy))) {
/* 269 */         setFilter(true);
/*     */       }
/*     */       
/*     */ 
/* 273 */       if (((getClientBehaviors().get("change") == null) || (((List)getClientBehaviors().get("change")).size() == 0)) && 
/* 274 */         (getValueChangeListeners().length > 0)) {
/* 275 */         ajaxBehavior = (AjaxBehavior)context.getApplication().createBehavior("org.primefaces.component.AjaxBehavior");
/* 276 */         ajaxBehavior.setUpdate("@this");
/*     */         
/* 278 */         addClientBehavior("change", ajaxBehavior);
/*     */       }
/*     */     }
/*     */     
/* 282 */     super.encodeEnd(context);
/*     */     
/* 284 */     if (ajaxBehavior != null) {
/* 285 */       ((List)getClientBehaviors().get("change")).remove(ajaxBehavior);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwSelectManyMenu.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */