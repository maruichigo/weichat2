/*     */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.faces.application.Application;
/*     */ import javax.faces.application.ResourceDependencies;
/*     */ import javax.faces.component.FacesComponent;
/*     */ import javax.faces.component.StateHelper;
/*     */ import javax.faces.context.FacesContext;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.taglib.input.FwSelectManyCheckbox;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.message.FwMessage;
/*     */ import org.primefaces.behavior.ajax.AjaxBehavior;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ResourceDependencies({@javax.faces.application.ResourceDependency(library="primefaces", name="primefaces.css"), @javax.faces.application.ResourceDependency(library="primefaces", name="jquery/jquery.js"), @javax.faces.application.ResourceDependency(library="primefaces", name="primefaces.js"), @javax.faces.application.ResourceDependency(library="tgfw_js", name="tgfw.js"), @javax.faces.application.ResourceDependency(library="js", name="cisfw-component.js")})
/*     */ @FacesComponent("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwSelectManyCheckbox")
/*     */ public class CfwSelectManyCheckbox
/*     */   extends FwSelectManyCheckbox
/*     */ {
/*     */   public static final String CHANGE = "change";
/*     */   public static final String COMPONENT_TYPE = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwSelectManyCheckbox";
/*     */   
/*     */   public static enum PropertyKeys
/*     */   {
/*  53 */     messageParam, 
/*     */     
/*     */ 
/*  56 */     top, 
/*     */     
/*     */ 
/*  59 */     right, 
/*     */     
/*     */ 
/*  62 */     bottom, 
/*     */     
/*     */ 
/*  65 */     left;
/*     */     
/*     */     String toString;
/*     */     
/*     */     private PropertyKeys(String toString) {
/*  70 */       this.toString = toString;
/*     */     }
/*     */     
/*     */ 
/*     */     private PropertyKeys() {}
/*     */     
/*     */ 
/*     */     public String toString()
/*     */     {
/*  79 */       return this.toString != null ? this.toString : super.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMessageParam(String messageParam)
/*     */   {
/*  88 */     getStateHelper().put(PropertyKeys.messageParam, messageParam);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessageParam()
/*     */   {
/*  96 */     return (String)getStateHelper().eval(PropertyKeys.messageParam, "値");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTop()
/*     */   {
/* 104 */     return (String)getStateHelper().eval(PropertyKeys.top, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTop(String top)
/*     */   {
/* 112 */     getStateHelper().put(PropertyKeys.top, top);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRight()
/*     */   {
/* 120 */     return (String)getStateHelper().eval(PropertyKeys.right, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRight(String right)
/*     */   {
/* 128 */     getStateHelper().put(PropertyKeys.right, right);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBottom()
/*     */   {
/* 136 */     return (String)getStateHelper().eval(PropertyKeys.bottom, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBottom(String bottom)
/*     */   {
/* 144 */     getStateHelper().put(PropertyKeys.bottom, bottom);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLeft()
/*     */   {
/* 152 */     return (String)getStateHelper().eval(PropertyKeys.left, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLeft(String left)
/*     */   {
/* 160 */     getStateHelper().put(PropertyKeys.left, left);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void encodeEnd(FacesContext context)
/*     */     throws IOException
/*     */   {
/* 169 */     AjaxBehavior ajaxBehavior = null;
/*     */     
/* 171 */     if (isRendered())
/*     */     {
/* 173 */       CfwComponentUtils utils = CfwComponentUtils.getInstance();
/*     */       
/*     */ 
/* 176 */       setStyle(utils.addStyle(getStyle(), "display", "inline-block"));
/* 177 */       setStyle(utils.addStyle(getStyle(), "vertical-align", "middle"));
/*     */       
/*     */ 
/* 180 */       String margin = utils.createMarginStyle(getTop(), getRight(), getBottom(), getLeft());
/* 181 */       setStyle(utils.addStyle(getStyle(), margin));
/*     */       
/*     */ 
/* 184 */       setRequiredMessage(FwMessage.getInstance().getMessage("CXXM90000E", new Object[] { getMessageParam() }));
/*     */       
/*     */ 
/* 187 */       if (((getClientBehaviors().get("change") == null) || (((List)getClientBehaviors().get("change")).size() == 0)) && 
/* 188 */         (getValueChangeListeners().length > 0)) {
/* 189 */         ajaxBehavior = (AjaxBehavior)context.getApplication().createBehavior("org.primefaces.component.AjaxBehavior");
/* 190 */         ajaxBehavior.setUpdate("@this");
/*     */         
/* 192 */         addClientBehavior("change", ajaxBehavior);
/*     */       }
/*     */     }
/*     */     
/* 196 */     super.encodeEnd(context);
/*     */     
/* 198 */     if (ajaxBehavior != null) {
/* 199 */       ((List)getClientBehaviors().get("change")).remove(ajaxBehavior);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwSelectManyCheckbox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */