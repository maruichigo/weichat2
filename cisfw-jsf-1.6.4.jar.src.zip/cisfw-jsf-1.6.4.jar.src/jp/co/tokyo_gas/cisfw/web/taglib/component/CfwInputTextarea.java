/*     */ package jp.co.tokyo_gas.cisfw.web.taglib.component;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.faces.application.ResourceDependencies;
/*     */ import javax.faces.component.FacesComponent;
/*     */ import javax.faces.component.StateHelper;
/*     */ import javax.faces.context.FacesContext;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.converter.FwTrimConverter;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.taglib.input.FwInputTextarea;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.message.FwMessage;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.string.FwStringValidator;
/*     */ import jp.co.tokyo_gas.cisfw.web.taglib.converter.CfwInputTextAreaConverter;
/*     */ import jp.co.tokyo_gas.cisfw.web.taglib.validator.CfwLengthValidator;
/*     */ import org.primefaces.component.inputtextarea.InputTextarea.PropertyKeys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ResourceDependencies({@javax.faces.application.ResourceDependency(library="primefaces", name="primefaces.css"), @javax.faces.application.ResourceDependency(library="primefaces", name="jquery/jquery.js"), @javax.faces.application.ResourceDependency(library="primefaces", name="primefaces.js"), @javax.faces.application.ResourceDependency(library="primefaces", name="jquery/jquery-plugins.js"), @javax.faces.application.ResourceDependency(library="tgfw_js", name="tgfw.js")})
/*     */ @FacesComponent("jp.co.tokyo_gas.cisfw.web.taglib.component.CfwInputTextarea")
/*     */ public class CfwInputTextarea
/*     */   extends FwInputTextarea
/*     */ {
/*     */   public static final String COMPONENT_TYPE = "jp.co.tokyo_gas.cisfw.web.taglib.component.CfwInputTextarea";
/*     */   
/*     */   public static enum PropertyKeys
/*     */   {
/*  45 */     width, 
/*     */     
/*     */ 
/*  48 */     height, 
/*     */     
/*     */ 
/*  51 */     validateMinLength, 
/*     */     
/*     */ 
/*  54 */     validateMaxLength, 
/*     */     
/*     */ 
/*  57 */     messageParam, 
/*     */     
/*     */ 
/*  60 */     top, 
/*     */     
/*     */ 
/*  63 */     right, 
/*     */     
/*     */ 
/*  66 */     bottom, 
/*     */     
/*     */ 
/*  69 */     left, 
/*     */     
/*     */ 
/*  72 */     removeLineFeed, 
/*     */     
/*     */ 
/*  75 */     uppercase;
/*     */     
/*     */     String toString;
/*     */     
/*     */     private PropertyKeys(String toString) {
/*  80 */       this.toString = toString;
/*     */     }
/*     */     
/*     */ 
/*     */     private PropertyKeys() {}
/*     */     
/*     */ 
/*     */     public String toString()
/*     */     {
/*  89 */       return this.toString != null ? this.toString : super.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWidth(String width)
/*     */   {
/*  99 */     getStateHelper().put(PropertyKeys.width, width);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getWidth()
/*     */   {
/* 108 */     return (String)getStateHelper().eval(PropertyKeys.width, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHeight(String height)
/*     */   {
/* 117 */     getStateHelper().put(PropertyKeys.height, height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHeight()
/*     */   {
/* 126 */     return (String)getStateHelper().eval(PropertyKeys.height, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValidateMinLength(String validateMinLength)
/*     */   {
/* 135 */     getStateHelper().put(PropertyKeys.validateMinLength, validateMinLength);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getValidateMinLength()
/*     */   {
/* 144 */     return (String)getStateHelper().eval(PropertyKeys.validateMinLength, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValidateMaxLength(String validateMaxLength)
/*     */   {
/* 153 */     getStateHelper().put(PropertyKeys.validateMaxLength, validateMaxLength);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getValidateMaxLength()
/*     */   {
/* 162 */     return (String)getStateHelper().eval(PropertyKeys.validateMaxLength, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMessageParam(String messageParam)
/*     */   {
/* 171 */     getStateHelper().put(PropertyKeys.messageParam, messageParam);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessageParam()
/*     */   {
/* 180 */     return (String)getStateHelper().eval(PropertyKeys.messageParam, "値");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTop()
/*     */   {
/* 189 */     return (String)getStateHelper().eval(PropertyKeys.top, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTop(String top)
/*     */   {
/* 198 */     getStateHelper().put(PropertyKeys.top, top);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRight()
/*     */   {
/* 207 */     return (String)getStateHelper().eval(PropertyKeys.right, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRight(String right)
/*     */   {
/* 216 */     getStateHelper().put(PropertyKeys.right, right);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBottom()
/*     */   {
/* 225 */     return (String)getStateHelper().eval(PropertyKeys.bottom, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBottom(String bottom)
/*     */   {
/* 234 */     getStateHelper().put(PropertyKeys.bottom, bottom);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLeft()
/*     */   {
/* 243 */     return (String)getStateHelper().eval(PropertyKeys.left, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLeft(String left)
/*     */   {
/* 252 */     getStateHelper().put(PropertyKeys.left, left);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRemoveLineFeed()
/*     */   {
/* 261 */     return ((Boolean)getStateHelper().eval(PropertyKeys.removeLineFeed, Boolean.valueOf(true))).booleanValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRemoveLineFeed(boolean removeLineFeed)
/*     */   {
/* 270 */     getStateHelper().put(PropertyKeys.removeLineFeed, Boolean.valueOf(removeLineFeed));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isUppercase()
/*     */   {
/* 278 */     return ((Boolean)getStateHelper().eval(PropertyKeys.uppercase, Boolean.valueOf(true))).booleanValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUppercase(boolean uppercase)
/*     */   {
/* 286 */     getStateHelper().put(PropertyKeys.uppercase, Boolean.valueOf(uppercase));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAddLine()
/*     */   {
/* 296 */     return ((Boolean)getStateHelper().eval(InputTextarea.PropertyKeys.addLine, Boolean.valueOf(true))).booleanValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validateValue(FacesContext context, Object newValue)
/*     */   {
/* 306 */     String max = getValidateMaxLength();
/* 307 */     String min = getValidateMinLength();
/*     */     
/* 309 */     CfwLengthValidator lengthValidator = new CfwLengthValidator();
/*     */     
/* 311 */     if ((!FwStringValidator.isEmpty(max)) || (!FwStringValidator.isEmpty(min))) {
/* 312 */       if (!FwStringValidator.isEmpty(max)) {
/* 313 */         lengthValidator.setMaximum(Integer.parseInt(max));
/*     */       }
/*     */       
/* 316 */       if (!FwStringValidator.isEmpty(min)) {
/* 317 */         lengthValidator.setMinimum(Integer.parseInt(min));
/*     */       }
/*     */       
/* 320 */       super.addValidator(lengthValidator);
/*     */     }
/*     */     
/*     */ 
/* 324 */     super.validateValue(context, newValue);
/*     */     
/*     */ 
/* 327 */     super.removeValidator(lengthValidator);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void encodeEnd(FacesContext context)
/*     */     throws IOException
/*     */   {
/* 336 */     if (isRendered())
/*     */     {
/*     */ 
/* 339 */       setAjaxValidator(Boolean.valueOf(true));
/*     */       
/* 341 */       CfwComponentUtils utils = CfwComponentUtils.getInstance();
/*     */       
/*     */ 
/* 344 */       setStyle(utils.addStyle(getStyle(), "vertical-align", "top"));
/* 345 */       setStyle(utils.addStyle(getStyle(), "overflow", "auto"));
/*     */       
/*     */ 
/* 348 */       setStyle(utils.addStyle(getStyle(), "width", utils.toWidth(getWidth(), -10)));
/*     */       
/*     */ 
/* 351 */       setStyle(utils.addStyle(getStyle(), "height", utils.toHeight(getHeight(), -10)));
/*     */       
/*     */ 
/* 354 */       String margin = utils.createMarginStyle(getTop(), getRight(), getBottom(), getLeft());
/* 355 */       setStyle(utils.addStyle(getStyle(), margin));
/*     */       
/*     */ 
/* 358 */       if ("rtl".equals(getDir())) {
/* 359 */         setDir(null);
/* 360 */         setStyle(utils.addStyle(getStyle(), "text-align", "right"));
/*     */       }
/*     */       
/*     */ 
/* 364 */       String trim = getTrim();
/* 365 */       if (("right".equals(trim)) || ("left".equals(trim)) || ("both".equals(trim))) {
/* 366 */         FwTrimConverter converter = new FwTrimConverter();
/* 367 */         converter.setType(trim);
/*     */       }
/*     */       
/*     */ 
/* 371 */       setRequiredMessage(FwMessage.getInstance().getMessage("CXXM90000E", new Object[] { getMessageParam() }));
/*     */       
/*     */ 
/* 374 */       setAutoResize(false);
/*     */       
/*     */ 
/* 377 */       if ((isRemoveLineFeed()) || (isUppercase())) {
/* 378 */         setConverter(new CfwInputTextAreaConverter());
/*     */       }
/*     */     }
/*     */     
/* 382 */     super.encodeEnd(context);
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\taglib\component\CfwInputTextarea.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */