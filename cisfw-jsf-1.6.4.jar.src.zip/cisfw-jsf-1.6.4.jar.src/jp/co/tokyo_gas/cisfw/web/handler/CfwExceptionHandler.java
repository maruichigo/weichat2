/*     */ package jp.co.tokyo_gas.cisfw.web.handler;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.StringJoiner;
/*     */ import javax.enterprise.context.RequestScoped;
/*     */ import javax.faces.application.Application;
/*     */ import javax.faces.application.FacesMessage;
/*     */ import javax.faces.application.NavigationHandler;
/*     */ import javax.faces.application.ViewExpiredException;
/*     */ import javax.faces.component.UIComponent;
/*     */ import javax.faces.context.ExceptionHandler;
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.faces.event.ExceptionQueuedEvent;
/*     */ import javax.faces.event.ExceptionQueuedEventContext;
/*     */ import javax.inject.Inject;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.config.FwConfig;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.ee.exception.FwError;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.FwFacesContext;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.handler.FwExtendExceptionHandler;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.token.FwTokenViewException;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.string.FwStringValidator;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.tracking.FwTrackingIdManager;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.ws.client.FwWSClientTimeoutException;
/*     */ import jp.co.tokyo_gas.cisfw.exception.CfwApplicationException;
/*     */ import jp.co.tokyo_gas.cisfw.exception.CfwErrorMessage;
/*     */ import jp.co.tokyo_gas.cisfw.exception.CfwInvalidSessionException;
/*     */ import jp.co.tokyo_gas.cisfw.exception.CfwRuntimeException;
/*     */ import jp.co.tokyo_gas.cisfw.exception.CfwScreenCheckException;
/*     */ import jp.co.tokyo_gas.cisfw.logger.CfwLogger;
/*     */ import jp.co.tokyo_gas.cisfw.message.CfwMessageManager;
/*     */ import jp.co.tokyo_gas.cisfw.sql.CfwDBInfoManager;
/*     */ import jp.co.tokyo_gas.cisfw.utils.CfwStringValidator;
/*     */ import jp.co.tokyo_gas.cisfw.version.CfwVersionProperty;
/*     */ import jp.co.tokyo_gas.cisfw.web.CfwFlash;
/*     */ import jp.co.tokyo_gas.cisfw.web.CfwSession;
/*     */ import jp.co.tokyo_gas.cisfw.ws.CfwCommunicationLogInfoHolder;
/*     */ import org.apache.commons.beanutils.PropertyUtils;
/*     */ import org.apache.ibatis.exceptions.PersistenceException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @RequestScoped
/*     */ public class CfwExceptionHandler
/*     */   implements FwExtendExceptionHandler
/*     */ {
/*  64 */   public static String MESSAGE_ID_CONNECTION_TIMEOUT = "CXXM91001E";
/*     */   
/*     */ 
/*  67 */   public static String MESSAGE_ID_RESPONSE_TIMEOUT = "CXXM91001E";
/*     */   
/*     */ 
/*  70 */   public static String MESSAGE_ID_NOT_AUTH = "CXXM91002E";
/*     */   
/*     */ 
/*     */   private static final String SYSTEM_EXCEPTION = "CXXM99999E";
/*     */   
/*     */ 
/*  76 */   public static String PAGE_ID_TIMEOUT = "/timeout?faces-redirect=true";
/*     */   
/*     */ 
/*  79 */   public static String PAGE_ID_SESSION_INVALID = "/jsf/cfwSessioninvalid?faces-redirect=true";
/*     */   
/*     */ 
/*  82 */   public static String PAGE_ID_AUTH = "/jsf/cfwAutority?faces-redirect=true";
/*     */   
/*     */ 
/*  85 */   public static String PAGE_ID_TIME = "/jsf/cfwAvailable?faces-redirect=true";
/*     */   
/*     */ 
/*  88 */   public static String PAGE_ID_MAINT = "/jsf/cfwMaintenance?faces-redirect=true";
/*     */   
/*     */ 
/*     */   private static final String CIRIUS_KEY = "CIRIUS";
/*     */   
/*     */   @Inject
/*     */   private CfwLogger log;
/*     */   
/*     */   @Inject
/*     */   private CfwDBInfoManager manager;
/*     */   
/*     */   @Inject
/*     */   private CfwMessageManager messageManager;
/*     */   
/*     */   @Inject
/*     */   private CfwSession session;
/*     */   
/*     */   @Inject
/*     */   private CfwFlash flash;
/*     */   
/*     */   @Inject
/*     */   private FwTrackingIdManager trackingManager;
/*     */   
/* 111 */   private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
/*     */   
/*     */   @Inject
/*     */   private FwConfig config;
/*     */   
/*     */   @Inject
/*     */   private CfwCommunicationLogInfoHolder comInfoHolder;
/*     */   
/*     */   @Inject
/*     */   private CfwVersionProperty versionProperty;
/*     */   
/* 122 */   private boolean showLog = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handle(ExceptionHandler wrapper)
/*     */   {
/* 135 */     Iterator<ExceptionQueuedEvent> it = wrapper.getUnhandledExceptionQueuedEvents().iterator();
/* 136 */     if (CfwStringValidator.isEmpty(this.comInfoHolder.getMessageId())) {
/* 137 */       this.comInfoHolder.setMessageId("SUCCESS");
/*     */     }
/*     */     
/* 140 */     while (it.hasNext()) {
/* 141 */       ExceptionQueuedEventContext eventContext = ((ExceptionQueuedEvent)it.next()).getContext();
/*     */       
/*     */ 
/* 144 */       String clientId = "";
/*     */       try {
/* 146 */         clientId = eventContext.getComponent().getClientId();
/*     */       }
/*     */       catch (NullPointerException nu)
/*     */       {
/* 150 */         clientId = "cirius-framework-clientId";
/*     */       }
/*     */       
/*     */ 
/* 154 */       Throwable th = eventContext.getException();
/* 155 */       Throwable rootCause = wrapper.getRootCause(th);
/*     */       
/* 157 */       Throwable target = rootCause;
/*     */       
/* 159 */       if (rootCause != null) {
/* 160 */         Throwable cause = rootCause.getCause();
/* 161 */         if (cause == null) {
/* 162 */           th = rootCause;
/*     */         } else {
/* 164 */           th = wrapper.getRootCause(cause);
/*     */         }
/*     */       }
/*     */       
/* 168 */       this.showLog = true;
/*     */       String stacktrace;
/*     */       String versionsMessage;
/*     */       try {
/* 172 */         this.flash.putData("fw_date", sdf.format(new Date()));
/* 173 */         this.flash.putData("fw_trackingid", this.trackingManager.get());
/* 174 */         this.flash.putData("fw_companyName", this.config.get("company.name", "INET"));
/* 175 */         this.flash.putData("fw_companyTelephoneNumber", this.config.get("company.telephone", "XX-XXXX-XXXX"));
/*     */         
/* 177 */         String showStackTrace = this.config.get("show.stacktrace", "false");
/* 178 */         boolean show = Boolean.valueOf(showStackTrace).booleanValue();
/*     */         
/* 180 */         if (show) {
/* 181 */           StringWriter writer = new StringWriter();
/* 182 */           PrintWriter printwriter = new PrintWriter(writer);
/* 183 */           target.printStackTrace(printwriter);
/* 184 */           stacktrace = writer.toString();
/*     */           
/* 186 */           versionsMessage = createVersionsMessage();
/* 187 */           this.flash.putData("fw_stacktrace", versionsMessage + stacktrace);
/* 188 */           this.flash.putData("fw_stacktrace_rendered", this.config.get("show.stacktrace", "false"));
/*     */         }
/*     */       } catch (Exception e) {
/* 191 */         this.log.error("例外が発生しました。 ", e);
/*     */       }
/*     */       
/*     */ 
/* 195 */       if ((th instanceof FwWSClientTimeoutException)) {
/* 196 */         createMessage(MESSAGE_ID_CONNECTION_TIMEOUT, null, clientId);
/*     */         
/* 198 */         it.remove();
/*     */         
/* 200 */         toNextScreen(null);
/* 201 */         this.showLog = false;
/*     */       }
/*     */       
/*     */ 
/* 205 */       if ((th instanceof FwTokenViewException))
/*     */       {
/* 207 */         it.remove();
/*     */         
/* 209 */         toNextScreen(PAGE_ID_SESSION_INVALID);
/* 210 */         this.showLog = false;
/*     */       }
/*     */       
/*     */ 
/* 214 */       if ((th instanceof ViewExpiredException))
/*     */       {
/* 216 */         it.remove();
/*     */         
/* 218 */         toNextScreen(PAGE_ID_TIMEOUT);
/* 219 */         this.showLog = false;
/*     */       }
/*     */       
/*     */ 
/* 223 */       if ((th instanceof CfwInvalidSessionException))
/*     */       {
/* 225 */         it.remove();
/*     */         
/* 227 */         toNextScreen(PAGE_ID_SESSION_INVALID);
/* 228 */         this.showLog = false;
/*     */       }
/*     */       
/*     */ 
/* 232 */       if ((th instanceof CfwScreenCheckException))
/*     */       {
/* 234 */         it.remove();
/*     */         
/* 236 */         CfwScreenCheckException cse = (CfwScreenCheckException)th;
/*     */         
/* 238 */         if (cse.getErrorKind() == 3) {
/* 239 */           toNextScreen(PAGE_ID_AUTH);
/*     */         }
/* 241 */         else if (cse.getErrorKind() == 1) {
/* 242 */           toNextScreen(PAGE_ID_TIME);
/*     */         }
/*     */         else {
/* 245 */           toNextScreen(PAGE_ID_MAINT);
/*     */         }
/*     */         
/*     */ 
/* 249 */         this.showLog = false;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 254 */       String thMessage = th.getMessage();
/*     */       
/* 256 */       boolean isSoapPersitence = (!FwStringValidator.isEmpty(thMessage)) && (thMessage.contains("PersistenceException"));
/* 257 */       String code; if ((isSoapPersitence) || ((th instanceof PersistenceException)))
/*     */       {
/* 259 */         String sqlErrCodes = this.manager.get("datasource.authority.sqlerr");
/* 260 */         if (sqlErrCodes != null) {
/* 261 */           boolean hasErrorCode = false;
/* 262 */           stacktrace = sqlErrCodes.split(",");versionsMessage = stacktrace.length; for (String str1 = 0; str1 < versionsMessage; str1++) { code = stacktrace[str1];
/* 263 */             if (thMessage.contains(code.trim())) {
/* 264 */               hasErrorCode = true;
/*     */             }
/*     */           }
/* 267 */           if (hasErrorCode) {
/* 268 */             createMessage(MESSAGE_ID_NOT_AUTH, null, clientId);
/*     */             
/* 270 */             it.remove();
/*     */             
/* 272 */             toNextScreen(null);
/*     */             
/* 274 */             this.showLog = false;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 279 */       if ((th instanceof CfwApplicationException))
/*     */       {
/* 281 */         CfwApplicationException cfwEx = (CfwApplicationException)th;
/*     */         
/* 283 */         CfwErrorMessage[] cfwErrorMessage = cfwEx.getCfwErrorMessage();
/* 284 */         StringJoiner joiner = new StringJoiner(",");
/* 285 */         versionsMessage = cfwErrorMessage;String str2 = versionsMessage.length; for (code = 0; code < str2; code++) { CfwErrorMessage message = versionsMessage[code];
/* 286 */           joiner.add(message.getErrorCode());
/*     */         }
/* 288 */         this.comInfoHolder.setMessageId(String.valueOf(joiner));
/*     */         
/*     */         try
/*     */         {
/* 292 */           checkSystemException(cfwEx);
/* 293 */           this.showLog = false;
/*     */           
/* 295 */           addMessage(cfwEx, clientId);
/*     */         } catch (Exception e) {
/* 297 */           this.log.error("例外が発生しました。 ", e);
/* 298 */           toNextScreen("/error.xhtml?faces-redirect=true");
/*     */         }
/*     */         
/* 301 */         it.remove();
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */       try
/*     */       {
/* 309 */         Object faultObject = PropertyUtils.getProperty(th, "faultInfo");
/*     */         
/* 311 */         if (faultObject != null)
/*     */         {
/*     */ 
/* 314 */           String errorCode = (String)PropertyUtils.getProperty(faultObject, "errorCode");
/* 315 */           List<?> errorParams = (List)PropertyUtils.getProperty(faultObject, "errorParams");
/*     */           
/* 317 */           List<?> errors = (List)PropertyUtils.getProperty(faultObject, "cfwErrorMessage");
/*     */           
/*     */ 
/*     */ 
/* 321 */           checkSystemException(errors);
/*     */           
/* 323 */           this.showLog = false;
/*     */           
/*     */ 
/* 326 */           if ((errors != null) && (errors.size() > 0)) {
/* 327 */             createMessage(errors, clientId);
/*     */           } else {
/* 329 */             createMessage(errorCode, 
/* 330 */               (String[])errorParams.toArray(new String[0]), clientId);
/*     */           }
/*     */           
/*     */ 
/* 334 */           it.remove();
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*     */       catch (NoSuchMethodException exx) {}catch (Exception e)
/*     */       {
/* 341 */         it.remove();
/* 342 */         this.log.error("SOAPエラー情報の取得時に例外が発生しました。 ", e);
/* 343 */         toNextScreen("/error.xhtml?faces-redirect=true");
/*     */       }
/*     */       
/* 346 */       if (this.showLog) {
/* 347 */         this.comInfoHolder.setMessageId("ERROR");
/* 348 */         outputSessionLog();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void createMessage(List<?> errors, String clientId)
/*     */   {
/* 362 */     for (Object error : errors) {
/*     */       try {
/* 364 */         String errorCode = (String)PropertyUtils.getProperty(error, "errorCode");
/* 365 */         List<?> errorParams = (List)PropertyUtils.getProperty(error, "errorParams");
/* 366 */         createMessage(errorCode, (String[])errorParams.toArray(new String[0]), clientId);
/*     */       } catch (Exception e) {
/* 368 */         throw new CfwRuntimeException("エラーメッセージの取得に失敗しました。", e, new Object[0]);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void toNextScreen(String nextPage)
/*     */   {
/* 381 */     FacesContext facesContext = FacesContext.getCurrentInstance();
/* 382 */     NavigationHandler navigationHandler = facesContext.getApplication().getNavigationHandler();
/* 383 */     navigationHandler.handleNavigation(facesContext, null, nextPage);
/*     */     
/* 385 */     facesContext.renderResponse();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkSystemException(List<?> errors)
/*     */   {
/* 395 */     boolean sysException = false;
/*     */     try
/*     */     {
/* 398 */       List<String> messages = new ArrayList();
/* 399 */       for (Object error : errors) {
/* 400 */         String errorCode = (String)PropertyUtils.getProperty(error, "errorCode");
/* 401 */         List<?> errorParams = (List)PropertyUtils.getProperty(error, "errorParams");
/* 402 */         messages.add(this.messageManager.getMessage(errorCode, 
/* 403 */           (Object[])errorParams.toArray(new String[0])));
/*     */         
/* 405 */         if ("CXXM99999E".equals(errorCode)) {
/* 406 */           sysException = true;
/*     */         }
/*     */       }
/*     */       
/* 410 */       if (sysException) {
/* 411 */         throw new CfwRuntimeException(messages.toString(), new Object[0]);
/*     */       }
/*     */     }
/*     */     catch (IllegalAccessException|InvocationTargetException|NoSuchMethodException e) {
/* 415 */       throw new CfwRuntimeException("エラーメッセージの取得に失敗しました。", e, new Object[0]);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkSystemException(CfwApplicationException cfwApplicationException)
/*     */   {
/* 428 */     boolean sysException = false;
/* 429 */     List<String> messages = new ArrayList();
/*     */     
/* 431 */     CfwErrorMessage[] cfwErrorMessage = cfwApplicationException.getCfwErrorMessage();
/*     */     
/* 433 */     for (CfwErrorMessage error : cfwErrorMessage)
/*     */     {
/* 435 */       String errorCode = error.getErrorCode();
/* 436 */       String[] errorParams = error.getErrorParams();
/* 437 */       messages.add(this.messageManager.getMessage(errorCode, (Object[])errorParams));
/* 438 */       if ("CXXM99999E".equals(errorCode)) {
/* 439 */         sysException = true;
/*     */       }
/*     */     }
/*     */     
/* 443 */     if (sysException) {
/* 444 */       throw new CfwRuntimeException(messages.toString(), cfwApplicationException, new Object[0]);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void outputSessionLog()
/*     */   {
/* 452 */     if (this.session != null) {
/* 453 */       this.session.writeSession();
/*     */     }
/*     */     else
/*     */     {
/* 457 */       this.log.info("セッション情報が存在しないため、セッションログの出力はしません。");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addMessage(CfwApplicationException cfwApplicationException, String clientId)
/*     */   {
/* 469 */     FacesContext facesContext = FwFacesContext.getFacesContext();
/* 470 */     CfwErrorMessage[] errors = cfwApplicationException.getCfwErrorMessage();
/* 471 */     for (FwError error : errors) {
/* 472 */       String errorCode = error.getErrorCode();
/* 473 */       Object[] params = error.getErrorParams();
/* 474 */       String msg = this.messageManager.getMessage(errorCode, params);
/* 475 */       facesContext.addMessage(clientId, new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, null));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void createMessage(String errorCode, String[] errorParams, String clientId)
/*     */   {
/* 487 */     FacesContext facesContext = FwFacesContext.getFacesContext();
/*     */     
/* 489 */     String msg = "";
/* 490 */     if ((errorParams != null) && (errorParams.length > 0)) {
/* 491 */       msg = this.messageManager.getMessage(errorCode, (Object[])errorParams);
/*     */     } else {
/* 493 */       msg = this.messageManager.getMessage(errorCode, new Object[0]);
/*     */     }
/* 495 */     facesContext.addMessage(clientId, new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String createVersionsMessage()
/*     */   {
/* 504 */     Properties props = this.versionProperty.getProperties();
/* 505 */     if (props == null) {
/* 506 */       return "";
/*     */     }
/*     */     
/* 509 */     String separator = System.getProperty("line.separator");
/* 510 */     StringBuilder stringBuilder = new StringBuilder();
/*     */     
/* 512 */     String ciriusVersion = props.getProperty("CIRIUS");
/* 513 */     if (ciriusVersion != null) {
/* 514 */       stringBuilder.append(String.format("%s=%s", new Object[] { "CIRIUS", ciriusVersion }));
/* 515 */       stringBuilder.append(separator);
/*     */     }
/*     */     
/* 518 */     for (Map.Entry<?, ?> entry : props.entrySet())
/* 519 */       if (!"CIRIUS".equals(entry.getKey()))
/*     */       {
/*     */ 
/* 522 */         stringBuilder.append(String.format("%s=%s", new Object[] { entry.getKey(), entry.getValue() }));
/* 523 */         stringBuilder.append(separator);
/*     */       }
/* 525 */     return stringBuilder.toString();
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\handler\CfwExceptionHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */