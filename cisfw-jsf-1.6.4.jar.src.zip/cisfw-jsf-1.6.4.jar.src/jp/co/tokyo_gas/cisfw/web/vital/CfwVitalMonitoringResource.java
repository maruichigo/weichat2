/*    */ package jp.co.tokyo_gas.cisfw.web.vital;
/*    */ 
/*    */ import javax.enterprise.context.RequestScoped;
/*    */ import javax.inject.Inject;
/*    */ import javax.ws.rs.GET;
/*    */ import javax.ws.rs.Path;
/*    */ import javax.ws.rs.core.Response;
/*    */ import javax.ws.rs.core.Response.ResponseBuilder;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.rs.FwRSAutoRegister;
/*    */ import jp.co.tokyo_gas.cisfw.vital.CfwVitalMonitoringLogic;
/*    */ import jp.co.tokyo_gas.cisfw.vital.CfwVitalMonitoringLogic.VitalState;
/*    */ import jp.co.tokyo_gas.cisfw.web.CfwRest;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Path("/vital")
/*    */ @CfwRest
/*    */ @RequestScoped
/*    */ public class CfwVitalMonitoringResource
/*    */   implements FwRSAutoRegister
/*    */ {
/*    */   @Inject
/*    */   CfwVitalMonitoringLogic logic;
/*    */   
/*    */   @GET
/*    */   @Path("/")
/*    */   public Response execute()
/*    */   {
/* 38 */     CfwVitalMonitoringLogic.VitalState vitalState = this.logic.checkVital();
/* 39 */     Response.ResponseBuilder rb = Response.status(vitalState.getResponseCode());
/* 40 */     rb.type("text/plain; charset=UTF-8");
/* 41 */     rb.entity(vitalState.getMessage());
/* 42 */     return rb.build();
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\vital\CfwVitalMonitoringResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */