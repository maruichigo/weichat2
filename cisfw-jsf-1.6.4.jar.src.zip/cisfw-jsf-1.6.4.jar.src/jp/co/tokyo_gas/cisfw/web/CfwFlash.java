/*    */ package jp.co.tokyo_gas.cisfw.web;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import javax.enterprise.context.RequestScoped;
/*    */ import javax.faces.context.ExternalContext;
/*    */ import javax.faces.context.FacesContext;
/*    */ import javax.faces.context.Flash;
/*    */ import javax.faces.event.PhaseId;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @RequestScoped
/*    */ public class CfwFlash
/*    */   implements Serializable
/*    */ {
/*    */   public Object getData(String key)
/*    */   {
/* 38 */     return FacesContext.getCurrentInstance().getExternalContext().getFlash().get(key);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void putData(String key, Object value)
/*    */   {
/* 47 */     Flash flash = FacesContext.getCurrentInstance().getExternalContext().getFlash();
/* 48 */     flash.put(key, value);
/* 49 */     FacesContext context = FacesContext.getCurrentInstance();
/* 50 */     if ((!PhaseId.RENDER_RESPONSE.equals(context.getCurrentPhaseId())) && (context.isPostback())) {
/* 51 */       flash.keep(key);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\CfwFlash.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */