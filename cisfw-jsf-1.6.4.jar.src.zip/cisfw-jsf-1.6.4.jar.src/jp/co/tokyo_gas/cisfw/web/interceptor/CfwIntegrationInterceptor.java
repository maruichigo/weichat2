/*     */ package jp.co.tokyo_gas.cisfw.web.interceptor;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import javax.annotation.Priority;
/*     */ import javax.enterprise.context.Dependent;
/*     */ import javax.faces.component.UIViewRoot;
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.inject.Inject;
/*     */ import javax.interceptor.AroundInvoke;
/*     */ import javax.interceptor.Interceptor;
/*     */ import javax.interceptor.InvocationContext;
/*     */ import jp.co.tokyo_gas.cisfw.interceptor.CfwIntegration;
/*     */ import jp.co.tokyo_gas.cisfw.sql.CfwDBInfoHolder;
/*     */ import jp.co.tokyo_gas.cisfw.utils.CfwSOAPMessageHolder;
/*     */ import jp.co.tokyo_gas.cisfw.web.CfwSession;
/*     */ import jp.co.tokyo_gas.cisfw.web.CfwUserInfo;
/*     */ import jp.co.tokyo_gas.cisfw.ws.CfwCommunicationLogInfoHolder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Priority(900)
/*     */ @Dependent
/*     */ @Interceptor
/*     */ @CfwIntegration
/*     */ public class CfwIntegrationInterceptor
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   @Inject
/*     */   private CfwSOAPMessageHolder cfwSoapMessageHolder;
/*     */   @Inject
/*     */   private CfwCommunicationLogInfoHolder cfwCommunicationLogInfoHolder;
/*     */   @Inject
/*     */   private CfwDBInfoHolder cfwDBInfoHolder;
/*     */   @Inject
/*     */   private CfwSession session;
/*     */   
/*     */   @AroundInvoke
/*     */   Object invoke(InvocationContext ctx)
/*     */     throws Exception
/*     */   {
/*  64 */     this.cfwSoapMessageHolder.setDatasourceSwitch(this.cfwDBInfoHolder.getDatasourceSwitch());
/*     */     
/*     */ 
/*  67 */     this.cfwSoapMessageHolder.setStartFunctionId(this.cfwCommunicationLogInfoHolder.getStartFunctionId());
/*     */     
/*  69 */     if ((isGetUserInfoEnable()) && 
/*  70 */       (this.session.getUserInfo() != null))
/*     */     {
/*  72 */       CfwUserInfo userInfo = this.session.getUserInfo();
/*  73 */       this.cfwSoapMessageHolder.setAllowedAuthorityCd(userInfo.getAllowedAuthorityCd());
/*  74 */       this.cfwSoapMessageHolder.setCompCd(userInfo.getCompCd());
/*  75 */       this.cfwSoapMessageHolder.setCompKbn(userInfo.getCompKbn());
/*  76 */       this.cfwSoapMessageHolder.setDefaultNonUpdatableFlg(userInfo.getDefaultNonUpdatableFlg());
/*  77 */       this.cfwSoapMessageHolder.setDepartmentCd(userInfo.getDepartmentCd());
/*  78 */       this.cfwSoapMessageHolder.setDukeId(userInfo.getDukeId());
/*  79 */       this.cfwSoapMessageHolder.setNwPlaceCd(userInfo.getNwPlaceCd());
/*  80 */       this.cfwSoapMessageHolder.setOfficeCd(userInfo.getOfficeCd());
/*  81 */       this.cfwSoapMessageHolder.setWorkplaceCd(userInfo.getWorkplaceCd());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  87 */     return ctx.proceed();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean isGetUserInfoEnable()
/*     */   {
/*  96 */     FacesContext context = FacesContext.getCurrentInstance();
/*  97 */     if (context == null) {
/*  98 */       return false;
/*     */     }
/* 100 */     UIViewRoot viewRoot = context.getViewRoot();
/* 101 */     if (viewRoot == null) {
/* 102 */       return false;
/*     */     }
/* 104 */     String viewId = viewRoot.getViewId();
/* 105 */     if (viewId == null) {
/* 106 */       return false;
/*     */     }
/* 108 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\interceptor\CfwIntegrationInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */