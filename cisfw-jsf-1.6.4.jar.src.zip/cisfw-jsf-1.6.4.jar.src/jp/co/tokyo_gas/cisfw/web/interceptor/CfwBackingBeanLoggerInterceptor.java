/*    */ package jp.co.tokyo_gas.cisfw.web.interceptor;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.StringJoiner;
/*    */ import javax.annotation.Priority;
/*    */ import javax.enterprise.context.Dependent;
/*    */ import javax.inject.Inject;
/*    */ import javax.interceptor.AroundInvoke;
/*    */ import javax.interceptor.Interceptor;
/*    */ import javax.interceptor.InvocationContext;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.config.FwConfig;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.string.FwStringValidator;
/*    */ import jp.co.tokyo_gas.cisfw.logger.CfwLogger;
/*    */ import jp.co.tokyo_gas.cisfw.logger.impl.CfwLoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Priority(2010)
/*    */ @Dependent
/*    */ @CfwBackingBeanLogger
/*    */ @Interceptor
/*    */ public class CfwBackingBeanLoggerInterceptor
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   @Inject
/*    */   private FwConfig fwConfig;
/*    */   
/*    */   @AroundInvoke
/*    */   public Object invoke(InvocationContext ctx)
/*    */     throws Exception
/*    */   {
/* 50 */     boolean showLog = Boolean.parseBoolean(this.fwConfig.get("bb.methodlog", "false"));
/* 51 */     if (!showLog) {
/* 52 */       return ctx.proceed();
/*    */     }
/*    */     
/* 55 */     String className = ctx.getMethod().getDeclaringClass().getName();
/* 56 */     String methodName = ctx.getMethod().getName();
/* 57 */     Object[] parameters = ctx.getParameters();
/*    */     
/*    */ 
/* 60 */     if (!isShow(methodName)) {
/* 61 */       return ctx.proceed();
/*    */     }
/*    */     
/* 64 */     StringJoiner sj = new StringJoiner(",");
/* 65 */     for (Object parameter : parameters) {
/* 66 */       if (parameter != null) {
/* 67 */         sj.add(parameter.getClass().getName());
/*    */       }
/*    */     }
/*    */     
/* 71 */     CfwLogger log = CfwLoggerFactory.getFactory().createCfwLogger(className);
/*    */     try
/*    */     {
/* 74 */       log.debug("{}({}) - START", methodName, sj.toString());
/* 75 */       return ctx.proceed();
/*    */     } finally {
/* 77 */       log.debug("{}({}) - END", methodName, sj.toString());
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isShow(String methodName)
/*    */   {
/* 87 */     String excludes = this.fwConfig.get("bb.methodlog.excludes", "");
/*    */     
/* 89 */     boolean result = true;
/* 90 */     for (String exclude : excludes.split(",")) {
/* 91 */       String key = exclude.trim();
/* 92 */       if ((!FwStringValidator.isEmpty(key)) && (methodName.startsWith(key))) {
/* 93 */         result = false;
/* 94 */         break;
/*    */       }
/*    */     }
/*    */     
/* 98 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\interceptor\CfwBackingBeanLoggerInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */