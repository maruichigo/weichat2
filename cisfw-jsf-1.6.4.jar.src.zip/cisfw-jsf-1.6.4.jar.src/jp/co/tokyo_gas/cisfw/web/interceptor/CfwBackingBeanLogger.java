package jp.co.tokyo_gas.cisfw.web.interceptor;

import java.lang.annotation.Annotation;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.interceptor.InterceptorBinding;

@InterceptorBinding
@Target({java.lang.annotation.ElementType.TYPE, java.lang.annotation.ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
public @interface CfwBackingBeanLogger {}


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\interceptor\CfwBackingBeanLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */