/*    */ package jp.co.tokyo_gas.cisfw.web.upload;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CfwUploadedFileData
/*    */ {
/*    */   private String fileId;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private String name;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private long size;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getFileId()
/*    */   {
/* 29 */     return this.fileId;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setFileId(String fileId)
/*    */   {
/* 37 */     this.fileId = fileId;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getName()
/*    */   {
/* 45 */     return this.name;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setName(String name)
/*    */   {
/* 53 */     this.name = name;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public long getSize()
/*    */   {
/* 61 */     return this.size;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setSize(long size)
/*    */   {
/* 69 */     this.size = size;
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\upload\CfwUploadedFileData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */