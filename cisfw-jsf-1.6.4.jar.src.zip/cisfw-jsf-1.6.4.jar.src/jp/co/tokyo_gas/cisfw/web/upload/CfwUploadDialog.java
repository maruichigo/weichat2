/*     */ package jp.co.tokyo_gas.cisfw.web.upload;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.enterprise.context.SessionScoped;
/*     */ import javax.faces.context.ExternalContext;
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.faces.event.ActionEvent;
/*     */ import javax.inject.Inject;
/*     */ import javax.inject.Named;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.token.FwTokenUtils;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.string.FwStringValidator;
/*     */ import jp.co.tokyo_gas.cisfw.file.CfwTemporaryFileUtil;
/*     */ import org.primefaces.context.RequestContext;
/*     */ import org.primefaces.event.FileUploadEvent;
/*     */ import org.primefaces.model.UploadedFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Named("cfwUploadDialog")
/*     */ @SessionScoped
/*     */ public class CfwUploadDialog
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   @Inject
/*     */   private FwTokenUtils utils;
/*     */   private String title;
/*     */   private int fileLimit;
/*     */   private int sizeLimit;
/*     */   private String allowTypes;
/*     */   private List<CfwUploadedFileData> files;
/*     */   private int count;
/*     */   @Inject
/*     */   private CfwTemporaryFileUtil fileUtils;
/*     */   
/*     */   public void setUp()
/*     */   {
/*  71 */     this.title = "アップロード";
/*  72 */     this.sizeLimit = 10485760;
/*  73 */     this.fileLimit = 10;
/*  74 */     this.allowTypes = "/\\.(doc|docx|xls|xlsx|ppt|pptx|tiff|tif|pdf|txt|zip|lzh|dxf|rtf|csd|gif|jpe?g|png)$/";
/*     */     
/*  76 */     if (this.files == null) {
/*  77 */       this.files = new ArrayList();
/*     */     } else {
/*  79 */       this.files.clear();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void listener(FileUploadEvent event)
/*     */     throws Exception
/*     */   {
/*  91 */     String countStr = (String)FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("count_of_files");
/*  92 */     if (!FwStringValidator.isEmpty(countStr)) {
/*  93 */       this.count = Integer.parseInt(countStr);
/*     */     }
/*     */     
/*     */ 
/*  97 */     String fileId = this.fileUtils.setFile(event.getFile().getContents());
/*     */     
/*     */ 
/* 100 */     CfwUploadedFileData file = new CfwUploadedFileData();
/* 101 */     file.setFileId(fileId);
/* 102 */     file.setName(event.getFile().getFileName());
/* 103 */     file.setSize(event.getFile().getSize());
/*     */     
/*     */ 
/* 106 */     this.files.add(file);
/*     */     
/*     */ 
/* 109 */     if (this.files.size() == this.count) {
/* 110 */       RequestContext.getCurrentInstance().closeDialog(this.files);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void closeEvent(ActionEvent event)
/*     */   {
/* 121 */     RequestContext.getCurrentInstance().closeDialog(this.files);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void open()
/*     */   {
/* 128 */     open(600, 300);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void open(int width, int height)
/*     */   {
/* 139 */     Map<String, Object> dialogOptions = new HashMap();
/* 140 */     dialogOptions.put("modal", Boolean.valueOf(true));
/* 141 */     dialogOptions.put("resizable", Boolean.valueOf(false));
/* 142 */     dialogOptions.put("draggable", Boolean.valueOf(true));
/* 143 */     dialogOptions.put("closable", Boolean.valueOf(false));
/* 144 */     dialogOptions.put("contentWidth", Integer.valueOf(width));
/* 145 */     dialogOptions.put("contentHeight", Integer.valueOf(height));
/*     */     
/*     */ 
/* 148 */     Map<String, List<String>> params = new HashMap();
/* 149 */     this.utils.addParamsForDialog(params);
/*     */     
/*     */ 
/* 152 */     RequestContext.getCurrentInstance().openDialog("/jsf/cfwUploadDialog", dialogOptions, params);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTitle(String title)
/*     */   {
/* 160 */     this.title = title;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTitle()
/*     */   {
/* 168 */     return this.title;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFileLimit(int fileLimit)
/*     */   {
/* 176 */     this.fileLimit = fileLimit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFileLimit()
/*     */   {
/* 184 */     return this.fileLimit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSizeLimit(int sizeLimit)
/*     */   {
/* 192 */     this.sizeLimit = sizeLimit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSizeLimit()
/*     */   {
/* 200 */     return this.sizeLimit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAllowType(String allowTypes)
/*     */   {
/* 208 */     this.allowTypes = allowTypes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAllowTypes()
/*     */   {
/* 216 */     return this.allowTypes;
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\upload\CfwUploadDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */