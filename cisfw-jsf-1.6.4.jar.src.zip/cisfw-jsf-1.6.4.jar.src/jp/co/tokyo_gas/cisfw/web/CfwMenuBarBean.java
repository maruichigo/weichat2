/*     */ package jp.co.tokyo_gas.cisfw.web;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Stack;
/*     */ import javax.faces.event.ActionEvent;
/*     */ import javax.faces.view.ViewScoped;
/*     */ import javax.inject.Inject;
/*     */ import javax.inject.Named;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.config.FwConfig;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.web.FwRequestContext;
/*     */ import jp.co.tokyo_gas.cisfw.exception.CfwApplicationException;
/*     */ import jp.co.tokyo_gas.cisfw.logger.CfwLogger;
/*     */ import jp.co.tokyo_gas.cisfw.web.menu.CfwMenuBarModel;
/*     */ import jp.co.tokyo_gas.cisfw.web.menu.CfwMenuItemDef;
/*     */ import jp.co.tokyo_gas.cisfw.web.menu.CfwMenuModelGenerator;
/*     */ import jp.co.tokyo_gas.cisfw.web.menu.CfwMenuUtil;
/*     */ import jp.co.tokyo_gas.cisfw.web.menu.CfwMenubarInfoCache;
/*     */ import org.primefaces.context.RequestContext;
/*     */ import org.primefaces.event.MenuActionEvent;
/*     */ import org.primefaces.model.menu.MenuItem;
/*     */ import org.primefaces.model.menu.MenuModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Named("menuBar")
/*     */ @ViewScoped
/*     */ public class CfwMenuBarBean
/*     */   extends CfwBaseBean
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   @Inject
/*     */   private CfwMenubarInfoCache cfwMenubarInfoCache;
/*     */   @Inject
/*     */   private CfwMenuModelGenerator menuModelGenerator;
/*     */   @Inject
/*     */   private CfwMenuBarModel menuBarModel;
/*     */   @Inject
/*     */   private FwConfig fwConfig;
/*     */   @Inject
/*     */   private FwRequestContext fwRequestContext;
/*     */   @Inject
/*     */   private CfwSession cfwSession;
/*     */   @Inject
/*     */   private CfwLogger log;
/*     */   @Inject
/*     */   private CfwMenuUtil util;
/*     */   
/*     */   public MenuModel getLeftMenuModel()
/*     */   {
/*  73 */     return this.menuModelGenerator.getLeftMenuModel();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MenuModel getRightMenuModel()
/*     */   {
/*  82 */     return this.menuModelGenerator.getRightMenuModel();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRightMenuEnable()
/*     */   {
/*  98 */     String facesViewId = this.fwRequestContext.getScreen();
/*  99 */     if (facesViewId == null)
/*     */     {
/*     */ 
/*     */ 
/* 103 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 108 */     String fwConfigScreenId = this.fwConfig.get("MENU");
/* 109 */     if (fwConfigScreenId == null) {
/* 110 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 114 */     String trimFacesViewId = this.util.trimXhtmlIfNeed(facesViewId);
/* 115 */     String trimFwConfigId = this.util.trimXhtmlIfNeed(fwConfigScreenId);
/*     */     
/*     */ 
/* 118 */     boolean topMenu = trimFacesViewId.equals(trimFwConfigId);
/*     */     
/*     */ 
/* 121 */     return !topMenu;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String next(ActionEvent event)
/*     */     throws CfwApplicationException
/*     */   {
/* 133 */     CfwMenuItemDef menuItemDef = getCfwMenuItemDef(event);
/* 134 */     String menuDefScreenId = menuItemDef.getScreenId();
/*     */     
/*     */ 
/* 137 */     moveBefore(menuItemDef);
/*     */     
/* 139 */     String gmnId = this.util.menuDefToDBDefScreenId(menuDefScreenId);
/* 140 */     String menuId = this.util.menuDefToDBDefScreenId(this.fwConfig.get("MENU", ""));
/*     */     
/*     */ 
/* 143 */     if (menuItemDef.needSubWindowClose()) {
/* 144 */       RequestContext.getCurrentInstance().execute("closeWindow(true);");
/*     */     }
/*     */     
/*     */ 
/* 148 */     if (gmnId.equals(menuId)) {
/* 149 */       return goMenu();
/*     */     }
/* 151 */     this.cfwSession.getScreenStack().clear();
/* 152 */     return redirect(menuDefScreenId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void openSubWindow(ActionEvent event)
/*     */     throws CfwApplicationException
/*     */   {
/* 166 */     CfwMenuItemDef menuItemDef = getCfwMenuItemDef(event);
/* 167 */     String menuDefScreenId = menuItemDef.getScreenId();
/*     */     
/*     */ 
/* 170 */     moveBefore(menuItemDef);
/*     */     
/*     */ 
/* 173 */     if (menuItemDef.needSubWindowClose()) {
/* 174 */       RequestContext.getCurrentInstance().execute("closeWindow(true);");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 179 */     openSubWindow(menuDefScreenId, menuItemDef.getWidth(), menuItemDef.getHeight());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void moveBefore(CfwMenuItemDef menuItemDef)
/*     */     throws CfwApplicationException
/*     */   {
/* 190 */     String menuDefScreenId = menuItemDef.getScreenId();
/* 191 */     String label = menuItemDef.getLabel();
/*     */     
/*     */ 
/* 194 */     checkAvailableTimeZone(menuDefScreenId, label);
/*     */     
/*     */ 
/* 197 */     checkAvailableMaintenance(menuDefScreenId, label);
/*     */     
/*     */ 
/*     */ 
/* 201 */     sessionOperation(menuItemDef);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   CfwMenuItemDef getCfwMenuItemDef(ActionEvent event)
/*     */   {
/* 215 */     MenuActionEvent menuEvent = (MenuActionEvent)event;
/* 216 */     MenuItem menuItem = menuEvent.getMenuItem();
/*     */     
/*     */ 
/* 219 */     Map<String, List<String>> params = menuItem.getParams();
/* 220 */     List<String> list = (List)params.get("MENU_ID");
/* 221 */     String menuId = (String)list.get(0);
/*     */     
/* 223 */     return (CfwMenuItemDef)this.menuBarModel.getMenuDefMap().get(menuId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkAvailableTimeZone(String menuDefScreenId, String label)
/*     */     throws CfwApplicationException
/*     */   {
/* 234 */     if (!this.cfwMenubarInfoCache.isAvailableTime(menuDefScreenId)) {
/* 235 */       throw new CfwApplicationException("CXXM91003E", new String[] { label });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkAvailableMaintenance(String menuDefScreenId, String label)
/*     */     throws CfwApplicationException
/*     */   {
/* 246 */     String screenId = this.util.menuDefToDBDefScreenId(menuDefScreenId);
/* 247 */     if (!this.cfwMenubarInfoCache.isAvailableMaintenance(screenId)) {
/* 248 */       throw new CfwApplicationException("CXXM91004E", new String[] { label });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void sessionOperation(CfwMenuItemDef menuItemDef)
/*     */   {
/* 260 */     if (menuItemDef.getSessionClear())
/*     */     {
/*     */ 
/* 263 */       this.cfwSession.getCfwSessionData().clear();
/*     */       
/* 265 */       this.cfwSession.getCfwSearchConditionInfo().clear();
/*     */     }
/*     */     
/*     */ 
/* 269 */     String parameters = menuItemDef.getParameters();
/* 270 */     setToCfwSessionData(parameters);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setToCfwSessionData(String parameters)
/*     */   {
/* 286 */     if (parameters == null) {
/* 287 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 295 */     CfwSessionData cfwSessionData = this.cfwSession.getCfwSessionData();
/* 296 */     Map<Object, Object> data = cfwSessionData.getData();
/* 297 */     String[] keyValues = parameters.split(";");
/* 298 */     for (String keyValue : keyValues)
/*     */     {
/* 300 */       String[] keyAndValue = keyValue.split("=");
/* 301 */       if (keyAndValue.length == 2) {
/* 302 */         data.put(keyAndValue[0], keyAndValue[1]);
/*     */       } else {
/* 304 */         this.log.warn("メニューバー用定義ファイル内にパラメーター設定できない値が存在します。{}", keyValue);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\CfwMenuBarBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */