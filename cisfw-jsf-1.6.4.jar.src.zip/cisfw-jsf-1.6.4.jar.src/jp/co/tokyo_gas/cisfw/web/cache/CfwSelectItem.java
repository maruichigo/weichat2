/*    */ package jp.co.tokyo_gas.cisfw.web.cache;
/*    */ 
/*    */ import javax.faces.model.SelectItem;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CfwSelectItem
/*    */   extends SelectItem
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String condition;
/*    */   
/*    */   public CfwSelectItem() {}
/*    */   
/*    */   public CfwSelectItem(Object value, String label)
/*    */   {
/* 39 */     super(value, label);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CfwSelectItem(Object value, String label, String condition)
/*    */   {
/* 49 */     super(value, label);
/* 50 */     setCondition(condition);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CfwSelectItem(Object value, String label, String description, boolean disabled, boolean escaped, boolean noSelectionOption, String condition)
/*    */   {
/* 65 */     super(value, label, description, disabled, escaped, noSelectionOption);
/* 66 */     setCondition(condition);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setCondition(String condition)
/*    */   {
/* 74 */     this.condition = condition;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getCondition()
/*    */   {
/* 82 */     return this.condition;
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\cache\CfwSelectItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */