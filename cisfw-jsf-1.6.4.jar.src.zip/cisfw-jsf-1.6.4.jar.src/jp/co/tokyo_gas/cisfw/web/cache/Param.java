/*    */ package jp.co.tokyo_gas.cisfw.web.cache;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlAttribute;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="")
/*    */ @XmlRootElement(name="param", namespace="http://cisfw.tokyo_gas.co.jp/web/cache/")
/*    */ public class Param
/*    */ {
/*    */   @XmlAttribute(name="key", required=true)
/*    */   protected String key;
/*    */   @XmlAttribute(name="value", required=true)
/*    */   protected String value;
/*    */   
/*    */   public String getKey()
/*    */   {
/* 39 */     return this.key;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setKey(String value)
/*    */   {
/* 47 */     this.key = value;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getValue()
/*    */   {
/* 55 */     return this.value;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setValue(String value)
/*    */   {
/* 63 */     this.value = value;
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\cache\Param.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */