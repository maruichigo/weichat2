/*    */ package jp.co.tokyo_gas.cisfw.web.cache;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlAttribute;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="", propOrder={"param"})
/*    */ @XmlRootElement(name="cache", namespace="http://cisfw.tokyo_gas.co.jp/web/cache/")
/*    */ public class Cache
/*    */ {
/*    */   @XmlElement(namespace="http://cisfw.tokyo_gas.co.jp/web/cache/")
/*    */   protected List<Param> param;
/*    */   @XmlAttribute(name="key", required=true)
/*    */   protected String key;
/*    */   @XmlAttribute(name="sqlid", required=true)
/*    */   protected String sqlid;
/*    */   
/*    */   public List<Param> getParam()
/*    */   {
/* 47 */     if (this.param == null) {
/* 48 */       this.param = new ArrayList();
/*    */     }
/* 50 */     return this.param;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getKey()
/*    */   {
/* 58 */     return this.key;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setKey(String value)
/*    */   {
/* 66 */     this.key = value;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getSqlid()
/*    */   {
/* 74 */     return this.sqlid;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setSqlid(String value)
/*    */   {
/* 82 */     this.sqlid = value;
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\cache\Cache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */