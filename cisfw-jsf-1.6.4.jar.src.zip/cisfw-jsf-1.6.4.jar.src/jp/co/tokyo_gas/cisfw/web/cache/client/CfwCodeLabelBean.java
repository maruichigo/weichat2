/*    */ package jp.co.tokyo_gas.cisfw.web.cache.client;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="cfwCodeLabelBean", propOrder={"code", "condition", "label"})
/*    */ public class CfwCodeLabelBean
/*    */ {
/*    */   protected String code;
/*    */   protected String condition;
/*    */   protected String label;
/*    */   
/*    */   public String getCode()
/*    */   {
/* 41 */     return this.code;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setCode(String value)
/*    */   {
/* 49 */     this.code = value;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getCondition()
/*    */   {
/* 57 */     return this.condition;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setCondition(String value)
/*    */   {
/* 65 */     this.condition = value;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getLabel()
/*    */   {
/* 73 */     return this.label;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setLabel(String value)
/*    */   {
/* 81 */     this.label = value;
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\cache\client\CfwCodeLabelBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */