/*     */ package jp.co.tokyo_gas.cisfw.web.cache.client;
/*     */ 
/*     */ import java.net.URL;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.ws.Service;
/*     */ import javax.xml.ws.WebEndpoint;
/*     */ import javax.xml.ws.WebServiceClient;
/*     */ import javax.xml.ws.WebServiceException;
/*     */ import javax.xml.ws.WebServiceFeature;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @WebServiceClient(name="CfwCacheServiceService", targetNamespace="http://provider.cache.cisfw.tokyo_gas.co.jp/", wsdlLocation="WEB-INF/wsdl/CfwCacheServiceService.wsdl")
/*     */ public class CfwCacheServiceService
/*     */   extends Service
/*     */ {
/*     */   private static final URL CFWCACHESERVICESERVICE_WSDL_LOCATION;
/*     */   private static final WebServiceException CFWCACHESERVICESERVICE_EXCEPTION;
/*  33 */   private static final QName CFWCACHESERVICESERVICE_QNAME = new QName("http://provider.cache.cisfw.tokyo_gas.co.jp/", "CfwCacheServiceService");
/*     */   
/*     */   static {
/*  36 */     CFWCACHESERVICESERVICE_WSDL_LOCATION = CfwCacheServiceService.class.getResource("/WEB-INF/wsdl/CfwCacheServiceService.wsdl");
/*  37 */     WebServiceException e = null;
/*  38 */     if (CFWCACHESERVICESERVICE_WSDL_LOCATION == null) {
/*  39 */       e = new WebServiceException("Cannot find 'WEB-INF/wsdl/CfwCacheServiceService.wsdl' wsdl. Place the resource correctly in the classpath.");
/*     */     }
/*  41 */     CFWCACHESERVICESERVICE_EXCEPTION = e;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwCacheServiceService()
/*     */   {
/*  49 */     super(__getWsdlLocation(), CFWCACHESERVICESERVICE_QNAME);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwCacheServiceService(WebServiceFeature... features)
/*     */   {
/*  57 */     super(__getWsdlLocation(), CFWCACHESERVICESERVICE_QNAME, features);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwCacheServiceService(URL wsdlLocation)
/*     */   {
/*  65 */     super(wsdlLocation, CFWCACHESERVICESERVICE_QNAME);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwCacheServiceService(URL wsdlLocation, WebServiceFeature... features)
/*     */   {
/*  74 */     super(wsdlLocation, CFWCACHESERVICESERVICE_QNAME, features);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwCacheServiceService(URL wsdlLocation, QName serviceName)
/*     */   {
/*  83 */     super(wsdlLocation, serviceName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwCacheServiceService(URL wsdlLocation, QName serviceName, WebServiceFeature... features)
/*     */   {
/*  94 */     super(wsdlLocation, serviceName, features);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @WebEndpoint(name="CfwCacheServicePort")
/*     */   public CfwCacheService getCfwCacheServicePort()
/*     */   {
/* 103 */     return (CfwCacheService)super.getPort(new QName("http://provider.cache.cisfw.tokyo_gas.co.jp/", "CfwCacheServicePort"), CfwCacheService.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @WebEndpoint(name="CfwCacheServicePort")
/*     */   public CfwCacheService getCfwCacheServicePort(WebServiceFeature... features)
/*     */   {
/* 113 */     return (CfwCacheService)super.getPort(new QName("http://provider.cache.cisfw.tokyo_gas.co.jp/", "CfwCacheServicePort"), CfwCacheService.class, features);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static URL __getWsdlLocation()
/*     */   {
/* 121 */     if (CFWCACHESERVICESERVICE_EXCEPTION != null) {
/* 122 */       throw CFWCACHESERVICESERVICE_EXCEPTION;
/*     */     }
/* 124 */     return CFWCACHESERVICESERVICE_WSDL_LOCATION;
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\cache\client\CfwCacheServiceService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */