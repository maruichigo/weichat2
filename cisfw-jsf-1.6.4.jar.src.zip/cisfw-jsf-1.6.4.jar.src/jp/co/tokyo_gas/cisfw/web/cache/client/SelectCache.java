/*    */ package jp.co.tokyo_gas.cisfw.web.cache.client;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="selectCache", propOrder={"arg0", "arg1"})
/*    */ public class SelectCache
/*    */ {
/*    */   protected String arg0;
/*    */   protected List<CacheParam> arg1;
/*    */   
/*    */   public String getArg0()
/*    */   {
/* 38 */     return this.arg0;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setArg0(String value)
/*    */   {
/* 46 */     this.arg0 = value;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public List<CacheParam> getArg1()
/*    */   {
/* 54 */     if (this.arg1 == null) {
/* 55 */       this.arg1 = new ArrayList();
/*    */     }
/* 57 */     return this.arg1;
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\cache\client\SelectCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */