/*     */ package jp.co.tokyo_gas.cisfw.web.cache;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.net.URL;
/*     */ import java.text.DateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.annotation.PostConstruct;
/*     */ import javax.enterprise.context.ApplicationScoped;
/*     */ import javax.enterprise.inject.Instance;
/*     */ import javax.enterprise.inject.spi.CDI;
/*     */ import javax.enterprise.util.AnnotationLiteral;
/*     */ import javax.faces.model.SelectItem;
/*     */ import javax.inject.Inject;
/*     */ import javax.inject.Named;
/*     */ import javax.xml.bind.JAXBContext;
/*     */ import javax.xml.bind.JAXBException;
/*     */ import javax.xml.bind.Unmarshaller;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.config.FwConfig;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.config.impl.FwResourceUtil;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.date.FwDateUtils;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.init.FwInitializer;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.tracking.FwTrackingIdManager;
/*     */ import jp.co.tokyo_gas.cisfw.cache.provider.CfwCacheManager;
/*     */ import jp.co.tokyo_gas.cisfw.converter.CfwBeanConverter;
/*     */ import jp.co.tokyo_gas.cisfw.exception.CfwRuntimeException;
/*     */ import jp.co.tokyo_gas.cisfw.init.CfwQualifier;
/*     */ import jp.co.tokyo_gas.cisfw.logger.CfwLogger;
/*     */ import jp.co.tokyo_gas.cisfw.web.cache.client.CfwCacheService;
/*     */ import jp.co.tokyo_gas.cisfw.web.cache.client.CfwCacheServiceService;
/*     */ import jp.co.tokyo_gas.cisfw.web.ws.CfwServiceFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Named("CfwCache")
/*     */ @ApplicationScoped
/*     */ public class CfwCache
/*     */   implements FwInitializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String SYSTEM_DATE = "$SYSDATE";
/*  60 */   private Map<String, List<CfwSelectItem>> cache = new HashMap();
/*     */   
/*     */ 
/*     */   @Inject
/*     */   private CfwLogger log;
/*     */   
/*     */ 
/*     */   @Inject
/*     */   private CfwServiceFactory factory;
/*     */   
/*     */ 
/*     */   @Inject
/*     */   private FwConfig config;
/*     */   
/*     */   @Inject
/*     */   private FwTrackingIdManager trackingIdManager;
/*     */   
/*     */ 
/*     */   public void setLog(CfwLogger log)
/*     */   {
/*  80 */     this.log = log;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFactory(CfwServiceFactory factory)
/*     */   {
/*  89 */     this.factory = factory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, List<CfwSelectItem>> getCache()
/*     */   {
/*  98 */     return this.cache;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @PostConstruct
/*     */   public void init()
/*     */   {
/* 110 */     this.trackingIdManager.get();
/*     */     
/* 112 */     this.log.debug("キャッシュ取得処理開始");
/*     */     
/*     */     try
/*     */     {
/* 116 */       CacheList cacheList = getCacheListElement("tgfw/CacheConfig.xml");
/*     */       
/*     */ 
/* 119 */       if (cacheList.getCache().size() == 0) {
/* 120 */         return;
/*     */       }
/*     */       
/* 123 */       for (Cache cacheElement : cacheList.getCache())
/*     */       {
/* 125 */         String key = cacheElement.getKey();
/* 126 */         String sqlStatement = cacheElement.getSqlid();
/*     */         
/* 128 */         List<jp.co.tokyo_gas.cisfw.web.cache.client.CacheParam> cacheParams = paramElementToCacheParam(cacheElement.getParam());
/*     */         
/* 130 */         List<jp.co.tokyo_gas.cisfw.web.cache.client.CfwCodeLabelBean> items = getCfwCodeLabelBeanList(sqlStatement, cacheParams);
/*     */         
/*     */ 
/* 133 */         if (items.size() == 0) {
/* 134 */           this.log.debug("DBにデータがありませんでした。 : CacheKey=" + key + ", SQLID=" + sqlStatement);
/*     */         }
/*     */         else
/*     */         {
/* 138 */           List<CfwSelectItem> list = new ArrayList();
/* 139 */           for (jp.co.tokyo_gas.cisfw.web.cache.client.CfwCodeLabelBean item : items) {
/* 140 */             list.add(new CfwSelectItem(item
/* 141 */               .getCode(), item.getLabel(), item.getCondition()));
/*     */           }
/*     */           
/* 144 */           this.cache.put(key, list);
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/* 148 */       throw new CfwRuntimeException("キャッシュの取得に失敗しました。", e, new Object[0]);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String get(String cachekey, String code)
/*     */   {
/* 160 */     String result = null;
/*     */     
/* 162 */     List<CfwSelectItem> list = (List)this.cache.get(cachekey);
/*     */     
/* 164 */     if (list == null) {
/* 165 */       return null;
/*     */     }
/*     */     
/* 168 */     for (SelectItem item : list) {
/* 169 */       if (item.getValue().equals(code)) {
/* 170 */         result = item.getLabel();
/* 171 */         break;
/*     */       }
/*     */     }
/* 174 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<CfwSelectItem> get(String cachekey)
/*     */   {
/* 184 */     return (List)this.cache.get(cachekey);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected CacheList getCacheListElement(String name)
/*     */   {
/* 195 */     CacheList cacheList = new CacheList();
/*     */     
/* 197 */     URL url = FwResourceUtil.getResource("TGFW-RESOURCES", name);
/*     */     
/*     */ 
/* 200 */     if (url == null) {
/* 201 */       this.log.warn("設定ファイルが見つかりませんでした。");
/* 202 */       return cacheList;
/*     */     }
/*     */     try
/*     */     {
/* 206 */       JAXBContext context = JAXBContext.newInstance(new Class[] { CacheList.class });
/* 207 */       Unmarshaller unmarshaller = context.createUnmarshaller();
/* 208 */       cacheList = (CacheList)unmarshaller.unmarshal(url);
/*     */       
/* 210 */       if (cacheList.getCache().size() == 0) {
/* 211 */         throw new CfwRuntimeException("設定ファイルは、cache.xsdで定義された構文に従って記述してください。", new Object[0]);
/*     */       }
/*     */     }
/*     */     catch (JAXBException je) {
/* 215 */       throw new CfwRuntimeException("設定ファイルは、cache.xsdで定義された構文に従って記述してください。", je, new Object[0]);
/*     */     }
/*     */     
/* 218 */     return cacheList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<jp.co.tokyo_gas.cisfw.web.cache.client.CacheParam> paramElementToCacheParam(List<Param> params)
/*     */   {
/* 231 */     List<jp.co.tokyo_gas.cisfw.web.cache.client.CacheParam> cacheParams = new ArrayList();
/*     */     
/* 233 */     for (Param param : params) {
/* 234 */       jp.co.tokyo_gas.cisfw.web.cache.client.CacheParam cacheParam = new jp.co.tokyo_gas.cisfw.web.cache.client.CacheParam();
/* 235 */       cacheParam.setKey(param.getKey());
/*     */       
/* 237 */       String value = param.getValue();
/*     */       
/* 239 */       if ("$SYSDATE".equals(value)) {
/* 240 */         Date systemDate = FwDateUtils.getSystemDate();
/* 241 */         String systemDateStr = DateFormat.getDateInstance().format(systemDate);
/* 242 */         cacheParam.setValue(systemDateStr.replace('/', '-'));
/*     */       }
/*     */       else {
/* 245 */         cacheParam.setValue(param.getValue());
/*     */       }
/*     */       
/* 248 */       cacheParams.add(cacheParam);
/*     */     }
/*     */     
/* 251 */     return cacheParams;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private List<jp.co.tokyo_gas.cisfw.web.cache.client.CfwCodeLabelBean> getCfwCodeLabelBeanList(String sqlId, List<jp.co.tokyo_gas.cisfw.web.cache.client.CacheParam> cacheParams)
/*     */   {
/* 263 */     List<jp.co.tokyo_gas.cisfw.web.cache.client.CfwCodeLabelBean> items = new ArrayList();
/*     */     
/* 265 */     if ("true".equals(this.config.get("ear.integration", "false")))
/*     */     {
/* 267 */       CfwCacheManager manager = (CfwCacheManager)getManager();
/* 268 */       List<jp.co.tokyo_gas.cisfw.cache.provider.CfwCodeLabelBean> cfwCodeLabelBeanList = new ArrayList();
/* 269 */       List<jp.co.tokyo_gas.cisfw.cache.provider.CacheParam> cacheParamList = new ArrayList();
/*     */       
/* 271 */       for (jp.co.tokyo_gas.cisfw.web.cache.client.CacheParam param : cacheParams) {
/* 272 */         jp.co.tokyo_gas.cisfw.cache.provider.CacheParam cacheParam = new jp.co.tokyo_gas.cisfw.cache.provider.CacheParam();
/*     */         
/*     */ 
/* 275 */         CfwBeanConverter<jp.co.tokyo_gas.cisfw.web.cache.client.CacheParam, jp.co.tokyo_gas.cisfw.cache.provider.CacheParam> converter = CfwBeanConverter.getConverter(jp.co.tokyo_gas.cisfw.web.cache.client.CacheParam.class, jp.co.tokyo_gas.cisfw.cache.provider.CacheParam.class);
/* 276 */         converter.propertyCopy(param, cacheParam);
/*     */         
/* 278 */         cacheParamList.add(cacheParam);
/*     */       }
/* 280 */       cfwCodeLabelBeanList = manager.selectCache(sqlId, cacheParamList);
/*     */       
/*     */ 
/* 283 */       for (jp.co.tokyo_gas.cisfw.cache.provider.CfwCodeLabelBean codeLabelBean : cfwCodeLabelBeanList)
/*     */       {
/*     */ 
/* 286 */         jp.co.tokyo_gas.cisfw.web.cache.client.CfwCodeLabelBean bean = new jp.co.tokyo_gas.cisfw.web.cache.client.CfwCodeLabelBean();
/*     */         
/* 288 */         CfwBeanConverter<jp.co.tokyo_gas.cisfw.cache.provider.CfwCodeLabelBean, jp.co.tokyo_gas.cisfw.web.cache.client.CfwCodeLabelBean> converter = CfwBeanConverter.getConverter(jp.co.tokyo_gas.cisfw.cache.provider.CfwCodeLabelBean.class, jp.co.tokyo_gas.cisfw.web.cache.client.CfwCodeLabelBean.class);
/*     */         
/* 290 */         converter.propertyCopy(codeLabelBean, bean);
/* 291 */         items.add(bean);
/*     */       }
/*     */     }
/*     */     else {
/* 295 */       CfwCacheService service = (CfwCacheService)this.factory.createSEI(CfwCacheServiceService.class, CfwCacheService.class);
/*     */       
/* 297 */       items = service.selectCache(sqlId, cacheParams);
/*     */     }
/* 299 */     return items;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object getManager()
/*     */   {
/* 307 */     CDI.current().select(CfwCacheManager.class, new Annotation[] { new AnnotationLiteral() {} }).get();
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\cache\CfwCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */