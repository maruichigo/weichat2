package jp.co.tokyo_gas.cisfw.web.cache.client;

import java.util.List;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

@WebService(name="CfwCacheService", targetNamespace="http://provider.cache.cisfw.tokyo_gas.co.jp/")
@XmlSeeAlso({ObjectFactory.class})
public abstract interface CfwCacheService
{
  @WebMethod
  @WebResult(targetNamespace="")
  @RequestWrapper(localName="selectCache", targetNamespace="http://provider.cache.cisfw.tokyo_gas.co.jp/", className="jp.co.tokyo_gas.cisfw.web.cache.client.SelectCache")
  @ResponseWrapper(localName="selectCacheResponse", targetNamespace="http://provider.cache.cisfw.tokyo_gas.co.jp/", className="jp.co.tokyo_gas.cisfw.web.cache.client.SelectCacheResponse")
  public abstract List<CfwCodeLabelBean> selectCache(@WebParam(name="arg0", targetNamespace="") String paramString, @WebParam(name="arg1", targetNamespace="") List<CacheParam> paramList);
}


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\cache\client\CfwCacheService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */