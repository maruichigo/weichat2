/*    */ package jp.co.tokyo_gas.cisfw.web.cache.client;
/*    */ 
/*    */ import javax.xml.bind.JAXBElement;
/*    */ import javax.xml.bind.annotation.XmlElementDecl;
/*    */ import javax.xml.bind.annotation.XmlRegistry;
/*    */ import javax.xml.namespace.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlRegistry
/*    */ public class ObjectFactory
/*    */ {
/* 21 */   private static final QName _SelectCacheResponse_QNAME = new QName("http://provider.cache.cisfw.tokyo_gas.co.jp/", "selectCacheResponse");
/* 22 */   private static final QName _SelectCache_QNAME = new QName("http://provider.cache.cisfw.tokyo_gas.co.jp/", "selectCache");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SelectCache createSelectCache()
/*    */   {
/* 35 */     return new SelectCache();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public SelectCacheResponse createSelectCacheResponse()
/*    */   {
/* 43 */     return new SelectCacheResponse();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public CacheParam createCacheParam()
/*    */   {
/* 51 */     return new CacheParam();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public CfwCodeLabelBean createCfwCodeLabelBean()
/*    */   {
/* 59 */     return new CfwCodeLabelBean();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   @XmlElementDecl(namespace="http://provider.cache.cisfw.tokyo_gas.co.jp/", name="selectCacheResponse")
/*    */   public JAXBElement<SelectCacheResponse> createSelectCacheResponse(SelectCacheResponse value)
/*    */   {
/* 68 */     return new JAXBElement(_SelectCacheResponse_QNAME, SelectCacheResponse.class, null, value);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   @XmlElementDecl(namespace="http://provider.cache.cisfw.tokyo_gas.co.jp/", name="selectCache")
/*    */   public JAXBElement<SelectCache> createSelectCache(SelectCache value)
/*    */   {
/* 77 */     return new JAXBElement(_SelectCache_QNAME, SelectCache.class, null, value);
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\cache\client\ObjectFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */