/*    */ package jp.co.tokyo_gas.cisfw.web.cache.client;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="selectCacheResponse", propOrder={"_return"})
/*    */ public class SelectCacheResponse
/*    */ {
/*    */   @XmlElement(name="return")
/*    */   protected List<CfwCodeLabelBean> _return;
/*    */   
/*    */   public List<CfwCodeLabelBean> getReturn()
/*    */   {
/* 37 */     if (this._return == null) {
/* 38 */       this._return = new ArrayList();
/*    */     }
/* 40 */     return this._return;
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\cache\client\SelectCacheResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */