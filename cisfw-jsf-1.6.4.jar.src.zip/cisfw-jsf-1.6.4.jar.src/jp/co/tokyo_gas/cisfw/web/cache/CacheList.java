/*    */ package jp.co.tokyo_gas.cisfw.web.cache;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="", propOrder={"cache"})
/*    */ @XmlRootElement(name="cache-list", namespace="http://cisfw.tokyo_gas.co.jp/web/cache/")
/*    */ public class CacheList
/*    */ {
/*    */   @XmlElement(namespace="http://cisfw.tokyo_gas.co.jp/web/cache/", required=true)
/*    */   protected List<Cache> cache;
/*    */   
/*    */   public List<Cache> getCache()
/*    */   {
/* 38 */     if (this.cache == null) {
/* 39 */       this.cache = new ArrayList();
/*    */     }
/* 41 */     return this.cache;
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\cache\CacheList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */