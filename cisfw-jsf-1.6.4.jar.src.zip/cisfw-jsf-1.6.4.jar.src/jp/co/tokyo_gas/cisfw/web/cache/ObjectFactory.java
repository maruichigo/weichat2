/*    */ package jp.co.tokyo_gas.cisfw.web.cache;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlRegistry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlRegistry
/*    */ public class ObjectFactory
/*    */ {
/*    */   public Cache createCache()
/*    */   {
/* 29 */     return new Cache();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Param createParam()
/*    */   {
/* 37 */     return new Param();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public CacheList createCacheList()
/*    */   {
/* 45 */     return new CacheList();
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\cache\ObjectFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */