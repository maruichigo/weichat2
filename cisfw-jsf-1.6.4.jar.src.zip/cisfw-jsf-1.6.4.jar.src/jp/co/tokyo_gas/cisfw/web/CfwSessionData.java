/*    */ package jp.co.tokyo_gas.cisfw.web;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CfwSessionData
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private Map<Object, Object> data;
/*    */   
/*    */   public CfwSessionData()
/*    */   {
/* 27 */     this.data = new HashMap();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Object get(Object key)
/*    */   {
/* 37 */     return this.data.get(key);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void put(Object key, Object value)
/*    */   {
/* 47 */     this.data.put(key, value);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean remove(Object key)
/*    */   {
/* 57 */     if (this.data.containsKey(key)) {
/* 58 */       this.data.remove(key);
/* 59 */       return true;
/*    */     }
/* 61 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void clear()
/*    */   {
/* 69 */     this.data.clear();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int size()
/*    */   {
/* 78 */     return this.data.size();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Map<Object, Object> getData()
/*    */   {
/* 87 */     return this.data;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setData(Map<Object, Object> data)
/*    */   {
/* 96 */     this.data = data;
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\CfwSessionData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */