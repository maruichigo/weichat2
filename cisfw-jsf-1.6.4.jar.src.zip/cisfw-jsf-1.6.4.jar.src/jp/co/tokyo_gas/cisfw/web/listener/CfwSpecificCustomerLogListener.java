/*    */ package jp.co.tokyo_gas.cisfw.web.listener;
/*    */ 
/*    */ import javax.faces.event.PhaseEvent;
/*    */ import javax.faces.event.PhaseId;
/*    */ import javax.inject.Inject;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.listener.FwPhaseListener;
/*    */ import jp.co.tokyo_gas.cisfw.converter.CfwJSONConverter;
/*    */ import jp.co.tokyo_gas.cisfw.logger.CfwLogger;
/*    */ import jp.co.tokyo_gas.cisfw.web.CfwSession;
/*    */ import jp.co.tokyo_gas.cisfw.web.CfwSpecificCustomerInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CfwSpecificCustomerLogListener
/*    */   extends FwPhaseListener
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   @Inject
/*    */   private CfwSession session;
/*    */   @Inject
/*    */   private CfwLogger log;
/*    */   
/*    */   public void before(PhaseEvent event) {}
/*    */   
/*    */   public void after(PhaseEvent event)
/*    */   {
/* 53 */     if (this.session != null)
/*    */     {
/* 55 */       CfwSpecificCustomerInfo cfwSpecificCustomerInfo = this.session.getCurrentCfwSpecificCustomerInfo();
/* 56 */       if (cfwSpecificCustomerInfo != null)
/*    */       {
/* 58 */         CfwJSONConverter<CfwSpecificCustomerInfo> converter = CfwJSONConverter.getConverter(CfwSpecificCustomerInfo.class);
/*    */         
/*    */ 
/* 61 */         this.log.info(converter.encode(cfwSpecificCustomerInfo));
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PhaseId getPhaseId()
/*    */   {
/* 73 */     return PhaseId.INVOKE_APPLICATION;
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\listener\CfwSpecificCustomerLogListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */