/*    */ package jp.co.tokyo_gas.cisfw.web.listener;
/*    */ 
/*    */ import java.time.LocalDateTime;
/*    */ import java.time.ZoneId;
/*    */ import java.time.ZonedDateTime;
/*    */ import java.util.Date;
/*    */ import javax.faces.event.PhaseEvent;
/*    */ import javax.faces.event.PhaseId;
/*    */ import javax.inject.Inject;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.config.FwConfig;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.listener.FwPhaseListener;
/*    */ import jp.co.tokyo_gas.cisfw.utils.CfwDateConverter;
/*    */ import jp.co.tokyo_gas.cisfw.utils.CfwDateUtils;
/*    */ import jp.co.tokyo_gas.cisfw.web.CfwSession;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CfwDateTimeListener
/*    */   extends FwPhaseListener
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   @Inject
/*    */   private CfwSession session;
/*    */   @Inject
/*    */   private FwConfig fwConfig;
/*    */   
/*    */   public void before(PhaseEvent event)
/*    */   {
/* 50 */     String date = "";
/* 51 */     if ("TRUE".equals(this.fwConfig.get("header.opdate", "false").toUpperCase()))
/*    */     {
/* 53 */       date = CfwDateUtils.getOperationDate();
/*    */     }
/*    */     else {
/* 56 */       date = CfwDateUtils.getSystemDateStr();
/*    */     }
/*    */     
/*    */ 
/* 60 */     LocalDateTime op = LocalDateTime.ofInstant(
/* 61 */       CfwDateConverter.stringToDate(date, "yyyyMMdd").toInstant(), 
/* 62 */       ZoneId.systemDefault());
/* 63 */     LocalDateTime sys = LocalDateTime.ofInstant(CfwDateUtils.getServerDate().toInstant(), 
/* 64 */       ZoneId.systemDefault());
/* 65 */     LocalDateTime login = LocalDateTime.of(op.getYear(), op.getMonthValue(), op.getDayOfMonth(), sys
/* 66 */       .getHour(), sys.getMinute(), sys.getSecond());
/* 67 */     this.session.setLoginTime(Date.from(login.atZone(ZoneId.systemDefault()).toInstant()));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void after(PhaseEvent event) {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PhaseId getPhaseId()
/*    */   {
/* 87 */     return PhaseId.RENDER_RESPONSE;
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\listener\CfwDateTimeListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */