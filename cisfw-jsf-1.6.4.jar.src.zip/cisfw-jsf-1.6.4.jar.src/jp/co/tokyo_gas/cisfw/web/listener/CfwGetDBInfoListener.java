/*    */ package jp.co.tokyo_gas.cisfw.web.listener;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.util.Properties;
/*    */ import javax.faces.event.PhaseEvent;
/*    */ import javax.faces.event.PhaseId;
/*    */ import javax.inject.Inject;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.listener.FwPhaseListener;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.string.FwStringValidator;
/*    */ import jp.co.tokyo_gas.cisfw.logger.CfwLogger;
/*    */ import jp.co.tokyo_gas.cisfw.sql.CfwDBInfoHolder;
/*    */ import jp.co.tokyo_gas.cisfw.sql.CfwDBInfoManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CfwGetDBInfoListener
/*    */   extends FwPhaseListener
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   @Inject
/*    */   private CfwDBInfoHolder holder;
/*    */   @Inject
/*    */   private CfwLogger log;
/*    */   @Inject
/*    */   private CfwDBInfoManager manager;
/*    */   
/*    */   public void after(PhaseEvent event) {}
/*    */   
/*    */   public void before(PhaseEvent event)
/*    */   {
/* 57 */     this.log.debug("CfwGetDBInfoListener#Start");
/*    */     
/*    */ 
/* 60 */     String path = this.manager.get("datasource.switch.propertyfile");
/*    */     
/* 62 */     Properties prop = new Properties();
/* 63 */     String datasourceSwitch = null;
/* 64 */     try { FileInputStream stream = new FileInputStream(new File(path));Throwable localThrowable3 = null;
/* 65 */       try { prop.load(stream);
/* 66 */         datasourceSwitch = prop.getProperty("datasource.switch");
/*    */         
/*    */ 
/* 69 */         if (FwStringValidator.isEmpty(datasourceSwitch)) {
/* 70 */           datasourceSwitch = "1";
/*    */         }
/*    */       }
/*    */       catch (Throwable localThrowable1)
/*    */       {
/* 64 */         localThrowable3 = localThrowable1;throw localThrowable1;
/*    */ 
/*    */ 
/*    */       }
/*    */       finally
/*    */       {
/*    */ 
/*    */ 
/* 72 */         if (stream != null) if (localThrowable3 != null) try { stream.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else stream.close();
/*    */       }
/* 74 */     } catch (Exception e) { datasourceSwitch = "1";
/*    */     }
/*    */     
/*    */ 
/* 78 */     this.holder.setDatasourceSwitch(datasourceSwitch);
/*    */     
/* 80 */     this.log.debug("CfwGetDBInfoListener#End");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PhaseId getPhaseId()
/*    */   {
/* 90 */     return PhaseId.APPLY_REQUEST_VALUES;
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\listener\CfwGetDBInfoListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */