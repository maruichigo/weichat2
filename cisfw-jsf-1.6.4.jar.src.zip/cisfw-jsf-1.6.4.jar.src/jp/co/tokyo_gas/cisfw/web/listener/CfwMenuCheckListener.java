/*     */ package jp.co.tokyo_gas.cisfw.web.listener;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.faces.component.UIViewRoot;
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.faces.event.PhaseEvent;
/*     */ import javax.faces.event.PhaseId;
/*     */ import javax.inject.Inject;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.ee.exception.FwApplicationException;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.listener.FwPhaseListener;
/*     */ import jp.co.tokyo_gas.cisfw.exception.CfwApplicationException;
/*     */ import jp.co.tokyo_gas.cisfw.exception.CfwScreenCheckException;
/*     */ import jp.co.tokyo_gas.cisfw.logger.CfwLogger;
/*     */ import jp.co.tokyo_gas.cisfw.web.CfwSession;
/*     */ import jp.co.tokyo_gas.cisfw.web.menu.CfwMenuUtil;
/*     */ import jp.co.tokyo_gas.cisfw.web.menu.CfwMenubarInfoCache;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CfwMenuCheckListener
/*     */   extends FwPhaseListener
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   @Inject
/*     */   private CfwMenubarInfoCache cfwMenubarInfoCache;
/*     */   @Inject
/*     */   private CfwSession cfwSession;
/*     */   @Inject
/*     */   private CfwLogger log;
/*     */   @Inject
/*     */   private CfwMenuUtil util;
/*     */   
/*     */   public void after(PhaseEvent event)
/*     */     throws FwApplicationException
/*     */   {}
/*     */   
/*     */   public PhaseId getPhaseId()
/*     */   {
/*  72 */     return PhaseId.PROCESS_VALIDATIONS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void before(PhaseEvent event)
/*     */     throws FwApplicationException
/*     */   {
/*  86 */     FacesContext facesContext = event.getFacesContext();
/*  87 */     String facesViewId = getViewId(facesContext);
/*     */     
/*     */ 
/*  90 */     boolean isPostback = facesContext.isPostback();
/*     */     
/*  92 */     if (exCludeCheck(facesViewId)) {
/*  93 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  99 */     judgeByMaintenance(facesViewId, isPostback);
/*     */     
/*     */ 
/* 102 */     judgeByTime(facesViewId, isPostback);
/*     */     
/*     */ 
/* 105 */     judgeByAuthority(facesViewId, isPostback);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean exCludeCheck(String facesViewId)
/*     */   {
/* 118 */     if (facesViewId == null) {
/* 119 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 125 */     if (facesViewId.startsWith("/jsf/")) {
/* 126 */       return true;
/*     */     }
/*     */     
/* 129 */     Set<String> set = new HashSet();
/* 130 */     set.add("/error.xhtml");
/* 131 */     set.add("/logout.xhtml");
/* 132 */     set.add("/sessioninvalid.xhtml");
/* 133 */     set.add("/timeout.xhtml");
/*     */     
/* 135 */     if (set.contains(facesViewId)) {
/* 136 */       return true;
/*     */     }
/* 138 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void judgeByTime(String facesViewId, boolean isPostback)
/*     */     throws FwApplicationException
/*     */   {
/* 156 */     String menuDefScreenId = this.util.facesViewIdToMenuDefScreenId(facesViewId);
/*     */     
/* 158 */     boolean availabelTime = this.cfwMenubarInfoCache.isAvailableTime(menuDefScreenId);
/* 159 */     if (availabelTime)
/*     */     {
/* 161 */       return;
/*     */     }
/*     */     
/*     */ 
/* 165 */     if (this.util.excludeByConfig()) {
/* 166 */       String currentTimeInfo = this.cfwMenubarInfoCache.getCurrentTimeInfo();
/* 167 */       this.log.debug("利用時間帯チェックはNGですが設定により処理を進めます。画面ID:{}, 時間帯{}", menuDefScreenId, currentTimeInfo);
/* 168 */       return;
/*     */     }
/*     */     
/* 171 */     if (isPostback)
/*     */     {
/* 173 */       throw new CfwApplicationException("CXXM91003E", new String[] { "その" });
/*     */     }
/*     */     
/* 176 */     throw CfwScreenCheckException.createByTime();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void judgeByMaintenance(String facesViewId, boolean isPostback)
/*     */     throws CfwApplicationException
/*     */   {
/* 191 */     String screenId = this.util.facesViewIdToDbDefScreenId(facesViewId);
/* 192 */     boolean available = this.cfwMenubarInfoCache.isAvailableMaintenance(screenId);
/*     */     
/*     */ 
/* 195 */     if (!available) {
/* 196 */       if (isPostback) {
/* 197 */         throw new CfwApplicationException("CXXM91004E", new String[] { "その" });
/*     */       }
/* 199 */       throw CfwScreenCheckException.createByMaint();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void judgeByAuthority(String facesViewId, boolean isPostback)
/*     */   {
/* 212 */     if (isPostback)
/*     */     {
/* 214 */       return;
/*     */     }
/*     */     
/* 217 */     String screenId = this.util.facesViewIdToDbDefScreenId(facesViewId);
/*     */     
/* 219 */     List<String> allowedScreenId = this.util.allowedScreenId(this.cfwSession);
/* 220 */     if ((allowedScreenId == null) || (allowedScreenId.size() == 0)) {
/* 221 */       this.log.warn("ユーザーの利用可能画面IDが設定されていません。");
/* 222 */       throw CfwScreenCheckException.createByAuth();
/*     */     }
/*     */     
/*     */ 
/* 226 */     boolean contains = allowedScreenId.contains(screenId);
/* 227 */     if (!contains) {
/* 228 */       if (this.util.excludeByConfig()) {
/* 229 */         this.log.debug("セッションのallowedScreenIdに画面ID:{}がありませんが、設定によりOKとして取り扱います。", screenId);
/* 230 */         return;
/*     */       }
/* 232 */       throw CfwScreenCheckException.createByAuth();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   String getViewId(FacesContext facesContext)
/*     */   {
/* 248 */     String facesViewId = facesContext.getViewRoot().getViewId();
/* 249 */     return facesViewId;
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\listener\CfwMenuCheckListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */