/*    */ package jp.co.tokyo_gas.cisfw.web.listener;
/*    */ 
/*    */ import javax.faces.event.PhaseEvent;
/*    */ import javax.faces.event.PhaseId;
/*    */ import javax.inject.Inject;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.listener.FwPhaseListener;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.string.FwStringValidator;
/*    */ import jp.co.tokyo_gas.cisfw.web.CfwSession;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CfwSubWindowSessionListener
/*    */   extends FwPhaseListener
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   @Inject
/*    */   private CfwSession session;
/*    */   @Inject
/*    */   private HttpServletRequest request;
/*    */   
/*    */   public void before(PhaseEvent event)
/*    */   {
/* 43 */     String businessKey = this.request.getParameter("cfw_windowkey");
/* 44 */     if (!FwStringValidator.isEmpty(businessKey)) {
/* 45 */       this.session.putWindowKeyMap(businessKey);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void after(PhaseEvent event) {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PhaseId getPhaseId()
/*    */   {
/* 63 */     return PhaseId.APPLY_REQUEST_VALUES;
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\listener\CfwSubWindowSessionListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */