/*    */ package jp.co.tokyo_gas.cisfw.web.menucache;
/*    */ 
/*    */ import javax.enterprise.context.RequestScoped;
/*    */ import javax.inject.Inject;
/*    */ import javax.ws.rs.PUT;
/*    */ import javax.ws.rs.Path;
/*    */ import javax.ws.rs.PathParam;
/*    */ import javax.ws.rs.core.Response;
/*    */ import javax.ws.rs.core.Response.ResponseBuilder;
/*    */ import javax.ws.rs.core.Response.Status;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.rs.FwRSAutoRegister;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.rs.csrf.FwRSCSRFTokenCheck;
/*    */ import jp.co.tokyo_gas.cisfw.logger.CfwLogger;
/*    */ import jp.co.tokyo_gas.cisfw.web.CfwRest;
/*    */ import jp.co.tokyo_gas.cisfw.web.menu.CfwMenuControlInfoGetter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Path("/menuCache")
/*    */ @CfwRest
/*    */ @RequestScoped
/*    */ public class CfwMenuCacheResource
/*    */   implements FwRSAutoRegister
/*    */ {
/*    */   @Inject
/*    */   private CfwMenuControlInfoGetter logic;
/*    */   @Inject
/*    */   private CfwLogger log;
/*    */   
/*    */   @PUT
/*    */   @Path("/{id}")
/*    */   @FwRSCSRFTokenCheck(excluded=true)
/*    */   public Response put(@PathParam("id") String id)
/*    */   {
/* 50 */     boolean success = false;
/*    */     
/* 52 */     if ("1".equals(id))
/*    */     {
/* 54 */       success = this.logic.refreshCurrentTime();
/* 55 */     } else if ("2".equals(id))
/*    */     {
/* 57 */       success = this.logic.refreshMaintenance();
/*    */     } else {
/* 59 */       this.log.error("パラメーター不正 id={}", id);
/*    */       
/* 61 */       return Response.status(Response.Status.BAD_REQUEST).build();
/*    */     }
/*    */     
/* 64 */     if (success)
/*    */     {
/* 66 */       return Response.ok().build();
/*    */     }
/*    */     
/* 69 */     return Response.serverError().build();
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\menucache\CfwMenuCacheResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */