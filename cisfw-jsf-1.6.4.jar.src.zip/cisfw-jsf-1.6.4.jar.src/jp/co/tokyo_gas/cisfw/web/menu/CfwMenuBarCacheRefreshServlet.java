/*     */ package jp.co.tokyo_gas.cisfw.web.menu;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.annotation.Annotation;
/*     */ import javax.enterprise.inject.Instance;
/*     */ import javax.inject.Inject;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CfwMenuBarCacheRefreshServlet
/*     */   extends HttpServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   @Inject
/*     */   private Instance<CfwMenuControlInfoGetter> tgtClsInstance;
/*     */   
/*     */   protected void doGet(HttpServletRequest req, HttpServletResponse resp)
/*     */     throws ServletException, IOException
/*     */   {
/*  60 */     CfwMenuControlInfoGetter logic = getLogic();
/*     */     
/*     */ 
/*  63 */     String mode = req.getParameter("mode");
/*  64 */     if (logic.validateMode(mode))
/*     */     {
/*  66 */       boolean success = false;
/*  67 */       if ("1".equals(mode)) {
/*  68 */         success = logic.refreshCurrentTime();
/*     */       } else {
/*  70 */         success = logic.refreshMaintenance();
/*     */       }
/*     */       
/*  73 */       responseSet(success, resp);
/*     */     }
/*     */     else {
/*  76 */       responseWarning(resp);
/*     */     }
/*  78 */     this.tgtClsInstance.destroy(logic);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   CfwMenuControlInfoGetter getLogic()
/*     */   {
/*  88 */     Instance<CfwMenuControlInfoGetter> inst = this.tgtClsInstance.select(CfwMenuControlInfoGetter.class, new Annotation[0]);
/*  89 */     return (CfwMenuControlInfoGetter)inst.get();
/*     */   }
/*     */   
/*     */   void responseSet(boolean success, HttpServletResponse resp) {
/*  93 */     if (success) {
/*  94 */       resp.setStatus(200);
/*     */     } else {
/*  96 */       resp.setStatus(500);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void responseWarning(HttpServletResponse resp)
/*     */   {
/* 106 */     resp.setStatus(400);
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\menu\CfwMenuBarCacheRefreshServlet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */