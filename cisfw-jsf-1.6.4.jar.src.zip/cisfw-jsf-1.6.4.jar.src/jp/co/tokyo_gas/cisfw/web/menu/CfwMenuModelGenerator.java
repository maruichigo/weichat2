/*     */ package jp.co.tokyo_gas.cisfw.web.menu;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.annotation.PostConstruct;
/*     */ import javax.enterprise.context.Dependent;
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.inject.Inject;
/*     */ import javax.xml.bind.JAXB;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.config.FwResourceManager;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.FwFacesContext;
/*     */ import jp.co.tokyo_gas.cisfw.exception.CfwRuntimeException;
/*     */ import jp.co.tokyo_gas.cisfw.logger.CfwLogger;
/*     */ import jp.co.tokyo_gas.cisfw.web.CfwSession;
/*     */ import jp.co.tokyo_gas.cisfw.web.CfwUserInfo;
/*     */ import org.apache.commons.io.IOUtils;
/*     */ import org.primefaces.model.menu.DefaultMenuItem;
/*     */ import org.primefaces.model.menu.DefaultMenuModel;
/*     */ import org.primefaces.model.menu.DefaultSubMenu;
/*     */ import org.primefaces.model.menu.MenuElement;
/*     */ import org.primefaces.model.menu.MenuModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Dependent
/*     */ public class CfwMenuModelGenerator
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   @Inject
/*     */   private CfwMenubarInfoCache cfwMenubarInfoCache;
/*     */   @Inject
/*     */   private CfwLogger log;
/*     */   @Inject
/*     */   private CfwSession session;
/*     */   @Inject
/*     */   private CfwMenuBarModel menuBarModel;
/*     */   @Inject
/*     */   private CfwScreenAuthorityGetter screenAuthorityGetter;
/*     */   @Inject
/*     */   private FwResourceManager fwResourceManager;
/*     */   @Inject
/*     */   private CfwMenuUtil util;
/*     */   private Map<String, CfwMenuItemDef> menuDefMap;
/*     */   
/*     */   @PostConstruct
/*     */   public void init()
/*     */   {
/*  90 */     this.menuDefMap = new HashMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void createMenuModel()
/*     */   {
/* 106 */     CfwUserInfo userInfo = this.session.getUserInfo();
/*     */     
/* 108 */     if (this.util.allowedScreenId(this.session) == null) {
/* 109 */       String dukeId = userInfo.getDukeId();
/* 110 */       List<String> authorities = this.util.allowedAuthorityCd(this.session);
/* 111 */       if ((authorities == null) || (authorities.size() == 0)) {
/* 112 */         this.log.warn("ログインユーザー情報の利用可能権限コードリストが設定されていません。ユーザーID:{}", dukeId);
/*     */       }
/*     */       
/* 115 */       List<String> screenList = this.screenAuthorityGetter.get(authorities);
/* 116 */       userInfo.setAllowedScreenId(screenList);
/* 117 */       if (screenList.size() == 0)
/*     */       {
/* 119 */         this.log.debug("ログインユーザー情報の利用可能画面IDリストが設定されていません。ユーザーID:{}", dukeId);
/*     */       }
/*     */     }
/*     */     
/* 123 */     createMenuModelAndMenuBar();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MenuModel getLeftMenuModel()
/*     */   {
/* 134 */     reCreateIfNeed(this.cfwMenubarInfoCache.getLastModefied(), this.menuBarModel.getLastModefied());
/* 135 */     return this.menuBarModel.getLeftMenuModel();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MenuModel getRightMenuModel()
/*     */   {
/* 146 */     reCreateIfNeed(this.cfwMenubarInfoCache.getLastModefied(), this.menuBarModel.getLastModefied());
/* 147 */     return this.menuBarModel.getRightMenuModel();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reCreateIfNeed(Date cacheModefied, Date menuModefied)
/*     */   {
/* 161 */     long cache = cacheModefied.getTime();
/* 162 */     long menu = menuModefied == null ? 0L : menuModefied.getTime();
/*     */     
/*     */ 
/* 165 */     List<String> allowedScreenId = this.session.getUserInfo().getAllowedScreenId();
/*     */     
/* 167 */     if ((cache > menu) || (allowedScreenId == null))
/*     */     {
/* 169 */       boolean isPostback = FwFacesContext.getFacesContext().isPostback();
/* 170 */       if (!isPostback) {
/* 171 */         createMenuModel();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void createMenuModelAndMenuBar()
/*     */   {
/* 182 */     CfwMenuBarDef cfwLeftMenuBarDef = toMenuBarDef("tgfw/menu/menubar_left.xml");
/* 183 */     CfwMenuBarDef cfwRightMenuBarDef = toMenuBarDef("tgfw/menu/menubar_right.xml");
/*     */     
/*     */ 
/* 186 */     MenuModel menuLeftModel = createMenuBar(cfwLeftMenuBarDef);
/* 187 */     MenuModel menuRightModel = createMenuBar(cfwRightMenuBarDef);
/*     */     
/*     */ 
/* 190 */     this.menuBarModel.setLeftMenuModel(menuLeftModel);
/* 191 */     this.menuBarModel.setRightMenuModel(menuRightModel);
/* 192 */     this.menuBarModel.setMenuDefMap(this.menuDefMap);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   CfwMenuBarDef toMenuBarDef(String relativePath)
/*     */   {
/* 204 */     String errMsg = "file:%sのメニュー構築時にエラーが発生しました。";
/* 205 */     InputStream is = null;
/*     */     try {
/* 207 */       is = this.fwResourceManager.getResourceStream(relativePath);
/* 208 */       CfwMenuBarDef localCfwMenuBarDef1; if (is == null)
/*     */       {
/* 210 */         this.log.warn("TGFW_RESOURCES配下にファイルがありません。：{}　メニューを表示できません。", relativePath);
/* 211 */         CfwMenuBarDef cfwMenuBarDef = new CfwMenuBarDef();
/* 212 */         cfwMenuBarDef.setMenuElements(new ArrayList());
/* 213 */         return cfwMenuBarDef;
/*     */       }
/* 215 */       CfwMenuBarDef cfwMenuBarDef = (CfwMenuBarDef)JAXB.unmarshal(is, CfwMenuBarDef.class);
/* 216 */       return cfwMenuBarDef;
/*     */     } catch (IOException e) {
/* 218 */       throw new CfwRuntimeException("file:%sのメニュー構築時にエラーが発生しました。", e, new Object[] { relativePath });
/*     */     } finally {
/* 220 */       IOUtils.closeQuietly(is);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   MenuModel createMenuBar(CfwMenuBarDef cfwMenuBarDef)
/*     */   {
/* 233 */     MenuModel menuModel = new DefaultMenuModel();
/*     */     
/* 235 */     List<CfwMenuDefElement> elements = cfwMenuBarDef.getMenuElements();
/* 236 */     for (CfwMenuDefElement cfwMenuDefElement : elements)
/*     */     {
/*     */ 
/* 239 */       MenuElement enebled = createMenuElement(cfwMenuDefElement);
/* 240 */       if (enebled != null) {
/* 241 */         menuModel.addElement(enebled);
/*     */       }
/*     */     }
/*     */     
/* 245 */     return menuModel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   MenuElement createMenuElement(CfwMenuDefElement cfwMenuDefElement)
/*     */   {
/* 256 */     String label = cfwMenuDefElement.getLabel();
/*     */     
/*     */ 
/*     */ 
/* 260 */     if ((cfwMenuDefElement instanceof CfwSubMenuDef)) {
/* 261 */       DefaultSubMenu element = new DefaultSubMenu(label);
/* 262 */       if (setSubMenuItem(element, cfwMenuDefElement)) {
/* 263 */         return element;
/*     */       }
/* 265 */     } else if ((cfwMenuDefElement instanceof CfwMenuItemDef)) {
/* 266 */       CfwMenuItemDef cfwMenuItemDef = (CfwMenuItemDef)cfwMenuDefElement;
/* 267 */       DefaultMenuItem element = new DefaultMenuItem(label);
/* 268 */       if (setMenuItem(element, cfwMenuItemDef)) {
/* 269 */         return element;
/*     */       }
/*     */     }
/* 272 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean setMenuItem(DefaultMenuItem defaultMenuItem, CfwMenuItemDef menuItemDef)
/*     */   {
/* 285 */     defaultMenuItem.setId(menuItemDef.getMenuID());
/* 286 */     defaultMenuItem.setTitle(menuItemDef.getLabel());
/* 287 */     defaultMenuItem.setIcon(menuItemDef.getIcon());
/*     */     
/* 289 */     String subWindow = menuItemDef.getSubWindow();
/* 290 */     if ("0".equals(subWindow)) {
/* 291 */       defaultMenuItem.setCommand("#{menuBar.next}");
/* 292 */       defaultMenuItem.setImmediate(true);
/* 293 */       defaultMenuItem.setAsync(false);
/*     */       
/* 295 */       defaultMenuItem.setAjax(true);
/* 296 */     } else if ("1".equals(subWindow)) {
/* 297 */       defaultMenuItem.setCommand("#{menuBar.openSubWindow}");
/* 298 */       defaultMenuItem.setImmediate(true);
/* 299 */       defaultMenuItem.setAsync(true);
/* 300 */       defaultMenuItem.setAjax(true);
/* 301 */       warnWidthAndHeight(menuItemDef);
/*     */     }
/*     */     else {
/* 304 */       this.log.warn("メニューID:{}のsubWindowの値が想定外です。 値：{}", menuItemDef.getMenuID(), subWindow);
/*     */     }
/*     */     
/*     */ 
/* 308 */     Map<String, List<String>> param = new HashMap();
/* 309 */     List<String> value = new ArrayList();
/* 310 */     value.add(menuItemDef.getMenuID());
/* 311 */     param.put("MENU_ID", value);
/* 312 */     defaultMenuItem.setParams(param);
/*     */     
/*     */ 
/* 315 */     this.menuDefMap.put(menuItemDef.getMenuID(), menuItemDef);
/*     */     
/*     */ 
/* 318 */     return isEnable(menuItemDef.getScreenId());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean setSubMenuItem(DefaultSubMenu defaultSubMenu, CfwMenuDefElement subMenuItemDef)
/*     */   {
/* 330 */     defaultSubMenu.setId(subMenuItemDef.getMenuID());
/* 331 */     defaultSubMenu.setLabel(subMenuItemDef.getLabel());
/* 332 */     defaultSubMenu.setIcon(subMenuItemDef.getIcon());
/*     */     
/*     */ 
/* 335 */     boolean result = false;
/*     */     
/* 337 */     List<CfwMenuDefElement> elements = subMenuItemDef.getMenuElements();
/* 338 */     for (CfwMenuDefElement cfwMenuDefElement : elements)
/*     */     {
/* 340 */       boolean childeEnable = false;
/* 341 */       MenuElement element = null;
/* 342 */       String label = cfwMenuDefElement.getLabel();
/*     */       
/*     */ 
/* 345 */       if ((cfwMenuDefElement instanceof CfwSubMenuDef)) {
/* 346 */         element = new DefaultSubMenu(label);
/* 347 */         DefaultSubMenu e2 = (DefaultSubMenu)element;
/* 348 */         childeEnable = setSubMenuItem(e2, cfwMenuDefElement);
/*     */       } else {
/* 350 */         element = new DefaultMenuItem(label);
/* 351 */         DefaultMenuItem e2 = (DefaultMenuItem)element;
/* 352 */         CfwMenuItemDef def = (CfwMenuItemDef)cfwMenuDefElement;
/* 353 */         childeEnable = setMenuItem(e2, def);
/*     */       }
/*     */       
/* 356 */       if (childeEnable) {
/* 357 */         defaultSubMenu.addElement(element);
/* 358 */         result = true;
/*     */       }
/*     */     }
/*     */     
/* 362 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean isEnable(String menuDefScreenId)
/*     */   {
/* 374 */     String screenId = this.util.menuDefToDBDefScreenId(menuDefScreenId);
/*     */     
/*     */ 
/* 377 */     List<String> allowedList = this.util.allowedScreenId(this.session);
/*     */     
/* 379 */     if ((allowedList == null) || (!allowedList.contains(screenId))) {
/* 380 */       this.log.debug("権限に紐づく利用可能画面IDが設定されていません。画面ID:{}", screenId);
/* 381 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 385 */     if (!this.cfwMenubarInfoCache.isAvailableTimeByScreenId(screenId)) {
/* 386 */       return false;
/*     */     }
/*     */     
/* 389 */     if (!this.cfwMenubarInfoCache.isAvailableMaintenance(screenId)) {
/* 390 */       return false;
/*     */     }
/*     */     
/* 393 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean warnWidthAndHeight(CfwMenuItemDef menuItemDef)
/*     */   {
/* 405 */     int width = menuItemDef.getWidth();
/* 406 */     int height = menuItemDef.getHeight();
/*     */     
/* 408 */     if ((width == 0) && (height == 0)) {
/* 409 */       this.log.warn("メニューID:{}のwidthとheightが設定されていません。", menuItemDef.getMenuID());
/* 410 */       menuItemDef.setWidth(300);
/* 411 */       menuItemDef.setHeight(300);
/* 412 */       return true;
/*     */     }
/* 414 */     if (width == 0) {
/* 415 */       this.log.warn("メニューID:{}のwidthが設定されていません。", menuItemDef.getMenuID());
/* 416 */       menuItemDef.setWidth(300);
/* 417 */       return true;
/*     */     }
/* 419 */     if (height == 0) {
/* 420 */       this.log.warn("メニューID:{}のheightが設定されていません。", menuItemDef.getMenuID());
/* 421 */       menuItemDef.setHeight(300);
/* 422 */       return true;
/*     */     }
/* 424 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\menu\CfwMenuModelGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */