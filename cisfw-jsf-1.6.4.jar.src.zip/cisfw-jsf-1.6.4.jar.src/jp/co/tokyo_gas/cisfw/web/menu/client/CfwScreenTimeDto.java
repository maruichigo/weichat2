/*     */ package jp.co.tokyo_gas.cisfw.web.menu.client;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name="cfwScreenTimeDto", propOrder={"canUseFlg", "gmnId", "timeInfo"})
/*     */ public class CfwScreenTimeDto
/*     */ {
/*     */   protected String canUseFlg;
/*     */   protected String gmnId;
/*     */   protected String timeInfo;
/*     */   
/*     */   public String getCanUseFlg()
/*     */   {
/*  51 */     return this.canUseFlg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCanUseFlg(String value)
/*     */   {
/*  63 */     this.canUseFlg = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getGmnId()
/*     */   {
/*  75 */     return this.gmnId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setGmnId(String value)
/*     */   {
/*  87 */     this.gmnId = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTimeInfo()
/*     */   {
/*  99 */     return this.timeInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeInfo(String value)
/*     */   {
/* 111 */     this.timeInfo = value;
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\menu\client\CfwScreenTimeDto.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */