/*     */ package jp.co.tokyo_gas.cisfw.web.menu;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.List;
/*     */ import javax.enterprise.context.Dependent;
/*     */ import javax.inject.Inject;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.config.FwConfig;
/*     */ import jp.co.tokyo_gas.cisfw.web.CfwSession;
/*     */ import jp.co.tokyo_gas.cisfw.web.CfwUserInfo;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Dependent
/*     */ public class CfwMenuUtil
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   public static final int GMN_ID_LENGTH = 8;
/*     */   @Inject
/*     */   private FwConfig fwConfig;
/*     */   
/*     */   public String menuDefToDBDefScreenId(String menuDefScreenId)
/*     */   {
/*  43 */     String screenId = StringUtils.right(menuDefScreenId, 8);
/*  44 */     return screenId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String facesViewIdToDbDefScreenId(String facesViewId)
/*     */   {
/*  55 */     String screenId = StringUtils.right(trimXhtmlIfNeed(facesViewId), 8);
/*  56 */     return screenId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String facesViewIdToMenuDefScreenId(String facesViewId)
/*     */   {
/*  66 */     String menuDefScreenId = trimXhtmlIfNeed(facesViewId);
/*  67 */     return menuDefScreenId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String trimXhtmlIfNeed(String fwConfigMenuId)
/*     */   {
/*  79 */     if (fwConfigMenuId == null) {
/*  80 */       return null;
/*     */     }
/*     */     
/*  83 */     String suffix = ".xhtml";
/*  84 */     if (!fwConfigMenuId.endsWith(".xhtml")) {
/*  85 */       return fwConfigMenuId;
/*     */     }
/*     */     
/*  88 */     int suffixLength = ".xhtml".length();
/*  89 */     int menuIdLength = fwConfigMenuId.length();
/*  90 */     int endIndex = menuIdLength - suffixLength;
/*     */     
/*  92 */     return fwConfigMenuId.substring(0, endIndex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> allowedScreenId(CfwSession cfwSession)
/*     */   {
/* 102 */     CfwUserInfo userInfo = userInfo(cfwSession);
/* 103 */     if (userInfo == null) {
/* 104 */       return null;
/*     */     }
/*     */     
/* 107 */     return userInfo.getAllowedScreenId();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean excludeByConfig()
/*     */   {
/* 117 */     String menuCheckDb = this.fwConfig.get("menu.check.exclude");
/* 118 */     if ("1".equals(menuCheckDb)) {
/* 119 */       return true;
/*     */     }
/* 121 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   List<String> allowedAuthorityCd(CfwSession cfwSession)
/*     */   {
/* 132 */     CfwUserInfo userInfo = userInfo(cfwSession);
/* 133 */     if (userInfo == null) {
/* 134 */       return null;
/*     */     }
/*     */     
/* 137 */     return userInfo.getAllowedAuthorityCd();
/*     */   }
/*     */   
/*     */   private CfwUserInfo userInfo(CfwSession cfwSession) {
/* 141 */     if (cfwSession == null) {
/* 142 */       return null;
/*     */     }
/* 144 */     if (cfwSession.getUserInfo() == null) {
/* 145 */       return null;
/*     */     }
/* 147 */     return cfwSession.getUserInfo();
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\menu\CfwMenuUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */