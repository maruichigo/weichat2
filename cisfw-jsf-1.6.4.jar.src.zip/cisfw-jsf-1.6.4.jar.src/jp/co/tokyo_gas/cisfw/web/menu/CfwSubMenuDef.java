/*     */ package jp.co.tokyo_gas.cisfw.web.menu;
/*     */ 
/*     */ import java.util.List;
/*     */ import javax.xml.bind.annotation.XmlAttribute;
/*     */ import javax.xml.bind.annotation.XmlElements;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CfwSubMenuDef
/*     */   implements CfwMenuDefElement
/*     */ {
/*     */   private String menuID;
/*     */   private String label;
/*     */   private String icon;
/*     */   private List<CfwMenuDefElement> menuElements;
/*     */   
/*     */   @XmlAttribute(name="id")
/*     */   public String getMenuID()
/*     */   {
/*  42 */     return this.menuID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @XmlAttribute(name="label")
/*     */   public String getLabel()
/*     */   {
/*  52 */     return this.label;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @XmlAttribute(name="icon")
/*     */   public String getIcon()
/*     */   {
/*  62 */     return this.icon;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @XmlElements({@javax.xml.bind.annotation.XmlElement(name="submenu", type=CfwSubMenuDef.class), @javax.xml.bind.annotation.XmlElement(name="menuitem", type=CfwMenuItemDef.class)})
/*     */   public List<CfwMenuDefElement> getMenuElements()
/*     */   {
/*  73 */     return this.menuElements;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMenuID(String menuID)
/*     */   {
/*  82 */     this.menuID = menuID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLabel(String label)
/*     */   {
/*  91 */     this.label = label;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIcon(String icon)
/*     */   {
/* 100 */     this.icon = icon;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMenuElements(List<CfwMenuDefElement> menuElements)
/*     */   {
/* 110 */     this.menuElements = menuElements;
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\menu\CfwSubMenuDef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */