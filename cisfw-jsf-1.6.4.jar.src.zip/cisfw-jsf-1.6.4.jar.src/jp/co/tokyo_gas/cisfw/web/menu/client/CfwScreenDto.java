/*     */ package jp.co.tokyo_gas.cisfw.web.menu.client;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name="cfwScreenDto", propOrder={"currentTimeInfo", "maintenances", "screenTimeList"})
/*     */ public class CfwScreenDto
/*     */ {
/*     */   protected String currentTimeInfo;
/*     */   @XmlElement(nillable=true)
/*     */   protected List<String> maintenances;
/*     */   @XmlElement(nillable=true)
/*     */   protected List<CfwScreenTimeDto> screenTimeList;
/*     */   
/*     */   public String getCurrentTimeInfo()
/*     */   {
/*  56 */     return this.currentTimeInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCurrentTimeInfo(String value)
/*     */   {
/*  68 */     this.currentTimeInfo = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getMaintenances()
/*     */   {
/*  94 */     if (this.maintenances == null) {
/*  95 */       this.maintenances = new ArrayList();
/*     */     }
/*  97 */     return this.maintenances;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<CfwScreenTimeDto> getScreenTimeList()
/*     */   {
/* 123 */     if (this.screenTimeList == null) {
/* 124 */       this.screenTimeList = new ArrayList();
/*     */     }
/* 126 */     return this.screenTimeList;
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\menu\client\CfwScreenDto.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */