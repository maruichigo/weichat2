/*    */ package jp.co.tokyo_gas.cisfw.web.menu;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ import java.util.stream.Stream;
/*    */ import javax.enterprise.context.Dependent;
/*    */ import javax.enterprise.inject.Instance;
/*    */ import javax.enterprise.inject.spi.CDI;
/*    */ import javax.enterprise.util.AnnotationLiteral;
/*    */ import javax.inject.Inject;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.config.FwConfig;
/*    */ import jp.co.tokyo_gas.cisfw.init.CfwQualifier;
/*    */ import jp.co.tokyo_gas.cisfw.logger.CfwLogger;
/*    */ import jp.co.tokyo_gas.cisfw.menu.provider.CfwMenuControlManager;
/*    */ import jp.co.tokyo_gas.cisfw.web.menu.client.CfwMenuControlService;
/*    */ import jp.co.tokyo_gas.cisfw.web.menu.client.CfwMenuControlServiceService;
/*    */ import jp.co.tokyo_gas.cisfw.web.ws.CfwServiceFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Dependent
/*    */ public class CfwScreenAuthorityGetter
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   @Inject
/*    */   private CfwLogger log;
/*    */   @Inject
/*    */   private CfwServiceFactory factory;
/*    */   @Inject
/*    */   private FwConfig config;
/*    */   
/*    */   public List<String> get(List<String> authorities)
/*    */   {
/* 54 */     if ((authorities == null) || (authorities.size() == 0)) {
/* 55 */       return new ArrayList();
/*    */     }
/*    */     
/* 58 */     if (this.log.isDebugEnabled()) {
/* 59 */       String prefix = "authorities";
/* 60 */       String suffix = "";
/* 61 */       String listMsg = (String)authorities.stream().collect(Collectors.joining(",", "authorities", ""));
/* 62 */       this.log.debug(listMsg);
/*    */     }
/*    */     
/* 65 */     return getScreenIdList(authorities);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private List<String> getScreenIdList(List<String> authorities)
/*    */   {
/* 75 */     if ("true".equals(this.config.get("ear.integration", "false")))
/*    */     {
/* 77 */       CfwMenuControlManager manager = (CfwMenuControlManager)getManager();
/* 78 */       return new ArrayList(manager.findScreenId(authorities));
/*    */     }
/*    */     
/* 81 */     CfwMenuControlService service = (CfwMenuControlService)this.factory.createSEI(CfwMenuControlServiceService.class, CfwMenuControlService.class);
/*    */     
/* 83 */     return service.findScreenId(authorities);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected Object getManager()
/*    */   {
/* 92 */     CDI.current().select(CfwMenuControlManager.class, new Annotation[] { new AnnotationLiteral() {} }).get();
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\menu\CfwScreenAuthorityGetter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */