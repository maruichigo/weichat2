/*    */ package jp.co.tokyo_gas.cisfw.web.menu;
/*    */ 
/*    */ import javax.annotation.PostConstruct;
/*    */ import javax.enterprise.context.ApplicationScoped;
/*    */ import javax.inject.Inject;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.init.FwInitializer;
/*    */ import jp.co.tokyo_gas.cisfw.logger.CfwLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ApplicationScoped
/*    */ public class CfwMenuBarCacheInitializer
/*    */   implements FwInitializer
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   @Inject
/*    */   private CfwLogger log;
/*    */   @Inject
/*    */   private CfwMenuControlInfoGetter cfwMenuControlInfoGetter;
/*    */   
/*    */   @PostConstruct
/*    */   public void initialize()
/*    */   {
/*    */     try
/*    */     {
/* 40 */       this.cfwMenuControlInfoGetter.initializeData();
/*    */     } catch (Exception e) {
/* 42 */       this.log.error("メニューバー情報初期化処理でエラーが発生しました。", e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\menu\CfwMenuBarCacheInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */