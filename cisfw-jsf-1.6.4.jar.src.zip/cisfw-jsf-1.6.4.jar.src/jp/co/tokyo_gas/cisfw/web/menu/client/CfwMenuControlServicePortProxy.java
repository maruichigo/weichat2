/*     */ package jp.co.tokyo_gas.cisfw.web.menu.client;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.ws.BindingProvider;
/*     */ import javax.xml.ws.Dispatch;
/*     */ import javax.xml.ws.Service.Mode;
/*     */ import javax.xml.ws.soap.SOAPBinding;
/*     */ 
/*     */ public class CfwMenuControlServicePortProxy
/*     */ {
/*     */   protected Descriptor _descriptor;
/*     */   
/*     */   public class Descriptor
/*     */   {
/*  21 */     private CfwMenuControlServiceService _service = null;
/*  22 */     private CfwMenuControlService _proxy = null;
/*  23 */     private Dispatch<Source> _dispatch = null;
/*  24 */     private boolean _useJNDIOnly = false;
/*     */     
/*     */     public Descriptor() {
/*  27 */       init();
/*     */     }
/*     */     
/*     */     public Descriptor(URL wsdlLocation, QName serviceName) {
/*  31 */       this._service = new CfwMenuControlServiceService(wsdlLocation, serviceName);
/*  32 */       initCommon();
/*     */     }
/*     */     
/*     */     public void init() {
/*  36 */       this._service = null;
/*  37 */       this._proxy = null;
/*  38 */       this._dispatch = null;
/*     */       try
/*     */       {
/*  41 */         InitialContext ctx = new InitialContext();
/*  42 */         this._service = ((CfwMenuControlServiceService)ctx.lookup("java:comp/env/service/CfwMenuControlServiceService"));
/*     */       }
/*     */       catch (NamingException e)
/*     */       {
/*  46 */         if ("true".equalsIgnoreCase(System.getProperty("DEBUG_PROXY"))) {
/*  47 */           System.out.println("JNDI lookup failure: javax.naming.NamingException: " + e.getMessage());
/*  48 */           e.printStackTrace(System.out);
/*     */         }
/*     */       }
/*     */       
/*  52 */       if ((this._service == null) && (!this._useJNDIOnly))
/*  53 */         this._service = new CfwMenuControlServiceService();
/*  54 */       initCommon();
/*     */     }
/*     */     
/*     */     private void initCommon() {
/*  58 */       this._proxy = this._service.getCfwMenuControlServicePort();
/*     */     }
/*     */     
/*     */     public CfwMenuControlService getProxy() {
/*  62 */       return this._proxy;
/*     */     }
/*     */     
/*     */     public void useJNDIOnly(boolean useJNDIOnly) {
/*  66 */       this._useJNDIOnly = useJNDIOnly;
/*  67 */       init();
/*     */     }
/*     */     
/*     */     public Dispatch<Source> getDispatch() {
/*  71 */       if (this._dispatch == null) {
/*  72 */         QName portQName = new QName("", "CfwMenuControlServicePort");
/*  73 */         this._dispatch = this._service.createDispatch(portQName, Source.class, Service.Mode.MESSAGE);
/*     */         
/*  75 */         String proxyEndpointUrl = getEndpoint();
/*  76 */         BindingProvider bp = this._dispatch;
/*  77 */         String dispatchEndpointUrl = (String)bp.getRequestContext().get("javax.xml.ws.service.endpoint.address");
/*  78 */         if (!dispatchEndpointUrl.equals(proxyEndpointUrl))
/*  79 */           bp.getRequestContext().put("javax.xml.ws.service.endpoint.address", proxyEndpointUrl);
/*     */       }
/*  81 */       return this._dispatch;
/*     */     }
/*     */     
/*     */     public String getEndpoint() {
/*  85 */       BindingProvider bp = (BindingProvider)this._proxy;
/*  86 */       return (String)bp.getRequestContext().get("javax.xml.ws.service.endpoint.address");
/*     */     }
/*     */     
/*     */     public void setEndpoint(String endpointUrl) {
/*  90 */       BindingProvider bp = (BindingProvider)this._proxy;
/*  91 */       bp.getRequestContext().put("javax.xml.ws.service.endpoint.address", endpointUrl);
/*     */       
/*  93 */       if (this._dispatch != null) {
/*  94 */         bp = this._dispatch;
/*  95 */         bp.getRequestContext().put("javax.xml.ws.service.endpoint.address", endpointUrl);
/*     */       }
/*     */     }
/*     */     
/*     */     public void setMTOMEnabled(boolean enable) {
/* 100 */       SOAPBinding binding = (SOAPBinding)((BindingProvider)this._proxy).getBinding();
/* 101 */       binding.setMTOMEnabled(enable);
/*     */     }
/*     */   }
/*     */   
/*     */   public CfwMenuControlServicePortProxy() {
/* 106 */     this._descriptor = new Descriptor();
/* 107 */     this._descriptor.setMTOMEnabled(false);
/*     */   }
/*     */   
/*     */   public CfwMenuControlServicePortProxy(URL wsdlLocation, QName serviceName) {
/* 111 */     this._descriptor = new Descriptor(wsdlLocation, serviceName);
/* 112 */     this._descriptor.setMTOMEnabled(false);
/*     */   }
/*     */   
/*     */   public Descriptor _getDescriptor() {
/* 116 */     return this._descriptor;
/*     */   }
/*     */   
/*     */   public String findCurrentTime() {
/* 120 */     return _getDescriptor().getProxy().findCurrentTime();
/*     */   }
/*     */   
/*     */   public List<String> findScreenId(List<String> arg0) {
/* 124 */     return _getDescriptor().getProxy().findScreenId(arg0);
/*     */   }
/*     */   
/*     */   public CfwScreenDto findDatas() {
/* 128 */     return _getDescriptor().getProxy().findDatas();
/*     */   }
/*     */   
/*     */   public List<String> findMaintenance() {
/* 132 */     return _getDescriptor().getProxy().findMaintenance();
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\menu\client\CfwMenuControlServicePortProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */