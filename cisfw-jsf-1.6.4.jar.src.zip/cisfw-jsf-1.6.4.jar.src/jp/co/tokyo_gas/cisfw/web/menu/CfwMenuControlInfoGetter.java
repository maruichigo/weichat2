/*     */ package jp.co.tokyo_gas.cisfw.web.menu;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.enterprise.context.Dependent;
/*     */ import javax.enterprise.inject.Instance;
/*     */ import javax.enterprise.inject.spi.CDI;
/*     */ import javax.enterprise.util.AnnotationLiteral;
/*     */ import javax.inject.Inject;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.config.FwConfig;
/*     */ import jp.co.tokyo_gas.cisfw.init.CfwQualifier;
/*     */ import jp.co.tokyo_gas.cisfw.logger.CfwLogger;
/*     */ import jp.co.tokyo_gas.cisfw.menu.provider.CfwMenuControlManager;
/*     */ import jp.co.tokyo_gas.cisfw.web.menu.client.CfwMenuControlService;
/*     */ import jp.co.tokyo_gas.cisfw.web.menu.client.CfwMenuControlServiceService;
/*     */ import jp.co.tokyo_gas.cisfw.web.ws.CfwServiceFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Dependent
/*     */ public class CfwMenuControlInfoGetter
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   public static final String MODE_TIME = "1";
/*     */   public static final String MODE_MAINTENANCE = "2";
/*     */   @Inject
/*     */   private CfwLogger log;
/*     */   @Inject
/*     */   private CfwServiceFactory factory;
/*     */   @Inject
/*     */   private CfwMenubarInfoCache cfwMenubarInfoCache;
/*     */   @Inject
/*     */   private FwConfig config;
/*     */   
/*     */   public void initializeData()
/*     */   {
/*  68 */     jp.co.tokyo_gas.cisfw.web.menu.client.CfwScreenDto dto = getCfwScreenDto();
/*     */     
/*     */ 
/*  71 */     this.cfwMenubarInfoCache.setCurrentTimeInfo(dto.getCurrentTimeInfo());
/*  72 */     this.cfwMenubarInfoCache.setScreenMaintenanceSet(new HashSet(dto.getMaintenances()));
/*     */     
/*     */ 
/*  75 */     Map<String, Map<String, Boolean>> map = toMap(dto.getScreenTimeList());
/*  76 */     this.cfwMenubarInfoCache.setScreenTimeMap(map);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean refreshMaintenance()
/*     */   {
/*     */     try
/*     */     {
/*  89 */       List<String> list = getMaintenance();
/*  90 */       this.cfwMenubarInfoCache.setScreenMaintenanceSet(new HashSet(list));
/*  91 */       return true;
/*     */     } catch (Exception e) {
/*  93 */       this.log.error("画面メンテナンス情報の取得に失敗しました。", e); }
/*  94 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean refreshCurrentTime()
/*     */   {
/*     */     try
/*     */     {
/* 110 */       String currentTimeInfo = getCurrentTimeInfo();
/* 111 */       this.cfwMenubarInfoCache.setCurrentTimeInfo(currentTimeInfo);
/* 112 */       return true;
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 117 */       this.log.error("現在時間帯情報の取得に失敗しました。", e); }
/* 118 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean validateMode(String mode)
/*     */   {
/* 131 */     if (("1".equals(mode)) || ("2".equals(mode))) {
/* 132 */       return true;
/*     */     }
/* 134 */     String msg = "メニューキャッシュ再構築処理で渡された値が正しい値ではありません。mode:{}";
/* 135 */     this.log.warn("メニューキャッシュ再構築処理で渡された値が正しい値ではありません。mode:{}", mode);
/* 136 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Map<String, Map<String, Boolean>> toMap(List<jp.co.tokyo_gas.cisfw.web.menu.client.CfwScreenTimeDto> list)
/*     */   {
/* 149 */     Map<String, Map<String, Boolean>> map = new HashMap();
/* 150 */     String flgTrue = "1";
/*     */     
/* 152 */     for (jp.co.tokyo_gas.cisfw.web.menu.client.CfwScreenTimeDto dto : list)
/*     */     {
/* 154 */       String gmnId = dto.getGmnId();
/* 155 */       Map<String, Boolean> kbn = null;
/* 156 */       if (map.containsKey(gmnId)) {
/* 157 */         kbn = (Map)map.get(gmnId);
/*     */       } else {
/* 159 */         kbn = new HashMap();
/* 160 */         map.put(gmnId, kbn);
/*     */       }
/* 162 */       boolean canUse = "1".equals(dto.getCanUseFlg());
/* 163 */       kbn.put(dto.getTimeInfo(), Boolean.valueOf(canUse));
/*     */     }
/* 165 */     return map;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   CfwMenuControlService getService()
/*     */   {
/* 174 */     return (CfwMenuControlService)this.factory.createSEI(CfwMenuControlServiceService.class, CfwMenuControlService.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private jp.co.tokyo_gas.cisfw.web.menu.client.CfwScreenDto getCfwScreenDto()
/*     */   {
/* 183 */     jp.co.tokyo_gas.cisfw.web.menu.client.CfwScreenDto dto = new jp.co.tokyo_gas.cisfw.web.menu.client.CfwScreenDto();
/*     */     
/* 185 */     if ("true".equals(this.config.get("ear.integration", "false")))
/*     */     {
/* 187 */       CfwMenuControlManager manager = (CfwMenuControlManager)getManager();
/* 188 */       jp.co.tokyo_gas.cisfw.menu.provider.CfwScreenDto cfwScreenDto = new jp.co.tokyo_gas.cisfw.menu.provider.CfwScreenDto();
/*     */       
/* 190 */       cfwScreenDto = manager.findDatas();
/*     */       
/* 192 */       List<jp.co.tokyo_gas.cisfw.web.menu.client.CfwScreenTimeDto> screenTimeList = new ArrayList();
/* 193 */       for (jp.co.tokyo_gas.cisfw.menu.dao.CfwScreenTimeDto screenTimeDtoProvider : cfwScreenDto.getScreenTimeList())
/*     */       {
/* 195 */         jp.co.tokyo_gas.cisfw.web.menu.client.CfwScreenTimeDto screenTimeDto = new jp.co.tokyo_gas.cisfw.web.menu.client.CfwScreenTimeDto();
/* 196 */         screenTimeDto.setGmnId(screenTimeDtoProvider.getGmnId());
/* 197 */         screenTimeDto.setTimeInfo(screenTimeDtoProvider.getTimeInfo());
/* 198 */         screenTimeDto.setCanUseFlg(screenTimeDtoProvider.getCanUseFlg());
/* 199 */         screenTimeList.add(screenTimeDto);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 204 */       dto.setCurrentTimeInfo(cfwScreenDto.getCurrentTimeInfo());
/* 205 */       for (String maintenance : cfwScreenDto.getMaintenances()) {
/* 206 */         dto.getMaintenances().add(maintenance);
/*     */       }
/* 208 */       for (jp.co.tokyo_gas.cisfw.web.menu.client.CfwScreenTimeDto screenTime : screenTimeList) {
/* 209 */         dto.getScreenTimeList().add(screenTime);
/*     */       }
/*     */     }
/*     */     else {
/* 213 */       CfwMenuControlService service = getService();
/* 214 */       dto = service.findDatas();
/*     */     }
/* 216 */     return dto;
/*     */   }
/*     */   
/*     */ 
/*     */   private List<String> getMaintenance()
/*     */   {
/*     */     List<String> list;
/*     */     
/*     */     List<String> list;
/*     */     
/* 226 */     if ("true".equals(this.config.get("ear.integration", "false")))
/*     */     {
/* 228 */       CfwMenuControlManager manager = (CfwMenuControlManager)getManager();
/* 229 */       list = new ArrayList(manager.findMaintenance());
/*     */     }
/*     */     else {
/* 232 */       CfwMenuControlService service = getService();
/* 233 */       list = service.findMaintenance();
/*     */     }
/* 235 */     return list;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getCurrentTimeInfo()
/*     */   {
/* 244 */     String currentTimeInfo = "";
/*     */     
/* 246 */     if ("true".equals(this.config.get("ear.integration", "false"))) {
/* 247 */       CfwMenuControlManager manager = (CfwMenuControlManager)getManager();
/*     */       
/* 249 */       currentTimeInfo = manager.findCurrentTime();
/*     */     }
/*     */     else {
/* 252 */       CfwMenuControlService service = getService();
/* 253 */       currentTimeInfo = service.findCurrentTime();
/*     */     }
/* 255 */     return currentTimeInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object getManager()
/*     */   {
/* 263 */     CDI.current().select(CfwMenuControlManager.class, new Annotation[] { new AnnotationLiteral() {} }).get();
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\menu\CfwMenuControlInfoGetter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */