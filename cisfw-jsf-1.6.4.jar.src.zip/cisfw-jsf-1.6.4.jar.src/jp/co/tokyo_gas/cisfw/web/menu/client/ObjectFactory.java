/*     */ package jp.co.tokyo_gas.cisfw.web.menu.client;
/*     */ 
/*     */ import javax.xml.bind.JAXBElement;
/*     */ import javax.xml.bind.annotation.XmlElementDecl;
/*     */ import javax.xml.bind.annotation.XmlRegistry;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlRegistry
/*     */ public class ObjectFactory
/*     */ {
/*  27 */   private static final QName _FindScreenId_QNAME = new QName("http://provider.menu.cisfw.tokyo_gas.co.jp/", "findScreenId");
/*  28 */   private static final QName _FindMaintenance_QNAME = new QName("http://provider.menu.cisfw.tokyo_gas.co.jp/", "findMaintenance");
/*  29 */   private static final QName _FindCurrentTime_QNAME = new QName("http://provider.menu.cisfw.tokyo_gas.co.jp/", "findCurrentTime");
/*  30 */   private static final QName _FindMaintenanceResponse_QNAME = new QName("http://provider.menu.cisfw.tokyo_gas.co.jp/", "findMaintenanceResponse");
/*  31 */   private static final QName _FindCurrentTimeResponse_QNAME = new QName("http://provider.menu.cisfw.tokyo_gas.co.jp/", "findCurrentTimeResponse");
/*  32 */   private static final QName _FindScreenIdResponse_QNAME = new QName("http://provider.menu.cisfw.tokyo_gas.co.jp/", "findScreenIdResponse");
/*  33 */   private static final QName _FindDatas_QNAME = new QName("http://provider.menu.cisfw.tokyo_gas.co.jp/", "findDatas");
/*  34 */   private static final QName _FindDatasResponse_QNAME = new QName("http://provider.menu.cisfw.tokyo_gas.co.jp/", "findDatasResponse");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FindScreenId createFindScreenId()
/*     */   {
/*  48 */     return new FindScreenId();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public FindMaintenance createFindMaintenance()
/*     */   {
/*  56 */     return new FindMaintenance();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public FindCurrentTime createFindCurrentTime()
/*     */   {
/*  64 */     return new FindCurrentTime();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public FindMaintenanceResponse createFindMaintenanceResponse()
/*     */   {
/*  72 */     return new FindMaintenanceResponse();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public FindCurrentTimeResponse createFindCurrentTimeResponse()
/*     */   {
/*  80 */     return new FindCurrentTimeResponse();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public FindScreenIdResponse createFindScreenIdResponse()
/*     */   {
/*  88 */     return new FindScreenIdResponse();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public FindDatas createFindDatas()
/*     */   {
/*  96 */     return new FindDatas();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public FindDatasResponse createFindDatasResponse()
/*     */   {
/* 104 */     return new FindDatasResponse();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwScreenDto createCfwScreenDto()
/*     */   {
/* 112 */     return new CfwScreenDto();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwScreenTimeDto createCfwScreenTimeDto()
/*     */   {
/* 120 */     return new CfwScreenTimeDto();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @XmlElementDecl(namespace="http://provider.menu.cisfw.tokyo_gas.co.jp/", name="findScreenId")
/*     */   public JAXBElement<FindScreenId> createFindScreenId(FindScreenId value)
/*     */   {
/* 129 */     return new JAXBElement(_FindScreenId_QNAME, FindScreenId.class, null, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @XmlElementDecl(namespace="http://provider.menu.cisfw.tokyo_gas.co.jp/", name="findMaintenance")
/*     */   public JAXBElement<FindMaintenance> createFindMaintenance(FindMaintenance value)
/*     */   {
/* 138 */     return new JAXBElement(_FindMaintenance_QNAME, FindMaintenance.class, null, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @XmlElementDecl(namespace="http://provider.menu.cisfw.tokyo_gas.co.jp/", name="findCurrentTime")
/*     */   public JAXBElement<FindCurrentTime> createFindCurrentTime(FindCurrentTime value)
/*     */   {
/* 147 */     return new JAXBElement(_FindCurrentTime_QNAME, FindCurrentTime.class, null, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @XmlElementDecl(namespace="http://provider.menu.cisfw.tokyo_gas.co.jp/", name="findMaintenanceResponse")
/*     */   public JAXBElement<FindMaintenanceResponse> createFindMaintenanceResponse(FindMaintenanceResponse value)
/*     */   {
/* 156 */     return new JAXBElement(_FindMaintenanceResponse_QNAME, FindMaintenanceResponse.class, null, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @XmlElementDecl(namespace="http://provider.menu.cisfw.tokyo_gas.co.jp/", name="findCurrentTimeResponse")
/*     */   public JAXBElement<FindCurrentTimeResponse> createFindCurrentTimeResponse(FindCurrentTimeResponse value)
/*     */   {
/* 165 */     return new JAXBElement(_FindCurrentTimeResponse_QNAME, FindCurrentTimeResponse.class, null, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @XmlElementDecl(namespace="http://provider.menu.cisfw.tokyo_gas.co.jp/", name="findScreenIdResponse")
/*     */   public JAXBElement<FindScreenIdResponse> createFindScreenIdResponse(FindScreenIdResponse value)
/*     */   {
/* 174 */     return new JAXBElement(_FindScreenIdResponse_QNAME, FindScreenIdResponse.class, null, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @XmlElementDecl(namespace="http://provider.menu.cisfw.tokyo_gas.co.jp/", name="findDatas")
/*     */   public JAXBElement<FindDatas> createFindDatas(FindDatas value)
/*     */   {
/* 183 */     return new JAXBElement(_FindDatas_QNAME, FindDatas.class, null, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @XmlElementDecl(namespace="http://provider.menu.cisfw.tokyo_gas.co.jp/", name="findDatasResponse")
/*     */   public JAXBElement<FindDatasResponse> createFindDatasResponse(FindDatasResponse value)
/*     */   {
/* 192 */     return new JAXBElement(_FindDatasResponse_QNAME, FindDatasResponse.class, null, value);
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\menu\client\ObjectFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */