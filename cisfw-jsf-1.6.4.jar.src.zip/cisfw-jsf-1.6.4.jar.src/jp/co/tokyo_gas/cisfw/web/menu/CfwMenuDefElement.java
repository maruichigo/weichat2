package jp.co.tokyo_gas.cisfw.web.menu;

import java.util.List;

public abstract interface CfwMenuDefElement
{
  public abstract String getMenuID();
  
  public abstract String getLabel();
  
  public abstract String getIcon();
  
  public abstract List<CfwMenuDefElement> getMenuElements();
}


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\menu\CfwMenuDefElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */