/*     */ package jp.co.tokyo_gas.cisfw.web.menu;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ import javax.enterprise.context.SessionScoped;
/*     */ import javax.inject.Named;
/*     */ import org.primefaces.model.menu.MenuModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Named("menuBarModel")
/*     */ @SessionScoped
/*     */ public class CfwMenuBarModel
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private MenuModel leftMenuModel;
/*     */   private MenuModel rightMenuModel;
/*     */   private Date lastModefied;
/*     */   private Map<String, CfwMenuItemDef> menuDefMap;
/*     */   
/*     */   public void setLeftMenuModel(MenuModel leftMenuModel)
/*     */   {
/*  57 */     this.leftMenuModel = leftMenuModel;
/*  58 */     this.lastModefied = new Date();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MenuModel getLeftMenuModel()
/*     */   {
/*  68 */     return this.leftMenuModel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRightMenuModel(MenuModel rightMenuModel)
/*     */   {
/*  78 */     this.rightMenuModel = rightMenuModel;
/*  79 */     this.lastModefied = new Date();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MenuModel getRightMenuModel()
/*     */   {
/*  88 */     return this.rightMenuModel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getLastModefied()
/*     */   {
/*  97 */     return this.lastModefied;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMenuDefMap(Map<String, CfwMenuItemDef> menuDefMap)
/*     */   {
/* 107 */     this.menuDefMap = menuDefMap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, CfwMenuItemDef> getMenuDefMap()
/*     */   {
/* 116 */     return this.menuDefMap;
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\menu\CfwMenuBarModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */