/*     */ package jp.co.tokyo_gas.cisfw.web.menu;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.bind.annotation.XmlAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CfwMenuItemDef
/*     */   implements CfwMenuDefElement
/*     */ {
/*     */   public static final String SUBWINDOW_NEW = "1";
/*     */   public static final String SUBWINDOW_SAME_WINDOW = "0";
/*     */   private static final String SUBWINDOW_CLOSE = "1";
/*     */   private String menuID;
/*     */   private String label;
/*     */   private String icon;
/*     */   private String screenId;
/*     */   private boolean sessionClear;
/*     */   private String parameters;
/*     */   private String subWindow;
/*     */   private String subWindowClose;
/*     */   private int width;
/*     */   private int height;
/*     */   
/*     */   @XmlAttribute(name="id")
/*     */   public String getMenuID()
/*     */   {
/*  87 */     return this.menuID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @XmlAttribute(name="label")
/*     */   public String getLabel()
/*     */   {
/*  97 */     return this.label;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @XmlAttribute(name="icon")
/*     */   public String getIcon()
/*     */   {
/* 107 */     return this.icon;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @XmlAttribute(name="screenId")
/*     */   public String getScreenId()
/*     */   {
/* 117 */     return this.screenId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @XmlAttribute(name="parameters")
/*     */   public String getParameters()
/*     */   {
/* 127 */     return this.parameters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @XmlAttribute(name="sessionClear")
/*     */   public boolean getSessionClear()
/*     */   {
/* 138 */     return this.sessionClear;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @XmlAttribute(name="subWindow")
/*     */   public String getSubWindow()
/*     */   {
/* 148 */     return this.subWindow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @XmlAttribute(name="subWindowClose")
/*     */   public String getSubWindowClose()
/*     */   {
/* 158 */     return this.subWindowClose;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @XmlAttribute(name="width")
/*     */   public int getWidth()
/*     */   {
/* 168 */     return this.width;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @XmlAttribute(name="height")
/*     */   public int getHeight()
/*     */   {
/* 178 */     return this.height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMenuID(String menuID)
/*     */   {
/* 187 */     this.menuID = menuID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLabel(String label)
/*     */   {
/* 196 */     this.label = label;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIcon(String icon)
/*     */   {
/* 205 */     this.icon = icon;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScreenId(String screenId)
/*     */   {
/* 214 */     this.screenId = screenId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParameters(String parameters)
/*     */   {
/* 223 */     this.parameters = parameters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSessionClear(boolean sessionClear)
/*     */   {
/* 232 */     this.sessionClear = sessionClear;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSubWindow(String subWindow)
/*     */   {
/* 241 */     this.subWindow = subWindow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSubWindowClose(String subWindowClose)
/*     */   {
/* 250 */     this.subWindowClose = subWindowClose;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWidth(int width)
/*     */   {
/* 259 */     this.width = width;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHeight(int height)
/*     */   {
/* 268 */     this.height = height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean needSubWindowClose()
/*     */   {
/* 278 */     String sub = this.subWindowClose;
/* 279 */     if ((sub != null) && (sub.equals("1"))) {
/* 280 */       return true;
/*     */     }
/* 282 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<CfwMenuDefElement> getMenuElements()
/*     */   {
/* 293 */     return new ArrayList();
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\menu\CfwMenuItemDef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */