/*     */ package jp.co.tokyo_gas.cisfw.web.menu;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.enterprise.context.ApplicationScoped;
/*     */ import javax.inject.Inject;
/*     */ import jp.co.tokyo_gas.cisfw.logger.CfwLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ApplicationScoped
/*     */ public class CfwMenubarInfoCache
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private Map<String, Map<String, Boolean>> screenTimeMap;
/*     */   private String currentTimeInfo;
/*     */   private Set<String> screenMaintenanceSet;
/*     */   private Date lastModefied;
/*     */   @Inject
/*     */   private CfwLogger log;
/*     */   @Inject
/*     */   private CfwMenuUtil util;
/*     */   
/*     */   public CfwMenubarInfoCache()
/*     */   {
/*  63 */     this.screenTimeMap = new HashMap();
/*  64 */     this.screenMaintenanceSet = new HashSet();
/*  65 */     this.lastModefied = new Date();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScreenTimeMap(Map<String, Map<String, Boolean>> screenTimeMap)
/*     */   {
/*  74 */     this.screenTimeMap = screenTimeMap;
/*  75 */     setLastModefied();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, Map<String, Boolean>> getScreenTimeMap()
/*     */   {
/*  84 */     return this.screenTimeMap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCurrentTimeInfo(String currentTimeInfo)
/*     */   {
/*  93 */     this.currentTimeInfo = currentTimeInfo;
/*  94 */     setLastModefied();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCurrentTimeInfo()
/*     */   {
/* 103 */     return this.currentTimeInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScreenMaintenanceSet(Set<String> screenMaintenanceSet)
/*     */   {
/* 112 */     this.screenMaintenanceSet = screenMaintenanceSet;
/* 113 */     setLastModefied();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<String> getScreenMaintenanceSet()
/*     */   {
/* 122 */     return this.screenMaintenanceSet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getLastModefied()
/*     */   {
/* 131 */     return this.lastModefied;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAvailableTime(String menuDefScreenId)
/*     */   {
/* 147 */     String screenId = this.util.menuDefToDBDefScreenId(menuDefScreenId);
/* 148 */     return isAvailableTimeByScreenId(screenId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean isAvailableTimeByScreenId(String screenId)
/*     */   {
/* 164 */     if (this.screenTimeMap.containsKey(screenId))
/*     */     {
/* 166 */       Map<String, Boolean> map = (Map)this.screenTimeMap.get(screenId);
/* 167 */       if (map.containsKey(this.currentTimeInfo)) {
/* 168 */         boolean isAvailable = ((Boolean)map.get(this.currentTimeInfo)).booleanValue();
/* 169 */         if ((this.log.isDebugEnabled()) && (!isAvailable)) {
/* 170 */           this.log.debug("画面ID:{},時間帯:{}は利用不可に設定されています。", screenId, this.currentTimeInfo);
/*     */         }
/* 172 */         return isAvailable;
/*     */       }
/*     */       
/*     */ 
/* 176 */       return availableTimeNg(screenId, this.currentTimeInfo);
/*     */     }
/*     */     
/*     */ 
/* 180 */     return availableTimeNg(screenId, this.currentTimeInfo);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAvailableMaintenance(String screenId)
/*     */   {
/* 195 */     boolean isAvailable = !this.screenMaintenanceSet.contains(screenId);
/*     */     
/* 197 */     if ((this.log.isDebugEnabled()) && (!isAvailable)) {
/* 198 */       this.log.debug("画面ID:{}はメンテナンス中と設定されています。", screenId);
/*     */     }
/* 200 */     return isAvailable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean availableTimeNg(String screenId, String currentTime)
/*     */   {
/* 214 */     if (this.util.excludeByConfig()) {
/* 215 */       this.log.debug("利用可能時間チェックはNGですが、設定によりOKとして取り扱います。画面ID:{},時間帯:{}", screenId, currentTime);
/* 216 */       return true;
/*     */     }
/*     */     
/* 219 */     String tblName = "画面時間帯別制御マスター";
/* 220 */     String warnMsg = "{}に画面ID:{},時間帯:{}のレコードがありません。";
/* 221 */     this.log.warn("{}に画面ID:{},時間帯:{}のレコードがありません。", new Object[] { "画面時間帯別制御マスター", screenId, this.currentTimeInfo });
/* 222 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setLastModefied()
/*     */   {
/* 231 */     this.lastModefied = new Date();
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\menu\CfwMenubarInfoCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */