/*    */ package jp.co.tokyo_gas.cisfw.web.menu.client;
/*    */ 
/*    */ import java.net.URL;
/*    */ import javax.xml.namespace.QName;
/*    */ import javax.xml.ws.Service;
/*    */ import javax.xml.ws.WebEndpoint;
/*    */ import javax.xml.ws.WebServiceClient;
/*    */ import javax.xml.ws.WebServiceException;
/*    */ import javax.xml.ws.WebServiceFeature;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @WebServiceClient(name="CfwMenuControlServiceService", targetNamespace="http://provider.menu.cisfw.tokyo_gas.co.jp/", wsdlLocation="WEB-INF/wsdl/CfwMenuControlServiceService.wsdl")
/*    */ public class CfwMenuControlServiceService
/*    */   extends Service
/*    */ {
/*    */   private static final URL CFWMENUCONTROLSERVICESERVICE_WSDL_LOCATION;
/*    */   private static final WebServiceException CFWMENUCONTROLSERVICESERVICE_EXCEPTION;
/* 26 */   private static final QName CFWMENUCONTROLSERVICESERVICE_QNAME = new QName("http://provider.menu.cisfw.tokyo_gas.co.jp/", "CfwMenuControlServiceService");
/*    */   
/*    */   static {
/* 29 */     CFWMENUCONTROLSERVICESERVICE_WSDL_LOCATION = CfwMenuControlServiceService.class.getResource("/WEB-INF/wsdl/CfwMenuControlServiceService.wsdl");
/* 30 */     WebServiceException e = null;
/* 31 */     if (CFWMENUCONTROLSERVICESERVICE_WSDL_LOCATION == null) {
/* 32 */       e = new WebServiceException("Cannot find 'WEB-INF/wsdl/CfwMenuControlServiceService.wsdl' wsdl. Place the resource correctly in the classpath.");
/*    */     }
/* 34 */     CFWMENUCONTROLSERVICESERVICE_EXCEPTION = e;
/*    */   }
/*    */   
/*    */   public CfwMenuControlServiceService() {
/* 38 */     super(__getWsdlLocation(), CFWMENUCONTROLSERVICESERVICE_QNAME);
/*    */   }
/*    */   
/*    */   public CfwMenuControlServiceService(WebServiceFeature... features) {
/* 42 */     super(__getWsdlLocation(), CFWMENUCONTROLSERVICESERVICE_QNAME, features);
/*    */   }
/*    */   
/*    */   public CfwMenuControlServiceService(URL wsdlLocation) {
/* 46 */     super(wsdlLocation, CFWMENUCONTROLSERVICESERVICE_QNAME);
/*    */   }
/*    */   
/*    */   public CfwMenuControlServiceService(URL wsdlLocation, WebServiceFeature... features) {
/* 50 */     super(wsdlLocation, CFWMENUCONTROLSERVICESERVICE_QNAME, features);
/*    */   }
/*    */   
/*    */   public CfwMenuControlServiceService(URL wsdlLocation, QName serviceName) {
/* 54 */     super(wsdlLocation, serviceName);
/*    */   }
/*    */   
/*    */   public CfwMenuControlServiceService(URL wsdlLocation, QName serviceName, WebServiceFeature... features) {
/* 58 */     super(wsdlLocation, serviceName, features);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   @WebEndpoint(name="CfwMenuControlServicePort")
/*    */   public CfwMenuControlService getCfwMenuControlServicePort()
/*    */   {
/* 68 */     return (CfwMenuControlService)super.getPort(new QName("http://provider.menu.cisfw.tokyo_gas.co.jp/", "CfwMenuControlServicePort"), CfwMenuControlService.class);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   @WebEndpoint(name="CfwMenuControlServicePort")
/*    */   public CfwMenuControlService getCfwMenuControlServicePort(WebServiceFeature... features)
/*    */   {
/* 80 */     return (CfwMenuControlService)super.getPort(new QName("http://provider.menu.cisfw.tokyo_gas.co.jp/", "CfwMenuControlServicePort"), CfwMenuControlService.class, features);
/*    */   }
/*    */   
/*    */   private static URL __getWsdlLocation() {
/* 84 */     if (CFWMENUCONTROLSERVICESERVICE_EXCEPTION != null) {
/* 85 */       throw CFWMENUCONTROLSERVICESERVICE_EXCEPTION;
/*    */     }
/* 87 */     return CFWMENUCONTROLSERVICESERVICE_WSDL_LOCATION;
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\menu\client\CfwMenuControlServiceService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */