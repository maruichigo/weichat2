/*    */ package jp.co.tokyo_gas.cisfw.web.menu;
/*    */ 
/*    */ import java.util.List;
/*    */ import javax.xml.bind.annotation.XmlElements;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlRootElement(name="menubar")
/*    */ public class CfwMenuBarDef
/*    */ {
/*    */   private List<CfwMenuDefElement> menuElements;
/*    */   
/*    */   @XmlElements({@javax.xml.bind.annotation.XmlElement(name="submenu", type=CfwSubMenuDef.class), @javax.xml.bind.annotation.XmlElement(name="menuitem", type=CfwMenuItemDef.class)})
/*    */   public List<CfwMenuDefElement> getMenuElements()
/*    */   {
/* 36 */     return this.menuElements;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setMenuElements(List<CfwMenuDefElement> menuElements)
/*    */   {
/* 45 */     this.menuElements = menuElements;
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\menu\CfwMenuBarDef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */