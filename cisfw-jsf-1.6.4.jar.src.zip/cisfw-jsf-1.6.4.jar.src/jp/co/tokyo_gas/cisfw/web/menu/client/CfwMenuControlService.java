package jp.co.tokyo_gas.cisfw.web.menu.client;

import java.util.List;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

@WebService(name="CfwMenuControlService", targetNamespace="http://provider.menu.cisfw.tokyo_gas.co.jp/")
@XmlSeeAlso({ObjectFactory.class})
public abstract interface CfwMenuControlService
{
  @WebMethod
  @WebResult(targetNamespace="")
  @RequestWrapper(localName="findCurrentTime", targetNamespace="http://provider.menu.cisfw.tokyo_gas.co.jp/", className="jp.co.tokyo_gas.cisfw.web.menu.client.FindCurrentTime")
  @ResponseWrapper(localName="findCurrentTimeResponse", targetNamespace="http://provider.menu.cisfw.tokyo_gas.co.jp/", className="jp.co.tokyo_gas.cisfw.web.menu.client.FindCurrentTimeResponse")
  public abstract String findCurrentTime();
  
  @WebMethod
  @WebResult(targetNamespace="")
  @RequestWrapper(localName="findScreenId", targetNamespace="http://provider.menu.cisfw.tokyo_gas.co.jp/", className="jp.co.tokyo_gas.cisfw.web.menu.client.FindScreenId")
  @ResponseWrapper(localName="findScreenIdResponse", targetNamespace="http://provider.menu.cisfw.tokyo_gas.co.jp/", className="jp.co.tokyo_gas.cisfw.web.menu.client.FindScreenIdResponse")
  public abstract List<String> findScreenId(@WebParam(name="arg0", targetNamespace="") List<String> paramList);
  
  @WebMethod
  @WebResult(targetNamespace="")
  @RequestWrapper(localName="findDatas", targetNamespace="http://provider.menu.cisfw.tokyo_gas.co.jp/", className="jp.co.tokyo_gas.cisfw.web.menu.client.FindDatas")
  @ResponseWrapper(localName="findDatasResponse", targetNamespace="http://provider.menu.cisfw.tokyo_gas.co.jp/", className="jp.co.tokyo_gas.cisfw.web.menu.client.FindDatasResponse")
  public abstract CfwScreenDto findDatas();
  
  @WebMethod
  @WebResult(targetNamespace="")
  @RequestWrapper(localName="findMaintenance", targetNamespace="http://provider.menu.cisfw.tokyo_gas.co.jp/", className="jp.co.tokyo_gas.cisfw.web.menu.client.FindMaintenance")
  @ResponseWrapper(localName="findMaintenanceResponse", targetNamespace="http://provider.menu.cisfw.tokyo_gas.co.jp/", className="jp.co.tokyo_gas.cisfw.web.menu.client.FindMaintenanceResponse")
  public abstract List<String> findMaintenance();
}


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\menu\client\CfwMenuControlService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */