/*     */ package jp.co.tokyo_gas.cisfw.web;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.el.ELContext;
/*     */ import javax.el.ELResolver;
/*     */ import javax.enterprise.inject.Instance;
/*     */ import javax.faces.application.Application;
/*     */ import javax.faces.application.FacesMessage;
/*     */ import javax.faces.application.FacesMessage.Severity;
/*     */ import javax.faces.component.UIComponent;
/*     */ import javax.faces.component.UIViewRoot;
/*     */ import javax.faces.context.ExternalContext;
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.inject.Inject;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.config.FwConfig;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.FwFacesContext;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.jsf.token.FwTokenUtils;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.string.FwStringConverter;
/*     */ import jp.co.tokyo_gas.cisfw.exception.CfwRuntimeException;
/*     */ import jp.co.tokyo_gas.cisfw.logger.CfwLogger;
/*     */ import jp.co.tokyo_gas.cisfw.message.CfwMessage;
/*     */ import jp.co.tokyo_gas.cisfw.message.CfwMessageManager;
/*     */ import jp.co.tokyo_gas.cisfw.web.interceptor.CfwBackingBeanLogger;
/*     */ import jp.co.tokyo_gas.cisfw.web.print.CfwPrintDto;
/*     */ import jp.co.tokyo_gas.cisfw.web.print.CfwPrintSession;
/*     */ import jp.co.tokyo_gas.cisfw.web.upload.CfwUploadDialog;
/*     */ import org.primefaces.context.RequestContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @CfwBackingBeanLogger
/*     */ public abstract class CfwBaseBean
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected static final String LOGIN = "LOGIN";
/*     */   protected static final String MENU = "MENU";
/*     */   @Inject
/*     */   private FwConfig fwConfig;
/*     */   @Inject
/*     */   private CfwSession session;
/*     */   @Inject
/*     */   private FwTokenUtils utils;
/*     */   @Inject
/*     */   private CfwLogger log;
/*     */   @Inject
/*     */   private HttpServletRequest request;
/*     */   @Inject
/*     */   private CfwPrintSession cfwPrintSession;
/*     */   @Inject
/*     */   private Instance<CfwScreenIdDecision> cfwScreenIdDecisionInstance;
/*     */   @Inject
/*     */   private CfwMessageManager messageManager;
/*     */   
/*     */   public String getRequestParameter(String key)
/*     */   {
/*  86 */     return this.request.getParameter(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String logout()
/*     */   {
/*  95 */     FwFacesContext.setKeepMessage(true);
/*  96 */     this.session.clear();
/*  97 */     return this.fwConfig.get("LOGIN") + "?faces-redirect=true";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String goMenu()
/*     */   {
/* 106 */     FwFacesContext.setKeepMessage(true);
/* 107 */     this.session.removeAll();
/* 108 */     String params = this.utils.getParamsForRedirect(false);
/* 109 */     return this.fwConfig.get("MENU") + "?faces-redirect=true&" + params;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String redirect(String xhtml)
/*     */   {
/* 120 */     String next = getScreenPath(xhtml);
/*     */     
/* 122 */     FwFacesContext.setKeepMessage(true);
/*     */     
/* 124 */     String params = this.utils.getParamsForRedirect(false);
/*     */     
/*     */ 
/* 127 */     String pathInfo = removeContextPathServletPath(next);
/*     */     
/*     */ 
/* 130 */     pathInfo = pathInfo.replace(".xhtml", "");
/*     */     
/*     */ 
/* 133 */     return pathInfo + "?faces-redirect=true&" + params;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void responseComplete(String xhtml)
/*     */   {
/*     */     try
/*     */     {
/* 147 */       String nextScreen = getScreenPath(xhtml);
/*     */       
/* 149 */       FacesContext context = FacesContext.getCurrentInstance();
/* 150 */       ExternalContext extContext = context.getExternalContext();
/*     */       
/* 152 */       extContext.redirect(extContext.encodeActionURL(createRequestURI(nextScreen)));
/* 153 */       context.responseComplete();
/*     */     }
/*     */     catch (Exception e) {
/* 156 */       throw new CfwRuntimeException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void responseCompleteBack()
/*     */   {
/* 165 */     String xhtml = this.session.popScreen();
/* 166 */     if (xhtml == null) {
/* 167 */       return;
/*     */     }
/*     */     try {
/* 170 */       FacesContext context = FacesContext.getCurrentInstance();
/* 171 */       ExternalContext extContext = context.getExternalContext();
/*     */       
/* 173 */       extContext.redirect(extContext.encodeActionURL(createRequestURI(xhtml)));
/* 174 */       context.responseComplete();
/*     */     } catch (Exception e) {
/* 176 */       throw new CfwRuntimeException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void openSubWindow(String xhtml, int width, int height)
/*     */   {
/* 191 */     this.session.createWindowSession(xhtml);
/*     */     
/*     */ 
/* 194 */     String nextScreen = getScreenPath(xhtml);
/*     */     
/*     */ 
/* 197 */     String params = "width=" + width;
/* 198 */     params = params + ",height=" + height;
/* 199 */     params = params + ",menubar=no,toolbar=no,location=no,status=no,resizable=no,scrollbars=yes";
/*     */     
/*     */ 
/* 202 */     RequestContext.getCurrentInstance().execute("openWindow('" + createRequestURI(nextScreen) + "?cfw_windowkey=" + xhtml + "', '" + xhtml + "', '" + params + "');");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void openWindow(String url, String name, String features)
/*     */   {
/* 217 */     String script = String.format("openWindowAndFocus('%s', '%s', '%s');", new Object[] { FwStringConverter.nullToBlank(url), FwStringConverter.nullToBlank(name), FwStringConverter.nullToBlank(features) });
/*     */     
/*     */ 
/* 220 */     RequestContext.getCurrentInstance().execute(script);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void openDialog(String xhtml, int width, int height)
/*     */   {
/* 233 */     String nextScreen = getScreenPath(xhtml);
/*     */     
/*     */ 
/* 236 */     Map<String, Object> dialogOptions = new HashMap();
/* 237 */     dialogOptions.put("modal", Boolean.valueOf(true));
/* 238 */     dialogOptions.put("resizable", Boolean.valueOf(false));
/* 239 */     dialogOptions.put("draggable", Boolean.valueOf(true));
/* 240 */     dialogOptions.put("closable", Boolean.valueOf(true));
/* 241 */     dialogOptions.put("contentWidth", Integer.valueOf(width));
/* 242 */     dialogOptions.put("contentHeight", Integer.valueOf(height));
/*     */     
/*     */ 
/* 245 */     Map<String, List<String>> params = new HashMap();
/* 246 */     this.utils.addParamsForDialog(params);
/*     */     
/*     */ 
/* 249 */     List<String> array = new ArrayList();
/* 250 */     array.add(this.session.getWindowKey());
/* 251 */     params.put("cfw_windowkey", array);
/*     */     
/*     */ 
/* 254 */     String pathInfo = removeContextPathServletPath(nextScreen);
/*     */     
/*     */ 
/* 257 */     pathInfo = pathInfo.replace(".xhtml", "");
/*     */     
/*     */ 
/* 260 */     RequestContext.getCurrentInstance().openDialog(pathInfo, dialogOptions, params);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void closeDialog(Object params)
/*     */   {
/* 271 */     this.session.removeWindowKeyMap(this.session.getClientWindowId());
/*     */     
/* 273 */     RequestContext.getCurrentInstance().closeDialog(params);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void closeSubWindow()
/*     */   {
/* 280 */     RequestContext.getCurrentInstance().execute("window.close();");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addMessage(CfwMessage message)
/*     */   {
/* 290 */     FacesMessage.Severity severity = null;
/*     */     
/* 292 */     switch (message.getSeverity()) {
/*     */     case 1: 
/* 294 */       severity = FacesMessage.SEVERITY_ERROR;
/* 295 */       break;
/*     */     case 2: 
/* 297 */       severity = FacesMessage.SEVERITY_INFO;
/* 298 */       break;
/*     */     case 3: 
/* 300 */       severity = FacesMessage.SEVERITY_WARN;
/* 301 */       break;
/*     */     default: 
/* 303 */       severity = FacesMessage.SEVERITY_ERROR;
/*     */     }
/*     */     
/*     */     
/*     */ 
/* 308 */     FacesContext facesContext = FwFacesContext.getFacesContext();
/* 309 */     String msg = "";
/* 310 */     if ((message.getParams() != null) && (message.getParams().length > 0)) {
/* 311 */       msg = this.messageManager.getMessage(message.getMessageId(), (Object[])message.getParams());
/*     */     } else {
/* 313 */       msg = this.messageManager.getMessage(message.getMessageId(), new Object[0]);
/*     */     }
/*     */     
/* 316 */     facesContext.addMessage(UIComponent.getCurrentComponent(
/* 317 */       FacesContext.getCurrentInstance()).getClientId(), new FacesMessage(severity, msg, null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addMessage(List<CfwMessage> messages)
/*     */   {
/* 327 */     for (CfwMessage message : messages) {
/* 328 */       addMessage(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String back()
/*     */   {
/* 337 */     FwFacesContext.setKeepMessage(true);
/* 338 */     return this.session.popScreen() + "?faces-redirect=true";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getBackingBean(String name)
/*     */   {
/* 348 */     ELContext elContext = FacesContext.getCurrentInstance().getELContext();
/* 349 */     return FacesContext.getCurrentInstance().getApplication().getELResolver().getValue(elContext, null, name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwAppDialog getAppDialog()
/*     */   {
/* 357 */     CfwAppDialog dialog = (CfwAppDialog)getBackingBean("cfwAppDialog");
/* 358 */     dialog.setUp();
/* 359 */     return dialog;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CfwUploadDialog getUploadDialog()
/*     */   {
/* 367 */     CfwUploadDialog dialog = (CfwUploadDialog)getBackingBean("cfwUploadDialog");
/* 368 */     dialog.setUp();
/* 369 */     return dialog;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void openDirectPrintWindow(String fileId, String sheetId)
/*     */   {
/* 385 */     this.cfwPrintSession.addMainToSub(new CfwPrintDto(fileId, sheetId));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 390 */     StringBuilder params = new StringBuilder();
/* 391 */     int width = 470;
/* 392 */     int height = 100;
/* 393 */     params.append("width=").append(width);
/* 394 */     params.append(",height=").append(height);
/* 395 */     params.append(",menubar=no,toolbar=no,location=no,status=no,resizable=no,scrollbars=no");
/*     */     
/*     */ 
/*     */ 
/* 399 */     String contextPath = this.request.getContextPath();
/*     */     
/* 401 */     String url = contextPath + "/faces/jsf/print/cfwPrinterList.xhtml";
/* 402 */     this.log.debug("fileId:{}, sheetId:{}で直接印刷呼び出し,URL:{}", new Object[] { fileId, sheetId, url });
/*     */     
/*     */ 
/* 405 */     RequestContext.getCurrentInstance().execute("openWindow('" + url + "', '帳票印刷中', '" + params + "');");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getScreenPath(String xhtml)
/*     */   {
/* 417 */     CfwScreenIdDecision screenDecisionClass = null;
/* 418 */     String nextScreen = null;
/*     */     
/*     */ 
/* 421 */     if (this.cfwScreenIdDecisionInstance.isAmbiguous()) {
/* 422 */       throw new CfwRuntimeException("画面遷移共通関数の呼び出しに失敗しました。", new Object[0]);
/*     */     }
/*     */     
/*     */ 
/* 426 */     if (!this.cfwScreenIdDecisionInstance.isUnsatisfied()) {
/* 427 */       screenDecisionClass = (CfwScreenIdDecision)this.cfwScreenIdDecisionInstance.get();
/*     */     }
/*     */     
/* 430 */     if (screenDecisionClass == null)
/*     */     {
/* 432 */       nextScreen = xhtml;
/*     */     }
/*     */     else
/*     */     {
/* 436 */       nextScreen = screenDecisionClass.getScreenPath(xhtml, getCurrentScreenId());
/*     */     }
/*     */     
/* 439 */     return nextScreen;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCurrentScreenId()
/*     */   {
/* 449 */     FacesContext context = FacesContext.getCurrentInstance();
/* 450 */     String screenPath = context.getViewRoot().getViewId();
/* 451 */     return getScreenId(screenPath);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPreviousScreenId()
/*     */   {
/* 461 */     String previousId = this.session.peekScreen();
/* 462 */     if (previousId == null) {
/* 463 */       return null;
/*     */     }
/* 465 */     return getScreenId(previousId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getScreenId(String screenPath)
/*     */   {
/* 477 */     String xhtmlName = screenPath.substring(screenPath.lastIndexOf("/") + 1);
/* 478 */     xhtmlName = xhtmlName.substring(0, xhtmlName.lastIndexOf(".xhtml"));
/*     */     
/* 480 */     return xhtmlName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String removeContextPathServletPath(String uri)
/*     */   {
/* 491 */     FacesContext context = FacesContext.getCurrentInstance();
/* 492 */     ExternalContext extContext = context.getExternalContext();
/*     */     
/* 494 */     String path = extContext.getRequestContextPath() + extContext.getRequestServletPath();
/* 495 */     String pathInfo = uri.replace(path, "");
/*     */     
/* 497 */     return pathInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String createRequestURI(String xhtml)
/*     */   {
/* 507 */     FacesContext context = FacesContext.getCurrentInstance();
/* 508 */     ExternalContext extContext = context.getExternalContext();
/*     */     
/* 510 */     String pathInfo = null;
/*     */     
/*     */ 
/* 513 */     if (!xhtml.substring(0, 1).equals("/")) {
/* 514 */       pathInfo = extContext.getRequestPathInfo();
/*     */       
/* 516 */       int index = pathInfo.lastIndexOf("/");
/* 517 */       if (index != -1) {
/* 518 */         pathInfo = pathInfo.substring(0, index);
/*     */       }
/*     */       
/* 521 */       pathInfo = pathInfo + "/" + xhtml;
/*     */     }
/*     */     else
/*     */     {
/* 525 */       pathInfo = removeContextPathServletPath(xhtml);
/*     */     }
/*     */     
/*     */ 
/* 529 */     pathInfo = pathInfo.replace(".xhtml", "");
/*     */     
/* 531 */     return extContext.getRequestContextPath() + extContext.getRequestServletPath() + pathInfo + ".xhtml";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void updateWindow(String... clientIds)
/*     */   {
/* 539 */     List<String> list = new ArrayList();
/* 540 */     for (String clientId : clientIds) {
/* 541 */       list.add(clientId);
/*     */     }
/* 543 */     RequestContext.getCurrentInstance().update(list);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void reset(String... clientIds)
/*     */   {
/* 552 */     List<String> list = new ArrayList();
/* 553 */     for (String clientId : clientIds) {
/* 554 */       list.add(clientId);
/*     */     }
/* 556 */     RequestContext.getCurrentInstance().reset(list);
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\CfwBaseBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */