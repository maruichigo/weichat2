/*    */ package jp.co.tokyo_gas.cisfw.web;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Stack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CfwAppData
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private CfwSessionData sessionData;
/*    */   private CfwSpecificCustomerInfo specificCustomerInfo;
/*    */   private CfwSearchConditionInfo searchConditionInfo;
/*    */   private Stack<String> screenStack;
/*    */   
/*    */   public CfwAppData()
/*    */   {
/* 37 */     this.sessionData = new CfwSessionData();
/* 38 */     this.specificCustomerInfo = new CfwSpecificCustomerInfo();
/* 39 */     this.searchConditionInfo = new CfwSearchConditionInfo();
/*    */     
/* 41 */     this.screenStack = new Stack();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public CfwSessionData getCfwSessionData()
/*    */   {
/* 49 */     return this.sessionData;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public CfwSpecificCustomerInfo getCfwSpecificCustomerInfo()
/*    */   {
/* 57 */     return this.specificCustomerInfo;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public CfwSearchConditionInfo getCfwSearchConditionInfo()
/*    */   {
/* 65 */     return this.searchConditionInfo;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Stack<String> getScreenStack()
/*    */   {
/* 73 */     return this.screenStack;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void clear()
/*    */   {
/* 80 */     this.sessionData.clear();
/* 81 */     this.specificCustomerInfo.clear();
/* 82 */     this.searchConditionInfo.clear();
/* 83 */     this.screenStack.clear();
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\CfwAppData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */