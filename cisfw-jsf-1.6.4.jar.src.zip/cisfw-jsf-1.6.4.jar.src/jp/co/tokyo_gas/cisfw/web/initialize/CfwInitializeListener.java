/*    */ package jp.co.tokyo_gas.cisfw.web.initialize;
/*    */ 
/*    */ import javax.inject.Inject;
/*    */ import javax.servlet.ServletContextEvent;
/*    */ import javax.servlet.ServletContextListener;
/*    */ import jp.co.tokyo_gas.aion.tgfw.parts.init.FwInitializer;
/*    */ import jp.co.tokyo_gas.cisfw.logger.CfwLogger;
/*    */ import jp.co.tokyo_gas.cisfw.web.authcheck.CfwComponentAuthorityMasterCache;
/*    */ import jp.co.tokyo_gas.cisfw.web.cache.CfwCache;
/*    */ import jp.co.tokyo_gas.cisfw.web.menu.CfwMenuBarCacheInitializer;
/*    */ import jp.co.tokyo_gas.cisfw.web.print.CfwPrintSheetManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CfwInitializeListener
/*    */   implements ServletContextListener
/*    */ {
/*    */   @Inject
/*    */   private CfwMenuBarCacheInitializer menuInitializer;
/*    */   @Inject
/*    */   private CfwPrintSheetManager printSheetManager;
/*    */   @Inject
/*    */   private CfwComponentAuthorityMasterCache componentAuthorityMasterCache;
/*    */   @Inject
/*    */   private CfwCache cache;
/*    */   @Inject
/*    */   private CfwLogger log;
/*    */   
/*    */   public void contextInitialized(ServletContextEvent sce)
/*    */   {
/* 54 */     this.log.info("初期化処理開始");
/*    */     
/* 56 */     initialize(this.menuInitializer);
/* 57 */     initialize(this.printSheetManager);
/* 58 */     initialize(this.componentAuthorityMasterCache);
/* 59 */     initialize(this.cache);
/*    */     
/* 61 */     this.log.info("初期化処理終了");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void contextDestroyed(ServletContextEvent sce) {}
/*    */   
/*    */ 
/*    */ 
/*    */   protected void initialize(FwInitializer target)
/*    */   {
/* 72 */     this.log.info("初期化実行：{}", target.getClass().getName());
/* 73 */     target.isReInitialize();
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\web\initialize\CfwInitializeListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */