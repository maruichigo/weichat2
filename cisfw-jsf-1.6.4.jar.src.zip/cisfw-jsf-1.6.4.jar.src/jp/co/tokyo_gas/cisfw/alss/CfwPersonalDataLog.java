/*     */ package jp.co.tokyo_gas.cisfw.alss;
/*     */ 
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.converter.delimiter.FwDelimiterAttrs;
/*     */ import jp.co.tokyo_gas.aion.tgfw.parts.converter.delimiter.FwDelimiterConvert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FwDelimiterConvert
/*     */ @FwDelimiterAttrs({@jp.co.tokyo_gas.aion.tgfw.parts.converter.delimiter.FwDelimiterAttr(name="lineNumber"), @jp.co.tokyo_gas.aion.tgfw.parts.converter.delimiter.FwDelimiterAttr(name="branchNumber"), @jp.co.tokyo_gas.aion.tgfw.parts.converter.delimiter.FwDelimiterAttr(name="name"), @jp.co.tokyo_gas.aion.tgfw.parts.converter.delimiter.FwDelimiterAttr(name="nameKana"), @jp.co.tokyo_gas.aion.tgfw.parts.converter.delimiter.FwDelimiterAttr(name="address"), @jp.co.tokyo_gas.aion.tgfw.parts.converter.delimiter.FwDelimiterAttr(name="phoneNumber"), @jp.co.tokyo_gas.aion.tgfw.parts.converter.delimiter.FwDelimiterAttr(name="birthDay"), @jp.co.tokyo_gas.aion.tgfw.parts.converter.delimiter.FwDelimiterAttr(name="mailAddress"), @jp.co.tokyo_gas.aion.tgfw.parts.converter.delimiter.FwDelimiterAttr(name="accountNumber"), @jp.co.tokyo_gas.aion.tgfw.parts.converter.delimiter.FwDelimiterAttr(name="creditNumber"), @jp.co.tokyo_gas.aion.tgfw.parts.converter.delimiter.FwDelimiterAttr(name="note")})
/*     */ public class CfwPersonalDataLog
/*     */ {
/*     */   private String lineNumber;
/*     */   private String branchNumber;
/*     */   private String name;
/*     */   private String nameKana;
/*     */   private String address;
/*     */   private String phoneNumber;
/*     */   private String birthDay;
/*     */   private String mailAddress;
/*     */   private String accountNumber;
/*     */   private String creditNumber;
/*     */   private String note;
/*     */   
/*     */   public String getLineNumber()
/*     */   {
/*  74 */     return this.lineNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLineNumber(String lineNumber)
/*     */   {
/*  82 */     this.lineNumber = lineNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBranchNumber()
/*     */   {
/*  90 */     return this.branchNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBranchNumber(String branchNumber)
/*     */   {
/*  98 */     this.branchNumber = branchNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 106 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 114 */     this.name = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getNameKana()
/*     */   {
/* 122 */     return this.nameKana;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNameKana(String nameKana)
/*     */   {
/* 130 */     this.nameKana = nameKana;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAddress()
/*     */   {
/* 138 */     return this.address;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAddress(String address)
/*     */   {
/* 146 */     this.address = address;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPhoneNumber()
/*     */   {
/* 154 */     return this.phoneNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPhoneNumber(String phoneNumber)
/*     */   {
/* 162 */     this.phoneNumber = phoneNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBirthDay()
/*     */   {
/* 170 */     return this.birthDay;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBirthDay(String birthDay)
/*     */   {
/* 178 */     this.birthDay = birthDay;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMailAddress()
/*     */   {
/* 186 */     return this.mailAddress;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMailAddress(String mailAddress)
/*     */   {
/* 194 */     this.mailAddress = mailAddress;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAccountNumber()
/*     */   {
/* 202 */     return this.accountNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAccountNumber(String accountNumber)
/*     */   {
/* 210 */     this.accountNumber = accountNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCreditNumber()
/*     */   {
/* 218 */     return this.creditNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCreditNumber(String creditNumber)
/*     */   {
/* 226 */     this.creditNumber = creditNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getNote()
/*     */   {
/* 234 */     return this.note;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNote(String note)
/*     */   {
/* 242 */     this.note = note;
/*     */   }
/*     */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\alss\CfwPersonalDataLog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */