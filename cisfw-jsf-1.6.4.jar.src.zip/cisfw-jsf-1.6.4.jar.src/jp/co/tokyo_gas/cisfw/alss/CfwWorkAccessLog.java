/*    */ package jp.co.tokyo_gas.cisfw.alss;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CfwWorkAccessLog
/*    */ {
/*    */   private String functionCode;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private String downloadCount;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private String note;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getFunctionCode()
/*    */   {
/* 35 */     return this.functionCode;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setFunctionCode(String functionCode)
/*    */   {
/* 43 */     this.functionCode = functionCode;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getDownloadCount()
/*    */   {
/* 51 */     return this.downloadCount;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setDownloadCount(String downloadCount)
/*    */   {
/* 59 */     this.downloadCount = downloadCount;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getNote()
/*    */   {
/* 67 */     return this.note;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setNote(String note)
/*    */   {
/* 75 */     this.note = note;
/*    */   }
/*    */ }


/* Location:              C:\eclipse\workspace\FrontEndWeb2\webapp\WEB-INF\lib\cisfw-jsf-1.6.4.jar!\jp\co\tokyo_gas\cisfw\alss\CfwWorkAccessLog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */