/**
 * ファイルアップロード部品のボタン制御をする部品です。
 * 
 * @author Koichi Sasaki (TDC)
 */
PrimeFaces.widget.FileUpload = PrimeFaces.widget.FileUpload.extend({
	init: function(a) {
		this._super(a);
		if (this.cfg.disabled) {
			return
		}
		this.ucfg = {};
		this.form = this.jq.closest("form");
		this.buttonBar = this.jq.children(".ui-fileupload-buttonbar");
		this.chooseButton = this.buttonBar.children(".ui-fileupload-choose");
		this.uploadButton = this.buttonBar.children(".ui-fileupload-upload");
		this.cancelButton = this.buttonBar.children(".ui-fileupload-cancel");
		this.content = this.jq.children(".ui-fileupload-content");
		this.filesTbody = this.content.find("> table.ui-fileupload-files > tbody");
		this.sizes = ["Bytes", "KB", "MB", "GB", "TB"];
		this.files = [];
		this.fileAddIndex = 0;
		this.cfg.invalidFileMessage = this.cfg.invalidFileMessage || "Invalid file type";
		this.cfg.invalidSizeMessage = this.cfg.invalidSizeMessage || "Invalid file size";
		this.cfg.fileLimitMessage = this.cfg.fileLimitMessage || "Maximum number of files exceeded";
		this.cfg.messageTemplate = this.cfg.messageTemplate || "{name} {size}";
		this.cfg.previewWidth = this.cfg.previewWidth || 80;
		this.uploadedFileCount = 0;
		this.renderMessages();
		this.bindEvents();
		var c = this,
			e = this.form.attr("action"),
			d = this.form.children("input[name*='javax.faces.encodedURL']");
		var b = null;
		if (d.length > 0) {
			b = 'form[action="' + e + '"]';
			e = d.val()
		}
		this.ucfg = {
			url: e,
			portletForms: b,
			paramName: this.id,
			dataType: "xml",
			dropZone: (this.cfg.dnd === false) ? null : this.jq,
			forceIframeTransport: PrimeFaces.isIE(10),
			formData: function() {
				return c.createPostData()
			},
			beforeSend: function(g, f) {
				g.setRequestHeader("Faces-Request", "partial/ajax");
				g.pfSettings = f;
				g.pfArgs = {}
			},
			start: function(f) {
				if (c.cfg.onstart) {
					c.cfg.onstart.call(c)
				}
			},
			add: function(l, k) {
				c.chooseButton.removeClass("ui-state-hover ui-state-focus");
				if (c.fileAddIndex === 0) {
					c.clearMessages()
				}
				if (c.cfg.fileLimit && (c.uploadedFileCount + c.files.length + 1) > c.cfg.fileLimit) {
					c.clearMessages();
					c.showMessage({
						summary: c.cfg.fileLimitMessage
					});
					return
				}
				var h = k.files ? k.files[0] : null;
				if (h) {
					var m = c.validate(h);
					if (m) {
						c.showMessage({
							summary: m,
							filename: h.name,
							filesize: h.size
						})
					} else {
						var o = $("<tr></tr>").append('<td class="ui-fileupload-preview"></td>').append("<td>" + h.name + "</td>").append("<td>" + c.formatSize(h.size) + "</td>").append('<td class="ui-fileupload-progress"></td>').append('<td><button class="ui-fileupload-cancel ui-button ui-widget ui-state-default ui-corner-all ui-button-icon-only"><span class="ui-button-icon-left ui-icon ui-icon ui-icon-close"></span><span class="ui-button-text">ui-button</span></button></td>').appendTo(c.filesTbody);
						if (c.isCanvasSupported() && window.File && window.FileReader && c.IMAGE_TYPES.test(h.name)) {
							var n = $("<canvas></canvas>").appendTo(o.children("td.ui-fileupload-preview")),
								g = n.get(0).getContext("2d"),
								i = window.URL || window.webkitURL,
								f = i.createObjectURL(h),
								j = new Image();
							j.onload = function() {
								var q = null,
									p = null,
									r = 1;
								if (c.cfg.previewWidth > this.width) {
									q = this.width
								} else {
									q = c.cfg.previewWidth;
									r = c.cfg.previewWidth / this.width
								}
								var p = parseInt(this.height * r);
								n.attr({
									width: q,
									height: p
								});
								g.drawImage(j, 0, 0, q, p)
							};
							j.src = f
						}
						o.children("td.ui-fileupload-progress").append('<div class="ui-progressbar ui-widget ui-widget-content ui-corner-all" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="ui-progressbar-value ui-widget-header ui-corner-left" style="display: none; width: 0%;"></div></div>');
						h.row = o;
						h.row.data("filedata", k);
						c.files.push(h);
						if (c.cfg.auto) {
							c.upload()
						}
					}
					if (c.files.length > 0) {
						c.enableButton(c.uploadButton);
						c.enableButton(c.cancelButton)
						c.disableButton(c.chooseButton)
						c.chooseButton.find('input[type="file"]').attr('disabled', 'disabled');
					}
					c.fileAddIndex++;
					if (c.fileAddIndex === (k.originalFiles.length)) {
						c.fileAddIndex = 0
					}
				}
			},
			send: function(j, h) {
				if (!window.FormData) {
					for (var g = 0; g < h.files.length; g++) {
						var f = h.files[g];
						f.row.children(".ui-fileupload-progress").find("> .ui-progressbar > .ui-progressbar-value").addClass("ui-progressbar-value-legacy").css({
							width: "100%",
							display: "block"
						})
					}
				}
			},
			fail: function(g, f) {
				if (c.cfg.onerror) {
					c.cfg.onerror.call(c)
				}
			},
			progress: function(k, j) {
				if (window.FormData) {
					var f = parseInt(j.loaded / j.total * 100, 10);
					for (var h = 0; h < j.files.length; h++) {
						var g = j.files[h];
						g.row.children(".ui-fileupload-progress").find("> .ui-progressbar > .ui-progressbar-value").css({
							width: f + "%",
							display: "block"
						})
					}
				}
			},
			done: function(g, f) {
				c.uploadedFileCount += f.files.length;
				c.removeFiles(f.files);
				PrimeFaces.ajax.Response.handle(f.result, f.textStatus, f.jqXHR, null)
			},
			always: function(g, f) {
				if (c.cfg.oncomplete) {
					c.cfg.oncomplete.call(c, f.jqXHR.pfArgs)
				}
			}
		};
		this.jq.fileupload(this.ucfg)
	},
	bindEvents: function() {
		var a = this;
		PrimeFaces.skinButton(this.buttonBar.children("button"));
		this.chooseButton.on("mouseover.fileupload", function() {
			var b = $(this);
			if (!b.prop("disabled")) {
				b.addClass("ui-state-hover")
			}
		}).on("mouseout.fileupload", function() {
			$(this).removeClass("ui-state-active ui-state-hover")
		}).on("mousedown.fileupload", function() {
			var b = $(this);
			if (!b.prop("disabled")) {
				b.addClass("ui-state-active").removeClass("ui-state-hover")
			}
		}).on("mouseup.fileupload", function() {
			$(this).removeClass("ui-state-active").addClass("ui-state-hover")
		});
		this.chooseButton.children("input").on("focus.fileupload", function() {
			a.chooseButton.addClass("ui-state-focus")
		}).on("blur.fileupload", function() {
			a.chooseButton.removeClass("ui-state-focus")
		});
		this.uploadButton.on("click.fileupload", function(b) {
			a.disableButton(a.uploadButton);
			a.disableButton(a.cancelButton);
			a.disableButton(a.filesTbody.find("> tr > td:last-child").children(".ui-fileupload-cancel"));
			a.upload();
			b.preventDefault()
		});
		this.cancelButton.on("click.fileupload", function(b) {
			a.clear();
			a.disableButton(a.uploadButton);
			a.disableButton(a.cancelButton);
			a.enableButton(a.chooseButton);
			a.chooseButton.find('input[type="file"]').removeAttr('disabled');
			b.preventDefault()
		});
		this.clearMessageLink.on("click.fileupload", function(b) {
			a.messageContainer.fadeOut(function() {
				a.messageList.children().remove()
			});
			b.preventDefault()
		});
		this.rowActionSelector = this.jqId + " .ui-fileupload-files button";
		this.rowCancelActionSelector = this.jqId + " .ui-fileupload-files .ui-fileupload-cancel";
		this.clearMessagesSelector = this.jqId + " .ui-messages .ui-messages-close";
		$(document).off("mouseover.fileupload mouseout.fileupload mousedown.fileupload mouseup.fileupload focus.fileupload blur.fileupload click.fileupload ", this.rowCancelActionSelector).on("mouseover.fileupload", this.rowCancelActionSelector, null, function(b) {
			$(this).addClass("ui-state-hover")
		}).on("mouseout.fileupload", this.rowCancelActionSelector, null, function(b) {
			$(this).removeClass("ui-state-hover ui-state-active")
		}).on("mousedown.fileupload", this.rowCancelActionSelector, null, function(b) {
			$(this).addClass("ui-state-active").removeClass("ui-state-hover")
		}).on("mouseup.fileupload", this.rowCancelActionSelector, null, function(b) {
			$(this).addClass("ui-state-hover").removeClass("ui-state-active")
		}).on("focus.fileupload", this.rowCancelActionSelector, null, function(b) {
			$(this).addClass("ui-state-focus")
		}).on("blur.fileupload", this.rowCancelActionSelector, null, function(b) {
			$(this).removeClass("ui-state-focus")
		}).on("click.fileupload", this.rowCancelActionSelector, null, function(c) {
			var d = $(this).closest("tr"),
				b = a.files.splice(d.index(), 1);
			b[0].row = null;
			a.removeFileRow(d);
			if (a.files.length === 0) {
				a.disableButton(a.uploadButton);
				a.disableButton(a.cancelButton)
				a.enableButton(a.chooseButton)
				a.chooseButton.find('input[type="file"]').removeAttr('disabled');
			}
			c.preventDefault()
		})
	}
})