/**
 * 複数項目から1項目選択する部品です。
 * 
 * @author Yuuki Matsushima (TDC)
 */
PrimeFaces.widget.SelectOneMenu = PrimeFaces.widget.SelectOneMenu.extend({
	
	filter: function(e) {
		
		var caseSensitive = this.cfg.caseSensitive;
        this.cfg.initialHeight = this.cfg.initialHeight || this.itemsWrapper.height();
        var g = caseSensitive ? $.trim(e) : $.trim(e).toLowerCase();
        
        // filterBy属性(絞り込み条件)
        var filterBy = this.jq.attr("data-fw-filterBy");
        
        if (g === "") {
            this.items.filter(":hidden").show()
        
        } else {
        	var length = this.options.length;
        	
        	if (filterBy == "label") {
        		for (var a = 0; a < length; a++) {
        			var option = this.options.eq(a),
                    	label = caseSensitive ? option.text() : option.text().toLowerCase(),
                    	item = this.items.eq(a);
                    	     
                    if (this.filterMatcher(label, g)) {
                    	item.show()
                    
        		     } else {
    				     item.hide()
        		    }
    			}
        	
        	} else if (filterBy == "condition") {
        		for (var a = 0; a < length; a++) {
        			var option = this.options.eq(a),
        				conditionValue = option.attr("condition"),
        				item = this.items.eq(a);
        			
        			if (conditionValue) {
        				var condition = caseSensitive ? conditionValue : conditionValue.toLowerCase();
        				
        				if (this.filterMatcher(condition, g)) {
        					item.show()
        				
        				} else {
        					item.hide()
        				}
        				
        			} else { 
        				item.hide()
        			}
        		}
        	
        	} else if (filterBy == "both") {
        		for (var a = 0; a < length; a++) {
        			var option = this.options.eq(a),
        				conditionValue = option.attr("condition"),
        				label = caseSensitive ? option.text() : option.text().toLowerCase(),
        				item = this.items.eq(a);
        			
        			if (conditionValue) { 
        				condition = caseSensitive ? conditionValue : conditionValue.toLowerCase();
        			
        				if (this.filterMatcher(label, g) || this.filterMatcher(condition, g)) {
        					item.show()
        			
        				} else {
        					item.hide()
        				}
        			
        			} else {
        				if (this.filterMatcher(label, g)) {
        					item.show()
        				
        				} else {
        					item.hide()
        				}
        			}
        		}
        	}
        }
        var f = this.items.filter(":visible:first");
        if (f.length) {
            this.highlightItem(f)
        }
        if (this.itemsContainer.height() < this.cfg.initialHeight) {
            this.itemsWrapper.css("height", "auto")
        } else {
            this.itemsWrapper.height(this.cfg.initialHeight)
        }
        this.alignPanel()
    },bindFilterEvents: function () {
        var a = this;
        this.filterInput.on("keyup.ui-selectonemenu", function (d) {
            var c = $.ui.keyCode, b = d.which;
            switch (b) {
                case c.UP:
                case c.DOWN:
                case c.LEFT:
                case c.RIGHT:
//                case c.ENTER:
                case c.NUMPAD_ENTER:
                case c.TAB:
                case c.ESCAPE:
//                case c.SPACE:
                case c.HOME:
                case c.PAGE_DOWN:
                case c.PAGE_UP:
                case c.END:
                case c.DELETE:
                case 16:
                case 17:
                case 18:
                case 224:
                    break;
                default:
                    var f = d.metaKey || d.ctrlKey || d.shiftKey;
                    if (!f) {
                        a.filter($(this).val());
                    }
                    break;
            }
        }).on("keydown.ui-selectonemenu", function (d) {
            var c = $.ui.keyCode, b = d.which;
            switch (b) {
                case c.UP:
                    a.highlightPrev(d);
                    break;
                case c.DOWN:
                    a.highlightNext(d);
                    break;
                case c.ENTER:
                case c.NUMPAD_ENTER:
                    a.handleEnterKey(d);
                    break;
                case c.TAB:
                    a.handleTabKey();
                    break;
                case c.ESCAPE:
                    a.handleEscapeKey(d);
                    break;
                default:
                    break;
            }
        });
    }
})
PrimeFaces.widget.SelectManyCheckbox = PrimeFaces.widget.SelectManyCheckbox.extend({
	bindEvents: function() {
		this.outputs.mouseover(function() {
			$(this).addClass("ui-state-hover")
		}).mouseout(function() {
			$(this).removeClass("ui-state-hover")
		}).click(function() {
			var b = $(this),
				a = b.prev().children(":checkbox");
				a.trigger("click");
				if ($.browser.msie && parseInt($.browser.version) < 9) {
					a.trigger("change")
				}
		});
		this.inputs.focus(function() {
			var a = $(this),
			b = a.parent().next();
			if($.browser.webkit) {
				if (a.prop("checked")) {
					b.removeClass("ui-state-active")
				} else {
					b.addClass("ui-state-active")
				}
				
			} else {
				if (a.prop("checked")) {
					b.addClass("ui-state-active")
				} else {
					b.removeClass("ui-state-active")
				}
			}
		}).blur(function() {
			var a = $(this),
				b = a.parent().next();
			if (a.prop("checked")) {
				b.addClass("ui-state-active")
			}
			b.removeClass("ui-state-focus")
		}).change(function(d) {
			var a = $(this),
				c = a.parent().next(),
				f = a.is(":focus"),
				b = a.is(":disabled");
			if (b) {
				return
			}
			if (a.is(":checked")) {
				c.children(".ui-chkbox-icon").removeClass("ui-icon-blank").addClass("ui-icon-check");
					c.addClass("ui-state-active")
			} else {
				c.removeClass("ui-state-active").children(".ui-chkbox-icon").addClass("ui-icon-blank").removeClass("ui-icon-check")
			}
		})
	}
})
PrimeFaces.widget.SelectManyMenu = PrimeFaces.widget.SelectManyMenu.extend({
	
	filter : function(e) {
		var caseSensitive = this.cfg.caseSensitive;
		var g = caseSensitive ? $.trim(e) : $.trim(e).toLowerCase();
		
        // filterBy属性(絞り込み条件)
        var filterBy = this.jq.attr("data-fw-filterBy");

		if (g === "") {
			this.items.filter(":hidden").show()
		
		} else {
			var length = this.options.length;
			if (filterBy == "label") {
				for (var a = 0; a < length; a++) {
					var option = this.options.eq(a),
						label = caseSensitive ? option.text() : option.text().toLowerCase(),
						item = this.items.eq(a);
					
					if (this.filterMatcher(label, g)) {
						item.show()
					
					} else {
						item.hide()
					}
				}
				
			} else if (filterBy == "condition") {
				for (var a = 0; a < length; a++) {
					var option = this.options.eq(a),
						conditionValue = option.attr("condition"),
						item = this.items.eq(a);
				
					if (conditionValue) {
						var condition = caseSensitive ? conditionValue : conditionValue.toLowerCase();
					
						if (this.filterMatcher(condition, g)) {
							item.show()
						
						} else {
							item.hide()
						}
				
					} else {
						item.hide()
					}
				}
		
			} else if (filterBy == "both") {
				for (var a = 0; a < length; a++) {
					var option =this.options.eq(a),
						conditionValue = option.attr("condition"),
						label = caseSensitive ? option.text() : option.text().toLowerCase(),
						item = this.items.eq(a);
					
					if (conditionValue) {
						condition = caseSensitive ? conditionValue : conditionValue.toLowerCase();
					
						if (this.filterMatcher(label, g) || this.filterMatcher(condition, g)) {
							item.show()
						
						} else {
							item.hide()
						}
				
					} else {
						if (this.filterMatcher(label, g)) {
							item.show()
					
						} else {
							item.hide()
						}
					}
				}
			}
		}
	}
})
/**
 * 1レコード複数行のデータ選択時に、複数行のデータが選択できるようにします。
 * 
 * @author Masumi Inada (TDC)
 */
PrimeFaces.widget.DataTable = PrimeFaces.widget.DataTable.extend({
	highlightRow: function(a) {
		var targetId = '#' +a.parent().get(0).parentElement.parentElement.parentElement.id
		targetId = targetId.replace(/:/g,"\\:")
		var ri = a.data("ri");
		ri = ".cfwDataTable"+ri;
		$(targetId).find(ri).removeClass("ui-state-hover").addClass("ui-state-highlight").attr("aria-selected", true)
		a.removeClass("ui-state-hover").addClass("ui-state-highlight").attr("aria-selected", true)
	},
	unhighlightRow: function(a) {
		var targetId = '#' +a.parent().get(0).parentElement.parentElement.parentElement.id
		targetId = targetId.replace(/:/g,"\\:")
		var ri = a.data("ri");
		ri = ".cfwDataTable"+ri;
		$(targetId).find(ri).removeClass("ui-state-highlight").attr("aria-selected", false)
		a.removeClass("ui-state-highlight").attr("aria-selected", false)
	},
	bindRowHover: function(a) {
	},
	selectRowTwo: function(b, a) {
		var d = this.findRow(b),
			c = this.getRowMeta(d);
		this.highlightRow(d);
		if (this.isCheckboxSelectionEnabled()) {
			if (this.cfg.nativeElements) {
				d.children("td.ui-selection-column").find(":checkbox").prop("checked", true)
			} else {
				this.selectCheckbox(d.children("td.ui-selection-column").find("> div.ui-chkbox > div.ui-chkbox-box"))
			}
			this.updateHeaderCheckbox()
		}
		this.addSelection(c.key);
		this.writeSelections();
		if (!a) {
			this.fireRowSelectEvent(c.key, "rowSelect")
		}
	},
	toggleCheckAll: function() {
		/** チェックボックスでグリッドヘッダのチェックボックスを選択した際に、非表示ページのデータもチェックするように変更。 */
		if (this.cfg.nativeElements) {
			var d = this.tbody.find("> tr.ui-datatable-selectable > td.ui-selection-column > :checkbox"), c = this.checkAllToggler.prop("checked"), e = this;
			d.each(function() {
				if (c) {
					var f = $(this);
					f.prop("checked", true);
					e.selectAllRows()
				} else {
					var f = $(this);
					f.prop("checked", false);
					e.unselectAllRows()
				}
			})
		} else {
			var d = this.tbody.find("> tr.ui-datatable-selectable > td.ui-selection-column .ui-chkbox-box"), c = this.checkAllToggler.hasClass("ui-state-active"), e = this;
			if (c) {
				e.unselectAllRows();
				this.checkAllToggler.removeClass("ui-state-active").children("span.ui-chkbox-icon").addClass("ui-icon-blank").removeClass("ui-icon-check");
			} else {
				e.selectAllRows();
				this.checkAllToggler.addClass("ui-state-active").children("span.ui-chkbox-icon").removeClass("ui-icon-blank").addClass("ui-icon-check");
			}
		}
		this.writeSelections();
		if (this.cfg.behaviors) {
			var a = this.cfg.behaviors.toggleSelect;
			if (a) {
				var b = {params: [{name: this.id + "_checked",value: !c}]};
				a.call(this, b)
			}
		}
	},
	selectAllRows: function() {
		this.selectAllRowsOnPageTwo();
		
		var allName = this.jqId + '_selection_cfw';
		var allValue = $(allName).val();

		var allArray = allValue.split(",");

		this.selection = [];
		for (var i = 0; i < allArray.length; i++) {
			this.addSelection(allArray[i]);
		}

        this.writeSelections();
	},
	updateHeaderCheckbox: function() {
		if(this.isEmpty()) {
			this.uncheckHeaderCheckbox();
			this.disableHeaderCheckbox();

		} else {
			var allName = this.jqId + '_selection_cfw';
			var allValue = $(allName).val();
			var allArray = allValue.split(",");

			if (this.selection.length == allArray.length) {
			   this.checkHeaderCheckbox();
			} else {
			   this.uncheckHeaderCheckbox();
			}
			
			var b = this.tbody.find("> tr > td.ui-selection-column .ui-chkbox-box");
            var a = b.filter(".ui-state-disabled");
              
            if (b.length === a.length) {
                this.disableHeaderCheckbox()
            } else {
                this.enableHeaderCheckbox()
            }
		}
	},
	selectAllRowsOnPageTwo: function() {
		var b = this.tbody.children("tr");
		for (var a = 0; a < b.length; a++) {
			var c = b.eq(a);
			this.selectRowTwo(c, true)
		}
	},
	selectRowTwo: function(b, a) {
		var d = this.findRow(b),
			c = this.getRowMeta(d);
		this.highlightRow(d);
		if (this.isCheckboxSelectionEnabled()) {
			if (this.cfg.nativeElements) {
				d.children("td.ui-selection-column").find(":checkbox").prop("checked", true)
			} else {
				this.selectCheckbox(d.children("td.ui-selection-column").find("> div.ui-chkbox > div.ui-chkbox-box"))
			}
			this.updateHeaderCheckbox()
		}
		this.addSelection(c.key);
		this.writeSelections();
		if (!a) {
			this.fireRowSelectEvent(c.key, "rowSelect")
		}
	},
	selectRow: function(b, a) {
	},
	selectRowWithRadio: function(a) {
		var c = a.closest("tr"), b = this.getRowMeta(c);
		this.unselectAllRows();
		if (!this.cfg.nativeElements) {
			this.selectRadio(a)
		}
		this.highlightRow(c);
		this.addSelection(b.key);
		this.writeSelections();
		this.fireRowSelectEvent(b.key, "rowSelectRadio")
	},
	/** グリッドの頁遷移後にヘッダとボディの枠線がずれるので、ヘッダ右側の隙間の幅をスクロールバーの幅に設定する。
	 * 17ｐｘ固定で書いていたが、IEとChromeで動作が異なるのでスクロールバーを計算して設定するように変更 */
	alignScrollBody: function() {
		var scrollBarWidth = this.getScrollbarWidth() + "px";
		this.scrollHeaderBox.css("margin-right", scrollBarWidth);
		this.scrollFooterBox.css("margin-right", scrollBarWidth);
	},
	/** primefaces 5.2 対応 1レコード複数行表示時に列のサイズ変更が出来ない問題を修正。 */
	setupResizableColumns : function () {
		this.fixColumnWidths();
		if (!this.cfg.liveResize) {
			this.resizerHelper = $('<div class="ui-column-resizer-helper ui-state-highlight"></div>').appendTo(this.jq)
		}
		this.addResizers();
		var a = this.thead.find("> tr > th > span.ui-column-resizer"), b = this;
		a.draggable({
			axis : "x",
			start : function (d, e) {
				e.helper.data("originalposition", e.helper.offset());
				if (b.cfg.liveResize) {
					b.jq.css("cursor", "col-resize")
				} else {
					var c = b.cfg.scrollable ? b.scrollBody.height() : b.thead.parent().height() - b.thead.height() - 1;
					b.resizerHelper.height(c);
					b.resizerHelper.show()
				}
			},
			drag : function (c, d) {
				if (b.cfg.liveResize) {
					b.resize(c, d)
				} else {
					b.resizerHelper.offset(
							{
								left : d.helper.offset().left + d.helper.width() / 2, top : b.thead.offset().top + b.thead.height()
							})
				}
			},
			stop : function (d, f) {
				var e = f.helper.parent();
				f.helper.css({
					left : "", top : "0px"
				});
				if (b.cfg.liveResize) {
					b.jq.css("cursor", "default")
				} else {
					b.resize(d, f);
					b.resizerHelper.hide()
				}
				var c = {
						source : b.id, process : b.id, params : [ {
							name : b.id + "_colResize", value : true
						},
						{
							name : b.id + "_columnId", value : e.attr("id")
						},
						{
							name : b.id + "_width", value : e.width()
						},
						{
							name : b.id + "_height", value : e.height()
						}]
				};
				if (b.hasBehavior("colResize")) {
					b.cfg.behaviors.colResize.call(b, c)
				}
				if (b.cfg.stickyHeader) {
					b.thead.find(".ui-column-filter").prop("disabled", false);
					b.clone = b.thead.clone(true);
					b.cloneContainer.find("thead").remove();
					b.cloneContainer.children("table").append(b.clone);
					b.thead.find(".ui-column-filter").prop("disabled", true)
				}
			},
			containment : this.jq
		})
	},
	paginate: function(d) {
		var c = this
		  , b = {
			source: this.id,
			update: this.id,
			process: this.id,
			formId: this.cfg.formId,
			params: [{
				name: this.id + "_pagination",
				value: true
			}, {
				name: this.id + "_first",
				value: d.first
			}, {
				name: this.id + "_rows",
				value: d.rows
			}, {
				name: this.id + "_encodeFeature",
				value: true
			}],
			onsuccess: function(g, e, f) {
				PrimeFaces.ajax.Response.handle(g, e, f, {
					widget: c,
					handle: function(h) {
						this.updateData(h);
						if (this.checkAllToggler) {
							this.updateHeaderCheckbox()
						}
						if (this.cfg.scrollable) {
							this.alignScrollBody()
						}
					}
				});
				return true
			},
			oncomplete: function() {
				c.paginator.cfg.page = d.page;
				c.paginator.updateUI()
			}
		};
		if (this.hasBehavior("page")) {
			var a = this.cfg.behaviors.page;
			a.call(this, b)
		} else {
			PrimeFaces.ajax.Request.handle(b)
		}
		var targetId = '#' +this.id;
		targetId = targetId.replace(/:/g , "\\:")
		/** ページング実行時に、スクロールを先頭に戻す。 */
		$(targetId).children().get(2).scrollTop = 0;
	},
	/** 初期表示時にデータがoverflowしない場合、ヘッダとボディの枠線がずれるため、setupScrollingをオーバーライドします。 */
	setupScrolling: function() {
		this.scrollHeader = this.jq.children('.ui-datatable-scrollable-header');
		this.scrollBody = this.jq.children('.ui-datatable-scrollable-body');
		this.scrollFooter = this.jq.children('.ui-datatable-scrollable-footer');
		this.scrollStateHolder = $(this.jqId + '_scrollState');
		this.scrollHeaderBox = this.scrollHeader.children('div.ui-datatable-scrollable-header-box');
		this.scrollFooterBox = this.scrollFooter.children('div.ui-datatable-scrollable-footer-box');
		this.headerTable = this.scrollHeaderBox.children('table');
		this.bodyTable = this.scrollBody.children('table');
		this.footerTable = this.scrollFooter.children('table');
		this.footerCols = this.scrollFooter.find('> .ui-datatable-scrollable-footer-box > table > tfoot > tr > td');
		this.percentageScrollHeight = this.cfg.scrollHeight && (this.cfg.scrollHeight.indexOf('%') !== -1);
		this.percentageScrollWidth = this.cfg.scrollWidth && (this.cfg.scrollWidth.indexOf('%') !== -1);
		var $this = this,
		scrollBarWidth = this.getScrollbarWidth() + 'px';

		if(this.percentageScrollHeight) {
			this.adjustScrollHeight();
		}

		/** scrollHeightが設定されていなくても、グリッドのヘッダ右側の隙間をスクロールバーの幅に設定するように変更 */
		this.scrollHeaderBox.css('margin-right', scrollBarWidth);
		this.scrollFooterBox.css('margin-right', scrollBarWidth);

		this.fixColumnWidths();

		if(this.cfg.scrollWidth) {
			if(this.percentageScrollWidth)
				this.adjustScrollWidth();
			else
				this.setScrollWidth(parseInt(this.cfg.scrollWidth));
		}

		this.cloneHead();

		this.restoreScrollState();

		if(this.cfg.liveScroll) {
			this.scrollOffset = 0;
			this.cfg.liveScrollBuffer = (100 - this.cfg.liveScrollBuffer) / 100;
			this.shouldLiveScroll = true;       
			this.loadingLiveScroll = false;
			this.allLoadedLiveScroll = $this.cfg.scrollStep >= $this.cfg.scrollLimit;      
		}

		this.scrollBody.on('scroll.dataTable', function() {
			var scrollLeft = $this.scrollBody.scrollLeft();
			$this.scrollHeaderBox.css('margin-left', -scrollLeft);
			$this.scrollFooterBox.css('margin-left', -scrollLeft);

			if($this.shouldLiveScroll) {
				var scrollTop = this.scrollTop,
				scrollHeight = this.scrollHeight,
				viewportHeight = this.clientHeight;

				if((scrollTop >= ((scrollHeight * $this.cfg.liveScrollBuffer) - (viewportHeight))) && $this.shouldLoadLiveScroll()) {
					$this.loadLiveRows();
				}
			}

			$this.saveScrollState();
		});

		this.scrollHeader.on('scroll.dataTable', function() {
			$this.scrollHeader.scrollLeft(0);
		});

		this.scrollFooter.on('scroll.dataTable', function() {
			$this.scrollFooter.scrollLeft(0);
		});

		var resizeNS = 'resize.' + this.id;
		$(window).unbind(resizeNS).bind(resizeNS, function() {
			if($this.jq.is(':visible')) {
				if($this.percentageScrollHeight)
					$this.adjustScrollHeight();

				if($this.percentageScrollWidth)
					$this.adjustScrollWidth();
			}
		});
	}
})
/**
 * 固定列グリッドで、カラムのリサイズを行った際のレイアウト崩れ内容に修正
 * 
 * @author Masumi Inada (TDC)
 */
PrimeFaces.widget.FrozenDataTable = PrimeFaces.widget.FrozenDataTable.extend({
	_render: function() {
		if (this.cfg.scrollable) {
			this.setupScrolling()
		}
		if (this.cfg.resizableColumns) {
			this.setupResizableColumns()
		}
		if (this.cfg.draggableColumns) {
			this.setupDraggableColumns()
		}
		if (this.cfg.stickyHeader) {
			this.setupStickyHeader()
		}
		/** グリッドのグリッドヘッダとグリッドセルの高さを揃える */
		this.arrangeHeight()
		
		/** 描画時にクローンされるthタグの高さを0pxにする。 */
		var cfwParam = this
		cfwParam.arrangeCloneHeight()
	},
	arrangeHeight:function() {
		/** 固定テーブル件数を取得する。 */
		var rowLength = $(".ui-datatable-frozenlayout-right").length
		for(j = 0; j < rowLength; j++) {
			var targetId = '#'+ $(".ui-datatable-frozenlayout-right").get(j).parentElement.parentElement.parentElement.parentElement.id
			targetId = targetId.replace(/:/g,"\\:")
			/** 固定列のth要素の高さを取得する(ヘッダ) */
			var frozenHeaderHeight = $(targetId).find(".ui-datatable-frozenlayout-left").children().children().get(0).clientHeight
			/** 固定列以外のth(ヘッダ) */
			var headerHeight = $(targetId).find(".ui-datatable-frozenlayout-right").children().children().get(0).clientHeight
			if(frozenHeaderHeight > headerHeight) {				
				$(targetId).find(".ui-datatable-frozenlayout-right").children().children().children().children().children().children().get(0).style.height = frozenHeaderHeight -1 + '' + 'px'
			} else if(headerHeight > frozenHeaderHeight) {
				$(targetId).find(".ui-datatable-frozenlayout-left").children().children().children().children().children().children().get(0).style.height = headerHeight -1 + '' + 'px'
			}
			
			var rowCount = $(targetId).find(targetId + "_frozenTbody").children().length;
			/** ページ表示時にそれぞれの高さを取得する。 */
			for(i = 0; i < rowCount; i++) { 
				/** 固定列以外の高さを取得する。 */
				var currentRightHeight = $(targetId).find(targetId + "_scrollableTbody").children().get(i).getBoundingClientRect().height
				/** 固定列の高さを取得する。 */
				var currentLeftHeight = $(targetId).find(targetId + "_frozenTbody").children().get(i).getBoundingClientRect().height
				/** primefaces 5.2 対応 */
				if(currentRightHeight > currentLeftHeight) {
					$(targetId).find(targetId + "_frozenTbody").children().get(i).style.height = currentRightHeight  + '' + 'px';
					$(targetId).find(targetId + "_scrollableTbody").children().get(i).style.height = currentRightHeight + '' + 'px';
				} else if (currentRightHeight < currentLeftHeight) {
					$(targetId).find(targetId + "_frozenTbody").children().get(i).style.height = currentLeftHeight + '' + 'px';
					$(targetId).find(targetId + "_scrollableTbody").children().get(i).style.height = currentLeftHeight + '' + 'px';
				}
			}
		}
	},
	arrangeCloneHeight: function() {
		/** 固定テーブル件数を取得する。 */
		var rowLength = $(".ui-datatable-frozenlayout-right").length
		for(j = 0; j < rowLength; j++) {
			var targetId = $(".ui-datatable-frozenlayout-right").get(j).parentElement.parentElement.parentElement.parentElement.id
			targetId = targetId.replace(/:/g,"\\:")
			/** 描画時にクローンされたtdタグの高さを0pxにする。 */
			var $rightTd = $('#' + targetId).find(".ui-datatable-frozenlayout-right").children().children().children().children().children().get(1);
			if ($rightTd) {
				$rightTd.style.height = '0px';
			}
			var $leftTd= $('#' + targetId).find(".ui-datatable-frozenlayout-left").children().children().children().children().children().get(1);
			if ($leftTd) {
				$leftTd.style.height = '0px';
			}
		}
	},
	resize: function(b, m) {
		var d = m.helper.parent(),
			g = d.next(),
			l = null,
			f = null,
			h = null,
			o = d.index(),
			k = d.hasClass("ui-frozen-column-last");
		if (this.cfg.liveResize) {
			l = d.outerWidth() - (b.pageX - d.offset().left), f = (d.width() - l), h = (g.width() + l)
		} else {
			l = (m.position.left - m.originalPosition.left), f = (d.width() + l), h = (g.width() - l)
		}
		var i = k ? (f > 15) : (f > 15 && h > 15);
		if (i) {
			
			if (k) {
				/** 固定列のカラムリサイズ時のレイアウト崩れを対応 */
				return
			}
			d.width(f);
			g.width(h);
			var n = d.hasClass("ui-frozen-column"),
				e = n ? this.frozenTheadClone : this.scrollTheadClone,
				a = n ? this.frozenFooterCols : this.scrollFooterCols;
			e.find(PrimeFaces.escapeClientId(d.attr("id") + "_clone")).width(f);
			e.find(PrimeFaces.escapeClientId(g.attr("id") + "_clone")).width(h);
			if (a.length > 0) {
				var j = a.eq(o),
					c = j.next();
				j.width(f);
				c.width(h)
			}
		}
	},
	toggleCheckAll: function() {
		/** 固定列の際にチェックボックスでグリッドヘッダのチェックボックスを選択した際に、非表示ページのデータもチェックするように変更。 */
		if (this.cfg.nativeElements) {
			var d = this.tbody.find("> tr.ui-datatable-selectable > td.ui-selection-column > :checkbox"), c = this.checkAllToggler.prop("checked"), e = this;
			d.each(function() {
				if (c) {
					var f = $(this);
					f.prop("checked", true);
					e.selectRowWithCheckbox(f, true)
				} else {
					var f = $(this);
					f.prop("checked", false);
					e.unselectRowWithCheckbox(f, true)
				}
			})
		} else {
			var d = this.tbody.find("> tr.ui-datatable-selectable > td.ui-selection-column .ui-chkbox-box"), c = this.checkAllToggler.hasClass("ui-state-active"), e = this;
			if (c) {
				e.unselectAllRows();
				this.checkAllToggler.removeClass("ui-state-active").children("span.ui-chkbox-icon").addClass("ui-icon-blank").removeClass("ui-icon-check");
			} else {
				e.selectAllRows();
				this.checkAllToggler.addClass("ui-state-active").children("span.ui-chkbox-icon").removeClass("ui-icon-blank").addClass("ui-icon-check");
			}
		}
		this.writeSelections();
		if (this.cfg.behaviors) {
			var a = this.cfg.behaviors.toggleSelect;
			if (a) {
				var b = {params: [{name: this.id + "_checked",value: !c}]};
				a.call(this, b)
			}
		}
	},
	/** 行選択を行った際に、チェックボックスにチェックをするように修正。 */
	selectCheckbox: function(a) {
		var targetId = '#'+ a.parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().get(0).id
		targetId = targetId.replace(/:/g,"\\:")
	   	var selectionRowIndex = a.parent().parent().parent().get(0).rowIndex;
	   	$(targetId).find(".ui-datatable-frozenlayout-left").find("span.ui-chkbox-icon").get(selectionRowIndex).parentNode.className = $(targetId).find(".ui-datatable-frozenlayout-left").find("span.ui-chkbox-icon").get(selectionRowIndex).parentNode.className + ' ui-state-active'
	   	$(targetId).find(".ui-datatable-frozenlayout-left").find("span.ui-chkbox-icon").get(selectionRowIndex).className =  $(targetId).find(".ui-datatable-frozenlayout-left").find("span.ui-chkbox-icon").get(selectionRowIndex).className.replace('ui-icon-blank','ui-icon-check');
	   	$(targetId).find(".ui-datatable-frozenlayout-left").find("input").get(selectionRowIndex).checked = true;  
	},
	/** 行選択を行った際に、バッキングビーンに送信するキーを設定する。 */
	getRowMeta: function(b) {
		var a = {
			index: b.data("ri"),
			key: b.data("rk")
		};
		return a
	},	
	/** バッキングビーンに送信するキーを配列に保持する。 */
	addSelection: function(a) {
		if (!this.isSelected(a)) {
			this.selection.push(a)
		}
	},
	/** グリッドの頁遷移後にヘッダとボディの枠線がずれるので、ヘッダ右側の隙間の幅をスクロールバーの幅に設定する。
	 * 17ｐｘ固定で書いていたが、IEとChromeで動作が異なるのでスクロールバーを計算して設定するように変更 */
	alignScrollBody: function() {
		var scrollBarWidth = this.getScrollbarWidth() + "px";
		this.scrollHeaderBox.css("margin-right", scrollBarWidth);
		this.scrollFooterBox.css("margin-right", scrollBarWidth);
	},
	bindRowHover: function(a) {
	},
	paginate: function(d) {
		var c = this, b = {source: this.id,update: this.id,process: this.id,formId: this.cfg.formId,params: [{name: this.id + "_pagination",value: true}, {name: this.id + "_first",value: d.first}, {name: this.id + "_rows",value: d.rows}, {name: this.id + "_encodeFeature",value: true}],onsuccess: function(g, e, f) {
				PrimeFaces.ajax.Response.handle(g, e, f, {widget: c,handle: function(h) {
						this.updateData(h);
						if (this.checkAllToggler) {
							this.updateHeaderCheckbox()
						}
						if (this.cfg.scrollable) {
							this.alignScrollBody()
						}
					}});
				return true
			},oncomplete: function() {
				c.paginator.cfg.page = d.page;
				c.paginator.updateUI()
				/** 固定テーブル件数を取得する。 */
				var rowLength = $(".ui-datatable-frozenlayout-right").length
				for(j = 0; j < rowLength; j++) {
					var targetId = '#'+ $(".ui-datatable-frozenlayout-right").get(j).parentElement.parentElement.parentElement.parentElement.id
					targetId = targetId.replace(/:/g,"\\:")
					/** 固定列のth要素の高さを取得する(ヘッダ) */
					var frozenHeaderHeight = $(targetId).find(".ui-datatable-frozenlayout-left").children().children().get(0).clientHeight
					/** 固定列以外のtd(ヘッダ) */
					var headerHeight = $(targetId).find(".ui-datatable-frozenlayout-right").children().children().get(0).clientHeight
					if(frozenHeaderHeight > headerHeight) {				
						$(targetId).find(".ui-datatable-frozenlayout-right").children().children().children().children().children().children().get(0).style.height = frozenHeaderHeight -1 + '' + 'px'
					} else if(headerHeight > frozenHeaderHeight) {
						$(targetId).find(".ui-datatable-frozenlayout-left").children().children().children().children().children().children().get(0).style.height = headerHeight -1 + '' + 'px'
					}
					
					var rowCount = $(targetId).find(targetId + "_frozenTbody").children().length;
					/** ページ表示時にそれぞれの高さを取得する。 */
					for(i = 0; i < rowCount; i++) { 
						/** 固定列以外の高さを取得する。 */
						var currentRightHeight = $(targetId).find(targetId + "_scrollableTbody").children().get(i).getBoundingClientRect().height
						/** 固定列の高さを取得する。 */
						var currentLeftHeight = $(targetId).find(targetId + "_frozenTbody").children().get(i).getBoundingClientRect().height
						/** primefaces 5.2 対応 */
						if(currentRightHeight > currentLeftHeight) {
							$(targetId).find(targetId + "_frozenTbody").children().get(i).style.height = currentRightHeight  + '' + 'px';
							$(targetId).find(targetId + "_scrollableTbody").children().get(i).style.height = currentRightHeight + '' + 'px';
						} else if (currentRightHeight < currentLeftHeight) {
							$(targetId).find(targetId + "_frozenTbody").children().get(i).style.height = currentLeftHeight + '' + 'px';
							$(targetId).find(targetId + "_scrollableTbody").children().get(i).style.height = currentLeftHeight + '' + 'px';
						}
					}
				}
			}};
		if (this.hasBehavior("page")) {
			var a = this.cfg.behaviors.page;
			a.call(this, b)
		} else {
			PrimeFaces.ajax.Request.handle(b)
		}
		var targetId = '#' +this.id;
		targetId = targetId.replace(/:/g , "\\:")
		/** ページング実行時に、スクロールを先頭に戻す。 */
		$(targetId).children().children().children().children().children().children().get(4).scrollTop = 0;
	},	
	/** ページングをした際にキーをコピーする。 */
	copyRow: function(a) {
		/** primefaces 5.2対応 */
		return $("<tr></tr>").data("ri", a.data("ri")).attr("data-rk", a.data("rk")).addClass(a.attr("class")).attr("role", "row")
	},
	selectRow: function(b, a) {
	},
	selectAllRows: function() {
		this.selectAllRowsOnPageTwo();
		
		var allName = this.jqId + '_selection_cfw';
		var allValue = $(allName).val();

		var allArray = allValue.split(",");

		this.selection = [];
		for (var i = 0; i < allArray.length; i++) {
			this.addSelection(allArray[i]);
		}

        this.writeSelections();
	},
	updateHeaderCheckbox: function() {
		if(this.isEmpty()) {
			this.uncheckHeaderCheckbox();
			this.disableHeaderCheckbox();

		} else {
			var allName = this.jqId + '_selection_cfw';
			var allValue = $(allName).val();
			var allArray = allValue.split(",");

			if (this.selection.length == allArray.length) {
			   this.checkHeaderCheckbox();
			} else {
			   this.uncheckHeaderCheckbox();
			}

			var b = this.tbody.find("> tr > td.ui-selection-column .ui-chkbox-box");
            var a = b.filter(".ui-state-disabled");
              
            if (b.length === a.length) {
                this.disableHeaderCheckbox()
            } else {
                this.enableHeaderCheckbox()
            }
		}
	},
	selectAllRowsOnPageTwo: function() {
		var targetId = '#' + this.id + '_frozenTbody'
		targetId = targetId.replace(/:/g,"\\:")
		var b = $(targetId).find("tr")
		for (var a = 0; a < b.length; a++) {
			var c = b.eq(a);
			this.selectRowTwo(c, true)
		}
	},
	selectRowTwo: function(b, a) {
		var d = this.findRow(b),
			c = this.getRowMeta(d);
		this.highlightRow(d);
		if (this.isCheckboxSelectionEnabled()) {
			if (this.cfg.nativeElements) {
				d.children("td.ui-selection-column").find(":checkbox").prop("checked", true)
			} else {
				this.selectCheckbox(d.children("td.ui-selection-column").find("> div.ui-chkbox > div.ui-chkbox-box"))
			}
			this.updateHeaderCheckbox()
		}
		this.addSelection(c.key);
		this.writeSelections();
		if (!a) {
			this.fireRowSelectEvent(c.key, "rowSelect")
		}
	},
	sort: function(d, a, f) {
		var e = this,
			b = {
				source: this.id,
				update: this.id,
				process: this.id,
				params: [{
					name: this.id + "_sorting",
					value: true
				}, {
					name: this.id + "_skipChildren",
					value: true
				}, {
					name: this.id + "_encodeFeature",
					value: true
				}],
				onsuccess: function(i, g, h) {
					PrimeFaces.ajax.Response.handle(i, g, h, {
						widget: e,
						handle: function(j) {
							this.updateData(j);
							var l = e.getPaginator();
							if (l) {
								l.setPage(0, true)
							}
							if (!f) {
								this.sortableColumns.filter(".ui-state-active").data("sortorder", this.SORT_ORDER.UNSORTED).removeClass("ui-state-active").find(".ui-sortable-column-icon").removeClass("ui-icon-triangle-1-n ui-icon-triangle-1-s")
							}
							d.data("sortorder", a).removeClass("ui-state-hover").addClass("ui-state-active");
							var k = d.find(".ui-sortable-column-icon");
							if (a === this.SORT_ORDER.DESCENDING) {
								k.removeClass("ui-icon-triangle-1-n").addClass("ui-icon-triangle-1-s")
							} else {
								if (a === this.SORT_ORDER.ASCENDING) {
									k.removeClass("ui-icon-triangle-1-s").addClass("ui-icon-triangle-1-n")
								}
							}
						}
					});
					return true
				},
				oncomplete: function(i, g, h) {
					var j = e.getPaginator();
					if (j && h && j.cfg.rowCount !== h.totalRecords) {
						j.setTotalRecords(h.totalRecords)
					}
					/** 固定テーブル件数を取得する。 */
					var rowCount = parseInt($(".ui-paginator-rpp-options").get(0).value,10)
					/** ページ表示時にそれぞれの高さを取得する。 */
					for(i = 0; i < rowCount; i++) {
						var targetId = '#' + this.source
						targetId = targetId.replace(/:/g,"\\:")
						var currentRightHeight = $(targetId).find(targetId + "_scrollableTbody").children().get(i).offsetHeight
						var currentLeftHeight = $(targetId).find(targetId + "_frozenTbody").children().get(i).offsetHeight
						/** primefaces 5.2 対応 */
						if(currentRightHeight > currentLeftHeight) {
							$(targetId).find(targetId + "_frozenTbody").children().get(i).style.height = currentRightHeight  + '' + 'px';
							$(targetId).find(targetId + "_scrollableTbody").children().get(i).style.height = currentRightHeight + '' + 'px';
						} else if (currentRightHeight < currentLeftHeight) {
							$(targetId).find(targetId + "_frozenTbody").children().get(i).style.height = currentLeftHeight + '' + 'px';
							$(targetId).find(targetId + "_scrollableTbody").children().get(i).style.height = currentLeftHeight + '' + 'px';
						}
					}
				}
			};
		if (f) {
			b.params.push({
				name: this.id + "_multiSorting",
				value: true
			});
			b.params.push({
				name: this.id + "_sortKey",
				value: e.joinSortMetaOption("col")
			});
			b.params.push({
				name: this.id + "_sortDir",
				value: e.joinSortMetaOption("order")
			})
		} else {
			b.params.push({
				name: this.id + "_sortKey",
				value: d.attr("id")
			});
			b.params.push({
				name: this.id + "_sortDir",
				value: a
			})
		}
		if (this.hasBehavior("sort")) {
			var c = this.cfg.behaviors.sort;
			c.call(this, b)
		} else {
			PrimeFaces.ajax.Request.handle(b)
		}
	},
	fixColumnWidths: function() {
		if (!this.columnWidthsFixed) {
			if (PrimeFaces.isIE(7)) {
				this.bodyTable.css("width", "auto")
			}
			if (this.cfg.scrollable) {
				this._fixColumnWidths(this.scrollHeader, this.scrollFooterCols, this.scrollColgroup);
				this._fixColumnWidths(this.frozenHeader, this.frozenFooterCols, this.frozenColgroup)
			} else {
				this.jq.find("> .ui-datatable-tablewrapper > table > thead > tr > th").each(function() {
					var a = $(this);
					a.width(a.width())
				}
				)
			}
			this.columnWidthsFixed = true
		}
	},
	_fixColumnWidths: function(b, a) {
		b.find("> .ui-datatable-scrollable-header-box > table > thead > tr > th").each(function() {
			var f = $(this)
			  , c = f.index()
			  , d = f.width();
			f.width(d);
			if (a.length > 0) {
				var e = a.eq(c);
				e.width(d)
			}
		}
		)
	},
	setScrollWidth: function(b) {
		var c = this
		  , a = b + this.frozenLayout.width();
		this.jq.children(".ui-widget-header").each(function() {
			c.setOuterWidth($(this), a)
		}
		);
		this.scrollHeader.width(b);
		this.scrollBody.css("margin-right", 0).width(b);
		this.scrollFooter.width(b)
	},
	/** 初期表示時にデータがoverflowしない場合、ヘッダとボディの枠線がずれるため、setupScrollingをオーバーライドします。 */
	setupScrolling: function() {
		this.scrollLayout = this.jq.find('> table > tbody > tr > td.ui-datatable-frozenlayout-right');
		this.frozenLayout = this.jq.find('> table > tbody > tr > td.ui-datatable-frozenlayout-left');
		this.scrollContainer = this.jq.find('> table > tbody > tr > td.ui-datatable-frozenlayout-right > .ui-datatable-scrollable-container');
		this.frozenContainer = this.jq.find('> table > tbody > tr > td.ui-datatable-frozenlayout-left > .ui-datatable-frozen-container');
		this.scrollHeader = this.scrollContainer.children('.ui-datatable-scrollable-header');
		this.scrollHeaderBox = this.scrollHeader.children('div.ui-datatable-scrollable-header-box');
		this.scrollBody = this.scrollContainer.children('.ui-datatable-scrollable-body');
		this.scrollFooter = this.scrollContainer.children('.ui-datatable-scrollable-footer');
		this.scrollFooterBox = this.scrollFooter.children('div.ui-datatable-scrollable-footer-box');
		this.scrollStateHolder = $(this.jqId + '_scrollState');
		this.scrollHeaderTable = this.scrollHeaderBox.children('table');
		this.scrollBodyTable = this.scrollBody.children('table');
		this.scrollThead = this.thead.eq(1);
		this.scrollTbody = this.tbody.eq(1);
		this.scrollFooterTable = this.scrollFooterBox.children('table');
		this.scrollFooterCols = this.scrollFooter.find('> .ui-datatable-scrollable-footer-box > table > tfoot > tr > td');  
		this.frozenHeader = this.frozenContainer.children('.ui-datatable-scrollable-header');
		this.frozenBody = this.frozenContainer.children('.ui-datatable-scrollable-body');
		this.frozenBodyTable = this.frozenBody.children('table');
		this.frozenThead = this.thead.eq(0);
		this.frozenTbody = this.tbody.eq(0);
		this.frozenFooter = this.frozenContainer.children('.ui-datatable-scrollable-footer');
		this.frozenFooterTable = this.frozenFooter.find('> .ui-datatable-scrollable-footer-box > table');
		this.frozenFooterCols = this.frozenFooter.find('> .ui-datatable-scrollable-footer-box > table > tfoot > tr > td');
		this.percentageScrollHeight = this.cfg.scrollHeight && (this.cfg.scrollHeight.indexOf('%') !== -1);
		this.percentageScrollWidth = this.cfg.scrollWidth && (this.cfg.scrollWidth.indexOf('%') !== -1);

		this.frozenThead.find('> tr > th').addClass('ui-frozen-column');

		var $this = this,
		scrollBarWidth = this.getScrollbarWidth() + 'px';

		if(this.percentageScrollHeight) {
			this.adjustScrollHeight();
		}

		/** scrollHeightが設定されていなくても、グリッドのヘッダ右側の隙間をスクロールバーの幅に設定するように変更 */
		this.scrollHeaderBox.css('margin-right', scrollBarWidth);
		this.scrollFooterBox.css('margin-right', scrollBarWidth);

		this.fixColumnWidths();

		if(this.cfg.scrollWidth) {
			if(this.percentageScrollWidth)
				this.adjustScrollWidth();
			else
				this.setScrollWidth(parseInt(this.cfg.scrollWidth));

			if(this.hasVerticalOverflow()) {
				if(PrimeFaces.env.browser.webkit === true)
					this.frozenBody.append('<div style="height:' + scrollBarWidth + ';border:1px solid transparent"></div>');
				else if(PrimeFaces.isIE(8))
					this.frozenBody.append('<div style="height:' + scrollBarWidth + '"></div>');
				else
					this.frozenBodyTable.css('margin-bottom', scrollBarWidth);
			}
		}

		this.cloneHead();  

		this.restoreScrollState();

		if(this.cfg.liveScroll) {
			this.scrollOffset = 0;
			this.cfg.liveScrollBuffer = (100 - this.cfg.liveScrollBuffer) / 100;
			this.shouldLiveScroll = true;       
			this.loadingLiveScroll = false;
			this.allLoadedLiveScroll = $this.cfg.scrollStep >= $this.cfg.scrollLimit;            
		}

		this.scrollBody.scroll(function() {
			var scrollLeft = $this.scrollBody.scrollLeft(),
			scrollTop = $this.scrollBody.scrollTop();
			$this.scrollHeaderBox.css('margin-left', -scrollLeft);
			$this.scrollFooterBox.css('margin-left', -scrollLeft);
			$this.frozenBody.scrollTop(scrollTop);

			if($this.shouldLiveScroll) {
				var scrollTop = this.scrollTop,
				scrollHeight = this.scrollHeight,
				viewportHeight = this.clientHeight;

				if((scrollTop >= ((scrollHeight * $this.cfg.liveScrollBuffer) - (viewportHeight))) && $this.shouldLoadLiveScroll()) {
					$this.loadLiveRows();
				}
			}

			$this.saveScrollState();
		});

		var resizeNS = 'resize.' + this.id;
		$(window).unbind(resizeNS).bind(resizeNS, function() {
			if($this.jq.is(':visible')) {
				if($this.percentageScrollHeight)
					$this.adjustScrollHeight();

				if($this.percentageScrollWidth)
					$this.adjustScrollWidth();
			}
		});
	}
});
/**
 * 日付選択部品の拡張
 */
$.extend($.datepicker, {

	parseDate: function (format, value, settings) {

		if (format == null || value == null) {
			throw "Invalid arguments";
		}

		value = (typeof value === "object" ? value.toString() : value + "");
		if (value === "") {
			return null;
		}

		var iFormat, dim, extra,
			iValue = 0,
			shortYearCutoffTemp = (settings ? settings.shortYearCutoff : null) || this._defaults.shortYearCutoff,
			shortYearCutoff = (typeof shortYearCutoffTemp !== "string" ? shortYearCutoffTemp :
				new Date().getFullYear() % 100 + parseInt(shortYearCutoffTemp, 10)),
			dayNamesShort = (settings ? settings.dayNamesShort : null) || this._defaults.dayNamesShort,
			dayNames = (settings ? settings.dayNames : null) || this._defaults.dayNames,
			monthNamesShort = (settings ? settings.monthNamesShort : null) || this._defaults.monthNamesShort,
			monthNames = (settings ? settings.monthNames : null) || this._defaults.monthNames,
			year = -1,
			month = -1,
			day = -1,
			doy = -1,
			literal = false,
			date,
			// Check whether a format character is doubled
			lookAhead = function(match) {
				var matches = (iFormat + 1 < format.length && format.charAt(iFormat + 1) === match);
				if (matches) {
					iFormat++;
				}
				return matches;
			},
			// Extract a number from the string value
			getNumber = function(match) {
				var isDoubled = lookAhead(match),
					size = (match === "@" ? 14 : (match === "!" ? 20 :
					(match === "y" && isDoubled ? 4 : (match === "o" ? 3 : 2)))),
					digits = new RegExp("^\\d{1," + size + "}"),
					num = value.substring(iValue).match(digits);
				if (!num) {
					throw "Missing number at position " + iValue;
				}
				iValue += num[0].length;
				return parseInt(num[0], 10);
			},
			// Extract a name from the string value and convert to an index
			getName = function(match, shortNames, longNames) {
				var index = -1,
					names = $.map(lookAhead(match) ? longNames : shortNames, function (v, k) {
						return [ [k, v] ];
					}).sort(function (a, b) {
						return -(a[1].length - b[1].length);
					});

				$.each(names, function (i, pair) {
					var name = pair[1];
					if (value.substr(iValue, name.length).toLowerCase() === name.toLowerCase()) {
						index = pair[0];
						iValue += name.length;
						return false;
					}
				});
				if (index !== -1) {
					return index + 1;
				} else {
					throw "Unknown name at position " + iValue;
				}
			},
			// Confirm that a literal character matches the string value
			checkLiteral = function() {
				if (value.charAt(iValue) !== format.charAt(iFormat)) {
					throw "Unexpected literal at position " + iValue;
				}
				iValue++;
			};

		for (iFormat = 0; iFormat < format.length; iFormat++) {
			if (literal) {
				if (format.charAt(iFormat) === "'" && !lookAhead("'")) {
					literal = false;
				} else {
					checkLiteral();
				}
			} else {
				switch (format.charAt(iFormat)) {
					case "d":
						day = getNumber("d");
						break;
					case "D":
						getName("D", dayNamesShort, dayNames);
						break;
					case "o":
						doy = getNumber("o");
						break;
					case "m":
						month = getNumber("m");
						break;
					case "M":
						month = getName("M", monthNamesShort, monthNames);
						break;
					case "y":
						year = getNumber("y");
						break;
					case "@":
						date = new Date(getNumber("@"));
						year = date.getFullYear();
						month = date.getMonth() + 1;
						day = date.getDate();
						break;
					case "!":
						date = new Date((getNumber("!") - this._ticksTo1970) / 10000);
						year = date.getFullYear();
						month = date.getMonth() + 1;
						day = date.getDate();
						break;
					case "'":
						if (lookAhead("'")){
							checkLiteral();
						} else {
							literal = true;
						}
						break;
					default:
						checkLiteral();
				}
			}
		}

		if (iValue < value.length){
			extra = value.substr(iValue);
			if (!/^\s+/.test(extra)) {
				throw "Extra/unparsed characters found in date: " + extra;
			}
		}

		if (year === -1) {
			year = new Date().getFullYear();
		} else if (year < 100) {
			year += new Date().getFullYear() - new Date().getFullYear() % 100 +
				(year <= shortYearCutoff ? 0 : -100);
		}

		/** yyyy/MMで、日付の値がない場合、日付に1を設定(下の3ステップのみ追加) */
		if (day === -1) {
			day = 1;
		}

		if (doy > -1) {
			month = 1;
			day = doy;
			do {
				dim = this._getDaysInMonth(year, month - 1);
				if (day <= dim) {
					break;
				}
				month++;
				day -= dim;
			} while (true);
		}

		date = this._daylightSavingAdjust(new Date(year, month - 1, day));
		if (date.getFullYear() !== year || date.getMonth() + 1 !== month || date.getDate() !== day) {
			throw "Invalid date"; // E.g. 31/02/00
		}
		return date;
	}
});
/**
 * 数値テキストボックス<br>
 * TGFWの数字キー以外を無効化する処理を削除
 * 
 * @author Yuuki Matsushima (TDC)
 */
PrimeFaces.widget.Spinner = PrimeFaces.widget.Spinner.extend({
	init : function(a) {
		this.cfg = a;
		this.id = a.id;
		this.jqId = PrimeFaces.escapeClientId(this.id);
		this.jq = $(this.jqId);
		this.widgetVar = a.widgetVar;
		$(this.jqId + "_s").remove();
		if (this.widgetVar) {
			var b = this;
			this.jq.on("remove", function() {
				PrimeFaces.detachedWidgets.push(b.widgetVar)
			})
		}
				this.input = this.jq.children(".ui-spinner-input");
				this.upButton = this.jq.children("a.ui-spinner-up");
				this.downButton = this.jq.children("a.ui-spinner-down");
				this.cfg.step = this.cfg.step || 1;
				this.cursorOffset = this.cfg.prefix ? this.cfg.prefix.length
						: 0;
				if (parseInt(this.cfg.step) === 0) {
					this.cfg.precision = this.cfg.step.toString().split(
							/[,]|[.]/)[1].length
				}
				var b = this.input.attr("maxlength");
				if (b) {
					this.cfg.maxlength = parseInt(b)
				}
				this.updateValue();
				this.addARIA();
				if (this.input.prop("disabled") || this.input.prop("readonly")) {
					return
				}
				this.bindEvents();
				this.input.data(PrimeFaces.CLIENT_ID_DATA, this.id);
				PrimeFaces.skinInput(this.input)
	}
});

PrimeFaces.widget.BlockUI = PrimeFaces.widget.BlockUI.extend({
	show: function() {
        // this.blocker.css('z-index', ++PrimeFaces.zindex);
        this.blocker.css('z-index', 90);
        
        // center position of content
        this.content.css({
            'left': (this.blocker.width() - this.content.outerWidth()) / 2,
            'top': (this.blocker.height() - this.content.outerHeight()) / 2,
            // 'z-index': ++PrimeFaces.zindex
            'z-index': 90
        });

        if(this.cfg.animate)
            this.blocker.fadeIn();    
        else
            this.blocker.show();

        if(this.hasContent()) {
            this.content.fadeIn();
        }
    }
});

/**
 * ダイアログフォーカス制御
 * 
 * @author Yuuki Matsushima (TDC)
 */
PrimeFaces.widget.CfwDialogFocusController = PrimeFaces.widget.BaseWidget.extend({
	init : function(a) {
		this._super(a);
		
		// start属性、end属性の値を取得
		var startId = this.cfg.start;
		var endId = this.cfg.end;
		
		// ダイアログ表示時に先頭の要素にフォーカスを当てる
		setTimeout(function() {
			var $start = getJQueryObject(startId);
			$start.focus();
		}, 100);

		var $contents = $('.dialogContents');

		$contents.on('keydown', function(e) {
			if (e.keyCode !== $.ui.keyCode.TAB) {
				return;
			}
			var $start = getJQueryObject(startId);
			var $end = getJQueryObject(endId);
			if (e.target == $end[0]) {
				if (!e.shiftKey) {
					$start.focus();
					return false;
				}
			}
			if (e.target == $start[0]) {
				if (e.shiftKey) {
					$end.focus();
					return false;
				}
			}
			
		});
		
		// 指定したidのJQueryオブジェクトを取得する。
		var getJQueryObject = function(id) {
			// 【指定されたID】に完全一致する要素を取得
			if ($("#" + id).get(0)) {
				var $target = $("#" + id);
				// 日付・数値テキストボックスは以下のようになるため、取得した要素がspanだったら、「_input」を付けて再取得
				// <span id="【指定されたID】"...><input id="【指定されたID_input】"...></span>
				return ($target.get(0).tagName == "SPAN") ? $("#" + id + "_input") : ($target.get(0).tagName == "DIV") ? $("#" + id + "_rppDD") : $target;
				
			// 【指定されたID:】に前方一致する要素を取得
			} else if ($("[id^='" + id + "\\:']").get(0)) {
				return $("[id^='" + id + "\\:']");
				
			// 【:指定されたID】に後方一致する要素を取得
			} else if ($("[id$='\\:" + id + "']").get(0)) {
				var $target = $("[id$='\\:" + id + "']");
				// 上と同様に取得した要素がspanだったら、「_input」を付けて再取得
				return ($target.get(0).tagName == "SPAN") ? $("[id$='\\:" + id + "_input']") : ($target.get(0).tagName == "DIV") ? $("[id$='\\:" + id + "_rppDD']") : $target;
				
			// 【:指定されたID:】に部分一致する要素を取得
			} else if ($("[id*='\\:" + id + "\\:']").get(0)) {
				return $("[id*='\\:" + id + "\\:']");
			}
			return null;

		};
	}
});