/**
 * サブウィンドウのonLoadで実行するメソッド。
 */
onLoadFunc = function() {
	// ストレージの取得
	var array = localStorage.getItem("cfw_open_subwindow");
	if (array == null) {
		array = new Array();
	} else {
		array = JSON.parse(array);
	}

	// ストレージに存在しない場合は追加
	if (array.indexOf(window.name) < 0) {
		array.push(window.name);
		localStorage.setItem("cfw_open_subwindow", JSON.stringify(array));
	}
}

/**
 * サブウィンドウのonbeforeunloadで実行するメソッド。
 */
onUnLoadFunc = function() {
	var array = localStorage.getItem("cfw_open_subwindow");
	if (array != null) {
		array = JSON.parse(array);
		var index = array.indexOf(window.name);
		if (index >= 0) {
			array.splice(index, 1);
		}
		if (array.length == 0) {
			localStorage.removeItem("cfw_open_subwindow");
		} else {
			localStorage.setItem("cfw_open_subwindow", JSON.stringify(array));
		}
	}
	return array;
}

/** ウィンドウを開く */
openWindow = function(url, title, options) {
	var w = window.open(url, title, options);

	// サブウィンドウのオンロードに移動
	/*
	var array = localStorage.getItem("cfw_open_subwindow");
	if (array == null) {
		array = new Array();
	} else {
		array = JSON.parse(array);
	}

	// ストレージに存在しない場合は追加
	if (array.indexOf(title) < 0) {
		array.push(title);
		localStorage.setItem("cfw_open_subwindow", JSON.stringify(array));
	}
	*/
}

/** ウィンドウを開き、フォーカスを当てる */
openWindowAndFocus = function(url, name, features) {
	var win = window.open(url, name, features);
	
	// ポップアップブロックの設定がされている場合window.openでnullが返る。その場合returnする。
	if (win == null) {
		return;
	}
	
	setTimeout(function() {
		win.focus();
	}, 0);
};

/** ウィンドウを閉じる */
closeWindow = function(close) {
	if (close) {
		var array = JSON.parse(localStorage.getItem("cfw_open_subwindow"));
		if (array != null) {
			for (var i = 0; i < array.length; i++) {
				if (array[i]) {
					var w = window.open("", array[i], 'width=4, height=4, status=no, scrollbars=no, location=no, toolbar=no, menubar=no, left=0, top=0');
					if (w) {
						w.close();
					}
				}
			}
			localStorage.removeItem("cfw_open_subwindow");
		}
	}
}

/** ブックマークに登録する。 */
bookmark = function(url, title) {
	window.external.AddFavorite(url, title);
}

/** 複数メッセージをドラッグ可能にする。 */
$(function() {
	$("div").on({
		"mouseover" : function(e) {
			/** マウスポインターが入った際に、ドラッグ可能にする。 */
			$(this).draggable({
				handle:'div',
				disabled : false,
			});
		},
		"mouseout" : function(e) {
			/** マウスポインターが外れた際に、ドラッグ不可能にする。 */
			$(this).draggable({
				disabled : true
			});
		}
	}, ".cisfw-messages")
	/** }, ".ui-messages-info , .ui-messages-warn , .ui-messages-error") */
});

/**
 *  戻る制御
 * */
$(function() {
	/** バックスペースキー、Alt + ←→での画面遷移を抑止する。 */
	$(document).keydown(function(event) {
		/** クリックされたキーコードを取得する。 */
		var keyCode = event.keyCode;
		/** Ctrlキーがクリックされたかを取得する。 */
		var ctrlClick = event.ctrlKey;
		/** Altキーがクリックされたかを取得する。 */
		var altClick = event.altKey;
		/** Shiftキーがクリックされたかを取得する。 */
		var shitClick = event.shiftKey;
		/** キーイベントが発生した対象のオブジェクトを取得する。 */
		var obj = event.target;

		/** バックスペースキー(keyCpde:8)を制御する。 */
		if (keyCode == 8) {
			return isInputComponent(obj);
		}

		/** Alt + ←→(ブラウザの戻る、進む)を制御する。 */
		if (altClick && (keyCode == 37 || keyCode == 39)) {
			return false;
		}

		/** ショートカットキーでのコンテキストメニュー表示を抑止する。 */
		if (shitClick && (keyCode == 121)) {
			return isInputComponent(obj);
		}
	});

	/** 右クリックでのコンテキストメニューの表示を抑止する。 */
	$(document).on("contextmenu", function(event) {
		/** キーイベントが発生した対象のオブジェクトを取得する。 */
		var obj = event.target;
		return isInputComponent(obj);

	});
});

/** 入力部品かチェックを行う。 */
isInputComponent = function(obj) {
	if ((obj.tagName == "INPUT" && (obj.type == "text" || obj.type == "password")) || obj.tagName == "TEXTAREA") {
		/** 入力できる場合は制御しない */
		if (!obj.readOnly && !obj.disabled) {
			return true;
		}
	}
	return false;
}

/** ダイアログを画面外にドラッグできないようにする。（スクロール発生時） */
$(function() {
	var $window = $(window);
	var drag_controll = function(e, _ui) {
		var $dialog = $(e.target);
		$dialog.on({
			drag : function(e) {
				var position = $dialog.offset();
				var w = $dialog.prop("clientWidth");
				var h = $dialog.prop("clientHeight");
				var scrTop = $window.scrollTop();
				var scrLeft = $window.scrollLeft();
				var scrRight = scrLeft + $window.width();
				var scrBottom = scrTop + $window.height();
				var p = 10; // 境界値から何px戻すか(0(境界値=再設定値)はNG)
				if (position.top <= scrTop - 5) { // 上はヘッダーしかドラッグイベント発生しない場合があるので、少しはみ出したところで戻す
					$dialog.offset({
						top : scrTop + p
					});
					e.preventDefault();
				}
				if (position.left + w * 0.9 <= scrLeft) { // 倍率x0にするとダイアログが画面外に出れなくなる
					$dialog.offset({
						left : scrLeft + p
					});
					e.preventDefault();
				}
				if (position.left + w * 0.1 >= scrRight) { // 倍率x1にするとダイアログが画面外に出れなくなる
					$dialog.offset({
						left : scrRight - w - p
					});
					e.preventDefault();
				}
				if (position.top + h * 0.1 >= scrBottom) { // 倍率x1にするとダイアログが画面外に出れなくなる
					$dialog.offset({
						top : scrBottom - h - p
					});
					e.preventDefault();
				}
				return true;
			}
		});
	}
	// ドラッグできるものすべてを対象にするわけではないので、ダイアログとメッセージに絞り込む
	$(document.body).on("dragcreate", ".ui-draggable.ui-dialog, .ui-draggable.cisfw-messages", drag_controll);
});

/**
 * バージョン5.3.Finalに含まれる対応を引用（menubarの表示位置改善）
 * PrimeFaces Menubar Widget
 */
PrimeFaces.widget.Menubar = PrimeFaces.widget.TieredMenu.extend({
    
    showSubmenu: function(menuitem, submenu) {
        var pos = null;
        
        if(menuitem.parent().hasClass('ui-menu-child')) {
            pos = {
                my: 'left top',
                at: 'right top',
                of: menuitem,
                collision: 'flipfit'
            };
        }
        else {
            pos = {
                my: 'left top',
                at: 'left bottom',
                of: menuitem,
                collision: 'flipfit'
            };
        }
        
        submenu.css('z-index', ++PrimeFaces.zindex)
                .show()
                .position(pos);
    },
          
    //@Override
    bindKeyEvents: function() {
        var $this = this;

        this.keyboardTarget.on('focus.menubar', function(e) {
            $this.highlight($this.links.eq(0).parent());
        })
        .on('blur.menubar', function() {
            $this.reset();
        })
        .on('keydown.menu', function(e) {
            var currentitem = $this.activeitem;
            if(!currentitem) {
                return;
            }
            
            var isRootLink = !currentitem.closest('ul').hasClass('ui-menu-child'),
            keyCode = $.ui.keyCode;
            
            switch(e.which) {
                    case keyCode.LEFT:
                        if(isRootLink) {
                            var prevItem = currentitem.prevAll('.ui-menuitem:not(.ui-menubar-options):first');
                            if(prevItem.length) {
                                $this.deactivate(currentitem);
                                $this.highlight(prevItem);
                            }
                            
                            e.preventDefault();
                        }
                        else {
                            if(currentitem.hasClass('ui-menu-parent') && currentitem.children('.ui-menu-child').is(':visible')) {
                                $this.deactivate(currentitem);
                                $this.highlight(currentitem);
                            }
                            else {
                                var parentItem = currentitem.parent().parent();
                                $this.deactivate(currentitem);
                                $this.deactivate(parentItem);
                                $this.highlight(parentItem);
                            }
                        }
                    break;
                    
                    case keyCode.RIGHT:
                        if(isRootLink) {
                            var nextItem = currentitem.nextAll('.ui-menuitem:not(.ui-menubar-options):first');
                            if(nextItem.length) {
                                $this.deactivate(currentitem);
                                $this.highlight(nextItem);
                            }

                            e.preventDefault();
                        }
                        else {
                            if(currentitem.hasClass('ui-menu-parent')) {
                                var submenu = currentitem.children('.ui-menu-child');
                                
                                if(submenu.is(':visible'))
                                    $this.highlight(submenu.children('.ui-menuitem:first'));
                                else
                                    $this.activate(currentitem);
                            }
                        }
                    break;
                    
                    case keyCode.UP:
                        if(!isRootLink) {         
                            var prevItem = currentitem.prev('.ui-menuitem');
                            if(prevItem.length) {
                                $this.deactivate(currentitem);
                                $this.highlight(prevItem);
                            }                   
                        }
                        
                        e.preventDefault();
                    break;
                    
                    case keyCode.DOWN:
                        if(isRootLink) {
                            var submenu = currentitem.children('ul.ui-menu-child');
                            if(submenu.is(':visible'))
                                $this.highlight(submenu.children('.ui-menuitem:first'));
                            else
                                $this.activate(currentitem);                        
                        }
                        else {
                            var nextItem = currentitem.next('.ui-menuitem');
                            if(nextItem.length) {
                                $this.deactivate(currentitem);
                                $this.highlight(nextItem);
                            }
                        }
                        
                        e.preventDefault();
                    break;
                    
                    case keyCode.ENTER:
                    case keyCode.NUMPAD_ENTER:
                        var currentLink = currentitem.children('.ui-menuitem-link');
                        currentLink.trigger('click');
                        $this.jq.blur();
                        var href = currentLink.attr('href');
                        if(href && href !== '#') {
                            window.location.href = href;
                        }
                        
                        e.preventDefault();
                    break;
                    
            }        
        });
    }
    
});

/**
 * cfw:commandButton,commandLink,confirmButtonでindicator=trueの場合、onClick時に実行されるメソッド。
 * 各テンプレートごとにOverrideし、indicator=trueの場合onClickで実施したい処理を実装する。
 */
attachEvent = function() {
}

/**
 * cfw:commandButton,commandLink,confirmButtonでindicator=trueの場合、onClick時に実行されるメソッド。
 * 各テンプレートごとにOverrideし、indicator=falseの場合onClickで実施したい処理を実装する。
 */
detachEvent = function() {
}