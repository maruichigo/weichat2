package jp.co.sharedsys.ssframe.dao;

import java.util.List;

/**　DAOの基底I/F
 * @author K.Akeda
 *
 * @param <T>
 */
public interface Dao<T> {

    /** 追加
     * @param entity
     * @return 追加したEntity
     */
    T create(T entity);

    /** PKでの検索
    * @param entity 検索パラメータ
    * @return 検索結果
    */
    T findById(T entity);


    /** PK以外の項目での検索
     * @param entity 検索パラメータ
     * @return 検索結果
     */
    List<T> findByColumn(T entity);

    /** 上記以外の検索
     * @param entity 検索パラメータ
     * @param sqlId SQLID
     * @return 検索結果
     */
    List<T> find(T entity, String sqlId);

    /** 更新
     * @param entity 更新するEntity
     * @return 更新結果
     */
    T update(T entity);

    /** 更新
     * @param searchCriteria 検索条件
     * @param entity 更新するEntity
     * @return 更新結果
     */
    List<T> updateByColumn(T searchCriteria,T entity);

    /** 更新
     * @param searchCriteria 検索条件
     * @param entity 更新データのリスト
     * @param sqlId 実行SQLID
     * @return 更新結果
     */
    List<T> update(T searchCriteria,T entity,String sqlId);

    /** 追加
     * @param entity 追加データのリスト
     * @param sqlId 実行SQLID
     * @return 更新結果
     */
    List<T> insert(List<T> entity, String sqlId);
    
    /** 追加
     * @param entity 追加データ
     * @param sqlId 実行SQLID
     * @return 更新結果
     */
    List<T> insert(T entity, String sqlId);

    
    /** 物理削除
     * @param id 削除したい情報のPK
     */
    void delete(String id);

    /** 物理削除
     * @param entity 削除条件
     */
    void deleteByColumn(T entity);

    /**
     * 論理削除
     * @param entity  削除情報
     * @return 削除結果
     */
    T softDelete(T entity);

    /**
     * 論理削除
     * @param entity  削除情報
     * @return 削除結果
     */
    List<T> softDeleteByColumn(T entity);

    /** 全件検索
     * @return 検索結果
     */
    List<T> findAll();
    
    String tableName();
}
