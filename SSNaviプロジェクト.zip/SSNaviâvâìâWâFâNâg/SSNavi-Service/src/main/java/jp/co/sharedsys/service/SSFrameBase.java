package jp.co.sharedsys.service;

import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.springframework.web.context.WebApplicationContext;

import jp.co.sharedsys.ssframe.model.BaseModel;

/**
 * 
 * @author sharedsys
 */
public class SSFrameBase {

    protected WebApplicationContext wac;

    /**
     * 登録時共通カラム（作成者、作成日、最終更新者、最終更新日）をセット
     *
     * @param model
     *            セット対象のモデル
     * @param UserCd
     *            ログインユーザーID
     */
    protected void setCommonFieldForCreate(BaseModel model, String UserCd) {
        model.setCreatedBy(UserCd);
        model.setLastModifiedBy(UserCd);
        Date date = new Date();
        model.setCreatedDate(date);
        model.setLastModifiedDate(date);
    }

    /**
     * 更新時共通カラム（最終更新者、最終更新日）をセット
     *
     * @param model
     *            セット対象のモデル
     * @param UserCd
     *            ログインユーザーID
     */
    protected void setCommonFieldForUpdate(BaseModel model, String UserCd) {
        model.setLastModifiedBy(UserCd);
        Date date = new Date();
        model.setLastModifiedDate(date);
    }


    /**
     * Stringから前後の半角・全角の空白、タブを取り除く
     * @param targetChar いらない文字を取り除くもの
     * @param optTab タブを取り除くときはTrue
     * @return
     */
    protected String removeNGCharFromString(String targetChar , boolean optTab){
        String ret = "";
        if (StringUtils.isEmpty(targetChar)) {
                return targetChar;
        }
        // 半角と全角の空白を取り除く
        int st = 0;
        int len = targetChar.length();
        char[] val = targetChar.toCharArray();
        while ((st < len) && ((val[st] <= '\u0020') || (val[st] == '\u00A0') || (val[st] == '\u3000'))) {
            st++;
        }
        while ((st < len) && ((val[len - 1] <= '\u0020') || (val[len - 1] == '\u00A0') || (val[len - 1] == '\u3000'))) {
            len--;
        }
        ret = ((st > 0) || (len < targetChar.length())) ? targetChar.substring(st, len) : targetChar;

        if(!optTab){
            return ret;
        }

        // tab削除
        ret.replaceAll("\t", "");
        return ret;
    }
}
