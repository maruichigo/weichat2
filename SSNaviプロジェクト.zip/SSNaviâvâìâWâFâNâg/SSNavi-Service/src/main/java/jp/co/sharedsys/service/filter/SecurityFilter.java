package jp.co.sharedsys.service.filter;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.PreMatching;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;

import org.springframework.stereotype.Component;

import jp.co.sharedsys.common.log.LOG;
import jp.co.sharedsys.common.methods.Cryptor;

/**
 * ssframeへのアクセス制限を行うためのフィルタクラスです
 * @author sharedsys
 */
@Component
@Provider
@PreMatching
public class SecurityFilter implements ContainerRequestFilter {

    @Context
    HttpServletRequest request;
    
    /**
     * リクエストフィルタです。<br>
     * @param requestContext
     * @throws java.io.IOException
     */
    @Override
    public void filter(ContainerRequestContext requestContext) throws IOException {
        // リクエスト前処理
        String ip = request.getRemoteAddr();
        // for proxy
        String clientIp = request.getHeader( "x-forwarded-for" );
        // auth text
        String externalAccept = request.getHeader("external-accept");
        String encAcc = Cryptor.decryptDes(externalAccept, "4x1ez3T1NBt=");
        // mine address
        InetAddress addr = null;
        try {
            addr = InetAddress.getLocalHost();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        String mine = addr.getHostAddress();
		
        // キーが合ってなければ、FORBIDDENとする
        if (!"ssframeAuthStrings".equals(encAcc)) {
//		if (!"127.0.0.1".equals(ip) && !mine.equals(ip) && !mine.equals(clientIp)) {
            LOG.error("SecurityFilter Unknown Host!!! IP[" + ip + "] X-Forwarderd-for[" + clientIp + "]");
            requestContext.abortWith(
                Response.status(Response.Status.FORBIDDEN)
                .entity("")
                .build()
            );            
        }
    }
}