package jp.co.sharedsys.service;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.common.log.LOG;
import jp.co.sharedsys.service.common.exception.SSServerErrorException;

/**
 * ssframeサービス内でExceptionが発生した時にエラーレスポンスを構築する為のクラスです。<br>
 * Transactionの関係上、rollbackをしたい場合、サービスのメソッドから上位にExceptionを
 * スローする必要があり、そのままスローすると呼び出し元にエラーメッセージが返却出来ない
 * 状態になってしまいます。その為、ExceptionMapperでハンドリングし
 * エラー用レスポンスをこのクラスで構築しています。
 * 
 * @author sharedsys
 */
@Provider
public class ServerErrorExceptionMapper implements ExceptionMapper<SSServerErrorException> {

	@Override
	public Response toResponse(SSServerErrorException e) {
		
            LOG.debug("ExceptionMapper extecute...");
            Response result = Response.status(Response.Status.OK)
                            .entity(JSONUtil.makeJSONString(e.getServiceInterfaceBean()))
                            .type(MediaType.APPLICATION_JSON)
                            .build();

            return result;
	}

}
