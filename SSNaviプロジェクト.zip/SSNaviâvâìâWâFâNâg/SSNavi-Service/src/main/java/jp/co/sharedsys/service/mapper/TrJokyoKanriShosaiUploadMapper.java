package jp.co.sharedsys.service.mapper;

import java.util.List;
import java.util.Map;
import jp.co.sharedsys.service.model.TrJokyoKanriShosaiUpload;
import org.springframework.stereotype.Component;

/**
 * 状況管理詳細テーブル(共通アップロード用)
 * @author sharedsys
 */
@Component("TR_JOKYO_KANRI_SHOSAI_UPLOAD")
public interface TrJokyoKanriShosaiUploadMapper extends IMapper {
    
    List<TrJokyoKanriShosaiUpload> findAll();

    List<Map> findAllForSelector();
    
    TrJokyoKanriShosaiUpload findById(int id);
    
    List<TrJokyoKanriShosaiUpload> findByColumn(TrJokyoKanriShosaiUpload entity);
    
//    List<TrJokyoKanri> findLineInfo();

}
