package jp.co.sharedsys.service.bus.common;

import java.util.List;
import java.util.Map;


import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Iterator;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.exception.SystemException;
import jp.co.sharedsys.common.methods.SSCommonUtil;
import jp.co.sharedsys.service.bus.SSFrameBusBase;
import jp.co.sharedsys.service.mapper.IMapper;

/** 
 * 共通メンテナンス用データ取得
 */
@Component("SS_COM_MAINT_UPDATE")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class SsComMaintUpdateBus extends SSFrameBusBase {
    protected final String TABLE_NAME = "TABLE_NAME";
    
    private IMapper mapForTarget(String target) {
        IMapper mapper =(IMapper)this.getWebApplicationContext().getBean(target);
        if (mapper != null) {
            return mapper;
        }
        throw new UnsupportedOperationException("unsupported table");
    }
    private IMapper targetMapper;
    
    private Map<String, Object> params = null;
    private List<Map<String, Object>> inputParams = null;
    
    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        super.init(serviceInterfaceBean);
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
        for (Iterator<String> ite = params.keySet().iterator();ite.hasNext();) {
            String key = ite.next();
            if (TABLE_NAME.equals(key)) {
                targetMapper = this.mapForTarget((String) params.get(key));
            } else {
                inputParams = (List)params.get(key);
            }
        }
    }

    @Override
    public String validateHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    } 
	
    @Override
    public String validateDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public String validateHeaderByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public String validateDetailByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    /** 
     * 検索
     * @param serviceInterfaceBean リクエストパラメータ
     * @throws Exception
     */
    @Override
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        List<Map> result = null;
        for (Map input : inputParams) {
            input.put("UserCd", serviceInterfaceBean.getUserCd());
            if ( input.get("newrow") != null && (Boolean)input.get("newrow") ) {
                targetMapper.insert(input);
            } else {
                List<Map> check = targetMapper.findById(input);
                boolean isUpdate = false;
                if (check != null && !check.isEmpty()) {
                    for (Iterator<String> ite = check.get(0).keySet().iterator(); ite.hasNext();) {
                        String key = ite.next();
                        String camelizedKey = SSCommonUtil.camelize(key);
                        if (input.get(camelizedKey) == null) {
                            continue;
                        }
                        if (!String.valueOf(input.get(camelizedKey)).equals(String.valueOf(check.get(0).get(key)))) {
                            // DBの値と違うものがあれば更新対象とする
                            isUpdate = true;
                            break;
                        }
                    }
                    if (isUpdate) {
                        targetMapper.update(input);
                    }
                } else {
            		throw new SystemException("更新対象のキーが存在しませんでした。");
                }
            }
        }
        serviceInterfaceBean.setMessage("データの登録・更新に成功しました");
    }

    @Override
    public void saveDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }
    
    @Override
    public void setValidaterFactory() throws Exception {
    }

    @Override
    public void confirm(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }

    @Override
    public String finalProc(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }
}
