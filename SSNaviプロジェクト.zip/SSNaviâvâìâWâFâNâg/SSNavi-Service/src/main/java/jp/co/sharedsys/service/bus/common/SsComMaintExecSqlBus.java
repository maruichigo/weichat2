package jp.co.sharedsys.service.bus.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.service.bus.SSFrameBusBase;
import jp.co.sharedsys.service.mapper.IMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.sharedsys.service.mapper.SsComMaintExecSqlMapper;

/**
 *
 * @author SS
 */
@Component("SS_COM_MAINT_EXEC_SQL")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class SsComMaintExecSqlBus extends SSFrameBusBase {

    protected final String TABLE_NAME = "TABLE_NAME";
    
    @Autowired
    private SsComMaintExecSqlMapper execSqlmapper;    

    private IMapper mapForTarget(String target) {
        IMapper mapper =(IMapper)this.getWebApplicationContext().getBean(target);
        if (mapper != null) {
            return mapper;
        }
        throw new UnsupportedOperationException("unsupported table");
    }
    private IMapper targetMapper;
    
    private Map<String, Object> params = null;    

    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        super.init(serviceInterfaceBean);
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
        targetMapper = this.mapForTarget("COM_MAINT_EXEC_SQL");        
    }
    
    @Override
    public String validateHeaderByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public String validateDetailByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public void setValidaterFactory() throws Exception {
    }

    @Override
    public String validateHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public String validateDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {

    }

    @Override
    public void saveDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        List<Map<String, Object>> resultList = execSqlmapper.query((String)params.get("exec_sql"));
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
    }

    @Override
    public void confirm(ServiceInterfaceBean serviceInterfaceBean) throws Exception {

    }

    @Override
    public String finalProc(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }
}
