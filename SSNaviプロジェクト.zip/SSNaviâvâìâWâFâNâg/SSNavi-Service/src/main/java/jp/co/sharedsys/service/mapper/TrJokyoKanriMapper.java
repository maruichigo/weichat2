package jp.co.sharedsys.service.mapper;

import java.util.List;
import java.util.Map;
import jp.co.sharedsys.service.model.TrJokyoKanri;
import org.springframework.stereotype.Component;

/**
 * 状況管理テーブル(共通アップロード用)
 * @author sharedsys
 */
@Component("TR_JOKYO_KANRI")
public interface TrJokyoKanriMapper extends IMapper {
    
    List<TrJokyoKanri> findAll();

    List<Map> findAllForSelector();
    
    TrJokyoKanri findById(int id);
    
    List<TrJokyoKanri> findByColumn(TrJokyoKanri entity);
    
    List<TrJokyoKanri> findStatusInfo(TrJokyoKanri entity);

}
