package jp.co.sharedsys.service;

import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.ServletContext;

import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.ServletContextAware;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.URLDecoder;
import java.util.HashMap;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.exception.InvalidValueException;
import jp.co.sharedsys.common.log.LOG;
import jp.co.sharedsys.service.bus.ISSFrameBus;
import jp.co.sharedsys.ssframe.common.SSFrameMessage;
import jp.co.sharedsys.service.common.exception.SSServerErrorException;
import jp.co.sharedsys.ssframe.dao.Dao;
import jp.co.sharedsys.ssframe.model.Function;
import jp.co.sharedsys.ssframe.model.User;
import jp.co.sharedsys.service.mapper.SsComMaintTableMapper;
import jp.co.sharedsys.service.model.SsComMaintTable;
import org.glassfish.jersey.media.multipart.BodyPart;
import org.glassfish.jersey.media.multipart.BodyPartEntity;
import org.glassfish.jersey.media.multipart.FormDataMultiPart;

/**　ssframeの公開サービス
 * 
 * ServiceInterfaceBean.functionCodeでFUNCTION_CODE_MASTERを検索。
 * FUNCTION_CODE_MASTERに登録されているクラスのメソッドを実行する。
 * 
 * @author sharedsys
 *
 */
//@Component("ssFrameService")
@Component
@Path("/ssframe")
@Scope(value = WebApplicationContext.SCOPE_REQUEST)
public class SSFrameService extends AbstractSSFrameService implements ServletContextAware {

    @Autowired(required=true)
    @Resource(shareable=true)
    protected Dao<Function> functionDao;

    @Autowired(required=true)
    @Resource(shareable=true)
    protected Dao<User> userDao;

    @Autowired
    private SsComMaintTableMapper tableMapper;

    @Context
    private ServletContext servletContext;
    
    private static final String SEPARATE_VALIDATE = "before";
    private static final String SEPARATE_FINAL = "final";
    
    @Override
    public void setServletContext(ServletContext servletContext) {
       this.servletContext = servletContext;
    }
    
    @Override
    @POST
    @Path("/JohmonWebService")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Transactional(propagation=Propagation.REQUIRED)
    public ServiceInterfaceBean baseService(ServiceInterfaceBean serviceInterfaceBean) throws SSServerErrorException {
        try {
                //===============================================================
                // パラメータ（serviceInterfaceBean）チェック
                //===============================================================
                checkServiceInterfaceBean(serviceInterfaceBean);
                // 上記パラメータチェックで問題があった場合はエラーとして処理を終了
                if(serviceInterfaceBean.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR){
                    throw new Exception(serviceInterfaceBean.getMessage());
                }
                //===============================================================
                // FunctionCodeでFUNCTION_CODE_MASTERを取得
                //===============================================================
                Function function = new Function();
                // 共通リストボックス取得用
                if ( serviceInterfaceBean.getFunctionCode().endsWith("_COMLIST") ) {
                    function.setFunctionCode("COM_CREATE_LIST");
                    String fcd = serviceInterfaceBean.getFunctionCode().replace("_COMLIST", "");
                    serviceInterfaceBean.setFunctionCode(fcd);
                } else {
                    function.setFunctionCode(serviceInterfaceBean.getFunctionCode());
                }
                
                List<Function> functions = functionDao.findByColumn(function);
                if(functions == null || functions.size() == 0 || functions.get(0) == null){
                    serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SYSTEM_ERROR);
                    serviceInterfaceBean.setMessage(SSFrameMessage.MSG_SYSTEM_ERROR_NOT_EXIST_FUNCTION);
                    return serviceInterfaceBean;
                }
                function = functions.get(0);
                //===============================================================
                // 実行処理クラスのインスタンス作成
                //===============================================================
                // FUNCTION_CODE_MASTERに登録されているクラスのインスタンスを作成
//			Class<?> c = Class.forName(function.getClassName());

                // 2015.08.19 saihara Busのメソッド単位でTransactionを行えるよう、springからクラスを取得する。
                // (当面、従来のfunction_master.class_nameからのリフレクションにも対応しておく)
                // 2015.08.21 springからの取得へ移行、reflectionは一旦コメント
                WebApplicationContext wac = WebApplicationContextUtils.getRequiredWebApplicationContext(servletContext);
                ISSFrameBus ssFrameBus = null;
                try {
                    ssFrameBus = (ISSFrameBus)wac.getBean(function.getFunctionCode());
                    ssFrameBus.setWebApplicationContext(wac);
//                    if (ssFrameBus == null) {
//                            ssFrameBus = (ISSFrameBus)c.newInstance();
//                    }
                } catch(NoSuchBeanDefinitionException e) {
                    throw e;
//			ssFrameBus = (ISSFrameBus)c.newInstance();
                }
			
                //===============================================================
                // 処理実行
                //===============================================================
                StringBuffer message = new StringBuffer();

                // 【共通】初期化処理
                ssFrameBus.init(serviceInterfaceBean);

                // 【共通】ValidaterFactory(データチェック処理クラス)の設定
                ssFrameBus.setValidaterFactory();

                // 【共通】ヘッダー情報のアノテーションによるチェック処理
                message.append(ssFrameBus.validateHeaderByAnnotation(serviceInterfaceBean));
                if(message.length() != 0){
                    throw new InvalidValueException(message.toString());
                }
                // 【共通】明細情報のアノテーションによるチェック処理
                message.append(ssFrameBus.validateDetailByAnnotation(serviceInterfaceBean));
                if(message.length() != 0){
                    throw new InvalidValueException(message.toString());
                }
			
                // 【共通】ヘッダー情報のチェック処理
                message.append(ssFrameBus.validateHeader(serviceInterfaceBean));
                if(message.length() != 0){
                    throw new InvalidValueException(message.toString());
                }
                // 【共通】明細情報のチェック処理
                message.append(ssFrameBus.validateDetail(serviceInterfaceBean));
                if(message.length() != 0){
                    throw new InvalidValueException(message.toString());
                }

                // 【個別】チェック処理
                message.append( separateCheck(serviceInterfaceBean, SEPARATE_VALIDATE) );
                if(message.length() != 0){
                    throw new InvalidValueException(message.toString());
                }

                // 【共通】ヘッダーのDB処理（登録、更新、削除)
                ssFrameBus.saveHeader(serviceInterfaceBean);
                // 【共通】明細のDB処理（登録、更新、削除)
			ssFrameBus.saveDetail(serviceInterfaceBean);

                // 【共通】確定処理
                try{
                    // 確定の場合は前処理のロールバックを行わないのでExceptionをCatchする。
                    ssFrameBus.confirm(serviceInterfaceBean);
                    // すべての処理が正常終了
                    serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
                } catch(Exception e){
                    serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SYSTEM_ERROR);
                    serviceInterfaceBean.setMessage(SSFrameMessage.MSG_SYSTEM_ERROR);
                    outStackTrace(e);
                    e.printStackTrace();
                }
                        
                // 【個別】後処理
                message.append( separateCheck(serviceInterfaceBean, SEPARATE_FINAL) );
                if(message.length() != 0){
                    throw new InvalidValueException(message.toString());
                }                        
                        
        } catch(InvalidValueException ve){
            serviceInterfaceBean.setMessage(ve.getMessage());
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            throw new SSServerErrorException(ve.getMessage(), ve, serviceInterfaceBean);
        } catch(Exception e) {
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SYSTEM_ERROR);
            serviceInterfaceBean.setMessage(SSFrameMessage.MSG_SYSTEM_ERROR);
            outStackTrace(e);
            e.printStackTrace();
            throw new SSServerErrorException(e.getMessage(), e, serviceInterfaceBean);
        }
        return serviceInterfaceBean;
    }
        
    /**
     * 【個別】チェック処理
     */
    private String separateCheck(ServiceInterfaceBean bean, String type) throws InvalidValueException, Exception {
        StringBuffer message = new StringBuffer();

        // functionCodeガ「共通メンテテーブル更新」以外は対象外
        if ( !"SS_COM_MAINT_UPDATE".equals( bean.getFunctionCode() )) {
            return message.toString();
        }
        if ( !bean.getJson().contains("TABLE_NAME") ) {
            return message.toString();
        }
            
        Map map = new HashMap();
        for(String val : bean.getJson().split(",")){
           String[] data = val.split(":");
           map.put(data[0].replaceAll("[^0-9a-zA-Z_]+",""), data[1].replaceAll("[^0-9a-zA-Z_]+", ""));
           if ( data[0].contains("TABLE_NAME") ) {
               break;
           }
        }

        //ss_com_maint_table_defを確認（個別処理が登録されているか）
        SsComMaintTable table = new SsComMaintTable();
        table.setTableName( map.get("TABLE_NAME").toString() );
        List<SsComMaintTable> resultList = tableMapper.findByColumn( table );
        // 登録されていれば
        if ( resultList.size() > 0 ) {
            WebApplicationContext wac = WebApplicationContextUtils.getRequiredWebApplicationContext(servletContext);
            ISSFrameBus ssFrameBus = null;

            // 【個別】処理
            if ( SEPARATE_VALIDATE.equals( type )) {

                try {
                    ssFrameBus = (ISSFrameBus)wac.getBean( resultList.get(0).getValidationProcId() );
                    ssFrameBus.setWebApplicationContext(wac);
                } catch(NoSuchBeanDefinitionException e) {
                    throw e;
                }

                // 【個別】ヘッダー情報のチェック処理
                message.append(ssFrameBus.validateHeader(bean));
                if(message.length() != 0){
                    return message.toString();
                }
                // 【個別】明細情報のチェック処理
                message.append(ssFrameBus.validateDetail(bean));
                if(message.length() != 0){
                    return message.toString();
                }
            // 後処理    
            } else if ( SEPARATE_FINAL.equals( type )) {
                
                try {
                    ssFrameBus = (ISSFrameBus)wac.getBean( resultList.get(0).getFinalProcId() );
                    ssFrameBus.setWebApplicationContext(wac);
                } catch(NoSuchBeanDefinitionException e) {
                    throw e;
                }
                
                // 【個別】後処理
                message.append(ssFrameBus.finalProc(bean));
                if(message.length() != 0){
                    return message.toString();
                }
            }
        }
        return message.toString();
    }

    private void outStackTrace(Exception e) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        e.printStackTrace(pw);
        pw.flush();
        String str = sw.toString();
        LOG.error(str);
    }

    protected void checkServiceInterfaceBean(ServiceInterfaceBean serviceInterfaceBean) throws InvalidValueException {
        if (serviceInterfaceBean.isInitial()) {
                // ログイン処理等、未ログインの処理に関するサービス呼び出しについては、Bean中身をチェックしない
                return;
        }
        if(serviceInterfaceBean == null 
                        || serviceInterfaceBean.getUserCd() == null 
                        || "".equals(serviceInterfaceBean.getUserCd())
                        ){

                serviceInterfaceBean.setMessage(SSFrameMessage.MSG_SYSTEM_ERROR_INVALID_PARAM);
                serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        } else {
            // ユーザーIDの確認
            User user = new User();
            user.setUserCd(String.valueOf(serviceInterfaceBean.getUserCd()));
            // UserCdがマスタに存在しているかどうかのチェック
            if(userDao.findById(user) == null){
                    serviceInterfaceBean.setMessage(SSFrameMessage.MSG_SYSTEM_ERROR_INVALID_UserCd_IN_PARAM);
                    serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            }
//			// ユーザーグループコードの確認
//			if(serviceInterfaceBean.getUserGroupCode() == null || "".equals(serviceInterfaceBean.getUserGroupCode())){
//				serviceInterfaceBean.setMessage(SSFrameMessage.MSG_SYSTEM_ERROR_INVALID_USER_GROUP_IN_PARAM);
//				serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
//			}
        }
    }

    @Override
    @POST
    @Path("/JohmonWebServiceForMultipart")
//    @Consumes("multipart/mixed; type=\"application/json\"")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    @Transactional(propagation=Propagation.REQUIRED)
//	public ServiceInterfaceBean baseServiceForMultipart(MultipartBody body) throws Exception, InvalidValueException {
    public ServiceInterfaceBean baseServiceForMultipart(FormDataMultiPart attachments) throws Exception, InvalidValueException {
        ServiceInterfaceBeanForMultiple serviceInterfaceBean = null;
        Map<String, InputStream> files = new LinkedHashMap<String, InputStream>();
        List<BodyPart> bodyPartList = attachments.getBodyParts();
        for (BodyPart att : bodyPartList) {
            LOG.debug("attachment content type: " + att.getMediaType().toString());
            if (att.getMediaType().getSubtype().equals("json")) {
                ObjectMapper mapper = new ObjectMapper();
                serviceInterfaceBean = mapper.readValue(((BodyPartEntity)att.getEntity()).getInputStream(), ServiceInterfaceBeanForMultiple.class);
            } else if (att.getMediaType().getSubtype().equals("octet-stream")) {
                String fileName = URLDecoder.decode(att.getContentDisposition().getFileName(), "UTF-8");
                files.put(fileName, ((BodyPartEntity)att.getEntity()).getInputStream());
//		        String ct = att.getContentType().toString();
//		        Message msg = new MessageImpl();
//		        msg.put(Message.CONTENT_TYPE, ct);
//		        msg.setContent(InputStream.class, att.getDataHandler().getInputStream());
//		        // store remaining embedded attachments
//		        for (org.apache.cxf.message.Attachment child : msg.getAttachments()) {
//		        	// to process
//		        }
            }
        }
        serviceInterfaceBean.setUploadFiles(files);
        return this.baseService(serviceInterfaceBean);
    }
}
