package jp.co.sharedsys.service.constraintannotation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.constraints.Digits;

/** 数値用Validator
 * 
 * NULL、空文字、文字列長のチェックを行う。
 * @author sharedsys
 *
 */
public class NumberFieldValidator implements ConstraintValidator<NumberField, Number>{

    private boolean isNotNull;
    private int integer;
    private int fraction;
    private long minValue;
    private long maxValue;

    @Override
    public void initialize(NumberField constraintAnnotation) {
        this.isNotNull = constraintAnnotation.isNotNull();
        this.integer  = constraintAnnotation.integer();
        this.fraction  = constraintAnnotation.fraction();
        this.minValue  = constraintAnnotation.minValue();
        this.maxValue  = constraintAnnotation.maxValue();
    }

    @Override
    public boolean isValid(Number value, ConstraintValidatorContext context) {
        // NULLと空文字を許可しない
        if(isNotNull){
            if(value == null || "".equals(value)){
                setMessage(context, "{columnName}は必須項目です。値を入力してください。\n");
                return false;
            }
        }
        if(value != null && !"".equals(value)){
            // 整数部桁多数チェック
            String work = value.toString().replace("-", "");
            String[] parts = work.split("\\.");
            if(parts[0].length() > integer){
                setMessage(context, "{columnName}が不正です。整数部の桁数は{integer}以下で入力してください。\n");
                return false;
            } 
            // 小数桁多数チェック
            if(parts.length > 1 && parts[1].length() > fraction){
                setMessage(context, "{columnName}が不正です。小数部の桁数は{integer}以下で入力してください。\n");
                return false;
            }
            // 最大値、最小値チェック
            if(value.doubleValue() < minValue || value.doubleValue() > maxValue){
                setMessage(context, "{columnName}が不正です。{minValue}以上{maxValue}以下で入力してください。\n");
                return false;
            }
        }
        return true;
    }
	
    private void setMessage(ConstraintValidatorContext context, String message){
        context.disableDefaultConstraintViolation();
        context.buildConstraintViolationWithTemplate(message).addConstraintViolation();
    }
}
