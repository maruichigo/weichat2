package jp.co.sharedsys.ssframe.model;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import lombok.Data;

/** ユーザークラス
 * @author K.Akeda
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "user")
@Data
//@XmlType(propOrder = { "UserCd", "password","userFirstName", "userLastName", "mailAddress", "createdBy","createdDate","lastModifiedBy","lastModifiedDate" })
public class User extends BaseModel implements Serializable {

    /**
    *
    */
    private static final long serialVersionUID = 7013090829426790523L;

    private String userCd;
    private Date tekiyoKaishibi;
    private String tekiyoMei;
    private String userMei;
	private String userMeiKana;
	private String useMeiEiji;
    private String mailAddress;
    private String siyoKbn;
    private String shozokuKashoCd;
	private String menuId;
	private String theme;
	private String biko1;
	private String biko2;
	private String biko3;
	private String biko4;
	private String shuryoFlg;
	private String sakujoFlg;

  
}
