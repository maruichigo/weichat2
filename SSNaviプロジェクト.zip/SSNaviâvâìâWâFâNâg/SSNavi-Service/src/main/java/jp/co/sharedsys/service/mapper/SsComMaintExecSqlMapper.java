package jp.co.sharedsys.service.mapper;

import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

/**
 *
 * @author shared
 */
@Component("COM_MAINT_EXEC_SQL")
public interface SsComMaintExecSqlMapper extends IMapper {

    @Select("${sql}")
    List<Map<String, Object>> query(@Param("sql") String sql );        
}

