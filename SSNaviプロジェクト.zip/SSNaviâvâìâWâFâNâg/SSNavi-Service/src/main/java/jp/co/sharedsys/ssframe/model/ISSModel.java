package jp.co.sharedsys.ssframe.model;

public interface ISSModel {
    String getLogicalNameByPhysical(String field);
}
