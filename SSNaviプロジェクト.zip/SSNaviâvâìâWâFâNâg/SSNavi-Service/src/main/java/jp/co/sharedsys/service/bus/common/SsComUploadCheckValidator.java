package jp.co.sharedsys.service.bus.common;

import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.Iterator;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.exception.SystemException;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.common.methods.SSCommonUtil;
import jp.co.sharedsys.service.bus.SSFrameBusBase;
import jp.co.sharedsys.service.mapper.IMapper;
import jp.co.sharedsys.service.mapper.MsUpFileDefMapper;
import jp.co.sharedsys.service.mapper.SsComUploadCheckResultMapper;
import jp.co.sharedsys.service.mapper.SsComUploadDefMapper;
import jp.co.sharedsys.service.mapper.SsComUploadRawDataMapper;
import jp.co.sharedsys.service.model.MsUpFileDef;
import jp.co.sharedsys.service.model.SsComUploadDef;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 共通アップロード　チェックボタン押下処理
 */
@Component("SS_COM_UPLOAD_VALIDATE")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class SsComUploadCheckValidator extends SSFrameBusBase {

    protected final String TABLE_NAME = "TABLE_NAME";
    protected final String SELECT_FILETYPE = "selectMaster";
    
//    @Autowired
//    private SsComUploadDefMapper uploadMapper;
    @Autowired
    private MsUpFileDefMapper upFileMapper; // 新(本番)テーブル用
    @Autowired
    private SsComUploadRawDataMapper uploadRawDataMapper;
    @Autowired
    private SsComUploadCheckResultMapper uploadCheckResultMapper;
    
    private IMapper mapForTarget(String target) {
        IMapper mapper = (IMapper) this.getWebApplicationContext().getBean(target);
        if (mapper != null) {
            return mapper;
        }
        throw new UnsupportedOperationException("unsupported table");
    }
    private IMapper targetMapper;

    private Map<String, Object> params = null;
    private List<Map<String, Object>> inputParams = null;
//    private SsComUploadDef targetDef = null;
    private MsUpFileDef targetDef = null;

    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        super.init(serviceInterfaceBean);
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
        for (Iterator<String> ite = params.keySet().iterator(); ite.hasNext();) {
            String key = ite.next();
            if (TABLE_NAME.equals(key)) {
                continue;
//                targetMapper = this.mapForTarget((String) params.get(key));
            } else {
                inputParams = (List) params.get(key);
            }
        }
    }

    @Override
    public String validateHeaderByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        // ソフトウェア方式設計に記載されているバリデーション処理用
        // dataspiderへ渡す前にデータチェックする場合はここで行う
        StringBuffer message = new StringBuffer();
        
        //iterator<String> ite = 
        //inputParams
        //必須項目の空チェック
//        if (inputParams == null || inputParams.isEmpty()){
//            message.append("nullまたは未入力の項目があります");
//            return message.toString(); 
//        }
        for (Map input : inputParams) {
            System.out.println(input);
            for (int i = 0; input.size() > i; i++) {
//                System.out.println(input.);
            }
        }
        
//        message.append("nullチェック完了");
//        return message.toString();
        return "";
    }

    @Override
    public String validateDetailByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }
    @Override
    public String validateHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        // ソフトウェア方式設計に記載されていない個別のバリデーション処理用
        return "";
    }

    @Override
    public String validateDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    /**
     * 検索
     *
     * @param serviceInterfaceBean リクエストパラメータ
     * @throws Exception
     */
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        MsUpFileDef upFile = new MsUpFileDef();
        upFile.setUploadKinoCd((String)params.get(SELECT_FILETYPE));// とりあえず、fileName→UploadKinoCdに置換(仮)
        List<MsUpFileDef> def = upFileMapper.findByColumn(upFile);
        targetDef = def.get(0);
        String dsChkValidate = targetDef.getIchijiHozonyoDsScriptUrl();// 取得するスクリプトは仮で一時保存用のものとしている。本来は、チェック処理用スクリプトになる
        // dataspiderでのバリデーションチェック結果ごとにメッセージ、再描画用データを変更する
        // TODO DataSpider側で一覧データとスクリプトを受け取る。
        //      受け取ったデータのバリデーションチェック処理後、ワークテーブル、チェック結果テーブル、件数テーブルを更新する。
        if(true){
            serviceInterfaceBean.setMessage("メッセージテスト");
            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(""));// ワークテーブルの結果を返す
        }
        // 登録結果メッセージ
        serviceInterfaceBean.setMessage("共通アップロード　バリデーションチェックが完了しました");
        

    }

    @Override
    public void saveDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {

    }

    @Override
    public void setValidaterFactory() throws Exception {

    }

    @Override
    public void confirm(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        
    }
    @Override
    public String finalProc(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }
}
