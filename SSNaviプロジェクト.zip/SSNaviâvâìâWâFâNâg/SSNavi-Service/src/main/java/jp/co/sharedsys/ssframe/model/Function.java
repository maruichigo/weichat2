/**
 *
 */
package jp.co.sharedsys.ssframe.model;

import java.io.Serializable;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/** ファンクションマスタクラス
 * @author S.Nagai
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "function")
public class Function implements Serializable{

    /**
     *
     */
    private static final long serialVersionUID = 8965633291910057625L;

    @NotNull
    @Size(max = 50)
    private String functionCode;

    @NotNull
    @Size(max = 45)
    private String functionName;

    @NotNull
    @Digits(integer = 11, fraction = 0)
    private Integer functionLevel;

    @Size(max = 50)
    private String parentFunctionCode;

    @NotNull
    @Size(max = 20)
    private String functionType;

    @Size(max = 20)
    private String screenCode;

    private Integer sortPriority;
    private String title;
    private String description;
    private String rptDirectory;
    private String rptFileName;

    @Size(max = 200)
    private String remarks;

    private String permission;

    /**機能コードの取得
     * @return 機能コード
     */
    @XmlElement(name = "functionCode")
    public String getFunctionCode() {
        return functionCode;
    }
    /**機能コードの設定
     * @param functionCode 機能コード
     */
    public void setFunctionCode(String functionCode) {
        this.functionCode = functionCode;
    }
    /**機能名の取得
     * @return 機能名
     */
    @XmlElement(name = "functionName")
    public String getFunctionName() {
        return functionName;
    }
    /**機能名の設定
     * @param functionName 機能名
     */
    public void setFunctionName(String functionName) {
        this.functionName = functionName;
    }
    /**機能の階層の取得
     * @return 機能の階層
     */
    @XmlElement(name = "functionLevel")
    public Integer getFunctionLevel() {
        return functionLevel;
    }
    /**機能の階層の設定
     * @param functionLevel 機能の階層
     */
    public void setFunctionLevel(Integer functionLevel) {
        this.functionLevel = functionLevel;
    }
    /**親機能コードの取得
     * @return 親機能コード
     */
    @XmlElement(name = "functionCode")
    public String getParentFunctionCode() {
        return parentFunctionCode;
    }
    /**親機能コードの設定
     * @param parentFunctionCode 親機能コード
     */
    public void setParentFunctionCode(String parentFunctionCode) {
        this.parentFunctionCode = parentFunctionCode;
    }
    /**機能の種別の取得
     * @return 機能の種別
     */
    @XmlElement(name = "functionType")
    public String getFunctionType() {
        return functionType;
    }
    /**機能の種別の設定
     * @param functionType 機能の種別
     */
    public void setFunctionType(String functionType) {
        this.functionType = functionType;
    }
    /**画面と機能の関連が必要な画面、画面コードを設定
     * screenCodeの取得
     * @return screenCode
     */
    @XmlElement(name = "screenCode")
    public String getScreenCode() {
        return screenCode;
    }
    /**画面と機能の関連が必要な画面、画面コードを設定
     * screenCodeの設定
     * @param screenCode
     */
    public void setScreenCode(String screenCode) {
        this.screenCode = screenCode;
    }

    /** 備考の取得
     * @return remarks
     */
    @XmlElement(name = "remarks")
    public String getRemarks() {
        return remarks;
    }
    /** 備考の設定
     * @param remarks
     */
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    /** 備考の取得
     * @return remarks
     */
    @XmlElement(name = "sortPriority")
    public Integer getSortPriority() {
        return sortPriority;
    }
    /** 備考の設定
     * @param sortPriority
     */
    public void setSortPriority(Integer sortPriority) {
        this.sortPriority = sortPriority;
    }

    /** 編集可否フラグの取得(user_group_x_functionから参照）
     * @return remarks
     */
    @XmlElement(name = "permission")
    public String getPermission() {
        return permission;
    }
    /** 編集可否フラグの設定
     * @param permission
     */
    public void setPermission(String permission) {
        this.permission = permission;
    }

    /** 機能タイトルの取得
     * @return 機能タイトル
     */
    @XmlElement(name = "title")
    public String getTitle() {
        return title;
    }
    /** 機能タイトルの設定
     * @param title 機能タイトル
     */
    public void setTitle(String title) {
        this.title = title;
    }
    /** 説明の取得
     * @return description
     */
    @XmlElement(name = "description")
    public String getDescription() {
        return description;
    }
    /** 説明の設定
     * @param description 設定
     */
    public void setDescription(String description) {
        this.description = description;
    }
    /** RPTディレクトリの取得
     * @return rptDirectory
     */
    @XmlElement(name = "rptDirectory")
    public String getRptDirectory() {
        return rptDirectory;
    }
    /** RPTディレクトリの設定
     * @param rptDirectory
     */
    public void setRptDirectory(String rptDirectory) {
        this.rptDirectory = rptDirectory;
    }
    /** RPTファイル名の取得
     * @return rptFileName
     */
    @XmlElement(name = "rptFileName")
    public String getRptFileName() {
        return rptFileName;
    }
    /** RPTファイル名の設定
     * @param rptFileName
     */
    public void setRptFileName(String rptFileName) {
        this.rptFileName = rptFileName;
    }
}
