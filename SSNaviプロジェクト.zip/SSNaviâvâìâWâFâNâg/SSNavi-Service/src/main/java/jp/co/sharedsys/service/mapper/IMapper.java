package jp.co.sharedsys.service.mapper;

import java.util.List;
import java.util.Map;
import jp.co.sharedsys.service.model.BaseModel;

/**
 *
 * @author sharedsys
 */
public interface IMapper {

    String TABLE_NAME = "";
    List<Map> findToMap(Map<String, Object> parameter);

    public List<Map> findById(Map input);

    public void insert(Map input);

    public void update(Map input);

    public void softDelete(Map input);

    public BaseModel findByIdToModel(Map input);    
}
