package jp.co.sharedsys.service;

import java.io.InputStream;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;

/**
 * アップロードファイル用に拡張したServiceInterfaceBeanです。
 * @author sharedsys
 *
 */
public class ServiceInterfaceBeanForMultiple extends ServiceInterfaceBean {

    @JsonIgnore
    private Map<String, InputStream> uploadFiles = null;

    /**
     * @return
     */
    public Map<String, InputStream> getUploadFiles() {
        return uploadFiles;
    }

    /**
     * @param uploadFiles
     */
    public void setUploadFiles(Map<String, InputStream> uploadFiles) {
        this.uploadFiles = uploadFiles;
    }
}
