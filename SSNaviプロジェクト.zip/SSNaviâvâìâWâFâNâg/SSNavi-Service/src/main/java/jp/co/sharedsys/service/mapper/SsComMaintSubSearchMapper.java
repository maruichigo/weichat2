package jp.co.sharedsys.service.mapper;

import java.util.List;
import jp.co.sharedsys.service.model.SsComMaintSubSearch;
import org.springframework.stereotype.Component;

/**
 *
 * @author sharedsys
 */
@Component("ss_com_maint_sub_search_def")
public interface SsComMaintSubSearchMapper extends IMapper {
    
    List<SsComMaintSubSearch> findAll();
    
    SsComMaintSubSearch findById(int id);
    
    List<SsComMaintSubSearch> findByColumn(SsComMaintSubSearch entity);
}
