package jp.co.sharedsys.service.mapper;

import java.util.List;
import java.util.Map;
import jp.co.sharedsys.service.model.SsComReportDef;
import org.springframework.stereotype.Component;

/**
 *
 * @author sharedsys
 */
@Component("ss_com_report_def")
public interface SsComReportDefMapper extends IMapper {
    
    List<SsComReportDef> findAll();

    List<Map> findAllForSelector();
    
    SsComReportDef findById(int id);
    
    List<SsComReportDef> findByColumn(SsComReportDef entity);
}
