package jp.co.sharedsys.service.common.exception;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;

/**
 * サービス実行中にExceptionが発生した場合にトランザクションを行うためのExceptionクラスです。<br>
 * @author saihara
 *
 */
public class SSServiceException  extends RuntimeException {

    private static final long serialVersionUID = 6228754072366142102L;
    private ServiceInterfaceBean serviceInterfaceBean = null;

    public SSServiceException(String message){
            super(message);
    }
    public SSServiceException(String message, Throwable cause, ServiceInterfaceBean bean){
            super(message,cause);
            serviceInterfaceBean = bean;
    }

    public ServiceInterfaceBean getServiceInterfaceBean() {
            return serviceInterfaceBean;
    }
    public void setServiceInterfaceBean(ServiceInterfaceBean serviceInterfaceBean) {
            this.serviceInterfaceBean = serviceInterfaceBean;
    }
}
