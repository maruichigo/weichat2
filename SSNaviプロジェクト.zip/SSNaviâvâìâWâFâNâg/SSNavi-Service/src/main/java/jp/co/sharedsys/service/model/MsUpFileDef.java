package jp.co.sharedsys.service.model;

import java.io.Serializable;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import jp.co.sharedsys.service.constraintannotation.PrimaryKey;
import lombok.Data;

/**
 * 共通アップロード用データ定義(本番テーブル用)
 *
 * @author sharedsys
 */
@Data
public class MsUpFileDef extends BaseModel implements Serializable {

    private static final long serialVersionUID = 8225066323266434396L;

//    @NotNull
//    @Digits(integer = 10, fraction = 0)
//    @Min(0)
    @PrimaryKey(columnName = "uploadKinoCd")

    private String uploadKinoCd;             // 機能名称コード
    private String uploadCd;                  // アップロードコード
    private String tekiyoKaishibi;            // 適用開始日
    private String ediSetteiId;               // EDI設定ID
//    private String dataFileMei;               // データファイル名
    
    private String dataFileMei;
    
    private String fileShubetsu;              // ファイル種別
    private String ichijiHozonyoWorkTableMei;          // 一時保存ワークテーブル名
    private String fileYomikomiyoDsScriptUrl;   // ファイル読込用DataSpiderScriptURL
    private String ichijiHozonyoDsScriptUrl;   // 一時保存用DataSpiderScriptURL
    private String hontorokuyoDsScriptUrl;   // 本登録用DataSpiderScriptURL
    private String fileHeaderGyoUmu;          // ファイルヘッダ行有無
    private String tekiyoShuryobi;                 // 終了フラグ
    private String sakujoFlg;                 // 削除フラグ
}
