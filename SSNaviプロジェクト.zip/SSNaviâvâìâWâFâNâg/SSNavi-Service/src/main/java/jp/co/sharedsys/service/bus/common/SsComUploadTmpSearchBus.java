package jp.co.sharedsys.service.bus.common;

import java.util.List;
import java.util.Map;


import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.service.model.SsComUploadDef;

/** 
 * 共通アップロード一時保存データ取得
 */
@Component("SS_COM_UPLOAD_TMP_SEARCH")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class SsComUploadTmpSearchBus extends SsComUploadBaseBus {
    
    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        super.init(serviceInterfaceBean);
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
    }
    
    @Override
    public String validateHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }
	
    @Override
    public String validateDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }
    
    @Override
    public String validateHeaderByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public String validateDetailByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    /** 
     * 検索
     * @param serviceInterfaceBean リクエストパラメータ
     * @throws Exception
     */
    @Override
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        SsComUploadDef crt = new SsComUploadDef();
        crt.setFileName((String)params.get(SELECT_FILETYPE));
        List<SsComUploadDef> def = uploadMapper.findByColumn(crt);
        this.targetDef = def.get(0);
    }

    @Override
    public void saveDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }
    
    @Override
    public void setValidaterFactory() throws Exception {
    }

    @Override
    public void confirm(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        List<Map> result = this.searchTmpData(serviceInterfaceBean.getUserCd(), null);
        if (result == null || result.isEmpty()) {
            serviceInterfaceBean.setMessage("アップロード登録データが存在しません。");
        } else {
            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
            serviceInterfaceBean.setMessage("共通アップロード 一時保存データ検索に成功しました");
        }
    }

    @Override
    public String finalProc(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }             
}
