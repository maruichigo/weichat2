package jp.co.sharedsys.service.mapper;

import java.util.List;
import java.util.Map;
import jp.co.sharedsys.service.model.TrUpFrmDat;
import org.springframework.stereotype.Component;

/**
 * アップロード元データ(共通アップロード用)
 * @author sharedsys
 */
@Component("TR_UPLOAD_MOTO_DATA")
public interface TrUpFrmDatMapper extends IMapper {
    
    List<TrUpFrmDat> findAll();

    List<Map> findAllForSelector();
    
    TrUpFrmDat findById(int id);
    
    List<TrUpFrmDat> findByColumn(TrUpFrmDat entity);
    
    List<TrUpFrmDat> findLineInfo(TrUpFrmDat entity);
    
}
