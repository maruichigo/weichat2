package jp.co.sharedsys.service.bus;

/**　データチェック処理クラスを作成するクラス
 * @author sharedsys
 *
 */
public abstract class SSFrameValidaterFactory {

    /**　　出荷指示チェッククラスを作成
     * @return 出荷指示チェッククラス
     */
    public abstract SSFrameValidaterProduct createInstrument();
}
