/**
 *
 */
package jp.co.sharedsys.ssframe.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/** システムクラス
 * @author K.Akeda
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "system")
public class SystemMaster implements Serializable{

    /**
     *
     */
    private static final long serialVersionUID = -484483151980776696L;
    private String systemUserCode;
    private String systemUserName;
    private BigDecimal rate1;
    private BigDecimal rate2;
    private BigDecimal rate3;
    private BigDecimal tax;
    private BigDecimal nextTax;
    private Date nextTaxStartDate;

    @Size(max = 20)
    private String inventoryAttributeLabel1;

    @Size(max = 20)
    private String inventoryAttributeLabel2;

    @Size(max = 20)
    private String inventoryAttributeLabel3;

    @Size(max = 20)
    private String inventoryAttributeLabel4;

    @Size(max = 20)
    private String inventoryAttributeLabel5;

    @Size(max = 20)
    private String inventoryAttributeLabel6;

    @Size(max = 20)
    private String inventoryAttributeLabel7;

    @Size(max = 20)
    private String inventoryAttributeLabel8;

    @Size(max = 20)
    private String inventoryAttributeLabel9;

    @Size(max = 20)
    private String inventoryAttributeLabel10;

    @Size(max = 20)
    private String inventoryAttributeLabel11;

    @Size(max = 20)
    private String inventoryAttributeLabel12;

    @Size(max = 20)
    private String inventoryAttributeLabel13;

    @Size(max = 20)
    private String inventoryAttributeLabel14;

    @Size(max = 20)
    private String inventoryAttributeLabel15;

    @Size(max = 20)
    private String inventoryAttributeLabel16;

    @Size(max = 20)
    private String inventoryAttributeLabel17;

    @Size(max = 20)
    private String inventoryAttributeLabel18;

    @Size(max = 20)
    private String inventoryAttributeLabel19;

    @Size(max = 20)
    private String inventoryAttributeLabel20;

    @Size(max = 20)
    private String inventoryAttributeLabel21;

    @Size(max = 20)
    private String inventoryAttributeLabel22;

    @Size(max = 20)
    private String inventoryAttributeLabel23;

    @Size(max = 20)
    private String inventoryAttributeLabel24;

    @Size(max = 20)
    private String inventoryAttributeLabel25;

    @Size(max = 20)
    private String inventoryAttributeLabel26;

    @Size(max = 20)
    private String inventoryAttributeLabel27;

    @Size(max = 20)
    private String inventoryAttributeLabel28;

    @Size(max = 20)
    private String inventoryAttributeLabel29;

    @Size(max = 20)
    private String inventoryAttributeLabel30;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd1;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd2;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd3;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd4;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd5;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd6;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd7;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd8;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd9;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd10;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd11;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd12;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd13;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd14;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd15;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd16;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd17;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd18;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd19;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd20;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd21;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd22;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd23;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd24;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd25;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd26;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd27;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd28;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd29;

    @Min(0)
    @Max(1)
    private Long inventoryAttributeUseInd30;

    @Min(0)
    @Max(1)
    private Long mandatoryInd1;

    @Min(0)
    @Max(1)
    private Long mandatoryInd2;

    @Min(0)
    @Max(1)
    private Long mandatoryInd3;

    @Min(0)
    @Max(1)
    private Long mandatoryInd4;

    @Min(0)
    @Max(1)
    private Long mandatoryInd5;

    @Min(0)
    @Max(1)
    private Long mandatoryInd6;

    @Min(0)
    @Max(1)
    private Long mandatoryInd7;

    @Min(0)
    @Max(1)
    private Long mandatoryInd8;

    @Min(0)
    @Max(1)
    private Long mandatoryInd9;

    @Min(0)
    @Max(1)
    private Long mandatoryInd10;

    @Min(0)
    @Max(1)
    private Long mandatoryInd11;

    @Min(0)
    @Max(1)
    private Long mandatoryInd12;

    @Min(0)
    @Max(1)
    private Long mandatoryInd13;

    @Min(0)
    @Max(1)
    private Long mandatoryInd14;

    @Min(0)
    @Max(1)
    private Long mandatoryInd15;

    @Min(0)
    @Max(1)
    private Long mandatoryInd16;

    @Min(0)
    @Max(1)
    private Long mandatoryInd17;

    @Min(0)
    @Max(1)
    private Long mandatoryInd18;

    @Min(0)
    @Max(1)
    private Long mandatoryInd19;

    @Min(0)
    @Max(1)
    private Long mandatoryInd20;

    @Min(0)
    @Max(1)
    private Long mandatoryInd21;

    @Min(0)
    @Max(1)
    private Long mandatoryInd22;

    @Min(0)
    @Max(1)
    private Long mandatoryInd23;

    @Min(0)
    @Max(1)
    private Long mandatoryInd24;

    @Min(0)
    @Max(1)
    private Long mandatoryInd25;

    @Min(0)
    @Max(1)
    private Long mandatoryInd26;

    @Min(0)
    @Max(1)
    private Long mandatoryInd27;

    @Min(0)
    @Max(1)
    private Long mandatoryInd28;

    @Min(0)
    @Max(1)
    private Long mandatoryInd29;

    @Min(0)
    @Max(1)
    private Long mandatoryInd30;

    /** システムユーザーコードの取得
     * @return システムユーザーコード
     */
     @XmlElement(name = "systemUserCode")
    public String getSystemUserCode() {
        return systemUserCode;
    }
    /** システムユーザーコードの設定
     * @param systemUserCode システムユーザーコード
     */
    public void setSystemUserCode(String systemUserCode) {
        this.systemUserCode = systemUserCode;
    }
    /** システムユーザーネームの取得
     * @return システムユーザーネーム
     */
     @XmlElement(name = "systemUserName")
    public String getSystemUserName() {
        return systemUserName;
    }
    /** システムユーザーネームの設定
     * @param systemUserName システムユーザーネーム
     */
    public void setSystemUserName(String systemUserName) {
        this.systemUserName = systemUserName;
    }
    /** レート1の取得
     * @return レート1
     */
     @XmlElement(name = "rate1")
    public BigDecimal getRate1() {
        return rate1;
    }
    /** レート1の設定
     * @param rate1 レート1
     */
    public void setRate1(BigDecimal rate1) {
        this.rate1 = rate1;
    }
    /** レート2の取得
     * @return レート2
     */
     @XmlElement(name = "rate2")
    public BigDecimal getRate2() {
        return rate2;
    }
    /** レート2の設定
     * @param rate2 レート2
     */
    public void setRate2(BigDecimal rate2) {
        this.rate2 = rate2;
    }
    /** レート3の取得
     * @return レート3
     */
     @XmlElement(name = "rate3")
    public BigDecimal getRate3() {
        return rate3;
    }
    /** レート3の設定
     * @param rate3 レート3
     */
    public void setRate3(BigDecimal rate3) {
        this.rate3 = rate3;
    }
    /** 税の取得
     * @return 税
     */
     @XmlElement(name = "tax")
    public BigDecimal getTax() {
        return tax;
    }
    /** 税の設定
     * @param tax 税
     */
    public void setTax(BigDecimal tax) {
        this.tax = tax;
    }
    /** 次に設定する税の取得
     * @return 次に設定する税
     */
     @XmlElement(name = "nextTax")
    public BigDecimal getNextTax() {
        return nextTax;
    }
    /** 次に設定する税の設定
     * @param nextTax 次に設定する税
     */
    public void setNextTax(BigDecimal nextTax) {
        this.nextTax = nextTax;
    }
    /** 次に設定する税を開始する日にちの取得
     * @return 次に設定する税を開始する日にち
     */
     @XmlElement(name = "nextTaxStartDate")
    public Date getNextTaxStartDate() {
        return nextTaxStartDate;
    }
    /** 次に設定する税を開始する日にちの設定
     * @param nextTaxStartDate 次に設定する税を開始する日にち
     */
    public void setNextTaxStartDate(Date nextTaxStartDate) {
        this.nextTaxStartDate = nextTaxStartDate;
    }

    /** 在庫の属性
     * inventoryAttributeLabel1の取得
     * @return inventoryAttributeLabel1
     */
    @XmlElement(name = "inventoryAttributeLabel1")
    public String getInventoryAttributeLabel1() {
        return inventoryAttributeLabel1;
    }
    /** inventoryAttributeLabel1の設定
     * @param inventoryAttributeLabel1
     */
    public void setInventoryAttributeLabel1(String inventoryAttributeLabel1) {
        this.inventoryAttributeLabel1 = inventoryAttributeLabel1;
    }
    /** 在庫の属性
     * inventoryAttributeLabel2の取得
     * @return inventoryAttributeLabel2
     */
    @XmlElement(name = "inventoryAttributeLabel2")
    public String getInventoryAttributeLabel2() {
        return inventoryAttributeLabel2;
    }
    /** inventoryAttributeLabel2の設定
     * @param inventoryAttributeLabel2
     */
    public void setInventoryAttributeLabel2(String inventoryAttributeLabel2) {
        this.inventoryAttributeLabel2 = inventoryAttributeLabel2;
    }
    /** 在庫の属性
     * inventoryAttributeLabel3の取得
     * @return inventoryAttributeLabel3
     */
    @XmlElement(name = "inventoryAttributeLabel3")
    public String getInventoryAttributeLabel3() {
        return inventoryAttributeLabel3;
    }
    /**
     * inventoryAttributeLabel3の設定
     * @param inventoryAttributeLabel3
     */
    public void setInventoryAttributeLabel3(String inventoryAttributeLabel3) {
        this.inventoryAttributeLabel3 = inventoryAttributeLabel3;
    }
    /** 在庫の属性
     * inventoryAttributeLabel4の取得
     * @return inventoryAttributeLabel4
     */
    @XmlElement(name = "inventoryAttributeLabel4")
    public String getInventoryAttributeLabel4() {
        return inventoryAttributeLabel4;
    }
    /** inventoryAttributeLabel4の設定
     * @param inventoryAttributeLabel4
     */
    public void setInventoryAttributeLabel4(String inventoryAttributeLabel4) {
        this.inventoryAttributeLabel4 = inventoryAttributeLabel4;
    }
    /** 在庫の属性
     * inventoryAttributeLabel5の取得
     * @return inventoryAttributeLabel5
     */
    @XmlElement(name = "inventoryAttributeLabel5")
    public String getInventoryAttributeLabel5() {
        return inventoryAttributeLabel5;
    }
    /** inventoryAttributeLabel5の設定
     * @param inventoryAttributeLabel5
     */
    public void setInventoryAttributeLabel5(String inventoryAttributeLabel5) {
        this.inventoryAttributeLabel5 = inventoryAttributeLabel5;
    }
    /** 在庫の属性
     *  inventoryAttributeLabel6の取得
     * @return inventoryAttributeLabel6
     */
    @XmlElement(name = "inventoryAttributeLabel6")
    public String getInventoryAttributeLabel6() {
        return inventoryAttributeLabel6;
    }
    /** inventoryAttributeLabel6の設定
     * @param inventoryAttributeLabel6
     */
    public void setInventoryAttributeLabel6(String inventoryAttributeLabel6) {
        this.inventoryAttributeLabel6 = inventoryAttributeLabel6;
    }
    /** 在庫の属性
     *  inventoryAttributeLabel7の取得
     * @return inventoryAttributeLabel7
     */
    @XmlElement(name = "inventoryAttributeLabel7")
    public String getInventoryAttributeLabel7() {
        return inventoryAttributeLabel7;
    }
    /** inventoryAttributeLabel7の設定
     * @param inventoryAttributeLabel7
     */
    public void setInventoryAttributeLabel7(String inventoryAttributeLabel7) {
        this.inventoryAttributeLabel7 = inventoryAttributeLabel7;
    }
    /** 在庫の属性
     *  inventoryAttributeLabel8の取得
     * @return inventoryAttributeLabel8
     */
    @XmlElement(name = "inventoryAttributeLabel8")
    public String getInventoryAttributeLabel8() {
        return inventoryAttributeLabel8;
    }
    /** inventoryAttributeLabel8の設定
     * @param inventoryAttributeLabel8
     */
    public void setInventoryAttributeLabel8(String inventoryAttributeLabel8) {
        this.inventoryAttributeLabel8 = inventoryAttributeLabel8;
    }
    /** 在庫の属性
     *  inventoryAttributeLabel9の取得
     * @return inventoryAttributeLabel9
     */
    @XmlElement(name = "inventoryAttributeLabel9")
    public String getInventoryAttributeLabel9() {
        return inventoryAttributeLabel9;
    }
    /** inventoryAttributeLabel9の設定
     * @param inventoryAttributeLabel9
     */
    public void setInventoryAttributeLabel9(String inventoryAttributeLabel9) {
        this.inventoryAttributeLabel9 = inventoryAttributeLabel9;
    }
    /** 在庫の属性
     * inventoryAttributeLabel10の取得
     * @return inventoryAttributeLabel10
     */
    @XmlElement(name = "inventoryAttributeLabel10")
    public String getInventoryAttributeLabel10() {
        return inventoryAttributeLabel10;
    }
    /** inventoryAttributeLabel10の設定
     * @param inventoryAttributeLabel10
     */
    public void setInventoryAttributeLabel10(String inventoryAttributeLabel10) {
        this.inventoryAttributeLabel10 = inventoryAttributeLabel10;
    }
    /** 在庫の属性
     * inventoryAttributeLabel11の取得
     * @return inventoryAttributeLabel11
     */
    @XmlElement(name = "inventoryAttributeLabel11")
    public String getInventoryAttributeLabel11() {
        return inventoryAttributeLabel11;
    }
    /** inventoryAttributeLabel11の設定
     * @param inventoryAttributeLabel11
     */
    public void setInventoryAttributeLabel11(String inventoryAttributeLabel11) {
        this.inventoryAttributeLabel11 = inventoryAttributeLabel11;
    }
    /** 在庫の属性
     * inventoryAttributeLabel12の取得
     * @return inventoryAttributeLabel12
     */
    @XmlElement(name = "inventoryAttributeLabel12")
    public String getInventoryAttributeLabel12() {
        return inventoryAttributeLabel12;
    }
    /** inventoryAttributeLabel12の設定
     * @param inventoryAttributeLabel12
     */
    public void setInventoryAttributeLabel12(String inventoryAttributeLabel12) {
        this.inventoryAttributeLabel12 = inventoryAttributeLabel12;
    }
    /** 在庫の属性
     * inventoryAttributeLabel13の取得
     * @return inventoryAttributeLabel13
     */
    @XmlElement(name = "inventoryAttributeLabel13")
    public String getInventoryAttributeLabel13() {
        return inventoryAttributeLabel13;
    }
    /** inventoryAttributeLabel13の設定
     * @param inventoryAttributeLabel13
     */
    public void setInventoryAttributeLabel13(String inventoryAttributeLabel13) {
        this.inventoryAttributeLabel13 = inventoryAttributeLabel13;
    }
    /** 在庫の属性
     * inventoryAttributeLabel14の取得
     * @return inventoryAttributeLabel14
     */
    @XmlElement(name = "inventoryAttributeLabel14")
    public String getInventoryAttributeLabel14() {
        return inventoryAttributeLabel14;
    }
    /** inventoryAttributeLabel14の設定
     * @param inventoryAttributeLabel14
     */
    public void setInventoryAttributeLabel14(String inventoryAttributeLabel14) {
        this.inventoryAttributeLabel14 = inventoryAttributeLabel14;
    }
    /** 在庫の属性
     * inventoryAttributeLabel15の取得
     * @return inventoryAttributeLabel15
     */
    @XmlElement(name = "inventoryAttributeLabel15")
    public String getInventoryAttributeLabel15() {
        return inventoryAttributeLabel15;
    }
    /** inventoryAttributeLabel15の設定
     * @param inventoryAttributeLabel15
     */
    public void setInventoryAttributeLabel15(String inventoryAttributeLabel15) {
        this.inventoryAttributeLabel15 = inventoryAttributeLabel15;
    }
    /** 在庫の属性
     * inventoryAttributeLabel16の取得
     * @return inventoryAttributeLabel16
     */
    @XmlElement(name = "inventoryAttributeLabel16")
    public String getInventoryAttributeLabel16() {
        return inventoryAttributeLabel16;
    }
    /** inventoryAttributeLabel16の設定
     * @param inventoryAttributeLabel16
     */
    public void setInventoryAttributeLabel16(String inventoryAttributeLabel16) {
        this.inventoryAttributeLabel16 = inventoryAttributeLabel16;
    }
    /** 在庫の属性
     * inventoryAttributeLabel17の取得
     * @return inventoryAttributeLabel17
     */
    @XmlElement(name = "inventoryAttributeLabel17")
    public String getInventoryAttributeLabel17() {
        return inventoryAttributeLabel17;
    }
    /** inventoryAttributeLabel17の設定
     * @param inventoryAttributeLabel17
     */
    public void setInventoryAttributeLabel17(String inventoryAttributeLabel17) {
        this.inventoryAttributeLabel17 = inventoryAttributeLabel17;
    }
    /** 在庫の属性
     * inventoryAttributeLabel18の取得
     * @return inventoryAttributeLabel18
     */
    @XmlElement(name = "inventoryAttributeLabel18")
    public String getInventoryAttributeLabel18() {
        return inventoryAttributeLabel18;
    }
    /** inventoryAttributeLabel18の設定
     * @param inventoryAttributeLabel18
     */
    public void setInventoryAttributeLabel18(String inventoryAttributeLabel18) {
        this.inventoryAttributeLabel18 = inventoryAttributeLabel18;
    }
    /** 在庫の属性
     * inventoryAttributeLabel19の取得
     * @return inventoryAttributeLabel19
     */
    @XmlElement(name = "inventoryAttributeLabel19")
    public String getInventoryAttributeLabel19() {
        return inventoryAttributeLabel19;
    }
    /** inventoryAttributeLabel19の設定
     * @param inventoryAttributeLabel19
     */
    public void setInventoryAttributeLabel19(String inventoryAttributeLabel19) {
        this.inventoryAttributeLabel19 = inventoryAttributeLabel19;
    }
    /** 在庫の属性
     * inventoryAttributeLabel20の取得
     * @return inventoryAttributeLabel20
     */
    @XmlElement(name = "inventoryAttributeLabel20")
    public String getInventoryAttributeLabel20() {
        return inventoryAttributeLabel20;
    }
    /** inventoryAttributeLabel20の設定
     * @param inventoryAttributeLabel20
     */
    public void setInventoryAttributeLabel20(String inventoryAttributeLabel20) {
        this.inventoryAttributeLabel20 = inventoryAttributeLabel20;
    }
    /** 在庫の属性
     * inventoryAttributeLabel21の取得
     * @return inventoryAttributeLabel21
     */
    @XmlElement(name = "inventoryAttributeLabel21")
    public String getInventoryAttributeLabel21() {
        return inventoryAttributeLabel21;
    }
    /** inventoryAttributeLabel21の設定
     * @param inventoryAttributeLabel21
     */
    public void setInventoryAttributeLabel21(String inventoryAttributeLabel21) {
        this.inventoryAttributeLabel21 = inventoryAttributeLabel21;
    }
    /** 在庫の属性
     * inventoryAttributeLabel22の取得
     * @return inventoryAttributeLabel22
     */
    @XmlElement(name = "inventoryAttributeLabel22")
    public String getInventoryAttributeLabel22() {
        return inventoryAttributeLabel22;
    }
    /** inventoryAttributeLabel22の設定
     * @param inventoryAttributeLabel22
     */
    public void setInventoryAttributeLabel22(String inventoryAttributeLabel22) {
        this.inventoryAttributeLabel22 = inventoryAttributeLabel22;
    }
    /** 在庫の属性
     * inventoryAttributeLabel23の取得
     * @return inventoryAttributeLabel23
     */
    @XmlElement(name = "inventoryAttributeLabel23")
    public String getInventoryAttributeLabel23() {
        return inventoryAttributeLabel23;
    }
    /** inventoryAttributeLabel23の設定
     * @param inventoryAttributeLabel23
     */
    public void setInventoryAttributeLabel23(String inventoryAttributeLabel23) {
        this.inventoryAttributeLabel23 = inventoryAttributeLabel23;
    }
    /** 在庫の属性
     * inventoryAttributeLabel24の取得
     * @return inventoryAttributeLabel24
     */
    @XmlElement(name = "inventoryAttributeLabel24")
    public String getInventoryAttributeLabel24() {
        return inventoryAttributeLabel24;
    }
    /** inventoryAttributeLabel24の設定
     * @param inventoryAttributeLabel24
     */
    public void setInventoryAttributeLabel24(String inventoryAttributeLabel24) {
        this.inventoryAttributeLabel24 = inventoryAttributeLabel24;
    }
    /** 在庫の属性
     * inventoryAttributeLabel25の取得
     * @return inventoryAttributeLabel25
     */
    @XmlElement(name = "inventoryAttributeLabel25")
    public String getInventoryAttributeLabel25() {
        return inventoryAttributeLabel25;
    }
    /** inventoryAttributeLabel25の設定
     * @param inventoryAttributeLabel25
     */
    public void setInventoryAttributeLabel25(String inventoryAttributeLabel25) {
        this.inventoryAttributeLabel25 = inventoryAttributeLabel25;
    }
    /** 在庫の属性
     * inventoryAttributeLabel26の取得
     * @return inventoryAttributeLabel26
     */
    @XmlElement(name = "inventoryAttributeLabel26")
    public String getInventoryAttributeLabel26() {
        return inventoryAttributeLabel26;
    }
    /** inventoryAttributeLabel26の設定
     * @param inventoryAttributeLabel26
     */
    public void setInventoryAttributeLabel26(String inventoryAttributeLabel26) {
        this.inventoryAttributeLabel26 = inventoryAttributeLabel26;
    }
    /** 在庫の属性
     * inventoryAttributeLabel27の取得
     * @return inventoryAttributeLabel27
     */
    @XmlElement(name = "inventoryAttributeLabel27")
    public String getInventoryAttributeLabel27() {
        return inventoryAttributeLabel27;
    }
    /** inventoryAttributeLabel27の設定
     * @param inventoryAttributeLabel27
     */
    public void setInventoryAttributeLabel27(String inventoryAttributeLabel27) {
        this.inventoryAttributeLabel27 = inventoryAttributeLabel27;
    }
    /** 在庫の属性
     * inventoryAttributeLabel28の取得
     * @return inventoryAttributeLabel28
     */
    @XmlElement(name = "inventoryAttributeLabel28")
    public String getInventoryAttributeLabel28() {
        return inventoryAttributeLabel28;
    }
    /** inventoryAttributeLabel28の設定
     * @param inventoryAttributeLabel28
     */
    public void setInventoryAttributeLabel28(String inventoryAttributeLabel28) {
        this.inventoryAttributeLabel28 = inventoryAttributeLabel28;
    }
    /** 在庫の属性
     * inventoryAttributeLabel29の取得
     * @return inventoryAttributeLabel29
     */
    @XmlElement(name = "inventoryAttributeLabel29")
    public String getInventoryAttributeLabel29() {
        return inventoryAttributeLabel29;
    }
    /** inventoryAttributeLabel29の設定
     * @param inventoryAttributeLabel29
     */
    public void setInventoryAttributeLabel29(String inventoryAttributeLabel29) {
        this.inventoryAttributeLabel29 = inventoryAttributeLabel29;
    }
    /** 在庫の属性
     * inventoryAttributeLabel30の取得
     * @return inventoryAttributeLabel30
     */
    @XmlElement(name = "inventoryAttributeLabel30")
    public String getInventoryAttributeLabel30() {
        return inventoryAttributeLabel30;
    }
    /** inventoryAttributeLabel30の設定
     * @param inventoryAttributeLabel30
     */
    public void setInventoryAttributeLabel30(String inventoryAttributeLabel30) {
        this.inventoryAttributeLabel30 = inventoryAttributeLabel30;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd1の取得
     * @return inventoryAttributeUseInd1
     */
    @XmlElement(name = "inventoryAttributeUseInd1")
    public Long getInventoryAttributeUseInd1() {
        return inventoryAttributeUseInd1;
    }
    /** inventoryAttributeUseInd1の設定
     * @param inventoryAttributeUseInd1
     */
    public void setInventoryAttributeUseInd1(Long inventoryAttributeUseInd1) {
        this.inventoryAttributeUseInd1 = inventoryAttributeUseInd1;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd2の取得
     * @return inventoryAttributeUseInd2
     */
    @XmlElement(name = "inventoryAttributeUseInd2")
    public Long getInventoryAttributeUseInd2() {
        return inventoryAttributeUseInd2;
    }
    /** inventoryAttributeUseInd2の設定
     * @param inventoryAttributeUseInd2
     */
    public void setInventoryAttributeUseInd2(Long inventoryAttributeUseInd2) {
        this.inventoryAttributeUseInd2 = inventoryAttributeUseInd2;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd3の取得
     * @return inventoryAttributeUseInd3
     */
    @XmlElement(name = "inventoryAttributeUseInd3")
    public Long getInventoryAttributeUseInd3() {
        return inventoryAttributeUseInd3;
    }
    /** inventoryAttributeUseInd3の設定
     * @param inventoryAttributeUseInd3
     */
    public void setInventoryAttributeUseInd3(Long inventoryAttributeUseInd3) {
        this.inventoryAttributeUseInd3 = inventoryAttributeUseInd3;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd4の取得
     * @return inventoryAttributeUseInd4
     */
    @XmlElement(name = "inventoryAttributeUseInd4")
    public Long getInventoryAttributeUseInd4() {
        return inventoryAttributeUseInd4;
    }
    /** inventoryAttributeUseInd4の設定
     * @param inventoryAttributeUseInd4
     */
    public void setInventoryAttributeUseInd4(Long inventoryAttributeUseInd4) {
        this.inventoryAttributeUseInd4 = inventoryAttributeUseInd4;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd5の取得
     * @return inventoryAttributeUseInd5
     */
    @XmlElement(name = "inventoryAttributeUseInd5")
    public Long getInventoryAttributeUseInd5() {
        return inventoryAttributeUseInd5;
    }
    /** inventoryAttributeUseInd5の設定
     * @param inventoryAttributeUseInd5
     */
    public void setInventoryAttributeUseInd5(Long inventoryAttributeUseInd5) {
        this.inventoryAttributeUseInd5 = inventoryAttributeUseInd5;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd6の取得
     * @return inventoryAttributeUseInd6
     */
    @XmlElement(name = "inventoryAttributeUseInd6")
    public Long getInventoryAttributeUseInd6() {
        return inventoryAttributeUseInd6;
    }
    /** inventoryAttributeUseInd6の設定
     * @param inventoryAttributeUseInd6
     */
    public void setInventoryAttributeUseInd6(Long inventoryAttributeUseInd6) {
        this.inventoryAttributeUseInd6 = inventoryAttributeUseInd6;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd7の取得
     * @return inventoryAttributeUseInd7
     */
    @XmlElement(name = "inventoryAttributeUseInd7")
    public Long getInventoryAttributeUseInd7() {
        return inventoryAttributeUseInd7;
    }
    /** inventoryAttributeUseInd7の設定
     * @param inventoryAttributeUseInd7
     */
    public void setInventoryAttributeUseInd7(Long inventoryAttributeUseInd7) {
        this.inventoryAttributeUseInd7 = inventoryAttributeUseInd7;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd8の取得
     * @return inventoryAttributeUseInd8
     */
    @XmlElement(name = "inventoryAttributeUseInd8")
    public Long getInventoryAttributeUseInd8() {
        return inventoryAttributeUseInd8;
    }
    /** inventoryAttributeUseInd8の設定
     * @param inventoryAttributeUseInd8
     */
    public void setInventoryAttributeUseInd8(Long inventoryAttributeUseInd8) {
        this.inventoryAttributeUseInd8 = inventoryAttributeUseInd8;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd9の取得
     * @return inventoryAttributeUseInd9
     */
    @XmlElement(name = "inventoryAttributeUseInd9")
    public Long getInventoryAttributeUseInd9() {
        return inventoryAttributeUseInd9;
    }
    /** inventoryAttributeUseInd9の設定
     * @param inventoryAttributeUseInd9
     */
    public void setInventoryAttributeUseInd9(Long inventoryAttributeUseInd9) {
        this.inventoryAttributeUseInd9 = inventoryAttributeUseInd9;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd10の取得
     * @return inventoryAttributeUseInd10
     */
    @XmlElement(name = "inventoryAttributeUseInd10")
    public Long getInventoryAttributeUseInd10() {
        return inventoryAttributeUseInd10;
    }
    /** inventoryAttributeUseInd10の設定
     * @param inventoryAttributeUseInd10
     */
    public void setInventoryAttributeUseInd10(Long inventoryAttributeUseInd10) {
        this.inventoryAttributeUseInd10 = inventoryAttributeUseInd10;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd11の取得
     * @return inventoryAttributeUseInd11
     */
    @XmlElement(name = "inventoryAttributeUseInd11")
    public Long getInventoryAttributeUseInd11() {
        return inventoryAttributeUseInd11;
    }
    /** inventoryAttributeUseInd11の設定
     * @param inventoryAttributeUseInd11
     */
    public void setInventoryAttributeUseInd11(Long inventoryAttributeUseInd11) {
        this.inventoryAttributeUseInd11 = inventoryAttributeUseInd11;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd12の取得
     * @return inventoryAttributeUseInd12
     */
    @XmlElement(name = "inventoryAttributeUseInd12")
    public Long getInventoryAttributeUseInd12() {
        return inventoryAttributeUseInd12;
    }
    /** inventoryAttributeUseInd12の設定
     * @param inventoryAttributeUseInd12
     */
    public void setInventoryAttributeUseInd12(Long inventoryAttributeUseInd12) {
        this.inventoryAttributeUseInd12 = inventoryAttributeUseInd12;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd13の取得
     * @return inventoryAttributeUseInd13
     */
    @XmlElement(name = "inventoryAttributeUseInd13")
    public Long getInventoryAttributeUseInd13() {
        return inventoryAttributeUseInd13;
    }
    /** inventoryAttributeUseInd13の設定
     * @param inventoryAttributeUseInd13
     */
    public void setInventoryAttributeUseInd13(Long inventoryAttributeUseInd13) {
        this.inventoryAttributeUseInd13 = inventoryAttributeUseInd13;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd14の取得
     * @return inventoryAttributeUseInd14
     */
    @XmlElement(name = "inventoryAttributeUseInd14")
    public Long getInventoryAttributeUseInd14() {
        return inventoryAttributeUseInd14;
    }
    /** inventoryAttributeUseInd14の設定
     * @param inventoryAttributeUseInd14
     */
    public void setInventoryAttributeUseInd14(Long inventoryAttributeUseInd14) {
        this.inventoryAttributeUseInd14 = inventoryAttributeUseInd14;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd15の取得
     * @return inventoryAttributeUseInd15
     */
    @XmlElement(name = "inventoryAttributeUseInd15")
    public Long getInventoryAttributeUseInd15() {
        return inventoryAttributeUseInd15;
    }
    /** inventoryAttributeUseInd15の設定
     * @param inventoryAttributeUseInd15
     */
    public void setInventoryAttributeUseInd15(Long inventoryAttributeUseInd15) {
        this.inventoryAttributeUseInd15 = inventoryAttributeUseInd15;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd16の取得
     * @return inventoryAttributeUseInd16
     */
    @XmlElement(name = "inventoryAttributeUseInd16")
    public Long getInventoryAttributeUseInd16() {
        return inventoryAttributeUseInd16;
    }
    /** inventoryAttributeUseInd16の設定
     * @param inventoryAttributeUseInd16
     */
    public void setInventoryAttributeUseInd16(Long inventoryAttributeUseInd16) {
        this.inventoryAttributeUseInd16 = inventoryAttributeUseInd16;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd17の取得
     * @return inventoryAttributeUseInd17
     */
    @XmlElement(name = "inventoryAttributeUseInd17")
    public Long getInventoryAttributeUseInd17() {
        return inventoryAttributeUseInd17;
    }
    /** inventoryAttributeUseInd17の設定
     * @param inventoryAttributeUseInd17
     */
    public void setInventoryAttributeUseInd17(Long inventoryAttributeUseInd17) {
        this.inventoryAttributeUseInd17 = inventoryAttributeUseInd17;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd18の取得
     * @return inventoryAttributeUseInd18
     */
    @XmlElement(name = "inventoryAttributeUseInd18")
    public Long getInventoryAttributeUseInd18() {
        return inventoryAttributeUseInd18;
    }
    /** inventoryAttributeUseInd18の設定
     * @param inventoryAttributeUseInd18
     */
    public void setInventoryAttributeUseInd18(Long inventoryAttributeUseInd18) {
        this.inventoryAttributeUseInd18 = inventoryAttributeUseInd18;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd19の取得
     * @return inventoryAttributeUseInd19
     */
    @XmlElement(name = "inventoryAttributeUseInd19")
    public Long getInventoryAttributeUseInd19() {
        return inventoryAttributeUseInd19;
    }
    /** inventoryAttributeUseInd19の設定
     * @param inventoryAttributeUseInd19
     */
    public void setInventoryAttributeUseInd19(Long inventoryAttributeUseInd19) {
        this.inventoryAttributeUseInd19 = inventoryAttributeUseInd19;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd20の取得
     * @return inventoryAttributeUseInd20
     */
    @XmlElement(name = "inventoryAttributeUseInd20")
    public Long getInventoryAttributeUseInd20() {
        return inventoryAttributeUseInd20;
    }
    /** inventoryAttributeUseInd20の設定
     * @param inventoryAttributeUseInd20
     */
    public void setInventoryAttributeUseInd20(Long inventoryAttributeUseInd20) {
        this.inventoryAttributeUseInd20 = inventoryAttributeUseInd20;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd21の取得
     * @return inventoryAttributeUseInd21
     */
    @XmlElement(name = "inventoryAttributeUseInd21")
    public Long getInventoryAttributeUseInd21() {
        return inventoryAttributeUseInd21;
    }
    /** inventoryAttributeUseInd21の設定
     * @param inventoryAttributeUseInd21
     */
    public void setInventoryAttributeUseInd21(Long inventoryAttributeUseInd21) {
        this.inventoryAttributeUseInd21 = inventoryAttributeUseInd21;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd22の取得
     * @return inventoryAttributeUseInd22
     */
    @XmlElement(name = "inventoryAttributeUseInd22")
    public Long getInventoryAttributeUseInd22() {
        return inventoryAttributeUseInd22;
    }
    /** inventoryAttributeUseInd22の設定
     * @param inventoryAttributeUseInd22
     */
    public void setInventoryAttributeUseInd22(Long inventoryAttributeUseInd22) {
        this.inventoryAttributeUseInd22 = inventoryAttributeUseInd22;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd23の取得
     * @return inventoryAttributeUseInd23
     */
    @XmlElement(name = "inventoryAttributeUseInd23")
    public Long getInventoryAttributeUseInd23() {
        return inventoryAttributeUseInd23;
    }
    /** inventoryAttributeUseInd23の設定
     * @param inventoryAttributeUseInd23
     */
    public void setInventoryAttributeUseInd23(Long inventoryAttributeUseInd23) {
        this.inventoryAttributeUseInd23 = inventoryAttributeUseInd23;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd24の取得
     * @return inventoryAttributeUseInd24
     */
    @XmlElement(name = "inventoryAttributeUseInd24")
    public Long getInventoryAttributeUseInd24() {
        return inventoryAttributeUseInd24;
    }
    /** inventoryAttributeUseInd24の設定
     * @param inventoryAttributeUseInd24
     */
    public void setInventoryAttributeUseInd24(Long inventoryAttributeUseInd24) {
        this.inventoryAttributeUseInd24 = inventoryAttributeUseInd24;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd25の取得
     * @return inventoryAttributeUseInd25
     */
    @XmlElement(name = "inventoryAttributeUseInd25")
    public Long getInventoryAttributeUseInd25() {
        return inventoryAttributeUseInd25;
    }
    /** inventoryAttributeUseInd25の設定
     * @param inventoryAttributeUseInd25
     */
    public void setInventoryAttributeUseInd25(Long inventoryAttributeUseInd25) {
        this.inventoryAttributeUseInd25 = inventoryAttributeUseInd25;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd26の取得
     * @return inventoryAttributeUseInd26
     */
    @XmlElement(name = "inventoryAttributeUseInd26")
    public Long getInventoryAttributeUseInd26() {
        return inventoryAttributeUseInd26;
    }
    /** inventoryAttributeUseInd26の設定
     * @param inventoryAttributeUseInd26
     */
    public void setInventoryAttributeUseInd26(Long inventoryAttributeUseInd26) {
        this.inventoryAttributeUseInd26 = inventoryAttributeUseInd26;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd27の取得
     * @return inventoryAttributeUseInd27
     */
    @XmlElement(name = "inventoryAttributeUseInd27")
    public Long getInventoryAttributeUseInd27() {
        return inventoryAttributeUseInd27;
    }
    /** inventoryAttributeUseInd27の設定
     * @param inventoryAttributeUseInd27
     */
    public void setInventoryAttributeUseInd27(Long inventoryAttributeUseInd27) {
        this.inventoryAttributeUseInd27 = inventoryAttributeUseInd27;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd28の取得
     * @return inventoryAttributeUseInd28
     */
    @XmlElement(name = "inventoryAttributeUseInd28")
    public Long getInventoryAttributeUseInd28() {
        return inventoryAttributeUseInd28;
    }
    /** inventoryAttributeUseInd28の設定
     * @param inventoryAttributeUseInd28
     */
    public void setInventoryAttributeUseInd28(Long inventoryAttributeUseInd28) {
        this.inventoryAttributeUseInd28 = inventoryAttributeUseInd28;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd29の取得
     * @return inventoryAttributeUseInd29
     */
    @XmlElement(name = "inventoryAttributeUseInd29")
    public Long getInventoryAttributeUseInd29() {
        return inventoryAttributeUseInd29;
    }
    /** inventoryAttributeUseInd29の設定
     * @param inventoryAttributeUseInd29
     */
    public void setInventoryAttributeUseInd29(Long inventoryAttributeUseInd29) {
        this.inventoryAttributeUseInd29 = inventoryAttributeUseInd29;
    }
    /** 0:利用しない
     * inventoryAttributeUseInd30の取得
     * @return inventoryAttributeUseInd30
     */
    @XmlElement(name = "inventoryAttributeUseInd30")
    public Long getInventoryAttributeUseInd30() {
        return inventoryAttributeUseInd30;
    }
    /** inventoryAttributeUseInd30の設定
     * @param inventoryAttributeUseInd30
     */
    public void setInventoryAttributeUseInd30(Long inventoryAttributeUseInd30) {
        this.inventoryAttributeUseInd30 = inventoryAttributeUseInd30;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd1の取得
     * @return mandatoryInd1
     */
    @XmlElement(name = "mandatoryInd1")
    public Long getMandatoryInd1() {
        return mandatoryInd1;
    }
    /** mandatoryInd1の設定
     * @param mandatoryInd1
     */
    public void setMandatoryInd1(Long mandatoryInd1) {
        this.mandatoryInd1 = mandatoryInd1;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd2の取得
     * @return mandatoryInd2
     */
    @XmlElement(name = "mandatoryInd2")
    public Long getMandatoryInd2() {
        return mandatoryInd2;
    }
    /** mandatoryInd2の設定
     * @param mandatoryInd2
     */
    public void setMandatoryInd2(Long mandatoryInd2) {
        this.mandatoryInd2 = mandatoryInd2;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd3の取得
     * @return mandatoryInd3
     */
    @XmlElement(name = "mandatoryInd3")
    public Long getMandatoryInd3() {
        return mandatoryInd3;
    }
    /** mandatoryInd3の設定
     * @param mandatoryInd3
     */
    public void setMandatoryInd3(Long mandatoryInd3) {
        this.mandatoryInd3 = mandatoryInd3;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd4の取得
     * @return mandatoryInd4
     */
    @XmlElement(name = "mandatoryInd4")
    public Long getMandatoryInd4() {
        return mandatoryInd4;
    }
    /** mandatoryInd4の設定
     * @param mandatoryInd4
     */
    public void setMandatoryInd4(Long mandatoryInd4) {
        this.mandatoryInd4 = mandatoryInd4;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd5の取得
     * @return mandatoryInd5
     */
    @XmlElement(name = "mandatoryInd5")
    public Long getMandatoryInd5() {
        return mandatoryInd5;
    }
    /** mandatoryInd5の設定
     * @param mandatoryInd5
     */
    public void setMandatoryInd5(Long mandatoryInd5) {
        this.mandatoryInd5 = mandatoryInd5;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd6の取得
     * @return mandatoryInd6
     */
    @XmlElement(name = "mandatoryInd6")
    public Long getMandatoryInd6() {
        return mandatoryInd6;
    }
    /** mandatoryInd6の設定
     * @param mandatoryInd6
     */
    public void setMandatoryInd6(Long mandatoryInd6) {
        this.mandatoryInd6 = mandatoryInd6;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd7の取得
     * @return mandatoryInd7
     */
    @XmlElement(name = "mandatoryInd7")
    public Long getMandatoryInd7() {
        return mandatoryInd7;
    }
    /** mandatoryInd7の設定
     * @param mandatoryInd7
     */
    public void setMandatoryInd7(Long mandatoryInd7) {
        this.mandatoryInd7 = mandatoryInd7;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd8の取得
     * @return mandatoryInd8
     */
    @XmlElement(name = "mandatoryInd8")
    public Long getMandatoryInd8() {
        return mandatoryInd8;
    }
    /** mandatoryInd8の設定
     * @param mandatoryInd8
     */
    public void setMandatoryInd8(Long mandatoryInd8) {
        this.mandatoryInd8 = mandatoryInd8;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd9の取得
     * @return mandatoryInd9
     */
    @XmlElement(name = "mandatoryInd9")
    public Long getMandatoryInd9() {
        return mandatoryInd9;
    }
    /** mandatoryInd9の設定
     * @param mandatoryInd9
     */
    public void setMandatoryInd9(Long mandatoryInd9) {
        this.mandatoryInd9 = mandatoryInd9;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd10の取得
     * @return mandatoryInd10
     */
    @XmlElement(name = "mandatoryInd10")
    public Long getMandatoryInd10() {
        return mandatoryInd10;
    }
    /** mandatoryInd10の設定
     * @param mandatoryInd10
     */
    public void setMandatoryInd10(Long mandatoryInd10) {
        this.mandatoryInd10 = mandatoryInd10;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd11の取得
     * @return mandatoryInd11
     */
    @XmlElement(name = "mandatoryInd11")
    public Long getMandatoryInd11() {
        return mandatoryInd11;
    }
    /** mandatoryInd11の設定
     * @param mandatoryInd11
     */
    public void setMandatoryInd11(Long mandatoryInd11) {
        this.mandatoryInd11 = mandatoryInd11;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd12の取得
     * @return mandatoryInd12
     */
    @XmlElement(name = "mandatoryInd12")
    public Long getMandatoryInd12() {
        return mandatoryInd12;
    }
    /** mandatoryInd12の設定
     * @param mandatoryInd12
     */
    public void setMandatoryInd12(Long mandatoryInd12) {
        this.mandatoryInd12 = mandatoryInd12;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd13の取得
     * @return mandatoryInd13
     */
    @XmlElement(name = "mandatoryInd13")
    public Long getMandatoryInd13() {
        return mandatoryInd13;
    }
    /** mandatoryInd13の設定
     * @param mandatoryInd13
     */
    public void setMandatoryInd13(Long mandatoryInd13) {
        this.mandatoryInd13 = mandatoryInd13;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd14の取得
     * @return mandatoryInd14
     */
    @XmlElement(name = "mandatoryInd14")
    public Long getMandatoryInd14() {
        return mandatoryInd14;
    }
    /** mandatoryInd14の設定
     * @param mandatoryInd14
     */
    public void setMandatoryInd14(Long mandatoryInd14) {
        this.mandatoryInd14 = mandatoryInd14;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd15の取得
     * @return mandatoryInd15
     */
    @XmlElement(name = "mandatoryInd15")
    public Long getMandatoryInd15() {
        return mandatoryInd15;
    }
    /** mandatoryInd15の設定
     * @param mandatoryInd15
     */
    public void setMandatoryInd15(Long mandatoryInd15) {
        this.mandatoryInd15 = mandatoryInd15;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd16の取得
     * @return mandatoryInd16
     */
    @XmlElement(name = "mandatoryInd16")
    public Long getMandatoryInd16() {
        return mandatoryInd16;
    }
    /** mandatoryInd16の設定
     * @param mandatoryInd16
     */
    public void setMandatoryInd16(Long mandatoryInd16) {
        this.mandatoryInd16 = mandatoryInd16;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd17の取得
     * @return mandatoryInd17
     */
    @XmlElement(name = "mandatoryInd17")
    public Long getMandatoryInd17() {
        return mandatoryInd17;
    }
    /** mandatoryInd17の設定
     * @param mandatoryInd17
     */
    public void setMandatoryInd17(Long mandatoryInd17) {
        this.mandatoryInd17 = mandatoryInd17;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd18の取得
     * @return mandatoryInd18
     */
    @XmlElement(name = "mandatoryInd18")
    public Long getMandatoryInd18() {
        return mandatoryInd18;
    }
    /** mandatoryInd18の設定
     * @param mandatoryInd18
     */
    public void setMandatoryInd18(Long mandatoryInd18) {
        this.mandatoryInd18 = mandatoryInd18;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd19の取得
     * @return mandatoryInd19
     */
    @XmlElement(name = "mandatoryInd19")
    public Long getMandatoryInd19() {
            return mandatoryInd19;
    }
    /** mandatoryInd19の設定
     * @param mandatoryInd19
     */
    public void setMandatoryInd19(Long mandatoryInd19) {
        this.mandatoryInd19 = mandatoryInd19;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd20の取得
     * @return mandatoryInd20
     */
    @XmlElement(name = "mandatoryInd20")
    public Long getMandatoryInd20() {
        return mandatoryInd20;
    }
    /** mandatoryInd20の設定
     * @param mandatoryInd20
     */
    public void setMandatoryInd20(Long mandatoryInd20) {
        this.mandatoryInd20 = mandatoryInd20;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd21の取得
     * @return mandatoryInd21
     */
    @XmlElement(name = "mandatoryInd21")
    public Long getMandatoryInd21() {
        return mandatoryInd21;
    }
    /** mandatoryInd21の設定
     * @param mandatoryInd21
     */
    public void setMandatoryInd21(Long mandatoryInd21) {
        this.mandatoryInd21 = mandatoryInd21;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd22の取得
     * @return mandatoryInd22
     */
    @XmlElement(name = "mandatoryInd22")
    public Long getMandatoryInd22() {
        return mandatoryInd22;
    }
    /** mandatoryInd22の設定
     * @param mandatoryInd22
     */
    public void setMandatoryInd22(Long mandatoryInd22) {
        this.mandatoryInd22 = mandatoryInd22;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd23の取得
     * @return mandatoryInd23
     */
    @XmlElement(name = "mandatoryInd23")
    public Long getMandatoryInd23() {
        return mandatoryInd23;
    }
    /** mandatoryInd23の設定
     * @param mandatoryInd23
     */
    public void setMandatoryInd23(Long mandatoryInd23) {
        this.mandatoryInd23 = mandatoryInd23;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd24の取得
     * @return mandatoryInd24
     */
    @XmlElement(name = "mandatoryInd24")
    public Long getMandatoryInd24() {
        return mandatoryInd24;
    }
    /** mandatoryInd24の設定
     * @param mandatoryInd24
     */
    public void setMandatoryInd24(Long mandatoryInd24) {
        this.mandatoryInd24 = mandatoryInd24;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd25の取得
     * @return mandatoryInd25
     */
    @XmlElement(name = "mandatoryInd25")
    public Long getMandatoryInd25() {
        return mandatoryInd25;
    }
    /** mandatoryInd25の設定
     * @param mandatoryInd25
     */
    public void setMandatoryInd25(Long mandatoryInd25) {
        this.mandatoryInd25 = mandatoryInd25;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd26の取得
     * @return mandatoryInd26
     */
    @XmlElement(name = "mandatoryInd26")
    public Long getMandatoryInd26() {
        return mandatoryInd26;
    }
    /** mandatoryInd26の設定
     * @param mandatoryInd26
     */
    public void setMandatoryInd26(Long mandatoryInd26) {
        this.mandatoryInd26 = mandatoryInd26;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd27の取得
     * @return mandatoryInd27
     */
    @XmlElement(name = "mandatoryInd27")
    public Long getMandatoryInd27() {
        return mandatoryInd27;
    }
    /** mandatoryInd27の設定
     * @param mandatoryInd27
     */
    public void setMandatoryInd27(Long mandatoryInd27) {
        this.mandatoryInd27 = mandatoryInd27;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd28の取得
     * @return mandatoryInd28
     */
    @XmlElement(name = "mandatoryInd28")
    public Long getMandatoryInd28() {
        return mandatoryInd28;
    }
    /** mandatoryInd28の設定
     * @param mandatoryInd28
     */
    public void setMandatoryInd28(Long mandatoryInd28) {
        this.mandatoryInd28 = mandatoryInd28;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd29の取得
     * @return mandatoryInd29
     */
    @XmlElement(name = "mandatoryInd29")
    public Long getMandatoryInd29() {
        return mandatoryInd29;
    }
    /** mandatoryInd29の設定
     * @param mandatoryInd29
     */
    public void setMandatoryInd29(Long mandatoryInd29) {
        this.mandatoryInd29 = mandatoryInd29;
    }
    /** 0:入荷時に必須ではない
     * mandatoryInd30の取得
     * @return mandatoryInd30
     */
    @XmlElement(name = "mandatoryInd30")
    public Long getMandatoryInd30() {
        return mandatoryInd30;
    }
    /** mandatoryInd30の設定
     * @param mandatoryInd30
     */
    public void setMandatoryInd30(Long mandatoryInd30) {
        this.mandatoryInd30 = mandatoryInd30;
    }
}
