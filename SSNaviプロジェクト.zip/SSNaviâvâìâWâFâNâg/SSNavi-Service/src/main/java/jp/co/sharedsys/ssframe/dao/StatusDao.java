/**
 *
 */
package jp.co.sharedsys.ssframe.dao;


import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jp.co.sharedsys.ssframe.model.Status;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**ステータスマスタテーブル処理クラス
 * @author S.Nagai
 */
@Repository
public class StatusDao extends BaseDao<Status>{

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    public Status create(Status status) {
        getSqlSession().insert("status.create", status);
        return status;
    }

    public Status update(Status status) {
        getSqlSession().update("status.update", status);
        return status;
    }

    public void delete(String id) {
        getSqlSession().delete("status.delete", id);
    }

    public Status softDelete(Status status) {
        getSqlSession().update("status.softDelete", status);
        return status;
    }

    public List<Status> findAll() {
        return getSqlSession().selectList("status.findAll");
    }

    public Status findById(Status status) {
        return (Status) getSqlSession().selectOne("status.findById", status);
    }

    public List<Status> findByColumn(Status entity) {
        return getSqlSession().selectList("status.findByColumn", entity);
    }

    public List<Status> find(Status entity, String sqlId) {
        return getSqlSession().selectList(sqlId, entity);
    }

    @Override
    public List<Status> updateByColumn(Status searchCriteria, Status entity) {
        Map<String, Object> map = new HashMap<>();
        map.put("crt", searchCriteria);
        map.put("upd", entity);
        getSqlSession().update("status.updateByColumn", map);
        return findByColumn(entity);
    }

    @Override
    public void deleteByColumn(Status entity) {
        getSqlSession().delete("status.deleteByColumn", entity);
    }

    @Override
    public List<Status> softDeleteByColumn(Status entity) {
        getSqlSession().update("status.softDeleteByColumn",entity);
        return findByColumn(entity);
    }

    @Override
    public List<Status> insert(List<Status> entity, String sqlId) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<Status> insert(Status entity, String sqlId) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<Status> update(Status searchCriteria, Status entity, String sqlId) {
        // TODO Auto-generated method stub
        return null;
    }
}

