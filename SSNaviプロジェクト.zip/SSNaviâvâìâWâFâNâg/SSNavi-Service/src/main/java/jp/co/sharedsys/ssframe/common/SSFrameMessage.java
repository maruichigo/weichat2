package jp.co.sharedsys.ssframe.common;

/** システムメッセージ
 * @author T.Hirose
 *
 */

@SuppressWarnings("javadoc")
public interface SSFrameMessage {
    // システム
    /** システムエラー発生時のエラー */
    public static final String MSG_SYSTEM_ERROR = "システムエラーが発生しました。システム管理者にご連絡ください。";
    public static final String MSG_SYSTEM_ERROR_INVALID_PARAM = "パラメーター(ServiceInterfaceBean)が不正です。";
    public static final String MSG_SYSTEM_ERROR_INVALID_UserCd_IN_PARAM = "UserCdが不正です。";
    public static final String MSG_SYSTEM_ERROR_INVALID_USER_GROUP_IN_PARAM = "UserGroupCodeが不正です。";
    public static final String MSG_SYSTEM_ERROR_INVALID_MAKER_IN_PARAM = "MakerCodeが不正です。";
    public static final String MSG_SYSTEM_ERROR_NOT_EXIST_FUNCTION = "Functionが登録されていません。";
    public static final String MSG_NOT_EXIST_IN_MASTER_ERROR = "マスタに存在しません。";
    public static final String MSG_SYSTEM_ERROR_INVALID_INBOUND_TYPE_X_WAREHOUSE = "Invalid InboundTypeXWarehouse settings";
    public static final String MSG_NOT_EXIST_USER_GROUP_IN_MASTER_ERROR = "ユーザーグループコードが不正です。";
    public static final String MSG_REQUIRED_ERROR = "は必須項目です。値を入力してください。";
    public static final String MSG_UPLOAD_NOT_FILE = "アップロードファイルが存在しません。";
    public static final String MSG_UPLOAD_NOT_DATA = "アップロードファイルの中にデータが存在しません。";
    public static final String MSG_UPLOAD_NOT_VALID_DATA = "アップロードファイルから有効なデータを取得できません。";
    /** Login - UserCdが空 */
    public static final String MSG_USER_LOGIN_NOT_EXIST_USER_ID = "ユーザーIDを入力してください。";
    /** Login - パスワードが空 */
    public static final String MSG_USER_LOGIN_NOT_EXIST_PASSWD = "パスワードを入力してください。";
    /** Login - 新パスワードが空 */
    public static final String MSG_USER_LOGIN_NOT_EXIST_NEWPASSWD = "新パスワードを入力してください。";
    /** Login - 旧パスワードが空 */
    public static final String MSG_USER_LOGIN_NOT_EXIST_OLDPASSWD = "旧パスワードを入力してください。";
    /** Login - パスワードルール違反 */
    public static final String MSG_USER_LOGIN_INVALID_PASSWD = "パスワードは12文字以上で英数字記号が最低1文字ずつ必須です。";
    /** Login - 旧パスワードが違う */
    public static final String MSG_USER_LOGIN_WRONG_OLDPASSWD = "ユーザーIDと旧パスワードが一致しません。";
    /** Login - 新パスワード確認が空 */
    public static final String MSG_USER_LOGIN_NOT_EXIST_RETYPEPASSWD = "新パスワード(再入力)を入力してください。";
    /** Login - 新と確認の内容が違う */
    public static final String MSG_USER_LOGIN_WRONG_NEW_AND_RETYPE = "新パスワードと新パスワード(再入力)の内容が一致しません。";
    /** Login - ログイン失敗 */
    public static final String MSG_USER_LOGIN_WRONG_USER_ID_OR_PASSWD = "ユーザーIDまたはパスワードが違います。";
    /** Login - 利用権限が取得できないユーザー（ユーザーグループが無い、Functionの登録が無い etc ） */
    public static final String MSG_USER_LOGIN_FORBIDDEN = "システム利用権限が無いユーザーです。";
    /** Login - パスワード変更成功 */
    public static final String MSG_USER_LOGIN_PASSWD_CHANGE_SUCCSESS = "パスワードを変更しました。";
    /** Login - パスワードリセット時のルール違反 */
    public static final String MSG_USER_RESET_INVALID_PASSWD = "パスワードは半角英数字記号1文字以上で入力してください。";
}
