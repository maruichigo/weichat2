package jp.co.sharedsys.service.bus;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;


/** SSFrameのBUSクラス（ビジネス処理クラス）のインターフェース
 * @author sharedsys
 *
 */
public interface ISSFrameBus {
    /** 初期処理
     * @param serviceInterfaceBean リクエストパラメータ
     * @throws Exception
     */
    void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception;
	
    /**
     * 
     */
    public WebApplicationContext wac = null;

    /**
     * @param wac
     */
    public void setWebApplicationContext (WebApplicationContext wac);
	
    /** アノテーションによるヘッダー情報のチェック
     * @param serviceInterfaceBean リクエストパラメータ
     * @return　エラー内容
     * @throws Exception
     */
    String validateHeaderByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception;

   /** アノテーションによる明細情報のチェック
     * @param serviceInterfaceBean リクエストパラメータ
     * @return　エラー内容
     * @throws Exception
     */
    String validateDetailByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception;

    /**
     * @param type バリデーションファクトリーを決定するための文字列
     * @throws Exception
     */
    void setValidaterFactory() throws Exception;
	
    /** ヘッダー情報のチェック
     * @param serviceInterfaceBean リクエストパラメータ
     * @return　エラー内容
     * @throws Exception
     */
    String validateHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception;

    /** 明細情報のチェック
     * @param serviceInterfaceBean リクエストパラメータ
     * @return　エラー内容
     * @throws Exception
     */
    String validateDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception;
	
    /** ヘッダー情報の登録・更新・削除
     * @param serviceInterfaceBean リクエストパラメータ
     * @throws Exception
     */
    void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception;

    /** 明細情報の登録・更新・削除
     * @param serviceInterfaceBean リクエストパラメータ
     * @throws Exception
     */
    void saveDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception;

    /** 確定処理
     * トランザクションをNestして開始し、前段のsaveHeader,saveDetailのトランザクションとは
     * 独立して動作します。
     * @param serviceInterfaceBean リクエストパラメータ
     * @throws Exception
     */
    @Transactional(propagation=Propagation.NESTED, rollbackFor=Exception.class)
    void confirm(ServiceInterfaceBean serviceInterfaceBean) throws Exception;
        
    /**
     * 後処理
     * @param serviceInterfaceBean リクエストパラメータ
     * @return エラー内容
     * @throws Exception
     */
     String finalProc(ServiceInterfaceBean serviceInterfaceBean) throws Exception;
}
