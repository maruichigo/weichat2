package jp.co.sharedsys.service.bus.common;

import java.util.List;
import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.service.ServiceInterfaceBeanForMultiple;
import jp.co.sharedsys.service.bus.SSFrameBusBase;
import jp.co.sharedsys.service.mapper.IMapper;
import jp.co.sharedsys.service.mapper.MsUpFileDefMapper;
import jp.co.sharedsys.service.mapper.SsComUploadCheckResultMapper;
import jp.co.sharedsys.service.mapper.SsComUploadDefMapper;
import jp.co.sharedsys.service.mapper.SsComUploadRawDataMapper;
import jp.co.sharedsys.service.mapper.TrJokyoKanriShosaiUploadMapper;
import jp.co.sharedsys.service.mapper.TrJokyoKanriMapper; 
import jp.co.sharedsys.service.mapper.TrUpFrmDatMapper;
import jp.co.sharedsys.service.model.MsUpFileDef;
import jp.co.sharedsys.service.model.SsComUploadCheckResult;
import jp.co.sharedsys.service.model.SsComUploadDef;
import jp.co.sharedsys.service.model.SsComUploadRawData;
import jp.co.sharedsys.service.model.TrJokyoKanri; //本番テーブル用モデルクラス
import jp.co.sharedsys.service.model.TrJokyoKanriShosaiUpload; //本番テーブル用モデルクラス
import jp.co.sharedsys.service.model.TrUpFrmDat;
import org.springframework.util.StringUtils;

/** 
 * 共通アップロード ファイル受付
 */
@Component("SS_COM_UPLOAD_FILE_PROC_EX")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class SsComUploadFileProcBus extends SSFrameBusBase {
    protected final String SELECT_FILETYPE = "selectMaster";
    
//    @Autowired
//    private SsComUploadDefMapper uploadMapper; // 旧テーブル用
    @Autowired
    private MsUpFileDefMapper upFileMapper; // 新(本番)テーブル用
//    @Autowired
//    private SsComUploadRawDataMapper uploadRawDataMapper;// 旧テーブル用
    @Autowired
    private TrUpFrmDatMapper upFromDataMapper;//　新テーブル用
//    @Autowired
//    private SsComUploadCheckResultMapper uploadCheckResultMapper;// 旧テーブル用
    @Autowired
    private TrJokyoKanriShosaiUploadMapper statMngDetailMapper; // 新テーブル用
    @Autowired
    private TrJokyoKanriMapper statMngMapper;// 共通アップロードの件数表示領域用(新テーブル用)

    private IMapper mapForTarget(String target) {
        IMapper mapper =(IMapper)this.getWebApplicationContext().getBean(target);
        if (mapper != null) {
            return mapper;
        }
        throw new UnsupportedOperationException("unsupported table");
    }
    
    private IMapper targetMapper;
    
    private Map<String, Object> params = null;
//    private SsComUploadDef targetDef = null; // 旧テーブル用
    private MsUpFileDef targetDef = null; // 新(本番)テーブル用
    private Long yomikomiId = null;
    
    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        super.init(serviceInterfaceBean);
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
    }
    
    @Override
    public String validateHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        ServiceInterfaceBeanForMultiple srvBean = (ServiceInterfaceBeanForMultiple)serviceInterfaceBean;
        Map<String, InputStream> streams = srvBean.getUploadFiles();
        if (streams == null || streams.isEmpty()) {
            return "ファイルが指定されていません。";
        }
        return "";
    }
	
    @Override
    public String validateDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public String validateHeaderByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public String validateDetailByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    /** 
     * 検索
     * @param serviceInterfaceBean リクエストパラメータ
     * @throws Exception
     */
    @Override
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
//        // 旧テーブル用
//        SsComUploadDef crt = new SsComUploadDef();
//        crt.setFileName((String)params.get(SELECT_FILETYPE));
//        List<SsComUploadDef> def =  uploadMapper.findByColumn(crt);
        
        // 新(本番)テーブル用
        MsUpFileDef upFile = new MsUpFileDef();
//        upFile.setUploadKinoCd((String)params.get(SELECT_FILETYPE));// とりあえず、fileName→UploadKinoCdに置換(仮)
        upFile.setUploadKinoCd((String)params.get(SELECT_FILETYPE));
        List<MsUpFileDef> def = upFileMapper.findByColumn(upFile);
        
        targetDef = def.get(0);
        
        List<Map> result = null;

//        String dsTmpSave = targetDef.getDsFileRead(); // 旧テーブル用
        String readDsUrl = targetDef.getFileYomikomiyoDsScriptUrl(); //新(本番)テーブル用

        ServiceInterfaceBeanForMultiple srvBean = (ServiceInterfaceBeanForMultiple)serviceInterfaceBean;
        Map<String, InputStream> streams = srvBean.getUploadFiles();
            for (Iterator<String> ite = streams.keySet().iterator(); ite.hasNext();) {
                String fileName = ite.next();
                // ファイルを渡して読込をするDSスクリプトの実行
                // TODO DataSpider側で行う処理
                //      対象ファイル、更新/スキップを受け取り、対象データのテーブルと照合し、その結果をワークテーブル、チェック結果テーブル、件数テーブル、元データテーブルに保存する
                //      読込IDをDataSpiderの結果からもらう
                yomikomiId = 1L; // 何に置換するか？
            }
        // bean内ファイルはクリア
        srvBean.setUploadFiles(null);
    }

    @Override
    public void saveDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }

    @Override
    public void setValidaterFactory() throws Exception {
    }

    @Override
    public void confirm(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        // 行Name,行表示名を取得(アップロードデータの1,2行目に記載されていることが前提)
        // SS_COM_UPLOAD_ROW_DATA(共通アップロード元データテーブルより取得)
        
        // 旧テーブル用
//        SsComUploadRawData crt = new SsComUploadRawData();
//        crt.setYomikomiId(this.yomikomiId);
        
        // 新テーブル用
        TrUpFrmDat upFrmDat = new TrUpFrmDat();
        upFrmDat.setYomikomiId(this.yomikomiId);
        
//        crt.setUploadDefId(targetDef.getId());// 旧テーブル用
//        upFrmDat.setUploadDefId(Long.parseLong(targetDef.getUploadKinoCd()));// 新テーブル用
        
//        crt.setUserCd(serviceInterfaceBean.getUserCd());// 旧テーブル用
//        upFrmDat.setUserCd(serviceInterfaceBean.getUserCd()); // 新テーブル用
        
        // 旧テーブル用
//        List<SsComUploadRawData> headerLine = uploadRawDataMapper.findLineInfo(crt);
//        if (headerLine == null || headerLine.isEmpty() || StringUtils.isEmpty(headerLine.get(0).getData())) {
//            serviceInterfaceBean.setMessage("アップロード登録データが存在しません。");
//            return;
//        }
        
        // 新テーブル用
        List<TrUpFrmDat> headerLine = upFromDataMapper.findLineInfo(upFrmDat);
        if (headerLine == null || headerLine.isEmpty() || StringUtils.isEmpty(headerLine.get(0).getGyoNaiyo())) {
            serviceInterfaceBean.setMessage("アップロード登録データが存在しません。");
            return;
        }
        
        //　共通アップロード件数取得処理
        TrJokyoKanri tsm = new TrJokyoKanri();
        //tsm.setEdiSetteiId("100"); // 仮値
        List<TrJokyoKanri> upldStatList = statMngMapper.findStatusInfo(tsm);
        if (upldStatList == null || upldStatList.isEmpty()) {
            serviceInterfaceBean.setMessage("アップロード件数データが存在しません。");
            return;
        }
//        List<String> upldStatsKeys = Arrays.asList(upldStatList.get(0).toString());
//        List<String> upldStatsVals = Arrays.asList(upldStatList.get(1).toString());

        List<String> upldStatsVals = new ArrayList<>();
        upldStatsVals.add(upldStatList.get(0).getShoriRecordKensu().toString());
        upldStatsVals.add(upldStatList.get(0).getOkKensu().toString());
        upldStatsVals.add(upldStatList.get(0).getYoushuseiKensu().toString());
        upldStatsVals.add(upldStatList.get(0).getNgKensu().toString());
        upldStatsVals.add(upldStatList.get(0).getSkipKensu().toString());

        List<String> upldStatsKeys = new ArrayList<>();
        upldStatsKeys.add("ShoriRecordKensu");
        upldStatsKeys.add("OkKensu");
        upldStatsKeys.add("YoushuseiKensu");
        upldStatsKeys.add("NgKensu");
        upldStatsKeys.add("SkipKensu");
        
        Map<String, String> upldStatsMap = new LinkedHashMap<>();
        for (int i = 0; i < upldStatsKeys.size(); i++){
            upldStatsMap.put(upldStatsKeys.get(i), upldStatsVals.get(i));
        } 
        
        List<Map> result = new ArrayList<>();
        
//        List<String> columnKeys = Arrays.asList(headerLine.get(0).getData().split(","));
//        List<String> columnNames = Arrays.asList(headerLine.get(1).getData().split(","));
        
        List<String> columnKeys = new ArrayList<>();
        List<String> columnNames = new ArrayList<>();
        if(targetDef.getFileHeaderGyoUmu().equals("0")){
            // ヘッダーなし
            int headerSize = Arrays.asList(headerLine.get(0).getGyoNaiyo().split(",")).size();
            for (int i = 0; i < headerSize; i++) {               
                columnKeys.add("val" + (i + 1) + "_headerOff");
                columnNames.add("列" + (i + 1));
            }
        } else {
            // ヘッダーあり
//            columnKeys = Arrays.asList(headerLine.get(0).getGyoNaiyo().split(","));
//            columnNames = Arrays.asList(headerLine.get(1).getGyoNaiyo().split(","));

            int headerSize = Arrays.asList(headerLine.get(0).getGyoNaiyo().split(",")).size();
            for (int i = 0; i < headerSize; i++) {               
                columnKeys.add("val" + (i + 1) + "_headerOn");
            }
            columnNames = Arrays.asList(headerLine.get(0).getGyoNaiyo().split(","));
        }
        
        Map<String, String> columnNameLine = new LinkedHashMap<>();
        for (int i = 0; i < columnKeys.size(); i++) {
            columnNameLine.put(columnKeys.get(i), columnNames.get(i));
        }
        
//        targetMapper = this.mapForTarget(targetDef.getTmpTableName()); // 旧テーブル用
        targetMapper = this.mapForTarget(targetDef.getIchijiHozonyoWorkTableMei()); // 新テーブル用
        if (targetMapper != null) {
            result = targetMapper.findToMap(params);
        }
        
        if (result != null) {
//            // 旧テーブル用
//            // チェック結果を検索、付与する
//            SsComUploadCheckResult ckCrt = new SsComUploadCheckResult();
//            ckCrt.setYomikomiId(yomikomiId);
////            ckCrt.setUploadDefId(targetDef.getId()); // 旧テーブル用
//            ckCrt.setUploadDefId(Long.parseLong(targetDef.getUploadKinoCd())); // 新テーブル用
//            String err_msg = "";
//            String srr_col_name = "";
//            for (int i = 0; i < result.size(); i++) {
//                Map m = result.get(i);
//                ckCrt.setLineNo(i);
//                List<SsComUploadCheckResult> checkResult = uploadCheckResultMapper.findByColumn(ckCrt);
//                if (checkResult != null && !checkResult.isEmpty()) {
//                    
//                    for (SsComUploadCheckResult ck : checkResult) {
//                        if (m.containsKey(ck.getColumnName())) {
//                            srr_col_name = ck.getColumnName();
//                            err_msg = err_msg + ck.getMessage() + "<br/>";
//                        }  
//                    }
//                    
//                    m.put("ROWERR", "true");
//                    m.put(srr_col_name + "_ISERR", "true");
//                    m.put(srr_col_name + "_ERRDESC", err_msg);
//                //    m.put(ck.getColumnName() + "_ISERR", "true");
//                //    m.put(ck.getColumnName() + "_ERRDESC", ck.getMessage());
//                }
//                
//            }
            
            // 各レコードに状態/登録カラム区分を付与
            upFrmDat.setYomikomiId(yomikomiId);
//            List<TrUpFrmDat> recordGroup = upFromDataMapper.findByColumn(upFrmDat);
            for (int i = 0; i < result.size(); i++) {
                Map m = result.get(i);
                upFrmDat.setGyoBango(i + 3);//ヘッダー部表示行を飛ばして取得
//                List<TrJokyoKanriShosaiUpload> checkResult = statMngDetailMapper.findByColumn(statMngDtl);
                List<TrUpFrmDat> upRecordGroup = upFromDataMapper.findByColumn(upFrmDat);
                if (upRecordGroup != null && !upRecordGroup.isEmpty()) {
                    m.put("TOROKU_STATUS", upRecordGroup.get(0).getJotaiKubun());
                    m.put("TOROKU_KUBUN", upRecordGroup.get(0).getTorokuKubun());
                //    m.put(ck.getColumnName() + "_ISERR", "true");
                //    m.put(ck.getColumnName() + "_ERRDESC", ck.getMessage());
                }
                
            }


            // 新テーブル用
            // チェック結果を検索、付与する
//            SsComUploadCheckResult ckCrt = new SsComUploadCheckResult();
            TrJokyoKanriShosaiUpload statMngDtl = new TrJokyoKanriShosaiUpload();
            
//            ckCrt.setYomikomiId(yomikomiId);
            statMngDtl.setScriptId(String.valueOf(yomikomiId));
            
//            ckCrt.setUploadDefId(targetDef.getId()); // 旧テーブル用
//            statMngDtl.setUploadDefId(Long.parseLong(targetDef.getUploadKinoCd())); // 新テーブル用
            String err_msg = "";
            String srr_col_name = "";
            for (int i = 0; i < result.size(); i++) {
                Map m = result.get(i);
//                ckCrt.setLineNo(i);
                statMngDtl.setErrorHasseiGyo(i);//0から開始している
//                List<SsComUploadCheckResult> checkResult = uploadCheckResultMapper.findByColumn(ckCrt);
                List<TrJokyoKanriShosaiUpload> checkResult = statMngDetailMapper.findByColumn(statMngDtl);
                if (checkResult != null && !checkResult.isEmpty()) {
                    
                    for (TrJokyoKanriShosaiUpload ck : checkResult) {
                        if (m.containsKey(ck.getErrorHasseiColumn())) {
                            srr_col_name = ck.getErrorHasseiColumn();
//                            err_msg = err_msg + ck.getMessageBun()+ "<br/>";
                            err_msg = ck.getMessageBun()+ "<br/>";
                        }  
                    }
                    
                    if (checkResult.get(0).getLogLevel().equals("error")) {
                        // エラー項目の場合
                    m.put("ROWERR", "true");
                    m.put(srr_col_name + "_ISERR", "true");
                    m.put(srr_col_name + "_ERRDESC", err_msg);
                //    m.put(ck.getColumnName() + "_ISERR", "true");
                //    m.put(ck.getColumnName() + "_ERRDESC", ck.getMessage());
                    } else {
                        //　要修正項目の場合
                        m.put("ROWWARN", "true");
                        m.put(srr_col_name + "_ISWARN", "true");
                        m.put(srr_col_name + "_WARNDESC", err_msg);
                    //    m.put(ck.getColumnName() + "_ISERR", "true");
                    //    m.put(ck.getColumnName() + "_ERRDESC", ck.getMessage());
                }
                
            }
                
            }


            result.add(0, columnNameLine);
            result.add(result.size(), upldStatsMap);
            // TODO 対象レコードのマスタ存在有無をresultに付与
//            private boolean isExistRecord = false;
//            if (isExistRecord) {
//                
//            }
            // TODO 対象レコードの削除フラグON/OFFをresultに付与
            
            
            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        }
        serviceInterfaceBean.setMessage("共通アップロード 一時保存データ検索に成功しました");
    }
        
    @Override
    public String finalProc(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }            
}
