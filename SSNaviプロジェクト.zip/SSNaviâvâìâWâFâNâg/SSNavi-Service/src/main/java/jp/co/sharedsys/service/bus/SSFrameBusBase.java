package jp.co.sharedsys.service.bus;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import javax.validation.groups.Default;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.service.SSFrameBase;
import jp.co.sharedsys.ssframe.common.SSFrameMessage;
import jp.co.sharedsys.ssframe.dao.Dao;

import jp.co.sharedsys.ssframe.model.Status;
import jp.co.sharedsys.ssframe.model.SystemMaster;
import jp.co.sharedsys.service.constraintannotation.PrimaryKey;

/**
 * SSFrameのBUSクラス（ビジネス処理クラス）の基底クラス
 * 
 * @author sharedsys
 *
 */
@Component("ssFrameBusBase")
@Scope(value = WebApplicationContext.SCOPE_REQUEST)
public abstract class SSFrameBusBase extends SSFrameBase implements ISSFrameBus {

    /**
     * @return WebApplicationContext
     */
    public WebApplicationContext getWebApplicationContext(){
            return super.wac;
    }

    @Override
    public void setWebApplicationContext(WebApplicationContext wac){
        super.wac = wac;
    }
	
    // Dao定義
    @Autowired(required = true)
    @Resource(shareable = true)
    protected Dao<SystemMaster> systemDao;

    @Autowired(required = true)
    @Resource(shareable = true)
    protected Dao<Status> statusDao;

    @Autowired(required=true)
    @Resource(shareable=true)
    protected PlatformTransactionManager transactionManager;

    // ログインユーザーID
    protected String UserCd = null;
    // メーカーコード
    //	protected List<String> makerCode = null;
    // ログインユーザーグループ
    // protected List<UserGroup> userGroup = null;
    // システムマスタ
    private static SystemMaster systemMaster;

    /**
     * 初期処理
     * 
     * @param serviceInterfaceBean
     *            リクエストパラメータ
     * @throws Exception
     */
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        UserCd = serviceInterfaceBean.getUserCd();
        //makerCode = serviceInterfaceBean.getMakerCode();
/*		List<UserGroup> userGroups = ((UserGroupDao)userGroupDao).findByGroups(serviceInterfaceBean.getUserGroupCode());
		if (userGroups == null || userGroups.size() == 0) {
            StringBuffer message = new StringBuffer();
            message.append(
                SSFrameMessage.MSG_NOT_EXIST_USER_GROUP_IN_MASTER_ERROR)
			.append("[")
			.append(serviceInterfaceBean.getUserGroupCode())
			.append("]");
			throw new Exception(message.toString());
		} else {
            userGroup = userGroups;
		}
  */
	}

    /**
     * 
     */
    public SSFrameBusBase() {
	SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
    }

    /**
     * 　アノテーションによるチェック処理の実行
     * 
     * @param entity
     *            チェック対象のモデル
     * @return エラー内容
     */
    protected <T> String validateByAnnotation(T entity) {
	StringBuffer msgBuf = new StringBuffer();

	ValidatorFactory vf = Validation.buildDefaultValidatorFactory();
	Validator v = vf.getValidator();
	for (ConstraintViolation<T> cv : v.validate(entity,Default.class)) {
            // validationで出力されたメッセージを取得しappendする
            msgBuf.append(cv.getMessage());
	}
	return msgBuf.toString();
    }
	
    /** アノテーションによるチェック処理（Default以外のチェック処理）
     * @param entity チェック対象モデル
     * @param validatioTypeClass チェック処理のタイプ
     * @return エラー内容
     */
    protected <T> String validateByAnnotation(T entity, Class<?> validatioTypeClass) {
        StringBuffer msgBuf = new StringBuffer();
		
	ValidatorFactory vf = Validation.buildDefaultValidatorFactory();
	Validator v = vf.getValidator();
	for (ConstraintViolation<T> cv : v.validate(entity,validatioTypeClass)) {
            // validationで出力されたメッセージを取得しappendする
            msgBuf.append(cv.getMessage());
	}
	return msgBuf.toString();
    }

    /**
     * システムマスタの取得
     * 
     * @return
     * @throws Exception
     */
    protected SystemMaster getSystemMaster() throws Exception {
	if (systemMaster == null) {
            // システムマスタの検索
            List<SystemMaster> systemMasters = systemDao.findAll();
            // 検索結果の１行目を利用 ※システムマスタには１行しかレコードをもたない
            systemMaster = systemMasters.get(0);
            // 消費税率管理
            taxManage(systemMaster);
	}
	return systemMaster;
    }

    /**
     * 消費税率管理
     * 
     * @param systemMaster
     *            システムマスタ
     * @throws Exception
     */
    private void taxManage(SystemMaster systemMaster) throws Exception {
	Date today = new Date();
	try {
            // 新消費税率の適用チェック
            // 新消費税率の適用開始日と税率がセットされており、適用日開始日時を過ぎていた場合、新消費税率を
            // 適用し、システムマスタの更新する。
            if (systemMaster.getNextTaxStartDate() != null
                    && systemMaster.getNextTax() != null
                    && systemMaster.getNextTaxStartDate().compareTo(today) <= 0) {
                systemMaster.setTax(systemMaster.getNextTax());
                systemMaster.setNextTax(new BigDecimal(0));
                systemMaster.setNextTaxStartDate(null);
                systemDao.update(systemMaster);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * ステタース表示名の取得
     * 
     * @param statusType
     *            ステータス種別
     * @param statusCode
     *            ステータスコード
     * @return ステータス表示名
     */
    protected String getStatusName(String statusType, String statusCode) {
        Status searchCriteria = new Status();
        searchCriteria.setStatusType(statusType);
        searchCriteria.setStatusCode(statusCode);
        
        return statusDao.findById(searchCriteria).getDescription();
    }
    
    protected List<String> checkPrimaryAnnotation(Object obj) throws IllegalArgumentException, IllegalAccessException{
        List<String> result = new ArrayList<>();
        if(obj == null){
           return result;
        }
        Field[] fieldList = obj.getClass().getDeclaredFields();

        for (Field f: fieldList) {
            f.setAccessible(true);
            String name     = f.getName();
            Object fieldObj = f.get(obj);

            if(f.getAnnotation(PrimaryKey.class) != null){
                PrimaryKey element = f.getAnnotation(PrimaryKey.class);
                result.add(element.columnName());
            }
        }
        return result;
    }    
}
