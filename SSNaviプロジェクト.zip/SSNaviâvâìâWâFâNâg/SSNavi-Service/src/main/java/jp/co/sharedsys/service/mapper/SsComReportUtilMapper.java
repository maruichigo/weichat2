package jp.co.sharedsys.service.mapper;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

/**
 * DBに定義されているSQLを実行するための汎用Mapper
 * @author sharedsys
 */
@Component("ss_com_report_util")
public interface SsComReportUtilMapper {

    @Select("${sql}")
    Map<String, Object> find(@Param("sql") String sql, @Param("id") Integer id);

    @Select("${sql}")
    List<LinkedHashMap<String, Object>> list(@Param("sql") String sql, @Param("params") Map<String, Object> params);

//    @SelectProvider(type=ReportSelectProvider.class, method="toSelect")
//    public int select(@Param("table") String table, @Param("data") Object... data);
//
//    static class ReportSelectProvider extends SQL {
//        public String toSelect(Map<String, Object> params) {
//            SELECT((String)params.get("table"));
//            Object[] data = (Object[]) params.get("data");
//            for (int i=0; i<data.length -1; i+=2) {
//                VALUES((String)data[i], "#{data[" + (i+1) + "]}");
//            }
//            return toString();
//        }
//    }
}
