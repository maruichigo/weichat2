/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.sharedsys.service.bus.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.exception.SystemException;
import jp.co.sharedsys.common.methods.SSCommonUtil;
import jp.co.sharedsys.service.bus.SSFrameBusBase;
import jp.co.sharedsys.service.mapper.IMapper;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
/** 
 * 共通メンテナンス用データ取得
 */
@Component("SS_COM_MAINT_DELETE")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class SsComMaintDeleteBus  extends SSFrameBusBase {
    protected final String TABLE_NAME = "TABLE_NAME";
    
    private IMapper mapForTarget(String target) {
        IMapper mapper =(IMapper)this.getWebApplicationContext().getBean(target);
        if (mapper != null) {
            return mapper;
        }
        throw new UnsupportedOperationException("unsupported table");
    }
    private IMapper targetMapper;
    
    private Map<String, Object> params = null;
    private List<Map<String, Object>> inputParams = null;
    
    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
	super.init(serviceInterfaceBean);
	ObjectMapper mapper = new ObjectMapper();
	params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
        for (Iterator<String> ite = params.keySet().iterator();ite.hasNext();) {
            String key = ite.next();
            if (TABLE_NAME.equals(key)) {
                targetMapper = this.mapForTarget((String) params.get(key));
            } else {
                inputParams = (List)params.get(key);
            }
        }
    }
    
    @Override
    public String validateHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
	return "";
    }
	
    @Override
    public String validateDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
	return "";
    }

    @Override
    public String validateHeaderByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
	return "";
    };

    @Override
    public String validateDetailByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
	return "";
    };

    @Override
    /** 
     * 検索
     * @param serviceInterfaceBean リクエストパラメータ
     * @throws Exception
     */
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        List<Map> result = null;
        
        List<Map> chgList = new ArrayList<>();
        for (Map input : inputParams) {
            List keys = new ArrayList(input.keySet());
            Map<String, Object> chgMap = new LinkedHashMap<>();
            for (Iterator<String> ite = keys.iterator(); ite.hasNext();) {
                String key = ite.next();
                chgMap.put(SSCommonUtil.camelize(key), input.get(key));
            }
            chgList.add(chgMap);
        }

        for (Map input : chgList) {
            input.put("UserCd", serviceInterfaceBean.getUserCd());
            if (input.get("newrow") != null && Boolean.valueOf((String)input.get("newrow"))) {
                targetMapper.insert(input);
            } else {
                List<Map> check = targetMapper.findById(input);
                if (check != null && !check.isEmpty()) {
                    targetMapper.softDelete(input);
                } else {
                    throw new SystemException("更新対象のキーが存在しませんでした。");
                }
            }
        }
        serviceInterfaceBean.setMessage("データの登録・更新に成功しました");
    }

    @Override
    public void saveDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }

    @Override
    public void setValidaterFactory() throws Exception {
    }
    
    @Override
    public void confirm(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }    

    @Override
    public String finalProc(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }
}

