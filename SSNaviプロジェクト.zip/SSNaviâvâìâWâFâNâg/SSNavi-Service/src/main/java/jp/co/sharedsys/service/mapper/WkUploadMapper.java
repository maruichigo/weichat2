package jp.co.sharedsys.service.mapper;

import java.util.Map;
import org.springframework.stereotype.Component;

/**
 *
 * @author sharedsys
 */
@Component("WK_UPLOAD")
public interface WkUploadMapper extends IMapper {
    public void update(Map input);
}
