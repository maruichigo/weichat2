package jp.co.sharedsys.service.config;

import javax.ws.rs.ApplicationPath;
import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.stereotype.Component;

/**
 *
 * @author sharedsys
 */
@Component
@ApplicationPath("/resources")
public class JerseyConfig extends ResourceConfig {

    public JerseyConfig() {
        packages("jp.co.sharedsys.service");
        register(MultiPartFeature.class);
    }
}