package jp.co.sharedsys.service.mapper;

import java.util.List;
import java.util.Map;
import jp.co.sharedsys.service.model.MsUpFileDef;
import org.springframework.stereotype.Component;

/**
 *
 * @author sharedsys
 */
@Component("MS_UPLOAD_FILE_TEIGI")
public interface MsUpFileDefMapper extends IMapper {

    List<MsUpFileDef> findAll();

    List<Map> findAllForSelector();

    MsUpFileDef findById(int id);

    List<MsUpFileDef> findByColumn(MsUpFileDef entity);
}
