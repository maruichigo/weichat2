package jp.co.sharedsys.service.bus.common;

import java.util.List;
import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.service.bus.SSFrameBusBase;
import jp.co.sharedsys.service.mapper.IMapper;
import jp.co.sharedsys.service.mapper.SsComUploadCheckResultMapper;
import jp.co.sharedsys.service.mapper.SsComUploadDefMapper;
import jp.co.sharedsys.service.mapper.SsComUploadRawDataMapper;
import jp.co.sharedsys.service.model.SsComUploadCheckResult;
import jp.co.sharedsys.service.model.SsComUploadDef;
import jp.co.sharedsys.service.model.SsComUploadRawData;
import org.springframework.util.StringUtils;

/** 
 * 共通アップロードBase
 */
public abstract class SsComUploadBaseBus extends SSFrameBusBase {
    protected final String SELECT_FILETYPE = "selectMaster";
    
    @Autowired
    protected SsComUploadDefMapper uploadMapper;
    @Autowired
    protected SsComUploadRawDataMapper uploadRawDataMapper;
    @Autowired
    protected SsComUploadCheckResultMapper uploadCheckResultMapper;

    protected IMapper mapForTarget(String target) {
        IMapper mapper =(IMapper)this.getWebApplicationContext().getBean(target);
        if (mapper != null) {
            return mapper;
        }
        throw new UnsupportedOperationException("unsupported table");
    }
    protected IMapper targetMapper;
    
    protected Map<String, Object> params = null;
    protected SsComUploadDef targetDef = null;
    protected Long yomikomiId = null;
    
    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        super.init(serviceInterfaceBean);
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
    }

    protected List<Map> searchTmpData(String UserCd, Long yomikomiId) throws Exception {
        // 行Name,行表示名を取得(アップロードデータの1,2行目に記載されていることが前提)
        SsComUploadRawData crt = new SsComUploadRawData();
        if (yomikomiId != null) {
            crt.setYomikomiId(yomikomiId);
        }
        crt.setUploadDefId(this.targetDef.getId());
        crt.setUserCd(UserCd);
        List<SsComUploadRawData> headerLine = this.uploadRawDataMapper.findLineInfo(crt);
        if (headerLine == null || headerLine.isEmpty() || StringUtils.isEmpty(headerLine.get(0).getData())) {
            return null;
        }
        
        if (yomikomiId == null) {
            yomikomiId = headerLine.get(0).getYomikomiId();
        }
        List<Map> result = new ArrayList<>();
        List<String> columnKeys = Arrays.asList(headerLine.get(0).getData().split(","));
        List<String> columnNames = Arrays.asList(headerLine.get(1).getData().split(","));
        Map<String, String> columnNameLine = new LinkedHashMap<>();
        for (int i = 0; i < columnKeys.size(); i++) {
            columnNameLine.put(columnKeys.get(i), columnNames.get(i));
        }
        
        this.targetMapper = this.mapForTarget(this.targetDef.getTmpTableName());
        if (this.targetMapper != null) {
            result = this.targetMapper.findToMap(this.params);
        }
        
        if (result != null) {
            // チェック結果を検索、付与する
            SsComUploadCheckResult ckCrt = new SsComUploadCheckResult();
            ckCrt.setYomikomiId(yomikomiId);
            ckCrt.setUploadDefId(targetDef.getId());
            for (int i = 0; i < result.size(); i++) {
                Map m = result.get(i);
                ckCrt.setLineNo(i);
                List<SsComUploadCheckResult> checkResult = uploadCheckResultMapper.findByColumn(ckCrt);
                if (checkResult != null && !checkResult.isEmpty()) {
                    for (SsComUploadCheckResult ck : checkResult) {
                        if (m.containsKey(ck.getColumnName())) {
                            m.put("ROWERR", "true");
                            m.put(ck.getColumnName() + "_ISERR", "true");
                            m.put(ck.getColumnName() + "_ERRDESC", ck.getMessage());
                        }
                    }
                }
                
            }
            result.add(0, columnNameLine);
        }
        return result;
    }
}
