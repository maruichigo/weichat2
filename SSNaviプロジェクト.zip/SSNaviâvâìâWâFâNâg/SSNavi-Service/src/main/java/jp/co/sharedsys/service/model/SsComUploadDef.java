package jp.co.sharedsys.service.model;

import java.io.Serializable;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import jp.co.sharedsys.service.constraintannotation.PrimaryKey;
import lombok.Data;

/** 
 * 共通アップロード用データ定義
 * @author sharedsys
 */
@Data
public class SsComUploadDef extends BaseModel implements Serializable {

    private static final long serialVersionUID = 8225066323266434396L;

    @NotNull
    @Digits(integer = 10, fraction = 0)
    @Min(0)
    @PrimaryKey(columnName = "ID")
    private Long id;

    private String fileName;          // ファイル名
    private String fileDescription;   //
    private String fileType;          // ファイル種別
    private String tmpTableName;      // ワークテーブル名
    private String dsFileRead;        // ファイル読込用DataSpider
    private String dsTmpSave;         // 一時保存用DataSpider
    private String dsProdSave;        // 登録用DataSpider
    private String remarks;
}
