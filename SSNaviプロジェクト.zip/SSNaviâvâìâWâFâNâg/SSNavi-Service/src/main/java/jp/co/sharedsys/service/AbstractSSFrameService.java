package jp.co.sharedsys.service;


import javax.annotation.PostConstruct;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.exception.InvalidValueException;
import org.glassfish.jersey.media.multipart.FormDataMultiPart;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

/**
 * @author sharedsys
 *
 */
public abstract class AbstractSSFrameService extends SSFrameBase {

    /**
     * initialization
     */
    @PostConstruct
    public void init() {
        SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);		
    }
    
    /**　共通公開メソッド
     *  
     * 外部からのリクエストに対しFUNCTION_CODE_MASTERに登録されている
     * クラス、メソッドを実行する。
     * 
     * serviceInterfaceBeanのFunctionCodeでFUNCTION_CODE_MASTERの
     * CLASS_NAMEとMETHOD_NAMEを取得。
     * 取得したCLASS_NAME、METHOD_NAMEで該当クラスのインスタンスを作成しメソッドの実行を行う。
     * 尚、メソッドのパラメータとしてserviceInterfaceBeanのUserCd,json(画面からパラメータが格納されているModelオブジェクトのJSON文字列)
     * を利用する。
     * 
     * @param serviceInterfaceBean リクエストパラメータ
     * @return レスポンスデータ
     * @throws Exception システムエラー
     * @throws InvalidValueException 入力値エラー 
     */
    public abstract ServiceInterfaceBean baseService(ServiceInterfaceBean serviceInterfaceBean)  throws Exception, InvalidValueException ;

    /**　共通公開メソッド(ファイル受信用)
     *  
     *  baseServiceメソッドに、Multipartデータを受信出来るようにしたもの
     * 
     * @param attachments
     * @return レスポンスデータ
     * @throws Exception システムエラー
     * @throws InvalidValueException 入力値エラー 
     */
//    @POST
//    @Path("/JohmonWebServiceForMultipart")
//    @Consumes("multipart/mixed; type=\"application/json\"")
//    @Produces(MediaType.APPLICATION_JSON)
////    @Multipart(value = "root", type = "application/json") 
//    @Transactional
//    public ServiceInterfaceBean baseServiceForMultipart(MultipartBody body)  throws Exception, InvalidValueException ;
    public abstract ServiceInterfaceBean baseServiceForMultipart(FormDataMultiPart attachments)  throws Exception, InvalidValueException ;
//    public ServiceInterfaceBean baseServiceForMultipart(@Multipart(value = "bean", type = "application/json") ServiceInterfaceBean serviceInterfaceBean
//    												   ,@Multipart(value = "file", type = "application/octet-stream") List<Attachment> attachments)  throws Exception, InvalidValueException ;
}
