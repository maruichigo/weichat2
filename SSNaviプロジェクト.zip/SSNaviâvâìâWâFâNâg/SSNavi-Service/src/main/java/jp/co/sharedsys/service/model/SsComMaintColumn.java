package jp.co.sharedsys.service.model;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import jp.co.sharedsys.service.constraintannotation.PrimaryKey;
import lombok.Data;

/** 
 * 共通メンテナンス用カラム定義
 * @author sharedsys
 */
@Data
public class SsComMaintColumn extends BaseModel implements Serializable {

    private static final long serialVersionUID = 8225066323266434396L;

    @NotNull
    @Digits(integer = 10, fraction = 0)
    @Min(0)
    @PrimaryKey(columnName = "ID")
    private Long id;

    private String tableName;
    private String columnName;
    private String subColumn;
    private String columnDescription;
    private Long controlInd;
    private Long searchColumnInd;
    private Long lineEnd;
    private Long section;    
    private String searchComponent;
    private String searchOptFuncName;
    private String searchOptParam;
    private String defaultValue;
    private Long sortIndex;
    private String schSortIndex;
    private String remarks;
    private String pk;
    private List<SsComMaintSubSearch> resultSubList;    
}
