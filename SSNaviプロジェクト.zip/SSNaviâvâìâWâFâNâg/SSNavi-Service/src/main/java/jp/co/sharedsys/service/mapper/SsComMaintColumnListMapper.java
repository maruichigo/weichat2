package jp.co.sharedsys.service.mapper;

import java.util.List;
import jp.co.sharedsys.service.model.SsComMaintColumnList;
import org.springframework.stereotype.Component;

/**
 *
 * @author sharedsys
 */
@Component("maint_column_list")
public interface SsComMaintColumnListMapper extends IMapper {
    
    List<SsComMaintColumnList> findAll();
    
    SsComMaintColumnList findById(int id);
    
    List<SsComMaintColumnList> findByColumn(SsComMaintColumnList entity);
}
