/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.sharedsys.service.bus.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.service.bus.SSFrameBusBase;
import jp.co.sharedsys.service.mapper.IMapper;
import jp.co.sharedsys.service.mapper.SsComMaintColumnListMapper;
import jp.co.sharedsys.service.model.SsComMaintColumnList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

/**
 *
 * @author 
 */
@Component("SS_COM_MAINT_COLUMN_LIST")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class SsComMaintColumnListBus extends SSFrameBusBase {
    protected final String TABLE_NAME = "TABLE_NAME";
    @Autowired
    private SsComMaintColumnListMapper columnList;
    
    private IMapper mapForTarget(String target) {
        IMapper mapper =(IMapper)this.getWebApplicationContext().getBean(target);
        if (mapper != null) {
            return mapper;
        }
        throw new UnsupportedOperationException("unsupported table");
    }
    private IMapper targetMapper;
    
    private Map<String, Object> params = null;    

    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        super.init(serviceInterfaceBean);
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
        targetMapper = this.mapForTarget("maint_column_list");
    }
    
    @Override
    public String validateHeaderByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public String validateDetailByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";        
    }

    @Override
    public void setValidaterFactory() throws Exception {
    }

    @Override
    public String validateHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";        
    }

    @Override
    public String validateDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";        
    }

    @Override
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        SsComMaintColumnList crt = new SsComMaintColumnList();
        crt.setTableName((String)params.get("TABLE_NAME"));
        List<SsComMaintColumnList> resultList = columnList.findByColumn(crt);
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));        
    }

    @Override
    public void saveDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }

    @Override
    public void confirm(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }

    @Override
    public String finalProc(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";        
    }
}
