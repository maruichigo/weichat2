package jp.co.sharedsys.service.bus.common;

import java.util.List;
import java.util.Map;


import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.common.methods.SSCommonUtil;
import jp.co.sharedsys.service.bus.SSFrameBusBase;
import jp.co.sharedsys.service.mapper.SsComMaintColumnMapper;
import jp.co.sharedsys.service.mapper.SsComReportDefMapper;
import jp.co.sharedsys.service.mapper.SsComReportUtilMapper;
import jp.co.sharedsys.service.model.SsComMaintColumn;
import jp.co.sharedsys.service.model.SsComReportDef;
import org.springframework.beans.factory.annotation.Autowired;

/** 
 * 共通メンテナンス用データ取得
 */
@Component("SS_COM_REPORT_PROC")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class SsComReportProcBus extends SSFrameBusBase {
    protected final String TABLE_NAME = "TABLE_NAME";
    
    @Autowired
    private SsComReportDefMapper reportMapper;
    @Autowired
    private SsComReportUtilMapper reportUtilMapper;
    @Autowired
    private SsComMaintColumnMapper columnMapper;
    
    private Map<String, Object> params = null;
    private List<Map<String, Object>> inputParams = null;
    private SsComReportDef targetDef = null;
    
    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        super.init(serviceInterfaceBean);
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
    }
    
    @Override
    public String validateHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }
	
    @Override
    public String validateDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public String validateHeaderByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
	return "";
    }

    @Override
    public String validateDetailByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    	return "";
    }

    /** 
     * 検索
     * @param serviceInterfaceBean リクエストパラメータ
     * @throws Exception
     */
    @Override
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        SsComReportDef crt = new SsComReportDef();
        crt.setReportId((String)params.get(TABLE_NAME));
        List<SsComReportDef> def =  reportMapper.findByColumn(crt);
        targetDef = def.get(0);

        // 検索条件に加える項目を取得
        SsComMaintColumn colCrt = new SsComMaintColumn();
        colCrt.setTableName((String)params.get(TABLE_NAME));
        colCrt.setSearchColumnInd(1L);
        List<SsComMaintColumn> whereColumns = columnMapper.findByColumn(colCrt);

        // ex
//        String sql = "select * from target_table where blog_id = #{params.blog_id} and created_date > #{params.date}";
        StringBuffer sql = new StringBuffer();
        sql.append(targetDef.getSearchSql());
        StringBuffer where = new StringBuffer();
        String compWhere = "";
        if (whereColumns != null) {
            List<String> evalList = new ArrayList<>();
            for (SsComMaintColumn col : whereColumns) {
                String camelizedKey = SSCommonUtil.camelize(col.getColumnName());
                if (!SSCommonUtil.ifnull(params.get(camelizedKey), "").isEmpty()) {
                    evalList.add(col.getColumnName() + " = #{params." + camelizedKey + "} " );
                } else if (!SSCommonUtil.ifnull(params.get(camelizedKey + "Start"), "").isEmpty() && !SSCommonUtil.ifnull(params.get(camelizedKey + "End"), "").isEmpty()) {
                    evalList.add(col.getColumnName() + " BETWEEN #{params." + camelizedKey + "Start} AND #{params." + camelizedKey + "End} " );
                } else if (!SSCommonUtil.ifnull(params.get(camelizedKey + "Start"), "").isEmpty() && SSCommonUtil.ifnull(params.get(camelizedKey + "End"), "").isEmpty()) {
                    evalList.add(col.getColumnName() + " >= #{params." + camelizedKey + "Start} " );
                } else if (SSCommonUtil.ifnull(params.get(camelizedKey + "Start"), "").isEmpty() && !SSCommonUtil.ifnull(params.get(camelizedKey + "End"), "").isEmpty()) {
                    evalList.add(col.getColumnName() + " <= #{params." + camelizedKey + "End} " );
                }
            }
            if (!evalList.isEmpty()) {
                if (!sql.toString().toUpperCase().contains(" WHERE ")) {
                    where.append(" WHERE ");
                } else {
                    where.append(" AND ");
                }
                for (String w : evalList) {
                    where.append(w);
                    where.append(" AND ");
                }
                compWhere = where.substring(0, where.length()-4);
            }
        }
        String compSql = sql.toString().replace("#{where}", compWhere);
        
        // SQL実行、データ取得
        List<LinkedHashMap<String, Object>> rset = reportUtilMapper.list(compSql, params);
        
        if (rset != null) {
            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(rset));
        }
        serviceInterfaceBean.setMessage("データの取得に成功しました");
    }

    @Override
    public void saveDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }

    @Override
    public void setValidaterFactory() throws Exception {
    }

    @Override
    public void confirm(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }

    @Override
    public String finalProc(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }        
}
