package jp.co.sharedsys.service.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import org.apache.commons.dbcp.BasicDataSource;
import org.apache.commons.lang.StringUtils;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternUtils;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;

/**
 * Spring,MyBatisの初期設定クラス
 * @author sharedsys
 */
@Component
@Configuration
@ComponentScan(basePackages = {
     "jp.co.*"
})
@MapperScan(basePackages={
    "jp.co.*.service.mapper"
})
@PropertySource("classpath:application.properties")
public class SpringAppConfiguration {
    
    @Autowired
    ApplicationContext applicationContext;

    @Autowired
    Environment environment;

    @Value("#{ environment['spring.datasource.url'] }")
    protected String databaseUrl;
    @Value("#{ environment['spring.datasource.username'] }")
    protected String databaseUserName = "";
    @Value("#{ environment['spring.datasource.password'] }")
    protected String databasePassword = "";
    @Value("#{ environment['spring.datasource.driverClassName'] }")
    protected String driverClassName;
    @Value("#{ environment['spring.datasource.testWhileIdle'] }")
    protected String testWhileIdle;
    @Value("#{ environment['spring.datasource.testOnBorrow'] }")
    protected String testOnBorrow;
    @Value("#{ environment['spring.datasource.validationQuery'] }")
    protected String databaseValidationQuery;
    @Value("#{ environment['spring.datasource.timeBetweenEvictionRunsMillis'] }")
    protected String timeBetweenEvictionRunsMillis;
    @Value("#{ environment['spring.datasource.defaultAutoCommit'] }")
    protected String defaultAutoCommit;
    @Value("#{ environment['spring.datasource.maxActive'] }")
    protected String maxActive;
    @Value("#{ environment['spring.datasource.maxIdle'] }")
    protected String maxIdle;

    @Value("#{ environment['spring.datasource.jndi'] }")
    protected String jndi;

    @Value("#{ environment['mybatis.config-location'] }")
    protected String mybatisConfigLocation;
    @Value("#{ environment['mybatis.mapper-location'] }")
    protected String mybatisMapperLocation;

    @Bean(destroyMethod = "close")
    @Profile("production")
    public DataSource productionDataSource() throws Exception {
        Context ctx = new InitialContext();
//        return (DataSource) ctx.lookup("java:comp/env/jdbc/datasource");
        return (DataSource) ctx.lookup(jndi);
    }

    @Bean(destroyMethod = "close")
    @Profile("dev")
    public DataSource devDataSource() {
        return dataSource();
    }    
    
    @Bean(destroyMethod = "close")
    public DataSource dataSource() {
        BasicDataSource dataSource = new BasicDataSource();
        dataSource.setDriverClassName(driverClassName);
        dataSource.setUrl(databaseUrl);
        dataSource.setUsername(databaseUserName);
        dataSource.setPassword(databasePassword);
        dataSource.setValidationQuery(databaseValidationQuery);
        dataSource.setTestOnBorrow("true".equals(testOnBorrow));
        dataSource.setTestWhileIdle("true".equals(testWhileIdle));
        dataSource.setTimeBetweenEvictionRunsMillis(StringUtils.isBlank(timeBetweenEvictionRunsMillis) ? 1800000 : Long.parseLong(timeBetweenEvictionRunsMillis));
        dataSource.setDefaultAutoCommit("true".equals(defaultAutoCommit));
        dataSource.setMaxActive(StringUtils.isBlank(maxActive) ? 50 : Integer.parseInt(maxActive));
        dataSource.setMaxIdle(StringUtils.isBlank(maxIdle) ? 50 : Integer.parseInt(maxIdle));
        return dataSource;
    }

    @Bean
    public ObjectMapper objectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.INDENT_OUTPUT, true);
        return mapper;
    }
    
    @Bean
    public SqlSessionFactory sqlSessionFactory() throws Exception {
        SqlSessionFactoryBean factory = new SqlSessionFactoryBean();
        factory.setDataSource(dataSource());
        ResourcePatternResolver resolver = ResourcePatternUtils.getResourcePatternResolver(new DefaultResourceLoader());
        // MyBatis のコンフィグレーションファイル
        factory.setConfigLocation(resolver.getResource(mybatisConfigLocation));
        // MyBatis で使用する SQL ファイル群(daoフォルダ内のサブフォルダ内も含んだ全てのxml)
        List<Resource> mapperLocations = new ArrayList<>();
        String[] locSplit = mybatisMapperLocation.split(",");
        for (String loc : locSplit) {
            mapperLocations.addAll(Arrays.asList(resolver.getResources(loc)));
        }
        Resource[] locationResources = {};
        factory.setMapperLocations(mapperLocations.toArray(locationResources));

        return factory.getObject();
    }

    @Bean
    public PlatformTransactionManager transactionManager() {
        return new DataSourceTransactionManager(dataSource());
    }    
}
