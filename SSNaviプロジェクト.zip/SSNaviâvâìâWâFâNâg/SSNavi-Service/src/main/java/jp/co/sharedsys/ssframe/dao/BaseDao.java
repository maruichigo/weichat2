package jp.co.sharedsys.ssframe.dao;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author sharedsys
 */
public abstract class BaseDao<T> extends SqlSessionDaoSupport implements Dao<T> {

    @Autowired
    @Override
    public void setSqlSessionFactory(SqlSessionFactory sqlSessionFactory) {
        super.setSqlSessionFactory(sqlSessionFactory);
    }
    
    @Override
    public String tableName() {
        return null;
    }
}
