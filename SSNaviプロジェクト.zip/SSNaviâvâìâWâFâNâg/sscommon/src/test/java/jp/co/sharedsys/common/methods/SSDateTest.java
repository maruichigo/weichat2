package jp.co.sharedsys.common.methods;

import java.util.Calendar;

import jp.co.sharedsys.common.methods.SSDate;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;


public class SSDateTest extends TestCase{


	public SSDateTest( String testName )
    {
        super( testName );
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( SSDateTest.class );
    }


	public void testGetCurrentDateTime(){
		System.out.println("testGetCurrentDateTime:" + SSDate.getCurrentDateTime());
	}
	
	public void testDiffDay(){
		Calendar start =  Calendar.getInstance();
		Calendar end =  Calendar.getInstance();
		// 2011.06.01
		start.set(2011, Calendar.OCTOBER, 1, 0, 0, 0);
		// 2011.06.30
		end.set(2011, Calendar.OCTOBER, 30, 0, 0, 0);
		System.out.println("testDiffDay:" + SSDate.diffDay(start, end));
	}
	
	public void testDiffMillionTime(){
		System.out.println("testDiffTime:" + SSDate.diffMillionTime("2015/06/01/ 00:00:00.001","2015/07/01/ 00:00:00.111"));
	}
	
	
	
}
