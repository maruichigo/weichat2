package jp.co.sharedsys.common.methods;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class Misk extends TestCase{
	
	public enum ACTIVE_IND{INACTIVE,ACTIVE,ABC};
	
	public Misk( String testName )
    {
        super( testName );
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( Misk.class );
    }

//	public void testENUM(){
//		System.out.println(ACTIVE_IND.INACTIVE.ordinal());
//		System.out.println(ACTIVE_IND.ACTIVE.ordinal());
//		
//		ACTIVE_IND ind = SSCommonUtil.fromOrdinal(ACTIVE_IND.class,0);
//
//		System.out.println(ind);
//
//	}
	
	public void testMask(){
		System.out.println(String.format("%1$010d", 0L));
		System.out.println(String.format("%1$010d", 1L));
		System.out.println(String.format("%1$010d", 12));
		System.out.println(String.format("%1$010d", 123));
		System.out.println(String.format("%1$010d", 1234));
		System.out.println(String.format("%1$010d", 12345));
		System.out.println(String.format("%1$010d", 123456));
		System.out.println(String.format("%1$010d", 1234567));
		System.out.println(String.format("%1$010d", 12345678));
		System.out.println(String.format("%1$010d", 123456789));
		System.out.println(String.format("%1$010d", 1234567890));

	}
}
