package jp.co.sharedsys.common.methods;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/** 郵便番号関連処理テストクラス
 * @author T.Hirose
 *
 */
public class PostalCodeTest extends TestCase{


	public PostalCodeTest( String testName )
    {
        super( testName );
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( PostalCodeTest.class );
    }

	public void testDownloadPostalCodeFile(){
//		try{
//			PostalCode.downloadPostalCodeFile("c://DCL/ken_all.zip","c://DCL/test");
//		} catch(Exception e){
//			e.printStackTrace();
//		}
		
	}
}
