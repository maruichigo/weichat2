package jp.co.sharedsys.common.bean;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.ArrayList;

public class ServiceInterfaceBean {

	//============================================================
	// 処理ステータス
	//============================================================
	// システムエラー
	public static final int PROCESS_STATUS_SYSTEM_ERROR = -2;
	// 通常エラー(値の間違い、不正処理)
	public static final int PROCESS_STATUS_ERROR = -1;
	// 正常終了
	public static final int PROCESS_STATUS_SUCCESS = 1;
	
	private String message = "";
	private int statusCode = 0;
	private String UserCd = "";
	private String functionCode = "";

        private String tableName = "";
	private String json = "";
        @JsonIgnore
	private List<String> makerCode = null;
	private List<String> userGroupCode = null;
	
        private String jsonResultTableList = "";
        private String jsonResultMap = "";

	private Map<String,String> errFldMapNew = new TreeMap<String,String>();
	private Map<String,String> errMsgMapNew = new TreeMap<String,String>();

    //新メッセージ処理 ss.furutani
    private List<String[]> messages = new ArrayList<String[]>();
    /**
	 * メッセージを格納する。
	 * @param level   INFO,WARN,ERROR,FATAL
	 * @param summary 協調メッセージ
	 * @param message メッセージ内容
	 */
    public void addMessage(String level, String summary, String messageStr ) {
        String[] msg = { level, summary, messageStr };
        messages.add(msg);
    }
    public List<String[]> getMessages(){
        return messages;
    }

	// initial処理用フラグ
	private boolean initial = false;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getUserCd() {
		return UserCd;
	}
	public void setUserCd(String UserCd) {
		this.UserCd = UserCd;
	}
	public String getFunctionCode() {
		return functionCode;
	}
	public void setFunctionCode(String funcId) {
		this.functionCode = funcId;
	}
	public Map getErrFldMapNew() {
		return errFldMapNew;
	}
	public void setErrFldMapNew(Map errFldMapNew) {
		this.errFldMapNew = errFldMapNew;
	}
	public Map getErrMsgMapNew() {
		return errMsgMapNew;
	}
	public void setErrMsgMapNew(Map errMsgMapNew) {
		this.errMsgMapNew = errMsgMapNew;
	}
	public String getJson() {
		return json;
	}
	public void setJson(String json) {
		this.json = json;
	}
	public List<String> getMakerCode() {
		return makerCode;
	}
	public void setMakerCode(List<String> makerCode) {
		this.makerCode = makerCode;
	}
	public List<String> getUserGroupCode() {
		return userGroupCode;
	}
	public void setUserGroupCode(List<String> userGroupCode) {
		this.userGroupCode = userGroupCode;
	}
	public boolean isInitial() {
		return initial;
	}
	public void setInitial(boolean initial) {
		this.initial = initial;
	}
        
         public String getTableName() {
            return tableName;
        }

        public void setTableName(String tableName) {
            this.tableName = tableName;
        }

    /**
     * @return the jsonResultTableList
     */
    public String getJsonResultTableList() {
        return jsonResultTableList;
    }

    /**
     * @param jsonResultTableList the jsonResultTableList to set
     */
    public void setJsonResultTableList(String jsonResultTableList) {
        this.jsonResultTableList = jsonResultTableList;
    }

    /**
     * @return the jsonResultMap
     */
    public String getJsonResultMap() {
        return jsonResultMap;
    }

    /**
     * @param jsonResultMap the jsonResultMap to set
     */
    public void setJsonResultMap(String jsonResultMap) {
        this.jsonResultMap = jsonResultMap;
    }
    
    
/*
    public MessageDataModel getMsg() {
        return msg;
    }

    public void setMsg(MessageDataModel msg) {
        this.msg = msg;
    }*/
}
