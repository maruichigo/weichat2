package jp.co.sharedsys.common.methods;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;

public class DateUtil {

    final public static String SLASH_YYYYMMDD = "yyyy/MM/dd";
    final public static String HYPHEN_YYYYMMDD = "yyyy-MM-dd";
    final public static String YYYYMMDD = "yyyyMMdd";
    final public static String YYMMDD = "yyMMdd";
    final public static Object NULL = null;

    /**
     * 日付をString型(YYYYMMDD)で返す
     * @return String
     * @throws java.text.ParseException
     */
    public static String getTodayYYYYMMDD() throws ParseException{
        
        return DateFormatUtils.format(new Date(), YYYYMMDD);

    }    

    /**
     * 日付をString型(YYMMDD)で返す
     * @return String
     * @throws java.text.ParseException
     */
    public static String getTodayYYMMDD() throws ParseException{
        
        return DateFormatUtils.format(new Date(), YYMMDD);

    }

    /**
     * 日付をString型(YYYY/MM/DD)で返す
     * @return String
     * @throws java.text.ParseException
     */
    public static String getTodaySlashYYYYMMDD() throws ParseException{
        
        return DateFormatUtils.format(new Date(), SLASH_YYYYMMDD);

    }

    /**
     * 日付をString型(YYYY/MM/DD)で返す
     * @return String
     * @throws java.text.ParseException
     */
    public static String getTodayHyphenYYYYMMDD() throws ParseException{
        
        return DateFormatUtils.format(new Date(), HYPHEN_YYYYMMDD);

    }
    
    /**
     * Data型の日付を指定された形式のString型で返す
     * @param stringDate 入力日付
     * @param format 日付形式
     * @return String 出力日付
     * @throws java.text.ParseException
     */
    public static Date stringToDate(String stringDate, String format) throws ParseException{
        
        return DateUtils.parseDateStrictly(stringDate, Optional.ofNullable(format).orElse(YYYYMMDD));

    }

    /**
     * String型の日付を指定された形式のDate型で返す
     * @param date 入力日付
     * @param format 日付形式
     * @return String 出力日付
     * @throws java.text.ParseException
     */
    public static String dateToString(Date date, String format) throws ParseException{
        
        return DateFormatUtils.format(date, format);

    }

    /**
     * 入力された年月日を設定してString型で返す
     * @param date 入力日付
     * @param format 日付形式
     * @param year 年
     * @param month 月
     * @param day 日
     * @return String 出力日付
     * @throws java.text.ParseException
     */
    public static String stringSetYMS(Object date, String format, Integer year, Integer month, Integer day) throws ParseException{
        Date tmpDate;
        format = Optional.ofNullable(format).orElse(YYYYMMDD);
        if (date instanceof String) {
            tmpDate = DateUtils.parseDateStrictly((String) date, format);
        } else if (date instanceof Date) {
            tmpDate = (Date) date;
        } else {
            return null;
        }
        if(year != null) tmpDate = DateUtils.setYears(tmpDate, year);
        if(month != null) tmpDate = DateUtils.setMonths(tmpDate, month - 1);
        if(day != null) tmpDate = DateUtils.setDays(tmpDate, day);
        return DateFormatUtils.format(tmpDate, format);
    }
    
    /**
     * 入力された年月日を設定してDate型で返す
     * @param date 入力日付
     * @param format 日付形式
     * @param year 年
     * @param month 月
     * @param day 日
     * @return Date 出力日付
     * @throws java.text.ParseException
     */
    public static Date dateSetYMS(Object date, String format, Integer year, Integer month, Integer day) throws ParseException{
        
        Date tmpDate;
        format = Optional.ofNullable(format).orElse(YYYYMMDD);
        if (date instanceof String) {
            tmpDate = DateUtils.parseDateStrictly((String) date, format);
        } else if (date instanceof Date) {
            tmpDate = (Date) date;
        } else {
            return null;
        }
        if(year != null) tmpDate = DateUtils.setYears(tmpDate, year);
        if(month != null) tmpDate = DateUtils.setMonths(tmpDate, month - 1);
        if(day != null) tmpDate = DateUtils.setDays(tmpDate, day);
        return tmpDate;

    }
    
    /**
     * 入力された年月日を加算してString型で返す
     * @param date 入力日付
     * @param format 日付形式
     * @param year 年
     * @param month 月
     * @param day 日
     * @return String 出力日付
     * @throws java.text.ParseException
     */
    public static String stringAddYMS(Object date, String format, Integer year, Integer month, Integer day) throws ParseException{
        
        Date tmpDate;
        format = Optional.ofNullable(format).orElse(YYYYMMDD);
        if (date instanceof String) {
            tmpDate = DateUtils.parseDateStrictly((String) date, format);
        } else if (date instanceof Date) {
            tmpDate = (Date) date;
        } else {
            return null;
        }

        if(year != null) tmpDate = DateUtils.addYears(tmpDate, year);
        if(month != null) tmpDate = DateUtils.addMonths(tmpDate, month);
        if(day != null) tmpDate = DateUtils.addDays(tmpDate, day);

        return DateFormatUtils.format(tmpDate, format);

    }

    /**
     * 入力された年月日を加算してDate型で返す
     * @param date 入力日付
     * @param format 日付形式
     * @param year 年
     * @param month 月
     * @param day 日
     * @return String 出力日付
     * @throws java.text.ParseException
     */
    public static Date dateAddYMS(Object date, String format, Integer year, Integer month, Integer day) throws ParseException{

        Date tmpDate;
        format = Optional.ofNullable(format).orElse(YYYYMMDD);
        if (date instanceof String) {
            tmpDate = DateUtils.parseDateStrictly((String) date, format);
        } else if (date instanceof Date) {
            tmpDate = (Date) date;
        } else {
            return null;
        }

        if(year != null) tmpDate = DateUtils.addYears(tmpDate, year);
        if(month != null) tmpDate = DateUtils.addMonths(tmpDate, month);
        if(day != null) tmpDate = DateUtils.addDays(tmpDate, day);

        return tmpDate;

    }

    /**
     * 入力された年月日の曜日(0～6)を返却
     * @param date 入力日付
     * @return String 曜日(0～6)
     * @throws java.text.ParseException
     */
    public static String stringWeekDay(Object date) throws ParseException{
        Date tmpDate;
        if (date instanceof String) {
            if (StringUtils.isBlank( (String) date)) tmpDate = new Date();
            else tmpDate = DateUtils.parseDateStrictly((String) date, YYYYMMDD);
            return DateFormatUtils.format(tmpDate, "E");
        } else if (date instanceof Date) {
            tmpDate = (Date) date;
            return DateFormatUtils.format(tmpDate, "E");
        } else {
            return null;
        }
    }
    
    /**
     * 入力された日付が一致しているか比較
     * @param date1 入力日付
     * @param date2 入力日付
     * @return boolean
     * @throws java.text.ParseException
     */
    public static boolean isSameDay(Object date1, Object date2) throws ParseException{
        Date tmpDate1,tmpDate2;

        if (date1 instanceof String) {
            tmpDate1 = DateUtils.truncate(DateUtils.parseDateStrictly((String) date1, YYYYMMDD), Calendar.DAY_OF_MONTH);
        } else if (date1 instanceof Date) {
            tmpDate1 = DateUtils.truncate((Date) date1, Calendar.DAY_OF_MONTH);
        } else {
            return false;
        }
        
        if (date2 instanceof String) {
            tmpDate2 = DateUtils.truncate(DateUtils.parseDateStrictly((String) date2, YYYYMMDD), Calendar.DAY_OF_MONTH);
        } else if (date2 instanceof Date) {
            tmpDate2 = DateUtils.truncate((Date) date2, Calendar.DAY_OF_MONTH);
        } else {
            return false;
        }        
        
        return DateUtils.isSameDay(tmpDate1, tmpDate2);
    }
    

}
