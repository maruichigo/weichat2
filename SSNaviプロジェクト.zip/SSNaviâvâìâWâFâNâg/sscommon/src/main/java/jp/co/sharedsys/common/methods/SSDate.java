package jp.co.sharedsys.common.methods;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.StringTokenizer;

/** 共通の日付関連メソッド
 * @author sharedsys
 *
 */
public class SSDate {
	
/*	
	文字	意味	例
	yy	西暦年（２桁）	2012年→2012
	yyyy	西暦年（４桁）	2012年→12
	M	月	8月→8
	MM	月（ゼロ埋め）	8月→08
	D	年に対する日	1月9日→9
	DDD	年に対する日（ゼロ埋め）	1月9日→009
	d	月に対する日	3日→3
	dd	月に対する日（ゼロ埋め）	3日→03
	w	年に対する週	2011年8月30日→36（2011年の36週目）
	W	月に対する週	2011年8月30日→5（2011年8月の5週目）
	E	曜日	2011年8月30日→火
	F	月に対する曜日番号	2011年8月30日（火）
	　→5（2011年8月の5回目の火曜日）
	a	午前午後	13:00→午後
	h	時（12時間制）	13時→1
	hh	時（12時間制ゼロ埋め）	13時→01
	H	時（24時間制）	3時→3
	HH	時（24時間制ゼロ埋め）	3時→03
	m	分	3分→3
	mm	分（ゼロ埋め）	3分→03
	s	秒	3秒→3
	ss	秒（ゼロ埋め）	3秒→03
	S	ミリ秒	3ミリ秒→3
	SSS	ミリ秒（ゼロ埋め）	3ミリ秒→003	
*/	
	/** 現在日時取得(yyyyMMdd hh:mm:ss.SSS)
	 * @return yyyyMMdd hh:mm:ss.SSSフォーマットの現在日時
	 */
	public static String getCurrentDateTime(){
		String format = "yyyy/MM/dd HH:mm:ss.SSS";
        Calendar c = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        return sdf.format(c.getTime());
	}
	
	public static String getCurrentDate(){
		String format = "yyyyMMdd";
        Calendar c = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        return sdf.format(c.getTime());
	}
	
	
    /** 日付の差(Calendar)
     * @param start 開始日
     * @param end 終了日
     * @return 日付の差
     */
    public static String diffDay(Calendar start, Calendar end) {
    	long difference = end.getTime().getTime() - start.getTime().getTime();
        return String.valueOf(difference / 1000 / 60 / 60 / 24);
    }
    
    /** 日付の差(String)
     * @param start 開始日
     * @param end 終了日
     * @return 日付の差
     */
    public static String diffMillionTime(String start, String end){
    	
    	Calendar strCal = toCalendar(start);
    	Calendar endCal = toCalendar(end);
    	
    	long e = endCal.getTime().getTime();
    	long s = strCal.getTime().getTime();
    	long r = e - s;
    	return String.valueOf(r);
    }
    
    /**
     * 指定された日付・時刻文字列を、可能であれば 
     * Calendarクラスに変換します。
     * 以下の形式の日付文字列を変換できます。
     * 
     * ●変換可能な形式は以下となります。
     *  yyyy/MM/dd
     *  yy/MM/dd
     *  yyyy-MM-dd
     *  yy-MM-dd
     *  yyyyMMdd
     * 
     * 上記に以下の時間フィールドが組み合わされた状態
     * でも有効です。
     *  HH:mm 
     *  HH:mm:ss 
     *  HH:mm:ss.SSS
     *  
     * @param strDate 日付・時刻文字列。
     * @return 変換後のCalendarクラス。
     * @throws IllegalArgumentException 
     *         日付文字列が変換不可能な場合
     *         または、矛盾している場合（例：2000/99/99）。
     */
    public static Calendar toCalendar(String strDate){
        strDate = format(strDate);
        Calendar cal = Calendar.getInstance();
        cal.setLenient(false);

        int yyyy = Integer.parseInt(strDate.substring(0,4));
        int MM = Integer.parseInt(strDate.substring(5,7));
        int dd = Integer.parseInt(strDate.substring(8,10));
        int HH = cal.get(Calendar.HOUR_OF_DAY);
        int mm = cal.get(Calendar.MINUTE);
        int ss = cal.get(Calendar.SECOND);
        int SSS = cal.get(Calendar.MILLISECOND);
        cal.clear();
        cal.set(yyyy,MM-1,dd);
        int len = strDate.length();
        switch (len) {
            case 10:
                break;
            case 16: // yyyy/MM/dd HH:mm
                HH = Integer.parseInt(strDate.substring(11,13));
                mm = Integer.parseInt(strDate.substring(14,16));
                cal.set(Calendar.HOUR_OF_DAY,HH);
                cal.set(Calendar.MINUTE,mm);
                break;
            case 19: //yyyy/MM/dd HH:mm:ss
                HH = Integer.parseInt(strDate.substring(11,13));
                mm = Integer.parseInt(strDate.substring(14,16));
                ss = Integer.parseInt(strDate.substring(17,19));
                cal.set(Calendar.HOUR_OF_DAY,HH);
                cal.set(Calendar.MINUTE,mm);
                cal.set(Calendar.SECOND,ss);
                break;
            case 23: //yyyy/MM/dd HH:mm:ss.SSS
                HH = Integer.parseInt(strDate.substring(11,13));
                mm = Integer.parseInt(strDate.substring(14,16));
                ss = Integer.parseInt(strDate.substring(17,19));
                SSS = Integer.parseInt(strDate.substring(20,23));
                cal.set(Calendar.HOUR_OF_DAY,HH);
                cal.set(Calendar.MINUTE,mm);
                cal.set(Calendar.SECOND,ss);
                cal.set(Calendar.MILLISECOND,SSS);
                break;
            default :
                throw new IllegalArgumentException(
                        "引数の文字列["+ strDate +
                        "]は日付文字列に変換できません");
        }
        return cal;
    }

    /**
     * 様々な日付、時刻文字列をデフォルトの日付・時刻フォーマット
     * へ変換します。
     * 
     * ●デフォルトの日付フォーマットは以下になります。
     *     日付だけの場合：yyyy/MM/dd
     *     日付+時刻の場合：yyyy/MM/dd HH:mm:ss.SSS
     * 
     * @param str 変換対象の文字列
     * @return デフォルトの日付・時刻フォーマット
     * @throws IllegalArgumentException 
     *     日付文字列が変換不可能な場合 
     */
    private static String format(String str){
        if (str == null || str.trim().length() < 8) {
            throw new IllegalArgumentException(
                    "引数の文字列["+ str +
                    "]は日付文字列に変換できません");
        }
        str = str.trim();
        String yyyy = null; String MM = null; String dd = null; 
        String HH = null; String mm = null; 
        String ss = null;String SSS = null;  
        // "-" or "/" が無い場合
        if (str.indexOf("/")==-1 && str.indexOf("-")==-1) {
            if (str.length() == 8) {
                yyyy = str.substring(0,4);
                MM = str.substring(4,6);
                dd = str.substring(6,8);
                return yyyy+"/"+MM+"/"+dd;
            }
            yyyy = str.substring(0,4);
            MM = str.substring(4,6);
            dd = str.substring(6,8);
            HH = str.substring(9,11);
            mm = str.substring(12,14);
            ss = str.substring(15,17);
            return yyyy+"/"+MM+"/"+dd+" "+HH+":"+mm+":"+ss;
        }
        StringTokenizer token = new StringTokenizer(str,"_/-:. ");
        StringBuffer result = new StringBuffer();
        for(int i = 0; token.hasMoreTokens(); i++) {
            String temp = token.nextToken();
            switch(i){
                case 0:// 年の部分
                    yyyy = fillString(str, temp, "L", "20", 4);
                    result.append(yyyy);  
                    break;
                case 1:// 月の部分
                    MM = fillString(str, temp, "L", "0", 2); 
                    result.append("/"+MM);  
                    break;
                case 2:// 日の部分
                    dd = fillString(str, temp, "L", "0", 2); 
                    result.append("/"+dd);  
                    break;
                case 3:// 時間の部分
                    HH = fillString(str, temp, "L", "0", 2);
                    result.append(" "+HH);  
                    break;
                case 4:// 分の部分
                    mm = fillString(str, temp, "L", "0", 2); 
                    result.append(":"+mm);  
                    break;
                case 5:// 秒の部分
                    ss = fillString(str, temp, "L", "0", 2); 
                    result.append(":"+ss);  
                    break;
                case 6:// ミリ秒の部分
                    SSS = fillString(str, temp, "R", "0", 3); 
                    result.append("."+SSS);  
                    break;
            }
        }
        return result.toString();
    }
    private static String fillString(String strDate, String str, 
                                 String position, String addStr, 
                                 int len){
        if (str.length() > len) {
            throw new IllegalArgumentException(
                "引数の文字列["+ strDate +
                "]は日付文字列に変換できません");
        }
        return fillString(str, position, len,addStr);
    }

    /**
     * 文字列[str]に対して、補充する文字列[addStr]を 
     * [position]の位置に[len]に満たすまで挿入します。
     * 
     * ※[str]がnullや空リテラルの場合でも[addStr]を
     * [len]に満たすまで挿入した結果を返します。
     * @param str 対象文字列
     * @param position 前に挿入 ⇒ L or l 後に挿入 ⇒ R or r
     * @param len 補充するまでの桁数
     * @param addStr 挿入する文字列
     * @return 変換後の文字列。
     */
    private static String fillString(String str, String position, 
            int len,
            String addStr) {
        if (addStr == null || addStr.length() == 0) {
            throw new IllegalArgumentException
                ("挿入する文字列の値が不正です。addStr="+addStr);
        }
        if (str == null) {
            str = "";
        }
        StringBuffer buffer = new StringBuffer(str);
        while (len > buffer.length()) {
            if (position.equalsIgnoreCase("l")) {
                int sum = buffer.length() + addStr.length();
                if (sum > len) {
                    addStr = addStr.substring
                        (0,addStr.length() - (sum - len));
                    buffer.insert(0, addStr);
                }else{
                    buffer.insert(0, addStr);
                }
            } else {
                buffer.append(addStr);
            }
        }
        if (buffer.length() == len) {
            return buffer.toString();
        }
        return buffer.toString().substring(0, len);
    }

    public static Date getFirstDayOfCurrentMonth(Date currentDate) {
    	Calendar cal = Calendar.getInstance();

    	//年月をセットする
    	cal.setTime(currentDate);

    	int year = cal.get(Calendar.YEAR);
    	int month = cal.get(Calendar.MONTH);
    	int date = 1;
    	cal.set(year, month, date, 0, 0, 0);

    	return cal.getTime();
    }

    public static Date getFirstDayOfNextMonth(Date currentDate) {
    	Calendar cal = Calendar.getInstance();

    	//年月をセットする
    	cal.setTime(currentDate);

    	int year = cal.get(Calendar.YEAR);
    	int month = cal.get(Calendar.MONTH);
    	int date = 1;
    	cal.set(year, month, date, 0, 0, 0);
    	cal.add(Calendar.MONTH, 1);
    	return cal.getTime();
    }

}
