package jp.co.sharedsys.common.exception;

public class InvalidPhonenumberException  extends SSException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 748445081644611532L;

	public InvalidPhonenumberException(String message){
		super(message);
	}	

}
