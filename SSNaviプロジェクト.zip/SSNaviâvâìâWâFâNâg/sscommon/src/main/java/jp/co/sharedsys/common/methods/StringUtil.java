package jp.co.sharedsys.common.methods;

import java.util.Date;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import java.text.NumberFormat;

public class StringUtil {
    
    /**
     * 文字判別、NULLと空文字[""]をTRUEで返却
     * @param inputString
     * @return TRUE or FALSE
     */
    public static boolean isEmpty(String inputString){
        return StringUtils.isEmpty(inputString);
    }
    
    /**
     * 文字判別、NULLと空文字[""]でない場合TRUEで返却
     * @param inputString
     * @return TRUE or FALSE
     */
    public static boolean isNotEmpty(String inputString){
        return StringUtils.isNotEmpty(inputString);
    }
    
    /**
     * 文字判別、空文字[""]の場合TRUEで返却
     * @param inputString
     * @return TRUE or FALSE
     */
    public static boolean isBlank(String inputString){
        return StringUtils.isBlank(inputString);
    }

    /**
     * 文字判別、空文字[""]でない場合TRUEで返却
     * @param inputString
     * @return TRUE or FALSE
     */
    public static boolean isNotBlank(String inputString){
        return StringUtils.isNotBlank(inputString);
    }

    /**
     * 半角アルファベット(記号は不可)を判別してTRUEを返却
     * @param inputString
     * @return TRUE or FALSE
     */
    public static boolean isAlpha(String inputString){
        return StringUtils.isAlpha(inputString);
    }

    /**
     * 数値を判別してTRUEを返却
     * @param inputString
     * @return TRUE or FALSE
     */
    public static boolean isNumeric(String inputString){
        return StringUtils.isNumeric(inputString);
    }   

    /**
     * 先頭、末尾の空白を取り除く
     * @param inputString
     * @return String
     */
    public static String trim(String inputString){
        return StringUtils.trim(inputString);
    }

    /**
     * 先頭、末尾の空白を取り除く(Nullまたは空文字[""]をNullで返す)
     * @param inputString
     * @return String
     */
    public static String trimToNull(String inputString){
        return StringUtils.trimToNull(inputString);
    }

    /**
     * 先頭、末尾の空白を取り除く(Nullまたは空文字[""]を空文字[""]で返す)
     * @param inputString
     * @return String
     */
    public static String trimToEmpty(String inputString){
        return StringUtils.trimToEmpty(inputString);
    }

    /**
     * 文字列の比較(Nullを含む)
     * @param inputString1 比較対象文字列
     * @param inputString2 比較対象文字列
     * @return String
     */
    public static boolean equals(String inputString1, String inputString2){
        return StringUtils.equals(inputString1, inputString2);
    }

    /**
     * 文字列(大文字、小文字を区別)の検索
     * @param targetString
     * @param saerchString
     * @return String
     */
    public static boolean contains(String targetString, String saerchString){
        return StringUtils.contains(targetString, saerchString);
    }

    /**
     * 文字列(大文字、小文字を区別なし)の検索
     * @param targetString
     * @param saerchString
     * @return String
     */
    public static boolean containsIgnoreCase(String targetString, String saerchString){
        return StringUtils.containsIgnoreCase(targetString, saerchString);
    }

    /**
     * 文字列を切り出す(終了位置は任意入力)
     * @param targetString
     * @param startInteger
     * @param endInteger
     * @return String
     */
    public static String substring(String targetString, Integer startInteger, Integer endInteger){
        
        if (targetString == null) return null;

        if (startInteger != null && endInteger != null){
            return StringUtils.substring(targetString, startInteger, endInteger);
        } else if (endInteger == null){
            return StringUtils.left(targetString, startInteger);
        } else if (startInteger == null){
            return StringUtils.right(targetString, endInteger);
        }
        return null;
    }

    /**
     * 文字列を連結
     * @param inputString1 連結対象文字列
     * @param inputString2 連結対象文字列
     * @return String
     */
    public static String join(String inputString1, String inputString2){
        return StringUtils.join(inputString1, inputString2);
    }

    /**
     * 文字リストを改行付きでString変換
     * @param inputList
     * @return String
     */
    public static String listToStringNewLine(List<String> inputList){
        if (inputList == null) return null;
        return String.join("\n", inputList);
    }

    /**
     * 文字リストをカンマ付きでString変換
     * @param inputList
     * @return String
     */
    public static String listToStringComma(List<String> inputList){
        if (inputList == null) return null;
        return String.join(",", inputList);
    }

    /**
     * 文字列を連結
     * @param inputString 変換対象文字列
     * @param replaceString1
     * @param replaceString2
     * @return String
     */
    public static String replace(String inputString, String replaceString1, String replaceString2){
        return StringUtils.replace(inputString, replaceString1, replaceString2);
    }
    
    /**
     * 文字列の長さを返却(Nullは0)
     * @param inputString
     * @return int 文字列の長さ
     */
    public static int length(String inputString){
        return StringUtils.length(inputString);
    }

    /**
     * Nullの場合、空文字[""]を返却
     * @param inputString
     * @return int 文字列の長さ
     */
    public static String defaultString(String inputString){
        return StringUtils.defaultString(inputString);
    }

    /**
     * Intteger型をString型へ変換
     * @param inputInteger
     * @return String
     */
    public static String typeIntToString(Integer inputInteger){
        if (inputInteger == null) return null;
        return inputInteger.toString();
    }
    
    /**
     * Intteger型をString型へ変換
     * @param inputString
     * @return Integer
     */
    public static Integer typeStringToInt(String inputString){
        if (inputString == null || !StringUtils.isNumeric(inputString)) return null;
        return Integer.valueOf(inputString);
    }
    
    /**
     * Date型をString型へ変換
     * @param inputDate
     * @return String
     */
    public static String typeDateToString(Date inputDate){
        if (inputDate == null) return null;
        return String.valueOf(inputDate);
    }
    
    /**
     * 数値入力から0埋めを行う
     * @param inputInteger 入力値
     * @param digit 桁
     * @return String
     */
    public static String numberZeroPad(Integer inputInteger, int digit){
        if (inputInteger == null) return null;
        return StringUtils.leftPad(inputInteger.toString(), digit, '0');

    }

    /**
     * 文字入力を左へ指定文字埋めして返却
     * @param inputString 入力値
     * @param pattern 埋める文字
     * @param digit 桁
     * @return String
     */
    public static String stringLeftPad(String inputString, char pattern, int digit){

        return StringUtils.leftPad(inputString, digit, pattern);

    }

    /**
     * 文字入力を右へ指定文字埋めして返却
     * @param inputString 入力値
     * @param pattern 埋める文字
     * @param digit 桁
     * @return String
     */
    public static String stringRightPad(String inputString, char pattern, int digit){

        return StringUtils.rightPad(inputString, digit, pattern);

    }

    /**
     * 文字入力を左に空白埋めして返却
     * @param inputString 入力値
     * @param digit 桁
     * @return String
     */
    public static String stringSpaceLeftPad(String inputString, int digit){

        return StringUtils.leftPad(inputString, digit);

    }

    /**
     * 文字入力を右に空白埋めして返却
     * @param inputString 入力値
     * @param digit 桁
     * @return String
     */
    public static String stringSpaceRightPad(String inputString, int digit){

        return StringUtils.rightPad(inputString, digit);

    }    
    
    /**
     * 数値入力をパーセントで返却
     * @param inputDouble 入力値
     * @return String
     */
    public static String stringFormatPerCent(Double inputDouble){
        NumberFormat numberFormat = NumberFormat.getPercentInstance();
        if (inputDouble == null) return null;

        numberFormat.setMaximumFractionDigits(2);
        return numberFormat.format(inputDouble);

    }
    
    /**
     * 数値入力をカンマ区切りで返却
     * @param inputInteger 入力値
     * @return String
     */
    public static String stringFormatComma(Integer inputInteger){

        if (inputInteger == null || !StringUtils.isNumeric(inputInteger.toString()) ) return null;
        return String.format("%,d", inputInteger);

    }
}
