package jp.co.sharedsys.common.methods;

import java.io.IOException;
import org.apache.commons.exec.*;

public class ExecUtil {
    
    /**
     * 指定された実行ファイルを実行する
     * @param inputPath
     * @return int 実行結果
     * @throws java.io.IOException
     */
    public static int execute(String inputPath) throws IOException{
        CommandLine commandLine = CommandLine.parse(inputPath);
        Executor exec = new DefaultExecutor();
        return exec.execute(commandLine);
    }
}
