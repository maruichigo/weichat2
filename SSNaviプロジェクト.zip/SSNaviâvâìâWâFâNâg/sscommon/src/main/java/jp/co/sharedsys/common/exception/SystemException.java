package jp.co.sharedsys.common.exception;

public class SystemException extends SSException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2317882167274452392L;


//	public SystemException(){
//		super();
//	}
//	
//	public SystemException(Throwable cause){
//		
//	}	
//
	public SystemException(String message){
		super(message);
	}	

	public SystemException(String message, Throwable cause){
		super(message, cause);
	}	

}
