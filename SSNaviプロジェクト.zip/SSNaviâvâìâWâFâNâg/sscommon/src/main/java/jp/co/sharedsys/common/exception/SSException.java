package jp.co.sharedsys.common.exception;

import jp.co.sharedsys.common.log.LOG;

public abstract class SSException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3993622295651009379L;

	private static final String SYSTEM_ERROR_MSG = "SSExceptionにThrowableが指定されていません。";
	
//	public SSException(){
//		super();
//	}
//	
//	public SSException(Throwable cause){
//		super(cause);
//	}
//	
	public SSException(String message){
		super(message);
		LOG.info(message);
	}
	
	public SSException(String message, Throwable cause){
		super(message,cause);
		if(cause != null){
			cause.printStackTrace();
			LOG.error(message);
			if(cause.getCause() != null){
				LOG.error(cause.getCause().getMessage());
			} else {
				LOG.error(cause.getMessage());
			}
		} else {
			LOG.error(SYSTEM_ERROR_MSG);
		}

	}
}
