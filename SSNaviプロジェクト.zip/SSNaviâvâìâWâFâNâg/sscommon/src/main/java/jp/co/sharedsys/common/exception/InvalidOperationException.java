package jp.co.sharedsys.common.exception;

public class InvalidOperationException  extends SSException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6704987376192367227L;

//	public InvalidOperationException(){
//		super();
//	}
//	
//	public InvalidOperationException(Throwable cause){
//		
//	}	
//
	public InvalidOperationException(String message){
		super(message);
	}	

	//	public InvalidOperationException(String message, Throwable cause){
//		super(message, cause);
//	}	
}
