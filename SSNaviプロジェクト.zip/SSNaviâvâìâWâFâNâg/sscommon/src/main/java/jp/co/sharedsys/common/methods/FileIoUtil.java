package jp.co.sharedsys.common.methods;

import java.io.File;
import java.io.IOException;
import java.util.List;
import org.apache.commons.io.FileUtils;

public class FileIoUtil {
    
    final public static String UTF8 =  "UTF-8";
    final public static String SJIS = "SJIS";

    /**
     * 指定されたディレクトリパスからファイルコピーを実行する
     * @param srcDirPath コピー元パス
     * @param destDirPath コピー先パス
     * @return File
     * @throws java.io.IOException
     */
    public static File copyDirectory(String srcDirPath, String destDirPath) throws IOException{
        File srcDir = new File(srcDirPath);
        File destDir = new File(destDirPath);
        FileUtils.copyDirectory(srcDir, destDir);
        return destDir;
    }
    
    /**
     * 指定されたファイルパスからファイルコピーを実行する
     * @param srcFilePath コピー元ファイルパス
     * @param destFilePath コピー先ファイルパス
     * @return File
     * @throws java.io.IOException
     */
    public static File copyFile(String srcFilePath, String destFilePath) throws IOException{
        File srcFile = new File(srcFilePath);
        File destFile = new File(destFilePath);
        FileUtils.copyFile(srcFile, destFile);
        return destFile;
    }

    /**
     * 指定されたディレクトリパスからディレクトリの再帰削除を実行する
     * @param srcDirPath ディレクトリパス
     * @throws java.io.IOException
     */
    public static void deleteDirectory(String srcDirPath) throws IOException{
        FileUtils.deleteDirectory(new File(srcDirPath));
    }

    /**
     * 指定されたファイルパスからファイル削除を実行する
     * @param srcFilePath ファイルパス
     * @throws java.io.IOException
     */
    public static void forceDelete(String srcFilePath) throws IOException{
        FileUtils.forceDelete(new File(srcFilePath));
    }

    /**
     * 指定されたディレクトリパスからディレクトリを作成する
     * @param srcDirPath ディレクトリパス
     * @throws java.io.IOException
     */
    public static void forceMkdir(String srcDirPath) throws IOException{
        FileUtils.forceMkdir(new File(srcDirPath));
    }

    /**
     * 指定されたディレクトリパスから移動(リネーム)を実行する
     * @param srcDirPath 元ディレクトリ
     * @param destDirPath 移動先(リネーム後)ディレクトリ
     * @return File
     * @throws java.io.IOException
     */
    public static File moveDirectory(String srcDirPath, String destDirPath) throws IOException{
        File srcDir = new File(srcDirPath);
        File destDir = new File(destDirPath);
        FileUtils.moveDirectory(srcDir, destDir);
        return destDir;
    }
    
    /**
     * 指定されたファイルパスからファイルコピーを実行する
     * @param srcFilePath コピー元ファイルパス
     * @param destFilePath コピー先ファイルパス
     * @return File
     * @throws java.io.IOException
     */
    public static File moveFile(String srcFilePath, String destFilePath) throws IOException{
        File srcFile = new File(srcFilePath);
        File destFile = new File(destFilePath);
        FileUtils.moveFile(srcFile, destFile);
        return destFile;
    }

    /**
     * 指定されたファイルパスから読み込み情報を返却する
     * @param srcFilePath ファイルパス
     * @param encodeString 文字コード
     * @return List
     * @throws java.io.IOException
     */
    public static List<String> readLines(String srcFilePath, String encodeString) throws IOException{
        return FileUtils.readLines(new File(srcFilePath), encodeString);
    }
    
    /**
     * 指定されたファイルパスから読み込み情報を返却する
     * @param srcFilePath ファイルパス
     * @param encodeString 文字コード
     * @return String
     * @throws java.io.IOException
     */
    public static String readFileToString(String srcFilePath, String encodeString) throws IOException{
        return FileUtils.readFileToString(new File(srcFilePath), encodeString);
    }

    /**
     * 出力文字リストを指定されたファイルパスへ出力する
     * @param srcFilePath ファイルパス
     * @param writeList 出力文字リスト
     * @param encodeString 文字コード
     * @throws java.io.IOException
     */
    public static void writeLines(String srcFilePath, List<String> writeList, String encodeString) throws IOException{
        FileUtils.writeLines(new File(srcFilePath), encodeString, writeList);
    }
        
    /**
     * 出力文字リストを指定されたファイルパスへ出力する
     * @param srcFilePath ファイルパス
     * @param writeString 出力文字
     * @param encodeString 文字コード
     * @throws java.io.IOException
     */
    public static void writeFile(String srcFilePath, String writeString, String encodeString) throws IOException{
        FileUtils.writeStringToFile(new File(srcFilePath), writeString, encodeString);
    }
}
