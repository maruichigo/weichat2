package jp.co.kintetsuls.dao.common;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jp.co.sharedsys.ssframe.dao.BaseDao;

import jp.co.kintetsuls.service.model.common.ComCreateListDef;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/** ファンクションマスタテーブル処理クラス
 * @author S.Nagai
 *
 */
@Repository
public class ComCreateListDao extends BaseDao<ComCreateListDef> {

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    public ComCreateListDef create(ComCreateListDef entity) {
        return entity;
    }

    public ComCreateListDef update(ComCreateListDef entity) {
        return entity;
    }

    public ComCreateListDef softDelete(ComCreateListDef entity) {
        return entity;
    }

    public void delete(String id) {
    }

    public List<ComCreateListDef> findAll() {
        return null;
    }

    @Override
    public ComCreateListDef findById(ComCreateListDef entity) {
        return null;
    }

    @Override
    public List<ComCreateListDef> findByColumn(ComCreateListDef entity) {
        return null;
    }

    @Override
    public List<ComCreateListDef> find(ComCreateListDef entity, String sqlId) {
        return null;
    }

    @Override
    public List<ComCreateListDef> updateByColumn(ComCreateListDef searchCriteria, ComCreateListDef entity) {
        return null;
    }

    @Override
    public void deleteByColumn(ComCreateListDef entity) {
    }

    @Override
    public List<ComCreateListDef> softDeleteByColumn(ComCreateListDef entity) {
        return null;
    }

    @Override
    public List<ComCreateListDef> insert(List<ComCreateListDef> entity, String sqlId) {
        return null;
    }

    @Override
    public List<ComCreateListDef> insert(ComCreateListDef entity, String sqlId) {
        return null;
    }

    @Override
    public List<ComCreateListDef> update(ComCreateListDef searchCriteria, ComCreateListDef entity, String sqlId) {
        return null;
    }
	
    public List<ComCreateListDef> findByUserGroup(@Param("userGroupCodes") List<String> userGroupCodes) {
        return null;
    }
	
    public List<Map<String, String>> findForSearch(Map<String, Object> searchCriteria) {
            return null;
    }
    public List<Map<String, String>> findForSearch(Map<String, Object> searchCriteria, String sqlId) {
            return getSqlSession().selectList("createList." + sqlId, searchCriteria);		
    }    
}
