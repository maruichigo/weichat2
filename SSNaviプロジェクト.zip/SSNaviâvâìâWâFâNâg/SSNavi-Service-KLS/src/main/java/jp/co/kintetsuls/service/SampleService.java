package jp.co.kintetsuls.service;

import javax.servlet.ServletContext;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.ServletContextAware;
import org.springframework.web.context.WebApplicationContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import jp.co.sharedsys.service.common.exception.SSServerErrorException;

/**
 * Sampleクラス
 *
 * @author sharedsys
 *
 */
@Component
@Path("/sample")
@Scope(value = WebApplicationContext.SCOPE_REQUEST)
public class SampleService implements ServletContextAware {

    @Context
    private ServletContext servletContext;

    @Override
    public void setServletContext(ServletContext servletContext) {
        this.servletContext = servletContext;
    }

    @POST
    @Path("/SampleWebService")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Transactional(propagation = Propagation.REQUIRED)
    public String baseService(String parameter) throws SSServerErrorException {

        return "test_" + parameter;
    }

}
