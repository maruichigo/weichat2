/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.service.model.biz_common;

import java.io.Serializable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "authorityComponent")
public class AuthorityComponent implements Serializable{
    
    private static final long serialVersionUID = 3144615551515151L;

    /** ユーザーID */
    private String userCd;

    /** スクリーンコード */
    private String screenCode;
    /** rptのコンポーネントname */
    private String componentName;
    /** 利用設定   0:利用不可(非表示), 1:表示のみ, 2:利用可能 */
    private int riyoSettei;

    public String getUserCd() {
        return userCd;
    }

    public void setUserCd(String userCd) {
        this.userCd = userCd;
    }

    public String getScreenCode() {
        return screenCode;
    }

    public void setScreenCode(String screenCode) {
        this.screenCode = screenCode;
    }

    public String getComponentName() {
        return componentName;
    }

    public void setComponentName(String componentName) {
        this.componentName = componentName;
    }

    public int getRiyoSettei() {
        return riyoSettei;
    }

    public void setRiyoSettei(int riyoSettei) {
        this.riyoSettei = riyoSettei;
    }
}
