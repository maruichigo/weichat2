package jp.co.kintetsuls.service.model.table;

import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import jp.co.sharedsys.service.model.BaseModel;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "msSystemMessage")
public class MsSystemMessage extends BaseModel {

	private String messageId;
	private String messageShubetsu;
	private String torokuUser;
	private Date torokuNichiji;
	private String torokuTammatsu;
	private String koshinUser;
	private String koshinTammatsu;
	private String saishuOperationUser;
	private Date koshinNichiji;
	private String messageBun;
	private String sakujoFlg;
	private String koshinCounter;
	private Date saishuOperationKoshinNichiji;

	public String getMessageId() {
		return this.messageId;
	}

	public String getMessageShubetsu() {
		return this.messageShubetsu;
	}

	public String getTorokuUser() {
		return this.torokuUser;
	}

	public Date getTorokuNichiji() {
		return this.torokuNichiji;
	}

	public String getTorokuTammatsu() {
		return this.torokuTammatsu;
	}

	public String getKoshinUser() {
		return this.koshinUser;
	}

	public String getKoshinTammatsu() {
		return this.koshinTammatsu;
	}

	public String getSaishuOperationUser() {
		return this.saishuOperationUser;
	}

	public Date getKoshinNichiji() {
		return this.koshinNichiji;
	}

	public String getMessageBun() {
		return this.messageBun;
	}

	public String getSakujoFlg() {
		return this.sakujoFlg;
	}

	public String getKoshinCounter() {
		return this.koshinCounter;
	}

	public Date getSaishuOperationKoshinNichiji() {
		return this.saishuOperationKoshinNichiji;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public void setMessageShubetsu(String messageShubetsu) {
		this.messageShubetsu = messageShubetsu;
	}

	public void setTorokuUser(String torokuUser) {
		this.torokuUser = torokuUser;
	}

	public void setTorokuNichiji(Date torokuNichiji) {
		this.torokuNichiji = torokuNichiji;
	}

	public void setTorokuTammatsu(String torokuTammatsu) {
		this.torokuTammatsu = torokuTammatsu;
	}

	public void setKoshinUser(String koshinUser) {
		this.koshinUser = koshinUser;
	}

	public void setKoshinTammatsu(String koshinTammatsu) {
		this.koshinTammatsu = koshinTammatsu;
	}

	public void setSaishuOperationUser(String saishuOperationUser) {
		this.saishuOperationUser = saishuOperationUser;
	}

	public void setKoshinNichiji(Date koshinNichiji) {
		this.koshinNichiji = koshinNichiji;
	}

	public void setMessageBun(String messageBun) {
		this.messageBun = messageBun;
	}

	public void setSakujoFlg(String sakujoFlg) {
		this.sakujoFlg = sakujoFlg;
	}

	public void setKoshinCounter(String koshinCounter) {
		this.koshinCounter = koshinCounter;
	}

	public void setSaishuOperationKoshinNichiji(Date saishuOperationKoshinNichiji) {
		this.saishuOperationKoshinNichiji = saishuOperationKoshinNichiji;
	}

}
