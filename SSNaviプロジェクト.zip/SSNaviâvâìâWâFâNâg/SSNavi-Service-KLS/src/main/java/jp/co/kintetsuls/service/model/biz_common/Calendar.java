package jp.co.kintetsuls.service.model.biz_common;

import java.io.Serializable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/** 
 * 営業日カレンダーマスタクラス
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "calendar")
public class Calendar implements Serializable{

    private static final long serialVersionUID = 8965633291910057625L;

    @NotNull
 //   private String nengappi; // PK

/*    private String kyujitsuFlg;
    private String nichiyoFlg;
    private String shukujitsuFlg;
    
    @Size(max = 20)
    private String shukujitsuMeisho;

    private String uriageShimebiFlg;
    private String shinseiStatus;
*/
    // カレンダー色変更json用
    private String year;
    private String month;
    private String day;
    private String holiday;
    
/*    @XmlElement(name = "nengappi")
    public String getNengappi() {
        return nengappi;
    }
    public void setNengappi(String nengappi) {
        this.nengappi = nengappi;
    }
    @XmlElement(name = "kyujitsuFlg")
    public String getKyujitsuFlg() {
        return kyujitsuFlg;
    }
    public void setKyujitsuFlg(String kyujitsuFlg) {
        this.kyujitsuFlg = kyujitsuFlg;
    }
    @XmlElement(name = "nichiyoFlg")
    public String getNichiyoFlg() {
        return nichiyoFlg;
    }
    public void setNichiyoFlg(String nichiyoFlg) {
        this.nichiyoFlg = nichiyoFlg;
    }
    @XmlElement(name = "shukujitsuFlg")
    public String getShukujitsuFlg() {
        return shukujitsuFlg;
    }
    public void setShukujitsuFlg(String shukujitsuFlg) {
        this.shukujitsuFlg = shukujitsuFlg;
    }
    @XmlElement(name = "shukujitsuMeisho")
    public String getShukujitsuMeisho() {
        return shukujitsuMeisho;
    }
    public void setShukujitsuMeisho(String shukujitsuMeisho) {
        this.shukujitsuMeisho = shukujitsuMeisho;
    }
    @XmlElement(name = "uriageShimebiFlg")
    public String getUriageShimebiFlg() {
        return uriageShimebiFlg;
    }
    public void setUriageShimebiFlg(String uriageShimebiFlg) {
        this.uriageShimebiFlg = uriageShimebiFlg;
    }
    @XmlElement(name = "shinseiStatus")
    public String getShiseiStatus() {
        return shinseiStatus;
    }
    public void setShinseiStatus(String shinseiStatus) {
        this.shinseiStatus = shinseiStatus;
    }*/

    @XmlElement(name = "year")
    public String getYear(){
        return year;
    }
    public void setYear(String year){
        this.year = year;
    }
    @XmlElement(name = "month")
    public String getMonth(){
        return month;
    }
    public void setMonth(String month){
        this.month = month;
    }
    @XmlElement(name = "day")
    public String getDay(){
        return day;
    }
    public void setDay(String day){
        this.day = day;
    }
    @XmlElement(name = "holiday")
    public String getHoliday(){
        return holiday;
    }
    public void setHoliday(String holiday){
        this.holiday = holiday;
    }

}
