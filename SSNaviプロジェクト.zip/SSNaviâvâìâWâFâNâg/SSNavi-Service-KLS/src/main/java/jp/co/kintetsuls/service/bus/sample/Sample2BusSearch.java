/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.service.bus.sample;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import jp.co.kintetsuls.dao.Sample2Dao;
import jp.co.kintetsuls.service.model.Sample2Def;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.ssframe.dao.Dao;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

@Component("FUNC_PATTERNB_SEARCH")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Sample2BusSearch extends SampleBus {

    @Autowired(required=true)
    @Resource(shareable=true)
    protected Dao<Sample2Def> sample2Dao;
    
    private Map<String, Object> params = null;
    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        super.init(serviceInterfaceBean);
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);        
        
    }
    
    @Override
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        List<Map<String, String>> resultList = ((Sample2Dao) sample2Dao).searchForList(params);
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));       
        System.out.print("★Sample2BusSearch：Header");
    }    
}
