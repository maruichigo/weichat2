/**
 *
 */
package jp.co.sharedsys.kintetsuls.common.util;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
 
@Aspect
@Component
public class ServiceLogInterceptor {
    private final Logger logger;

    public ServiceLogInterceptor(){
        this.logger = LoggerFactory.getLogger(ServiceLogInterceptor.class);
    }

    @Before("execution(* jp.co.kintetsuls.service.*.*(..))")
    public void invokeBefore(JoinPoint joinPoint) {
        System.out.println("Before:");
        methodLog(joinPoint.getTarget().getClass().toString(), joinPoint.getSignature().getName(), "start");
    }

    @After("execution(* jp.co.kintetsuls.service.*.*(..))")
    public void invokeAfter(JoinPoint joinPoint) {
        System.out.println("After:");
        methodLog(joinPoint.getTarget().getClass().toString(), joinPoint.getSignature().getName(), "end");
    }

    @AfterThrowing(value = "execution(* jp.co.kintetsuls.service.*.*(..))", throwing = "e")
    public void afterThrowing(JoinPoint joinPoint, Exception e) {
        System.out.println("AfterThrowing:");
        methodLog(joinPoint.getTarget().getClass().toString(), joinPoint.getSignature().getName(), "exception");
        logger.error(e.getMessage(), e);
    }

    private void methodLog(String className, String methodName, String message){
        logger.info(className + "." + methodName + "() " + message + ".");
    }
}
