package jp.co.kintetsuls.dao.biz_common;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.service.model.biz_common.Menu;
import jp.co.sharedsys.ssframe.dao.BaseDao;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/** ファンクションマスタテーブル処理クラス
 *
 */
@Repository
public class MenuDao extends BaseDao<Menu> {

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    public Menu create(Menu menu) {
        getSqlSession().insert("menu.create", menu);
        return menu;
    }

    public Menu update(Menu menu) {
        getSqlSession().update("menu.update", menu);
        return menu;
    }

    public Menu softDelete(Menu menu) {
        getSqlSession().update("menu.softDelete", menu);
        return menu;
    }

    public void delete(String id) {
        getSqlSession().delete("menu.delete", id);
    }

    public List<Menu> findAll() {
        return getSqlSession().selectList("menu.findAll");
    }

    @Override
    public Menu findById(Menu entity) {
        return getSqlSession().selectOne("menu.findById", entity);
    }

    @Override
    public List<Menu> findByColumn(Menu entity) {
        return getSqlSession().selectList("menu.findByColumn", entity);
    }

    @Override
    public List<Menu> find(Menu entity, String sqlId) {
        return getSqlSession().selectList(sqlId, entity);
    }

    @Override
    public List<Menu> updateByColumn(Menu searchCriteria, Menu entity) {
        Map<String, Object> map = new HashMap<>();
        map.put("crt", searchCriteria);
        map.put("upd", entity);
        getSqlSession().update("function.updateByColumn",map);
        return findByColumn(entity);
    }

    @Override
    public void deleteByColumn(Menu entity) {
        getSqlSession().delete("function.deleteByColumn",entity);
    }

    @Override
    public List<Menu> softDeleteByColumn(Menu entity) {
        getSqlSession().update("function.softDeleteByColumn", entity);
        return findByColumn(entity);
    }

    
 
    public List<Menu> getAvailableMenu(String userCd){
	return getSqlSession().selectList("menu.getAvailableMenu", userCd);
    }


    @Override
    public List<Menu> update(Menu searchCriteria, Menu entity, String sqlId) {
	throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Menu> insert(List<Menu> entity, String sqlId) {
	throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Menu> insert(Menu entity, String sqlId) {
	throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
