package jp.co.kintetsuls.service.mapper.dem;

import jp.co.sharedsys.service.mapper.IMapper;
import org.springframework.stereotype.Component;

/**
 * Mybatis 共通申請 Mapper
 * @author sharedsys
 */
@Component("dem012")
public interface Dem012Mapper extends IMapper {
    
}
