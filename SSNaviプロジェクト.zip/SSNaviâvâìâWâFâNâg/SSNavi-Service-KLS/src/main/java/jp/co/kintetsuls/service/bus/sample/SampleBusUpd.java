/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.service.bus.sample;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import jp.co.kintetsuls.dao.SampleDao;
import jp.co.kintetsuls.service.model.SampleDef;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.exception.SystemException;
import jp.co.sharedsys.common.methods.SSCommonUtil;
import jp.co.sharedsys.service.mapper.IMapper;
import jp.co.sharedsys.ssframe.dao.Dao;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

@Component("SAMPLE_UPD")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class SampleBusUpd extends SampleBus {
    protected final String TABLE_NAME = "TABLE_NAME";

    //　新規追加
    @Autowired(required=true)
    @Resource(shareable=true)
    protected Dao<SampleDef> dao;
    
    private IMapper mapForTarget(String target) {
        IMapper mapper =(IMapper)this.getWebApplicationContext().getBean(target);
        if (mapper != null) {
            return mapper;
        }
        throw new UnsupportedOperationException("unsupported table");
    }
//    private SampleMapper targetMapper;
    
    private Map<String, Object> params = null;
    private List<Map<String, Object>> inputParams = null;
    
    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        super.init(serviceInterfaceBean);
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
        for (Iterator<String> ite = params.keySet().iterator();ite.hasNext();) {
            String key = ite.next();
            if (TABLE_NAME.equals(key)) {
//                targetMapper = this.mapForTarget((String) params.get(key));
            } else {
                inputParams = (List)params.get(key);
            }
        }
    }
    
    @Override
    public void saveDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
//        List<Map<String, String>> resultList = ((SampleDao) sampleDao).updateForList(params);
        List<Map> result = null;
        for (Map input : inputParams) {
            input.put("UserCd", serviceInterfaceBean.getUserCd());
            if ( input.get("newrow") != null && (Boolean)input.get("newrow") ) {
                ((SampleDao) dao).insertForList(input);
            } else {
                List<Map> check = ((SampleDao) dao).findForSearch(input, "findById");
                boolean isUpdate = false;
                if (check != null && !check.isEmpty()) {
                    for (Iterator<String> ite = check.get(0).keySet().iterator(); ite.hasNext();) {
                        String key = ite.next();
                        String camelizedKey = SSCommonUtil.camelize(key);
                        if (input.get(camelizedKey) == null) {
                            continue;
                        }
                        if (!String.valueOf(input.get(camelizedKey)).equals(String.valueOf(check.get(0).get(key)))) {
                            // DBの値と違うものがあれば更新対象とする
                            isUpdate = true;
                            break;
                        }
                    }
                    if (isUpdate) {
                        ((SampleDao) dao).updateForList(input);
                    }
                } else {
            		throw new SystemException("更新対象のキーが存在しませんでした。");
                }
            }
        }
        serviceInterfaceBean.setMessage("データの登録・更新に成功しました");
    }    
}
