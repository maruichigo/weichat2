package jp.co.kintetsuls.service.model.table;

import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import jp.co.sharedsys.service.model.BaseModel;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "msSystem")
public class MsSystem extends BaseModel {

	private String cdGroup;
	private String cd;
	private String val;

	private String torokuUser;
	private Date torokuNichiji;
	private String torokuTammatsu;
	private String koshinUser;
	private String koshinTammatsu;
	private String saishuOperationUser;
	private Date koshinNichiji;
	private String sakujoFlg;
	private String koshinCounter;
	private Date saishuOperationKoshinNichiji;

	/**
	 * @return the cdGroup
	 */
	public String getCdGroup() {
		return cdGroup;
	}

	/**
	 * @param cdGroup the cdGroup to set
	 */
	public void setCdGroup(String cdGroup) {
		this.cdGroup = cdGroup;
	}

	/**
	 * @return the cd
	 */
	public String getCd() {
		return cd;
	}

	/**
	 * @param cd the cd to set
	 */
	public void setCd(String cd) {
		this.cd = cd;
	}

	/**
	 * @return the val
	 */
	public String getVal() {
		return val;
	}

	/**
	 * @param val the val to set
	 */
	public void setVal(String val) {
		this.val = val;
	}

	/**
	 * @return the torokuUser
	 */
	public String getTorokuUser() {
		return torokuUser;
	}

	/**
	 * @param torokuUser the torokuUser to set
	 */
	public void setTorokuUser(String torokuUser) {
		this.torokuUser = torokuUser;
	}

	/**
	 * @return the torokuNichiji
	 */
	public Date getTorokuNichiji() {
		return torokuNichiji;
	}

	/**
	 * @param torokuNichiji the torokuNichiji to set
	 */
	public void setTorokuNichiji(Date torokuNichiji) {
		this.torokuNichiji = torokuNichiji;
	}

	/**
	 * @return the torokuTammatsu
	 */
	public String getTorokuTammatsu() {
		return torokuTammatsu;
	}

	/**
	 * @param torokuTammatsu the torokuTammatsu to set
	 */
	public void setTorokuTammatsu(String torokuTammatsu) {
		this.torokuTammatsu = torokuTammatsu;
	}

	/**
	 * @return the koshinUser
	 */
	public String getKoshinUser() {
		return koshinUser;
	}

	/**
	 * @param koshinUser the koshinUser to set
	 */
	public void setKoshinUser(String koshinUser) {
		this.koshinUser = koshinUser;
	}

	/**
	 * @return the koshinTammatsu
	 */
	public String getKoshinTammatsu() {
		return koshinTammatsu;
	}

	/**
	 * @param koshinTammatsu the koshinTammatsu to set
	 */
	public void setKoshinTammatsu(String koshinTammatsu) {
		this.koshinTammatsu = koshinTammatsu;
	}

	/**
	 * @return the saishuOperationUser
	 */
	public String getSaishuOperationUser() {
		return saishuOperationUser;
	}

	/**
	 * @param saishuOperationUser the saishuOperationUser to set
	 */
	public void setSaishuOperationUser(String saishuOperationUser) {
		this.saishuOperationUser = saishuOperationUser;
	}

	/**
	 * @return the koshinNichiji
	 */
	public Date getKoshinNichiji() {
		return koshinNichiji;
	}

	/**
	 * @param koshinNichiji the koshinNichiji to set
	 */
	public void setKoshinNichiji(Date koshinNichiji) {
		this.koshinNichiji = koshinNichiji;
	}

	/**
	 * @return the sakujoFlg
	 */
	public String getSakujoFlg() {
		return sakujoFlg;
	}

	/**
	 * @param sakujoFlg the sakujoFlg to set
	 */
	public void setSakujoFlg(String sakujoFlg) {
		this.sakujoFlg = sakujoFlg;
	}

	/**
	 * @return the koshinCounter
	 */
	public String getKoshinCounter() {
		return koshinCounter;
	}

	/**
	 * @param koshinCounter the koshinCounter to set
	 */
	public void setKoshinCounter(String koshinCounter) {
		this.koshinCounter = koshinCounter;
	}

	/**
	 * @return the saishuOperationKoshinNichiji
	 */
	public Date getSaishuOperationKoshinNichiji() {
		return saishuOperationKoshinNichiji;
	}

	/**
	 * @param saishuOperationKoshinNichiji the saishuOperationKoshinNichiji to
	 * set
	 */
	public void setSaishuOperationKoshinNichiji(Date saishuOperationKoshinNichiji) {
		this.saishuOperationKoshinNichiji = saishuOperationKoshinNichiji;
	}

}
