package jp.co.kintetsuls.service.mapper;

import jp.co.kintetsuls.service.mapper.mst.*;
import jp.co.sharedsys.service.mapper.IMapper;
import org.springframework.stereotype.Component;

/**
 * Mybatis 単量画面履歴表示サンプル用 Mapper
 * @author sharedsys
 */
@Component("SampleForHistory")
public interface SampleMapperForHistory extends IMapper {
    
}
