package jp.co.kintetsuls.service.mapper.biz_common;

import jp.co.sharedsys.service.mapper.IMapper;
import org.springframework.stereotype.Component;

/**
 * Mybatis 顧客一覧 Mapper
 * @author sharedsys
 */
@Component("calendar")
public interface CalendarMapper extends IMapper {
    
}
