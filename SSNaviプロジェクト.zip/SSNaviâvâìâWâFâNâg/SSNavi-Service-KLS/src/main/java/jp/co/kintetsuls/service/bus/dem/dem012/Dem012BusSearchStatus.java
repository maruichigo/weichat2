/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.service.bus.dem.dem012;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import jp.co.kintetsuls.dao.dem.Dem012Dao;
import jp.co.kintetsuls.service.model.dem.Dem012Def;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.ssframe.dao.Dao;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
/** 
 *  共通申請　初期処理　承認状況領域表示データ検索
 */
@Component("DEM012_SEARCH_STATUS")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Dem012BusSearchStatus extends Dem012Bus {

    @Autowired(required=true)
    @Resource(shareable=true)
    protected Dao<Dem012Def> dem012Dao;
    
    private Map<String, Object> params = null;
    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        super.init(serviceInterfaceBean);
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);        
        
    }
    
    @Override
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        List<Map<String, String>> resultList = ((Dem012Dao) dem012Dao).findForSearch(params, "searchForList");
//        resultList.
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));       
        System.out.print("★共通申請　申請状況領域　検索：saveHeader");
    }    
}
