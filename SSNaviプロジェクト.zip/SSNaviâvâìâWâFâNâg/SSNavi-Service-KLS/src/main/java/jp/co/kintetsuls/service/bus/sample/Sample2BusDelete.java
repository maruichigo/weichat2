package jp.co.kintetsuls.service.bus.sample;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import jp.co.kintetsuls.dao.Sample2Dao;
import jp.co.kintetsuls.dao.SampleDao;
import jp.co.kintetsuls.service.model.Sample2Def;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.exception.SystemException;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.common.methods.SSCommonUtil;
import jp.co.sharedsys.service.mapper.IMapper;
import jp.co.sharedsys.ssframe.dao.Dao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

@Component("FUNC_PATTERNB_DELETE")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Sample2BusDelete extends SampleBus {
    //選択データ
    protected static final String SELECTED_NODE = "SELECTED_NODE";
    
    @Autowired(required=true)
    @Resource(shareable=true)
    protected Dao<Sample2Def> sample2Dao;
    private List<Map<String, Object>> selectdatas;
    
    private Map<String, Object> params = null;
    
    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        super.init(serviceInterfaceBean);
        ObjectMapper mapper = new ObjectMapper();//#{pageBean.selectedNodes
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);        
        if (0 != params.size()){
            selectdatas = (List<Map<String, Object>>)params.get(SELECTED_NODE); 
        }
    }
    
    @Override
    public String validateHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        StringBuffer message = new StringBuffer();
        if (0 == selectdatas.size()){
            message.append("選択されていません");
        }
        return message.toString();
    }

    @Override
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        
        List<Sample2Def> itemlist = new ArrayList<Sample2Def>();
        for (Map<String,Object> mapline : selectdatas){
            String tablename = (String)mapline.get("TABLENAME");
            Sample2Def model = new Sample2Def();
            String sid = String.valueOf(mapline.get("COLUMN1"));
            if ("SAMPLE2".equals(tablename)){
                model.setHid(sid);
            } else if ("SAMPLE2_DETAIL".equals(tablename)){
                model.setDid(sid);

            } else if ("SAMPLE2_MAGO_DETAIL".equals(tablename)){
                model.setMid(sid);
            }
            itemlist.add(model);
        }
        //削除処理
        ((Sample2Dao) sample2Dao).softDeleteList(itemlist);
        //再取得処理
        List<Map<String, String>> resultList = ((Sample2Dao) sample2Dao).searchForList(params);
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));   
        
        serviceInterfaceBean.setMessage("データの登録・更新に成功しました");
    }    
}
