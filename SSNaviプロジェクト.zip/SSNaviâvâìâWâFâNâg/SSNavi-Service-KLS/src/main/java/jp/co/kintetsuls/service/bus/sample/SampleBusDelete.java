/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.service.bus.sample;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import jp.co.kintetsuls.dao.SampleDao;
import jp.co.kintetsuls.service.model.SampleDef;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.exception.SystemException;
import jp.co.sharedsys.ssframe.dao.Dao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

@Component("SAMPLE_DEL")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class SampleBusDelete extends SampleBus {
    //選択データ
    protected static final String SELECTED_NODE = "SELECTED_NODE";

    //　新規追加
    @Autowired(required=true)
    @Resource(shareable=true)
    protected Dao<SampleDef> dao;
    private List<Map<String, Object>> selectdatas = null;
    private Map<String, Object> params = null;
    
    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        super.init(serviceInterfaceBean);
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);       
        if (0 != params.size()){
            selectdatas = (List<Map<String, Object>>)params.get(SELECTED_NODE); 
        }
        //serviceInterfaceBean.getUserCd() UserCdをとる場合
    }
    
    @Override
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        // 新規作成行の場合は何もしない。
        // IDが存在する場合だけ削除処理を実施する。
        
        for (Map input : selectdatas) {
            if (input.get("newrow") != null && Boolean.valueOf((String)input.get("newrow"))) {
                 //新規追加行の場合は何もしない
            } else {
                List<Map> check = ((SampleDao) dao).findForSearch(input, "findById");
                if (check != null && !check.isEmpty()) {
                    ((SampleDao) dao).findForSearch(input, "softDelete");
                } else {
                    throw new SystemException("更新対象のキーが存在しませんでした。");
                }
            }
        }
        serviceInterfaceBean.setMessage("データの登録・更新に成功しました");
    }    
}
