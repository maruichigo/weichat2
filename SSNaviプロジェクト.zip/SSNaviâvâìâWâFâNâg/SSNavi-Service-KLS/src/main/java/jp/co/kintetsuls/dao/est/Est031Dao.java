/**
 *
 */
package jp.co.kintetsuls.dao.est;

import jp.co.kintetsuls.dao.est.*;
import jp.co.kintetsuls.dao.est.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.service.model.est.Est031Def;
import jp.co.sharedsys.ssframe.dao.BaseDao;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class Est031Dao extends BaseDao<Est031Def>{

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    public Est031Def create(Est031Def entity) {
        getSqlSession().insert("est031.create", entity);
        return entity;
    }

    public Est031Def update(Est031Def entity) {
        getSqlSession().update("est031.update", entity);
        return entity;
    }

    public Est031Def softDelete(Est031Def entity) {
    	getSqlSession().update("est031.softDelete", entity);
        return entity;
    }

    public void delete(String id) {
        getSqlSession().delete("est031.delete",id);
    }

    public List<Est031Def> findAll() {
        return getSqlSession().selectList("est031.findAll");
    }
    
    public Est031Def findById(Est031Def entity) {
        return getSqlSession().selectOne("est031.findById", entity);
    }

    public List<Est031Def> findByColumn(Est031Def entity) {
        return getSqlSession().selectList("est031.findByColumn", entity);
    }

    public List<Est031Def> find(Est031Def entity, String sqlId) {
        return getSqlSession().selectList("est031.find", entity);
    }

    @Override
    public List<Est031Def> updateByColumn(Est031Def searchCriteria, Est031Def entity) {
        Map<String, Object> map = new HashMap<>();
        map.put("crt", searchCriteria);
        map.put("upd", entity);
        getSqlSession().update("est031.updateByColumn",map);
        return findByColumn(entity);        
    }

    @Override
    public void deleteByColumn(Est031Def entity) {
        getSqlSession().delete("est031.deleteByColumn",entity);
    }

    @Override
    public List<Est031Def> softDeleteByColumn(Est031Def entity) {
        getSqlSession().update("est031.softDeleteByColumn", entity);
        return findByColumn(entity);
    }

    @Override
    public List<Est031Def> insert(List<Est031Def> entity, String sqlId) {
        return null;
    }

    @Override
    public List<Est031Def> insert(Est031Def entity, String sqlId) {
        return null;
    }
    
    @Override
    public List<Est031Def> update(Est031Def searchCriteria, Est031Def entity, String sqlId) {
        return null;
    }

    public List<Map<String, String>> findForSearch(Map<String, Object> searchCriteria, String sqlId) {
        return getSqlSession().selectList("est031." + sqlId, searchCriteria);		
    }

    public List<Map<String, String>> findForSearch(Map<String,Object> searchCriteria) {
            return getSqlSession().selectList("est031.findToMap", searchCriteria);		
    }

    //新規追加
    public Est031Def updateForList(Est031Def entity) {
        getSqlSession().update("est031.updateForList", entity);
        return entity;
    }
    
    //新規追加
    public Est031Def softDeleteForList(Est031Def entity) {
    	getSqlSession().update("est031.softDeleteForList", entity);
        return entity;
    }

    /**
     *
     * @return
     */
    @Override
    public String tableName() {
        return "est031";
    }    

    // 新規追加
    public void updateForList(Map input) {
        getSqlSession().update("est031.updateForList", input);
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    // 新規追加
    public void softDeleteForList(Map input) {
        getSqlSession().update("est031.softDeleteForList", input);
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
