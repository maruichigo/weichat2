package jp.co.kintetsuls.dao.biz_common;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.service.model.biz_common.Office;
import jp.co.sharedsys.ssframe.dao.BaseDao;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/** Kinoテーブル処理クラス
 *
 */
@Repository
public class OfficeDao extends BaseDao<Office> {

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    //public List<Office> getAccessibleOffice(String userCd){
    //    return getSqlSession().selectList("office.getAccessibleOffice", userCd);
    //}
    public List<Map<String, String>> getAccessibleOffice(String userCd){
        return getSqlSession().selectList("office.getAccessibleOffice", userCd);
    }
    
    public String getDefaultEigyosho(String userCd){
        return getSqlSession().selectOne("office.getDefaultEigyosho", userCd);
    }

    @Override
    public Office create(Office entity) {
        return null;
    }

    @Override
    public Office findById(Office entity) {
        return null;
    }

    @Override
    public List<Office> findByColumn(Office entity) {
        return null;
    }

    @Override
    public List<Office> find(Office entity, String sqlId) {
        return null;
    }

    @Override
    public Office update(Office entity) {
        return null;
    }

    @Override
    public List<Office> updateByColumn(Office searchCriteria, Office entity) {
        return null;
    }

    @Override
    public List<Office> update(Office searchCriteria, Office entity, String sqlId) {
        return null;
    }

    @Override
    public List<Office> insert(List<Office> entity, String sqlId) {
        return null;
    }

    @Override
    public List<Office> insert(Office entity, String sqlId) {
        return null;
    }

    @Override
    public void delete(String id) {
    }

    @Override
    public void deleteByColumn(Office entity) {
    }

    @Override
    public Office softDelete(Office entity) {
        return null;
    }

    @Override
    public List<Office> softDeleteByColumn(Office entity) {
        return null;
    }

    @Override
    public List<Office> findAll() {
        return null;
    }


}
