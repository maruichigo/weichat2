/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.service.model.biz_common;

import jp.co.kintetsuls.service.model.table.*;
import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import jp.co.sharedsys.service.model.BaseModel;
import lombok.Data;

/**
 * システムマスタBean
 *
 */
@Data
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "systemMst")
public class SystemMstDef extends BaseModel implements Serializable {

    private static final long serialVersionUID = 1L;

    private String cdGroup; // コードグループ    
    private String cd; // コード
    private String val; // 値

}
