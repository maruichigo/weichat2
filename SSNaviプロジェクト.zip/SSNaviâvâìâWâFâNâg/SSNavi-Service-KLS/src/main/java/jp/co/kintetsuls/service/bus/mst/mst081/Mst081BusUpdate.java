/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.service.bus.mst.mst081;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import jp.co.kintetsuls.dao.mst.Mst081Dao;
import jp.co.kintetsuls.service.bus.sample.SampleBus;
import jp.co.kintetsuls.service.model.mst.Mst081Def;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.exception.SystemException;
import jp.co.sharedsys.common.methods.SSCommonUtil;
import jp.co.sharedsys.ssframe.dao.Dao;
import jp.co.sharedsys.service.mapper.IMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.service.mapper.mst.Mst081Mapper;
/** 
 * 顧客集約設定マスタ　更新ボタン押下時処理
 */
@Component("MST081_UPDATE")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Mst081BusUpdate  extends Mst081Bus {
    protected final String TABLE_NAME = "TABLE_NAME";
    
    //　新規追加
    @Autowired(required=true)
    @Resource(shareable=true)
    protected Dao<Mst081Def> kokyakuShuyakuDao;
    
    private IMapper mapForTarget(String target) {
        IMapper mapper =(IMapper)this.getWebApplicationContext().getBean(target);
        if (mapper != null) {
            return mapper;
        }
        throw new UnsupportedOperationException("unsupported table");
    }
    private IMapper targetMapper;
    
    private Map<String, Object> params = null;
    private List<Map<String, Object>> inputParams = null;
    
    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
	super.init(serviceInterfaceBean);
	ObjectMapper mapper = new ObjectMapper();
	params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
        for (Iterator<String> ite = params.keySet().iterator();ite.hasNext();) {
            String key = ite.next();
            if (TABLE_NAME.equals(key)) {
//                targetMapper = this.mapForTarget((String) params.get(key));
            } else {
                inputParams = (List)params.get(key);
            }
        }
        // TODO 一覧内の集約コードが空のデータに値の変更があった場合
    }
    
    @Override
    public String validateHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
	return "";
    }
	
    @Override
    public String validateDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
	return "";
    }

    @Override
    public String validateHeaderByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
	return "";
    };

    @Override
    public String validateDetailByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
	return "";
    };

    @Override
    /** 
     * 検索
     * @param serviceInterfaceBean リクエストパラメータ
     * @throws Exception
     */
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        List<Map> result = null;
        
        List<Map> chgList = new ArrayList<>();
        for (Map input : inputParams) {
            List keys = new ArrayList(input.keySet());
            Map<String, Object> chgMap = new LinkedHashMap<>();
            for (Iterator<String> ite = keys.iterator(); ite.hasNext();) {
                String key = ite.next();
                chgMap.put(SSCommonUtil.camelize(key), input.get(key));
            }
            chgList.add(chgMap);
        }
        

        for (Map input : chgList) {
            input.put("UserCd", serviceInterfaceBean.getUserCd());
            
            System.out.println(input.get("shuyakuCd"));
            // 営業所コードの切り出し
            String eigyoshoCd = (String) input.get("eigyosho");
            input.replace("eigyosho", eigyoshoCd.substring(0, 3));
            
            if (input.get("shuyakuCd").toString().length() > 10){
                //　集約コードの切り出し(map)
                Map<String, String> shuyakuCd = (Map<String, String>) input.get("shuyakuCd");
                String shuyakuCdVal = shuyakuCd.get("label");
                input.replace("shuyakuCd", shuyakuCdVal);
            }
           
            
//            //　集約コードの切り出し(String)
//            String shuyakuCd = (String) input.get("shuyakuCd");
//            input.replace("shuyakuCd", shuyakuCd);
            
//            if (input.get("newrow") != null && Boolean.valueOf((String)input.get("newrow"))) {
////                targetMapper.insert(input);
//                ((KokyakuShuyakuSetteiDao) kokyakuShuyakuDao).insert(input);
//            } else {
//                List<Map> check = targetMapper.findById(input);
//                if (check != null && !check.isEmpty()) {
//                    targetMapper.updateForList(input);
                    ((Mst081Dao) kokyakuShuyakuDao).updateForList(input);
//                } else {
//                    throw new SystemException("更新対象のキーが存在しませんでした。");
//                }
//            }
        }
        serviceInterfaceBean.setMessage("データの登録・更新に成功しました");
    }

    @Override
    public void saveDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }

    @Override
    public void setValidaterFactory() throws Exception {
    }
    
    @Override
    public void confirm(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }    
}

