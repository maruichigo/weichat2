package jp.co.kintetsuls.service.model;

import jp.co.kintetsuls.service.model.mst.*;
import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

//import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import jp.co.sharedsys.service.constraintannotation.PrimaryKey;
import jp.co.sharedsys.service.model.BaseModel;
import lombok.Data;

/** 
 * Sample model
 * @author sharedsys
 */
@Data
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "SampleForHistory")
public class SampleForHistoryDef extends BaseModel implements Serializable{

    private static final long serialVersionUID = 8225066323266437322L;
    
    @PrimaryKey(columnName = "id")
    private String id;
    private String dateValue;
    private String value1;
    private String value2;
    private String value3;
}
