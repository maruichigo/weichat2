/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.service.bus.mst.mst081;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import jp.co.kintetsuls.dao.mst.Mst081Dao;
import jp.co.kintetsuls.service.bus.sample.SampleBus;
import jp.co.kintetsuls.service.model.mst.Mst081Def;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.ssframe.dao.Dao;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
/** 
 *  顧客集約設定マスタ　検索ボタン押下時処理
 */
@Component("MST081_SEARCH")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Mst081BusSearch extends Mst081Bus {

    @Autowired(required=true)
    @Resource(shareable=true)
    protected Dao<Mst081Def> kokyakuShuyakuDao;
    
    private Map<String, Object> params = null;
    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        super.init(serviceInterfaceBean);
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);        
        
    }
    
    @Override
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        List<Map<String, String>> resultList = ((Mst081Dao) kokyakuShuyakuDao).findForSearch(params, "searchForList");
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));    
    }    
}
