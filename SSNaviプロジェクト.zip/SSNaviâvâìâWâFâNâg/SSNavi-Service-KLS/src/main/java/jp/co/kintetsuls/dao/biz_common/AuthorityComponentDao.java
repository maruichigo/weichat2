package jp.co.kintetsuls.dao.biz_common;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.service.model.biz_common.AuthorityComponent;
import jp.co.sharedsys.ssframe.dao.BaseDao;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/** Kinoテーブル処理クラス
 *
 */
@Repository
public class AuthorityComponentDao extends BaseDao<AuthorityComponent> {

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    public List<AuthorityComponent> getAuthorityComponent(String userCd){
        return getSqlSession().selectList("authorityComponent.getAuthorityComponent", userCd);
    }

    @Override
    public AuthorityComponent create(AuthorityComponent entity) {
        return null;
    }

    @Override
    public AuthorityComponent findById(AuthorityComponent entity) {
        return null;
    }

    @Override
    public List<AuthorityComponent> findByColumn(AuthorityComponent entity) {
        return null;
    }

    @Override
    public List<AuthorityComponent> find(AuthorityComponent entity, String sqlId) {
        return null;
    }

    @Override
    public AuthorityComponent update(AuthorityComponent entity) {
        return null;
    }

    @Override
    public List<AuthorityComponent> updateByColumn(AuthorityComponent searchCriteria, AuthorityComponent entity) {
        return null;
    }

    @Override
    public List<AuthorityComponent> update(AuthorityComponent searchCriteria, AuthorityComponent entity, String sqlId) {
        return null;
    }

    @Override
    public List<AuthorityComponent> insert(List<AuthorityComponent> entity, String sqlId) {
        return null;
    }

    @Override
    public List<AuthorityComponent> insert(AuthorityComponent entity, String sqlId) {
        return null;
    }

    @Override
    public void delete(String id) {
    }

    @Override
    public void deleteByColumn(AuthorityComponent entity) {
    }

    @Override
    public AuthorityComponent softDelete(AuthorityComponent entity) {
        return null;
    }

    @Override
    public List<AuthorityComponent> softDeleteByColumn(AuthorityComponent entity) {
        return null;
    }

    @Override
    public List<AuthorityComponent> findAll() {
        return null;
    }


}
