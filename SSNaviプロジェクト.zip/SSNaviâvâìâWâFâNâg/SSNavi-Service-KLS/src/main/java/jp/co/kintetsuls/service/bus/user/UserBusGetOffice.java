package jp.co.kintetsuls.service.bus.user;

import java.util.List;
import java.util.HashMap;
import java.util.Map;
import jp.co.kintetsuls.dao.common.ComCreateListDao;
import jp.co.kintetsuls.service.model.biz_common.Office;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;

/**
 * 権限取得処理クラス
 * 
 * @author s_furutani
 */
@Component("USER_GET_ACCESSIBLE_OFFICE")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class UserBusGetOffice extends UserBus {

    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        UserCd = serviceInterfaceBean.getUserCd();
    }
    @Override
    public String validateHeaderByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }
    @Override
    public String validateDetailByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    /** 営業所リストの取得
     * @param serviceInterfaceBean リクエストパラメータ
     * @throws Exception 
     */
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        // 営業所リストの取得
        //List<Office> list = officeDao.getAccessibleOffice(serviceInterfaceBean.getUserCd());
        List<Map<String, String>> list = officeDao.getAccessibleOffice(serviceInterfaceBean.getUserCd());

        // デフォルト営業所の取得
        String defaultEigyosho = officeDao.getDefaultEigyosho(serviceInterfaceBean.getUserCd());
        //Office defoffice = new Office(){{ setEigyoshoCd(defaultEigyosho); }};
        Map<String, String> defoffice = new HashMap<String, String>(){{ put("VALUE", defaultEigyosho); }};

        // listの0番目に追加(呼び出し元で分離)
        list.add(0, defoffice);
        // 格納返却
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(list));
    }

    @Override
    public void saveDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }
    @Override
    public void confirm(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }

}