package jp.co.kintetsuls.service.bus.user;

import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import com.fasterxml.jackson.databind.ObjectMapper;
import jp.co.kintetsuls.dao.biz_common.MenuDao;
import jp.co.kintetsuls.dao.biz_common.AuthorityComponentDao;
import jp.co.kintetsuls.dao.biz_common.OfficeDao;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.service.bus.SSFrameBusBase;
import jp.co.sharedsys.ssframe.dao.Dao;
import jp.co.sharedsys.ssframe.dao.FunctionDao;
import jp.co.sharedsys.ssframe.model.User;

/**
 * @author saihara
 *
 */
public abstract class UserBus extends SSFrameBusBase  {

    // Dao定義
    @Autowired(required=true)
    @Resource(shareable=true)
    protected Dao<User> userDao;

    @Autowired(required=true)
    @Resource(shareable=true)
    protected FunctionDao functionDao;
	
    @Autowired(required=true)
    @Resource(shareable=true)
    protected MenuDao menuDao;

    @Autowired(required=true)
    @Resource(shareable=true)
    protected AuthorityComponentDao authCompDao;

    @Autowired(required=true)
    @Resource(shareable=true)
    protected OfficeDao officeDao;

    // パラメーターで渡されるヘッダー格納用オブジェクト
    protected User user;

    // passwordのMD5化に使用されるキー値
    protected static final String PASSWD_ENCRYPT_KEY = "1v6ii4Q2QMt=";
    protected static final String STATUS_PASS_WILL_EXPIRE = "6";
    
    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
            ObjectMapper mapper = new ObjectMapper();
            user = mapper.readValue(serviceInterfaceBean.getJson(), User.class);
    }

    @Override
    public void setValidaterFactory() throws Exception {
    }

    @Override
    public String validateHeaderByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
            return validateByAnnotation(user);
    }

    @Override
    public String validateDetailByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
            StringBuffer message = new StringBuffer();
            return message.toString();
    }


    @Override
    public String validateHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
            StringBuffer message = new StringBuffer();
            return message.toString();
    }

    @Override
    public String validateDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
            StringBuffer message = new StringBuffer();
            return message.toString();
    }

    @Override
    public abstract void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception;

    @Override
    public abstract void saveDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception;

    @Override
    public String finalProc(ServiceInterfaceBean serviceInterfaceBean) throws Exception{
        return "";
    }
        
}
