package jp.co.kintetsuls.service.model.table;

import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import jp.co.sharedsys.service.model.BaseModel;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "msKbn")
public class MsKbn extends BaseModel {

	private String kbnGroupCd;
	private String kbnGroupMei;
	private String kbnCd;
	private String kbnMei;
	private String kbnKey;

	private String torokuUser;
	private Date torokuNichiji;
	private String torokuTammatsu;
	private String koshinUser;
	private String koshinTammatsu;
	private String saishuOperationUser;
	private Date koshinNichiji;
	private String sakujoFlg;
	private String koshinCounter;
	private Date saishuOperationKoshinNichiji;

	/**
	 * @return the kbnGroupCd
	 */
	public String getKbnGroupCd() {
		return kbnGroupCd;
	}

	/**
	 * @param kbnGroupCd the kbnGroupCd to set
	 */
	public void setKbnGroupCd(String kbnGroupCd) {
		this.kbnGroupCd = kbnGroupCd;
	}

	/**
	 * @return the kbnGroupMei
	 */
	public String getKbnGroupMei() {
		return kbnGroupMei;
	}

	/**
	 * @param kbnGroupMei the kbnGroupMei to set
	 */
	public void setKbnGroupMei(String kbnGroupMei) {
		this.kbnGroupMei = kbnGroupMei;
	}

	/**
	 * @return the kbnCd
	 */
	public String getKbnCd() {
		return kbnCd;
	}

	/**
	 * @param kbnCd the kbnCd to set
	 */
	public void setKbnCd(String kbnCd) {
		this.kbnCd = kbnCd;
	}

	/**
	 * @return the kbnMei
	 */
	public String getKbnMei() {
		return kbnMei;
	}

	/**
	 * @param kbnMei the kbnMei to set
	 */
	public void setKbnMei(String kbnMei) {
		this.kbnMei = kbnMei;
	}

	/**
	 * @return the kbnKey
	 */
	public String getKbnKey() {
		return kbnKey;
	}

	/**
	 * @param kbnKey the kbnKey to set
	 */
	public void setKbnKey(String kbnKey) {
		this.kbnKey = kbnKey;
	}

	/**
	 * @return the torokuUser
	 */
	public String getTorokuUser() {
		return torokuUser;
	}

	/**
	 * @param torokuUser the torokuUser to set
	 */
	public void setTorokuUser(String torokuUser) {
		this.torokuUser = torokuUser;
	}

	/**
	 * @return the torokuNichiji
	 */
	public Date getTorokuNichiji() {
		return torokuNichiji;
	}

	/**
	 * @param torokuNichiji the torokuNichiji to set
	 */
	public void setTorokuNichiji(Date torokuNichiji) {
		this.torokuNichiji = torokuNichiji;
	}

	/**
	 * @return the torokuTammatsu
	 */
	public String getTorokuTammatsu() {
		return torokuTammatsu;
	}

	/**
	 * @param torokuTammatsu the torokuTammatsu to set
	 */
	public void setTorokuTammatsu(String torokuTammatsu) {
		this.torokuTammatsu = torokuTammatsu;
	}

	/**
	 * @return the koshinUser
	 */
	public String getKoshinUser() {
		return koshinUser;
	}

	/**
	 * @param koshinUser the koshinUser to set
	 */
	public void setKoshinUser(String koshinUser) {
		this.koshinUser = koshinUser;
	}

	/**
	 * @return the koshinTammatsu
	 */
	public String getKoshinTammatsu() {
		return koshinTammatsu;
	}

	/**
	 * @param koshinTammatsu the koshinTammatsu to set
	 */
	public void setKoshinTammatsu(String koshinTammatsu) {
		this.koshinTammatsu = koshinTammatsu;
	}

	/**
	 * @return the saishuOperationUser
	 */
	public String getSaishuOperationUser() {
		return saishuOperationUser;
	}

	/**
	 * @param saishuOperationUser the saishuOperationUser to set
	 */
	public void setSaishuOperationUser(String saishuOperationUser) {
		this.saishuOperationUser = saishuOperationUser;
	}

	/**
	 * @return the koshinNichiji
	 */
	public Date getKoshinNichiji() {
		return koshinNichiji;
	}

	/**
	 * @param koshinNichiji the koshinNichiji to set
	 */
	public void setKoshinNichiji(Date koshinNichiji) {
		this.koshinNichiji = koshinNichiji;
	}

	/**
	 * @return the sakujoFlg
	 */
	public String getSakujoFlg() {
		return sakujoFlg;
	}

	/**
	 * @param sakujoFlg the sakujoFlg to set
	 */
	public void setSakujoFlg(String sakujoFlg) {
		this.sakujoFlg = sakujoFlg;
	}

	/**
	 * @return the koshinCounter
	 */
	public String getKoshinCounter() {
		return koshinCounter;
	}

	/**
	 * @param koshinCounter the koshinCounter to set
	 */
	public void setKoshinCounter(String koshinCounter) {
		this.koshinCounter = koshinCounter;
	}

	/**
	 * @return the saishuOperationKoshinNichiji
	 */
	public Date getSaishuOperationKoshinNichiji() {
		return saishuOperationKoshinNichiji;
	}

	/**
	 * @param saishuOperationKoshinNichiji the saishuKoshinNichiji to set
	 */
	public void setSaishuOperationKoshinNichiji(Date saishuOperationKoshinNichiji) {
		this.saishuOperationKoshinNichiji = saishuOperationKoshinNichiji;
	}

}
