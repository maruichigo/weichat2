/**
 *
 */
package jp.co.kintetsuls.dao.mst;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.service.model.mst.Mst081Def;
import jp.co.sharedsys.ssframe.dao.BaseDao;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class Mst081Dao extends BaseDao<Mst081Def>{

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    public Mst081Def create(Mst081Def entity) {
        getSqlSession().insert("mst081.create", entity);
        return entity;
    }

    public Mst081Def update(Mst081Def entity) {
        getSqlSession().update("mst081.update", entity);
        return entity;
    }

    public Mst081Def softDelete(Mst081Def entity) {
    	getSqlSession().update("mst081.softDelete", entity);
        return entity;
    }

    public void delete(String id) {
        getSqlSession().delete("mst081.delete",id);
    }

    public List<Mst081Def> findAll() {
        return getSqlSession().selectList("mst081.findAll");
    }
    
    public Mst081Def findById(Mst081Def entity) {
        return getSqlSession().selectOne("mst081.findById", entity);
    }

    public List<Mst081Def> findByColumn(Mst081Def entity) {
        return getSqlSession().selectList("mst081.findByColumn", entity);
    }

    public List<Mst081Def> find(Mst081Def entity, String sqlId) {
        return getSqlSession().selectList("mst081.find", entity);
    }

    @Override
    public List<Mst081Def> updateByColumn(Mst081Def searchCriteria, Mst081Def entity) {
        Map<String, Object> map = new HashMap<>();
        map.put("crt", searchCriteria);
        map.put("upd", entity);
        getSqlSession().update("mst081.updateByColumn",map);
        return findByColumn(entity);        
    }

    @Override
    public void deleteByColumn(Mst081Def entity) {
        getSqlSession().delete("mst081.deleteByColumn",entity);
    }

    @Override
    public List<Mst081Def> softDeleteByColumn(Mst081Def entity) {
        getSqlSession().update("mst081.softDeleteByColumn", entity);
        return findByColumn(entity);
    }

    @Override
    public List<Mst081Def> insert(List<Mst081Def> entity, String sqlId) {
        return null;
    }

    @Override
    public List<Mst081Def> insert(Mst081Def entity, String sqlId) {
        return null;
    }
    
    @Override
    public List<Mst081Def> update(Mst081Def searchCriteria, Mst081Def entity, String sqlId) {
        return null;
    }

    public List<Map<String, String>> findForSearch(Map<String, Object> searchCriteria, String sqlId) {
        return getSqlSession().selectList("mst081." + sqlId, searchCriteria);		
    }

    public List<Map<String, String>> findForSearch(Map<String,Object> searchCriteria) {
            return getSqlSession().selectList("mst081.findToMap", searchCriteria);		
    }

    //新規追加
    public Mst081Def updateForList(Mst081Def entity) {
        getSqlSession().update("mst081.updateForList", entity);
        return entity;
    }
    
    //新規追加
    public Mst081Def softDeleteForList(Mst081Def entity) {
    	getSqlSession().update("mst081.softDeleteForList", entity);
        return entity;
    }

    /**
     *
     * @return
     */
    @Override
    public String tableName() {
        return "mst081";
    }    

    // 新規追加
    public void updateForList(Map input) {
        getSqlSession().update("mst081.updateForList", input);
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    // 新規追加
    public void softDeleteForList(Map input) {
        getSqlSession().update("mst081.softDeleteForList", input);
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
