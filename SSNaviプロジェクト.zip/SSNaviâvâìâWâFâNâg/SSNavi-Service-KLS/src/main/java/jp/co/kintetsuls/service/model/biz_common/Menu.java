package jp.co.kintetsuls.service.model.biz_common;

import java.io.Serializable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/** 
 * メニューマスタクラス
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "menu")
public class Menu implements Serializable{

    /**
     *
     */
    private static final long serialVersionUID = 8965633291910057625L;

    @NotNull
    @Size(max = 6)
    private String menuId;

    private String menuName;
    private String kinoCd;
    
    @Size(max = 20)
    private String parentGroupId;

    private String parentGroupName;
    private String parentIconPath;

    @Size(max = 20)
    private String childGroupId;

    private String childGroupName;
    private String childIconPath;

    private String rptDirectory;
    private String rptFileName;
    private String bridge;
		
    /**親メニューグループIDの取得
     * @return 親メニューグループID
     */
    @XmlElement(name = "parentGroupId")
    public String getParentGroupId() {
        return parentGroupId;
    }
    /**親メニューグループIDの設定
     * @param parentGroupId 親メニューグループID
     */
    public void setParentGroupId(String parentGroupId) {
        this.parentGroupId = parentGroupId;
    }
    /**親メニューグループ名の取得
     * @return 親メニューグループ名
     */
    @XmlElement(name = "parentGroupName")
    public String getParentGroupName() {
        return parentGroupName;
    }
    /**親メニューグループ名の設定
     * @param parentGroupName 親メニューグループ名
     */
    public void setParentGroupName(String parentGroupName) {
        this.parentGroupName = parentGroupName;
    }
    /**親アイコン画像パスの取得
     * @return 親アイコン画像パス
     */
    @XmlElement(name = "parentIconPath")
    public String getParentIconPath() {
        return parentIconPath;
    }
    /**親アイコン画像パスの設定
     * @param parentIconPath 親アイコン画像パス
     */
    public void setParentIconPath(String parentIconPath) {
        this.parentIconPath = parentIconPath;
    }
    /**子メニューグループIDの取得
     * @return 子メニューグループID
     */
    @XmlElement(name = "childGroupId")
    public String getChildGroupId() {
        return childGroupId;
    }
    /**子メニューグループIDの設定
     * @param childGroupId 子メニューグループID
     */
    public void setChildGroupId(String childGroupId) {
        this.childGroupId = childGroupId;
    }
    /**子メニューグループ名の取得
     * @return 子メニューグループ名
     */
    @XmlElement(name = "childGroupName")
    public String getChildGroupName() {
        return childGroupName;
    }
    /**子メニューグループ名の設定
     * @param childGroupName 子メニューグループ名
     */
    public void setChildGroupName(String childGroupName) {
        this.childGroupName = childGroupName;
    }
    /**子アイコン画像パスの取得
     * @return 子アイコン画像パス
     */
    @XmlElement(name = "childIconPath")
    public String getChildIconPath() {
        return childIconPath;
    }
    /**子アイコン画像パスの設定
     * @param childIconPath 子アイコン画像パス
     */
    public void setChildIconPath(String childIconPath) {
        this.childIconPath = childIconPath;
    }
    
    /**メニューIDの取得
     * @return メニューID
     */
    @XmlElement(name = "menuId")
    public String getMenuId() {
        return menuId;
    }
    /**メニューIDの設定
     * @param menuId メニューID
     */
    public void setMenuId(String menuId) {
        this.menuId = menuId;
    }
    /** メニュー名の取得
     * @return menuName
     */
    @XmlElement(name = "menuName")
    public String getMenuName() {
        return menuName;
    }
    /** メニュー名の設定
     * @param menuName メニュー名
     */
    public void setMenuName(String menuName) {
        this.menuName = menuName;
    }
    /** 機能コードの取得
     * @return kinoCd
     */
    @XmlElement(name = "kinoCd")
    public String getKinoCd() {
        return kinoCd;
    }
    /** 機能コードの設定
     * @param kinoCd 機能コード
     */
    public void setKinoCd(String kinoCd) {
        this.kinoCd = kinoCd;
    }
    /** rptディレクトリの取得
     * @return rptDirectory
     */
    @XmlElement(name = "rptDirectory")
    public String getRptDirectory() {
        return rptDirectory;
    }
    /** rptディレクトリの設定
     * @param rptDirectory rptディレクトリ
     */
    public void setRptDirectory(String rptDirectory) {
        this.rptDirectory = rptDirectory;
    }
    /** rptファイルの取得
     * @return rptFileName
     */
    @XmlElement(name = "rptFileName")
    public String getRptFileName() {
        return rptFileName;
    }
    /** rptファイルの設定
     * @param rptFileName rptファイル
     */
    public void setRptFileName(String rptFileName) {
        this.rptFileName = rptFileName;
    }

	/**
	 * ブリッジの取得
	 * @return 
	 */
	public String getBridge() {
		return bridge;
	}

	/**
	 * ブリッジの設定
	 * @param bridge 
	 */
	public void setBridge(String bridge) {
		this.bridge = bridge;
	}

}
