/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.service.model.biz_common;

import java.io.Serializable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "office")
public class Office implements Serializable{

    private static final long serialVersionUID = 593779985832909L;

    /** 営業所コード */
    private String eigyoshoCd;
    /** 営業所名 */
    private String eigyoshoMei;

    public String getEigyoshoCd() {
        return eigyoshoCd;
    }

    public void setEigyoshoCd(String eigyoshoCd) {
        this.eigyoshoCd = eigyoshoCd;
    }

    public String getEigyoshoMei() {
        return eigyoshoMei;
    }

    public void setEigyoshoMei(String eigyoshoMei) {
        this.eigyoshoMei = eigyoshoMei;
    }
}
