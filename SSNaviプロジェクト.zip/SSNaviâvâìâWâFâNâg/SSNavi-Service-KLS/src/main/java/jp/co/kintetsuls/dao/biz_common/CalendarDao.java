package jp.co.kintetsuls.dao.biz_common;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.service.model.biz_common.Calendar;
import jp.co.sharedsys.ssframe.dao.BaseDao;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/** ファンクションマスタテーブル処理クラス
 *
 */
@Repository
public class CalendarDao extends BaseDao<Calendar> {

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    public Calendar create(Calendar calendar) {
        getSqlSession().insert("calendar.create", calendar);
        return calendar;
    }

    public Calendar update(Calendar calendar) {
        getSqlSession().update("calendar.update", calendar);
        return calendar;
    }

    public Calendar softDelete(Calendar calendar) {
        getSqlSession().update("calendar.softDelete", calendar);
        return calendar;
    }

    public void delete(String id) {
        getSqlSession().delete("calendar.delete", id);
    }

    public List<Calendar> findAll() {
        return getSqlSession().selectList("calendar.findAll");
    }

    @Override
    public Calendar findById(Calendar entity) {
        return getSqlSession().selectOne("calendar.findById", entity);
    }

    @Override
    public List<Calendar> findByColumn(Calendar entity) {
        return getSqlSession().selectList("calendar.findByColumn", entity);
    }

    @Override
    public List<Calendar> find(Calendar entity, String sqlId) {
        return getSqlSession().selectList(sqlId, entity);
    }

    @Override
    public List<Calendar> updateByColumn(Calendar searchCriteria, Calendar entity) {
        Map<String, Object> map = new HashMap<>();
        map.put("crt", searchCriteria);
        map.put("upd", entity);
        getSqlSession().update("function.updateByColumn",map);
        return findByColumn(entity);
    }

    @Override
    public void deleteByColumn(Calendar entity) {
        getSqlSession().delete("function.deleteByColumn",entity);
    }

    @Override
    public List<Calendar> softDeleteByColumn(Calendar entity) {
        getSqlSession().update("function.softDeleteByColumn", entity);
        return findByColumn(entity);
    }

    
    public List<Calendar> getHolidays(){
	return getSqlSession().selectList("calendar.getHolidays");
    }


    @Override
    public List<Calendar> update(Calendar searchCriteria, Calendar entity, String sqlId) {
	throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Calendar> insert(List<Calendar> entity, String sqlId) {
	throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Calendar> insert(Calendar entity, String sqlId) {
	throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
