/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.service.bus.biz_common.Calendar;

import jp.co.kintetsuls.service.bus.cus.cus011.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import jp.co.kintetsuls.dao.biz_common.CalendarDao;
import jp.co.kintetsuls.service.model.biz_common.Calendar;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.ssframe.dao.Dao;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
/** 
 *  顧客一覧　検索ボタン押下時処理
 */
@Component("GET_HOLIDAYS")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class CalendarBusHoliday extends CalendarBus {

    @Autowired(required=true)
    @Resource(shareable=true)
    protected Dao<Calendar> calendarDao;
    
    private Map<String, Object> params = null;
    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        super.init(serviceInterfaceBean);
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);        
        
    }
    
    @Override
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        List<Calendar> resultList = ((CalendarDao) calendarDao).getHolidays();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));       
    }    
}
