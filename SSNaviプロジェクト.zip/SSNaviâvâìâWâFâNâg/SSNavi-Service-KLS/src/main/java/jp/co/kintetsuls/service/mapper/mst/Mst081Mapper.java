package jp.co.kintetsuls.service.mapper.mst;

import jp.co.sharedsys.service.mapper.IMapper;
import org.springframework.stereotype.Component;

/**
 * Mybatis 顧客集約設定 Mapper
 * @author sharedsys
 */
@Component("mst081")
public interface Mst081Mapper extends IMapper {
    
}
