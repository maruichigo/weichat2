/**
 *
 */
package jp.co.kintetsuls.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.service.model.SampleDef;
import jp.co.sharedsys.ssframe.dao.BaseDao;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class SampleDao extends BaseDao<SampleDef>{

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    public SampleDef create(SampleDef entity) {
        getSqlSession().insert("sample.create", entity);
        return entity;
    }

    public SampleDef update(SampleDef entity) {
        getSqlSession().update("sample.update", entity);
        return entity;
    }

    public SampleDef softDelete(SampleDef entity) {
    	getSqlSession().update("sample.softDelete", entity);
        return entity;
    }

    public void delete(String id) {
        getSqlSession().delete("sample.delete",id);
    }

    public List<SampleDef> findAll() {
        return getSqlSession().selectList("sample.findAll");
    }
    
    public SampleDef findById(SampleDef entity) {
        return getSqlSession().selectOne("sample.findById", entity);
    }

    public List<SampleDef> findByColumn(SampleDef entity) {
        return getSqlSession().selectList("sample.findByColumn", entity);
    }

    public List<SampleDef> find(SampleDef entity, String sqlId) {
        return getSqlSession().selectList("sample.find", entity);
    }

    @Override
    public List<SampleDef> updateByColumn(SampleDef searchCriteria, SampleDef entity) {
        Map<String, Object> map = new HashMap<>();
        map.put("crt", searchCriteria);
        map.put("upd", entity);
        getSqlSession().update("sample.updateByColumn",map);
        return findByColumn(entity);        
    }

    @Override
    public void deleteByColumn(SampleDef entity) {
        getSqlSession().delete("sample.deleteByColumn",entity);
    }

    @Override
    public List<SampleDef> softDeleteByColumn(SampleDef entity) {
        getSqlSession().update("sample.softDeleteByColumn", entity);
        return findByColumn(entity);
    }

    @Override
    public List<SampleDef> insert(List<SampleDef> entity, String sqlId) {
        return null;
    }

    @Override
    public List<SampleDef> insert(SampleDef entity, String sqlId) {
        return null;
    }
    
    @Override
    public List<SampleDef> update(SampleDef searchCriteria, SampleDef entity, String sqlId) {
        return null;
    }

    public List<Map<String, String>> findForSearch(Map<String, Object> searchCriteria, String sqlId) {
        return getSqlSession().selectList("sample." + sqlId, searchCriteria);		
    }

    public List<Map<String, String>> findForSearch(Map<String,Object> searchCriteria) {
        return getSqlSession().selectList("sample.findToMap", searchCriteria);		
    }    

    //新規追加
    public SampleDef updateForList(SampleDef entity) {
        getSqlSession().update("sample.updateForList", entity);
        return entity;
    }    
    
    /**
     *
     * @return
     */
    @Override
    public String tableName() {
        return "sample";
    }    
    
    public void insertForList(Map<String, Object> params) {
        getSqlSession().update("sample.insertForList", params);
    }
    
    public void updateForList(Map<String, Object> params) {
        getSqlSession().update("sample.updateForList", params);
    }
    
    public void softDeleteForList(Map input) {
        getSqlSession().update("sample.softDeleteForList", input);
    }
}
