/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.service.bus.sample.historySample;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import jp.co.kintetsuls.dao.SampleForHistoryDao;
import jp.co.kintetsuls.service.model.SampleForHistoryDef;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.ssframe.dao.Dao;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
/** 
 *  単票画面履歴検索サンプル
 */
@Component("SAMPLE_HISTORY_REPORT1")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ListSearch extends SampleBase {

    @Autowired(required=true)
    @Resource(shareable=true)
    protected Dao<SampleForHistoryDef> sampleForHistoryDao;
    
    private Map<String, Object> params = null;
    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        super.init(serviceInterfaceBean);
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);        
    }
    
    @Override
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        SampleForHistoryDao tempDao = (SampleForHistoryDao)sampleForHistoryDao;
        List<Map<String, String>> resultList = tempDao.findForSearch(params, "searchForList");
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
    }    
}
