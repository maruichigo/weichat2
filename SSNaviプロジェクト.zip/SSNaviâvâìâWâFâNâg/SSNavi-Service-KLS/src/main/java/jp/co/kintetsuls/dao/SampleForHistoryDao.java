/**
 *
 */
package jp.co.kintetsuls.dao;

import jp.co.kintetsuls.dao.mst.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.service.model.SampleForHistoryDef;
import jp.co.kintetsuls.service.model.mst.Mst081Def;
import jp.co.sharedsys.ssframe.dao.BaseDao;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class SampleForHistoryDao extends BaseDao<SampleForHistoryDef>{
    
    
    public List<Map<String, String>> findForSearch(Map<String, Object> searchCriteria, String sqlId) {
        return getSqlSession().selectList("SampleForHistory." + sqlId, searchCriteria);		
    }

    @Override
    public SampleForHistoryDef create(SampleForHistoryDef entity) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public SampleForHistoryDef findById(SampleForHistoryDef entity) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<SampleForHistoryDef> findByColumn(SampleForHistoryDef entity) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<SampleForHistoryDef> find(SampleForHistoryDef entity, String sqlId) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public SampleForHistoryDef update(SampleForHistoryDef entity) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<SampleForHistoryDef> updateByColumn(SampleForHistoryDef searchCriteria, SampleForHistoryDef entity) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<SampleForHistoryDef> update(SampleForHistoryDef searchCriteria, SampleForHistoryDef entity, String sqlId) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<SampleForHistoryDef> insert(List<SampleForHistoryDef> entity, String sqlId) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<SampleForHistoryDef> insert(SampleForHistoryDef entity, String sqlId) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(String id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void deleteByColumn(SampleForHistoryDef entity) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public SampleForHistoryDef softDelete(SampleForHistoryDef entity) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<SampleForHistoryDef> softDeleteByColumn(SampleForHistoryDef entity) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<SampleForHistoryDef> findAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
}
