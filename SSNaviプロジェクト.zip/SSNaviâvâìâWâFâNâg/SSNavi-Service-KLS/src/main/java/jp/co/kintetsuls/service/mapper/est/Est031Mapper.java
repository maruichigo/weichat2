package jp.co.kintetsuls.service.mapper.est;

import jp.co.kintetsuls.service.mapper.est.*;
import jp.co.sharedsys.service.mapper.IMapper;
import org.springframework.stereotype.Component;

/**
 * Mybatis 顧客一覧 Mapper
 * @author sharedsys
 */
@Component("est031")
public interface Est031Mapper extends IMapper {
    
}
