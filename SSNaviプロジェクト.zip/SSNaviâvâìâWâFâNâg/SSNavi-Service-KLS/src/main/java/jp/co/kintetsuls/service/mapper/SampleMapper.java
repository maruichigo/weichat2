package jp.co.kintetsuls.service.mapper;

import jp.co.sharedsys.service.mapper.IMapper;
import org.springframework.stereotype.Component;

/**
 * Mybatis Sample Mapper
 * @author sharedsys
 */
@Component("sample")
public interface SampleMapper extends IMapper {
    
}
