package jp.co.kintetsuls.common.svf;

import java.io.*;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.core.Response;
import jp.co.fit.UCXSingle.UCXSingle;
import jp.co.kintetsuls.common.util.PropertyUtil;
import jp.co.kintetsuls.exception.LogicException;
import jp.co.kintetsuls.exception.SystemException;

/**
 * 印刷共通機能（帳票出力）
 */
 public class PrintReport {
     
        // 入力必須エラーメッセージ
        final String ERROR_MESSAGE_VALIDATE_REQUIRED = "%sが指定されていません。";
        
        // ファイル形式の定義
        enum FileFormat {
            PDF,
            Excel,
            PREV,
        };
        
        // ファイル形式と拡張子の定義
        private final Map<String, String> fileExtensionMap = new HashMap<String, String>() {
            {
                put(FileFormat.PDF.name(), "pdf");
                put(FileFormat.Excel.name(), "xlsx");
                put(FileFormat.PREV.name(), "svfwdx");
            }
        };
        
        /**
         * 帳票出力（ファイル（PDF、Excel）に出力する場合）
         * @param chohyoId 帳票ID
         * @param yoshiId 用紙ID
         * @param shutsuryokuFileMei 出力ファイル名
         * @param fileFormat ファイル形式　PDF、Excel
         * @param dataFilePath データファイル（CSV）のAPサーバー上でのフルパス
         * @param adjustX 印字位置の調整　(X座標をmm単位に指定)
         * @param adjustY 印字位置の調整　(Y座標をmm単位に指定)
         * @return 0=正常、正数=パラメータ不正、負数=エラーステータス
         * @throws IOException
         * @throws SystemException
         * @throws LogicException
         */
	public Response.ResponseBuilder outputFile(String chohyoId, String yoshiId, String shutsuryokuFileMei, String fileFormat, String dataFilePath, int adjustX, int adjustY) 
                throws IOException, SystemException, LogicException {
            
            //TODO:DONE:パラメータチェック未実装
            if (isEmpty(chohyoId)) {
                throw new LogicException(String.format(ERROR_MESSAGE_VALIDATE_REQUIRED, "帳票ID"));
//                return -1;
            }
            if (isEmpty(yoshiId)) {
                throw new LogicException(String.format(ERROR_MESSAGE_VALIDATE_REQUIRED, "用紙ID"));
//                return -2;
            }
            if (isEmpty(shutsuryokuFileMei)) {
                throw new LogicException(String.format(ERROR_MESSAGE_VALIDATE_REQUIRED, "出力ファイル名"));
//                return -3;
            }
            if (isEmpty(fileFormat)) {
                throw new LogicException(String.format(ERROR_MESSAGE_VALIDATE_REQUIRED, "ファイル形式"));
//                return -4;
            }
            if (!Arrays.asList(FileFormat.PDF.name(), FileFormat.Excel.name(), FileFormat.PREV.name()).contains(fileFormat)) {
                throw new LogicException(String.format("ファイル形式が不正です。fileFormat=%s", fileFormat));
//                return -5;
            }
            if (isEmpty(dataFilePath)) {
                throw new LogicException(String.format(ERROR_MESSAGE_VALIDATE_REQUIRED, "データファイル"));
//                return -6;
            }

            long currentTime = System.currentTimeMillis();
            long before = 24 * 60 * 60 * 1000;

            //ユニークなファイル名を生成します。
            //TODO:DONE:ユニーク度が不十分
            String TIMEN = String.valueOf(System.currentTimeMillis());
            String RAND = String.valueOf(new Random(currentTime).nextInt());

            //拡張子を付与します。ファイル形式（PDF=.pdf, Excel=.xlsx）
            //TODO:DONE:ケース分け
            String fileExtension = fileExtensionMap.get(fileFormat);
            String outputfname = String.format("%s_%s.%s", TIMEN, RAND, fileExtension);

            //出力ファイルのパスを生成します。
            //TODO:DONE:上位パスをプロパティから取得
            //注意：SVFのIE用ActiveXがURL参照するため、外部から公開されたフォルダである必要がある。サンプルではresoucesの配下
            String resultFilePath = PropertyUtil.getString("ucx.resultfilepath");
            String outputpath = new File(resultFilePath, outputfname).getPath();

            int ret = 0;

            // Universal Connect/Xサーバーのホスト名
            //TODO:DONE:プロパティ化
            String host           = PropertyUtil.getString("ucx.xserver.host");
            // Universal Connect/Xサーバーのポート番号
            //TODO:DONE:プロパティ化
            int    port           = PropertyUtil.getInt("ucx.xserver.port");
            // 動作設定名 = 帳票ID_用紙ID_ファイル形式
            //TODO:パラメータから生成
            String settingName    = String.format("%s_%s_%s", chohyoId, yoshiId, fileFormat);

            UCXSingle ucs = new UCXSingle();
            Response.ResponseBuilder res = null;
            try {
                // Universal Connect/Xサーバーのホスト名、ポート番号を指定します。
                ucs.setUniConXServer(host, port);

                // 動作設定名を指定します。
                ucs.setSettingName(settingName);

                // データファイル名を指定します。
                ucs.setSourceName(dataFilePath);

                // 処理が正常終了した場合に、データファイルを削除しません。
                ucs.setUndeleteSourceFile(true);

                // 処理が異常終了した場合に、データファイルを削除しません。
                ucs.setUndeleteSourceFileIfError(true);

                // 生成される出力ファイル名を指定します。
                ucs.setResultFileName(outputpath);

                // UCXサーバーとファイルを送受信する際に、ファイルを圧縮しません。
                ucs.useCompression(false);

                // 1/10ミリ単位で印字位置を調節します。(1ミリ単位から変換)
                ucs.setAdjustm(adjustX * 10, adjustY * 10);

                // 設定した動作設定に従って処理をします。
                ucs.doTransaction();

                // UCXSingleの実行結果を取得します。
                ret = ucs.getUCXSingleResult();
                // Universal Connect/Xの実行結果を取得します。
                if (ret == 0) {
                    ret = ucs.getUniConXResult();
                }

                //正常時
                if (ret == 0) {
                    //TODO:DONE:分岐未実装
                    res = Response.ok((Object)new File(outputpath));
                    res.header("Pragma", "No-cache");   
                    res.header("content-disposition", String.format("attachment; filename=\"%s.%s\"", shutsuryokuFileMei, fileExtension));
                } else {
                    throw new SystemException(String.format("帳票発行に失敗しました。エラーコード=%s", ret));
                }
            } catch (Exception ex) {
                    //TODO:DONE:例外時の処理未実装
                    if (ex instanceof IOException) {
                        throw new IOException(ex);
                    }
                    throw new SystemException(ex);
            }
            return res;
	}
        
        /**
         * 帳票出力（クライアントでプレビューする場合）
         * @param chohyoId 帳票ID
         * @param yoshiId 用紙ID
         * @param shutsuryokuDocumentMei 出力ドキュメント名
         * @param dataFilePath データファイル（CSV）のAPサーバー上でのフルパス
         * @param adjustX 印字位置の調整　(X座標をmm単位に指定)
         * @param adjustY 印字位置の調整　(Y座標をmm単位に指定)
         * @return 0=正常、正数=パラメータ不正、負数=エラーステータス
         * @throws IOException 
         * @throws SystemException 
         * @throws LogicException 
         */
        public String preview(String chohyoId, String yoshiId, String shutsuryokuDocumentMei, String dataFilePath, int adjustX, int adjustY) throws IOException, SystemException, LogicException {

                //TODO:DONE:パラメータチェック未実装
                if (isEmpty(chohyoId)) {
                    throw new LogicException(String.format(ERROR_MESSAGE_VALIDATE_REQUIRED, "帳票ID"));
//                    return -1;
                }
                if (isEmpty(yoshiId)) {
                    throw new LogicException(String.format(ERROR_MESSAGE_VALIDATE_REQUIRED, "用紙ID"));
//                    return -2;
                }
                if (isEmpty(shutsuryokuDocumentMei)) {
                    throw new LogicException(String.format(ERROR_MESSAGE_VALIDATE_REQUIRED, "出力ファイル名"));
//                    return -3;
                }
                if (isEmpty(dataFilePath)) {
                    throw new LogicException(String.format(ERROR_MESSAGE_VALIDATE_REQUIRED, "データファイル"));
//                    return -4;
                }
                
                long currentTime = System.currentTimeMillis();
		long before = 24 * 60 * 60 * 1000;

                //ユニークなファイル名を生成します。
                //TODO:DONE:ユニーク度が不十分
		String TIMEN = String.valueOf(System.currentTimeMillis());
                String RAND = String.valueOf(new Random(currentTime).nextInt());
		
                String fileExtension = fileExtensionMap.get("PREV");
                String outputfname = String.format("%s_%s.%s", TIMEN, RAND, fileExtension);

		//出力ファイルのパスを生成します。
                //TODO:DONE:上位パスをプロパティから取得
                String resultFilePath = PropertyUtil.getString("ucx.resultfilepath");
		String outputpath = new File(resultFilePath, outputfname).getPath();

		int ret = 0;

                // Universal Connect/Xサーバーのホスト名
                //TODO:DONE:プロパティ化
                String host           = PropertyUtil.getString("ucx.xserver.host");
                // Universal Connect/Xサーバーのポート番号
                //TODO:DONE:プロパティ化
                int    port           = PropertyUtil.getInt("ucx.xserver.port");
                // 動作設定名 = 帳票ID_用紙ID_PREV
                //TODO:DONE:パラメータから生成
                String settingName    = String.format("%s_%s_PREV", chohyoId, yoshiId);

                UCXSingle ucs = new UCXSingle();
                StringBuilder sb = new StringBuilder();

                try {
                    // Universal Connect/Xサーバーのホスト名、ポート番号を指定します。
                    ucs.setUniConXServer(host, port);

                    // 動作設定名を指定します。
                    ucs.setSettingName(settingName);

                    // データファイル名を指定します。
                    ucs.setSourceName(dataFilePath);

                    // 処理が正常終了した場合に、データファイルを削除しません。
                    ucs.setUndeleteSourceFile(true);

                    // 処理が異常終了した場合に、データファイルを削除しません。
                    ucs.setUndeleteSourceFileIfError(true);

                    // 生成される出力ファイル名を指定します。
                    ucs.setResultFileName(outputpath);

                    // UCXサーバーとファイルを送受信する際に、ファイルを圧縮しません。
                    ucs.useCompression(false);

                    // 1/10ミリ単位で印字位置を調節します。(1ミリ単位から変換)
                    ucs.setAdjustm(adjustX * 10, adjustY * 10);

                    // 設定した動作設定に従って処理をします。
                    ucs.doTransaction();

                    // UCXSingleの実行結果を取得します。
                    ret = ucs.getUCXSingleResult();
                    // Universal Connect/Xの実行結果を取得します。
                    if (ret == 0) {
                        ret = ucs.getUniConXResult();
                    }

                    if (0 <= ret) {
                        //retの値が正の値だった場合の処理
                        sb.append("http://localhost:8080/SSNavi-JSF/resources/download/").append(outputfname);
                    }
                } catch (Exception ex) {
                    Logger.getLogger(PrintReport.class.getName()).log(Level.SEVERE, null, ex);
                }
                return sb.toString();
	}

        /**
         * 未入力チェックを行う
         * @param s
         *              検証文字列
         * @return
         *              true:未入力 false:入力済
         */
        private static boolean isEmpty(String s) {
            return null == s || s.trim().isEmpty();
        }
        
}