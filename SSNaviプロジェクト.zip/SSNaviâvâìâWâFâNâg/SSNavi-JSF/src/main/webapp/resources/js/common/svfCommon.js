/*
 * SVF JSファイル 
 * svfCommon.js 
 * Copyright (c) Shared System Inc.
 */
           
// プレビュー用の小窓(モーダレス)           
function openSvfPrev() { 
    var newWin = window.open(
            "http://localhost:10417/SSNavi-JSF/contents/common/svf/svfPrev.xhtml",    //移動先
            "svfPrev",  //ターゲット名（aタグのtargetと同様）
            "width=600, height=640"
    );
    newWin.focus();        
} 

// 印刷時に「直接印刷」、「印刷設定画面」、「プレビュー」に合わせて画面を表示する
function selectPrint(args) { 

    // センターに表示
    var w = ( screen.width-640 ) / 2;
    var h = ( screen.height-480 ) / 2;
    
    if (args.ptn == "print") {
        // 印刷確認画面
        var newWin = window.open(
                "http://localhost:10417/SSNavi-JSF/contents/common/svf/svfConfirm.xhtml",    //移動先
                "svfConfirm",  //ターゲット名
                "width=100, height=100, top="+ h + ",left=" + w
        );   
    } else {
        // 印刷結果を表示する小窓を表示
        var newWin = window.open(
                "http://localhost:10417/SSNavi-JSF/contents/common/svf/svfPrint.xhtml",    //移動先
                "svfPrint",  //ターゲット名（aタグのtargetと同様）
                "width=100, height=100, top="+ h + ",left=" + w
        );                   
    }
    newWin.focus();        
} 


function openSvfObject() { 
    var newWin = window.open(
            "http://localhost:10417/SSNavi-JSF/contents/common/svf/svfObject.xhtml",    //移動先
            "svfObject",  //ターゲット名（aタグのtargetと同様）
            "width=600, height=640"
    );
    newWin.focus();        
} 

