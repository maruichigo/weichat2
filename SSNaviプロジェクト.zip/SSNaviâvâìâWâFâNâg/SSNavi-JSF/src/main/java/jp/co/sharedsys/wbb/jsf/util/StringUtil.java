package jp.co.sharedsys.wbb.jsf.util;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.BitSet;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import jp.co.sharedsys.wbb.jsf.reports.ReportColumn;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateFormatUtils;

public class StringUtil {

    /**
     * キャメライズする
     *
     * @param s string
     * @return camerized string
     */
    public static String camelize(String s) {
        if (s == null) {
            return null;
        }
        s = s.toLowerCase();
        String[] array = StringUtils.split(s, "_");
        if (array.length == 1) {
            return StringUtils.lowerCase(s);
        }
        StringBuffer buf = new StringBuffer(40);
        for (int i = 0; i < array.length; ++i) {
            if (i == 0) {
                buf.append(StringUtils.lowerCase(array[i]));
            } else {
                buf.append(StringUtils.capitalize(array[i]));
            }
        }
        return buf.toString();
    }

    /**
     * Stringに型変換
     *
     * @param col reportcolumn
     * @param obj object
     * @return string
     */
    public static String castToString(ReportColumn col, Object obj) {
        String val = "";
        if (obj == null) {
            return "";
        }
        if (obj instanceof Integer) {
            Integer i = (Integer) obj;
            val = i.toString();
        } else if (obj instanceof String) {
            val = (String) obj;
        } else if (obj instanceof Long) {
            Long l = (Long) obj;
            if (StringUtils.equals("DATE", col.getDataType())) {
                Date date = new Date(l);
                val = DateFormatUtils.format(date, "yyyy/MM/dd");
            } else if (StringUtils.equals("DATE_TIMESTAMP", col.getDataType())) {
                Date date = new Date(l);
                val = DateFormatUtils.format(date, "yyyy/MM/dd HH:mm:ss");
            } else {
                val = l.toString();
            }
        }
        return val;
    }

    /**
     * ファイルを読み込み、全内容を取得する。
     *
     * @param path filepath
     * @return ファイル全内容
     */
    public static String fileReadAll(final String path) {
        try {
            return new String(Files.readAllBytes(Paths.get(path)), StandardCharsets.UTF_8);
        } catch (IOException ex) {
            Logger.getLogger(StringUtil.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    
    /**
     * Whether str is all Em(zenkaku) characters or not.
     *
     * @param str Target characters
     * @return True if str is all Em, false if not
     */
    public static boolean isEm(String str) {
        // Regular expression.
        if (str == null) return false;
        return str.matches("[^ -~｡-ﾟ]*");
    }

    /**
     * Whether str includes Em or not.
     *
     * @param str Target characters
     * @return True if str includes Em, false if not.
     */
    public static boolean includeEm(String str) {
        boolean retVal = false;
        if (str == null) return retVal;
        for (char ch : str.toCharArray()) {
            char chs[] = new char[1];
            chs[0] = ch;

            String st = new String(chs);
            if (isEm(st)) {
                retVal = true;
            }
        }
        return retVal;
    }

    /**
     * Check str includes Em or En(hankaku).
     *
     * @param str
     * @return BitSet(if the character is Em, set bit)
     */
    public static BitSet charsCheck(String str) {
        BitSet retVal = new BitSet();

        int count = 0;
        for (char ch : str.toCharArray()) {
            char chs[] = new char[1];
            chs[0] = ch;

            String st = new String(chs);
            if (isEm(st)) {
                retVal.set(count);
            }
            count++;
        }
        return retVal;
    }

    /**
     * Return what kind of characters set?
     *
     * @param str Target characters
     * @return 0: All En, 1: All Em,
     */
    public static int validateChars(String str) {
        int retVal = 0;
        if (isEm(str)) {
            // All Em.
            retVal = 1;
        } else if (includeEm(str)) {
            // At least one character is Em.
            retVal = 2;
        }
        return retVal;
    }
}
