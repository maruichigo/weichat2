/*
 * BaseHistoryForReport.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.wbb.jsf.beans.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.event.FacesEvent;
import jp.co.kintetsuls.common.MessageDataModel;
import jp.co.sharedsys.wbb.jsf.beans.SSNaviManagedBean;
import jp.co.sharedsys.wbb.jsf.exception.LogicException;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;
import jp.co.sharedsys.wbb.jsf.process.MsgExec;
import jp.co.sharedsys.wbb.jsf.reports.ReportSql;
import org.primefaces.context.RequestContext;
import org.primefaces.event.SelectEvent;

/**
 * <p>単票形式画面の履歴表示用の抽象クラス
 * 
 * @author matsumoto
 */
public abstract class BaseHistoryForReport {
    
    /** 簡易履歴一覧情報がvaluesに格納されるキー名称  変更したい場合は継承先でオーバーライド */
    protected String keyNameForSidebarHistory = "SidebarHistoryValues";
    /** 明細表示リストがvaluesに格納されるキー名称  変更したい場合は継承先でオーバーライド */
    protected String keyNameForHistoryDetailList = "HistoryDetailValues";
    
    /**
     * <p>履歴一覧を検索し、結果をサイドバー表示用に格納する
     * <p>Attributeに指定された'component_id'を元に履歴を検索する。
     * <br>検索結果を保持するキー値は変数keyNameForSidebarHistoryに格納。
     * @param bean
     * @param event
     * @param messageData
     * @param flag
     * @throws LogicException
     * @throws SystemException 
     */
    public void searchHistory(SSNaviManagedBean bean, FacesEvent event, MessageDataModel messageData, Boolean flag) throws LogicException, SystemException{
        
        // Attribute情報の取得
        Map<String ,Object> attribute = event.getComponent().getAttributes();
        
        // Values保持キー名称を元に履歴情報のクリア
        bean.getValues().remove(keyNameForSidebarHistory);
        
        // 呼び出しコンポーネントIDを取得
        String componentId = attribute.get("component_id").toString();
        
        // 画面入力パラメータの取得
        ReportSql targetDef = bean.buttonActGetReportSql(event);
        Map<String, Object> targetValues = bean.getValues().get(targetDef.getName());
        
        // 履歴検索
        ReportSql target = new ReportSql();
        target.setName("HISTORY");
        target.setFunctionCode(componentId);
        target.setEditModeName("SEARCH");
        List<Map<String, Object>> resultList = bean.callSql(target, targetValues);
        
        // 取得結果が0件の場合エラーメッセージを表示する
        if(resultList.isEmpty()){
            new MsgExec().message("ERROR", "エラー", "履歴がありません。");
            return;
        }
        
        // 履歴一覧表示データの設定
        List<Map<String, Object>> historyMapList = new ArrayList();
        int key = 0;
        for(Map<String, Object> paramMap: resultList){
            Map <String, Object> historyMap = new HashMap();
            historyMapList.add(historyMap);
            for(Map.Entry<String, Object> param: paramMap.entrySet()){
                historyMap.put(param.getKey(), param.getValue().toString());
            }
        }        
        // 検索結果を元に履歴表示用情報を設定する
        Map<String, Object> tempMap = new HashMap();
        tempMap.put(keyNameForSidebarHistory, historyMapList);
        bean.getValues().put(keyNameForSidebarHistory, tempMap);
        
        // 履歴サイドバー表示モードOn
        RequestContext context = RequestContext.getCurrentInstance();
        // サイドバーを表示するJavascriptを実行するかの判定に使用するフラグを設定
        context.addCallbackParam("showRightSidebarFlag", true);
    }
    
    /**
     * <p>サイドバー履歴一覧の行選択イベント
     * <p>Attributeに指定された'component_id'を元に、
     * <br>選択された行情報に該当する履歴明細情報を取得。
     * <br>取得した情報の1レコード目を画面表示コンポーネントと紐づける。
     * <p>※検索結果を画面コンポーネントと紐づける処理は実装必須(setHistoryDetail)
     * @param bean
     * @param event
     * @param messageData
     * @param flag
     * @throws LogicException
     * @throws SystemException 
     */
    public void clickRow(SSNaviManagedBean bean, FacesEvent event, MessageDataModel messageData, Boolean flag) throws LogicException, SystemException{

        // 選択行情報の取得
        SelectEvent selectEvent = (SelectEvent)event;
        Map<String, Object> rowValue = (Map<String, Object>)selectEvent.getObject();
        
        // Values保持キー名称を元に履歴明細リスト情報のクリア
        bean.getValues().remove(keyNameForHistoryDetailList);
        
        // ボタンAttribute情報の取得
        Map<String ,Object> attribute = event.getComponent().getAttributes();
        
        // 呼び出しコンポーネントIDを取得
        String componentId = attribute.get("component_id").toString();
        
        // 履歴検索
        ReportSql target = new ReportSql();
        target.setName("HISTORY");
        target.setFunctionCode(componentId);
        target.setEditModeName("SEARCH");
        List<Map<String, Object>> resultList = bean.callSql(target, rowValue);
        
        // 取得結果が0件の場合エラーメッセージを表示する
        if(resultList.isEmpty()){
            new MsgExec().message("ERROR", "エラー", "履歴がありません。");
            return;
        }
        
        // 画面入力情報の保持
        Map<String, Map<String, Object>> oldValues = new HashMap();
        bean.setOldValues(oldValues);
        for(Map.Entry<String, Map<String, Object>> entry: bean.getValues().entrySet()){
            Map<String, Object> tempMap = new HashMap();
            oldValues.put(entry.getKey(), tempMap);
            for(Map.Entry<String, Object> entryChild: entry.getValue().entrySet()){
                tempMap.put(entryChild.getKey(), entryChild.getValue());
            }
        }
        
        // 取得した履歴明細リストの設定
        Map<String, Object> tempMap = new HashMap();
        tempMap.put(keyNameForHistoryDetailList, resultList);
        bean.getValues().put(keyNameForHistoryDetailList, tempMap);
        
        // 履歴表示インデックスの初期化
        bean.getConfig().setHistoryIndex(0);
        
        // 履歴表示MAXインデックスの設定
        bean.getConfig().setHistoryMaxIndex(resultList.size());
        
        // 画面表示情報の設定
        setHistoryDetail(bean);
        
        // 履歴表示モードOn
        bean.getConfig().setHistoryMode(true);
    }
    
    /**
     * <p>履歴表示モード時の[←]ボタン処理
     * <p>表示している履歴情報を、保持している履歴リストのひとつ前の内容に変更する
     * @param bean
     * @param event
     * @param messageData
     * @param flag 
     */
    public void preHistory(SSNaviManagedBean bean, FacesEvent event, MessageDataModel messageData, Boolean flag){
        // 履歴表示インデックスをひとつ前へ
        bean.getConfig().setHistoryIndex(bean.getConfig().getHistoryIndex() - 1);
        
        // 画面表示情報の設定
        setHistoryDetail(bean);
        
    }
    
    /**
     * <p>履歴表示モード時の[→]ボタン処理
     * <p>表示している履歴情報を、保持している履歴リストのひとつ次の内容に変更する
     * @param bean
     * @param event
     * @param messageData
     * @param flag 
     */
    public void nextHistory(SSNaviManagedBean bean, FacesEvent event, MessageDataModel messageData, Boolean flag){
        // 履歴表示インデックスをひとつ次へ
        bean.getConfig().setHistoryIndex(bean.getConfig().getHistoryIndex() + 1);
        
        // 画面表示情報の設定
        setHistoryDetail(bean);
        
    }
    
    /**
     * <p>履歴モード終了ボタン処理
     * <p>履歴モードになる前の画面情報を復元し、履歴モードを終了する
     * <p>※履歴モードでない場合に実行された場合、処理は行われない
     * @param bean
     * @param event
     * @param messageData
     * @param flag 
     */
    public void exitHistoryMode(SSNaviManagedBean bean, FacesEvent event, MessageDataModel messageData, Boolean flag){
        // 履歴表示モードでない場合は処理を終了する
        if(!bean.getConfig().isHistoryMode()){
            return;
        }
 
        // 画面表示情報の復元
        restoreValues(bean);
        
        // 履歴表示モードOff
        bean.getConfig().setHistoryMode(false);
        
        // 履歴表示インデックスの初期化
        bean.getConfig().setHistoryIndex(0);
        bean.getConfig().setHistoryMaxIndex(0);
        
    }
    
    /**
     * <p>履歴明細情報と画面コンポーネントを格納
     * @param bean 
     */
    abstract protected void setHistoryDetail(SSNaviManagedBean bean);
    
    /**
     * <p>画面情報復元処理
     * <p>復元処理のみ実装を変更したい場合にオーバーライド
     * @param bean 
     */
    protected void restoreValues(SSNaviManagedBean bean){
        bean.setValues(bean.getOldValues());
        bean.setOldValues(new HashMap());
    }
    
}
