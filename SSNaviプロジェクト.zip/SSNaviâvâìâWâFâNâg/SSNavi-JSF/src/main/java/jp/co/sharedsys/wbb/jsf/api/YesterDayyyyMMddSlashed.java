/*
 **---------------------------------------------------------------------*
 **                                                                     *
 **          Copyright (c) 2010 Kintetsu World Express.                 *
 **          All Rights Reserved                                        *
 **          Kintetsu World Express.                                    *
 **                                                                     *
 **---------------------------------------------------------------------*
 **                                                                     *
 **  File Name       :   YesterDayyyyMMddSlashed.java                   *
 **                                                                     *
 **  HISTORY:                                                           *
 **  Date            Name         		Version     Change      *
 **---------------------------------------------------------------------*
 **  2011/09/15    	 S.Akiba                  1.0      Initial      *    
 **---------------------------------------------------------------------*
 */
package jp.co.sharedsys.wbb.jsf.api;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class YesterDayyyyMMddSlashed implements IAPI {

    public String getAPI() {
        return "@YesterdaySlashed@";
    }

    public String execute() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        return new SimpleDateFormat("yyyy/MM/dd").format(cal.getTime());
    }
}
