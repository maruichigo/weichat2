/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.common.util;

import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import jp.co.kintetsuls.service.model.biz_common.SystemMstDef;

/**
 * システムマスタ保持クラス
 *
 */
public class SystemMstHold {

	private static SystemMstHold systemMstHold;

	private static Map<String, SystemMstDef> systemMstMap = null;

	private SystemMstHold() {
		setMap(); //TODO テスト時用
	}

	public static synchronized SystemMstHold getInstance() {
		if (systemMstHold == null) {
			systemMstHold = new SystemMstHold();
		}

		return systemMstHold;
	}

	public static void setSystemMst(Map<String, SystemMstDef> systemMst) {
		systemMstMap = systemMst;
	}

	/**
	 * 使用不可
	 */
	public static Map<String, SystemMstDef> getSytemMstDebug() {
		return systemMstMap;
	}

	/**
	 * システムマスタ設定値を取得する
	 *
	 * @param cdGroup コードグループ
	 * @param cd コード
	 * @return システムマスタ設定値
	 */
	public static String getSystemMst(String cdGroup, String cd) {

		String val = "";

		// printDebug();
		// TODO テスト用
		if (systemMstMap == null) {
			systemMstHold = new SystemMstHold();
		}

		// コードグループ・コードがNULLの場合
		if (cdGroup == null || cd == null) {
			return null;
		}

		try {
			String key = cdGroup.concat("_").concat(cd);
			val = systemMstMap.get(key).getVal();
		} catch (Exception e) {
			Logger.getLogger(SystemMstHold.class.getName()).log(Level.SEVERE, null, e);
		}

		return val;
	}

	private static void printDebug() {

		if (systemMstMap == null) {
			System.out.println("システムマスタMapがありません");
		} else {

			//          System.out.println("システムマスタ件数 [" + systemMstMap.size() + "]");
		}
	}

	/**
	 * テスト時のみ使用
	 */
	private void setMap() {

		//   System.out.println("システムマスタ設定★テスト");
		systemMstMap = new HashMap();

		String csvFile = "/csv/systemMst.csv";

		try {
			InputStream is = this.getClass().getResourceAsStream(csvFile);
			//        System.out.println("IS [" + is + "]");
			BufferedReader br = new BufferedReader(new InputStreamReader(is));

			String line;
			while ((line = br.readLine()) != null) {
				String[] data = line.split(",", -1); // 行をカンマ区切りで配列に変換

				if (data.length == 3) {
					// システムマスタBean
					SystemMstDef bean = new SystemMstDef();
					bean.setCdGroup(data[0]);
					bean.setCd(data[1]);
					bean.setVal(data[2]);
					String key = data[0].concat("_").concat(data[1]);
					systemMstMap.put(key, bean);
				}
			}
			br.close();

		} catch (IOException e) {
			Logger.getLogger(SystemMstHold.class.getName()).log(Level.SEVERE, null, e);
		}
	}
}
