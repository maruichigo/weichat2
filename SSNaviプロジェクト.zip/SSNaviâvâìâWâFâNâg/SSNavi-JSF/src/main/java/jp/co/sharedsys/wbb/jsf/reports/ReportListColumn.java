package jp.co.sharedsys.wbb.jsf.reports;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ReportListColumn implements Serializable {

    private static final long serialVersionUID = 6205862151197138788L;
    /** ソートするかどうかのフラグ */
    private boolean sortFlg = true;
    /** ヘッダ部にAllチェックをつけるかどうかのフラグ */
    private boolean allChkFlg = false;
    private String displayName = "";
    private String align = "left";

    /** 1項目の中に表示するカラム情報 */
    private List<ReportColumn> cols = new ArrayList<>();
    
    public boolean isSortFlg() {
            return sortFlg;
    }
    public void setSortFlg(boolean sortFlg) {
            this.sortFlg = sortFlg;
    }
    public boolean isAllChkFlg() {
            return allChkFlg;
    }
    public void setAllChkFlg(boolean allChkFlg) {
            this.allChkFlg = allChkFlg;
    }
    public String getDisplayName() {
            return displayName;
    }
    public void setDisplayName(String displayName) {
            this.displayName = displayName;
    }
    public String getAlign() {
            return align;
    }
    public void setAlign(String align) {
            this.align = align;
    }
    public List<ReportColumn> getCols() {
            return cols;
    }
    public void setCols(List<ReportColumn> cols) {
            this.cols = cols;
    }
    public void addCol(ReportColumn col) {
            cols.add(col);
    }

}
