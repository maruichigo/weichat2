package jp.co.sharedsys.wbb.jsf.reports;

public class ReportColumn extends AbstractReportCondition {

    private static final long serialVersionUID = -7390733578838444915L;
}
