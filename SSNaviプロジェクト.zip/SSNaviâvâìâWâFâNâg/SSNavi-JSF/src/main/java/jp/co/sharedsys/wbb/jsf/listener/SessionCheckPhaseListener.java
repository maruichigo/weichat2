/*
 * SessionCheckPhaseListener.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.listener;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;
import javax.servlet.http.HttpSession;

/**
 *
 * @author saihara
 */
public class SessionCheckPhaseListener implements PhaseListener {

    private static final long serialVersionUID = -7462937908829777735L;

    @Override
    public void afterPhase(final PhaseEvent arg0) {

    }

    @Override
    public void beforePhase(final PhaseEvent event) {

        final FacesContext context = event.getFacesContext();
        final String viewId = context.getViewRoot().getViewId();
        final ExternalContext extContext = context.getExternalContext();
        final HttpSession session = (HttpSession) extContext.getSession(false);
        final String LOGIN_PAGE = "/login.xhtml";

        if (!LOGIN_PAGE.equals(viewId)) {
//            if ((session == null) || session.getAttribute("sessionKey") == null) {
//
//                try {
//                    extContext.dispatch(LOGIN_PAGE);
//                    context.responseComplete();
//                } catch (IOException ioe) {
//                    throw new RuntimeException("エラーです");
//                }
//            }
        } else {
//            if (session != null ) {
//                ELContext elContext = FacesContext.getCurrentInstance().getELContext();
//                SSNaviManagedBean pageBean = (SSNaviManagedBean) FacesContext.getCurrentInstance().getApplication()
//                    .getELResolver().getValue(elContext, null, "pageBean");
//                try {
//                    extContext.dispatch(pageBean.init());
//                    context.responseComplete();
//                } catch (IOException ioe) {
//                    throw new RuntimeException("Error!");
//                } catch (SystemException ex) {
//                    Logger.getLogger(SessionCheckPhaseListener.class.getName()).log(Level.SEVERE, null, ex);
//                }
//            }
        }
    }

    @Override
    public PhaseId getPhaseId() {
        return PhaseId.RENDER_RESPONSE;
    }
}
