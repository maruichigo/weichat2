package jp.co.sharedsys.wbb.jsf.api;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateyyyyMMdd_HHmmss implements IAPI {

    public String getAPI() {
        return "@DateyyyyMMdd_HHmmss@";
    }

    public String execute() {
        return new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
    }
}
