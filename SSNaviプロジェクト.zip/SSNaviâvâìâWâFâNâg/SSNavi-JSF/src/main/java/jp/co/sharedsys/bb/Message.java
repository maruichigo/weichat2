package jp.co.sharedsys.bb;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Message {
	
    private ListMap parameters = new ListMap();
    private Map attributes = new HashMap();
    private List errors = new ArrayList();

    private ListMap externalParameter = new ListMap();

    public Map getParameterMap (){
        return this.parameters;
    }
	
    public String getParameter(String key){
        return (String) parameters.get(key);
    }
	
    public Iterator getParameterValues(String key){
        return parameters.valueIterator(key);
    }
	
    public void setParameter(String key,String value){
        parameters.put(key,value);
    }
	
    public void removeParameter(String key){
        parameters.remove(key);
    }
	
    public void setAttribute(Object key,Object value){
        attributes.put(key,value);
    }
	
    public Object getAttribute(Object key){
        return attributes.get(key);
    }
	
    public Set attributeKeySet(){
        return attributes.keySet();
    }
	
    public Set attributeEntrySet(){
        return attributes.entrySet();
    }
	
    public void removeAttribute(Object key){
        attributes.remove(key);
    }
	
    public void addError(Exception exception){
        errors.add(exception);
    }
	
    public Iterator errorIterator(){
        return errors.iterator();
    }
	
    public ListMap getExternalParameter() {
        return externalParameter;
    }
	
    public Map getAttributes() {
        return attributes;
    }
	
    public static void mergeMessage(Message from, Message to){
        if (from == null || to == null){
            return;
        }
        for (Iterator ite = from.attributeKeySet().iterator();ite.hasNext();){
            String key = (String) ite.next();
            Object value = from.getAttribute(key);
            to.setAttribute(key,value);
        }
        for (Iterator ite = from.parameters.keySet().iterator();ite.hasNext();){
            String key = (String) ite.next();
            for (Iterator inner = from.getParameterValues(key);inner.hasNext();){
                to.setParameter(key,(String) inner.next());
            }			
        }
    }

    public static void mergeAttribute(Message from, Message to){
        if (from == null || to == null){
            return;
        }
        for (Iterator ite = from.attributeKeySet().iterator();ite.hasNext();){
            String key = (String) ite.next();
            Object value = from.getAttribute(key);
            to.setAttribute(key,value);
        }		
    }	
}
