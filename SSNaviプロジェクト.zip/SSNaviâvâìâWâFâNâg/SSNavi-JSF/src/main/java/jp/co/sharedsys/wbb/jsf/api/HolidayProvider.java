/*
 * HolidayProvider.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.api;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import org.primefaces.json.JSONArray;
import org.primefaces.json.JSONObject;

/**
 * 営業日カレンダーマスタから取得した休日をjsonに書き込むクラス
 * @author Yuka Kobayashi
 */
public class HolidayProvider {

    File file;
    
    public HolidayProvider(String path) {
        file = new File(path);
        
        try{
            if(!file.exists()){
                file.createNewFile();
            }
        }catch(IOException e){
            e.printStackTrace();
        }
    }
    
    public void getHolidays(String json){

        // TODO: ServiceをキックしてDBからデータを取得する
        // calendar.getHolidays
        
        //[{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2016","month":"1","day":"1","holidayFlg":"","shiseiStatus":""}
        // ,{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2016","month":"1","day":"2","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2016","month":"1","day":"4","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2016","month":"2","day":"4","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2016","month":"2","day":"6","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2016","month":"2","day":"7","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2017","month":"1","day":"1","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2017","month":"1","day":"3","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2017","month":"1","day":"4","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2017","month":"1","day":"6","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2017","month":"2","day":"2","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2017","month":"2","day":"5","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2017","month":"2","day":"6","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2018","month":"1","day":"1","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2018","month":"1","day":"2","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2018","month":"1","day":"3","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2018","month":"2","day":"2","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2018","month":"2","day":"4","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2018","month":"2","day":"5","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2018","month":"2","day":"6","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2018","month":"12","day":"2","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2018","month":"12","day":"6","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2018","month":"12","day":"9","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2018","month":"12","day":"16","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2018","month":"12","day":"23","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2018","month":"12","day":"24","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2018","month":"12","day":"30","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2019","month":"1","day":"1","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2019","month":"1","day":"2","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2019","month":"2","day":"4","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2019","month":"2","day":"6","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2019","month":"2","day":"7","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2020","month":"1","day":"1","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2020","month":"1","day":"2","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2020","month":"1","day":"4","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2020","month":"1","day":"5","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2020","month":"2","day":"3","holidayFlg":"","shiseiStatus":""},{"nengappi":"","kyujitsuFlg":"","nichiyoFlg":"","shukujitsuFlg":"","shukujitsuMeisho":"","uriageShimebiFlg":"","year":"2020","month":"2","day":"6","holidayFlg":"","shiseiStatus":""}]

        String lastYear = "";
        String lastMonth = "";
        JSONObject res = new JSONObject();
        JSONObject months = new JSONObject();
        JSONObject days = new JSONObject();
        
        JSONArray arr = new JSONArray(json);
        for(int i = 0; i < arr.length(); i++){
            JSONObject obj = arr.getJSONObject(i);
            String year = obj.getString("year");
            String month = obj.getString("month");
            String day = obj.getString("day");
            Boolean flg = Boolean.valueOf(obj.getString("holiday"));
            
            if (!month.equals(lastMonth) && !lastMonth.isEmpty()){
                months.put(lastMonth, days);
                days = new JSONObject();
            }

            if(!year.equals(lastYear) && !lastYear.isEmpty()){
                res.put(lastYear, months);
                months = new JSONObject();
            }

            days.put(day, flg);
            
            lastYear = year;
            lastMonth = month;
        }
        months.put(lastMonth, days);
        res.put(lastYear, months);
        
        
        // 取得したjsonデータをファイルに書き込む
        PrintWriter writer = null;
        
        try{
            FileWriter fWriter = new FileWriter(file);
            
            writer = new PrintWriter(new BufferedWriter(fWriter));
  
            writer.println(res);

        }catch(IOException e){
            e.printStackTrace();
        } finally {
            if(writer != null) writer.close();
        }
        
        
    }
    
}
