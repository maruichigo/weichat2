package jp.co.sharedsys.wbb.jsf.api;

public class FirstDateYMDOfLastMonth implements IAPI {

    public String execute() {
        // TODO Auto-generated method stub
        return null;
    }

    public String getAPI() {
        // TODO Auto-generated method stub
        return null;
    }
}
