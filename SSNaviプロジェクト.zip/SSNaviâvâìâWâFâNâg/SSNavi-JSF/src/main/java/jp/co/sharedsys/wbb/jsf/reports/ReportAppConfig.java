package jp.co.sharedsys.wbb.jsf.reports;

import java.io.Serializable;

public class ReportAppConfig implements Serializable {
    /**
     * 
     */
    private static long serialVersionUID = 7633962368965612036L;
    private String title = "";
    private String directory = "";
    private String screenCode = "";
    private String screenSize = "";
    private String lineDisp = "";

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDirectory() {
        return directory;
    }

    public void setDirectory(String directory) {
        this.directory = directory;
    }

    public String getScreenCode() {
        return screenCode;
    }

    public void setScreenCode(String screenCode) {
        this.screenCode = screenCode;
    }

    /**
     * @return the screenSize
     */
    public String getScreenSize() {
        return screenSize;
    }

    /**
     * @param screenSize the screenSize to set
     */
    public void setScreenSize(String screenSize) {
        this.screenSize = screenSize;
    }

    /**
     * @return the serialVersionUID
     */
    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    /**
     * @param aSerialVersionUID the serialVersionUID to set
     */
    public static void setSerialVersionUID(long aSerialVersionUID) {
        serialVersionUID = aSerialVersionUID;
    }

    /**
     * @return the lineDisp
     */
    public String getLineDisp() {
        return lineDisp;
    }

    /**
     * @param lineDisp the lineDisp to set
     */
    public void setLineDisp(String lineDisp) {
        this.lineDisp = lineDisp;
    }
}
