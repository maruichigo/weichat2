package jp.co.sharedsys.wbb.jsf.reports;

import java.io.Serializable;

public class ReportFormat implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = -6329741239235708171L;

}
