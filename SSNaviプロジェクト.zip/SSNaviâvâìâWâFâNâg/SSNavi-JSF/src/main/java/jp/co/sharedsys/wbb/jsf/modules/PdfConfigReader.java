package jp.co.sharedsys.wbb.jsf.modules;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import jp.co.sharedsys.bb.ApplicationManager;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;

import org.apache.commons.digester.Digester;
import org.apache.commons.digester.xmlrules.DigesterLoader;
import org.apache.commons.io.IOUtils;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import jp.co.sharedsys.wbb.jsf.conf.XReportPdfConfig;
import jp.co.sharedsys.wbb.jsf.conf.XReportPdfs;
import jp.co.sharedsys.wbb.jsf.reports.ReportPdfConfig;
import jp.co.sharedsys.wbb.jsf.reports.ReportPdfGroup;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PdfConfigReader {

    public static final String CONFIG_FILENAME = "pdf_rule.xml";
    private static Logger logger = LoggerFactory.getLogger(PdfConfigReader.class);

    public static List<ReportPdfGroup> get(String target) throws SystemException {
        logger.info("PdfGroups get start.");
        String home = ApplicationManager.getInstance().getHomeDirectory();
        Digester d = null;
        File f = new File(home + "/conf/" + CONFIG_FILENAME);
        logger.debug("rule [" + f.getPath() + "]");
        InputStream fs = null;
        List<ReportPdfGroup> pdfGroups = null;
        try {
                fs = new FileInputStream(f);
                InputSource is = new InputSource(fs);
                d = DigesterLoader.createDigester(is);
                File pdfGroupFile = new File(home + "/" + target);
                logger.debug("target pdf group [" + pdfGroupFile.getPath() + "]");
                // Cacheにあればそれを返す
                pdfGroups = PdfGroupsCache.getInstance("").getPdfGroupByName(pdfGroupFile.getName());
                if (pdfGroups != null && pdfGroups.size() != 0) {
                        logger.debug("target pdf group already loaded.");
                        return pdfGroups;
                }

                File targetFile = pdfGroupFile;
                logger.info("PARSING [" + targetFile.getPath() + "]");
                InputStream datastream = null;
                try {
                    datastream = new FileInputStream(targetFile);
                    List configlist = (List) d.parse(datastream);
                    //parsing ok
                    pdfGroups = new ArrayList<>();
                    for (Iterator<XReportPdfs> item = configlist.iterator();item.hasNext();){
                        XReportPdfs xm = (XReportPdfs)item.next();
                        ReportPdfGroup pdfGroup = new ReportPdfGroup();
                        pdfGroup.setName(xm.getName());
                        pdfGroup.setDescription(xm.getDescription());
                        pdfGroup.setAfterExecService(xm.getAfterExecService());
                        for (Iterator<XReportPdfConfig> itec = xm.getPdfConfig().iterator();itec.hasNext();){
                            XReportPdfConfig xc = (XReportPdfConfig) itec.next();
                            logger.debug("PdfConfig file[" + xc.getFormatFile() + "] is added to [" + pdfGroup.getName() + "]");
                            ReportPdfConfig pconfig = new ReportPdfConfig();
                            pconfig.setFormatFile(xc.getFormatFile());
                            pconfig.setSqlFile(xc.getSqlFile());
                            pconfig.setName(xc.getName());
                            pconfig.setPrevService(xc.getPrevService());
                            pconfig.setAfterService(xc.getAfterService());
                            pconfig.setSortKey(xc.getSortKey());
                            pdfGroup.getPdfs().add(pconfig);
                        }
                        pdfGroups.add(pdfGroup);
                    }
                    PdfGroupsCache.getInstance("").getPdfGroups().put(pdfGroupFile.getName(), pdfGroups);
                } catch (IOException e) {
                    throw new SystemException(e);
                } catch (SAXException e) {
                    e.printStackTrace();
                } finally {
                    IOUtils.closeQuietly(datastream);
                }
        } catch (FileNotFoundException e) {
            throw new SystemException(e);
        } finally {
            IOUtils.closeQuietly(fs);
        }
        logger.info("PdfGroups get end.");
        return pdfGroups;
    }
}
