package jp.co.sharedsys.wbb.jsf.conf;

import lombok.Data;

@Data
public class XReportSql {
    private String name = null;         //S02
    private String templateFile = null; //S04 対象外
    private String tableName;           //S13
    private String service;             //S14
    private String functionCode;        //S15
}
