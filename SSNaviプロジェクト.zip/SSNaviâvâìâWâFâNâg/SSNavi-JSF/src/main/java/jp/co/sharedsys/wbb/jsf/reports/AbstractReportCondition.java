package jp.co.sharedsys.wbb.jsf.reports;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jp.co.sharedsys.wbb.jsf.api.TextEditor;
import lombok.Getter;
import lombok.Setter;

public abstract class AbstractReportCondition implements Serializable {
    //ない title,description,pageTemplate,
    //service-parameter,show-add-row-button,show-del-row-button,label,value,checked
    private static final long serialVersionUID = -1952990451251072316L;
    protected String name = null;                   //C01物理名×
    protected String displayName = null;            //C02項目名×
    protected String controlType = null;            //C03コンポーネント×
    protected String dataType = null;               //C04データ種別×
    @Getter @Setter
    protected String align = null;                  //C05配置〇
    @Getter @Setter
    protected boolean visible;                      //C06表示有無×
    @Getter @Setter
    protected boolean readonly = false;             //C07読み取り専用×
    private String format = null;                   //C08
    protected String defaultValue = null;           //C09設定初期値×
    protected int minLength = -1;                   //C13桁数最小×
    protected int maxLength = -1;                   //C14桁数最大×
    protected List<AbstractReportOption> options = new ArrayList<>();//C16選択項目参照先×
    protected List<AbstractReportOption> originalOptions = new ArrayList<>();
    
    protected String applyTo = null;                //C17データ参照先×
    private String pointLength = null;              //C25少数点対象外
    @Getter @Setter
    protected boolean pk = false;                   //C29PK対象外
    @Getter @Setter
    protected int tabIndex = -1;                    //C30TabIndex〇
    @Getter @Setter
    protected String tableName = null;              //C34テーブル名対象外
    @Getter @Setter
    protected String functionCode;                  //C36FunctionCode×
    private String action;                          //C37action〇
    @Getter @Setter
    protected String transferRptFile = null;        //C38遷移先定義ファイル×
    @Getter @Setter
    protected String transferRptDir = null;         //C39遷移先定義ディレクトリ×
    @Getter @Setter
    protected String service;                       //C41対象サービス対象外
    @Getter @Setter
    protected String extra1;                        //C43追加項目１〇
    @Getter @Setter
    protected String extra2;                        //C44追加項目２〇
    @Getter @Setter
    protected String extra3;                        //C45追加項目３〇
    @Getter @Setter
    protected String extra4;                        //C46追加項目４〇
    @Getter @Setter
    protected String extra5;                        //C47追加項目５〇
    @Getter @Setter
    protected String section;                       //C48セクション表示ラベル対象外
    
    @Getter @Setter
    protected int sortIndex = -1;

    @Getter @Setter
    protected AbstractReportOption selectOption;

    @Getter @Setter
    protected String subColumn;
    @Getter @Setter
    protected String schSortIndex;
    @Getter @Setter
    protected String textValue = null;
    @Getter @Setter
    protected String labelValue = null;

    private String[] itemValue;
    
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getDisplayName() {
        return displayName;
    }
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }
    public String getControlType() {
        return controlType;
    }
    public void setControlType(String controlType) {
        this.controlType = controlType;
    }
    public int getMinLength() {
        return minLength;
    }
    public void setMinLength(int minLength) {
        this.minLength = minLength;
    }
    public int getMaxLength() {
        return maxLength;
    }
    public void setMaxLength(int maxLength) {
        this.maxLength = maxLength;
    }
    public String getDataType() {
        return dataType;
    }
    public void setDataType(String dataType) {
        this.dataType = dataType;
    }
    public String getDefaultValue() {
        return TextEditor.replace(defaultValue);
    }
    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }
    public List<AbstractReportOption> getOptions() {
        return options;
    }
    public void setOptions(List<AbstractReportOption> options) {
        this.options = options;
    }
    public String getApplyTo() {
        return applyTo;
    }
    public void setApplyTo(String applyTo) {
        this.applyTo = applyTo;
    }
    public List<AbstractReportOption> getOriginalOptions() {
        return originalOptions;
    }
    public String getNameStart(){
        return getName() + "_START";
    }
    public String getNameEnd(){
        return getName() + "_END";
    }
    public String getAlign() {
        if ("NUMBER".equals(dataType) || "INT".equals(dataType) || "DECIMAL".equals(dataType)) {
            return "text-align: right;";
        }
        return "text-align: left;";
    }
    
    public List<AbstractReportOption> autoCompMethod(String query) {
        List<AbstractReportOption> filtered = new ArrayList<>();
        for (AbstractReportOption option : options) {
            if (option.getLabel().contains(query)) {
                filtered.add(option);
            }
        }
        return filtered;
    }
    
    public List<AbstractReportOption> doubleComboOut(String query) {
        List<AbstractReportOption> filtered = new ArrayList<>();
        for (AbstractReportOption option : options) {
            if (option.getLabel().startsWith(query)) {
                filtered.add(option);
            }
        }
        return filtered;
    }

    public List<AbstractReportOption> doubleComboIn(String query) {
        List<AbstractReportOption> filtered = new ArrayList<>();
        for (AbstractReportOption option : options) {
            if (option.getLabel().startsWith(query)) {
                filtered.add(option);
            }
        }
        return filtered;
    }  

    /**
     * @return the itemValue
     */
    public String[] getItemValue() {
        return itemValue;
    }

    /**
     * @param itemValue the itemValue to set
     */
    public void setItemValue(String[] itemValue) {
        this.itemValue = itemValue;
    }
    
}
