/*
 * SampleHistoryForReport.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.wbb.jsf.beans.test;

import java.util.List;
import java.util.Map;
import jp.co.sharedsys.wbb.jsf.beans.SSNaviManagedBean;

/**
 *
 * @author matsumoto
 */
public class SampleHistoryForReport extends BaseHistoryForReport{

    @Override
    protected void setHistoryDetail(SSNaviManagedBean bean) {
        
        // 表示対象履歴情報の取得
        List<Map<String, Object>> targetHistoryList = (List<Map<String, Object>>)bean.getValues().get(keyNameForHistoryDetailList).get(keyNameForHistoryDetailList);
        Map<String, Object> targetHistory = targetHistoryList.get(bean.getConfig().getHistoryIndex());
        
        // 画面表示情報の設定
        Map<String,Object> displayValues = bean.getValues().get("list");
        displayValues.put("ID", targetHistory.get("ID"));
        displayValues.put("VALUE1", targetHistory.get("VALUE1"));
        displayValues.put("VALUE2", targetHistory.get("VALUE2"));
        displayValues.put("VALUE3", targetHistory.get("VALUE3"));
        displayValues.put("DATE", targetHistory.get("DATE_VALUE"));
        
    }
    
}
