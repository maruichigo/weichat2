package jp.co.sharedsys.wbb.jsf.process;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.wbb.jsf.exception.LogicException;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;
import jp.co.sharedsys.wbb.jsf.beans.AuthorityConfBean;

import jp.co.sharedsys.wbb.jsf.beans.SSNaviManagedBean;
import jp.co.sharedsys.wbb.jsf.reports.Input;
import jp.co.sharedsys.wbb.jsf.reports.ReportColumn;
import jp.co.sharedsys.wbb.jsf.reports.ReportConfig;
import jp.co.sharedsys.wbb.jsf.reports.ReportConst;
import jp.co.sharedsys.wbb.jsf.reports.ReportModification;
import jp.co.sharedsys.wbb.jsf.util.StringUtil;


public class ExternalServiceExecuter extends AbstractExternalProcess<SSNaviManagedBean> {
    public static final String P_REPORTIDPARAM = "id-parameter-name";
    public static final String P_KEY = "application-key";
    public static final String P_ATTRIBUTE = "parameter-attribute-name";
    public static final String P_SEND_PARAMETER = "send_parameters";
    public static final String P_EDIT_MODE_NAME = "edit-name";
    public static final String P_EDIT_MODE_INSERT = "edit-name-value-insert";
    public static final String P_EDIT_MODE_UPDATE = "edit-name-value-update";
    public static final String P_EDIT_MODE_DELETE = "edit-name-value-delete";
    public static final String P_EDIT_ACTIVITY_NAME = "act";
    public static final String P_EDIT_ACTIVITY_INIT = "INIT";
    public static final String P_EDIT_ACTIVITY_ERROR = "ERROR";
    public static final String P_EDIT_ACTIVITY_EXECUTE = "EXECUTE";
    public static final String P_INPUT_ATTRIBUTE = "input_parameter";
    public static final String PREFIX_COND_PARAM = "P_";
    public static final String P_EXEC_RES_STATUS_ATTRIBUTE = "execResStatus";
    public static final String P_EXEC_RES_MSG_ATTRIBUTE = "execResMsg";
    public static final String P_IS_SEARCH = "isSearch";
    public static final String P_CURRENT_PAGE = "current-page";
    public static final String P_ALL_PAGE     = "all-page";
    public static final String P_LIMIT_PAGE   = "limit-page";
    public static final String P_RESULT_DATA_COUNT = "result-data-count";
    public static final String E_SERVICE_URL = "target_service_url";
    public static final String E_FUNCTION = "target_function";
    public static final String E_SERVICE_NAME = "target_service_name";
    public static final String E_TARGET_CONFIG = "target_config";
    public static final String E_SQL = "exec_sql";

    @Override
    public void onService(SSNaviManagedBean pageBean) throws LogicException, SystemException {
        // 入力されたcondition
	String repid = pageBean.getR();
        
	ReportConfig config;
        if (pageBean.getTargetServices().get(0).get(E_TARGET_CONFIG) != null) {
            config = (ReportConfig)pageBean.getTargetServices().get(0).get(E_TARGET_CONFIG);
        } else {
            config = pageBean.getConfig();
        }
        
        if (config == null) {
            throw new LogicException("Specified report-id was not found.[" + repid + "]");
        }

        // 検索条件パラメータ取得
	List<Input> params = new ArrayList<>();
        Map<String, Input> request = new HashMap<>();
        for (Input in : params) {
            request.put(in.getName(), in);
        }

        // ログイン情報取得
//        Map login = new HashMap();
//	login.put(SecurityUtils.TOKEN_UserCd, (SecurityToken) listUserCd.get(0));

	// メイン処理
        ReportModification mod = config.getModification();
        mod = mod == null ? new ReportModification() : mod;
        for (Map<String, Object> target : pageBean.getTargetServices()) {
            // 機能モード(INSERT/UPDATE/DELETE)
            String modeName = (String)target.get(P_EDIT_MODE_NAME);
            modeName = modeName == null ? "" : modeName;
            String actName = (String)target.get(P_EDIT_ACTIVITY_NAME);
            actName = actName == null ? "" : actName;
            if (actName.equals(P_EDIT_ACTIVITY_EXECUTE)) {
                // 追加更新削除確定時処理
                // 入力チェックでエラーが発生していた場合
                // 画面に再検索結果とedit対象を返却する

                // 登録時送信パラメータセット
                Object inputParams = target.get(P_SEND_PARAMETER);
                if (StringUtils.equals(modeName, ReportConst.EditMode.SEARCH) || StringUtils.equals(modeName, ReportConst.EditMode.SEARCH_ONE)) {
                    inputParams = camelizedMap(inputParams, pageBean.getValues().get(target.get(E_SERVICE_NAME)));
                } else {
                    if (inputParams == null) {
                        try {
                            inputParams = screeningKeyAndCamelize(inputParams, pageBean.getValues().get(target.get(E_SERVICE_NAME)), mod);
                        } catch (ParseException ex) {
                            logger.error(ex.getMessage(), ex);
                            throw new SystemException(ex);
                        }
                    }
                }
                // サービス名取得
                String service = (String)target.get(E_SERVICE_URL);
                String functionCode = (String)target.get(E_FUNCTION);
                String tableName = "";
                String sqlMap = (String)target.get(E_SQL);
                if (sqlMap != null) {
                    tableName = sqlMap;
                }
 
                if(inputParams != null) {
                    /**** SSNavi : Service request ****/
                    try {
                        AuthorityConfBean authConf = pageBean.getAuthConf();
                        ServiceInterfaceBean dto = this.requestExternalService(service, inputParams, functionCode, tableName, authConf.getUserCd(), authConf.getUserGroup(), false);

                        // Json結果データをMapに変換
                        ObjectMapper mapper = new ObjectMapper();
                        Map<String, Object> jsonResMap = null;

                        if (!StringUtils.equals(modeName, ReportConst.EditMode.LIST_UPDATE)
                                && !StringUtils.equals(modeName, ReportConst.EditMode.MULTI_UPDATE) 
                                && !StringUtils.equals(modeName, ReportConst.EditMode.DETAIL_DELETE)
                                && !StringUtils.equals(modeName, ReportConst.EditMode.DETAIL_UPDATE)
                                && !StringUtils.equals(modeName, ReportConst.EditMode.SEARCH) 
                                && !StringUtils.equals(modeName, ReportConst.EditMode.SEARCH_SIDEBAR)) {
                            // 一覧画面での更新の場合は、Jsonデータの解析はしない。
                            try {
                                jsonResMap = mapper.readValue(dto.getJson(), Map.class);
                                pageBean.setExternalAttribute(jsonResMap);
                            } catch (IOException e) {
                                logger.error("サービス側から意図しないパラメータが返ってきています。");
                                logger.error(e.getMessage(), e);
                                pageBean.getExternalAttribute().put(P_EXEC_RES_STATUS_ATTRIBUTE, "9");
                                pageBean.getExternalAttribute().put(P_EXEC_RES_MSG_ATTRIBUTE, ReportConst.Msg.SYSTEM_ERROR);
                                return ;
                            }
                        }
                        
                        if (StringUtils.equals(modeName, ReportConst.EditMode.SEARCH)) {
                            try {
                                List searchResult = mapper.readValue(dto.getJson(), List.class);
                                pageBean.getReportResult().put((String)target.get(E_SERVICE_NAME), searchResult);
                            } catch (IOException e) {
                                logger.error("サービス側から意図しないパラメータが返ってきています。");
                                logger.error(e.getMessage(), e);
                                pageBean.getExternalAttribute().put(P_EXEC_RES_STATUS_ATTRIBUTE, "9");
                                pageBean.getExternalAttribute().put(P_EXEC_RES_MSG_ATTRIBUTE, ReportConst.Msg.SYSTEM_ERROR);
                                return ;
                            }

                        } else if (StringUtils.equals(modeName, ReportConst.EditMode.LIST_UPDATE)) {
                            // 一覧画面用
                            String issearch = pageBean.getIsSearch();
                            issearch = issearch == null ? "" : issearch;
                            pageBean.getExternalAttribute().put(P_IS_SEARCH, issearch);

                            if (dto.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_SUCCESS) {
                                pageBean.getExternalAttribute().put(P_EXEC_RES_STATUS_ATTRIBUTE, "0");
                                pageBean.getExternalAttribute().put(P_EXEC_RES_MSG_ATTRIBUTE, dto.getMessage());
                                // 再検索する
//        			parameter = executeListSqls(parameter, config, request, login);
                            } else {
                                pageBean.getExternalAttribute().put(P_EXEC_RES_STATUS_ATTRIBUTE, "9");
                                pageBean.getExternalAttribute().put(P_EXEC_RES_MSG_ATTRIBUTE, dto.getMessage());
                            }

                        } else if (StringUtils.equals(modeName, ReportConst.EditMode.MULTI_UPDATE)) {
                            String issearch = pageBean.getIsSearch();
                            issearch = issearch == null ? "" : issearch;
                            pageBean.getExternalAttribute().put(P_IS_SEARCH, issearch);

                            if (dto.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_SUCCESS) {
                                pageBean.getExternalAttribute().put(P_EXEC_RES_STATUS_ATTRIBUTE, "0");
                                pageBean.getExternalAttribute().put(P_EXEC_RES_MSG_ATTRIBUTE, dto.getMessage());
                                // 再検索する
//        			parameter = executeSqls(parameter, config, request, login);
                            } else {
                                pageBean.getExternalAttribute().put(P_EXEC_RES_STATUS_ATTRIBUTE, "9");
                                pageBean.getExternalAttribute().put(P_EXEC_RES_MSG_ATTRIBUTE, dto.getMessage());
                            }
                        } else if (StringUtils.equals(modeName, ReportConst.EditMode.SEARCH_SIDEBAR)) {
                            // サイドバー用
                            try {
                                List searchResult = mapper.readValue(dto.getJson(), List.class);
                                pageBean.getReportSidebarResult().put((String)target.get(E_SERVICE_NAME), searchResult);
                            } catch (IOException e) {
                                logger.error("サービス側から意図しないパラメータが返ってきています。");
                                logger.error(e.getMessage(), e);
                                pageBean.getExternalAttribute().put(P_EXEC_RES_STATUS_ATTRIBUTE, "9");
                                pageBean.getExternalAttribute().put(P_EXEC_RES_MSG_ATTRIBUTE, ReportConst.Msg.SYSTEM_ERROR);
                                return ;
                            }


                        } else {
                            // 編集画面用
                            if (StringUtils.equals(modeName, ReportConst.EditMode.BLOCK_DELETE)
                                || StringUtils.equals(modeName, ReportConst.EditMode.DETAIL_DELETE)
                                || StringUtils.equals(modeName, ReportConst.EditMode.DETAIL_UPDATE)
                                || StringUtils.equals(modeName, ReportConst.EditMode.DELETE)) {
                                // 削除モードの場合は終わったら、編集モードに戻す
                                pageBean.getExternalAttribute().put(P_EDIT_MODE_NAME, ReportConst.EditMode.UPDATE);
                            }

                            if (dto.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_SUCCESS) {
                                // 正常終了
                                if (StringUtils.equals(modeName, ReportConst.EditMode.INSERT)) {
                                    // 新規時は、新規発行したIDで検索するため検索条件をリクエストにセットする
                                    request = new HashMap<String, Input>();
                                    List<ReportColumn> sortedColumns = mod.getColumnsSort(config.getSqls().get(0).getName());
                                    for (ReportColumn col : sortedColumns){
                                        if (col.isPk()) {
                                            for (String key : jsonResMap.keySet()) {
                                                if (StringUtils.equals(key, StringUtil.camelize(col.getName()))) {
                                                    Input in = new Input();
                                                    in.setName(PREFIX_COND_PARAM + col.getName());
                                                    in.setApplyTo(col.getApplyTo());
                                                    in.setType(col.getDataType());
                                                    in.getValues().add(StringUtil.castToString(col, jsonResMap.get(key)));
                                                    request.put(in.getName(), in);
                                                    params.add(in);
                                                }
                                            }
                                        }
                                    }
                                    pageBean.getExternalAttribute().put("request", request);
                                    // 新規登録から更新モードにする
                                    pageBean.getExternalAttribute().put(P_EDIT_MODE_NAME, ReportConst.EditMode.UPDATE);
                                }
                                pageBean.getExternalAttribute().put(P_EXEC_RES_STATUS_ATTRIBUTE, "0");
                                pageBean.getExternalAttribute().put(P_EXEC_RES_MSG_ATTRIBUTE, dto.getMessage());
                                // 再検索する
//        			parameter = executeSqls(parameter, config, request, login);
                            } else {
                                // エラー時
                                pageBean.getExternalAttribute().put(P_EXEC_RES_STATUS_ATTRIBUTE, "9");
                                pageBean.getExternalAttribute().put(P_EXEC_RES_MSG_ATTRIBUTE, dto.getMessage());
                            }
                        }
                    }catch (SystemException e) {
                        logger.error(e.getMessage(), e);
                        pageBean.getExternalAttribute().put(P_EXEC_RES_STATUS_ATTRIBUTE, "9");
                        pageBean.getExternalAttribute().put(P_EXEC_RES_MSG_ATTRIBUTE, ReportConst.Msg.SYSTEM_ERROR);
                    }
                }
            } else {
                if (StringUtils.equals(ReportConst.Act.PAGER_NEXT, actName)
                    || StringUtils.equals(ReportConst.Act.PAGER_PREV, actName)) {
                }

                if (StringUtils.equals(modeName, ReportConst.EditMode.UPDATE)
                    || StringUtils.equals(modeName, ReportConst.EditMode.MULTI_UPDATE)
                    || StringUtils.equals(ReportConst.Act.COPY, actName)
                    || StringUtils.equals(ReportConst.Act.PAGER_NEXT, actName)
                    || StringUtils.equals(ReportConst.Act.PAGER_PREV, actName)) {
                    // 更新またはコピー時は検索処理を実行
//                    parameter = executeSqls(parameter, config, request, login);
                } else if (StringUtils.equals("CREATE_NEW", actName)) {
                    // 2016.03.01 pkをクリアする
                    List<ReportColumn> sortedColumns = mod.getColumnsSort(config.getSqls().get(0).getName());
                    for (ReportColumn col : sortedColumns){
                        if (col.isPk()) {
                            Input input = request.get(PREFIX_COND_PARAM + col.getName());
                            if (input != null) {
                                input.clearValues();
                            }
                        }
                    }
                }

                if (StringUtils.equals(ReportConst.Act.COPY, actName)) {
                    //pk項目とLABEL項目を空にする
                    // TODO あとでCOPY対象データを取得するようにする
//                    List<List<Map<String, String>>> list = (List<List<Map<String, String>>>) parameter.getAttribute("report_result");
                    List<List<Map<String, String>>> list = new ArrayList();

                    if (StringUtils.equals(ReportConst.Mode.HD_EDIT, mod.getMode()) || StringUtils.equals(ReportConst.Mode.M_EDIT, mod.getMode())) {
                        // ヘッダと明細でそれぞれ処理する
                        List<Map<String, String>> dataList = list.get(0);
                        for (Map<String, String> h : dataList) {
                            List<ReportColumn> cols = mod.getControlTypeList(ReportConst.ApplyTo.H, null, ReportConst.ControlType.LABEL);
                            for (ReportColumn col : cols) {
                                h.put(col.getName(), "");
                            }
                            cols = mod.getPkList(ReportConst.ApplyTo.H);
                            for (ReportColumn col : cols) {
                                h.put(col.getName(), "");
                            }
                        }
                        dataList = list.get(1);
                        for (Map<String, String> d : dataList) {
                            List<ReportColumn> cols = mod.getControlTypeList(ReportConst.ApplyTo.D, null, ReportConst.ControlType.LABEL);
                            for (ReportColumn col : cols) {
                                d.put(col.getName(), "");
                            }
                            cols = mod.getPkList(ReportConst.ApplyTo.D);
                            for (ReportColumn col : cols) {
                                d.put(col.getName(), "");
                            }
                        }
                    }
                }
            }
        }
    }
}
