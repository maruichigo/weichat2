package jp.co.sharedsys.wbb.jsf.conf;

import java.util.ArrayList;
import java.util.List;

public class XReportCondition {
    private String name = null;//2物理名×
    private String displayName = null;//1項目名×
    private String controlType = null;//3コンポーネント×
    private String dataType = null;//4データ種別×
    private String align = null;//5配置〇
    private String visible = null;//6表示有無×
    private String readonly = null;//7読み取り専用×
    private String format = null;//8
    private String defaultValue = null;//9設定初期値×
    private String minLength = null;//13桁数最小×
    private String maxLength = null;//14桁数最大×
    private List options = new ArrayList();//16選択項目参照先×
    private String applyTo = null;//17データ参照先×
    private String pointLength = null;//25少数点対象外
    private String pk = null;//29PK対象外
    private String tabIndex = null;//30TabIndex〇
    private String tableName;//34テーブル名対象外
    private String functionCode;//36FunctionCode×
    private String action;//37action〇
    private String transferRptFile;//38遷移先定義ファイル×
    private String transferRptDir;//39遷移先定義ディレクトリ×
    private String service;//41対象サービス対象外
    private String extra1;//43追加項目１〇
    private String extra2;//44追加項目２〇
    private String extra3;//45追加項目３〇
    private String extra4;//46追加項目４〇
    private String extra5;//47追加項目５〇
    private String section;//48セクション表示ラベル対象外
    
    public void setVisible(String visible) {
        this.visible = visible;
    }
    
    public String getVisible() {
        return visible;
    }
    
    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getDisplayName() {
        return displayName;
    }
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }
    public String getControlType() {
        return controlType;
    }
    public void setControlType(String controlType) {
        this.controlType = controlType;
    }
    public String getDataType() {
        return dataType;
    }
    public void setDataType(String dataType) {
        this.dataType = dataType;
    }
    public String getDefaultValue() {
        return defaultValue;
    }
    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }
    public String getMinLength() {
        return minLength;
    }
    public void setMinLength(String minLength) {
        this.minLength = minLength;
    }
    public String getMaxLength() {
        return maxLength;
    }
    public void setMaxLength(String maxLength) {
        this.maxLength = maxLength;
    }
    public void addOption(XReportConditionOption option) {
        this.options.add(option);
    }
    public List getOptions() {
        return options;
    }
    public String getApplyTo() {
        return applyTo;
    }
    public void setApplyTo(String applyTo) {
        this.applyTo = applyTo;
    }
    public String getTabIndex() {
        return tabIndex;
    }
    public void setTabIndex(String tabIndex) {
        this.tabIndex = tabIndex;
    }
    public String getExtra1() {
        return extra1;
    }

    public void setExtra1(String extra1) {
        this.extra1 = extra1;
    }

    public String getExtra2() {
        return extra2;
    }

    public void setExtra2(String extra2) {
        this.extra2 = extra2;
    }

    public String getExtra3() {
        return extra3;
    }

    public void setExtra3(String extra3) {
        this.extra3 = extra3;
    }

    public String getExtra4() {
        return extra4;
    }

    public void setExtra4(String extra4) {
        this.extra4 = extra4;
    }

    public String getExtra5() {
        return extra5;
    }

    public void setExtra5(String extra5) {
        this.extra5 = extra5;
    }

    /**
     * @return the align
     */
    public String getAlign() {
        return align;
    }

    /**
     * @param align the align to set
     */
    public void setAlign(String align) {
        this.align = align;
    }
    
}
