package jp.co.sharedsys.wbb.jsf.conf;

import java.util.ArrayList;
import java.util.List;

public class XReportPdfs {
    private String name = null;
    private String description = null;
    private String selected = null;
    private List<XReportPdfConfig> pdfConfig = new ArrayList<XReportPdfConfig>();
    private String afterExecService = null;

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public List<XReportPdfConfig> getPdfConfig() {
        return pdfConfig;
    }
    public void setPdfConfig(List<XReportPdfConfig> pdfConfig) {
        this.pdfConfig = pdfConfig;
    }

    public void addPdfConfig(XReportPdfConfig config) {
        pdfConfig.add(config);
    }
    public String getSelected() {
        return selected;
    }
    public void setSelected(String selected) {
        this.selected = selected;
    }
    public String getAfterExecService() {
        return afterExecService;
    }
    public void setAfterExecService(String afterExecService) {
        this.afterExecService = afterExecService;
    }
}
