/*
 * AuthorityConfBean.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.application.ConfigurableNavigationHandler;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import jp.co.sharedsys.wbb.jsf.reports.ReportConditionOption;
import lombok.Data;

import org.primefaces.model.menu.MenuModel;

/**
 * ログインユーザー情報を格納するManagedBeanです。
 * ログイン成功時に生成され、セッションスコープで持ち回ります。
 * @author Shared System Inc.
 */
@ManagedBean(name = "authConf")
@SessionScoped
@Data
public class AuthorityConfBean implements Serializable {

    private static final long serialVersionUID = -8006365439680582676L;

    private Map<String, String> functionList = new HashMap<>();

    // ToDo:下記はログイン処理にてDBから取得するようにしてください。
    private boolean admin = false;
    private String userName = "近鉄 太郎";
    private String userDepartment = "システム部";

    /** login時に取得 */
    private String userCd = null;

    /** アクセス可能メニュー menuに紐づくScreenCodeを保有 */
    private Map<String, List<String>> authMenu = new LinkedHashMap<>();
    private List<String> menuCategories = new ArrayList();

    /** primefaces magemenuコンポーネント */
    private MenuModel menuModel;

    /**  コンポーネント権限リスト Map<screenCode, Map<component , 権限>  */
    private Map<String ,Map <String, Integer>> authScCompoMap = new LinkedHashMap<>();

    /** 担当営業所一覧 List＜Map{{VALUE:営業所CD}, {LABEL_VALUE:営業所名}, {LABEL:営業所CD:営業所名}}＞ */
    private List eigyoshoOption;
    
    /** デフォルト営業所 */
    private String defaultEigyosho;

    /** 使ってない */
    //private boolean HUpdateFlg = false;
    //private String groupSelectInd = null;
    //private List<String> authScreen = new ArrayList<>();
    //private List<String> dataGroup = null;
    private List<String> userGroup = null;

    
    public boolean isAllEnabledFunction() {
        return isAdmin() || functionList.containsKey("ALL");
    }

    public void isLoggedIn() {
        if (userCd == null) {
            ConfigurableNavigationHandler handler = (ConfigurableNavigationHandler)FacesContext.getCurrentInstance().getApplication().getNavigationHandler();
            handler.performNavigation("login");
        }
    }
    
    public String logout() {
        // 別途削除処理を実装
        
        FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
        return "/login.xhtml?faces-redirect=true";
    }
    
    public boolean loggedIn() {
        return userCd != null && !userCd.isEmpty();
    }
}
