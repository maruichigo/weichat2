package jp.co.sharedsys.wbb.jsf.process;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import jp.co.sharedsys.wbb.jsf.exception.LogicException;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;
import jp.co.sharedsys.wbb.jsf.beans.UserLoginView;
import jp.co.sharedsys.wbb.jsf.external.general.ExternalServiceProperty;
import jp.co.sharedsys.wbb.jsf.reports.ReportConst;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExternalLoginProcess extends AbstractExternalProcess<UserLoginView> {
    public static final String P_REPSYS = "application-attribute";
    public static final String P_REPSYSCONFIGS = "usesysconfig-attribute";

    public static final String USER_GROUP_CODE = "UserGroupCode";
    public static final String ROLE_GROUP_CODE = "RoleGroupCode";
    public static final String FUNCTION_CODE = "FunctionCode";
    public static final String SYSTEM_CODE = "SystemCode";
    public static final String SYSTEM_GROUP_NAME = "SystemGroupName";
    public static final String DISPLAY_POSITION = "DisplayPosition";
    public static final String SYSTEM_NAME = "SystemName";
    public static final String ACCESS_KEY = "AccessKey";
    public static final String SYSTEM_MULTIPLE = "SystemMulti";

    private final static String RECEIVE_CHARSET = "UTF-8";

    public static final String USE_SYSTEMS = "USESYSTEM";
    public static final String USE_ACCESS_KEY = "USEACCESSKEY";
    private static final String STATUS_PASS_WILL_EXPIRE = "6";

    private Logger logger = LoggerFactory.getLogger(this.getClass());
    @Override
    public void onService(UserLoginView userLogin) throws LogicException, SystemException {
        // TODO パラメータ取得のための手法
//      HttpServletRequest request = null;
//	HttpServletRequest request = this.getRequest(parameter);
//	HttpSession session = this.getSession(parameter);

        // TODO セッション作成
//	this.createSession(parameter);
        ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
        HttpServletRequest request = (HttpServletRequest) externalContext.getRequest();
        
        String loginId = userLogin.getUsername();
        String passwd = userLogin.getPassword();
        logger.info("LoginID [" + loginId + "] PASSWORD [" + passwd!=null ? "****" : "" + "]");
		
        // 外部サービスから帰ってきたメッセージをparameterに格納するキー
//	String atrResMsg = parameter.getParameter(P_EXEC_RES_MSG_ATTRIBUTE);
        String atrResMsg = "";

        String message = null;
		
        try {
            String service = ExternalServiceProperty.getInstance().getProperty("external-service");
            String function = ExternalServiceProperty.getInstance().getProperty("login-func");
            String tableName = "";
            List<String> dummyUserGroupCode = Arrays.asList(new String[]{"dummy"});
            Map<String, List<Map<String, Object>>> loginResult = (Map<String, List<Map<String, Object>>>)this.externalExecute(service, function, tableName, loginId, dummyUserGroupCode, this.createLoginParameter(userLogin), true);
			
            if (loginResult.get("userGroups") == null) {
                // 外部サービスからのメッセージ
                message = this.externalMessage; 
            } else {
                Map<String, Object> comRes = loginResult.get("userGroups").get(0);
                String status = (String)comRes.get(this.EXTERNAL_STATUS);
	
                if (status != null && (status.equals("1") || status.equals(STATUS_PASS_WILL_EXPIRE))) {
                    List<String> userGroupCodes = new ArrayList<String>();
                    for (Map<String, Object> result : loginResult.get("userGroups")) {
                        if (result.get("userGroupCode") != null) {
                            userGroupCodes.add((String)result.get("userGroupCode"));
                        }
                    }
                    // ユーザーグループが取得出来なかった場合
                    if (userGroupCodes.size() == 0) {
                        if (comRes.get(this.EXTERNAL_MESSAGE) != null) {
                            userLogin.setMessage((String)comRes.get(this.EXTERNAL_MESSAGE));
                        } else {
                            userLogin.setMessage(ReportConst.Msg.SYSTEM_ERROR);
                        }
                        return;
                    }
					
                    // data group
                    //List<String> dataGroupCodes = new ArrayList<String>();
                    //for (Map<String, Object> result : loginResult.get("dataGroups")) {
                    //    if (result.get("dataGroupCode") != null) {
                    //        dataGroupCodes.add((String)result.get("dataGroupCode"));
                    //    }
                    //}
					
                    // loginUser ワンタイムパスワードフラグが立っているか取得
                    for (Map<String, Object> result : loginResult.get("loginUser")) {
                        if (result.get("onetimePassInd") != null && result.get("onetimePassInd").equals(1)) {
                            userLogin.setStatus(STATUS_PASS_WILL_EXPIRE);
                        }
                    }
	
//                  parameter.setAttribute(parameter.getParameter(P_REPSYSCONFIGS), useSysList);
//                  parameter.setAttribute(parameter.getParameter(P_REPSYS), sysList);
                    userLogin.setMessage((String)comRes.get(this.EXTERNAL_MESSAGE));
                    userLogin.setUserGroupCodes(userGroupCodes);
                    //userLogin.setDataGroupCodes(dataGroupCodes);
					
                } else {
                    // 外部サービスからのメッセージ
                    message = (String)comRes.get(this.EXTERNAL_MESSAGE); 
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
//          message = e.getMessage();
            message = ReportConst.Msg.SYSTEM_ERROR;
//          throw new SystemException(e);
	} finally {
	}
        userLogin.setExtMessage(message);
    }
	
    private Map<String, Object> createLoginParameter(UserLoginView request) {
        Map<String, Object> prmList = new HashMap<String, Object>();
        String loginId = request.getUsername();
        String passwd = request.getPassword();
        prmList.put("UserCd", loginId);
        prmList.put("password", passwd);
        return prmList;
    }
}
