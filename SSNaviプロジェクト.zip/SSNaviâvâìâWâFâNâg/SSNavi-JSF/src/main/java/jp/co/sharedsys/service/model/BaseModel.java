package jp.co.sharedsys.service.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlElement;

import jp.co.sharedsys.service.constraintannotation.DateField;
import jp.co.sharedsys.service.constraintannotation.StringField;

/** 
 * 基底モデル
 * @author sharedsys
 *
 */
public abstract class BaseModel {

    @StringField(columnName="作成ユーザ", isNotNull=false, maxLength=20)
    protected String createdBy;

    @DateField(columnName="作成日時", isNotNull=false)
    protected Date createdDate;

    @StringField(columnName="最終更新ユーザ", isNotNull=false, maxLength=20)
    protected String lastModifiedBy;

    @DateField(columnName="最終更新日時", isNotNull=false)
    protected Date lastModifiedDate;
        
    protected String orderBy;

    /**　作成者の取得
     * @return 作成者
     */
    @XmlElement(name = "createdBy")
    public String getCreatedBy() {
            return createdBy;
    }
    /** 作成者の設定
     * @param createdBy 作成者
     */
    public void setCreatedBy(String createdBy) {
            this.createdBy = createdBy;
    }
    /** 作成日の取得
     * @return 作成日
     */
    @XmlElement(name = "createdDate")
    public Date getCreatedDate() {
        return createdDate;
    }
    /** 作成日の設定
     * @param createdDate 作成日
     */
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }
    /** 最終更新者の取得
     * @return 最終更新者
     */
    @XmlElement(name = "lastModifiedBy")
    public String getLastModifiedBy() {
        return lastModifiedBy;
    }
    /** 最終更新者の設定
     * @param lastModifiedBy 最終更新者
     */
    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }
    /** 最終更新日の取得
     * @return 最終更新日
     */
    @XmlElement(name = "lastModifiedDate")
    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }
    /** 最終更新日の設定
     * @param lastModifiedDate 最終更新日
     */
    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }
        
    @XmlElement(name = "orderby")
    public String getOrderBy() {
        return orderBy;
    }
    public void setOrderBy(String orderBy){
        this.orderBy = orderBy;
    }
}
