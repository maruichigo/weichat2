package jp.co.sharedsys.wbb.jsf.api;

public class CurrentRawPath implements IAPI {

    public String getAPI() {
        return "@CURRENTRAWPATH@";
    }

    public String execute() {
        String p = System.getProperty("user.dir","");
        return p.replaceAll("[\\\\]","\\\\\\\\");
    }
}
