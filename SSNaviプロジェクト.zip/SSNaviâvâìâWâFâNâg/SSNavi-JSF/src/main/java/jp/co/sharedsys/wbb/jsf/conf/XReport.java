package jp.co.sharedsys.wbb.jsf.conf;

import java.util.ArrayList;
import java.util.List;

public class XReport {

    //RC01 configから。
    //RC02
    //RC03
    //RC04
    private String title = null;                //RC05
    private String pageTemplate = null;         //RC15
    private String screenCode = null;           //RC21
    private String screenSize = null;           //RC22
    private String lineDisp = null;             //RC23
    private String reloadCondition = null;      //RC24

    private List sqls = new ArrayList();
    private List conditions = new ArrayList();

    private List buttons = new ArrayList();
    private List formats = new ArrayList();

    private String version = null;

    // 2012.08.10 N.Ichijo Add
    private XReportModification modification = null;
    // 2012.08.10 N.Ichijo End
 
    public String getTitle() {
            return title;
    }
    public void setTitle(String title) {
            this.title = title;
    }
/*
    public String getExcelTemplate() {
            return excelTemplate;
    }
    public void setExcelTemplate(String excelTemplate) {
            this.excelTemplate = excelTemplate;
    }
*/
    
    public List getConditions() {
            return conditions;
    }
    public void setConditions(List conditions) {
            this.conditions = conditions;
    }
    public void addCondition(XReportCondition condition){
            this.conditions.add(condition);
    }
    public List getSqls() {
            return sqls;
    }
    public void setSqls(List sqls) {
            this.sqls = sqls;
    }
    public void addSql(XReportSql sql){
            this.sqls.add(sql);
    }
    public List getButtons() {
            return buttons;
    }
    public void setButtons(List buttons) {
            this.buttons = buttons;
    }
    public void addButton(XReportButton button){
            this.buttons.add(button);
    }
    public String getPageTemplate() {
            return pageTemplate;
    }
    public void setPageTemplate(String pageTemplate) {
            this.pageTemplate = pageTemplate;
    }
    public List getFormats() {
            return formats;
    }
    public void setFormats(List formats) {
            this.formats = formats;
    }
    public void addFormat(XReportFormat format){
            this.formats.add(format);
    }
    public String getVersion() {
            return version;
    }
    public void setVersion(String version) {
            this.version = version;
    }
    public String getReloadCondition() {
            return reloadCondition;
    }
    public void setReloadCondition(String reloadCondition) {
            this.reloadCondition = reloadCondition;
    }
    // 2012.08.10 N.Ichijo Add
    public XReportModification getModification() {
            return modification;
    }
    public void setModification(XReportModification modification) {
            this.modification = modification;
    }
    // 2012.08.10 N.Ichijo End
    public String getScreenCode() {
            return screenCode;
    }
    public void setScreenCode(String screenCode) {
            this.screenCode = screenCode;
    }

    /**
     * @return the screenSize
     */
    public String getScreenSize() {
        return screenSize;
    }

    /**
     * @param screenSize the screenSize to set
     */
    public void setScreenSize(String screenSize) {
        this.screenSize = screenSize;
    }

    /**
     * @return the lineDisp
     */
    public String getLineDisp() {
        return lineDisp;
    }

    /**
     * @param lineDisp the lineDisp to set
     */
    public void setLineDisp(String lineDisp) {
        this.lineDisp = lineDisp;
    }
}
