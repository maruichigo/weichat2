package jp.co.sharedsys.wbb.jsf.reports;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;

public class ReportModification implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 1674129991277453058L;
    private String mode = null;
    private String defaultLine = null;
    private String insert = null;
    private String update = null;
    private String delete = null;
    private boolean updateFlg = false;

    private List<ReportColumn> columns = new ArrayList<>();
    
    private Map<String, ReportColumn> columnsMap = null;
    private List<ReportColumn> contexts = null;
    
    public String getMode() {
        return mode;
    }
    public void setMode(String mode) {
        this.mode = mode;
    }
    public String getDefaultLine() {
        return defaultLine;
    }
    public void setDefaultLine(String defaultLine) {
        this.defaultLine = defaultLine;
    }
    public String getInsert() {
        return insert;
    }
    public void setInsert(String insert) {
        this.insert = insert;
    }
    public String getUpdate() {
        return update;
    }
    public void setUpdate(String update) {
        this.update = update;
    }
    public String getDelete() {
        return delete;
    }
    public void setDelete(String delete) {
        this.delete = delete;
    }
    public void addColumn(ReportColumn column) {
        this.columns.add(column);
    }
    public List<ReportColumn> getColumns() {
        return columns;
    }
    public boolean isUpdateFlg() {
        return updateFlg;
    }
    public void setUpdateFlg(boolean updateFlg){
        this.updateFlg = updateFlg;
    }
    public List<ReportColumn> getContexts() {
        return contexts;
    }
    
    /**
     * sortIndexでソートしたものをディープコピーで返却します
     * @return reportcolumn list
     */
    public List<ReportColumn> getColumnsSort(){
        return getColumnsSort(null);
    }
    /**
     * sortIndexでソートしたものをディープコピーで返却します
     * applyToが一致するもののみ対象とする。
     * @param applyTo applyTo
     * @return reportcolumn list
     */
    public List<ReportColumn> getColumnsSort(String applyTo){
        List<ReportColumn> newlist;
        if (StringUtils.isEmpty(applyTo)) {
            newlist = new ArrayList<>(columns);
        } else {
            newlist = new ArrayList<>();
            for (int i = 0; i < this.columns.size(); i++) {
                ReportColumn col = (ReportColumn) this.columns.get(i);
                if (applyTo.equals(col.getApplyTo())) {
                    newlist.add(col);
                }
            }
        }
        Collections.sort(newlist, new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                ReportColumn b1 = (ReportColumn)o1;
                ReportColumn b2 = (ReportColumn)o2;
                return b1.getSortIndex() - b2.getSortIndex();
            }
        });
        return newlist;
    }
    /**
     * 対象sectionに指定されているapplyToのリストを返却します。
     * sectionが一致するもののみ対象とする。
     * @param section section
     * @return applyTo list
     */
    public List<String> getApplyToSection(String section){
        List<String> newlist;
        if (StringUtils.isEmpty(section)) {
            newlist = new ArrayList<>();
        } else {
            newlist = new ArrayList<>();
            for (int i = 0; i < this.columns.size(); i++) {
                ReportColumn col = (ReportColumn) this.columns.get(i);
                if (section.equals(col.getSection())) {
                    newlist.add(col.getApplyTo());
                }
            }
        }
        return newlist;
    }
    /**
     * シングルレイアウト用にソートしたものをディープコピーで返却します。
     * ソート -&gt; line-endがある項目まで1行にする(list&gt;map([n],column))
     * @return map
     */
    public List<Map<Integer, ReportColumn>> getSingleLayoutList(){
        List<ReportColumn> sorted = getColumnsSort();
        List<Map<Integer, ReportColumn>> newList = new ArrayList<>();
        Map<Integer, ReportColumn> map = new TreeMap<>();
        int index = 0;
        for (int i=0; i<sorted.size();i++) {
            ReportColumn col = (ReportColumn)sorted.get(i);
            map.put(index, col);
            if(i == sorted.size() - 1){
                newList.add(map);
                break;
            }

            index ++;

        }
        return newList;
    }

    /**
     * PKのMAPを返す。
     * @return pk map
     */
    public Map<String, ReportColumn> getPkMap(){
        Map<String, ReportColumn> map = new HashMap<>();
        for(ReportColumn col : (List<ReportColumn>) columns) {
            if(col.isPk()){
                map.put(col.getName(), col);
            }
        }
        return map;
    }

    /**
     * PKのリストを返す。
     * @return pk list
     */
    public List<ReportColumn> getPkList() {
        return this.getPkList(null);
    }
    
    public List<ReportColumn> getPkListForSidebar() {
        List<String> applyTo = getApplyToSection(ReportConst.SECTION.HISTORY);
        if (applyTo.isEmpty()) return new ArrayList<>();
        return this.getPkList(applyTo.get(0));
    }
    /**
     * PKのリストを返す。
     * @param applyTo applyto
     * @return reportcolumn list
     */
    public List<ReportColumn> getPkList(String applyTo) {
        List<ReportColumn> result = new ArrayList<>();
        List<ReportColumn> list = getColumnsSort(applyTo);
        for(ReportColumn col : list) {
            if (col.isPk()) {
                result.add(col);
            }
        }
        return result;
    }

    /**
     * 登録・編集画面レイアウト用のリストを取得。
     * @param applyTo applyto
     * @return reporttable list
     */
    public List<ReportTable> getEditColumnLayout(String applyTo) {
        return getEditColumnLayout(applyTo, null);
    }

    /**
     * 登録・編集画面レイアウト用のリストを取得。
     * @param applyTo applyto
     * @param section section
     * @return reporttable list
     */
    public List<ReportTable> getEditColumnLayout(String applyTo, String section) {
        if (StringUtils.isEmpty(section)) {
            section = ReportConst.SECTION.LIST;
        }
        List<ReportTable> tableList = new ArrayList<>();
        ReportTable table = new ReportTable();

        List<List<List<AbstractReportCondition>>> lines = new ArrayList<>();
        List<List<AbstractReportCondition>> line = new ArrayList<>();
        List<AbstractReportCondition> cols = new ArrayList<>();

        List<ReportColumn> list = getColumnsSort(applyTo);
        for (int i = 0; i < list.size(); i++) {
            ReportColumn col = (ReportColumn) list.get(i);
            if (StringUtils.equals(ReportConst.ControlType.HIDDEN, col.getControlType())
                || !StringUtils.equals(section, StringUtils.isEmpty(col.getSection()) ? ReportConst.SECTION.LIST : col.getSection())) {
                // HIDDENは無視
                // sectionが違う場合も無視
                if (i == list.size() - 1) {
                    lines.add(line);
                    table.setLines(lines);
                    tableList.add(table);
                    break;
                }
                continue ;
            }

            cols = new ArrayList<>();
            cols.add(col);
            line.add(cols);

            if (i == list.size() - 1) {
                lines.add(line);
                table.setLines(lines);
                tableList.add(table);
                break;
            }

        }
        return tableList;
    }

    /**
     * 一覧画面レイアウト用のリストを取得。
     * @return reportlistcolumn
     */
    public List<ReportListColumn> getListColumnLayout() {
        return this.getListColumnLayout(null);
    }

    public List<ReportListColumn> getListColumnLayout(String applyTo) {
        return getListColumnLayout(applyTo, null);
    }
    
    /**
     * サイドバー表示部分レイアウト用のリストを取得。
     * @return reportlistcolumn
     */
    public List<ReportListColumn> getListColumnLayoutForHistory() {
        String applyTo = null;
        List<String> sortList = getApplyToSection(ReportConst.SECTION.HISTORY);
        if (sortList != null && !sortList.isEmpty()) {
            applyTo = sortList.get(0);
        }
        return getListColumnLayout(applyTo, ReportConst.SECTION.HISTORY);
    }

    /**
     * 一覧画面レイアウト用のリストを取得。
     * @param applyTo applyto
     * @param section section
     * @return reportlistcolumn
     */
    public List<ReportListColumn> getListColumnLayout(String applyTo, String section) {
        if (StringUtils.isEmpty(section)) {
            section = ReportConst.SECTION.LIST;
        }
        List<ReportListColumn> result = new ArrayList<>();
        ReportListColumn listCol = new ReportListColumn();

        List<ReportColumn> sortList = getColumnsSort(applyTo);
        for (int i = 0; i < sortList.size(); i++) {
            ReportColumn col = (ReportColumn) sortList.get(i);
            if (StringUtils.equals(ReportConst.ControlType.HIDDEN, col.getControlType())) {
                // HIDDENは無視
                continue ;
            }
            if (!section.equals(StringUtils.isEmpty(col.getSection()) ? ReportConst.SECTION.LIST : col.getSection())) {
                // sectionが同じ場合に対象とする(sectionの設定が無い場合はLISTと同等)
                continue ;
            }            

            listCol = new ReportListColumn();
            if (StringUtils.equals(ReportConst.ControlType.CHECKBOX, col.getControlType())
                    || StringUtils.equals(ReportConst.ControlType.BUTTON, col.getControlType())) {
                // ソートしない
                listCol.setSortFlg(false);
                listCol.setAlign("center");

                if (StringUtils.equals(ReportConst.ControlType.CHECKBOX, col.getControlType())) {
                    listCol.setAllChkFlg(true);
                }
            }

            if (StringUtils.equals(ReportConst.DataType.INT, col.getDataType())
                    || StringUtils.equals(ReportConst.DataType.DECIMAL, col.getDataType())
                    || StringUtils.equals(ReportConst.DataType.NUMBER, col.getDataType())) {
                listCol.setAlign("right");
            }
            listCol.setDisplayName(col.getDisplayName());
            listCol.addCol(col);
            result.add(listCol);
        }
        return result;
    }

    /**
     * 最大タブインデックスの取得。
     * @param applyTo applyto
     * @return int
     */
    public int getMaxTabIndex(String applyTo) {
        int res = 0;
        List<ReportColumn> list = getColumnsSort(applyTo);
        for (ReportColumn col : list) {
            if (res < col.getTabIndex()) {
                res = col.getTabIndex();
            }
        }
        return res;
    }

    /**
     * コントロールタイプ別リストを取得。
     * @param applyTo applyto
     * @param section section
     * @param controlTypes controlType
     * @return reportcolumn list
     */
    public List<ReportColumn> getControlTypeList(String applyTo, String section, String... controlTypes) {
        if (StringUtils.isEmpty(section)) {
            section = ReportConst.SECTION.LIST;
        }
        List<ReportColumn> list = getColumnsSort(applyTo);
        List<ReportColumn> result = new ArrayList<>();
        for (ReportColumn col : list) {
            for (String type : controlTypes) {
                if (StringUtils.equals(type, col.getControlType())) {
                    if (section.equals(StringUtils.isEmpty(col.getSection()) ? ReportConst.SECTION.LIST : col.getSection())) {
                        // sectionが同じ場合に対象とする(sectionの設定が無い場合はLISTと同等)
                        result.add(col);
                    }
                }
            }
        }
        contexts = result;
        return result;
    }

    /**
     * コントロールタイプ「HIDDEN」のリストを返す
     * @param applyTo applyto
     * @return reportcolumn list
     */
    public List<ReportColumn> getHiddenList(String applyTo) {
        return getControlTypeList(applyTo, null, ReportConst.ControlType.HIDDEN);
    }
    
    public List<ReportColumn> getHiddenList(String applyTo, String section) {
        return getControlTypeList(applyTo, section, ReportConst.ControlType.HIDDEN);
    }

    /**
     * コントロールタイプ「BUTTON」のリストを返す
     * @param applyTo applyto
     * @return reportcolumn list
     */
    public List<ReportColumn> getButtonList(String applyTo) {
        return getControlTypeList(applyTo, null, ReportConst.ControlType.BUTTON);
    }
    
    public List<ReportColumn> getButtonList(String applyTo, String section) {
        return getControlTypeList(applyTo, section, ReportConst.ControlType.BUTTON);
    }

    /**
     * コントロールタイプ「CONTEXT」のリストを返す
     * @param applyTo applyto
     * @return reportcolumn list
     */
    public List<ReportColumn> getContextList(String applyTo) {
        return getControlTypeList(applyTo, null, ReportConst.ControlType.CONTEXT);
    }
    
    public List<ReportColumn> getContextList(String applyTo, String section) {
        return getControlTypeList(applyTo, section, ReportConst.ControlType.CONTEXT);
    }

    /**
     * カラム情報の取得
     * @param name name
     * @return reportcolumn
     */
    public ReportColumn getColumn(String name) {
        ReportColumn result = null;
        for (ReportColumn col : this.columns) {
            if (StringUtils.equals(name, col.getName())) {
                result = col;
                break ;
            }
        }
        return result;
    }

    /**
     * カラム情報の取得
     * @param applyTo applyto
     * @param name name
     * @return reportcolumn
     */
    public ReportColumn getColumn(String applyTo, String name) {
        ReportColumn result = null;
        List<ReportColumn> cols = getColumnsSort(applyTo);
        for (ReportColumn col : cols) {
            if (StringUtils.equals(name, col.getName())) {
                result = col;
                break ;
            }
        }
        return result;
    }

    
    /**
     * カラム情報の取得(Mapから)
     * @param applyTo applyto
     * @param name name
     * @return reportcolumn
     */
    public ReportColumn getColumnSoft(String applyTo, String name) {
        if (columnsMap == null) {
            columnsMap = new LinkedHashMap<>();
            List<ReportColumn> cols = getColumnsSort(applyTo);
            for (ReportColumn col : cols) {
                columnsMap.put(col.getName(), col);
            }
        }
        return columnsMap.get(name);
    }
    
    /**
     * カラム情報の存在チェック
     * @param name name
     * @return iscolumn
     */
    public boolean isColumn(String name) {
        ReportColumn col = this.getColumn(name);
        return col != null;
    }

    /**
     * カラム情報の存在チェック
     * @param applyTo applyto
     * @param name name
     * @return iscolumn
     */
    public boolean isColumn(String applyTo, String name) {
        ReportColumn col = this.getColumn(applyTo, name);
        return col != null;
    }

    /**
     * ヘルプボタンの取得
     * @return reportcolumn
     */
    public List<ReportColumn> getHelpColumns() {
        List<ReportColumn> result = new ArrayList<>();
        List<ReportColumn> sortList = getColumnsSort();
        for (ReportColumn col : sortList) {
            if (StringUtils.equals(ReportConst.ControlType.BUTTON, col.getControlType())
                    && StringUtils.equals(ReportConst.DataType.HELP, col.getDataType())) {
                result.add(col);
            }
        }
    return result;
    }
}
