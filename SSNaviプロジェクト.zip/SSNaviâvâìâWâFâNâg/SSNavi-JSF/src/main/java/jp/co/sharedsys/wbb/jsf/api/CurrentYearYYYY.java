package jp.co.sharedsys.wbb.jsf.api;

import java.text.SimpleDateFormat;
import java.util.Date;

public class CurrentYearYYYY implements IAPI {

    public String execute() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy");
        return format.format(new Date());
    }

    public String getAPI() {
        return "@yyyy@";
    }
}
