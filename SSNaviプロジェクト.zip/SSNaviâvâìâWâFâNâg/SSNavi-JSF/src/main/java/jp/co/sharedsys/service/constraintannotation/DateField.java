package jp.co.sharedsys.service.constraintannotation;

import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

/** 文字列フィールド用アノテーション
 * @author sharedsys
 *
 */
@Target({ METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER })
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = { DateFieldValidator.class })
public @interface DateField {

	
    @SuppressWarnings("javadoc")
    @Documented
    @Target({ElementType.TYPE, ElementType.METHOD, ElementType.FIELD, ElementType.CONSTRUCTOR, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE})
    @Retention(RetentionPolicy.RUNTIME)
    public @interface List {
        DateField[] value();
    }

    /** チェック結果メッセージ取得
     * @return チェック結果メッセージ
     */
    String message() default "";
    
    /** カラム名取得
     * @return カラム名
     */
    String columnName();
    
    /**　NotNullフラグ取得(true:NotNull false:Null (NULL許可))
     * @return NotNull許可フラグ
     */
    boolean isNotNull() default false;
    
    /**　グループの取得
     * @return グループ
     */
    Class<?>[] groups() default {};

    /**　Payload取得
     * @return Payload
     */
    Class<? extends Payload>[] payload() default {};
}