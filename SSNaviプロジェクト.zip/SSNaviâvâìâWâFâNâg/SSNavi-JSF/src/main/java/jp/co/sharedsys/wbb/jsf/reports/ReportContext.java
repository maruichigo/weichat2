package jp.co.sharedsys.wbb.jsf.reports;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import jp.co.sharedsys.bb.ReportFileFilter;

import org.apache.commons.beanutils.BeanComparator;
import org.apache.commons.digester.Digester;
import org.apache.commons.digester.xmlrules.DigesterLoader;
import org.apache.commons.io.comparator.NameFileComparator;
import org.apache.commons.lang.StringUtils;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import jp.co.sharedsys.wbb.jsf.exception.SystemException;
import jp.co.sharedsys.wbb.jsf.conf.XReport;
import jp.co.sharedsys.wbb.jsf.conf.XReportButton;
import jp.co.sharedsys.wbb.jsf.conf.XReportColumn;
import jp.co.sharedsys.wbb.jsf.conf.XReportColumnOption;
import jp.co.sharedsys.wbb.jsf.conf.XReportCondition;
import jp.co.sharedsys.wbb.jsf.conf.XReportConditionOption;
import jp.co.sharedsys.wbb.jsf.conf.XReportFormat;
import jp.co.sharedsys.wbb.jsf.conf.XReportSql;
import jp.co.sharedsys.wbb.jsf.modules.PdfConfigReader;
import jp.co.sharedsys.wbb.jsf.process.ExternalGetAuthorityProcess;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ReportContext {
    private static Map instances = new HashMap();
    private Map<String,ReportConfig> configs = new HashMap<>();
    private Map<String, String> screenCodes = new HashMap<>();
    private Map<String, List<ReportConfig>> configListMap = new HashMap<>();
    private List<ReportAppConfig> repordirs = new ArrayList<>();
    private String confDirectory = null;
    private static final String confName = "report_rule.xml";
    private static final String appConfName = "rep_description_rule.xml";
    private boolean isExternalRefresh = false;
    private Logger logger;
    
    public ReportContext(){
    }

    // JSFのApplicationScopedクラスに持たせるため、Singletonを止める
//	public static ReportContext getInstance(String key){
//		synchronized (instances) {
//			if (instances.containsKey(key)){
//				return (ReportContext) instances.get(key);
//			}else{
//				ReportContext instance = new ReportContext();
//				instances.put(key, instance);
//				return instance;
//			}
//		}
//	}

    public void addReport(String group,ReportConfig report){
    }

    public void init(){
        configs.clear();
        configListMap.clear();
        repordirs.clear();
        logger = LoggerFactory.getLogger("system");
    }


    public void loadDir(File reportapp) throws SystemException {
        Digester d = null;
        ReportAppConfig app = new ReportAppConfig();
        try {
            d = DigesterLoader.createDigester(new InputSource(new FileReader(new File(this.getConfDirectory() + "/conf/" + appConfName))));
            logger.info("DESCRIPTION LOAD START:" + reportapp.getName());
            app = (ReportAppConfig) d.parse(new File(reportapp,"description.xml"));
            app.setDirectory(reportapp.getName());
            logger.info("SHOW-IN-MENU(" + app.getTitle() + "):");
        } catch (FileNotFoundException e) {
            logger.warn("Report descrition file was not found.[" + reportapp.getPath() + "]");
            app.setDirectory(reportapp.getName());
            app.setTitle(reportapp.getName());
        } catch (IOException e) {
            logger.warn("Error reading report description", e);
            app.setDirectory(reportapp.getName());
            app.setTitle(reportapp.getName());
        } catch (SAXException e) {
            logger.warn("Error reading report description", e);
            app.setDirectory(reportapp.getName());
            app.setTitle(reportapp.getName());
        } finally {
            logger.info("DESCRIPTION LOAD END:" + reportapp.getName());
        }
        this.repordirs.add(app);
        File[] reports = reportapp.listFiles(new ReportFileFilter());
        List reportslist = new ArrayList();
        if (reports != null){
            reportslist = Arrays.asList(reports);
        }
        Collections.sort(reportslist,NameFileComparator.NAME_COMPARATOR);

        configListMap.put(reportapp.getName(), new ArrayList());
        for (Iterator ite = reportslist.iterator();ite.hasNext();){
        //for (int i = 0;i < reports.length;i++){
            loadFile(reportapp,(File) ite.next());
        }
    }

    public synchronized void loadFile(File reportapp,File reportConfig) throws SystemException{
        Digester d = null;

        try {
                d = DigesterLoader.createDigester(new InputSource(new FileReader(new File(this.getConfDirectory() + "/conf/" + confName))));
        } catch (FileNotFoundException e) {
                throw new SystemException(e);
        }
        try {
	    //Logger.getInstance("").info("!!!!!!!!!!!!!!!!!! name : " + reportConfig.getName());
             XReport xreport = (XReport) d.parse(reportConfig);
	    
            //Initialize reportconfig instance with xml paramters
            ReportConfig report  = new ReportConfig();
            report.setConfigFilePath(reportConfig.getPath());   //RC01
            report.setConfigDirectory(reportapp.getName());     //RC02
            report.setConfigFileName(reportConfig.getName());   //RC03
            report.setLastModified(reportConfig.lastModified());//RC04
            report.setTitle(xreport.getTitle());                //RC05
            report.setPageTemplate(xreport.getPageTemplate());      //RC15
            report.setReloadCondition("true".equalsIgnoreCase(xreport.getReloadCondition()));//RC16
            report.setScreenCode(xreport.getScreenCode());          //RC21
            report.setScreenSize(xreport.getScreenSize());          //RC22
            report.setLineDisp(xreport.getLineDisp());              //RC23

            for (Iterator ite = xreport.getConditions().iterator();ite.hasNext();){
                XReportCondition xcondition = (XReportCondition) ite.next();
                ReportCondition condition = new ReportCondition();
                condition.setName(xcondition.getName());//2物理名×
                condition.setDisplayName(xcondition.getDisplayName());//1項目名×
                condition.setControlType(xcondition.getControlType());//3コンポーネント×
                condition.setDataType(xcondition.getDataType());//4データ種別×
                condition.setAlign(null != xcondition.getAlign() ? xcondition.getAlign():"");//5配置〇
                condition.setVisible("true".equalsIgnoreCase(StringUtils.isEmpty(xcondition.getVisible()) ? "true" : xcondition.getVisible()));//6表示有無×
                //7読み取り専用×
                condition.setDefaultValue(xcondition.getDefaultValue());//9設定初期値×
                try {
                        condition.setMinLength(Integer.parseInt(xcondition.getMinLength()));//13桁数最小×
                }catch(Exception ex){
                }
                try {
                        condition.setMaxLength(Integer.parseInt(xcondition.getMaxLength()));//14桁数最大×
                }catch(Exception ex){
                }
                
                condition.setApplyTo(xcondition.getApplyTo());//17データ参照先×
                //25少数点対象外
                //27テーブル終了対象外
                //28テーブル切り替え対象外
                //29PK対象外
                try {
                        condition.setTabIndex(Integer.parseInt(xcondition.getTabIndex()));//30TabIndex〇
                }catch(Exception ex){
                }
                //34テーブル名対象外
                //35準必須項目〇
                //36FunctionCode×
                condition.setExtra1(xcondition.getExtra1());//43追加項目１〇
                condition.setExtra2(xcondition.getExtra2());//44追加項目２〇
                condition.setExtra3(xcondition.getExtra3());//45追加項目３〇
                condition.setExtra4(xcondition.getExtra4());//46追加項目４〇
                condition.setExtra5(xcondition.getExtra5());//47追加項目５〇
                condition.setSection(xcondition.getSection());//48セクション表示ラベル対象外

                //16選択項目参照先×
                boolean condOptChecked = false;
                for (Iterator oite = xcondition.getOptions().iterator();oite.hasNext();){
                    XReportConditionOption xoption = (XReportConditionOption) oite.next();
                    ReportConditionOption option = new ReportConditionOption();
                    option.setLabel(xoption.getLabel());//表示ラベル×
                    option.setValue(xoption.getValue());//値×
                    {
                        boolean checked = "true".equalsIgnoreCase(xoption.getChecked());
                        if (checked) condOptChecked = checked;
                        option.setChecked(checked);//初期チェック状態×
                    }
                    option.setService(xoption.getService());//呼出サービス対象外
                    option.setFunctionCode(xoption.getFunctionCode());//FunctionCode×
                    option.setServiceParameter(xoption.getServiceParameter());//サービスパラメーター対象外
                    //ソートインデックスsort-index

                    option.setTableName(xoption.getTableName());
                    
                    condition.getOptions().add(option);
                    condition.getOriginalOptions().add(option);
                }
                if (!condOptChecked && !condition.getOptions().isEmpty()) {
                    condition.getOptions().get(0).setChecked(true);
                    condition.getOriginalOptions().get(0).setChecked(true);
                }
                report.getConditions().add(condition);
            }

            for (Iterator ite = xreport.getSqls().iterator();ite.hasNext();){
                XReportSql xsql = (XReportSql) ite.next();
                ReportSql sql = new ReportSql();
                sql.setName(xsql.getName());
                sql.setTemplateFile(xsql.getTemplateFile());
                sql.setService(xsql.getService());
                sql.setFunctionCode(xsql.getFunctionCode());
                sql.setTableName(xsql.getTableName());
                report.getSqls().add(sql);
            }

            for (Iterator ite = xreport.getButtons().iterator();ite.hasNext();){
                XReportButton xbutton = (XReportButton) ite.next();
                ReportButton button = new ReportButton();
                button.setName(xbutton.getName());
                button.setValue(xbutton.getValue());
                button.setAction(xbutton.getAction());
                button.setRptFile(xbutton.getRptFile());
                button.setRptDir(xbutton.getRptDir());
                button.setService(xbutton.getService());
                button.setFunctionCode(xbutton.getFunctionCode());

                button.setPosition(xbutton.getPosition());
                for (Iterator oite = xbutton.getOptions().iterator();oite.hasNext();){
                    XReportConditionOption xoption = (XReportConditionOption) oite.next();
                    ReportConditionOption option = new ReportConditionOption();
                    option.setLabel(xoption.getLabel());
                    option.setValue(xoption.getValue());
                    option.setChecked("true".equalsIgnoreCase(xoption.getChecked()));
                    option.setService(xoption.getService());
                    option.setFunctionCode(xoption.getFunctionCode());
                    option.setServiceParameter(xoption.getServiceParameter());
                    button.getOptions().add(option);
                    button.getOriginalOptions().add(option);
                }

                report.getButtons().add(button);
            }

            for (Iterator ite = xreport.getFormats().iterator();ite.hasNext();){
                XReportFormat xformat = (XReportFormat) ite.next();
                ReportFormat format = new ReportFormat();
                report.getFormats().add(format);
            }

            // 2012.08.13 N.Ichijo Add
            ReportModification mod = new ReportModification();
            if(xreport.getModification() != null){
                mod.setDefaultLine(xreport.getModification().getDefaultLine());
                mod.setDelete(xreport.getModification().getDelete());
                mod.setInsert(xreport.getModification().getInsert());
                mod.setMode(xreport.getModification().getMode());
                mod.setUpdate(xreport.getModification().getUpdate());
                report.setModification(mod);
                for (Iterator ite = xreport.getModification().getColumns().iterator();ite.hasNext();){
                    XReportColumn xcolumn = (XReportColumn) ite.next();
                    ReportColumn column = new ReportColumn();
                    column.setName(xcolumn.getName());
                    column.setDisplayName(xcolumn.getDisplayName());
                    column.setControlType(xcolumn.getControlType());
                    column.setDataType(xcolumn.getDataType());
                    column.setDefaultValue(xcolumn.getDefaultValue());
                    column.setApplyTo(xcolumn.getApplyTo());
                    try {
                            column.setMinLength(Integer.parseInt(xcolumn.getMinLength()));
                    }catch(Exception ex){
                    }
                    try {
                            column.setMaxLength(Integer.parseInt(xcolumn.getMaxLength()));
                    }catch(Exception ex){
                    }
                    try {
                            column.setSortIndex(Integer.parseInt(xcolumn.getSortIndex()));
                    }catch(Exception ex){
                    }
                    try {
                            column.setTabIndex(Integer.parseInt(xcolumn.getTabIndex()));
                    }catch(Exception ex){
                    }
                    column.setReadonly("true".equalsIgnoreCase(xcolumn.getReadonly()));
                    column.setPk("true".equalsIgnoreCase(xcolumn.getPk()));
                    boolean columnOptChecked = false;
                    for (Iterator oite = xcolumn.getOptions().iterator();oite.hasNext();){
                        XReportColumnOption xoption = (XReportColumnOption) oite.next();
                        ReportColumnOption option = new ReportColumnOption();
                        boolean checked = "true".equalsIgnoreCase(xoption.getChecked());
                        if (checked) columnOptChecked = true;
                        option.setLabel(xoption.getLabel());
                        option.setValue(xoption.getValue());
                        option.setChecked(checked);
                        option.setService(xoption.getService());
                        option.setFunctionCode(xoption.getFunctionCode());
                        option.setServiceParameter(xoption.getServiceParameter());
                        column.getOptions().add(option);
                        column.getOriginalOptions().add(option);
                    }
                    if (!columnOptChecked && !column.getOptions().isEmpty()) {
                        column.getOptions().get(0).setChecked(true);
                        column.getOriginalOptions().get(0).setChecked(true);
                    }
                    column.setTransferRptFile(xcolumn.getTransferRptFile());
                    column.setTransferRptDir(xcolumn.getTransferRptDir());
                    column.setTableName(xcolumn.getTableName());
                    column.setService(xcolumn.getService());
                    column.setFunctionCode(xcolumn.getFunctionCode());
                    column.setExtra1(xcolumn.getExtra1());
                    column.setExtra2(xcolumn.getExtra2());
                    column.setExtra3(xcolumn.getExtra3());
                    column.setExtra4(xcolumn.getExtra4());
                    column.setExtra5(xcolumn.getExtra5());
                    column.setSection(xcolumn.getSection());
                    column.setVisible("true".equalsIgnoreCase(StringUtils.isEmpty(xcolumn.getVisible()) ? "true" : xcolumn.getVisible()));
                    report.getModification().getColumns().add(column);
		}
            }
            // 2012.08.13 N.Ichijo End
            // タブ順をキレイに揃える
            List<ReportColumn> colList = report.getModification().getColumns();
            Collections.sort(colList,  new BeanComparator("tabIndex"));
            int tabidx = 1;
            for(ReportColumn col : colList) {
                if (StringUtils.equals("HIDDEN", col.getControlType())
                    || StringUtils.equals("LABEL", col.getControlType())) {
                    // HIDDENとLABELはタブ順の設定はしないため、-1をセット
                    col.setTabIndex(-1);
                } else {
                    if (col.getTabIndex() < 0) {
                        col.setTabIndex(col.getTabIndex());
                    } else {
                        col.setTabIndex(tabidx);
                        tabidx++;
                    }
                }
            }

            //Reload時用の処理
//			configs.put(reportapp.getName() + "." + reportConfig.getName() , report);
            this.configs.put(report.getScreenCode(), report);
            this.screenCodes.put(reportapp.getName() + "." + reportConfig.getName(), report.getScreenCode());
            
            List<ReportConfig> reportList = configListMap.get(reportapp.getName());
            boolean modified = false;
            for (int i = 0;i < reportList.size();i++){
                //登録済みのReportConfigがあった場合、新規の読み込んだものと差し替え
                ReportConfig reportconfig = reportList.get(i);
                if (reportconfig.getConfigFilePath().equals(report.getConfigFilePath())){
                    reportList.set(i, report);
                    modified = true;
                }
            }
            //前回の読み込みからファイルが増えている
            if (!modified){
                    reportList.add(report);
            }

        } catch (IOException e) {
            throw new SystemException(e);
        } catch (SAXException e) {
            throw new SystemException(e);
        }
    }

    /**
     * 外部からのメニュー情報取得
     * @param externalService exservice name
     * @param externalFunction function code
     * @param externalUser username
     */
    public void loadExternal(String externalService, String externalFunction, String externalUser) {
        // 更新は1回のみ。既にされていたら何もしない
    //    if (isExternalRefresh) return;
        ExternalGetAuthorityProcess process = new ExternalGetAuthorityProcess();
        List<Map<String, Object>> result = process.externalService(externalUser, Arrays.asList(new String[]{"dummy"}), externalService, externalFunction, "", this.createGetAuthParameter(externalUser));
	
	this.buildDbMenuList(result);
	isExternalRefresh = true;
    }
    
    private List<Map<String, Object>> createGetAuthParameter(String externalUser) {
        List<Map<String, Object>> prmList = new ArrayList<>();
	Map<String, Object> data = new HashMap<>();
        prmList.add(data);
        data.put("UserCd", externalUser);

        return prmList;
    }
    
    private Map<String, List<Map<String, List<String>>>> menuMap = new LinkedHashMap<>();
    private Map<String, String> iconMap = new HashMap<>();
    private Map<String, String> groupNameMap = new HashMap<>();
    
    private void buildDbMenuList(List<Map<String, Object>> authResult) {
        Map<String, List<Map<String, List<String>>>> result = new LinkedHashMap<>();
	String lastParentId = "";
	String lastChildId = "";
	Map<String, List<String>> childMap = new LinkedHashMap<>();
	List<Map<String, List<String>>> childList = new ArrayList();
	List<String> menuList = new ArrayList();
	Map<String, List<ReportConfig>> configs = this.getConfigListMap();
        
	for (Map<String, Object> auth : authResult) {
	    String parentId = (String)auth.get("parentGroupId");
	    String parentName = (String)auth.get("parentGroupName");
	    String parentIcon = (String)auth.get("parentIconPath");
	    String childId = (String)auth.get("childGroupId");
	    String childName = (String)auth.get("childGroupName");
	    String childIcon = (String)auth.get("childIconPath");
	    String menuId = (String)auth.get("menuId");
	    String menuName = (String)auth.get("menuName");
	    String kinoCd = (String)auth.get("kinoCd");
	    String rptDirectory = (String)auth.get("rptDirectory");
	    String rptFileName = (String)auth.get("rptFileName");
		String bridge = (String)auth.get("bridge");
	    
		// 違う親メニューの場合、前までの子メニューをresultに追加し、子メニューリストを新しくする
	    if(!parentId.equals(lastParentId)){
		if(!menuList.isEmpty()){
		    // 子メニューマップに追加
		    childMap.put(lastChildId, menuList);
		}
		if(!childMap.isEmpty()){
		    // 子メニューリストに追加
		    childList.add(childMap);
		}
		if(!childList.isEmpty()){
		    // rootとなるMapに子メニューリストを追加
		    result.put(lastParentId, childList);
		}
		menuList = new ArrayList<>();
		childMap = new HashMap<>();
		childList = new ArrayList<>();
		
		groupNameMap.put(parentId, parentName);
	    }
	    
	    // 違う子メニューの場合、前までの分を子メニューに追加して画面リストを新しくする
	    if(!childId.equals(lastChildId)){
		if(!menuList.isEmpty()){
		    childMap.put(lastChildId, menuList);
		}
		menuList = new ArrayList<>();
		


		groupNameMap.put(childId, childName);
	    }

		// ReportConfigの一覧にDB取得したメニューのrptDirectoryが含まれるかチェック
		List<ReportConfig> catConfigList = configs.get(rptDirectory);
		// 無い場合は空のリストを新規作成
		if (catConfigList == null) {
                    catConfigList = new ArrayList<>();
                    configs.put(rptDirectory, catConfigList);
                }
		
                ReportConfig tmpconf = null;
		for(ReportConfig conf : catConfigList){
		    // directoryで絞ったconfigsの中に該当のrptファイルがあるかチェック
                    if (conf != null && conf.getConfigFileName().equals(rptFileName)) {
			tmpconf = conf;
			break;
                    }
		}
                if (tmpconf == null) {
                    // rptファイルなし
                    continue;
                }
		
		// rptファイルありの場合
                ReportConfig config = null;
		if(catConfigList.isEmpty()){
                    // MENUで指定されているDirectoryとSCREENのDirectoryが違う場合はリストに追加
                    config = (ReportConfig)tmpconf.clone();
                    catConfigList.add(config);
                } else {
                    config = tmpconf;
                }

                // DBの内容でtitle,screenCodeを書き換える
                config.setTitle(menuName);
                config.setScreenCode(kinoCd);
                this.configs.put(config.getScreenCode(), config);
                this.screenCodes.put(config.getConfigDirectory() + "." + config.getConfigFileName(), config.getScreenCode());	    // 画面リストに追加
	    menuList.add(kinoCd);
	    
	    // 今回の値を保存
	    lastChildId = childId;
	    lastParentId = parentId;

        //configsに該当スクリーンが存在する場合、属性を新たに追加
        if (this.configs.containsKey(kinoCd)){
            this.configs.get(kinoCd).setBridge(bridge);//ブリッジID(クラス名）
        }
    }
	// 最後に全部追加
	if(!menuList.isEmpty()){
	    childMap.put(lastChildId, menuList);
	}
	if(!childMap.isEmpty()){
	    childList.add(childMap);
	}
	if(!childList.isEmpty()){
	    result.put(lastParentId, childList);
	}
	
	this.menuMap = result;

    }

    public String getConfDirectory() {
        return confDirectory;
    }

    public void setConfDirectory(String confDirectory) {
        this.confDirectory = confDirectory;
    }

    public Map<String, ReportConfig> getConfigs() {
        return configs;
    }
    public Map<String, String> getScreenCodes() {
        return screenCodes;
    }

    public Map<String, List<ReportConfig>> getConfigListMap() {
        return configListMap;
    }

    public List<ReportAppConfig> getRepordirs() {
        return repordirs;
    }

    public Map<String, List<Map<String, List<String>>>> getMenuMap(){
	return menuMap;
    }
    
    public String getGroupName(String groupId){
	return groupNameMap.get(groupId);
    }
}
