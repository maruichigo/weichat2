/*
 * SvfDataModel.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.common.svf;

import jp.co.sharedsys.wbb.jsf.external.general.ExternalServiceProperty;

/**
 * Svfで使用する情報のModelクラスです。
 *
 * @author sharedSystem
 */
public class SvfDataModel {
    
    private final String PTN_PDF = "PDF";
    private final String PTN_EXCEL = "Excel";
    private final String PTN_PREV = "PREV";
    private final String PTN_PRINT = "PRINT";
    private final String CONTEXT_TYPE_EXCEL = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    private final String CONTEXT_TYPE_PDF = "application/pdf"; 
    private final String CONTEXT_TYPE_PREV = "text/plain"; 
    private String PREV_TOP = ExternalServiceProperty.getInstance().getProperty("svf-prevtop");
    private String PREV_LEFT = ExternalServiceProperty.getInstance().getProperty("svf-prevleft");
    private String PREV_WIDTH = ExternalServiceProperty.getInstance().getProperty("svf-prevWidth");
    private String PREV_HEIGHT = ExternalServiceProperty.getInstance().getProperty("svf-prevHeight");
    
    private String UserCd;              // ユーザーID
    private String chohyoGroupId;       // 帳票グループID    
    private String chohyoId;            // 帳票ID
    private String yoshiId;             // 用紙ID
    private String shutsuryokuFileMei;  // 出力ファイル名
    private String docName;             // スプールされる際のドキュメント名
    private String fileFormat;          // ファイル形式　PDF、Excel、PREV、PRINT
    private String dataFilePath;        // データファイル（CSV）のAPサーバー上でのフルパス
    private String cotextType;          // コンテキストタイプ
    private int adjustX;                // 印字位置の調整　(X座標をmm単位に指定) 
    private int adjustY;                // 印字位置の調整　(Y座標をmm単位に指定)
    private boolean prevFlag;           // プレビューするかどうか false:しない true:する
    private String prevFileUrl;         // プレビューするファイルのURL
    private String outPutFileName;      // 実際に出力されるemfファイル名
    private boolean completeFlag;       // 完了フラグ

    // 印刷用
    private String printerId;           // 使用するプリンターID
    private String printerName;         // 使用するプリンター名
    private String trayId;              // 使用するトレイID
    private String trayName;            // 使用するトレイ名
    private String traySeigyoMode;      // トレイ制御モード 1:ドライバー取得順指定 未設定:トレイ指定なし 
    private boolean printerSetFlag;     // プリンター設定 false:不可 true:可能
    
    // DB更新用
    private boolean dbUpdateFlag;       // 業務DB更新フラグ false:更新しない true:更新する
    private String printId;             // 印刷ID
    
    // 画面URL
    private String endUrl;              // エンドURL
    private String closeUrl;            // クローズURL
    private String errorUrl;            // エラーURL
    private String cancelUrl;           // キャンセルURL
    
    // SVF処理を行うクラスとメソッド
    private String svfBizClass;         // クラス
    private String svfBizMethod;        // メソッド
        
    public void SvfDataModel(){
        this.prevFlag = false;
        this.completeFlag = false;
        this.printerSetFlag = false;
        this.prevFileUrl = "";
        this.adjustX = 0;
        this.adjustY = 0;  
    }
        
    /**
     * @return the prevFlag
     */
    public boolean isPrevFlag() {
        return prevFlag;
    }

    /**
     * @param prevFlag the prevFlag to set
     */
    public void setPrevFlag(boolean prevFlag) {
        this.prevFlag = prevFlag;
    }

    /**
     * @return the chohyoId
     */
    public String getChohyoId() {
        return chohyoId;
    }

    /**
     * @param chohyoId the chohyoId to set
     */
    public void setChohyoId(String chohyoId) {
        this.chohyoId = chohyoId;
    }

    /**
     * @return the yoshiId
     */
    public String getYoshiId() {
        return yoshiId;
    }

    /**
     * @param yoshiId the yoshiId to set
     */
    public void setYoshiId(String yoshiId) {
        this.yoshiId = yoshiId;
    }

    /**
     * @return the shutsuryokuFileMei
     */
    public String getShutsuryokuFileMei() {
        return shutsuryokuFileMei;
    }

    /**
     * @param shutsuryokuFileMei the shutsuryokuFileMei to set
     */
    public void setShutsuryokuFileMei(String shutsuryokuFileMei) {
        this.shutsuryokuFileMei = shutsuryokuFileMei;
    }

    /**
     * @return the fileFormat
     */
    public String getFileFormat() {
        return fileFormat;
    }

    /**
     * @param fileFormat the fileFormat to set
     */
    public void setFileFormat(String fileFormat) {
        this.fileFormat = fileFormat;
    }

    /**
     * @return the dataFilePath
     */
    public String getDataFilePath() {
        return dataFilePath;
    }

    /**
     * @param dataFilePath the dataFilePath to set
     */
    public void setDataFilePath(String dataFilePath) {
        this.dataFilePath = dataFilePath;
    }

    /**
     * @return the adjustX
     */
    public int getAdjustX() {
        return adjustX;
    }

    /**
     * @param adjustX the adjustX to set
     */
    public void setAdjustX(int adjustX) {
        this.adjustX = adjustX;
    }

    /**
     * @return the adjustY
     */
    public int getAdjustY() {
        return adjustY;
    }

    /**
     * @param adjustY the adjustY to set
     */
    public void setAdjustY(int adjustY) {
        this.adjustY = adjustY;
    }

    /**
     * @return the PTN_EXCEL
     */
    public String getPTN_EXCEL() {
        return PTN_EXCEL;
    }

    /**
     * @return the PTN_PREV
     */
    public String getPTN_PREV() {
        return PTN_PREV;
    }

    /**
     * @return the PTN_PDF
     */
    public String getPTN_PDF() {
        return PTN_PDF;
    }

    /**
     * @return the CONTEXT_TYPE_EXCEL
     */
    public String getCONTEXT_TYPE_EXCEL() {
        return CONTEXT_TYPE_EXCEL;
    }

    /**
     * @return the CONTEXT_TYPE_PDF
     */
    public String getCONTEXT_TYPE_PDF() {
        return CONTEXT_TYPE_PDF;
    }

    /**
     * @return the CONTEXT_TYPE_PREV
     */
    public String getCONTEXT_TYPE_PREV() {
        return CONTEXT_TYPE_PREV;
    }

    /**
     * @return the prevFileUrl
     */
    public String getPrevFileUrl() {
        return prevFileUrl;
    }

    /**
     * @param prevFileUrl the prevFileUrl to set
     */
    public void setPrevFileUrl(String prevFileUrl) {
        this.prevFileUrl = prevFileUrl;
    }
    
    /**
     * @return the cotextType
     */
    public String getCotextType() {
        return cotextType;
    }

    /**
     * @param cotextType the cotextType to set
     */
    public void setCotextType(String cotextType) {
        this.cotextType = cotextType;
    }

    /**
     * @return the PTN_PRINT
     */
    public String getPTN_PRINT() {
        return PTN_PRINT;
    }

    /**
     * @return the printerSetFlag
     */
    public boolean isPrinterSetFlag() {
        return printerSetFlag;
    }

    /**
     * @param printerSetFlag the printerSetFlag to set
     */
    public void setPrinterSetFlag(boolean printerSetFlag) {
        this.printerSetFlag = printerSetFlag;
    }

    /**
     * @return the outPutFileName
     */
    public String getOutPutFileName() {
        return outPutFileName;
    }

    /**
     * @param outPutFileName the outPutFileName to set
     */
    public void setOutPutFileName(String outPutFileName) {
        this.outPutFileName = outPutFileName;
    }

    /**
     * @return the completeFlag
     */
    public boolean isCompleteFlag() {
        return completeFlag;
    }

    /**
     * @param completeFlag the completeFlag to set
     */
    public void setCompleteFlag(boolean completeFlag) {
        this.completeFlag = completeFlag;
    }

    /**
     * @return the endUrl
     */
    public String getEndUrl() {
        return endUrl;
    }

    /**
     * @param endUrl the endUrl to set
     */
    public void setEndUrl(String endUrl) {
        this.endUrl = endUrl;
    }

    /**
     * @return the closeUrl
     */
    public String getCloseUrl() {
        return closeUrl;
    }

    /**
     * @param closeUrl the closeUrl to set
     */
    public void setCloseUrl(String closeUrl) {
        this.closeUrl = closeUrl;
    }

    /**
     * @return the errorUrl
     */
    public String getErrorUrl() {
        return errorUrl;
    }

    /**
     * @param errorUrl the errorUrl to set
     */
    public void setErrorUrl(String errorUrl) {
        this.errorUrl = errorUrl;
    }

    /**
     * @return the cancelUrl
     */
    public String getCancelUrl() {
        return cancelUrl;
    }

    /**
     * @param cancelUrl the cancelUrl to set
     */
    public void setCancelUrl(String cancelUrl) {
        this.cancelUrl = cancelUrl;
    }

    /**
     * @return the printerId
     */
    public String getPrinterId() {
        return printerId;
    }

    /**
     * @param printerId the printerId to set
     */
    public void setPrinterId(String printerId) {
        this.printerId = printerId;
    }

    /**
     * @return the printerName
     */
    public String getPrinterName() {
        return printerName;
    }

    /**
     * @param printerName the printerName to set
     */
    public void setPrinterName(String printerName) {
        this.printerName = printerName;
    }

    /**
     * @return the trayId
     */
    public String getTrayId() {
        return trayId;
    }

    /**
     * @param trayId the trayId to set
     */
    public void setTrayId(String trayId) {
        this.trayId = trayId;
    }

    /**
     * @return the trayName
     */
    public String getTrayName() {
        return trayName;
    }

    /**
     * @param trayName the trayName to set
     */
    public void setTrayName(String trayName) {
        this.trayName = trayName;
    }
    
    /**
     * @return the docName
     */
    public String getDocName() {
        return docName;
    }

    /**
     * @param docName the docName to set
     */
    public void setDocName(String docName) {
        this.docName = docName;
    }

    /**
     * @return the UserCd
     */
    public String getUserCd() {
        return UserCd;
    }

    /**
     * @param UserCd the UserCd to set
     */
    public void setUserCd(String UserCd) {
        this.UserCd = UserCd;
    }

    /**
     * @return the chohyoGroupId
     */
    public String getChohyoGroupId() {
        return chohyoGroupId;
    }

    /**
     * @param chohyoGroupId the chohyoGroupId to set
     */
    public void setChohyoGroupId(String chohyoGroupId) {
        this.chohyoGroupId = chohyoGroupId;
    }

    /**
     * @return the dbUpdateFlag
     */
    public boolean isDbUpdateFlag() {
        return dbUpdateFlag;
    }

    /**
     * @param dbUpdateFlag the dbUpdateFlag to set
     */
    public void setDbUpdateFlag(boolean dbUpdateFlag) {
        this.dbUpdateFlag = dbUpdateFlag;
    }

    /**
     * @return the traySeigyoMode
     */
    public String getTraySeigyoMode() {
        return traySeigyoMode;
    }

    /**
     * @param traySeigyoMode the traySeigyoMode to set
     */
    public void setTraySeigyoMode(String traySeigyoMode) {
        this.traySeigyoMode = traySeigyoMode;
    }
    
    /**
     * @return the printId
     */
    public String getPrintId() {
        return printId;
    }

    /**
     * @param printId the printId to set
     */
    public void setPrintId(String printId) {
        this.printId = printId;
    }

    /**
     * @return the svfBizClass
     */
    public String getSvfBizClass() {
        return svfBizClass;
    }

    /**
     * @param svfBizClass the svfBizClass to set
     */
    public void setSvfBizClass(String svfBizClass) {
        this.svfBizClass = svfBizClass;
    }

    /**
     * @return the svfBizMethod
     */
    public String getSvfBizMethod() {
        return svfBizMethod;
    }

    /**
     * @param svfBizMethod the svfBizMethod to set
     */
    public void setSvfBizMethod(String svfBizMethod) {
        this.svfBizMethod = svfBizMethod;
    }

    /**
     * @return the PREV_TOP
     */
    public String getPREV_TOP() {
        return PREV_TOP;
    }

    /**
     * @param PREV_TOP the PREV_TOP to set
     */
    public void setPREV_TOP(String PREV_TOP) {
        this.PREV_TOP = PREV_TOP;
    }

    /**
     * @return the PREV_LEFT
     */
    public String getPREV_LEFT() {
        return PREV_LEFT;
    }

    /**
     * @param PREV_LEFT the PREV_LEFT to set
     */
    public void setPREV_LEFT(String PREV_LEFT) {
        this.PREV_LEFT = PREV_LEFT;
    }

    /**
     * @return the PREV_WIDTH
     */
    public String getPREV_WIDTH() {
        return PREV_WIDTH;
    }

    /**
     * @param PREV_WIDTH the PREV_WIDTH to set
     */
    public void setPREV_WIDTH(String PREV_WIDTH) {
        this.PREV_WIDTH = PREV_WIDTH;
    }

    /**
     * @return the PREV_HEIGHT
     */
    public String getPREV_HEIGHT() {
        return PREV_HEIGHT;
    }

    /**
     * @param PREV_HEIGHT the PREV_HEIGHT to set
     */
    public void setPREV_HEIGHT(String PREV_HEIGHT) {
        this.PREV_HEIGHT = PREV_HEIGHT;
    }

}
