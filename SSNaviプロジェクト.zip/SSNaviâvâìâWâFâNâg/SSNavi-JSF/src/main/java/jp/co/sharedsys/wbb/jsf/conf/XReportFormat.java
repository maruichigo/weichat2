package jp.co.sharedsys.wbb.jsf.conf;

public class XReportFormat {

}
