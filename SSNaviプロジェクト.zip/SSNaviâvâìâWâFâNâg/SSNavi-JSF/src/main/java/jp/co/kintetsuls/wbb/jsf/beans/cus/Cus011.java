/*
 * Cus011.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.wbb.jsf.beans.cus;

import javax.faces.event.FacesEvent;
import jp.co.kintetsuls.common.MessageDataModel;
import jp.co.sharedsys.wbb.jsf.beans.SSNaviManagedBean;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

/**
 * 顧客一覧画面
 * @author y_kamata
 */
public class Cus011 {
        
    /**
     * 初期処理
     * @param bean
     * @param event
     * @param messageData
     * @param backFlag
     */
    public void init(SSNaviManagedBean bean, FacesEvent event, MessageDataModel messageData, Boolean backFlag) {
        String str;
        str = "test";
    }
    
    /**
     * 後処理
     * @param bean
     * @param event
     * @param messageData
     * @param backFlag
     */
    public void close(SSNaviManagedBean bean, FacesEvent event, MessageDataModel messageData, Boolean backFlag) {
        String str;
        str = "test";        
    }
    
    /**
     * エクセル編集処理
     * @param bean
     * @param document
     * @param wb
     * @param messageData
     */
    public void editExcel(SSNaviManagedBean bean, HSSFWorkbook wb, MessageDataModel messageData) {
        HSSFSheet sheet = wb.getSheetAt(0);
        HSSFRow header = sheet.getRow(0);
        
        String str;
        str = "test";
    }
}
