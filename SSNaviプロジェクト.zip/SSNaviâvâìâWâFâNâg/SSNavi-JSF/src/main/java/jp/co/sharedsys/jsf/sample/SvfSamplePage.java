/*
 * SvfTestPage.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.jsf.sample;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;
import org.glassfish.jersey.client.ClientConfig;

/**
 *
 * @author klsproj
 */
@ManagedBean(name="svfSamplePage")
@ViewScoped
public class SvfSamplePage implements Serializable {

    // ファイル形式の定義
    enum FileFormat {
        PDF,
        Excel,
        EMF,
    };

    // ファイル形式と拡張子の定義
    private final Map<FileFormat, String> fileExtensionMap = new HashMap<FileFormat, String>() {
        {
            put(FileFormat.PDF, "pdf");
            put(FileFormat.Excel, "xlsx");
        }
    };    
    
    // SVFサンプル用のjax-rsのURL
    static final String SVF_SAMPLE_URL = "http://localhost:8080/SSNavi-Service-KLS/resources/svfsample";

    private boolean prev = false;
    public boolean isPrev() {
        return prev;
    }
    
    private String prevFileUrl;
    public String getPrevFileUrl() {
        return prevFileUrl;
    }
    
    /**
     * Excelダウンロードのactionです。
     * 
     * @return
     * @throws IOException 
     */
    public String excel() throws IOException {
        prev = false;
        String url = String.format("%s/%s?%s=%s", SVF_SAMPLE_URL, "downloadExcel", "param", "dummy");
        String contentType = "application/vnd.ms-excel";
        String fileExtension = fileExtensionMap.get(FileFormat.Excel);
        File file = (File) jaxrs(url, contentType, fileExtension);
        download(file, contentType, fileExtension);
        return null;
    }
    
    /**
     * pdfダウンロードのactionです。
     * 
     * @return
     * @throws IOException 
     */
    public String pdf() throws IOException {
        prev = false;
        String url = String.format("%s/%s?%s=%s", SVF_SAMPLE_URL, "downloadPdf", "param", "dummy");
        String contentType = "application/pdf";
        String fileExtension = fileExtensionMap.get(FileFormat.PDF);
        File file = (File) jaxrs(url, contentType, fileExtension);
        download(file, contentType, fileExtension);
        return null;
    }
    
    /**
     * プレビューのactionです。
     * 
     * @return
     * @throws IOException 
     */
    public String prev() throws IOException {
        String url = String.format("%s/%s", SVF_SAMPLE_URL, "preview");
        String contentType = "text/plain";
        String fileUrl = (String) jaxrs(url, contentType, null);
        System.out.println(fileUrl);
        if (null != fileUrl && !fileUrl.isEmpty()) {
            prev = true;
            prevFileUrl = fileUrl;            
        }
        return null;
    }
    
    /**
     * jax-rsの呼び出し処理です。
     * jax-rs呼び出し処理はSSNaviに既に実装してあるので実際はそちらを使用します。
     * ファイルダウンロードに対応した実装は未実装かもしれないので必要に応じて実装してください。
     * 
     * @param url
     * @param contentType
     * @param fileExtension
     * @return
     * @throws IOException 
     */
    private Object jaxrs(String url, String contentType, String fileExtension) throws IOException {
        
        // jax-rs呼び出し
        ClientConfig config = new ClientConfig();
        Client client = ClientBuilder.newClient(config);
        WebTarget webTarget = client.target(url);
        Invocation.Builder invocationBuilder =  webTarget.request(contentType);
        // jax-rsのレスポンスを取得
        Response response = invocationBuilder.get();
        
        // ファイルダウンロードの場合
        if (null != fileExtension && !fileExtension.isEmpty()) {
            // ファイルを一時フォルダへダウンロードし一旦保存（このあとにjax-rsのレスポンスからjsf用のレスポンスを作る必要がある）
            Path out;
            try (InputStream in = response.readEntity( InputStream.class )) {
                out = Files.createTempFile(Paths.get(System.getProperty("java.io.tmpdir")), "KLS_SVF_SAMPLE", String.format(".%s", fileExtension));
                Files.copy(in, out, StandardCopyOption.REPLACE_EXISTING);
            }
            File file = out.toFile();
            System.out.println(file.getAbsolutePath());

            return file;
        // プレビューの場合
        } else {
            return response.readEntity( String.class );
        }
    }
    
    /**
     * JSFのダウンロード処理です。
     * jax-rsでダウンロードしたファイルからJSF用のレスポンスを作成します。
     * SSNaviに実装を追加する必要があるかもしれません。
     * 
     * @param file
     * @param contentType
     * @param fileExtension
     * @throws IOException 
     */
    private void download(File file, String contentType, String fileExtension) throws IOException {
        ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
        try (BufferedInputStream inStream = new BufferedInputStream(new FileInputStream(file.getAbsolutePath()))) {
            int len=0;
            byte[] buffer = new byte[1024];
            while((len=inStream.read(buffer, 0, buffer.length))!=-1) {
                byteStream.write(buffer, 0, len);
            }
	}
        byte[] byteArray = byteStream.toByteArray();
        
        FacesContext facesContext = FacesContext.getCurrentInstance();
        ExternalContext exContext = facesContext.getExternalContext();
	exContext.responseReset();
	exContext.setResponseContentType(contentType);
	exContext.setResponseContentLength(byteArray.length);
	exContext.setResponseHeader("Content-Disposition", String.format("attachment; filename=sample.%s", fileExtension));

        // 送出
	try(OutputStream downloadStream = exContext.getResponseOutputStream()) {
		downloadStream.write(byteArray);
		downloadStream.flush();
		exContext.responseFlushBuffer();
		facesContext.responseComplete();
	}
    }
}


