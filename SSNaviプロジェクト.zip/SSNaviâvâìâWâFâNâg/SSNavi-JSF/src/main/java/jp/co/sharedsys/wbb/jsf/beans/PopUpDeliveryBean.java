/*
 * AuthorityConfBean.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.beans;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 * ポップアップ受け渡し情報を格納するManagedBeanです。
 * @author Shared System Inc.
 */
@ManagedBean(name = "popupBean")
@SessionScoped
public class PopUpDeliveryBean implements Serializable {

    private static final long serialVersionUID = -8006365439680582676L;

    private Map<String, Map<String, Object>> popupValues = new HashMap<>();     // ポップアップ画面との受け渡し値
    private boolean pouUpOpenFlag = false;  // ポップアップ表示中フラグ false:非表示 true:表示中

    /**
     * @return the popupValues
     */
    public Map<String, Map<String, Object>> getPopupValues() {
        return popupValues;
    }

    /**
     * @param popupValues the popupValues to set
     */
    public void setPopupValues(Map<String, Map<String, Object>> popupValues) {
        this.popupValues = popupValues;
    }

    /**
     * @return the pouUpOpenFlag
     */
    public boolean isPouUpOpenFlag() {
        return pouUpOpenFlag;
    }

    /**
     * @param pouUpOpenFlag the pouUpOpenFlag to set
     */
    public void setPouUpOpenFlag(boolean pouUpOpenFlag) {
        this.pouUpOpenFlag = pouUpOpenFlag;
    }

}
