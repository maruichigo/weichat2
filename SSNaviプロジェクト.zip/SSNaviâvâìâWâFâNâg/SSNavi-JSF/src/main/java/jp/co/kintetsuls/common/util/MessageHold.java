/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.common.util;

import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Map;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import jp.co.kintetsuls.service.model.biz_common.SystemMessageDef;

/**
 * メッセージ保持クラス
 *
 */
public class MessageHold {

	private static MessageHold messageHold;

	private static Map<String, SystemMessageDef> messageMap = null;

	private MessageHold() {

		setMap(); //TODO テスト時用
	}

	public static synchronized MessageHold getInstance() {
		if (messageHold == null) {
			messageHold = new MessageHold();
		}

		return messageHold;
	}

	public static void setMessage(Map<String, SystemMessageDef> mes) {
		messageMap = mes;
	}

	/**
	 * 使用不可
	 */
	public static Map<String, SystemMessageDef> getMessageDebug() {
		return messageMap;
	}

	/**
	 * メッセージを取得する（パラメータなし）
	 *
	 * @param messageId メッセージID
	 * @return メッセージ
	 */
	public static String getMessage(String messageId) {

		String message = "";

		// printDebug();
		// TODO テスト用
		if (messageMap == null) {
			messageHold = new MessageHold();
		}

		//  printDebug();
		if (messageMap == null || messageMap.get(messageId) == null) {
			return "";
		}

		try {
			message = messageMap.get(messageId).getMessage();
		} catch (Exception e) {
			Logger.getLogger(MessageHold.class.getName()).log(Level.SEVERE, null, e);
		}

		return message;
	}

	/**
	 * メッセージを取得する（パラメータあり）
	 *
	 * @param messageId メッセージID
	 * @param param パラメータ
	 * @return メッセージ
	 */
	public static String getMessage(String messageId, Object[] param) {

		String message = "";

		// printDebug(param);
		// TODO テスト用
		if (messageMap == null) {
			messageHold = new MessageHold();
		}

		//  printDebug(param);
		if (messageMap == null || messageMap.get(messageId) == null || param == null) {
			return "";
		}

		try {
			message = MessageFormat.format(messageMap.get(messageId).getMessage().replace("$", ""), param);
		} catch (Exception e) {

			Logger.getLogger(MessageHold.class.getName()).log(Level.SEVERE, null, e);
		}

		return message;
	}

	private static void printDebug(Object[] param) {
		if (messageMap == null) {
			System.out.println("メッセージMapがありません");
		} else {

			//        System.out.println("メッセージ件数 [" + messageMap.size() + "]");
		}

		if (param == null || param.length == 0) {
			System.out.println("パラメータがありません");
		} else {
			/*
            for (Object obj : param) {
                System.out.println(" [" + obj + "]");
            }
			 */
		}
	}

	private static void printDebug() {
		if (messageMap == null) {
			System.out.println("メッセージMapがありません");
		} else {

			System.out.println("メッセージ件数 [" + messageMap.size() + "]");
		}

	}

	/**
	 * テスト時のみ使用
	 */
	private void setMap() {

		//   System.out.println("メッセージMap設定★テスト");
		messageMap = new HashMap();

		String csvFile = "/csv/message.csv";

		try {
			InputStream is = this.getClass().getResourceAsStream(csvFile);
			//        System.out.println("IS [" + is + "]");
			BufferedReader br = new BufferedReader(new InputStreamReader(is));

			String line;
			while ((line = br.readLine()) != null) {
				String[] data = line.split(",", -1); // 行をカンマ区切りで配列に変換

				if (data.length == 3) {
					// システムメッセージBean
					SystemMessageDef bean = new SystemMessageDef();
					bean.setMessageId(data[0]);
					bean.setMessageShubetsu(data[1]);
					bean.setMessage(data[2]);
					messageMap.put(data[0], bean);

					/*
                    System.out.println("メッセージID [" + bean.getMessageId() + "]");
                    System.out.println("メッセージ種別 [" + bean.getMessageShubetsu() + "]");
                    System.out.println("メッセージ [" + bean.getMessage() + "]");
					 */
				}
			}
			br.close();

		} catch (IOException e) {
			Logger.getLogger(MessageHold.class.getName()).log(Level.SEVERE, null, e);
		}
	}

}
