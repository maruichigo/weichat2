package jp.co.sharedsys.wbb.jsf.api;

public interface IAPI {
    String getAPI();
    String execute();
}
