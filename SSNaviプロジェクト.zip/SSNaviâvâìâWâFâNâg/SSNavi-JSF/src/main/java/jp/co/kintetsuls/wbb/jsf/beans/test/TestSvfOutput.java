/*
 * MenuModelBean.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.wbb.jsf.beans.test;

import java.io.Serializable;
import java.util.ArrayList;
import jp.co.kintetsuls.common.MessageDataModel;
import jp.co.sharedsys.wbb.jsf.beans.SSNaviManagedBean;

/**
 * Svf出力機能
 * @author 
 */
public class TestSvfOutput implements Serializable {

 
    /**
     * Excel、PDF、Prev用
     * @author 
     * @param pageBean 
     * @param messageData 
     * @throws java.lang.Exception 
     */
     public void svfOutPut(SSNaviManagedBean pageBean, MessageDataModel messageData) throws Exception {
        
        pageBean.getSvfData().setChohyoId("REP01");                           // 帳票ID
        pageBean.getSvfData().setYoshiId("LET01");                            // 用紙ID
        pageBean.getSvfData().setShutsuryokuFileMei("TEST用ファイル1");        // 出力ファイル名
        pageBean.getSvfData().setDataFilePath("C:\\ssnavi\\TEST001.csv");     // ファイルパス
        pageBean.getSvfData().setPrevFlag(false);                             // プレビュー表示
        
        
        ArrayList kbn = new ArrayList();
        ArrayList message = new ArrayList();
        
        kbn.add("正常");
        message.add("テスト");
        kbn.add("異常");
        message.add("テスト２");
        messageData.setMessageKbn(kbn);
        messageData.setMessage(message);
        
        // コンテキストタイプ、ファイルフォーマット
        if (pageBean.getSvfData().getPTN_EXCEL().equals(pageBean.getSvfData().getFileFormat())) {
            pageBean.getSvfData().setCotextType(pageBean.getSvfData().getCONTEXT_TYPE_EXCEL());
        } else if (pageBean.getSvfData().getPTN_PDF().equals(pageBean.getSvfData().getFileFormat())) {
            pageBean.getSvfData().setCotextType(pageBean.getSvfData().getCONTEXT_TYPE_PDF());
        } else if (pageBean.getSvfData().getPTN_PREV().equals(pageBean.getSvfData().getFileFormat())) {
            pageBean.getSvfData().setCotextType(pageBean.getSvfData().getCONTEXT_TYPE_PREV());
        } else {
            pageBean.getSvfData().setCotextType("");
        }
        
        // プレビュー表示
        if (pageBean.getSvfData().getPTN_PREV().equals(pageBean.getSvfData().getFileFormat())) {
            pageBean.getSvfData().setDocName("プレビューテスト用");
        } else {
            pageBean.getSvfData().setDocName("");
        }
    }   

    /**
     * 印刷用（直接印刷）
     * @author 
     * @param pageBean 
     * @param messageData 
     * @throws java.lang.Exception 
     */     
     public void svfPrintDirect(SSNaviManagedBean pageBean, MessageDataModel messageData) throws Exception {
        
        pageBean.getSvfData().setChohyoId("REP01");                           // 帳票ID
        pageBean.getSvfData().setYoshiId("LET01");                            // 用紙ID
        pageBean.getSvfData().setShutsuryokuFileMei("TEST用ファイル1");        // 出力ファイル名
        pageBean.getSvfData().setFileFormat(pageBean.getSvfData().getPTN_PRINT());          // ファイルフォーマット
        pageBean.getSvfData().setDataFilePath("C:\\ssnavi\\TEST001.csv");     // ファイルパス
        pageBean.getSvfData().setCotextType("");                              // コンテキストタイプ
        pageBean.getSvfData().setAdjustX(0);                                  // 印字位置の調整　(X座標をmm単位に指定) 
        pageBean.getSvfData().setAdjustY(0);                                  // 印字位置の調整　(Y座標をmm単位に指定)
        pageBean.getSvfData().setPrevFileUrl("");                             // プレビューURL
        pageBean.getSvfData().setPrinterId("");                               // プレインターID
        pageBean.getSvfData().setPrinterName("Docucentre VI C5571");          // プリンター名        
        pageBean.getSvfData().setTrayId("");                                  // トレイID
        pageBean.getSvfData().setTrayName("");                                // トレイ名
        pageBean.getSvfData().setTraySeigyoMode("");                          // トレイ制御モード
        pageBean.getSvfData().setDocName("直接印刷");                          // 直接印刷
        pageBean.getSvfData().setPrevFlag(false);                             // プレビュー表示 false:しない true:する
        pageBean.getSvfData().setPrinterSetFlag(false);                       // プリンター設定 false:不可 true:可能

        //帳票系のマスタから値を取得　今は書かない
        
    }   

    /**
     * 印刷用（プリンター選択可）
     * @author 
     * @param pageBean 
     * @param messageData 
     * @throws java.lang.Exception 
     */     
     public void svfPrintSelect(SSNaviManagedBean pageBean, MessageDataModel messageData) throws Exception {
        
        pageBean.getSvfData().setChohyoId("REP01");                           // 帳票ID
        pageBean.getSvfData().setYoshiId("LET01");                            // 用紙ID
        pageBean.getSvfData().setShutsuryokuFileMei("TEST用ファイル1");        // 出力ファイル名
        pageBean.getSvfData().setFileFormat(pageBean.getSvfData().getPTN_PRINT());          // ファイルフォーマット
        pageBean.getSvfData().setDataFilePath("C:\\ssnavi\\TEST001.csv");     // ファイルパス
        pageBean.getSvfData().setCotextType("");                              // コンテキストタイプ
        pageBean.getSvfData().setAdjustX(0);                                  // 印字位置の調整　(X座標をmm単位に指定) 
        pageBean.getSvfData().setAdjustY(0);                                  // 印字位置の調整　(Y座標をmm単位に指定)
        pageBean.getSvfData().setPrevFileUrl("");                             // プレビューURL
        pageBean.getSvfData().setPrinterId("");                               // プレインターID
        pageBean.getSvfData().setPrinterName("");                             // プリンター名        
        pageBean.getSvfData().setTrayId("");                                  // トレイID
        pageBean.getSvfData().setTrayName("");                                // トレイ名
        pageBean.getSvfData().setDocName("プリンター選択");                    // 直接印刷
        pageBean.getSvfData().setPrevFlag(false);                             // プレビュー表示 false:しない true:する
        pageBean.getSvfData().setPrinterSetFlag(true);                        // プリンター設定 false:不可 true:可能
        
        //帳票系のマスタから値を取得　今は書かない
        
    } 

    /**
     * 印刷用（プレビューありで印刷設定不可）
     * @author 
     * @param pageBean 
     * @param messageData 
     * @throws java.lang.Exception 
     */     
     public void svfPrintPrev(SSNaviManagedBean pageBean, MessageDataModel messageData) throws Exception {
        
        pageBean.getSvfData().setChohyoId("REP01");                           // 帳票ID
        pageBean.getSvfData().setYoshiId("LET01");                            // 用紙ID
        pageBean.getSvfData().setShutsuryokuFileMei("TEST用ファイル1");       // 出力ファイル名
        pageBean.getSvfData().setFileFormat(pageBean.getSvfData().getPTN_PRINT());          // ファイルフォーマット
        pageBean.getSvfData().setDataFilePath("C:\\ssnavi\\TEST001.csv");    // ファイルパス
        pageBean.getSvfData().setCotextType("");                              // コンテキストタイプ
        pageBean.getSvfData().setAdjustX(0);                                  // 印字位置の調整　(X座標をmm単位に指定) 
        pageBean.getSvfData().setAdjustY(0);                                  // 印字位置の調整　(Y座標をmm単位に指定)
        pageBean.getSvfData().setPrevFileUrl("");                             // プレビューURL
        pageBean.getSvfData().setDocName("");                                 // プレビュー名
        pageBean.getSvfData().setPrinterId("");                               // プレインターID
        pageBean.getSvfData().setPrinterName("Docucentre VI C5571");          // プリンター名        
        pageBean.getSvfData().setTrayId("");                                  // トレイID
        pageBean.getSvfData().setTrayName("");                                // トレイ名
        pageBean.getSvfData().setDocName("直接印刷");                          // 直接印刷
        pageBean.getSvfData().setPrevFlag(true);                              // プレビュー表示 false:しない true:する
        pageBean.getSvfData().setPrinterSetFlag(false);                       // プリンター設定 false:不可 true:可能
        
        //帳票系のマスタから値を取得　今は書かない
        
    } 

    /**
     * 印刷用（プレビューありで印刷設定可能）
     * @author 
     * @param pageBean 
     * @param messageData 
     * @throws java.lang.Exception 
     */     
     public void svfPrintPrevSelect(SSNaviManagedBean pageBean, MessageDataModel messageData) throws Exception {
        
        pageBean.getSvfData().setChohyoId("REP01");                           // 帳票ID
        pageBean.getSvfData().setYoshiId("LET01");                            // 用紙ID
        pageBean.getSvfData().setShutsuryokuFileMei("TEST用ファイル1");       // 出力ファイル名
        pageBean.getSvfData().setFileFormat(pageBean.getSvfData().getPTN_PRINT());          // ファイルフォーマット
        pageBean.getSvfData().setDataFilePath("C:\\ssnavi\\TEST001.csv");    // ファイルパス
        pageBean.getSvfData().setCotextType("");                              // コンテキストタイプ
        pageBean.getSvfData().setAdjustX(0);                                  // 印字位置の調整　(X座標をmm単位に指定) 
        pageBean.getSvfData().setAdjustY(0);                                  // 印字位置の調整　(Y座標をmm単位に指定)
        pageBean.getSvfData().setPrevFileUrl("");                             // プレビューURL
        pageBean.getSvfData().setDocName("");                                 // プレビュー名
        pageBean.getSvfData().setPrinterId("");                               // プレインターID
        pageBean.getSvfData().setPrinterName("Docucentre VI C5571");          // プリンター名        
        pageBean.getSvfData().setTrayId("");                                  // トレイID
        pageBean.getSvfData().setTrayName("");                                // トレイ名
        pageBean.getSvfData().setDocName("直接印刷");                          // 直接印刷
        pageBean.getSvfData().setPrevFlag(true);                              // プレビュー表示 false:しない true:する
        pageBean.getSvfData().setPrinterSetFlag(true);                        // プリンター設定 false:不可 true:可能
        
        //帳票系のマスタから値を取得　今は書かない
        
    } 
     
}
