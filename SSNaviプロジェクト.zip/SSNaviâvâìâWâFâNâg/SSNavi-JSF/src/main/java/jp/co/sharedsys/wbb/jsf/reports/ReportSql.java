package jp.co.sharedsys.wbb.jsf.reports;

import java.io.Serializable;
import java.util.Map;

import jp.co.sharedsys.wbb.jsf.loader.IModule;
import lombok.Data;

@Data
public class ReportSql implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 6562300961982071698L;
    private String templateFile = null;
    private String description = null;
//    private boolean customClassType = false;
    private IModule module = null;
    private Map<String,Input> params = null;
    private String tableName;
    private String name = null;
    private String service = ReportConst.F_SERVICE.JOHMONWEBSERVICE;
    private String functionCode;
    private String editModeName = ReportConst.EditMode.SEARCH;
    private String editActivityName = ReportConst.Act.EXECUTE;
    private ReportConfig config;
}