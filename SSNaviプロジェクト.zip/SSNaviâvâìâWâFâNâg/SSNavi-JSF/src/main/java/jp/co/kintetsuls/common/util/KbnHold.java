/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.common.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import jp.co.kintetsuls.service.model.biz_common.KbnDef;

/**
 * 区分保持クラス
 *
 */
public class KbnHold {

	private static KbnHold kbnHold;

	private static Map<String, KbnDef> kbnMap = null;

	private KbnHold() {
		setMap(); //TODO テスト時用
	}

	public static synchronized KbnHold getInstance() {
		if (kbnHold == null) {
			kbnHold = new KbnHold();
		}

		return kbnHold;
	}

	public static void setKbn(Map<String, KbnDef> kbn) {
		kbnMap = kbn;
	}

	/**
	 * 使用不可
	 */
	public static Map<String, KbnDef> getKbnDebug() {
		return kbnMap;
	}

	/**
	 * 区分名を取得する
	 *
	 * @param kbnKey 区分キー
	 * @return 区分名
	 */
	public static String getKbnMei(String kbnKey) {

		String kbnMei = "";

		// TODO テスト用
		if (kbnMap == null) {
			kbnHold = new KbnHold();
		}

		//  printDebug();
		if (kbnMap == null || kbnMap.get(kbnKey) == null) {
			return "";
		}

		try {
			kbnMei = kbnMap.get(kbnKey).getKbnMei();
		} catch (Exception e) {
			Logger.getLogger(KbnHold.class.getName()).log(Level.SEVERE, null, e);
		}

		return kbnMei;
	}

	/**
	 * 区分コードを取得する
	 *
	 * @param kbnKey 区分キー
	 * @return 区分コード
	 */
	public static String getKbnCd(String kbnKey) {

		String kbnCd = "";

		// TODO テスト用
		if (kbnMap == null) {
			kbnHold = new KbnHold();
		}

		//  printDebug();
		if (kbnMap == null || kbnMap.get(kbnKey) == null) {
			return "";
		}

		try {
			kbnCd = kbnMap.get(kbnKey).getKbnCd();
		} catch (Exception e) {
			Logger.getLogger(KbnHold.class.getName()).log(Level.SEVERE, null, e);
		}

		return kbnCd;
	}

	private static void printDebug() {

		if (kbnMap == null) {
			System.out.println("区分Mapがありません");
		} else {

			//           System.out.println("区分件数 [" + kbnMap.size() + "]");
		}
	}

	/**
	 * テスト時のみ使用
	 */
	private void setMap() {

		//   System.out.println("区分Map設定★テスト");
		kbnMap = new HashMap();

		String csvFile = "/csv/kbn.csv";

		try {
			InputStream is = this.getClass().getResourceAsStream(csvFile);
			//        System.out.println("IS [" + is + "]");
			BufferedReader br = new BufferedReader(new InputStreamReader(is));

			String line;
			while ((line = br.readLine()) != null) {
				String[] data = line.split(",", -1); // 行をカンマ区切りで配列に変換

				if (data.length == 5) {
					// 区分Bean
					KbnDef bean = new KbnDef();
					bean.setKbnGroupCd(data[0]);
					bean.setKbnGroupMei(data[1]);
					bean.setKbnCd(data[2]);
					bean.setKbnMei(data[3]);
					bean.setKbnKey(data[4]);
					kbnMap.put(bean.getKbnKey(), bean);
				}
			}
			br.close();

		} catch (IOException e) {
			Logger.getLogger(KbnHold.class.getName()).log(Level.SEVERE, null, e);
		}
	}
}
