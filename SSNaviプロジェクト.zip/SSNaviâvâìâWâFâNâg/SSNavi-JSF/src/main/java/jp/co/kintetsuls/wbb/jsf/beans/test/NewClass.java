/*
 * NewClass.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.wbb.jsf.beans.test;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.event.ActionEvent;
import jp.co.kintetsuls.common.MessageDataModel;
import jp.co.sharedsys.wbb.jsf.beans.SSNaviManagedBean;
import jp.co.sharedsys.wbb.jsf.conf.XReportConditionOption;
import jp.co.sharedsys.wbb.jsf.reports.AbstractReportOption;
import jp.co.sharedsys.wbb.jsf.reports.ReportCondition;
import jp.co.sharedsys.wbb.jsf.reports.ReportConditionOption;
import jp.co.sharedsys.wbb.jsf.util.bean.PagePropertiesBean;
import jp.co.sharedsys.wbb.jsf.reports.ReportConfig;
/**
 * ブリッジ経由でオプションをとるサンプル
 * 
 */
public class NewClass implements Serializable {
	public void init(SSNaviManagedBean bean, ActionEvent event, MessageDataModel messageData) throws Exception {
		
		ReportConfig tmpConfig = new ReportConfig();
		/// tmpConfig =bean.getConfig().clone();
			ReportCondition condition = new ReportCondition();

                    ReportConditionOption option = new ReportConditionOption();
                    option.setLabel("");
                    option.setValue("");
                    option.setChecked(true);
                    option.setService("JohmonWebService");
                    option.setFunctionCode("KOKYAKU_SEARCH");
              
                    option.setServiceParameter("");
                    condition.getOptions().add(option);
                    condition.getOriginalOptions().add(option);
		tmpConfig.getConditions().add(condition);
		//現在protectedだが、変更してよいか確認が必要。	sqlが実行される。
		//bean.generateOption(tmpConfig, bean.getAuthConf());
		
		
		
	}
}
