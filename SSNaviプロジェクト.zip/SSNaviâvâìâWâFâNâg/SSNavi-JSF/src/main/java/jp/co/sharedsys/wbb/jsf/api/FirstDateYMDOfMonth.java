package jp.co.sharedsys.wbb.jsf.api;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class FirstDateYMDOfMonth implements IAPI {

    public String execute() {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        return new SimpleDateFormat("yyyyMMdd").format(calendar.getTime());
    }

    public String getAPI() {
        return "@FIRSTDATE@";
    }
}
