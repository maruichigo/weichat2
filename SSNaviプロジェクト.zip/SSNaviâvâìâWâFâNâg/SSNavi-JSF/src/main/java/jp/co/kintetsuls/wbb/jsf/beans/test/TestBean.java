/*
 * MenuModelBean.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.wbb.jsf.beans.test;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.event.ActionEvent;
import javax.faces.event.FacesEvent;
import org.primefaces.event.MenuActionEvent;
import jp.co.kintetsuls.common.MessageDataModel;
import jp.co.sharedsys.wbb.jsf.beans.SSNaviManagedBean;
import jp.co.sharedsys.wbb.jsf.util.bean.PagePropertiesBean;

/**
 *
 * @author 
 */
public class TestBean implements Serializable {

    private TestDataModel testDataModel;
    public TestBean() {
        testDataModel = new TestDataModel();
    }

    public void init(SSNaviManagedBean bean, ActionEvent event, MessageDataModel messageData) throws Exception {
        System.out.println("init 開始");
        System.out.println("init 終了");
    }

    public void close(SSNaviManagedBean bean, ActionEvent event, MessageDataModel messageData) throws Exception {
        System.out.println("close 開始");
        //遷移した画面rptファイルのスクリーンコードを取得し、
        //画面遷移したことがある場合は、以下の方法で前回の検索条件を復元することができます。
        String screenCode = bean.getConfig().getScreenCode();
        PagePropertiesBean prop = bean.getBreadCrumbBean().getPageProperties(screenCode);
        if (null != prop){
            //前の画面のデータを復元して引き継ぐ場合。
            //bean.setConfig(prop.getConfig());
            //bean.setValues(prop.getValues());
            //一覧検索する必要がある場合は以下を指定します。
            bean.executeSearch(event);
            //パンくずリスト操作：例：A -B -C -B -Cの場合にBを指定した場合、A -Bのみ残る。
        //bean.getBreadCrumbBean().crumbScFirstRestructure(screenCode);
        }
        System.out.println("close 終了");
    }
	
    public void init(SSNaviManagedBean bean, FacesEvent event, MessageDataModel messageData, Boolean isBack) throws Exception {
        System.out.println("画面情報読み出し開始(init)");
    }
    public void close(SSNaviManagedBean bean, FacesEvent event, MessageDataModel messageData, Boolean isBack) throws Exception {
        System.out.println("画面表示開始(close)");
        if (isBack){
            System.out.println("前に戻った時に実行する処理。");
            //検索実行。
            bean.executeSearch(event);
        } else {
            System.out.println("次の画面に遷移したときに実行する処理。");
        }
        
    }

     public void init(HashMap<String, HashMap<String, Object>> values, ActionEvent event, ArrayList<Object> obj) throws Exception {
        if(obj.isEmpty()){
            testDataModel.setStr("777");
            obj.add(testDataModel);
        }        
        if( obj.get(0) instanceof TestDataModel == false ){
            return;
        }
		HashMap<String, Object> testdata = new HashMap<>();
		testdata.put("key", "values");
		values.put("0000000000", testdata);
		for(Map.Entry<String, HashMap<String, Object>> entry : values.entrySet()) {
			HashMap<String, Object> valmap = entry.getValue();
			for(Map.Entry<String, Object> entry2 : valmap.entrySet()) {
				System.out.println(entry.getKey());
				System.out.println(entry2.getKey());
				System.out.println(entry2.getValue());
				values.get(entry.getKey()).put(entry2.getKey(), "書き換え");	
				System.out.println(entry2.getValue());
			}
		}
		
        TestDataModel tb = (TestDataModel)obj.get(0);
        tb.setStr("666");
        obj.add(values);
    }   
}
