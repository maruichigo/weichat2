package jp.co.sharedsys.wbb.jsf.beans;

import java.io.Serializable;

/**
 * アップロードファイル定義マスタの情報を管理する。
 */
public class UploadFileDefinitionMasterBean implements Serializable {
	
	private static final long serialVersionUID = 2L;
	
	/** アップロード機能コード CHAR3 key1 */
	private String UploadKindCd;
	/** アップロードコード VARCHAR2 20 key2 */
	private String UploadCd;
	/** 適用開始日 DATE key3 */
	private String TekiyoKaishibi;
	/** EDI設定ID CHAR 6 */
	private String EdiSetteiId;
	/** データファイル名 VARCHAR2	 256 */
	private String DataFileMei;
	/** ファイル種別 CHAR 1 */
	private String FileShubetsu;
	/** 一時保存用ワークテーブル名 VARCHAR2 50 */
	private String IchijiHozonyoWorkTableMei;
	/** ファイル読込用DATASPIDERSCRIPTのURL VARCHAR2	256 */
	private String FileYomikomiDsScriptUrl;
	/** 一時保存用DATASPIDERSCRIPTのURL VARCHAR2	256 */
	private String IchijiHozonyoDsScriptUrl;
	/** 本登録用DATASPIDERSCRIPTのURL VARCHAR2 256 */
	private String HontorokuyoDsScriptUrl;
	/** ファイルヘッダ行の有無 CHAR 1 */
	private String FileHeaderGyoNoUmu;
	/** 適用終了日 DATE */
	private String TekiyoShuryobi;
	/** 削除フラグ CHAR 1 */
	private String SakujoFlg;

	public String getUploadKindCd() {
		return UploadKindCd;
	}

	public void setUploadKindCd(String UploadKindCd) {
		this.UploadKindCd = UploadKindCd;
	}

	public String getUploadCd() {
		return UploadCd;
	}

	public void setUploadCd(String UploadCd) {
		this.UploadCd = UploadCd;
	}

	public String getTekiyoKaishibi() {
		return TekiyoKaishibi;
	}

	public void setTekiyoKaishibi(String TekiyoKaishibi) {
		this.TekiyoKaishibi = TekiyoKaishibi;
	}

	public String getEdiSetteiId() {
		return EdiSetteiId;
	}

	public void setEdiSetteiId(String EdiSetteiId) {
		this.EdiSetteiId = EdiSetteiId;
	}

	public String getDataFileMei() {
		return DataFileMei;
	}

	public void setDataFileMei(String DataFileMei) {
		this.DataFileMei = DataFileMei;
	}

	public String getFileShubetsu() {
		return FileShubetsu;
	}

	public void setFileShubetsu(String FileShubetsu) {
		this.FileShubetsu = FileShubetsu;
	}

	public String getIchijiHozonyoWorkTableMei() {
		return IchijiHozonyoWorkTableMei;
	}

	public void setIchijiHozonyoWorkTableMei(String IchijiHozonyoWorkTableMei) {
		this.IchijiHozonyoWorkTableMei = IchijiHozonyoWorkTableMei;
	}

	public String getFileYomikomiDsScriptUrl() {
		return FileYomikomiDsScriptUrl;
	}

	public void setFileYomikomiDsScriptUrl(String FileYomikomiDsScriptUrl) {
		this.FileYomikomiDsScriptUrl = FileYomikomiDsScriptUrl;
	}

	public String getIchijiHozonyoDsScriptUrl() {
		return IchijiHozonyoDsScriptUrl;
	}

	public void setIchijiHozonyoDsScriptUrl(String IchijiHozonyoDsScriptUrl) {
		this.IchijiHozonyoDsScriptUrl = IchijiHozonyoDsScriptUrl;
	}

	public String getHontorokuyoDsScriptUrl() {
		return HontorokuyoDsScriptUrl;
	}

	public void setHontorokuyoDsScriptUrl(String HontorokuyoDsScriptUrl) {
		this.HontorokuyoDsScriptUrl = HontorokuyoDsScriptUrl;
	}

	public String getFileHeaderGyoNoUmu() {
		return FileHeaderGyoNoUmu;
	}

	public void setFileHeaderGyoNoUmu(String FileHeaderGyoNoUmu) {
		this.FileHeaderGyoNoUmu = FileHeaderGyoNoUmu;
	}

	public String getTekiyoShuryobi() {
		return TekiyoShuryobi;
	}

	public void setTekiyoShuryobi(String TekiyoShuryobi) {
		this.TekiyoShuryobi = TekiyoShuryobi;
	}

	public String getSakujoFlg() {
		return SakujoFlg;
	}

	public void setSakujoFlg(String SakujoFlg) {
		this.SakujoFlg = SakujoFlg;
	}
}
