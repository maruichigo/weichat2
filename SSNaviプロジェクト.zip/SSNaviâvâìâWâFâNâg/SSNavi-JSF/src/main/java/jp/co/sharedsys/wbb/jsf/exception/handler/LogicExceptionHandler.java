/*
 * LogicExceptionHandler.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.exception.handler;

import java.util.Iterator;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExceptionHandler;
import javax.faces.context.ExceptionHandlerWrapper;
import javax.faces.context.FacesContext;
import javax.faces.event.ExceptionQueuedEvent;
import javax.faces.event.ExceptionQueuedEventContext;
import jp.co.sharedsys.wbb.jsf.exception.LogicException;
import org.slf4j.LoggerFactory;

/**
 *
 * @author saihara
 */
public class LogicExceptionHandler extends ExceptionHandlerWrapper {

    private ExceptionHandler wrapped;

    public LogicExceptionHandler(ExceptionHandler wrapped) {
        this.wrapped = wrapped;
    }

    @Override
    public void handle() {
        for (Iterator<ExceptionQueuedEvent> it = getUnhandledExceptionQueuedEvents().iterator(); it.hasNext() == true;) {

            ExceptionQueuedEventContext eventContext = it.next().getContext();

            // 1. ハンドリング対象のアプリケーション例外を取得
            Throwable th = getRootCause(eventContext.getException()).getCause();

            if (th instanceof LogicException) {
                FacesContext facesContext = eventContext.getContext();

                // メッセージを追加する
                facesContext.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "System Error", "システムエラーが発生しました。システム管理者にご連絡ください。"));

                // 2. リダイレクトしてもFacesMessageが消えないように設定
                facesContext.getExternalContext().getFlash().setKeepMessages(true);

//                try {
//                    // エラー画面に画面遷移させる
//                    String contextPath = facesContext.getExternalContext().getRequestContextPath();
//                    facesContext.getExternalContext().redirect(contextPath + "/login.xhtml");
//                } catch (IOException e) {
//                    System.out.println("error.xhtmlがありません");
//                } finally {
                    // 3. 未ハンドリングキューから削除する
                    it.remove();
//                }
            }
            LoggerFactory.getLogger(this.getClass()).error(eventContext.getException().getMessage(), eventContext.getException());
        }
        wrapped.handle();
    }

    @Override
    public ExceptionHandler getWrapped() {
        return wrapped;
    }
}
