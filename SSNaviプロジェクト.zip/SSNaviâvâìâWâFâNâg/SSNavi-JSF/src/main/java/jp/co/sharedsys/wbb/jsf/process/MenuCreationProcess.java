package jp.co.sharedsys.wbb.jsf.process;

import java.util.List;
import java.util.Map;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpSession;
import jp.co.sharedsys.wbb.jsf.exception.LogicException;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;

import jp.co.sharedsys.wbb.jsf.beans.AuthorityConfBean;
import jp.co.sharedsys.wbb.jsf.beans.UserLoginView;
import jp.co.sharedsys.wbb.jsf.external.general.ExternalServiceProperty;
import jp.co.sharedsys.wbb.jsf.reports.ReportConfig;
import jp.co.sharedsys.wbb.jsf.reports.ReportContext;
import org.primefaces.model.menu.DefaultMenuColumn;
import org.primefaces.model.menu.DefaultMenuItem;
import org.primefaces.model.menu.DefaultMenuModel;
import org.primefaces.model.menu.DefaultSubMenu;
import org.primefaces.model.menu.MenuModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MenuCreationProcess extends AbstractExternalProcess<UserLoginView>{

    public static final String P_KEY = "application-key";
    public static final String P_REPAPPS = "application-attribute";
    public static final String P_REPCONFIGS = "reportconfig-attribute";
//	private static final String TOKEN_TYPE = SecurityUtils.TOKEN_MENU;
    private static final String RULE_TYPE = "report-menu";
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public void onService(UserLoginView userLogin) throws LogicException, SystemException {

        // システムのメニュー取得
        ReportContext rcontext = userLogin.getSsconfig().getRcontext();
        String service = ExternalServiceProperty.getInstance().getProperty("external-service");
        String function = ExternalServiceProperty.getInstance().getProperty("loadmenu-func");
        rcontext.loadExternal(service, function, userLogin.getUsername());

        ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
        HttpServletRequest request = (HttpServletRequest) externalContext.getRequest();
        HttpSession session = request.getSession();
        if (session == null) {
            logger.warn("session is not available.");
            return;
        }

	// authConfに格納されたmenulistからMenuModelを作成
        AuthorityConfBean authConf = userLogin.getAuthConf();
	
	authConf.setMenuModel(createMenuModel(rcontext, rcontext.getConfigs()));	
        userLogin.getMenuBean().setModel(authConf.getMenuModel());
    }

    private MenuModel createMenuModel(ReportContext rcontext, Map<String, ReportConfig> configs) {

    Map<String, List<Map<String, List<String>>>> parentMap = rcontext.getMenuMap();

	MenuModel model = new DefaultMenuModel();
	DefaultSubMenu rootMenu = null;
	DefaultMenuColumn menuSection = null;
	
	for(String parentKey : parentMap.keySet()){
	    List<Map<String, List<String>>> parentList = parentMap.get(parentKey);

	    rootMenu = new DefaultSubMenu(rcontext.getGroupName(parentKey));
	    menuSection = new DefaultMenuColumn();
	    
	    for (Map<String, List<String>> childMap : parentList){
		
		for(String childKey : childMap.keySet()){
		    
		    DefaultSubMenu sectionMenu = new DefaultSubMenu(rcontext.getGroupName(childKey));
		    List<String> childList = childMap.get(childKey);
		    
		    for (String menu : childList){
			ReportConfig config = configs.get(menu);
			if(config == null){
			    continue;
			}
			DefaultMenuItem item = new DefaultMenuItem(config.getTitle());
			if(config.getScreenCode().equals("LOGOUT")){
			    item.setCommand("#{authConf.logout}");
			}else{
			    item.setCommand("#{pageBean.gotoNext}");
			    item.setUpdate(":main_section");
			    item.setParam("repid", config.getScreenCode());
			    item.setOnstart("PF('blw').block();");
			    item.setOncomplete("doConfirm(args); PF('blw').unblock();scrollTo(0,0);");
			    item.setStyleClass("ssnavi-itemlink");
			    item.setStyleClass("iconEst");
			}
			sectionMenu.addElement(item);
		    }
		    menuSection.addElement(sectionMenu);
		}
		rootMenu.addElement(menuSection);
	    }
	    model.addElement(rootMenu);
	}
	
      // 設定されたSubMenu,MenuItemにユニークなIDが設定されていないと、メニュー動作が出来ない為、
        // 最後にgenerateUniqueIdsを実行する
        model.generateUniqueIds();
        return model;
    }
}
