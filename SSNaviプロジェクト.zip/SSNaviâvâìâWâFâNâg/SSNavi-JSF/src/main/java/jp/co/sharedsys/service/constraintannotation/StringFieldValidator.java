	package jp.co.sharedsys.service.constraintannotation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/** String用Validator
 * 
 * NULL、空文字、文字列長のチェックを行う。
 * @author T.Hirose
 *
 */
public class StringFieldValidator implements ConstraintValidator<StringField, String>{

    private boolean isNotNull;
    private int minLength;
    private int maxLength;
	
    @interface List {
        StringField[] value();
    }

	
    @Override
    public void initialize(StringField constraintAnnotation) {
        this.isNotNull = constraintAnnotation.isNotNull();
        this.minLength  = constraintAnnotation.minLength();
        this.maxLength  = constraintAnnotation.maxLength();
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        // NULLと空文字を許可しない
        if(isNotNull){
            if(value == null || "".equals(value)){
                setMessage(context, "{columnName}は必須項目です。値を入力してください。\n");
                return false;
            }
        }
        // 文字列長チェック（最小）
        if(value != null){
            if(value.length() < minLength || value.length() > maxLength){
                setMessage(context, "{columnName}は{minLength}文字以上{maxLength}文字以下で入力してください。\n");
                return false;
            }
        }
        return true;
    }
	
    private void setMessage(ConstraintValidatorContext context, String message){
        context.disableDefaultConstraintViolation();
        context.buildConstraintViolationWithTemplate(message).addConstraintViolation();
    }
}
