/*
 * PagePropertiesBean.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.util.bean;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.faces.component.UIComponent;
import jp.co.kintetsuls.common.MessageDataModel;
import jp.co.sharedsys.wbb.jsf.beans.ReportListDataModel;
import jp.co.sharedsys.wbb.jsf.component.PageParameterGetter;
import org.primefaces.model.menu.DefaultMenuItem;
import jp.co.sharedsys.wbb.jsf.reports.ReportConfig;
import jp.co.sharedsys.wbb.jsf.reports.ReportPdfGroup;

/**
 * ページネスト時、前画面のプロパティ情報を格納しておくBeanです。
 * BreadCrumbのMenuItem.valueに格納され、遷移指定時に、pageBeanの
 * 各フィールドに展開します。
 */
public class PagePropertiesBean {

	//** 新規追加フィールド */
	/** SQLに渡されるformパラメータ */
	private Map<String, Map<String, Object>> paramsmap = null;
	/** テーブルのpkリストMAP */
	private Map<String, Map<String, Object>> pklistdatas = null;
	/** 検索条件formのデータ1 */
	private Map<String, Map<String, Object>> values = null;
	/** 検索条件formのデータ2 (condition.getDefaultValue,condition.getItemValue) */
	private ReportConfig config = null; 
	/** 個別用formデータ */
    private ArrayList<Object> objectValues = null;
	/** 選択されたデータ */
	private List<Map<String, Object>> selectdatas = null;
	/** メッセージデータ */
	private MessageDataModel messageData;
	/** データテーブル遷移した場合のsqlid */
	private String sqlId = null;
	/** (検討)画面ファイル名 */
	private String filename = null;
	/** 画面スクリーンコード */
	private String screenCode = null;
	/** メニューItem */
	private DefaultMenuItem menuItem = null;
	
	private int index = 0;
	

	public PagePropertiesBean(){
	}
	
	public PagePropertiesBean(Map<String, Map<String, Object>> values , ReportConfig config, String sqlid){
		PageParameterGetter ppg = new PageParameterGetter();
		this.paramsmap = ppg.getParamMap(values, config);
		this.pklistdatas = ppg.getPklist(config);
		this.values = values;
		this.config = config;
		this.filename = config.getConfigFileName();
		this.screenCode = config.getScreenCode();
	}

	public Map<String, Map<String, Object>> getParamsmap() {
		return paramsmap;
	}
	public void setParamsmap(Map<String, Map<String, Object>> paramsmap) {
		this.paramsmap = paramsmap;
	}

	public Map<String, Map<String, Object>> getPklistdatas() {
		return pklistdatas;
	}
	public void setPklistdatas(Map<String, Map<String, Object>> pklistdatas) {
		this.pklistdatas = pklistdatas;
	}

	public Map<String, Map<String, Object>> getValues() {
		return values;
	}
	public void setValues(Map<String, Map<String, Object>> values) {
		this.values = values;
	}

	public ReportConfig getConfig() {
		return config;
	}

	public void setConfig(ReportConfig config) {
		this.config = config;
	}

	public ArrayList<Object> getObjectValues() {
		return objectValues;
	}
	public void setObjectValues(ArrayList<Object> objectValues) {
		this.objectValues = objectValues;
	}

	public Map<String, String> getSelectedLine() {
		return selectedLine;
	}
	public void setSelectedLine(Map<String, String> selectedLine) {
		this.selectedLine = selectedLine;
	}

	public List<Map<String, Object>> getSelectdatas() {
		return selectdatas;
	}
	public void setSelectdatas(List<Map<String, Object>> selectdatas) {
		this.selectdatas = selectdatas;
	}

	public MessageDataModel getMessageData() {
		return messageData;
	}
	public void setMessageData(MessageDataModel messageData) {
		this.messageData = messageData;
	}

	public String getSqlId() {
		return sqlId;
	}
	public void setSqlId(String sqlId) {
		this.sqlId = sqlId;
	}

	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getScreenCode() {
		return screenCode;
	}
	public void setScreenCode(String screenCode) {
		this.screenCode = screenCode;
	}

	public DefaultMenuItem getMenuItem() {
		return menuItem;
	}

	public void setMenuItem(DefaultMenuItem menuItem) {
		this.menuItem = menuItem;
	}

	
	//** 旧フィールド　順次削除対応 */

    
    private String r;
    private String isSearch;
    private String isTrans;

    // 現在のテンプレートXHTML
    private String curXhtml;
    // 現在の画面モード
    private String editMode;
    // 一覧検索結果の格納先
    private Map<String, List<Map<String, Object>>> reportResult;
    // 一覧検索結果をチェックボックスで選択可能とするためのクラス
    private ReportListDataModel selectableResult;
    // 一覧検索結果をチェックボックスで選択可能とするためのクラス(複数定義用)
    private Map<String, ReportListDataModel> selectableResults;
    // 画面で選択された行の格納先
    private List<Map<String, Object>> selectReportResult;
    // 画面で選択された行の格納先(編集画面)
    private Map<String, List<Map<String, Object>>> selectEditReportResult;
    
    // 印刷実施ボタンの、selectOneMenuで選択された項目格納先
    private Map<String, ReportPdfGroup> selectedPdf;
    
    // 外部サービスのレスポンス情報格納先
    private Map<String, Object> externalAttribute;
    
    private Map<String, UIComponent> idBind;
	
	private Map<String, String> selectedLine;
    // Datatable内データ入力値受付の為のプロパティ
    private Map<String, List<Map<String, Object>>> listValues;
	


	public String getR() {
		return r;
	}

	public void setR(String r) {
		this.r = r;
	}

	public String getIsSearch() {
		return isSearch;
	}

	public void setIsSearch(String isSearch) {
		this.isSearch = isSearch;
	}

	public String getIsTrans() {
		return isTrans;
	}

	public void setIsTrans(String isTrans) {
		this.isTrans = isTrans;
	}

	public String getCurXhtml() {
		return curXhtml;
	}

	public void setCurXhtml(String curXhtml) {
		this.curXhtml = curXhtml;
	}

	public String getEditMode() {
		return editMode;
	}

	public void setEditMode(String editMode) {
		this.editMode = editMode;
	}

	public Map<String, List<Map<String, Object>>> getReportResult() {
		return reportResult;
	}

	public void setReportResult(Map<String, List<Map<String, Object>>> reportResult) {
		this.reportResult = reportResult;
	}

	public ReportListDataModel getSelectableResult() {
		return selectableResult;
	}

	public void setSelectableResult(ReportListDataModel selectableResult) {
		this.selectableResult = selectableResult;
	}

	public Map<String, ReportListDataModel> getSelectableResults() {
		return selectableResults;
	}

	public void setSelectableResults(Map<String, ReportListDataModel> selectableResults) {
		this.selectableResults = selectableResults;
	}

	public List<Map<String, Object>> getSelectReportResult() {
		return selectReportResult;
	}

	public void setSelectReportResult(List<Map<String, Object>> selectReportResult) {
		this.selectReportResult = selectReportResult;
	}

	public Map<String, List<Map<String, Object>>> getSelectEditReportResult() {
		return selectEditReportResult;
	}

	public void setSelectEditReportResult(Map<String, List<Map<String, Object>>> selectEditReportResult) {
		this.selectEditReportResult = selectEditReportResult;
	}

	public Map<String, ReportPdfGroup> getSelectedPdf() {
		return selectedPdf;
	}

	public void setSelectedPdf(Map<String, ReportPdfGroup> selectedPdf) {
		this.selectedPdf = selectedPdf;
	}

	public Map<String, Object> getExternalAttribute() {
		return externalAttribute;
	}

	public void setExternalAttribute(Map<String, Object> externalAttribute) {
		this.externalAttribute = externalAttribute;
	}

	public Map<String, UIComponent> getIdBind() {
		return idBind;
	}

	public void setIdBind(Map<String, UIComponent> idBind) {
		this.idBind = idBind;
	}	

	public Map<String, List<Map<String, Object>>> getListValues() {
		return listValues;
	}
	public void setListValues(Map<String, List<Map<String, Object>>> listValues) {
		this.listValues = listValues;
	}


}
