package jp.co.sharedsys.wbb.jsf.conf;

import java.util.ArrayList;
import java.util.List;

public class XReportButton {
    private String name = null;     //B01
    private String value = null;    //B02
    private String action = null;   //B03
    private String rptFile = null;  //B04
    private String rptDir = null;   //B05
    private String service = null;  //B06
    private String functionCode = null; //B08

    private String position = null;     //B10
    private List options = new ArrayList(); //B11

    public void addOption(XReportConditionOption option) {
        this.options.add(option);
    }
    public List getOptions() {
        return options;
    }
    public void setOptions(List options) {
        this.options = options;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getValue() {
        return value;
    }
    public void setValue(String value) {
        this.value = value;
    }
    public String getAction() {
        return action;
    }
    public void setAction(String action) {
        this.action = action;
    }
    public String getRptFile() {
        return rptFile;
    }
    public void setRptFile(String rptFile) {
        this.rptFile = rptFile;
    }
    public String getRptDir() {
        return rptDir;
    }
    public void setRptDir(String rptDir) {
        this.rptDir = rptDir;
    }
    public String getService() {
        return service;
    }
    public void setService(String service) {
        this.service = service;
    }
    public String getPosition() {
        return position;
    }
    public void setPosition(String position) {
        this.position = position;
    }
    public void setFunctionCode(String functionCode) {
        this.functionCode = functionCode;
    }
    public String getFunctionCode() {
        return functionCode;
    }
}
