package jp.co.sharedsys.wbb.jsf.conf;

import java.util.ArrayList;
import java.util.List;

public class XReportColumn {
    private String name = null;         //X01
    private String displayName = null;  //X02
    private String controlType = null;  //X03
    private String dataType = null;     //X04
    private String defaultValue = null; //X05
    private String minLength = null;    //X07
    private String maxLength = null;    //X08
    private String applyTo = null;      //X10
    private String sortIndex = null;    //X16
    private String tabIndex = null;     //X17
    private String readonly = null;     //X18
    private String pk = null;           //X20

    private List options = new ArrayList(); //X21

    private String transferRptFile = null;  //X23
    private String transferRptDir = null;   //X24
    private String tableName = null;        //X26
    private String service;                 //X39
    private String functionCode;            //X40
    private String extra1;                  //X42
    private String extra2;                  //X43
    private String extra3;                  //X44
    private String extra4;                  //X45
    private String extra5;                  //X46

    private String section;                 //X47
    private String visible;                 //X48

    public void setVisible(String visible) {
        this.visible = visible;
    }
    
    public String getVisible() {
        return visible;
    }
    
    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }
            
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getDisplayName() {
        return displayName;
    }
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }
    public String getControlType() {
        return controlType;
    }
    public void setControlType(String controlType) {
        this.controlType = controlType;
    }
    public String getDataType() {
        return dataType;
    }
    public void setDataType(String dataType) {
        this.dataType = dataType;
    }
    public String getDefaultValue() {
        return defaultValue;
    }
    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }
    public String getMinLength() {
        return minLength;
    }
    public void setMinLength(String minLength) {
        this.minLength = minLength;
    }
    public String getMaxLength() {
        return maxLength;
    }
    public void setMaxLength(String maxLength) {
        this.maxLength = maxLength;
    }
    public void addOption(XReportColumnOption option) {
        this.options.add(option);
    }
    public List getOptions() {
        return options;
    }
    public String getApplyTo() {
        return applyTo;
    }
    public void setApplyTo(String applyTo) {
        this.applyTo = applyTo;
    } 
    public String getSortIndex() {
        return sortIndex;
    }
    public void setSortIndex(String sortIndex) {
        this.sortIndex = sortIndex;
    }
    public String getTabIndex() {
        return tabIndex;
    }
    public void setTabIndex(String tabIndex) {
        this.tabIndex = tabIndex;
    }
    public String getReadonly() {
        return readonly;
    }
    public void setReadonly(String readonly) {
        this.readonly = readonly;
    }
    public String getPk() {
        return pk;
    }
    public void setPk(String pk) {
        this.pk = pk;
    }
    public String getTransferRptFile() {
        return transferRptFile;
    }
    public void setTransferRptFile(String transferRptFile) {
        this.transferRptFile = transferRptFile;
    }
    public String getTransferRptDir() {
        return transferRptDir;
    }
    public void setTransferRptDir(String transferRptDir) {
        this.transferRptDir = transferRptDir;
    }
    public String getTableName() {
        return tableName;
    }
    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
    public String getService() {
        return service;
    }
    public void setService(String service) {
        this.service = service;
    }
    public String getFunctionCode() {
        return functionCode;
    }
    public void setFunctionCode(String functionCode) {
        this.functionCode = functionCode;
    }
    public String getExtra1() {
        return extra1;
    }
    public void setExtra1(String extra1) {
        this.extra1 = extra1;
    }
    public String getExtra2() {
        return extra2;
    }
    public void setExtra2(String extra2) {
        this.extra2 = extra2;
    }
    public String getExtra3() {
        return extra3;
    }
    public void setExtra3(String extra3) {
        this.extra3 = extra3;
    }
    public String getExtra4() {
        return extra4;
    }
    public void setExtra4(String extra4) {
        this.extra4 = extra4;
    }
    public String getExtra5() {
        return extra5;
    }
    public void setExtra5(String extra5) {
        this.extra5 = extra5;
    }
}
