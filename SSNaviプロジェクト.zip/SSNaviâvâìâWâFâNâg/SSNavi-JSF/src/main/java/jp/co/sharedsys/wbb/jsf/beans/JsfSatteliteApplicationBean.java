/*
 * JsfSatteliteApplicationBean.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.beans;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.annotation.PostConstruct;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Response;
import jp.co.kintetsuls.common.util.KbnHold;
import jp.co.kintetsuls.common.util.MessageHold;
import jp.co.kintetsuls.common.util.SystemMstHold;
import jp.co.kintetsuls.service.model.biz_common.KbnDef;
import jp.co.kintetsuls.service.model.biz_common.SystemMessageDef;
import jp.co.kintetsuls.service.model.biz_common.SystemMstDef;
import jp.co.sharedsys.bb.ApplicationManager;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;
import jp.co.sharedsys.wbb.jsf.external.general.ExternalAuthTokenClientHeader;
import jp.co.sharedsys.wbb.jsf.external.general.ExternalServiceProperty;
import jp.co.sharedsys.wbb.jsf.reports.ReportAppConfig;
import jp.co.sharedsys.wbb.jsf.reports.ReportConfig;
import jp.co.sharedsys.wbb.jsf.reports.ReportContext;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.io.comparator.NameFileComparator;
import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * SSNaviの動作に必要な情報を保持するManagedBeanで、
 * アプリケーション上に単独で存在するインスタンスです。
 * アプリケーション起動時に設定ファイル群をロードし、インスタンスに保持します。
 * 
 * @author saihara
 */
@ManagedBean(name="ssconfig", eager=true)
@ApplicationScoped
public class JsfSatteliteApplicationBean implements Serializable {
	public static final String IP_HOME = "home-directory";
	public static final String IP_REPORT = "report-directory";
    
    @Getter
    private Map<String, ReportConfig> configs;
    @Getter
    private Map<String, String> screenCodesMap;
    @Getter
    private Map<String, List<ReportConfig>> configListMap;
    @Getter
    private List<ReportAppConfig> reportDirs;
    @Getter
    private String confDirectory = null;
    @Getter
    private ReportContext rcontext;
    @Getter @Setter
    private String sessionTimeout;

    private Logger logger = LoggerFactory.getLogger(this.getClass());
    
    public JsfSatteliteApplicationBean() {
        String homeDir = FacesContext.getCurrentInstance().getExternalContext().getInitParameter(IP_HOME);
        ApplicationManager.getInstance().setHomeDirectory(homeDir);
    }
    
    @PostConstruct
    public void init() {
//        if (FacesContext.getCurrentInstance().isPostback()) {
//            logger.debug("JsfSatteliteApplicationBean is postback...");
//            return;
//        }

        // ここでSSNavi定義ファイルを読み込む (アプリケーション起動時)
        // ManagedBean eager=true により、起動時インスタンス化を実現
        rcontext = new ReportContext();
        rcontext.setConfDirectory(ApplicationManager.getInstance().getHomeDirectory());
        rcontext.init();
        String home = ApplicationManager.getInstance().getHomeDirectory();

        // レポートのフォルダを取得する
        String reportdir = FacesContext.getCurrentInstance().getExternalContext().getInitParameter(IP_REPORT);
        reportdir = reportdir == null || reportdir.isEmpty() ? "reports" : reportdir;
        logger.warn("Home directory is [" + home + "]");
        logger.warn("Report directory name is [" + reportdir + "]");
		
        File directory = new File(home + "/" + reportdir);
        File[] repapps = directory.listFiles();

        List repappslist = new ArrayList();
        if (repapps != null){
                repappslist = Arrays.asList(repapps);
        }
        Collections.sort(repappslist,NameFileComparator.NAME_COMPARATOR);
        for (Iterator ite = repappslist.iterator();ite.hasNext();){
            File repapp = (File) ite.next();
            if (repapp.isDirectory()){
                try {
                    rcontext.loadDir(repapp);
                } catch (SystemException ex) {
                    logger.error(ex.getMessage(), ex);
                }
            }
        }        
        // config set
        this.confDirectory = rcontext.getConfDirectory();
        this.configListMap = rcontext.getConfigListMap();
        this.configs = rcontext.getConfigs();
        this.screenCodesMap = rcontext.getScreenCodes();
        this.reportDirs = rcontext.getRepordirs();
		
        // 追加処理
        
        // ★システムメッセージ取得呼び出し   
        ServiceInterfaceBean res = getMaster("COM_SYSTEM_MESSAGE_SEARCH");
        ObjectMapper mapper = new ObjectMapper();
        Map<String, SystemMessageDef> map = null;
        try {
            map = mapper.readValue(res.getJson(), new TypeReference<Map<String, SystemMessageDef>>() {
            });
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(JsfSatteliteApplicationBean.class.getName()).log(Level.SEVERE, null, ex);
        }
        MessageHold.getInstance().setMessage(map);
             
        // ★区分取得呼び出し
        ServiceInterfaceBean resKbn = getMaster("COM_KBN_SEARCH");
        ObjectMapper mapperKbn = new ObjectMapper();
        Map<String, KbnDef> mapKbn = null;
        try {
            mapKbn = mapperKbn.readValue(resKbn.getJson(), new TypeReference<Map<String, KbnDef>>() {
            });
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(JsfSatteliteApplicationBean.class.getName()).log(Level.SEVERE, null, ex);
        }
        KbnHold.getInstance().setKbn(mapKbn);
        
        // ★システムマスタ取得呼び出し
        ServiceInterfaceBean resSys = getMaster("COM_SYSTEM_MST_SEARCH");
        ObjectMapper mapperSys = new ObjectMapper();
        Map<String, SystemMstDef> mapSys = null;
        try {
            mapSys = mapperSys.readValue(resSys.getJson(), new TypeReference<Map<String, SystemMstDef>>() {
            });
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(JsfSatteliteApplicationBean.class.getName()).log(Level.SEVERE, null, ex);
        }
        SystemMstHold.getInstance().setSystemMst(mapSys);
		
    }
	
	/**
	 * 各種マスタ取得
	 * @param functionCode
	 * @return 
	 */
    public ServiceInterfaceBean getMaster(String functionCode) {
        // JAX-RS接続

        ServiceInterfaceBean res = null;
        try {

            // json作成
            Map<String, String> params = new HashMap<>();
            params.put("TEST", "TEST");
            String requestData = JSONUtil.makeJSONString(params);
            ServiceInterfaceBean req = new ServiceInterfaceBean();
            // ログイン処理等のサービス呼び出しフラグ
            req.setInitial(false);

            req.setUserCd("axis00");
            req.setMakerCode(Arrays.asList(new String[]{"FORTINET"}));  // TODO dummy あとで消す
            List<String> ugcList = new ArrayList<>();
            ugcList.add("ADMIN");
            req.setUserGroupCode(ugcList);

            req.setFunctionCode(functionCode);
            req.setTableName("");
            req.setJson(requestData);
            String reqJson = JSONUtil.makeJSONString(req);

            // request
//          List<Object> providers = new ArrayList<>();
//	    providers.add(new JacksonJaxbJsonProvider());
            ClientConfig config = new ClientConfig();
            // Auth Token付与用フィルタ
            config.register(ExternalAuthTokenClientHeader.class);
            Client client = ClientBuilder.newClient(config);
            client.property(ClientProperties.CONNECT_TIMEOUT, 1200000);
//            client.property(ClientProperties.READ_TIMEOUT,    1000);
            // REST URL 設定
            WebTarget webTarget = client.target(ExternalServiceProperty.getInstance().getProperty("baseurl")).path("/JohmonWebService");
            Invocation.Builder invocationBuilder = webTarget.request(MediaType.APPLICATION_JSON);
            Response response = invocationBuilder.post(Entity.entity(reqJson, MediaType.APPLICATION_JSON_TYPE));

            String result = response.readEntity(String.class);
            ObjectMapper objectMapper = new ObjectMapper();
            res = objectMapper.readValue(result, new TypeReference<ServiceInterfaceBean>() {
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
        return res;
    }
}
