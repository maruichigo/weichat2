package jp.co.sharedsys.service.constraintannotation;

import java.util.Date;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/** Date用Validator
 * 
 * NULL、空文字のチェックを行う。
 * @author sharedsys
 *
 */
public class DateFieldValidator implements ConstraintValidator<DateField, Date>{

    private boolean isNotNull;

    @Override
    public void initialize(DateField constraintAnnotation) {
            this.isNotNull = constraintAnnotation.isNotNull();
    }

    @Override
    public boolean isValid(Date value, ConstraintValidatorContext context) {
            // NULLと空文字を許可しない
            if(isNotNull){
                    if(value == null){
                            setMessage(context, "{columnName}は必須項目です。値を入力してください。\n");
                            return false;
                    }
            }
            return true;
    }

    private void setMessage(ConstraintValidatorContext context, String message){
    context.disableDefaultConstraintViolation();
    context.buildConstraintViolationWithTemplate(message)
            .addConstraintViolation();
    }
}
