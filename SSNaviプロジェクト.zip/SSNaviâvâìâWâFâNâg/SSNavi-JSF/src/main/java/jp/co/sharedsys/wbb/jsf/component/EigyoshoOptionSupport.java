/*
 * reportConditionSupport.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import jp.co.sharedsys.wbb.jsf.beans.SSNaviManagedBean;
import jp.co.sharedsys.wbb.jsf.external.general.ExternalServiceProperty;
import jp.co.sharedsys.wbb.jsf.reports.ReportCondition;
import jp.co.sharedsys.wbb.jsf.reports.ReportConditionOption;
import jp.co.sharedsys.wbb.jsf.process.ExternalServiceExecuter2;
import jp.co.sharedsys.wbb.jsf.reports.AbstractReportOption;
import jp.co.sharedsys.wbb.jsf.reports.ReportColumnOption;
/**
 * 営業所一覧 Autocomplate作製のサポートを行う
 */
public class EigyoshoOptionSupport {

    /** 画面読み込み時にrptファイルで設定されたAutoComleteのoptionに営業所一覧を格納する */
    public ReportCondition setEigyoshoOption(SSNaviManagedBean pageBean, ReportCondition condition){
        String defeigyosho = pageBean.getAuthConf().getDefaultEigyosho();
        List<Map <String, String>> eigyoshoList = pageBean.getAuthConf().getEigyoshoOption();
        condition.setDefaultValue(defeigyosho);
        List list  = getOption(eigyoshoList);
        condition.getOptions().addAll(list);
        return condition;
    }

    /** オプションリストからListを作成する。 */
    public static List getOption(List<Map <String, String>> optionList){

        List newOption = new ArrayList();
        for (Map<String, String> one : optionList){
            AbstractReportOption o = new ReportColumnOption();
            for (Iterator<String> oneIte = one.keySet().iterator(); oneIte.hasNext();) {
                String key = oneIte.next();
                String val = String.valueOf(one.get(key));
                if ("LABEL".equals(key)) {
                    o.setLabel(val);
                } else if ("VALUE".equals(key)) {
                    o.setValue(val);
                } else {
                    o.getRelationValues().put(key, val);
                }
            }
            newOption.add(o);
        }
        return newOption;
    }

    /** コンポーネントサンプル */
    public ReportCondition getAutoComplete(String name, String displayName, String functionCode, String defaultValue, List<String> params, String applyto, String extra2, List<Map <String, String>> optionList){
        try {
            //コンディション作成
            ReportCondition condition = new ReportCondition();
            condition.setName(name);
            condition.setDisplayName(displayName);
            condition.setControlType("AUTOCOMPLETE");
            condition.setDefaultValue(defaultValue);
            condition.setApplyTo(applyto);
            condition.setExtra2(extra2);
            
            //オプション作成
            ReportConditionOption option = new ReportConditionOption();
            if (null == optionList){
                //SQLに渡すためのパラメータ作成
                Map<String, Object> request = new HashMap<>();
                for (int i = 0; i < params.size(); i++) {
                    String in = params.get(i);
                    request.put(String.valueOf(i), in);
                }
                //SQL実行
                optionList = new ExternalServiceExecuter2().simpleSqlList(functionCode, extra2, request);
            }
            
            List list  = getOption(optionList);

            if (null != functionCode){
                String service = ExternalServiceProperty.getInstance().getProperty("external-service");
                option.setService(service);
                option.setFunctionCode(functionCode);
            }

            condition.getOptions().addAll(list);

            return condition;
        } catch (Exception e){
            java.util.logging.Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, e);
            throw e;
        }
    }
}