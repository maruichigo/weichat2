/*
 * BreadCrumbBean.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.beans;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;
import jp.co.sharedsys.wbb.jsf.util.bean.PagePropertiesBean;
import lombok.Getter;
import lombok.Setter;
import org.primefaces.context.RequestContext;
import org.primefaces.model.menu.DefaultMenuItem;
import org.primefaces.model.menu.DefaultMenuModel;
import org.primefaces.model.menu.MenuElement;
import org.primefaces.model.menu.MenuItem;
import org.primefaces.model.menu.MenuModel;

/**
 * パンくずリスト表示用Bean
 * @author s_furutani
 */
@ManagedBean
@ViewScoped
public class BreadCrumbBean implements Serializable {

	@Getter @Setter
	private MenuModel model;

	@Getter @Setter
	private boolean bUpdateFlg;

	@Getter @Setter
	private String curXhtml;

	@Getter
	private Map<String, PagePropertiesBean> properties;
	
	@Getter
	private List<PagePropertiesBean> proplist;

	@Getter @Setter
	private DefaultMenuItem selfMenuItem;
	
	private int menuindex = 0;

	public BreadCrumbBean() {
		init();
	}

	public void init(){
		proplist = new ArrayList<>();
		proplist.add(new PagePropertiesBean());
		properties = new HashMap<>();
		model = new DefaultMenuModel();
		DefaultMenuItem item = createMenuItem("TOP","top_page");
		model.addElement(item);
	}

	/**
	 * ぱんくずリストに入れるアイテムの新規作成
	 * @param title パンくずの画面表示名
	 * @return パンくずitem
	 */
	private DefaultMenuItem createMenuItem(String title, String ScreenCode) {
		DefaultMenuItem item = new DefaultMenuItem(title);
		item.setValue(title);
		item.setUpdate(":main_section");
		item.setOnstart("PF('blw').block();");
		item.setOncomplete("doEditNoActionConfirm();PF('blw').unblock();scrollTo(0,0);");
		item.setCommand("#{pageBean.transAtCrumb}");
		item.setParam("index", Integer.toString(menuindex));
		item.setParam("repid", ScreenCode);
		item.setId(Integer.toString(menuindex));//一意ユニークを与えないと仕様でエラーになります。
		item.setDisabled(false);
		item.setStyleClass("");
		selfMenuItem = item;
		menuindex++;
		return item;
	}

	/**
	 * パンくずにデータが存在する場合は最終的に代入した画面データを取得
	 * A→B→A→Aと遷移する場合、３番目のAのデータを取得。
	 * @param nextScreenCode
	 * @return 
	 */
	public PagePropertiesBean getPageProperties(String nextScreenCode){
		int size = proplist.size();
		for (int i = size - 1; i >= 0; i--) {
			PagePropertiesBean prop = proplist.get(i);
			if (null == prop){
				continue;
			}
			String menuScreenCode = prop.getScreenCode();//getMenuScreenCode(prop.getMenuItem());
			if(nextScreenCode.equals(menuScreenCode)){
				return prop;
			}
		}
		return null;
	}

	/**
	 * パンくずリスト初期化
	 * 使用するタイミングはメニューからの直接遷移時
	 * @param pageBean
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException 
	 */
	public void gotoFirst(String repid, SSNaviManagedBean pageBean) throws IllegalAccessException, InvocationTargetException {
		String title = pageBean.getConfig().getTitle();
		String screenCode = repid;
		
		DefaultMenuModel tmpModel = new DefaultMenuModel();
		// TOPのcrumb
		DefaultMenuItem topItem = (DefaultMenuItem)getModel().getElements().get(0);
		topItem.setDisabled(false);
		tmpModel.addElement(topItem);
		menuindex = 1;
		// 遷移先のcrumb
		DefaultMenuItem item = createMenuItem(title, screenCode);
		item.setDisabled(true);
		item.setStyleClass("currentBreadCrumb");
		tmpModel.addElement(item);
		// model入替え
		model = tmpModel;
		proplist.clear();
		proplist.add(null);
	}

	public void gotoBreadNext(SSNaviManagedBean nextPageBean, PagePropertiesBean oldProp) throws IllegalAccessException, InvocationTargetException {
		oldProp.setMenuItem(selfMenuItem);
		proplist.add(oldProp); 
		
		String nextScreenCode = nextPageBean.getConfig().getScreenCode();
		String nextTitle = nextPageBean.getConfig().getTitle();
		crumbNextRestructure(nextTitle, nextScreenCode);
	}

	/**
	 * 画面ボタン遷移時にパンくずリストに追加する。
	 * A→B→Aの場合、ぱんくずもA→B→Aになる想定。
	 * @param nextTitle
	 * @param nextScreenCode 
	 */
	private void crumbNextRestructure(String nextTitle, String nextScreenCode) {
		int size = model.getElements().size();
		
		for (MenuElement me : model.getElements()) {
			DefaultMenuItem item = (DefaultMenuItem)me;
			item.setDisabled(false);
			item.setStyleClass("");
		}
		DefaultMenuItem item = createMenuItem(nextTitle, nextScreenCode);
		item.setDisabled(true);
		item.setStyleClass("currentBreadCrumb");
		model.addElement(item);		
	}

	/**
	 * crumbクリック遷移時、遷移先画面までのパンくずリストに再構築する。
	 * 逆順でループし、指定パンくず以降のものを削除する。
	 * 例：A - B - C - B の場合に1を指定した場合、A-Bのみ残る。
	 * @param index
	 * @throws SystemException 
	 */
	public void crumbIdRestructure(int index) throws SystemException {
		int size = model.getElements().size();
		proplist.add(null);
		for (int i = size - 1; i >= 0; i--) {
			if (i == index){
				menuindex = i;
				break;
			}
			model.getElements().remove(i);
			proplist.remove(i);
		}
		DefaultMenuItem item = (DefaultMenuItem)model.getElements().get(menuindex);
		item.setDisabled(true);
		item.setStyleClass("currentBreadCrumb");
	}
	
	/**
	 * menu内の最初のscreencodeに一致するindexを取得し、一致した以降のメニュを削除する。
	 * 例：A -B -C -B -Cの場合にBを指定した場合、A -Bのみ残る。
	 * @param screenCode
	 * @throws SystemException 
	 */
	public void crumbScFirstRestructure(String screenCode) throws SystemException {
		int size = model.getElements().size();
		int index = size -1;
		for (int i = 0; i < size; i++) {
			String menusc = getMenuScreenCode((MenuItem)model.getElements().get(i));
			if (menusc.equals(screenCode)){
				index = i;
				break;
			}
		}
		crumbIdRestructure(index);
	}

	/**
	 * menu内の最初のscreencodeに一致するindexを取得し、一致した以降のメニュを削除する。
	 * 例：A -B -C -B -Cの場合にBを指定した場合、A -B -C -B のみ残る。
	 * @param screenCode
	 * @throws SystemException 
	 */
	public void crumbScLastRestructure(String screenCode) throws SystemException {
		int size = model.getElements().size();
		int index = size -1;
		for (int i = size - 1; i >= 0; i--) {
			String menusc = getMenuScreenCode((MenuItem)model.getElements().get(i));
			if (menusc.equals(screenCode)){
				index = i;
				break;
			}
		}
		crumbIdRestructure(index);
	}

	/**
	 * パンくずとして保存されているかチェック
	 * @param nextScreenCode
	 * @return 
	 */
	public boolean findCheck(String screenCode){
		for (PagePropertiesBean prop : proplist){
			String menuScreenCode = prop.getScreenCode();//getMenuScreenCode(prop.getMenuItem());
			if(screenCode.equals(menuScreenCode)){
				return true;
			}
		}
		return false;
	}

	/**
	 * 編集中の場合、callbackで判定戻し
	 * @return 
	 */
	public Boolean checkBUpdateFlg(){
		if (isBUpdateFlg()) {
			RequestContext context = RequestContext.getCurrentInstance();  
			context.addCallbackParam("updateFlg", isBUpdateFlg() );
			context.addCallbackParam("cfType", "editNoActionConfirm");
			return true;
		}
		return false;
	}

	/**
	 * パンくずにデータが存在する場合は取得(index方式)
	 * @param nextScreenCode
	 * @return 
	 */
	public PagePropertiesBean getPageProperties(int index){
		return proplist.get(index);
	}

	/**
	 * menuのindexを取得する
	 * @param item
	 * @return 
	 */
	public int getMenuIndex(MenuItem item){
		return Integer.parseInt(item.getId());
	}

	/**
	 * menuのスクリーンコードを取得する
	 * @param item
	 * @return 
	 */
	public String getMenuScreenCode(MenuItem item){
		return item.getParams().get("repid").get(0);
	}

	//現在のindex番号を取得する。
	public int getMenuindex() {
		return menuindex -1;
	}

}