/*
 * AutoCompOptionConverter.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.component;

import java.util.List;
import javax.faces.bean.ViewScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import jp.co.sharedsys.wbb.jsf.reports.AbstractReportOption;
import org.primefaces.component.autocomplete.AutoComplete;

/**
 * AutoComplete コンポーネントで使用するPOJOを変換するためのクラス
 * doublecombo_in 専用
 * @author saihara
 */
@FacesConverter("optionConverter2")
@ViewScoped
public class AutoCompOptionConverter2 implements Converter {
 
    /**
     * リストから選択された時に呼び出されるメソッド。
     * 通常は入力された value からサービス呼出等でPOJOを取得するが、
     * SSNaviでは呼び出すサービスを特定出来ない為、AutoCompleteに指定されている completeMethodを使用して
     * 取得する。
     * @param context facesContext
     * @param component AutoComplete
     * @param value 入力値
     * @return selected object
     */
    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        AutoComplete uiobj = (AutoComplete)component;
        List list = (List)uiobj.getCompleteMethod().invoke(FacesContext.getCurrentInstance().getELContext(), new String[]{value});
        if (list != null && !list.isEmpty()) {
            return list.get(0);
        } else {
            return value;
        }
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {
        if (value instanceof String) {
            return String.valueOf(value);
        }
        
        if (value != null) {
            return ((AbstractReportOption)value).getValue();
        } else {
            return "";
        }
    }
}
