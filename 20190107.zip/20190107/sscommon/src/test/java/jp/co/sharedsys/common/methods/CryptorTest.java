package jp.co.sharedsys.common.methods;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/** MD5 encrypt test
 * @author saihara
 *
 */
public class CryptorTest extends TestCase{

	private String stringKey = "4x1ez3T1NBt=";
	
	public CryptorTest( String testName )
    {
        super( testName );
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( CryptorTest.class );
    }

	public void testCryptor() throws Exception {
		String clearText = "ssframeAuthStrings";
		String enc = Cryptor.encryptDes(clearText, stringKey);
		
		System.out.println("encrypted string : [" + enc + "]");
		
		String dec = Cryptor.decryptDes(enc, stringKey);

		System.out.println("decrypted string : [" + dec + "]");

		assertEquals(clearText, dec);
	}
}
