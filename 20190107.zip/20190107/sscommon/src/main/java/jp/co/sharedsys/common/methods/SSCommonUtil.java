package jp.co.sharedsys.common.methods;

import java.io.UnsupportedEncodingException;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;

public class SSCommonUtil {

	public static <E extends Enum<E>> E fromOrdinal(Class<E> enumClass, int ordinal) {
	    E[] enumArray = enumClass.getEnumConstants();
	    return enumArray[ordinal];
	}

	public static String zeroMask(Long l){
		return String.format("%1$010d", l);
	}
	public static String zeroMask(Long l, int cnt){
		return String.format("%1$0"+ cnt + "d", l);
	}

	public static byte[] string2byte(String string) {
		try {
			return Base64.decodeBase64(string.getBytes("UTF8"));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return null;
		// return Base16Encoder.decode(string);
	}

    public static String ifnull(Object obj, String replaceVal) {
        if (obj == null) {
            return replaceVal;
        }
        return String.valueOf(obj);
    }
    /**
     * キャメライズする
     *
     * @param s string
     * @return camerized string
     */
    public static String camelize(String s) {
        if (s == null) {
            return null;
        }
        s = s.toLowerCase();
        String[] array = StringUtils.split(s, "_");
        if (array.length == 1) {
            return StringUtils.lowerCase(s);
        }
        StringBuffer buf = new StringBuffer(40);
        for (int i = 0; i < array.length; ++i) {
            if (i == 0) {
                buf.append(StringUtils.lowerCase(array[i]));
            } else {
                buf.append(StringUtils.capitalize(array[i]));
            }
        }
        return buf.toString();
    }
    
}
