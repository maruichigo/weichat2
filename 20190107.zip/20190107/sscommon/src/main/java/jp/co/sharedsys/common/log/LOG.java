package jp.co.sharedsys.common.log;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LOG {
	
	private static final Logger L = LoggerFactory.getLogger(LOG.class);
	
	public static void debug(String msg){
		L.debug(msg);
	}
	public static void info(String msg){
		L.info(msg);
	}
	public static void warn(String msg){
		L.warn(msg);
	}
	public static void error(String msg){
		L.error(msg);
	}
	public static void fatal(String msg){
		L.error(msg);
	}
}
