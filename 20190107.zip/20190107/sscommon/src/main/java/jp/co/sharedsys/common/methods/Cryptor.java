package jp.co.sharedsys.common.methods;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import jp.co.sharedsys.common.exception.SystemException;

public class Cryptor {

	public static String md5(String src) throws SystemException {
		MessageDigest md;
		byte[] digest = null;
		try {
			md = MessageDigest.getInstance("MD5");
			digest = md.digest(src.getBytes("UTF8"));
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			throw new SystemException(e.getMessage(), e);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			throw new SystemException(e.getMessage(), e);
		}
	
		StringBuffer buf = new StringBuffer();
		for(int i= 0; i< digest.length; i++){
			int d = digest[i];
			if (d < 0) {
			    d += 256;
			}
			if (d < 16) {
			  buf.append("0");
			}
			buf.append(Integer.toString(d, 16));
		}
		return buf.toString();
	}

	public static String encryptDes(String clearText, String stringKey) throws NoSuchAlgorithmException, NoSuchPaddingException,
	        InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
	
	    byte[] encodedKey = SSCommonUtil.string2byte(stringKey);
	    SecretKey secretKey = new SecretKeySpec(encodedKey, 0, encodedKey.length, "DES");
	
	    byte[] clearTextByte = clearText.getBytes();
	
	    Cipher cipher = Cipher.getInstance("DES");
	    cipher.init(Cipher.ENCRYPT_MODE, secretKey);
	
	    byte[] encryptedBytes = cipher.doFinal(clearTextByte);
	    String encryptedHexString = BinaryHexConverter.bytesToHexString(encryptedBytes);
	
	    return encryptedHexString;
	}

	public static String decryptDes(String encryptedHexText, String stringKey) {
	
	    byte[] encodedKey = SSCommonUtil.string2byte(stringKey);
	    SecretKey secretKey = new SecretKeySpec(encodedKey, 0, encodedKey.length, "DES");
	
	    String decryptedText = null;
	    try {
		    Cipher cipher = Cipher.getInstance("DES");
		    cipher.init(Cipher.DECRYPT_MODE, secretKey);
		
		    byte[] decryptedByte = cipher.doFinal(BinaryHexConverter.hexStringToBytes(encryptedHexText));
		    decryptedText = new String(decryptedByte);
	    } catch (Exception e) {
	    	e.printStackTrace();
	    }
	
	    return decryptedText;
	}

}
