package jp.co.sharedsys.common.methods;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** 郵便番号処理クラス
 * @author T.Hirose
 *
 */
public class PostalCode {

	/**
	 * 郵便局のHP（読み仮名データの促音・拗音を小書きで表記するもの(zip形式)）
	 */
	private final static String URL = "http://www.post.japanpost.jp/zipcode/dl/oogaki/zip/ken_all.zip";

	/**
	 * 郵便局のHPより郵便番号のZIPファイルをダウンロードし展開する。
	 * 
	 * @param saveDir
	 *            ダウンロードした郵便番号ZIPファイル保存先ディレクトリ
	 * @param unzipDir
	 *            郵便番号ZIPファイルの展開先ディレクトリ
	 */
	public static void downloadPostalCodeFile(String saveDir, String unzipDir)
			throws Exception {

		FileOutputStream fos = null;
		DataInputStream dis = null;
		try {
			/*
			 * 保存するファイルの FileOutputStream を構築します。 引数にファイル名を指定します。
			 */
			fos = new FileOutputStream(saveDir);

			/* URLを構築します。引数にダウンロード先のURLを指定します。 */
			URL url = new URL(URL);

			HttpURLConnection urlConnection = (HttpURLConnection) url
					.openConnection();
			urlConnection.connect();

			int num;
			byte buf[] = new byte[4096];

			/* DataInputStreamを使用してファイルに書き出します。 */
			dis = new DataInputStream(
					urlConnection.getInputStream());
			while ((num = dis.read(buf)) != -1) {
				fos.write(buf, 0, num);
			}
			File f = new File(saveDir);
			Zip.decode(f, unzipDir);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally{
			if(dis != null){
				try{
					dis.close();
				} catch(Exception e){
				} finally{
					dis = null;
				}
			}
			if(fos != null){
				try{
					fos.close();
				} catch(Exception e){
				} finally{
					fos = null;
				}
			}
		}
	}

}
