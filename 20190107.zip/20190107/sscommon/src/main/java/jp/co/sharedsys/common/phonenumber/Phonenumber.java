package jp.co.sharedsys.common.phonenumber;

import jp.co.sharedsys.common.exception.InvalidPhonenumberException;

import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber.PhoneNumber;

public class Phonenumber {

	public static String getFormetedPhoneNumber(String phonenumber) throws Exception{
		
		PhoneNumberUtil phoneNumberUtil = PhoneNumberUtil.getInstance();
		
		String formatedPhoneNumber = null;
		
		try{
			PhoneNumber phoneNumber = phoneNumberUtil.parse(phonenumber, "JP");
			formatedPhoneNumber = phoneNumberUtil.format(phoneNumber, PhoneNumberUtil.PhoneNumberFormat.NATIONAL);
		} catch(NumberParseException ne){
			throw new InvalidPhonenumberException(ne.getMessage());
		} catch(Exception e){
			throw e;
		}
		return formatedPhoneNumber;
		
	}
	
}
