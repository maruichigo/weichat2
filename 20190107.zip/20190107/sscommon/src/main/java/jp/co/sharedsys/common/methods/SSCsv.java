package jp.co.sharedsys.common.methods;

import java.io.FileReader;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import au.com.bytecode.opencsv.CSVReader;

public class SSCsv {

	/** CSVデータからModelオブジェクトを作成
	 * @param directory CSVファイルが置かれているディレクトリ
	 * @param fileName CSVファイル名
	 * @param className CSVファイルのデータをセットするモデルのクラス名
	 * @return CSVデータをセットしたモデルのリスト
	 * @throws Exception
	 */
	public static List<Object> createModelFromCSV(String directory,
			String fileName, String className) throws Exception {
		
		CSVReader reader = new CSVReader(new FileReader(directory + fileName));
		String[] nextLine;
		int lineNo = 1;
		Map<Integer, String> title = new HashMap<Integer, String>();
		List<Map<String, Object>> csvData = new ArrayList<Map<String, Object>>();
		while ((nextLine = reader.readNext()) != null) {
			if (lineNo++ == 1) { // １行目(タイトル行)
				for (int i = 0; i < nextLine.length; i++) {
					title.put(i, nextLine[i].toUpperCase().replaceAll("_", ""));
				}
			} else { // 2行目移行(データ行)
				Map<String, Object> lineData = new HashMap<String, Object>();
				for (int i = 0; i < nextLine.length; i++) {
					lineData.put(title.get(i).replaceAll("_", ""), nextLine[i]);
				}
				csvData.add(lineData);
			}
		}
		reader.close();
		reader = null;

		List<Object> models = new ArrayList<Object>();

		for (Map<String, Object> lineData : csvData) {
			Class<?> model = Class.forName(className);
			Object object = model.newInstance();

			Method[] methods = object.getClass().getDeclaredMethods();
			for (Method method : methods) {
				if (method.getName().startsWith("set")) { // setterメソッドを実行
					if (lineData.get(method.getName().replace("set", "")
							.toUpperCase()) != null) {
						try {
							method.invoke(
									object,
									lineData.get(method.getName()
											.replace("set", "").toUpperCase()));
						} catch (Exception e) {
							System.out.println(method.getName()
									.replace("set", "").toUpperCase());
						}
					} else {
						System.out.println(method.getName().replace("set", "")
								.toUpperCase());
					}
				}
			}
			models.add(object);
		}
		return models;
	}

}
