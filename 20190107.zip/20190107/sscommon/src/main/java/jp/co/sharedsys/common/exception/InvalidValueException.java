package jp.co.sharedsys.common.exception;

public class InvalidValueException  extends SSException{


	/**
	 * 
	 */
	private static final long serialVersionUID = 748445081644611532L;

//	public InvalidValueException(){
//		super();
//	}
//	
//	public InvalidValueException(Throwable cause){
//		
//	}	
//
	public InvalidValueException(String message){
		super(message);
	}	
//	public InvalidValueException(String message, Throwable cause){
//		super(message, cause);
//	}	

}
