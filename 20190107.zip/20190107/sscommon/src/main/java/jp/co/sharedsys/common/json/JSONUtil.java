package jp.co.sharedsys.common.json;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ser.DefaultSerializerProvider;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;

public class JSONUtil {

	public static String makeJSONString(Object valueMap){
		ObjectMapper objectMapper = new ObjectMapper();

		// nullを空文字にするためのシリアライザークラスをセット
		DefaultSerializerProvider.Impl serializeProvider = new DefaultSerializerProvider.Impl();
		serializeProvider.setNullValueSerializer(new NullValueSerializer());
		objectMapper.setSerializerProvider(serializeProvider);

		String jsonString = null;

		try {
			jsonString = objectMapper.writeValueAsString(valueMap);
		} catch (JsonGenerationException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return jsonString;
	}

	public static ServiceInterfaceBean getServiceInterfaceBeanFromResult(String result){
		ObjectMapper mapper = new ObjectMapper();
		ServiceInterfaceBean s = null;
		try {
			s= mapper.readValue(result, ServiceInterfaceBean.class);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s;
	}

}
