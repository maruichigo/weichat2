package jp.co.sharedsys.common.pdf;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;

/** PDFからのテキスト抽出処理の基底クラス
 * @author sharedsys
 *
 */
public abstract class SSPDFTextStripper {

	enum MONTH{January, February, March, April, May, June , July, August, September, October, November, December}

	/**
	 * PDFファイルのパス（ファイル名も含む）
	 */
	protected String pdfFilePath;

	/** PDFファイルのパス（ファイル名も含む）の設定
	 * @param pdfFilePath　PDFファイルのパス（ファイル名も含む）
	 */
	public void setPDFFileDir(String pdfFilePath){

		this.pdfFilePath = pdfFilePath;
	}


	/**　PDFファイルのテキストを抽出
	 * @return　PDFファイルのテキスト
	 */
	protected String getTextInPDF(){

		String text = null;
		PDDocument document = null;
		try {
		    //PDFドキュメントをロード
		    document = PDDocument.load(pdfFilePath);

		    //テキスト分解クラス生成
		    PDFTextStripper stripper = new PDFTextStripper();
		    //抽出実施
		    text = stripper.getText(document);
		    document.close();
		} catch (IOException e) {
		    e.printStackTrace();
		} finally{
			document = null;
		}
		return text;
	}

	protected String getTextInPDF(InputStream stream){
		String text = null;
		PDDocument document = null;
		try {
		    //PDFドキュメントをロード
		    document = PDDocument.load(stream);

		    //テキスト分解クラス生成
		    PDFTextStripper stripper = new PDFTextStripper();
		    //抽出実施
		    text = stripper.getText(document);
		    document.close();
		} catch (IOException e) {
		    e.printStackTrace();
		} finally{
			document = null;
		}
		return text;
	}

	protected abstract <T> T getText();

	/** テキストからPrefixから始まる単語を取得する(最初の１語のみ)
     * @param sentence テキスト
     * @param prefix 抽出対象の単語のプレフィックス
     * @return Prefixから始まる単語
     */
    protected String getTextMachedToPrefix(String sentence, String prefix){

    	String word = null;
    	int wordStartPosition = 0;
    	String lineStr = "\n";
    	sentence = sentence.replaceAll("\r\n", lineStr);
    	sentence = sentence.replaceAll("\r", lineStr);

    	while(true){
    		int sepPosition = 0;
    		int sepSpacePosition = sentence.indexOf(" ",wordStartPosition);
    		int sepEnterPosition = sentence.indexOf(lineStr,wordStartPosition);
    		if(sepSpacePosition <= sepEnterPosition){
    			sepPosition = sepSpacePosition;
    		} else {
    			sepPosition = sepEnterPosition;
    		}
        	if(sepPosition < 0){
        		sepPosition = sentence.indexOf(lineStr,wordStartPosition);
        		if(sepPosition < 0){
        			word = sentence;
        		} else {
        			word = sentence.substring(wordStartPosition,sepPosition);
        		}
        	} else {
    			word = sentence.substring(wordStartPosition,sepPosition);
        	}
        	if(word != null){
        		word = word.replace(lineStr, "");
            	if(word.matches(prefix)){
            		break;
            	} else {
            		wordStartPosition += word.length();
            	}
        	}
        	word = null;
        	wordStartPosition++;
        	if(wordStartPosition >= sentence.length()){
        		break;
        	}
    	}
    	return word;
    }

//    2019.07.20 入庫取込PDFファイル変更のため C.Kajiwara Contract Registration Codeの取得方法を変更
	/** テキストからPrefixから始まる単語を取得する(最初の１語のみ)
     * @param sentence テキスト
     * @param beforeWord 検出対象の前にある文
     * @return beforeWordの右隣にある単語
     */
    protected String getTextMachedToBeforeWord(String sentence, String beforeWord){

    	String lineStr = "\n";
    	sentence = sentence.replaceAll("\r\n", lineStr);
    	sentence = sentence.replaceAll("\r", lineStr);
    	sentence = sentence.replaceAll("\t", "");
    	sentence = sentence.replaceAll(" ", "");
    	sentence = sentence.replaceAll("&nbsp;", "");
    	sentence = sentence.replaceAll("　", "");

    	String[] words = sentence.split(lineStr);
    	String word = null;

    	for (int i = 0 ; i < words.length ; i++){
    		word = words[i];
    		if(word.toUpperCase().startsWith(beforeWord.toUpperCase())){
    			word = word.toUpperCase().replaceAll(beforeWord.toUpperCase(), "");
    			if (word.length() == 0){
    				word = null;
    			}
    			break;
    		}
    	}
    	return word;
    }

    /**　テキストからタイトル文字列の次の単語を取得する。
     * @param sentence　テキスト
     * @param title タイトル文字列
     * @return タイトル文字列の次の単語
     */
    protected String getTextWithTitle(String sentence, String title){

    	System.out.println(sentence);

		String value = null;
		int i = sentence.indexOf(title);
		if(i < 0){
		} else {
			if(sentence.length() != title.length()){
				int j=i + title.length();
				while(true){
					String word = sentence.substring(j,j+1);
					System.out.println("j:" + j + ":[" + word + "]");
					if(!" ".equals(word) || "\n".equals(word)){
						break;
					}
					j++;
					if(j >= sentence.length()){
						break;
					}
				}
				int spaceAfterLicenseNo = sentence.indexOf(" ",j+1);
				if(spaceAfterLicenseNo > j){
					value = sentence.substring(j,spaceAfterLicenseNo);
				} else {
					if(!"\n".equals(sentence.subSequence(j, j+1))){
						value = sentence.substring(j);
					}
				}
				if(value != null) value = value.replaceAll("\n", "");
			}
		}
		return value;
	}

	/** テキストからPrefixから始まる単語を取得する(全て)
     * @param sentence テキスト
     * @param prefix 抽出対象の単語のプレフィックス
     * @return Prefixから始まる単語
     */
    protected List<String> getTextMachedToPrefixAll(String sentence, String prefix){
    	List<String> words = new ArrayList<String>();
    	String word = null;
    	int wordStartPosition = 0;
    	String lineStr = "\n";
    	sentence = sentence.replaceAll("\r\n", lineStr);
    	sentence = sentence.replaceAll("\r", lineStr);

    	while(true){
    		int sepPosition = 0;
    		int sepSpacePosition = sentence.indexOf(" ",wordStartPosition);
    		int sepEnterPosition = sentence.indexOf(lineStr,wordStartPosition);
    		if(sepSpacePosition <= sepEnterPosition){
    			sepPosition = sepSpacePosition;
    		} else {
    			sepPosition = sepEnterPosition;
    		}
        	if(sepPosition < 0){
        		sepPosition = sentence.indexOf(lineStr,wordStartPosition);
        		if(sepPosition < 0){
        			word = sentence;
        		} else {
        			word = sentence.substring(wordStartPosition,sepPosition);
        		}
        	} else {
    			word = sentence.substring(wordStartPosition,sepPosition);
        	}
        	if(word != null){
        		word = word.replace(lineStr, "");
            	if(word.matches(prefix)){
            		if (!words.contains(word)) {
            			words.add(word);
            		}
            	}
        		wordStartPosition += word.length();
        	}
        	word = null;
        	wordStartPosition++;
        	if(wordStartPosition >= sentence.length()){
        		break;
        	}
    	}
    	return words;
    }

    /**　文字列内に含まれている日付（一番目）を取得
     * @param sentence　文字列
     * @return　文字列内に含まれている日付（一番目）
     */
    protected String getDate(String sentence){
    	String lineStr = "\n";
    	sentence = sentence.replaceAll("\r\n", lineStr);
    	sentence = sentence.replaceAll("\r", lineStr);

    	for(int i=0;i<MONTH.values().length;i++){
    		int idx = sentence.indexOf(MONTH.values()[i].toString());
    		if(idx >= 0){
    			return sentence.substring(idx,sentence.indexOf("\n",idx));
    		}
    	}
    	return null;
    }

}
