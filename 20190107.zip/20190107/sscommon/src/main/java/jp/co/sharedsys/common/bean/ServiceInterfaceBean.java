package jp.co.sharedsys.common.bean;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class ServiceInterfaceBean {

	//============================================================
	// 処理ステータス
	//============================================================
	// システムエラー
	public static final int PROCESS_STATUS_SYSTEM_ERROR = -2;
	// 通常エラー(値の間違い、不正処理)
	public static final int PROCESS_STATUS_ERROR = -1;
	// 正常終了
	public static final int PROCESS_STATUS_SUCCESS = 1;
	
	private String message = "";
	private int statusCode = 0;
	private String userId = "";
	private String functionCode = "";

        private String tableName = "";
	private String json = "";
    @JsonIgnore
	private List<String> makerCode = null;
	private List<String> userGroupCode = null;
	
	private Map<String,String> errFldMapNew = new TreeMap<String,String>();
	private Map<String,String> errMsgMapNew = new TreeMap<String,String>();
	
	// initial処理用フラグ
	private boolean initial = false;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getFunctionCode() {
		return functionCode;
	}
	public void setFunctionCode(String funcId) {
		this.functionCode = funcId;
	}
	public Map getErrFldMapNew() {
		return errFldMapNew;
	}
	public void setErrFldMapNew(Map errFldMapNew) {
		this.errFldMapNew = errFldMapNew;
	}
	public Map getErrMsgMapNew() {
		return errMsgMapNew;
	}
	public void setErrMsgMapNew(Map errMsgMapNew) {
		this.errMsgMapNew = errMsgMapNew;
	}
	public String getJson() {
		return json;
	}
	public void setJson(String json) {
		this.json = json;
	}
	public List<String> getMakerCode() {
		return makerCode;
	}
	public void setMakerCode(List<String> makerCode) {
		this.makerCode = makerCode;
	}
	public List<String> getUserGroupCode() {
		return userGroupCode;
	}
	public void setUserGroupCode(List<String> userGroupCode) {
		this.userGroupCode = userGroupCode;
	}
	public boolean isInitial() {
		return initial;
	}
	public void setInitial(boolean initial) {
		this.initial = initial;
	}
        
         public String getTableName() {
            return tableName;
        }

        public void setTableName(String tableName) {
            this.tableName = tableName;
        }
}
