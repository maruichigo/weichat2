package jp.co.sharedsys.ssframe.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jp.co.sharedsys.ssframe.model.User;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/** ユーザーテーブル処理クラス
 * @author K.Akeda
 *
 */
@Component
public class UserDao extends BaseDao<User> {

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    public User create(User user) {
        getSqlSession().insert("user.create", user);
        return user;
    }

    public User update(User user) {
        getSqlSession().update("user.update", user);
        return user;
    }

    public User softDelete(User user) {
        getSqlSession().update("user.softDelete", user);
        return user;
    }

    public void delete(String userId) {
        getSqlSession().delete("user.delete", userId);
    }

    public List<User> findAll() {
        return getSqlSession().selectList("user.findAll");
    }

    public User findById(User user) {
        return (User) getSqlSession().selectOne("user.findById", user);
    }

    public List<User> findByColumn(User entity) {
        return getSqlSession().selectList("user.findByColumn", entity);
    }

    public List<User> find(User entity, String sqlId) {
        return getSqlSession().selectList(sqlId, entity);
    }

    @Override
    public List<User> updateByColumn(User searchCriteria, User entity) {
        Map<String ,Object> map = new HashMap<>();
        map.put("crt", searchCriteria);
        map.put("upd", entity);
        getSqlSession().update("user.updateByColumn",map);
        return findByColumn(entity);
    }

    @Override
    public void deleteByColumn(User entity) {
        getSqlSession().delete("user.deleteByColumn", entity);
    }

    @Override
    public List<User> softDeleteByColumn(User entity) {
        getSqlSession().update("user.softDeleteByColumn",entity);
        return null;
    }

    @Override
    public List<User> insert(List<User> entity, String sqlId) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<User> insert(User entity, String sqlId) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<User> update(User searchCriteria, User entity, String sqlId) {
        // TODO Auto-generated method stub
        return null;
    }

    public List<User> passwordChange(User target, User old) {
        List<User> chk = findByColumn(old);
        if (chk == null || chk.isEmpty()) {
                return null;
        }
        return updateByColumn(old, target);
    }
}
