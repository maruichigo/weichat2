package jp.co.sharedsys.service.model;

import java.io.Serializable;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import jp.co.sharedsys.service.constraintannotation.PrimaryKey;
import lombok.Data;

/** 
 * 共通アップロードテスト
 * @author sharedsys
 */
@Data
public class WkUpload extends BaseModel implements Serializable {

    @NotNull
    @Digits(integer = 10, fraction = 0)
    @Min(0)
    @PrimaryKey(columnName = "ID")
    private Long id;

    private Long yomikomiId;
    private String val1;
    private String val2;
    private String val3;
}
