package jp.co.sharedsys.service.constraintannotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

/** 文字列フィールド用アノテーション
 * @author sharedsys
 *
 */
@Documented
@Target({ElementType.TYPE, ElementType.METHOD, ElementType.FIELD, ElementType.CONSTRUCTOR, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = { StringFieldValidator.class })
public @interface StringField {

    @SuppressWarnings("javadoc")
    @Documented
    @Target({ElementType.TYPE, ElementType.METHOD, ElementType.FIELD, ElementType.CONSTRUCTOR, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE})
    @Retention(RetentionPolicy.RUNTIME)
    public @interface List {
        StringField[] value();
    }

    /** チェック結果メッセージ取得
     * @return チェック結果メッセージ
     */
    String message() default "";
    
    /** カラム名取得
     * @return カラム名
     */
    String columnName();
    
    /**　NotNullフラグ取得(true:NotNull false:Null (NULL許可))
     * @return NotNull許可フラグ
     */
    boolean isNotNull() default false;
    
    /** 最小文字列長取得
     * @return 最小文字列長
     */
    int minLength() default 0;
    
    /** 最大文字列長取得
     * @return 最大文字列長
     */
    int maxLength();
    
    /**　グループの取得
     * @return グループ
     */
    Class<?>[] groups() default {};

    /**　Payload取得
     * @return Payload
     */
    Class<? extends Payload>[] payload() default {};
}