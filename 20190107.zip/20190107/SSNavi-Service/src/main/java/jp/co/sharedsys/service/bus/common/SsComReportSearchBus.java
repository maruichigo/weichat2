package jp.co.sharedsys.service.bus.common;

import java.util.List;
import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.service.bus.SSFrameBusBase;
import jp.co.sharedsys.service.mapper.IMapper;
import jp.co.sharedsys.service.mapper.SsComMaintColumnMapper;
import jp.co.sharedsys.service.mapper.SsComMaintSubSearchMapper;
import jp.co.sharedsys.service.mapper.SsComReportDefMapper;
import jp.co.sharedsys.service.model.SsComMaintColumn;
import jp.co.sharedsys.service.model.SsComMaintSubSearch;
import org.apache.commons.lang.StringUtils;

/** 
 * 共通メンテナンス用データ取得
 */
@Component("SS_COM_REPORT_SEARCH")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class SsComReportSearchBus extends SSFrameBusBase {
    protected final String TABLE_NAME = "TABLE_NAME";
    
    @Autowired
    private SsComReportDefMapper reportMapper;
    @Autowired
    private SsComMaintColumnMapper columnMapper;
    @Autowired
    private SsComMaintSubSearchMapper subSearchMapper;

    private IMapper mapForTarget(String target) {
        IMapper mapper =(IMapper)this.getWebApplicationContext().getBean(target);
        if (mapper != null) {
            return mapper;
        }
        throw new UnsupportedOperationException("unsupported table");
    }
    private IMapper targetMapper;
    
    private Map<String, Object> params = null;
    
    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        super.init(serviceInterfaceBean);
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
        if (params.get(TABLE_NAME) != null && !StringUtils.isEmpty((String)params.get(TABLE_NAME))) {
            targetMapper = this.mapForTarget((String) params.get(TABLE_NAME));
        }
    }
    @Override
    public String validateHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }
	
    @Override
    public String validateDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }
    
    @Override
    public String validateHeaderByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public String validateDetailByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    /** 
     * 検索
     * @param serviceInterfaceBean リクエストパラメータ
     * @throws Exception
     */
    @Override
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        List<Map> result = null;
        if (targetMapper != null) {
            result = targetMapper.findToMap(params);
        } else {
            if (params != null && params.get("0").equals("COM_REPORT_DEF")) {
                List<Map> resultList = reportMapper.findAllForSelector();
                serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
            } else if (params != null && (params.get("0").equals("COM_MAINT_COLUMN"))) {
                SsComMaintColumn crt = new SsComMaintColumn();
                crt.setTableName((String)params.get("1"));
                List<SsComMaintColumn> resultList = columnMapper.findByColumn(crt);
                serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
            } else if (params != null && (params.get("0").equals("COM_MAINT_SUB_SEARCH"))) {
                SsComMaintSubSearch crt = new SsComMaintSubSearch();
                crt.setTableName((String)params.get("TABLE_NAME"));
                List<SsComMaintSubSearch> resultList = subSearchMapper.findByColumn(crt);
                serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
            }
        }

        if (result != null) {
            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        }
        serviceInterfaceBean.setMessage("共通レポート用データ検索に成功しました");
    }

    @Override
    public void saveDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }
    
    @Override
    public void setValidaterFactory() throws Exception {
    }
    
    @Override
    public void confirm(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }
        
    @Override
    public String finalProc(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }             
}
