package jp.co.sharedsys.service.mapper;

import java.util.List;
import java.util.Map;
import jp.co.sharedsys.service.model.SsComUploadCheckResult;
import org.springframework.stereotype.Component;

/**
 *
 * @author sharedsys
 */
@Component("SS_COM_UPLOAD_CHECK_RESULT")
public interface SsComUploadCheckResultMapper extends IMapper {
    
    List<SsComUploadCheckResult> findAll();

    List<Map> findAllForSelector();
    
    SsComUploadCheckResult findById(int id);
    
    List<SsComUploadCheckResult> findByColumn(SsComUploadCheckResult entity);
    
    List<SsComUploadCheckResult> findLineInfo(SsComUploadCheckResult entity);

}
