package jp.co.sharedsys.service;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;

/**
 * @author sharedsys
 *
 */
public interface ISSFrameValidater {

    /**
     * @param serviceInterfaceBean
     * @return エラーメッセージ
     */
    public String validateHeader(ServiceInterfaceBean serviceInterfaceBean);

    /**
     * @param serviceInterfaceBean
     * @return エラーメッセージ
     */
    public String validateDetail(ServiceInterfaceBean serviceInterfaceBean);
}
