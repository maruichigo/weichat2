package jp.co.sharedsys.service.mapper;

import java.util.List;
import java.util.Map;
import jp.co.sharedsys.service.model.SsComUploadDef;
import org.springframework.stereotype.Component;

/**
 *
 * @author sharedsys
 */
@Component("SS_COM_UPLOAD_DEF")
public interface SsComUploadDefMapper extends IMapper {
    
    List<SsComUploadDef> findAll();

    List<Map> findAllForSelector();
    
    SsComUploadDef findById(int id);
    
    List<SsComUploadDef> findByColumn(SsComUploadDef entity);
}
