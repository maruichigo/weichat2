package jp.co.sharedsys.ssframe.common;

/** ssframeで利用する定数
 * @author T.Hirose
 *
 */
public interface SSFrameConst {

    /** 有効化フラグ */
    enum ACTIVE_IND {INACTIVE,ACTIVE};

    /** ステータス種別 */
    enum STATUS_TYPE{RECEIVE,ORDER,ASN,SHIPMENT};
}
