package jp.co.sharedsys.service.config;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;

/**
 *
 * @author sharedsys
 */
@Order(Ordered.HIGHEST_PRECEDENCE)
public class SpringWebContainerInitializer implements WebApplicationInitializer {

    @Override
    public void onStartup(ServletContext servletContext) throws ServletException {
        registerContextLoaderListener(servletContext);
        
        // Set the Jersey used property to it won't load a ContextLoaderListener
        servletContext.setInitParameter("contextConfigLocation", "");
        
    }
    
    private void registerContextLoaderListener(ServletContext servletContext) {
        WebApplicationContext webContext = createWebAplicationContext(SpringAppConfiguration.class);
        servletContext.addListener(new ContextLoaderListener(webContext));

//        final ServletRegistration.Dynamic appServlet = servletContext.addServlet("dispatcher", new DispatcherServlet(webContext));
//        appServlet.setAsyncSupported(true);
//        appServlet.setMultipartConfig(new MultipartConfigElement(null, 10000, 1000000, 1000000));
////        appServlet.setLoadOnStartup(1);
//        appServlet.addMapping("/");
    }
    
    public WebApplicationContext createWebAplicationContext(Class configClasses) {
        AnnotationConfigWebApplicationContext context = new AnnotationConfigWebApplicationContext();
//        context.getEnvironment().setActiveProfiles("production");
        context.register(configClasses);
        context.refresh();
//        context.scan(configClasses.getPackage().getName());

        return context;
    }
}
