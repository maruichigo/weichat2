package jp.co.sharedsys.ssframe.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.sharedsys.ssframe.model.Function;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/** ファンクションマスタテーブル処理クラス
 * @author S.Nagai
 *
 */
@Repository
public class FunctionDao extends BaseDao<Function> {

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    public Function create(Function function) {
        getSqlSession().insert("function.create", function);
        return function;
    }

    public Function update(Function function) {
        getSqlSession().update("function.update", function);
        return function;
    }

    public Function softDelete(Function function) {
        getSqlSession().update("function.softDelete", function);
        return function;
    }

    public void delete(String id) {
        getSqlSession().delete("function.delete", id);
    }

    public List<Function> findAll() {
        return getSqlSession().selectList("function.findAll");
    }

    @Override
    public Function findById(Function entity) {
        return (Function) getSqlSession().selectOne("function.findById", entity);
    }

    @Override
    public List<Function> findByColumn(Function entity) {
        return getSqlSession().selectList("function.findByColumn", entity);
    }

    @Override
    public List<Function> find(Function entity, String sqlId) {
        return getSqlSession().selectList(sqlId, entity);
    }

    @Override
    public List<Function> updateByColumn(Function searchCriteria, Function entity) {
        Map<String, Object> map = new HashMap<>();
        map.put("crt", searchCriteria);
        map.put("upd", entity);
        getSqlSession().update("function.updateByColumn",map);
        return findByColumn(entity);
    }

    @Override
    public void deleteByColumn(Function entity) {
        getSqlSession().delete("function.deleteByColumn",entity);
    }

    @Override
    public List<Function> softDeleteByColumn(Function entity) {
        getSqlSession().update("function.softDeleteByColumn", entity);
        return findByColumn(entity);
    }

    @Override
    public List<Function> insert(List<Function> entity, String sqlId) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<Function> insert(Function entity, String sqlId) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<Function> update(Function searchCriteria, Function entity, String sqlId) {
        // TODO Auto-generated method stub
        return null;
    }
	
    public List<Function> findByUserGroup(@Param("userGroupCodes") List<String> userGroupCodes) {
        return getSqlSession().selectList("function.findByUserGroup", userGroupCodes);
    }


	public List<Function> getAvailableFunction(String userCd){
		return getSqlSession().selectList("function.getAvailableFunctions", userCd);
	}
	
}
