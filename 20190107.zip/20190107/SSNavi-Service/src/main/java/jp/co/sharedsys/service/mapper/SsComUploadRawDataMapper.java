package jp.co.sharedsys.service.mapper;

import java.util.List;
import java.util.Map;
import jp.co.sharedsys.service.model.SsComUploadRawData;
import org.springframework.stereotype.Component;

/**
 *
 * @author sharedsys
 */
@Component("SS_COM_UPLOAD_ROW_DATA")
public interface SsComUploadRawDataMapper extends IMapper {
    
    List<SsComUploadRawData> findAll();

    List<Map> findAllForSelector();
    
    SsComUploadRawData findById(int id);
    
    List<SsComUploadRawData> findByColumn(SsComUploadRawData entity);
    
    List<SsComUploadRawData> findLineInfo(SsComUploadRawData entity);

}
