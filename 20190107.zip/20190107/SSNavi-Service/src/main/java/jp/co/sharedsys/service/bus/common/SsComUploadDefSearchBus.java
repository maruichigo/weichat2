package jp.co.sharedsys.service.bus.common;

import java.util.List;
import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.HashMap;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.service.bus.SSFrameBusBase;
import jp.co.sharedsys.service.mapper.MsUpFileDefMapper;
import jp.co.sharedsys.service.mapper.SsComMaintColumnMapper;
import jp.co.sharedsys.service.mapper.SsComUploadDefMapper;
import jp.co.sharedsys.service.model.SsComMaintColumn;
import jp.co.sharedsys.service.model.MsUpFileDef;

/** 
 * 共通メンテナンス用データ取得
 */
@Component("SS_COM_UPLOAD_SEARCH")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class SsComUploadDefSearchBus extends SSFrameBusBase {
    
//    @Autowired
//    private SsComUploadDefMapper uploadMapper;// 旧テーブル
    @Autowired
    private MsUpFileDefMapper upFileMapper;// 新(本番用)テーブル
    @Autowired
    private SsComMaintColumnMapper columnMapper;

    private Map<String, Object> params = null;
    
    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        super.init(serviceInterfaceBean);
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
    }

    @Override
    public String validateHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }
	
    @Override
    public String validateDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public String validateHeaderByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public String validateDetailByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    /** 
     * 検索
     * @param serviceInterfaceBean リクエストパラメータ
     * @throws Exception
     */
    @Override
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        List<Map<String, String>> result = null;
        if (params != null && params.get("0").equals("COM_UPLOAD_DATA")) {
//            List<Map> resultList = uploadMapper.findAllForSelector();// 旧テーブル
            List<Map> resultList = upFileMapper.findAllForSelector();// 新(本番用)テーブル
            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
        } else if (params != null && (params.get("0").equals("COM_MAINT_COLUMN"))) {
            SsComMaintColumn crt = new SsComMaintColumn();
            crt.setTableName((String)params.get("1"));
            List<SsComMaintColumn> resultList = columnMapper.findByColumn(crt);

            Map<String, String> param = new HashMap<>();
            param.put("tableName", (String)params.get("1"));
            List<Map> primarys = columnMapper.findPrimaryKeyName(param);
            if (primarys != null && !primarys.isEmpty()) {
                for (Map p : primarys) {
                    for (SsComMaintColumn column : resultList) {
                        if (column.getColumnName().equals((String)p.get("COUMN_NAME"))) {
                            column.setPk("1");
                            break;
                        }
                    }
                }
            }
            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
        } else if (params != null && params.get("0").equals("COM_UPLOAD_DEF")) {
            MsUpFileDef upFileDef = new MsUpFileDef();
//            upFileDef.setUploadKinoCd((String) params.get("1")); // 仮設定
            upFileDef.setDataFileMei((String) params.get("1"));
            List<MsUpFileDef> resultList = upFileMapper.findByColumn(upFileDef);
            
            // TODO　システムマスタからアップロード可能ファイルサイズ取得
            
            
            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
        }
        
        if (result != null) {
            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
	}
        serviceInterfaceBean.setMessage("共通アップロードデータ検索に成功しました");
    }

    @Override
    public void saveDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }
    
    @Override
    public void setValidaterFactory() throws Exception {
    }

    @Override
    public void confirm(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }
        
    @Override
    public String finalProc(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }         
}
