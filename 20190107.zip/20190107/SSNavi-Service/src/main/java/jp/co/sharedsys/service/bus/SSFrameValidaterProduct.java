package jp.co.sharedsys.service.bus;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;


/** データチェック処理実装クラス
 * @author sharedsys
 *
 */
public abstract class SSFrameValidaterProduct {

    /**　処理区分
     *  INSERT:追加
     *  UPDATE:更新
     *  DELETE：削除
     *  CONFIRM:確定
     */
    public enum PROCESS_TYPE{INSERT,UPDATE,DELETE,CONFIRM} 

    /**　ヘッダーデータチェック処理
     * @param checkedData チェック対象データ
     * @param processType 処理区分
     * @return　チェック結果
     */
    public abstract <T>  String validateHeader(T checkedData, PROCESS_TYPE processType);

    /**　明細データチェック処理
     * @param checkedData チェック対象データ
     * @param processType 処理区分
     * @return　チェック結果
     */
    public abstract  <T> String validateDetail(T checkedData, PROCESS_TYPE processType);

    /**
     * 　アノテーションによるチェック処理の実行
     * 
     * @param entity
     *            チェック対象のモデル
     * @return エラー内容
     */
    protected <T> String validateByAnnotation(T entity) {
            return validateByAnnotation(entity,null);
    }
	
    /** アノテーションによるチェック処理（Default以外のチェック処理）
     * @param entity チェック対象モデル
     * @param validatioTypeClass チェック処理のタイプ
     * @return エラー内容
     */
    protected <T> String validateByAnnotation(T entity, Class<?> validatorTypeClass) {
        StringBuffer msgBuf = new StringBuffer();

        ValidatorFactory vf = Validation.buildDefaultValidatorFactory();
        Validator v = vf.getValidator();
        Set<ConstraintViolation<T>> violations = null;
        if(validatorTypeClass == null){
            violations = v.validate(entity);
        } else {
            violations = v.validate(entity,validatorTypeClass);
        }
        for (ConstraintViolation<T> cv : violations) {
            // validationで出力されたメッセージを取得しappendする
            msgBuf.append(cv.getMessage());
        }
        return msgBuf.toString();
    }
}
