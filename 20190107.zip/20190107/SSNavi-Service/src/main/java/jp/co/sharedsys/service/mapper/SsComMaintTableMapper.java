package jp.co.sharedsys.service.mapper;

import java.util.List;
import java.util.Map;
import jp.co.sharedsys.service.model.SsComMaintTable;
import org.springframework.stereotype.Component;

/**
 *
 * @author sharedsys
 */
@Component("ss_com_maint_table_def")
public interface SsComMaintTableMapper extends IMapper {
    
    List<SsComMaintTable> findAll();

    List<Map> findAllForSelector();
    
    SsComMaintTable findById(int id);
    
    List<SsComMaintTable> findByColumn(SsComMaintTable entity);
}
