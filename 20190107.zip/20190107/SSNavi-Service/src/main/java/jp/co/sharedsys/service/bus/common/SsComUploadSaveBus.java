package jp.co.sharedsys.service.bus.common;

import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.Iterator;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.exception.SystemException;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.common.methods.SSCommonUtil;
import jp.co.sharedsys.service.bus.SSFrameBusBase;
import jp.co.sharedsys.service.mapper.IMapper;
import jp.co.sharedsys.service.mapper.MsUpFileDefMapper;
import jp.co.sharedsys.service.mapper.SsComUploadCheckResultMapper;
import jp.co.sharedsys.service.mapper.SsComUploadDefMapper;
import jp.co.sharedsys.service.mapper.SsComUploadRawDataMapper;
import jp.co.sharedsys.service.mapper.WkUploadMapper;
import jp.co.sharedsys.service.model.MsUpFileDef;
import jp.co.sharedsys.service.model.SsComUploadDef;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 共通アップロード　登録処理
 */
@Component("SS_COM_UPLOAD_SAVE")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class SsComUploadSaveBus extends SSFrameBusBase {

    protected final String TABLE_NAME = "TABLE_NAME";
    protected final String SELECT_FILETYPE = "selectMaster";
    
//    @Autowired
//    private SsComUploadDefMapper uploadMapper;
    @Autowired
    private MsUpFileDefMapper upFileMapper; // 新(本番)テーブル用
    @Autowired
    private SsComUploadRawDataMapper uploadRawDataMapper;
    @Autowired
    private SsComUploadCheckResultMapper uploadCheckResultMapper;
    @Autowired
    private WkUploadMapper tmpUploadMapper;
    
    
    private IMapper mapForTarget(String target) {
        IMapper mapper = (IMapper) this.getWebApplicationContext().getBean(target);
        if (mapper != null) {
            return mapper;
        }
        throw new UnsupportedOperationException("unsupported table");
    }
    private IMapper targetMapper;

    private Map<String, Object> params = null;
    private List<Map<String, Object>> inputParams = null;
//    private SsComUploadDef targetDef = null;
    private MsUpFileDef targetDef = null;

    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        super.init(serviceInterfaceBean);
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
        for (Iterator<String> ite = params.keySet().iterator(); ite.hasNext();) {
            String key = ite.next();
            if (TABLE_NAME.equals(key)) {
//                targetMapper = this.mapForTarget((String) params.get(key));
                targetMapper = tmpUploadMapper;
            } else {
                inputParams = (List) params.get(key);
            }
        }
    }

    @Override
    public String validateHeaderByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public String validateDetailByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }
    
    @Override
    public String validateHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        // dataspiderへ渡す前にデータチェックする場合はここで行う
        return "";
    }

    @Override
    public String validateDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    
    @Override
    /**
     * 検索
     *
     * @param serviceInterfaceBean リクエストパラメータ
     * @throws Exception
     */
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        
        System.out.println("SsComUploadSaveBus.java Done！！");
        
        // TODO 本登録用DataSpiderScriptの取得
//        SsComUploadDef crt = new SsComUploadDef();
//        crt.setFileName((String)params.get(SELECT_FILETYPE));
//        List<SsComUploadDef> def =  uploadMapper.findByColumn(crt);
//        targetDef = def.get(0);
//        String dsProdSave = targetDef.getDsProdSave();

        MsUpFileDef upFile = new MsUpFileDef();
//        upFile.setUploadKinoCd((String)params.get(SELECT_FILETYPE));// とりあえず、fileName→UploadKinoCdに置換(仮)
        upFile.setDataFileMei((String)params.get(SELECT_FILETYPE));// とりあえず、fileName→UploadKinoCdに置換(仮)
        List<MsUpFileDef> def = upFileMapper.findByColumn(upFile);
//        targetDef = def.get(0);// Listの一番目(0番目)を取得している
        targetDef = def.get(0);// Listの一番目(0番目)を取得している
        
        String dsMainSave = targetDef.getHontorokuyoDsScriptUrl();
        //TODO DataSpider側で行う処理
        //取得した本登録用DataSpiderScriptをキックする
        //取込一覧データ（inputParam）、アップロード方法（更新・スキップ）もDataSpider側に渡す
        //一覧の情報をもとにデータベースの登録を行う。																			
        //一覧内容のエラーチェックをし、その後に登録処理が行われる。																			
        //登録処理成功時はアップロードファイルを完了済フォルダに移動する。																		
        //一定期間を過ぎた登録済フォルダに移動していないファイルは削除対象として削除する。																	
        //登録完了後、ユーザのワークテーブルデータを過去分を含めて削除する。																			
    
        // 仮で選択済のデータのread_idを変更する

        List<Map> result = null;
        for (Map input : inputParams) {
//            input.put("userId", serviceInterfaceBean.getUserId());
//            if (input.get("newrow") != null && Boolean.valueOf((String) input.get("newrow"))) {
//                targetMapper.insert(input);
//            } else {
//                List<Map> check = targetMapper.findById(input);
//                boolean isUpdate = false;
//                if (check != null && !check.isEmpty()) {
//                    for (Iterator<String> ite = check.get(0).keySet().iterator(); ite.hasNext();) {
//                        String key = ite.next();
//                        String camelizedKey = SSCommonUtil.camelize(key);
//                        if (input.get(camelizedKey) == null) {
//                            continue;
//                        }
//                        if (!String.valueOf(input.get(camelizedKey)).equals(String.valueOf(check.get(0).get(key)))) {
//                            // DBの値と違うものがあれば更新対象とする
//                            isUpdate = true;
//                            break;
//                        }
//                    }
//                    if (isUpdate) {
//                        targetMapper.update(input);
//                    }
//                } else {
//                    //throw new SystemException("更新対象のキーが存在しませんでした。");
//                    //新規登録処理
//                    targetMapper.insert(input);
//                }
//            }
            // 仮実行用
//            targetMapper.update(input);
            System.out.println("********** sql insert done ********");
        }
        
        // TODO 登録結果をDataSpider側から取得
//        List<Map> result = new ArrayList<>();
//        result = targetMapper.findToMap(params); // 仮設定
//        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        // 登録結果メッセージ
        serviceInterfaceBean.setMessage("共通アップロード　データの登録・更新に成功しました");
        
    }

    @Override
    public void saveDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {

    }

    @Override
    public void setValidaterFactory() throws Exception {

    }

    @Override
    public void confirm(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        
    }
    
    @Override
    public String finalProc(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }
}
