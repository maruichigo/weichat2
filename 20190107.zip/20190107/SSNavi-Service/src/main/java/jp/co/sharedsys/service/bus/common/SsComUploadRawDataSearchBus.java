package jp.co.sharedsys.service.bus.common;

import java.util.List;
import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.service.bus.SSFrameBusBase;
import jp.co.sharedsys.service.mapper.IMapper;
import jp.co.sharedsys.service.mapper.MsUpFileDefMapper;
import jp.co.sharedsys.service.mapper.SsComUploadDefMapper;
import jp.co.sharedsys.service.mapper.SsComUploadRawDataMapper;
import jp.co.sharedsys.service.mapper.TrUpFrmDatMapper;
import jp.co.sharedsys.service.mapper.MsUpFileDefMapper;
import jp.co.sharedsys.service.model.SsComUploadDef;
import jp.co.sharedsys.service.model.SsComUploadRawData;
import jp.co.sharedsys.service.model.TrUpFrmDat;
import org.apache.commons.lang.StringUtils;

/** 
 * 共通アップロード一時保存データ取得
 */
@Component("SS_COM_UPLOAD_SHOW_ORG")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class SsComUploadRawDataSearchBus extends SSFrameBusBase {
    protected final String SELECT_FILETYPE = "selectMaster";
    
    @Autowired
//    private SsComUploadDefMapper uploadMapper; // 旧テーブル用
    private MsUpFileDefMapper upFileMapper; // 新テーブル用
    @Autowired
//    private SsComUploadRawDataMapper uploadRawDataMapper; // 旧テーブル用
    private TrUpFrmDatMapper upFromDataMapper; // 新テーブル用

    private IMapper mapForTarget(String target) {
        IMapper mapper =(IMapper)this.getWebApplicationContext().getBean(target);
        if (mapper != null) {
            return mapper;
        }
        throw new UnsupportedOperationException("unsupported table");
    }
    
    private IMapper targetMapper;
    
    private Map<String, Object> params = null;
    
    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        super.init(serviceInterfaceBean);
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
    }

    @Override
    public String validateHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }
	
    @Override
    public String validateDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public String validateHeaderByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public String validateDetailByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    /** 
     * 検索
     * @param serviceInterfaceBean リクエストパラメータ
     * @throws Exception
     */
    @Override
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {

//        SsComUploadDef crt = new SsComUploadDef();
//        crt.setFileName((String) params.get(SELECT_FILETYPE));
//        List<SsComUploadDef> def = uploadMapper.findByColumn(crt);
//
//        SsComUploadRawData rawCrt = new SsComUploadRawData();
//        rawCrt.setYomikomiId(Long.parseLong(String.valueOf(params.get("yomikomiId"))));
//        rawCrt.setLineNo(Integer.parseInt(String.valueOf(params.get("lineNo"))));
//        rawCrt.setUploadDefId(def.get(0).getId());
//        rawCrt.setUserId(userId);
//        List<SsComUploadRawData> result = uploadRawDataMapper.findByColumn(rawCrt);
//
//        if (result != null && !result.isEmpty()) {
//            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result.get(0)));
//        }
        
//        MsUpFileDef upFile = new MsUpFileDef();
//        upFile.setUploadKinoCd((String) params.get(SELECT_FILETYPE));
//        List<MsUpFileDef> def = upFileMapper.findByColumn(upFile);
        
        TrUpFrmDat upFrmData = new TrUpFrmDat();
        upFrmData.setYomikomiId(Long.parseLong(String.valueOf(params.get("yomikomiId")))); // return null?
        upFrmData.setGyoBango(Integer.parseInt(String.valueOf(params.get("lineNo"))));
        List<TrUpFrmDat> result = upFromDataMapper.findByColumn(upFrmData);

        if (result != null && !result.isEmpty()) {
            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result.get(0)));
        }
        serviceInterfaceBean.setMessage("共通アップロード 元データ検索に成功しました");
    }

    @Override
    public void saveDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }

    @Override
    public void setValidaterFactory() throws Exception {
    }

    @Override
    public void confirm(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }
        
    @Override
    public String finalProc(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }        
}
