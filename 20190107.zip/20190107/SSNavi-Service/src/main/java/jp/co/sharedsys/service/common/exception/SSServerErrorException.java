package jp.co.sharedsys.service.common.exception;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.exception.SSException;

/**
 * サービス実行中にExceptionが発生した場合にスローされるExceptionクラスです。<br>
 * このExceptionが発生した場合、ExceptionMapperにハンドリングされ、
 * Error用のレスポンスが返却されます
 * @author saihara
 *
 */
public class SSServerErrorException  extends SSException {

    /**
     * 
     */
    private static final long serialVersionUID = 3814126070267891468L;

    private ServiceInterfaceBean serviceInterfaceBean = null;

    public SSServerErrorException(String message){
            super(message);
    }
    public SSServerErrorException(String message, Throwable cause, ServiceInterfaceBean bean){
            super(message,cause);
            serviceInterfaceBean = bean;
    }

    public ServiceInterfaceBean getServiceInterfaceBean() {
            return serviceInterfaceBean;
    }
    public void setServiceInterfaceBean(ServiceInterfaceBean serviceInterfaceBean) {
            this.serviceInterfaceBean = serviceInterfaceBean;
    }
}
