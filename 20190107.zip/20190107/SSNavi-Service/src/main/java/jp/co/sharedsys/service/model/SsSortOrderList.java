package jp.co.sharedsys.service.model;

import java.io.Serializable;
import lombok.Data;

/**
 *
 * @author shared
 */
@Data
public class SsSortOrderList extends BaseModel implements Serializable {
    private static final long serialVersionUID = 8225066323266434396L;
    private String functionCode;
    private String tableName;
    private String sortId;
    private String sortName;
    private String sortValue;
}
