package jp.co.sharedsys.service.model;

import java.io.Serializable;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import jp.co.sharedsys.service.constraintannotation.PrimaryKey;
import lombok.Data;

/** 
 * 共通アップロードチェック(件数表示用)結果
 * @author sharedsys
 */
@Data
public class TrJokyoKanri extends BaseModel implements Serializable {

	private static final long serialVersionUID = 8225066323266434396L;

	@NotNull
	@Digits(integer = 10, fraction = 0)
	@Min(0)
//    @PrimaryKey(columnName = "ID")
        @PrimaryKey(columnName = "EDI_SETTEI_ID")
//	private Long id;

    private String ediSetteiId;
    private String jikkoKaisiNichiji;
    private Long shoriSeq;
    private String shoriTaishoMeisho;
    private String shoriJikkoKekka;
    private Long shoriRecordKensu;
    private Long okKensu;
    private Long youshuseiKensu;
    private Long ngKensu;
    private Long skipKensu;
    private String jikkoShuryoNichiji;

}
