package jp.co.sharedsys.ssframe.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jp.co.sharedsys.ssframe.model.SystemMaster;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/** システムテーブル処理クラス
 * @author K.Akeda
 *
 */
@Repository
public class SystemDao extends BaseDao<SystemMaster> {

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    public SystemMaster create(SystemMaster system) {
        getSqlSession().insert("system.create", system);
        return system;
    }

    public SystemMaster update(SystemMaster system) {
        getSqlSession().update("system.update", system);
        return system;
    }

    public SystemMaster softDelete(SystemMaster system) {
        getSqlSession().update("system.softDelete", system);
        return system;
    }

    public void delete(String id) {
        getSqlSession().delete("system.delete", id);
    }

    public List<SystemMaster> findAll() {
        return getSqlSession().selectList("system.findAll");
    }

    public SystemMaster findById(SystemMaster system) {
        return (SystemMaster) getSqlSession().selectOne("system.findById", system);
    }

    public List<SystemMaster> findByColumn(SystemMaster entity) {
        return getSqlSession().selectList("system.findByColumn", entity);
    }

    public List<SystemMaster> find(SystemMaster entity, String sqlId) {
        return getSqlSession().selectList(sqlId, entity);
    }

    @Override
    public List<SystemMaster> updateByColumn(SystemMaster searchCriteria, SystemMaster entity) {
        Map<String ,Object> map = new HashMap<>();
        map.put("crt", searchCriteria);
        map.put("upd", entity);
        getSqlSession().update("system.updateByColumn",map);
        return findByColumn(entity);
    }

    @Override
    public void deleteByColumn(SystemMaster entity) {
        getSqlSession().delete("system.deleteByColumn", entity);
    }

    @Override
    public List<SystemMaster> softDeleteByColumn(SystemMaster entity) {
        getSqlSession().update("system.softDeleteByColumn",entity);
        return null;
    }

    @Override
    public List<SystemMaster> insert(List<SystemMaster> entity, String sqlId) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<SystemMaster> insert(SystemMaster entity, String sqlId) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<SystemMaster> update(SystemMaster searchCriteria, SystemMaster entity, String sqlId) {
        // TODO Auto-generated method stub
        return null;
    }
}
