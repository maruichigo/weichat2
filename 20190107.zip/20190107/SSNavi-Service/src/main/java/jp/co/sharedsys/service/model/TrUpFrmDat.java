package jp.co.sharedsys.service.model;

import java.io.Serializable;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import jp.co.sharedsys.service.constraintannotation.PrimaryKey;
import lombok.Data;

/**
 * 共通アップロード元データ用定義
 *
 * @author sharedsys
 */
@Data
public class TrUpFrmDat extends BaseModel implements Serializable {

    private static final long serialVersionUID = 8225066323266434396L;

//    @NotNull
//    @Digits(integer = 10, fraction = 0)
//    @Min(0)
//    @PrimaryKey(columnName = "yomikomiId")

    private Long yomikomiId;
    private Integer gyoBango;
    private String gyoNaiyo;
    private String torokushaCd;
    private String torokuNichiji;
    
    // 仮設定
//    private String masterRecordUmu;
//    private String masterSakujoFlg;
    private String jotaiKubun;
    private String torokuKubun;
}
