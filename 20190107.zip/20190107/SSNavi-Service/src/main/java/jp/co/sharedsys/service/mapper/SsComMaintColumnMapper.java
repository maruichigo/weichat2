package jp.co.sharedsys.service.mapper;

import java.util.List;
import java.util.Map;
import jp.co.sharedsys.service.model.SsComMaintColumn;
import org.springframework.stereotype.Component;

/**
 *
 * @author sharedsys
 */
@Component("ss_com_maint_column_def")
public interface SsComMaintColumnMapper extends IMapper {

    List<SsComMaintColumn> findAll();
    
    SsComMaintColumn findById(int id);
    
    List<SsComMaintColumn> findByColumn(SsComMaintColumn entity);
    
    List<Map> findPrimaryKeyName(Map params);
}
