package jp.co.sharedsys.service.model;

import java.io.Serializable;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import jp.co.sharedsys.service.constraintannotation.PrimaryKey;
import lombok.Data;

/** 
 * 共通アップロード用データ定義
 * @author sharedsys
 */
@Data
public class SsComUploadRawData extends BaseModel implements Serializable {

    private static final long serialVersionUID = 8225066323266434396L;

    @NotNull
    @Digits(integer = 10, fraction = 0)
    @Min(0)
    @PrimaryKey(columnName = "ID")
    private Long id;

    private Long yomikomiId;
    private Long uploadDefId;
    private String uploadFileName;
    private String userId;
    private Integer lineNo;
    private String data;
}
