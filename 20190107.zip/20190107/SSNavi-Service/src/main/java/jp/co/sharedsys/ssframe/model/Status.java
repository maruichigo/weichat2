/**
 *
 */
package jp.co.sharedsys.ssframe.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/** ステータスクラス
 * @author K.Akeda
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "status")
public class Status implements Serializable{

    /**
     *
     */
    private static final long serialVersionUID = 6661413556470914706L;

    private String statusType;
    private String statusCode;
    private String description;
    private Long workFlowNo;
    private String remarks;

    /** ステータスタイプの取得
     * @return ステータスタイプ
     */
    @XmlElement(name = "statusType")
    public String getStatusType() {
        return statusType;
    }
    /** ステータスタイプの設定
     * @param statusType ステータスタイプ
     */
    public void setStatusType(String statusType) {
        this.statusType = statusType;
    }
    /** ステータスコードの取得
     * @return ステータスコード
     */
    @XmlElement(name = "statusCode")
    public String getStatusCode() {
        return statusCode;
    }
    /** ステータスコードの設定
     * @param statusCode ステータスコード
     */
    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }


    /** 作業フロー番号の取得
     * @return 作業フロー番号
     */
    @XmlElement(name = "workFlowNo")
    public Long getWorkFlowNo() {
        return workFlowNo;
    }
    /** 作業フロー番号の設定
     * @param workFlowNo  作業フロー番号
     */
    public void setWorkFlowNo(Long workFlowNo) {
        this.workFlowNo = workFlowNo;
    }
    /** 説明内容の取得
     * @return 説明内容
     */
    @XmlElement(name = "description")
    public String getDescription() {
        return description;
    }
    /** 説明内容の設定
     * @param description 説明内容
     */
    public void setDescription(String description) {
        this.description = description;
    }
    /** 備考の取得
     * @return 備考
     */
    @XmlElement(name = "remarks")
    public String getRemarks() {
        return remarks;
    }
    /** 備考の設定
     * @param remarks 備考
     */
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}
