package jp.co.kintetsuls.dao;

import java.util.*;
import jp.co.kintetsuls.service.model.MsSystem;
import jp.co.sharedsys.ssframe.dao.BaseDao;
import org.springframework.stereotype.Component;

@Component
public class MsSystemDao extends BaseDao<MsSystem> {

    @Override
    public MsSystem create(MsSystem msSystem) {
        getSqlSession().insert("msSystem.insert", msSystem);
        return null;
    }

    @Override
    public MsSystem findById(MsSystem msSystem) {
        return (MsSystem) getSqlSession().selectOne("msSystem.findById", msSystem);
    }

    @Override
    public List<MsSystem> findByColumn(MsSystem msSystem) {
        return getSqlSession().selectList("msSystem.findByColumn", msSystem);
    }

    @Override
    public List<MsSystem> find(MsSystem msSystem, String sqlId) {
        return getSqlSession().selectList("msSystem.find" + sqlId , msSystem);
    }

    @Override
    public MsSystem update(MsSystem msSystem) {
        return null;
    }

    @Override
    public List<MsSystem> updateByColumn(MsSystem crt, MsSystem upd) {
        Map<String ,Object> map = new HashMap<>();
        map.put("crt", crt);
        map.put("upd", upd);
        getSqlSession().update("msSystem.updateByColumn",map);
        return null;
    }

    @Override
    public List<MsSystem> update(MsSystem crt, MsSystem upd, String sqlId) {
        Map<String ,Object> map = new HashMap<>();
        map.put("crt", crt);
        map.put("upd", upd);
        getSqlSession().update("msSystem.update" + sqlId, map);
        return null;
    }

    @Override
    public List<MsSystem> insert(List<MsSystem> msSystem, String sqlId) {
        getSqlSession().insert("msSystem.insert" + sqlId, msSystem);
        return null;
    }

    @Override
    public List<MsSystem> insert(MsSystem msSystem, String sqlId) {
        getSqlSession().insert("msSystem.insert" + sqlId, msSystem);
        return null;
    }

    @Override
    public void delete(String id) {
    }

    @Override
    public void deleteByColumn(MsSystem msSystem) {
        getSqlSession().delete("msSystem.deleteByColumn", msSystem);
    }

    @Override
    public MsSystem softDelete(MsSystem msSystem) {
        getSqlSession().update("msSystem.softDelete", msSystem);
        return null;
    }

    @Override
    public List<MsSystem> softDeleteByColumn(MsSystem msSystem) {
        getSqlSession().update("msSystem.softDeleteByColumn",msSystem);
        return null;
    }

    @Override
    public List<MsSystem> findAll() {
        return getSqlSession().selectList("msSystem.findAll");
    }

}
