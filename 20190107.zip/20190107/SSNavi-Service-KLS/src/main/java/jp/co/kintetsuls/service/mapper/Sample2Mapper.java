package jp.co.kintetsuls.service.mapper;

import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.service.model.Sample2Def;
import jp.co.sharedsys.service.mapper.IMapper;
import org.springframework.stereotype.Component;
/**
 * Mybatis Sample Mapper
 * @author sharedsys
 */
@Component("sample2")
public interface Sample2Mapper extends IMapper {
    public List<Map> searchForList(Map<String, Object> parameter);
    public int softDeleteList(List<Sample2Def> itemList);
}
