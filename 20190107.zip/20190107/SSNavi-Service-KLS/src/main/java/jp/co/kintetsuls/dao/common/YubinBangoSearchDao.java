package jp.co.kintetsuls.dao.common;

import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.service.model.common.YubinBangoSearchDef;

import jp.co.sharedsys.ssframe.dao.BaseDao;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * 郵便番号検索処理クラス
 *
 * @author
 *
 */
@Repository
public class YubinBangoSearchDao extends BaseDao<YubinBangoSearchDef>
{

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    public YubinBangoSearchDef create(YubinBangoSearchDef entity)
    {
        return entity;
    }

    public YubinBangoSearchDef update(YubinBangoSearchDef entity)
    {
        return entity;
    }

    public YubinBangoSearchDef softDelete(YubinBangoSearchDef entity)
    {
        return entity;
    }

    public void delete(String id)
    {
    }

    public List<YubinBangoSearchDef> findAll()
    {
        return null;
    }

    public YubinBangoSearchDef findById(YubinBangoSearchDef entity)
    {
        return null;
    }

    public List<YubinBangoSearchDef> findByColumn(YubinBangoSearchDef entity)
    {
        return null;
    }

    public List<YubinBangoSearchDef> find(YubinBangoSearchDef entity, String sqlId)
    {
        return null;
    }

    public List<YubinBangoSearchDef> updateByColumn(YubinBangoSearchDef searchCriteria, YubinBangoSearchDef entity)
    {
        return null;
    }

    public void deleteByColumn(YubinBangoSearchDef entity)
    {
    }

    public List<YubinBangoSearchDef> softDeleteByColumn(YubinBangoSearchDef entity)
    {
        return null;
    }

    public List<YubinBangoSearchDef> insert(List<YubinBangoSearchDef> entity, String sqlId)
    {
        return null;
    }

    public List<YubinBangoSearchDef> insert(YubinBangoSearchDef entity, String sqlId)
    {
        return null;
    }

    public List<YubinBangoSearchDef> update(YubinBangoSearchDef searchCriteria, YubinBangoSearchDef entity, String sqlId)
    {
        return null;
    }

    public List<Map<String, String>> findForSearch(Map<String, Object> searchCriteria, String sqlId)
    {
        return null;
    }

    public List<Map<String, String>> findForSearch(Map<String, Object> searchCriteria)
    {
        return null;
    }

    public List<YubinBangoSearchDef> findYubinBango(YubinBangoSearchDef entity)
    {
        return getSqlSession().selectList("yubinBangoSearch.findYubinBango", entity);
    }
}
