/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.service.bus.common;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import jp.co.kintetsuls.dao.common.ComSearchDao;
import jp.co.kintetsuls.service.model.common.ComSearchDef;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.ssframe.dao.Dao;
import jp.co.sharedsys.service.bus.SSFrameBusBase;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

@Component("COM_SEARCH")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ComSearch extends SSFrameBusBase {

    @Autowired(required=true)
    @Resource(shareable=true)
    protected Dao<ComSearchDef> dao;
    
    private Map<String, Object> params = null;
    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        super.init(serviceInterfaceBean);
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);        
        
    }
    
    @Override
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        List<Map<String, String>> resultList = ((ComSearchDao) dao).findForSearch(params, serviceInterfaceBean.getTableName());
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));       
    }    

    @Override
    public String validateHeaderByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public String validateDetailByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public void setValidaterFactory() throws Exception {
    }

    @Override
    public String validateHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public String validateDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public void saveDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }

    @Override
    public void confirm(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }

    @Override
    public String finalProc(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }
}
