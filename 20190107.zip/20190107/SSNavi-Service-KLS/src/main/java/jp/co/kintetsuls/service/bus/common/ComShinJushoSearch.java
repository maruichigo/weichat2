/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.service.bus.common;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import jp.co.kintetsuls.dao.common.ShinJushoSearchDao;
import jp.co.kintetsuls.exception.LogicException;
import jp.co.kintetsuls.service.model.common.ShinJushoSearchDef;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.ssframe.dao.Dao;
import jp.co.sharedsys.service.bus.SSFrameBusBase;
import jp.co.sharedsys.ssframe.common.SSFrameMessage;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import javax.faces.context.FacesContext;
import javax.faces.application.FacesMessage;

@Component("COM_SHIN_JUSHO_SEARCH")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ComShinJushoSearch extends SSFrameBusBase
{
    // 住所文字数超過エラーメッセージ
    final String ERROR_MESSAGE_ADDRESS_LIMIT_OVER = "住所が20文字を超えました。%s";
    
    @Autowired(required = true)
    @Resource(shareable = true)
    protected Dao<ShinJushoSearchDef> dao;

    private ShinJushoSearchDef shinJushoPrm;

    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception
    {
        super.init(serviceInterfaceBean);

        ObjectMapper mapper = new ObjectMapper();

        shinJushoPrm = mapper.readValue(serviceInterfaceBean.getJson(), ShinJushoSearchDef.class);

    }

    @Override
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception, LogicException
    {
        List<ShinJushoSearchDef> resultList = new ArrayList<>();
        
        // パラメータが設定されていた場合
//        if (shinJushoPrm != null && shinJushoPrm.getShinJusho() != null && !"".equals(shinJushoPrm.getShinJusho())) {
            // 新住所情報を取得
            List<ShinJushoSearchDef> rl = ((ShinJushoSearchDao) dao).findShinJusho(shinJushoPrm);

            System.out.println(rl.size() + "件");
            
            System.out.println("取得 [" + JSONUtil.makeJSONString(rl) + "]");

            // 取得件数が1件の場合、リストに設定
            if (rl.size() == 1) {
                resultList = rl;
            }
            
            // 住所文字数チェック
            ShinJushoSearchDef tmpdef = rl.get(0);

            // 住所文字列退避で使用していた住所4に設定されている場合、エラー＆住所4をクリア
            if (tmpdef.getJusho4() != null){
                tmpdef.setJusho4("");
                rl.set(0, tmpdef);
                resultList = rl;
    //            throw new LogicException(String.format(ERROR_MESSAGE_ADDRESS_LIMIT_OVER, tmpdef.getJusho4()));
                serviceInterfaceBean.setMessage(String.format(ERROR_MESSAGE_ADDRESS_LIMIT_OVER, tmpdef.getJusho4()));
                serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
//                FacesContext.getCurrentInstance().addMessage("messages", new FacesMessage(FacesMessage.SEVERITY_WARN, "注意", String.format(ERROR_MESSAGE_ADDRESS_LIMIT_OVER, tmpdef.getJusho4())));
            }
            System.out.println("返却 [" + JSONUtil.makeJSONString(resultList) + "]");
//        }else{
//            resultList.add(shinJushoPrm);
//            System.out.println("返却 [" + JSONUtil.makeJSONString(resultList) + "]");
//        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
    }

    @Override
    public String validateHeaderByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception
    {
        return "";
    }

    @Override
    public String validateDetailByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception
    {
        return "";
    }

    @Override
    public void setValidaterFactory() throws Exception
    {
    }

    @Override
    public String validateHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception
    {
        return "";
    }

    @Override
    public String validateDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception
    {
        return "";
    }

    @Override
    public void saveDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception
    {
    }

    @Override
    public void confirm(ServiceInterfaceBean serviceInterfaceBean) throws Exception
    {
    }

    @Override
    public String finalProc(ServiceInterfaceBean serviceInterfaceBean) throws Exception
    {
        return "";
    }
}
