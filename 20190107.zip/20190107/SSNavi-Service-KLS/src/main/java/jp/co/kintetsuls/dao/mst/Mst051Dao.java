/**
 *
 */
package jp.co.kintetsuls.dao.mst;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.service.model.mst.Mst051Def;
import jp.co.sharedsys.ssframe.dao.BaseDao;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class Mst051Dao extends BaseDao<Mst051Def> {

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    public Mst051Def create(Mst051Def entity) {
        return null;
    }

    public Mst051Def update(Mst051Def entity) {
        return null;
    }

    public Mst051Def softDelete(Mst051Def entity) {
        return null;
    }

    public void delete(String id) {
    }

    public List<Mst051Def> findAll() {
        return getSqlSession().selectList("mst051.findAll");
    }

    public Mst051Def findById(Mst051Def entity) {
        return getSqlSession().selectOne("mst051.findById", entity);
    }

    public List<Mst051Def> findByColumn(Mst051Def entity) {
        return getSqlSession().selectList("mst051.findByColumn", entity);
    }

    public List<Mst051Def> find(Mst051Def entity, String sqlId) {
        return getSqlSession().selectList("mst051.find", entity);
    }

    @Override
    public List<Mst051Def> updateByColumn(Mst051Def searchCriteria, Mst051Def entity) {
        return null;
    }

    @Override
    public void deleteByColumn(Mst051Def entity) {
    }

    @Override
    public List<Mst051Def> softDeleteByColumn(Mst051Def entity) {
        return null;
    }

    @Override
    public List<Mst051Def> insert(List<Mst051Def> entity, String sqlId) {
        return null;
    }

    @Override
    public List<Mst051Def> insert(Mst051Def entity, String sqlId) {
        return null;
    }

    @Override
    public List<Mst051Def> update(Mst051Def searchCriteria, Mst051Def entity, String sqlId) {
        return null;
    }

    public List<Map<String, String>> findForSearch(Map<String, Object> searchCriteria, String sqlId) {
        return getSqlSession().selectList("mst051." + sqlId, searchCriteria);
    }

    public List<Map<String, String>> findForSearch(Map<String, Object> searchCriteria) {
        return getSqlSession().selectList("mst051.findToMap", searchCriteria);
    }

    //新規追加
    public Mst051Def updateForList(Mst051Def entity) {
        return null;
    }

    //新規追加
    public Mst051Def softDeleteForList(Mst051Def entity) {
        return null;
    }

    /**
     *
     * @return
     */
    @Override
    public String tableName() {
        return "mst051";
    }
}
