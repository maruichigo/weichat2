package jp.co.kintetsuls.dao.common;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jp.co.sharedsys.ssframe.dao.BaseDao;

import jp.co.kintetsuls.service.model.common.ComSearchDef;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/** 共通検索処理クラス
 * @author 
 *
 */
@Repository
public class ComSearchDao extends BaseDao<ComSearchDef> {

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    public ComSearchDef create(ComSearchDef entity) {
        return entity;
    }

    public ComSearchDef update(ComSearchDef entity) {
        return entity;
    }

    public ComSearchDef softDelete(ComSearchDef entity) {
        return entity;
    }

    public void delete(String id) {
    }

    public List<ComSearchDef> findAll() {
        return null;
    }

    @Override
    public ComSearchDef findById(ComSearchDef entity) {
        return null;
    }

    @Override
    public List<ComSearchDef> findByColumn(ComSearchDef entity) {
        return null;
    }

    @Override
    public List<ComSearchDef> find(ComSearchDef entity, String sqlId) {
        return null;
    }

    @Override
    public List<ComSearchDef> updateByColumn(ComSearchDef searchCriteria, ComSearchDef entity) {
        return null;
    }

    @Override
    public void deleteByColumn(ComSearchDef entity) {
    }

    @Override
    public List<ComSearchDef> softDeleteByColumn(ComSearchDef entity) {
        return null;
    }

    @Override
    public List<ComSearchDef> insert(List<ComSearchDef> entity, String sqlId) {
        return null;
    }

    @Override
    public List<ComSearchDef> insert(ComSearchDef entity, String sqlId) {
        return null;
    }

    @Override
    public List<ComSearchDef> update(ComSearchDef searchCriteria, ComSearchDef entity, String sqlId) {
        return null;
    }
	
    public List<ComSearchDef> findByUserGroup(@Param("userGroupCodes") List<String> userGroupCodes) {
        return null;
    }
	
    public List<Map<String, String>> findForSearch(Map<String, Object> searchCriteria) {
            return null;
    }
    public List<Map<String, String>> findForSearch(Map<String, Object> searchCriteria, String sqlId) {
            return getSqlSession().selectList("comSearch." + sqlId, searchCriteria);		
    }    
}
