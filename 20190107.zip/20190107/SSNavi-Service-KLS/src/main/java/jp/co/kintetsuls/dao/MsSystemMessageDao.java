package jp.co.kintetsuls.dao;

import java.util.*;
import jp.co.kintetsuls.service.model.MsSystemMessage;
import jp.co.sharedsys.ssframe.dao.BaseDao;
import org.springframework.stereotype.Component;

@Component
public class MsSystemMessageDao extends BaseDao<MsSystemMessage> {

    @Override
    public MsSystemMessage create(MsSystemMessage msSystemMessage) {
        getSqlSession().insert("msSystemMessage.insert", msSystemMessage);
        return null;
    }

    @Override
    public MsSystemMessage findById(MsSystemMessage msSystemMessage) {
        return (MsSystemMessage) getSqlSession().selectOne("msSystemMessage.findById", msSystemMessage);
    }

    @Override
    public List<MsSystemMessage> findByColumn(MsSystemMessage msSystemMessage) {
        return getSqlSession().selectList("msSystemMessage.findByColumn", msSystemMessage);
    }

    @Override
    public List<MsSystemMessage> find(MsSystemMessage msSystemMessage, String sqlId) {
        return getSqlSession().selectList("msSystemMessage.find" + sqlId , msSystemMessage);
    }

    @Override
    public MsSystemMessage update(MsSystemMessage msSystemMessage) {
        return null;
    }

    @Override
    public List<MsSystemMessage> updateByColumn(MsSystemMessage crt, MsSystemMessage upd) {
        Map<String ,Object> map = new HashMap<>();
        map.put("crt", crt);
        map.put("upd", upd);
        getSqlSession().update("msSystemMessage.updateByColumn",map);
        return null;
    }

    @Override
    public List<MsSystemMessage> update(MsSystemMessage crt, MsSystemMessage upd, String sqlId) {
        Map<String ,Object> map = new HashMap<>();
        map.put("crt", crt);
        map.put("upd", upd);
        getSqlSession().update("msSystemMessage.update" + sqlId, map);
        return null;
    }

    @Override
    public List<MsSystemMessage> insert(List<MsSystemMessage> msSystemMessage, String sqlId) {
        getSqlSession().insert("msSystemMessage.insert" + sqlId, msSystemMessage);
        return null;
    }

    @Override
    public List<MsSystemMessage> insert(MsSystemMessage msSystemMessage, String sqlId) {
        getSqlSession().insert("msSystemMessage.insert" + sqlId, msSystemMessage);
        return null;
    }

    @Override
    public void delete(String id) {
    }

    @Override
    public void deleteByColumn(MsSystemMessage msSystemMessage) {
        getSqlSession().delete("msSystemMessage.deleteByColumn", msSystemMessage);
    }

    @Override
    public MsSystemMessage softDelete(MsSystemMessage msSystemMessage) {
        getSqlSession().update("msSystemMessage.softDelete", msSystemMessage);
        return null;
    }

    @Override
    public List<MsSystemMessage> softDeleteByColumn(MsSystemMessage msSystemMessage) {
        getSqlSession().update("msSystemMessage.softDeleteByColumn",msSystemMessage);
        return null;
    }

    @Override
    public List<MsSystemMessage> findAll() {
        return getSqlSession().selectList("msSystemMessage.findAll");
    }

}
