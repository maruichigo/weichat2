package jp.co.kintetsuls.service.model.common;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import jp.co.sharedsys.service.constraintannotation.PrimaryKey;
import jp.co.sharedsys.service.model.BaseModel;

/** 
 * M_JIS
 * @author sharedsys
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "m_jis")
public class JisDef extends BaseModel implements Serializable{

    private static final long serialVersionUID = 8225066323266434396L;

    @PrimaryKey(columnName = "ccode")
    private String pcode;
    private String pval;
    private String ccode;
    private String cval;
    private String searchOption;
    
    @XmlElement(name = "pcode")
    public String getPcode() {
        return pcode;
    }
    public void setPcode(String pcode) {
        this.pcode = pcode;
    }

    @XmlElement(name = "pval")
    public String getPval() {
        return pval;
    }
    public void setPval(String pval) {
        this.pval = pval;
    }
    
    @XmlElement(name = "ccode")
    public String getCcode() {
        return ccode;
    }
    public void setCcode(String ccode) {
        this.ccode = ccode;
    }

    @XmlElement(name = "cval")
    public String getCval() {
        return cval;
    }
    public void setCval(String cval) {
        this.cval = cval;
    }

    @XmlElement(name = "searchOption")
    public String getSearchOption() {
        return searchOption;
    }
    public void setSearchOption(String searchOption) {
        this.searchOption = searchOption;
    }    
    
}
