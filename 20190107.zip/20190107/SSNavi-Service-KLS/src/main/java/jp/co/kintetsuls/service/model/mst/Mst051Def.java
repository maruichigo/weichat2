package jp.co.kintetsuls.service.model.mst;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import jp.co.sharedsys.service.constraintannotation.PrimaryKey;
import jp.co.sharedsys.service.model.BaseModel;
import lombok.Data;

/**
 * Sample model
 *
 * @author sharedsys
 */
@Data
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "mst051")
public class Mst051Def extends BaseModel implements Serializable {

    private static final long serialVersionUID = 8225066323266434396L;

    @PrimaryKey(columnName = "dairitenCd")
    private String daihyoFlg;
    private String dairitenCd;
    private String dairitenMei;
    private String tekiyoKaishibi;
    private String kaishaMei;
    private String shitenMei;
    private String jusho;
    private String shukaten;
    private String haitatsuten;
    private String chaterkiten;
    private String haitatsuDenpyoShutsuryokuten;
    private String siiresakiCd;
    private String siiresaki;
    private String shuryo;
    private String saishuSiyoHiduke;

//    @XmlElement(name = "daihyoFlg")
//    public String getDaihyoFlg() {
//        return daihyoFlg;
//    }
//
//    public void setDaihyoFlg(String daihyoFlg) {
//        this.daihyoFlg = daihyoFlg;
//    }
//
//    @XmlElement(name = "dairitenCd")
//    public String getDairitenCd() {
//        return dairitenCd;
//    }
//
//    public void setDairitenCd(String dairitenCd) {
//        this.dairitenCd = dairitenCd;
//    }
}
