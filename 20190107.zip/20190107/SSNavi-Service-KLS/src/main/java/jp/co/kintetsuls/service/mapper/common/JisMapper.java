package jp.co.kintetsuls.service.mapper.common;

import jp.co.sharedsys.service.mapper.IMapper;
import org.springframework.stereotype.Component;

/**
 * Mybatis Sample Mapper
 * @author sharedsys
 */
@Component("m_jis")
public interface JisMapper extends IMapper {
    
}
