package jp.co.kintetsuls.service.bus.user;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.common.log.LOG;
import jp.co.sharedsys.ssframe.common.SSFrameMessage;
import jp.co.sharedsys.ssframe.model.Function;


import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;


/**
 * 権限取得処理クラス
 * 
 * @author saihara
 */
@Component("USER_GET_AUTHORITY")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class UserBusGetAuthority extends UserBus {

//	private List<UserGroupXUser> userGroupCodes = null;
	
	@Override
	public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
		userId = serviceInterfaceBean.getUserId();
		ObjectMapper mapper = new ObjectMapper();
//		userGroupCodes = mapper.readValue(serviceInterfaceBean.getJson(), new TypeReference<List<UserGroupXUser>>(){});
	}
	@Override
	public String validateHeaderByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
		return "";
	}

	@Override
	public String validateDetailByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
		return "";
	}

	@Override
	/** 権限検索
     * @param serviceInterfaceBean リクエストパラメータ
	 * @throws Exception 
	 */
	public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
		// 権限の取得
/*		List<String> userGroups = new ArrayList<String>();
		for (UserGroupXUser u : userGroupCodes) {
			userGroups.add(u.getUserGroupCode());
		}
*/
//		List<Function> functionList = functionDao.findByUserGroup(userGroups);
		String userCd = serviceInterfaceBean.getUserId();
		List<Function> functionList = functionDao.getAvailableFunction(userCd);
		if (functionList == null || functionList.size() == 0) {
			// 利用権限が無いユーザー（1つもFunctionが取れない)
			LOG.warn(SSFrameMessage.MSG_USER_LOGIN_FORBIDDEN + " UserCd[" + userCd + "]");
			serviceInterfaceBean.setMessage(SSFrameMessage.MSG_USER_LOGIN_WRONG_USER_ID_OR_PASSWD);
			return;
		} else {
			if (functionList.get(0).getFunctionCode().equals("ALL")) {
				// ALLが入ってたら全てのFunctionを取得する
				functionList = functionDao.findAll();
			}
		}
		
		serviceInterfaceBean.setJson(JSONUtil.makeJSONString(functionList));
		return;
	}

	@Override
	public void saveDetail(ServiceInterfaceBean serviceInterfaceBean)
			throws Exception {
	}

	@Override
	public void confirm(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
	}
	
}