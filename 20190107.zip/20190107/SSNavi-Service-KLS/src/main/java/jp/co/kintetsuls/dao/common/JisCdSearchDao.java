package jp.co.kintetsuls.dao.common;

import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.service.model.common.JisCdSearchDef;

import jp.co.sharedsys.ssframe.dao.BaseDao;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * JISコード検索処理クラス
 *
 * @author
 *
 */
@Repository
public class JisCdSearchDao extends BaseDao<JisCdSearchDef>
{

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    public JisCdSearchDef create(JisCdSearchDef entity)
    {
        return entity;
    }

    public JisCdSearchDef update(JisCdSearchDef entity)
    {
        return entity;
    }

    public JisCdSearchDef softDelete(JisCdSearchDef entity)
    {
        return entity;
    }

    public void delete(String id)
    {
    }

    public List<JisCdSearchDef> findAll()
    {
        return null;
    }

    public JisCdSearchDef findById(JisCdSearchDef entity)
    {
        return null;
    }

    public List<JisCdSearchDef> findByColumn(JisCdSearchDef entity)
    {
        return null;
    }

    public List<JisCdSearchDef> find(JisCdSearchDef entity, String sqlId)
    {
        return null;
    }

    public List<JisCdSearchDef> updateByColumn(JisCdSearchDef searchCriteria, JisCdSearchDef entity)
    {
        return null;
    }

    public void deleteByColumn(JisCdSearchDef entity)
    {
    }

    public List<JisCdSearchDef> softDeleteByColumn(JisCdSearchDef entity)
    {
        return null;
    }

    public List<JisCdSearchDef> insert(List<JisCdSearchDef> entity, String sqlId)
    {
        return null;
    }

    public List<JisCdSearchDef> insert(JisCdSearchDef entity, String sqlId)
    {
        return null;
    }

    public List<JisCdSearchDef> update(JisCdSearchDef searchCriteria, JisCdSearchDef entity, String sqlId)
    {
        return null;
    }

    public List<Map<String, String>> findForSearch(Map<String, Object> searchCriteria, String sqlId)
    {
        return null;
    }

    public List<Map<String, String>> findForSearch(Map<String, Object> searchCriteria)
    {
        return null;
    }

    public List<JisCdSearchDef> findJisCd(JisCdSearchDef entity)
    {
        return getSqlSession().selectList("jisCdSearch.findJisCd", entity);
    }
}
