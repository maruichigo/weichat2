package jp.co.kintetsuls.service.bus.user;

import java.util.List;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.common.methods.Cryptor;
import jp.co.sharedsys.ssframe.common.SSFrameMessage;
import jp.co.sharedsys.ssframe.dao.UserDao;
import jp.co.sharedsys.ssframe.model.User;

/**
 * パスワード変更処理クラス
 * 
 * @author saihara
 */
@Component("USER_PASSWORD_CHANGE")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class UserBusPasswordChange extends UserBus {

	// 12文字以上で英数字記号をそれぞれ１つづつ含む
	private final static String PASSWORD_RULE = "^(?=.*[0-9])(?=.*[A-Za-z])(?=.*[!\\x22\\#$%&@'()*+,-./_])[\\w!\\x22\\#$%&@'()*+,-./]{12,}$";

	
	@Override
	public String validateHeaderByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
		return "";
	}

	@Override
	public String validateDetailByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
		return "";
	}
	
	@Override
	public String validateHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
		/* Todo:
		if (user.getUserId() == null || user.getUserId().length() == 0) {
			return SSFrameMessage.MSG_USER_LOGIN_NOT_EXIST_USER_ID;
		}
		if (user.getOldPassword() == null || user.getOldPassword().length() == 0) {
			return SSFrameMessage.MSG_USER_LOGIN_NOT_EXIST_OLDPASSWD;
		}
		if (user.getPassword() == null || user.getPassword().length() == 0) {
			return SSFrameMessage.MSG_USER_LOGIN_NOT_EXIST_NEWPASSWD;
		}
		if(!user.getPassword().matches(PASSWORD_RULE)){
			return SSFrameMessage.MSG_USER_LOGIN_INVALID_PASSWD;
		}
		if (user.getRetypeNewPassword() == null || user.getRetypeNewPassword().length() == 0) {
			return SSFrameMessage.MSG_USER_LOGIN_NOT_EXIST_RETYPEPASSWD;
		}
		
		if (!user.getPassword().equals(user.getRetypeNewPassword())) {
			// 新と確認が違う
			return SSFrameMessage.MSG_USER_LOGIN_WRONG_NEW_AND_RETYPE;
		}

		User crt = new User();
		crt.setUserId(user.getUserId());
		// passwordをencrypt
		crt.setOldPassword(Cryptor.encryptDes(this.user.getPassword(), UserBus.PASSWD_ENCRYPT_KEY));
		List<User> result = userDao.findByColumn(crt);
		if (result == null || result.size() == 0) {
			// ユーザIDまたはパスワードが違う
			return SSFrameMessage.MSG_USER_LOGIN_WRONG_OLDPASSWD;
		}
		*/
		return "";
	}

	@Override
	/** ログイン検索
     * @param serviceInterfaceBean リクエストパラメータ
	 * @throws Exception 
	 */
	public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
		// passwordをencrypt
		User old = new User();
		old.setUserCd(user.getUserCd());
//		old.setPassword(user.getOldPassword());
		setCommonFieldForUpdate(this.user, this.user.getUserCd());
//		old.setPassword(Cryptor.encryptDes(this.user.getOldPassword(), UserBus.PASSWD_ENCRYPT_KEY));
//		this.user.setPassword(Cryptor.encryptDes(this.user.getPassword(), UserBus.PASSWD_ENCRYPT_KEY));
		// OneTime passのフラグを倒す
//		this.user.setOnetimePassInd(0L);
		// password change
		List<User> result = ((UserDao)userDao).passwordChange(this.user, old);
		if (result == null || result.size() == 0) {
			// ユーザIDまたはパスワードが違う
			serviceInterfaceBean.setMessage(SSFrameMessage.MSG_USER_LOGIN_WRONG_USER_ID_OR_PASSWD);
			return;
		}
		serviceInterfaceBean.setMessage(SSFrameMessage.MSG_USER_LOGIN_PASSWD_CHANGE_SUCCSESS);
		serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
		return;
	}

	@Override
	public void saveDetail(ServiceInterfaceBean serviceInterfaceBean)
			throws Exception {
	}

	@Override
	public void confirm(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
	}
	
}