/**
 *
 */
package jp.co.kintetsuls.dao.mst;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.service.model.mst.Mst042Def;
import jp.co.sharedsys.ssframe.dao.BaseDao;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class Mst042Dao extends BaseDao<Mst042Def>{

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    public Mst042Def create(Mst042Def entity) {
        getSqlSession().insert("mst042.create", entity);
        return entity;
    }

    public Mst042Def update(Mst042Def entity) {
        getSqlSession().update("mst042.update", entity);
        return entity;
    }

    public Mst042Def softDelete(Mst042Def entity) {
        getSqlSession().update("mst042.softDelete", entity);
        return entity;
    }

    public void delete(String id) {
        getSqlSession().delete("mst042.delete",id);
    }

    public List<Mst042Def> findAll() {
        return getSqlSession().selectList("mst042.findAll");
    }
    
    public Mst042Def findById(Mst042Def entity) {
        return getSqlSession().selectOne("mst042.findById", entity);
    }

    public List<Mst042Def> findByColumn(Mst042Def entity) {
        return getSqlSession().selectList("mst042.findByColumn", entity);
    }

    public List<Mst042Def> find(Mst042Def entity, String sqlId) {
        return getSqlSession().selectList("mst042.find", entity);
    }

    @Override
    public List<Mst042Def> updateByColumn(Mst042Def searchCriteria, Mst042Def entity) {
        Map<String, Object> map = new HashMap<>();
        map.put("crt", searchCriteria);
        map.put("upd", entity);
        getSqlSession().update("mst042.updateByColumn",map);
        return findByColumn(entity);        
    }

    @Override
    public void deleteByColumn(Mst042Def entity) {
        getSqlSession().delete("mst042.deleteByColumn",entity);
    }

    @Override
    public List<Mst042Def> softDeleteByColumn(Mst042Def entity) {
        getSqlSession().update("mst042.softDeleteByColumn", entity);
        return findByColumn(entity);
    }

    @Override
    public List<Mst042Def> insert(List<Mst042Def> entity, String sqlId) {
        return null;
    }

    @Override
    public List<Mst042Def> insert(Mst042Def entity, String sqlId) {
        return null;
    }
    
    @Override
    public List<Mst042Def> update(Mst042Def searchCriteria, Mst042Def entity, String sqlId) {
        return null;
    }

    public List<Map<String, String>> findForSearch(Map<String, Object> searchCriteria, String sqlId) {
        return getSqlSession().selectList("mst042." + sqlId, searchCriteria);
    }

    public List<Map<String, String>> findForSearch(Map<String,Object> searchCriteria) {
            return getSqlSession().selectList("mst042.findToMap", searchCriteria);
    }

    //新規追加
    public Mst042Def updateForList(Mst042Def entity) {
        getSqlSession().update("mst042.updateForList", entity);
        return entity;
    }
    
    //新規追加
    public Mst042Def softDeleteForList(Mst042Def entity) {
        getSqlSession().update("mst042.softDeleteForList", entity);
        return entity;
    }

    /**
     *
     * @return
     */
    @Override
    public String tableName() {
        return "mst042";
    }    

    // 新規追加
    public void updateForList(Map input) {
        getSqlSession().update("mst042.updateForList", input);
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    // 新規追加
    public void softDeleteForList(Map input) {
        getSqlSession().update("mst042.softDeleteForList", input);
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
