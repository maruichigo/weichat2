/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.service.model;

import java.io.Serializable;


import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import jp.co.sharedsys.service.model.BaseModel;
import lombok.Data;

/**
 * JushoJisDef
 *
 * @author
 */
@Data
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "jushoJis")
public class JushoJisDef extends BaseModel implements Serializable {
    
    private static final long serialVersionUID = 1L;

    private String conJusho; // 検索住所    
    private Date tekiyoBi; // 適用日
    
    private String jisCd; // JISコード
    private String jusho; // 住所
    private String ritoUmuFlg; // 離島有無フラグ
    private String kyuJushoFlg; // 旧住所フラグ
    private String shiyoFukaFlg; // 使用不可フラグ ji


}
