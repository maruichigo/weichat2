/**
 *
 */
package jp.co.kintetsuls.dao.smp;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.service.model.smp.Smp101Def;
import jp.co.sharedsys.ssframe.dao.BaseDao;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class Smp101Dao extends BaseDao<Smp101Def>{

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    public Smp101Def create(Smp101Def entity) {
        getSqlSession().insert("smp101.create", entity);
        return entity;
    }

    public Smp101Def update(Smp101Def entity) {
        getSqlSession().update("smp101.update", entity);
        return entity;
    }

    public Smp101Def softDelete(Smp101Def entity) {
    	getSqlSession().update("smp101.softDelete", entity);
        return entity;
    }

    public void delete(String id) {
        getSqlSession().delete("smp101.delete",id);
    }

    public List<Smp101Def> findAll() {
        return getSqlSession().selectList("smp101.findAll");
    }
    
    public Smp101Def findById(Smp101Def entity) {
        return getSqlSession().selectOne("smp101.findById", entity);
    }

    public List<Smp101Def> findByColumn(Smp101Def entity) {
        return getSqlSession().selectList("smp101.findByColumn", entity);
    }

    public List<Smp101Def> find(Smp101Def entity, String sqlId) {
        return getSqlSession().selectList("smp101.find", entity);
    }

    @Override
    public List<Smp101Def> updateByColumn(Smp101Def searchCriteria, Smp101Def entity) {
        Map<String, Object> map = new HashMap<>();
        map.put("crt", searchCriteria);
        map.put("upd", entity);
        getSqlSession().update("smp101.updateByColumn",map);
        return findByColumn(entity);        
    }

    @Override
    public void deleteByColumn(Smp101Def entity) {
        getSqlSession().delete("smp101.deleteByColumn",entity);
    }

    @Override
    public List<Smp101Def> softDeleteByColumn(Smp101Def entity) {
        getSqlSession().update("smp101.softDeleteByColumn", entity);
        return findByColumn(entity);
    }

    @Override
    public List<Smp101Def> insert(List<Smp101Def> entity, String sqlId) {
        return null;
    }

    @Override
    public List<Smp101Def> insert(Smp101Def entity, String sqlId) {
        return null;
    }
    
    @Override
    public List<Smp101Def> update(Smp101Def searchCriteria, Smp101Def entity, String sqlId) {
        return null;
    }

    public List<Map<String, String>> findForSearch(Map<String, Object> searchCriteria, String sqlId) {
        return getSqlSession().selectList("smp101." + sqlId, searchCriteria);		
    }

    public List<Map<String, String>> findForSearch(Map<String,Object> searchCriteria) {
        return getSqlSession().selectList("smp101.findToMap", searchCriteria);		
    }   
    
    public List<Map<String, String>> findJisCd(Smp101Def entity) {
        return getSqlSession().selectList("smp101.findJisCd", entity);		
    }    

    //新規追加
    public Smp101Def updateForList(Smp101Def entity) {
        getSqlSession().update("smp101.updateForList", entity);
        return entity;
    }    
    
    /**
     *
     * @return
     */
    @Override
    public String tableName() {
        return "smp101";
    }    
    
    public void insertForList(Map<String, Object> params) {
        getSqlSession().update("smp101.insertForList", params);
    }
    
    public void updateForList(Map<String, Object> params) {
        getSqlSession().update("smp101.updateForList", params);
    }
    
    public void softDeleteForList(Map input) {
        getSqlSession().update("smp101.softDeleteForList", input);
    }
}
