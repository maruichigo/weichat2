/**
 *
 */
package jp.co.kintetsuls.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.service.model.JushoJisDef;

import jp.co.sharedsys.ssframe.dao.BaseDao;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class JushoJisDao extends BaseDao<JushoJisDef>{

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    public JushoJisDef create(JushoJisDef entity) {
        getSqlSession().insert("smp102.create", entity);
        return entity;
    }

    public JushoJisDef update(JushoJisDef entity) {
        getSqlSession().update("smp102.update", entity);
        return entity;
    }

    public JushoJisDef softDelete(JushoJisDef entity) {
    	getSqlSession().update("smp102.softDelete", entity);
        return entity;
    }

    public void delete(String id) {
        getSqlSession().delete("smp102.delete",id);
    }

    public List<JushoJisDef> findAll() {
        return getSqlSession().selectList("smp102.findAll");
    }
    
    public JushoJisDef findById(JushoJisDef entity) {
        return getSqlSession().selectOne("smp102.findById", entity);
    }

    public List<JushoJisDef> findByColumn(JushoJisDef entity) {
        return getSqlSession().selectList("smp102.findByColumn", entity);
    }

    public List<JushoJisDef> find(JushoJisDef entity, String sqlId) {
        return getSqlSession().selectList("smp102.find", entity);
    }

    @Override
    public List<JushoJisDef> updateByColumn(JushoJisDef searchCriteria, JushoJisDef entity) {
        Map<String, Object> map = new HashMap<>();
        map.put("crt", searchCriteria);
        map.put("upd", entity);
        getSqlSession().update("smp102.updateByColumn",map);
        return findByColumn(entity);        
    }

    @Override
    public void deleteByColumn(JushoJisDef entity) {
        getSqlSession().delete("smp102.deleteByColumn",entity);
    }

    @Override
    public List<JushoJisDef> softDeleteByColumn(JushoJisDef entity) {
        getSqlSession().update("smp102.softDeleteByColumn", entity);
        return findByColumn(entity);
    }

    @Override
    public List<JushoJisDef> insert(List<JushoJisDef> entity, String sqlId) {
        return null;
    }

    @Override
    public List<JushoJisDef> insert(JushoJisDef entity, String sqlId) {
        return null;
    }
    
    @Override
    public List<JushoJisDef> update(JushoJisDef searchCriteria, JushoJisDef entity, String sqlId) {
        return null;
    }

    public List<Map<String, String>> findForSearch(Map<String, Object> searchCriteria, String sqlId) {
        return getSqlSession().selectList("smp102." + sqlId, searchCriteria);		
    }

    public List<Map<String, String>> findForSearch(Map<String,Object> searchCriteria) {
        return getSqlSession().selectList("smp102.findToMap", searchCriteria);		
    }   
    
    public List<JushoJisDef> findJisCd(JushoJisDef entity) {
        return getSqlSession().selectList("jushoJis.findJisCd", entity);		
    }    

    
    /**
     *
     * @return
     */
    @Override
    public String tableName() {
        return "smp102";
    }    
    
    public void insertForList(Map<String, Object> params) {
        getSqlSession().update("smp102.insertForList", params);
    }
    
    public void updateForList(Map<String, Object> params) {
        getSqlSession().update("smp102.updateForList", params);
    }
    
    public void softDeleteForList(Map input) {
        getSqlSession().update("smp102.softDeleteForList", input);
    }
}
