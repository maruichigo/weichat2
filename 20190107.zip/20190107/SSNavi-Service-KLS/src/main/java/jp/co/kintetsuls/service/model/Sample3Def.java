package jp.co.kintetsuls.service.model;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import javax.xml.bind.annotation.XmlRootElement;
import jp.co.sharedsys.service.model.BaseModel;
import lombok.Data;

/**
 * Sample3Def
 *
 * @author 
 */
@Data
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "sample3")
public class Sample3Def extends BaseModel implements Serializable {

    private static final long serialVersionUID = 1L;

    private String cd;
    private Integer val;
}
