/**
 * 
 */
package jp.co.kintetsuls.dao.dem;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.service.model.dem.Dem012Def;
import jp.co.sharedsys.ssframe.dao.BaseDao;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class Dem012Dao extends BaseDao<Dem012Def>{

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    public Dem012Def create(Dem012Def entity) {
        getSqlSession().insert("dem012.create", entity);
        return entity;
    }

    public Dem012Def update(Dem012Def entity) {
        getSqlSession().update("dem012.update", entity);
        return entity;
    }

    public Dem012Def softDelete(Dem012Def entity) {
    	getSqlSession().update("dem012.softDelete", entity);
        return entity;
    }

    public void delete(String id) {
        getSqlSession().delete("dem012.delete",id);
    }

    public List<Dem012Def> findAll() {
        return getSqlSession().selectList("dem012.findAll");
    }
    
    public Dem012Def findById(Dem012Def entity) {
        return getSqlSession().selectOne("dem012.findById", entity);
    }

    public List<Dem012Def> findByColumn(Dem012Def entity) {
        return getSqlSession().selectList("dem012.findByColumn", entity);
    }

    public List<Dem012Def> find(Dem012Def entity, String sqlId) {
        return getSqlSession().selectList("dem012.find", entity);
    }

    @Override
    public List<Dem012Def> updateByColumn(Dem012Def searchCriteria, Dem012Def entity) {
        Map<String, Object> map = new HashMap<>();
        map.put("crt", searchCriteria);
        map.put("upd", entity);
        getSqlSession().update("dem012.updateByColumn",map);
        return findByColumn(entity);        
    }

    @Override
    public void deleteByColumn(Dem012Def entity) {
        getSqlSession().delete("dem012.deleteByColumn",entity);
    }

    @Override
    public List<Dem012Def> softDeleteByColumn(Dem012Def entity) {
        getSqlSession().update("dem012.softDeleteByColumn", entity);
        return findByColumn(entity);
    }

    @Override
    public List<Dem012Def> insert(List<Dem012Def> entity, String sqlId) {
        return null;
    }

    @Override
    public List<Dem012Def> insert(Dem012Def entity, String sqlId) {
        return null;
    }
    
    @Override
    public List<Dem012Def> update(Dem012Def searchCriteria, Dem012Def entity, String sqlId) {
        return null;
    }

    public List<Map<String, String>> findForSearch(Map<String, Object> searchCriteria, String sqlId) {
        return getSqlSession().selectList("dem012." + sqlId, searchCriteria);		
    }

    public List<Map<String, String>> findForSearch(Map<String,Object> searchCriteria) {
            return getSqlSession().selectList("dem012.findToMap", searchCriteria);		
    }

    //新規追加
    public Dem012Def updateForList(Dem012Def entity) {
        getSqlSession().update("dem012.updateForList", entity);
        return entity;
    }
    
    //新規追加
    public Dem012Def softDeleteForList(Dem012Def entity) {
    	getSqlSession().update("dem012.softDeleteForList", entity);
        return entity;
    }

    /**
     *
     * @return
     */
    @Override
    public String tableName() {
        return "dem012";
    }    

    // 新規追加
    public void updateForList(Map input) {
        getSqlSession().update("dem012.updateForList", input);
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    // 新規追加
    public void softDeleteForList(Map input) {
        getSqlSession().update("dem012.softDeleteForList", input);
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
