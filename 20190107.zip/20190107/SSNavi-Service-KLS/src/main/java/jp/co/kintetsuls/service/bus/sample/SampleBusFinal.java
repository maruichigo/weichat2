/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.service.bus.sample;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

@Component("SS_COM_SAMPLE_FINAL")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class SampleBusFinal extends SampleBus {
    
    @Override
    public String finalProc(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
System.out.print("★SampleBusFinal：finalProc");
        StringBuffer message = new StringBuffer();
        return message.toString();
    }    
}
