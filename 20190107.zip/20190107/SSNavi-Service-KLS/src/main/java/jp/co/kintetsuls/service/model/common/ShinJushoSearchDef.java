package jp.co.kintetsuls.service.model.common;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import jp.co.sharedsys.service.model.BaseModel;
import lombok.Data;

/**
 * ShinJushoSearchDef
 *
 * @author
 */
@Data
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "shinJushoSearch")
public class ShinJushoSearchDef extends BaseModel implements Serializable
{

    private static final long serialVersionUID = 8225066323266434396L;

    private Date tekiyoBi;     // 適用日
    private String jisCd;      // JISコード
    private String jusho1;     // 住所1
    private String jusho2;     // 住所2
    private String jusho3;     // 住所3
    private String jusho4;     // 住所4
}
