/**
 *
 */
package jp.co.kintetsuls.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.service.model.CalcDef;
import jp.co.kintetsuls.service.model.Sample3Def;
import jp.co.sharedsys.ssframe.dao.BaseDao;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.apache.ibatis.annotations.Param;

@Repository
public class Sample3Dao extends BaseDao<Sample3Def>{

    @Autowired
    private SqlSessionFactory sqlSessionFactory;
    
    public void getVal(Sample3Def entity) {
        getSqlSession().selectList("sptest.getVal", entity);
    }
    
      public void calc(CalcDef entity) {
        getSqlSession().selectList("sptest.calc", entity);
    }

    public Sample3Def create(Sample3Def entity) {
        getSqlSession().insert("sample3.create", entity);
        return entity;
    }

    public Sample3Def update(Sample3Def entity) {
        getSqlSession().update("sample3.update", entity);
        return entity;
    }

    public Sample3Def softDelete(Sample3Def entity) {
    	getSqlSession().update("sample3.softDelete", entity);
        return entity;
    }

    public void delete(String id) {
        getSqlSession().delete("sample3.delete",id);
    }

    public List<Sample3Def> findAll() {
        return getSqlSession().selectList("sample3.findAll");
    }
    
    public Sample3Def findById(Sample3Def entity) {
        return getSqlSession().selectOne("sample3.findById", entity);
    }

    public List<Sample3Def> findByColumn(Sample3Def entity) {
        return getSqlSession().selectList("sample3.findByColumn", entity);
    }

    public List<Sample3Def> find(Sample3Def entity, String sqlId) {
        return getSqlSession().selectList("sample3.find", entity);
    }
    
    @Override
    public List<Sample3Def> updateByColumn(Sample3Def searchCriteria, Sample3Def entity) {
        Map<String, Object> map = new HashMap<>();
        map.put("crt", searchCriteria);
        map.put("upd", entity);
        getSqlSession().update("sample3.updateByColumn",map);
        return findByColumn(entity);        
    }

    @Override
    public void deleteByColumn(Sample3Def entity) {
        getSqlSession().delete("sample3.deleteByColumn",entity);
    }

    @Override
    public List<Sample3Def> softDeleteByColumn(Sample3Def entity) {
        getSqlSession().update("sample3.softDeleteByColumn", entity);
        return findByColumn(entity);
    }

    @Override
    public List<Sample3Def> insert(List<Sample3Def> entity, String sqlId) {
        return null;
    }

    @Override
    public List<Sample3Def> insert(Sample3Def entity, String sqlId) {
        return null;
    }
    
    @Override
    public List<Sample3Def> update(Sample3Def searchCriteria, Sample3Def entity, String sqlId) {
        return null;
    }

    public List<Map<String, String>> findForSearch(Map<String, Object> searchCriteria, String sqlId) {
        return getSqlSession().selectList("sample3." + sqlId, searchCriteria);		
    }

    public List<Map<String, String>> findForSearch(Map<String,Object> searchCriteria) {
        return getSqlSession().selectList("sample3.findToMap", searchCriteria);		
    }   
    
    //treeのためのクエリ追加
    public List<Map<String, String>> searchForList(Map<String,Object> searchCriteria) {
        return getSqlSession().selectList("jp.co.kintetsuls.service.mapper.Sample3Mapper.searchForList", searchCriteria);		
    }    
    
    public int updateDeleteItem(Sample3Def entity){
        return getSqlSession().update("sample3.softDeleteOya", entity);
    } 
    public int softDeleteTree(Map<String,Object> param){
        return getSqlSession().update("sample3.softDeleteTree", param);
    } 
    public int softDeleteList(@Param ("itemList" ) List<Sample3Def> itemList){
        return getSqlSession().update("jp.co.kintetsuls.service.mapper.Sample3Mapper.softDeleteList", itemList);
    } 
    
    
    /**
     *
     * @return
     */
    @Override
    public String tableName() {
        return "sample3";
    }    
}
