package jp.co.kintetsuls.service.mapper.mst;

import jp.co.sharedsys.service.mapper.IMapper;
import org.springframework.stereotype.Component;

/**
 * Mybatis 営業所マスタ詳細 Mapper
 * @author sharedsys
 */
@Component("mst042")
public interface Mst042Mapper extends IMapper {
    
}
