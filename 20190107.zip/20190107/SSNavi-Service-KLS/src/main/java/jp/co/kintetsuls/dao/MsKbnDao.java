package jp.co.kintetsuls.dao;

import java.util.*;
import jp.co.kintetsuls.service.model.MsKbn;
import jp.co.sharedsys.ssframe.dao.BaseDao;
import org.springframework.stereotype.Component;

@Component
public class MsKbnDao extends BaseDao<MsKbn> {

    @Override
    public MsKbn create(MsKbn msKbn) {
        getSqlSession().insert("msKbn.insert", msKbn);
        return null;
    }

    @Override
    public MsKbn findById(MsKbn msKbn) {
        return (MsKbn) getSqlSession().selectOne("msKbn.findById", msKbn);
    }

    @Override
    public List<MsKbn> findByColumn(MsKbn msKbn) {
        return getSqlSession().selectList("msKbn.findByColumn", msKbn);
    }

    @Override
    public List<MsKbn> find(MsKbn msKbn, String sqlId) {
        return getSqlSession().selectList("msKbn.find" + sqlId , msKbn);
    }

    @Override
    public MsKbn update(MsKbn msKbn) {
        return null;
    }

    @Override
    public List<MsKbn> updateByColumn(MsKbn crt, MsKbn upd) {
        Map<String ,Object> map = new HashMap<>();
        map.put("crt", crt);
        map.put("upd", upd);
        getSqlSession().update("msKbn.updateByColumn",map);
        return null;
    }

    @Override
    public List<MsKbn> update(MsKbn crt, MsKbn upd, String sqlId) {
        Map<String ,Object> map = new HashMap<>();
        map.put("crt", crt);
        map.put("upd", upd);
        getSqlSession().update("msKbn.update" + sqlId, map);
        return null;
    }

    @Override
    public List<MsKbn> insert(List<MsKbn> msKbn, String sqlId) {
        getSqlSession().insert("msKbn.insert" + sqlId, msKbn);
        return null;
    }

    @Override
    public List<MsKbn> insert(MsKbn msKbn, String sqlId) {
        getSqlSession().insert("msKbn.insert" + sqlId, msKbn);
        return null;
    }

    @Override
    public void delete(String id) {
    }

    @Override
    public void deleteByColumn(MsKbn msKbn) {
        getSqlSession().delete("msKbn.deleteByColumn", msKbn);
    }

    @Override
    public MsKbn softDelete(MsKbn msKbn) {
        getSqlSession().update("msKbn.softDelete", msKbn);
        return null;
    }

    @Override
    public List<MsKbn> softDeleteByColumn(MsKbn msKbn) {
        getSqlSession().update("msKbn.softDeleteByColumn",msKbn);
        return null;
    }

    @Override
    public List<MsKbn> findAll() {
        return getSqlSession().selectList("msKbn.findAll");
    }

}
