/**
 *
 */
package jp.co.kintetsuls.dao.cus;

import jp.co.kintetsuls.dao.cus.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.service.model.cus.Cus011Def;
import jp.co.sharedsys.ssframe.dao.BaseDao;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class Cus011Dao extends BaseDao<Cus011Def>{

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    public Cus011Def create(Cus011Def entity) {
        getSqlSession().insert("cus011.create", entity);
        return entity;
    }

    public Cus011Def update(Cus011Def entity) {
        getSqlSession().update("cus011.update", entity);
        return entity;
    }

    public Cus011Def softDelete(Cus011Def entity) {
    	getSqlSession().update("cus011.softDelete", entity);
        return entity;
    }

    public void delete(String id) {
        getSqlSession().delete("cus011.delete",id);
    }

    public List<Cus011Def> findAll() {
        return getSqlSession().selectList("cus011.findAll");
    }
    
    public Cus011Def findById(Cus011Def entity) {
        return getSqlSession().selectOne("cus011.findById", entity);
    }

    public List<Cus011Def> findByColumn(Cus011Def entity) {
        return getSqlSession().selectList("cus011.findByColumn", entity);
    }

    public List<Cus011Def> find(Cus011Def entity, String sqlId) {
        return getSqlSession().selectList("cus011.find", entity);
    }

    @Override
    public List<Cus011Def> updateByColumn(Cus011Def searchCriteria, Cus011Def entity) {
        Map<String, Object> map = new HashMap<>();
        map.put("crt", searchCriteria);
        map.put("upd", entity);
        getSqlSession().update("cus011.updateByColumn",map);
        return findByColumn(entity);        
    }

    @Override
    public void deleteByColumn(Cus011Def entity) {
        getSqlSession().delete("cus011.deleteByColumn",entity);
    }

    @Override
    public List<Cus011Def> softDeleteByColumn(Cus011Def entity) {
        getSqlSession().update("cus011.softDeleteByColumn", entity);
        return findByColumn(entity);
    }

    @Override
    public List<Cus011Def> insert(List<Cus011Def> entity, String sqlId) {
        return null;
    }

    @Override
    public List<Cus011Def> insert(Cus011Def entity, String sqlId) {
        return null;
    }
    
    @Override
    public List<Cus011Def> update(Cus011Def searchCriteria, Cus011Def entity, String sqlId) {
        return null;
    }

    public List<Map<String, String>> findForSearch(Map<String, Object> searchCriteria, String sqlId) {
        return getSqlSession().selectList("cus011." + sqlId, searchCriteria);		
    }

    public List<Map<String, String>> findForSearch(Map<String,Object> searchCriteria) {
            return getSqlSession().selectList("cus011.findToMap", searchCriteria);		
    }

    //新規追加
    public Cus011Def updateForList(Cus011Def entity) {
        getSqlSession().update("cus011.updateForList", entity);
        return entity;
    }
    
    //新規追加
    public Cus011Def softDeleteForList(Cus011Def entity) {
    	getSqlSession().update("cus011.softDeleteForList", entity);
        return entity;
    }

    /**
     *
     * @return
     */
    @Override
    public String tableName() {
        return "cus011";
    }    

    // 新規追加
    public void updateForList(Map input) {
        getSqlSession().update("cus011.updateForList", input);
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    // 新規追加
    public void softDeleteForList(Map input) {
        getSqlSession().update("cus011.softDeleteForList", input);
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
