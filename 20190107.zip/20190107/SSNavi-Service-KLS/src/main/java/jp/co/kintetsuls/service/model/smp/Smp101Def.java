/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.service.model.smp;

import java.io.Serializable;
import java.math.BigDecimal;

import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import jp.co.sharedsys.service.model.BaseModel;
import lombok.Data;

/**
 * Smp101Def
 *
 * @author
 */
@Data
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "smp101")
public class Smp101Def extends BaseModel implements Serializable {

    private static final long serialVersionUID = 1L;

    // 検索条件
    private String conRyokinKomokuCd; // 料金項目コード
    private String conRyokinKomokuMeisho; // 料金項目名称
    private String conRyokinKomokuGroup; // 料金項目グループ
    private String conRyokinKomokuGroupMei; // 料金項目グループ名
    private String conSyoriKamoku; // 処理科目
    private String conHojoKamoku; // 補助科目
    private Date conTekiyoBi; // 適用日
    private String conJusho; // 住所
    private String jusyo2; // 住所2
    private String jusyo3; // 住所3
    private String conTekiyoMei; // 適用名
    private boolean conSakujoNomiKensaku; // 削除のみ検索

    // 検索結果
    private String tekiyoKaishibi; // 適用開始日                         
    private String ryokinKomokuCd; // 料金項目コード
    private String ryokinKomokuMeisho; // 料金項目名称
    private String ryokinKomokuGroup; // 料金項目グループ
    private String ryokinKomokuGruopMeisho; // 料金項目グループ名称
    private String groupNaiHyojijun; // グループ内表示順                      

    private BigDecimal oroshineritsu; // 卸値率               

    private String shuryoFlg; // 終了フラグ                  
    private String oroshineritsuSetteiKanoFlg; // 卸値率設定可能フラグ
    private String koteiKomokuFlg; // 固定項目フラグ     

    private String meisaiKomokuMei; // 明細項目名                  
    private String koteiKomoku; // 固定項目
    private String tekiyoMei; // 適用名
}
