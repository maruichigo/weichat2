package jp.co.kintetsuls.service.bus.mst.mst042;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.service.bus.SSFrameBusBase;

/**
 * 営業所マスタ詳細 businessロジック
 */
public abstract class Mst042Bus extends SSFrameBusBase {

    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }

    @Override
    public String validateHeaderByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public String validateDetailByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        StringBuffer message = new StringBuffer();
        return message.toString();
    }

    @Override
    public void setValidaterFactory() throws Exception {
    }

    @Override
    public String validateHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        StringBuffer message = new StringBuffer();
        return message.toString();
    }

    @Override
    public String validateDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        StringBuffer message = new StringBuffer();
        return message.toString();
    }
    @Override
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }

    @Override
    public void saveDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }

    @Override
    public void confirm(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }
    
    @Override
    public String finalProc(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

}
