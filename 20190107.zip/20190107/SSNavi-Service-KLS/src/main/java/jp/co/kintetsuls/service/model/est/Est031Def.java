package jp.co.kintetsuls.service.model.est;

import jp.co.kintetsuls.service.model.est.*;
import jp.co.kintetsuls.service.model.est.*;
import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

//import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import jp.co.sharedsys.service.constraintannotation.PrimaryKey;
import jp.co.sharedsys.service.model.BaseModel;
import lombok.Data;

/** 
 * Sample model
 * @author sharedsys
 */
@Data
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "est031")
public class Est031Def extends BaseModel implements Serializable{

    private static final long serialVersionUID = 8225066323266434396L;
    

}
