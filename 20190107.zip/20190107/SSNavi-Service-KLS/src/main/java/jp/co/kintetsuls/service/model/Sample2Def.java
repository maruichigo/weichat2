package jp.co.kintetsuls.service.model;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import jp.co.sharedsys.service.constraintannotation.PrimaryKey;
import jp.co.sharedsys.service.model.BaseModel;

/** 
 * Sample model
 * @author sharedsys
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "sample2")
public class Sample2Def extends BaseModel implements Serializable{

    private static final long serialVersionUID = 8225066323266434396L;

    @PrimaryKey(columnName = "column1")
    private String column1;
    private String column2;
    private String column3;
    private String column4;
    private String column5;
    private String column6;
    private String column7;   
    private String jis_code;
    private String column8;  
    private String column9;
    private String column11;  
    
    private String searchOption;
    private String tablename;
    
    private String oyaid;
    private String koid;
    private String magoid;  

    private String hid;
    private String did;
    private String mid;
    
    @XmlElement(name = "column1")
    public String getColumn1() {
        return column1;
    }
    public void setColumn1(String column1) {
        this.column1 = column1;
    }

    @XmlElement(name = "column2")
    public String getColumn2() {
        return column2;
    }
    public void setColumn2(String column2) {
        this.column2 = column2;
    }
    
    @XmlElement(name = "column3")
    public String getColumn3() {
        return column3;
    }
    public void setColumn3(String column3) {
        this.column3 = column3;
    }

    @XmlElement(name = "column4")
    public String getColumn4() {
        return column4;
    }
    public void setColumn4(String column4) {
        this.column4 = column4;
    }

    @XmlElement(name = "column5")
    public String getColumn5() {
        return column5;
    }
    public void setColumn5(String column5) {
        this.column5 = column5;
    }
    
    @XmlElement(name = "column6")
    public String getColumn6() {
        return column6;
    }
    public void setColumn6(String column6) {
        this.column6 = column6;
    }
    
    @XmlElement(name = "column7")
    public String getColumn7() {
        return column7;
    }
    public void setColumn7(String column7) {
        this.column6 = column7;
    }    

    @XmlElement(name = "searchOption")
    public String getSearchOption() {
        return searchOption;
    }
    public void setSearchOption(String searchOption) {
        this.searchOption = searchOption;
    }    

    @XmlElement(name = "tablename")
    public String getTablename() {
        return tablename;
    }
    public void setTablename(String tablename) {
        this.tablename = tablename;
    }

    @XmlElement(name = "jis_code")
    public String getJis_code() {
        return jis_code;
    }
    public void setJis_code(String jis_code) {
        this.jis_code = jis_code;
    }

    @XmlElement(name = "column8")
    public String getColumn8() {
        return column8;
    }
    public void setColumn8(String column8) {
        this.column8 = column8;
    }
    
    @XmlElement(name = "column9")
    public String getColumn9() {
        return column9;
    }
    public void setColumn9(String column9) {
        this.column9 = column9;
    }

    @XmlElement(name = "column11")
    public String getColumn11() {
        return column11;
    }
    public void setColumn11(String column11) {
        this.column11 = column11;
    }


    @XmlElement(name = "magoid")
    public String getMagoid() {
        return magoid;
    }
    public void setMagoid(String magoid) {
        this.magoid = magoid;
    }

    @XmlElement(name = "oyaid")
    public String getOyaid() {
        return oyaid;
    }
    public void setOyaid(String oyaid) {
        this.oyaid = oyaid;
    }

    public String getKoid() {
        return koid;
    }
    @XmlElement(name = "koid")
    public void setKoid(String koid) {
        this.koid = koid;
    }

    @XmlElement(name = "hid")
    public String getHid() {
        return hid;
    }
    public void setHid(String hid) {
        this.hid = hid;
    }

    @XmlElement(name = "did")
    public String getDid() {
        return did;
    }
    public void setDid(String did) {
        this.did = did;
    }

    @XmlElement(name = "mid")
    public String getMid() {
        return mid;
    }
    public void setMid(String mid) {
        this.mid = mid;
    }


}
