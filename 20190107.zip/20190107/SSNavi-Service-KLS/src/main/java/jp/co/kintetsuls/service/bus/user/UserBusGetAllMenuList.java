package jp.co.kintetsuls.service.bus.user;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.ssframe.model.Function;

/**
 * 権限取得処理クラス
 * 
 * @author saihara
 */
@Component("USER_GET_ALLMENU")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class UserBusGetAllMenuList extends UserBus {

	@Override
	public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
		userId = serviceInterfaceBean.getUserId();
//		ObjectMapper mapper = new ObjectMapper();
//		userGroupCodes = mapper.readValue(serviceInterfaceBean.getJson(), new TypeReference<List<UserGroupXUser>>(){});
	}
	@Override
	public String validateHeaderByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
		return "";
	}

	@Override
	public String validateDetailByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
		return "";
	}

	@Override
	/** 権限検索
     * @param serviceInterfaceBean リクエストパラメータ
	 * @throws Exception 
	 */
	public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
		// 権限の取得
		// 全てのFunctionを取得する
		List<Function> functionList = functionDao.findAll();
		
		serviceInterfaceBean.setJson(JSONUtil.makeJSONString(functionList));
		return;
	}

	@Override
	public void saveDetail(ServiceInterfaceBean serviceInterfaceBean)
			throws Exception {
	}

	@Override
	public void confirm(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
	}
	
}