package jp.co.kintetsuls.service.model.common;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import javax.xml.bind.annotation.XmlRootElement;
import jp.co.sharedsys.service.model.BaseModel;
import lombok.Data;

/**
 * 税金計算結果
 *
 */
@Data
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "taxCalc")
public class TaxCalcDef extends BaseModel implements Serializable {

    private static final long serialVersionUID = 8225066323266434396L;

    /**
     * 金額
     */
    private Integer kingaku = 0;
    /**
     * 課税対象額
     */
    private Integer kazeiTaishoGaku = 0;
    /**
     * 消費税額
     */
    private Integer shohizeiGaku = 0;
    /**
     * 内税金額
     */
    private Integer uchizeiKingaku = 0;
    /**
     * 非課税金額
     */
    private Integer hiKazeiKingaku = 0;

}
