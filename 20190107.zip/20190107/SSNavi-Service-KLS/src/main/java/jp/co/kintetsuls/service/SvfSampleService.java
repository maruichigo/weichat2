package jp.co.kintetsuls.service;

import java.io.IOException;
import javax.servlet.ServletContext;

import org.springframework.stereotype.Component;
import org.springframework.web.context.ServletContextAware;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import jp.co.kintetsuls.common.svf.PrintReport;
import jp.co.kintetsuls.exception.LogicException;
import jp.co.kintetsuls.exception.SystemException;

/**
 * SVFのSampleクラス
 *
 * @author sharedsys
 *
 */
@Component
@Path("/svfsample")
//@Scope(value = WebApplicationContext.SCOPE_REQUEST)
public class SvfSampleService implements ServletContextAware {
    
    @Context
    private ServletContext servletContext;
        
    @Override
    public void setServletContext(ServletContext servletContext) {
        this.servletContext = servletContext;
    }
    
    /**
     * This is a sample web service operation
     * @param name
     * @return 
     */
    @GET
    public String hello(@QueryParam("name") String name) {
        return "Hello " + name + "!";
    }
    
    /**
     * SVFからExcelを取得し返却するAPIです。
     * 
     * @param param
     *                          ダミーパラメタ
     * @return
     * @throws IOException 
     * @throws SystemException
     * @throws LogicException
     */
    @GET
    @Path("/downloadExcel")
    @Produces({
        "application/vnd.ms-excel",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"})
    public Response downloadExcel(@QueryParam("param") final String param) throws IOException, SystemException, LogicException {
        PrintReport rep = new PrintReport();
        // サンプルなのでパラメタはハードコーディングです。必要に応じてパラメータ化してください。
        Response.ResponseBuilder jaxRsResponse = rep.outputFile("REP01", "LET01", "Excelだよ", "Excel", "C:\\SSNavi-KLS-documents\\環境\\SVF\\EXCEL_TEST001.csv", 0, 0);
        return jaxRsResponse.build();
    }

   /**
     * SVFからPDFを取得し返却するAPIです。
     * 
     * @param param
     *                          ダミーパラメタ
     * @return
     * @throws IOException 
     * @throws SystemException
     * @throws LogicException
     */
    @GET
    @Path("/downloadPdf")
    @Produces({"application/pdf"})
    public Response downloadPdf(@QueryParam("param") final String param) throws IOException, SystemException, LogicException {
        PrintReport rep = new PrintReport();
        // サンプルなのでパラメタはハードコーディングです。必要に応じてパラメータ化してください。
        Response.ResponseBuilder jaxRsResponse = rep.outputFile("REP01", "LET01", "PDFだよ", "PDF", "C:\\SSNavi-KLS-documents\\環境\\SVF\\PDF_TEST001.csv", 0, 0);
        return jaxRsResponse.build();
    }
        
    /**
     * SVFからプレビュー用のイメージ（EMF）URLを取得し返却するAPIです。
     * 
     * @return
     *                              SVFのプレビュー用のイメージ（EMF）URL
     * @throws IOException 
     * @throws SystemException
     * @throws LogicException
     */
    @GET
    @Path("/preview")
    @Produces({"text/plain"})
    public String preview() throws IOException, SystemException, LogicException {
        PrintReport rep = new PrintReport();
        // サンプルなのでパラメタはハードコーディングです。必要に応じてパラメータ化してください。
        String res = rep.preview("REP01", "LET01", "PREVだよ", "C:\\SSNavi-KLS-documents\\環境\\SVF\\EXCEL_TEST001.csv", 0, 0);
        return res;
    }
}
