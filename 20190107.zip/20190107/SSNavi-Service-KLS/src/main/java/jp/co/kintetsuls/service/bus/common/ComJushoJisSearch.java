/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.service.bus.common;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import jp.co.kintetsuls.dao.JushoJisDao;
import jp.co.kintetsuls.service.model.JushoJisDef;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.ssframe.dao.Dao;
import jp.co.sharedsys.service.bus.SSFrameBusBase;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

@Component("COM_JUSHO_JIS_SEARCH")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ComJushoJisSearch extends SSFrameBusBase {

    @Autowired(required = true)
    @Resource(shareable = true)
    protected Dao<JushoJisDef> dao;

    private JushoJisDef jushoJisPrm;

    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        super.init(serviceInterfaceBean);
        
        ObjectMapper mapper = new ObjectMapper();

        jushoJisPrm = mapper.readValue(serviceInterfaceBean.getJson(), JushoJisDef.class);

    }

    @Override
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        List<JushoJisDef> resultList = new ArrayList<>();

        // 適用日が設定されていた場合
        if (jushoJisPrm != null && jushoJisPrm.getTekiyoBi() != null && !"".equals(jushoJisPrm.getTekiyoBi())) {

            // 住所を元にJISコードを取得
            List<JushoJisDef> rl = ((JushoJisDao) dao).findJisCd(jushoJisPrm);

            System.out.println(rl.size() + "件");
            System.out.println("取得 [" + JSONUtil.makeJSONString(rl) + "]");

            // 取得件数が1件の場合、リストに設定
            if (rl.size() == 1) {
                resultList = rl;
            }
        }

        System.out.println("返却 [" + JSONUtil.makeJSONString(resultList) + "]");

        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
    }

    @Override
    public String validateHeaderByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public String validateDetailByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public void setValidaterFactory() throws Exception {
    }

    @Override
    public String validateHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public String validateDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public void saveDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }

    @Override
    public void confirm(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }

    @Override
    public String finalProc(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }
}
