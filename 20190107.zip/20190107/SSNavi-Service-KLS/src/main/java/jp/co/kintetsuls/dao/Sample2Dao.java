/**
 *
 */
package jp.co.kintetsuls.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.service.model.Sample2Def;
import jp.co.sharedsys.ssframe.dao.BaseDao;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.apache.ibatis.annotations.Param;

@Repository
public class Sample2Dao extends BaseDao<Sample2Def>{

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    public Sample2Def create(Sample2Def entity) {
        getSqlSession().insert("sample2.create", entity);
        return entity;
    }

    public Sample2Def update(Sample2Def entity) {
        getSqlSession().update("sample2.update", entity);
        return entity;
    }

    public Sample2Def softDelete(Sample2Def entity) {
    	getSqlSession().update("sample2.softDelete", entity);
        return entity;
    }

    public void delete(String id) {
        getSqlSession().delete("sample2.delete",id);
    }

    public List<Sample2Def> findAll() {
        return getSqlSession().selectList("sample2.findAll");
    }
    
    public Sample2Def findById(Sample2Def entity) {
        return getSqlSession().selectOne("sample2.findById", entity);
    }

    public List<Sample2Def> findByColumn(Sample2Def entity) {
        return getSqlSession().selectList("sample2.findByColumn", entity);
    }

    public List<Sample2Def> find(Sample2Def entity, String sqlId) {
        return getSqlSession().selectList("sample2.find", entity);
    }

    @Override
    public List<Sample2Def> updateByColumn(Sample2Def searchCriteria, Sample2Def entity) {
        Map<String, Object> map = new HashMap<>();
        map.put("crt", searchCriteria);
        map.put("upd", entity);
        getSqlSession().update("sample2.updateByColumn",map);
        return findByColumn(entity);        
    }

    @Override
    public void deleteByColumn(Sample2Def entity) {
        getSqlSession().delete("sample2.deleteByColumn",entity);
    }

    @Override
    public List<Sample2Def> softDeleteByColumn(Sample2Def entity) {
        getSqlSession().update("sample2.softDeleteByColumn", entity);
        return findByColumn(entity);
    }

    @Override
    public List<Sample2Def> insert(List<Sample2Def> entity, String sqlId) {
        return null;
    }

    @Override
    public List<Sample2Def> insert(Sample2Def entity, String sqlId) {
        return null;
    }
    
    @Override
    public List<Sample2Def> update(Sample2Def searchCriteria, Sample2Def entity, String sqlId) {
        return null;
    }

    public List<Map<String, String>> findForSearch(Map<String, Object> searchCriteria, String sqlId) {
        return getSqlSession().selectList("sample2." + sqlId, searchCriteria);		
    }

    public List<Map<String, String>> findForSearch(Map<String,Object> searchCriteria) {
        return getSqlSession().selectList("sample.findToMap", searchCriteria);		
    }   
    
    //treeのためのクエリ追加
    public List<Map<String, String>> searchForList(Map<String,Object> searchCriteria) {
        return getSqlSession().selectList("jp.co.kintetsuls.service.mapper.Sample2Mapper.searchForList", searchCriteria);		
    }    
    
    public int updateDeleteItem(Sample2Def entity){
        return getSqlSession().update("sample2.softDeleteOya", entity);
    } 
    public int softDeleteTree(Map<String,Object> param){
        return getSqlSession().update("sample2.softDeleteTree", param);
    } 
    public int softDeleteList(@Param ("itemList" ) List<Sample2Def> itemList){
        return getSqlSession().update("jp.co.kintetsuls.service.mapper.Sample2Mapper.softDeleteList", itemList);
    } 
    
    
    /**
     *
     * @return
     */
    @Override
    public String tableName() {
        return "sample2";
    }    
}
