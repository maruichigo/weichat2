package jp.co.kintetsuls.common.util;
import java.security.*;
import java.io.*;
import jp.co.kintetsuls.service.bus.common.*;

import java.util.Objects;
import org.apache.commons.lang.StringUtils;
    
/**
 * RSA方式で暗号化、復号を行うユーティリティ
 * @author shatakeyama
 */
public class CipherUtil {
    //公開鍵と秘密鍵の保存先をプロパティから取得する。
    private final String publicKeyFileName =PropertyUtil.getString("util.privateKey.url");//TODO キー及び格納先
    private final String privateKeyFileName = PropertyUtil.getString("util.publicKey.url");//TODO キー及び格納先

    CipherUtil(){
        
    }
    
    /**
     * 文字列をRSA方式で暗号化する
     * @param key 暗号化する文字列
     * @return 暗号化したバイト列
     * @throws GeneralSecurityException
     * @throws UnsupportedEncodingException
     * @throws IOException
     * @throws ClassNotFoundException 
     */ 
    public byte[] toEncrypt(String key) throws GeneralSecurityException, UnsupportedEncodingException, IOException, ClassNotFoundException {
        if(isCipher()==true){
            if(StringUtils.isEmpty(key)){
                return null;
            }
            return ComCipherUtil.RSAEncryptChar(key,publicKeyFileName);
        }
        return stringToByte(key);
    }

    /**
     * 文字列をRSA方式で復号化する
     * @param key 復号化するバイト列
     * @return 復号化した文字列
     * @throws GeneralSecurityException
     * @throws UnsupportedEncodingException
     * @throws IOException
     * @throws ClassNotFoundException 
     */
    public String toDecrypt(byte[] key) throws GeneralSecurityException, UnsupportedEncodingException, IOException, ClassNotFoundException {
        if(isCipher() == true){
            if(key == null){
                return null;
            }
            return ComCipherUtil.RSADecryptChar(key,privateKeyFileName);
        }
        return byteToString(key);
    }
    
    /**
     * 文字列をRSA方式で暗号化する（DS用）
     * @param key 暗号化する文字列
     * @return 暗号化したバイト列
     * @throws GeneralSecurityException
     * @throws UnsupportedEncodingException
     * @throws IOException
     * @throws ClassNotFoundException 
     */
    public byte[] toEncryptForDS(String key) throws GeneralSecurityException, UnsupportedEncodingException, IOException, ClassNotFoundException {
        if(isCipher()==true){
            if(StringUtils.isEmpty(key)){
                return null;
            }
            return ComCipherUtil.RSAEncryptCharForDS(key,publicKeyFileName);
        }
        return stringToByte(key);
    }
    
    /**
     * 文字列をRSA方式で復号化する（DS用）
     * @param key 復号化するバイト列
     * @return 復号化した文字列
     * @throws GeneralSecurityException
     * @throws UnsupportedEncodingException
     * @throws IOException
     * @throws ClassNotFoundException 
     */
    public String toDecryptForDS(byte[] key) throws GeneralSecurityException, UnsupportedEncodingException, IOException, ClassNotFoundException {
        if(isCipher()==true){
            return ComCipherUtil.RSADecryptCharForDS(key,privateKeyFileName);
        }
        return byteToString(key);
    }
    
    /**
     * 暗号化、復号化を実施するか確認する
     * @return 実施する場合 true
     */
    public static boolean isCipher(){
        if(Objects.equals(PropertyUtil.getString("util.encript"),"true")){
            return true;
        }
        return false;
    }
    
    /**
     * 暗号化をしない場合の引数Stringのbyte[]変換
     * @param str 引数の文字列
     * @return byte[]変換した文字列 
     */
    public static byte[] stringToByte(String str){
        //Stringをbyte[]に変換
        byte [] returnValue = str.getBytes();
        //byte変換された文字列を返す
        return returnValue;
    }
    
    /**
     * 復号をしない場合の引数byte[]のString変換
     * @param byt 引数のbyte[]文字列
     * @return String変換した文字列 
     */
    public static String byteToString(byte[] byt){
        //byte[]をStringに変換
        String returnValue = new String(byt);
        //String変換された文字列を返す
        return returnValue;
    }
}
