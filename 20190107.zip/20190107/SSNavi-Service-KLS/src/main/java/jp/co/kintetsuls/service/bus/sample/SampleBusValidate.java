package jp.co.kintetsuls.service.bus.sample;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

@Component("SS_COM_SAMPLE_VALIDATE")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class SampleBusValidate extends SampleBus {

    @Override
    public String validateHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
System.out.print("★SampleBusValidate：validateHeader");
        StringBuffer message = new StringBuffer();
        return message.toString();
    }

    @Override
    public String validateDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
System.out.print("★SampleBusValidate：validateDetail");
        StringBuffer message = new StringBuffer();
        return message.toString();
    }
}
