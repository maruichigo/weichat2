/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.service.bus.smp.smp101;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.math.BigDecimal;

import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import jp.co.kintetsuls.dao.Sample3Dao;
import jp.co.kintetsuls.dao.smp.Smp101Dao;
import jp.co.kintetsuls.service.model.CalcDef;
import jp.co.kintetsuls.service.model.Sample3Def;

import jp.co.kintetsuls.service.model.smp.Smp101Def;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.ssframe.dao.Dao;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

/**
 * 検索ボタン押下時処理
 */
@Component("SDC_SMP101_SEARCH")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Smp101BusSearch extends Smp101Bus {

    @Autowired(required = true)
    @Resource(shareable = true)
    protected Dao<Smp101Def> dao;

    @Autowired(required = true)
    @Resource(shareable = true)
    protected Sample3Dao sample3Dao;

    private Map<String, Object> params = null;
    private Sample3Def sample3Prm = new Sample3Def();
    private CalcDef calcPrm = new CalcDef();

    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        super.init(serviceInterfaceBean);
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
    }
    
    @Override
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {

        // ★一覧検索
        List<Map<String, String>> resultList = ((Smp101Dao) dao).findForSearch(params);

        
        // ストアド呼出確認 CHAR→NUMBER
        System.out.print("★getVal呼出 開始");
        sample3Prm.setCd("100");

        ((Sample3Dao) sample3Dao).getVal(sample3Prm);

        System.out.print("★getVal呼出 終了");
        System.out.print("CD  [" + sample3Prm.getCd() + "]");
        System.out.print("VAL [" + sample3Prm.getVal() + "]");
        

        // ストアド呼出確認 BigDecimal 四則演算
        System.out.print("★calc呼出 開始");
        calcPrm.setVal1(BigDecimal.valueOf(1.0));
        calcPrm.setVal2(BigDecimal.valueOf(0.3));

        ((Sample3Dao) sample3Dao).calc(calcPrm);

        System.out.print("★calc呼出 終了");
        System.out.print("[" + calcPrm.getVal1() + "][" + calcPrm.getVal2() + "]");
        System.out.print("和 [" + calcPrm.getWa() + "]");
        System.out.print("差 [" + calcPrm.getSa() + "]");
        System.out.print("積 [" + calcPrm.getSeki() + "]");
        System.out.print("商 [" + calcPrm.getShou() + "]");

        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
    }
}
