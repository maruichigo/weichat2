/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.dao.mst;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.service.model.mst.Mst501Def;
import jp.co.sharedsys.ssframe.dao.BaseDao;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * 仕向地名マスタ詳細 Dao
 *
 * @author MaLei (MBP)
 * @version 2019/1/6 新規作成
 */
@Repository
public class Mst501Dao extends BaseDao<Mst501Def>{

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    public Mst501Def create(Mst501Def entity) {
        getSqlSession().insert("mst501.create", entity);
        return entity;
    }

    public Mst501Def update(Mst501Def entity) {
        getSqlSession().update("mst501.update", entity);
        return entity;
    }

    public Mst501Def softDelete(Mst501Def entity) {
        getSqlSession().update("mst501.softDelete", entity);
        return entity;
    }

    public void delete(String id) {
        getSqlSession().delete("mst501.delete",id);
    }

    public List<Mst501Def> findAll() {
        return getSqlSession().selectList("mst501.findAll");
    }
    
    public Mst501Def findById(Mst501Def entity) {
        return getSqlSession().selectOne("mst501.findById", entity);
    }

    public List<Mst501Def> findByColumn(Mst501Def entity) {
        return getSqlSession().selectList("mst501.findByColumn", entity);
    }

    public List<Mst501Def> find(Mst501Def entity, String sqlId) {
        return getSqlSession().selectList("mst501.find", entity);
    }

    @Override
    public List<Mst501Def> updateByColumn(Mst501Def searchCriteria, Mst501Def entity) {
        Map<String, Object> map = new HashMap<>();
        map.put("crt", searchCriteria);
        map.put("upd", entity);
        getSqlSession().update("mst501.updateByColumn",map);
        return findByColumn(entity);        
    }

    @Override
    public void deleteByColumn(Mst501Def entity) {
        getSqlSession().delete("mst501.deleteByColumn",entity);
    }

    @Override
    public List<Mst501Def> softDeleteByColumn(Mst501Def entity) {
        getSqlSession().update("mst501.softDeleteByColumn", entity);
        return findByColumn(entity);
    }

    @Override
    public List<Mst501Def> insert(List<Mst501Def> entity, String sqlId) {
        return null;
    }

    @Override
    public List<Mst501Def> insert(Mst501Def entity, String sqlId) {
        return null;
    }
    
    @Override
    public List<Mst501Def> update(Mst501Def searchCriteria, Mst501Def entity, String sqlId) {
        return null;
    }

    public List<Map<String, String>> findForSearch(Map<String, Object> searchCriteria, String sqlId) {
        return getSqlSession().selectList("mst501." + sqlId, searchCriteria);
    }

    // 明細検索
    public List<Map<String, String>> findForSearch(Map<String,Object> searchCriteria) {
            return getSqlSession().selectList("mst501.findToMap", searchCriteria);
    }

    // 都道府県存在チェック
    public List<Map<String, String>> countTodofuken(Map<String,Object> searchCriteria) {
            return getSqlSession().selectList("mst501.countToMap", searchCriteria);
    }    

    //新規追加
    public Mst501Def updateForList(Mst501Def entity) {
        getSqlSession().update("mst501.updateForList", entity);
        return entity;
    }
    
    //新規追加
    public Mst501Def softDeleteForList(Mst501Def entity) {
        getSqlSession().update("mst501.softDeleteForList", entity);
        return entity;
    }

    /**
     *
     * @return
     */
    @Override
    public String tableName() {
        return "mst501";
    }    

    // 新規追加
    public void updateForList(Map input) {
        getSqlSession().update("mst501.updateForList", input);
    }

    // 新規追加
    public void softDeleteForList(Map input) {
        getSqlSession().update("mst501.softDeleteForList", input);
    }
}
