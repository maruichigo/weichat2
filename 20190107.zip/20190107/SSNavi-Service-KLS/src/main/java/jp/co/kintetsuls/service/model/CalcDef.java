package jp.co.kintetsuls.service.model;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import jp.co.sharedsys.service.model.BaseModel;
import lombok.Data;

/**
 * CalcDef
 *
 * @author
 */
@Data
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "calc")
public class CalcDef extends BaseModel implements Serializable {

    private static final long serialVersionUID = 1L;

    private BigDecimal val1;
    private BigDecimal val2;
    private BigDecimal wa;
    private BigDecimal sa;
    private BigDecimal seki;
    private BigDecimal shou;
}
