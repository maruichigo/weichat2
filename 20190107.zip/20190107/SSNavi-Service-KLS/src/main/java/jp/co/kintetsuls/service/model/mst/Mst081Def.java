package jp.co.kintetsuls.service.model.mst;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

//import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import jp.co.sharedsys.service.constraintannotation.PrimaryKey;
import jp.co.sharedsys.service.model.BaseModel;
import lombok.Data;

/** 
 * Sample model
 * @author sharedsys
 */
@Data
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "mst081")
public class Mst081Def extends BaseModel implements Serializable{

    private static final long serialVersionUID = 8225066323266434396L;
    
    @PrimaryKey(columnName = "kokyakuCd")
    private String kokyakuCd;
    private String shuyakuCd;
    private String shiyoKbn;
    private String eigyoshoCd;
    private String sakujoFlg;
    private String torokuUser;
    private String torokuNichiji;
    private String koshinUser;
    private String koshinNichiji;
    private String koshinCounter;
    private String torokuTammatsu;
    private String koshinTammatsu;
    private String saishuOperationUser;
    private String saishuOperationKoshinNichiji;

//    @PrimaryKey(columnName = "column1")
//    private String column1;
//    private String column2;
//    private String column3;
//    private String column4;
//    private String column5;
//    private String column6;
//    private String column7;    
//    private String searchOption;
    
//    @XmlElement(name = "column1")
//    public String getColumn1() {
//        return column1;
//    }
//    public void setColumn1(String column1) {
//        this.column1 = column1;
//    }
//
//    @XmlElement(name = "column2")
//    public String getColumn2() {
//        return column2;
//    }
//    public void setColumn2(String column2) {
//        this.column2 = column2;
//    }
//    
//    @XmlElement(name = "column3")
//    public String getColumn3() {
//        return column3;
//    }
//    public void setColumn3(String column3) {
//        this.column3 = column3;
//    }
//
//    @XmlElement(name = "column4")
//    public String getColumn4() {
//        return column4;
//    }
//    public void setColumn4(String column4) {
//        this.column4 = column4;
//    }
//
//    @XmlElement(name = "column5")
//    public String getColumn5() {
//        return column5;
//    }
//    public void setColumn5(String column5) {
//        this.column5 = column5;
//    }
//    
//    @XmlElement(name = "column6")
//    public String getColumn6() {
//        return column6;
//    }
//    public void setColumn6(String column6) {
//        this.column6 = column6;
//    }
//    
//    @XmlElement(name = "column7")
//    public String getColumn7() {
//        return column7;
//    }
//    public void setColumn7(String column7) {
//        this.column6 = column7;
//    }    
//
//    @XmlElement(name = "searchOption")
//    public String getSearchOption() {
//        return searchOption;
//    }
//    public void setSearchOption(String searchOption) {
//        this.searchOption = searchOption;
//    }    
    
}
