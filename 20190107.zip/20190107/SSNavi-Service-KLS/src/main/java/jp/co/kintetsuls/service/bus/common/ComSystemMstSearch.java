/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.service.bus.common;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
//import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import javax.annotation.Resource;
import jp.co.kintetsuls.common.util.SystemMstHold;
import jp.co.kintetsuls.dao.MsSystemDao;
import jp.co.kintetsuls.service.model.MsSystem;
import jp.co.kintetsuls.service.model.SystemMstDef;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.ssframe.dao.Dao;
import jp.co.sharedsys.service.bus.SSFrameBusBase;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

@Component("COM_SYSTEM_MST_SEARCH")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ComSystemMstSearch extends SSFrameBusBase {

    @Autowired(required = true)
    @Resource(shareable = true)
    protected Dao<MsSystem> dao;

    // Map<String, Object> map = null;
    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {

        //System.out.println("◆◆◆◆◆◆◆ init ◆◆◆◆◆◆◆[" + new Object() {}.getClass().getEnclosingClass().getName() + "]");
        super.init(serviceInterfaceBean);

        //ObjectMapper mapper = new ObjectMapper();
        //map = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
    }

    @Override
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        List<SystemMstDef> resultList = new ArrayList<>();

        // 検索条件パラメータ
        MsSystem prm = new MsSystem();
        prm.setSakujoFlg("0"); // 検索条件に「未削除」を設定

        // システムマスタを取得
        List<MsSystem> rl = ((MsSystemDao) dao).findByColumn(prm);

        System.out.println(rl.size() + "件");
 //       System.out.println("取得 [" + JSONUtil.makeJSONString(rl) + "]");

        // システムマスタをMapに格納
        Map<String, SystemMstDef> map = new HashMap<>();
        for (MsSystem res : rl) {

            // システムマスタBean
            SystemMstDef bean = new SystemMstDef();
            bean.setCdGroup(res.getCdGroup());
            bean.setCd(res.getCd());
            bean.setVal(res.getVal());

            if (bean.getCdGroup() != null && bean.getCd() != null) {
                String key = bean.getCdGroup().concat("_").concat(bean.getCd());
                map.put(key, bean);
            }
        }

        // システムマスタ保持クラスにMapを格納
        SystemMstHold systemMstHold = SystemMstHold.getInstance();
        systemMstHold.setSystemMst(map);

        // デバッグ 
        // printDebug(systemMstHold);
        //      System.out.println("返却 [" + JSONUtil.makeJSONString(resultList) + "]");

        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
    }

    private void printDebug(SystemMstHold systemMstHold) {
        Map<String, SystemMstDef> md = systemMstHold.getSytemMstDebug();
        System.out.println("★★★★★★ システムマスタ定義(debug) ★★★★★★");
        for (Entry<String, SystemMstDef> entry : md.entrySet()) {
            System.out.println("[" + entry.getKey() + "][" + entry.getValue().getVal() + "]");
        }
        System.out.println("★★★★★★★★★★★★★★★★★★★★★★★★★");
    }

    @Override
    public String validateHeaderByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public String validateDetailByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public void setValidaterFactory() throws Exception {
    }

    @Override
    public String validateHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public String validateDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public void saveDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }

    @Override
    public void confirm(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }

    @Override
    public String finalProc(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }
}
