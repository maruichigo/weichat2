/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.service.bus.mst.mst501;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import jp.co.kintetsuls.dao.mst.Mst501Dao;
import jp.co.kintetsuls.service.model.mst.Mst501Def;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.ssframe.dao.Dao;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

/**
 * 仕向地名マスタ　検索ボタン押下時処理
 *
 * @author MaLei (MBP)
 * @version 2019/1/6 新規作成
 */
@Component("MST501_SEARCH")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Mst501BusSearch extends Mst501Bus
{

    @Autowired(required = true)
    @Resource(shareable = true)
    protected Dao<Mst501Def> shimukeChiMeiDao;

    /** 検索パラメータ */
    private Map<String, Object> params = null;

    /** ワーク.営業所コード */
    private String conEigyoshoCd;

    /** ワーク.顧客コード */
    private String conKokyakuCd;

    /** メッセージID：COMW0001. */
    private static final String MSG_ID_COMW0001 = "COMW0001";    

    /** メッセージID：COMW0006. */
    private static final String MSG_ID_COMW0006 = "COMW0006";        
    
    public String getConEigyoshoCd() {
        return conEigyoshoCd;
    }

    public void setConEigyoshoCd(String conEigyoshoCd) {
        this.conEigyoshoCd = conEigyoshoCd;
    }

    public String getConKokyakuCd() {
        return conKokyakuCd;
    }

    public void setConKokyakuCd(String conKokyakuCd) {
        this.conKokyakuCd = conKokyakuCd;
    }        
    
    /**
    * 初期処理<br>
    * 
    * @throws Exception
    */
    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception
    {
        super.init(serviceInterfaceBean);
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
    }

    /**
    * 入力項目チェック処理<br>
    * 
    * @param serviceInterfaceBean
    * @throws Exception
    */
    public String validateHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception
    {
       
        // 都道府県存在チェック
        List<Map<String, String>> resultList = ((Mst501Dao) shimukeChiMeiDao).countTodofuken(params);
        
        // 取得件数 = 0の場合
        if (resultList == null || resultList.isEmpty()) {
            serviceInterfaceBean.setMessage(MSG_ID_COMW0006);
        }
        return null;
    }    
    
    /**
    * 検索実施処理<br>
    * 
    * @throws Exception
    */
    @Override
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception
    {
        List<Map<String, String>> resultList = ((Mst501Dao) shimukeChiMeiDao).findForSearch(params);
        
        // 取得件数 = 0の場合
        if (resultList == null || resultList.isEmpty()) {
            serviceInterfaceBean.setMessage(MSG_ID_COMW0001);
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
    }
}
