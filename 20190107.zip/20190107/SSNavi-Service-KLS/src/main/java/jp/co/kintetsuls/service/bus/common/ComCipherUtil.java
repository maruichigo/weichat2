package jp.co.kintetsuls.service.bus.common;
import jp.co.kintetsuls.common.util.*;
import java.security.*;
import javax.crypto.*;
import java.io.*;
import java.security.spec.InvalidKeySpecException;

import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.RSAPrivateKeySpec;
import java.security.spec.RSAPublicKeySpec;
    
/**
 *
 * @author shatakeyama
 */
public class ComCipherUtil {
    //公開鍵と秘密鍵の保存先をプロパティから取得する。
    private final String publicKeyFileName =PropertyUtil.getString("util.privateKey.url");//TODO
    private final String privateKeyFileName = PropertyUtil.getString("util.publicKey.url");//TODO

    public ComCipherUtil(){
        
    }

    /**
     * RSAの鍵をファイルに保存する
     * @param key 鍵（公開鍵または秘密鍵）
     * @param fileName 保存するファイルパス
     * @throws IOException 
     */
    private void saveKey(Key key, String fileName) throws IOException {
        FileOutputStream fileOutputStream = new FileOutputStream(fileName);
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
        objectOutputStream.writeObject(key);
        objectOutputStream.flush();
        objectOutputStream.close();
    }
    
    /**
     * RSAの鍵をファイルから復元する
     * @param fileName 保存されているファイルパス
     * @return 復元した鍵（公開鍵または秘密鍵）
     * @throws IOException
     * @throws ClassNotFoundException 
     */
    private static Key restoreKey(String fileName) throws IOException, ClassNotFoundException {
        FileInputStream fileInputStream = new FileInputStream(fileName);
        ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
        Key key = (Key) objectInputStream.readObject();
        objectInputStream.close();
        return key;
    }
    
    /**
     * 公開鍵と秘密鍵を取得し、ファイルに保存する（システム稼働時に1回のみ実行）
     * @throws NoSuchAlgorithmException
     * @throws IOException 
     */
    public void getAndSaveKeyPair() 
            throws NoSuchAlgorithmException, IOException,InvalidKeySpecException {

        //公開鍵と秘密鍵を生成
        KeyPairGenerator kg = KeyPairGenerator.getInstance("RSA");//暗号化方式=RSA方式
        kg.initialize(2048);//鍵長2048
        KeyPair keyPair = kg.generateKeyPair();
        KeyFactory factoty = KeyFactory.getInstance("RSA");
        RSAPublicKeySpec publicKeySpec = factoty.getKeySpec(keyPair.getPublic(), RSAPublicKeySpec.class);
        RSAPrivateKeySpec privateKeySpec = factoty.getKeySpec(keyPair.getPrivate(), RSAPrivateKeySpec.class);
        //公開鍵を作成する
        PublicKey publickey = factoty.generatePublic(publicKeySpec);
        //秘密鍵を作成する
        PrivateKey privatekey = factoty.generatePrivate(privateKeySpec);

        //作成した公開鍵と秘密鍵をファイルに保存する
        saveKey(publickey, publicKeyFileName);
        saveKey(privatekey, privateKeyFileName);
    }

    /**
     * 文字列をRSA方式で暗号化する
     * @param source 暗号化する文字列
     * @param url 公開鍵保存先
     * @return 暗号化したバイト列
     * @throws GeneralSecurityException
     * @throws UnsupportedEncodingException
     * @throws IOException
     * @throws ClassNotFoundException 
     */
    public static byte[] RSAEncryptChar(String source,String url) throws GeneralSecurityException, UnsupportedEncodingException, IOException, ClassNotFoundException {
        //公開鍵を取得
        PublicKey publickey = (PublicKey)restoreKey(url);

        //RSA方式で暗号化する
        Cipher encrypterWithPublicKey = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        encrypterWithPublicKey.init(Cipher.ENCRYPT_MODE, publickey);
        return encrypterWithPublicKey.doFinal(source.getBytes("MS932"));

    }

    /**
     * RSA方式で暗号化した文字列を復号化する
     * @param crypto 暗号化したバイト列
     * @param url 暗号鍵保存先
     * @return 復号化した文字列
     * @throws GeneralSecurityException
     * @throws UnsupportedEncodingException
     * @throws IOException
     * @throws ClassNotFoundException 
     */
    public static String RSADecryptChar(byte[] crypto,String url) throws GeneralSecurityException, UnsupportedEncodingException, IOException, ClassNotFoundException {
        //秘密鍵を取得
        PrivateKey privatekey = (PrivateKey)restoreKey(url);

        //RSA方式で復号化する
        Cipher decrypter = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        decrypter.init(Cipher.DECRYPT_MODE, privatekey);
        return new String(decrypter.doFinal(crypto), "MS932");

    }
    
     /**
     * 文字列をRSA方式で暗号化する(DataSpider用)
     * @param source 暗号化する文字列
     * @param url 公開鍵保存先
     * @return 暗号化したバイト列
     * @throws GeneralSecurityException
     * @throws UnsupportedEncodingException
     * @throws IOException
     * @throws ClassNotFoundException 
     */
    public static byte[] RSAEncryptCharForDS(String source,String url) throws GeneralSecurityException, UnsupportedEncodingException, IOException, ClassNotFoundException {
        //公開鍵を取得
        PublicKey publickey = (PublicKey)restoreKey(url);

        //RSA方式で暗号化する
        Cipher encrypterWithPublicKey = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        encrypterWithPublicKey.init(Cipher.ENCRYPT_MODE, publickey);
        return encrypterWithPublicKey.doFinal(source.getBytes("MS932"));
    }
    
    /**
     * RSA方式で暗号化した文字列を復号化する(DataSpider用)
     * @param crypto 暗号化したバイト列
     * @param url 秘密鍵保存先
     * @return 復号化した文字列
     * @throws GeneralSecurityException
     * @throws UnsupportedEncodingException
     * @throws IOException
     * @throws ClassNotFoundException 
     */
    public static String RSADecryptCharForDS(byte[] crypto,String url) throws GeneralSecurityException, UnsupportedEncodingException, IOException, ClassNotFoundException {
        //秘密鍵を取得
        PrivateKey privatekey = (PrivateKey)restoreKey(url);

        //RSA方式で復号化する
        Cipher decrypter = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        decrypter.init(Cipher.DECRYPT_MODE, privatekey);
        //復号化して文字列で返す
        return new String(decrypter.doFinal(crypto), "MS932");
    }

}
