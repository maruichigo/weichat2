/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.service.model.mst;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import jp.co.sharedsys.service.constraintannotation.PrimaryKey;
import jp.co.sharedsys.service.model.BaseModel;

/** 
 * 仕向地名マスタ詳細 model
 *
 * @author MaLei (MBP)
 * @version 2019/1/6 新規作成
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "mst501")
public class Mst501Def extends BaseModel implements Serializable{

    private static final long serialVersionUID = 8225066323266434396L;
    
    /** 都道府県コード */
    @PrimaryKey(columnName = "listTodofukenCd")
    private String listTodofukenCd;

    /** 都道府県名 */
    private String listTodofukenMei;    
    
    /** 仕向地名コード */    
    @PrimaryKey(columnName = "shimukeChiMeiCd")
    private String listShimukeChiMeiCd;

    /** 仕向地名 */      
    private String listShimukeChiMei;
    
    /** 備考 */      
    private String listBiko;

    @XmlElement(name = "listTodofukenCd")
    public String getListTodofukenCd() {
        return listTodofukenCd;
    }

    public void setListTodofukenCd(String listTodofukenCd) {
        this.listTodofukenCd = listTodofukenCd;
    }

    @XmlElement(name = "listTodofukenMei")
    public String getListTodofukenMei() {
        return listTodofukenMei;
    }

    public void setListTodofukenMei(String listTodofukenMei) {
        this.listTodofukenMei = listTodofukenMei;
    }

    @XmlElement(name = "listShimukeChiMeiCd")
    public String getListShimukeChiMeiCd() {
        return listShimukeChiMeiCd;
    }

    public void setListShimukeChiMeiCd(String listShimukeChiMeiCd) {
        this.listShimukeChiMeiCd = listShimukeChiMeiCd;
    }

    @XmlElement(name = "listShimukeChiMei")
    public String getListShimukeChiMei() {
        return listShimukeChiMei;
    }

    public void setShimukeChiMeiCd(String listShimukeChiMei) {
        this.listShimukeChiMei = listShimukeChiMei;
    }

    @XmlElement(name = "listBiko")
    public String getListBiko() {
        return listBiko;
    }

    public void setListBiko(String listBiko) {
        this.listBiko = listBiko;
    }
}
