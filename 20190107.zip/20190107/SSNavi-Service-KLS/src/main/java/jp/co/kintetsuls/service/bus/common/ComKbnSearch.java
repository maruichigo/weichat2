/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.service.bus.common;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
//import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import javax.annotation.Resource;
import jp.co.kintetsuls.common.util.KbnHold;
import jp.co.kintetsuls.dao.MsKbnDao;
import jp.co.kintetsuls.service.model.KbnDef;
import jp.co.kintetsuls.service.model.MsKbn;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.ssframe.dao.Dao;
import jp.co.sharedsys.service.bus.SSFrameBusBase;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

@Component("COM_KBN_SEARCH")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ComKbnSearch extends SSFrameBusBase {

    @Autowired(required = true)
    @Resource(shareable = true)
    protected Dao<MsKbn> dao;

    // Map<String, Object> map = null;
    @Override
    public void init(ServiceInterfaceBean serviceInterfaceBean) throws Exception {

    //    System.out.println("◆◆◆◆◆◆◆ init ◆◆◆◆◆◆◆[" + new Object() {}.getClass().getEnclosingClass().getName() + "]");
        super.init(serviceInterfaceBean);

        //ObjectMapper mapper = new ObjectMapper();
        //map = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
    }

    @Override
    public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        List<KbnDef> resultList = new ArrayList<>();

        // 検索条件パラメータ
        MsKbn prm = new MsKbn();
        prm.setSakujoFlg("0"); // 検索条件に「未削除」を設定

        // 区分を取得
        List<MsKbn> rl = ((MsKbnDao) dao).findByColumn(prm);

        System.out.println(rl.size() + "件");
        //     System.out.println("取得 [" + JSONUtil.makeJSONString(rl) + "]");

        // 区分をMapに格納
        Map<String, KbnDef> map = new HashMap<>();
        for (MsKbn res : rl) {

            // 区分Bean
            KbnDef bean = new KbnDef();
            bean.setKbnGroupCd(res.getKbnGroupCd());
            bean.setKbnGroupMei(res.getKbnGroupMei());
            bean.setKbnCd(res.getKbnCd());
            bean.setKbnMei(res.getKbnMei());
            bean.setKbnKey(res.getKbnKey());
            map.put(res.getKbnKey(), bean);
        }

        // 区分保持クラスにMapを格納
        KbnHold kbnHold = KbnHold.getInstance();
        kbnHold.setKbn(map);

        // デバッグ
        //printDebug(kbnHold);
        //      System.out.println("返却 [" + JSONUtil.makeJSONString(resultList) + "]");

        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
    }

    private void printDebug(KbnHold kbnHold) {
        Map<String, KbnDef> md = kbnHold.getKbnDebug();
        System.out.println("★★★★★★ 区分(debug) ★★★★★★");
        for (Entry<String, KbnDef> entry : md.entrySet()) {
            System.out.println("[" + entry.getKey() + "][" + entry.getValue().getKbnMei() + "]");
        }
        System.out.println("★★★★★★★★★★★★★★★★★★★★★★★★★");
    }

    @Override
    public String validateHeaderByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public String validateDetailByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public void setValidaterFactory() throws Exception {
    }

    @Override
    public String validateHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public String validateDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }

    @Override
    public void saveDetail(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }

    @Override
    public void confirm(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
    }

    @Override
    public String finalProc(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        return "";
    }
}
