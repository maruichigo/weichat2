package jp.co.kintetsuls.service.bus.user;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.ssframe.common.SSFrameMessage;
import jp.co.sharedsys.ssframe.model.User;


/**
 * ログイン処理クラス
 *
 * @author saihara
 */
@Component("USER_LOGIN")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class UserBusLogin extends UserBus {

	@Override
	public String validateHeaderByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
		return "";
	}

	@Override
	public String validateDetailByAnnotation(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
		return "";
	}

	@Override
	public String validateHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
		StringBuffer message = new StringBuffer();
		if (user.getUserCd() == null || user.getUserCd().length() == 0) {
			message.append(SSFrameMessage.MSG_USER_LOGIN_NOT_EXIST_USER_ID);
		}
		return message.toString();
	}

	@Override
	/** ログイン検索
     * @param serviceInterfaceBean リクエストパラメータ
	 * @throws Exception
	 */
	public void saveHeader(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
		// ユーザテーブルを検索
		// passwordをencrypt
//		this.user.setPassword(Cryptor.encryptDes(this.user.getPassword(), UserBus.PASSWD_ENCRYPT_KEY));
		Map<String, List<?>> ret = new HashMap<>();
//		No54 UserMasterメンテナンス 2016.1003 Kajiwara  => アカウントロック中はActiveInd=0
//		this.user.setActiveInd(1);
		List<User> result = userDao.findByColumn(this.user);
		if (result == null || result.size() == 0) {
			// ユーザIDまたはパスワードが違う
			serviceInterfaceBean.setMessage(SSFrameMessage.MSG_USER_LOGIN_WRONG_USER_ID_OR_PASSWD);
			serviceInterfaceBean.setJson(JSONUtil.makeJSONString(ret));
			return;
		}
		// カレントのユーザオブジェクト更新
		this.user = result.get(0);

		// ユーザグループの取得
/*		UserGroupXUser crt = new UserGroupXUser();
		crt.setUserId(this.user.getUserCd());
		List<UserGroupXUser> userGroupList = userGroupXUserDao.findByColumn(crt);
		if (userGroupList == null || userGroupList.size() == 0) {
			// 利用権限が無いユーザー（ユーザグループに属していない)
			serviceInterfaceBean.setMessage(SSFrameMessage.MSG_USER_LOGIN_FORBIDDEN);
			serviceInterfaceBean.setJson(JSONUtil.makeJSONString(ret));
			return;
		}
*/
		// データ参照権限グループの取得
/*		List<String> userGroups = new ArrayList<String>();
		for (UserGroupXUser u : userGroupList) {
			userGroups.add(u.getUserGroupCode());
		}
		List<UserGroupXDataGroup> dataGroupList = userGroupXDataGroupDao.findByUserGroup(userGroups);
		if (dataGroupList == null || dataGroupList.size() == 0) {
			// 利用権限が無いユーザー（ユーザグループに属していない)
			serviceInterfaceBean.setMessage(SSFrameMessage.MSG_USER_LOGIN_FORBIDDEN);
			serviceInterfaceBean.setJson(JSONUtil.makeJSONString(ret));
			return;
		}
*/
		ret.put("loginUser", Arrays.asList(this.user));

//		ret.put("userGroups", userGroupList);
//		ret.put("dataGroups", dataGroupList);

//		serviceInterfaceBean.setJson(JSONUtil.makeJSONString(userGroupList));
		serviceInterfaceBean.setJson(JSONUtil.makeJSONString(ret));
		return;
	}

	@Override
	public void saveDetail(ServiceInterfaceBean serviceInterfaceBean)
			throws Exception {
	}

	@Override
	public void confirm(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
	}

}