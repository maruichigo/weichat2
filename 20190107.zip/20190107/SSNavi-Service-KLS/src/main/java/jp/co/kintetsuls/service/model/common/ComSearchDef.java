package jp.co.kintetsuls.service.model.common;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import jp.co.sharedsys.service.constraintannotation.PrimaryKey;
import jp.co.sharedsys.service.model.BaseModel;

/** 
 * Sample model
 * @author sharedsys
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "comSearch")
public class ComSearchDef extends BaseModel implements Serializable{

    private static final long serialVersionUID = 8225066323266434396L;

    @PrimaryKey(columnName = "value")
    private String value;
    private String label;
    
    @XmlElement(name = "value")
    public String getValue() {
        return value;
    }
    public void setValue(String value) {
        this.value = value;
    }

    @XmlElement(name = "label")
    public String getLabel() {
        return label;
    }
    public void setLabel(String label) {
        this.label = label;
    }   
}
