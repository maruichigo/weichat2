package jp.co.kintetsuls.common.util;

import java.security.*;
import java.io.*;
import java.math.BigDecimal;
import jp.co.kintetsuls.service.model.common.TaxCalcDef;

/**
 * 税金計算ユーティリティ
 *
 */
public class TaxCalcUtil {

    // TODO　定数クラス 暫定対応
    final class CONST {

        /**
         * 税区分
         */
        final class ZeiKbn {

            /**
             * 内税
             */
            static final String UCHIZEI = "1";
            /**
             * 外税
             */
            static final String SOTOZEI = "2";
            /**
             * 非課税
             */
            static final String HIKAZEI = "3";
        }
    }

    /**
     * 税金額を計算する
     *
     * @param kingaku 金額
     * @param nebikiGaku 値引額
     * @param zeiKbn 税区分
     * @param zeiritsu 税率
     * @param menzeiFlg 免税フラグ
     * @return 税金計算結果
     * @throws GeneralSecurityException
     * @throws UnsupportedEncodingException
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public static TaxCalcDef calc(Integer kingaku, Integer nebikiGaku, String zeiKbn, BigDecimal zeiritsu, boolean menzeiFlg)
            throws GeneralSecurityException, UnsupportedEncodingException, IOException, ClassNotFoundException {

        TaxCalcDef rtn = new TaxCalcDef();

        System.out.println("---- 税金計算UTIL   パラメータ ----");
        System.out.println("金額       [" + kingaku + "]");
        System.out.println("値引額     [" + nebikiGaku + "]");
        System.out.println("税区分     [" + zeiKbn + "]");
        System.out.println("税率       [" + zeiritsu + "]");
        System.out.println("免税フラグ [" + menzeiFlg + "]");
        System.out.println("----------------------------------");

        // 免税以外 かつ 税区分がNULLの場合、初期値で返す
        if (!menzeiFlg && zeiKbn == null) {
            return rtn;
        }

        // 金額がNULLの場合、0を設定
        if (kingaku == null) {
            kingaku = 0;
        }
        // 値引額がNULLの場合、0を設定
        if (nebikiGaku == null) {
            nebikiGaku = 0;
        }

        // 税率がNULLの場合、0を設定
        if (zeiritsu == null) {
            zeiritsu = BigDecimal.ZERO;
        }

        BigDecimal trnZeiritsu = zeiritsu.divide(BigDecimal.valueOf(100)); // 税率を100で割る
        System.out.println("税率 [" + trnZeiritsu + "]");

        // ●免税フラグが True の場合
        if (menzeiFlg) {
            rtn.setKingaku(kingaku); // 金額

            rtn.setHiKazeiKingaku(kingaku + nebikiGaku); // 非課税金額 = 金額 + 値引額

        } else {
            // ●免税フラグが False の場合

            // 税区分の分岐
            switch (zeiKbn) {
                case CONST.ZeiKbn.HIKAZEI:
                    // ★非課税の場合
                    rtn.setKingaku(kingaku); // 金額

                    // 非課税額 = 金額 + 値引額
                    rtn.setHiKazeiKingaku(kingaku + nebikiGaku);
                    break;

                case CONST.ZeiKbn.SOTOZEI:
                    // ★外税の場合
                    rtn.setKingaku(kingaku); // 金額

                    // 課税対象額 = 金額 + 値引額
                    rtn.setKazeiTaishoGaku(kingaku + nebikiGaku);

                    // 消費税額 = (金額 + 値引額) × 税率　 ※小数点以下切り捨て
                    BigDecimal shohizeiGaku = BigDecimal.valueOf(kingaku + nebikiGaku).multiply(trnZeiritsu);
                    rtn.setShohizeiGaku(shohizeiGaku.setScale(0, BigDecimal.ROUND_DOWN).intValue());

                    break;

                case CONST.ZeiKbn.UCHIZEI:
                    // ★内税の場合
                    rtn.setKingaku(kingaku); // 金額

                    // 課税対象額 = (金額 + 値引額) ÷ (1 + 税率)   ※小数点以下切り上げ
                    BigDecimal kazeiTaishoGaku = BigDecimal.valueOf(kingaku + nebikiGaku).divide(BigDecimal.ONE.add(trnZeiritsu), 0, BigDecimal.ROUND_UP);
                    rtn.setKazeiTaishoGaku(kazeiTaishoGaku.intValue());

                    // 内税額 = 金額 + 値引額 - 課税対象額
                    rtn.setUchizeiKingaku(kingaku + nebikiGaku - rtn.getKazeiTaishoGaku());
                    break;

                default:
                    // 初期値で返す
                    return rtn;
            }
        }

        System.out.println("---- 税金計算UTIL   計算結果 ----");
        System.out.println("金額         [" + rtn.getKingaku() + "]");
        System.out.println("課税対象額   [" + rtn.getKazeiTaishoGaku() + "]");
        System.out.println("消費税額     [" + rtn.getShohizeiGaku() + "]");
        System.out.println("内税金額     [" + rtn.getUchizeiKingaku() + "]");
        System.out.println("非課税金額   [" + rtn.getHiKazeiKingaku() + "]");
        System.out.println("----------------------------------");

        return rtn;
    }

}
