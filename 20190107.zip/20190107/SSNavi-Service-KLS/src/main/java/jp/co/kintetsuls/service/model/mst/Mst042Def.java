package jp.co.kintetsuls.service.model.mst;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import jp.co.sharedsys.service.constraintannotation.PrimaryKey;
import jp.co.sharedsys.service.model.BaseModel;
import java.util.Date;

/** 
 * Sample model
 * @author sharedsys
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "mst042")
public class Mst042Def extends BaseModel implements Serializable{

    private static final long serialVersionUID = 8225066323266434396L;
    
    @PrimaryKey(columnName = "eigyoshoCd")
    private String eigyoshoCd;

    @PrimaryKey(columnName = "tekiyoKaishibi")
    private Date tekiyoKaishibi;
    private Date tekiyoShuryobi;
    private String tekiyoMei;
    private String column1;
    private String column2;
    private String column3;
    private String column4;
    private String column5;
    private String column6;

    private String yubinBango;
    private String jisCd;
    private String jusho1;
    private String jusho2;
    private String jusho3;
    private String jusho4;

    @XmlElement(name = "eigyoshoCd")
    public String getEigyoshoCd() {
        return eigyoshoCd;
    }
    public void setEigyoshoCd(String eigyoshoCd) {
        this.eigyoshoCd = eigyoshoCd;
    }

    @XmlElement(name = "tekiyoKaishibi")
    public Date getTekiyoKaishibi() {
        return tekiyoKaishibi;
    }
    public void setTekiyoKaishibi(Date tekiyoKaishibi) {
        this.tekiyoKaishibi = tekiyoKaishibi;
    }

    @XmlElement(name = "tekiyoShuryobi")
    public Date getTekiyoShuryobi() {
        return tekiyoShuryobi;
    }
    public void setTekiyoShuryobi(Date tekiyoShuryobi) {
        this.tekiyoShuryobi = tekiyoShuryobi;
    }

    @XmlElement(name = "tekiyoMei")
    public String getTekiyoMei() {
        return tekiyoMei;
    }
    public void setTekiyoMei(String tekiyoMei) {
        this.tekiyoMei = tekiyoMei;
    }
    
    @XmlElement(name = "column1")
    public String getColumn1() {
        return column1;
    }
    public void setColumn1(String column1) {
        this.column1 = column1;
    }

    @XmlElement(name = "column2")
    public String getColumn2() {
        return column2;
    }
    public void setColumn2(String column2) {
        this.column2 = column2;
    }
    
    @XmlElement(name = "column3")
    public String getColumn3() {
        return column3;
    }
    public void setColumn3(String column3) {
        this.column3 = column3;
    }

    @XmlElement(name = "column4")
    public String getColumn4() {
        return column4;
    }
    public void setColumn4(String column4) {
        this.column4 = column4;
    }

    @XmlElement(name = "column5")
    public String getColumn5() {
        return column5;
    }
    public void setColumn5(String column5) {
        this.column5 = column5;
    }
    
    @XmlElement(name = "column6")
    public String getColumn6() {
        return column6;
    }
    public void setColumn6(String column6) {
        this.column6 = column6;
    }
    
    // 住所コンポーネント
    @XmlElement(name = "yubinBango")
    public String getYubinBango() {
        return yubinBango;
    }
    public void setYubinBango(String yubinBango) {
        this.yubinBango = yubinBango;
    }

    @XmlElement(name = "jisCd")
    public String getJisCd() {
        return jisCd;
    }
    public void setJisCd(String jisCd) {
        this.jisCd = jisCd;
    }

    @XmlElement(name = "jusho1")
    public String getJusho1() {
        return jusho1;
    }
    public void setJusho1(String jusho1) {
        this.jusho1 = jusho1;
    }

    @XmlElement(name = "jusho2")
    public String getJusho2() {
        return jusho2;
    }
    public void setJusho2(String jusho2) {
        this.jusho2 = jusho2;
    }

    @XmlElement(name = "jusho3")
    public String getJusho3() {
        return jusho3;
    }
    public void setJusho3(String jusho3) {
        this.jusho3 = jusho3;
    }

    @XmlElement(name = "jusho4")
    public String getJusho4() {
        return jusho4;
    }
    public void setJusho4(String jusho4) {
        this.jusho4 = jusho4;
    }
}
