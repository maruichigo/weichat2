/*
 * 共通JSファイル 
 * ssNaviCommon.js 
 * Copyright (c) Shared System Inc.
 */
jQuery(document).ready(function() {  
    
    var tglflg=false;
    var valflg=false;
    //初回表示時はサブ検索条件を非表示に変更
     $("button[id$='cnd_btn_change']").hide();
    //1■サブ検索条件判定
    // サブ検索条件開閉
    $("a[id$='horizontal_search_sub_expression_toggler']").on("click", function(){
        if ( tglflg ) {
            $('div[id$="horizontal_search_sub_expression_header"] > span[class$="ui-panel-title"]').html('<span class="ui-panel-title" >サブ検索条件</span>');
            tglflg = false;
        } else {
            //1.1サブ検索条件が使用される場合に星マークを付与する処理判定開始
            // サブ検索条件項目のテキストボックスが使用されているか
            var inputText = $("div[id$='horizontal_search_sub_expression_content']").find("input[type='text']").map(function (index, el) {
                return $(this).val();
            });
            // サブ検索条件項目のチェックボックスが使用されているか
            var inputCheck = $("div[id$='horizontal_search_sub_expression_content']").find("input[type='checkbox']:checked").map(function (index, el) {
                return $(this);
            });
            // サブ検索条件項目のセレクトボックスが使用されているか
            var selectCheck = $("div[id$='horizontal_search_sub_expression_content']").find("option:selected").map(function (index, el) {
               return $(this).val(); 
            });
            
            
            for (i = 0; i < inputText.length; i++) {
                if ( inputText[i] != "" ) {
                    valflg=true;
                    break;
                }
            }
            
            for (i = 0; i < inputCheck.length; i++) {
                if ( inputCheck[i] ) {
                    valflg=true;
                    break;
                }
            }

            for (i = 0; i < selectCheck.length; i++) {
                if ( selectCheck[i] !== "" ) {
                    valflg=true;
                    break;
                }
            }            
            //1.2入力があればサブ検索の先頭に星マークを付与
            if ( valflg ){
                $('div[id$="horizontal_search_sub_expression_header"] > span[class$="ui-panel-title"]').html('<span class="ui-panel-title" style="background-image: url(resources/images/ico_ari.png) !important; background-repeat: no-repeat;" >&emsp;&emsp;サブ検索条件</span>');
            } else {
                $('div[id$="horizontal_search_sub_expression_header"] > span[class$="ui-panel-title"]').html('<span class="ui-panel-title" >サブ検索条件</span>');                
            }
            valflg=false;
            tglflg=true;
        }
    });
    
    //2■検索実行ボタン押下時
    $("button[id$='cnd_btn_search']").on("click",function(){
        //2.1サブ検索条件への対応
        if( $("div[id$='horizontal_search_sub_expression_content']").is(':visible') ){
            // サブ検索条件閉じる
            $("a[id$='horizontal_search_sub_expression_toggler']").click();
        }
        //2.2検索実行を隠し、検索条件のタグを変更不可にする
        $(this).hide();
        $("button[id$='cnd_btn_change']").show();
        // 検索条件の入力タグを変更不可にする
        $("div[id$='search_expression_main_content']").find(":input").addClass("ui-state-disabled").prop("disabled", true);
        $("div[class$='search_panel']").find(":input").addClass("ui-state-disabled").prop("disabled", true);
        
        $("div[class^='ui-selectonemenu']").addClass("ui-state-disabled").css("pointer-events","none");
        $("label[class^='ui-selectonemenu-label']").addClass("ui-state-disabled");
        
       // 検索条件変更ボタンのグレー化解除
        $("button[id$='cnd_btn_change']").prop("disabled", false).removeClass("ui-state-disabled");
        // confirm用ボタン
        $("button[id$='btnYes']").prop("disabled", false).removeClass("ui-state-disabled");
        $("button[id$='btnNo']").prop("disabled", false).removeClass("ui-state-disabled");

    });
    
    //3■検索条件変更ボタン押下時
    $("button[id$='cnd_btn_change']").on("click",function(){
       $("div[id$='search_expression_main_content']").find(":input").removeClass("ui-state-disabled").prop("disabled", false);
       $("div[id$='horizontal_search_expression_content']").find(":input").addClass("ui-state-disabled").prop("disabled", false);
       $("div[class^='ui-selectonemenu']").removeClass("ui-state-disabled").css("pointer-events","all");
       $("label[class^='ui-selectonemenu-label']").removeClass("ui-state-disabled");     
       $("div[class$='search_panel']").find(":input").removeClass("ui-state-disabled");
       $(this).hide();
       $("button[id$='cnd_btn_search']").show();
    }); 

    //3■クリアボタン押下時
    $("button[id$='cnd_btn_clear']").on("click",function(){
       $("button[id$='cnd_btn_change']").hide();
       $("button[id$='cnd_btn_search']").show();
    }); 
});
       
var chkConfirm = false;
var onclickVal;
var $breadLen;

// コンテキストメニュー行削除（パターン用）
function conMenu(){
    $("button[id$='delBtn']").click();
}

// 検索btn押下時のfilter制御
function filterLoad(){
    if($("input[id$='filterTgl:1']").prop("checked")) {
        filterToggle();
    } else {
        $("input[id$='filterTgl:1']").click();
    }
}

// 更新flgを立てる
function setUpdateFlg() {
    $('input[id$="updateFlg"]').attr('value',true);
    $('input[id$="MUpdateFlg"]').attr('value',true);
    $('input[id$="BUpdateFlg"]').attr('value',true);
    $('input[id$="HUpdateFlg"]').attr('value',true);
    chkConfirm = true;
}

// 更新flgを倒す
function resetUpdateFlg() {
    $('input[id$="updateFlg"]').attr('value',false);
    $('input[id$="MUpdateFlg"]').attr('value',false);
    $('input[id$="BUpdateFlg"]').attr('value',false);    
    $('input[id$="HUpdateFlg"]').attr('value',false);    
    chkConfirm = false;
}

// 画面フラグの再構築(クリアボタン用）
function doUpdateFlg() {
    if( chkConfirm ) {
       setUpdateFlg(); 
    }else{
       resetUpdateFlg();
    }
}

// クリアボタン押下時 main_section全体でなく検索条件のみupdateするため、検索条件変更ボタンを消す必要がある
function clearClicked(){
       $("button[id$='cnd_btn_change']").hide();
}
	

// confirmダイアログ起動
function doConfirm(args) {
    if ( args.updateFlg ) {
         PF(args.cfType).show();
        if (args.cfType == "header") {
            $('form[id$="menuForm"] button[id$="btnYes"]').removeAttr("onclick");
            $('form[id$="menuForm"] button[id$="btnYes"]').attr("onclick", "PF('header').hide();resetUpdateFlg();" + onclickVal);
            onclickVal = "";
            $('form[id$="menuForm"] button[id$="btnNo"]').removeAttr("onclick");
            $('form[id$="menuForm"] button[id$="btnNo"]').attr("onclick","PF('header').hide(); setUpdateFlg();");
            $('form[id$="menuForm"] button[id$="btnNo"]').attr("type", "button");
        }else{
            $('form[id^="cnd_"] button[id$="btnNo"]').removeAttr("onclick");
            $('form[id^="cnd_"] button[id$="btnNo"]').attr("onclick","PF('sch').hide(); setUpdateFlg();");
            $('form[id^="cnd_"] button[id$="btnNo"]').attr("type", "button");
        }
    }
}

function changeList(idx, args){
    data = args.itemList.list;
    tgtclm = args.targetColumn;
    $('select[id*=' + tgtclm + ']:eq(' + idx + ') > option').remove();
    var $select = $('select[id*=' + tgtclm + ']:eq(' + idx + ')'),
        $option;
    for (var i in data) {
        if ( data[i].value !== "") {
            $option = $('<option>')
                .val(data[i].value)
                .text(data[i].label);
            $select.append($option);
        }
    }
}

/** autocomplateの値を消す */
function auComboClearlabel(obj, type) {
   if (obj.val().length == 0) {
     $("[id$='"+ type+"']").val("");
   }
}

/**
 * ダブルコンボデータ同期用（直接入力用）
 * @param {type} obj
 * @param {type} type
 * @returns {undefined}
 */
function dbComboValCopy(obj, type) {
    $id=obj.attr("id");
    var iId = cutId(obj.attr("id"));

    if (obj.val().length < 2) {
        $('#id').find('.ui-autocomplete > input[type="text"]').focus();                                 
        $('#id').find('.ui-autocomplete > input[type="text"]').trigger("keydown", {which: 40});                                                
        $('#id').find('.ui-autocomplete > input[type="text"]').val("");
    }
    // clipbordにデータ設定
    var input = document.createElement('input');
    input.setAttribute('id', 'copyinput');
    document.body.appendChild(input);
    var spVal = obj.val().split(":");
    if (spVal.length > 0){
        input.value = spVal[0];
    } else {
        input.value = obj.val();
    }
    input.select();
    document.execCommand('copy');
    document.body.removeChild(input);

    // hiddenにペースト
    $('#id').find('.ui-autocomplete > input[type="hidden"]').val("");
    $('#id').find('.ui-autocomplete > input[type="hidden"]').val(obj.val());
    
    // textにペースト
    $('.ui-autocomplete > input[type="text"]').each(function() {
        var iobj = $(this);
        var oId = cutId($(this).attr("id"));
        if (iId == oId) {
            if( iobj.val() != obj.val() ){
                iobj.focus();    
                if(type=='OUT'){
                    iobj.trigger("keydown", {which: 40});                                                
                }
                iobj.val("");
                document.execCommand('paste');            
            }
        }
    }); 
    // 都道府県のテキストにフォーカスあてる。 
    if (type == "OUT") {
        obj.focus();
    }
    // clipbordのデータ破棄
    if (window.clipboardData){
        result = window.clipboardData.clearData( "Text" );
    }    
}

function cutId(val){
    var spVal = val.split(":");
    var reVal = "";
    for(var i=0; i<spVal.length; i++){
        // cnd_mst_000mst_100rpt
        if (spVal.length == 10){
            if(i==6 || i==9){
                // 何もしない
            }else{
                reVal += spVal[i] + ":";
            }
        } else if(spVal.length == 4){
            if(i==3){
                // 何もしない
            }else{
                reVal += spVal[i] + ":";
            }
        }
    }
    return reVal;
}


/**
 * ダブルコンボデータ同期用（dropbox選択用)
 * @param {type} type
 * @returns {undefined}
 */
function valCopy(type, area) {
    var i=0;
    var targetId = $(":focus").attr("id");
    var iId = cutId(targetId);
    var $con="";
    if(area == "cond") {
        $con=$("div[id$='search_expression_main_content']");
    } else {
        $con=$("div[class='ui-datatable-tablewrapper']");
    }      
    
    $con.find('.ui-autocomplete > input[type="text"]').each(function() {        
        var obj = $(this);
        var spOpj = obj.val().split(":");
        var oId = cutId($(this).attr("id"));
        if ( iId == oId ) {        
            if ( 5 == spOpj[0].length ) {
                if(type == "IN"){
                    obj.val("");
                }else{
                    dbComboValCopy(obj, "IN");
                }
            }
            if ( 2 == spOpj[0].length ) {
                dbComboValCopy(obj, "OUT");
            }
        }
        i++;
    });
}

// functionボタン：前画面へボタン処理
function backforward() {
    var array = $(".ui-breadcrumb li[role] a");
    var i = $(".ui-breadcrumb li[role]").length -2;
    $(array[i]).click();
    this.setScroll("top");
    return false;
}

/* 行追加＆行複製時の画面スクロール（引数[top or bottom]) */
function setScroll(type) {
    var s = "";
    if (type == "top") {
        s = 0;
    } else {
        s = $('body').scrollHeight || document.documentElement.scrollHeight;
    }
    $(window).scrollTop(s);
}

// checkBoxで選択された行のデータを保持
var $checkList="";
function handleComplete(args){
    $checkList = args.checkParam;
}
// コンテキストメニュー：選択行コピー
function cprow(){
    var input = document.createElement('input');
    input.setAttribute('id', 'copyinput');
    document.body.appendChild(input);
    input.value = $checkList;
    input.select();
    document.execCommand('copy');
    document.body.removeChild(input);            
}
