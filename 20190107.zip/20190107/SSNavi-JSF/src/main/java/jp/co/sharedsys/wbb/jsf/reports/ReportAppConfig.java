package jp.co.sharedsys.wbb.jsf.reports;

import java.io.Serializable;

public class ReportAppConfig implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 7633962368965612036L;
    private String title = "";
    private String description = "";
    private String directory = "";
    private String showInMenu = "";
    private String screenCode = "";
	
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDirectory() {
        return directory;
    }

    public void setDirectory(String directory) {
        this.directory = directory;
    }

    public String getShowInMenu() {
        return showInMenu;
    }

    public void setShowInMenu(String showInMenu) {
        this.showInMenu = showInMenu;
    }

    public boolean isAvailableInMenu(){
        return "true".equalsIgnoreCase(getShowInMenu());
    }

    public String getScreenCode() {
        return screenCode;
    }

    public void setScreenCode(String screenCode) {
        this.screenCode = screenCode;
    }
}
