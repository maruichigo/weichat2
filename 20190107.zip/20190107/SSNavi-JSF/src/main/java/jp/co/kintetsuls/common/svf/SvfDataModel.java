/*
 * SvfDataModel.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.common.svf;

/**
 * Svfで使用する情報のModelクラスです。
 *
 * @author sharedSystem
 */
public class SvfDataModel {
    
    private final String PTN_PDF = "PDF";
    private final String PTN_EXCEL = "Excel";
    private final String PTN_PREV = "PREV";
    private final String CONTEXT_TYPE_EXCEL = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    private final String CONTEXT_TYPE_PDF = "application/pdf"; 
    private final String CONTEXT_TYPE_PREV = "text/plain"; 

    private String chohyoId;            // 帳票ID
    private String yoshiId;             // 用紙ID
    private String shutsuryokuFileMei;  // 出力ファイル名
    private String fileFormat;          // ファイル形式　PDF、Excel
    private String dataFilePath;        // データファイル（CSV）のAPサーバー上でのフルパス
    private String cotextType;          // コンテキストタイプ
    private int adjustX;                // 印字位置の調整　(X座標をmm単位に指定) 
    private int adjustY;                // 印字位置の調整　(Y座標をmm単位に指定)
    private boolean prevFlag;           // プレビューするかどうか false:しない true:する
    private String prevFileUrl;         // プレビューするファイルのURL
    private String prevDocName;         // プレビュー用のドキュメント名
        
    public void SvfDataModel(){
        this.prevFlag = false;
        this.prevFileUrl = "";
        this.adjustX = 0;
        this.adjustY = 0;       
    }
        
    /**
     * @return the prevFlag
     */
    public boolean isPrevFlag() {
        return prevFlag;
    }

    /**
     * @param prevFlag the prevFlag to set
     */
    public void setPrevFlag(boolean prevFlag) {
        this.prevFlag = prevFlag;
    }

    /**
     * @return the chohyoId
     */
    public String getChohyoId() {
        return chohyoId;
    }

    /**
     * @param chohyoId the chohyoId to set
     */
    public void setChohyoId(String chohyoId) {
        this.chohyoId = chohyoId;
    }

    /**
     * @return the yoshiId
     */
    public String getYoshiId() {
        return yoshiId;
    }

    /**
     * @param yoshiId the yoshiId to set
     */
    public void setYoshiId(String yoshiId) {
        this.yoshiId = yoshiId;
    }

    /**
     * @return the shutsuryokuFileMei
     */
    public String getShutsuryokuFileMei() {
        return shutsuryokuFileMei;
    }

    /**
     * @param shutsuryokuFileMei the shutsuryokuFileMei to set
     */
    public void setShutsuryokuFileMei(String shutsuryokuFileMei) {
        this.shutsuryokuFileMei = shutsuryokuFileMei;
    }

    /**
     * @return the fileFormat
     */
    public String getFileFormat() {
        return fileFormat;
    }

    /**
     * @param fileFormat the fileFormat to set
     */
    public void setFileFormat(String fileFormat) {
        this.fileFormat = fileFormat;
    }

    /**
     * @return the dataFilePath
     */
    public String getDataFilePath() {
        return dataFilePath;
    }

    /**
     * @param dataFilePath the dataFilePath to set
     */
    public void setDataFilePath(String dataFilePath) {
        this.dataFilePath = dataFilePath;
    }

    /**
     * @return the adjustX
     */
    public int getAdjustX() {
        return adjustX;
    }

    /**
     * @param adjustX the adjustX to set
     */
    public void setAdjustX(int adjustX) {
        this.adjustX = adjustX;
    }

    /**
     * @return the adjustY
     */
    public int getAdjustY() {
        return adjustY;
    }

    /**
     * @param adjustY the adjustY to set
     */
    public void setAdjustY(int adjustY) {
        this.adjustY = adjustY;
    }

    /**
     * @return the PTN_EXCEL
     */
    public String getPTN_EXCEL() {
        return PTN_EXCEL;
    }

    /**
     * @return the PTN_PREV
     */
    public String getPTN_PREV() {
        return PTN_PREV;
    }

    /**
     * @return the PTN_PDF
     */
    public String getPTN_PDF() {
        return PTN_PDF;
    }

    /**
     * @return the CONTEXT_TYPE_EXCEL
     */
    public String getCONTEXT_TYPE_EXCEL() {
        return CONTEXT_TYPE_EXCEL;
    }

    /**
     * @return the CONTEXT_TYPE_PDF
     */
    public String getCONTEXT_TYPE_PDF() {
        return CONTEXT_TYPE_PDF;
    }

    /**
     * @return the CONTEXT_TYPE_PREV
     */
    public String getCONTEXT_TYPE_PREV() {
        return CONTEXT_TYPE_PREV;
    }

    /**
     * @return the prevFileUrl
     */
    public String getPrevFileUrl() {
        return prevFileUrl;
    }

    /**
     * @param prevFileUrl the prevFileUrl to set
     */
    public void setPrevFileUrl(String prevFileUrl) {
        this.prevFileUrl = prevFileUrl;
    }
    
    /**
     * @return the cotextType
     */
    public String getCotextType() {
        return cotextType;
    }

    /**
     * @param cotextType the cotextType to set
     */
    public void setCotextType(String cotextType) {
        this.cotextType = cotextType;
    }

    /**
     * @return the prevDocName
     */
    public String getPrevDocName() {
        return prevDocName;
    }

    /**
     * @param prevDocName the prevDocName to set
     */
    public void setPrevDocName(String prevDocName) {
        this.prevDocName = prevDocName;
    }
    
}
