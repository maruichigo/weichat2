package jp.co.sharedsys.bb;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ListMap implements Map {
    private Map map = new HashMap();
    public int size() {
        return map.size();
    }

    public void clear() {
        map.clear();
    }

    public boolean isEmpty() {
        return map.isEmpty();
    }

    public boolean containsKey(Object key) {
        return map.containsKey(key);
    }

    public boolean containsValue(Object value) {
        boolean b = false;
        for (Iterator ite = map.keySet().iterator();ite.hasNext();){
            Object key = ite.next();
            List list = (List) map.get(key);
            if (list.contains(value)){
                b = true;
                break;
            }
        }
        return b;
    }

    public Collection values() {
        List list = new ArrayList();
        for (Iterator ite = map.keySet().iterator();ite.hasNext();){
            Object key = ite.next();
            List value = (List) map.get(key);
            for (Iterator vit = value.iterator();vit.hasNext();){
                list.add(vit.next());
            }
        }
        return list;
    }

    public void putAll(Map t) {
        for (Iterator ite = t.keySet().iterator();ite.hasNext();){
            Object key = ite.next();
            Object value = null;
            if (t instanceof ListMap){
                value = ((ListMap)t).getList(key);
            } else {
                value = t.get(key);
            }
            if (value instanceof List){
                map.put(key,value);
            }else{
                List list = new ArrayList();
                list.add(value);
                map.put(key,list);
            }
        }
    }

    public Set entrySet() {
        return map.entrySet();
    }

    public Set keySet() {
        return map.keySet();
    }

    public Object get(Object key) {
        List list = null;
        if (map.get(key) == null){
            list = new ArrayList();
            list.add(null);
        }else{
            list = (List) map.get(key);
        }
        return list.get(0);
    }
	
    public Iterator valueIterator(Object key){
        List list = null;
        if (map.get(key) == null){
            list = new ArrayList();
        } else {
            list = (List) map.get(key);
        }
        return list.iterator();
    }	
	
    public Object remove(Object key) {
        return map.remove(key);
    }

    public Object put(Object key, Object value) {
        List list = null;
        if (map.get(key) == null){
            list = new ArrayList();
            list.add(value);
        } else {
            list = (List) map.get(key);
            list.add(value);
        }
        return map.put(key,list);
    }

    public Object getList(Object key){
        return map.get(key);
    }	
}
