package jp.co.sharedsys.wbb.jsf.api;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class YesterDayyyMMdd implements IAPI {

    public String getAPI() {
        return "@YesterDayyyMMdd@";
    }

    public String execute() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        return new SimpleDateFormat("yyMMdd").format(cal.getTime());
    }
}
