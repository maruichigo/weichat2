package jp.co.sharedsys.wbb.jsf.api;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateyyyyMMddHHmmss implements IAPI {

    public String getAPI() {
        return "@DateyyyyMMddHHmmss@";
    }

    public String execute() {
        return new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
    }
}
