package jp.co.sharedsys.wbb.jsf.reports;

import java.io.InputStream;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;

import jp.co.sharedsys.wbb.jsf.reports.ReportConst.ButtonPosition;
import jp.co.sharedsys.wbb.jsf.reports.checker.BlankChecker;
import jp.co.sharedsys.wbb.jsf.util.StringUtil;

public class ReportConfig implements Cloneable, Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = -8433803792998556927L;
    private String configDirectory = "";
    private String configFilePath = "";
    private String configFileName = "";
    private long lastModified = -1;

    private String title = "";
    private String shortTitle = "";
    private String description = "";
    private String style = "report";
    private String parameterPageTemplate = "";
    private String icon = "";
    private String reportType = "";
    private boolean showInMenu = false;
    private List<ReportCondition> conditions = new ArrayList<>();
    private List<ReportSql> sqls = new ArrayList<>();
    private String excelTemplate = "";
    private String csvTemplate = "";
    private String pageTemplate = "";
    private IParameterChecker paramChecker = new BlankChecker();
    private List<ReportButton> buttons = new ArrayList<>();
    private List formats = new ArrayList();
    private boolean ready = false;
    private String fileSaveScope = "private";
    private String screenCode;
    private String currentScreenCode;

    private boolean reloadCondition = false;

    private String filePathToSave = "";
    private String fileNameToSave = null;
    
    private String filterShow = null;

    // 2012.08.13 N.Ichijo Add
    private ReportModification modification = null;
    // 2012.12.27 S.Komaji Add
    private boolean nullZero = true;
    
    private boolean editFlg = false;
    
    private List<ReportColumn> contexts = null;
    
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
        this.setShortTitle(title);
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getReportType() {
        return reportType;
    }
    public void setReportType(String reportType) {
        this.reportType = reportType;
    }
    public boolean isShowInMenu() {
        return showInMenu;
    }
    public void setShowInMenu(boolean showInMenu) {
        this.showInMenu = showInMenu;
    }
    public List<ReportCondition> getConditions() {
        return conditions;
    }
    public void setConditions(List<ReportCondition> conditions) {
        this.conditions = conditions;
    }  
    public List<ReportSql> getSqls() {
        return sqls;
    }
    public void setSqls(List<ReportSql> sqls) {
        this.sqls = sqls;
    }
    public String getExcelTemplate() {
        return excelTemplate;
    }
    public void setExcelTemplate(String excelTemplate) {
        this.excelTemplate = excelTemplate;
    }
    public List<ReportButton> getButtons() {
        return buttons;
    }
    public void setButtons(List<ReportButton> buttons) {
        this.buttons = buttons;
    }
    public String getPageTemplate() {
        return pageTemplate;
    }
    public void setPageTemplate(String pageTemplate) {
        this.pageTemplate = pageTemplate;
    }
    public IParameterChecker getParamChecker() {
        return paramChecker;
    }
    public void setParamChecker(IParameterChecker paramChecker) {
        this.paramChecker = paramChecker;
    }
    public String getConfigFileName() {
        return configFileName;
    }
    public void setConfigFileName(String configFileName) {
        this.configFileName = configFileName;
    }
    public String getConfigFileSimpleName() {
        return configFileName.replaceAll("[.]","");
    }
    public long getLastModified() {
        return lastModified;
    }
    public void setLastModified(long lastModified) {
        this.lastModified = lastModified;
    }
    public Date getLastModifiedDateValue(){
        Date d = new Date();
        if (getLastModified() > 0){
            d.setTime(getLastModified());
        }
        return d;
    }
    public String getLastModifiedStringValue(){
        Date d = getLastModifiedDateValue();
        SimpleDateFormat f = new SimpleDateFormat("yyyy/MM/dd HH:mm");
        return f.format(d);
    }
    public String getConfigFilePath() {
        return configFilePath;
    }
    public void setConfigFilePath(String configFilePath) {
        this.configFilePath = configFilePath;
    }
    public String getConfigDirectory() {
        return configDirectory;
    }
    public void setConfigDirectory(String configDirectory) {
        this.configDirectory = configDirectory;
    }
    public List getFormats() {
        return formats;
    }
    public void setFormats(List formats) {
        this.formats = formats;
    }
    public boolean isReady() {
        return ready;
    }
    public void setReady(boolean ready) {
        this.ready = ready;
    }

    public String getConfigIdentifier(){
        return "report_result";
//		return this.getConfigDirectory() + "." + this.getConfigFileName();
    }
    public boolean isReloadCondition() {
        return reloadCondition;
    }
    public void setReloadCondition(boolean reloadCondition) {
        this.reloadCondition = reloadCondition;
    }
    public String getParameterPageTemplate() {
        return parameterPageTemplate;
    }
    public void setParameterPageTemplate(String parameterPageTemplate) {
        this.parameterPageTemplate = parameterPageTemplate;
    }
    public String getShortTitle() {
        return shortTitle;
    }
    public void setShortTitle(String shortTitle) {
        this.shortTitle = shortTitle;
    }
    public String getStyle() {
        return style;
    }
    public void setStyle(String style) {
        this.style = style;
    }

    public boolean hasParameterPage(){
        String p = this.getParameterPageTemplate();
        return p != null && p.length() > 0;
    }
    public String getIcon() {
        return icon;
    }
    public void setIcon(String icon) {
        this.icon = icon;
    }
    public String getFileSaveScope() {
        return fileSaveScope;
    }
    public void setFileSaveScope(String scope) {
        this.fileSaveScope = scope;
    }
    public String getFileNameToSave() {
        return fileNameToSave;
    }
    public void setFileNameToSave(String fileNameToSave) {
        this.fileNameToSave = fileNameToSave;
    }
    public String getFilePathToSave() {
        return filePathToSave;
    }
    public void setFilePathToSave(String filePathToSave) {
        this.filePathToSave = filePathToSave;
    }
    public String getCsvTemplate() {
        return csvTemplate;
    }
    public void setCsvTemplate(String csvTemplate) {
        this.csvTemplate = csvTemplate;
    }
    public ReportModification getModification() {
        return modification;
    }
    public void setModification(ReportModification modification) {
        this.modification = modification;
    }
    public String getModificationIdentifier(){
        return "report_result_exec";
//		return this.getConfigDirectory() + "." + this.getConfigFileName() + "_exec";
    }
    public boolean isNullZero() {
        return nullZero;
    }
    public void setNullZero(boolean nullZero) {
        this.nullZero = nullZero;
    }
    public boolean isEditFlg() {
        return editFlg;
    }
    public void setEditFlg(boolean editFlg) {
        this.editFlg = editFlg;
    }    
    public String getScreenCode() {
        return screenCode;
    }
    public void setScreenCode(String screenCode) {
        this.screenCode = screenCode;
    }

    public String getFilterShow() {
        return filterShow;
    }

    public void setFilterShow(String filterShow) {
        this.filterShow = filterShow;
    }
    
    public List<ReportColumn> getContexts() {
        return contexts;
    }

    public void setContexts() {
        this.contexts = modification.getContextList(null);
    }
    
    @Override
    public ReportConfig clone() {
        try {
            return (ReportConfig)super.clone();
        } catch (CloneNotSupportedException e) {
            throw new InternalError(e.toString());
        }
    }
    public String getCurrentScreenCode() {
        return currentScreenCode;
    }
    public void setCurrentScreenCode(String currentScreenCode) {
        this.currentScreenCode = currentScreenCode;
    }

    /**
     * 上部ボタンリストの取得
     * @return reportbutton list
     */
    public List<ReportButton> getTopButtons() {
        List<ReportButton> list = new ArrayList<ReportButton>();
        for (ReportButton btn : this.buttons) {
            if (StringUtils.equalsIgnoreCase(ButtonPosition.TOP, btn.getPosition())) {
                list.add(btn);
            }
        }
        return list;
    }

    /**
     * 下部ボタンリストの取得
     * @return reportbutton list
     */
    public List<ReportButton> getBottomButtons() {
        List<ReportButton> list = new ArrayList<ReportButton>();
        for (ReportButton btn : this.buttons) {
            if (StringUtils.isEmpty(btn.getPosition())) {
                list.add(btn);
            }
            if (StringUtils.equalsIgnoreCase(ButtonPosition.BOTTOM, btn.getPosition())) {
                list.add(btn);
            }
        }
        return list;
    }

    /**
     * 検索定義をReportModificationに変換
     * @return modification
     */
    public ReportModification convertCondListToModification() {
        ReportModification result = new ReportModification();
        for (ReportCondition cnd : conditions) {
            ReportColumn col = new ReportColumn();
            try {
                BeanUtils.copyProperties(col, cnd);
                result.addColumn(col);
            } catch (IllegalAccessException e) {
                // 何もしない
            } catch (InvocationTargetException e) {
                // 何もしない
            }
        }
        return result;
    }
    
    public List<ReportTable> getConditionLayout() {
        return getConditionLayoutProc("main");
    }
    public List<ReportTable> getSubConditionLayout() {
        return getConditionLayoutProc("sub");
    }
    /**
     * 検索項目レイアウト用のリストを取得。
     * @return reporttable list
     */
    private List<ReportTable> getConditionLayoutProc(String section) {
        List<ReportTable> tableList = new ArrayList<>();
        ReportTable table = new ReportTable();
        List<List<List<AbstractReportCondition>>> lines = new ArrayList<>();
        List<List<AbstractReportCondition>> line = new ArrayList<>();
        List<AbstractReportCondition> cols = new ArrayList<>();
        List<ReportCondition> list = new ArrayList<>();
        for (ReportCondition col : conditions) {
            if (StringUtils.isEmpty(col.getSection())) {
                col.setSection("main");
            }
            if (!section.equals(col.getSection())) {
                continue;
            }
            list.add(col);
        }
        
        for (int i = 0; i < list.size(); i++) {
            ReportCondition col = (ReportCondition) list.get(i);
            if (StringUtils.equals(ReportConst.ControlType.HIDDEN, col.getControlType())) {
                // HIDDENは無視
                if (i == list.size() - 1) {
                    lines.add(line);
                    table.setLines(lines);
                    tableList.add(table);
                    break;
                }
                continue ;
            }

            if ((StringUtils.equals("width", col.getPrevColPosition())
                    || StringUtils.equals("height", col.getPrevColPosition()))
                    && !line.isEmpty()) {
                cols.add(col);
            } else {
                cols = new ArrayList<>();
                cols.add(col);
                line.add(cols);
            }

            if (i == list.size() - 1) {
                lines.add(line);
                table.setLines(lines);
                tableList.add(table);
                break;
            }

            if (col.isTableEnd()) {
                lines.add(line);
                if (!col.isTableBreak()) {
                    table.setPosition("left");
                }
                table.setLines(lines);
                tableList.add(table);
                line = new ArrayList<>();
                lines = new ArrayList<>();
                table = new ReportTable();
                continue ;
            }

            if (col.isLineEnd()) {
                lines.add(line);
                line = new ArrayList<>();
            }
        }
        return tableList;
    }
    
    public String getFormId() {
//        return configDirectory + configFileName;
        // Faceletのrenderで、h:hidden のvalueに"."が含まれているとエラーになった為、"."を消す
        return configDirectory + configFileName.replaceAll("\\.", "");
    }
    
    /**
     * 画面定義と同ファイル名のJSファイル内容を返す
     * @param confDirectory config dir
     * @return dir string
     */
    public String getJsContent(String confDirectory) {
        String jsPath = getJsFilePathProc(confDirectory, this.configDirectory, this.configFileName.substring(0, 3), this.configFileName.replaceAll("[.]rpt", ".js"));
        String result = "";
        if (!jsPath.isEmpty()) {
            result = StringUtil.fileReadAll(jsPath);            
        }
        return result;
    }
    public String getJsFilePath(String confDirectory) {
        
        return getJsFilePathProc(confDirectory, this.configDirectory, this.configFileName.substring(0, 3), this.configFileName.replaceAll("[.]rpt", ".js"));
    }
    private String getJsFilePathProc(String confDirectory, String dirNm, String procId, String jsFile) {
        String result = "";
//		File file = new File(confDirectory + "/reports/" + dirNm + "/js/" + jsFile);
//		if (file.exists()) {
//			result = "reports/" + dirNm + "/js/" + jsFile;
//		}
    ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
    InputStream resourcesDir = externalContext.getResourceAsStream("/resources/js/" + procId + "/" + jsFile);
        if (resourcesDir != null) {
                result = procId + "/" +  jsFile;
        }
        return result;
    }      
}
