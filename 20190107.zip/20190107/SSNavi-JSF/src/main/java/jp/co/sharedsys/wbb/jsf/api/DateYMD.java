package jp.co.sharedsys.wbb.jsf.api;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateYMD implements IAPI {

    public String getAPI() {
        return "@DATE@";
    }

    public String execute() {
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        return format.format(new Date());
    }
}
