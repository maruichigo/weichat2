package jp.co.sharedsys.wbb.jsf.reports;

/**
 * 定数クラス
 * @author ohi
 */
public class ReportConst {

    /** ファクションコードのパラメータ名称 */
    public static final String PRM_NM_FUNC_CD = "functionCode";

    /** セッションに含まれる権限情報の格納先キー名 */
    public static final String SESSION_AUTH_CONF = "AUTHORITY_CONF";

    /** ボタンアクション関連 */
    public static final class F_EXECUTER {
        /** rptファイルの serviceタグ。 例:JohmonWebService */
        public static final String E_SERVICE_URL = "target_service_url";
        /** rptファイルのfunction-codeタグ。例:FUNC_PATTERNB_SEARCH */
        public static final String E_FUNCTION = "target_function";
		/** rptファイルのsql項目-nameタグ。例:sql1 */
        public static final String E_SERVICE_NAME = "target_service_name";
		/** rptファイルのbotton項目-actionタグ。例:CHKLIST_UPDATE */
        public static final String P_EDIT_MODE_NAME = "edit-name";
		/** 基本はEXECUTE だけど、CREATE_NEW などもある */
        public static final String P_EDIT_ACTIVITY_NAME = "act";
    }

    /** rptファイルのbotton項目-actionタグの内容。excelから選択(search以外) */
    public static final class F_BTNACT {
        public static final String INSERT = "INSERT";
        public static final String UPDATE = "UPDATE";
        public static final String CONFIRM = "CONFIRM";
        public static final String UNCONFIRM = "UNCONFIRM";
        public static final String CHKLIST_UPDATE = "CHKLIST_UPDATE";
        public static final String PAGER_PREV = "PAGER_PREV";
        public static final String PAGER_NEXT = "PAGER_NEXT";
        public static final String CREATE_NEW = "CREATE_NEW";
        public static final String SEARCH = "SEARCH";
    }

	/** 内部検索動作用 */
    public static final class F_ACTIVITY {
		public static final String EXECUTE = "EXECUTE";
	}

    public static final class F_SQLDATA {
		/** 画面から選択された行データ(現在はツリーのみ、、あとで統一) */
        public static final String SELECTED_NODE = "SELECTED_NODE";
    }

    /** 機能モード */
    public static final class EditMode {
        /** 検索 */
        public static final String SEARCH = "SEARCH";
        /** Tree用検索 */
        public static final String SEARCH_TREE = "SEARCH_TREE";
        /** サイドバー(履歴)用検索 */
        public static final String SEARCH_SIDEBAR = "SEARCH_SIDEBAR";
        /** 1件取得用検索 */
        public static final String SEARCH_ONE = "SEARCH_ONE";
        /** 登録 */
        public static final String INSERT = "INSERT";
        /** 更新 */
        public static final String UPDATE = "UPDATE";
        /** 削除 */
        public static final String DELETE = "DELETE";
        /** 明細更新 */
        public static final String DETAIL_UPDATE = "D_UPDATE";
        /** 明細削除 */
        public static final String DETAIL_DELETE = "D_DELETE";
        /** ブロック削除(受注専用) */
        public static final String BLOCK_DELETE = "B_DELETE";
        /** リスト更新(検索画面用) */
        public static final String LIST_UPDATE = "LIST_UPDATE";
        /** リスト編集更新(一覧編集画面用) */
        public static final String LIST_EDIT_UPDATE = "LIST_EDIT_UPDATE";
        /** ファイルダウンロード */
        public static final String DOWNLOAD = "DOWNLOAD";
//	No61 在庫属性一括変換 2016.09.14 Kajiwara
        /** 一括更新の画面へ進む */
        public static final String MULTI_UPDATE = "MULTI_UPDATE";
    }

    /** メッセージ関連 */
    public static final class Msg {
        public static final String SYSTEM_ERROR = "システムエラーが発生しました。システム管理者にご連絡ください。";
    }

    
    /** アクション関連 */
    public static final class Act {
        public static final String COPY = "COPY";
        public static final String EXECUTE = "EXECUTE";
        public static final String PAGER_PREV = "PAGER_PREV";
        public static final String PAGER_NEXT = "PAGER_NEXT";
    }

    /** モード関連 */
    public static final class Mode {
        /** 検索一覧画面 */
        public static final String CND_L = "CND_LIST";
        /** ヘッダと明細の登録・編集画面 */
        public static final String HD_EDIT = "HEADER_DETAIL_EDIT";
        /** 一覧画面 */
        public static final String L = "LIST";
//	No61 在庫属性一括変換 2016.09.14 Kajiwara
        /** 検索結果一括更新 */
        public static final String M_EDIT = "MULTI_DETAIL_EDIT";
    }

    /** コントロールタイプ */
    public static final class ControlType {
        public static final String LABEL          = "LABEL";
        public static final String TEXT           = "TEXT";
        public static final String TEXTAREA       = "TEXTAREA";
        public static final String RANGE          = "RANGE";
        public static final String SELECT         = "SELECT";
        public static final String SELECT_DYNAMIC = "SELECT_DYNAMIC";
        public static final String SELECT_MULTI   = "SELECT_MULTI";
        public static final String CHECKBOX       = "CHECKBOX";
        public static final String RADIO          = "RADIO";
        public static final String RADIO_DYNAMIC  = "RADIO_DYNAMIC";
        public static final String HIDDEN         = "HIDDEN";
        public static final String BUTTON         = "BUTTON";
        public static final String HEADER_ONLY    = "HEADER_ONLY";
        public static final String AUTOCOMPLETE   = "AUTOCOMPLETE";
        public static final String AUTOCOMPLETE_DYNAMIC = "AUTOCOMPLETE_DYNAMIC";
        public static final String AUTOCOMPLETE_MULTI   = "AUTOCOMPLETE_MULTI";
        public static final String CONTEXT   = "CONTEXT";
        public static final String DOUBLECOMBO_IN = "DOUBLECOMBO_IN";
        public static final String DOUBLECOMBO_OUT = "DOUBLECOMBO_OUT";
    }

    /** データタイプ */
    public static final class DataType {
        public static final String TEXT           = "TEXT";
        public static final String NUMBER         = "NUMBER";
        public static final String INT            = "INT";
        public static final String DECIMAL        = "DECIMAL";
        public static final String DATE           = "DATE";
        public static final String DATE_TIMESTAMP = "DATE_TIMESTAMP";
        public static final String EDIT           = "EDIT";
        public static final String TRANS          = "TRANS";
        public static final String PASTE          = "PASTE";
        public static final String POSTAL         = "POSTAL";
        public static final String HELP           = "HELP";
    }

    /** section */
    public static final class SECTION {
        public static final String LIST = "LIST";
        public static final String HISTORY = "HISTORY";
    }
    
    /**
     * applyTo関連
     * ※Mode.HD_EDITの場合のみ使用する。(ヘッダか明細かを判別するため)
     */
    public static final class ApplyTo {
        public static final String H = "header";
        public static final String D = "detail";
    }

    /** パラメータキー */
    public static final class ParameterKey {
        public static final String RPT_SEARCH = "rptSearch";
        public static final String PAGER_PREV = "isPagerPrev";
        public static final String PAGER_NEXT = "isPagerNext";
    }

    /** ボタンのポジション */
    public static final class ButtonPosition {
        /** 上部 */
        public static final String TOP = "top";
        /** 下部 */
        public static final String BOTTOM = "bottom";
    }

    enum DATA_CLASS {header, detail};

    enum DETAIL_MODE {line, group};
}
