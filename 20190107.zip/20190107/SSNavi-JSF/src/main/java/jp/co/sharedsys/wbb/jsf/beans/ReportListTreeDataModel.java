/*
 * ReportListTreeDataModel.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.beans;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import jp.co.sharedsys.wbb.jsf.component.LazyScrollDataModel;
import jp.co.sharedsys.wbb.jsf.reports.ReportConst;
import lombok.Data;
import org.primefaces.model.CheckboxTreeNode;
import org.primefaces.model.DefaultTreeNode;
import org.primefaces.model.SelectableDataModel;
import org.primefaces.model.SortMeta;
import org.primefaces.model.SortOrder;
import org.primefaces.model.TreeNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 検索結果一覧画面での行選択を有効にする為のModelクラスです。(TreeTable用)
 *
 * @author saihara
 */
@Data
// public class ReportListDataModel extends ListDataModel<Map<String, Object>>
// implements SelectableDataModel<Map<String, Object>> {
public class ReportListTreeDataModel extends LazyScrollDataModel<Map<String, Object>>
        implements SelectableDataModel<Map<String, Object>> {
    protected Logger logger = LoggerFactory.getLogger(this.getClass());

    private String reportColPk;
    private List<Map<String, Object>> datasource;
    private boolean firstLoad;
    private TreeNode root;
    private boolean isCheckbox;

    // 2018/9/25 s_furutani UPD oracleではカラム名は大文字として取得される
    private static final String SN_TREE_SELF_KEY = "SN_TREE_SELF_KEY";
    private static final String SN_TREE_PARENT_KEY = "SN_TREE_PARENT_KEY";

    public ReportListTreeDataModel() {
        root = new DefaultTreeNode(new HashMap<>(), null);
    }

    public void datareset() {
        datasource = new ArrayList<>();
        root = new DefaultTreeNode(new HashMap<>(), null);
    }

    public void init(List<Map<String, Object>> datas, String reportColPk, boolean isCheckbox) {
        // 根幹
        TreeNode rootnode = null;
        this.isCheckbox = isCheckbox;
        if (isCheckbox) {
            rootnode = new CheckboxTreeNode("Root Node", null);
        } else {
            rootnode = new DefaultTreeNode("Root Node", null);
        }

        // サブツリー作成
        Map<String, TreeNode> nodemap = new LinkedHashMap<>();
        int TreeNo = 0;
        // 処理ができなくなるまで再帰的に処理
        createNode(rootnode, datas, nodemap, TreeNo);
        // 呼び出し変数に格納
        this.root = rootnode;

        // ソート用？
        this.datasource = datas;
        this.reportColPk = reportColPk;
        this.firstLoad = true;
    }

    private void createNode(TreeNode rootnode, List<Map<String, Object>> datalist, Map<String, TreeNode> nodemap,
            int TreeNo) {

        List<Map<String, Object>> templist = new ArrayList<Map<String, Object>>();

        for (int i = 0; i < datalist.size(); i++) {
            Map<String, Object> map = datalist.get(i);
            String parentid = (String) map.get(SN_TREE_PARENT_KEY);
            String selfkey = (String) map.get(SN_TREE_SELF_KEY);
            if ("root".equals(parentid)) {
                // rootの場合、noderootに属する
                TreeNo++;
                map.put("TreeNo", TreeNo);
                TreeNode newnode = null;
                if (isCheckbox) {
                    newnode = new CheckboxTreeNode(map, rootnode);
                } else {
                    newnode = new DefaultTreeNode(map, rootnode);
                }
                nodemap.put(selfkey, newnode);
            } else if (nodemap.containsKey(parentid)) {
                // 親keyと同じidを持っている場合
                TreeNode node = nodemap.get(parentid);
                TreeNode newnode = null;
                if (isCheckbox) {
                    newnode = new CheckboxTreeNode(map, node);
                } else {
                    newnode = new DefaultTreeNode(map, node);
                }
                nodemap.put(selfkey, newnode);
            } else {
                // 親→子→孫の順で取得していない場合もあるので、再起処理データを用意
                templist.add(map);
            }
        }

        if (templist.size() != 0) {
            if (templist.size() < datalist.size()) {
                // 親を持っていない場合は永久ループなので一緒になったタイミングで終了
                createNode(rootnode, templist, nodemap, TreeNo);
            }
        }
    }

    @Override
    public Map<String, Object> getRowData(String key) {
        List<Map<String, Object>> columns = (List<Map<String, Object>>) getWrappedData();
        String id = String.valueOf(key);
        for (Map<String, Object> column : columns) {
            if (id.equals(column.get(reportColPk))) {
                return column;
            }
        }
        return null;
    }

    @Override
    public Object getRowKey(Map<String, Object> column) {
        return column.get(reportColPk);
    }

    @Override
    public List<Map<String, Object>> load(int first, int pageSize, String sortField, SortOrder sortOrder,
            Map<String, Object> filters) {
        List<Map<String, Object>> data = new ArrayList<>();

        // filter
        for (Map<String, Object> src : datasource) {
            boolean match = true;

            if (filters != null) {
                for (Iterator<String> it = filters.keySet().iterator(); it.hasNext();) {
                    try {
                        String filterProperty = it.next();
                        Object filterValue = filters.get(filterProperty);
                        String fieldValue = String.valueOf(src.get(filterProperty));

                        if (filterValue == null || fieldValue.contains(filterValue.toString())) {
                            match = true;
                        } else {
                            match = false;
                            break;
                        }
                    } catch (Exception e) {
                        match = false;
                    }
                }
            }

            if (match) {
                data.add(src);
            }
        }

        // sort
        if (sortField != null) {
            Collections.sort(data, new LazySorter(sortField, sortOrder));
        }

        // rowCount
        int dataSize = data.size();
        this.setRowCount(dataSize);

        // paginate
        if (dataSize > pageSize) {
            try {
                return data.subList(first, first + pageSize);
            } catch (IndexOutOfBoundsException e) {
                return data.subList(first, first + (dataSize % pageSize));
            }
        } else {
            return data;
        }
    }

    @Override
    public List<Map<String, Object>> load(int first, int pageSize, List<SortMeta> multiSortMeta,
            Map<String, Object> filters) {
        if (firstLoad) {
            this.preload(first, pageSize, multiSortMeta, filters);
            firstLoad = false;
        }
        if (multiSortMeta == null || multiSortMeta.isEmpty()) {
            return this.load(first, pageSize, null, SortOrder.UNSORTED, filters);
        } else {
            return this.load(first, pageSize, multiSortMeta.get(0).getSortField(), multiSortMeta.get(0).getSortOrder(),
                    filters);
        }
    }
    
    public List<Map<String, Object>> selectedmap(TreeNode[] selectedNodes){
        
        List<Map<String, Object>> selectdatas = new ArrayList<>();
        if (null != selectedNodes && 0 != selectedNodes.length){
            
            for(TreeNode node : selectedNodes) {
                Map<String,Object> map = (java.util.HashMap<String,Object>)node.getData();
                selectdatas.add(map);
            }

        }
        return selectdatas;
    }
}
