/*
 * AbstractReportOption.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.reports;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import lombok.Data;

/**
 *
 * @author saihara
 */
@Data
public abstract class AbstractReportOption implements Serializable {
    
    protected String label = "";
    protected String value = "";
    protected String connection = "";
    protected String templateFile = "";
    protected String optionCode = "";
    protected boolean checked = false;
    // 2012.11.08 for roots
    protected String matchKey = "";
    protected boolean duplicateValue = false;
    protected String service;
    protected String functionCode;
    protected String tableName;
    protected String serviceParameter;
    protected Map<String, String> relationValues = new HashMap<>();

    @Override
    public String toString() {
        return label;
    }
}
