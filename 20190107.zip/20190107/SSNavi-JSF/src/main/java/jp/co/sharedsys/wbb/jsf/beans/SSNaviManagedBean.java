/*
 * SSNaviManagedBean.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.beans;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lowagie.text.FontFactory;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import jp.co.kintetsuls.common.svf.PrintReport;
import jp.co.kintetsuls.common.svf.SvfDataModel;
import jp.co.sharedsys.common.methods.SSCommonUtil;
import jp.co.sharedsys.wbb.jsf.exception.LogicException;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;
import jp.co.sharedsys.wbb.jsf.external.general.ExternalServiceProperty;
import jp.co.sharedsys.wbb.jsf.process.AddressFinder;
import jp.co.sharedsys.wbb.jsf.process.ExternalServiceExecuter;
import jp.co.sharedsys.wbb.jsf.process.ExternalServiceExecuterForMultipart;
import jp.co.sharedsys.wbb.jsf.process.ExternalServiceParameterCheck;
import jp.co.sharedsys.wbb.jsf.process.OptionsFinder;
import jp.co.sharedsys.wbb.jsf.reports.AbstractReportCondition;
import jp.co.sharedsys.wbb.jsf.reports.AbstractReportOption;
import jp.co.sharedsys.wbb.jsf.reports.ReportButton;
import jp.co.sharedsys.wbb.jsf.reports.ReportColumn;
import jp.co.sharedsys.wbb.jsf.reports.ReportCondition;
import jp.co.sharedsys.wbb.jsf.reports.ReportConditionOption;
import jp.co.sharedsys.wbb.jsf.reports.ReportConfig;
import jp.co.sharedsys.wbb.jsf.reports.ReportConst;
import jp.co.sharedsys.wbb.jsf.reports.ReportListColumn;
import jp.co.sharedsys.wbb.jsf.reports.ReportPdfGroup;
import jp.co.sharedsys.wbb.jsf.reports.ReportSql;
import jp.co.sharedsys.wbb.jsf.util.bean.PagePropertiesBean;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.primefaces.component.api.UIData;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.context.RequestContext;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.event.MenuActionEvent;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.primefaces.model.TreeNode;
import org.primefaces.model.menu.MenuItem;


/**
 *
 * @author saihara
 */
@ManagedBean(name = "pageBean")
@ViewScoped
public class SSNaviManagedBean extends AbstractSSNaviManagedBean {

    @ManagedProperty(value = "#{menuBean}")
    private MenuBean menuBean;
    @ManagedProperty(value = "#{authConf}")
    private AuthorityConfBean authConf;
    @ManagedProperty(value = "#{ssconfig}")
    private JsfSatteliteApplicationBean ssconfig;
    @ManagedProperty(value = "#{breadCrumbBean}")
    private BreadCrumbBean breadCrumbBean;

    private ReportConfig config;
    private ReportConfig oldConfig;
    private Map<String, Object> defConds = new HashMap();
    // 共通メンテナンス画面用可変config
    private ReportConfig maintConfig;
    private ReportConfig oldMaintConfig;

    private String testText;
    private String r;
    private String isSearch;
    private String isTrans;

    // 現在のテンプレートXHTML
    private String curXhtml;
    // 現在の画面モード
    private String editMode;
    // 一時的に画面モードを変更した際に、現在の画面モードを保存する領域
    private String editModeTemp;
    // 一覧検索結果の格納先
    private Map<String, List<Map<String, Object>>> reportResult;
    private Map<String, List<Map<String, Object>>> oldReportResult;
    // 一覧結果のフィルタON/OFF管理
    private Map<String, List<Boolean>> visibleFilter;
    // 一覧検索結果をチェックボックスで選択可能とするためのクラス
    private ReportListDataModel selectableResult;
    private ReportListDataModel oldSelectableResult;
    // contextメニュー用リスト
    private List<ReportColumn> oldColumnList;
    private Map<String, List<Map<String, Object>>> contextResult;
    private ReportListDataModel contextMenuResult;
    private ReportListDataModel contextTableResult;    
    
    private ReportListDataModel columnLists;
    private Map<String, List> optionLists;
    // 一覧検索結果をチェックボックスで選択可能とするためのクラス
    private ReportListTreeDataModel selectableTreeResult;
    // 一覧検索結果をチェックボックスで選択可能とするためのクラス(複数定義用)
    private Map<String, ReportListDataModel> selectableResults;
    // 一覧検索結果をチェックボックスで選択可能とするためのクラス(Tree,複数定義用)
    private TreeNode[] selectedNodes;
    // 画面で選択された行の格納先
    private List<Map<String, Object>> selectReportResult;
    private List<Map<String, Object>> oldSelectReportResult;
    // 画面で選択された行の格納先(編集画面)
    private Map<String, List<Map<String, Object>>> selectEditReportResult;
    // サイドバー検索結果の格納先
    private Map<String, List<Map<String, Object>>> reportSidebarResult;
    // マスタ選択項目格納先
    private String selectMaster;
    private String oldSelectMaster;
    // マスタ選択項目設定格納先
    private AbstractReportCondition condMaster;
    // ソート順選択項目格納先
    private List<Map<String, Object>> sortVal;
    // ソート順、selectOneMenuで選択された格納先
    private String selectedSort;

    // 押下されたボタンのReportButton(f:setPropertyActionListenerで設定される)
    private ReportButton execButton;

    // 印刷実施ボタンの、selectOneMenuで選択された項目格納先
    private Map<String, ReportPdfGroup> selectedPdf;

    // 画面からアップロードされたファイルの格納先
    private List<File> uploadFiles;

    // 外部サービスのレスポンス情報格納先
    private Map<String, Object> externalAttribute;

    private Map<String, UIComponent> idBind;

    // 画面からの入力値を受け付けるプロパティ
    private Map<String, Map<String, Object>> values;
    private ArrayList<Object> objectValues;
    private int svfValuesIndex;
    private Map<String, Map<String, Object>> oldValues;
    private ArrayList<Object> oldObjectValues;
    private Map<String, Object> selectedLine;
    // Datatable内データ入力値受付の為のプロパティ
    private Map<String, List<Map<String, Object>>> listValues;
    // Dialog表示時に使用するパラメータ
    private List<Map<String, String>> dialogParams;

    // 外部サービス呼出の為のパラメータ
    private List<Map<String, Object>> targetServices;
    // アップロード用 アップロード方法格納先
    private String wayOfUpload;
    // 共通アップロード用　アップロードチェック件数格納先
    private Map<String,Object> uploadStatuses;
    // 共通アップロード用　アップロードファイル定義格納先
    private List<Map<String, Object>> uploadFileDef;
    // アップロードファイル名格納先
    private List<String> uploadFileName;
    // 共通アップロード用　ヘッダー名格納先
    private String headerName;
    // 共通アップロード用　一覧内変更情報格納先
    private String isChange;
    
    public SSNaviManagedBean() {
        parameterInitialization();
    }

    /**
     * ログイン後のトップページを表示する
     * @return menu page xhtml
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    public String init() throws SystemException {
        parameterInitialization();

        setTestText("is this show??");
        setCurXhtml("/contents/est/est021.xhtml");
        setConfig(new ReportConfig());
        getConfig().setScreenCode("top_page");
        return "main.xhtml";
    }

    /**
     * メニューから選択された時に、テンプレートを決定するメソッド
     * menubarで指定されるel式にReportIDを引数で渡す。
     * @param event ActionEvent
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    public void gotoNext(ActionEvent event) throws LogicException, SystemException {
        
        if ( getMenuBean().isMUpdateFlg() ) {
            // callbackで判定戻し（編集中）
            RequestContext context = RequestContext.getCurrentInstance();  
            context.addCallbackParam("updateFlg", getMenuBean().isMUpdateFlg() );
            context.addCallbackParam("cfType", "header");
        }else{
        // 項目初期化
            parameterInitialization();
			// 2018/10/10 Kobayashi 初期化項目を追加
			setDefConds(new HashMap<>());
			
            // 表示する画面のReportConfigを取得
            MenuItem menuItem = ((MenuActionEvent) event).getMenuItem();
            String repid = (String)menuItem.getParams().get("repid").get(0);
            ReportConfig tmpConfig = getSsconfig().getConfigs().get(repid);
            // init filter on/off
            tmpConfig.setFilterShow("filter_on");
            logger.debug("ReportID:" + repid);
            if (tmpConfig == null) {
                throw new LogicException("Specified report-id was not found.[" + repid + "]");
            }

            // 初回展開時にデフォルト検索結果を表示するためのコード
            if (!tmpConfig.isReady() || tmpConfig.isReloadCondition()){
                //if config status is not ready, there needs to create option values
                synchronized(tmpConfig){
                    this.generateOption(tmpConfig, getAuthConf());
					this.generateOptionByModification(tmpConfig, getAuthConf());
                    tmpConfig.setReady(true);
                }
            }

            setConfig(tmpConfig.clone());
			
			// 2018.10.04 Kobayashi 
		    // 単票系など、複数のapplyToが必要な画面にも対応するため、rptのsql定義分のvaluesを持つように修正
		    // 履歴まで実装後に問題なければコメントアウト削除します
		    // values.put(config.getSqls().get(0).getName(), new HashMap<>());
		    for (ReportSql sql : getConfig().getSqls()){
				getValues().put(sql.getName(), new HashMap<>());
			}
			
            for (ReportCondition cond : getConfig().getConditions()) {
				// 同じfor(each)で回している処理を統合 2018/10/11 Kobayashi
				 cond.setApplyTo(getConfig().getSqls().get(0).getName());
				
                getDefConds().put(cond.getName(), cond.getDefaultValue());
				
				// AUTOCOMPLETEラベル用データを初期化 2018/10/10 Kobayashi 
				cond.setLabelValue("");
			
				// SELECT MULTI の初期値を投入 2018/10/10 Kobayashi
				if (("MULTI").equals(cond.getDataType())) {
					String[] itemValue = new String[cond.getOptions().size()];
					int i = 0;
					for (AbstractReportOption option : cond.getOptions()) {
						if (option.isChecked()) {
							itemValue[i] = option.getValue();
							i++;
						}
					}
					cond.setItemValue(itemValue);
				} else if (("RADIO").equals(cond.getControlType())) {
					getValues().get(cond.getApplyTo()).put(cond.getName(), cond.getDefaultValue());
				}
				
            }

				
			// modificationの値も初期化 2018/10/10 Kobayashi
			for (ReportColumn column : getConfig().getModification().getColumns()){
				column.setLabelValue("");
				if ( ("MULTI").equals(column.getDataType()) ){
					String[] itemValue = new String[column.getOptions().size()];
					int i = 0;
					for (AbstractReportOption option : column.getOptions()) {
						if (option.isChecked()) {
							itemValue[i] = option.getValue();
							i++;
						}
					}
					column.setItemValue(itemValue);
				} else if (("RADIO").equals(column.getControlType())) {
					getValues().get(column.getApplyTo()).put(column.getName(), column.getDefaultValue());
				}
			}

// 遷移先テンプレートXHTML決定
            if (getCurXhtml() != null && getCurXhtml().equals(this.getConfig().getPageTemplate())) {
                // Datatableのリセット
                UIComponent pcomponent = FacesContext.getCurrentInstance().getViewRoot().findComponent(":main_section");
                if(pcomponent != null) {
                    resetDatatable(pcomponent.getChildren());
                }
            }
            setCurXhtml(this.getConfig().getPageTemplate());
            setSelectableTreeResult(new ReportListTreeDataModel());

            for (ReportCondition condition : getConfig().getConditions()) {
                // マスタ選択値の場合(マスタ選択領域があるもの用)
                if (condition.getName().equals("_TARGET_MASTER")) {
                    setCondMaster(condition);
                    break;
                }
            }

            try {
                // パンくず構築
                getBreadCrumbBean().gotoFirst(repid, this);
            } catch (IllegalAccessException | InvocationTargetException ex) {
                Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
                throw new SystemException(ex);
            }
            
            //初期値(defaultvalue)を代入する //初期化は別途必要.
            Map<String, Object> formvalues = new HashMap<>();
            config.getConditions().forEach((condition) -> {
                String condct = condition.getControlType();
                String conddt = condition.getDataType();
                if (null != condition.getDefaultValue()){
                switch (condct) { //除外するものはbreak
                    case "BUTTON":
                        break;
                    case "CHECKBOX":
                        if("MULTI".equals(condition.getDataType())){
                        } else {
                            String schk = condition.getDefaultValue();
                            if ("true".equals(schk) || "false".equals(schk)){
                                formvalues.put(condition.getName(), Boolean.valueOf(schk));
                            } else {
                                formvalues.put(condition.getName(), false);
                            }
                        }
                        break;
                    default:
                        formvalues.put(condition.getName(),condition.getDefaultValue());
                    }
                }
            });
            values.put(config.getSqls().get(0).getName(), formvalues);
            
            //画面作成時にコンテキストメニュー作成
            config.setContexts();
        }
    }

    /**
     * 共通メンテナンス画面がメニューから選択された時に実行されるメソッド
     * menubarで指定されるel式にReportIDを引数で渡す。
     * @param event ActionEvent
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    public void gotoNextForComMaint(ActionEvent event) throws LogicException, SystemException {
        // 項目初期化
        parameterInitialization();
        // 表示する画面のReportConfigを取得
        MenuItem menuItem = ((MenuActionEvent) event).getMenuItem();
        String repid = (String)menuItem.getParams().get("repid").get(0);
        ReportConfig tmpConfig = getSsconfig().getConfigs().get(repid);
        // init filter on/off
        tmpConfig.setFilterShow("filter_on");
//		if (parameter.getExternalParameter().get("scrcode") != null) {
//			config.setCurrentScreenCode((String)parameter.getExternalParameter().get("scrcode"));
//		}
//		ReportConfig config = (ReportConfig) ReportContext.getInstance(pkey).getConfigs().get((String) parameter.getExternalParameter().get("scrcode"));
//		if (config == null) {
//			config = (ReportConfig) ReportContext.getInstance(pkey).getConfigs().get(repid);
//		}
        logger.debug("ReportID:" + repid);
        if (tmpConfig == null) {
            throw new LogicException("Specified report-id was not found.[" + repid + "]");
        }

        // 初回展開時にデフォルト検索結果を表示するためのコード
//        if (!"true".equalsIgnoreCase(parameter.getParameter(P_SKIPOPTION))) {
	if (!tmpConfig.isReady() || tmpConfig.isReloadCondition()){
            //if config status is not ready, there needs to create option values
	    synchronized(tmpConfig){
                this.authConf.setUserId("admin");
                this.authConf.setUserGroup(Arrays.asList(new String[]{"TEST"}));
                this.generateOption(tmpConfig, getAuthConf());
                tmpConfig.setReady(true);
            }
        }
//		}

this.setConfig(tmpConfig.clone());
        // condition に applyToを入れておく(入力値の値取得に、applyToの設定が必要)
        getConfig().getConditions().forEach((condition) -> {
            condition.setApplyTo(getConfig().getSqls().get(0).getName());
        });

        getValues().put(getConfig().getSqls().get(0).getName(), new HashMap<>());
        // 遷移先テンプレートXHTML決定
        if (getCurXhtml() != null && getCurXhtml().equals(this.getConfig().getPageTemplate())) {
            // Datatableのリセット
            UIComponent pcomponent = FacesContext.getCurrentInstance().getViewRoot().findComponent(":main_section");
            if(pcomponent != null) {
                resetDatatable(pcomponent.getChildren());
            }
        }
        setCurXhtml(this.getConfig().getPageTemplate());
        setSelectableTreeResult(new ReportListTreeDataModel());

        for (ReportCondition condition : getConfig().getConditions()) {
            // マスタ選択値の場合(マスタ選択領域があるもの用)
            if (condition.getName().equals("_TARGET_MASTER")) {
                setCondMaster(condition);
                break;
            }
        }
        
        try {
            // パンくず構築
            getBreadCrumbBean().gotoFirst(repid, this);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw new SystemException(ex);
        }
     return;
    }

    private void resetDatatable(List<UIComponent> components) {
        components.forEach((component) -> {
            if (component instanceof DataTable) {
                ((DataTable)component).clearLazyCache();
                ((DataTable)component).clearInitialState();
                ((DataTable)component).reset();
                ((DataTable)component).resetValue();
                ((DataTable)component).restoreTableState();
//                component = null;
            } else {
                resetDatatable(component.getChildren());
            }
        });
    }

    public void transAtCrumb(ActionEvent event) throws SystemException {
        
        if ( getBreadCrumbBean().isBUpdateFlg() ) {
            // callbackで判定戻し（編集中）
            RequestContext context = RequestContext.getCurrentInstance();  
            context.addCallbackParam("updateFlg", getBreadCrumbBean().isBUpdateFlg() );
            context.addCallbackParam("cfType", "header");
            
        }else{        
        
            MenuItem menuItem = ((MenuActionEvent) event).getMenuItem();
            // 現在のプロパティ値を保存
            PagePropertiesBean curPageBean = new PagePropertiesBean();
            try {
                BeanUtils.copyProperties(curPageBean, this);
            } catch (IllegalAccessException | InvocationTargetException ex) {
                Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
                throw new SystemException(ex);
            }
            getBreadCrumbBean().getProperties().put(getConfig().getScreenCode(), curPageBean);

            if ("top_page".equals(menuItem.getParams().get("repid").get(0))) {
                init();
                getBreadCrumbBean().crumbRestructure("top_page", null);
            } else {
                PagePropertiesBean transPageBean = getBreadCrumbBean().getProperties().get(menuItem.getParams().get("repid").get(0));

                try {
                    BeanUtils.copyProperties(this, transPageBean);
                } catch (IllegalAccessException | InvocationTargetException ex) {
                    Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
                    throw new SystemException(ex);
                }
                getBreadCrumbBean().crumbRestructure(getConfig().getScreenCode(), null);
            }
            // 遷移した先のMenuItemを記憶
            getBreadCrumbBean().setCurrentMenuItem(menuItem);
        }
    }

    /**
     * ダイアログ画面クローズ時処理
     * @param event 
     */
    public void popClose(ActionEvent event){
        if ( getOldConfig() != null ){
            this.getConfig().getModification().getColumns().clear();   
            for(ReportColumn clm : getOldColumnList()) {
                this.getConfig().getModification().getColumns().add(clm);
            }
            getOldColumnList().clear();
            setOldConfig(new ReportConfig());
        }
        if( getOldMaintConfig() != null ) {
            this.getMaintConfig().getModification().getColumns().clear();   
            for(ReportColumn clm : getOldColumnList()) {
                this.getMaintConfig().getModification().getColumns().add(clm);
            }
            getOldColumnList().clear();
            setOldMaintConfig(new ReportConfig());
        }
    }    
    
    
    /**
     * 一覧検索画面で指定されたパラメータをもとに、外部サービスから
     * データ検索結果を取得する。
     * @param event
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    public void executeSearch(ActionEvent event) throws LogicException, SystemException, IllegalAccessException, InvocationTargetException {
         
        // 一覧検索画面は、1つ目のSql定義使用を強制する
        ReportSql targetDef = getConfig().getSqls().get(0);
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
        target.put(ExternalServiceExecuter.E_FUNCTION, targetDef.getFunctionCode());
        target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);

        Map<String, Object> sendParams = new HashMap<>();
        for(ReportCondition cond : getConfig().getConditions()) {
            if ( cond.getOptions().size() > 0 ) {
                // チェックボックス、セレクト、ラジオボタン以外の場合
                if (!cond.getControlType().equals("CHECKBOX") && !cond.getControlType().equals("RADIO") 
                        && !cond.getControlType().equals("RADIO_DYNAMIC") && !cond.getControlType().equals("SELECT_CHECKBOX_MENU") ) {
                    
                    for( String key : getValues().keySet() ){
                        if(getValues().get(key).get(cond.getName()) instanceof ReportConditionOption){
                            ReportConditionOption op = (ReportConditionOption)getValues().get(key).get(cond.getName());
                            if ( op != null) {
                                sendParams.put(cond.getName(), (String)op.getValue() );
                                getValues().get(key).replace(cond.getName(), (String)op.getValue());
                            }    
                        }else{
                            sendParams.put(cond.getName(), getValues().get(key).get(cond.getName()));
                        };
                    }
                } else {
                    // チェックボックス、ラジオボタンの場合
                    // 画面上でチェックされた内容を検索条件にセットする
                    if(cond.getItemValue() != null) {
                        sendParams.put(cond.getName(), cond.getItemValue());

                        for (AbstractReportOption op : cond.getOptions()) {
                            for (String itemValue : cond.getItemValue()) {
                                if (itemValue.equals(op.getValue())) {
                                    sendParams.put(cond.getName() + "_" +op.getValue(), itemValue);
                                    break;
                                }
                            }  
                        }  
                    } else {
                        sendParams.put(cond.getName(), "");
                    }
                }
            }else{
                if(cond.getDefaultValue() != null) {
                  sendParams.put(cond.getName(), cond.getDefaultValue());
                  
                }
            }
        }
        
        target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);
        this.getTargetServices().add(target);
        searchProcess();
//        List dummyResult = new ArrayList<LinkedHashMap<String, String>>();
//        LinkedHashMap<String, String> data = new LinkedHashMap<String, String>();
//        data.put("listTodofukenCd", "axis00");
//        data.put("listTodofukenMei", "001");
//        data.put("listShimukeChiMeiCd", "01");
//        data.put("listShimukeChiMei", "01");
//        data.put("listBiko", "EST021");
//
//        dummyResult.add(data);
//        data = new LinkedHashMap<String, String>();
//        data.put("listTodofukenCd", "axis00");
//        data.put("listTodofukenMei", "001");
//        data.put("listShimukeChiMeiCd", "01");
//        data.put("listShimukeChiMei", "01");
//        data.put("listBiko", "EST021");
//        dummyResult.add(data);
//
//        data = new LinkedHashMap<String, String>();
//        data.put("listTodofukenCd", "axis00");
//        data.put("listTodofukenMei", "001");
//        data.put("listShimukeChiMeiCd", "01");
//        data.put("listShimukeChiMei", "01");
//        data.put("listBiko", "EST021");
//        dummyResult.add(data);
//        this.getReportResult().put("detail", dummyResult);

        setSelectableResult(new ReportListDataModel(this.getReportResult().get(targetDef.getName()), this.colPkName()));
       
        // 一覧のOption項目を取得する
        synchronized(this.getConfig()){
            this.generateOptionByModification(this.getConfig(), getAuthConf());
            this.getConfig().setReady(true);
        }
        setOldConfig(getConfig());
        setOldColumnList(new ArrayList<>());
        for(ReportColumn clm : this.getConfig().getModification().getColumns()) {
            getOldColumnList().add(clm);
        }
            
        // contextメニュー作成
        if( getConfig().getSqls().size() > 1) {
            this.executeContextSearch(1);   
        }
        
        // 明細行用
        getConfig().getSqls().forEach((sql) -> {
            // 入力値受付パラメータに、検索結果をdeep copy
            getListValues().put(sql.getName(), new ArrayList<>(getReportResult().get(sql.getName())));
        });        
    }
    
    /**
     * 一覧検索画面で指定されたパラメータをもとに、外部サービスから
     * データ検索結果を取得する。TreeTable用データバインド
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException
     **/
    public void executeSearchForTree() throws LogicException, SystemException {
        executeSearchForTree(true);
    }
    /**
     * 一覧検索画面で指定されたパラメータをもとに、外部サービスから
     * データ検索結果を取得する。Tree,またはTreeTable用データバインド
     *
     * 親子関係は、"sn_tree_parent_key","sn_tree_parent_id"と言うフィールドを判定基準とし、親データには
     * "sn_tree_parent_id"に"root"の文字が入っているものとする。
     * 子データには、"sn_tree_parent_key"に指定された項目の、親のデータが入る。
     * @param isCheckbox is checkbox use
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    public void executeSearchForTree(boolean isCheckbox) throws LogicException, SystemException {
        // 一覧検索画面は、1つ目のSql定義使用を強制する
        ReportSql targetDef = getConfig().getSqls().get(0);
        callSql(0,ReportConst.EditMode.SEARCH, targetDef.getFunctionCode());
        getSelectableTreeResult().init(this.getReportResult().get(targetDef.getName()), this.colPkName(), isCheckbox);
    }

    /**
     * 一覧検索画面で指定されたパラメータをもとに、外部サービスから
     * データ検索結果を取得する。(共通メンテナンス用)
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    public void executeSearchForMaint() throws Exception {

        //confirm検知
        if ( getConfig().getModification().isUpdateFlg() ) {
            // callbackで判定戻し（編集中）
            RequestContext context = RequestContext.getCurrentInstance();  
            context.addCallbackParam("updateFlg", getConfig().getModification().isUpdateFlg());
            context.addCallbackParam("cfType", "sch");
        }else{
            // 検索処理
            ReportSql targetDef = getConfig().getSqls().get(0);
            Map<String, Object> target = new HashMap<>();
            this.setTargetServices(new ArrayList<>());
            target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
            target.put(ExternalServiceExecuter.E_FUNCTION, targetDef.getFunctionCode());
            target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
            target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
            target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);

            Map<String, Object> sendParams = new HashMap<>();
            for(ReportCondition cond : getMaintConfig().getConditions()) {
                if( cond.getDefaultValue() != null ) {
                    if ( cond.getOptions().size() > 0 ) {
                        for( String key : getValues().keySet() ){
                            //optionsを優先取得し、optionではない場合はvalueitを取得させる対応
                            if(getValues().get(key).get(cond.getName()) instanceof ReportConditionOption){
                                ReportConditionOption op = (ReportConditionOption)getValues().get(key).get(cond.getName());
                                if ( op != null) {
                                    sendParams.put(cond.getName(), (String)op.getValue() );
                                    getValues().get(key).replace(cond.getName(), (String)op.getValue());
                                }    
                            }else{
                                sendParams.put(cond.getName(), getValues().get(key).get(cond.getName()));
                            };                            
                        }
                    }else{
                        sendParams.put(cond.getName(), cond.getDefaultValue());
                    }
                }
            }

            sendParams.put("TABLE_NAME", this.getSelectMaster());
            if (getSortVal().size() > 0) {
                sendParams.put("searchOption", getSortVal().size()==1 ? getSortVal().get(0).get("VALUE") : this.getSelectedSort() );
            }
            
            target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);
            this.getTargetServices().add(target);

            searchProcess();

            setSelectableResult(new ReportListDataModel(this.getReportResult().get(targetDef.getName()), this.colPkName(this.getMaintConfig())));
            // contextメニュー作成
            this.executeContextSearch(0);
            // 一覧部リスト作成
            this.executeMainListSearch();
           
            //
            setOldMaintConfig(getMaintConfig());
            setOldColumnList(new ArrayList<>());
            for(ReportColumn clm : this.getMaintConfig().getModification().getColumns()) {
                getOldColumnList().add(clm);
            }

            // 明細行用
            getMaintConfig().getSqls().forEach((sql) -> {
                // 入力値受付パラメータに、検索結果をdeep copy
                getListValues().put(sql.getName(), new ArrayList<>(getReportResult().get(sql.getName())));
            });              
        }
    }

    /**
     * データ検索時に、コンテキストメニュー取得する。（共通メンテナンス用）
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException
     */
    public void executeContextSearch(int type) throws LogicException, SystemException, IllegalAccessException, InvocationTargetException, InvocationTargetException {
  
        ReportSql targetDef = getConfig().getSqls().get(type);
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
        target.put(ExternalServiceExecuter.E_FUNCTION, "SS_COM_MAINT_SUB_SEARCH");
        target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);

        // 画面構成リストのバックアップ
        if (getSelectableResult() != null) {
            setOldSelectableResult(new ReportListDataModel(null, null));
            BeanUtils.copyProperties(getOldSelectableResult(), getSelectableResult());
        }
        
        setOldReportResult(new HashMap<>());
        for ( String key : getReportResult().keySet() ){
            getOldReportResult().put(key, getReportResult().get(key) );
        }        
        // 画面チェック状態のバックアップ
        setOldSelectReportResult(new ArrayList<>());
        if ( getSelectReportResult() != null ) {
            for ( Map map : getSelectReportResult() ) {
                getOldSelectReportResult().add( map );
            }
        }
        // 画面からの入力値のバックアップ
        setOldValues(new HashMap<>());
        if ( getValues() != null ) {
            for ( String key : getValues().keySet() ) {
                if (!values.get(key).isEmpty()) {
                    getOldValues().put(key, getValues().get(key));
                }
            }            
        }

        setOldObjectValues(new ArrayList<>());
        if ( getObjectValues() != null ) {
            for (int i=0; i<objectValues.size(); i++) {
                    oldObjectValues.add(objectValues.get(i));
            }            
        }
        
        Map<String, Object> sendParams = new HashMap<>();
        String tableName = "";
        if( !this.selectMaster.isEmpty() ) {
            tableName = this.getSelectMaster();
        } else {
            tableName = targetDef.getTableName();
        }
        sendParams.put("TABLE_NAME", tableName);
//        sendParams.put(tableName, this.selectReportResult);        
        target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);

        this.getTargetServices().add(target);
        
        searchProcess();
        
        setContextMenuResult(new ReportListDataModel(this.getReportResult().get(targetDef.getName()), this.colPkName()));        
        
        this.resetList();
    }
    
    /**
     * 検索実行時に、一覧部用Listを作成する
     * @throws LogicException
     * @throws SystemException
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     * @throws InvocationTargetException 
     */
    public void executeMainListSearch() throws LogicException, SystemException, IllegalAccessException, InvocationTargetException, InvocationTargetException {

        setOldReportResult(new HashMap<>());
        for ( String key : getReportResult().keySet() ){
            getOldReportResult().put(key, getReportResult().get(key) );
        }        
        
        ReportSql targetDef = getConfig().getSqls().get(0);
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
        target.put(ExternalServiceExecuter.E_FUNCTION, "SS_COM_MAINT_COLUMN_LIST");
        target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);

        // 画面構成リストのバックアップ
        if (getSelectableResult() != null) {
            setOldSelectableResult(new ReportListDataModel(null, null));
            BeanUtils.copyProperties(getOldSelectableResult(), getSelectableResult());
        }
        
        setOldReportResult(new HashMap<>());
        for ( String key : getReportResult().keySet() ){
            getOldReportResult().put(key, getReportResult().get(key) );
        }        
        // 画面チェック状態のバックアップ
        if ( getSelectReportResult() != null ) {
            setOldSelectReportResult(new ArrayList<>());
            for ( Map map : getSelectReportResult() ) {
                getOldSelectReportResult().add( map );
            }
        }
        // 画面からの入力値のバックアップ
        setOldValues(new HashMap<>());
        for ( String key : getValues().keySet() ) {
            if (!values.get(key).isEmpty()) {
                getOldValues().put(key, getValues().get(key));
            }
        }
        
        setOldObjectValues(new ArrayList<>());
        if ( getObjectValues() != null ) {
            for (int i=0; i<objectValues.size(); i++) {
                    oldObjectValues.add(objectValues.get(i));
            }            
        }
        
        Map<String, Object> sendParams = new HashMap<>();
        sendParams.put("TABLE_NAME", this.getSelectMaster());
        target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);
        this.getTargetServices().add(target);
        searchProcess();
        setColumnLists(new ReportListDataModel(this.getReportResult().get(targetDef.getName()), this.colPkName(this.getMaintConfig())));
        setOptionLists((Map<String, List>) new HashMap());

        for ( Map map : getColumnLists().getDatasource() ) {
            
            targetDef = getConfig().getSqls().get(0);
            target = new HashMap<>();
            this.setTargetServices(new ArrayList<>());
            target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
            target.put(ExternalServiceExecuter.E_FUNCTION, (String)map.get("searchOptFuncName") + "_COMLIST");
            target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
            target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
            target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);
            sendParams = new HashMap<>();
            sendParams.put("TABLE_NAME", (String)map.get("tableName"));
            target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);
            this.getTargetServices().add(target);
            searchProcess();

            List<AbstractReportOption> list = new ArrayList();
            for (Map op : this.getReportResult().get(targetDef.getName()) ) {
                AbstractReportOption option = new ReportConditionOption();            
                option.setValue( (String)op.get("VALUE") );
                option.setLabel( (String)op.get("LABEL") );
                String[] spVal = op.get("LABEL").toString().split(":");
                if( spVal.length > 1) {
                    option.getRelationValues().put( "pval", spVal[1] );
                } else {
                    option.getRelationValues().put( "pval", (String)op.get("LABEL") );
                }
                
                list.add(option);
            }
            getOptionLists().put( (String)map.get("columnName"), list );
        }
         
//        setSelectForSearch();
        setSelectForTable();
        this.resetList();    
    }    
    
    /**
     * Tableから取得したリストをカラム情報に渡す(一覧用）
     */
    private void setSelectForTable() {
        int i = 0;
        for( ReportColumn clm : this.getMaintConfig().getModification().getColumns() ) {
            if ( getOptionLists().get(clm.getName()) != null ) {
                this.getMaintConfig().getModification().getColumns().get(i).setOptions(getOptionLists().get(clm.getName()) );
            }
            i++;
        }        
    }

    /**
     * 検索条件から取得したリストをカラム情報に渡す(一覧用）
     * 親切機能なので敢えて未導入
     */
//    @Deprecated
    private void setSelectForSearch() {
        for ( ReportCondition rc : this.getMaintConfig().getConditions() ) {
            if ( rc.getControlType().equals( ReportConst.ControlType.SELECT )) {
                int i = 0;
                for( ReportColumn clm : this.getMaintConfig().getModification().getColumns() ) {
                    if ( clm.getName().equals( rc.getName() )) {
                        this.getMaintConfig().getModification().getColumns().get(i).setOptions( rc.getOptions() );
                    }
                    i++;
                }
            }
        }
    }
    
    /**
     * コンテキストメニューにセットされているSQLを実行する。
     * @param sql
     * @throws LogicException
     * @throws SystemException 
     */
    public void executeSql(String sql) throws LogicException, SystemException, IllegalAccessException, InvocationTargetException {

        ReportSql targetDef = getConfig().getSqls().get(0);
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
        target.put(ExternalServiceExecuter.E_FUNCTION, "SS_COM_MAINT_EXEC_SQL");
        target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);
        
        Map<String, Object> sendParams = new HashMap<>();
        String tableName = "";
        if( this.getSelectMaster() != null) {
            tableName = this.getSelectMaster();
        } else {
            tableName = targetDef.getTableName();
        }
        sendParams.put("TABLE_NAME", tableName);
        sendParams.put(ExternalServiceExecuter.E_SQL, createWhereSection(sql));
        target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);
        
        this.getTargetServices().add(target);
        
        searchProcess();
        
        // ReportColumnの組み立て
        createcolumn (this.getReportResult().get(targetDef.getName()) , "");     
        setContextTableResult(new ReportListDataModel(this.getReportResult().get(targetDef.getName()), this.colPkName()));
        
    }    
    
    /**
     * order by句を動的作成する
     * @param sql
     * @return 
     */
    private String createWhereSection(String sql) {
        String[] col = null;
        String upSql = StringUtils.upperCase(sql);
        if ( upSql.contains( "WHERE" ) ) {
            col = upSql.split("WHERE");
        } else {
            return upSql;
        }
        
        String val = "";
        // バインド対象個所があれば処理する
        if (sql.contains("=")) {
            String[] str = col[1].split("=");

            String key = StringUtils.deleteWhitespace(str[0]);
            if ( str[1].contains("?") ) {
                for(Map map : getSelectReportResult()) {
                    if ( map.keySet().contains( key.toLowerCase() ) ) {
                        val = (String)map.get(StringUtils.deleteWhitespace(str[0].toLowerCase()));
                    } else {
                        // SQLに想定外のカラムが設定されている
                    }
                }
            }
        }
        return StringUtils.swapCase(upSql.replace("?", val) );        
    }
        
    /**
     * 画面上で選択されたアップロードデータタイプに対し、外部サービスから
     * 一時保存データ検索結果を取得する。(共通アップロード用)
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    public void executeSearchForUploadTmp() throws LogicException, SystemException {
        ReportSql targetDef = getConfig().getSqls().get(0);
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
        target.put(ExternalServiceExecuter.E_FUNCTION, targetDef.getFunctionCode());
        target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);

        Map<String, Object> sendParams = new HashMap<>();
        sendParams.put("selectMaster", this.getSelectMaster());
        target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);
        this.getTargetServices().add(target);

        searchProcess();
        createUploadColumns();

        setSelectableResult(new ReportListDataModel(this.getReportResult().get(targetDef.getName()), this.colPkName(this.getMaintConfig())));
    }

    /**
     * 一覧検索画面で指定されたパラメータをもとに、外部サービスから
     * データ検索結果を取得する。(共通レポート用)
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    public void executeSearchForReport() throws LogicException, SystemException {
        ReportSql targetDef = getConfig().getSqls().get(0);
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
        target.put(ExternalServiceExecuter.E_FUNCTION, targetDef.getFunctionCode());
        target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);

        Map<String, Object> sendParams = new HashMap<>();
        sendParams.put("TABLE_NAME", this.getSelectMaster());
        target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);
        this.getTargetServices().add(target);

        searchProcess();

        // ReportColumnの組み立て
        List<Map<String, Object>> reportMaps = this.getReportResult().get(targetDef.getName());
        if (reportMaps != null && !reportMaps.isEmpty()) {
            this.getMaintConfig().getModification().getColumns().clear();
            int i = 1;
            for (String key : reportMaps.get(0).keySet()) {
                ReportColumn column = new ReportColumn();
                column.setName(key);
                column.setDisplayName(key);
                column.setTableName(this.getSelectMaster());
                column.setControlType("LABEL");
                column.setReadonly(true);
                column.setSortIndex(i++);
                column.setEnable(true);
                column.setVisible(true);

                this.getMaintConfig().getModification().getColumns().add(column);
            }
        }

        FontFactory.defaultEncoding = "UniJIS-UCS2-H";

        setSelectableResult(new ReportListDataModel(this.getReportResult().get(targetDef.getName()), this.colPkName(this.getMaintConfig())));
    }
    private void searchProcess() throws LogicException, SystemException {

        ExternalServiceExecuter exec = new ExternalServiceExecuter();
        try {
        this.authConf.setUserId("admin");
        this.authConf.setUserGroup(Arrays.asList(new String[]{"TEST"}));
            exec.onService(this);
        } catch (LogicException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        } catch (SystemException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        }
    }
    private void executeProcess() throws LogicException, SystemException {
        ExternalServiceParameterCheck paramCheck = new ExternalServiceParameterCheck();
        paramCheck.onService(this);

        ExternalServiceExecuter exec = new ExternalServiceExecuter();
        exec.onService(this);
    }

    /**
     * 入力された検索条件を全てクリア
     */
    public void clear() {
        this.targetClear(this.getConfig());
    }
    /**
     * 入力された検索条件を全てクリア(config指定,共通メンテナンスで使用)
     * @param tconfig
     */
    public void targetClear(ReportConfig tconfig) {
        for(ReportCondition cond: tconfig.getConditions()) {
            if ( getDefConds().containsKey(cond.getName()) ) {
                cond.setDefaultValue((String)getDefConds().get(cond.getName()) );
				// Autocomplete,Selectの選択内容を初期化
				getValues().get(cond.getApplyTo()).replace(cond.getName(), cond.getDefaultValue());
				cond.setLabelValue("");
				// CheckBox Multi の選択内容を初期化
				if (("MULTI").equals(cond.getDataType())) {
					String[] itemValue = new String[cond.getOptions().size()];
					int i = 0;
					for (AbstractReportOption option : cond.getOptions()) {
						if (option.isChecked()) {
							itemValue[i] = option.getValue();
							i++;
						}
					}
					cond.setItemValue(itemValue);
				}
			}
        }
    }
	
	/**
	 * 個別画面対応: conditionでない項目のクリア処理
	 * @param applyTo 
	 */
    public void modificationClear(String applyTo) {
		ReportConfig tconfig = this.getConfig();
		for (ReportColumn column: tconfig.getModification().getColumns()) {
			if (applyTo.equals(column.getApplyTo())){
				getValues().get(applyTo).replace(column.getName(), column.getDefaultValue());
				column.setLabelValue("");
			}
        }
    }

	/**
     * TextBoxでのEnterキー押下時イベントなど
     * @param action
     * @param service
     * @param functionCode
     * @param name
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException
     */
    public void executeEvent(String action, String service, String functionCode, String name) throws LogicException, SystemException {
        // 一覧検索画面は、1つ目のSql定義使用を強制する
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, service);
        target.put(ExternalServiceExecuter.E_FUNCTION, functionCode);
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, action);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);
        this.getTargetServices().add(target);

        try {
            executeProcess();
        } catch (LogicException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        } catch (SystemException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        }

        // TODO 現ページをパンくず情報をもとに取り直す
//        selectableResult = new ReportListDataModel(this.reportResult.get(targetDef.getName()), this.colPkName());
        
    }
    /**
     * メンテナンス画面のボタン押下時イベント
     * @param action
     * @param service
     * @param functionCode
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException
     */
    public void executeEventForMaint(String action, String service, String functionCode) throws LogicException, SystemException {
        // 一覧検索画面は、1つ目のSql定義使用を強制する
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, service);
        target.put(ExternalServiceExecuter.E_FUNCTION, functionCode);
        //target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.LIST_EDIT_UPDATE);
        if ("SS_COM_MAINT_DELETE".equals(functionCode)) {
            target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.DETAIL_DELETE);
        } else {
            target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.LIST_EDIT_UPDATE);
        }
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);
        target.put(ExternalServiceExecuter.E_TARGET_CONFIG, getMaintConfig());
        this.getTargetServices().add(target);

        try {
            ExternalServiceParameterCheck paramCheck = new ExternalServiceParameterCheck();
            paramCheck.onService(this);

            Map<String, Object> sendParams = new HashMap<>();
            sendParams.put("TABLE_NAME", this.getSelectMaster());
            sendParams.put(this.getSelectMaster(), getSelectableResult().getDatasource());
            target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);

            ExternalServiceExecuter exec = new ExternalServiceExecuter();
            exec.onService(this);
        } catch (LogicException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        } catch (SystemException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        }

        // TODO 現ページをパンくず情報をもとに取り直す
//        selectableResult = new ReportListDataModel(this.reportResult.get(targetDef.getName()), this.colPkName());
        
    }
    /**
     * メンテナンス画面のボタン押下時イベント(CHKLIST_UPDATE)
     * @param action
     * @param service
     * @param functionCode
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException
     */
    public void executeChkListEventForMaint(String action, String service, String functionCode) throws LogicException, SystemException {
        // 一覧検索画面は、1つ目のSql定義使用を強制する
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, service);
        target.put(ExternalServiceExecuter.E_FUNCTION, functionCode);
//        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.LIST_UPDATE);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);
        target.put(ExternalServiceExecuter.E_TARGET_CONFIG, getMaintConfig());
        if ("SS_COM_MAINT_DELETE".equals(functionCode)) {
            target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.DETAIL_DELETE);
        } else {
            target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.LIST_UPDATE);
        }
        this.getTargetServices().add(target);

        try {
            ExternalServiceParameterCheck paramCheck = new ExternalServiceParameterCheck();
            paramCheck.onService(this);

            Map<String, Object> sendParams = new HashMap<>();
            sendParams.put("TABLE_NAME", this.getSelectMaster());
            sendParams.put(this.getSelectMaster(), this.getSelectReportResult());
            target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);

            ExternalServiceExecuter exec = new ExternalServiceExecuter();
            exec.onService(this);
        } catch (LogicException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        } catch (SystemException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        }
        
        // TODO 現ページをパンくず情報をもとに取り直す
//        selectableResult = new ReportListDataModel(this.reportResult.get(SSNaviManagedBean.class.getName()), this.colPkName());
        // selectReportResultの初期化
        setSelectReportResult(new ArrayList<>());
                }
            
    /**
     * 共通アップロード画面のボタン押下時イベント(CHKLIST_UPDATE)
     * @param action
     * @param service
     * @param functionCode
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException
     */
    public void executeChkListEventForUpload(String action, String service, String functionCode) throws LogicException, SystemException {
        
        if (getSelectReportResult() == null || getSelectReportResult().isEmpty()) {
            FacesContext.getCurrentInstance().addMessage("messages", new FacesMessage(FacesMessage.SEVERITY_ERROR, "エラー", "アップロードデータが選択されていません。"));
            return;
        }
        // 一覧検索画面は、1つ目のSql定義使用を強制する
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, service);
        target.put(ExternalServiceExecuter.E_FUNCTION, functionCode);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);
        target.put(ExternalServiceExecuter.E_TARGET_CONFIG, getMaintConfig());
        if ("SS_COM_MAINT_DELETE".equals(functionCode)) {
            target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.DETAIL_DELETE);
        } else {
            target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.LIST_UPDATE);
        }
        this.getTargetServices().add(target);

        try {
            ExternalServiceParameterCheck paramCheck = new ExternalServiceParameterCheck();
            paramCheck.onService(this);

            Map<String, Object> sendParams = new HashMap<>();
            sendParams.put("TABLE_NAME", this.getSelectMaster()); // ここで、MS_UPLOAD_FILE_TEIGIのUPLOAD_KINO_CDが入ってきている
            sendParams.put(this.getSelectMaster(), this.getSelectReportResult());
            target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);

            ExternalServiceExecuter exec = new ExternalServiceExecuter();
            exec.onService(this);
        } catch (LogicException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        } catch (SystemException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        }
        if (functionCode.equals("SS_COM_UPLOAD_SAVE")){
            FacesContext.getCurrentInstance().addMessage("messages", new FacesMessage(FacesMessage.SEVERITY_INFO, "登録完了", "登録処理が完了しました"));
        } else if(functionCode.equals("SS_COM_UPLOAD_VALIDATE")) {
            FacesContext.getCurrentInstance().addMessage("messages", new FacesMessage(FacesMessage.SEVERITY_INFO, "バリデーションチェック完了", "バリデーションチェック処理が完了しました"));            
        }
        System.out.println("サービス側メッセージ　： " + this.getExternalAttribute().get("exec-res-msg-attribute-name"));
        
        // selectReportResultの初期化
        setSelectReportResult(new ArrayList<>());

        // 登録ボタン押下時は、登録結果メッセージ表示、件数/一覧の更新を行う⇒バリデーションチェック時も再検索実施
        if (functionCode.equals("SS_COM_UPLOAD_SAVE")){
            boolean isErr =false;
            // 登録処理成功時はアップロードファイルを登録済フォルダに移動
            if (!isErr) {
                try {
                    Path sourcePath = Paths.get(""); // 取得元
                    Path targetPath = Paths.get(""); // 完了ファイル格納先
                    Files.move(sourcePath, targetPath);
                } catch (IOException ex) {
                    Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            
            functionCode = "SS_COM_UPLOAD_FILE_PROC_EX";
            service = "JohmonWebServiceForMultipart";

            target = new HashMap<>();
            this.setTargetServices(new ArrayList<>());
            target.put(ExternalServiceExecuter.E_SERVICE_URL, service);
            target.put(ExternalServiceExecuter.E_FUNCTION, functionCode);
            target.put(ExternalServiceExecuter.E_SERVICE_NAME, this.getConfig().getSqls().get(0).getName());
            target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.LIST_UPDATE);
            target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);
            Map<String, Object> params = new HashMap<>();
            params.put("wayOfUpload", this.getWayOfUpload());
            params.put("selectMaster", this.getSelectMaster());
            params.put("fileName", this.getUploadFileName());
            target.put(ExternalServiceExecuter.P_SEND_PARAMETER, params);
            this.getTargetServices().add(target);

            try {
                ExternalServiceExecuterForMultipart exec = new ExternalServiceExecuterForMultipart();
                exec.onService(this);
            } catch (LogicException ex) {
                Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
                throw ex;
            } catch (SystemException ex) {
                Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
                throw ex;
            }
            // 取得したLISTの最後を別変数に格納し、LISTの該当箇所を削除する。(件数表示領域更新)
            setUploadStatuses(this.getReportResult().get(this.getConfig().getSqls().get(0).getName()).get(this.getReportResult().get(this.getConfig().getSqls().get(0).getName()).size() - 1));
            this.getReportResult().get(this.getConfig().getSqls().get(0).getName()).remove(this.getReportResult().get(this.getConfig().getSqls().get(0).getName()).size() - 1);
            createUploadColumns();

            List<Map<String, Object>> selectedRowParam;
            selectedRowParam = this.getReportResult().get(this.getConfig().getSqls().get(0).getName());

            Iterator<Map<String, Object>> ite = selectedRowParam.iterator();
            while(ite.hasNext()){
                Map<String, Object> i = ite.next();
                if (!i.get("TOROKU_STATUS").equals("4") && !i.get("TOROKU_STATUS").equals("5")) {
                    getSelectReportResult().add(i);
                }
            }
            setIsChange("false");
            setSelectableResult(new ReportListDataModel(this.getReportResult().get(this.getConfig().getSqls().get(0).getName()), this.colPkName(this.getMaintConfig())));
        }
    }
    
    /**
     * 共通アップロード画面　ファンクションボタン活性/非活性変更
     */
    public void chkCellChange(String cngFlg){
        setIsChange(cngFlg);
        String compName = ":btn_" + this.getConfig().getFormId() + ":chklistvalidate_" + this.getConfig().getFormId();
        UIComponent component = FacesContext.getCurrentInstance().getViewRoot().findComponent(compName);
        if(component != null) {
            disableAll(component.getChildren(), true);
        }
    }
    
    /**
     * チェックイベント（ON）
     * @param event
     * @throws IllegalAccessException
     * @throws InvocationTargetException 
     */
    public void check(SelectEvent event) throws IllegalAccessException, InvocationTargetException {
        System.out.print(event.getObject());
        String checkparam = "";
        for(Map map : this.getSelectReportResult()){
            if ( !checkparam.isEmpty() ) {
                checkparam += "\r\n";
            }
            checkparam += map.values();
        }
        RequestContext context = RequestContext.getCurrentInstance();
        context.addCallbackParam("checkParam", checkparam);
    }
    
    /**
     * 共通アップロード　行選択イベント拡張版
     */
    public void onRowSelectEx(SelectEvent event) {
        System.out.println("--- row select ---");
        System.out.print(event.getObject());
        getSelectReportResult().clear();
        getSelectReportResult().add((Map<String, Object>)event.getObject());

//        this.selectReportResult.add((Map)event.getObject());
        System.out.println("check: " + this.getSelectReportResult());
    }

    /**
     * チェックイベント（OFF）
     * @param event 
     */
    public void uncheck(UnselectEvent event) {
        String checkparam = "";
        for(Map map : this.getSelectReportResult()){
            if ( !checkparam.isEmpty() ) {
                checkparam += "\r\n";
            }
            checkparam += map.values();
        }
        RequestContext context = RequestContext.getCurrentInstance();  
        context.addCallbackParam("checkParam", checkparam);        
    }

    /**
     * modification内定義ボタンの押下時イベントなど(共通系）
     * @param act action
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    public void executeButton(String act) throws Exception {
        if ("INSERT".equals(getExecButton().getAction())) {
            execInsert();
        }        
       
        if ( "SEARCH".equals(act) ) {
            getConfig().getSqls().get(0).setFunctionCode("SEARCH_SAVED");
//            executeSearch();
        }

        //　顧客集約設定マスタ用として追加
        if ("CHKLIST_UPDATE".equals(act)) {
            if (getSelectReportResult() == null || getSelectReportResult().isEmpty()) {
                FacesContext.getCurrentInstance().addMessage("messages", new FacesMessage(FacesMessage.SEVERITY_ERROR, "エラー", "削除対象行が選択されていません。"));
                return;
            }
            this.executeChkListEventForMaint(act, "JohmonWebService", "SS_COM_MAINT_DELETE");
        }
        //　顧客集約設定マスタ用として追加
        if ("CHKLIST_UPDATE".equals(act)) {
            if (getSelectReportResult() == null || getSelectReportResult().isEmpty()) {
                FacesContext.getCurrentInstance().addMessage("messages", new FacesMessage(FacesMessage.SEVERITY_ERROR, "エラー", "削除対象行が選択されていません。"));
                return;
            }
            this.executeChkListEventForMaint(act, "JohmonWebService", "SS_COM_MAINT_DELETE");
        }
        if ("SS_COMMON_UPLOAD".equals(act)) {
            String sCode = "SS_COMMON_UPLOAD";
            String xhtml = "/templates/common_d_upload.xhtml";
            String title = "共通アップロード";
            this.forward(sCode, xhtml, title);
            // 初期選択させたいマスタ名を選択
            if (getCondMaster() != null){
                for (ReportCondition condition : getConfig().getConditions()) {
                    // マスタ選択値の場合(マスタ選択領域があるもの用)
                    if (condition.getName().equals("_TARGET_MASTER")) {
                        setCondMaster(condition);
                        break;
                    }
                }
                // 動作確認のため、他画面からのパラメータとして、仮で代理店マスタ(reseller_master)としている
                //　selectMaster = "reseller_master";
            }
        }
    }

    /**
     * 画面遷移
     * @param sCode
     * @param xhtml
     * @param title
     * @throws Exception
     */
    public void forward(String sCode, String xhtml, String title) throws Exception {

        PagePropertiesBean oldPageParam = new PagePropertiesBean();
        BeanUtils.copyProperties(oldPageParam, this);

        parameterInitialization();

        setConfig(new ReportConfig());
        getConfig().setPageTemplate(xhtml);
        getConfig().setScreenCode(sCode);
        getConfig().setTitle(title);
        setCurXhtml(this.getConfig().getPageTemplate());

        getBreadCrumbBean().gotoNext(this, oldPageParam);
        }
    
    protected void execInsert() throws LogicException, SystemException {
        // パンくず用プロパティ値コピー
        PagePropertiesBean oldPageParam = new PagePropertiesBean();
        try {
            BeanUtils.copyProperties(oldPageParam, this);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw new SystemException(ex);
        }

        // 項目初期化
        parameterInitialization();
        // 表示する画面のReportConfigを取得
        String screenCode = getExecButton().getRptDir() + "." + getExecButton().getRptFile();
//	ReportConfig tmpConfig = ssconfig.getConfigs().get(screenCode);
        ReportConfig tmpConfig = getSsconfig().getConfigs().get(getSsconfig().getScreenCodesMap().get(screenCode));
        logger.debug("ReportID:" + screenCode);
        if (tmpConfig == null) {
                throw new LogicException("Specified report-id was not found.[" + screenCode + "]");
        }

        // 初回展開時にデフォルト検索結果を表示するためのコード
//        if (!"true".equalsIgnoreCase(parameter.getParameter(P_SKIPOPTION))) {
            if (!tmpConfig.isReady() || tmpConfig.isReloadCondition()){
                //if config status is not ready, there needs to create option values
                synchronized(tmpConfig){
                    this.generateOptionByModification(tmpConfig, getAuthConf());
                    tmpConfig.setReady(true);
                }
            }
//	}


this.setConfig(tmpConfig);
        // editMode設定（INSERT)
        setEditMode("INSERT");
        // 画面項目初期化
        for (ReportSql sql : getConfig().getSqls()) {
            this.getReportResult().put(sql.getName(), new ArrayList<>());
            this.getReportResult().get(sql.getName()).add(new HashMap<>());
            this.getValues().put(sql.getName(), new HashMap<>());
        }

        // 遷移先テンプレートXHTML決定
        setCurXhtml(this.getConfig().getPageTemplate());

        try {
            // パンくず構築
            getBreadCrumbBean().gotoNext(this, oldPageParam);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw new SystemException(ex);
        }
    }

    /**
     * 一覧検索画面の行ボタン押下時の動作
     * @param transferRptDir reportDir
     * @param transferRptFile reportFile
     * @param dataType dataType
     * @throws LogicException logic
     * @throws SystemException  system
     */
    public void executeEditTrans(String transferRptDir, String transferRptFile, String dataType) throws LogicException, SystemException {
        // パンくず用プロパティ値コピー
        PagePropertiesBean oldPageParam = new PagePropertiesBean();
        try {
            BeanUtils.copyProperties(oldPageParam, this);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw new SystemException(ex);
        }

        // 遷移先データ取得のためのキー項目組み立て(1件のみ実行) datatable用
        Map<String, Object> tmpValues = new HashMap<>();
        if (!selectReportResult.isEmpty()) {
            if (selectReportResult.size() >1){
                FacesContext.getCurrentInstance().addMessage("messages", new FacesMessage(FacesMessage.SEVERITY_ERROR, "エラー", "選択は一か所のみ行ってください。"));
                return;
            }
            List<ReportColumn> pklist = this.getConfig().getModification().getPkList();
            for (ReportColumn rcol : pklist){
                tmpValues.put(rcol.getName(), selectReportResult.get(0).get(rcol.getName()));
            }
        }
        // 遷移先データ取得のためのキー項目組み立て(1件のみ実行) datatree用
        List<Map<String, Object>> selectdatas = selectableTreeResult.selectedmap(selectedNodes);
        if (selectdatas.size() != 0){
            List<ReportColumn> pklist = this.getConfig().getModification().getPkList();
            for (ReportColumn rcol : pklist){
                tmpValues.put(rcol.getName(), selectdatas.get(0).get(rcol.getName())); 
            }
        }

        // 表示する画面のReportConfigを取得		
        String screenCode = transferRptDir + "." + transferRptFile;
//		ReportConfig tmpConfig = ssconfig.getConfigs().get(screenCode);
        ReportConfig tmpConfig = getSsconfig().getConfigs().get(getSsconfig().getScreenCodesMap().get(screenCode));
        // 項目初期化
        parameterInitialization();

//		if (parameter.getExternalParameter().get("scrcode") != null) {
//			config.setCurrentScreenCode((String)parameter.getExternalParameter().get("scrcode"));
//		}
//		ReportConfig config = (ReportConfig) ReportContext.getInstance(pkey).getConfigs().get((String) parameter.getExternalParameter().get("scrcode"));
//		if (config == null) {
//			config = (ReportConfig) ReportContext.getInstance(pkey).getConfigs().get(repid);
//		}
        logger.debug("ReportID:" + screenCode);
        if (tmpConfig == null) {
            throw new LogicException("Specified report-id was not found.[" + screenCode + "]");
        }

        // 初回展開時にデフォルト検索結果を表示するためのコード
//        if (!"true".equalsIgnoreCase(parameter.getParameter(P_SKIPOPTION))) {
			if (!tmpConfig.isReady() || tmpConfig.isReloadCondition()){
            //if config status is not ready, there needs to create option values
				synchronized(tmpConfig){
                this.generateOptionByModification(tmpConfig, getAuthConf());
                tmpConfig.setReady(true);
            }
        }
//		}

this.setConfig(tmpConfig);

        // editMode判定
        if ("EDIT".equals(dataType)) {
            setEditMode("UPDATE");
        } else if ("COPY".equals(dataType)) {
            setEditMode("INSERT");
        }

        // 遷移先テンプレートXHTML決定
//        menuBean.setCurXhtml(this.config.getPageTemplate());
        setCurXhtml(this.getConfig().getPageTemplate());

        // 遷移先データ表示のための検索
        this.setTargetServices(new ArrayList<>());
        getConfig().getSqls().forEach((targetDef) -> {
            Map<String, Object> target = new HashMap<>();
            target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
            target.put(ExternalServiceExecuter.E_FUNCTION, targetDef.getFunctionCode());
            target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
            target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
            target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);

            // 遷移元から受け取るパラメータの組み立て
            if (getValues().get(targetDef.getName()) == null) {
                getValues().put(targetDef.getName(), new HashMap<>());
            }
            tmpValues.keySet().forEach((key) -> {
                getValues().get(targetDef.getName()).put(key, tmpValues.get(key));
            });

            this.getTargetServices().add(target);
        });

        searchProcess();
        if (getReportResult() != null && !reportResult.isEmpty()) {
            for (String key : getReportResult().keySet()) {
                getSelectableResults().put(key, new ReportListDataModel(getReportResult().get(key), colPkName(key)));
                getSelectEditReportResult().put(key, new ArrayList<>());
                // 検索結果をvaluesにセット
                if (getReportResult().get(key) != null && !reportResult.get(key).isEmpty()) {
                    getValues().put(key, getReportResult().get(key).get(0));

//                    Map<String, Object> resultmap = values.get(key);
//                    for (Iterator<String> itf = resultmap.keySet().iterator(); itf.hasNext();) {
//                        String mapKey = itf.next();
//                        AbstractReportCondition column = config.getModification().getColumnSoft(key, mapKey);
//                        if (column.getControlType().startsWith("AUTOCOMPLETE")) {
//                            for (AbstractReportOption opt : column.getOptions()) {
//                                
//                            }
//                        }
//                    }
                }
            }
            // 明細行用
            getConfig().getSqls().forEach((sql) -> {
                // 入力値受付パラメータに、検索結果をdeep copy
                getListValues().put(sql.getName(), new ArrayList<>(getReportResult().get(sql.getName())));
            });
        }

        try {
            // パンくず構築
            getBreadCrumbBean().gotoNext(this, oldPageParam);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw new SystemException(ex);
        }
    }

    public void executePopup(ActionEvent event) throws Exception {
        String name = (String)event.getComponent().getAttributes().get("function");
        String service = (String)event.getComponent().getAttributes().get("service");
        String lineNo = String.valueOf(((Integer)event.getComponent().getAttributes().get("lineNo"))+1);
        setSelectedLine((Map<String, Object>)event.getComponent().getAttributes().get("selectedLine"));

        this.setDialogParams(new ArrayList<>());
        // 遷移先データ取得のためのキー項目組み立て
        Map<String, Object> tmpValues = new HashMap<>();
        this.getMaintConfig().getModification().getPkList().forEach((pkKey) -> {
            tmpValues.put(pkKey.getName(), getSelectedLine().get(pkKey.getName()));
        });
        ReportSql targetDef = this.getConfig().getSqls().get(0);
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, service);
        target.put(ExternalServiceExecuter.E_FUNCTION, name);
        target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH_ONE);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);
        Map<String, Object> params = new HashMap<>();
        params.put("selectMaster", this.getSelectMaster());
        params.put("lineNo", lineNo);
        params.put("yomikomiId", getSelectableResult().getDatasource().get(0).get("YOMIKOMI_ID"));
        target.put(ExternalServiceExecuter.P_SEND_PARAMETER, params);

        this.getTargetServices().add(target);
        tmpValues.keySet().forEach((key) -> {
            getValues().get(targetDef.getName()).put(key, tmpValues.get(key));
        });

        try {
            searchProcess();
        } catch (LogicException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        } catch (SystemException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        }
        Map<String, String> rawData = new HashMap<>();
        rawData.put("ATTR_01", SSCommonUtil.ifnull(this.getExternalAttribute().get("gyoNaiyo"), "")); // 共通アップロードの元データ表示用()
        this.getDialogParams().add(rawData);
    }
    
    /**
     * 共通アップロード用ポップアップ画面表示
     */
    public void executePopupForUpContext(ActionEvent event) throws Exception {
        String name = (String) event.getComponent().getAttributes().get("function");
        String service = (String) event.getComponent().getAttributes().get("service");
        String lineNo = String.valueOf(((Integer) event.getComponent().getAttributes().get("lineNo")));
        setSelectedLine((Map<String, Object>) event.getComponent().getAttributes().get("selectedLine"));

        this.setDialogParams(new ArrayList<>());
        // 遷移先データ取得のためのキー項目組み立て
        Map<String, Object> tmpValues = new HashMap<>();
        this.getMaintConfig().getModification().getPkList().forEach((pkKey) -> {
            tmpValues.put(pkKey.getName(), getSelectedLine().get(pkKey.getName()));
        });
        ReportSql targetDef = this.getConfig().getSqls().get(0);
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, service);
        target.put(ExternalServiceExecuter.E_FUNCTION, name);
        target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH_ONE);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);
        Map<String, Object> params = new HashMap<>();
        params.put("selectMaster", this.getSelectMaster());
        params.put("lineNo", lineNo);
        target.put(ExternalServiceExecuter.P_SEND_PARAMETER, params);

        this.getTargetServices().add(target);
        tmpValues.keySet().forEach((key) -> {
            getValues().get(targetDef.getName()).put(key, tmpValues.get(key));
        });

        try {
            searchProcess();
        } catch (LogicException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        } catch (SystemException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        }
        Map<String, String> rawData = new HashMap<>();
        rawData.put("ATTR_01", SSCommonUtil.ifnull(this.getExternalAttribute().get("gyoNaiyo"), ""));
        this.getDialogParams().add(rawData);
    }

    public void chgMode(boolean editFlg){
        if(editFlg) {
            getConfig().setEditFlg(false);
        }else{
            getConfig().setEditFlg(true);
        }
    }
    
    /**
     * 共通系画面で行追加を行うイベント
     * @throws IllegalAccessException
     * @throws InvocationTargetException 
     */
    public void addRowMaint(String ptn) throws IllegalAccessException, InvocationTargetException {
        
        if ( "cmn".equals(ptn) ) {
            this.resetList();
        }
        
        ReportSql targetDef = getConfig().getSqls().get(0);
        
        Map<String, Object> orgrow = this.getReportResult().get(targetDef.getName()).get(0);
        Map<String, Object> addrow = new HashMap<>();
        for (Iterator<String> ite = orgrow.keySet().iterator(); ite.hasNext();) {
            addrow.put(ite.next(), "");
        }
        addrow.put("newrow", true);
        this.getReportResult().get(targetDef.getName()).add(addrow);
//        selectableResult = new ReportListDataModel(this.reportResult.get(targetDef.getName()), this.colPkName());
    }

    public void addRowMaintForCon(String ptn) throws IllegalAccessException, InvocationTargetException {
        
        if ( "cmn".equals(ptn) ) {
            this.resetList();
        }
        ReportSql targetDef = getConfig().getSqls().get(0);
        Map<String, Object> orgrow = this.getReportResult().get(targetDef.getName()).get(0);
        Map<String, Object> addrow = new HashMap<>();        
        for (Iterator<String> ite = orgrow.keySet().iterator(); ite.hasNext();) {
            addrow.put(ite.next(), "");
        }        
            addrow.put( "newrow", true );
        for ( Iterator ite = this.getSelectReportResult().iterator(); ite.hasNext(); ) {
            Object obj = ite.next();
            int pos = this.getReportResult().get( targetDef.getName() ).indexOf( obj );
            this.getReportResult().get( targetDef.getName() ).add( pos, addrow );
        }
//        selectableResult = new ReportListDataModel( this.reportResult.get( targetDef.getName() ), this.colPkName() );
//        selectReportResult = new ArrayList<>();
    }

    /**
     * 共通画面で行複製を行うイベント
     * @throws IllegalAccessException
     * @throws InvocationTargetException 
     */
    public void copyRowMaint(String ptn) throws IllegalAccessException, InvocationTargetException {
        
        if ( "cmn".equals(ptn) ) {
            this.resetList();
        }
        ReportSql targetDef = getConfig().getSqls().get(0);
        Map<String, Object> addrow;
        for ( Iterator ite = this.getSelectReportResult().iterator(); ite.hasNext(); ) {
            addrow = new HashMap<>();
            Object obj = ite.next();
            addrow.putAll( (Map)obj );
            addrow.put( "newrow", true );
            int pos = this.getReportResult().get( targetDef.getName() ).indexOf( obj );
            this.getReportResult().get( targetDef.getName() ).add( pos, addrow );
        }
//        selectableResult = new ReportListDataModel( this.reportResult.get( targetDef.getName() ), this.colPkName() );
//        selectReportResult = new ArrayList<>();
    }

    /**
     * 履歴画面「close」処理
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     */
    public void resetList() throws IllegalAccessException, InvocationTargetException {
        // 履歴表示時に取得した元画面情報を戻す
        
        boolean chkFlg = false;
        
        if ( getOldSelectableResult() != null ) {
            setSelectableResult(new ReportListDataModel(null, null));
            BeanUtils.copyProperties(getSelectableResult(), getOldSelectableResult());    
            chkFlg = true;
        }

        if ( getOldReportResult().size() > 0 ) {
            setReportResult(new HashMap<>());
            for ( String key : getOldReportResult().keySet() ){
                getReportResult().put(key, getOldReportResult().get(key) );
            }
            chkFlg = true;            
        }
        
        if ( getOldSelectReportResult().size() > 0 ) {
            setSelectReportResult(new ArrayList<>());
            for ( Map map : getOldSelectReportResult() ) {
                getSelectReportResult().add( map );
            }
            chkFlg = true;            
        }
        
        if ( getOldValues().size() > 0 ) {
            setValues(new HashMap<>());
            for ( String key : getOldValues().keySet() ) {
                getValues().put(key, getOldValues().get(key));
            }
            chkFlg = true;            
        }

        if ( getOldObjectValues().size() > 0 ) {
            setObjectValues(new ArrayList<>());
            for (int i=0; i<oldObjectValues.size(); i++) {
                    objectValues.add(oldObjectValues.get(i));
            }            
        }
        if ( chkFlg ) {
            createcolumn (this.getReportResult().get(getConfig().getSqls().get(0).getName() ) , "");
        }
    }
   
    // ReportColumnの組み立て
    public void createcolumn( List<Map<String, Object>> reportMaps, String type ) {
         ReportSql targetDef = new ReportSql(); 
        if (getConfig().getSqls().size() > 2 ){
            targetDef = getConfig().getSqls().get(1);
         }
         
        if (reportMaps != null && !reportMaps.isEmpty()) {
            this.getConfig().getModification().getColumns().clear();
            int i = 1;
            for (String key : reportMaps.get(0).keySet()) {
                ReportColumn column = new ReportColumn();
                column.setName(key);
                column.setDisplayName(key);
                
                if( !this.selectMaster.isEmpty() ) {
                    column.setTableName(this.getSelectMaster());
                } else {
                    column.setTableName( targetDef.getTableName() );
                }                
                column.setControlType("LABEL");
                column.setReadonly(true);
                column.setSortIndex(i++);
                column.setEnable(true);
                column.setVisible(true);

                this.getConfig().getModification().getColumns().add(column);
            }
        }
    }

    /**
     * メンテナンスBのDatatableで行選択をした時の動作
     * @param event
     * @throws LogicException
     * @throws SystemException 
     */
    public void onRowSelect(SelectEvent event) 
            throws LogicException, SystemException, InvocationTargetException, IllegalAccessException, IllegalAccessException {
        Map<String, Object> row = ((Map<String, Object>) event.getObject());
        setSelectedLine(row);
        
        this.check(event);
    }
    /**
     * メンテナンスBのDatatableで行選択を解除した時の動作
     * @param event 
     */
    public void unRowSelect(UnselectEvent event) {
        setSelectedLine(new HashMap<String, Object>());
    
        this.uncheck(event);
    }
    
    public void onModifyPopClose() {
        String rowKeyData = (String)this.getSelectedLine().get(this.colPkName(this.getMaintConfig()));
        Map<String, Object> target = this.getSelectableResult().getRowData(rowKeyData);
        target.keySet().forEach((key) -> {
            if (getSelectedLine().get(key) != null) {
                target.put(key, getSelectedLine().get(key));
            }
        });
    }
    /**
     * 共通系画面でマスタ選択された時に動作するハンドラー
     * @param event
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException
     **/
    public void handleMasterChange(SelectEvent event) throws LogicException, SystemException, IllegalAccessException, InvocationTargetException {
        // カラムレイアウトの初期化
        if ( this.getMaintConfig() != null ) {
             setMaintConfig(new ReportConfig());
             setOldMaintConfig(new ReportConfig());
             getConfig().getModification().getListColumnLayout().clear();
             getConfig().getModification().getColumns().clear();
             setOldConfig(new ReportConfig());
             setSelectableResults(new HashMap<>());
             setReportResult(new HashMap<>());
             setSelectableResult(null);
        }
                
        String reportType = (String)event.getComponent().getAttributes().get("report_type");
        String selectedValue = (String)event.getObject();

        if (selectedValue == null || selectedValue.isEmpty()) {
            // 値が無ければ終了
            setSelectMaster("");
            setMaintConfig(null);
            setUploadStatuses(null);
            return;
        }
        // 外部サービスから取得する。
        OptionsFinder process = new OptionsFinder();
        process.setAuthConf(getAuthConf());
        List<Map<String, Object>> columnResult = null;
        try {
            AbstractReportOption option = new ReportConditionOption();
            option.setFunctionCode("SS_COM_MAINT_SETTING");
            option.setService(this.getConfig().getSqls().get(0).getService());
            option.setServiceParameter("COM_MAINT_COLUMN," + selectedValue);
            process.onService(option);
            columnResult = process.getSearchResult();
            if (columnResult == null || columnResult.isEmpty()) {
                logger.info(option.getValue() + " function-code:" + option.getFunctionCode() + " is NoResult..");
                return;
            }
        } catch (LogicException | SystemException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            return;
        }

        // 入力値クリア
//        values = new HashMap<>();
        
        // configをdeep copy
        this.setMaintConfig((ReportConfig) SerializationUtils.clone(getConfig()));
        this.getMaintConfig().getModification().getColumns().clear();
        // 定義されているcolumn(checkbox,button等)をコピー
        this.getConfig().getModification().getColumns().forEach((column) -> {
            this.getMaintConfig().getModification().getColumns().add(column);
        });

        // 検索条件の並び順
        Collections.sort(columnResult, new Comparator<Map<String, Object>>(){
            @Override
            public int compare(Map<String, Object> rec1, Map<String, Object> rec2) {
                String colName1 = (String)rec1.get("schSortIndex");
                String colName2 = (String)rec2.get("schSortIndex");
                return colName1.compareTo(colName2);
            }    
        });        
        
        // 検索条件、一覧組み立て
        for (int i = 0; i < columnResult.size(); i++) {
            Map<String, Object> one = columnResult.get(i);
            String columnName = String.valueOf(one.get("columnName"));
            String subColumn = String.valueOf(one.get("subColumn"));
            String columnDescription = String.valueOf(one.get("columnDescription"));
            String controlInd = String.valueOf(one.get("controlInd"));
            String searchColumnInd = String.valueOf(one.get("searchColumnInd"));
            String searchColType = null;
            String searchDataType = null;
            if (one.get("searchComponent") != null) {
                String[] component = String.valueOf(one.get("searchComponent")).split("::");
                searchColType = component[0];
                searchDataType = component.length > 1 ? component[1] : "";
            }
            String pk = String.valueOf(one.get("pk"));

            if ("1".equals(searchColumnInd) || ( ("0").equals(searchColumnInd) && !searchColType.isEmpty() )) {
                // 検索条件作成
                this.getMaintConfig().getConditions().add( createCondition( one, searchColumnInd ) );
            }
            if (!StringUtils.isEmpty(controlInd) && !"report".equals(reportType)) {
                // 共通メンテナス画面の場合、ここでカラムを組み立てる
                ReportColumn column = new ReportColumn();
                column.setApplyTo(this.getConfig().getSqls().get(0).getName());
                column.setName(columnName);
                column.setDisplayName(columnDescription);
                column.setTableName(this.getSelectMaster());
                if ("2".equals(controlInd)) {
                    if ( ReportConst.ControlType.SELECT.equals(searchColType) ) {
                        column.setControlType(ReportConst.ControlType.SELECT);
                        
                    } else if ( ReportConst.ControlType.DOUBLECOMBO_IN.equals(searchColType) 
                            || ReportConst.ControlType.DOUBLECOMBO_OUT.equals(searchColType) ){    
                        column.setControlType(searchColType);
                        
                    } else if ( ReportConst.ControlType.AUTOCOMPLETE.equals(searchColType)
                            || ReportConst.ControlType.AUTOCOMPLETE_DYNAMIC.equals(searchColType)
                            || ReportConst.ControlType.AUTOCOMPLETE_MULTI.equals(searchColType) ) {
                        column.setControlType(searchColType);
                        column.setExtra1(subColumn);
                        
                    } else {
                        column.setControlType(ReportConst.ControlType.TEXT);                        
                    }
                    column.setReadonly(false);
                } else if ("1".equals(controlInd)) {
                    // controlInd = 1(表示のみ)
                    column.setControlType(ReportConst.ControlType.LABEL);
                    column.setReadonly(true);
                } else {
                    column.setControlType(ReportConst.ControlType.HIDDEN);
                }
                column.setSortIndex(i + 2);
                column.setEnable(true);
                column.setVisible(true);
                // 入力項目を縦並べ
                column.setLineEnd(true);
                if ("1".equals(pk)) column.setPk(true);

                this.getMaintConfig().getModification().getColumns().add(column);
            }
        }
        // 検索条件のOption項目を取得する
        synchronized(this.getMaintConfig()){
            this.generateOption(this.getMaintConfig(), getAuthConf());
            this.getMaintConfig().setReady(true);
            createSortList();
//            setSelectForSearch();
        }

        for (ReportCondition cond : getMaintConfig().getConditions()) {
            getDefConds().put(cond.getName(), cond.getDefaultValue());
        }        
    }

    /**
     * 検索条件作成
     * @param one
     * @return 
     */
    private ReportCondition createCondition( Map<String, Object> one, String searchColumnInd) {

        String columnName = String.valueOf(one.get("columnName"));
        String columnDescription = String.valueOf(one.get("columnDescription"));
        String searchColType = null;
        String searchDataType = null;
        Boolean lineEnd = "0".equals(one.get("lineEnd").toString()) ? false : true;
        if (one.get("searchComponent") != null) {
            String[] component = String.valueOf(one.get("searchComponent")).split("::");
            searchColType = component[0];
            searchDataType = component.length > 1 ? component[1] : "";
        }
        String searchOptFuncName = SSCommonUtil.ifnull(one.get("searchOptFuncName"), "");
        String searchOptParam = SSCommonUtil.ifnull(one.get("searchOptParam"), "");
        String defaultValue = String.valueOf(one.get("defaultValue"));
        
        ReportCondition condition = new ReportCondition();
        condition.setDisplayName(columnDescription);
        condition.setName(columnName);
        condition.setControlType(searchColType);
        condition.setDataType(searchDataType);
        condition.setSection(String.valueOf(one.get("section")).equals("0")?"main":"sub");
        condition.setApplyTo(this.getConfig().getSqls().get(0).getName());
        condition.setPrevColPosition("");
        condition.setLineEnd(lineEnd);
        condition.setEnable(true);

        // TODO 
        // 検索条件の表示制御(営業所権限：1／本社権限：1,2）
        if( "SYSTEM_ADMIN".equals(getAuthConf().getUserGroup().get(0) )) {
            if ( searchColumnInd.equals("0") ) {
                condition.setVisible(false);
            } else {
                condition.setVisible(true);
            }
        } else {
            if (searchColumnInd.equals("1")) {
                condition.setVisible(true);
            } else {
                condition.setVisible(false);
            }
        }
        condition.setDefaultValue(selDefaultVal(defaultValue));
        condition.setCache(false);
        if (!searchOptFuncName.isEmpty()) {
            AbstractReportOption spaceOpt = new ReportConditionOption();
            spaceOpt.setValue("");
            spaceOpt.setLabel("");
            condition.getOptions().add(spaceOpt);
            condition.getOriginalOptions().add(spaceOpt);
            AbstractReportOption option = new ReportConditionOption();
            option.setService(this.getConfig().getSqls().get(0).getService());
            option.setFunctionCode(searchOptFuncName);
            option.setServiceParameter(searchOptParam);
            condition.getOptions().add(option);
            condition.getOriginalOptions().add(option);
        }
        return condition;
    }

    private String selDefaultVal(String defaultVal) {
        
        String val = "";
        if (defaultVal.equals("userGroup")) {
            val = getAuthConf().getUserGroup().get(0);
        } else {
            val = defaultVal;
        }
        return val;
    }
    
    /**
     * selectBox連携
     * @param event
     * @throws LogicException
     * @throws SystemException
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     * @throws InvocationTargetException 
     */
    public void changeItemSearch( SelectEvent event ) throws LogicException, SystemException, IllegalAccessException, InvocationTargetException, InvocationTargetException {
        
        String subColumn = "";
        String tableName = "";
        
        for ( ReportCondition con : getConfig().getConditions() ) {
            if (StringUtils.isNotEmpty(con.getTargetDynamic()) ) {
                subColumn = con.getTargetDynamic();
                tableName = con.getTableName();                
                break;
            }
        }
            
        for ( ReportCondition cond : getConfig().getConditions() ) {
            if (StringUtils.isNotEmpty(subColumn)
                    && StringUtils.equals(subColumn, cond.getName() )) {
                ReportSql targetDef = getConfig().getSqls().get(0);
                Map<String, Object> target = new HashMap<>();
                this.setTargetServices(new ArrayList<>());
                target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
                target.put(ExternalServiceExecuter.E_FUNCTION, cond.getOriginalOptions().get(1).getFunctionCode() );
                target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
                target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
                target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);
                Map<String, Object> sendParams = new HashMap<>();
                sendParams.put("TABLE_NAME", tableName);
                if (StringUtils.isNotEmpty((String)event.getObject())) {
                    sendParams.put("pCode",event.getObject());
                }
                
                target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);
                this.getTargetServices().add(target);
                searchProcess();

                List<AbstractReportOption> list = new ArrayList();
                int i = 0;
                for (Map op : this.getReportResult().get(targetDef.getName()) ) {
                    AbstractReportOption option = new ReportConditionOption();
                    if ( i==0 ) {
                        option.setValue("");
                        option.setLabel("");
                        list.add(option);
                        option = new ReportConditionOption();
                    }                    
                    
                    option.setValue( (String)op.get("VALUE") );
                    option.setLabel( (String)op.get("LABEL") );
                    list.add(option);
                    i++;
                }
                cond.setOptions(list);
            }
        }
    }
    
   public void changeItemList( SelectEvent event ) throws LogicException, SystemException, IllegalAccessException, InvocationTargetException, InvocationTargetException {
        
        String subColumn = "";
        String tableName = "";
//        String pkName = columnLists.getReportColPk();
        
        for ( ReportColumn col : getConfig().getModification().getColumns() ) {
            if (StringUtils.isNotEmpty(col.getTargetDynamic()) ) {
                subColumn = col.getTargetDynamic();
                tableName = col.getTableName();                
                break;
            }
        }

        for ( ReportColumn col : getConfig().getModification().getColumns() ) {
            if (StringUtils.isNotEmpty(subColumn)
                    && StringUtils.equals(subColumn, col.getName() )) {
                
                ReportSql targetDef = getConfig().getSqls().get(0);
                Map<String, Object> target = new HashMap<>();
                this.setTargetServices(new ArrayList<>());
                target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
                target.put(ExternalServiceExecuter.E_FUNCTION, col.getOriginalOptions().get(1).getFunctionCode() );
                target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
                target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
                target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);
                Map<String, Object> sendParams = new HashMap<>();
                sendParams.put("TABLE_NAME", tableName);
                if (StringUtils.isNotEmpty((String)event.getObject())) {
                    sendParams.put("pCode",event.getObject());
                }
                
                target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);
                this.getTargetServices().add(target);
                searchProcess();

                List<AbstractReportOption> list = new ArrayList();
                int i = 0;
                for (Map op : this.getReportResult().get(targetDef.getName()) ) {
                    AbstractReportOption option = new ReportConditionOption();
                    if ( i==0 ) {
                        option.setValue("");
                        option.setLabel("");
                        list.add(option);
                        option = new ReportConditionOption();
                    }                    
                    
                    option.setValue( (String)op.get("VALUE") );
                    option.setLabel( (String)op.get("LABEL") );
                    list.add(option);
                    i++;
                }
                col.setOptions(list);
//                JSONObject json = new JSONObject();
//                json.put("list", list);                
//                RequestContext context = RequestContext.getCurrentInstance();  
//                context.addCallbackParam("itemList", json);
//                context.addCallbackParam("targetColumn", subColumn);
            }
        }
    }    
   
    /**
     * 共通アップロード画面でマスタ選択された時に動作するハンドラー
     *
     * @param event
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException
     */
    public void handleMasterChangeForComUpload(SelectEvent event) throws LogicException, SystemException {
        String selectedValue = (String) event.getObject();

        if (selectedValue == null || selectedValue.isEmpty()) {
            // 値が無ければ終了
            setSelectMaster("");
            setMaintConfig(null);
            setUploadStatuses(null);
            setSelectableResult(null);
            setUploadFileDef(null);
            return;
        }
        if (!selectedValue.equals(oldSelectMaster)) {
            setMaintConfig(null);
            setUploadStatuses(null);
            setSelectableResult(null);
        }
        setOldSelectMaster(selectedValue);
        // 外部サービスから取得する。(選択されたデータファイルのアップロードファイル定義を取得)
        OptionsFinder process = new OptionsFinder();
        process.setAuthConf(getAuthConf());
        List<Map<String, Object>> upFileDefResult = null;
        try {
            AbstractReportOption option = new ReportConditionOption();
            option.setFunctionCode("SS_COM_UPLOAD_SEARCH");
            option.setService(this.getConfig().getSqls().get(0).getService());
            option.setServiceParameter("COM_UPLOAD_DEF," + selectedValue);
            process.onService(option);
            upFileDefResult = process.getSearchResult();
            if (upFileDefResult == null || upFileDefResult.isEmpty()) {
                logger.info(option.getValue() + " function-code:" + option.getFunctionCode() + " is NoResult..");
                return;
            }
        } catch (LogicException | SystemException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            return;
        }
        setUploadFileDef(upFileDefResult);
    }
    
    /**
     * 共通アップロード画面用　一覧内値変更検知
     */
    public void doValueChange(ValueChangeEvent event){
        System.out.println(event.getOldValue() + "⇒" + event.getNewValue());
        UIData data = (UIData) event.getComponent().findComponent(":List" + this.getConfig().getFormId() + ":tablesorter_" + this.getConfig().getFormId());
        DataTable dataTable = (DataTable) FacesContext.getCurrentInstance().getViewRoot().findComponent(":List" + this.getConfig().getFormId() + ":tablesorter_" + this.getConfig().getFormId());
        List<org.primefaces.component.api.UIColumn> column = dataTable.getColumns();
//        for (org.primefaces.component.api.UIColumn uiColumn : column) {
//            System.out.println(uiColumn.getHeaderText());  
//        } 
//        System.out.println("header :" + headerName);
//        int rowIndex = data.getRowIndex();
        setIsChange("true");
    }
        
    /**
     * 検索条件にソート順のリストを表示する
     * @throws LogicException
     * @throws SystemException
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     */
    private void createSortList() throws LogicException, SystemException, IllegalAccessException, InvocationTargetException {
              
        ReportSql targetDef = getConfig().getSqls().get(0);
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
        target.put(ExternalServiceExecuter.E_FUNCTION, "SS_SORT_ORDER_LIST");
        target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);

        Map<String, Object> sendParams = new HashMap<>();
        sendParams.put("TABLE_NAME", this.getSelectMaster());
        sendParams.put("FUNCTION_CODE", targetDef.getFunctionCode());
        target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);
        
        this.getTargetServices().add(target);
        
        searchProcess();
        
        setSortVal(this.getReportResult().get(targetDef.getName()));  
    }

    public void executeSidebar(ActionEvent event) {
        String name = (String)event.getComponent().getAttributes().get("name");
        String service = (String)event.getComponent().getAttributes().get("service");

        // 現在サイドバーが開いている場合は、editModeを元に戻して処理を終了する
        if ("SIDEBAR_UP".equals(getEditMode()) || "SIDEBAR_CLOSE".equals(getEditMode())) {
            setEditMode(getEditModeTemp());
            return;
        } else {
            setEditModeTemp(getEditMode());
            setEditMode("SIDEBAR_UP");
        }

        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, service);
        target.put(ExternalServiceExecuter.E_FUNCTION, name);
        target.put(ExternalServiceExecuter.E_SERVICE_NAME, this.getConfig().getSqls().get(0).getName());
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH_SIDEBAR);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);
        this.getTargetServices().add(target);

        try {
            searchProcess();
        } catch (LogicException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
//            throw ex;
        } catch (SystemException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
//            throw ex;
        }
        getSelectableResults().put("sidebar", new ReportListDataModel(this.getReportSidebarResult().get(target.get(ExternalServiceExecuter.E_SERVICE_NAME)), this.colPkNameForSidebar("sidebar")));

    }
    public void onSidebarRowSelect(SelectEvent event) throws LogicException, SystemException {
        Map<String, Object> row = ((Map<String, Object>) event.getObject());
        Map<String, Object> tmpValues = new HashMap<>();
        ReportColumn pkcol = null;
        for (ReportColumn pkKey : this.getConfig().getModification().getPkListForSidebar()) {
            tmpValues.put(pkKey.getName(), row.get(pkKey.getName()));
            if (pkcol == null) pkcol = pkKey;
            }
        // データ表示のための検索
        this.setTargetServices(new ArrayList<>());
        getConfig().getSqls().forEach((targetDef) -> {
            Map<String, Object> target = new HashMap<>();
            target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
            target.put(ExternalServiceExecuter.E_FUNCTION, targetDef.getFunctionCode());
            target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
            target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
            target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);

            // パラメータの組み立て
            getValues().put(targetDef.getName(), new HashMap<>());
            tmpValues.keySet().forEach((key) -> {
                getValues().get(targetDef.getName()).put(key, tmpValues.get(key));
            });

            this.getTargetServices().add(target);
        });

        searchProcess();
        if (getReportResult() != null && !reportResult.isEmpty()) {
            for (String key : getReportResult().keySet()) {
                getSelectableResults().put(key, new ReportListDataModel(getReportResult().get(key), colPkName(key)));
                getSelectEditReportResult().put(key, new ArrayList<>());
                // 検索結果をvaluesにセット
                if (getReportResult().get(key) != null && !reportResult.get(key).isEmpty()) {
                    getValues().put(key, getReportResult().get(key).get(0));

//                    Map<String, Object> resultmap = values.get(key);
//                    for (Iterator<String> itf = resultmap.keySet().iterator(); itf.hasNext();) {
//                        String mapKey = itf.next();
//                        AbstractReportCondition column = config.getModification().getColumnSoft(key, mapKey);
//                        if (column.getControlType().startsWith("AUTOCOMPLETE")) {
//                            for (AbstractReportOption opt : column.getOptions()) {
//                                
//                            }
//                        }
//                    }
                }
            }
            // 明細行用
            getConfig().getSqls().forEach((sql) -> {
                // 入力値受付パラメータに、検索結果をdeep copy
                getListValues().put(sql.getName(), new ArrayList<>(getReportResult().get(sql.getName())));
            });
        }
        // サイドバーは閉じるがモードは終了しない（モードを SIDEBAR_CLOSE に変更
        if ("SIDEBAR_UP".equals(getEditMode())) {
            setEditMode("SIDEBAR_CLOSE");
            getSelectableResults().put("sidebar", new ReportListDataModel(new ArrayList<>(), this.colPkNameForSidebar("sidebar")));
        }
    }
    /**
     * SELECT_DYNAMIC,SELECT_MULTI の値が選択されたとき、紐づく値を各項目に展開する。
     * @param event event
     */
    public void onChangeDynamic(SelectEvent event) {
        String applyTo = (String)event.getComponent().getAttributes().get("applyTo");
        AbstractReportOption option = (AbstractReportOption)event.getObject();

        if (option.getRelationValues().isEmpty()) {
            // 値展開先が無ければ終了
            return;
        }
        // 値の展開
        option.getRelationValues().keySet().forEach((key) -> {
            this.getValues().get(applyTo).put(key, option.getRelationValues().get(key));
        });
    }
    /**
     * SELECT_DYNAMIC,SELECT_MULTI の値が選択されたとき、紐づく値を各項目に展開する。(明細用)
     * @param event event
     */
    public void onChangeDynamicForLine(SelectEvent event) {
        AbstractReportOption option = (AbstractReportOption)event.getObject();
        String applyTo = (String)event.getComponent().getAttributes().get("applyTo");
        Integer rowIndex = (Integer)event.getComponent().getAttributes().get("rowIndex");
        AbstractReportCondition column = (AbstractReportCondition)event.getComponent().getAttributes().get("condition");

        if (option.getRelationValues().isEmpty()) {
            // 値展開先が無ければ終了
            return;
        }
        // 値の展開
        option.getRelationValues().keySet().forEach((key) -> {
            this.getListValues().get(applyTo).get(rowIndex).put(key, option.getRelationValues().get(key));
        });
    }

    /**
     * AUTOCOMPLETE の値が選択されたとき、紐づく値を各項目に展開する。
     * @param event event
     */
    public void onAutoCompSelected(SelectEvent event) {
        String applyTo = (String)event.getComponent().getAttributes().get("applyTo");
        AbstractReportOption option = (AbstractReportOption)event.getObject();
        AbstractReportCondition column = (AbstractReportCondition)event.getComponent().getAttributes().get("condition");

        // 共通部品の場合はコードと名称を分割して表示
        if (column.getExtra2() != null){
            if (column.getExtra2().equals("1") || column.getExtra2().equals("2") || column.getExtra2().equals("3")) {
                column.setTextValue(option.getValue());
                column.setLabelValue(option.getRelationValues().get("LABEL_VALUE"));
            }
        }
        this.getValues().get(applyTo).put(column.getName(), option.getValue());

        if (option.getRelationValues().isEmpty()) {
            // 値展開先が無ければ終了
            return;
        }
        // 値の展開
        option.getRelationValues().keySet().forEach((key) -> {
            this.getValues().get(applyTo).put(key, option.getRelationValues().get(key));
        });
    }
     
    /**
     * AUTOCOMPLETE の値が選択されたとき、紐づく値を各項目に展開する。(明細用)
     * @param event event
     */
    public void onAutoCompSelectedForLine(SelectEvent event) {
        AbstractReportOption option = (AbstractReportOption)event.getObject();
        String applyTo = (String)event.getComponent().getAttributes().get("applyTo");
        Integer rowIndex = (Integer)event.getComponent().getAttributes().get("rowIndex");
        AbstractReportCondition column = (AbstractReportCondition)event.getComponent().getAttributes().get("condition");

        this.getListValues().get(applyTo).get(rowIndex).put(column.getName(), option.getValue());

        if (option.getRelationValues().isEmpty()) {
            // 値展開先が無ければ終了
            return;
        }
        // 値の展開
        option.getRelationValues().keySet().forEach((key) -> {
            this.getListValues().get(applyTo).get(rowIndex).put(key, option.getRelationValues().get(key));
        });
    }
    
    /**
     * AUTOCOMPLETE_MULTIの値が選択された時に、紐づく値を渡す.
     * @param event 
     */
    public void onAtCmpCdSelectedForLine(SelectEvent event) {
        for( ReportColumn clm : getMaintConfig().getModification().getColumns() ) {
            if( "AUTOCOMPLETE_MULTI".equals(clm.getControlType()) ) {
                for( AbstractReportOption option : clm.getOptions() ) {
                    if ( event.getObject().equals(option.getValue()) ) {
                        String applyTo = (String)event.getComponent().getAttributes().get("applyTo");
                        Integer rowIndex = (Integer)event.getComponent().getAttributes().get("rowIndex");
                        AbstractReportCondition column = (AbstractReportCondition)event.getComponent().getAttributes().get("condition");

                        this.getListValues().get(applyTo).get(rowIndex).put(column.getName(), option.getValue());

                        if (option.getRelationValues().isEmpty()) {
                            // 値展開先が無ければ終了
                            return;
                        }
                        // 値の展開
                        option.getRelationValues().keySet().forEach((key) -> {
                            this.getListValues().get(applyTo).get(rowIndex).put(key, option.getRelationValues().get(key));
                        });                    
                        return;
                    }
                }                
            }
        }
    }
    

    /**
     * FileUpload時に実行されるイベント
     * @param event event
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException
     * @throws java.io.IOException
     */
    public void handleFileUpload(FileUploadEvent event) throws LogicException, SystemException, IOException {
        File file = null;
        setUploadFileName(new ArrayList<>());
        try {
            getUploadFileName().add(event.getFile().getFileName());

            file = File.createTempFile("updtmp_", event.getFile().getFileName(), new File("./")); // 一時ファイル作成
            file.deleteOnExit(); // ファイルが存在したら削除する
            Files.copy(event.getFile().getInputstream(), file.toPath(), StandardCopyOption.REPLACE_EXISTING); //　ファイルを上書き保存する

            setUploadFiles(new ArrayList<>());
            getUploadFiles().add(file);
        } catch (IOException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        }
        String function = "SS_COM_UPLOAD_FILE_PROC_EX";
        String service = "JohmonWebServiceForMultipart";

        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, service);
        target.put(ExternalServiceExecuter.E_FUNCTION, function);
        target.put(ExternalServiceExecuter.E_SERVICE_NAME, this.getConfig().getSqls().get(0).getName());
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.LIST_UPDATE);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);
        Map<String, Object> params = new HashMap<>();
        params.put("wayOfUpload", this.getWayOfUpload());
        params.put("selectMaster", this.getSelectMaster());
        params.put("fileName", this.getUploadFileName());
        target.put(ExternalServiceExecuter.P_SEND_PARAMETER, params);
        this.getTargetServices().add(target);

        try {
            ExternalServiceExecuterForMultipart exec = new ExternalServiceExecuterForMultipart();
            exec.onService(this);
        } catch (LogicException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        } catch (SystemException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        }
        setSelectReportResult(new ArrayList<>());
        // 取得したLISTの最後を別変数に格納し、LISTの該当箇所を削除する。
        setUploadStatuses(this.getReportResult().get(this.getConfig().getSqls().get(0).getName()).get(this.getReportResult().get(this.getConfig().getSqls().get(0).getName()).size() - 1));
        this.getReportResult().get(this.getConfig().getSqls().get(0).getName()).remove(this.getReportResult().get(this.getConfig().getSqls().get(0).getName()).size() - 1);
        createUploadColumns();
        
        List<Map<String, Object>> selectedRowParam;
        selectedRowParam = this.getReportResult().get(this.getConfig().getSqls().get(0).getName());
        
        Iterator<Map<String, Object>> ite = selectedRowParam.iterator();
        while(ite.hasNext()){
            Map<String, Object> i = ite.next();
            if (!i.get("TOROKU_STATUS").equals("4") && !i.get("TOROKU_STATUS").equals("5") && !i.get("TOROKU_STATUS").equals("6")) {
                getSelectReportResult().add(i);
            }
        }
        setIsChange("false");
        setSelectableResult(new ReportListDataModel(this.getReportResult().get(this.getConfig().getSqls().get(0).getName()), this.colPkName(this.getMaintConfig())));
      
        // 画面構成リストのバックアップ
        setOldSelectableResult(new ReportListDataModel(null, null));
        try {
            BeanUtils.copyProperties(getOldSelectableResult(), getSelectableResult());
        } catch (IllegalAccessException | InvocationTargetException ex) {
            Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
        }
        setOldReportResult(new HashMap<>());
        for ( String key : getReportResult().keySet() ){
            getOldReportResult().put(key, getReportResult().get(key) );
        }        
        // 画面チェック状態のバックアップ
        setOldSelectReportResult(new ArrayList<>());
        for ( Map map : getSelectReportResult() ) {
            getOldSelectReportResult().add( map );
        }
        // 画面からの入力値のバックアップ
        setOldValues(new HashMap<>());
        for ( String key : getValues().keySet() ) {
            getOldValues().put(key, getValues().get(key));
        } 

        setOldObjectValues(new ArrayList<>());
        for (int i=0; i<objectValues.size(); i++) {
                oldObjectValues.add(objectValues.get(i));
        }                   
        
        DataTable pDt = (DataTable)FacesContext.getCurrentInstance().getViewRoot().findComponent(":List" + this.getConfig().getFormId() + ":tablesorter_" + this.getConfig().getFormId());
        System.out.println(pDt.getSelection());
    }

    private void createUploadColumns() {
        // configをdeep copy
        this.setMaintConfig((ReportConfig) SerializationUtils.clone(getConfig()));
        this.getMaintConfig().getModification().getColumns().clear();
        // 定義されているcolumn(checkbox,button等)をコピー
        this.getConfig().getModification().getColumns().forEach((column) -> {
            this.getMaintConfig().getModification().getColumns().add(column);
        });
        // 1行目からcolumn定義を取る
        Map columnSetting = this.getReportResult().get(this.getConfig().getSqls().get(0).getName()).get(0);
        // 2行目(一時保存データ)から、カラムを作成
        Map columnsBase = this.getReportResult().get(this.getConfig().getSqls().get(0).getName()).get(1);
        int i = 1;
        for (Iterator ite = columnsBase.keySet().iterator(); ite.hasNext();) {
            String columnName = (String)ite.next();
            
            ReportColumn column = new ReportColumn();
            String columnDescription = null;
            if (columnSetting.get(columnName) != null) {
                columnDescription = (String)columnSetting.get(columnName);
                column.setControlType("LABEL");
                column.setPk(false);
            } else {
                columnDescription = columnName;
                column.setControlType("HIDDEN");
                column.setPk(true);
            }
            column.setName(columnName);
            column.setDisplayName(columnDescription);
            column.setTableName(this.getSelectMaster());
            column.setReadonly(true);
            column.setSortIndex(i + 5);
            column.setEnable(true);
            column.setVisible(true);

            this.getMaintConfig().getModification().getColumns().add(column);
        }
        this.getReportResult().get(this.getConfig().getSqls().get(0).getName()).remove(0);
    }
    
    /**
     * ツリーのノードを全て閉じる
     */
    public void collapseAll() {
        setExpandedRecursively(getSelectableTreeResult().getRoot(), false);
    }
    /**
     * ツリーのノードを全て開く
     */
    public void expandAll() {
        setExpandedRecursively(getSelectableTreeResult().getRoot(), true);
    }
    private void setExpandedRecursively(final TreeNode node, final boolean expanded) {
        node.getChildren().forEach((child) -> {
            setExpandedRecursively(child, expanded);
        });
        node.setExpanded(expanded);
    }

    public void disableUIComponent() {
        disableUIComponentProc(true);
    }
    public void unDisableUIComponent() {
        disableUIComponentProc(false);
    }
    private void disableUIComponentProc(boolean isDisable) {
        // ヘッダ部
        String compName = ":h_" + this.getConfig().getFormId() + ":headerTitle_" + this.getConfig().getFormId();
        UIComponent component = FacesContext.getCurrentInstance().getViewRoot().findComponent(compName);
        if(component != null) {
            disableAll(component.getChildren(), isDisable);
        }
        // 明細部
        for (ReportSql sql : this.getConfig().getSqls()) {
            String compDlName = ":dl_" + this.getConfig().getFormId() + ":headerTitle_" + this.getConfig().getFormId() + "_" + sql.getName();
            UIComponent componentDl = FacesContext.getCurrentInstance().getViewRoot().findComponent(compDlName);
            if(componentDl != null) {
                disableAll(componentDl.getChildren(), isDisable);
            }
        }
    }

    private void disableAll(List<UIComponent> components, boolean isDisable) {
        components.stream().map((component) -> {
            if (component instanceof UIInput) {
                try {
                    Method m = component.getClass().getMethod("setDisabled", boolean.class);
                    m.invoke(component, isDisable);
                    try {
                        setStyleClass(component, "StyleClass", isDisable);
                    } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException ex) {
                    }
                    // inputStyleClassがあるコンポーネントはこちらが優先されCSSが効く
                    try {
                        setStyleClass(component, "InputStyleClass", isDisable);
                    } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException ex) {
                    }
                } catch (NoSuchMethodException | SecurityException ex) {
                    // untarget component
                } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
                    Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            return component;
        }).forEachOrdered((component) -> {
            disableAll(component.getChildren(), isDisable);
        });
    }
    private void setStyleClass(UIComponent component, String method, boolean isDisable) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        final String disableStyle = "disabledForHistory";
        String style = null;
        Method m2get = component.getClass().getMethod("get" + method);
        Object styleRaw = m2get.invoke(component);
        if (styleRaw != null) {
            style = (String)styleRaw;
        }

        Method m2 = component.getClass().getMethod("set" + method, String.class);
        if (isDisable) {
            m2.invoke(component, style + " " + disableStyle);
        } else {
            if (style != null && style.indexOf(disableStyle) > 1) {
                m2.invoke(component, style.substring(0, style.indexOf(disableStyle)-1));
            } else {
                m2.invoke(component, "");
            }
        }

    }

    public void spreadAddress(String applyTo, String targetDynamic) throws LogicException, SystemException {
        String[] split = targetDynamic.split(",");
        String add1Id = split[1];
        String add2Id = split[2];
        String add3Id = split[3];

        // clear
        this.getValues().get(applyTo).put(add1Id, "");
        this.getValues().get(applyTo).put(add2Id, "");
        this.getValues().get(applyTo).put(add3Id, "");

        Map<String, String> option = new HashMap<>();
        option.put(AddressFinder.P_POSTAL_CODE, (String)this.getValues().get(applyTo).get(split[0]));
        AddressFinder process = new AddressFinder();
        process.setAuthConf(getAuthConf());
        process.onService(option);
        List<Map<String, Object>> searchResult = process.getSearchResult();
        if (searchResult == null || searchResult.isEmpty()) {
            logger.info("Address search postal[" + option.get(AddressFinder.P_POSTAL_CODE)  + "] is NoResult..");
            return;
        }

        RequestContext context = RequestContext.getCurrentInstance();

        setDialogParams(new ArrayList<>());
        if (searchResult.size() == 1) {
            this.getValues().get(applyTo).put(add1Id, searchResult.get(0).get("address1"));
            this.getValues().get(applyTo).put(add2Id, searchResult.get(0).get("address2"));
            this.getValues().get(applyTo).put(add3Id, searchResult.get(0).get("address3"));
            context.addCallbackParam("multiple", false);
        } else {
            searchResult.stream().map((result) -> {
                Map<String, String> add = new HashMap<>();
                add.put(add1Id, (String)result.get("address1"));
                add.put(add2Id, (String)result.get("address2"));
                add.put(add3Id, (String)result.get("address3"));
                add.put("applyTo", applyTo);
                add.put("DISP_ADDRESS", (String)result.get("address1") + (String)result.get("address2") + (String)result.get("address3"));
                return add;
            }).forEachOrdered((add) -> {
                getDialogParams().add(add);
            });
            context.addCallbackParam("multiple", true);
        }
    }

    public void selectOneAddress(Map<String, String> add) {
        add.keySet().stream().filter((targetField) -> (!targetField.equals("DISP_ADDRESS") && !targetField.equals("applyTo"))).forEachOrdered((targetField) -> {
            this.getValues().get(add.get("applyTo")).put(targetField, add.get(targetField));
        });
    }

    public List<ReportButton> authorizedTopButtons() {
        List<ReportButton> result = new ArrayList<>();
        getConfig().getTopButtons().forEach((btn) -> {
            if (!authConf.isAllEnabledFunction() && !authConf.getFunctionList().containsKey(btn.getName())) {
                // 権限制御によるボタン非表示
            } else if ("INSERT".equals(getEditMode()) && (btn.getAction().equals("UPDATE") || btn.getAction().equals("CONFIRM") || btn.getAction().equals("UNCONFIRM") || btn.getAction().equals("UPDATE2") || btn.getAction().equals("CHKLIST_UPDATE") || btn.getAction().equals("PAGER_PREV") || btn.getAction().equals("PAGER_NEXT") || btn.getAction().equals("CREATE_NEW"))) {
                // 新規時は確定と確定解除は表示しない
            } else if ("UPDATE".equals(getEditMode()) && (btn.getAction().equals("INSERT"))) {
                // 更新時は新規登録ボタンを表示しない
            } else {
                result.add(btn);
            }
        });
        return result;
    }
    public List<ReportButton> authorizedBottomButtons() {
        List<ReportButton> result = new ArrayList<>();
        getConfig().getBottomButtons().forEach((btn) -> {
            if (!authConf.isAllEnabledFunction() && !authConf.getFunctionList().containsKey(btn.getName())) {
                // 権限制御によるボタン非表示
            } else if ("INSERT".equals(getEditMode()) && (btn.getAction().equals("UPDATE") || btn.getAction().equals("CONFIRM") || btn.getAction().equals("UNCONFIRM") || btn.getAction().equals("UPDATE2") || btn.getAction().equals("CHKLIST_UPDATE") || btn.getAction().equals("PAGER_PREV") || btn.getAction().equals("PAGER_NEXT") || btn.getAction().equals("CREATE_NEW"))) {
                // 新規時は確定と確定解除は表示しない
            } else if ("UPDATE".equals(getEditMode()) && (btn.getAction().equals("INSERT"))) {
                // 更新時は新規登録ボタンを表示しない
            } else {
                result.add(btn);
            }
        });
        return result;
    }
    public String getChkVal(Map<String, String> line) {
        StringBuffer chkVal = new StringBuffer();
        this.getConfig().getModification().getPkList().forEach((column) -> {
            String val = line.get(column.getName());
            if (chkVal.length() != 0) {
                chkVal.append("&");
            }
            chkVal.append("LIST-").append(column.getName()).append("=").append(val);
        });
        return chkVal.toString();
    }

    public String getPkParam(Map<String, String> line) {
        return getPkParam(line, null);
    }
    public String getPkParam(Map<String, String> line, String applyTo) {
        StringBuffer pkParam = new StringBuffer();
        this.getConfig().getModification().getPkList(applyTo).forEach((column) -> {
            String val = line.get(column.getName());
            if (pkParam.length() != 0) {
                pkParam.append("&");
            }
            pkParam.append("P_").append(column.getName()).append("=").append(val);
        });
        return pkParam.toString();
    }

    public String getHdnList(Map<String, String> line) {
        return getHdnList(line, null);
    }
    public String getHdnList(Map<String, String> line, String applyTo) {
        StringBuffer hdnList = new StringBuffer();
        this.getConfig().getModification().getHiddenList(applyTo).forEach((column) -> {
            String val = line.get(column.getName());
            if (hdnList.length() != 0) {
                hdnList.append("&");
            }
            hdnList.append("P_").append(column.getName()).append("=").append(val);
        });
        return hdnList.toString();
    }

    public String colPkName() {
        return colPkName(null, null, this.getConfig());
    }
    public String colPkName(String applyTo) {
        return colPkName(applyTo, null, this.getConfig());
    }
    public String colPkName(ReportConfig targetConfig) {
        return colPkName(null, null, targetConfig);
    }
    public String colPkNameForSidebar(String applyTo) {
        return colPkName(applyTo, ReportConst.SECTION.HISTORY, this.getConfig());
    }
    public String colPkName(String applyTo, String section, ReportConfig targetConfig) {
        String result = null;
        for (ReportListColumn listCol : targetConfig.getModification().getListColumnLayout(applyTo, section)) {
            for (ReportColumn column : listCol.getCols()) {
                if (column.isPk()) {
                    result = column.getName();
                    break;
                }
            }
            if (result != null) break;
            }

        if (result == null) {
            for (ReportColumn column : targetConfig.getModification().getHiddenList(applyTo, section)) {
                if (column.isPk()) {
                    result = column.getName();
                    break;
                }
            }
        }
        return result;
    }

    public String getJsContent() {
        return this.getConfig().getJsContent(getSsconfig().getRcontext().getConfDirectory());
    }

    public String getJsFilePath() {
        return this.getConfig().getJsFilePath(getSsconfig().getRcontext().getConfDirectory());
    }

    public ReportSql getHeaderSql() {
        return getConfig().getSqls().get(0);
    }

    private void parameterInitialization() {
        setExternalAttribute(new HashMap<>());
        setValues(new HashMap<>());
        setObjectValues(new ArrayList<>());
        setIdBind(new HashMap<>());
        setReportResult(new HashMap<>());
        setSelectReportResult(new ArrayList<>());
        setSelectEditReportResult(new HashMap<>());
        setSelectableResult(null);
        setSelectableResults(new HashMap<>());
        setReportSidebarResult(new HashMap<>());
        setTargetServices(new ArrayList<>());
        setSelectedPdf(new HashMap<>());
        setListValues(new HashMap<>());
        setDialogParams(new ArrayList<>());
        setEditModeTemp("");
        setSelectedLine(new HashMap<>());
        setMaintConfig(null);
        setSelectMaster("");
        setWayOfUpload("upd");
        setOldSelectMaster("");        
        setUploadStatuses(null);
    }

    // Handsontable section start
    @ManagedProperty(value = "#{parentWindowSize}")
    private String parentWindowSize;
    @ManagedProperty(value = "#{handsontableVal}")
    private String handsontableVal;

    public void viewHandson() {
        Map<String,Object> options = new HashMap<>();
        options.put("resizable", false);
        options.put("modal", true);
        options.put("closable", false);
        options.put("width", "95%");
        options.put("height", Double.parseDouble(getParentWindowSize()) * 0.8);
        options.put("contentWidth", "100%");
        options.put("contentHeight", "100%");
//        options.put("widgetVar", "handson_grid_dlg");
//        handsontableVal = new ArrayList<>();
        RequestContext.getCurrentInstance().openDialog("/contents/handson_dialog", options, null);
    }

    public void closeHandson() {
        RequestContext.getCurrentInstance().closeDialog(null);
    }

    public void submitHandson(SelectEvent event) throws IOException, LogicException {
        if (event.getObject() == null) {
            // クローズボタン押下時動作
            return;
        }
        String tableVal = (String)event.getObject();
        ObjectMapper mapper = new ObjectMapper();
        List<List<String>> handsonResultList = mapper.readValue(tableVal, List.class);

        if (handsonResultList.size() < 1) {
            throw new LogicException("入力データがありません。");
        }

        if (this.getReportResult() == null) {
            this.setReportResult(new HashMap<>());
        }
        if (this.getReportResult().get(this.getConfig().getSqls().get(0).getName()) == null) {
            this.getReportResult().put(this.getConfig().getSqls().get(0).getName(), new ArrayList<>());
        }

        List<Map<String, Object>> tmpReportResult = new ArrayList<>();

        // 1行目からcolumn定義を取る(左詰めで設定されていることが条件)
//        List<String> columnSetting = handsonResultList.get(0);
//        // 2行目から、カラム名を取る(左詰めで設定されていることが条件)
//        List<String> columnBase = handsonResultList.get(1);
//        Map<String, Object> columnNames = new LinkedHashMap<>();
//        Map<String, Object> columnDisplays = new LinkedHashMap<>();
//        for (int i = 0; i < columnSetting.size(); i++) {
//            String columnName = columnSetting.get(i);
//            if (columnName.isEmpty()) continue;
//            columnNames.put(columnName, columnName);
//            columnDisplays.put(columnName, columnBase.get(i));
//        }
        Map<String, Object> columnNames = new LinkedHashMap<>();
        Map<String, Object> columnDisplays = new LinkedHashMap<>();
        if (!this.reportResult.get(this.config.getSqls().get(0).getName()).isEmpty()) {
            for (String key : columnDisplays.keySet()) {
                columnDisplays.put(key, "");
            }
        } else {
            List<String> columnBase = handsonResultList.get(0);
            for (int i = 0; i < columnBase.size(); i++) {
                String column = columnBase.get(i);
                if (column.isEmpty()) continue;
                columnDisplays.put("value" + i, "列" + i);
            }
        }

        for (int i = 2; i < handsonResultList.size(); i++) {
            List<String> oneLine = handsonResultList.get(i);
            Map<String, Object> line = new LinkedHashMap<>();
            int j = 0;
            for (String key : columnDisplays.keySet()) {
                line.put(key, oneLine.get(j++));
            }
            tmpReportResult.add(line);
        }

        if (this.getMaintConfig() == null) {
            tmpReportResult.add(0, columnDisplays);
            this.getReportResult().get(this.getConfig().getSqls().get(0).getName()).addAll(tmpReportResult);
            createUploadColumns();
        } else {
            this.getReportResult().get(this.getConfig().getSqls().get(0).getName()).addAll(tmpReportResult);
        }
        setSelectableResult(new ReportListDataModel(this.getReportResult().get(this.getConfig().getSqls().get(0).getName()), this.colPkName(this.getMaintConfig())));

//        System.out.println("handsonResultList : " + handsonResultList);
    }

    public void handleReturn() {
        RequestContext.getCurrentInstance().closeDialog(this.getHandsontableVal());

//        HttpServletRequest request = null;
//        HttpSession session = request.getSession(false);
//        HttpSession session = (HttpSession)  FacesContext.getCurrentInstance().getExternalContext().getSession(false);
//        if (session == null) {
//            response.sendRedirect("/WEB-INF/errorpages/expired.xhtml");
//            
//        }

    }
    // Handsontable section end

    /**
     * セッション継続のための空処理用メソッド
     */
    public void resetSessionTimeout() {
    }

    public void redirectLogin() throws IOException{
        FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
        FacesContext.getCurrentInstance().getExternalContext().redirect("/WEB-INF/errorpages/expired.xhtml");
    }

    /**
     * Excel帳票に罫線を引く（サンプル）
     * @param document 
     */
    public void ppMethod(Object document) {
        HSSFWorkbook wb = (HSSFWorkbook) document;
        HSSFSheet sheet = wb.getSheetAt(0);
        HSSFRow header = sheet.getRow(0);        
        
        HSSFCellStyle cellStyle = wb.createCellStyle();  
        cellStyle.setFillForegroundColor(HSSFColor.GREEN.index);
        cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

        cellStyle.setBorderTop(cellStyle.BORDER_DASHED);
        cellStyle.setBorderBottom(cellStyle.BORDER_DOUBLE);
        cellStyle.setBorderLeft(cellStyle.BORDER_MEDIUM_DASH_DOT);
        cellStyle.setBorderRight(cellStyle.BORDER_MEDIUM);          
        
        for(int i=0; i < header.getPhysicalNumberOfCells();i++) {
            HSSFCell cell = header.getCell(i);
             
            cell.setCellStyle(cellStyle);
        }
    }
    
    public List<String> getDivList(){
	List<String> divList = new ArrayList<String>();
	getConfig().getModification().getColumnsSort().forEach((column) -> {
	    if(!divList.contains(column.getApplyTo()) && column.getApplyTo().length() > 0){
		divList.add(column.getApplyTo());
	    }
        });
	return divList;
    }
    
    public List<Object> getDivColumns(String div){
	List<Object> divColumns = new ArrayList<Object>();
	getConfig().getModification().getColumnsSort().forEach((column) -> {
	    if(div == column.getApplyTo() && div.length() > 0){
		divColumns.add(column);
	    }
	});	
	return divColumns;
    }
    
 /**
     * 自分ボタン押下時に自分の情報を取得(担当者コード：担当者名を反映)
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     * @param  event
     * @throws java.lang.reflect.InvocationTargetException
     */
    public void selectSelfInfo(ActionEvent event) throws LogicException, SystemException, InvocationTargetException {
   
        String applyTo = (String)event.getComponent().getAttributes().get("applyTo");
        AbstractReportCondition column = (AbstractReportCondition)event.getComponent().getAttributes().get("condition");

        ReportSql targetDef = getConfig().getSqls().get(0);
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
        target.put(ExternalServiceExecuter.E_FUNCTION, "COM_SEARCH");
        target.put(ExternalServiceExecuter.E_SQL, "USER_SELF_SEARCH");
        target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, ReportConst.EditMode.SEARCH);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);
       
        Map<String, Object> sendParams = new HashMap<>();       
        target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);
        this.getTargetServices().add(target);
        searchProcess();
        setSelectableResult(new ReportListDataModel(this.getReportResult().get(targetDef.getName()), this.colPkName()));
        this.getValues().get(applyTo).put(column.getName(), getSelectableResult().getDatasource().get(0).get("VALUE").toString());
        column.setLabelValue(getSelectableResult().getDatasource().get(0).get("LABEL_VALUE").toString());

    }
       
    /**
     * 指定されたサービスのSQL呼び出しだけを行う 
     * s_furutani
     * @param num SQL番号
     * @param editmode SEARCHとかDELETE
     * @param function FUNC_XXXX_XXXの
     * @return select結果
     * @throws LogicException
     * @throws SystemException 
     */
    private List<Map<String, Object>> callSql(int num, String editmode, String function) throws LogicException, SystemException {
        
        ReportSql targetDef = getConfig().getSqls().get(num);
                
        Map<String, Object> target = new HashMap<>();
        this.setTargetServices(new ArrayList<>());
        target.put(ExternalServiceExecuter.E_SERVICE_URL, targetDef.getService());
        target.put(ExternalServiceExecuter.E_FUNCTION, function);
        target.put(ExternalServiceExecuter.E_SERVICE_NAME, targetDef.getName());
        target.put(ExternalServiceExecuter.P_EDIT_MODE_NAME, editmode);
        target.put(ExternalServiceExecuter.P_EDIT_ACTIVITY_NAME, ReportConst.Act.EXECUTE);
        this.getTargetServices().add(target);
        
        Map<String, Object> sendParams = new HashMap<>();
        //defaultValueのものはここに入る
        for(ReportCondition cond : getConfig().getConditions()) {
            if(cond.getDefaultValue() != null) {
                sendParams.put(cond.getName(), cond.getDefaultValue());
            }            
        } 
        //valueitのものはここに入る(defaultvalue上書き)
        Map<String,Object> formvalues = getValues().get(targetDef.getName());
        for( String key : formvalues.keySet() ){
            sendParams.put(key, formvalues.get(key));
        }
        
        //必須チェックrequired＞trueのものチェック
        String errcolumn = requiredValidate(sendParams);
        if (!"".equals(errcolumn)){
            FacesContext.getCurrentInstance().addMessage("messages", new FacesMessage(FacesMessage.SEVERITY_ERROR, "エラー", errcolumn + ": 必須項目が未入力です。"));
        }

        //明細チェック操作データ (tree or list)
        if ((null != this.selectReportResult && 0 != selectReportResult.size())){
            sendParams.put(ReportConst.F_SQLDATA.SELECTED_NODE, this.selectReportResult);
        }
        List<Map<String, Object>> selectdatas = selectableTreeResult.selectedmap(selectedNodes);
        if (0 != selectdatas.size()){
            sendParams.put(ReportConst.F_SQLDATA.SELECTED_NODE, selectdatas); 
        }

        //検索の場合は前回のデータを消去
        if (ReportConst.EditMode.SEARCH.equals(targetDef.getFunctionCode())){
            getSelectableTreeResult().datareset(); //ツリー形式
        } 
        
        target.put(ExternalServiceExecuter.P_SEND_PARAMETER, sendParams);
        searchProcess();
        
        if (this.getReportResult().containsKey(targetDef.getName())){
            return this.getReportResult().get(targetDef.getName());
        } else {
            //データが取得できない、または取得する必要が無い場合
            return new ArrayList<Map<String, Object>>();
        }
    } 

    /**
     * 必須チェックrequired＞trueチェック
     */
    private String requiredValidate(Map<String, Object> sendParams){
        //必須チェックrequired＞trueのものチェック
        String targetcolumn = null;
        StringBuffer sb = new StringBuffer();
        for(ReportCondition cond : getConfig().getConditions()) {
            if(cond.isRequired()){
                Object obj = sendParams.get(cond.getName());
                if (obj == null){
                    sb.append(cond.getName()).append(",");
                    continue;
                } else if (obj instanceof String){
                    if ("".equals((String)obj)){
                        sb.append(cond.getName()).append(",");
                        continue;
                    }
                }
            }
        }
        return sb.toString();
    }
    /**
     * サブボタンのボタン動作
     * @param act rpt.button.action
     * @throws Exception 
     */
    public void executeSubButton(String act) throws Exception {
        //明細行選択で、selectableTreeResult
        if (ReportConst.F_BTNACT.CHKLIST_UPDATE.equals(act)) {
            if ((getSelectedNodes() == null || getSelectedNodes().length == 0) &&
             (getSelectReportResult() == null || getSelectReportResult().isEmpty())){
                FacesContext.getCurrentInstance().addMessage("messages", new FacesMessage(FacesMessage.SEVERITY_ERROR, "エラー", "削除対象行が選択されていません。"));
                return;
            }
            if (null == this.getExecButton()){
                FacesContext.getCurrentInstance().addMessage("messages", new FacesMessage(FacesMessage.SEVERITY_ERROR, "エラー", "execButtonがxhtmlに未設定です。"));
                return;
            }
            this.callSql(0, ReportConst.EditMode.LIST_UPDATE, this.getExecButton().getName());
        } 
        this.callSql(0, ReportConst.EditMode.LIST_UPDATE, this.getExecButton().getName());
    }
    
/**
     * 各業務ロジック呼び出し(ActionEvent対応)
     * @param event
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException
     */
    public void callBusinessLogic(ActionEvent event) throws SystemException {
        
        // 画面からクラス、メソッド、オブジェクトの受け取る
        String strCls = (String)event.getComponent().getAttributes().get("cls");
        String strMt = (String)event.getComponent().getAttributes().get("method");
        objectValues = (ArrayList)event.getComponent().getAttributes().get("objectValues");

        if(!StringUtils.defaultString(strCls).equals("") && !StringUtils.defaultString(strMt).equals("")){
            try{
                // クラスのインスタンスを作成してメソッドを実行
                Class<?> cls;
                cls = Class.forName(ExternalServiceProperty.getInstance().getProperty("businesssource") + strCls);
                Object obj = cls.newInstance();
                Method mt = cls.getMethod(strMt, values.getClass(), event.getClass(), java.util.ArrayList.class);
                mt.invoke(obj, values, event, objectValues);

            }catch(ClassNotFoundException 
                    | IllegalAccessException
                    | IllegalArgumentException 
                    | InstantiationException 
                    | NoSuchMethodException
                    | SecurityException 
                    | InvocationTargetException ex){
                Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
                throw new SystemException(ex);
            }
        }
    }

/**
     * SVF出力
     * @param event
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException
     * @throws java.io.IOException
     * @throws jp.co.kintetsuls.exception.SystemException
     * @throws jp.co.kintetsuls.exception.LogicException
     */
    public int svfOutput(ActionEvent event) throws SystemException, IOException, jp.co.kintetsuls.exception.SystemException, jp.co.kintetsuls.exception.LogicException {
        
        SvfDataModel svfData = new SvfDataModel();  // SVF情報
        int ret = 0;
                 
        // 画面からクラス、メソッド、オブジェクト、出力パターンを受け取る
        String strCls = (String)event.getComponent().getAttributes().get("cls");
        String strMt = (String)event.getComponent().getAttributes().get("method");
        String strOutPtn = (String)event.getComponent().getAttributes().get("outPtn");
        svfData.setFileFormat(strOutPtn);
        objectValues = (ArrayList)event.getComponent().getAttributes().get("objectValues");

        if(!StringUtils.defaultString(strCls).equals("") && !StringUtils.defaultString(strMt).equals("")){
            try{
                // クラスのインスタンスを作成してメソッドを実行　SVF出力する情報を生成する
                Class<?> cls;
                cls = Class.forName(ExternalServiceProperty.getInstance().getProperty("businesssource") + strCls);
                Object obj = cls.newInstance();
                Method mt = cls.getMethod(strMt, values.getClass(), java.util.ArrayList.class, svfData.getClass());
                mt.invoke(obj, values, objectValues, svfData);

            }catch(ClassNotFoundException 
                    | IllegalAccessException
                    | IllegalArgumentException 
                    | InstantiationException 
                    | NoSuchMethodException
                    | SecurityException 
                    | InvocationTargetException ex){
                Logger.getLogger(SSNaviManagedBean.class.getName()).log(Level.SEVERE, null, ex);
                throw new SystemException(ex);
            }
            
            // メソッドの取得結果を反映してSVF出力を実行
            PrintReport rep = new PrintReport();
  
            // Excel、Pdfの場合とPreviewの場合で処理を分ける
            if (strOutPtn.equals(svfData.getPTN_EXCEL()) || strOutPtn.equals(svfData.getPTN_PDF())) {
                ret = rep.outputFile(svfData); 

            } else if (strOutPtn.equals(svfData.getPTN_PREV())) {
                ret = rep.preview(svfData);
                // 正常の場合
                if (ret == 0) {
                    objectValues.add(svfData);
                    svfValuesIndex = objectValues.size() - 1; 
                }
            }
        }
        return ret;
    }
    
    /**
     * @return the menuBean
     */
    public MenuBean getMenuBean() {
        return menuBean;
    }

    /**
     * @param menuBean the menuBean to set
     */
    public void setMenuBean(MenuBean menuBean) {
        this.menuBean = menuBean;
    }

    /**
     * @return the authConf
     */
    public AuthorityConfBean getAuthConf() {
        return authConf;
    }

    /**
     * @param authConf the authConf to set
     */
    public void setAuthConf(AuthorityConfBean authConf) {
        this.authConf = authConf;
    }

    /**
     * @return the ssconfig
     */
    public JsfSatteliteApplicationBean getSsconfig() {
        return ssconfig;
    }

    /**
     * @param ssconfig the ssconfig to set
     */
    public void setSsconfig(JsfSatteliteApplicationBean ssconfig) {
        this.ssconfig = ssconfig;
    }

    /**
     * @return the breadCrumbBean
     */
    public BreadCrumbBean getBreadCrumbBean() {
        return breadCrumbBean;
    }

    /**
     * @param breadCrumbBean the breadCrumbBean to set
     */
    public void setBreadCrumbBean(BreadCrumbBean breadCrumbBean) {
        this.breadCrumbBean = breadCrumbBean;
    }

    /**
     * @return the config
     */
    public ReportConfig getConfig() {
        return config;
    }

    /**
     * @param config the config to set
     */
    public void setConfig(ReportConfig config) {
        this.config = config;
    }

    /**
     * @return the oldConfig
     */
    public ReportConfig getOldConfig() {
        return oldConfig;
    }

    /**
     * @param oldConfig the oldConfig to set
     */
    public void setOldConfig(ReportConfig oldConfig) {
        this.oldConfig = oldConfig;
    }

    /**
     * @return the defConds
     */
    public Map<String, Object> getDefConds() {
        return defConds;
    }

    /**
     * @param defConds the defConds to set
     */
    public void setDefConds(Map<String, Object> defConds) {
        this.defConds = defConds;
    }

    /**
     * @return the maintConfig
     */
    public ReportConfig getMaintConfig() {
        return maintConfig;
    }

    /**
     * @param maintConfig the maintConfig to set
     */
    public void setMaintConfig(ReportConfig maintConfig) {
        this.maintConfig = maintConfig;
    }

    /**
     * @return the oldMaintConfig
     */
    public ReportConfig getOldMaintConfig() {
        return oldMaintConfig;
    }

    /**
     * @param oldMaintConfig the oldMaintConfig to set
     */
    public void setOldMaintConfig(ReportConfig oldMaintConfig) {
        this.oldMaintConfig = oldMaintConfig;
    }

    /**
     * @return the testText
     */
    public String getTestText() {
        return testText;
    }

    /**
     * @param testText the testText to set
     */
    public void setTestText(String testText) {
        this.testText = testText;
    }

    /**
     * @return the r
     */
    public String getR() {
        return r;
    }

    /**
     * @param r the r to set
     */
    public void setR(String r) {
        this.r = r;
    }

    /**
     * @return the isSearch
     */
    public String getIsSearch() {
        return isSearch;
    }

    /**
     * @param isSearch the isSearch to set
     */
    public void setIsSearch(String isSearch) {
        this.isSearch = isSearch;
    }

    /**
     * @return the isTrans
     */
    public String getIsTrans() {
        return isTrans;
    }

    /**
     * @param isTrans the isTrans to set
     */
    public void setIsTrans(String isTrans) {
        this.isTrans = isTrans;
    }

    /**
     * @return the curXhtml
     */
    public String getCurXhtml() {
        return curXhtml;
    }

    /**
     * @param curXhtml the curXhtml to set
     */
    public void setCurXhtml(String curXhtml) {
        this.curXhtml = curXhtml;
    }

    /**
     * @return the editMode
     */
    public String getEditMode() {
        return editMode;
    }

    /**
     * @param editMode the editMode to set
     */
    public void setEditMode(String editMode) {
        this.editMode = editMode;
    }

    /**
     * @return the editModeTemp
     */
    public String getEditModeTemp() {
        return editModeTemp;
    }

    /**
     * @param editModeTemp the editModeTemp to set
     */
    public void setEditModeTemp(String editModeTemp) {
        this.editModeTemp = editModeTemp;
    }

    /**
     * @return the reportResult
     */
    public Map<String, List<Map<String, Object>>> getReportResult() {
        return reportResult;
    }

    /**
     * @param reportResult the reportResult to set
     */
    public void setReportResult(Map<String, List<Map<String, Object>>> reportResult) {
        this.reportResult = reportResult;
    }

    /**
     * @return the oldReportResult
     */
    public Map<String, List<Map<String, Object>>> getOldReportResult() {
        return oldReportResult;
    }

    /**
     * @param oldReportResult the oldReportResult to set
     */
    public void setOldReportResult(Map<String, List<Map<String, Object>>> oldReportResult) {
        this.oldReportResult = oldReportResult;
    }

    /**
     * @return the visibleFilter
     */
    public Map<String, List<Boolean>> getVisibleFilter() {
        return visibleFilter;
    }

    /**
     * @param visibleFilter the visibleFilter to set
     */
    public void setVisibleFilter(Map<String, List<Boolean>> visibleFilter) {
        this.visibleFilter = visibleFilter;
    }

    /**
     * @return the selectableResult
     */
    public ReportListDataModel getSelectableResult() {
        return selectableResult;
    }

    /**
     * @param selectableResult the selectableResult to set
     */
    public void setSelectableResult(ReportListDataModel selectableResult) {
        this.selectableResult = selectableResult;
    }

    /**
     * @return the oldSelectableResult
     */
    public ReportListDataModel getOldSelectableResult() {
        return oldSelectableResult;
    }

    /**
     * @param oldSelectableResult the oldSelectableResult to set
     */
    public void setOldSelectableResult(ReportListDataModel oldSelectableResult) {
        this.oldSelectableResult = oldSelectableResult;
    }

    /**
     * @return the oldColumnList
     */
    public List<ReportColumn> getOldColumnList() {
        return oldColumnList;
    }

    /**
     * @param oldColumnList the oldColumnList to set
     */
    public void setOldColumnList(List<ReportColumn> oldColumnList) {
        this.oldColumnList = oldColumnList;
    }

    /**
     * @return the contextResult
     */
    public Map<String, List<Map<String, Object>>> getContextResult() {
        return contextResult;
    }

    /**
     * @param contextResult the contextResult to set
     */
    public void setContextResult(Map<String, List<Map<String, Object>>> contextResult) {
        this.contextResult = contextResult;
    }

    /**
     * @return the contextMenuResult
     */
    public ReportListDataModel getContextMenuResult() {
        return contextMenuResult;
    }

    /**
     * @param contextMenuResult the contextMenuResult to set
     */
    public void setContextMenuResult(ReportListDataModel contextMenuResult) {
        this.contextMenuResult = contextMenuResult;
    }

    /**
     * @return the contextTableResult
     */
    public ReportListDataModel getContextTableResult() {
        return contextTableResult;
    }

    /**
     * @param contextTableResult the contextTableResult to set
     */
    public void setContextTableResult(ReportListDataModel contextTableResult) {
        this.contextTableResult = contextTableResult;
    }

    /**
     * @return the columnLists
     */
    public ReportListDataModel getColumnLists() {
        return columnLists;
    }

    /**
     * @param columnLists the columnLists to set
     */
    public void setColumnLists(ReportListDataModel columnLists) {
        this.columnLists = columnLists;
    }

    /**
     * @return the optionLists
     */
    public Map<String, List> getOptionLists() {
        return optionLists;
    }

    /**
     * @param optionLists the optionLists to set
     */
    public void setOptionLists(Map<String, List> optionLists) {
        this.optionLists = optionLists;
    }

    /**
     * @return the selectableTreeResult
     */
    public ReportListTreeDataModel getSelectableTreeResult() {
        return selectableTreeResult;
    }

    /**
     * @param selectableTreeResult the selectableTreeResult to set
     */
    public void setSelectableTreeResult(ReportListTreeDataModel selectableTreeResult) {
        this.selectableTreeResult = selectableTreeResult;
    }

    /**
     * @return the selectableResults
     */
    public Map<String, ReportListDataModel> getSelectableResults() {
        return selectableResults;
    }

    /**
     * @param selectableResults the selectableResults to set
     */
    public void setSelectableResults(Map<String, ReportListDataModel> selectableResults) {
        this.selectableResults = selectableResults;
    }

    /**
     * @return the selectedNodes
     */
    public TreeNode[] getSelectedNodes() {
        return selectedNodes;
    }

    /**
     * @param selectedNodes the selectedNodes to set
     */
    public void setSelectedNodes(TreeNode[] selectedNodes) {
        this.selectedNodes = selectedNodes;
    }

    /**
     * @return the selectReportResult
     */
    public List<Map<String, Object>> getSelectReportResult() {
        return selectReportResult;
    }

    /**
     * @param selectReportResult the selectReportResult to set
     */
    public void setSelectReportResult(List<Map<String, Object>> selectReportResult) {
        this.selectReportResult = selectReportResult;
    }

    /**
     * @return the oldSelectReportResult
     */
    public List<Map<String, Object>> getOldSelectReportResult() {
        return oldSelectReportResult;
    }

    /**
     * @param oldSelectReportResult the oldSelectReportResult to set
     */
    public void setOldSelectReportResult(List<Map<String, Object>> oldSelectReportResult) {
        this.oldSelectReportResult = oldSelectReportResult;
    }

    /**
     * @return the selectEditReportResult
     */
    public Map<String, List<Map<String, Object>>> getSelectEditReportResult() {
        return selectEditReportResult;
    }

    /**
     * @param selectEditReportResult the selectEditReportResult to set
     */
    public void setSelectEditReportResult(Map<String, List<Map<String, Object>>> selectEditReportResult) {
        this.selectEditReportResult = selectEditReportResult;
    }

    /**
     * @return the reportSidebarResult
     */
    public Map<String, List<Map<String, Object>>> getReportSidebarResult() {
        return reportSidebarResult;
    }

    /**
     * @param reportSidebarResult the reportSidebarResult to set
     */
    public void setReportSidebarResult(Map<String, List<Map<String, Object>>> reportSidebarResult) {
        this.reportSidebarResult = reportSidebarResult;
    }

    /**
     * @return the selectMaster
     */
    public String getSelectMaster() {
        return selectMaster;
    }

    /**
     * @param selectMaster the selectMaster to set
     */
    public void setSelectMaster(String selectMaster) {
        this.selectMaster = selectMaster;
    }

    /**
     * @return the oldSelectMaster
     */
    public String getOldSelectMaster() {
        return oldSelectMaster;
    }

    /**
     * @param oldSelectMaster the oldSelectMaster to set
     */
    public void setOldSelectMaster(String oldSelectMaster) {
        this.oldSelectMaster = oldSelectMaster;
    }

    /**
     * @return the condMaster
     */
    public AbstractReportCondition getCondMaster() {
        return condMaster;
    }

    /**
     * @param condMaster the condMaster to set
     */
    public void setCondMaster(AbstractReportCondition condMaster) {
        this.condMaster = condMaster;
    }

    /**
     * @return the sortVal
     */
    public List<Map<String, Object>> getSortVal() {
        return sortVal;
    }

    /**
     * @param sortVal the sortVal to set
     */
    public void setSortVal(List<Map<String, Object>> sortVal) {
        this.sortVal = sortVal;
    }

    /**
     * @return the selectedSort
     */
    public String getSelectedSort() {
        return selectedSort;
    }

    /**
     * @param selectedSort the selectedSort to set
     */
    public void setSelectedSort(String selectedSort) {
        this.selectedSort = selectedSort;
    }

    /**
     * @return the execButton
     */
    public ReportButton getExecButton() {
        return execButton;
    }

    /**
     * @param execButton the execButton to set
     */
    public void setExecButton(ReportButton execButton) {
        this.execButton = execButton;
    }

    /**
     * @return the selectedPdf
     */
    public Map<String, ReportPdfGroup> getSelectedPdf() {
        return selectedPdf;
    }

    /**
     * @param selectedPdf the selectedPdf to set
     */
    public void setSelectedPdf(Map<String, ReportPdfGroup> selectedPdf) {
        this.selectedPdf = selectedPdf;
    }

    /**
     * @return the uploadFiles
     */
    public List<File> getUploadFiles() {
        return uploadFiles;
    }

    /**
     * @param uploadFiles the uploadFiles to set
     */
    public void setUploadFiles(List<File> uploadFiles) {
        this.uploadFiles = uploadFiles;
    }

    /**
     * @return the externalAttribute
     */
    public Map<String, Object> getExternalAttribute() {
        return externalAttribute;
    }

    /**
     * @param externalAttribute the externalAttribute to set
     */
    public void setExternalAttribute(Map<String, Object> externalAttribute) {
        this.externalAttribute = externalAttribute;
    }

    /**
     * @return the idBind
     */
    public Map<String, UIComponent> getIdBind() {
        return idBind;
    }

    /**
     * @param idBind the idBind to set
     */
    public void setIdBind(Map<String, UIComponent> idBind) {
        this.idBind = idBind;
    }

    /**
     * @return the values
     */
    public Map<String, Map<String, Object>> getValues() {
        return values;
    }

    /**
     * @param values the values to set
     */
    public void setValues(Map<String, Map<String, Object>> values) {
        this.values = values;
    }

    /**
     * @return the oldValues
     */
    public Map<String, Map<String, Object>> getOldValues() {
        return oldValues;
    }

    /**
     * @param oldValues the oldValues to set
     */
    public void setOldValues(Map<String, Map<String, Object>> oldValues) {
        this.oldValues = oldValues;
    }

    /**
     * @return the selectedLine
     */
    public Map<String, Object> getSelectedLine() {
        return selectedLine;
    }

    /**
     * @param selectedLine the selectedLine to set
     */
    public void setSelectedLine(Map<String, Object> selectedLine) {
        this.selectedLine = selectedLine;
    }

    /**
     * @return the listValues
     */
    public Map<String, List<Map<String, Object>>> getListValues() {
        return listValues;
    }

    /**
     * @param listValues the listValues to set
     */
    public void setListValues(Map<String, List<Map<String, Object>>> listValues) {
        this.listValues = listValues;
    }

    /**
     * @return the dialogParams
     */
    public List<Map<String, String>> getDialogParams() {
        return dialogParams;
    }

    /**
     * @param dialogParams the dialogParams to set
     */
    public void setDialogParams(List<Map<String, String>> dialogParams) {
        this.dialogParams = dialogParams;
    }

    /**
     * @return the targetServices
     */
    public List<Map<String, Object>> getTargetServices() {
        return targetServices;
    }

    /**
     * @param targetServices the targetServices to set
     */
    public void setTargetServices(List<Map<String, Object>> targetServices) {
        this.targetServices = targetServices;
    }

    /**
     * @return the wayOfUpload
     */
    public String getWayOfUpload() {
        return wayOfUpload;
    }

    /**
     * @param wayOfUpload the wayOfUpload to set
     */
    public void setWayOfUpload(String wayOfUpload) {
        this.wayOfUpload = wayOfUpload;
    }

    /**
     * @return the uploadStatuses
     */
    public Map<String,Object> getUploadStatuses() {
        return uploadStatuses;
    }

    /**
     * @param uploadStatuses the uploadStatuses to set
     */
    public void setUploadStatuses(Map<String,Object> uploadStatuses) {
        this.uploadStatuses = uploadStatuses;
    }

    /**
     * @return the uploadFileDef
     */
    public List<Map<String, Object>> getUploadFileDef() {
        return uploadFileDef;
    }

    /**
     * @param uploadFileDef the uploadFileDef to set
     */
    public void setUploadFileDef(List<Map<String, Object>> uploadFileDef) {
        this.uploadFileDef = uploadFileDef;
    }

    /**
     * @return the uploadFileName
     */
    public List<String> getUploadFileName() {
        return uploadFileName;
    }

    /**
     * @param uploadFileName the uploadFileName to set
     */
    public void setUploadFileName(List<String> uploadFileName) {
        this.uploadFileName = uploadFileName;
    }

    /**
     * @return the headerName
     */
    public String getHeaderName() {
        return headerName;
    }

    /**
     * @param headerName the headerName to set
     */
    public void setHeaderName(String headerName) {
        this.headerName = headerName;
    }

    /**
     * @return the isChange
     */
    public String getIsChange() {
        return isChange;
    }

    /**
     * @param isChange the isChange to set
     */
    public void setIsChange(String isChange) {
        this.isChange = isChange;
    }

    /**
     * @return the parentWindowSize
     */
    public String getParentWindowSize() {
        return parentWindowSize;
    }

    /**
     * @param parentWindowSize the parentWindowSize to set
     */
    public void setParentWindowSize(String parentWindowSize) {
        this.parentWindowSize = parentWindowSize;
    }

    /**
     * @return the handsontableVal
     */
    public String getHandsontableVal() {
        return handsontableVal;
    }

    /**
     * @param handsontableVal the handsontableVal to set
     */
    public void setHandsontableVal(String handsontableVal) {
        this.handsontableVal = handsontableVal;
    }

    /**
     * @return the objectValues
     */
    public ArrayList<Object> getObjectValues() {
        return objectValues;
    }

    /**
     * @param objectValues the objectValues to set
     */
    public void setObjectValues(ArrayList<Object> objectValues) {
        this.objectValues = objectValues;
    }

    /**
     * @return the oldObjectValues
     */
    public ArrayList<Object> getOldObjectValues() {
        return oldObjectValues;
    }

    /**
     * @param oldObjectValues the oldObjectValues to set
     */
    public void setOldObjectValues(ArrayList<Object> oldObjectValues) {
        this.oldObjectValues = oldObjectValues;
    }
    
    /**
     * columnTogglerが実行されたときに呼び出されます。
     * カラムのvisibleを更新します。
     */
    public void onToggle(org.primefaces.event.ToggleEvent e) {
        //ReportColumn rmod = config.getModification().getColumns().get((Integer)e.getData());
        //rmod.setVisible(e.getVisibility() == org.primefaces.model.Visibility.VISIBLE);
    }
}
