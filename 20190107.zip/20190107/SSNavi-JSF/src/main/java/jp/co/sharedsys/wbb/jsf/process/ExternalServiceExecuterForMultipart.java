package jp.co.sharedsys.wbb.jsf.process;

import com.fasterxml.jackson.core.type.TypeReference;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.sharedsys.wbb.jsf.exception.LogicException;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;
import jp.co.sharedsys.wbb.jsf.beans.SSNaviManagedBean;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateFormatUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.net.URLEncoder;
import java.text.ParseException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.wbb.jsf.beans.AuthorityConfBean;
import jp.co.sharedsys.wbb.jsf.external.general.ExternalAuthTokenClientHeader;
import jp.co.sharedsys.wbb.jsf.external.general.ExternalServiceProperty;
import static jp.co.sharedsys.wbb.jsf.process.ExternalServiceExecuter.E_SERVICE_NAME;
import static jp.co.sharedsys.wbb.jsf.process.ExternalServiceExecuter.P_EXEC_RES_MSG_ATTRIBUTE;
import static jp.co.sharedsys.wbb.jsf.process.ExternalServiceExecuter.P_EXEC_RES_STATUS_ATTRIBUTE;
import jp.co.sharedsys.wbb.jsf.reports.Input;
import jp.co.sharedsys.wbb.jsf.reports.ReportColumn;
import jp.co.sharedsys.wbb.jsf.reports.ReportConfig;
import jp.co.sharedsys.wbb.jsf.reports.ReportConst;
import jp.co.sharedsys.wbb.jsf.reports.ReportModification;
import jp.co.sharedsys.wbb.jsf.util.StringUtil;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataMultiPart;
import org.glassfish.jersey.media.multipart.MultiPart;
import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.glassfish.jersey.media.multipart.file.FileDataBodyPart;


public class ExternalServiceExecuterForMultipart extends AbstractExternalProcess<SSNaviManagedBean> {
    public static final String P_REPORTIDPARAM = "id-parameter-name";
    public static final String P_KEY = "application-key";
    public static final String P_ATTRIBUTE = "parameter-attribute-name";

    public static final String P_EDIT_MODE_NAME = "edit-name";
    public static final String P_EDIT_MODE_INSERT = "edit-name-value-insert";
    public static final String P_EDIT_MODE_UPDATE = "edit-name-value-update";
    public static final String P_EDIT_MODE_DELETE = "edit-name-value-delete";
    public static final String P_EDIT_ACTIVITY_NAME = "activity-name";
    public static final String P_EDIT_ACTIVITY_INIT = "activity-name-value-init";
    public static final String P_EDIT_ACTIVITY_ERROR = "activity-name-value-error";
    public static final String P_EDIT_ACTIVITY_EXECUTE = "activity-name-value-execute";
    public static final String P_INPUT_ATTRIBUTE = "input-attribute-name";
    public static final String PREFIX_COND_PARAM = "P_";
    public static final String P_EXEC_RES_STATUS_ATTRIBUTE = "exec-res-status-attribute-name";
    public static final String P_EXEC_RES_MSG_ATTRIBUTE = "exec-res-msg-attribute-name";
    public static final String P_IS_SEARCH = "is-search";

    public static final String P_EXTERNAL_ACCEPT = "external-accept";
    public static final String EXTERNAL_SERVICE_ACCEPT = "01f2f489152116ee94235918ec6d2461cb75a361ab9527dd";

    public static final String P_CURRENT_PAGE = "current-page";
    public static final String P_ALL_PAGE     = "all-page";
    public static final String P_LIMIT_PAGE   = "limit-page";
    public static final String P_RESULT_DATA_COUNT = "result-data-count";

    @Override
    public void onService(SSNaviManagedBean pageBean) throws LogicException, SystemException {
//	String pid = parameter.getParameter(P_REPORTIDPARAM);
//	String papp = parameter.getParameter(P_KEY);
	// 入力されたcondition
//	String pattribute = parameter.getParameter(P_ATTRIBUTE);
//	String repid = (String) parameter.getExternalParameter().get(pid);
        String repid = pageBean.getR();
	// 入力されたcolumn
//	String pattributeI = parameter.getParameter(P_INPUT_ATTRIBUTE);
//	String atrResStatus = parameter.getParameter(P_EXEC_RES_STATUS_ATTRIBUTE);
//	String atrResMsg = parameter.getParameter(P_EXEC_RES_MSG_ATTRIBUTE);

//	String externalAccept = parameter.getParameter(P_EXTERNAL_ACCEPT);

        ReportConfig config = pageBean.getConfig();
        if (config == null) {
            throw new LogicException("Specified report-id was not found.[" + repid + "]");
        }
        // 機能モード(INSERT/UPDATE/DELETE)
//      for (Map<String, String> target : pageBean.getTargetServices()) {
        Map<String, Object> target = pageBean.getTargetServices().get(0);
        // 機能モード(INSERT/UPDATE/DELETE)
        String modeName = (String)target.get(P_EDIT_MODE_NAME);
        modeName = modeName == null ? "" : modeName;
        String actName = (String)target.get(P_EDIT_ACTIVITY_NAME);
        actName = actName == null ? "" : actName;
        // 検索条件パラメータ取得
        // TODO パラメータ取得
//	List<Input> params = (List<Input>) parameter.getAttribute(pattribute);
	List<Input> params = new ArrayList<>();
	Map<String, Input> request = new HashMap<>();
	for (Input in : params) {
            request.put(in.getName(), in);
	}
        
//	parameter.setAttribute("request", request);
//	parameter.setAttribute("report_sqls", config.getSqls());

	// ログイン情報取得
//	HttpSession session = this.getSession(parameter);
//	List listUserId = SecurityUtils.getSecurityTokens(session, SecurityUtils.TOKEN_USERID);
//	List listGroup = SecurityUtils.getSecurityTokens(session, SecurityUtils.TOKEN_GROUP);
//	List listUserType = SecurityUtils.getSecurityTokens(session, SecurityUtils.TOKEN_USERTYPE);
//	listUserId = listUserId == null ? new ArrayList() : listUserId;
//	listGroup = listGroup == null ? new ArrayList() : listGroup;
//	listUserType = listUserType == null ? new ArrayList() : listUserType;
//	Map login = new HashMap();
//	login.put(SecurityUtils.TOKEN_USERID, (SecurityToken) listUserId.get(0));
//	login.put(SecurityUtils.TOKEN_GROUP, (SecurityToken) listGroup.get(0));
//	login.put(SecurityUtils.TOKEN_USERTYPE, (SecurityToken) listUserType.get(0));

        /** メイン処理 */
        ReportModification mod = config.getModification();
        mod = mod == null ? new ReportModification() : mod;
        // 追加更新削除確定時処理
        // 入力チェックでエラーが発生していた場合
        // 画面に再検索結果とedit対象を返却する

	// 登録時送信パラメータセット
        // 登録時送信パラメータセット
        Object inputParams = target.get(ExternalServiceExecuter.P_SEND_PARAMETER);

        if (StringUtils.equals(modeName, jp.co.sharedsys.wbb.jsf.reports.ReportConst.EditMode.SEARCH)) {
            inputParams = camelizedMap(inputParams, pageBean.getValues().get(target.get(E_SERVICE_NAME)));
        } else {
            try {
                inputParams = screeningKeyAndCamelize(inputParams, pageBean.getValues().get(target.get(E_SERVICE_NAME)), mod);
            } catch (ParseException ex) {
                logger.error(ex.getMessage(), ex);
                throw new SystemException(ex);
            }
        }
	// サービス名取得
        String service = (String)target.get(ExternalServiceExecuter.E_SERVICE_URL);
        String functionCode = (String)target.get(ExternalServiceExecuter.E_FUNCTION);

        try {
            // ****** file process **********
            List<File> files = pageBean.getUploadFiles();
            if(files != null && files.size() != 0) {
                /**** SSNavi : Service request ****/
                AuthorityConfBean authConf = pageBean.getAuthConf();
                ServiceInterfaceBean dto = this.requestExternalServiceForMultipart(service, inputParams, functionCode, authConf, files);

                // Json結果データをMapに変換
                ObjectMapper mapper = new ObjectMapper();
                Map<String, Object> jsonResMap = null;
                if (!StringUtils.equals(modeName, ReportConst.EditMode.LIST_UPDATE)
                        && !StringUtils.equals(modeName, ReportConst.EditMode.DETAIL_DELETE)
                        && !StringUtils.equals(modeName, ReportConst.EditMode.DETAIL_UPDATE)) {
                    // 一覧画面での更新の場合は、Jsonデータの解析はしない。
                    try {
                            jsonResMap = mapper.readValue(dto.getJson(), Map.class);
                    } catch (IOException e) {
                        logger.error("サービス側から意図しないパラメータが返ってきています。", e);
                        logger.error(e.getMessage(), e);
                        pageBean.getExternalAttribute().put(P_EXEC_RES_STATUS_ATTRIBUTE, "9");
                        pageBean.getExternalAttribute().put(P_EXEC_RES_MSG_ATTRIBUTE, jp.co.sharedsys.wbb.jsf.reports.ReportConst.Msg.SYSTEM_ERROR);
                        return ;
                    }
                }

                if (StringUtils.equals(modeName, ReportConst.EditMode.LIST_UPDATE)) {
                    // 一覧画面用
                    String issearch = (String) pageBean.getExternalAttribute().get(P_IS_SEARCH);
                    issearch = issearch == null ? "" : issearch;
                    pageBean.getExternalAttribute().put(P_IS_SEARCH, issearch);

                    if (dto.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_SUCCESS) {
                        pageBean.getExternalAttribute().put(P_EXEC_RES_STATUS_ATTRIBUTE, "0");
                    } else {
                        pageBean.getExternalAttribute().put(P_EXEC_RES_STATUS_ATTRIBUTE, "9");
                    }
                    pageBean.getExternalAttribute().put(P_EXEC_RES_MSG_ATTRIBUTE, dto.getMessage());
					// 取得されたデータをセット
                    try {
                        List searchResult = mapper.readValue(dto.getJson(), List.class);
                        pageBean.getReportResult().put((String)target.get(E_SERVICE_NAME), searchResult);
                    } catch (IOException e) {
                        logger.error("サービス側から意図しないパラメータが返ってきています。");
                        logger.error(e.getMessage(), e);
                        pageBean.getExternalAttribute().put(P_EXEC_RES_STATUS_ATTRIBUTE, "9");
                        pageBean.getExternalAttribute().put(P_EXEC_RES_MSG_ATTRIBUTE, ReportConst.Msg.SYSTEM_ERROR);
                        return ;
                    }
                } else {
                    // 編集画面用
                    if (StringUtils.equals(modeName, ReportConst.EditMode.BLOCK_DELETE)
                            || StringUtils.equals(modeName, ReportConst.EditMode.DETAIL_DELETE)
                            || StringUtils.equals(modeName, ReportConst.EditMode.DETAIL_UPDATE)
                            || StringUtils.equals(modeName, ReportConst.EditMode.DELETE)) {
                        // 削除モードの場合は終わったら、編集モードに戻す
                        pageBean.getExternalAttribute().put(P_EDIT_MODE_NAME, ReportConst.EditMode.UPDATE);
                    }

                    if (dto.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_SUCCESS) {
                        // 正常終了
                        if (StringUtils.equals(modeName, ReportConst.EditMode.INSERT)) {
                            // 新規時は、新規発行したIDで検索するため検索条件をリクエストにセットする
                            request = new HashMap<String, Input>();
                            List<ReportColumn> sortedColumns = mod.getColumnsSort("header");
                            for (ReportColumn col : sortedColumns){
                                if (col.isPk()) {
                                    for (String key : jsonResMap.keySet()) {
                                        if (StringUtils.equals(key, StringUtil.camelize(col.getName()))) {
                                            Input in = new Input();
                                            in.setName(PREFIX_COND_PARAM + col.getName());
                                            in.setApplyTo(col.getApplyTo());
                                            in.setType(col.getDataType());
                                            in.getValues().add(this.castToString(col, jsonResMap.get(key)));
                                            request.put(in.getName(), in);
                                            params.add(in);
                                        }
                                    }
                                }
                            }
                            pageBean.getExternalAttribute().put("request", request);
                            // 新規登録から更新モードにする
                            pageBean.getExternalAttribute().put(P_EDIT_MODE_NAME, ReportConst.EditMode.UPDATE);
                        }
                        pageBean.getExternalAttribute().put(P_EXEC_RES_STATUS_ATTRIBUTE, "0");
                        pageBean.getExternalAttribute().put(P_EXEC_RES_MSG_ATTRIBUTE, dto.getMessage());

                        // 再検索する
//                      parameter = executeSqls(parameter, config, request, login);
//                      parameter.setParameter(VelocityBase.P_TEMPLATE, config.getPageTemplate());
                    } else {
                        // エラー時
                        pageBean.getExternalAttribute().put(P_EXEC_RES_STATUS_ATTRIBUTE, "9");
                        pageBean.getExternalAttribute().put(P_EXEC_RES_MSG_ATTRIBUTE, dto.getMessage());
                    }
                }
                // TODO 画面表示系処理
//		VelocityPageGenerator generator = new VelocityPageGenerator();
//              generator.setWorkspace(this.getWorkspace());
//		parameter.setAttribute("vreportutil", new VReportUtility(this.getRequest(parameter)));
//		generator.onService(parameter);
            }
	}catch (SystemException e) {
            logger.error(e.getMessage(), e);
            pageBean.getExternalAttribute().put(P_EXEC_RES_STATUS_ATTRIBUTE, "9");
            pageBean.getExternalAttribute().put(P_EXEC_RES_MSG_ATTRIBUTE, ReportConst.Msg.SYSTEM_ERROR);
	} catch (Exception e) {
            logger.error(e.getMessage(), e);
            pageBean.getExternalAttribute().put(P_EXEC_RES_STATUS_ATTRIBUTE, "9");
            pageBean.getExternalAttribute().put(P_EXEC_RES_MSG_ATTRIBUTE, ReportConst.Msg.SYSTEM_ERROR);
	}
        // TODO 画面表示系処理
//	parameter.setParameter(VelocityBase.P_TEMPLATE, config.getPageTemplate());
//	VelocityPageGenerator generator = new VelocityPageGenerator();
//	generator.setWorkspace(this.getWorkspace());
//	parameter.setAttribute("vreportutil", new VReportUtility(this.getRequest(parameter)));
//	generator.onService(parameter);
    }

    /**
     * Stringに型変換
     * @param obj
     * @return
     */
    private String castToString(ReportColumn col, Object obj) {
        String val = "";
        if (obj == null) {
            return "";
        }

        if (obj instanceof Integer) {
            Integer i = (Integer)obj;
            val = i.toString();
        } else if (obj instanceof String) {
            val = (String) obj;
        } else if (obj instanceof Long) {
            Long l = (Long) obj;
            if (StringUtils.equals("DATE", col.getDataType())) {
                Date date = new Date(l);
                val = DateFormatUtils.format(date, "yyyy/MM/dd");
            } else if (StringUtils.equals("DATE_TIMESTAMP", col.getDataType())) {
                Date date = new Date(l);
                val = DateFormatUtils.format(date, "yyyy/MM/dd HH:mm:ss");
            } else {
                val = l.toString();
            }
        }
        return val;
    }

    protected ServiceInterfaceBean requestExternalServiceForMultipart(String url, Object params, String functionCode, AuthorityConfBean authConf, List<File> files) throws LogicException, SystemException {
        // JAX-RS接続
        try {
            // json作成
            String requestData = JSONUtil.makeJSONString(params);
            ServiceInterfaceBean req = new ServiceInterfaceBean();

            // セッションから取得する
            req.setUserId(authConf.getUserId());
            req.setUserGroupCode(authConf.getUserGroup());
            req.setFunctionCode(functionCode);
            req.setJson(requestData);
            String reqJson = JSONUtil.makeJSONString(req);
            
            Map paramMap = (Map)params;

//          List<Attachment> atts = new LinkedList<Attachment>();
//          atts.add(new Attachment("root", "application/json", reqJson));
//          // ****** file process **********
//	    for (int i = 0; i < files.size(); i++) {
//              atts.add(new Attachment("file"+i, "application/octet-stream", files.get(i)));
//	    }
            
            // request
            final Client client = ClientBuilder.newBuilder().register(MultiPartFeature.class).build();
            final MultiPart multipart = new FormDataMultiPart().field("root", reqJson, MediaType.APPLICATION_JSON_TYPE);
//                    .field("filename", file.getName(), MediaType.TEXT_PLAIN_TYPE);
            List fileNames = (List)paramMap.get("fileName");
            for (int i = 0; i < files.size(); i++) {
                File file = files.get(i);
                String fileName = URLEncoder.encode((String)fileNames.get(i), "UTF-8");
                FileDataBodyPart fileDataBodyPart = new FileDataBodyPart("file", file, MediaType.APPLICATION_OCTET_STREAM_TYPE);
                fileDataBodyPart.setContentDisposition(FormDataContentDisposition.name("file").fileName(fileName).build());
                multipart.bodyPart(fileDataBodyPart);
            }
            multipart.setMediaType(MediaType.MULTIPART_FORM_DATA_TYPE);
//            // POST request final
//            ClientResponse response = resource
//                    .type("multipart/form-data").post(ClientResponse.class,
//                            multipart);
            client.register(new ExternalAuthTokenClientHeader());
            final WebTarget target = client.target(ExternalServiceProperty.getInstance().getProperty("baseurl")).path(url);
            Invocation.Builder invocationBuilder =  target.request(MediaType.MULTIPART_FORM_DATA).accept(MediaType.APPLICATION_JSON);
            Response response = invocationBuilder.post(Entity.entity(multipart, MediaType.MULTIPART_FORM_DATA_TYPE));
     
            //Use response object to verify upload success
            multipart.close();
            String result = response.readEntity(String.class);
            ObjectMapper objectMapper = new ObjectMapper();
            ServiceInterfaceBean res = objectMapper.readValue(result, new TypeReference<ServiceInterfaceBean>() {});
            return res;
        } catch (Exception e) {
            throw new SystemException(e);
        }
    }

//	private List<FileItem> createUploadFiles(Message parameter) throws IOException {
//		DiskFileItemFactory factory = new DiskFileItemFactory();
//		factory.setSizeThreshold(4096);
//		ServletFileUpload upload = new ServletFileUpload(factory);
//		upload.setHeaderEncoding("UTF-8");
//		upload.setSizeMax(-1);
//
//		List<FileItem> files = new ArrayList<FileItem>();
//		try {
//			List<FileItem> items = upload.parseRequest(this.getRequest(parameter));
//			Map<String,String> options = new HashMap<String,String>();
//			for (FileItem item : items) {
//				System.out.println("item: " + item);
//				logger.info("items:"+ items);
//				logger.info("item.isFormField():"+ item.isFormField());
//				if (item.isFormField()) {
//					options.put(item.getFieldName(),item.getString());
//				} else {
////					DataHandler h = new DataHandler(new InputStreamDataSource(item.getInputStream(), "application/octet-stream"));
//					files.add(item);
//				}
//
//			}
////			parameter.setAttribute("fileitems", items);
//		} catch (FileUploadException e) {
//			logger.warn(e.getMessage());
//		}
//		return files;
//	}
}
