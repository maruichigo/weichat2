/*
 * JsfSatteliteApplicationBean.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.beans;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import jp.co.sharedsys.bb.ApplicationManager;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;
import jp.co.sharedsys.wbb.jsf.reports.ReportAppConfig;
import jp.co.sharedsys.wbb.jsf.reports.ReportConfig;
import jp.co.sharedsys.wbb.jsf.reports.ReportContext;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.io.comparator.NameFileComparator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * SSNaviの動作に必要な情報を保持するManagedBeanで、
 * アプリケーション上に単独で存在するインスタンスです。
 * アプリケーション起動時に設定ファイル群をロードし、インスタンスに保持します。
 * 
 * @author saihara
 */
@ManagedBean(name="ssconfig", eager=true)
@ApplicationScoped
public class JsfSatteliteApplicationBean implements Serializable {
	public static final String IP_HOME = "home-directory";
	public static final String IP_REPORT = "report-directory";
    
    @Getter
    private Map<String, ReportConfig> configs;
    @Getter
    private Map<String, String> screenCodesMap;
    @Getter
    private Map<String, List<ReportConfig>> configListMap;
    @Getter
    private List<ReportAppConfig> reportDirs;
    @Getter
    private String confDirectory = null;
    @Getter
    private ReportContext rcontext;
    @Getter @Setter
    private String sessionTimeout;

    private Logger logger = LoggerFactory.getLogger(this.getClass());
    
    public JsfSatteliteApplicationBean() {
        String homeDir = FacesContext.getCurrentInstance().getExternalContext().getInitParameter(IP_HOME);
        ApplicationManager.getInstance().setHomeDirectory(homeDir);
    }
    
    @PostConstruct
    public void init() {
//        if (FacesContext.getCurrentInstance().isPostback()) {
//            logger.debug("JsfSatteliteApplicationBean is postback...");
//            return;
//        }

        // ここでSSNavi定義ファイルを読み込む (アプリケーション起動時)
        // ManagedBean eager=true により、起動時インスタンス化を実現
        rcontext = new ReportContext();
        rcontext.setConfDirectory(ApplicationManager.getInstance().getHomeDirectory());
        rcontext.init();
        String home = ApplicationManager.getInstance().getHomeDirectory();

        // レポートのフォルダを取得する
        String reportdir = FacesContext.getCurrentInstance().getExternalContext().getInitParameter(IP_REPORT);
        reportdir = reportdir == null || reportdir.isEmpty() ? "reports" : reportdir;
        logger.warn("Home directory is [" + home + "]");
        logger.warn("Report directory name is [" + reportdir + "]");
		
        File directory = new File(home + "/" + reportdir);
        File[] repapps = directory.listFiles();

        List repappslist = new ArrayList();
        if (repapps != null){
                repappslist = Arrays.asList(repapps);
        }
        Collections.sort(repappslist,NameFileComparator.NAME_COMPARATOR);
        for (Iterator ite = repappslist.iterator();ite.hasNext();){
            File repapp = (File) ite.next();
            if (repapp.isDirectory()){
                try {
                    rcontext.loadDir(repapp);
                } catch (SystemException ex) {
                    logger.error(ex.getMessage(), ex);
                }
            }
        }        
        // config set
        this.confDirectory = rcontext.getConfDirectory();
        this.configListMap = rcontext.getConfigListMap();
        this.configs = rcontext.getConfigs();
        this.screenCodesMap = rcontext.getScreenCodes();
        this.reportDirs = rcontext.getRepordirs();
    }
}
