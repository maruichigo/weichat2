package jp.co.sharedsys.wbb.jsf.conf;

public class XReportFormat {
    private String fieldName = "";
    private String type = "";
    private String pattern = "";
    public String getFieldName() {
        return fieldName;
    }
    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public String getPattern() {
        return pattern;
    }
    public void setPattern(String pattern) {
        this.pattern = pattern;
    }
}
