/*
 * BreadCrumbBean.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.beans;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import jp.co.sharedsys.wbb.jsf.util.bean.PagePropertiesBean;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.beanutils.BeanUtils;
import org.primefaces.model.menu.DefaultMenuItem;
import org.primefaces.model.menu.DefaultMenuModel;
import org.primefaces.model.menu.MenuElement;
import org.primefaces.model.menu.MenuItem;
import org.primefaces.model.menu.MenuModel;

/**
 * パンくずリスト表示用Bean
 * @author saihara
 */
@ManagedBean
@ViewScoped
public class BreadCrumbBean implements Serializable {

    @Getter
    private List<PagePropertiesBean> proplist;    
    
    @Getter @Setter
    private MenuModel model;
    
    @Getter @Setter
    private boolean bUpdateFlg;
    
    @Getter @Setter
    private String curXhtml;
 
    @Getter @Setter
    private String screenId = "MST042_SCREEN";     
    
    @Getter
    private Map<String, PagePropertiesBean> properties;
    
    @Getter @Setter
    private MenuItem currentMenuItem;
    
    public BreadCrumbBean() {
        properties = new HashMap<>();
        model = new DefaultMenuModel();
               DefaultMenuItem item = new DefaultMenuItem("テスト画面へ");
        item.setUpdate(":main_section");
        item.setOnstart("PF('blw').block();");
        item.setOncomplete("doConfirm(args);PF('blw').unblock();scrollTo(0,0);");
        item.setCommand("#{pageBean.gotoNextForComMaint}");
            item.setParam("repid", screenId);
            PagePropertiesBean transPage = new PagePropertiesBean();
//            BeanUtils.copyProperties(transPage, pageBean);
            properties.put(screenId, transPage);
	model.addElement(item);
        
    }
    
 	public void setFortest(){
		proplist = new ArrayList<>();
		proplist.add(new PagePropertiesBean());
		properties = new HashMap<>();
		model = new DefaultMenuModel();
               DefaultMenuItem item = new DefaultMenuItem("title");
        item.setUpdate(":main_section");
        item.setOnstart("PF('blw').block();");
        item.setOncomplete("doConfirm(args);PF('blw').unblock();scrollTo(0,0);");
        item.setCommand("#{pageBean.gotoNextForComMaint}");
            item.setParam("repid", screenId);
            PagePropertiesBean transPage = new PagePropertiesBean();
//            BeanUtils.copyProperties(transPage, pageBean);
            properties.put(screenId, transPage);
		model.addElement(item);
	}           
    
    public BreadCrumbBean(MenuModel model) {
        if (model != null) {
            this.model = model;
            return;
        }
        
    }
    
    public void addCrumb(String title, SSNaviManagedBean pageBean) throws IllegalAccessException, InvocationTargetException {
        MenuItem item = createMenuItem(title, pageBean);
        model.addElement(item);
    }
    
    /**
     * crumb指定遷移時、遷移先画面までのパンくずリストに再構築する。
     * @param currentRepId reportId
     * @param curIdx index
     */
    public void crumbRestructure(String currentRepId, Integer curIdx) {
        MenuModel tmpModel = new DefaultMenuModel();
        int cnt = 0;
        for (MenuElement item : model.getElements()) {
            tmpModel.addElement(item);
            DefaultMenuItem itm = (DefaultMenuItem)item;
            if (currentRepId.equals(itm.getParams().get("repid").get(0))) {
                itm.setDisabled(true);
                itm.setStyleClass("currentBreadCrumb");
            } else {
                itm.setDisabled(false);
                itm.setStyleClass("");
            }
            if (curIdx != null && curIdx == cnt) {
                break;
            }
            cnt++;
        }
        model = tmpModel;
    }

    /**
     * メニューアイテム選択時遷移のパンくずリスト構築
     * @param repid reportid
     * @param pageBean pageBean
     * @throws IllegalAccessException illegal
     * @throws InvocationTargetException  invocation
     */
    public void gotoFirst(String repid, SSNaviManagedBean pageBean) throws IllegalAccessException, InvocationTargetException {
        DefaultMenuModel tmpModel = new DefaultMenuModel();
        // TOPのcrumb
        DefaultMenuItem topItem = (DefaultMenuItem)model.getElements().get(0);
        topItem.setDisabled(false);
        tmpModel.addElement(topItem);
        // 遷移先のcrumb
        DefaultMenuItem item = createMenuItem(pageBean.getConfig().getTitle(), pageBean);
        item.setDisabled(true);
        item.setStyleClass("currentBreadCrumb");
        tmpModel.addElement(item);
        // model入替え
        model = tmpModel;
        currentMenuItem = item;
    }
    
    public void gotoNext(SSNaviManagedBean pageBean, PagePropertiesBean oldPageParam) throws IllegalAccessException, InvocationTargetException {
        // プロパティ値更新
        properties.put(currentMenuItem.getParams().get("repid").get(0), oldPageParam);
        if (model.getElements().indexOf(currentMenuItem) >= model.getElements().size()-1) {
            // 現在の位置が最深部である場合
            crumbRestructure(pageBean.getConfig().getScreenCode(), null);
        } else {
            // リスト途中からの遷移の場合
            crumbRestructure(pageBean.getConfig().getScreenCode(), model.getElements().indexOf(currentMenuItem));
        }
        // 遷移先crumb
        DefaultMenuItem item = createMenuItem(pageBean.getConfig().getTitle(), pageBean);
        item.setDisabled(true);
        item.setStyleClass("currentBreadCrumb");
        model.addElement(item);
        currentMenuItem = item;
    }

    private DefaultMenuItem createMenuItem(String title, SSNaviManagedBean pageBean) throws IllegalAccessException, InvocationTargetException {
        DefaultMenuItem item = new DefaultMenuItem(title);
        item.setValue(title);
        item.setUpdate(":main_section");
        item.setOnstart("PF('blw').block();");
        item.setOncomplete("doConfirm(args);PF('blw').unblock();scrollTo(0,0);");
        item.setCommand("#{pageBean.transAtCrumb}");
        if (pageBean != null) {
            item.setParam("repid", pageBean.getConfig().getScreenCode());
            PagePropertiesBean transPage = new PagePropertiesBean();
            BeanUtils.copyProperties(transPage, pageBean);
            properties.put(pageBean.getConfig().getScreenCode(), transPage);
        } else {
            item.setParam("repid", "top_page");
        }
        return item;
    }
}