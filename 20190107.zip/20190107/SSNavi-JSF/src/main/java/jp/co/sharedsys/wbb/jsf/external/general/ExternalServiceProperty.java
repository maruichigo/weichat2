package jp.co.sharedsys.wbb.jsf.external.general;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import jp.co.sharedsys.bb.ApplicationManager;

public class ExternalServiceProperty {

    private static ExternalServiceProperty instance = null;
    private static Properties prop = null;

    private ExternalServiceProperty() {
        String configFile = ApplicationManager.getInstance().getHomeDirectory() + "/conf/exservice.properties";
//		String configFile = "./conf/exservice.properties";
        prop = new Properties();
        try {
            prop.load(new FileInputStream(configFile));
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }
    }

    public static ExternalServiceProperty getInstance() {
        if (instance == null) {
            instance = new ExternalServiceProperty();
        }
        return instance;
    }

    public String getProperty(String key){
        return prop.getProperty(key);
    }
}