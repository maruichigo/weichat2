/*
 * MenuModelBean.java

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.wbb.jsf.beans.common;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import javax.faces.event.ActionEvent;

/**
 *
 * @author 
 */
public class CommentDialogBean implements Serializable
{

    private CommentDialogDataModel commentDialogDataModel;

    public CommentDialogBean()
    {
        commentDialogDataModel = new CommentDialogDataModel();
    }

    public void updateComment(HashMap<String, HashMap<String, Object>> values, ActionEvent event, ArrayList<Object> obj) throws Exception
    {
        {
//            if (obj.isEmpty()) {
//                commentDialogDataModel.setComment("test");
//                commentDialogDataModel.setTableName("test");
//                commentDialogDataModel.setKeyColumnName1("test");
//                commentDialogDataModel.setKeyColumnName2("test");
//                commentDialogDataModel.setKeyColumnName3("test");
//                commentDialogDataModel.setUpdateColumnName("test");
//                obj.add(commentDialogDataModel);
//
//            }
            // objectValuesがブランクの場合、入力値をobjectValuesに追加する
            if (obj.isEmpty()) {
                obj.add(values);
                
            // objectValuesが既に設定済みの場合、入力値をobjectValuesに設定する
            } else {
                obj.set(0, values);
//                CommentDialogDataModel tb = (CommentDialogDataModel) obj.get(0);
//                tb.setComment("CommentDialogUpdate_TEST");
//                tb.setTableName("TR_YUSO_URIAGE");
//                tb.setKeyColumnName1("URIAGE_ID");
//                tb.setKeyColumnName2("");
//                tb.setKeyColumnName3("");
//                tb.setUpdateColumnName("URIAGE_COMMENT");
//                obj.add(values);
            }
        }
    }
}
