/**
 * 
 */
package jp.co.sharedsys.wbb.jsf.loader;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * @author sharedsys
 *
 */
public interface IModule {

    void execute(Connection conn) throws SQLException;
//	void setParameter(Message parameter);
    void setParameter();
}
