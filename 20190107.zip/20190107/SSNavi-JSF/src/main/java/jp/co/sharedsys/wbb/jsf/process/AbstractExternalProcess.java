package jp.co.sharedsys.wbb.jsf.process;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MediaType;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.common.json.JSONUtil;
import jp.co.sharedsys.wbb.jsf.exception.LogicException;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;
import jp.co.sharedsys.wbb.jsf.beans.AuthorityConfBean;
import jp.co.sharedsys.wbb.jsf.external.general.ExternalAuthTokenClientHeader;
import jp.co.sharedsys.wbb.jsf.external.general.ExternalServiceProperty;
import jp.co.sharedsys.wbb.jsf.reports.ReportAppConfig;
import jp.co.sharedsys.wbb.jsf.reports.ReportColumn;
import jp.co.sharedsys.wbb.jsf.reports.ReportConfig;
import jp.co.sharedsys.wbb.jsf.reports.ReportConst;
import jp.co.sharedsys.wbb.jsf.reports.ReportContext;
import jp.co.sharedsys.wbb.jsf.reports.ReportModification;
import jp.co.sharedsys.wbb.jsf.util.StringUtil;
import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public abstract class AbstractExternalProcess<T> {
    public static final String P_EXTERNAL_SERVICE = "external-service";
    public static final String P_EXTERNAL_FUNCTIION = "external-function";
    public static final String P_EXEC_RES_MSG_ATTRIBUTE = "exec-res-msg-attribute-name";
    public static final String P_EXTERNAL_ACCEPT = "external-accept";
    public static final String P_KEY = "application-key";
    protected final String EXTERNAL_MESSAGE = "external-message";
    protected final String EXTERNAL_STATUS = "external-status";
    protected String externalMessage = null;
    protected Logger logger = LoggerFactory.getLogger(this.getClass());
    public abstract void onService(T mbean) throws LogicException, SystemException;
    
    protected Object externalExecute(String service, String functionCode, String tableName, String loginUser, List<String> userGroupCodes, Object inputParams, boolean isInit) {
        List<Map<String, Object>> jsonResMapList = null;
        Map<String, List<Map<String, Object>>> jsonResMapMapList = null;
        Map<String, Object> jsonResMap = null;
        /**** SSNavi : Service request ****/
        try {
            ServiceInterfaceBean dto = requestExternalService(service, inputParams, functionCode, tableName, loginUser, userGroupCodes, isInit);

            // Json結果データをMapに変換
            ObjectMapper mapper = new ObjectMapper();
            // Jsonデータ解析
            try {
                jsonResMapList = mapper.readValue(dto.getJson(), new TypeReference<List<Map<String, Object>>>(){});
            } catch (IOException e) {
                try {
                    jsonResMapMapList = mapper.readValue(dto.getJson(), new TypeReference<Map<String,List<Map<String, Object>>>>(){});
                } catch (IOException ex) {
                    logger.error("サービス側から意図しないパラメータが返ってきています。");
                    logger.error(ex.getMessage(), ex);
                }
//	return null;
            }
            if (jsonResMapList != null && !jsonResMapList.isEmpty()) {
                jsonResMap = jsonResMapList.get(0);
            } else {
                if (jsonResMapMapList != null && !jsonResMapMapList.isEmpty()) {
                    for (Iterator<String> ite = jsonResMapMapList.keySet().iterator(); ite.hasNext();) {
                        jsonResMap = jsonResMapMapList.get(ite.next()).get(0);
                        jsonResMap.put(EXTERNAL_MESSAGE, dto.getMessage());
                        jsonResMap.put(EXTERNAL_STATUS, String.valueOf(dto.getStatusCode()));
                    }
                } else {
                    jsonResMap = new HashMap<>();
                    jsonResMapList = new ArrayList<>();
                    jsonResMapList.add(jsonResMap);
                }
            }
			
            jsonResMap.put(EXTERNAL_MESSAGE, dto.getMessage());
            jsonResMap.put(EXTERNAL_STATUS, String.valueOf(dto.getStatusCode()));
            externalMessage = dto.getMessage();
        } catch (SystemException e) {
            logger.error(e.getMessage(), e);
            jsonResMap = new HashMap<>();
            jsonResMapList = new ArrayList<>();
            jsonResMapList.add(jsonResMap);
            jsonResMap.put(EXTERNAL_STATUS, "-1");
            jsonResMap.put(EXTERNAL_MESSAGE, ReportConst.Msg.SYSTEM_ERROR);
            return jsonResMapList;
        } catch (LogicException e) {
            logger.error(e.getMessage(), e);
            return null;
        }
        if (jsonResMapMapList != null) {
                return jsonResMapMapList;
        }
        return jsonResMapList;
    }
	
    protected ServiceInterfaceBean requestExternalService(String url, Object params, String functionCode, String tableName, String loginUser, List<String> userGroupCodes, boolean isInit) throws LogicException, SystemException {
        // JAX-RS接続
        try {
            // json作成
            String requestData = JSONUtil.makeJSONString(params);
            ServiceInterfaceBean req = new ServiceInterfaceBean();
            // ログイン処理等のサービス呼び出しフラグ
            req.setInitial(isInit);

            req.setUserId(loginUser);
            req.setMakerCode(Arrays.asList(new String[]{"FORTINET"}));  // TODO dummy あとで消す
            if (userGroupCodes != null && !userGroupCodes.isEmpty()) {
                    req.setUserGroupCode(userGroupCodes);
            }

            req.setFunctionCode(functionCode);
            req.setTableName(tableName);
            req.setJson(requestData);
            String reqJson = JSONUtil.makeJSONString(req);

            // request
//          List<Object> providers = new ArrayList<>();
//	    providers.add(new JacksonJaxbJsonProvider());
            
            ClientConfig config = new ClientConfig();
            // Auth Token付与用フィルタ
            config.register(ExternalAuthTokenClientHeader.class);
            Client client = ClientBuilder.newClient(config);
            client.property(ClientProperties.CONNECT_TIMEOUT, 1200000);
//            client.property(ClientProperties.READ_TIMEOUT,    1000);
            // REST URL 設定
            WebTarget webTarget = client.target(ExternalServiceProperty.getInstance().getProperty("baseurl")).path(url);
            Invocation.Builder invocationBuilder =  webTarget.request(MediaType.APPLICATION_JSON);
            Response response = invocationBuilder.post(Entity.entity(reqJson, MediaType.APPLICATION_JSON_TYPE));
 
            String result = response.readEntity(String.class);
            ObjectMapper objectMapper = new ObjectMapper();
            ServiceInterfaceBean res = objectMapper.readValue(result, new TypeReference<ServiceInterfaceBean>() {});
            
//			ServiceInterfaceBean res = client.post(reqJson, ServiceInterfaceBean.class);
            return res;
        } catch (Exception e) {
            throw new SystemException(e);
        }
    }
	
    /**
     * 外部サービスから取得してきた機能使用権限リストが、SSNaviに配置されている機能に存在するかチェックする。
     * @param authConf authConf
     * @param rcontext reportcontext
     * @return boolean
     */
    protected boolean checkAuthAndDirs(AuthorityConfBean authConf, ReportContext rcontext) {
        List originalDirs = new ArrayList();
        originalDirs.addAll(rcontext.getRepordirs());
        Map originalConfigListMap = new HashMap();
        originalConfigListMap.putAll(rcontext.getConfigListMap());
        List replaceDirs = new ArrayList();
        Map replaceConfigListMap = new LinkedHashMap();
        for (Iterator<String> ite = authConf.getAuthMenu().keySet().iterator(); ite.hasNext();) {
            String menuCategory = ite.next();
            for (Iterator ited = originalDirs.iterator();ited.hasNext();) {
                ReportAppConfig app = (ReportAppConfig) ited.next();
                if (!menuCategory.equals(app.getScreenCode())) {
                    // ディレクトリにHitしなければ次
                    continue;
                }
                List originalReports = (List) originalConfigListMap.get(app.getDirectory());
                for (String screenCode : authConf.getAuthMenu().get(menuCategory)) {
                    for (Iterator iter = originalReports.iterator();iter.hasNext();) {
                        ReportConfig originalReportInConfig = (ReportConfig) iter.next();
                        if (screenCode.equals(originalReportInConfig.getScreenCode())) {
                            List report2add = (List)replaceConfigListMap.get(app.getDirectory());
                            if (report2add == null) { 
                                    report2add = new ArrayList<>();
                                    replaceConfigListMap.put(app.getDirectory(), report2add);
                            }
                            if (!replaceDirs.contains(app)) {
                                    replaceDirs.add(app);
                            }
                            report2add.add(originalReportInConfig);
                            break;
                        }
                    }
                }
            }
        }
        return replaceDirs.size() != 0 && replaceConfigListMap.size() != 0;
    }
    
    protected Map<String, Object> screeningKeyAndCamelize(Object inputParams, Map<String, Object> values, ReportModification mod) throws ParseException {
        Map<String, Object> newValues;
        if (inputParams != null) {
            newValues = (Map<String, Object>)inputParams;
        } else {
            newValues = new HashMap<>();
        }
        if (values == null || values.isEmpty()) return newValues;
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        for (Iterator<String> ite = values.keySet().iterator(); ite.hasNext();) {
            String key = ite.next();
            // controlTypeがHTML,LABELの場合は送信対象としない
            ReportColumn column = mod.getColumn(key);
            Object value = values.get(key);
            if (column == null) continue;
            if (column.getControlType().equals("HTML")) {
                continue;
            } else if (column.getControlType().equals("LABEL") && !column.isPk()) {
                continue;
            }
            if ("DATE".equals(column.getDataType())) {
                value = format.parse(String.valueOf(value));
            }
            String camelizedKey = StringUtil.camelize(key);
            newValues.put(camelizedKey, value);
        }
        return newValues;
    }
    
    protected Map<String, Object> camelizedMap(Object inputParams, Map<String, Object> values) {
        Map<String, Object> newValues;
        if (inputParams != null) {
            newValues = (Map<String, Object>)inputParams;
        } else {
            newValues = new HashMap<>();
        }
        if (values == null || values.isEmpty()) return newValues;
//        for (Iterator<String> ite = values.keySet().iterator(); ite.hasNext();) {
//            String key = ite.next();
//            String camelizedKey = StringUtil.camelize(key);
//            newValues.put(camelizedKey, values.get(key));
//        }
        return newValues;
    }   
}
