package jp.co.kintetsuls.common.svf;

import java.io.*;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import jp.co.fit.UCXSingle.UCXSingle;
import jp.co.kintetsuls.exception.LogicException;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.sharedsys.wbb.jsf.external.general.ExternalServiceProperty;

/**
 * 印刷共通機能（帳票出力）
 */
 public class PrintReport {
     
    // 入力必須エラーメッセージ
    final String ERROR_MESSAGE_VALIDATE_REQUIRED = "%sが指定されていません。";

    // ファイル形式の定義
    enum FileFormat {
        PDF,
        Excel,
        PREV,
    };
        
    // ファイル形式と拡張子の定義
    private final Map<String, String> fileExtensionMap = new HashMap<String, String>() {
        {
            put(FileFormat.PDF.name(), "pdf");
            put(FileFormat.Excel.name(), "xlsx");
            put(FileFormat.PREV.name(), "svfwdx");
        }
    };
        
    /**
     * 帳票出力（ファイル（PDF、Excel）に出力する場合）
     * @param svfData
     * @return 0=正常、正数=パラメータ不正、負数=エラーステータス
     * @throws IOException
     * @throws SystemException
     * @throws LogicException
     */
    public int outputFile(SvfDataModel svfData) throws IOException, SystemException, LogicException {
        //TODO:DONE:パラメータチェック
        if (isEmpty(svfData.getChohyoId())) {
            throw new LogicException(String.format(ERROR_MESSAGE_VALIDATE_REQUIRED, "帳票ID"));
        }
        if (isEmpty(svfData.getYoshiId())) {
            throw new LogicException(String.format(ERROR_MESSAGE_VALIDATE_REQUIRED, "用紙ID"));
        }
        if (isEmpty(svfData.getShutsuryokuFileMei())) {
            throw new LogicException(String.format(ERROR_MESSAGE_VALIDATE_REQUIRED, "出力ファイル名"));
        }
        if (isEmpty(svfData.getFileFormat())) {
            throw new LogicException(String.format(ERROR_MESSAGE_VALIDATE_REQUIRED, "ファイル形式"));
        }
        if (!Arrays.asList(FileFormat.PDF.name(), FileFormat.Excel.name(), FileFormat.PREV.name()).contains(svfData.getFileFormat())) {
            throw new LogicException(String.format("ファイル形式が不正です。fileFormat=%s", svfData.getFileFormat()));
        }
        if (isEmpty(svfData.getDataFilePath())) {
            throw new LogicException(String.format(ERROR_MESSAGE_VALIDATE_REQUIRED, "データファイル"));
        }

        long currentTime = System.currentTimeMillis();

        //ユニークなファイル名を生成します。
        //TODO:DONE:ユニーク度が不十分
        String TIMEN = String.valueOf(System.currentTimeMillis());
        String RAND = String.valueOf(new Random(currentTime).nextInt());

        //拡張子を付与します。ファイル形式（PDF=.pdf, Excel=.xlsx）
        //TODO:DONE:ケース分け
        String fileExtension = fileExtensionMap.get(svfData.getFileFormat());
        String outputfname = String.format("%s_%s.%s", TIMEN, RAND, fileExtension);

        //出力ファイルのパスを生成します。
        //TODO:DONE:上位パスをプロパティから取得
        //注意：SVFのIE用ActiveXがURL参照するため、外部から公開されたフォルダである必要がある。サンプルではresoucesの配下
        String resultFilePath;
        if (svfData.getFileFormat().equals(svfData.getPTN_EXCEL())) {
            resultFilePath = ExternalServiceProperty.getInstance().getProperty("ucx.resultexcelpath");
        } else {
            resultFilePath = ExternalServiceProperty.getInstance().getProperty("ucx.resultpdfpath");
        }
        
        String outputpath = new File(resultFilePath, outputfname).getPath();

        // Universal Connect/Xサーバーのホスト名
        //TODO:DONE:プロパティ化
        String host           = ExternalServiceProperty.getInstance().getProperty("ucx.xserver.host");
        // Universal Connect/Xサーバーのポート番号
        //TODO:DONE:プロパティ化
        int    port           =  Integer.parseInt(ExternalServiceProperty.getInstance().getProperty("ucx.xserver.port"));
        // 動作設定名 = 帳票ID_用紙ID_ファイル形式
        //TODO:パラメータから生成
        String settingName    = String.format("%s_%s_%s", svfData.getChohyoId(), svfData.getYoshiId(), svfData.getFileFormat());

        UCXSingle ucs = new UCXSingle();
        try {
            // Universal Connect/Xサーバーのホスト名、ポート番号を指定します。
            ucs.setUniConXServer(host, port);

            // 動作設定名を指定します。
            ucs.setSettingName(settingName);

            // データファイル名を指定します。
            ucs.setSourceName(svfData.getDataFilePath());

            // 処理が正常終了した場合に、データファイルを削除しません。
            ucs.setUndeleteSourceFile(true);

            // 処理が異常終了した場合に、データファイルを削除しません。
            ucs.setUndeleteSourceFileIfError(true);

            // 生成される出力ファイル名を指定します。
            ucs.setResultFileName(outputpath);

            // UCXサーバーとファイルを送受信する際に、ファイルを圧縮しません。
            ucs.useCompression(false);

            // 1/10ミリ単位で印字位置を調節します。(1ミリ単位から変換)
            ucs.setAdjustm(svfData.getAdjustX() * 10, svfData.getAdjustY() * 10);

            // 設定した動作設定に従って処理をします。
            ucs.doTransaction();

            // UCXSingleの実行結果を取得します。
            int ret = ucs.getUCXSingleResult();
            // Universal Connect/Xの実行結果を取得します。
            if (ret == 0) {
                ret = ucs.getUniConXResult();
            }

            //正常時
            if (ret == 0) {
                ByteArrayOutputStream byteStream = new ByteArrayOutputStream();

                try (BufferedInputStream inStream = new BufferedInputStream(new FileInputStream(outputpath))) {
                    int len=0;
                    byte[] buffer = new byte[1024];
                    while((len=inStream.read(buffer, 0, buffer.length))!=-1) {
                        byteStream.write(buffer, 0, len);
                    }
                }

                byte[] byteArray = byteStream.toByteArray();

                FacesContext facesContext = FacesContext.getCurrentInstance();
                ExternalContext exContext = facesContext.getExternalContext();
                exContext.responseReset();
                exContext.setResponseContentType(svfData.getCotextType());
                exContext.setResponseContentLength(byteArray.length);
                exContext.setResponseHeader("Content-Disposition", String.format("attachment; filename=TEST_SVF20181030.%s", fileExtension));

                // 送出
                try(OutputStream downloadStream = exContext.getResponseOutputStream()) {
                        downloadStream.write(byteArray);
                        downloadStream.flush();
                        exContext.responseFlushBuffer();
                        facesContext.responseComplete();
                }
                
            } else {
                throw new SystemException(String.format("帳票発行に失敗しました。エラーコード=%s", ret));
            }
        } catch (Exception ex) {
                //TODO:DONE:例外時の処理未実装
                if (ex instanceof IOException) {
                    throw new IOException(ex);
                }
                throw new SystemException(ex);
        }
        return 0;
    }

    /**
     * 帳票出力（クライアントでプレビューする場合）
     * @param svfData
     * @return 0=正常、正数=パラメータ不正、負数=エラーステータス
     * @throws IOException 
     * @throws SystemException 
     * @throws LogicException 
     */
    public int preview(SvfDataModel svfData) throws IOException, SystemException, LogicException {

        //TODO:DONE:パラメータチェック未実装
        if (isEmpty(svfData.getChohyoId())) {
            throw new LogicException(String.format(ERROR_MESSAGE_VALIDATE_REQUIRED, "帳票ID"));
        }
        if (isEmpty(svfData.getYoshiId())) {
            throw new LogicException(String.format(ERROR_MESSAGE_VALIDATE_REQUIRED, "用紙ID"));
        }
        if (isEmpty(svfData.getShutsuryokuFileMei())) {
            throw new LogicException(String.format(ERROR_MESSAGE_VALIDATE_REQUIRED, "出力ファイル名"));
        }
        if (isEmpty(svfData.getDataFilePath())) {
            throw new LogicException(String.format(ERROR_MESSAGE_VALIDATE_REQUIRED, "データファイル"));
        }

        long currentTime = System.currentTimeMillis();

        //ユニークなファイル名を生成します。
        //TODO:DONE:ユニーク度が不十分
        String TIMEN = String.valueOf(System.currentTimeMillis());
        String RAND = String.valueOf(new Random(currentTime).nextInt());

        String fileExtension = fileExtensionMap.get(svfData.getFileFormat());
        String outputfname = String.format("%s_%s.%s", TIMEN, RAND, fileExtension);

        //出力ファイルのパスを生成します。
        //TODO:DONE:上位パスをプロパティから取得
        String resultFilePath = ExternalServiceProperty.getInstance().getProperty("ucx.resultprevpath");
        String outputpath = new File(resultFilePath, outputfname).getPath();

        // Universal Connect/Xサーバーのホスト名
        //TODO:DONE:プロパティ化
        String host           = ExternalServiceProperty.getInstance().getProperty("ucx.xserver.host");

        // Universal Connect/Xサーバーのポート番号
        //TODO:DONE:プロパティ化
        int    port           =  Integer.parseInt(ExternalServiceProperty.getInstance().getProperty("ucx.xserver.port"));

        // 動作設定名 = 帳票ID_用紙ID_PREV
        //TODO:DONE:パラメータから生成
        String settingName    = String.format("%s_%s_PREV", svfData.getChohyoId(), svfData.getYoshiId());

        UCXSingle ucs = new UCXSingle();
        try {
            // Universal Connect/Xサーバーのホスト名、ポート番号を指定します。
            ucs.setUniConXServer(host, port);

            // 動作設定名を指定します。
            ucs.setSettingName(settingName);

            // データファイル名を指定します。
            ucs.setSourceName(svfData.getDataFilePath());

            // 処理が正常終了した場合に、データファイルを削除しません。
            ucs.setUndeleteSourceFile(true);

            // 処理が異常終了した場合に、データファイルを削除しません。
            ucs.setUndeleteSourceFileIfError(true);

            // 生成される出力ファイル名を指定します。
            ucs.setResultFileName(outputpath);

            // UCXサーバーとファイルを送受信する際に、ファイルを圧縮しません。
            ucs.useCompression(false);

            // 1/10ミリ単位で印字位置を調節します。(1ミリ単位から変換)
            ucs.setAdjustm(svfData.getAdjustX() * 10, svfData.getAdjustY() * 10);

            // 設定した動作設定に従って処理をします。
            ucs.doTransaction();

            // UCXSingleの実行結果を取得します。
            int ret = ucs.getUCXSingleResult();
            // Universal Connect/Xの実行結果を取得します。
            if (ret == 0) {
                ret = ucs.getUniConXResult();
            }

            if (0 <= ret) {
                //retの値が正の値だった場合の処理
                String prevPath = ExternalServiceProperty.getInstance().getProperty("svf-prevpath") + outputfname;
                svfData.setPrevFlag(true);
                svfData.setPrevFileUrl(prevPath);
                
            }
        } catch (Exception ex) {
            Logger.getLogger(PrintReport.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    /**
     * 未入力チェックを行う
     * @param s
     *              検証文字列
     * @return
     *              true:未入力 false:入力済
     */
    private static boolean isEmpty(String s) {
        return null == s || s.trim().isEmpty();
    }
}