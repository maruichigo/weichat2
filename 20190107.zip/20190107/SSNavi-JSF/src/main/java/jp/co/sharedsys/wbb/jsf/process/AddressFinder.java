package jp.co.sharedsys.wbb.jsf.process;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.StringUtils;
import java.io.IOException;
import java.util.HashMap;
import jp.co.sharedsys.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.wbb.jsf.exception.LogicException;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;
import jp.co.sharedsys.wbb.jsf.beans.AuthorityConfBean;
import jp.co.sharedsys.wbb.jsf.external.general.ExternalServiceProperty;
import jp.co.sharedsys.wbb.jsf.reports.ReportConst;
import lombok.Getter;
import lombok.Setter;


public class AddressFinder extends AbstractExternalProcess<Map<String, String>> {

    private static final String P_EDIT_ACTIVITY_EXECUTE = "EXECUTE";
    private static final String P_EXEC_RES_STATUS_ATTRIBUTE = "execResStatus";
    public static final String P_POSTAL_CODE = "POSTAL_CODE";
    
    @Setter
    private AuthorityConfBean authConf;
    @Getter
    private List<Map<String, Object>> searchResult;
    
    @Override
    public void onService(Map<String, String> option) throws LogicException, SystemException {

        // 機能モード(SEARCH)
        String modeName = "SEARCH";
        String actName = P_EDIT_ACTIVITY_EXECUTE;

        // サービス呼出時パラメータ取得
        Map<String, String> request = new HashMap<>();
        request.put("0", "POSTAL");
        request.put(P_POSTAL_CODE, option.get(P_POSTAL_CODE));

        /** メイン処理 */
        Object inputParams = request;
        // サービス名取得
        // 設定ファイルからデフォルトサービス取得
        String service = ExternalServiceProperty.getInstance().getProperty("external-service");
        String functionCode = "CODE_SEARCH";
        String tableName = "";
        /**** SSNavi : Service request ****/
        try {
            ServiceInterfaceBean dto = this.requestExternalService(service, inputParams, functionCode, tableName, authConf.getUserId(), authConf.getUserGroup(), false);

            // Json結果データをMapに変換
            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> jsonResMap = null;

            if (StringUtils.equals(modeName, ReportConst.EditMode.SEARCH)) {
                try {
                    List searchResult = mapper.readValue(dto.getJson(), List.class);
                    this.searchResult = searchResult;
                } catch (IOException e) {
                    logger.error("サービス側から意図しないパラメータが返ってきています。");
                    logger.error(e.getMessage(), e);
//                    pageBean.getExternalAttribute().put(P_EXEC_RES_STATUS_ATTRIBUTE, "9");
//                    pageBean.getExternalAttribute().put(P_EXEC_RES_MSG_ATTRIBUTE, ReportConst.Msg.SYSTEM_ERROR);
                }
            }
        }catch (SystemException e) {
            logger.error(e.getMessage(), e);
//            pageBean.getExternalAttribute().put(P_EXEC_RES_STATUS_ATTRIBUTE, "9");
//            pageBean.getExternalAttribute().put(P_EXEC_RES_MSG_ATTRIBUTE, ReportConst.Msg.SYSTEM_ERROR);
        }
    }
}
