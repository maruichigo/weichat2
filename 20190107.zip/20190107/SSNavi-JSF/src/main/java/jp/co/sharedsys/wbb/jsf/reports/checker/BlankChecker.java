package jp.co.sharedsys.wbb.jsf.reports.checker;

import java.io.Serializable;

import jp.co.sharedsys.wbb.jsf.exception.LogicException;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;
import jp.co.sharedsys.wbb.jsf.reports.IParameterChecker;
import jp.co.sharedsys.wbb.jsf.reports.ReportConfig;

public class BlankChecker implements IParameterChecker, Serializable{
    /**
     * 
     */
    private static final long serialVersionUID = 6312995432283905912L;
    private ReportConfig config = null;

    public void check() throws LogicException, SystemException {
    }

    public void setReportConfig(ReportConfig config) {
        this.config = config;
    }

    public ReportConfig getReportConfig() {
        return this.config;
    }
}
