package jp.co.sharedsys.wbb.jsf.process;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpSession;
import jp.co.sharedsys.wbb.jsf.exception.LogicException;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;

import jp.co.sharedsys.wbb.jsf.beans.AuthorityConfBean;
import jp.co.sharedsys.wbb.jsf.beans.UserLoginView;
import jp.co.sharedsys.wbb.jsf.external.general.ExternalServiceProperty;
import jp.co.sharedsys.wbb.jsf.reports.ReportAppConfig;
import jp.co.sharedsys.wbb.jsf.reports.ReportConfig;
import jp.co.sharedsys.wbb.jsf.reports.ReportContext;
import org.primefaces.model.menu.DefaultMenuColumn;
import org.primefaces.model.menu.DefaultMenuItem;
import org.primefaces.model.menu.DefaultMenuModel;
import org.primefaces.model.menu.DefaultSubMenu;
import org.primefaces.model.menu.MenuModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MenuCreationProcess extends AbstractExternalProcess<UserLoginView>{

    public static final String P_KEY = "application-key";
    public static final String P_REPAPPS = "application-attribute";
    public static final String P_REPCONFIGS = "reportconfig-attribute";
//	private static final String TOKEN_TYPE = SecurityUtils.TOKEN_MENU;
    private static final String RULE_TYPE = "report-menu";
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public void onService(UserLoginView userLogin) throws LogicException, SystemException {

        // システムのメニュー取得
        ReportContext rcontext = userLogin.getSsconfig().getRcontext();
        String service = ExternalServiceProperty.getInstance().getProperty("external-service");
        String function = ExternalServiceProperty.getInstance().getProperty("loadmenu-func");
        String user = ExternalServiceProperty.getInstance().getProperty("loadmenu-user");
        rcontext.loadExternal(service, function, user);

        ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
        HttpServletRequest request = (HttpServletRequest) externalContext.getRequest();
        HttpSession session = request.getSession();
        if (session == null) {
            logger.warn("session is not available.");
            return;
        }

//	String pkey = parameter.getParameter(P_KEY);
//	pkey = pkey == null || "".equals(pkey) ? "default" : pkey;
//	String papps = parameter.getParameter(P_REPAPPS);
//	String pconf = parameter.getParameter(P_REPCONFIGS);

        //first, copy data
        List originalDirs = new ArrayList();
        originalDirs.addAll(rcontext.getRepordirs());
        Map<String, List<ReportConfig>> originalConfigListMap = new HashMap<>();
        originalConfigListMap.putAll(rcontext.getConfigListMap());
        logger.info("ORIGINAL DIRS [" + originalDirs.size() + "] CONFIGS [" + originalConfigListMap.entrySet().size() + "]");

        //to replace
        List<ReportAppConfig> replaceDirs = new ArrayList<>();
        Map<String, List<ReportConfig>> replaceConfigListMap = new LinkedHashMap<>();
//	//remove once
//	parameter.removeAttribute(papps);
//	parameter.removeAttribute(pconf);
//	//replace!
//	parameter.setAttribute(papps, replaceDirs);
//	parameter.setAttribute(pconf, replaceConfigListMap);

        //セッション情報をチェック
        AuthorityConfBean authConf = userLogin.getAuthConf();
		
        // ログイン時に取得した使用可能メニューの順にチェックする -> DBに指定されているソート順でListを作成
        for (Iterator<String> ite = authConf.getAuthMenu().keySet().iterator(); ite.hasNext();) {
            String menuCategory = ite.next();
            for (Iterator ited = originalDirs.iterator();ited.hasNext();) {
                ReportAppConfig app = (ReportAppConfig) ited.next();
                if (!menuCategory.equals(app.getScreenCode())) {
                    // ディレクトリにHitしなければ次
                    continue;
                }
                List originalReports = (List) originalConfigListMap.get(app.getDirectory());
                for (String screenCode : authConf.getAuthMenu().get(menuCategory)) {
                    for (Iterator iter = originalReports.iterator();iter.hasNext();) {
                        ReportConfig originalReportInConfig = (ReportConfig) iter.next();
                        if (screenCode.equals(originalReportInConfig.getScreenCode())) {
                            List report2add = (List)replaceConfigListMap.get(app.getDirectory());
                            if (report2add == null) { 
                                report2add = new ArrayList<>();
                                replaceConfigListMap.put(app.getDirectory(), report2add);
                            }
                            if (!replaceDirs.contains(app)) {
                                replaceDirs.add(app);
                            }
                            report2add.add(originalReportInConfig);
                            break;
                        }
                    }
                }
            }
        }
        // MenuModel を作る
        userLogin.getMenuBean().setModel(createMenuModel(replaceDirs, replaceConfigListMap));
        logger.info("Security filtered:[" +replaceDirs.size() + "][" + replaceConfigListMap.size() + "]" );
    }

    private MenuModel createMenuModel(List<ReportAppConfig> replaceDirs, Map<String, List<ReportConfig>> replaceConfigListMap) {
        MenuModel model = new DefaultMenuModel();
        for (ReportAppConfig app : replaceDirs) {
            List<ReportConfig> reports = replaceConfigListMap.get(app.getDirectory());
            // First category
            DefaultSubMenu rootMenu = new DefaultSubMenu(app.getTitle());
            model.addElement(rootMenu);
            // TODO section menu changes
            // column section
            DefaultMenuColumn menuSection = new DefaultMenuColumn();
            rootMenu.addElement(menuSection);
            DefaultSubMenu sectionMenu = new DefaultSubMenu(app.getTitle());
            sectionMenu.setId(app.getScreenCode());
            menuSection.addElement(sectionMenu);
            for (ReportConfig config :reports) {
                DefaultMenuItem item = new DefaultMenuItem(config.getTitle());
                item.setCommand("#{pageBean.gotoNext}");
                item.setUpdate(":main_section");
                item.setParam("repid", config.getScreenCode());
                item.setOnstart("PF('blw').block();");
                item.setOncomplete("doConfirm(args); PF('blw').unblock();scrollTo(0,0);");
                item.setStyleClass("ssnavi-itemlink");
                sectionMenu.addElement(item);
            }
        }
        // 設定されたSubMenu,MenuItemにユニークなIDが設定されていないと、メニュー動作が出来ない為、
        // 最後にgenerateUniqueIdsを実行する
        model.generateUniqueIds();
        return model;
    }
}
