/*
 * SvfDataModel.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.common;

import java.util.List;
import java.util.ArrayList;
import javax.faces.application.FacesMessage;

/**
 * Message情報のModelクラスです。
 *
 * @author sharedSystem
 */
public class MessageDataModel {

	private List<FacesMessage> messages = new ArrayList<FacesMessage>();
	
	
    private ArrayList messageKbn;          // メッセージ区分
    private ArrayList message;             // メッセージ

	
    /**
     * @return the messageKbn
     */
    public ArrayList getMessageKbn() {
        return messageKbn;
    }

    /**
     * @param messageKbn the messageKbn to set
     */
    public void setMessageKbn(ArrayList messageKbn) {
        this.messageKbn = messageKbn;
    }

    /**
     * @return the message
     */
    public ArrayList getMessage() {
        return message;
    }

    /**
     * @param message the message to set
     */
    public void setMessage(ArrayList message) {
        this.message = message;
    }

//facesMessages形式
	/**
	 * メッセージ一覧を取得する
	 * @return 
	 */
	public List<FacesMessage> getFacesMessages() {
		return messages;
	}

	/**
	 * facesmessageを格納する。
	 * @param message 
	 */
	public void addFacesMessage(FacesMessage message) {
		this.messages.add(message);
	}
	/**
	 * メッセージを格納する。
	 * @param level   INFO,WARN,ERROR,FATAL
	 * @param summary 協調メッセージ
	 * @param message メッセージ内容
	 */
	public void addFacesMessage(String level, String summary, String message) {
		FacesMessage.Severity severity = getMsgIcon(level);
		this.messages.add(new FacesMessage(severity, summary, message));
	}

    public static FacesMessage.Severity getMsgIcon(String level){
		switch (level) {
			case "通常":
			case "INFO":
				return FacesMessage.SEVERITY_INFO;
			case "注意":
			case "WARN":
				return FacesMessage.SEVERITY_WARN;
			case "警告":
			case "ERROR":
				return FacesMessage.SEVERITY_ERROR;
			case "異常":
			case "FATAL":
				return FacesMessage.SEVERITY_FATAL;
			default:
				return FacesMessage.SEVERITY_INFO;
		}
	}
}
