package jp.co.sharedsys.wbb.jsf.conf;

public class XReportPdfConfig {
    private String formatFile = null;
    private String sqlFile = null;
    private String connection = null;
    private String name = null;
    private String prevService = null;
    private String afterService = null;
    private String sortKey = null;

    public String getFormatFile() {
        return formatFile;
    }
    public void setFormatFile(String action) {
        this.formatFile = action;
    }
    public String getSqlFile() {
        return sqlFile;
    }
    public void setSqlFile(String rptFile) {
        this.sqlFile = rptFile;
    }
    public String getConnection() {
        return connection;
    }
    public void setConnection(String connection) {
        this.connection = connection;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getPrevService() {
        return prevService;
    }
    public void setPrevService(String prevService) {
        this.prevService = prevService;
    }
    public String getAfterService() {
        return afterService;
    }
    public void setAfterService(String afterService) {
        this.afterService = afterService;
    }
    public String getSortKey() {
        return sortKey;
    }
    public void setSortKey(String sortkey) {
        this.sortKey = sortkey;
    }
}
