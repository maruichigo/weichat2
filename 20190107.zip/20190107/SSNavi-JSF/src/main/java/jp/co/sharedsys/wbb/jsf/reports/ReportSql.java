package jp.co.sharedsys.wbb.jsf.reports;

import java.io.Serializable;
import java.util.Map;

import jp.co.sharedsys.wbb.jsf.loader.IModule;
import lombok.Data;

@Data
public class ReportSql implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 6562300961982071698L;
    private String connection = null;
    private String name = null;
    private String templateFile = null;
    private boolean preparedStatementType = false;
    private String description = null;
    private boolean customClassType = false;
    private IModule module = null;
    private Map<String,Input> params = null;
    private String moduleName = null;
    private boolean showResult = false;
    private boolean downloadable = true;
    private boolean showAddRowButton = false;
    private boolean showDelRowButton = false;
    private String dataClass;
    private String detailMode;
    private String tableName;
    private String service;
    private String functionCode;

}