package jp.co.kintetsuls.common.util;

import java.nio.file.Paths;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;

/**
 * プロパティ取得ユーティリティ
 * @author asaga
 */
public class PropertyUtil {

    private static final String INIT_FILE_PATH = "application.properties";
    private static final PropertiesConfiguration config;

    private PropertyUtil() throws Exception {
    }

    static {
        config = new PropertiesConfiguration();
        try {
            config.setEncoding("UTF-8");
            config.setFile(Paths.get(INIT_FILE_PATH).toFile());
            config.load();
        } catch (ConfigurationException e) {
            // ファイル読み込みに失敗
            System.out.println(String.format("ファイルの読み込みに失敗しました。ファイル名:%s", INIT_FILE_PATH));
        }
    }

    /**
     * プロパティ値を取得する（文字列）
     *
     * @param key キー
     * @return キーが存在しない場合、空文字
     *          存在する場合、値
     */
    public static String getString(final String key) {
        return getString(key, "");
    }

    /**
     * プロパティ値を取得する（文字列）
     *
     * @param key キー
     * @param defaultValue デフォルト値
     * @return キーが存在しない場合、デフォルト値
     *          存在する場合、値
     */
    public static String getString(final String key, final String defaultValue) {
        return config.getString(key, defaultValue);
    }

    /**
     * プロパティ値を取得する（整数値）
     *
     * @param key キー
     * @return キーが存在しない場合、0
     *          存在する場合、値
     */
    public static int getInt(final String key) {
        return getInt(key, 0);
    }

    /**
     * プロパティ値を取得する（整数値）
     *
     * @param key キー
     * @param defaultValue デフォルト値
     * @return キーが存在しない場合、デフォルト値
     *          存在する場合、値
     */
    public static int getInt(final String key, final int defaultValue) {
        return config.getInt(key, defaultValue);
    }

    /**
     * プロパティ値を取得する（論理値）
     *
     * @param key キー
     * @return キーが存在しない場合、false
     *          存在する場合、値
     */
    public static boolean getBoolean(final String key) {
        return getBoolean(key, false);
    }

    /**
     * プロパティ値を取得する（論理値）
     *
     * @param key キー
     * @param defaultValue デフォルト値
     * @return キーが存在しない場合、デフォルト値
     *          存在する場合、値
     */
    public static boolean getBoolean(final String key, final boolean defaultValue) {
        return config.getBoolean(key, defaultValue);
    }

}
