/*
 * AuthorityConfBean.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.application.ConfigurableNavigationHandler;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import lombok.Data;
import org.primefaces.context.RequestContext;
import org.primefaces.model.menu.MenuModel;

/**
 * ログインユーザー情報を格納するManagedBeanです。
 * ログイン成功時に生成され、セッションスコープで持ち回ります。
 * @author Shared System Inc.
 */
@ManagedBean(name = "authConf")
@SessionScoped
@Data
public class AuthorityConfBean implements Serializable {

    private static final long serialVersionUID = -8006365439680582676L;

    private Map<String, String> functionList = new HashMap<>();
    private boolean admin = false;
    private List<String> userGroup = null;
    private List<String> dataGroup = null;
    private String userId = null;
    private String groupSelectInd = null;
    private List<String> authScreen = new ArrayList<>();
    private Map<String, List<String>> authMenu = new LinkedHashMap<>();
    private MenuModel menuModel;
    private boolean HUpdateFlg = false;

    public boolean isAllEnabledFunction() {
        return isAdmin() || functionList.containsKey("ALL");
    }
    
    public void isLoggedIn() {
        if (userId == null) {
            ConfigurableNavigationHandler handler = (ConfigurableNavigationHandler)FacesContext.getCurrentInstance().getApplication().getNavigationHandler();
            handler.performNavigation("login");
        }
    }
    
    public String logout() {
        if ( HUpdateFlg ) {
            // callbackで判定戻し（編集中）
            RequestContext context = RequestContext.getCurrentInstance();  
            context.addCallbackParam("updateFlg", HUpdateFlg );
            context.addCallbackParam("cfType", "header");            
            return null;
        } else {
            FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
            return "/login.xhtml?faces-redirect=true";
        }
//        return "/login.xhtml";
    }
    
    public boolean loggedIn() {
        return userId != null && !userId.isEmpty();
    }
}
