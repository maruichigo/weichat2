/*
 * MenuModelBean.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.wbb.jsf.beans.test;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import jp.co.kintetsuls.common.svf.SvfDataModel;

/**
 * Svf出力機能
 * @author 
 */
public class TestSvfOutput implements Serializable {

     public void svfOutPut(HashMap<String, HashMap<String, Object>> values, ArrayList<Object> obj, SvfDataModel svfData) throws Exception {
        
        svfData.setChohyoId("REP01");                           // 帳票ID
        svfData.setYoshiId("LET01");                            // 用紙ID
        svfData.setShutsuryokuFileMei("テスト用ファイル");       // 出力ファイル名
        svfData.setDataFilePath("C:\\ssnavi\\TEST001.csv");    // ファイルパス
        svfData.setPrevFlag(false);                             // プレビュー表示 
        
        // コンテキストタイプ
        if (svfData.getPTN_EXCEL().equals(svfData.getFileFormat())) {
            svfData.setCotextType(svfData.getCONTEXT_TYPE_EXCEL());
        } else if (svfData.getPTN_PDF().equals(svfData.getFileFormat())) {
            svfData.setCotextType(svfData.getCONTEXT_TYPE_PDF());
        } else if (svfData.getPTN_PREV().equals(svfData.getFileFormat())) {
            svfData.setCotextType(svfData.getCONTEXT_TYPE_PREV());
        } else {
            svfData.setCotextType("");
        }
        
        // プレビュー表示
        if (svfData.getPTN_PREV().equals(svfData.getFileFormat())) {
            svfData.setPrevDocName("プレビューテスト用");
        } else {
            svfData.setPrevDocName("");
        }

    }   
}
