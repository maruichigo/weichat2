package jp.co.sharedsys.wbb.jsf.api;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class YesterDayyyyyMMdd implements IAPI {

    public String getAPI() {
        return "@YesterDayyyyyMMdd@";
    }

    public String execute() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        return new SimpleDateFormat("yyyyMMdd").format(cal.getTime());
    }
}
