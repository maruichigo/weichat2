package jp.co.sharedsys.wbb.jsf.reports;

public class ReportCondition extends AbstractReportCondition {
}
