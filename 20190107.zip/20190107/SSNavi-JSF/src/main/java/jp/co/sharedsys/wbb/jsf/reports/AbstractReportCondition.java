package jp.co.sharedsys.wbb.jsf.reports;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jp.co.sharedsys.wbb.jsf.api.TextEditor;
import lombok.Getter;
import lombok.Setter;

public abstract class AbstractReportCondition implements Serializable {
    
    private static final long serialVersionUID = -1952990451251072316L;
    protected String name = null;
    protected String displayName = null;
    protected String controlType = null;
    protected String dataType = null;
    protected String defaultValue = null;
    protected boolean required = false;
    protected String combination = null;
    protected String toolTip = null;
    protected int minLength = -1;
    protected int maxLength = -1;
    protected List<AbstractReportOption> options = new ArrayList<>();
    protected List<AbstractReportOption> originalOptions = new ArrayList<>();
    protected boolean skipIfBlank = false;
    protected String applyTo = null;
    protected boolean cache = true;
    protected String imeMode = null;
    protected String headerWidth = null;
    protected String size = null;
    protected String width = null;
    protected String height = null;

    @Getter @Setter
    protected String targetDynamic = null;

    // 2017.08 from ReportColumn
    @Getter @Setter
    protected String prefix = null;
    @Getter @Setter
    protected String suffix = null;
    @Getter @Setter
    protected int sortIndex = -1;
    @Getter @Setter
    protected int tabIndex = -1;
    @Getter @Setter
    protected boolean readonly = false;
    @Getter @Setter
    protected boolean lineEnd = false;
    @Getter @Setter
    protected boolean pk = false;

    @Getter @Setter
    protected String transferRptFile = null;
    @Getter @Setter
    protected String transferRptDir = null;
    @Getter @Setter
    protected String transferTabTitle = null;
    @Getter @Setter
    protected String tableName = null;
    @Getter @Setter
    protected String prevColPosition;
    @Getter @Setter
    protected boolean confirmRequired = false;
    @Getter @Setter
    protected boolean tableEnd = false;
    @Getter @Setter
    protected boolean tableBreak = false;
    @Getter @Setter
    protected String colspan;
    @Getter @Setter
    protected String rowspan;
    @Getter @Setter
    protected boolean enterKeyEventServiceRun = false;
    @Getter @Setter
    protected String service;
    @Getter @Setter
    protected String functionCode;
    @Getter @Setter
    protected boolean removeTableHeader = false;
    @Getter @Setter
    protected String extra1;
    @Getter @Setter
    protected String extra2;
    @Getter @Setter
    protected String extra3;
    @Getter @Setter
    protected String extra4;
    @Getter @Setter
    protected String extra5;
    
    @Getter @Setter
    protected AbstractReportOption selectOption;

    @Getter @Setter
    protected String section;
    
    @Getter @Setter
    protected boolean visible;
    @Getter @Setter
    protected boolean enable;
    @Getter @Setter
    protected String subColumn;
    @Getter @Setter
    protected String schSortIndex;
    @Getter @Setter
    protected String textValue = null;
    @Getter @Setter
    protected String labelValue = null;

    private String[] itemValue;
    
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getDisplayName() {
        return displayName;
    }
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }
    public String getControlType() {
        return controlType;
    }
    public void setControlType(String controlType) {
        this.controlType = controlType;
    }

    public boolean isRequired() {
        return required;
    }
    public void setRequired(boolean requires) {
        this.required = requires;
    }
    public String getCombination() {
        return combination;
    }
    public void setCombination(String combination) {
        this.combination = combination;
    }
    public String getToolTip() {
        return toolTip;
    }
    public void setToolTip(String toolTip) {
        this.toolTip = toolTip;
    }
    public int getMinLength() {
        return minLength;
    }
    public void setMinLength(int minLength) {
        this.minLength = minLength;
    }
    public int getMaxLength() {
        return maxLength;
    }
    public void setMaxLength(int maxLength) {
        this.maxLength = maxLength;
    }
    public String getDataType() {
        return dataType;
    }
    public void setDataType(String dataType) {
        this.dataType = dataType;
    }
    public String getDefaultValue() {
        return TextEditor.replace(defaultValue);
    }
    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }
    public List<AbstractReportOption> getOptions() {
        return options;
    }
    public void setOptions(List<AbstractReportOption> options) {
        this.options = options;
    }
        
    public boolean isSkipIfBlank() {
        return skipIfBlank;
    }
    public void setSkipIfBlank(boolean skipIfBlank) {
        this.skipIfBlank = skipIfBlank;
    }
    public String getApplyTo() {
        return applyTo;
    }
    public void setApplyTo(String applyTo) {
        this.applyTo = applyTo;
    }
    public boolean isCache() {
        return cache;
    }
    public void setCache(boolean cache) {
        this.cache = cache;
    }
    public List<AbstractReportOption> getOriginalOptions() {
        return originalOptions;
    }
    public String getImeMode() {
        return imeMode;
    }
    public void setImeMode(String imeMode) {
        this.imeMode = imeMode;
    }
    public String getHeaderWidth() {
        return headerWidth;
    }
    public void setHeaderWidth(String headerWidth) {
        this.headerWidth = headerWidth;
    }
    public String getSize() {
        return size;
    }
    public void setSize(String size) {
        this.size = size;
    }
    public String getWidth() {
        return width;
    }
    public String getWidthForce() {
        if (width == null || width.length() == 0) {
            return "auto";
        }
        return width;
    }
    public void setWidth(String width) {
        this.width = width;
    }
    public String getHeight() {
        return height;
    }
    public void setHeight(String height) {
        this.height = height;
    }

    public String getNameStart(){
        return getName() + "_START";
    }
    public String getNameEnd(){
        return getName() + "_END";
    }
    
    public boolean isCombinationType(){
        if (this.getCombination() == null) {
            return false;
        }
        if ("".equals(this.getCombination())){
            return false;
        }
        return true;
    }
    
    public String imeModeType() {
        if (imeMode == null || imeMode.isEmpty()) {
            if ("TEXT".equals(dataType)) {
                return "ime-mode: auto;";
            } else if ("NUMBER".equals(dataType) || "INT".equals(dataType) || "DECIMAL".equals(dataType) || "DATE_TIMESTAMP".equals(dataType) || "DATE".equals(dataType)) {
                return "ime-mode: inactive;";
            } else {
                return "";
            }
        } else {
            return "ime-mode: " + imeMode;
        }
    }
    
    public void widthAndHeight() {
        if (size == null || size.isEmpty()) {
            return;
        }
        String[] sizeArrays = size.split(",");
        String colWidth = sizeArrays[0];
        String colHeight = "";
        if (sizeArrays.length > 1) {
            colHeight = sizeArrays[1];
        }
    }
    
    public String getColWidth() {
        if (size == null || size.isEmpty()) {
            return "";
        }
        String[] sizeArrays = size.split(",");
        return sizeArrays[0];
    }
    public String getColHeight() {
        if (size == null || size.isEmpty()) {
            return "";
        }
        String[] sizeArrays = size.split(",");
        if (sizeArrays.length > 1) {
            return sizeArrays[1];
        }
        return "";
    }
    public String getAlign() {
        if ("NUMBER".equals(dataType) || "INT".equals(dataType) || "DECIMAL".equals(dataType)) {
            return "text-align: right;";
        }
        return "text-align: left;";
    }
    
    public List<AbstractReportOption> autoCompMethod(String query) {
        List<AbstractReportOption> filtered = new ArrayList<>();
        for (AbstractReportOption option : options) {
            if (option.getLabel().contains(query)) {
                filtered.add(option);
            }
        }
        return filtered;
    }
    
    public List<AbstractReportOption> doubleComboOut(String query) {
        List<AbstractReportOption> filtered = new ArrayList<>();
        for (AbstractReportOption option : options) {
            if (option.getLabel().startsWith(query)) {
                filtered.add(option);
            }
        }
        return filtered;
    }

    public List<AbstractReportOption> doubleComboIn(String query) {
        List<AbstractReportOption> filtered = new ArrayList<>();
        for (AbstractReportOption option : options) {
            if (option.getLabel().startsWith(query)) {
                filtered.add(option);
            }
        }
        return filtered;
    }  

    /**
     * @return the itemValue
     */
    public String[] getItemValue() {
        return itemValue;
    }

    /**
     * @param itemValue the itemValue to set
     */
    public void setItemValue(String[] itemValue) {
        this.itemValue = itemValue;
    }
   
}
