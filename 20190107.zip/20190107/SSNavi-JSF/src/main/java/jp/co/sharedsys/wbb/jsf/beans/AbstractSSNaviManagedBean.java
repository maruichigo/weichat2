/*
 * AbstractSSNaviManagedBean.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import jp.co.sharedsys.wbb.jsf.exception.LogicException;
import jp.co.sharedsys.wbb.jsf.exception.SystemException;
import jp.co.sharedsys.wbb.jsf.process.OptionsFinder;
import jp.co.sharedsys.wbb.jsf.reports.AbstractReportOption;
import jp.co.sharedsys.wbb.jsf.reports.ReportColumn;
import jp.co.sharedsys.wbb.jsf.reports.ReportColumnOption;
import jp.co.sharedsys.wbb.jsf.reports.ReportCondition;
import jp.co.sharedsys.wbb.jsf.reports.ReportConditionOption;
import jp.co.sharedsys.wbb.jsf.reports.ReportConfig;
import jp.co.sharedsys.wbb.jsf.util.StringUtil;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author saihara
 */
public abstract class AbstractSSNaviManagedBean implements Serializable {
    
    protected Logger logger = LoggerFactory.getLogger(this.getClass());
    private final String[] TARGET_LAYOUT_LABEL_EDIT = {"CHECKBOX", "RADIO"};
    
    public String replaceLiteral(String str) {
        String val = "";
        if (StringUtils.isNotEmpty(str)) {
            val = str.replaceAll("(\\r\\n|\\r|\\n)", "\\\\n");
            val = val.replace("'", "\\'");
            val = val.replace("\"", "\\\"");
        }
        return val;
    }
	
    public String escapeHtml(String str) {
        String val = "";
        if (StringUtils.isNotEmpty(str)) {
            val = str.replaceAll("&", "&amp;");
            val = val.replaceAll("<", "&lt;");
            val = val.replaceAll(">", "&gt;");
            val = val.replaceAll("'", "&apos;");
            val = val.replaceAll("\"", "&quot;");
        }	    
        return val;
    }
    
    /**
     * 選択項目(checkbox,radio,autocomplete等)で、外部参照指定がされている部分の取得
     * @param config config
     * @param authConf authConf
     * @throws LogicException logic
     * @throws SystemException  system
     */
    protected void generateOption(ReportConfig config, AuthorityConfBean authConf) throws LogicException, SystemException{

        for (Iterator ite = config.getConditions().iterator();ite.hasNext();){
            ReportCondition condition = (ReportCondition) ite.next();
            logger.debug(condition.getName() + ":" + condition.isCache() + "/" +config.isReady());
            if (config.isReady() && condition.isCache()){
                    continue;
            }
            logger.debug(condition.getName() + ":Loading start");
            List newOption = new ArrayList();
            for (Iterator oite = condition.getOriginalOptions().iterator(); oite.hasNext(); ){
                ReportConditionOption option = (ReportConditionOption) oite.next();
                if (option.getService() == null || "".equals(option.getService())){
                    newOption.add(option);
                    continue;
                }
                
                // 外部サービスから取得する。
                OptionsFinder process = new OptionsFinder();
                process.setAuthConf(authConf);
                // 検索条件のLIST共通化
                if ( !"SS_COM_MAINT_SEARCH".equals(option.getFunctionCode())
                        && !"SS_SORT_ORDER_LIST".equals(option.getFunctionCode())) {
                    option.setFunctionCode( option.getFunctionCode() + "_COMLIST" );
                }
                process.onService(option);
                List<Map<String, Object>> searchResult = process.getSearchResult();
                if (searchResult == null || searchResult.isEmpty()) {
                    logger.info(condition.getName() + " function-code:" + option.getFunctionCode() + " is NoResult..");
                    continue;
                }
                
                // CHECKED存在チェック
                for (int i = 0; i < searchResult.size(); i++) {
                    Map<String, Object> one = searchResult.get(i);

                    ReportConditionOption o = new ReportConditionOption();
                    for (Iterator<String> oneIte = one.keySet().iterator(); oneIte.hasNext();) {
                        String key = oneIte.next();
                        String val = String.valueOf(one.get(key));
                        if ("CHECKED".equals(key)) {
                            o.setChecked(true);
                        } else if ("LABEL".equals(key)) {
                            o.setLabel(val);
                        } else if ("VALUE".equals(key)) {
                            o.setValue(val);
                        } else {
                            o.getRelationValues().put(key, val);
                        }
                    }
                    newOption.add(o);
                }
            }
            condition.getOptions().clear();
            labelEditing(condition.getControlType(), newOption);
            condition.getOptions().addAll(newOption);
        }
    }
    
    /**
     * 選択項目(checkbox,radio,autocomplete等)で、外部参照指定がされている部分の取得
     * (明細画面 ReportColumn 用)
     * @param config config 
     * @param authConf authConfig
     * @throws LogicException logic
     * @throws SystemException  system
     */
    protected void generateOptionByModification(ReportConfig config, AuthorityConfBean authConf) throws LogicException, SystemException{

        for (Iterator<ReportColumn> ite = config.getModification().getColumns().iterator();ite.hasNext();) {
            ReportColumn column = ite.next();
            logger.debug(column.getName() + ":" + column.isCache() + "/" +config.isReady());
            if (config.isReady() && column.isCache()){
                    continue;
            }
            logger.debug(column.getName() + ":Loading start");
            List newOption = new ArrayList();
            for (Iterator oite = column.getOriginalOptions().iterator(); oite.hasNext(); ){
                AbstractReportOption option = (ReportColumnOption) oite.next();
                if (option.getService() == null || "".equals(option.getService())){
                    newOption.add(option);
                    continue;
                }
                
		// Service未定義の場合は検索をスルー 2018/10/3 Kobayashi
		if(option.getFunctionCode() == null || option.getFunctionCode().equals("")){
                    newOption.add(option);
		    continue;
		}
		
                // 検索条件のLIST共通化
                if ( !"SS_COM_MAINT_SEARCH".equals(option.getFunctionCode())
                        && !"SS_SORT_ORDER_LIST".equals(option.getFunctionCode())) {
                    option.setFunctionCode( option.getFunctionCode() + "_COMLIST" );
                }
                
                // 外部サービスから取得する。
                OptionsFinder process = new OptionsFinder();
                process.setAuthConf(authConf);
                process.onService(option);
                List<Map<String, Object>> searchResult = process.getSearchResult();
                if (searchResult == null || searchResult.isEmpty()) {
                    logger.info(column.getName() + " function-code:" + option.getFunctionCode() + " is NoResult..");
                    continue;
                }
                
                // CHECKED存在チェック
                for (int i = 0; i < searchResult.size(); i++) {
                    Map<String, Object> one = searchResult.get(i);

                    AbstractReportOption o = new ReportColumnOption();
                    for (Iterator<String> oneIte = one.keySet().iterator(); oneIte.hasNext();) {
                        String key = oneIte.next();
                        String val = String.valueOf(one.get(key));
                        if ("CHECKED".equals(key)) {
                            o.setChecked(true);
                        } else if ("LABEL".equals(key)) {
                            o.setLabel(val);
                        } else if ("VALUE".equals(key)) {
                            o.setValue(val);
                        } else {
                            o.getRelationValues().put(key, val);
                        }
                    }
                    newOption.add(o);
                }
            }
            column.getOptions().clear();
            labelEditing(column.getControlType(), newOption);
            column.getOptions().addAll(newOption);
        }
    }

    /**
     * checkbox,radio等の画面レイアウト上、1番目のラベル長さに合わせて
     * div幅が決まるため、最大長に合わせてスペースを付与する。
     * (とりあえずcheckbox,radioのみ)
     * @param controlType controlType
     * @param options reportoption
     */
    private void labelEditing(String controlType, List<AbstractReportOption> options) {
        final String ENCODE_SHIFTJIS = "Shift_JIS";
        if (!Arrays.asList(TARGET_LAYOUT_LABEL_EDIT).contains(controlType) || options == null || options.isEmpty()) {
            return;
        }
        int maxLabelLength = 0;
        BitSet maxSet = null;
        String maxLabel = null;
        for (AbstractReportOption option : options) {
            if (option.getLabel().length() > maxLabelLength) {
                maxLabelLength = option.getLabel().length();
                maxSet = StringUtil.charsCheck(option.getLabel());
                maxLabel = option.getLabel();
            }
        }

        int emCnt = 0;
        int enCnt = 0;
        if (maxSet != null) {
            for (int i = 0; i < maxSet.length(); i++) {
                if (maxSet.get(i)) emCnt++;  else enCnt++;
            }
        }
        // 最大長ラベルが半角を含んでいたら最大長カウントを-1する
        if (!StringUtil.isEm(maxLabel) && StringUtil.includeEm(maxLabel)) {
            maxLabelLength--;
        }

        for (AbstractReportOption option : options) {
            StringBuffer buf = new StringBuffer(option.getLabel());
            for (int i = option.getLabel().length(); i < maxLabelLength; i++) {
                buf.append("　");
            }
            option.setLabel(buf.toString());
        }
    } 
}
