/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.wbb.jsf.beans.mst;

import java.io.Serializable;
import javax.faces.event.FacesEvent;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import jp.co.kintetsuls.common.MessageDataModel;
import jp.co.sharedsys.wbb.jsf.beans.SSNaviManagedBean;

/**
 * 仕向地名マスタ画面
 *
 * @author MaLei (MBP)
 * @version 2019/1/6 新規作成
 */

@Named("Mst501")
@ViewScoped
public class Mst501 implements Serializable  {

    private static final long serialVersionUID = 1L;
    
    /**
     * 初期処理
     * @param bean
     * @param event
     * @param messageData
     * @param backFlag
     */
    public void init(SSNaviManagedBean bean, FacesEvent event, MessageDataModel messageData, Boolean backFlag) {
        // 戻ってきた場合
        
        // 進んできた場合
        
    }
    
    /**
     * 後処理
     * @param bean
     * @param event
     * @param messageData
     * @param backFlag
     */
    public void close(SSNaviManagedBean bean, FacesEvent event, MessageDataModel messageData, Boolean backFlag) {
        String str;
        str = "test";        
    }
}
