/*
 * PagePropertiesBean.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.wbb.jsf.util.bean;

import java.util.List;
import java.util.Map;
import javax.faces.component.UIComponent;
import jp.co.sharedsys.wbb.jsf.beans.ReportListDataModel;
import jp.co.sharedsys.wbb.jsf.reports.ReportConfig;
import jp.co.sharedsys.wbb.jsf.reports.ReportPdfGroup;
import lombok.Data;

/**
 * ページネスト時、前画面のプロパティ情報を格納しておくBeanです。
 * BreadCrumbのMenuItem.valueに格納され、遷移指定時に、pageBeanの
 * 各フィールドに展開します。
 * @author saihara
 */
@Data
public class PagePropertiesBean {
    private ReportConfig config;
    
    private String r;
    private String isSearch;
    private String isTrans;

    // 現在のテンプレートXHTML
    private String curXhtml;
    // 現在の画面モード
    private String editMode;
    // 一覧検索結果の格納先
    private Map<String, List<Map<String, Object>>> reportResult;
    // 一覧検索結果をチェックボックスで選択可能とするためのクラス
    private ReportListDataModel selectableResult;
    // 一覧検索結果をチェックボックスで選択可能とするためのクラス(複数定義用)
    private Map<String, ReportListDataModel> selectableResults;
    // 画面で選択された行の格納先
    private List<Map<String, Object>> selectReportResult;
    // 画面で選択された行の格納先(編集画面)
    private Map<String, List<Map<String, Object>>> selectEditReportResult;
    
    // 印刷実施ボタンの、selectOneMenuで選択された項目格納先
    private Map<String, ReportPdfGroup> selectedPdf;
    
    // 外部サービスのレスポンス情報格納先
    private Map<String, Object> externalAttribute;
    
    private Map<String, UIComponent> idBind;
    
    // 画面からの入力値を受け付けるプロパティ
    private Map<String, Map<String, Object>> values;
    private Map<String, String> selectedLine;
    // Datatable内データ入力値受付の為のプロパティ
    private Map<String, List<Map<String, Object>>> listValues;
        
}
