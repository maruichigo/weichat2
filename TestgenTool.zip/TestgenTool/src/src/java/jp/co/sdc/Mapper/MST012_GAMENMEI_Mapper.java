package jp.co.sdc.Mapper;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.faces.view.ViewScoped;
import jp.co.sdc.entity.MessageEntity;

/**
 *  MST012:画面名取得用Mapperインターフェース。<br>
 * 
 * @author XXX
 * @version 2018/12/12
 */
@ViewScoped
public class MST012_GAMENMEI_Mapper implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    /**
     * 画面名取得。<br>
     * 
     * @param condition InputDaoDTO
     * @return OutputDaoDTO 結果無しの場合はnull
     */
    public List<String> find(String condition1, String condition2) {
       List<String> nameList = new ArrayList<String>();
       return nameList;
    }
}
