package jp.co.sdc.dao;

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;

import javax.faces.view.ViewScoped;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

/**
 * 访问数据库类
 */
@ViewScoped
public class DBAccess implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	Reader reader;
	SqlSessionFactory sqlSessionFactory;
	SqlSession sqlSession;
	
	 public DBAccess() throws IOException {
		// 通过配置文件获取数据库连接信息
		reader = Resources.getResourceAsReader("config/Configuration.xml");
		// 通过配置信息构建一个SqlSessionFactory
		sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
		// 通过sqlSessionFactory打开一个数据库会话
		sqlSession = sqlSessionFactory.openSession();
	}
	
	public Object selectList (Object param) {
		String paraName = param.getClass().getName();
		int lastIndex = paraName.lastIndexOf(".");
		return sqlSession.selectList("Message." + paraName.substring(lastIndex + 1 ) +  "List", param);
	}
	
}
