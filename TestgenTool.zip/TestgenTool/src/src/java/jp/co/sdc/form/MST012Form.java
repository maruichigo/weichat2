package jp.co.sdc.form;

import java.io.Serializable;
import javax.faces.view.ViewScoped;

/**
 *
 * ユーザマスタ詳細BackingForm
 
 *  @author MBP XXX
 *  @version 2018/12/12 新規作成
 */

@ViewScoped
public class MST012Form implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String userCd;

 	private String userName;       
        
        private String kanaMei;
        
	private boolean userCdRen;
	
	private String gamennMei;
	
	private boolean gamennMeiRen;

        private String mode;
	
    /**
     * ユーザコードget
     */
	public String getUserCd() {
	   return userCd;
	}
	
    /**
     * ユーザコードset
     */
	public void setUserCd(String v) {
	   userCd = v;
	}
	
	
    /**
     * ユーザコード の表示制御get
     */
	public boolean getUserCdRen() {
	   return userCdRen;
	}
    /**
     * ユーザコード の表示制御
     */
	public boolean isUserCdRen() {
		return userCdRen;
	} 
	
    /**
     * ユーザコード の表示制御
     */
	public void setUserCdRen(boolean v) {
	   userCdRen = v;
	}
	
	
    /**
     * 画面名称
     */
	public String getGamennMei() {
	   return gamennMei;
	}
	
    /**
     * 画面名称
     */
	public void setGamennMei(String v) {
	   gamennMei = v;
	}
	
	
    /**
     * 画面名称 の表示制御
     */
	public boolean getGamennMeiRen() {
	   return gamennMeiRen;
	}
    /**
     * 画面名称 の表示制御
     */
	public boolean isGamennMeiRen() {
		return gamennMeiRen;
	} 
	
    /**
     * 画面名称 の表示制御
     */
	public void setGamennMeiRen(boolean v) {
	   gamennMeiRen = v;
	}

    /**
     * モードget
     */
	public String getMode() {
	   return mode;
	}
	
    /**
     * モードset
     */
	public void setMode(String v) {
	   mode = v;
	}      
        
    public String getUserName() {
        return userName;
    }

    public String getKanaMei() {
        return kanaMei;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setKanaMei(String kanaMei) {
        this.kanaMei = kanaMei;
    }
        
}
