package  jp.co.sdc.constant;

import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * モード 用列挙型。<br>
 *
 * @author XXX
 * @version 2018/12/12
 */
public enum GAMEN_MODE {
    /** 参照モード */
    SANSYO_MODE("1"),
    /** 新規登録モード */
    SINKI_MODE("2");

    private final String cd;

    /**
     * コンストラクタ
     * @param cd コンスタントコード
     */
    private GAMEN_MODE(final String cd) {
        this.cd = cd;
    }

    /**
     * コード値取得
     * @return コード値
     */
    public String getValue() {
        return this.cd;
    }

    /**
     * コンスタントコード、型マップ
     */
    private static final Map<String, GAMEN_MODE> MAP;

    /**
     * コンスタントコード、型マップを生成
     */
    static {
        Map<String, GAMEN_MODE> map = new ConcurrentHashMap<>();
        for (GAMEN_MODE instance : GAMEN_MODE.values()) {
            map.put(instance.getValue(), instance);
        }
        MAP = Collections.unmodifiableMap(map);
    }

    /**
     * コンスタントコードから列挙型を取得
     * 
     * @param cd
     *            コンスタントコード
     * @return 列挙型
     * @throws RuntimeException
     *             コード値不正の場合
     */
    public static GAMEN_MODE fromString(String cd) {
        GAMEN_MODE ret = MAP.get(cd);
        if (ret == null) {
            throw new RuntimeException("該当するEnumコード値が見つかりません " + cd);
        }
        return ret;
    }
}
