package jp.co.sdc.common.interf;

import javax.faces.view.ViewScoped;
import jp.co.sdc.bean.param.LoginInf;

/**
 * MST012:ログイン情報（共通）Interface
 *
 * @author  XXX
 * @version 2018/12/12 新規作成
 */
public interface GetLoginInf {
    
    /**
    * ログイン情報（共通） 取得処理<br>
    * 
    * 入力パラメータ なし<br>
    * 
    */
    LoginInf getLoginInf ();
    
}
