package jp.co.sdc.bean.param;

import java.io.Serializable;
import javax.faces.view.ViewScoped;

/**
 *
 * ログイン情報（共通）Bean
 
 *  @author MBP XXX
 *  @version 2018/12/12 新規作成
 */

@ViewScoped
public class LoginInf implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String userCd;
	
	private String syozokuEigyosyoCd;
	
	private String syozokuEigyosyoMei;
	
	
    /**
     * ユーザーコードget
     */
	public String getUserCd() {
	   return userCd;
	}
	
    /**
     * ユーザーコードset
     */
	public void setUserCd(String v) {
	   userCd = v;
	}

	
	
    /**
     * 所属営業所コードget
     */
	public String getSyozokuEigyosyoCd() {
	   return syozokuEigyosyoCd;
	}
	
    /**
     * 所属営業所コードset
     */
	public void setSyozokuEigyosyoCd(String v) {
	   syozokuEigyosyoCd = v;
	}
	
    /**
     * 所属営業所名get
     */
	public String getSyozokuEigyosyoMei() {
	   return syozokuEigyosyoMei;
	}
	
    /**
     * 所属営業所名set
     */
	public void setSyozokuEigyosyoMei(String v) {
	   syozokuEigyosyoMei = v;
	}
        
}
