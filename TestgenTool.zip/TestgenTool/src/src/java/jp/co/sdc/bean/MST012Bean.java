package jp.co.sdc.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpSession;
import jp.co.sdc.Mapper.MST012_GAMENMEI_Mapper;
import jp.co.sdc.bean.param.LoginInf;
import jp.co.sdc.bean.param.UserMasterShosai;
import jp.co.sdc.constant.GAMEN_MODE;
import jp.co.sdc.form.MST012Form;
import jp.co.sdc.common.interf.GetLoginInf;
import jp.co.sdc.dao.DBAccess;
import jp.co.sdc.entity.MessageEntity;
import org.apache.ibatis.session.SqlSession;

/**
 * MST012:ユーザマスタ詳細ServiceBean
 *
 * @author  MBP 作成者
 * @version 2018/12/12 新規作成
 */
@Named("MST012Bean")
@ViewScoped
public class MST012Bean implements Serializable {

	private static final long serialVersionUID = 1L;

	/** メッセージID：COME0003. */
	private static final String MSG_ID_COME0003 = "COME0003";

	/** メッセージID：MSTE0094. */
	private static final String MSG_ID_MSTE0094 = "MSTE0094";

	/** 定数：ブランク. */
	private static final String BLANK = "";

	/** 【定数.年月日】("yyyy/MM/dd HH:mm:ss"). */
	private static final String YYYYMMDDHHMMSS = "yyyy/MM/dd HH:mm:ss";

	/** 【定数.年月日】("YYYYMMDD"). */
	private static final String YYYYMMDD = "YYYYMMDD";        
        
	/** ユーザマスタ詳細画面Formクラス. */
	@Inject
	private MST012Form mST012Form;

	/** 画面パラメータ渡すションモジュール */
	@Inject
	private HttpSession hs;        
 
	/** ログイン情報（共通）モジュール */
	@Inject
	private GetLoginInf commonLoginInf;          
        
	/** 画面名取得Mapper */
	@Inject
        private MST012_GAMENMEI_Mapper mST012_GAMENMEI_Mapper;

 	/** DBアクセスモジュール */
	@Inject
	private DBAccess dbAccess;	       
        
        /** エラーメッセージリスト */
        List<String> messageList;
        
        public List<String> getMessageList() {
            return messageList;
        }
        
	/**
	 * MST012Formオブジェクトset
	 *
	 * @param form MST012Formオブジェクト
	 */
	public void setForm(MST012Form form) {
		this.mST012Form = form;
	}

	/**
	 * MST012Formオブジェクトget
	 *
	 * @return MST012Formオブジェクト(<code>null</code>を返らない)
	 */
	public MST012Form getForm() {
		MST012Form form = mST012Form;
		return form;
	}

	/**
	 * MST012_initialize 1.初期処理<br>
	 * 
	 * 入力パラメータ（検索条件、表示ページ番号）を初期化して、セッションに格納する。<br>
	 * 
	 * @throws throwしない
	 */
	public void initialize() {
		// パラメータ設定
                messageList = new ArrayList<>();
		// 遷移元画面から渡されたパラメータの取得
                UserMasterShosai userMasterShosai = (UserMasterShosai) hs.getAttribute("STC031");
                if (null == userMasterShosai) {
                    userMasterShosai = new UserMasterShosai();
                }
                
                // ユーザーマスタ詳細.モード = null
		if (null == userMasterShosai.getMode()) {
			// モードの設定を行う
			userMasterShosai.setMode(GAMEN_MODE.SINKI_MODE.getValue());
		}
		// ユーザ情報取得
		LoginInf loginInf = commonLoginInf.getLoginInf();

                // 画面名取得
                List<String> gamenMeiList = null;
                try {
		    gamenMeiList = mST012_GAMENMEI_Mapper.find("con1","con2");
                    if (null == gamenMeiList || 0 == gamenMeiList.size()) {
                        throw new Exception();
                    }
                } catch (Exception e) {
                    messageList.add(MSG_ID_COME0003);
                    //FacesContext.getCurrentInstance().addMessage(BLANK, new FacesMessage(FacesMessage.SEVERITY_ERROR, MSG_ID_COME0003, "DB取得エラー"));
                    return;
                }
                
                // 内容を画面へ表示する
                if (GAMEN_MODE.SINKI_MODE.getValue().equals(userMasterShosai.getMode())) {
                    // ユーザコード
                    mST012Form.setUserCd("000001");
                    mST012Form.setUserCdRen(true);
                    // 画面名
                    mST012Form.setGamennMei(gamenMeiList.get(0));
                    mST012Form.setGamennMeiRen(true);
                    // モード
                    mST012Form.setMode(userMasterShosai.getMode());
                } else {
                    // ユーザコード
                    mST012Form.setUserCd(loginInf.getUserCd());
                    mST012Form.setUserCdRen(false);
                    // 画面名
                    mST012Form.setGamennMei(gamenMeiList.get(0));
                    mST012Form.setGamennMeiRen(false);
                    // モード
                    mST012Form.setMode(userMasterShosai.getMode());
                }

	}

	/**
	 * MST012_search 2.検索処理<br>
	 * 
	 * 入力パラメータ（検索条件、表示ページ番号）を初期化して、セッションに格納する。<br>
	 * 
	 * @throws throwしない
	 */
	public void search() {
            		List<MessageEntity> messageList = new ArrayList<MessageEntity>();
		SqlSession sqlSession = null;
		try {
			MessageEntity message = new MessageEntity();
			message.setCommand("123");
			message.setDescription("456");
			// 通过sqlSession执行SQL语句
			messageList = (List<MessageEntity>) dbAccess.selectList(message);
			mST012Form.setGamennMei(messageList.get(0).getDescription());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if(sqlSession != null) {
				sqlSession.close();
			}
		}	
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, MSG_ID_COME0003, "メッセージサンプル"));
        }        
        
}