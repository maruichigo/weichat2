package jp.co.sdc.bean.param;

import java.io.Serializable;
import javax.faces.view.ViewScoped;

/**
 *
 * ユーザーマスタ詳細の入力パラメータBean
 
 *  @author MBP XXX
 *  @version 2018/12/12 新規作成
 */

@ViewScoped
public class UserMasterShosai implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String userCd;
	
	private String tekiyoKaishibi;
	
	private String mode;
	
	
    /**
     * ユーザーコードget
     */
	public String getUserCd() {
	   return userCd;
	}
	
    /**
     * ユーザーコードset
     */
	public void setUserCd(String v) {
	   userCd = v;
	}

	
	
    /**
     * 適用開始日get
     */
	public String getTekiyoKaishibi() {
	   return tekiyoKaishibi;
	}
	
    /**
     * 適用開始日set
     */
	public void setTekiyoKaishibi(String v) {
	   tekiyoKaishibi = v;
	}
	
    /**
     * モード
     */
	public String getMode() {
	   return mode;
	}
	
    /**
     * モード
     */
	public void setMode(String v) {
	   mode = v;
	}
        
}
