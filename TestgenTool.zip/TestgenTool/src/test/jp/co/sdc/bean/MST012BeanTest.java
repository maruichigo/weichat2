/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.sdc.bean;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpSession;
import jp.co.sdc.Mapper.MST012_GAMENMEI_Mapper;
import jp.co.sdc.bean.param.LoginInf;
import jp.co.sdc.bean.param.UserMasterShosai;
import jp.co.sdc.common.interf.GetLoginInf;
import jp.co.sdc.constant.GAMEN_MODE;
import jp.co.sdc.form.MST012Form;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.doThrow;
import org.mockito.MockitoAnnotations;

/**
 * MST012:ユーザマスタ詳細ServiceBeanTest
 *
 * @author  MBP 作成者
 * @version 2018/12/12 新規作成
 */
public class MST012BeanTest {
    
    // テストTarget
    @InjectMocks
    private MST012Bean target;
    
    // Mockitoオブジェクト
    @Mock 	
    private HttpSession hs;
    
    @Mock 
    private GetLoginInf commonLoginInf;	
    
    @Mock 
    private MST012_GAMENMEI_Mapper mST012_GAMENMEI_Mapper;   
    
    public MST012BeanTest() {
    }
    
    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化  
        MockitoAnnotations.initMocks(this);  
    }
    
    @After
    public void tearDown() {
    }

    // initialize_初期化_正常_1
    // param なし
    @Test
    public void initialize_初期化_正常_1 () {

        // パラメータキャプチャー
        ArgumentCaptor<String> stringCaptor_1 = ArgumentCaptor.forClass(String.class);    	
        // Mockitoオブジェクトの予想値設定
        UserMasterShosai userMasterShosai = new UserMasterShosai();
        userMasterShosai.setMode(GAMEN_MODE.SANSYO_MODE.getValue());
        when(hs.getAttribute(stringCaptor_1.capture())).thenReturn(userMasterShosai);
 
        // Mockitoオブジェクトの予想値設定
        LoginInf loginInf = new LoginInf();
        loginInf.setUserCd("0123");
        when(commonLoginInf.getLoginInf()).thenReturn(loginInf);
        
        // パラメータキャプチャー   	
        ArgumentCaptor<String> stringCaptor_2 = ArgumentCaptor.forClass(String.class);  
        ArgumentCaptor<String> stringCaptor_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想値設定
        List<String> gamenNameList = new ArrayList<String>();
        gamenNameList.add("画面名Test2");
        when(mST012_GAMENMEI_Mapper.find(stringCaptor_2.capture(), stringCaptor_3.capture())).thenReturn(gamenNameList);
        
        // テスト実行
        MST012Form mST012Form = new MST012Form();
        target.setForm(mST012Form);
        target.initialize();
        
        // 実施結果Outを取得
        mST012Form = target.getForm();
        
        // 実行時に渡すパラメータの検証  
        assertEquals("STC031", stringCaptor_1.getValue()); 
        assertEquals("con1", stringCaptor_2.getValue()); 
        assertEquals("con2", stringCaptor_3.getValue()); 
        
        // 実施結果Outの検証
        assertEquals("1", mST012Form.getMode());     
        assertEquals("0123", mST012Form.getUserCd()); 
        assertEquals(false, mST012Form.getUserCdRen()); 
        assertEquals("画面名Test", mST012Form.getGamennMei()); 
        assertEquals(false, mST012Form.getGamennMeiRen());
    }
    
    // initialize_初期化_正常_2
    // param なし
    @Test
    public void initialize_初期化_正常_2 () {

        // パラメータキャプチャー
        ArgumentCaptor<String> stringCaptor_1 = ArgumentCaptor.forClass(String.class);    	
        // Mockitoオブジェクトの予想値設定
        UserMasterShosai userMasterShosai = new UserMasterShosai();

        when(hs.getAttribute(stringCaptor_1.capture())).thenReturn(userMasterShosai);
 
        // Mockitoオブジェクトの予想値設定
        LoginInf loginInf = new LoginInf();
        loginInf.setUserCd("0124");
        when(commonLoginInf.getLoginInf()).thenReturn(loginInf);
        
        // パラメータキャプチャー   	
        ArgumentCaptor<String> stringCaptor_2 = ArgumentCaptor.forClass(String.class);  
        ArgumentCaptor<String> stringCaptor_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想値設定
        List<String> gamenNameList = new ArrayList<String>();
        gamenNameList.add("画面名Test2");
        when(mST012_GAMENMEI_Mapper.find(stringCaptor_2.capture(), stringCaptor_3.capture())).thenReturn(gamenNameList);
        
        // テスト実行
        MST012Form mST012Form = new MST012Form();
        target.setForm(mST012Form);
        target.initialize();
        
        // 実施結果Outを取得
        mST012Form = target.getForm();
        
        // 実行時に渡すパラメータの検証  
        assertEquals("STC031", stringCaptor_1.getValue()); 
        assertEquals("con1", stringCaptor_2.getValue()); 
        assertEquals("con2", stringCaptor_3.getValue()); 
        
        // 実施結果Outの検証
        assertEquals("2", mST012Form.getMode());     
        assertEquals("0124", mST012Form.getUserCd()); 
        assertEquals(true, mST012Form.getUserCdRen()); 
        assertEquals("画面名Test2", mST012Form.getGamennMei()); 
        assertEquals(true, mST012Form.getGamennMeiRen());
    }
    
    // initialize_初期化_異常_1
    // param なし
    @Test
    public void initialize_初期化_異常_1 () {

        // パラメータキャプチャー
        ArgumentCaptor<String> stringCaptor_1 = ArgumentCaptor.forClass(String.class);    	
        // Mockitoオブジェクトの予想値設定
        UserMasterShosai userMasterShosai = new UserMasterShosai();
        userMasterShosai.setMode(GAMEN_MODE.SANSYO_MODE.getValue());
        when(hs.getAttribute(stringCaptor_1.capture())).thenReturn(userMasterShosai);
 
        // Mockitoオブジェクトの予想値設定
        LoginInf loginInf = new LoginInf();
        loginInf.setUserCd("0123");
        when(commonLoginInf.getLoginInf()).thenReturn(loginInf);
        
        // パラメータキャプチャー   	
        ArgumentCaptor<String> stringCaptor_2 = ArgumentCaptor.forClass(String.class);  
        ArgumentCaptor<String> stringCaptor_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想値設定
        doThrow(SQLException.class).when(mST012_GAMENMEI_Mapper).find(stringCaptor_2.capture(), stringCaptor_3.capture());
        
        // テスト実行
        MST012Form mST012Form = new MST012Form();
        target.setForm(mST012Form);
        target.initialize();
        
        // 実施結果Outを取得
        mST012Form = target.getForm();
        
        // 実行時に渡すパラメータの検証  
        assertEquals("STC031", stringCaptor_1.getValue()); 
        assertEquals("con1", stringCaptor_2.getValue()); 
        assertEquals("con2", stringCaptor_3.getValue()); 
        
        // 実施結果Outの検証
        assertEquals(null, mST012Form.getMode());     
        assertEquals(null, mST012Form.getUserCd()); 
        assertEquals(false, mST012Form.getUserCdRen()); 
        assertEquals(null, mST012Form.getGamennMei()); 
        assertEquals(false, mST012Form.getGamennMeiRen());
        assertEquals("COME0003", target.getMessageList().get(0));
    }    

}
