package jp.co.kintetsuls.beans.mst;

import java.io.IOException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst291Form;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;


/**
 * 料金項目マスタ画面
 *
 * @author 呉俊 (MBP)
 * @version 2019/03/12 新規作成
 */
public class Mst291BeanTest {

    // テストTarget
    @InjectMocks
    private Mst291Bean target;

    // Mockitoオブジェクト
    @Mock
    private FileBean fileBean;
    @Mock
    private AutoCompleteViewBean autoCompleteViewBean;
    @Mock
    private MasterInfoBean masterInfo;
    @Mock
    private MessagePropertyBean messageProperty;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosai;
    @Mock
    private SearchHelpBean searchHelpBean;
    @Mock
    private AuthorityConfBean authConfBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private MessagePropertyBean messagePropertyBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosaiBean;
    @Mock
    private ListCheckBean listCheckBean;

    public Mst291BeanTest() {
    }

    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() {
    }

    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[not null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst291Form mst291Form = new Mst291Form();
        
        //前画面情報[not null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst291Form);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());

        // テスト実行
        Mst291Form form = new Mst291Form();
        target.setMst291Form(form);
        // 戻ってきた場合、再検索を実施する。
        target.init("","MST031_SCREEN",true);

        // 実施結果Outを取得
        form = target.getMst291Form();
        String title = target.getTITLE();
        String url = target.getUrl();
        BreadCrumbBean breadBean = target.getBreadBean();
        AutoCompleteViewBean autoCompleteViewBean = target.getAutoCompleteViewBean();
        AuthorityConfBean authorityConfBean  = target.getAuthorityConfBean();
        FileBean fileBean = target.getFileBean();
        MessagePropertyBean messagePropertyBean = target.getMessagePropertyBean();
        PageCommonBean pageCommonBean = target.getPageCommonBean();
        SearchHelpBean searchHelpBean = target.getSearchHelpBean();
        RirekiSyosaiBean rirekiSyosaiBean = target.getRirekiSyosaiBean();
        ListCheckBean listCheckBean = target.getListCheckBean();
        Map<String, Object> rirekiSearchKey = target.getRirekiSearchKey();
        List<MessageModuleBean> msgList = target.getMsgList();
        target.setUrl(url);
        target.setBreadBean(breadBean);
        target.setAutoCompleteViewBean(autoCompleteViewBean);
        target.setAuthorityConfBean(authorityConfBean);
        target.setFileBean(fileBean);
        target.setMessagePropertyBean(messagePropertyBean);
        target.setPageCommonBean(pageCommonBean);
        target.setSearchHelpBean(searchHelpBean);
        target.setRirekiSyosaiBean(rirekiSyosaiBean);
        target.setListCheckBean(listCheckBean);
        target.setRirekiSearchKey(rirekiSearchKey);
        target.setMsgList(msgList);
        
        // 実行時に渡すパラメータの検証
        assertEquals("mst291Form",keyCaptor_1.getValue());
        // 想定通りに再検索を実施する。
        assertEquals("search_mst291",keyCaptor_2.getValue());
    }

    // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[料金項目コード = 001,料金項目名称 = 航空運賃1,世代検索 = {01,02},料金項目グループ = 1,処理科目 = 02,補助科目 = 01,輸送売上セット先 = 2,プルーフ用集約項目 = 03,適用日 = null, 適用名 = hhh,削除済のみ検索 = null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2 () throws IllegalAccessException, InvocationTargetException {
        // Mockitoオブジェクトの予想return値設定
        Mst291Form mst291Form = new Mst291Form();
        //前回検索パラメータ[料金項目コード = 001,料金項目名称 = 航空運賃1,世代検索 = {01,02},料金項目グループ = 1,処理科目 = 02,補助科目 = 01,輸送売上セット先 = 2,プルーフ用集約項目 = 03,適用日 = null, 適用名 = hhh,削除済のみ検索 = null]
        mst291Form.setConRyokinKomokuCd("001");

        mst291Form.setConSedaiKensakuJoken(new String[]{"01","02"});
        
        mst291Form.setConRyokinKomokuMeisho("航空運賃1");
        
        AutoCompOptionBean conSyoriKamoku = new AutoCompOptionBean();
        conSyoriKamoku.setValue("02");
        mst291Form.setConSyoriKamoku(conSyoriKamoku);
        
        AutoCompOptionBean conHojoKamoku = new AutoCompOptionBean();
        conHojoKamoku.setValue("01");
        mst291Form.setConHojoKamoku(conHojoKamoku);
        
        AutoCompOptionBean conRyokinKomokuGroup = new AutoCompOptionBean();
        conRyokinKomokuGroup.setValue("1");
        mst291Form.setConRyokinKomokuGroup(conRyokinKomokuGroup);
        
        AutoCompOptionBean conYusoUriageSetSaki = new AutoCompOptionBean();
        conYusoUriageSetSaki.setValue("2");
        mst291Form.setConYusoUriageSetSaki(conYusoUriageSetSaki);
        
        AutoCompOptionBean conProofYouShuyakuKomoku = new AutoCompOptionBean();
        conProofYouShuyakuKomoku.setValue("03");
        mst291Form.setConProofYouShuyakuKomoku(conProofYouShuyakuKomoku);
        
        mst291Form.setConTekiyoBi(null);
        
        mst291Form.setConTekiyoMei("hhh");
        
        mst291Form.setConSakujoNomiKensaku(null);
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        //前画面パラメータ[料金項目コード = 008,削除済のみ検索 = null]
        flash.put("mst291Form", mst291Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash); 
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        // テスト実行
        Mst291Form form = new Mst291Form();
        target.setMst291Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        // 実施結果Outを取得
        form = target.getMst291Form();
        //想定通りに再検索を実施する。
        assertEquals("search_mst291",keyCaptor_2.getValue());
        assertEquals("001",form.getConRyokinKomokuCd());
        assertEquals("航空運賃1", form.getConRyokinKomokuMeisho());
        assertEquals("01", form.getConSedaiKensakuJoken()[0]);
        assertEquals("02", form.getConSedaiKensakuJoken()[1]);
        assertEquals("1", form.getConRyokinKomokuGroup().getValue());
        assertEquals("02", form.getConSyoriKamoku().getValue());
        assertEquals("01", form.getConHojoKamoku().getValue());
        assertEquals("2", form.getConYusoUriageSetSaki().getValue());
        assertEquals("03", form.getConProofYouShuyakuKomoku().getValue());
        assertEquals(null, form.getConTekiyoBi());
        assertEquals("hhh", form.getConTekiyoMei());
        assertEquals(null, form.getConSakujoNomiKensaku());
    }    

    // init_正常_初期処理_1-2_1
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[料金項目コード = 001,料金項目名称 = 航空運賃1,世代検索 = {01,02},料金項目グループ = 1,処理科目 = 02,補助科目 = 01,輸送売上セット先 = 2,プルーフ用集約項目 = 03,適用日 = null, 適用名 = hhh,削除済のみ検索 = null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2_1() throws IllegalAccessException, InvocationTargetException,
            InstantiationException {

        // Mockitoオブジェクトの予想return値設定
        Mst291Form mst291Form = new Mst291Form();
        //前回検索パラメータ[料金項目コード = 001,料金項目名称 = 航空運賃1,世代検索 = {01,02},料金項目グループ = 1,処理科目 = 02,補助科目 = 01,輸送売上セット先 = 2,プルーフ用集約項目 = 03,適用日 = null, 適用名 = hhh,削除済のみ検索 = null]
        mst291Form.setConRyokinKomokuCd("001");

        mst291Form.setConSedaiKensakuJoken(new String[]{"01","02"});
        
        mst291Form.setConRyokinKomokuMeisho("航空運賃1");
        
        AutoCompOptionBean conSyoriKamoku = new AutoCompOptionBean();
        conSyoriKamoku.setValue("02");
        mst291Form.setConSyoriKamoku(conSyoriKamoku);
        
        AutoCompOptionBean conHojoKamoku = new AutoCompOptionBean();
        conHojoKamoku.setValue("01");
        mst291Form.setConHojoKamoku(conHojoKamoku);
        
        AutoCompOptionBean conRyokinKomokuGroup = new AutoCompOptionBean();
        conRyokinKomokuGroup.setValue("1");
        mst291Form.setConRyokinKomokuGroup(conRyokinKomokuGroup);
        
        AutoCompOptionBean conYusoUriageSetSaki = new AutoCompOptionBean();
        conYusoUriageSetSaki.setValue("2");
        mst291Form.setConYusoUriageSetSaki(conYusoUriageSetSaki);
        
        AutoCompOptionBean conProofYouShuyakuKomoku = new AutoCompOptionBean();
        conProofYouShuyakuKomoku.setValue("03");
        mst291Form.setConProofYouShuyakuKomoku(conProofYouShuyakuKomoku);
        
        mst291Form.setConTekiyoBi(null);
        
        mst291Form.setConTekiyoMei("hhh");
        
        mst291Form.setConSakujoNomiKensaku(null);
        
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        //前画面パラメータ[料金項目コード = 001,料金項目名称 = 航空運賃1,世代検索 = {01,02},料金項目グループ = 1,処理科目 = 02,補助科目 = 01,輸送売上セット先 = 2,プルーフ用集約項目 = 03,適用日 = null, 適用名 = hhh,削除済のみ検索 = null]
        flash.put("mst291Form", null);
        when(pageCommonBean.getPageParam()).thenReturn(flash);        

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst291Form form = new Mst291Form();
        target.setMst291Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst291Form();

        //想定通りに再検索を実施する。
        assertEquals(null, form.getConSakujoNomiKensaku());
    }  
    
    // init_正常_初期処理_1-3
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        //前画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(null);

        //テスト実行
        Mst291Form form = new Mst291Form();
        
        target.setMst291Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst291Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst291Form",keyCaptor_1.getValue());
        //想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null,form.getSearchResult());
    }

    // init_正常_初期処理_1-3_1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        //前画面情報[null]
        doThrow(IllegalAccessException.class).when(pageCommonBean).getPageInfo(keyCaptor_1.capture());

        //テスト実行
        Mst291Form form = new Mst291Form();
        target.setMst291Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst291Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst291Form",keyCaptor_1.getValue());
        //想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null,form.getSearchResult());
    }
    
    // search_異常_検索処理_2-1
    //
    // -------------------テスト条件--------------------------
    // 入力項目チェック：世代検索条件=ない 適用日=ありません
    // 料金項目マスタ検索結果一覧取得 取得件数 = 0
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //料金項目マスタ検索結果一覧取得 取得件数 = 0
        List<Map<String, String>> result = new ArrayList<>();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst291Form form = new Mst291Form();
        form.setConSedaiKensakuJoken(new String[]{});
        target.setMst291Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst291Form();

        //実行時に渡すパラメータの検証
        assertEquals(null, paramsCaptor_1.getValue().get("conRyokinKomokuCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conRyokinKomokuMeisho"));
        String[] conSedaiKensakuJoken =  (String[]) paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals("0", conSedaiKensakuJoken[0]);
        assertEquals("0", conSedaiKensakuJoken[1]);
        assertEquals("0", conSedaiKensakuJoken[2]);
        assertEquals("0", conSedaiKensakuJoken[3]);
        assertEquals("0", conSedaiKensakuJoken[4]);
        assertEquals("", paramsCaptor_1.getValue().get("conSyoriKamoku"));
        assertEquals("", paramsCaptor_1.getValue().get("conHojoKamoku"));
        assertEquals("", paramsCaptor_1.getValue().get("conRyokinKomokuGroup"));
        assertEquals(0, paramsCaptor_1.getValue().get("conYusoUriageSetSaki"));
        assertEquals("", paramsCaptor_1.getValue().get("conProofYouShuyakuKomoku"));
        assertEquals("", paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoMei"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSakujoNomiKensaku"));
        assertEquals("mst291_search",functionCodeCaptor_2.getValue());
        //料金項目マスタに ・ファンクションボタンは表示（検索前と同じ） 
        assertForRecList_2_1(form);
    }
    
    // search_異常_検索処理_2-2
    //
    // -------------------テスト条件--------------------------
    // 入力項目チェック：世代検索条件で05(適用日指定)が選択されている場合、入力項目チェック：世代検索条件=あり 適用日=ない
    // 料金項目マスタ検索結果一覧取得 取得件数 = 0
    // -----------------------------------------------------
    //@Test
    public void search_異常_検索処理_2_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //料金項目マスタ検索結果一覧取得 取得件数 = 0
        List<Map<String, String>> result = new ArrayList<>();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst291Form form = new Mst291Form();
        form.setConSedaiKensakuJoken(new String[]{"05"});
        target.setMst291Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst291Form();

        //実行時に渡すパラメータの検証
        assertEquals(null, paramsCaptor_1.getValue().get("conRyokinKomokuCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conRyokinKomokuMeisho"));
        String[] conSedaiKensakuJoken =  (String[]) paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals("1", conSedaiKensakuJoken[4]);
        assertEquals("", paramsCaptor_1.getValue().get("conSyoriKamoku"));
        assertEquals("", paramsCaptor_1.getValue().get("conHojoKamoku"));
        assertEquals("", paramsCaptor_1.getValue().get("conRyokinKomokuGroup"));
        assertEquals(0, paramsCaptor_1.getValue().get("conYusoUriageSetSaki"));
        assertEquals("", paramsCaptor_1.getValue().get("conProofYouShuyakuKomoku"));
        assertEquals("", paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoMei"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSakujoNomiKensaku"));
        assertEquals("mst291_search",functionCodeCaptor_2.getValue());
        //料金項目マスタに ・ファンクションボタンは表示（検索前と同じ） 
        assertForRecList_2_2(form);
    }
    
    // search_正常_検索処理_2-3
    //
    // -------------------テスト条件--------------------------
    // 料金項目マスタ検索結果一覧取得
    // 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //料金項目マスタ検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=0;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst291Form form = new Mst291Form();
        form.setConRyokinKomokuCd("005");

        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        
        form.setConRyokinKomokuMeisho("航空運賃5");
        
        AutoCompOptionBean conSyoriKamoku = new AutoCompOptionBean();
        conSyoriKamoku.setValue("02");
        form.setConSyoriKamoku(conSyoriKamoku);
        
        AutoCompOptionBean conHojoKamoku = new AutoCompOptionBean();
        conHojoKamoku.setValue("03");
        form.setConHojoKamoku(conHojoKamoku);
        
        AutoCompOptionBean conRyokinKomokuGroup = new AutoCompOptionBean();
        conRyokinKomokuGroup.setValue("3");
        form.setConRyokinKomokuGroup(conRyokinKomokuGroup);
        
        AutoCompOptionBean conYusoUriageSetSaki = new AutoCompOptionBean();
        conYusoUriageSetSaki.setValue("2");
        form.setConYusoUriageSetSaki(conYusoUriageSetSaki);
        
        AutoCompOptionBean conProofYouShuyakuKomoku = new AutoCompOptionBean();
        conProofYouShuyakuKomoku.setValue("03");
        form.setConProofYouShuyakuKomoku(conProofYouShuyakuKomoku);
        
        form.setConTekiyoBi(null);
        
        form.setConTekiyoMei("bbb");
        
        form.setConSakujoNomiKensaku(new String[]{"1"});
        target.setMst291Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst291Form();

        // 実行時に渡すパラメータの検証
        assertEquals("005", paramsCaptor_1.getValue().get("conRyokinKomokuCd"));
        assertEquals("航空運賃5", paramsCaptor_1.getValue().get("conRyokinKomokuMeisho"));
        String[] conSedaiKensakuJoken =  (String[]) paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals("1", conSedaiKensakuJoken[0]);
        assertEquals("1", conSedaiKensakuJoken[1]);
        assertEquals("02", paramsCaptor_1.getValue().get("conSyoriKamoku"));
        assertEquals("03", paramsCaptor_1.getValue().get("conHojoKamoku"));
        assertEquals("3", paramsCaptor_1.getValue().get("conRyokinKomokuGroup"));
        assertEquals(2, paramsCaptor_1.getValue().get("conYusoUriageSetSaki"));
        assertEquals("03", paramsCaptor_1.getValue().get("conProofYouShuyakuKomoku"));
        assertEquals("", paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals("bbb", paramsCaptor_1.getValue().get("conTekiyoMei"));
        String[] conSakujoNomiKensaku = (String[]) paramsCaptor_1.getValue().get("conSakujoNomiKensaku");
        assertEquals("1", conSakujoNomiKensaku[0]);
        assertEquals("mst291_search", functionCodeCaptor_2.getValue());
        //想定通りに料金項目マスタ一覧を表示されること
        assertForRecList_2_3(form);
    }    

   // search_正常_検索処理_2-4
    //
    // -------------------テスト条件--------------------------
    // 料金項目マスタ検索結果一覧取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //料金項目マスタ検索結果一覧取得 取得件数 = 2
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=1;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst291Form form = new Mst291Form();
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        
        AutoCompOptionBean conRyokinKomokuGroup = new AutoCompOptionBean();
        conRyokinKomokuGroup.setValue("1");
        form.setConRyokinKomokuGroup(conRyokinKomokuGroup);
        target.setMst291Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst291Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null, paramsCaptor_1.getValue().get("conRyokinKomokuCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conRyokinKomokuMeisho"));
        String[] conSedaiKensakuJoken =  (String[]) paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals("1", conSedaiKensakuJoken[0]);
        assertEquals("1", conSedaiKensakuJoken[1]);
        assertEquals("", paramsCaptor_1.getValue().get("conSyoriKamoku"));
        assertEquals("", paramsCaptor_1.getValue().get("conHojoKamoku"));
        assertEquals("1", paramsCaptor_1.getValue().get("conRyokinKomokuGroup"));
        assertEquals(0, paramsCaptor_1.getValue().get("conYusoUriageSetSaki"));
        assertEquals("", paramsCaptor_1.getValue().get("conProofYouShuyakuKomoku"));
        assertEquals("", paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoMei"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSakujoNomiKensaku"));
        assertEquals("mst291_search",functionCodeCaptor_2.getValue());
        //想定通りに料金項目マスタ一覧を表示されること
        assertForRecList_2_4(form);
    }

    // search_異常_検索処理_2-5
    //
    // -------------------テスト条件--------------------------
    // 料金項目マスタ検索結果一覧取得 取得件数 = 0
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_5 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //料金項目マスタ検索結果一覧取得 取得件数 = 0
        List<Map<String, String>> result = new ArrayList<>();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst291Form form = new Mst291Form();
        form.setConRyokinKomokuCd("500");
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        target.setMst291Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst291Form();

        //実行時に渡すパラメータの検証
        assertEquals("500", paramsCaptor_1.getValue().get("conRyokinKomokuCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conRyokinKomokuMeisho"));
        String[] conSedaiKensakuJoken =  (String[]) paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals("1", conSedaiKensakuJoken[0]);
        assertEquals("1", conSedaiKensakuJoken[1]);
        assertEquals("", paramsCaptor_1.getValue().get("conSyoriKamoku"));
        assertEquals("", paramsCaptor_1.getValue().get("conHojoKamoku"));
        assertEquals("", paramsCaptor_1.getValue().get("conRyokinKomokuGroup"));
        assertEquals(0, paramsCaptor_1.getValue().get("conYusoUriageSetSaki"));
        assertEquals("", paramsCaptor_1.getValue().get("conProofYouShuyakuKomoku"));
        assertEquals("", paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoMei"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSakujoNomiKensaku"));
        assertEquals("mst291_search",functionCodeCaptor_2.getValue());
        //料金項目マスタに ・ファンクションボタンは表示（検索前と同じ） 
        assertForRecList_2_5(form);
    }
    
    // getRecordCount_正常_件数取得処理_2-6
    //
    // -------------------テスト条件--------------------------
    // 料金項目マスタ検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_6 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //料金項目マスタ検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst291Form form = new Mst291Form();
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        AutoCompOptionBean conRyokinKomokuGroup = new AutoCompOptionBean();
        conRyokinKomokuGroup.setValue("1");
        form.setConRyokinKomokuGroup(conRyokinKomokuGroup);
        target.setMst291Form(form);
        target.getRecordCount();

        //実施結果Outを取得
        form = target.getMst291Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null, paramsCaptor_1.getValue().get("conRyokinKomokuCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conRyokinKomokuMeisho"));
        String[] conSedaiKensakuJoken =  (String[]) paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals("1", conSedaiKensakuJoken[0]);
        assertEquals("1", conSedaiKensakuJoken[1]);
        assertEquals("", paramsCaptor_1.getValue().get("conSyoriKamoku"));
        assertEquals("", paramsCaptor_1.getValue().get("conHojoKamoku"));
        assertEquals("1", paramsCaptor_1.getValue().get("conRyokinKomokuGroup"));
        assertEquals(0, paramsCaptor_1.getValue().get("conYusoUriageSetSaki"));
        assertEquals("", paramsCaptor_1.getValue().get("conProofYouShuyakuKomoku"));
        assertEquals("", paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoMei"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSakujoNomiKensaku"));
        assertEquals("mst291_kensu",functionCodeCaptor_2.getValue());
    }
    
    // getRecordCount_正常_件数取得処理_2-6-1
    //
    // -------------------テスト条件--------------------------
    // 料金項目マスタ検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_6_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //料金項目マスタ検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst291Form form = new Mst291Form();
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        AutoCompOptionBean conRyokinKomokuGroup = new AutoCompOptionBean();
        conRyokinKomokuGroup.setValue("1");
        form.setConRyokinKomokuGroup(conRyokinKomokuGroup);
        target.setMst291Form(form);
        target.getRecordCount();

        //実施結果Outを取得
        form = target.getMst291Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null, paramsCaptor_1.getValue().get("conRyokinKomokuCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conRyokinKomokuMeisho"));
        String[] conSedaiKensakuJoken =  (String[]) paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals("1", conSedaiKensakuJoken[0]);
        assertEquals("1", conSedaiKensakuJoken[1]);
        assertEquals("", paramsCaptor_1.getValue().get("conSyoriKamoku"));
        assertEquals("", paramsCaptor_1.getValue().get("conHojoKamoku"));
        assertEquals("1", paramsCaptor_1.getValue().get("conRyokinKomokuGroup"));
        assertEquals(0, paramsCaptor_1.getValue().get("conYusoUriageSetSaki"));
        assertEquals("", paramsCaptor_1.getValue().get("conProofYouShuyakuKomoku"));
        assertEquals("", paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoMei"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSakujoNomiKensaku"));
        assertEquals("mst291_kensu",functionCodeCaptor_2.getValue());
    }
    
    // getRecordCount_正常_件数取得処理_2-6-2
    //
    // -------------------テスト条件--------------------------
    // 料金項目マスタ検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_6_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //料金項目マスタ検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        doThrow(IOException.class).when(pageCommonBean).getDBInfo(paramsCaptor_1.capture(), 
                functionCodeCaptor_2.capture());

        //テスト実行
        Mst291Form form = new Mst291Form();
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        AutoCompOptionBean conRyokinKomokuGroup = new AutoCompOptionBean();
        conRyokinKomokuGroup.setValue("1");
        form.setConRyokinKomokuGroup(conRyokinKomokuGroup);
        target.setMst291Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst291Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null, paramsCaptor_1.getValue().get("conRyokinKomokuCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conRyokinKomokuMeisho"));
        String[] conSedaiKensakuJoken =  (String[]) paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals("1", conSedaiKensakuJoken[0]);
        assertEquals("1", conSedaiKensakuJoken[1]);
        assertEquals("", paramsCaptor_1.getValue().get("conSyoriKamoku"));
        assertEquals("", paramsCaptor_1.getValue().get("conHojoKamoku"));
        assertEquals("1", paramsCaptor_1.getValue().get("conRyokinKomokuGroup"));
        assertEquals(0, paramsCaptor_1.getValue().get("conYusoUriageSetSaki"));
        assertEquals("", paramsCaptor_1.getValue().get("conProofYouShuyakuKomoku"));
        assertEquals("", paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoMei"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSakujoNomiKensaku"));
        assertEquals("mst291_search",functionCodeCaptor_2.getValue());
    }
    
    // clear_正常_クリア処理_3-1
    //
    // -------------------テスト条件--------------------------
    // 検索条件と検索結果がある
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst291Form form = new Mst291Form();
        // 検索条件と検索結果がある
        form.setConRyokinKomokuCd("005");

        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        
        form.setConRyokinKomokuMeisho("航空運賃5");
        
        AutoCompOptionBean conSyoriKamoku = new AutoCompOptionBean();
        conSyoriKamoku.setValue("02");
        form.setConSyoriKamoku(conSyoriKamoku);
        
        AutoCompOptionBean conHojoKamoku = new AutoCompOptionBean();
        conHojoKamoku.setValue("03");
        form.setConHojoKamoku(conHojoKamoku);
        
        AutoCompOptionBean conRyokinKomokuGroup = new AutoCompOptionBean();
        conRyokinKomokuGroup.setValue("3");
        form.setConRyokinKomokuGroup(conRyokinKomokuGroup);
        
        AutoCompOptionBean conYusoUriageSetSaki = new AutoCompOptionBean();
        conYusoUriageSetSaki.setValue("2");
        form.setConYusoUriageSetSaki(conYusoUriageSetSaki);
        
        AutoCompOptionBean conProofYouShuyakuKomoku = new AutoCompOptionBean();
        conProofYouShuyakuKomoku.setValue("03");
        form.setConProofYouShuyakuKomoku(conProofYouShuyakuKomoku);
        
        form.setConTekiyoBi(null);
        
        form.setConTekiyoMei("bbb");
        
        form.setConSakujoNomiKensaku(new String[]{"1"});

        target.setMst291Form(form);
        target.clear();

        //実施結果Outを取得
        form = target.getMst291Form();

        //想定通りに正常にClearを実施されること
        assertEquals(null,form.getConRyokinKomokuCd());
        assertEquals(null, form.getConRyokinKomokuMeisho());
        assertEquals("01", form.getConSedaiKensakuJoken()[0]);
        assertEquals("02", form.getConSedaiKensakuJoken()[1]);
        assertEquals(null, form.getConRyokinKomokuGroup());
        assertEquals(null, form.getConSyoriKamoku());
        assertEquals(null, form.getConHojoKamoku());
        assertEquals(null, form.getConYusoUriageSetSaki());
        assertEquals(null, form.getConProofYouShuyakuKomoku());
        assertEquals(null, form.getConTekiyoBi());
        assertEquals(null, form.getConTekiyoMei());
        assertEquals(null, form.getConSakujoNomiKensaku());
    }
    
    // clear_正常_クリア処理_3-2
    //
    // -------------------テスト条件--------------------------
    // 検索条件がある、検索結果がない
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst291Form form = new Mst291Form();
        form.setConRyokinKomokuCd("500");
        form.setConRyokinKomokuMeisho("航空運賃1");
        AutoCompOptionBean conRyokinKomokuGroup = new AutoCompOptionBean();
        conRyokinKomokuGroup.setValue("1");
        conRyokinKomokuGroup.setLabel("ノーマル運賃関連金額1");
        form.setConRyokinKomokuGroup(conRyokinKomokuGroup);
        AutoCompOptionBean conSyoriKamoku = new AutoCompOptionBean();
        conSyoriKamoku.setValue("01");
        conSyoriKamoku.setLabel("輸送原価 ");
        AutoCompOptionBean conHojoKamoku = new AutoCompOptionBean();
        conHojoKamoku.setValue("01");
        conHojoKamoku.setLabel("航空運賃");
        AutoCompOptionBean conYusoUriageSetSaki = new AutoCompOptionBean();
        conYusoUriageSetSaki.setValue("2");
        conYusoUriageSetSaki.setLabel("その他");
        AutoCompOptionBean conProofYouShuyakuKomoku = new AutoCompOptionBean();
        conProofYouShuyakuKomoku.setValue("03");
        conProofYouShuyakuKomoku.setLabel("航空料");
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        form.setConSakujoNomiKensaku(new String[]{"1"});
        
        target.setMst291Form(form);
        target.clear();

        //実施結果Outを取得
        form = target.getMst291Form();

        //想定通りに正常にClearを実施されること
        assertEquals(null,form.getConRyokinKomokuCd());
        assertEquals(null, form.getConRyokinKomokuMeisho());
        assertEquals("01", form.getConSedaiKensakuJoken()[0]);
        assertEquals("02", form.getConSedaiKensakuJoken()[1]);
        assertEquals(null, form.getConRyokinKomokuGroup());
        assertEquals(null, form.getConSyoriKamoku());
        assertEquals(null, form.getConHojoKamoku());
        assertEquals(null, form.getConYusoUriageSetSaki());
        assertEquals(null, form.getConProofYouShuyakuKomoku());
        assertEquals(null, form.getConTekiyoBi());
        assertEquals(null, form.getConTekiyoMei());
        assertEquals(null, form.getConSakujoNomiKensaku());
    }
    
    // getHeader_正常_ダウンロード_4-1
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void getHeader_正常_ダウンロード_4_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst291Form form = new Mst291Form();
        target.setMst291Form(form);
        List<CSVDto> dto = target.getHeader();

        //実施結果Outを取得
        form = target.getMst291Form();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にCVSのHeaderを設定されること
        assertEquals("料金項目コード",dto.get(0).getTitle());
        assertEquals("listRyokinKomokuCd",dto.get(0).getName());
        assertEquals("料金項目名称",dto.get(1).getTitle());
        assertEquals("listRyokinKomokuMeisho",dto.get(1).getName());
        assertEquals("適用開始日",dto.get(2).getTitle());
        assertEquals("listTekiyoKaishibi",dto.get(2).getName());
        assertEquals("料金項目グループコード",dto.get(3).getTitle());
        assertEquals("listRyokinKomokuGroupCd",dto.get(3).getName());
        assertEquals("料金項目グループ名称",dto.get(4).getTitle());
        assertEquals("listRyokinKomokuGruopMeisho",dto.get(4).getName());
        assertEquals("グループ内表示順",dto.get(5).getTitle());
        assertEquals("listGroupNaiHyojijun",dto.get(5).getName());
        assertEquals("税区分",dto.get(6).getTitle());
        assertEquals("listZeiKbn",dto.get(6).getName());
        assertEquals("輸送売上セット先",dto.get(7).getTitle());
        assertEquals("listYusoUriageSetSaki",dto.get(7).getName());
        assertEquals("プルーフ用集約項目",dto.get(8).getTitle());
        assertEquals("listProofYouShuyakuKomoku",dto.get(8).getName());
        assertEquals("明細区分",dto.get(9).getTitle());
        assertEquals("listMeisaiKbn",dto.get(9).getName());
        assertEquals("卸値率(%)",dto.get(10).getTitle());
        assertEquals("listOroshineritsu",dto.get(10).getName());
        assertEquals("卸計上箇所",dto.get(11).getTitle());
        assertEquals("listOroshiKeijoKasho",dto.get(11).getName());
        assertEquals("計上箇所名称",dto.get(12).getTitle());
        assertEquals("listOroshiKeijoKashoMeisho",dto.get(12).getName());
        assertEquals("処理科目コード",dto.get(13).getTitle());
        assertEquals("listShoriKamokuCd",dto.get(13).getName());
        assertEquals("処理科目名称",dto.get(14).getTitle());
        assertEquals("listShoriKamokuMeisho",dto.get(14).getName());
        assertEquals("補助科目コード",dto.get(15).getTitle());
        assertEquals("listHojoKamokuCd",dto.get(15).getName());
        assertEquals("補助科目名称",dto.get(16).getTitle());
        assertEquals("listHojoKamokuMeisho",dto.get(16).getName());
        assertEquals("明細項目",dto.get(17).getTitle());
        assertEquals("listMeisaiKomokuMei",dto.get(17).getName());
        assertEquals("固定項目",dto.get(18).getTitle());
        assertEquals("listKoteiKomoku",dto.get(18).getName());
        assertEquals("適用名",dto.get(19).getTitle());
        assertEquals("listTekiyoMei",dto.get(19).getName());
        assertEquals("適用終了日",dto.get(20).getTitle());
        assertEquals("listTekiyoShuryobi",dto.get(20).getName());
        assertEquals("卸値率設定可能フラグ",dto.get(21).getTitle());
        assertEquals("listOroshineritsuSetteiKanoFlg",dto.get(21).getName());
        assertEquals("固定項目フラグ",dto.get(22).getTitle());
        assertEquals("listKoteiKomokuFlg",dto.get(22).getName());
    }
    
    // beforeDown_正常_ダウンロード_4-2
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=2件
    // -----------------------------------------------------
    @Test
    public void beforeDown_正常_ダウンロード_4_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst291Form form = new Mst291Form();
        target.setMst291Form(form);
        try {
            target.beforeDown("testComment");
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(Mst291BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        //実施結果Outを取得
        form = target.getMst291Form();

        // 実行時に渡すパラメータの検証
        // 想定通りに正常にダウンロード理由を記録すること
        // 不清楚以下代码的具体用意
        assertEquals(null,form.getConRyokinKomokuGroup());
    }  

    // rirekiIchiran_正常_更新履歴コンテキストメニュー_15-1
    //
    // -------------------テスト条件--------------------------
    // 正常に取得された場合
    // -----------------------------------------------------
    @Test
    public void rirekiIchiran_正常_更新履歴コンテキストメニュー_15_1 () throws IllegalAccessException, 
            InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> titleFlgCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> searchKeyCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(rirekiSyosaiBean).searchList(titleFlgCaptor_1.capture(),functionCodeCaptor_2.capture()
                ,searchKeyCaptor_3.capture());
        //テスト実行
        Mst291Form form = new Mst291Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst291Form(form);
        target.rirekiIchiran();

        //実施結果Outを取得
        form = target.getMst291Form();

        //想定通りに履歴を表示する。
        assertEquals("2",titleFlgCaptor_1.getValue());
        assertEquals("MST291_RIREKI",functionCodeCaptor_2.getValue());
        assertEquals("listRyokinKomokuCd0",searchKeyCaptor_3.getValue().get("listRyokinKomokuCd"));
        assertEquals("listTekiyoKaishibi0",searchKeyCaptor_3.getValue().get("listTekiyoKaishibi"));
    } 
    
    // update_正常_更新処理_新規登録_16_1
    //
    // -------------------テスト条件--------------------------
    //　入力した料金項目グループコードが料金項目グループマスタに存在、入力した卸計上箇所が区分マスタ・営業所マスタに存在、
    //　入力した処理科目コードが経理科目マスタに存在、入力した処理科目コード・補助科目コードの組み合わせが経理科目マスタに存在、
    //　料金項目グループコード・グループ内表示順の組み合わせが既に存在しない
    // -----------------------------------------------------
    @Test
    public void update_正常_更新処理_新規登録_16_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //重複チェック.存在チェック
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //料金項目マスタ検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_2(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        //テスト実行
        Mst291Form form = new Mst291Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_2(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst291Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst291Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listRyokinKomokuCd0",paramsCaptor_1_Param.get("listRyokinKomokuCd"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals("listRyokinKomokuGroupCd0",paramsCaptor_1_Param.get("listRyokinKomokuGroupCd"));
        assertEquals("listGroupNaiHyojijun0",paramsCaptor_1_Param.get("listGroupNaiHyojijun"));
        assertEquals("listZeiKbn0",paramsCaptor_1_Param.get("listZeiKbn"));
        assertEquals("listYusoUriageSetSaki0",paramsCaptor_1_Param.get("listYusoUriageSetSaki"));
        assertEquals("listProofYouShuyakuKomoku0",paramsCaptor_1_Param.get("listProofYouShuyakuKomoku"));
        assertEquals("listMeisaiKbn0",paramsCaptor_1_Param.get("listMeisaiKbn"));
        assertEquals("listOroshineritsu0",paramsCaptor_1_Param.get("listOroshineritsu"));
        assertEquals("listRyokinKomokuDataVersion0",paramsCaptor_1_Param.get("listRyokinKomokuDataVersion"));
        assertEquals("listOroshiKeijoKasho0",paramsCaptor_1_Param.get("listOroshiKeijoKasho"));
        assertEquals("listOroshiKamokuCd0",paramsCaptor_1_Param.get("listOroshiKamokuCd"));
        assertEquals("listShoriKamokuCd0",paramsCaptor_1_Param.get("listShoriKamokuCd"));
        assertEquals("listHojoKamokuCd0",paramsCaptor_1_Param.get("listHojoKamokuCd"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        
        assertEquals("mst291_update",functionCodeCaptor_2.getValue());
        //想定通りに正常終了メッセージ（メッセージID：COMI0007）を表示されること
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0007",summaryCaptor_4.getValue());
        assertEquals("更新",detailCaptor_5.getValue());
    }  
    
    // update_異常_更新処理_新規登録_16_2
    //
    // -------------------テスト条件--------------------------
    // 重複チェック（新規登録行）入力した料金項目コード・適用開始日と同一データがDBに存在しています[COME0018]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_新規登録_16_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //重複チェック.入力した料金項目コード・適用開始日と同一データがDBに存在しています[COME0018]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0018",
                "listRyokinKomokuCdryokinkomokumaster");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
    
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst291Form form = new Mst291Form();
        
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_2(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst291Form(form);
        target.update();
        
        //実施結果Outを取得
        form = target.getMst291Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listRyokinKomokuCd0",paramsCaptor_1_Param.get("listRyokinKomokuCd"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals("listRyokinKomokuGroupCd0",paramsCaptor_1_Param.get("listRyokinKomokuGroupCd"));
        assertEquals("listGroupNaiHyojijun0",paramsCaptor_1_Param.get("listGroupNaiHyojijun"));
        assertEquals("listZeiKbn0",paramsCaptor_1_Param.get("listZeiKbn"));
        assertEquals("listYusoUriageSetSaki0",paramsCaptor_1_Param.get("listYusoUriageSetSaki"));
        assertEquals("listProofYouShuyakuKomoku0",paramsCaptor_1_Param.get("listProofYouShuyakuKomoku"));
        assertEquals("listMeisaiKbn0",paramsCaptor_1_Param.get("listMeisaiKbn"));
        assertEquals("listOroshineritsu0",paramsCaptor_1_Param.get("listOroshineritsu"));
        assertEquals("listRyokinKomokuDataVersion0",paramsCaptor_1_Param.get("listRyokinKomokuDataVersion"));
        assertEquals("listOroshiKeijoKasho0",paramsCaptor_1_Param.get("listOroshiKeijoKasho"));
        assertEquals("listOroshiKamokuCd0",paramsCaptor_1_Param.get("listOroshiKamokuCd"));
        assertEquals("listShoriKamokuCd0",paramsCaptor_1_Param.get("listShoriKamokuCd"));
        assertEquals("listHojoKamokuCd0",paramsCaptor_1_Param.get("listHojoKamokuCd"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        
        assertEquals("mst291-insert-update-check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0018）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0018",summaryCaptor_4.getValue());
    } 
    
    // update_異常_更新処理_新規登録_16_3
    //
    // -------------------テスト条件--------------------------
    // 入力した料金項目グループコードが料金項目グループマスタに存在しない
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_新規登録_16_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力した料金項目グループコードが料金項目グループマスタに存在しない[COME0043]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0043",
                "listRyokinKomokuGroupCd");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
    
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst291Form form = new Mst291Form();
        
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_2(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst291Form(form);
        target.update();
        
        //実施結果Outを取得
        form = target.getMst291Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listRyokinKomokuCd0",paramsCaptor_1_Param.get("listRyokinKomokuCd"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals("listRyokinKomokuGroupCd0",paramsCaptor_1_Param.get("listRyokinKomokuGroupCd"));
        assertEquals("listGroupNaiHyojijun0",paramsCaptor_1_Param.get("listGroupNaiHyojijun"));
        assertEquals("listZeiKbn0",paramsCaptor_1_Param.get("listZeiKbn"));
        assertEquals("listYusoUriageSetSaki0",paramsCaptor_1_Param.get("listYusoUriageSetSaki"));
        assertEquals("listProofYouShuyakuKomoku0",paramsCaptor_1_Param.get("listProofYouShuyakuKomoku"));
        assertEquals("listMeisaiKbn0",paramsCaptor_1_Param.get("listMeisaiKbn"));
        assertEquals("listOroshineritsu0",paramsCaptor_1_Param.get("listOroshineritsu"));
        assertEquals("listRyokinKomokuDataVersion0",paramsCaptor_1_Param.get("listRyokinKomokuDataVersion"));
        assertEquals("listOroshiKeijoKasho0",paramsCaptor_1_Param.get("listOroshiKeijoKasho"));
        assertEquals("listOroshiKamokuCd0",paramsCaptor_1_Param.get("listOroshiKamokuCd"));
        assertEquals("listShoriKamokuCd0",paramsCaptor_1_Param.get("listShoriKamokuCd"));
        assertEquals("listHojoKamokuCd0",paramsCaptor_1_Param.get("listHojoKamokuCd"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        
        assertEquals("mst291-insert-update-check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0043）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0043",summaryCaptor_4.getValue());
    }  
    
    // update_異常_更新処理_新規登録_16_4
    //
    // -------------------テスト条件--------------------------
    // 入力した卸計上箇所が区分マスタ・営業所マスタに存在しない
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_新規登録_16_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力した卸計上箇所が区分マスタ・営業所マスタに存在しない[COME0043]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0043",
                "listOroshiKeijoKasho");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
    
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst291Form form = new Mst291Form();
        
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_2(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst291Form(form);
        target.update();
        
        //実施結果Outを取得
        form = target.getMst291Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listRyokinKomokuCd0",paramsCaptor_1_Param.get("listRyokinKomokuCd"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals("listRyokinKomokuGroupCd0",paramsCaptor_1_Param.get("listRyokinKomokuGroupCd"));
        assertEquals("listGroupNaiHyojijun0",paramsCaptor_1_Param.get("listGroupNaiHyojijun"));
        assertEquals("listZeiKbn0",paramsCaptor_1_Param.get("listZeiKbn"));
        assertEquals("listYusoUriageSetSaki0",paramsCaptor_1_Param.get("listYusoUriageSetSaki"));
        assertEquals("listProofYouShuyakuKomoku0",paramsCaptor_1_Param.get("listProofYouShuyakuKomoku"));
        assertEquals("listMeisaiKbn0",paramsCaptor_1_Param.get("listMeisaiKbn"));
        assertEquals("listOroshineritsu0",paramsCaptor_1_Param.get("listOroshineritsu"));
        assertEquals("listRyokinKomokuDataVersion0",paramsCaptor_1_Param.get("listRyokinKomokuDataVersion"));
        assertEquals("listOroshiKeijoKasho0",paramsCaptor_1_Param.get("listOroshiKeijoKasho"));
        assertEquals("listOroshiKamokuCd0",paramsCaptor_1_Param.get("listOroshiKamokuCd"));
        assertEquals("listShoriKamokuCd0",paramsCaptor_1_Param.get("listShoriKamokuCd"));
        assertEquals("listHojoKamokuCd0",paramsCaptor_1_Param.get("listHojoKamokuCd"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        
        assertEquals("mst291-insert-update-check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0043）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0043",summaryCaptor_4.getValue());
    }  
    
    // update_異常_更新処理_新規登録_16_5
    //
    // -------------------テスト条件--------------------------
    // 入力した処理科目コードが経理科目マスタに存在しない
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_新規登録_16_5 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力した処理科目コードが経理科目マスタに存在しない[COME0043]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0043",
                "listShoriKamokuCd");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
    
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst291Form form = new Mst291Form();
        
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_2(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst291Form(form);
        target.update();
        
        //実施結果Outを取得
        form = target.getMst291Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listRyokinKomokuCd0",paramsCaptor_1_Param.get("listRyokinKomokuCd"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals("listRyokinKomokuGroupCd0",paramsCaptor_1_Param.get("listRyokinKomokuGroupCd"));
        assertEquals("listGroupNaiHyojijun0",paramsCaptor_1_Param.get("listGroupNaiHyojijun"));
        assertEquals("listZeiKbn0",paramsCaptor_1_Param.get("listZeiKbn"));
        assertEquals("listYusoUriageSetSaki0",paramsCaptor_1_Param.get("listYusoUriageSetSaki"));
        assertEquals("listProofYouShuyakuKomoku0",paramsCaptor_1_Param.get("listProofYouShuyakuKomoku"));
        assertEquals("listMeisaiKbn0",paramsCaptor_1_Param.get("listMeisaiKbn"));
        assertEquals("listOroshineritsu0",paramsCaptor_1_Param.get("listOroshineritsu"));
        assertEquals("listRyokinKomokuDataVersion0",paramsCaptor_1_Param.get("listRyokinKomokuDataVersion"));
        assertEquals("listOroshiKeijoKasho0",paramsCaptor_1_Param.get("listOroshiKeijoKasho"));
        assertEquals("listOroshiKamokuCd0",paramsCaptor_1_Param.get("listOroshiKamokuCd"));
        assertEquals("listShoriKamokuCd0",paramsCaptor_1_Param.get("listShoriKamokuCd"));
        assertEquals("listHojoKamokuCd0",paramsCaptor_1_Param.get("listHojoKamokuCd"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        
        assertEquals("mst291-insert-update-check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0043）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0043",summaryCaptor_4.getValue());
    }  
    
    // update_異常_更新処理_新規登録_16_6
    //
    // -------------------テスト条件--------------------------
    // 入力した処理科目コード・補助科目コードの組み合わせが経理科目マスタに存在しない
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_新規登録_16_6 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力した処理科目コード・補助科目コードの組み合わせが経理科目マスタに存在しない[COME0043]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0043",
                "listShoriKamokuCdlistHojoKamokuCd");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
    
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst291Form form = new Mst291Form();
        
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_2(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst291Form(form);
        target.update();
        
        //実施結果Outを取得
        form = target.getMst291Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listRyokinKomokuCd0",paramsCaptor_1_Param.get("listRyokinKomokuCd"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals("listRyokinKomokuGroupCd0",paramsCaptor_1_Param.get("listRyokinKomokuGroupCd"));
        assertEquals("listGroupNaiHyojijun0",paramsCaptor_1_Param.get("listGroupNaiHyojijun"));
        assertEquals("listZeiKbn0",paramsCaptor_1_Param.get("listZeiKbn"));
        assertEquals("listYusoUriageSetSaki0",paramsCaptor_1_Param.get("listYusoUriageSetSaki"));
        assertEquals("listProofYouShuyakuKomoku0",paramsCaptor_1_Param.get("listProofYouShuyakuKomoku"));
        assertEquals("listMeisaiKbn0",paramsCaptor_1_Param.get("listMeisaiKbn"));
        assertEquals("listOroshineritsu0",paramsCaptor_1_Param.get("listOroshineritsu"));
        assertEquals("listRyokinKomokuDataVersion0",paramsCaptor_1_Param.get("listRyokinKomokuDataVersion"));
        assertEquals("listOroshiKeijoKasho0",paramsCaptor_1_Param.get("listOroshiKeijoKasho"));
        assertEquals("listOroshiKamokuCd0",paramsCaptor_1_Param.get("listOroshiKamokuCd"));
        assertEquals("listShoriKamokuCd0",paramsCaptor_1_Param.get("listShoriKamokuCd"));
        assertEquals("listHojoKamokuCd0",paramsCaptor_1_Param.get("listHojoKamokuCd"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        
        assertEquals("mst291-insert-update-check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0043）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0043",summaryCaptor_4.getValue());
    }  
    
    // update_異常_更新処理_新規登録_16_7
    //
    // -------------------テスト条件--------------------------
    // 料金項目グループコード・グループ内表示順の組み合わせが既に存在する
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_新規登録_16_7 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 料金項目グループコード・グループ内表示順の組み合わせが既に存在する[MSTE0042]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0042",
                "listRyokinKomokuGroupCdlistGroupNaiHyojijun");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
    
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst291Form form = new Mst291Form();
        
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_2(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst291Form(form);
        target.update();
        
        //実施結果Outを取得
        form = target.getMst291Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listRyokinKomokuCd0",paramsCaptor_1_Param.get("listRyokinKomokuCd"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals("listRyokinKomokuGroupCd0",paramsCaptor_1_Param.get("listRyokinKomokuGroupCd"));
        assertEquals("listGroupNaiHyojijun0",paramsCaptor_1_Param.get("listGroupNaiHyojijun"));
        assertEquals("listZeiKbn0",paramsCaptor_1_Param.get("listZeiKbn"));
        assertEquals("listYusoUriageSetSaki0",paramsCaptor_1_Param.get("listYusoUriageSetSaki"));
        assertEquals("listProofYouShuyakuKomoku0",paramsCaptor_1_Param.get("listProofYouShuyakuKomoku"));
        assertEquals("listMeisaiKbn0",paramsCaptor_1_Param.get("listMeisaiKbn"));
        assertEquals("listOroshineritsu0",paramsCaptor_1_Param.get("listOroshineritsu"));
        assertEquals("listRyokinKomokuDataVersion0",paramsCaptor_1_Param.get("listRyokinKomokuDataVersion"));
        assertEquals("listOroshiKeijoKasho0",paramsCaptor_1_Param.get("listOroshiKeijoKasho"));
        assertEquals("listOroshiKamokuCd0",paramsCaptor_1_Param.get("listOroshiKamokuCd"));
        assertEquals("listShoriKamokuCd0",paramsCaptor_1_Param.get("listShoriKamokuCd"));
        assertEquals("listHojoKamokuCd0",paramsCaptor_1_Param.get("listHojoKamokuCd"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        
        assertEquals("mst291-insert-update-check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：MSTE0042）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("MSTE0042",summaryCaptor_4.getValue());
    }  
    
    // update_正常_更新処理_更新登録_16_8
    //
    // -------------------テスト条件--------------------------
    //　入力した料金項目グループコードが料金項目グループマスタに存在、入力した卸計上箇所が区分マスタ・営業所マスタに存在、
    //　入力した処理科目コードが経理科目マスタに存在、入力した処理科目コード・補助科目コードの組み合わせが経理科目マスタに存在、
    //　料金項目グループコード・グループ内表示順の組み合わせが既に存在しない
    // -----------------------------------------------------
    @Test
    public void update_正常_更新処理_更新登録_16_8 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //　入力した料金項目グループコードが料金項目グループマスタに存在、入力した卸計上箇所が区分マスタ・営業所マスタに存在、
        //　入力した処理科目コードが経理科目マスタに存在、入力した処理科目コード・補助科目コードの組み合わせが経理科目マスタに存在、
        //　料金項目グループコード・グループ内表示順の組み合わせが既に存在しない
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        // 料金項目マスタ検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_2(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        //テスト実行
        Mst291Form form = new Mst291Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_2(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst291Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst291Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listRyokinKomokuCd0",paramsCaptor_1_Param.get("listRyokinKomokuCd"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals("listRyokinKomokuGroupCd0",paramsCaptor_1_Param.get("listRyokinKomokuGroupCd"));
        assertEquals("listGroupNaiHyojijun0",paramsCaptor_1_Param.get("listGroupNaiHyojijun"));
        assertEquals("listZeiKbn0",paramsCaptor_1_Param.get("listZeiKbn"));
        assertEquals("listYusoUriageSetSaki0",paramsCaptor_1_Param.get("listYusoUriageSetSaki"));
        assertEquals("listProofYouShuyakuKomoku0",paramsCaptor_1_Param.get("listProofYouShuyakuKomoku"));
        assertEquals("listMeisaiKbn0",paramsCaptor_1_Param.get("listMeisaiKbn"));
        assertEquals("listOroshineritsu0",paramsCaptor_1_Param.get("listOroshineritsu"));
        assertEquals("listRyokinKomokuDataVersion0",paramsCaptor_1_Param.get("listRyokinKomokuDataVersion"));
        assertEquals("listOroshiKeijoKasho0",paramsCaptor_1_Param.get("listOroshiKeijoKasho"));
        assertEquals("listOroshiKamokuCd0",paramsCaptor_1_Param.get("listOroshiKamokuCd"));
        assertEquals("listShoriKamokuCd0",paramsCaptor_1_Param.get("listShoriKamokuCd"));
        assertEquals("listHojoKamokuCd0",paramsCaptor_1_Param.get("listHojoKamokuCd"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        
        assertEquals("mst291_update",functionCodeCaptor_2.getValue());
        //想定通りに正常終了メッセージ（メッセージID：COMI0007）を表示されること
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0007",summaryCaptor_4.getValue());
        assertEquals("更新",detailCaptor_5.getValue());
    }  
    
    // update_異常_更新処理_更新登録_16_9
    //
    // -------------------テスト条件--------------------------
    // 重複チェック（更新行）入力した料金項目コード・適用開始日が変更されている かつ　入力した料金項目コード・適用開始日と同一データがDBに存在する[COME0018]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_16_9 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 重複チェック.入力した料金項目コード・適用開始日が変更されている かつ　入力した料金項目コード・適用開始日と同一データがDBに存在する[COME0018]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0018",
                "listRyokinKomokuCdryokinkomokumaster");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
    
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst291Form form = new Mst291Form();
        
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_2(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst291Form(form);
        target.update();
        
        //実施結果Outを取得
        form = target.getMst291Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listRyokinKomokuCd0",paramsCaptor_1_Param.get("listRyokinKomokuCd"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals("listRyokinKomokuGroupCd0",paramsCaptor_1_Param.get("listRyokinKomokuGroupCd"));
        assertEquals("listGroupNaiHyojijun0",paramsCaptor_1_Param.get("listGroupNaiHyojijun"));
        assertEquals("listZeiKbn0",paramsCaptor_1_Param.get("listZeiKbn"));
        assertEquals("listYusoUriageSetSaki0",paramsCaptor_1_Param.get("listYusoUriageSetSaki"));
        assertEquals("listProofYouShuyakuKomoku0",paramsCaptor_1_Param.get("listProofYouShuyakuKomoku"));
        assertEquals("listMeisaiKbn0",paramsCaptor_1_Param.get("listMeisaiKbn"));
        assertEquals("listOroshineritsu0",paramsCaptor_1_Param.get("listOroshineritsu"));
        assertEquals("listRyokinKomokuDataVersion0",paramsCaptor_1_Param.get("listRyokinKomokuDataVersion"));
        assertEquals("listOroshiKeijoKasho0",paramsCaptor_1_Param.get("listOroshiKeijoKasho"));
        assertEquals("listOroshiKamokuCd0",paramsCaptor_1_Param.get("listOroshiKamokuCd"));
        assertEquals("listShoriKamokuCd0",paramsCaptor_1_Param.get("listShoriKamokuCd"));
        assertEquals("listHojoKamokuCd0",paramsCaptor_1_Param.get("listHojoKamokuCd"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        
        assertEquals("mst291-insert-update-check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0018）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0018",summaryCaptor_4.getValue());
    } 
    
    // update_異常_更新処理_更新登録_16_10
    //
    // -------------------テスト条件--------------------------
    // 入力した料金項目グループコードが料金項目グループマスタに存在しない
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_16_10 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //入力した料金項目グループコードが料金項目グループマスタに存在しない[COME0043]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0043",
                "listRyokinKomokuGroupCd");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
    
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst291Form form = new Mst291Form();
        
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_2(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst291Form(form);
        target.update();
        
        //実施結果Outを取得
        form = target.getMst291Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listRyokinKomokuCd0",paramsCaptor_1_Param.get("listRyokinKomokuCd"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals("listRyokinKomokuGroupCd0",paramsCaptor_1_Param.get("listRyokinKomokuGroupCd"));
        assertEquals("listGroupNaiHyojijun0",paramsCaptor_1_Param.get("listGroupNaiHyojijun"));
        assertEquals("listZeiKbn0",paramsCaptor_1_Param.get("listZeiKbn"));
        assertEquals("listYusoUriageSetSaki0",paramsCaptor_1_Param.get("listYusoUriageSetSaki"));
        assertEquals("listProofYouShuyakuKomoku0",paramsCaptor_1_Param.get("listProofYouShuyakuKomoku"));
        assertEquals("listMeisaiKbn0",paramsCaptor_1_Param.get("listMeisaiKbn"));
        assertEquals("listOroshineritsu0",paramsCaptor_1_Param.get("listOroshineritsu"));
        assertEquals("listRyokinKomokuDataVersion0",paramsCaptor_1_Param.get("listRyokinKomokuDataVersion"));
        assertEquals("listOroshiKeijoKasho0",paramsCaptor_1_Param.get("listOroshiKeijoKasho"));
        assertEquals("listOroshiKamokuCd0",paramsCaptor_1_Param.get("listOroshiKamokuCd"));
        assertEquals("listShoriKamokuCd0",paramsCaptor_1_Param.get("listShoriKamokuCd"));
        assertEquals("listHojoKamokuCd0",paramsCaptor_1_Param.get("listHojoKamokuCd"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        
        assertEquals("mst291-insert-update-check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0043）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0043",summaryCaptor_4.getValue());
    }  
    
    // update_異常_更新処理_更新登録_16_11
    //
    // -------------------テスト条件--------------------------
    // 入力した卸計上箇所が区分マスタ・営業所マスタに存在しない
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_16_11 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力した卸計上箇所が区分マスタ・営業所マスタに存在しない[COME0043]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0043",
                "listOroshiKeijoKasho");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
    
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst291Form form = new Mst291Form();
        
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_2(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst291Form(form);
        target.update();
        
        //実施結果Outを取得
        form = target.getMst291Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listRyokinKomokuCd0",paramsCaptor_1_Param.get("listRyokinKomokuCd"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals("listRyokinKomokuGroupCd0",paramsCaptor_1_Param.get("listRyokinKomokuGroupCd"));
        assertEquals("listGroupNaiHyojijun0",paramsCaptor_1_Param.get("listGroupNaiHyojijun"));
        assertEquals("listZeiKbn0",paramsCaptor_1_Param.get("listZeiKbn"));
        assertEquals("listYusoUriageSetSaki0",paramsCaptor_1_Param.get("listYusoUriageSetSaki"));
        assertEquals("listProofYouShuyakuKomoku0",paramsCaptor_1_Param.get("listProofYouShuyakuKomoku"));
        assertEquals("listMeisaiKbn0",paramsCaptor_1_Param.get("listMeisaiKbn"));
        assertEquals("listOroshineritsu0",paramsCaptor_1_Param.get("listOroshineritsu"));
        assertEquals("listRyokinKomokuDataVersion0",paramsCaptor_1_Param.get("listRyokinKomokuDataVersion"));
        assertEquals("listOroshiKeijoKasho0",paramsCaptor_1_Param.get("listOroshiKeijoKasho"));
        assertEquals("listOroshiKamokuCd0",paramsCaptor_1_Param.get("listOroshiKamokuCd"));
        assertEquals("listShoriKamokuCd0",paramsCaptor_1_Param.get("listShoriKamokuCd"));
        assertEquals("listHojoKamokuCd0",paramsCaptor_1_Param.get("listHojoKamokuCd"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        
        assertEquals("mst291-insert-update-check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0043）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0043",summaryCaptor_4.getValue());
    }  
    
    // update_異常_更新処理_更新登録_16_12
    //
    // -------------------テスト条件--------------------------
    // 入力した処理科目コードが経理科目マスタに存在しない
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_16_12 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力した処理科目コードが経理科目マスタに存在しない[COME0043]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0043",
                "listShoriKamokuCd");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
    
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst291Form form = new Mst291Form();
        
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_2(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst291Form(form);
        target.update();
        
        //実施結果Outを取得
        form = target.getMst291Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listRyokinKomokuCd0",paramsCaptor_1_Param.get("listRyokinKomokuCd"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals("listRyokinKomokuGroupCd0",paramsCaptor_1_Param.get("listRyokinKomokuGroupCd"));
        assertEquals("listGroupNaiHyojijun0",paramsCaptor_1_Param.get("listGroupNaiHyojijun"));
        assertEquals("listZeiKbn0",paramsCaptor_1_Param.get("listZeiKbn"));
        assertEquals("listYusoUriageSetSaki0",paramsCaptor_1_Param.get("listYusoUriageSetSaki"));
        assertEquals("listProofYouShuyakuKomoku0",paramsCaptor_1_Param.get("listProofYouShuyakuKomoku"));
        assertEquals("listMeisaiKbn0",paramsCaptor_1_Param.get("listMeisaiKbn"));
        assertEquals("listOroshineritsu0",paramsCaptor_1_Param.get("listOroshineritsu"));
        assertEquals("listRyokinKomokuDataVersion0",paramsCaptor_1_Param.get("listRyokinKomokuDataVersion"));
        assertEquals("listOroshiKeijoKasho0",paramsCaptor_1_Param.get("listOroshiKeijoKasho"));
        assertEquals("listOroshiKamokuCd0",paramsCaptor_1_Param.get("listOroshiKamokuCd"));
        assertEquals("listShoriKamokuCd0",paramsCaptor_1_Param.get("listShoriKamokuCd"));
        assertEquals("listHojoKamokuCd0",paramsCaptor_1_Param.get("listHojoKamokuCd"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        
        assertEquals("mst291-insert-update-check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0043）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0043",summaryCaptor_4.getValue());
    }  
    
    // update_異常_更新処理_更新登録_16_13
    //
    // -------------------テスト条件--------------------------
    // 入力した処理科目コード・補助科目コードの組み合わせが経理科目マスタに存在しない
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_16_13 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力した処理科目コード・補助科目コードの組み合わせが経理科目マスタに存在しない[COME0043]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0043",
                "listShoriKamokuCdlistHojoKamokuCd");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
    
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst291Form form = new Mst291Form();
        
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_2(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst291Form(form);
        target.update();
        
        //実施結果Outを取得
        form = target.getMst291Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listRyokinKomokuCd0",paramsCaptor_1_Param.get("listRyokinKomokuCd"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals("listRyokinKomokuGroupCd0",paramsCaptor_1_Param.get("listRyokinKomokuGroupCd"));
        assertEquals("listGroupNaiHyojijun0",paramsCaptor_1_Param.get("listGroupNaiHyojijun"));
        assertEquals("listZeiKbn0",paramsCaptor_1_Param.get("listZeiKbn"));
        assertEquals("listYusoUriageSetSaki0",paramsCaptor_1_Param.get("listYusoUriageSetSaki"));
        assertEquals("listProofYouShuyakuKomoku0",paramsCaptor_1_Param.get("listProofYouShuyakuKomoku"));
        assertEquals("listMeisaiKbn0",paramsCaptor_1_Param.get("listMeisaiKbn"));
        assertEquals("listOroshineritsu0",paramsCaptor_1_Param.get("listOroshineritsu"));
        assertEquals("listRyokinKomokuDataVersion0",paramsCaptor_1_Param.get("listRyokinKomokuDataVersion"));
        assertEquals("listOroshiKeijoKasho0",paramsCaptor_1_Param.get("listOroshiKeijoKasho"));
        assertEquals("listOroshiKamokuCd0",paramsCaptor_1_Param.get("listOroshiKamokuCd"));
        assertEquals("listShoriKamokuCd0",paramsCaptor_1_Param.get("listShoriKamokuCd"));
        assertEquals("listHojoKamokuCd0",paramsCaptor_1_Param.get("listHojoKamokuCd"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        
        assertEquals("mst291-insert-update-check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0043）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0043",summaryCaptor_4.getValue());
    }  
    
    // update_異常_更新処理_更新登録_16_14
    //
    // -------------------テスト条件--------------------------
    // 料金項目グループコード・グループ内表示順の組み合わせが既に存在する
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_16_14 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 料金項目グループコード・グループ内表示順の組み合わせが既に存在する[MSTE0042]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0042",
                "listRyokinKomokuGroupCdlistGroupNaiHyojijun");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
    
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst291Form form = new Mst291Form();
        
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_2(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst291Form(form);
        target.update();
        
        //実施結果Outを取得
        form = target.getMst291Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listRyokinKomokuCd0",paramsCaptor_1_Param.get("listRyokinKomokuCd"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals("listRyokinKomokuGroupCd0",paramsCaptor_1_Param.get("listRyokinKomokuGroupCd"));
        assertEquals("listGroupNaiHyojijun0",paramsCaptor_1_Param.get("listGroupNaiHyojijun"));
        assertEquals("listZeiKbn0",paramsCaptor_1_Param.get("listZeiKbn"));
        assertEquals("listYusoUriageSetSaki0",paramsCaptor_1_Param.get("listYusoUriageSetSaki"));
        assertEquals("listProofYouShuyakuKomoku0",paramsCaptor_1_Param.get("listProofYouShuyakuKomoku"));
        assertEquals("listMeisaiKbn0",paramsCaptor_1_Param.get("listMeisaiKbn"));
        assertEquals("listOroshineritsu0",paramsCaptor_1_Param.get("listOroshineritsu"));
        assertEquals("listRyokinKomokuDataVersion0",paramsCaptor_1_Param.get("listRyokinKomokuDataVersion"));
        assertEquals("listOroshiKeijoKasho0",paramsCaptor_1_Param.get("listOroshiKeijoKasho"));
        assertEquals("listOroshiKamokuCd0",paramsCaptor_1_Param.get("listOroshiKamokuCd"));
        assertEquals("listShoriKamokuCd0",paramsCaptor_1_Param.get("listShoriKamokuCd"));
        assertEquals("listHojoKamokuCd0",paramsCaptor_1_Param.get("listHojoKamokuCd"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("Tue Mar 19 00:00:00 CST 2019",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        
        assertEquals("mst291-insert-update-check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：MSTE0042）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("MSTE0042",summaryCaptor_4.getValue());
    } 
    
    // update_異常_更新処理_新規登録_16_15
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_新規登録_16_15 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        //テスト実行
        Mst291Form form = new Mst291Form();
        target.setMst291Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst291Form();

        //想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0029",summaryCaptor_2.getValue());
    }  
    
    // update_異常_更新処理_更新登録_16_16
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_16_16 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        //テスト実行
        Mst291Form form = new Mst291Form();
        target.setMst291Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst291Form();

        //想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0029",summaryCaptor_2.getValue());
    }  
    
    // delRows_異常_料金項目マスタ削除処理_17-1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // 固定項目フラグが"0"の場合　料金項目コード・適用開始日の組み合わせが料金項目マスタに存在する場合
    // -----------------------------------------------------
    @Test
    public void delRows_異常_料金項目マスタ削除処理_17_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        //テスト実行
        Mst291Form form = new Mst291Form();
        //行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        form.setSelectedSearchResult(result);
        target.setMst291Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst291Form();

        //想定通りにエラーが発生。（メッセージID：COME0013）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0013",summaryCaptor_2.getValue());
    }  
    
    // delRows_異常_料金項目マスタ削除処理_17_2
    //
    // -------------------テスト条件--------------------------
    // 固定項目フラグが"1"の場合
    // -----------------------------------------------------
    @Test
    public void delRows_異常_料金項目マスタ削除処理_17_2 () throws IllegalAccessException, InvocationTargetException {

      // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 固定項目フラグが"1"の場合[MTSE0043]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MTSE0043", "");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2
                .capture(),summaryCaptor_3.capture(),summaryCaptor_4.capture())).thenReturn(messageModuleBean);

        //テスト実行
        Mst291Form form = new Mst291Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        form.setSearchResult(result);
        target.setMst291Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst291Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listRyokinKomokuCd0",paramsCaptor_1_Param.get("listRyokinKomokuCd"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("listTekiyoKaishibi0",paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals("listRyokinKomokuGroupCd0",paramsCaptor_1_Param.get("listRyokinKomokuGroupCd"));
        assertEquals("listGroupNaiHyojijun0",paramsCaptor_1_Param.get("listGroupNaiHyojijun"));
        assertEquals("listZeiKbn0",paramsCaptor_1_Param.get("listZeiKbn"));
        assertEquals("listYusoUriageSetSaki0",paramsCaptor_1_Param.get("listYusoUriageSetSaki"));
        assertEquals("listProofYouShuyakuKomoku0",paramsCaptor_1_Param.get("listProofYouShuyakuKomoku"));
        assertEquals("listMeisaiKbn0",paramsCaptor_1_Param.get("listMeisaiKbn"));
        assertEquals("listOroshineritsu0",paramsCaptor_1_Param.get("listOroshineritsu"));
        assertEquals("listRyokinKomokuDataVersion0",paramsCaptor_1_Param.get("listRyokinKomokuDataVersion"));
        assertEquals("listOroshiKeijoKasho0",paramsCaptor_1_Param.get("listOroshiKeijoKasho"));
        assertEquals("listOroshiKamokuCd0",paramsCaptor_1_Param.get("listOroshiKamokuCd"));
        assertEquals("listShoriKamokuCd0",paramsCaptor_1_Param.get("listShoriKamokuCd"));
        assertEquals("listHojoKamokuCd0",paramsCaptor_1_Param.get("listHojoKamokuCd"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("mst291-delete-exist",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0006）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("MTSE0043",summaryCaptor_2.getValue());
    }   
    
    // delRows_異常_料金項目マスタ削除処理_17_3
    //
    // -------------------テスト条件--------------------------
    // 料金項目コード・適用開始日の組み合わせが料金項目マスタに存在しない場合
    // -----------------------------------------------------
    @Test
    public void delRows_異常_料金項目マスタ削除処理_17_3 () throws IllegalAccessException, InvocationTargetException {

      // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 料金項目コード・適用開始日の組み合わせが料金項目マスタに存在しない場合[MSTE0109]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0109",
                "listRyokinKomokuCdlistTekiyoKaishibi");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2
                .capture(),summaryCaptor_3.capture(),summaryCaptor_4.capture())).thenReturn(messageModuleBean);

        //テスト実行
        Mst291Form form = new Mst291Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        form.setSearchResult(result);
        target.setMst291Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst291Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listRyokinKomokuCd0",paramsCaptor_1_Param.get("listRyokinKomokuCd"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("listTekiyoKaishibi0",paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals("listRyokinKomokuGroupCd0",paramsCaptor_1_Param.get("listRyokinKomokuGroupCd"));
        assertEquals("listGroupNaiHyojijun0",paramsCaptor_1_Param.get("listGroupNaiHyojijun"));
        assertEquals("listZeiKbn0",paramsCaptor_1_Param.get("listZeiKbn"));
        assertEquals("listYusoUriageSetSaki0",paramsCaptor_1_Param.get("listYusoUriageSetSaki"));
        assertEquals("listProofYouShuyakuKomoku0",paramsCaptor_1_Param.get("listProofYouShuyakuKomoku"));
        assertEquals("listMeisaiKbn0",paramsCaptor_1_Param.get("listMeisaiKbn"));
        assertEquals("listOroshineritsu0",paramsCaptor_1_Param.get("listOroshineritsu"));
        assertEquals("listRyokinKomokuDataVersion0",paramsCaptor_1_Param.get("listRyokinKomokuDataVersion"));
        assertEquals("listOroshiKeijoKasho0",paramsCaptor_1_Param.get("listOroshiKeijoKasho"));
        assertEquals("listOroshiKamokuCd0",paramsCaptor_1_Param.get("listOroshiKamokuCd"));
        assertEquals("listShoriKamokuCd0",paramsCaptor_1_Param.get("listShoriKamokuCd"));
        assertEquals("listHojoKamokuCd0",paramsCaptor_1_Param.get("listHojoKamokuCd"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("mst291-delete-exist",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：MSTE0109）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("MSTE0109",summaryCaptor_2.getValue());
    }   
    
    // delRows_正常_料金項目マスタ削除処理_17_4
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 1
    // 料金項目コード・適用開始日の組み合わせが料金項目マスタに存在場合
    // -----------------------------------------------------
    @Test
    public void delRows_正常_料金項目マスタ削除処理_17_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture());

        //テスト実行
        Mst291Form form = new Mst291Form();
        // 行選択チェック選択 = 1
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst291Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst291Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listRyokinKomokuCd0",paramsCaptor_1_Param.get("listRyokinKomokuCd"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("listTekiyoKaishibi0",paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals("listRyokinKomokuGroupCd0",paramsCaptor_1_Param.get("listRyokinKomokuGroupCd"));
        assertEquals("listGroupNaiHyojijun0",paramsCaptor_1_Param.get("listGroupNaiHyojijun"));
        assertEquals("listZeiKbn0",paramsCaptor_1_Param.get("listZeiKbn"));
        assertEquals("listYusoUriageSetSaki0",paramsCaptor_1_Param.get("listYusoUriageSetSaki"));
        assertEquals("listProofYouShuyakuKomoku0",paramsCaptor_1_Param.get("listProofYouShuyakuKomoku"));
        assertEquals("listMeisaiKbn0",paramsCaptor_1_Param.get("listMeisaiKbn"));
        assertEquals("listOroshineritsu0",paramsCaptor_1_Param.get("listOroshineritsu"));
        assertEquals("listRyokinKomokuDataVersion0",paramsCaptor_1_Param.get("listRyokinKomokuDataVersion"));
        assertEquals("listOroshiKeijoKasho0",paramsCaptor_1_Param.get("listOroshiKeijoKasho"));
        assertEquals("listOroshiKamokuCd0",paramsCaptor_1_Param.get("listOroshiKamokuCd"));
        assertEquals("listShoriKamokuCd0",paramsCaptor_1_Param.get("listShoriKamokuCd"));
        assertEquals("listHojoKamokuCd0",paramsCaptor_1_Param.get("listHojoKamokuCd"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("mst291_delete",functionCodeCaptor_2.getValue());
        //想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること仕向地名マスタ削除処理を行う。
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0004",summaryCaptor_4.getValue());
        assertEquals("削除",detailCaptor_5.getValue());
    }   
    
    // delRows_正常_料金項目マスタ削除処理_17_5
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 2
    // 料金項目コード・適用開始日の組み合わせが料金項目マスタに存在場合
    // -----------------------------------------------------
    @Test
    public void delRows_正常_料金項目マスタ削除処理_17_5 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture());

        //テスト実行
        Mst291Form form = new Mst291Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst291Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst291Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listRyokinKomokuCd0",paramsCaptor_1_Param.get("listRyokinKomokuCd"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("listTekiyoKaishibi0",paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals("listRyokinKomokuGroupCd0",paramsCaptor_1_Param.get("listRyokinKomokuGroupCd"));
        assertEquals("listGroupNaiHyojijun0",paramsCaptor_1_Param.get("listGroupNaiHyojijun"));
        assertEquals("listZeiKbn0",paramsCaptor_1_Param.get("listZeiKbn"));
        assertEquals("listYusoUriageSetSaki0",paramsCaptor_1_Param.get("listYusoUriageSetSaki"));
        assertEquals("listProofYouShuyakuKomoku0",paramsCaptor_1_Param.get("listProofYouShuyakuKomoku"));
        assertEquals("listMeisaiKbn0",paramsCaptor_1_Param.get("listMeisaiKbn"));
        assertEquals("listOroshineritsu0",paramsCaptor_1_Param.get("listOroshineritsu"));
        assertEquals("listRyokinKomokuDataVersion0",paramsCaptor_1_Param.get("listRyokinKomokuDataVersion"));
        assertEquals("listOroshiKeijoKasho0",paramsCaptor_1_Param.get("listOroshiKeijoKasho"));
        assertEquals("listOroshiKamokuCd0",paramsCaptor_1_Param.get("listOroshiKamokuCd"));
        assertEquals("listShoriKamokuCd0",paramsCaptor_1_Param.get("listShoriKamokuCd"));
        assertEquals("listHojoKamokuCd0",paramsCaptor_1_Param.get("listHojoKamokuCd"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("mst291_delete",functionCodeCaptor_2.getValue());
        //想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること仕向地名マスタ削除処理を行う。
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0004",summaryCaptor_4.getValue());
        assertEquals("削除",detailCaptor_5.getValue());
    } 
    
    private Map<String, String> createRecMapFor_1_1(int i) {
        Map recMap = new HashMap();
        recMap.put("listRyokinKomokuCd", "listRyokinKomokuCd" + i);
        recMap.put("listRyokinKomokuMeisho", "listRyokinKomokuMeisho" + i);
        recMap.put("listTekiyoKaishibi", "listTekiyoKaishibi" + i);
        recMap.put("listRyokinKomokuGroupCd", "listRyokinKomokuGroupCd" + i);
        recMap.put("listRyokinKomokuGruopMeisho", "listRyokinKomokuGruopMeisho" + i);
        recMap.put("listGroupNaiHyojijun", "listGroupNaiHyojijun" + i);
        recMap.put("listZeiKbn", "listZeiKbn" + i);
        recMap.put("listYusoUriageSetSaki", "listYusoUriageSetSaki" + i);
        recMap.put("listProofYouShuyakuKomoku", "listProofYouShuyakuKomoku" + i);
        recMap.put("listMeisaiKbn", "listMeisaiKbn" + i);
        recMap.put("listOroshineritsuSetteiKanoFlg", "listOroshineritsuSetteiKanoFlg" + i);
        recMap.put("listOroshineritsu", "listOroshineritsu" + i);
        recMap.put("listOroshiKeijoKasho", "listOroshiKeijoKasho" + i);
        recMap.put("listOroshiKeijoKashoMeisho", "listOroshiKeijoKashoMeisho" + i);
        recMap.put("listOroshiKamokuCd", "listOroshiKamokuCd" + i);
        recMap.put("listOroshiKamokuMeisho", "listOroshiKamokuMeisho" + i);
        recMap.put("listShoriKamokuCd", "listShoriKamokuCd" + i);
        recMap.put("listShoriKamokuMeisho", "listShoriKamokuMeisho" + i);
        recMap.put("listHojoKamokuCd", "listHojoKamokuCd" + i);
        recMap.put("listHojoKamokuMeisho", "listHojoKamokuMeisho" + i);
        recMap.put("listMeisaiKomokuMei", "listMeisaiKomokuMei" + i);
        recMap.put("listKoteiKomoku", "listKoteiKomoku" + i);
        recMap.put("listTekiyoMei", "listTekiyoMei" + i);
        recMap.put("listTekiyoShuryobi", "listTekiyoShuryobi" + i);
        recMap.put("listRyokinKomokuDataVersion", "listRyokinKomokuDataVersion" + i);
        recMap.put("listKoteiKomokuFlg", "listKoteiKomokuFlg" + i);
        return recMap;
    }
    
    private Map<String, String> createRecMapFor_1_2(int i) {
        Map recMap = new HashMap();
        recMap.put("listRyokinKomokuCd", "listRyokinKomokuCd" + i);
        recMap.put("listRyokinKomokuMeisho", "listRyokinKomokuMeisho" + i);
        recMap.put("listTekiyoKaishibi", "Tue Mar 19 00:00:00 CST 2019");
        recMap.put("listRyokinKomokuGroupCd", "listRyokinKomokuGroupCd" + i);
        recMap.put("listRyokinKomokuGruopMeisho", "listRyokinKomokuGruopMeisho" + i);
        recMap.put("listGroupNaiHyojijun", "listGroupNaiHyojijun" + i);
        recMap.put("listZeiKbn", "listZeiKbn" + i);
        recMap.put("listYusoUriageSetSaki", "listYusoUriageSetSaki" + i);
        recMap.put("listProofYouShuyakuKomoku", "listProofYouShuyakuKomoku" + i);
        recMap.put("listMeisaiKbn", "listMeisaiKbn" + i);
        recMap.put("listOroshineritsuSetteiKanoFlg", "listOroshineritsuSetteiKanoFlg" + i);
        recMap.put("listOroshineritsu", "listOroshineritsu" + i);
        recMap.put("listOroshiKeijoKasho", "listOroshiKeijoKasho" + i);
        recMap.put("listOroshiKeijoKashoMeisho", "listOroshiKeijoKashoMeisho" + i);
        recMap.put("listOroshiKamokuCd", "listOroshiKamokuCd" + i);
        recMap.put("listOroshiKamokuMeisho", "listOroshiKamokuMeisho" + i);
        recMap.put("listShoriKamokuCd", "listShoriKamokuCd" + i);
        recMap.put("listShoriKamokuMeisho", "listShoriKamokuMeisho" + i);
        recMap.put("listHojoKamokuCd", "listHojoKamokuCd" + i);
        recMap.put("listHojoKamokuMeisho", "listHojoKamokuMeisho" + i);
        recMap.put("listMeisaiKomokuMei", "listMeisaiKomokuMei" + i);
        recMap.put("listKoteiKomoku", "listKoteiKomoku" + i);
        recMap.put("listTekiyoMei", "listTekiyoMei" + i);
        recMap.put("listShuryoFlg", "true");
        recMap.put("listTekiyoShuryobi", "Tue Mar 19 00:00:00 CST 2019");
        recMap.put("listRyokinKomokuDataVersion", "listRyokinKomokuDataVersion" + i);
        recMap.put("listKoteiKomokuFlg", "listKoteiKomokuFlg" + i);
        return recMap;
    }

    private Map<String, Object> createRecMapFor_11_1(int i) {
        Map recMap = new HashMap();
        recMap.put("listRyokinKomokuCd", "listRyokinKomokuCd" + i);
        recMap.put("listRyokinKomokuMeisho", "listRyokinKomokuMeisho" + i);
        recMap.put("listTekiyoKaishibi", "listTekiyoKaishibi" + i);
        recMap.put("listRyokinKomokuGroupCd", "listRyokinKomokuGroupCd" + i);
        recMap.put("listRyokinKomokuGruopMeisho", "listRyokinKomokuGruopMeisho" + i);
        recMap.put("listGroupNaiHyojijun", "listGroupNaiHyojijun" + i);
        recMap.put("listZeiKbn", "listZeiKbn" + i);
        recMap.put("listYusoUriageSetSaki", "listYusoUriageSetSaki" + i);
        recMap.put("listProofYouShuyakuKomoku", "listProofYouShuyakuKomoku" + i);
        recMap.put("listMeisaiKbn", "listMeisaiKbn" + i);
        recMap.put("listOroshineritsuSetteiKanoFlg", "listOroshineritsuSetteiKanoFlg" + i);
        recMap.put("listOroshineritsu", "listOroshineritsu" + i);
        recMap.put("listOroshiKeijoKasho", "listOroshiKeijoKasho" + i);
        recMap.put("listOroshiKeijoKashoMeisho", "listOroshiKeijoKashoMeisho" + i);
        recMap.put("listOroshiKamokuCd", "listOroshiKamokuCd" + i);
        recMap.put("listOroshiKamokuMeisho", "listOroshiKamokuMeisho" + i);
        recMap.put("listShoriKamokuCd", "listShoriKamokuCd" + i);
        recMap.put("listShoriKamokuMeisho", "listShoriKamokuMeisho" + i);
        recMap.put("listHojoKamokuCd", "listHojoKamokuCd" + i);
        recMap.put("listHojoKamokuMeisho", "listHojoKamokuMeisho" + i);
        recMap.put("listMeisaiKomokuMei", "listMeisaiKomokuMei" + i);
        recMap.put("listKoteiKomoku", "listKoteiKomoku" + i);
        recMap.put("listTekiyoMei", "listTekiyoMei" + i);
        recMap.put("listTekiyoShuryobi", "listTekiyoShuryobi" + i);
        recMap.put("listRyokinKomokuDataVersion", "listRyokinKomokuDataVersion" + i);
        recMap.put("listKoteiKomokuFlg", "listKoteiKomokuFlg" + i);
        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }
    
    private Map<String, Object> createRecMapFor_11_2(int i) {
        Map recMap = new HashMap();
        recMap.put("listRyokinKomokuCd", "listRyokinKomokuCd" + i);
        recMap.put("listRyokinKomokuMeisho", "listRyokinKomokuMeisho" + i);
        recMap.put("listTekiyoKaishibi", "Tue Mar 19 00:00:00 CST 2019");
        recMap.put("listRyokinKomokuGroupCd", "listRyokinKomokuGroupCd" + i);
        recMap.put("listRyokinKomokuGruopMeisho", "listRyokinKomokuGruopMeisho" + i);
        recMap.put("listGroupNaiHyojijun", "listGroupNaiHyojijun" + i);
        recMap.put("listZeiKbn", "listZeiKbn" + i);
        recMap.put("listYusoUriageSetSaki", "listYusoUriageSetSaki" + i);
        recMap.put("listProofYouShuyakuKomoku", "listProofYouShuyakuKomoku" + i);
        recMap.put("listMeisaiKbn", "listMeisaiKbn" + i);
        recMap.put("listOroshineritsuSetteiKanoFlg", "listOroshineritsuSetteiKanoFlg" + i);
        recMap.put("listOroshineritsu", "listOroshineritsu" + i);
        recMap.put("listOroshiKeijoKasho", "listOroshiKeijoKasho" + i);
        recMap.put("listOroshiKeijoKashoMeisho", "listOroshiKeijoKashoMeisho" + i);
        recMap.put("listOroshiKamokuCd", "listOroshiKamokuCd" + i);
        recMap.put("listOroshiKamokuMeisho", "listOroshiKamokuMeisho" + i);
        recMap.put("listShoriKamokuCd", "listShoriKamokuCd" + i);
        recMap.put("listShoriKamokuMeisho", "listShoriKamokuMeisho" + i);
        recMap.put("listHojoKamokuCd", "listHojoKamokuCd" + i);
        recMap.put("listHojoKamokuMeisho", "listHojoKamokuMeisho" + i);
        recMap.put("listMeisaiKomokuMei", "listMeisaiKomokuMei" + i);
        recMap.put("listKoteiKomoku", "listKoteiKomoku" + i);
        recMap.put("listTekiyoMei", "listTekiyoMei" + i);
        recMap.put("listShuryoFlg", "true");
        recMap.put("listTekiyoShuryobi", "Tue Mar 19 00:00:00 CST 2019");
        recMap.put("listRyokinKomokuDataVersion", "listRyokinKomokuDataVersion" + i);
        recMap.put("listKoteiKomokuFlg", "listKoteiKomokuFlg" + i);
        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }

    private void assertForRecList_2_1(Mst291Form form) {
        int i = 0;
        assertEquals(0, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listRyokinKomokuCd" + i, rec.get("listRyokinKomokuCd"));
            assertEquals("listRyokinKomokuMeisho" + i, rec.get("listRyokinKomokuMeisho"));
            assertEquals("listTekiyoKaishibi" + i, rec.get("listTekiyoKaishibi"));
            assertEquals("listRyokinKomokuGroupCd" + i, rec.get("listRyokinKomokuGroupCd"));
            assertEquals("listRyokinKomokuGruopMeisho" + i, rec.get("listRyokinKomokuGruopMeisho"));
            assertEquals("listGroupNaiHyojijun" + i, rec.get("listGroupNaiHyojijun"));
            assertEquals("listZeiKbn" + i, rec.get("listZeiKbn"));
            assertEquals("listYusoUriageSetSaki" + i, rec.get("listYusoUriageSetSaki"));
            assertEquals("listProofYouShuyakuKomoku" + i, rec.get("listProofYouShuyakuKomoku"));
            assertEquals("listMeisaiKbn" + i, rec.get("listMeisaiKbn"));
            assertEquals("listOroshineritsuSetteiKanoFlg" + i, rec.get("listOroshineritsuSetteiKanoFlg"));
            assertEquals("listOroshineritsu" + i, rec.get("listOroshineritsu"));
            assertEquals("listOroshiKeijoKasho" + i, rec.get("listOroshiKeijoKasho"));
            assertEquals("listOroshiKeijoKashoMeisho" + i, rec.get("listOroshiKeijoKashoMeisho"));
            assertEquals("listOroshiKamokuCd" + i, rec.get("listOroshiKamokuCd"));
            assertEquals("listOroshiKamokuMeisho" + i, rec.get("listOroshiKamokuMeisho"));
            assertEquals("listShoriKamokuCd" + i, rec.get("listShoriKamokuCd"));
            assertEquals("listShoriKamokuMeisho" + i, rec.get("listShoriKamokuMeisho"));
            assertEquals("listHojoKamokuCd" + i, rec.get("listHojoKamokuCd"));
            assertEquals("listHojoKamokuMeisho" + i, rec.get("listHojoKamokuMeisho"));
            assertEquals("listMeisaiKomokuMei" + i, rec.get("listMeisaiKomokuMei"));
            assertEquals("listKoteiKomoku" + i, rec.get("listKoteiKomoku"));
            assertEquals("listTekiyoMei" + i, rec.get("listTekiyoMei"));
            assertEquals("listTekiyoShuryobi" + i, rec.get("listTekiyoShuryobi"));
            assertEquals("listRyokinKomokuDataVersion" + i, rec.get("listRyokinKomokuDataVersion"));
            assertEquals("listKoteiKomokuFlg" + i, rec.get("listKoteiKomokuFlg"));
            i++;
        }
    } 

    private void assertForRecList_2_2(Mst291Form form) {
        int i = 0;
        assertEquals(0, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listRyokinKomokuCd" + i, rec.get("listRyokinKomokuCd"));
            assertEquals("listRyokinKomokuMeisho" + i, rec.get("listRyokinKomokuMeisho"));
            assertEquals("listTekiyoKaishibi" + i, rec.get("listTekiyoKaishibi"));
            assertEquals("listRyokinKomokuGroupCd" + i, rec.get("listRyokinKomokuGroupCd"));
            assertEquals("listRyokinKomokuGruopMeisho" + i, rec.get("listRyokinKomokuGruopMeisho"));
            assertEquals("listGroupNaiHyojijun" + i, rec.get("listGroupNaiHyojijun"));
            assertEquals("listZeiKbn" + i, rec.get("listZeiKbn"));
            assertEquals("listYusoUriageSetSaki" + i, rec.get("listYusoUriageSetSaki"));
            assertEquals("listProofYouShuyakuKomoku" + i, rec.get("listProofYouShuyakuKomoku"));
            assertEquals("listMeisaiKbn" + i, rec.get("listMeisaiKbn"));
            assertEquals("listOroshineritsuSetteiKanoFlg" + i, rec.get("listOroshineritsuSetteiKanoFlg"));
            assertEquals("listOroshineritsu" + i, rec.get("listOroshineritsu"));
            assertEquals("listOroshiKeijoKasho" + i, rec.get("listOroshiKeijoKasho"));
            assertEquals("listOroshiKeijoKashoMeisho" + i, rec.get("listOroshiKeijoKashoMeisho"));
            assertEquals("listOroshiKamokuCd" + i, rec.get("listOroshiKamokuCd"));
            assertEquals("listOroshiKamokuMeisho" + i, rec.get("listOroshiKamokuMeisho"));
            assertEquals("listShoriKamokuCd" + i, rec.get("listShoriKamokuCd"));
            assertEquals("listShoriKamokuMeisho" + i, rec.get("listShoriKamokuMeisho"));
            assertEquals("listHojoKamokuCd" + i, rec.get("listHojoKamokuCd"));
            assertEquals("listHojoKamokuMeisho" + i, rec.get("listHojoKamokuMeisho"));
            assertEquals("listMeisaiKomokuMei" + i, rec.get("listMeisaiKomokuMei"));
            assertEquals("listKoteiKomoku" + i, rec.get("listKoteiKomoku"));
            assertEquals("listTekiyoMei" + i, rec.get("listTekiyoMei"));
            assertEquals("listTekiyoShuryobi" + i, rec.get("listTekiyoShuryobi"));
            assertEquals("listRyokinKomokuDataVersion" + i, rec.get("listRyokinKomokuDataVersion"));
            assertEquals("listKoteiKomokuFlg" + i, rec.get("listKoteiKomokuFlg"));
            i++;
        }
    }      

    private void assertForRecList_2_3(Mst291Form form) {
        int i = 0;
        assertEquals(1, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listRyokinKomokuCd" + i, rec.get("listRyokinKomokuCd"));
            assertEquals("listRyokinKomokuMeisho" + i, rec.get("listRyokinKomokuMeisho"));
            assertEquals("listTekiyoKaishibi" + i, rec.get("listTekiyoKaishibi"));
            assertEquals("listRyokinKomokuGroupCd" + i, rec.get("listRyokinKomokuGroupCd"));
            assertEquals("listRyokinKomokuGruopMeisho" + i, rec.get("listRyokinKomokuGruopMeisho"));
            assertEquals("listGroupNaiHyojijun" + i, rec.get("listGroupNaiHyojijun"));
            assertEquals("listZeiKbn" + i, rec.get("listZeiKbn"));
            assertEquals("listYusoUriageSetSaki" + i, rec.get("listYusoUriageSetSaki"));
            assertEquals("listProofYouShuyakuKomoku" + i, rec.get("listProofYouShuyakuKomoku"));
            assertEquals("listMeisaiKbn" + i, rec.get("listMeisaiKbn"));
            assertEquals("listOroshineritsuSetteiKanoFlg" + i, rec.get("listOroshineritsuSetteiKanoFlg"));
            assertEquals("listOroshineritsu" + i, rec.get("listOroshineritsu"));
            assertEquals("listOroshiKeijoKasho" + i, rec.get("listOroshiKeijoKasho"));
            assertEquals("listOroshiKeijoKashoMeisho" + i, rec.get("listOroshiKeijoKashoMeisho"));
            assertEquals("listOroshiKamokuCd" + i, rec.get("listOroshiKamokuCd"));
            assertEquals("listOroshiKamokuMeisho" + i, rec.get("listOroshiKamokuMeisho"));
            assertEquals("listShoriKamokuCd" + i, rec.get("listShoriKamokuCd"));
            assertEquals("listShoriKamokuMeisho" + i, rec.get("listShoriKamokuMeisho"));
            assertEquals("listHojoKamokuCd" + i, rec.get("listHojoKamokuCd"));
            assertEquals("listHojoKamokuMeisho" + i, rec.get("listHojoKamokuMeisho"));
            assertEquals("listMeisaiKomokuMei" + i, rec.get("listMeisaiKomokuMei"));
            assertEquals("listKoteiKomoku" + i, rec.get("listKoteiKomoku"));
            assertEquals("listTekiyoMei" + i, rec.get("listTekiyoMei"));
            assertEquals("listTekiyoShuryobi" + i, rec.get("listTekiyoShuryobi"));
            assertEquals("listRyokinKomokuDataVersion" + i, rec.get("listRyokinKomokuDataVersion"));
            assertEquals("listKoteiKomokuFlg" + i, rec.get("listKoteiKomokuFlg"));
            i++;
        }
    }      
    
    private void assertForRecList_2_4(Mst291Form form) {
        int i = 0;
        assertEquals(2, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listRyokinKomokuCd" + i, rec.get("listRyokinKomokuCd"));
            assertEquals("listRyokinKomokuMeisho" + i, rec.get("listRyokinKomokuMeisho"));
            assertEquals("listTekiyoKaishibi" + i, rec.get("listTekiyoKaishibi"));
            assertEquals("listRyokinKomokuGroupCd" + i, rec.get("listRyokinKomokuGroupCd"));
            assertEquals("listRyokinKomokuGruopMeisho" + i, rec.get("listRyokinKomokuGruopMeisho"));
            assertEquals("listGroupNaiHyojijun" + i, rec.get("listGroupNaiHyojijun"));
            assertEquals("listZeiKbn" + i, rec.get("listZeiKbn"));
            assertEquals("listYusoUriageSetSaki" + i, rec.get("listYusoUriageSetSaki"));
            assertEquals("listProofYouShuyakuKomoku" + i, rec.get("listProofYouShuyakuKomoku"));
            assertEquals("listMeisaiKbn" + i, rec.get("listMeisaiKbn"));
            assertEquals("listOroshineritsuSetteiKanoFlg" + i, rec.get("listOroshineritsuSetteiKanoFlg"));
            assertEquals("listOroshineritsu" + i, rec.get("listOroshineritsu"));
            assertEquals("listOroshiKeijoKasho" + i, rec.get("listOroshiKeijoKasho"));
            assertEquals("listOroshiKeijoKashoMeisho" + i, rec.get("listOroshiKeijoKashoMeisho"));
            assertEquals("listOroshiKamokuCd" + i, rec.get("listOroshiKamokuCd"));
            assertEquals("listOroshiKamokuMeisho" + i, rec.get("listOroshiKamokuMeisho"));
            assertEquals("listShoriKamokuCd" + i, rec.get("listShoriKamokuCd"));
            assertEquals("listShoriKamokuMeisho" + i, rec.get("listShoriKamokuMeisho"));
            assertEquals("listHojoKamokuCd" + i, rec.get("listHojoKamokuCd"));
            assertEquals("listHojoKamokuMeisho" + i, rec.get("listHojoKamokuMeisho"));
            assertEquals("listMeisaiKomokuMei" + i, rec.get("listMeisaiKomokuMei"));
            assertEquals("listKoteiKomoku" + i, rec.get("listKoteiKomoku"));
            assertEquals("listTekiyoMei" + i, rec.get("listTekiyoMei"));
            assertEquals("listTekiyoShuryobi" + i, rec.get("listTekiyoShuryobi"));
            assertEquals("listRyokinKomokuDataVersion" + i, rec.get("listRyokinKomokuDataVersion"));
            assertEquals("listKoteiKomokuFlg" + i, rec.get("listKoteiKomokuFlg"));
            i++;
        }
    }  
    
    private void assertForRecList_2_5(Mst291Form form) {
        int i = 0;
        assertEquals(0, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listRyokinKomokuCd" + i, rec.get("listRyokinKomokuCd"));
            assertEquals("listRyokinKomokuMeisho" + i, rec.get("listRyokinKomokuMeisho"));
            assertEquals("listTekiyoKaishibi" + i, rec.get("listTekiyoKaishibi"));
            assertEquals("listRyokinKomokuGroupCd" + i, rec.get("listRyokinKomokuGroupCd"));
            assertEquals("listRyokinKomokuGruopMeisho" + i, rec.get("listRyokinKomokuGruopMeisho"));
            assertEquals("listGroupNaiHyojijun" + i, rec.get("listGroupNaiHyojijun"));
            assertEquals("listZeiKbn" + i, rec.get("listZeiKbn"));
            assertEquals("listYusoUriageSetSaki" + i, rec.get("listYusoUriageSetSaki"));
            assertEquals("listProofYouShuyakuKomoku" + i, rec.get("listProofYouShuyakuKomoku"));
            assertEquals("listMeisaiKbn" + i, rec.get("listMeisaiKbn"));
            assertEquals("listOroshineritsuSetteiKanoFlg" + i, rec.get("listOroshineritsuSetteiKanoFlg"));
            assertEquals("listOroshineritsu" + i, rec.get("listOroshineritsu"));
            assertEquals("listOroshiKeijoKasho" + i, rec.get("listOroshiKeijoKasho"));
            assertEquals("listOroshiKeijoKashoMeisho" + i, rec.get("listOroshiKeijoKashoMeisho"));
            assertEquals("listOroshiKamokuCd" + i, rec.get("listOroshiKamokuCd"));
            assertEquals("listOroshiKamokuMeisho" + i, rec.get("listOroshiKamokuMeisho"));
            assertEquals("listShoriKamokuCd" + i, rec.get("listShoriKamokuCd"));
            assertEquals("listShoriKamokuMeisho" + i, rec.get("listShoriKamokuMeisho"));
            assertEquals("listHojoKamokuCd" + i, rec.get("listHojoKamokuCd"));
            assertEquals("listHojoKamokuMeisho" + i, rec.get("listHojoKamokuMeisho"));
            assertEquals("listMeisaiKomokuMei" + i, rec.get("listMeisaiKomokuMei"));
            assertEquals("listKoteiKomoku" + i, rec.get("listKoteiKomoku"));
            assertEquals("listTekiyoMei" + i, rec.get("listTekiyoMei"));
            assertEquals("listTekiyoShuryobi" + i, rec.get("listTekiyoShuryobi"));
            assertEquals("listRyokinKomokuDataVersion" + i, rec.get("listRyokinKomokuDataVersion"));
            assertEquals("listKoteiKomokuFlg" + i, rec.get("listKoteiKomokuFlg"));
            i++;
        }
    }  
}
