package jp.co.kintetsuls.beans.mst;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.forms.mst.Mst363Form;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * 月額自動請求マスタ(その他売上)画面
 *
 * @author 呉俊 (MBP)
 * @version 2019/03/20 新規作成
 */
public class Mst363BeanTest {

    // テストTarget
    @InjectMocks
    private Mst363Bean target;

    // Mockitoオブジェクト
    @Mock
    private FileBean fileBean;
    @Mock
    private AutoCompleteViewBean autoCompleteViewBean;
    @Mock
    private MasterInfoBean masterInfo;
    @Mock
    private MessagePropertyBean messageProperty;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosai;
    @Mock
    private SearchHelpBean searchHelpBean;
    @Mock
    private AuthorityConfBean authConfBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private MessagePropertyBean messagePropertyBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosaiBean;
    @Mock
    private ListCheckBean listCheckBean;
    
    public Mst363BeanTest() {
    }

    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() {
    }

    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[not null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst363Form mst363Form = new Mst363Form();
        
        //前画面情報[not null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst363Form);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst363Form form = new Mst363Form();
        target.setMst363Form(form);
        // 戻ってきた場合、再検索を実施する。
        target.init("","MST363_SCREEN",true);

        //実施結果Outを取得
        form = target.getMst363Form();
        String url = target.getUrl();
        AuthorityConfBean authorityConfBean  = target.getAuthConfBean();
        Map<String, Object> rirekiSearchKey = target.getRirekiSearchKey();
        List<MessageModuleBean> msgList = target.getMsgList();
        target.setUrl(url);
        target.setBreadBean(breadBean);
        target.setAutoCompleteViewBean(autoCompleteViewBean);
        target.setAuthConfBean(authorityConfBean);
        target.setFileBean(fileBean);
        target.setMessageProperty(messagePropertyBean);
        target.setPageCommonBean(pageCommonBean);
        target.setSearchHelpBean(searchHelpBean);
        target.setRirekiSyosaiBean(rirekiSyosaiBean);
        target.setListCheckBean(listCheckBean);
        target.setRirekiSearchKey(rirekiSearchKey);
        target.setMsgList(msgList);
        
        // 実行時に渡すパラメータの検証
        assertEquals("mst363Form",keyCaptor_1.getValue());
        //想定通りに再検索を実施する。
        assertEquals("search_mst363",keyCaptor_2.getValue());
    }

    // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[営業所コード = 111,顧客 = 000002,料金項目 = 02,適用名 = ppp,世代検索条件 = {"01"},適用日指定 = null,申請状況 = {"01","02","03","04","05"},削除済のみ検索 = null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2() throws IllegalAccessException, InvocationTargetException,
            InstantiationException {

        //前回検索パラメータ[営業所コード = 111,顧客 = 000002,料金項目 = 02,適用名 = ppp,世代検索条件 = {"01"},適用日指定 = null,申請状況 = {"01","02","03","04","05"},削除済のみ検索 = null]
        // Mockitoオブジェクトの予想return値設定
        Mst363Form mst363Form = new Mst363Form();
        //営業所コード
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("111");
        mst363Form.setConEigyoshoCd(conEigyoshoCd);
        //顧客コード
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("000002");
        mst363Form.setConKokyakuCd(conKokyakuCd);
        //料金項目
        AutoCompOptionBean conRyokinKomoku1 = new AutoCompOptionBean();
        conRyokinKomoku1.setValue("02");
        mst363Form.setConRyokinKomoku(conRyokinKomoku1);
        //適用名
        mst363Form.setConTekiyoMei("ppp");
        //世代検索条件
        mst363Form.setConSedaiKensakuJoken(new String[]{"01"});
        //適用日
        mst363Form.setConTekiyoBi(null);
        //削除済のみ
        mst363Form.setConSakujonomiKensaku(null);
        //申請状況
        mst363Form.setConShinseiJokyo(new String[]{"01","02","03","04","05"});
        
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        //前画面パラメータ[営業所コード = 111,顧客 = 000002,料金項目 = 02,適用名 = ppp,世代検索条件 = {"01"},適用日指定 = null,申請状況 = {"01","02","03","04","05"},削除済のみ検索 = null]
        flash.put("mst363Form", mst363Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);        

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst363Form form = new Mst363Form();
        target.setMst363Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst363Form();

        //想定通りに再検索を実施する。
        assertEquals("search_mst363",keyCaptor_2.getValue());
        assertEquals("111",form.getConEigyoshoCd().getValue());
        assertEquals("000002",form.getConKokyakuCd().getValue());
        assertEquals("02",form.getConRyokinKomoku().getValue());
        assertEquals("ppp",form.getConTekiyoMei());
        assertEquals("01",form.getConSedaiKensakuJoken()[0]);
        assertEquals(null,form.getConTekiyoBi());
        assertEquals(null,form.getConSakujonomiKensaku());
        assertEquals("01",form.getConShinseiJokyo()[0]);
        assertEquals("02",form.getConShinseiJokyo()[1]);
        assertEquals("03",form.getConShinseiJokyo()[2]);
        assertEquals("04",form.getConShinseiJokyo()[3]);
        assertEquals("05",form.getConShinseiJokyo()[4]);
    }
    
    // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[営業所コード = 111,顧客 = 000002,料金項目 = 02,適用名 = ppp,世代検索条件 = {"01"},適用日指定 = null,申請状況 = {"01"},削除済のみ検索 = null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3() throws IllegalAccessException, InvocationTargetException,
            InstantiationException {

        //前回検索パラメータ[営業所コード = 111,顧客 = 000002,料金項目 = 02,適用名 = ppp,世代検索条件 = {"01"},適用日指定 = null,申請状況 = {"01","02","03","04","05"},削除済のみ検索 = null]
        // Mockitoオブジェクトの予想return値設定
        Mst363Form mst363Form = new Mst363Form();
        //営業所コード
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("111");
        mst363Form.setConEigyoshoCd(conEigyoshoCd);
        //顧客コード
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("000002");
        mst363Form.setConKokyakuCd(conKokyakuCd);
        //料金項目
        AutoCompOptionBean conRyokinKomoku1 = new AutoCompOptionBean();
        conRyokinKomoku1.setValue("02");
        mst363Form.setConRyokinKomoku(conRyokinKomoku1);
        //適用名
        mst363Form.setConTekiyoMei("ppp");
        //世代検索条件
        mst363Form.setConSedaiKensakuJoken(new String[]{"01"});
        //適用日
        mst363Form.setConTekiyoBi(null);
        //削除済のみ
        mst363Form.setConSakujonomiKensaku(null);
        //申請状況
        mst363Form.setConShinseiJokyo(new String[]{"01"});
        
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        //前画面パラメータ[営業所コード = 111,顧客 = 000002,料金項目 = 02,適用名 = ppp,世代検索条件 = {"01"},適用日指定 = null,申請状況 = {"01"},削除済のみ検索 = null]
        flash.put("mst363Form", null);
        when(pageCommonBean.getPageParam()).thenReturn(flash);        

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst363Form form = new Mst363Form();
        target.setMst363Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst363Form();

         //想定通りに再検索を実施する。
        assertEquals(null,form.getConSakujonomiKensaku());
    }
    
    // init_正常_初期処理_1_4
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        //前画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(null);

        //テスト実行
        Mst363Form form = new Mst363Form();
        target.setMst363Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst363Form",keyCaptor_1.getValue());
        //想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null,form.getSearchResult());
    }
    
    // init_正常_初期処理_1_5
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_5 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        //前画面情報[null]
        doThrow(IllegalAccessException.class).when(pageCommonBean).getPageInfo(keyCaptor_1.capture());

        //テスト実行
        Mst363Form form = new Mst363Form();
        target.setMst363Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst363Form",keyCaptor_1.getValue());
        //想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null,form.getSearchResult());
    }

    // search_正常_検索処理_2-1
    //
    // -------------------テスト条件--------------------------
    // 月額自動請求マスタ(その他売上)検索結果一覧取得
    // 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //月額自動請求マスタ(その他売上)検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=0;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst363Form form = new Mst363Form();
        //営業所コード
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("111");
        form.setConEigyoshoCd(conEigyoshoCd);
        //顧客コード
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("000002");
        form.setConKokyakuCd(conKokyakuCd);
        //料金項目
        AutoCompOptionBean conRyokinKomoku1 = new AutoCompOptionBean();
        conRyokinKomoku1.setValue("02");
        form.setConRyokinKomoku(conRyokinKomoku1);
        //適用名
        form.setConTekiyoMei("ppp");
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        //適用日
        form.setConTekiyoBi(null);
        //削除済のみ
        form.setConSakujonomiKensaku(null);
        //申請状況
        form.setConShinseiJokyo(new String[]{"01","02","03","04","05"});
        
        target.setMst363Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        assertEquals("111", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("000002", paramsCaptor_1.getValue().get("conKokyakuCd"));
        String[] conSedaiKensakuJoken =  (String[]) paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals("1", conSedaiKensakuJoken[0]);
        assertEquals("1", conSedaiKensakuJoken[1]);
        assertEquals("02", paramsCaptor_1.getValue().get("conRyokinKomoku"));
        assertEquals("ppp", paramsCaptor_1.getValue().get("conTekiyoMei"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSakujoNomiKensaku"));
        String[] conShinseiJokyo =  (String[]) paramsCaptor_1.getValue().get("conShinseiJokyo");
        assertEquals("01", conShinseiJokyo[0]);
        assertEquals("02", conShinseiJokyo[1]);
        assertEquals("03", conShinseiJokyo[2]);
        assertEquals("04", conShinseiJokyo[3]);
        assertEquals("05", conShinseiJokyo[4]);
        assertEquals("mst363_search",functionCodeCaptor_2.getValue());
        //想定通りに月額自動請求マスタ(その他売上)名マスタ一覧を表示されること
        assertForRecList_2_1(form);
    }    
    
    // search_正常_検索処理_2-2
    //
    // -------------------テスト条件--------------------------
    // 月額自動請求マスタ(その他売上)検索結果一覧取得
    // 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //月額自動請求マスタ(その他売上)検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=1;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst363Form form = new Mst363Form();
        //営業所コード
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("111");
        form.setConEigyoshoCd(conEigyoshoCd);
        //顧客コード
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("000002");
        form.setConKokyakuCd(conKokyakuCd);
        //料金項目
        AutoCompOptionBean conRyokinKomoku1 = new AutoCompOptionBean();
        conRyokinKomoku1.setValue("02");
        form.setConRyokinKomoku(conRyokinKomoku1);
        //適用名
        form.setConTekiyoMei("ppp");
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        //適用日
        form.setConTekiyoBi(null);
        //削除済のみ
        form.setConSakujonomiKensaku(null);
        //申請状況
        form.setConShinseiJokyo(new String[]{"01","02","03","04","05"});
        
        target.setMst363Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        assertEquals("111", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("000002", paramsCaptor_1.getValue().get("conKokyakuCd"));
        String[] conSedaiKensakuJoken =  (String[]) paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals("1", conSedaiKensakuJoken[0]);
        assertEquals("1", conSedaiKensakuJoken[1]);
        assertEquals("02", paramsCaptor_1.getValue().get("conRyokinKomoku"));
        assertEquals("ppp", paramsCaptor_1.getValue().get("conTekiyoMei"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSakujoNomiKensaku"));
        String[] conShinseiJokyo =  (String[]) paramsCaptor_1.getValue().get("conShinseiJokyo");
        assertEquals("01", conShinseiJokyo[0]);
        assertEquals("02", conShinseiJokyo[1]);
        assertEquals("03", conShinseiJokyo[2]);
        assertEquals("04", conShinseiJokyo[3]);
        assertEquals("05", conShinseiJokyo[4]);
        assertEquals("mst363_search",functionCodeCaptor_2.getValue());
        //想定通りに月額自動請求マスタ(その他売上)名マスタ一覧を表示されること
        assertForRecList_2_2(form);
    }

    // search_異常_検索処理_2-3
    //
    // -------------------テスト条件--------------------------
    // 月額自動請求マスタ(その他売上)検索結果一覧取得 取得件数 = 0
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //月額自動請求マスタ(その他売上)検索結果一覧取得 取得件数 = 0
        List<Map<String, String>> result = new ArrayList<>();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst363Form form = new Mst363Form();
        //営業所コード
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("111");
        form.setConEigyoshoCd(conEigyoshoCd);
        //顧客コード
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("000002");
        form.setConKokyakuCd(conKokyakuCd);
        //料金項目
        AutoCompOptionBean conRyokinKomoku1 = new AutoCompOptionBean();
        conRyokinKomoku1.setValue("02");
        form.setConRyokinKomoku(conRyokinKomoku1);
        //適用名
        form.setConTekiyoMei("ppp");
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        //適用日
        form.setConTekiyoBi(null);
        //削除済のみ
        form.setConSakujonomiKensaku(null);
        //申請状況
        form.setConShinseiJokyo(new String[]{"01","02","03","04","05"});
        
        target.setMst363Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        assertEquals("111", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("000002", paramsCaptor_1.getValue().get("conKokyakuCd"));
        String[] conSedaiKensakuJoken =  (String[]) paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals("1", conSedaiKensakuJoken[0]);
        assertEquals("1", conSedaiKensakuJoken[1]);
        assertEquals("02", paramsCaptor_1.getValue().get("conRyokinKomoku"));
        assertEquals("ppp", paramsCaptor_1.getValue().get("conTekiyoMei"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSakujoNomiKensaku"));
        String[] conShinseiJokyo =  (String[]) paramsCaptor_1.getValue().get("conShinseiJokyo");
        assertEquals("01", conShinseiJokyo[0]);
        assertEquals("02", conShinseiJokyo[1]);
        assertEquals("03", conShinseiJokyo[2]);
        assertEquals("04", conShinseiJokyo[3]);
        assertEquals("05", conShinseiJokyo[4]);
        assertEquals("mst363_search",functionCodeCaptor_2.getValue());
        //想定通りに月額自動請求マスタ(その他売上)名マスタ一覧を表示されること
        assertForRecList_2_3(form);
    }

    // getRecordCount_正常_件数取得処理_2-4
    //
    // -------------------テスト条件--------------------------
    // 月額自動請求マスタ(その他売上)検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //月額自動請求マスタ(その他売上)検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst363Form form = new Mst363Form();
        //営業所コード
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("111");
        form.setConEigyoshoCd(conEigyoshoCd);
        //顧客コード
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("000002");
        form.setConKokyakuCd(conKokyakuCd);
        //料金項目
        AutoCompOptionBean conRyokinKomoku1 = new AutoCompOptionBean();
        conRyokinKomoku1.setValue("02");
        form.setConRyokinKomoku(conRyokinKomoku1);
        //適用名
        form.setConTekiyoMei("ppp");
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        //適用日
        form.setConTekiyoBi(null);
        //削除済のみ
        form.setConSakujonomiKensaku(null);
        //申請状況
        form.setConShinseiJokyo(new String[]{"01","02","03","04","05"});
        target.setMst363Form(form);
        target.getRecordCount(false);

        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        assertEquals("111", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("000002", paramsCaptor_1.getValue().get("conKokyakuCd"));
        String[] conSedaiKensakuJoken =  (String[]) paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals("1", conSedaiKensakuJoken[0]);
        assertEquals("1", conSedaiKensakuJoken[1]);
        assertEquals("02", paramsCaptor_1.getValue().get("conRyokinKomoku"));
        assertEquals("ppp", paramsCaptor_1.getValue().get("conTekiyoMei"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSakujoNomiKensaku"));
        String[] conShinseiJokyo =  (String[]) paramsCaptor_1.getValue().get("conShinseiJokyo");
        assertEquals("01", conShinseiJokyo[0]);
        assertEquals("02", conShinseiJokyo[1]);
        assertEquals("03", conShinseiJokyo[2]);
        assertEquals("04", conShinseiJokyo[3]);
        assertEquals("05", conShinseiJokyo[4]);
        assertEquals("mst363_search_kensu",functionCodeCaptor_2.getValue());
    }

    // clear_正常_クリア処理_3-1
    //
    // -------------------テスト条件--------------------------
    // 検索条件と検索結果がある
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_1 () throws IllegalAccessException, InvocationTargetException, SystemException {
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //月額自動請求マスタ(その他売上)検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=1;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        //テスト実行
        Mst363Form form = new Mst363Form();
        //営業所コード
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("111");
        form.setConEigyoshoCd(conEigyoshoCd);
        //顧客コード
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("000002");
        form.setConKokyakuCd(conKokyakuCd);
        //料金項目
        AutoCompOptionBean conRyokinKomoku1 = new AutoCompOptionBean();
        conRyokinKomoku1.setValue("02");
        form.setConRyokinKomoku(conRyokinKomoku1);
        //適用名
        form.setConTekiyoMei("ppp");
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01","02","03","04","05"});
        //適用日
        form.setConTekiyoBi("2019/01/02");
        //削除済のみ
        form.setConSakujonomiKensaku(new String[]{"01"});
        //申請状況
        form.setConShinseiJokyo(new String[]{"01","02","03","04","05"});

        target.setMst363Form(form);
        target.clear();

        //実施結果Outを取得
        form = target.getMst363Form();

        //想定通りに正常にClearを実施されること
        assertEquals(null,form.getConEigyoshoCd());
        assertEquals(null,form.getConKokyakuCd());
        assertEquals(null,form.getConRyokinKomoku());
        assertEquals(null,form.getConTekiyoMei());
        assertEquals("01",form.getConSedaiKensakuJoken()[0]);
        assertEquals(null,form.getConTekiyoBi());
        assertEquals(null,form.getConSakujonomiKensaku());
        assertEquals("01",form.getConShinseiJokyo()[0]);
        assertEquals("02",form.getConShinseiJokyo()[1]);
        assertEquals("03",form.getConShinseiJokyo()[2]);
        assertEquals("04",form.getConShinseiJokyo()[3]);
        assertEquals("05",form.getConShinseiJokyo()[4]);
        //検索結果がない
        assertEquals(null,form.getSearchResult());
        assertEquals(null,form.getSearchResultSelectable());
        assertEquals(null,form.getSelectedSearchResult());
    }

    // clear_正常_クリア処理_3-2
    //
    // -------------------テスト条件--------------------------
    // 検索条件がある、検索結果がない
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_2 () throws IllegalAccessException, InvocationTargetException, SystemException {

       //テスト実行
        Mst363Form form = new Mst363Form();
        //営業所コード
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("111");
        form.setConEigyoshoCd(conEigyoshoCd);
        //顧客コード
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("000002");
        form.setConKokyakuCd(conKokyakuCd);
        //料金項目
        AutoCompOptionBean conRyokinKomoku1 = new AutoCompOptionBean();
        conRyokinKomoku1.setValue("02");
        form.setConRyokinKomoku(conRyokinKomoku1);
        //適用名
        form.setConTekiyoMei("ppp");
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01","02","03","04","05"});
        //適用日
        form.setConTekiyoBi("2019/01/02");
        //削除済のみ
        form.setConSakujonomiKensaku(new String[]{"01"});
        //申請状況
        form.setConShinseiJokyo(new String[]{"01","02","03","04","05"});

        target.setMst363Form(form);
        target.clear();

        //実施結果Outを取得
        form = target.getMst363Form();

        //想定通りに正常にClearを実施されること
        assertEquals(null,form.getConEigyoshoCd());
        assertEquals(null,form.getConKokyakuCd());
        assertEquals(null,form.getConRyokinKomoku());
        assertEquals(null,form.getConTekiyoMei());
        assertEquals("01",form.getConSedaiKensakuJoken()[0]);
        assertEquals(null,form.getConTekiyoBi());
        assertEquals(null,form.getConSakujonomiKensaku());
        assertEquals("01",form.getConShinseiJokyo()[0]);
        assertEquals("02",form.getConShinseiJokyo()[1]);
        assertEquals("03",form.getConShinseiJokyo()[2]);
        assertEquals("04",form.getConShinseiJokyo()[3]);
        assertEquals("05",form.getConShinseiJokyo()[4]);
    }

    // getHeader_正常_ダウンロード_4-1
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void getHeader_正常_ダウンロード_4_1 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // Mockitoオブジェクトの予想return値設定
        Mst363Form form = new Mst363Form();
        //営業所コード
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("111");
        form.setConEigyoshoCd(conEigyoshoCd);
        //顧客コード
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("000002");
        form.setConKokyakuCd(conKokyakuCd);
        //料金項目
        AutoCompOptionBean conRyokinKomoku1 = new AutoCompOptionBean();
        conRyokinKomoku1.setValue("02");
        form.setConRyokinKomoku(conRyokinKomoku1);
        //適用名
        form.setConTekiyoMei("ppp");
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01"});
        //適用日
        form.setConTekiyoBi("2019/01/02");
        //削除済のみ
        form.setConSakujonomiKensaku(null);
        //申請状況
        form.setConShinseiJokyo(new String[]{"01","02","03","04","05"});

        target.setMst363Form(form);
        List<CSVDto> dto = target.getHeader();

        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        assertEquals("111",form.getConEigyoshoCd().getValue());
        assertEquals("000002",form.getConKokyakuCd().getValue());
        assertEquals("02",form.getConRyokinKomoku().getValue());
        assertEquals("ppp",form.getConTekiyoMei());
        assertEquals("01",form.getConSedaiKensakuJoken()[0]);
        assertEquals("2019/01/02",form.getConTekiyoBi());
        assertEquals(null,form.getConSakujonomiKensaku());
        assertEquals("01",form.getConShinseiJokyo()[0]);
        assertEquals("02",form.getConShinseiJokyo()[1]);
        assertEquals("03",form.getConShinseiJokyo()[2]);
        assertEquals("04",form.getConShinseiJokyo()[3]);
        assertEquals("05",form.getConShinseiJokyo()[4]);
        //想定通りに正常にCVSのHeaderを設定されること
        assertEquals("顧客コード",dto.get(0).getTitle());
        assertEquals("listKokyakuCd",dto.get(0).getName());
        assertEquals("顧客名",dto.get(1).getTitle());
        assertEquals("listKokyakuMei",dto.get(1).getName());
        assertEquals("売上日FROM",dto.get(2).getTitle());
        assertEquals("listUriagebiFrom",dto.get(2).getName());
        assertEquals("売上日TO",dto.get(3).getTitle());
        assertEquals("listUriagebiTo",dto.get(3).getName());
        assertEquals("休日計上",dto.get(4).getTitle());
        assertEquals("listKyujitsuKeijo",dto.get(4).getName());
        assertEquals("お題目",dto.get(5).getTitle());
        assertEquals("listOdaimoku",dto.get(5).getName());
        assertEquals("伝票種別",dto.get(6).getTitle());
        assertEquals("listDempyoShubetsu",dto.get(6).getName());
        assertEquals("伝票種別名",dto.get(7).getTitle());
        assertEquals("listDempyoShubetsuMei",dto.get(7).getName());
        assertEquals("料金項目コード",dto.get(8).getTitle());
        assertEquals("listRyokinKomoku",dto.get(8).getName());
        assertEquals("料金項目名",dto.get(9).getTitle());
        assertEquals("listRyokinKomokuMei",dto.get(9).getName());
        assertEquals("明細区分",dto.get(10).getTitle());
        assertEquals("hListMeisaiKbn",dto.get(10).getName());
        assertEquals("表示名",dto.get(11).getTitle());
        assertEquals("listHyojiMei",dto.get(11).getName());
        assertEquals("適用開始日",dto.get(12).getTitle());
        assertEquals("listTekiyoKaishibi",dto.get(12).getName());
        assertEquals("単価",dto.get(13).getTitle());
        assertEquals("listTanka",dto.get(13).getName());
        assertEquals("単位",dto.get(14).getTitle());
        assertEquals("listTani",dto.get(14).getName());
        assertEquals("数量",dto.get(15).getTitle());
        assertEquals("listSuryo",dto.get(15).getName());
        assertEquals("金額",dto.get(16).getTitle());
        assertEquals("listKingaku",dto.get(16).getName());
        assertEquals("請求書備考1",dto.get(17).getTitle());
        assertEquals("listSeikyushoBiko1",dto.get(17).getName());
        assertEquals("適用名",dto.get(18).getTitle());
        assertEquals("listTekiyoMei",dto.get(18).getName());
        assertEquals("適用終了日",dto.get(19).getTitle());
        assertEquals("listTekiyoShuryobi",dto.get(19).getName());
        assertEquals("申請ステータス",dto.get(20).getTitle());
        assertEquals("hListShinseiStatus",dto.get(20).getName());
        assertEquals("申請状況",dto.get(21).getTitle());
        assertEquals("listShinseiJokyo",dto.get(21).getName());
        assertEquals("データバージョン",dto.get(22).getTitle());
        assertEquals("listDataVersion",dto.get(22).getName());
        assertEquals("適用フラグ",dto.get(23).getTitle());
        assertEquals("listTekiyoFlg",dto.get(23).getName());
    }  
    
    // beforeDown_正常_ダウンロード_4-2
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=2件
    // -----------------------------------------------------
    @Test
    public void beforeDown_正常_ダウンロード_4_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst363Form form = new Mst363Form();
        target.setMst363Form(form);
        try {
            target.beforeDown("testComment");
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(Mst363BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にダウンロード理由を記録すること
        assertEquals(null,form.getConKokyakuCd());
    }  
    
    // rirekiIchiran_正常_更新履歴コンテキストメニュー_14-1
    //
    // -------------------テスト条件--------------------------
    // 正常に取得された場合
    // -----------------------------------------------------
    @Test
    public void rirekiIchiran_正常_更新履歴コンテキストメニュー_14_1 () throws IllegalAccessException, 
            InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> titleFlgCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> searchKeyCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(rirekiSyosaiBean).searchList(titleFlgCaptor_1.capture(),functionCodeCaptor_2.capture()
                ,searchKeyCaptor_3.capture());
        //テスト実行
        Mst363Form form = new Mst363Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_14_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst363Form(form);
        target.rirekiIchiran();

        //実施結果Outを取得
        form = target.getMst363Form();

        //想定通りに履歴を表示する。
        assertEquals("2",titleFlgCaptor_1.getValue());
        assertEquals("MST363_SEARCH_VW_JIDOSEIKYU_KOMOKU_SONOTA_URIAGE_RIREKI",functionCodeCaptor_2.getValue());
        assertEquals("listKokyakuCd0",searchKeyCaptor_3.getValue().get("listKokyakuCd"));
        assertEquals("listRyokinKomoku0",searchKeyCaptor_3.getValue().get("listRyokinKomoku"));
        assertEquals("listUriagebiTo0",searchKeyCaptor_3.getValue().get("listUriagebiTo"));
        assertEquals("0",searchKeyCaptor_3.getValue().get("listKyujitsuKeijo"));
        assertEquals("2019-01-05 00:00:00.0", searchKeyCaptor_3.getValue().get("listTekiyoKaishibi"));
        assertEquals("listUriagebiFrom0", searchKeyCaptor_3.getValue().get("listUriagebiFrom"));
    }   
    
    // update_異常_登録申請ボタン_登録申請_15_1
    //
    // -------------------テスト条件--------------------------
    // 新規行 かつ 入力された顧客コード/売上日FROM/料金項目コード/適用開始日と同一データが自動請求項目マスタ(その他売上)に存在しない。
    // -----------------------------------------------------
    @Test
    public void update_異常_登録申請ボタン_登録申請_15_1 () throws IllegalAccessException, InvocationTargetException {
        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 新規行 かつ 入力された顧客コード/売上日FROM/料金項目コード/適用開始日と同一データが自動請求項目マスタ(その他売上)に存在しない。
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0053",
                "listKokyakuCdlistUriagebiFromlistRyokinKomokulistTekiyoKaishibi");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst363Form form = new Mst363Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_15_2(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst363Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("15",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("25",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("Wed Jan 02 15:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_sonzai_check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0053）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0053",summaryCaptor_4.getValue());
    }
    
    // update_正常_登録申請ボタン_登録申請_15_2
    //
    // -------------------テスト条件--------------------------
    // 新規行 かつ 入力された顧客コード/売上日FROM/料金項目コード/適用開始日と同一データが自動請求項目マスタ(その他売上)に存在する。
    // -----------------------------------------------------
    @Test
    public void update_正常_登録申請ボタン_登録申請_15_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 新規行 かつ 入力された顧客コード/売上日FROM/料金項目コード/適用開始日と同一データが自動請求項目マスタ(その他売上)に存在する。
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //月額自動請求マスタ(その他売上)検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_2(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        //テスト実行
        Mst363Form form = new Mst363Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_15_2(i));
        }
        form.setSelectedSearchResult(result);
        //営業所コード
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("111");
        form.setConEigyoshoCd(conEigyoshoCd);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        //申請状況
        form.setConShinseiJokyo(new String[]{"01","02","03","04","05"});
        target.setMst363Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("15",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("25",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("Wed Jan 02 15:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_update",functionCodeCaptor_2.getValue());
    }  
    
    // update_異常_登録申請ボタン_登録申請_15_3
    //
    // -------------------テスト条件--------------------------
    // 取得行 かつ 顧客コード/売上日FROM/料金項目コード/適用開始日が変更されており、
    // 顧客コード/売上日FROM/料金項目コード/適用開始日と同一データが自動請求項目マスタ(その他売上)に存在しない。[COME0053]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_登録申請ボタン_登録申請_15_3 () throws IllegalAccessException, InvocationTargetException {
        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 顧客コード/売上日FROM/料金項目コード/適用開始日と同一データが自動請求項目マスタ(その他売上)に存在しない。[COME0053]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0053",
                "listKokyakuCdlistUriagebiFromlistRyokinKomokulistTekiyoKaishibi");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst363Form form = new Mst363Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_15_2(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst363Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("15",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("25",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("Wed Jan 02 15:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_sonzai_check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0053）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0053",summaryCaptor_4.getValue());
    }
    
    // update_正常_登録申請ボタン_登録申請_15_4
    //
    // -------------------テスト条件--------------------------
    // 取得行 かつ 顧客コード/売上日FROM/料金項目コード/適用開始日が変更されており、
    // 顧客コード/売上日FROM/料金項目コード/適用開始日と同一データが自動請求項目マスタ(その他売上)に存在する。
    // -----------------------------------------------------
    @Test
    public void update_正常_登録申請ボタン_登録申請_15_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 顧客コード/売上日FROM/料金項目コード/適用開始日と同一データが自動請求項目マスタ(その他売上)に存在する。
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //月額自動請求マスタ(その他売上)検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_2(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        //テスト実行
        Mst363Form form = new Mst363Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_15_2(i));
        }        
        form.setSelectedSearchResult(result);
        //営業所コード
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("111");
        form.setConEigyoshoCd(conEigyoshoCd);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        //申請状況
        form.setConShinseiJokyo(new String[]{"01","02","03","04","05"});
        target.setMst363Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("15",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("25",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("Wed Jan 02 15:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_update",functionCodeCaptor_2.getValue());
    } 
    
    // update_異常_登録申請ボタン_登録申請_15_5
    //
    // -------------------テスト条件--------------------------
    // 入力された顧客コードが顧客マスタに存在しない。[COME0051]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_登録申請ボタン_登録申請_15_5 () throws IllegalAccessException, InvocationTargetException {
        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力された顧客コードが顧客マスタに存在しない。[COME0051]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0051", "listKokyakuCd");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst363Form form = new Mst363Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_15_2(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst363Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("15",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("25",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("Wed Jan 02 15:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_sonzai_check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0051）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0051",summaryCaptor_4.getValue());
    }
    
    // update_正常_登録申請ボタン_登録申請_15_6
    //
    // -------------------テスト条件--------------------------
    // 入力された顧客コードが顧客マスタに存在する。
    // -----------------------------------------------------
    @Test
    public void update_正常_登録申請ボタン_登録申請_15_6 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力された料金項目コードが付帯料金項目マスタに存在
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //月額自動請求マスタ(その他売上)検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_2(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        //テスト実行
        Mst363Form form = new Mst363Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_15_2(i));
        }        
        form.setSelectedSearchResult(result);
        //営業所コード
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("111");
        form.setConEigyoshoCd(conEigyoshoCd);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        //申請状況
        form.setConShinseiJokyo(new String[]{"01","02","03","04","05"});
        target.setMst363Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("15",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("25",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("Wed Jan 02 15:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_update",functionCodeCaptor_2.getValue());
    } 
    
    // update_異常_登録申請ボタン_登録申請_15_7
    //
    // -------------------テスト条件--------------------------
    // 入力された伝票種別コードが伝票種別マスタに存在しない。[COME0051]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_登録申請ボタン_登録申請_15_7 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力された伝票種別コードが伝票種別マスタに存在しない。[COME0051]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0051", "listDempyoShubetsuMei");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst363Form form = new Mst363Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_15_2(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst363Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("15",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("25",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("Wed Jan 02 15:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_sonzai_check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：MSTE0051）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0051",summaryCaptor_4.getValue());
    }
    
    // update_正常_登録申請ボタン_登録申請_15_8
    //
    // -------------------テスト条件--------------------------
    // 入力された伝票種別コードが伝票種別マスタに存在する。
    // -----------------------------------------------------
    @Test
    public void update_正常_登録申請ボタン_登録申請_15_8 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力された伝票種別コードが伝票種別マスタに存在する。
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //月額自動請求マスタ(その他売上)検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_2(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        //テスト実行
        Mst363Form form = new Mst363Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_15_2(i));
        }        
        form.setSelectedSearchResult(result);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        //申請状況
        form.setConShinseiJokyo(new String[]{"01","02","03","04","05"});
        target.setMst363Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("15",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("25",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("Wed Jan 02 15:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_update",functionCodeCaptor_2.getValue());
    } 
    
    // update_異常_登録申請ボタン_登録申請_15_9
    //
    // -------------------テスト条件--------------------------
    // 入力された料金項目コードが付帯料金項目マスタに存在しない。[COME0051]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_登録申請ボタン_登録申請_15_9 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力された料金項目コードが付帯料金項目マスタに存在しない。[COME0051]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0051", "listRyokinKomoku");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst363Form form = new Mst363Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_15_2(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst363Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("15",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("25",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("Wed Jan 02 15:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_sonzai_check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：MSTE0051）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0051",summaryCaptor_4.getValue());
    }
    
    // update_正常_登録申請ボタン_登録申請_15_10
    //
    // -------------------テスト条件--------------------------
    // 入力された料金項目コードが付帯料金項目マスタに存在する。
    // -----------------------------------------------------
    @Test
    public void update_正常_登録申請ボタン_登録申請_15_10 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力された料金項目コードが付帯料金項目マスタに存在する。
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //月額自動請求マスタ(その他売上)検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_2(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        //テスト実行
        Mst363Form form = new Mst363Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_15_2(i));
        }        
        form.setSelectedSearchResult(result);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        //申請状況
        form.setConShinseiJokyo(new String[]{"01","02","03","04","05"});
        target.setMst363Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("15",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("25",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("Wed Jan 02 15:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_update",functionCodeCaptor_2.getValue());
    }  
    
    // update_異常_登録申請ボタン_登録申請_15_11
    //
    // -------------------テスト条件--------------------------
    // 単位・単価が付帯料金表と不一致。[COME0051]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_登録申請ボタン_登録申請_15_11 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 単位・単価が付帯料金表と不一致。[COME0051]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0051", "listTanilistTanka");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst363Form form = new Mst363Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_15_2(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst363Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("15",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("25",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("Wed Jan 02 15:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_sonzai_check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：MSTE0051）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0051",summaryCaptor_4.getValue());
    }
    
    // update_正常_登録申請ボタン_登録申請_15_12
    //
    // -------------------テスト条件--------------------------
    // 単位・単価が付帯料金表と一致。
    // -----------------------------------------------------
    @Test
    public void update_正常_登録申請ボタン_登録申請_15_12 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 単位・単価が付帯料金表と一致。
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //月額自動請求マスタ(その他売上)検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_2(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        //テスト実行
        Mst363Form form = new Mst363Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_15_2(i));
        }        
        form.setSelectedSearchResult(result);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        //申請状況
        form.setConShinseiJokyo(new String[]{"01","02","03","04","05"});
        target.setMst363Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("15",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("25",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("Wed Jan 02 15:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_update",functionCodeCaptor_2.getValue());
    } 
    
    // update_異常_登録申請ボタン_更新申請_15_13
    //
    // -------------------テスト条件--------------------------
    // 新規行 かつ 入力された顧客コード/売上日FROM/料金項目コード/適用開始日と同一データが自動請求項目マスタ(その他売上)に存在しない。
    // -----------------------------------------------------
    @Test
    public void update_異常_登録申請ボタン_更新申請_15_13 () throws IllegalAccessException, InvocationTargetException {
        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 新規行 かつ 入力された顧客コード/売上日FROM/料金項目コード/適用開始日と同一データが自動請求項目マスタ(その他売上)に存在しない。
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0053",
                "listKokyakuCdlistUriagebiFromlistRyokinKomokulistTekiyoKaishibi");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst363Form form = new Mst363Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_15_2(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst363Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("15",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("25",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("Wed Jan 02 15:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_sonzai_check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0053）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0053",summaryCaptor_4.getValue());
    }
    
    // update_正常_登録申請ボタン_更新申請_15_14
    //
    // -------------------テスト条件--------------------------
    // 新規行 かつ 入力された顧客コード/売上日FROM/料金項目コード/適用開始日と同一データが自動請求項目マスタ(その他売上)に存在する。
    // -----------------------------------------------------
    @Test
    public void update_正常_登録申請ボタン_更新申請_15_14 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 新規行 かつ 入力された顧客コード/売上日FROM/料金項目コード/適用開始日と同一データが自動請求項目マスタ(その他売上)に存在する。
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //月額自動請求マスタ(その他売上)検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_2(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        //テスト実行
        Mst363Form form = new Mst363Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_15_2(i));
        }
        form.setSelectedSearchResult(result);
        //営業所コード
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("111");
        form.setConEigyoshoCd(conEigyoshoCd);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        //申請状況
        form.setConShinseiJokyo(new String[]{"01","02","03","04","05"});
        target.setMst363Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("15",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("25",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("Wed Jan 02 15:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_update",functionCodeCaptor_2.getValue());
    }  
    
    // update_異常_登録申請ボタン_更新申請_15_15
    //
    // -------------------テスト条件--------------------------
    // 取得行 かつ 顧客コード/売上日FROM/料金項目コード/適用開始日が変更されており、
    // 顧客コード/売上日FROM/料金項目コード/適用開始日と同一データが自動請求項目マスタ(その他売上)に存在しない。[COME0053]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_登録申請ボタン_更新申請_15_15 () throws IllegalAccessException, InvocationTargetException {
        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 顧客コード/売上日FROM/料金項目コード/適用開始日と同一データが自動請求項目マスタ(その他売上)に存在しない。[COME0053]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0053",
                "listKokyakuCdlistUriagebiFromlistRyokinKomokulistTekiyoKaishibi");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst363Form form = new Mst363Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_15_2(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst363Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("15",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("25",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("Wed Jan 02 15:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_sonzai_check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0053）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0053",summaryCaptor_4.getValue());
    }
    
    // update_正常_登録申請ボタン_更新申請_15_16
    //
    // -------------------テスト条件--------------------------
    // 取得行 かつ 顧客コード/売上日FROM/料金項目コード/適用開始日が変更されており、
    // 顧客コード/売上日FROM/料金項目コード/適用開始日と同一データが自動請求項目マスタ(その他売上)に存在する。
    // -----------------------------------------------------
    @Test
    public void update_正常_登録申請ボタン_更新申請_15_16 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 顧客コード/売上日FROM/料金項目コード/適用開始日と同一データが自動請求項目マスタ(その他売上)に存在する。
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //月額自動請求マスタ(その他売上)検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_2(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        //テスト実行
        Mst363Form form = new Mst363Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_15_2(i));
        }        
        form.setSelectedSearchResult(result);
        //営業所コード
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("111");
        form.setConEigyoshoCd(conEigyoshoCd);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        //申請状況
        form.setConShinseiJokyo(new String[]{"01","02","03","04","05"});
        target.setMst363Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("15",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("25",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("Wed Jan 02 15:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_update",functionCodeCaptor_2.getValue());
    } 
    
    // update_異常_登録申請ボタン_更新申請_15_17
    //
    // -------------------テスト条件--------------------------
    // 入力された顧客コードが顧客マスタに存在しない。[COME0051]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_登録申請ボタン_更新申請_15_17 () throws IllegalAccessException, InvocationTargetException {
        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力された顧客コードが顧客マスタに存在しない。[COME0051]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0051", "listKokyakuCd");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst363Form form = new Mst363Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_15_2(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst363Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("15",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("25",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("Wed Jan 02 15:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_sonzai_check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0051）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0051",summaryCaptor_4.getValue());
    }
    
    // update_正常_登録申請ボタン_更新申請_15_18
    //
    // -------------------テスト条件--------------------------
    // 入力された顧客コードが顧客マスタに存在する。
    // -----------------------------------------------------
    @Test
    public void update_正常_登録申請ボタン_更新申請_15_18 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力された料金項目コードが付帯料金項目マスタに存在
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //月額自動請求マスタ(その他売上)検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_2(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        //テスト実行
        Mst363Form form = new Mst363Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_15_2(i));
        }        
        form.setSelectedSearchResult(result);
        //営業所コード
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("111");
        form.setConEigyoshoCd(conEigyoshoCd);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        //申請状況
        form.setConShinseiJokyo(new String[]{"01","02","03","04","05"});
        target.setMst363Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("15",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("25",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("Wed Jan 02 15:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_update",functionCodeCaptor_2.getValue());
    } 
    
    // update_異常_登録申請ボタン_更新申請_15_19
    //
    // -------------------テスト条件--------------------------
    // 入力された伝票種別コードが伝票種別マスタに存在しない。[COME0051]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_登録申請ボタン_更新申請_15_19 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力された伝票種別コードが伝票種別マスタに存在しない。[COME0051]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0051", "listDempyoShubetsuMei");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst363Form form = new Mst363Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_15_2(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst363Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("15",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("25",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("Wed Jan 02 15:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_sonzai_check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：MSTE0051）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0051",summaryCaptor_4.getValue());
    }
    
    // update_正常_登録申請ボタン_更新申請_15_20
    //
    // -------------------テスト条件--------------------------
    // 入力された伝票種別コードが伝票種別マスタに存在する。
    // -----------------------------------------------------
    @Test
    public void update_正常_登録申請ボタン_更新申請_15_20 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力された伝票種別コードが伝票種別マスタに存在する。
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //月額自動請求マスタ(その他売上)検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_2(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        //テスト実行
        Mst363Form form = new Mst363Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_15_2(i));
        }        
        form.setSelectedSearchResult(result);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        //申請状況
        form.setConShinseiJokyo(new String[]{"01","02","03","04","05"});
        target.setMst363Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("15",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("25",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("Wed Jan 02 15:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_update",functionCodeCaptor_2.getValue());
    } 
    
    // update_異常_登録申請ボタン_更新申請_15_21
    //
    // -------------------テスト条件--------------------------
    // 入力された料金項目コードが付帯料金項目マスタに存在しない。[COME0051]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_登録申請ボタン_更新申請_15_21 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力された料金項目コードが付帯料金項目マスタに存在しない。[COME0051]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0051", "listRyokinKomoku");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst363Form form = new Mst363Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_15_2(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst363Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("15",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("25",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("Wed Jan 02 15:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_sonzai_check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：MSTE0051）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0051",summaryCaptor_4.getValue());
    }
    
    // update_正常_登録申請ボタン_更新申請_15_22
    //
    // -------------------テスト条件--------------------------
    // 入力された料金項目コードが付帯料金項目マスタに存在する。
    // -----------------------------------------------------
    @Test
    public void update_正常_登録申請ボタン_更新申請_15_22 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力された料金項目コードが付帯料金項目マスタに存在する。
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //月額自動請求マスタ(その他売上)検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_2(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        //テスト実行
        Mst363Form form = new Mst363Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_15_2(i));
        }        
        form.setSelectedSearchResult(result);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        //申請状況
        form.setConShinseiJokyo(new String[]{"01","02","03","04","05"});
        target.setMst363Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("15",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("25",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("Wed Jan 02 15:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_update",functionCodeCaptor_2.getValue());
    }  
    
    // update_異常_登録申請ボタン_更新申請_15_23
    //
    // -------------------テスト条件--------------------------
    // 単位・単価が付帯料金表と不一致。[COME0051]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_登録申請ボタン_更新申請_15_23 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 単位・単価が付帯料金表と不一致。[COME0051]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0051", "listTanilistTanka");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst363Form form = new Mst363Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_15_2(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst363Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("15",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("25",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("Wed Jan 02 15:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_sonzai_check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：MSTE0051）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0051",summaryCaptor_4.getValue());
    }
    
    // update_正常_登録申請ボタン_更新申請_15_24
    //
    // -------------------テスト条件--------------------------
    // 単位・単価が付帯料金表と一致。
    // -----------------------------------------------------
    @Test
    public void update_正常_登録申請ボタン_更新申請_15_24 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 単位・単価が付帯料金表と一致。
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //月額自動請求マスタ(その他売上)検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_2(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        //テスト実行
        Mst363Form form = new Mst363Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_15_2(i));
        }        
        form.setSelectedSearchResult(result);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        //申請状況
        form.setConShinseiJokyo(new String[]{"01","02","03","04","05"});
        target.setMst363Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("15",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("25",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("Wed Jan 02 15:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_update",functionCodeCaptor_2.getValue());
    } 
    
    // delRows_正常_削除申請ボタン_16_1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 1
    // -----------------------------------------------------
    @Test
    public void delRows_正常_削除申請ボタン_16_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture());
        //テスト実行
        Mst363Form form = new Mst363Form();
        //行選択チェック選択 = 1
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_15_1(i));
        }
        form.setSelectedSearchResult(result);
        form.setSearchResult(result);
        target.setMst363Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst363_delete",functionCodeCaptor_2.getValue());
    }  
    
    // delRows_異常_削除申請ボタン_16_2
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // -----------------------------------------------------
    @Test
    public void delRows_異常_削除申請ボタン_16_2 () throws IllegalAccessException, InvocationTargetException {
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> objCaptor_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_1.capture(), summaryCaptor_2.capture(),objCaptor_3
                .capture());
        //テスト実行
        Mst363Form form = new Mst363Form();
        //行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        form.setSelectedSearchResult(result);
        target.setMst363Form(form);
        target.delRowsFunc();

        //実施結果Outを取得
        form = target.getMst363Form();

        // 想定通りにエラーが発生。（メッセージID：COME0011）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0011",summaryCaptor_2.getValue());
        assertEquals("選択",objCaptor_3.getValue());
    }   
    
    // delRows_正常_削除申請ボタン_16_3
    //
    // -------------------テスト条件--------------------------
    // データが存在していた場合
    // -----------------------------------------------------
    @Test
    public void delRows_正常_削除申請ボタン_16_3 () throws IllegalAccessException, 
            InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        serviceInterfaceBean2.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean,serviceInterfaceBean2);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture());
        //テスト実行
        Mst363Form form = new Mst363Form();
        //行選択チェック選択 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            result.add(createRecMapFor_15_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst363Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listUriagebiTo0",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("listUriagebiFrom0",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("2019-01-05 00:00:00.0",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_delete",functionCodeCaptor_2.getValue());
    }
    
    // delRows_異常_削除申請ボタン_16_4
    //
    // -------------------テスト条件--------------------------
    // データが存在していない場合  [COME0043]が返却
    // -----------------------------------------------------
    @Test
    public void delRows_異常_削除申請ボタン_16_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 適用終了日が適用開始日より過去日付の場合。[COME0043]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0043", "listTekiyoShuryobilistTekiyoKaishibi");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messageProperty.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2
                .capture(),summaryCaptor_3.capture(),summaryCaptor_4.capture())).thenReturn(messageModuleBean);

        //テスト実行
        Mst363Form form = new Mst363Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_15_1(i));
        }
        form.setSelectedSearchResult(result);
        form.setSearchResult(result);
        target.setMst363Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst363Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listUriagebiTo0",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("listUriagebiFrom0",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("2019-01-05 00:00:00.0",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_delete_check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0043）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0043",summaryCaptor_2.getValue());
    }  
    
    // callBackDataUpdate_正常_申請ステータス更新_17_1
    //
    // -------------------テスト条件--------------------------
    // 申請書のステータスが変更になった際に共通申請画面から呼び出されるメソッドを作成する。
    // -----------------------------------------------------
    @Test
    public void callBackDataUpdate_正常_申請ステータス更新_17_1 () throws IllegalAccessException, InvocationTargetException {
        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        //テスト実行
        Mst363Form form = new Mst363Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_15_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst363Form(form);
        target.callBackDataUpdate(result);

        //実施結果Outを取得
        form = target.getMst363Form();
        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listUriagebiTo0",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("listUriagebiFrom0",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("2019-01-05 00:00:00.0",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_update_callback",functionCodeCaptor_2.getValue());
    }   
    
    // callBackDataSakujo_正常_未申請データ削除_18_1
    //
    // -------------------テスト条件--------------------------
    // 申請データ削除の際に共通申請画面から呼び出されるメソッドを作成する。
    // -----------------------------------------------------
    @Test
    public void callBackDataSakujo_正常_未申請データ削除_18_1 () throws IllegalAccessException, InvocationTargetException {
        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        //テスト実行
        Mst363Form form = new Mst363Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_15_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst363Form(form);
        target.callBackDataSakujo(result);

        //実施結果Outを取得
        form = target.getMst363Form();
        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listUriagebiTo0",paramsCaptor_1_Param.get("listUriagebiTo"));
        assertEquals("listUriagebiFrom0",paramsCaptor_1_Param.get("listUriagebiFrom"));
        assertEquals("listHyojiMei0",paramsCaptor_1_Param.get("listHyojiMei"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("100",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listOdaimoku0",paramsCaptor_1_Param.get("listOdaimoku"));
        assertEquals("listDempyoShubetsuMei0",paramsCaptor_1_Param.get("listDempyoShubetsuMei"));
        assertEquals("listKyujitsuKeijo0",paramsCaptor_1_Param.get("listKyujitsuKeijo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTani"));
        assertEquals("2019-01-05 00:00:00.0",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listDempyoShubetsu0",paramsCaptor_1_Param.get("listDempyoShubetsu"));
        assertEquals("true",paramsCaptor_1_Param.get("addFlg").toString());
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listRyokinKomokuMei0",paramsCaptor_1_Param.get("listRyokinKomokuMei"));
        assertEquals("listSeikyushoBiko10",paramsCaptor_1_Param.get("listSeikyushoBiko1"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("10",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("mst363_delete_callback",functionCodeCaptor_2.getValue());
    }   
    
    private Map<String, String> createRecMapFor_1_1(int i) {
        Map recMap = new HashMap();
        //顧客コード
        recMap.put("listKokyakuCd", "listKokyakuCd" + i);
        //顧客名称
        recMap.put("listKokyakuMei", "listKokyakuMei" + i);
        //売上日From
        recMap.put("listUriagebiFrom", "listUriagebiFrom" + i);
        //売上日To
        recMap.put("listUriagebiTo", "listUriagebiTo" + i);
        //休日計上
        recMap.put("listKyujitsuKeijo", "listKyujitsuKeijo" + i);
        //お題目
        recMap.put("listOdaimoku", "listOdaimoku" + i);
        //伝票種別
        recMap.put("listDempyoShubetsu", "listDempyoShubetsu" + i);
        //伝票種別名
        recMap.put("listDempyoShubetsuMei", "listDempyoShubetsuMei" + i);
        //料金項目
        recMap.put("listRyokinKomoku", "listRyokinKomoku" + i);
        //料金項目名
        recMap.put("listRyokinKomokuMei", "listRyokinKomokuMei" + i);
        //表示名
        recMap.put("listHyojiMei", "listHyojiMei" + i);
        //適用開始日
        recMap.put("listTekiyoKaishibi", "listTekiyoKaishibi" + i);
         //単位
        recMap.put("listTani", "10");
        //単価
        recMap.put("listTanka", "10");
        //数量
        recMap.put("listSuryo", "1");
        //金額
        recMap.put("listKingaku", "100");
        //請求書備考１
        recMap.put("listSeikyushoBiko1", "listSeikyushoBiko1" + i);
        //適用名
        recMap.put("listTekiyoMei", "listTekiyoMei" + i);
        //終了
        recMap.put("listShuryoFlg", "listShuryoFlg" + i);
        //申請状況
        recMap.put("listShinseiJokyo", "listShinseiJokyo" + i);
        return recMap;
    }
    
    private Map<String, String> createRecMapFor_1_2(int i) {
        Map recMap = new HashMap();
        //顧客コード
        recMap.put("listKokyakuCd", "listKokyakuCd" + i);
        //顧客名称
        recMap.put("listKokyakuMei", "listKokyakuMei" + i);
        //売上日From
        recMap.put("listUriagebiFrom", "listUriagebiFrom" + i);
        //売上日To
        recMap.put("listUriagebiTo", "listUriagebiTo" + i);
        //休日計上
        recMap.put("listKyujitsuKeijo", "listKyujitsuKeijo" + i);
        //お題目
        recMap.put("listOdaimoku", "listOdaimoku" + i);
        //伝票種別
        recMap.put("listDempyoShubetsu", "listDempyoShubetsu" + i);
        //伝票種別名
        recMap.put("listDempyoShubetsuMei", "listDempyoShubetsuMei" + i);
        //料金項目
        recMap.put("listRyokinKomoku", "listRyokinKomoku" + i);
        //料金項目名
        recMap.put("listRyokinKomokuMei", "listRyokinKomokuMei" + i);
        //表示名
        recMap.put("listHyojiMei", "listHyojiMei" + i);
        //適用開始日
        recMap.put("listTekiyoKaishibi", "listTekiyoKaishibi" + i);
        //単位
        recMap.put("listTani", "10");
        //単価
        recMap.put("listTanka", "10");
        //数量
        recMap.put("listSuryo", "1");
        //金額
        recMap.put("listKingaku", "100");
        //請求書備考１
        recMap.put("listSeikyushoBiko1", "listSeikyushoBiko1" + i);
        //適用名
        recMap.put("listTekiyoMei", "listTekiyoMei" + i);
        //終了
        recMap.put("listShuryoFlg", "listShuryoFlg" + i);
        //申請状況
        recMap.put("listShinseiJokyo", "listShinseiJokyo" + i);
        return recMap;
    }

    private Map<String, Object> createRecMapFor_14_1(int i) {
        Map recMap = new HashMap();
        //顧客コード
        recMap.put("listKokyakuCd", "listKokyakuCd" + i);
        //顧客名称
        recMap.put("listKokyakuMei", "listKokyakuMei" + i);
        //売上日From
        recMap.put("listUriagebiFrom", "listUriagebiFrom" + i);
        //売上日To
        recMap.put("listUriagebiTo", "listUriagebiTo" + i);
        //休日計上
        recMap.put("listKyujitsuKeijo", "listKyujitsuKeijo" + i);
        //お題目
        recMap.put("listOdaimoku", "listOdaimoku" + i);
        //伝票種別
        recMap.put("listDempyoShubetsu", "listDempyoShubetsu" + i);
        //伝票種別名
        recMap.put("listDempyoShubetsuMei", "listDempyoShubetsuMei" + i);
        //料金項目
        recMap.put("listRyokinKomoku", "listRyokinKomoku" + i);
        //料金項目名
        recMap.put("listRyokinKomokuMei", "listRyokinKomokuMei" + i);
        //表示名
        recMap.put("listHyojiMei", "listHyojiMei" + i);
        //適用開始日
        recMap.put("listTekiyoKaishibi", "2019-01-05 00:00:00.0");
        //単位
        recMap.put("listTani", "10");
        //単価
        recMap.put("listTanka", "10");
        //数量
        recMap.put("listSuryo", "1");
        //金額
        recMap.put("listKingaku", "100");
        //請求書備考１
        recMap.put("listSeikyushoBiko1", "listSeikyushoBiko1" + i);
        //適用名
        recMap.put("listTekiyoMei", "listTekiyoMei" + i);
        //終了
        recMap.put("listShuryoFlg", "listShuryoFlg" + i);
        //申請状況
        recMap.put("listShinseiJokyo", "listShinseiJokyo" + i);
        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }
    private Map<String, Object> createRecMapFor_15_1(int i) {
        Map recMap = new HashMap();
        //顧客コード
        recMap.put("listKokyakuCd", "listKokyakuCd" + i);
        //顧客名称
        recMap.put("listKokyakuMei", "listKokyakuMei" + i);
        //売上日From
        recMap.put("listUriagebiFrom", "listUriagebiFrom" + i);
        //売上日To
        recMap.put("listUriagebiTo", "listUriagebiTo" + i);
        //休日計上
        recMap.put("listKyujitsuKeijo", "listKyujitsuKeijo" + i);
        //お題目
        recMap.put("listOdaimoku", "listOdaimoku" + i);
        //伝票種別
        recMap.put("listDempyoShubetsu", "listDempyoShubetsu" + i);
        //伝票種別名
        recMap.put("listDempyoShubetsuMei", "listDempyoShubetsuMei" + i);
        //料金項目
        recMap.put("listRyokinKomoku", "listRyokinKomoku" + i);
        //料金項目名
        recMap.put("listRyokinKomokuMei", "listRyokinKomokuMei" + i);
        //表示名
        recMap.put("listHyojiMei", "listHyojiMei" + i);
        //適用開始日
        recMap.put("listTekiyoKaishibi", "2019-01-05 00:00:00.0");
        //単位
        recMap.put("listTani", "10");
        //単価
        recMap.put("listTanka", "10");
        //数量
        recMap.put("listSuryo", "1");
        //金額
        recMap.put("listKingaku", "100");
        //請求書備考１
        recMap.put("listSeikyushoBiko1", "listSeikyushoBiko1" + i);
        //適用名
        recMap.put("listTekiyoMei", "listTekiyoMei" + i);
        //終了
        recMap.put("listShuryoFlg", "listShuryoFlg" + i);
        //申請状況
        recMap.put("listShinseiJokyo", "listShinseiJokyo" + i);
        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }
    
    private Map<String, Object> createRecMapFor_15_2(int i) {
        Map recMap = new HashMap();
        //顧客コード
        recMap.put("listKokyakuCd", "listKokyakuCd" + i);
        //顧客名称
        recMap.put("listKokyakuMei", "listKokyakuMei" + i);
        //売上日From
        recMap.put("listUriagebiFrom", "25" );
        //売上日To
        recMap.put("listUriagebiTo", "15");
        //休日計上
        recMap.put("listKyujitsuKeijo", "listKyujitsuKeijo" + i);
        //お題目
        recMap.put("listOdaimoku", "listOdaimoku" + i);
        //伝票種別
        recMap.put("listDempyoShubetsu", "listDempyoShubetsu" + i);
        //伝票種別名
        recMap.put("listDempyoShubetsuMei", "listDempyoShubetsuMei" + i);
        //料金項目
        recMap.put("listRyokinKomoku", "listRyokinKomoku" + i);
        //料金項目名
        recMap.put("listRyokinKomokuMei", "listRyokinKomokuMei" + i);
        //表示名
        recMap.put("listHyojiMei", "listHyojiMei" + i);
        //適用開始日
        recMap.put("listTekiyoKaishibi", "Wed Jan 02 15:00:00 JST 2019");
        //単位
        recMap.put("listTani", "10");
        //単価
        recMap.put("listTanka", "10");
        //数量
        recMap.put("listSuryo", "1");
        //金額
        recMap.put("listKingaku", "100");
        //請求書備考１
        recMap.put("listSeikyushoBiko1", "listSeikyushoBiko1" + i);
        //適用名
        recMap.put("listTekiyoMei", "listTekiyoMei" + i);
        //終了
        recMap.put("listShuryoFlg", "listShuryoFlg" + i);
        //申請状況
        recMap.put("listShinseiJokyo", "listShinseiJokyo" + i);
        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }
    
    private void assertForRecList_2_1(Mst363Form form) {
        int i = 0;
        assertEquals(1, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            //顧客コード
            assertEquals("listKokyakuCd" + i, rec.get("listKokyakuCd"));
            //顧客名称
            assertEquals("listKokyakuMei" + i, rec.get("listKokyakuMei"));
            //売上日From
            assertEquals("listUriagebiFrom" + i, rec.get("listUriagebiFrom"));
            //売上日To
            assertEquals("listUriagebiTo" + i, rec.get("listUriagebiTo"));
            //休日計上
            assertEquals("listKyujitsuKeijo" + i, rec.get("listKyujitsuKeijo"));
            //お題目
            assertEquals("listOdaimoku" + i, rec.get("listOdaimoku"));
            //伝票種別
            assertEquals("listDempyoShubetsu" + i, rec.get("listDempyoShubetsu"));
            //伝票種別名
            assertEquals("listDempyoShubetsuMei" + i, rec.get("listDempyoShubetsuMei"));
            //料金項目
            assertEquals("listRyokinKomoku" + i, rec.get("listRyokinKomoku"));
            //料金項目名
            assertEquals("listRyokinKomokuMei" + i, rec.get("listRyokinKomokuMei"));
            //表示名
            assertEquals("listHyojiMei" + i, rec.get("listHyojiMei"));
            //適用開始日
            assertEquals("listTekiyoKaishibi" + i, rec.get("listTekiyoKaishibi"));
            //単位
            assertEquals("10", rec.get("listTani"));
            //単価
            assertEquals("10", rec.get("listTanka"));
            //数量
            assertEquals("1", rec.get("listSuryo"));
            //金額
            assertEquals("100", rec.get("listKingaku"));
            //請求書備考１
            assertEquals("listSeikyushoBiko1" + i, rec.get("listSeikyushoBiko1"));
            //適用名
            assertEquals("listTekiyoMei"  + i, rec.get("listTekiyoMei"));
            //終了
            assertEquals("listShuryoFlg" + i, rec.get("listShuryoFlg"));
            //申請状況
            assertEquals("listShinseiJokyo" + i, rec.get("listShinseiJokyo"));
            i++;
        }
    }    

    private void assertForRecList_2_2(Mst363Form form) {
        int i = 0;
        assertEquals(2, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            //顧客コード
            assertEquals("listKokyakuCd" + i, rec.get("listKokyakuCd"));
            //顧客名称
            assertEquals("listKokyakuMei" + i, rec.get("listKokyakuMei"));
            //売上日From
            assertEquals("listUriagebiFrom" + i, rec.get("listUriagebiFrom"));
            //売上日To
            assertEquals("listUriagebiTo" + i, rec.get("listUriagebiTo"));
            //休日計上
            assertEquals("listKyujitsuKeijo" + i, rec.get("listKyujitsuKeijo"));
            //お題目
            assertEquals("listOdaimoku" + i, rec.get("listOdaimoku"));
            //伝票種別
            assertEquals("listDempyoShubetsu" + i, rec.get("listDempyoShubetsu"));
            //伝票種別名
            assertEquals("listDempyoShubetsuMei" + i, rec.get("listDempyoShubetsuMei"));
            //料金項目
            assertEquals("listRyokinKomoku" + i, rec.get("listRyokinKomoku"));
            //料金項目名
            assertEquals("listRyokinKomokuMei" + i, rec.get("listRyokinKomokuMei"));
            //表示名
            assertEquals("listHyojiMei" + i, rec.get("listHyojiMei"));
            //適用開始日
            assertEquals("listTekiyoKaishibi" + i, rec.get("listTekiyoKaishibi"));
            //単位
            assertEquals("10", rec.get("listTani"));
            //単価
            assertEquals("10", rec.get("listTanka"));
            //数量
            assertEquals("1", rec.get("listSuryo"));
            //金額
            assertEquals("100", rec.get("listKingaku"));
            //請求書備考１
            assertEquals("listSeikyushoBiko1" + i, rec.get("listSeikyushoBiko1"));
            //適用名
            assertEquals("listTekiyoMei"  + i, rec.get("listTekiyoMei"));
            //終了
            assertEquals("listShuryoFlg" + i, rec.get("listShuryoFlg"));
            //申請状況
            assertEquals("listShinseiJokyo" + i, rec.get("listShinseiJokyo"));
            i++;
        }
    }      

    private void assertForRecList_2_3(Mst363Form form) {
        int i = 0;
        assertEquals(0, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            //顧客コード
            assertEquals("listKokyakuCd" + i, rec.get("listKokyakuCd"));
            //顧客名称
            assertEquals("listKokyakuMei" + i, rec.get("listKokyakuMei"));
            //売上日From
            assertEquals("listUriagebiFrom" + i, rec.get("listUriagebiFrom"));
            //売上日To
            assertEquals("listUriagebiTo" + i, rec.get("listUriagebiTo"));
            //休日計上
            assertEquals("listKyujitsuKeijo" + i, rec.get("listKyujitsuKeijo"));
            //お題目
            assertEquals("listOdaimoku" + i, rec.get("listOdaimoku"));
            //伝票種別
            assertEquals("listDempyoShubetsu" + i, rec.get("listDempyoShubetsu"));
            //伝票種別名
            assertEquals("listDempyoShubetsuMei" + i, rec.get("listDempyoShubetsuMei"));
            //料金項目
            assertEquals("listRyokinKomoku" + i, rec.get("listRyokinKomoku"));
            //料金項目名
            assertEquals("listRyokinKomokuMei" + i, rec.get("listRyokinKomokuMei"));
            //表示名
            assertEquals("listHyojiMei" + i, rec.get("listHyojiMei"));
            //適用開始日
            assertEquals("listTekiyoKaishibi" + i, rec.get("listTekiyoKaishibi"));
            //単位
            assertEquals("10", rec.get("listTani"));
            //単価
            assertEquals("10", rec.get("listTanka"));
            //数量
            assertEquals("1", rec.get("listSuryo"));
            //金額
            assertEquals("100", rec.get("listKingaku"));
            //請求書備考１
            assertEquals("listSeikyushoBiko1" + i, rec.get("listSeikyushoBiko1"));
            //適用名
            assertEquals("listTekiyoMei"  + i, rec.get("listTekiyoMei"));
            //終了
            assertEquals("listShuryoFlg" + i, rec.get("listShuryoFlg"));
            //申請状況
            assertEquals("listShinseiJokyo" + i, rec.get("listShinseiJokyo"));
            i++;
        }
    }
    
}
