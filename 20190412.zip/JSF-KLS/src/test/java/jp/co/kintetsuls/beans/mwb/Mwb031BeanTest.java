/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mwb;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.beans.common.TemplateBean;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mwb.Mwb031Form;
import jp.co.kintetsuls.utils.FlashUtil;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import org.junit.After;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import org.mockito.MockitoAnnotations;

/**
 * VOID入力
 *
 * @author 許 彭戈ヤン
 */
public class Mwb031BeanTest {

    // テストTarget
    @InjectMocks
    private Mwb031Bean target;

    // Mockitoオブジェクト
    @Mock
    private TemplateBean templeteBean;
    @Mock
    private AutoCompleteViewBean autoCompleteViewBean;
    @Mock
    private MasterInfoBean masterInfo;
    @Mock
    private MessagePropertyBean messageProperty;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosai;
    @Mock
    private SearchHelpBean searchHelpBean;
    @Mock
    private AuthorityConfBean authConfBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private MessagePropertyBean messagePropertyBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosaiBean;
    @Mock
    private FlashUtil flashUtil;
    @Mock
    private BaseBean baseBean;

    public Mwb031BeanTest() {
    }

    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() {
    }

    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[not null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> scriptCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mwb031Form mwb031Form = new Mwb031Form();

        //前画面情報[not null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mwb031Form);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());

        // テスト実行
        Mwb031Form form = new Mwb031Form();
        target.setMwb031Form(form);
        // 戻ってきた場合、再検索を実施する。
        target.init("", "MST031_SCREEN", true);

        // 実施結果Outを取得
        form = target.getMwb031Form();
        // タイトル設定
        String title = target.getTITLE();
        // URL設定
        String url = target.getUrl();
        // パンくず設定
        BreadCrumbBean breadBean = target.getBreadBean();
        // autoCompletebean設定
        AutoCompleteViewBean autoCompleteViewBean = target.getAutoCompleteViewBean();
        // ユーザ権限設定
        AuthorityConfBean authorityConfBean = target.getAuthConfBean();
        // ダウンロード
        TemplateBean fileBean = target.getTempleteBean();
        // メッセージ
        MessagePropertyBean messagePropertyBean = target.getMessageProperty();
        // 画面共通作業
        PageCommonBean pageCommonBean = target.getPageCommonBean();
        // 検索ボタン設定
        SearchHelpBean searchHelpBean = target.getSearchHelpBean();
        // メッセージリスト
        List<MessageModuleBean> msgList = target.getMsgList();
        target.setUrl(url);
        target.setBreadBean(breadBean);
        target.setAutoCompleteViewBean(autoCompleteViewBean);
        target.setAuthConfBean(authorityConfBean);
        target.setTempleteBean(fileBean);
        target.setMessageProperty(messagePropertyBean);
        target.setPageCommonBean(pageCommonBean);
        target.setSearchHelpBean(searchHelpBean);
        target.setMsgList(msgList);
        doNothing().when(this.pageCommonBean).executeScript(scriptCaptor_2.capture());

        // 実行時に渡すパラメータの検証
        assertEquals("mwb031Form", keyCaptor_1.getValue());
        // 想定通りに再検索を実施する。
        assertEquals("search_mwb031", keyCaptor_2.getValue());
    }

    // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[ 発券営業所コード = "001" VOID年月="2018/12/25" 航空会社="ANA"]
    // DBデータ戻り値なし
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2() throws IllegalAccessException, InvocationTargetException,
            InstantiationException, ParseException {

        // Mockitoオブジェクトの予想return値設定
        Mwb031Form mwb031Form = new Mwb031Form();

        // Mockitoオブジェクトの予想return値設定
        Flash flash = new FlashKls();

        flash.put("mwb031Form", mwb031Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());

        // テスト実行
        Mwb031Form form = new Mwb031Form();
        // 発券営業所コード値
        AutoCompOptionBean conSearchHakkenEigyoshoCd = new AutoCompOptionBean("1", "001");
        // 航空会社レータコード値
        AutoCompOptionBean conSearchKokuGaishaLetterCd = new AutoCompOptionBean("1", "ANA");

        form.setConSearchHakkenEigyoshoCd(conSearchHakkenEigyoshoCd);
        form.setConSearchKokuGaishaLetterCd(conSearchKokuGaishaLetterCd);
        // VOID年月
        form.setConSearchVoidNengetsu("2018/12/25");

        target.setMwb031Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID", "", false);

        // 想定通りに再検索を実施する。
        assertEquals("search_mwb031", keyCaptor_2.getValue());
        assertEquals(null, form.getConSearchHakkenEigyoshoCd());
        assertEquals(null, form.getConSearchKokuGaishaLetterCd());
        assertEquals(null, form.getConSearchVoidNengetsu());
    }

    // init_正常_初期処理_1-2_1
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2_1() throws IllegalAccessException, InvocationTargetException,
            InstantiationException, ParseException {

        // Mockitoオブジェクトの予想return値設定
        Mwb031Form mwb031Form = new Mwb031Form();

        // Mockitoオブジェクトの予想return値設定
        Flash flash = new FlashKls();

        flash.put("mwb031Form", mwb031Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());

        // テスト実行
        Mwb031Form form = new Mwb031Form();
        form.setConSelectSagyoKubun("1");
        target.setMwb031Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID", "", false);

        // 実施結果Outを取得
        // 想定通りに再検索を実施する。
        assertEquals("search_mwb031", keyCaptor_2.getValue());
    }

    // init_正常_初期処理_1-3
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        // 前画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(null);

        // テスト実行
        Mwb031Form form = new Mwb031Form();
        target.setMwb031Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID", "", false);

        // 実施結果Outを取得
        form = target.getMwb031Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mwb031Form", keyCaptor_1.getValue());
        // 想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null, form.getSearchResult());
    }

    // init_正常_初期処理_1-3_1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        // 前画面情報[null]
        doThrow(IllegalAccessException.class).when(pageCommonBean).getPageInfo(keyCaptor_1.capture());

        // テスト実行
        Mwb031Form form = new Mwb031Form();
        target.setMwb031Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID", "", false);

        // 実施結果Outを取得
        form = target.getMwb031Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mwb031Form", keyCaptor_1.getValue());
        // 想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null, form.getSearchResult());
    }

    // search_正常_検索処理_2-1
    //
    // -------------------テスト条件--------------------------
    // 検索結果一覧取得 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_1() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索結果一覧取得 件数 = 1
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i <= 0; i++) {
            result.add(createRecMapFor_2_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mwb031Form form = new Mwb031Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("conEigyoshoCd1");
        AutoCompOptionBean conKokuKaishaCode = new AutoCompOptionBean();
        conKokuKaishaCode.setValue("ANA");
        String conTekiyobi = "2019-01";

        form.setConSearchHakkenEigyoshoCd(conEigyoshoCd);
        form.setConSearchKokuGaishaLetterCd(conKokuKaishaCode);
        form.setConSearchVoidNengetsu(conTekiyobi);

        doNothing().when(pageCommonBean).executeScript("displayChange()");
        target.setMwb031Form(form);
        target.search();

        // 実施結果Outを取得
        form = target.getMwb031Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conEigyoshoCd1", paramsCaptor_1.getValue().get("conSearchHakkenEigyoshoCd"));
        assertEquals("2019-01", paramsCaptor_1.getValue().get("conSearchVoidNengetsu"));
        assertEquals("ANA", paramsCaptor_1.getValue().get("conSearchKokuGaishaLetterCd"));
        assertEquals("mwb031-search", functionCodeCaptor_2.getValue());
        // 想定通りに一覧を表示されること
        assertForRecList_2_1(form);
    }

    // search_正常_検索処理_2-2
    //
    // -------------------テスト条件--------------------------
    // 検索結果一覧取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_2() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索結果一覧取得 取得件数 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            result.add(createRecMapFor_2_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mwb031Form form = new Mwb031Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("conEigyoshoCd1");
        AutoCompOptionBean conKokuKaishaCode = new AutoCompOptionBean();
        conKokuKaishaCode.setValue("ANA");
        String conTekiyobi = "2019-01";
        form.setConSearchHakkenEigyoshoCd(conEigyoshoCd);
        form.setConSearchKokuGaishaLetterCd(conKokuKaishaCode);
        form.setConSearchVoidNengetsu(conTekiyobi);
        target.setMwb031Form(form);
        target.search();

        // 実施結果Outを取得
        form = target.getMwb031Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conEigyoshoCd1", paramsCaptor_1.getValue().get("conSearchHakkenEigyoshoCd"));
        assertEquals("2019-01", paramsCaptor_1.getValue().get("conSearchVoidNengetsu"));
        assertEquals("ANA", paramsCaptor_1.getValue().get("conSearchKokuGaishaLetterCd"));
        assertEquals("mwb031-search", functionCodeCaptor_2.getValue());
        // 想定通りに一覧を表示されること
        assertForRecList_2_2(form);
    }

    // search_正常_検索処理_2-3
    //
    // -------------------テスト条件--------------------------
    // 仕入予定検索結果一覧取得 取得件数 = 0
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_3() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索結果一覧取得 取得件数 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("conEigyoshoCd1");
        AutoCompOptionBean conKokuKaishaCode = new AutoCompOptionBean();
        conKokuKaishaCode.setValue("ANA");
        String conTekiyobi = "2019-01";
        Mwb031Form form = new Mwb031Form();
        form.setConSearchHakkenEigyoshoCd(conEigyoshoCd);
        form.setConSearchKokuGaishaLetterCd(conKokuKaishaCode);
        form.setConSearchVoidNengetsu(conTekiyobi);
        // テスト実行

        target.setMwb031Form(form);
        target.search();

        // 実施結果Outを取得
        form = target.getMwb031Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conEigyoshoCd1", paramsCaptor_1.getValue().get("conSearchHakkenEigyoshoCd"));
        assertEquals("2019-01", paramsCaptor_1.getValue().get("conSearchVoidNengetsu"));
        assertEquals("ANA", paramsCaptor_1.getValue().get("conSearchKokuGaishaLetterCd"));
        assertEquals("mwb031-search", functionCodeCaptor_2.getValue());
        // 想定通りに・一覧は表示しない（ヘッダーのみ） 
        // 想定通りに ・ファンクションボタンは表示（検索前と同じ）       
    }

    // search_異常_件数取得処理_2-4_2
    //
    // -------------------テスト条件--------------------------
    // 仕入予定検索結果一覧取得
    // -----------------------------------------------------
    @Test
    public void search_異常_件数取得処理_2_3_1() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        doThrow(IOException.class).when(pageCommonBean).getDBInfo(paramsCaptor_1.capture(),
                functionCodeCaptor_2.capture());
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mwb031Form form = new Mwb031Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("conEigyoshoCd1");
        AutoCompOptionBean conKokuKaishaCode = new AutoCompOptionBean();
        conKokuKaishaCode.setValue("ANA");
        String conTekiyobi = "2019-01";
        form.setConSearchHakkenEigyoshoCd(conEigyoshoCd);
        form.setConSearchKokuGaishaLetterCd(conKokuKaishaCode);
        form.setConSearchVoidNengetsu(conTekiyobi);
        target.setMwb031Form(form);
        target.search();

        // 実施結果Outを取得
        form = target.getMwb031Form();
    }

    // getRecordCount_正常_件数取得処理_2-4
    //
    // -------------------テスト条件--------------------------
    // 仕入予定検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_4() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),
                functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mwb031Form form = new Mwb031Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("conEigyoshoCd1");
        AutoCompOptionBean conKokuKaishaCode = new AutoCompOptionBean();
        conKokuKaishaCode.setValue("ANA");
        String conTekiyobi = "2019-01";
        form.setConSearchHakkenEigyoshoCd(conEigyoshoCd);
        form.setConSearchKokuGaishaLetterCd(conKokuKaishaCode);
        form.setConSearchVoidNengetsu(conTekiyobi);
        target.setMwb031Form(form);
        target.getRecordCount(false);

        // 実施結果Outを取得
        form = target.getMwb031Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conEigyoshoCd1", paramsCaptor_1.getValue().get("conSearchHakkenEigyoshoCd"));
        assertEquals("2019-01", paramsCaptor_1.getValue().get("conSearchVoidNengetsu"));
        assertEquals("ANA", paramsCaptor_1.getValue().get("conSearchKokuGaishaLetterCd"));
        assertEquals("mwb031-search-count", functionCodeCaptor_2.getValue());
        // 想定通りに正常にCountを実施されること
    }
    
    // getRecordCount_正常_件数取得処理_2-4
    //
    // -------------------テスト条件--------------------------
    // 仕入予定検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_5() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),
                functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mwb031Form form = new Mwb031Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("conEigyoshoCd1");
        AutoCompOptionBean conKokuKaishaCode = new AutoCompOptionBean();
        conKokuKaishaCode.setValue("ANA");
        String conTekiyobi = "2019-01";
        form.setConSearchHakkenEigyoshoCd(conEigyoshoCd);
        form.setConSearchKokuGaishaLetterCd(conKokuKaishaCode);
        form.setConSearchVoidNengetsu(conTekiyobi);
        target.setMwb031Form(form);
        when(pageCommonBean.getPageInfo("mwb031Form")).thenReturn(form);
        target.getRecordCount(true);

        // 実施結果Outを取得
        form = target.getMwb031Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conEigyoshoCd1", paramsCaptor_1.getValue().get("conSearchHakkenEigyoshoCd"));
        assertEquals("2019-01", paramsCaptor_1.getValue().get("conSearchVoidNengetsu"));
        assertEquals("ANA", paramsCaptor_1.getValue().get("conSearchKokuGaishaLetterCd"));
        assertEquals("mwb031-search-count", functionCodeCaptor_2.getValue());
        // 想定通りに正常にCountを実施されること
    }

    // search_異常_検索処理_2_1_1
    //
    // -------------------テスト条件--------------------------
    // 必須チェック
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_1_1() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索結果一覧取得 件数 = 1

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mwb031Form form = new Mwb031Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean(" ", " ");
        conEigyoshoCd.setValue(" ");
        AutoCompOptionBean conKokuKaishaCode = new AutoCompOptionBean(" ", " ");
        conKokuKaishaCode.setValue(" ");
        form.setConSearchHakkenEigyoshoCd(conEigyoshoCd);
        form.setConSearchKokuGaishaLetterCd(conKokuKaishaCode);
        target.setMwb031Form(form);
        target.searchCheck();

        // 実施結果Outを取得
        form = target.getMwb031Form();

    }
    // search_異常_検索処理_2_1_1
    //
    // -------------------テスト条件--------------------------
    // 必須チェック
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_1_2() throws IllegalAccessException, InvocationTargetException, ParseException {

        // 仕向地検索結果一覧取得 件数 = 1

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mwb031Form form = new Mwb031Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean(" ", " ");
        conEigyoshoCd.setValue(" ");
        AutoCompOptionBean conKokuKaishaCode = new AutoCompOptionBean(" ", " ");
        conKokuKaishaCode.setValue(" ");
        form.setConSearchVoidNengetsu("2018/02");
        form.setConSearchHakkenEigyoshoCd(conEigyoshoCd);
        form.setConSearchKokuGaishaLetterCd(conKokuKaishaCode);
        target.setMwb031Form(form);
        target.searchCheck();

        // 実施結果Outを取得
        form = target.getMwb031Form();

    }

    // search_異常_検索処理_2_1_2
    //
    // -------------------テスト条件--------------------------
    // フォマートチェック
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_1_3() throws IllegalAccessException, InvocationTargetException, ParseException {


        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mwb031Form form = new Mwb031Form();
        
        form.setConSearchVoidNengetsu("7777/77");
        target.setMwb031Form(form);
        target.searchCheck();

        // 実施結果Outを取得
        form = target.getMwb031Form();

    }

    // haifuSakiEigyosho_正常_配布先営業所取得_11-1
    //
    // -------------------テスト条件--------------------------
    // 検索結果一覧取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void haifuSakiEigyosho_正常_検索処理_11_1() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 配布先営業所取得 取得件数 = 1
        Map<String, Object> result = new HashMap<>();

        result.put("HAIFUSAKI_EIGYOSHO_CD", "listKokuGaisha");
        result.put("EIGYOSHO_MEI", "listMawbBango");

        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        // テスト実行
        Mwb031Form form = new Mwb031Form();

        form.setConInsertMawbBango("788884848");
        target.setMwb031Form(form);
        target.haifuSakiEigyosho();

        // 実施結果Outを取得
        form = target.getMwb031Form();
        assertEquals("mwb031-get-haifu-saki-eigyosho", functionCodeCaptor_2.getValue());
    }

    // haifuSakiEigyosho_異常_配布先営業所取得_11-2
    //
    // -------------------テスト条件--------------------------
    // 検索結果一覧取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void haifuSakiEigyosho_異常_検索処理_11_2() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(-1);
        // 配布先営業所取得 取得件数 = 1
        Map<String, Object> result = new HashMap<>();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        // テスト実行
        Mwb031Form form = new Mwb031Form();

        form.setConInsertMawbBango("788884848");
        target.setMwb031Form(form);
        target.haifuSakiEigyosho();

        // 実施結果Outを取得
        form = target.getMwb031Form();

    }

    // haifuSakiEigyosho_異常_配布先営業所取得_11-2_1
    //
    // -------------------テスト条件--------------------------
    // 検索結果一覧取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void haifuSakiEigyosho_異常_検索処理_11_2_1() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 配布先営業所取得 取得件数 = 1

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i <= 0; i++) {
            result.add(createRecMapFor_2_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        // テスト実行
        Mwb031Form form = new Mwb031Form();

        form.setConInsertMawbBango("788884848");
        target.setMwb031Form(form);
        target.haifuSakiEigyosho();

        // 実施結果Outを取得
        form = target.getMwb031Form();
    }

    // clear_正常_クリア処理_3-1
    //
    // -------------------テスト条件--------------------------
    // 検索条件がある、検索結果がない
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_1() throws IllegalAccessException, InvocationTargetException, ParseException {

        // テスト実行
        Mwb031Form form = new Mwb031Form();
        form.setConInsertVoidHizuke("2019/12/25");
        target.setMwb031Form(form);
        target.torokuClear();

        // 実施結果Outを取得
        form = target.getMwb031Form();

        // 想定通りに正常にClearを実施されること
    }

    // getHeader_正常_ダウンロード_4-1
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void getHeader_正常_ダウンロード_4_1() throws IllegalAccessException, InvocationTargetException, ParseException {

        // テスト実行
        Mwb031Form form = new Mwb031Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("conEigyoshoCd1");
        AutoCompOptionBean conKokuKaishaCode = new AutoCompOptionBean();
        conKokuKaishaCode.setValue("ANA");
        String conTekiyobi = "2019-01";
        form.setConSearchHakkenEigyoshoCd(conEigyoshoCd);
        form.setConSearchKokuGaishaLetterCd(conKokuKaishaCode);
        form.setConSearchVoidNengetsu(conTekiyobi);
        target.setMwb031Form(form);
        List<CSVDto> dto = target.getHeader();

        // 実施結果Outを取得
        form = target.getMwb031Form();

    }

    // beforeDown_正常_ダウンロード_4-2
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=2件
    // -----------------------------------------------------
    @Test
    public void beforeDown_正常_ダウンロード_4_2() throws IllegalAccessException, InvocationTargetException, ParseException, Exception {

        // テスト実行
        Mwb031Form form = new Mwb031Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("conEigyoshoCd1");
        AutoCompOptionBean conKokuKaishaCode = new AutoCompOptionBean();
        conKokuKaishaCode.setValue("ANA");
        String conTekiyobi = "2019-01";
        form.setConSearchHakkenEigyoshoCd(conEigyoshoCd);
        form.setConSearchKokuGaishaLetterCd(conKokuKaishaCode);
        form.setConSearchVoidNengetsu(conTekiyobi);
        target.setMwb031Form(form);
        List<CSVDto> dto = target.getHeader();

        // 実施結果Outを取得
        form = target.getMwb031Form();
        target.beforeDown("test");

        // 実施結果Outを取得
        form = target.getMwb031Form();
    }

    // toroku_異常_更新処理_更新登録_11-1
    //
    // -------------------テスト条件--------------------------
    // 登録パラメータ入力しない
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_登録_13_1() throws IllegalAccessException, InvocationTargetException {

        Mwb031Form form = new Mwb031Form();
        target.setMwb031Form(form);
        target.toroku();
        //実施結果Outを取得
        form = target.getMwb031Form();
        assertEquals(null, form.getConInsertKokuGaishaLetterCd());
        assertEquals(null, form.getConInsertMawbBango());
        assertEquals(null, form.getConInsertRiyu());
    }

    // toroku_異常_更新処理_更新登録_11-2_1
    //
    // -------------------テスト条件--------------------------
    // MAWB番号入力、7DRチェック失敗
    // -----------------------------------------------------
    @Test
    public void toroku_異常_更新処理_登録_13_2_2() throws IllegalAccessException, InvocationTargetException {

        Mwb031Form form = new Mwb031Form();
        form.setConInsertMawbBango("78787878");
        target.setMwb031Form(form);
        target.toroku();
        //実施結果Outを取得
        form = target.getMwb031Form();
        assertEquals(null, form.getConInsertKokuGaishaLetterCd());
        assertEquals("78787878", form.getConInsertMawbBango());
        assertEquals(null, form.getConInsertRiyu());
    }

    // toroku_異常_更新処理_更新登録_11-2_1
    //
    // -------------------テスト条件--------------------------
    // 都道府県コード、仕向地名コードの組み合わせが、仕向地名マスタに存在しています
    // -----------------------------------------------------
    @Test
    public void toroku_異常_更新処理_登録_13_2_3() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        // 登録・更新処理パラメータ
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        // 登録・更新処理ファンクション
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // メッセージ追加
        serviceInterfaceBean.addMessage("ERROR", "COME0003", "VOID日付");
        // 状態コードを追加する
        serviceInterfaceBean.setStatusCode(-1);
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        Mwb031Form form = new Mwb031Form();
        // VOID日付
        String voidHizuke = "2019/01/01";
        form.setConInsertVoidHizuke(voidHizuke);
        // 配布先営業所
        form.setConInsertHaifusakiEigyoshoCd("001");
        // MAWB番号
        form.setConInsertMawbBango("78787870");
        // 航空会社コード
        AutoCompOptionBean kokuGaisha = new AutoCompOptionBean("全日空", "ANA");
        form.setConInsertKokuGaishaLetterCd(kokuGaisha);
        // 理由
        form.setConInsertRiyu("77777");
        target.setMwb031Form(form);
        target.toroku();
        //実施結果Outを取得
        form = target.getMwb031Form();
        assertEquals(kokuGaisha, form.getConInsertKokuGaishaLetterCd());
        assertEquals("78787870", form.getConInsertMawbBango());
        assertEquals("77777", form.getConInsertRiyu());
    }

    // toroku_異常_更新処理_更新登録_11-2_4
    //
    // -------------------テスト条件--------------------------
    // VOID日付=2019/01/01、配布先営業所=001、MAWB番号=78787870、航空会社コード=ANA、理由=77777
    // 異常あり
    // -----------------------------------------------------
    @Test
    public void toroku_異常_更新処理_登録_13_2_4() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        // 登録・更新処理パラメータ
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        // 登録・更新処理ファンクション
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        Map<String, Object> result = new HashMap<>();
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        result.put("listKokuGaisha", "listKokuGaisha");
        result.put("listMawbBango", "listMawbBango");
        result.put("listHakkenEigyosho", "listHakkenEigyosho");
        result.put("listHaifusakiEigyosho", "listHaifusakiEigyosho");
        result.put("listVoidHizuke", "2019-01-01");
        result.put("listRiyu", "listRiyu");
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        Mwb031Form form = new Mwb031Form();
        // VOID日付
        String voidHizuke = "2019/01/01";
        form.setConInsertVoidHizuke(voidHizuke);
        // 配布先営業所
        form.setConInsertHaifusakiEigyoshoCd("001");
        // MAWB番号
        form.setConInsertMawbBango("78787870");
        // 航空会社コード
        AutoCompOptionBean kokuGaisha = new AutoCompOptionBean("全日空", "ANA");
        form.setConInsertKokuGaishaLetterCd(kokuGaisha);
        // 理由
        form.setConInsertRiyu("77777");
        target.setMwb031Form(form);
        target.toroku();
        //実施結果Outを取得
        form = target.getMwb031Form();
        assertEquals(kokuGaisha, form.getConInsertKokuGaishaLetterCd());
        assertEquals("001", form.getConInsertHaifusakiEigyoshoCd());
        assertEquals("78787870", form.getConInsertMawbBango());
        assertEquals("77777", form.getConInsertRiyu());
    }

    // toroku_正常_更新処理_更新登録_11-3
    //
    // -------------------テスト条件--------------------------
    // VOID日付=2019/01/01、配布先営業所=001、MAWB番号=78787870、航空会社コード=ANA、理由=77777
    // 登録1件
    // -----------------------------------------------------
    @Test
    public void toroku_正常_更新処理_登録_13_3() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        // 登録・更新処理パラメータ
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        // 登録・更新処理ファンクション
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        List<Map<String, Object>> result = new ArrayList<>();
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_2_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        Mwb031Form form = new Mwb031Form();
        // VOID日付
        String voidHizuke = "2019/01/01";
        form.setConInsertVoidHizuke(voidHizuke);
        // 配布先営業所
        form.setConInsertHaifusakiEigyoshoCd("001");
        // MAWB番号
        form.setConInsertMawbBango("78787870");
        // 航空会社コード
        AutoCompOptionBean kokuGaisha = new AutoCompOptionBean("全日空", "ANA");
        form.setConInsertKokuGaishaLetterCd(kokuGaisha);
        // 理由
        form.setConInsertRiyu("77777");
        target.setMwb031Form(form);
        target.toroku();
        //実施結果Outを取得
        form = target.getMwb031Form();
        assertEquals(kokuGaisha, form.getConInsertKokuGaishaLetterCd());
        assertEquals("001", form.getConInsertHaifusakiEigyoshoCd());
        assertEquals("78787870", form.getConInsertMawbBango());
        assertEquals("77777", form.getConInsertRiyu());
    }

    // voidTorikeshi_異常_更新処理_更新登録_11-1
    //
    // -------------------テスト条件--------------------------
    // 削除パラメータ入力しない
    // -----------------------------------------------------
    @Test
    public void voidTorikeshi_異常_VOID取消処理_14_1() throws IllegalAccessException, InvocationTargetException {

        Mwb031Form form = new Mwb031Form();
        target.setMwb031Form(form);
        target.voidTorikeshi();
        //実施結果Outを取得
        form = target.getMwb031Form();
        assertEquals(null, form.getConInsertKokuGaishaLetterCd());
        assertEquals(null, form.getConInsertMawbBango());
        assertEquals(null, form.getConInsertRiyu());
    }

    // voidTorikeshi_異常_更新処理_更新登録_11-2_1
    //
    // -------------------テスト条件--------------------------
    // 都道府県コード、仕向地名コードの組み合わせが、仕向地名マスタに存在しています
    // -----------------------------------------------------
    @Test
    public void voidTorikeshi_異常_VOID取消処理_14_2_1() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        // 登録・更新処理パラメータ
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        // 登録・更新処理ファンクション
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        Mwb031Form form = new Mwb031Form();
        // VOID日付
        String voidHizuke = "2019/01/01";
        form.setConInsertVoidHizuke(voidHizuke);
        // 配布先営業所
        form.setConInsertHaifusakiEigyoshoCd("001");
        // MAWB番号
        form.setConInsertMawbBango("78787870");
        // 航空会社コード
        AutoCompOptionBean kokuGaisha = new AutoCompOptionBean("全日空", "ANA");
        form.setConInsertKokuGaishaLetterCd(kokuGaisha);
        // 理由
        form.setConInsertRiyu("77777");
        target.setMwb031Form(form);
        target.voidTorikeshi();
        //実施結果Outを取得
        form = target.getMwb031Form();
        assertEquals(kokuGaisha, form.getConInsertKokuGaishaLetterCd());
        assertEquals("78787870", form.getConInsertMawbBango());
        assertEquals("77777", form.getConInsertRiyu());
    }

    // voidTorikeshi_異常_更新処理_更新登録_11-2_1
    //
    // -------------------テスト条件--------------------------
    // 都道府県コード、仕向地名コードの組み合わせが、仕向地名マスタに存在しています
    // -----------------------------------------------------
    @Test
    public void voidTorikeshi_異常_更新処理_更新登録_14_2_1() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        // 登録・更新処理パラメータ
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        // 登録・更新処理ファンクション
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // メッセージ追加
        serviceInterfaceBean.addMessage("ERROR", "COME0003", "VOID日付");
        // 状態コードを追加する
        serviceInterfaceBean.setStatusCode(-1);
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        Mwb031Form form = new Mwb031Form();
        // VOID日付
        String voidHizuke = "2019/01/01";
        form.setConInsertVoidHizuke(voidHizuke);
        // 配布先営業所
        form.setConInsertHaifusakiEigyoshoCd("001");
        // MAWB番号
        form.setConInsertMawbBango("78787870");
        // 航空会社コード
        AutoCompOptionBean kokuGaisha = new AutoCompOptionBean("全日空", "ANA");
        form.setConInsertKokuGaishaLetterCd(kokuGaisha);
        // 理由
        form.setConInsertRiyu("77777");
        target.setMwb031Form(form);
        target.voidTorikeshi();
        //実施結果Outを取得
        form = target.getMwb031Form();
        assertEquals(kokuGaisha, form.getConInsertKokuGaishaLetterCd());
        assertEquals("78787870", form.getConInsertMawbBango());
        assertEquals("77777", form.getConInsertRiyu());
    }

    // voidTorikeshi_異常_更新処理_更新登録_11-2_4
    //
    // -------------------テスト条件--------------------------
    // VOID日付=2019/01/01、配布先営業所=001、MAWB番号=78787870、航空会社コード=ANA
    // 異常あり
    // -----------------------------------------------------
    @Test
    public void voidTorikeshi_異常_更新処理_更新登録_14_2_4() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        // 登録・更新処理パラメータ
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        // 登録・更新処理ファンクション
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        Map<String, Object> result = new HashMap<>();
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        result.put("listKokuGaisha", "listKokuGaisha");
        result.put("listMawbBango", "listMawbBango");
        result.put("listHakkenEigyosho", "listHakkenEigyosho");
        result.put("listHaifusakiEigyosho", "listHaifusakiEigyosho");
        result.put("listVoidHizuke", "2019-01-01");
        result.put("listRiyu", "listRiyu");
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        Mwb031Form form = new Mwb031Form();
        // VOID日付
        String voidHizuke = "2019/01/01";
        form.setConInsertVoidHizuke(voidHizuke);
        // 配布先営業所
        form.setConInsertHaifusakiEigyoshoCd("001");
        // MAWB番号
        form.setConInsertMawbBango("78787870");
        // 航空会社コード
        AutoCompOptionBean kokuGaisha = new AutoCompOptionBean("全日空", "ANA");
        form.setConInsertKokuGaishaLetterCd(kokuGaisha);
        // 理由
        form.setConInsertRiyu("77777");
        target.setMwb031Form(form);
        target.voidTorikeshi();
        //実施結果Outを取得
        form = target.getMwb031Form();
        assertEquals(kokuGaisha, form.getConInsertKokuGaishaLetterCd());
        assertEquals("001", form.getConInsertHaifusakiEigyoshoCd());
        assertEquals("78787870", form.getConInsertMawbBango());
        assertEquals("77777", form.getConInsertRiyu());
    }

    // voidTorikeshi_正常_更新処理_更新登録_11-3
    //
    // -------------------テスト条件--------------------------
    // VOID日付=2019/01/01、配布先営業所=001、MAWB番号=78787870、航空会社コード=ANA、理由=77777
    // 登録1件
    // -----------------------------------------------------
    @Test
    public void voidTorikeshi_正常_更新処理_更新登録_14_3() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        // 登録・更新処理パラメータ
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        // 登録・更新処理ファンクション
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        List<Map<String, Object>> result = new ArrayList<>();
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_2_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        Mwb031Form form = new Mwb031Form();
        // VOID日付
        String voidHizuke = "2019/01/01";
        form.setConInsertVoidHizuke(voidHizuke);
        // 配布先営業所
        form.setConInsertHaifusakiEigyoshoCd("001");
        // MAWB番号
        form.setConInsertMawbBango("78787870");
        // 航空会社コード
        AutoCompOptionBean kokuGaisha = new AutoCompOptionBean("全日空", "ANA");
        form.setConInsertKokuGaishaLetterCd(kokuGaisha);
        // 理由
        form.setConInsertRiyu("77777");
        target.setMwb031Form(form);
        target.voidTorikeshi();
        //実施結果Outを取得
        form = target.getMwb031Form();
        assertEquals(kokuGaisha, form.getConInsertKokuGaishaLetterCd());
        assertEquals("001", form.getConInsertHaifusakiEigyoshoCd());
        assertEquals("78787870", form.getConInsertMawbBango());
        assertEquals("77777", form.getConInsertRiyu());
    }

    // searchChange_正常_補充ケース_18-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void searchChange_正常_補充ケース_18_1() throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mwb031Form form = new Mwb031Form();
        target.setMwb031Form(form);
        target.searchChange();

        // 実施結果Outを取得
        form = target.getMwb031Form();

    }

    // menuClick_正常_補充ケース_18-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_18_2() throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mwb031Form form = new Mwb031Form();
        target.setMwb031Form(form);
        target.menuClick("", "");

        // 実施結果Outを取得
        form = target.getMwb031Form();

    }

    // menuClick_正常_補充ケース_18-2-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_18_2_1() throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(1);

        // テスト実行
        Mwb031Form form = new Mwb031Form();
        target.setMwb031Form(form);
        target.menuClick("", "");

        // 実施結果Outを取得
        form = target.getMwb031Form();

    }

    // breadClumClick_正常_補充ケース_18-3
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_18_3() throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mwb031Form form = new Mwb031Form();
        target.setMwb031Form(form);
        target.breadClumClick("", 0);

        // 実施結果Outを取得
        form = target.getMwb031Form();

    }

    // breadClumClick_正常_補充ケース_18-3-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_18_3_1() throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(0);
        // テスト実行
        Mwb031Form form = new Mwb031Form();
        target.setMwb031Form(form);
        target.breadClumClick("", 0);

        // 実施結果Outを取得
        form = target.getMwb031Form();

    }

    // logoutClick_正常_補充ケース_18-4
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void logoutClick_正常_補充ケース_18_4() throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mwb031Form form = new Mwb031Form();
        target.setMwb031Form(form);
        target.logoutClick();

        // 実施結果Outを取得
        form = target.getMwb031Form();

    }

    // displayChange_正常_補充ケース_18-5
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void displayChange_正常_補充ケース_18_5() throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mwb031Form form = new Mwb031Form();
        target.setMwb031Form(form);
        target.displayChange();

        // 実施結果Outを取得
        form = target.getMwb031Form();

    }

    // displayChange_正常_補充ケース_18-5_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void displayChange_正常_補充ケース_18_5_1() throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mwb031Form form = new Mwb031Form();
        target.setMwb031Form(form);
        form.setConSelectSagyoKubun("1");
        target.displayChange();

        // 実施結果Outを取得
        form = target.getMwb031Form();

    }

    /**
     * 2_1検索結果
     *
     * @param i 件数
     * @return 検索結果
     */
    private Map<String, Object> createRecMapFor_2_1(int i) {
        Map recMap = new HashMap();
        recMap.put("listKokuGaisha", "listKokuGaisha" + i);
        recMap.put("listMawbBango", "listMawbBango" + i);
        recMap.put("listHakkenEigyosho", "listHakkenEigyosho" + i);
        String conTekiyobi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        recMap.put("listHaifusakiEigyosho", "listHaifusakiEigyosho" + i);
        recMap.put("listVoidHizuke", "2019-01-01");
        recMap.put("listRiyu", "listRiyu" + i);
        return recMap;
    }

    private void assertForRecList_2_1(Mwb031Form form) {
        int i = 0;
        assertEquals(1, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listKokuGaisha" + i, rec.get("listKokuGaisha"));
            assertEquals("listMawbBango" + i, rec.get("listMawbBango"));
            assertEquals("listHakkenEigyosho" + i, rec.get("listHakkenEigyosho"));
            assertEquals("listHaifusakiEigyosho" + i, rec.get("listHaifusakiEigyosho"));
            assertEquals("2019-01-01", rec.get("listVoidHizuke"));
            assertEquals("listRiyu" + i, rec.get("listRiyu"));
            i++;
        }
    }

    /**
     * パラメータの検証
     *
     * @param form 検索結果
     */
    private void assertForRecList_2_2(Mwb031Form form) {
        int i = 0;
        assertEquals(2, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listKokuGaisha" + i, rec.get("listKokuGaisha"));
            assertEquals("listMawbBango" + i, rec.get("listMawbBango"));
            assertEquals("listHakkenEigyosho" + i, rec.get("listHakkenEigyosho"));
            assertEquals("listHaifusakiEigyosho" + i, rec.get("listHaifusakiEigyosho"));
            assertEquals("2019-01-01", rec.get("listVoidHizuke"));
            assertEquals("listRiyu" + i, rec.get("listRiyu"));
            i++;
        }
    }

}
