package jp.co.kintetsuls.beans.mst;

import java.io.IOException;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.forms.mst.Mst211Form;
import jp.co.kintetsuls.utils.FlashUtil;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import org.junit.Assert;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * 車両マスタテスト
 *
 * @author 馬雷 (MBP)
 * @version 2019/1/24 新規作成
 */
public class Mst211BeanTest {

    // テストTarget
    @InjectMocks
    private Mst211Bean target;

    // Mockitoオブジェクト
    @Mock
    private FileBean fileBean;
    @Mock
    private AutoCompleteViewBean autoCompleteViewBean;
    @Mock
    private AutoCompleteBean autoCompleteBean;
    @Mock
    private MasterInfoBean masterInfo;
    @Mock
    private MessagePropertyBean messageProperty;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosai;
    @Mock
    private SearchHelpBean searchHelpBean;
    @Mock
    private AuthorityConfBean authConfBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private MessagePropertyBean messagePropertyBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosaiBean;
    @Mock
    private ListCheckBean listCheckBean;
    @Mock
    private FlashUtil flashUtil;

    public Mst211BeanTest() {
    }

    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() {
    }

    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[not null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst211Form mst211Form = new Mst211Form();

        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //前画面情報[not null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst211Form);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        Map<String, Object> shashu = createShashuMapFor_1_1();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(shashu));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst211Form form = new Mst211Form();

        form.setShashu(shashu);
        target.setMst211Form(form);
        // 戻ってきた場合、再検索を実施する。
        target.init("", "MST031_SCREEN", true);

        //実施結果Outを取得
        form = target.getMst211Form();
        String title = target.getTITLE();
        String url = target.getUrl();
        BreadCrumbBean breadBean = target.getBreadBean();
        AutoCompleteViewBean autoCompleteViewBean = target.getAutoCompleteViewBean();
        AuthorityConfBean authorityConfBean = target.getAuthConfBean();
        FileBean fileBean = target.getFileBean();
        MessagePropertyBean messagePropertyBean = target.getMessageProperty();
        PageCommonBean pageCommonBean = target.getPageCommon();
        SearchHelpBean searchHelpBean = target.getSearchHelpBean();
        RirekiSyosaiBean rirekiSyosaiBean = target.getRirekiSyosai();
        ListCheckBean listCheckBean = target.getListCheckBean();
        Map<String, Object> rirekiSearchKey = target.getRirekiSearchKey();
        List<MessageModuleBean> msgList = target.getMsgList();
        target.setBreadBean(breadBean);
        target.setAutoCompleteViewBean(autoCompleteViewBean);
        target.setAuthConfBean(authorityConfBean);
        target.setFileBean(fileBean);
        target.setMessageProperty(messagePropertyBean);
        target.setPageCommon(pageCommonBean);
        target.setSearchHelpBean(searchHelpBean);
        target.setRirekiSyosai(rirekiSyosaiBean);
        target.setListCheckBean(listCheckBean);
        target.setRirekiSearchKey(rirekiSearchKey);
        target.setMsgList(msgList);

        // 実行時に渡すパラメータの検証
        assertEquals("mst211Form", keyCaptor_1.getValue());
        assertEquals("mst211-get-shashu", functionCodeCaptor_2.getValue());
        //想定通りに再検索を実施する。
        assertEquals("search_mst211", keyCaptor_2.getValue());
    }

    // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 前画面パラメータ[営業所コード = "001",世代検索条件 = "現在適用",適用日 = "",車両NO = "00001",車両名称 = "test1",
    // 未使用期間（年） = "2",未使用期間（月） = "10",適用名 = "test1",削除のみ検索選択しない]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2() throws IllegalAccessException, InvocationTargetException,
            InstantiationException {
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

        // Mockitoオブジェクトの予想return値設定
        Mst211Form mst211Form = new Mst211Form();
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        Map<String, Object> shashu = createShashuMapFor_1_1();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(shashu));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        // 前画面パラメータ[営業所コード = "001",世代検索条件 = "適用日指定",適用日 = "2019/01/01",車両NO = "00001",車両名称 = "test1",
        // 未使用期間（年） = "2",未使用期間（月） = "10",適用名 = "test1",削除のみ検索選択しない]
        AutoCompOptionBean conEigyoushoCd = new AutoCompOptionBean();
        String[] conSedaiKensaku = {"03"};
        conEigyoushoCd.setValue("123");
        Date tekiyoBi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoBi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst211BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        List<String> sakujoNomi = new ArrayList<>();
        mst211Form.setConEigyoushoCd(conEigyoushoCd);
        mst211Form.setConSedaiKensakuJoken(conSedaiKensaku);
        mst211Form.setConTekiyoBi(tekiyoBi);
        mst211Form.setConSharyoNo("00001");
        mst211Form.setConSharyoMeisho("test1");
        mst211Form.setConMishiyoKikanNen("2");
        mst211Form.setConMishiyoKikanGetu("10");
        mst211Form.setConTekiyoMei("test1");
        mst211Form.setConSakujonomiKensaku(sakujoNomi);
        mst211Form.setShashu(shashu);
        // Mockitoオブジェクトの予想return値設定
        Flash flash = new FlashKls();
        // 前画面パラメータ[営業所コード = "001",世代検索条件 = "現在適用",適用日 = "",車両NO = "00001",車両名称 = "test1",
        // 未使用期間（年） = "2",未使用期間（月） = "10",適用名 = "test1",削除のみ検索 = 0]
        flash.put("mst211Form", mst211Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());

        //テスト実行
        Mst211Form form = new Mst211Form();
        target.setMst211Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID", "", false);

        //実施結果Outを取得
        form = target.getMst211Form();

        //想定通りに再検索を実施する。
        assertEquals("search_mst211", keyCaptor_2.getValue());
        assertEquals("123", form.getConEigyoushoCd().getValue());
        assertEquals(tekiyoBi, form.getConTekiyoBi());
        assertEquals("00001", form.getConSharyoNo());
        assertEquals("test1", form.getConSharyoMeisho());
        assertEquals("2", form.getConMishiyoKikanNen());
        assertEquals("10", form.getConMishiyoKikanGetu());
        assertEquals("test1", form.getConTekiyoMei());
        Assert.assertArrayEquals(conSedaiKensaku, form.getConSedaiKensakuJoken());
        assertEquals(sakujoNomi, form.getConSakujonomiKensaku());
    }

    // init_正常_初期処理_1-2_1
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[都道府県 = 01,仕向地名 = 地名23,削除済のみ検索 = null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2_1() throws IllegalAccessException, InvocationTargetException,
            InstantiationException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

        // Mockitoオブジェクトの予想return値設定
        Mst211Form Mst211Form = new Mst211Form();
        //前回検索パラメータ[営業所コード = '01']
        AutoCompOptionBean conEigyoushoCd = new AutoCompOptionBean();
        conEigyoushoCd.setValue("01");
        Mst211Form.setConEigyoushoCd(conEigyoushoCd);
        // Mockitoオブジェクトの予想return値設定
        Flash flash = new FlashKls();
        //前画面パラメータ[都道府県 = 01,仕向地名 = 地名23,削除済のみ検索 = null]
        flash.put("Mst211Form", null);
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        Map<String, Object> shashu = createShashuMapFor_1_1();
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(shashu));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());

        //テスト実行
        Mst211Form form = new Mst211Form();
        target.setMst211Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID", "", false);

        //実施結果Outを取得
        form = target.getMst211Form();

        //想定通りに再検索を実施する。
        assertEquals(null, form.getConSakujonomiKensaku());
    }

    // init_正常_初期処理_1-3
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        //前画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(null);
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        Map<String, Object> shashu = createShashuMapFor_1_1();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(shashu));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        //テスト実行
        Mst211Form form = new Mst211Form();
        target.setMst211Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID", "", false);

        //実施結果Outを取得
        form = target.getMst211Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst211Form", keyCaptor_1.getValue());
        //想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null, form.getSearchResult());
    }

    // init_異常_初期処理_1_4
    //
    // -------------------テスト条件--------------------------
    // 車種取得異常処理
    // -----------------------------------------------------
    @Test
    public void init_異常_初期処理_1_4() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        //前画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(null);
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        Map<String, Object> shashu = createShashuMapFor_1_1();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(shashu));
        doThrow(IOException.class).when(pageCommonBean).getDBInfo(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture());
        //テスト実行
        Mst211Form form = new Mst211Form();
        target.setMst211Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID", "", false);

        //実施結果Outを取得
        form = target.getMst211Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst211Form", keyCaptor_1.getValue());
        //想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null, form.getSearchResult());

    }

    // init_正常_初期処理_1-3_1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> paramsCaptor_2 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        // 前画面情報[null]
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        Map<String, Object> shashu = createShashuMapFor_1_1();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(shashu));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_2.capture(), functionCodeCaptor_3.capture())).thenReturn(serviceInterfaceBean);
        doThrow(IllegalAccessException.class).when(pageCommonBean).getPageInfo(keyCaptor_1.capture());

        // テスト実行
        Mst211Form form = new Mst211Form();
        target.setMst211Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID", "", false);

        // 実施結果Outを取得
        form = target.getMst211Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst211Form", keyCaptor_1.getValue());
        // 想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null, form.getSearchResult());
    }

    // search_正常_検索処理_2-1
    //
    // -------------------テスト条件--------------------------
    // 車両マスタ検索結果一覧取得
    // 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 0; i++) {
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        //テスト実行
        Mst211Form form = new Mst211Form();
        AutoCompOptionBean conEigyoushoCd = new AutoCompOptionBean();
        conEigyoushoCd.setValue("123");
        String[] conSedaiKensaku = {"03"};
        Date tekiyoBi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoBi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst211BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        List<String> sakujoNomi = new ArrayList<>();
        sakujoNomi.add("0");
        form.setConEigyoushoCd(conEigyoushoCd);
        form.setConSedaiKensakuJoken(conSedaiKensaku);
        form.setConTekiyoBi(tekiyoBi);
        form.setConSharyoNo("00001");
        form.setConSharyoMeisho("test1");
        form.setConMishiyoKikanNen("2");
        form.setConMishiyoKikanGetu("10");
        form.setConTekiyoMei("test1");
        form.setConSakujonomiKensaku(sakujoNomi);
        target.setMst211Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst211Form();

        // 実行時に渡すパラメータの検証
        assertEquals("123", paramsCaptor_1.getValue().get("conEigyoushoCd"));
        assertEquals(conSedaiKensaku, paramsCaptor_1.getValue().get("conSedaiKensakuJoken"));
        assertEquals(tekiyoBi, paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals("00001", paramsCaptor_1.getValue().get("conSharyoNo"));
        assertEquals("test1", paramsCaptor_1.getValue().get("conSharyoMeisho"));
        assertEquals("test1", paramsCaptor_1.getValue().get("conTekiyoMei"));
        assertEquals("1", paramsCaptor_1.getValue().get("conSakujonomiKensaku"));
        assertEquals("mst211-get-sharyo-detail", functionCodeCaptor_2.getValue());
        //想定通りに車両マスタ一覧を表示されること
        assertForRecList_2_1(form);
    }

    // search_正常_検索処理_2-2
    //
    // -------------------テスト条件--------------------------
    // 車両マスタ検索結果一覧取得
    // 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_2() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 0; i++) {
            result.add(createRecMapFor_1_2(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        //テスト実行
        Mst211Form form = new Mst211Form();
        AutoCompOptionBean conEigyoushoCd = new AutoCompOptionBean();
        conEigyoushoCd.setValue("123");
        String[] conSedaiKensaku = {"03"};
        Date tekiyoBi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoBi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst211BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        List<String> sakujoNomi = new ArrayList<>();
        sakujoNomi.add("0");
        form.setConEigyoushoCd(conEigyoushoCd);
        form.setConSedaiKensakuJoken(conSedaiKensaku);
        form.setConTekiyoBi(tekiyoBi);
        form.setConSharyoNo("00001");
        form.setConSharyoMeisho("test1");
        form.setConMishiyoKikanNen("2");
        form.setConMishiyoKikanGetu("10");
        form.setConTekiyoMei("test1");
        form.setConSakujonomiKensaku(sakujoNomi);
        target.setMst211Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst211Form();

        // 実行時に渡すパラメータの検証
        assertEquals("123", paramsCaptor_1.getValue().get("conEigyoushoCd"));
        assertEquals(conSedaiKensaku, paramsCaptor_1.getValue().get("conSedaiKensakuJoken"));
        assertEquals(tekiyoBi, paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals("00001", paramsCaptor_1.getValue().get("conSharyoNo"));
        assertEquals("test1", paramsCaptor_1.getValue().get("conSharyoMeisho"));
        assertEquals("test1", paramsCaptor_1.getValue().get("conTekiyoMei"));
        assertEquals("1", paramsCaptor_1.getValue().get("conSakujonomiKensaku"));
        assertEquals("mst211-get-sharyo-detail", functionCodeCaptor_2.getValue());
        //想定通りに車両マスタ一覧を表示されること
        assertForRecList_2_2(form);
    }

    // search_正常_検索処理_2-3
    //
    // -------------------テスト条件--------------------------
    // 車両マスタ検索結果一覧取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_3() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得 取得件数 = 2
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst211Form form = new Mst211Form();
        AutoCompOptionBean conEigyoushoCd = new AutoCompOptionBean();
        conEigyoushoCd.setValue("123");
        String[] conSedaiKensaku = {"03"};
        Date tekiyoBi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoBi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst211BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        form.setConEigyoushoCd(conEigyoushoCd);
        form.setConSedaiKensakuJoken(conSedaiKensaku);
        form.setConTekiyoBi(tekiyoBi);
        form.setConSharyoNo("00001");
        form.setConSharyoMeisho("test1");
        form.setConMishiyoKikanGetu("10");
        form.setConTekiyoMei("test1");
        target.setMst211Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst211Form();

        // 実行時に渡すパラメータの検証
        assertEquals("123", paramsCaptor_1.getValue().get("conEigyoushoCd"));
        assertEquals(conSedaiKensaku, paramsCaptor_1.getValue().get("conSedaiKensakuJoken"));
        assertEquals(tekiyoBi, paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals("00001", paramsCaptor_1.getValue().get("conSharyoNo"));
        assertEquals("test1", paramsCaptor_1.getValue().get("conSharyoMeisho"));
        assertEquals("test1", paramsCaptor_1.getValue().get("conTekiyoMei"));
        assertEquals("10", paramsCaptor_1.getValue().get("conMishiyoKikanGetu"));
        assertEquals("0", paramsCaptor_1.getValue().get("conSakujonomiKensaku"));
        assertEquals("mst211-get-sharyo-detail", functionCodeCaptor_2.getValue());
        //想定通りに車両マスタ一覧を表示されること
        assertForRecList_2_4(form);
    }

    // search_異常_検索処理_2-3
    //
    // -------------------テスト条件--------------------------
    // 車両マスタ検索結果一覧取得 取得件数 = 0
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_3() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得 取得件数 = 0
        List<Map<String, String>> result = new ArrayList<>();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        doThrow(IOException.class).when(pageCommonBean).getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture());
        //テスト実行
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        Mst211Form form = new Mst211Form();
        target.setMst211Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst211Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null, paramsCaptor_1.getValue().get("conEigyoushoCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSedaiKensakuJoken"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSharyoNo"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSharyoMeisho"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoMei"));
        assertEquals("0", paramsCaptor_1.getValue().get("conSakujonomiKensaku"));
        assertEquals("mst211-get-sharyo-detail", functionCodeCaptor_2.getValue());
        //想定通りに・一覧は表示しない（ヘッダーのみ） 
    }
    
    // search_異常_検索処理_2-3-1
    //
    // -------------------テスト条件--------------------------
    // 適用開始日フォマート化異常あり
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_3_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得 取得件数 = 2
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            result.add(createRecMapFor_2_3_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        //テスト実行
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        Mst211Form form = new Mst211Form();
        target.setMst211Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst211Form();

        //想定通りに・一覧は表示しない（ヘッダーのみ） 
    }

    // getRecordCount_正常_件数取得処理_2-4_1
    //
    // -------------------テスト条件--------------------------
    // 車両マスタ検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_4_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 車両マスタ検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        //テスト実行
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        Mst211Form form = new Mst211Form();
        AutoCompOptionBean conEigyoushoCd = new AutoCompOptionBean();
        conEigyoushoCd.setValue("123");
        String[] conSedaiKensaku = {"03"};
        form.setConEigyoushoCd(conEigyoushoCd);
        form.setConSedaiKensakuJoken(conSedaiKensaku);
        target.setMst211Form(form);
        target.getRecordCount();

        //実施結果Outを取得
        form = target.getMst211Form();

        // 実行時に渡すパラメータの検証
        assertEquals(conSedaiKensaku, paramsCaptor_1.getValue().get("conSedaiKensakuJoken"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSharyoNo"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSharyoMeisho"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoMei"));
        assertEquals("0", paramsCaptor_1.getValue().get("conSakujonomiKensaku"));
        assertEquals("mst211-get-sharyo-count", functionCodeCaptor_2.getValue());
        //想定通りに正常にCountを実施されること
        assertEquals("123", form.getConEigyoushoCd().getValue());
    }

    // getRecordCount_正常_件数取得処理_2-4_2
    //
    // -------------------テスト条件--------------------------
    // 車両マスタ検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_4_2() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 車両マスタ検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        //テスト実行
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        Mst211Form form = new Mst211Form();
        AutoCompOptionBean conEigyoushoCd = new AutoCompOptionBean();
        conEigyoushoCd.setValue("123");
        List sakujo = new ArrayList();
        sakujo.add("0");
        form.setConEigyoushoCd(conEigyoushoCd);
        form.setConSakujonomiKensaku(sakujo);
        target.setMst211Form(form);
        target.getRecordCount();

        //実施結果Outを取得
        form = target.getMst211Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null, paramsCaptor_1.getValue().get("conSedaiKensakuJoken"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSharyoNo"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSharyoMeisho"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoMei"));
        assertEquals("1", paramsCaptor_1.getValue().get("conSakujonomiKensaku"));
        assertEquals("mst211-get-sharyo-count", functionCodeCaptor_2.getValue());
        //想定通りに正常にCountを実施されること
        assertEquals("123", form.getConEigyoushoCd().getValue());
    }

    // getRecordCount_正常_件数取得処理_2-4_3
    //
    // -------------------テスト条件--------------------------
    // 仕向地検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_4_3() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 車両マスタ検索件数取得 取得件数 = 2
        int result = 2;
        List<Map<String, String>> result2 = new ArrayList<>();
        for (int i = 0; i <= 0; i++) {
            result2.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result2));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        //テスト実行
        Mst211Form form = new Mst211Form();
        AutoCompOptionBean conEigyoushoCd = new AutoCompOptionBean();
        conEigyoushoCd.setValue("123");
        form.setConEigyoushoCd(conEigyoushoCd);
        target.setMst211Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst211Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null, paramsCaptor_1.getValue().get("conSedaiKensakuJoken"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSharyoNo"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSharyoMeisho"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoMei"));
        assertEquals("0", paramsCaptor_1.getValue().get("conSakujonomiKensaku"));
        assertEquals("mst211-get-sharyo-detail", functionCodeCaptor_2.getValue());
        //想定通りに正常にCountを実施されること
        assertEquals("123", form.getConEigyoushoCd().getValue());
    }

    // clear_正常_クリア処理_3-1
    //
    // -------------------テスト条件--------------------------
    // 検索条件と検索結果がある
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_1() throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst211Form form = new Mst211Form();
        // 検索条件と検索結果がある
        AutoCompOptionBean conEigyoushoCd = new AutoCompOptionBean();
        conEigyoushoCd.setValue("123");
        String[] conSedaiKensaku = {"01", "02"};
        Date tekiyoBi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoBi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst211BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        List<String> sakujoNomi = new ArrayList<>();
        sakujoNomi.add("0");
        form.setConEigyoushoCd(conEigyoushoCd);
        form.setConSedaiKensakuJoken(conSedaiKensaku);
        form.setConTekiyoBi(tekiyoBi);
        form.setConSharyoNo("00001");
        form.setConSharyoMeisho("test1");
        form.setConMishiyoKikanNen("2");
        form.setConMishiyoKikanGetu("10");
        form.setConTekiyoMei("test1");
        form.setConSakujonomiKensaku(sakujoNomi);

        target.setMst211Form(form);
        target.clear();

        //実施結果Outを取得
        form = target.getMst211Form();

        //想定通りに正常にClearを実施されること
        assertEquals(null, form.getConEigyoushoCd());
        Assert.assertArrayEquals(conSedaiKensaku, form.getConSedaiKensakuJoken());
        assertEquals(null, form.getConTekiyoBi());
        assertEquals(null, form.getConSharyoNo());
        assertEquals(null, form.getConSharyoMeisho());
        assertEquals(null, form.getConMishiyoKikanNen());
        assertEquals(null, form.getConMishiyoKikanGetu());
    }

    // clear_正常_クリア処理_3-2
    //
    // -------------------テスト条件--------------------------
    // 検索条件がある、検索結果がない
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_2() throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst211Form form = new Mst211Form();
        target.setMst211Form(form);
        target.clear();

        //実施結果Outを取得
        form = target.getMst211Form();
        String[] sedaiKensaku = {"01", "02"};
        form.setConSedaiKensakuJoken(sedaiKensaku);

        //想定通りに正常にClearを実施されること
        assertEquals(null, form.getConEigyoushoCd());
        Assert.assertArrayEquals(sedaiKensaku, form.getConSedaiKensakuJoken());
        assertEquals(null, form.getConTekiyoBi());
        assertEquals(null, form.getConSharyoNo());
        assertEquals(null, form.getConSharyoMeisho());
        assertEquals(null, form.getConMishiyoKikanNen());
        assertEquals(null, form.getConMishiyoKikanGetu());
    }

    // upload_正常_アップロード_4_1
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void upload_正常_アップロード_4_1() throws IllegalAccessException, InvocationTargetException {
        ArgumentCaptor<String> urlCaptor_1 = ArgumentCaptor.forClass(String.class);
        //テスト実行
        Mst211Form form = new Mst211Form();
        Flash flash = new FlashKls();
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        when(flashUtil.getPageParam()).thenReturn(flash);
        target.upload();
    }

    // getHeader_正常_ダウンロード_5-1
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void getHeader_正常_ダウンロード_5_1() throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst211Form form = new Mst211Form();
        target.setMst211Form(form);
        List<CSVDto> dto = target.getHeader();

        //実施結果Outを取得
        form = target.getMst211Form();
        String[] sedaiKensaku = {"01", "02"};
        form.setConSedaiKensakuJoken(sedaiKensaku);

        // 実行時に渡すパラメータの検証
        //想定通りに正常にCSVのHeaderを設定されること
        assertEquals(null, form.getConEigyoushoCd());

        Assert.assertArrayEquals(sedaiKensaku, form.getConSedaiKensakuJoken());
        assertEquals(null, form.getConTekiyoBi());
        assertEquals(null, form.getConSharyoNo());
        assertEquals(null, form.getConSharyoMeisho());
        assertEquals(null, form.getConMishiyoKikanNen());
        assertEquals(null, form.getConMishiyoKikanGetu());
        assertEquals("車両No", dto.get(0).getTitle());
        assertEquals("listSharyoNo", dto.get(0).getName());
        assertEquals("車両名称", dto.get(1).getTitle());
        assertEquals("listSharyoMeisho", dto.get(1).getName());
        assertEquals("ナンバープレート", dto.get(2).getTitle());
        assertEquals("listNumberPlate", dto.get(2).getName());
        assertEquals("適用開始日", dto.get(3).getTitle());
        assertEquals("listTekiyoKaishibi", dto.get(3).getName());
        assertEquals("適用終了日(チェックボックス)", dto.get(4).getTitle());
        assertEquals("listTekiyoShuryobiCheckBox", dto.get(4).getName());
        assertEquals("適用終了日(テキストボックス)", dto.get(5).getTitle());
        assertEquals("listTekiyoShuryobiTextBox", dto.get(5).getName());
        assertEquals("車種", dto.get(6).getTitle());
        assertEquals("listShashu", dto.get(6).getName());
        assertEquals("車両一覧表示", dto.get(7).getTitle());
        assertEquals("listSharyoIchiranHyoji", dto.get(7).getName());
        assertEquals("仕入先コード", dto.get(8).getTitle());
        assertEquals("listShiiresakiCd", dto.get(8).getName());
        assertEquals("仕入先名称", dto.get(9).getTitle());
        assertEquals("listShiiresakiMei", dto.get(9).getName());
        assertEquals("適用名", dto.get(10).getTitle());
        assertEquals("listTekiyoMei", dto.get(10).getName());
        assertEquals("最終使用日", dto.get(11).getTitle());
        assertEquals("listSaishuShiyobi", dto.get(11).getName());
    }

    // beforeDown_正常_ダウンロード_5-2
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=2件
    // -----------------------------------------------------
    @Test
    public void beforeDown_正常_ダウンロード_5_2() throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst211Form form = new Mst211Form();
        target.setMst211Form(form);
        try {
            target.beforeDown("testComment");
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(Mst211BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        //実施結果Outを取得
        form = target.getMst211Form();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にダウンロード理由を記録すること
        assertEquals(null, form.getConEigyoushoCd());
    }

    // update_異常_更新処理_新規登録_11-1
    //
    // -------------------テスト条件--------------------------
    // 営業所コードが営業所マスタに存在しない
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_新規登録_11_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 営業所コードが営業所マスタに存在しない[COME0039]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0039", "eigyoshoCd");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()
        )).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),
                summaryCaptor_4.capture(), detailCaptor_5.capture(), tableNameCaptor_6.capture());

        //テスト実行
        Mst211Form form = new Mst211Form();

        List<Map<String, Object>> result = new ArrayList<>();

        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        AutoCompOptionBean conEigyoushoCd = new AutoCompOptionBean();
        conEigyoushoCd.setValue("123");
        form.setConEigyoushoCd(conEigyoushoCd);
        form.setSelectedSearchResult(result);

        target.setMst211Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst211Form();

        Date tekiyoBi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoBi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst211BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("No0", paramsCaptor_1_Param.get("listSharyoNo"));
        assertEquals("Meisho0", paramsCaptor_1_Param.get("listSharyoMeisho"));
        assertEquals("Plate0", paramsCaptor_1_Param.get("listNumberPlate"));
        assertEquals(tekiyoBi, paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals(1, paramsCaptor_1_Param.get("listTekiyoShuryobiCheckBox"));
        assertEquals(tekiyoBi, paramsCaptor_1_Param.get("listTekiyoShuryobiTextBox"));
        assertEquals("listShashu0", paramsCaptor_1_Param.get("listShashu"));
        assertEquals("Hyoji0", paramsCaptor_1_Param.get("listSharyoIchiranHyoji"));
        assertEquals("00", paramsCaptor_1_Param.get("listShiiresakiCd"));
        assertEquals("Mei0", paramsCaptor_1_Param.get("listShiiresakiMei"));
        assertEquals("Mei0", paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals(0, paramsCaptor_1_Param.get("listSaishuShiyobi"));
        assertEquals("mst211-insert-update-check", functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0039）
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0039", summaryCaptor_4.getValue());
    }

    // update_異常_更新処理_新規登録_11-2
    //
    // -------------------テスト条件--------------------------
    // 仕入先コードが仕入先マスタに存在しない
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_新規登録_11_2() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 営業所コードが営業所マスタに存在しない[COME0039]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0039", "shiiresahiCd");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture(), tableNameCaptor_6.capture());

        //テスト実行
        Mst211Form form = new Mst211Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        AutoCompOptionBean conEigyoushoCd = new AutoCompOptionBean();
        conEigyoushoCd.setValue("000");
        form.setConEigyoushoCd(conEigyoushoCd);
        target.setMst211Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst211Form();

        Date tekiyoBi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoBi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst211BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("No0", paramsCaptor_1_Param.get("listSharyoNo"));
        assertEquals("Meisho0", paramsCaptor_1_Param.get("listSharyoMeisho"));
        assertEquals("Plate0", paramsCaptor_1_Param.get("listNumberPlate"));
        assertEquals(tekiyoBi, paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals(1, paramsCaptor_1_Param.get("listTekiyoShuryobiCheckBox"));
        assertEquals(tekiyoBi, paramsCaptor_1_Param.get("listTekiyoShuryobiTextBox"));
        assertEquals("listShashu0", paramsCaptor_1_Param.get("listShashu"));
        assertEquals("Hyoji0", paramsCaptor_1_Param.get("listSharyoIchiranHyoji"));
        assertEquals("00", paramsCaptor_1_Param.get("listShiiresakiCd"));
        assertEquals("Mei0", paramsCaptor_1_Param.get("listShiiresakiMei"));
        assertEquals("Mei0", paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals(0, paramsCaptor_1_Param.get("listSaishuShiyobi"));
        assertEquals("mst211-insert-update-check", functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0039）
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0039", summaryCaptor_4.getValue());
    }

    // update_異常_更新処理_新規登録_11-3
    //
    // -------------------テスト条件--------------------------
    // 営業所コード、車両NO、適用開始日が車両マスタに既に存在し
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_新規登録_11_3() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 営業所コード、車両NO、適用開始日が車両マスタに既に存在し[MSTE0057]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0057", "");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture(), tableNameCaptor_6.capture());

        //テスト実行
        Mst211Form form = new Mst211Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        AutoCompOptionBean conEigyoushoCd = new AutoCompOptionBean();
        conEigyoushoCd.setValue("000");
        form.setConEigyoushoCd(conEigyoushoCd);
        target.setMst211Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst211Form();

        Date tekiyoBi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoBi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst211BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("No0", paramsCaptor_1_Param.get("listSharyoNo"));
        assertEquals("Meisho0", paramsCaptor_1_Param.get("listSharyoMeisho"));
        assertEquals("Plate0", paramsCaptor_1_Param.get("listNumberPlate"));
        assertEquals(tekiyoBi, paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals(1, paramsCaptor_1_Param.get("listTekiyoShuryobiCheckBox"));
        assertEquals(tekiyoBi, paramsCaptor_1_Param.get("listTekiyoShuryobiTextBox"));
        assertEquals("listShashu0", paramsCaptor_1_Param.get("listShashu"));
        assertEquals("Hyoji0", paramsCaptor_1_Param.get("listSharyoIchiranHyoji"));
        assertEquals("00", paramsCaptor_1_Param.get("listShiiresakiCd"));
        assertEquals("Mei0", paramsCaptor_1_Param.get("listShiiresakiMei"));
        assertEquals("Mei0", paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals(0, paramsCaptor_1_Param.get("listSaishuShiyobi"));
        assertEquals("mst211-insert-update-check", functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0039）
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("MSTE0057", summaryCaptor_4.getValue());
    }

    // update_異常_更新処理_更新登録_11-4
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_新規登録_11_4() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messageProperty.createMessageModule(levelCaptor_1.capture(), summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        //テスト実行
        // 行選択チェック選択 = 0
        List<Map<String, Object>> result = null;
        Mst211Form form = new Mst211Form();
        form.setSelectedSearchResult(result);
        target.setMst211Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst211Form();

        //想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("ERROR", levelCaptor_1.getValue());
        assertEquals("COME0029", summaryCaptor_2.getValue());
    }

    // update_異常_更新処理_更新登録_11-5
    //
    // -------------------テスト条件--------------------------
    // 一覧に必須項目はnull場合
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_新規登録_11_5() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Boolean> datasCaptor_3 = ArgumentCaptor.forClass(Boolean.class);
        ArgumentCaptor<List> checksCaptor_4 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<List> checksCaptor_5 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定

        //テスト実行
        Mst211Form form = new Mst211Form();
        // 行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        form.setSelectedSearchResult(result);
        target.setMst211Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst211Form();
    }

    // update_異常_更新処理_更新登録_11-6_1
    //
    // -------------------テスト条件--------------------------
    // 適用終了日(チェックボックス)を選択する、適用終了日(テキストボックス)を入力しないの場合
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_新規登録_11_6_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(), summaryCaptor_4.capture());

        //テスト実行
        Mst211Form form = new Mst211Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_11_6_1(i));
        }
        form.setSelectedSearchResult(result);
        AutoCompOptionBean conEigyoushoCd = new AutoCompOptionBean();
        conEigyoushoCd.setValue("000");
        form.setConEigyoushoCd(conEigyoushoCd);
        target.setMst211Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst211Form();

        // 実行時に渡すパラメータの検証
        //想定通りに正常終了メッセージ（メッセージID：COMI0007）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("MSTE0058", summaryCaptor_4.getValue());
    }

    // update_異常_更新処理_更新登録_11-6_1
    //
    // -------------------テスト条件--------------------------
    // 適用終了日(チェックボックス)を選択しな、適用終了日(テキストボックス)を入力するの場合
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_新規登録_11_6_2() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        doNothing().when(messageProperty).message(levelCaptor_3.capture(), summaryCaptor_4.capture());

        //テスト実行
        Mst211Form form = new Mst211Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_11_6_2(i));
        }
        form.setSelectedSearchResult(result);
        AutoCompOptionBean conEigyoushoCd = new AutoCompOptionBean();
        conEigyoushoCd.setValue("000");
        form.setConEigyoushoCd(conEigyoushoCd);
        target.setMst211Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst211Form();

        // 実行時に渡すパラメータの検証
        //想定通りに正常終了メッセージ（メッセージID：COMI0007）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("MSTE0059", summaryCaptor_4.getValue());
    }

    // update_異常_更新処理_更新登録_11-6_3
    //
    // -------------------テスト条件--------------------------
    // 適用終了日(チェックボックス)を選択しな、適用終了日(テキストボックス)を入力するの場合
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_新規登録_11_7() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(), summaryCaptor_4.capture());

        //テスト実行
        Mst211Form form = new Mst211Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_11_6_3(i));
        }
        form.setSelectedSearchResult(result);
        AutoCompOptionBean conEigyoushoCd = new AutoCompOptionBean();
        conEigyoushoCd.setValue("000");
        form.setConEigyoushoCd(conEigyoushoCd);
        target.setMst211Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst211Form();

        // 実行時に渡すパラメータの検証
        //想定通りに正常終了メッセージ（メッセージID：COMI0007）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("MSTE0058", summaryCaptor_4.getValue());
    }

    // update_正常_更新処理_更新登録_11-5
    //
    // -------------------テスト条件--------------------------
    // 営業所コードと仕入先コードは存在の場合
    // -----------------------------------------------------
    @Test
    public void update_正常_更新処理_新規登録_11_8() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture());

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 2; i++) {
            resultS.add(createRecMapFor_1_1(i));
        }
        //テスト実行
        Mst211Form form = new Mst211Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        form.setSelectedSearchResult(result);
        AutoCompOptionBean conEigyoushoCd = new AutoCompOptionBean();
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        conEigyoushoCd.setValue("000");
        form.setConEigyoushoCd(conEigyoushoCd);
        target.setMst211Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst211Form();

        Date tekiyoBi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoBi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst211BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("No0", paramsCaptor_1_Param.get("listSharyoNo"));
        assertEquals("Meisho0", paramsCaptor_1_Param.get("listSharyoMeisho"));
        assertEquals("Plate0", paramsCaptor_1_Param.get("listNumberPlate"));
        assertEquals(tekiyoBi, paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals(1, paramsCaptor_1_Param.get("listTekiyoShuryobiCheckBox"));
        assertEquals(tekiyoBi, paramsCaptor_1_Param.get("listTekiyoShuryobiTextBox"));
        assertEquals("listShashu0", paramsCaptor_1_Param.get("listShashu"));
        assertEquals("Hyoji0", paramsCaptor_1_Param.get("listSharyoIchiranHyoji"));
        assertEquals("00", paramsCaptor_1_Param.get("listShiiresakiCd"));
        assertEquals("Mei0", paramsCaptor_1_Param.get("listShiiresakiMei"));
        assertEquals("Mei0", paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals(0, paramsCaptor_1_Param.get("listSaishuShiyobi"));
        assertEquals("mst211-insert-update", functionCodeCaptor_2.getValue());
        //想定通りに正常終了メッセージ（メッセージID：COMI0007）を表示されること
        assertEquals("INFO", levelCaptor_3.getValue());
        assertEquals("COMI0011", summaryCaptor_4.getValue());
        assertEquals("更新", detailCaptor_5.getValue());
    }
    
    // delRows_正常_車両マスタ削除処理_12-1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 1
    // 営業所コード、車両No、適用開始日の組み合わせが、車両マスタに存在するの場合
    // -----------------------------------------------------
    @Test
    public void delRows_正常_車両マスタ削除処理_12_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_4.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture());
        //テスト実行
        Mst211Form form = new Mst211Form();
        //行選択チェック選択 = 1
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        AutoCompOptionBean conEigyoushoCd = new AutoCompOptionBean();
        conEigyoushoCd.setValue("000");
        form.setConEigyoushoCd(conEigyoushoCd);
        form.setSearchResult(result);
        form.setSelectedSearchResult(result);
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        target.setMst211Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst211Form();
        Date tekiyoBi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoBi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst211BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("No0", paramsCaptor_1_Param.get("listSharyoNo"));
        assertEquals("Meisho0", paramsCaptor_1_Param.get("listSharyoMeisho"));
        assertEquals("Plate0", paramsCaptor_1_Param.get("listNumberPlate"));
        assertEquals(tekiyoBi, paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals(1, paramsCaptor_1_Param.get("listTekiyoShuryobiCheckBox"));
        assertEquals(tekiyoBi, paramsCaptor_1_Param.get("listTekiyoShuryobiTextBox"));
        assertEquals("listShashu0", paramsCaptor_1_Param.get("listShashu"));
        assertEquals("Hyoji0", paramsCaptor_1_Param.get("listSharyoIchiranHyoji"));
        assertEquals("00", paramsCaptor_1_Param.get("listShiiresakiCd"));
        assertEquals("Mei0", paramsCaptor_1_Param.get("listShiiresakiMei"));
        assertEquals("Mei0", paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals(0, paramsCaptor_1_Param.get("listSaishuShiyobi"));
        assertEquals("mst211-delete", functionCodeCaptor_2.getValue());
        //想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること車両マスタ削除処理を行う。
        assertEquals("INFO", levelCaptor_3.getValue());
        assertEquals("COMI0011", summaryCaptor_4.getValue());
        assertEquals("削除", detailCaptor_5.getValue());
    }

    // delRows_正常_車両マスタ削除処理_12-1_2
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 2
    // 都道府県コード、仕向地名コードの組み合わせが、車両マスタに存在している
    // -----------------------------------------------------
    @Test
    public void delRows_正常_車両マスタ削除処理_12_1_2() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_4.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture());
        //テスト実行
        Mst211Form form = new Mst211Form();
        //行選択チェック選択 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        form.setSearchResult(result);
        AutoCompOptionBean conEigyoushoCd = new AutoCompOptionBean();
        conEigyoushoCd.setValue("000");
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        form.setConEigyoushoCd(conEigyoushoCd);
        form.setSelectedSearchResult(result);
        target.setMst211Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst211Form();
        Date tekiyoBi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoBi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst211BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("No0", paramsCaptor_1_Param.get("listSharyoNo"));
        assertEquals("Meisho0", paramsCaptor_1_Param.get("listSharyoMeisho"));
        assertEquals("Plate0", paramsCaptor_1_Param.get("listNumberPlate"));
        assertEquals(tekiyoBi, paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals(1, paramsCaptor_1_Param.get("listTekiyoShuryobiCheckBox"));
        assertEquals(tekiyoBi, paramsCaptor_1_Param.get("listTekiyoShuryobiTextBox"));
        assertEquals("listShashu0", paramsCaptor_1_Param.get("listShashu"));
        assertEquals("Hyoji0", paramsCaptor_1_Param.get("listSharyoIchiranHyoji"));
        assertEquals("00", paramsCaptor_1_Param.get("listShiiresakiCd"));
        assertEquals("Mei0", paramsCaptor_1_Param.get("listShiiresakiMei"));
        assertEquals("Mei0", paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals(0, paramsCaptor_1_Param.get("listSaishuShiyobi"));
        assertEquals("mst211-delete", functionCodeCaptor_2.getValue());
        //想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること車両マスタ削除処理を行う。
        assertEquals("INFO", levelCaptor_3.getValue());
        assertEquals("COMI0011", summaryCaptor_4.getValue());
        assertEquals("削除", detailCaptor_5.getValue());
    }

    // delRows_異常_車両マスタ削除処理_12-3
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // -----------------------------------------------------
    @Test
    public void delRows_異常_車両マスタ削除処理_12_2() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messageProperty.createMessageModule(levelCaptor_1.capture(), summaryCaptor_2.capture())).thenReturn(messageModuleBean);
        //テスト実行
        Mst211Form form = new Mst211Form();
        //行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        form.setSelectedSearchResult(result);
        AutoCompOptionBean conEigyoushoCd = new AutoCompOptionBean();
        conEigyoushoCd.setValue("000");
        form.setConEigyoushoCd(conEigyoushoCd);
        target.setMst211Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst211Form();

        //想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("ERROR", levelCaptor_1.getValue());
        assertEquals("COME0013", summaryCaptor_2.getValue());
    }

    // delRows_異常_車両マスタ削除処理_12-1_2
    //
    // -------------------テスト条件--------------------------
    // 
    // -----------------------------------------------------
    @Test
    public void delRows_正常_車両マスタ削除処理_12_3() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        ServiceInterfaceBean serviceInterfaceBean1 = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME003", "");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_4.capture())).thenReturn(serviceInterfaceBean1);

        //テスト実行
        Mst211Form form = new Mst211Form();
        //行選択チェック選択 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        form.setSearchResult(result);
        AutoCompOptionBean conEigyoushoCd = new AutoCompOptionBean();
        conEigyoushoCd.setValue("000");
        form.setConEigyoushoCd(conEigyoushoCd);
        form.setSelectedSearchResult(result);
        target.setMst211Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst211Form();
        Date tekiyoBi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoBi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst211BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("No0", paramsCaptor_1_Param.get("listSharyoNo"));
        assertEquals("Meisho0", paramsCaptor_1_Param.get("listSharyoMeisho"));
        assertEquals("Plate0", paramsCaptor_1_Param.get("listNumberPlate"));
        assertEquals(tekiyoBi, paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals(1, paramsCaptor_1_Param.get("listTekiyoShuryobiCheckBox"));
        assertEquals(tekiyoBi, paramsCaptor_1_Param.get("listTekiyoShuryobiTextBox"));
        assertEquals("listShashu0", paramsCaptor_1_Param.get("listShashu"));
        assertEquals("Hyoji0", paramsCaptor_1_Param.get("listSharyoIchiranHyoji"));
        assertEquals("00", paramsCaptor_1_Param.get("listShiiresakiCd"));
        assertEquals("Mei0", paramsCaptor_1_Param.get("listShiiresakiMei"));
        assertEquals("Mei0", paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals(0, paramsCaptor_1_Param.get("listSaishuShiyobi"));
        assertEquals("mst211-delete-check", functionCodeCaptor_2.getValue());
    }

    // delRows_異常_車両マスタ削除処理_12-4
    //
    // -------------------テスト条件--------------------------
    // 車両NO、適用開始日、営業所コードの組み合わせが、車両マスタに存在しない
    // -----------------------------------------------------
    @Test
    public void delRows_異常_車両マスタ削除処理_12_4() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 車両NO、適用開始日、営業所コードの組み合わせが、車両マスタに存在しない[COME0006]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0006", "");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messageProperty.createMessageModule(levelCaptor_1.capture(), summaryCaptor_2.capture(), summaryCaptor_3.capture(), summaryCaptor_4.capture())).thenReturn(messageModuleBean);

        //テスト実行
        Mst211Form form = new Mst211Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        form.setSearchResult(result);
        AutoCompOptionBean conEigyoushoCd = new AutoCompOptionBean();
        conEigyoushoCd.setValue("000");
        form.setConEigyoushoCd(conEigyoushoCd);
        target.setMst211Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst211Form();

        Date tekiyoBi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoBi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst211BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("No0", paramsCaptor_1_Param.get("listSharyoNo"));
        assertEquals("Meisho0", paramsCaptor_1_Param.get("listSharyoMeisho"));
        assertEquals("Plate0", paramsCaptor_1_Param.get("listNumberPlate"));
        assertEquals(tekiyoBi, paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals(1, paramsCaptor_1_Param.get("listTekiyoShuryobiCheckBox"));
        assertEquals(tekiyoBi, paramsCaptor_1_Param.get("listTekiyoShuryobiTextBox"));
        assertEquals("listShashu0", paramsCaptor_1_Param.get("listShashu"));
        assertEquals("Hyoji0", paramsCaptor_1_Param.get("listSharyoIchiranHyoji"));
        assertEquals("00", paramsCaptor_1_Param.get("listShiiresakiCd"));
        assertEquals("Mei0", paramsCaptor_1_Param.get("listShiiresakiMei"));
        assertEquals("Mei0", paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals(0, paramsCaptor_1_Param.get("listSaishuShiyobi"));
        assertEquals("mst211-delete-check", functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0006）
        assertEquals("ERROR", levelCaptor_1.getValue());
        assertEquals("COME0006", summaryCaptor_2.getValue());
    }

    // rirekiIchiran_正常_更新履歴コンテキストメニュー_13-1
    //
    // -------------------テスト条件--------------------------
    // 正常に取得された場合
    // -----------------------------------------------------
    @Test
    public void rirekiIchiran_正常_更新履歴コンテキストメニュー_13_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> titleFlgCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> searchKeyCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(rirekiSyosai).searchList(titleFlgCaptor_1.capture(), functionCodeCaptor_2.capture(), searchKeyCaptor_3.capture());
        //テスト実行
        Mst211Form form = new Mst211Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        AutoCompOptionBean conEigyoushoCd = new AutoCompOptionBean();
        conEigyoushoCd.setValue("000");
        form.setConEigyoushoCd(conEigyoushoCd);
        target.setMst211Form(form);
        target.rirekiIchiran();

        //実施結果Outを取得
        form = target.getMst211Form();
        Date tekiyoBi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoBi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst211BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        //想定通りに履歴を表示する。
        assertEquals("2", titleFlgCaptor_1.getValue());
        assertEquals("MST211_SEARCH_RIREKI", functionCodeCaptor_2.getValue());
        assertEquals("000", searchKeyCaptor_3.getValue().get("conEigyoushoCd"));
        assertEquals("No0", searchKeyCaptor_3.getValue().get("listSharyoNo"));
        assertEquals(tekiyoBi, searchKeyCaptor_3.getValue().get("listTekiyoKaishibi"));
    }

    // searchChange_正常_補充ケース_14-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void searchChange_正常_補充ケース_14_1() throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst211Form form = new Mst211Form();
        target.setMst211Form(form);
        target.searchChange();

        //実施結果Outを取得
        form = target.getMst211Form();

    }

    // menuClick_正常_補充ケース_14-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_14_2() throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst211Form form = new Mst211Form();
        target.setMst211Form(form);
        target.menuClick("", "");

        //実施結果Outを取得
        form = target.getMst211Form();

    }

    // menuClick_正常_補充ケース_14-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_14_2_1() throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(1);

        //テスト実行
        Mst211Form form = new Mst211Form();
        target.setMst211Form(form);
        target.menuClick("", "");

        //実施結果Outを取得
        form = target.getMst211Form();

    }

    // breadClumClick_正常_補充ケース_14-3
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_14_3() throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst211Form form = new Mst211Form();
        target.setMst211Form(form);
        target.breadClumClick("", 0);

        //実施結果Outを取得
        form = target.getMst211Form();

    }

    // breadClumClick_正常_補充ケース_14-3_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_14_3_1() throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(0);

        //テスト実行
        Mst211Form form = new Mst211Form();
        target.setMst211Form(form);
        target.breadClumClick("", 0);

        //実施結果Outを取得
        form = target.getMst211Form();

    }

    // logoutClick_正常_補充ケース_14-4
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void logoutClick_正常_補充ケース_14_4() throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst211Form form = new Mst211Form();
        target.setMst211Form(form);
        target.logoutClick();

        //実施結果Outを取得
        form = target.getMst211Form();

    }

    // delRowsFunc_正常_補充ケース_14-5
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void delRowsFunc_正常_補充ケース_14_5() throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst211Form form = new Mst211Form();
        target.setMst211Form(form);
        target.delRowsFunc();

        //実施結果Outを取得
        form = target.getMst211Form();

    }

    // getAutoCompForShiireSakiCdList_正常_補充ケース_14_6
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void getAutoCompForShiireSakiCdList_正常_補充ケース_14_6() throws IllegalAccessException, InvocationTargetException {
        Mst211Form form = new Mst211Form();
        String shiireSakiCd = "001";
        List<String> value = new ArrayList<>();
        value.add("test");
        // パラメータキャプチャー
        target.getAutoCompForShiireSakiCdList(shiireSakiCd);

    }
    
     private Map<String, Object> createShashuMapFor_1_1() {
        Map recMap = new HashMap();
        recMap.put("SHASHU_MEI", "SHASHU_CD");
        return recMap;
    }

    private Map<String, String> createRecMapFor_1_1(int i) {
        Date tekiyoBi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoBi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst211BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        Map recMap = new HashMap();
        recMap.put("listSharyoNo", "listSharyoNo" + i);
        recMap.put("listSharyoMeisho", "listSharyoMeisho" + i);
        recMap.put("listNumberPlate", "listNumberPlate" + i);
        recMap.put("listTekiyoKaishibi", tekiyoBi);
        recMap.put("listTekiyoShuryobiCheckBox", 1);
        recMap.put("listTekiyoShuryobiTextBox", tekiyoBi);
        recMap.put("listShashu", "listShashu" + i);
        recMap.put("listSharyoIchiranHyoji", "listSharyoIchiranHyoji" + i);
        recMap.put("listShiiresakiCd", "listShiiresakiCd" + i);
        recMap.put("listShiiresakiMei", "listShiiresakiMei" + i);
        recMap.put("listTekiyoMei", "listTekiyoMei" + i);
        recMap.put("listSaishuShiyobi", i);
        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }
    private Map<String, String> createRecMapFor_2_3_1(int i) {
        Date tekiyoBi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoBi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst211BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        Map recMap = new HashMap();
        recMap.put("listSharyoNo", "listSharyoNo" + i);
        recMap.put("listSharyoMeisho", "listSharyoMeisho" + i);
        recMap.put("listNumberPlate", "listNumberPlate" + i);
        recMap.put("listTekiyoKaishibi", "11111123123132112");
        recMap.put("listTekiyoShuryobiCheckBox", 1);
        recMap.put("listTekiyoShuryobiTextBox", tekiyoBi);
        recMap.put("listShashu", "listShashu" + i);
        recMap.put("listSharyoIchiranHyoji", "listSharyoIchiranHyoji" + i);
        recMap.put("listShiiresakiCd", "listShiiresakiCd" + i);
        recMap.put("listShiiresakiMei", "listShiiresakiMei" + i);
        recMap.put("listTekiyoMei", "listTekiyoMei" + i);
        recMap.put("listSaishuShiyobi", i);
        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }

    private Map<String, String> createRecMapFor_1_2(int i) {
        Date tekiyoBi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoBi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst211BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        Map recMap = new HashMap();
        recMap.put("listSharyoNo", "listSharyoNo" + i);
        recMap.put("listSharyoMeisho", "listSharyoMeisho" + i);
        recMap.put("listNumberPlate", "listNumberPlate" + i);
        recMap.put("listTekiyoKaishibi", tekiyoBi);
        recMap.put("listTekiyoShuryobiCheckBox", 0);
        recMap.put("listShashu", "listShashu" + i);
        recMap.put("listSharyoIchiranHyoji", "listSharyoIchiranHyoji" + i);
        recMap.put("listShiiresakiCd", "listShiiresakiCd" + i);
        recMap.put("listShiiresakiMei", "listShiiresakiMei" + i);
        recMap.put("listTekiyoMei", "listTekiyoMei" + i);
        recMap.put("listSaishuShiyobi", i);
        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }

    private Map<String, Object> createRecMapFor_11_1(int i) {
        Date tekiyoBi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoBi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst211BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        Map recMap = new HashMap();
        recMap.put("listSharyoNo", "No" + i);
        recMap.put("listSharyoMeisho", "Meisho" + i);
        recMap.put("listNumberPlate", "Plate" + i);
        recMap.put("listTekiyoKaishibi", tekiyoBi);
        recMap.put("listTekiyoShuryobiCheckBox", 1);
        recMap.put("listTekiyoShuryobiTextBox", tekiyoBi);
        recMap.put("listShashu", "listShashu" + i);
        recMap.put("listSharyoIchiranHyoji", "Hyoji" + i);
        recMap.put("listShiiresakiCd", "0" + i);
        recMap.put("listShiiresakiMei", "Mei" + i);
        recMap.put("listTekiyoMei", "Mei" + i);
        recMap.put("listSaishuShiyobi", i);
        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }

    private Map<String, Object> createRecMapFor_11_6_1(int i) {
        Date tekiyoBi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoBi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst211BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        Map recMap = new HashMap();
        recMap.put("listSharyoNo", "No" + i);
        recMap.put("listSharyoMeisho", "Meisho" + i);
        recMap.put("listNumberPlate", "Plate" + i);
        recMap.put("listTekiyoKaishibi", tekiyoBi);
        recMap.put("listTekiyoShuryobiCheckBox", true);
        recMap.put("listShashu", "listShashu" + i);
        recMap.put("listSharyoIchiranHyoji", "Hyoji" + i);
        recMap.put("listShiiresakiCd", "0" + i);
        recMap.put("listShiiresakiMei", "Mei" + i);
        recMap.put("listTekiyoMei", "Mei" + i);
        recMap.put("listSaishuShiyobi", i);
        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }

    private Map<String, Object> createRecMapFor_11_6_2(int i) {
        Date tekiyoBi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoBi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst211BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        Map recMap = new HashMap();
        recMap.put("listSharyoNo", "No" + i);
        recMap.put("listSharyoMeisho", "Meisho" + i);
        recMap.put("listNumberPlate", "Plate" + i);
        recMap.put("listTekiyoKaishibi", tekiyoBi);
        recMap.put("listTekiyoShuryobiCheckBox", false);
        recMap.put("listTekiyoShuryobiTextBox", tekiyoBi);
        recMap.put("listShashu", "listShashu" + i);
        recMap.put("listSharyoIchiranHyoji", "Hyoji" + i);
        recMap.put("listShiiresakiCd", "0" + i);
        recMap.put("listShiiresakiMei", "Mei" + i);
        recMap.put("listTekiyoMei", "Mei" + i);
        recMap.put("listSaishuShiyobi", i);
        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }

    private Map<String, Object> createRecMapFor_11_6_3(int i) {
        Date tekiyoBi = null;
        Map recMap = new HashMap();
        recMap.put("listSharyoNo", "No" + i);
        recMap.put("listSharyoMeisho", "Meisho" + i);
        recMap.put("listNumberPlate", "Plate" + i);
        recMap.put("listTekiyoKaishibi", tekiyoBi);
        recMap.put("listTekiyoShuryobiCheckBox", true);
        recMap.put("listTekiyoShuryobiTextBox", tekiyoBi);
        recMap.put("listShashu", "listShashu" + i);
        recMap.put("listSharyoIchiranHyoji", "Hyoji" + i);
        recMap.put("listShiiresakiCd", "0" + i);
        recMap.put("listShiiresakiMei", "Mei" + i);
        recMap.put("listTekiyoMei", "Mei" + i);
        recMap.put("listSaishuShiyobi", i);
        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }

    private void assertForRecList_2_1(Mst211Form form) {
        int i = 0;
        Date tekiyoBi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoBi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst211BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        assertEquals(1, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listSharyoNo" + i, rec.get("listSharyoNo"));
            assertEquals("listSharyoMeisho" + i, rec.get("listSharyoMeisho"));
            assertEquals("listNumberPlate" + i, rec.get("listNumberPlate"));
            assertEquals("true", rec.get("listTekiyoShuryobiCheckBox"));
            assertEquals("listShashu" + i, rec.get("listShashu"));
            assertEquals("listSharyoIchiranHyoji" + i, rec.get("listSharyoIchiranHyoji"));
            assertEquals("listShiiresakiCd" + i, rec.get("listShiiresakiCd"));
            assertEquals("listShiiresakiMei" + i, rec.get("listShiiresakiMei"));
            assertEquals("listTekiyoMei" + i, rec.get("listTekiyoMei"));
            i++;
        }
    }

    private void assertForRecList_2_2(Mst211Form form) {
        int i = 0;
        Date tekiyoBi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoBi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst211BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        assertEquals(1, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listSharyoNo" + i, rec.get("listSharyoNo"));
            assertEquals("listSharyoMeisho" + i, rec.get("listSharyoMeisho"));
            assertEquals("listNumberPlate" + i, rec.get("listNumberPlate"));
            assertEquals("false", rec.get("listTekiyoShuryobiCheckBox"));
            assertEquals("listShashu" + i, rec.get("listShashu"));
            assertEquals("listSharyoIchiranHyoji" + i, rec.get("listSharyoIchiranHyoji"));
            assertEquals("listShiiresakiCd" + i, rec.get("listShiiresakiCd"));
            assertEquals("listShiiresakiMei" + i, rec.get("listShiiresakiMei"));
            assertEquals("listTekiyoMei" + i, rec.get("listTekiyoMei"));
            i++;
        }
    }

    private void assertForRecList_2_1_2(Mst211Form form) {
        int i = 0;
        Date tekiyoBi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoBi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst211BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        assertEquals(1, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listSharyoNo" + i, rec.get("listSharyoNo"));
            assertEquals("listSharyoMeisho" + i, rec.get("listSharyoMeisho"));
            assertEquals("listNumberPlate" + i, rec.get("listNumberPlate"));
            assertEquals(tekiyoBi, rec.get("listTekiyoKaishibi"));
            assertEquals("true", rec.get("listTekiyoShuryobiCheckBox"));
            assertEquals(tekiyoBi, rec.get("listTekiyoShuryobiTextBox"));
            assertEquals("listShashu" + i, rec.get("listShashu"));
            assertEquals("listSharyoIchiranHyoji" + i, rec.get("listSharyoIchiranHyoji"));
            assertEquals("listShiiresakiCd" + i, rec.get("listShiiresakiCd"));
            assertEquals("listShiiresakiMei" + i, rec.get("listShiiresakiMei"));
            assertEquals("listTekiyoMei" + i, rec.get("listTekiyoMei"));
            assertEquals(i, rec.get("listSaishuShiyobi"));
            i++;
        }
    }

    private void assertForRecList_2_3(Mst211Form form) {
        int i = 0;
        Date tekiyoBi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoBi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst211BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        assertEquals(2, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listSharyoNo" + i, rec.get("listSharyoNo"));
            assertEquals("listSharyoMeisho" + i, rec.get("listSharyoMeisho"));
            assertEquals("listNumberPlate" + i, rec.get("listNumberPlate"));
            assertEquals(tekiyoBi, rec.get("listTekiyoKaishibi"));
            assertEquals("true", rec.get("listTekiyoShuryobiCheckBox"));
            assertEquals(tekiyoBi, rec.get("listTekiyoShuryobiTextBox"));
            assertEquals("listShashu" + i, rec.get("listShashu"));
            assertEquals("listSharyoIchiranHyoji" + i, rec.get("listSharyoIchiranHyoji"));
            assertEquals("listShiiresakiCd" + i, rec.get("listShiiresakiCd"));
            assertEquals("listShiiresakiMei" + i, rec.get("listShiiresakiMei"));
            assertEquals("listTekiyoMei" + i, rec.get("listTekiyoMei"));
            assertEquals(new Date(i), rec.get("listSaishuShiyobi"));
            i++;
        }
    }

    private void assertForRecList_2_4(Mst211Form form) {
        int i = 0;
        Date tekiyoBi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoBi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst211BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        assertEquals(2, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listSharyoNo" + i, rec.get("listSharyoNo"));
            assertEquals("listSharyoMeisho" + i, rec.get("listSharyoMeisho"));
            assertEquals("listNumberPlate" + i, rec.get("listNumberPlate"));
            assertEquals("true", rec.get("listTekiyoShuryobiCheckBox"));
            assertEquals("listShashu" + i, rec.get("listShashu"));
            assertEquals("listSharyoIchiranHyoji" + i, rec.get("listSharyoIchiranHyoji"));
            assertEquals("listShiiresakiCd" + i, rec.get("listShiiresakiCd"));
            assertEquals("listShiiresakiMei" + i, rec.get("listShiiresakiMei"));
            assertEquals("listTekiyoMei" + i, rec.get("listTekiyoMei"));
            i++;
        }
    }

}
