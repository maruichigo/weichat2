/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import java.io.IOException;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.KbnBean;
import jp.co.kintetsuls.beans.common.KbnModuleBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst301Form;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import static org.mockito.Mockito.when;

/**
 * 仕向地名マスタ画面
 *
 * @author 曾鳳(MBP)
 * @version 2019/3/22 新規作成
 */
public class Mst301BeanTest {

    // テストTarget
    @InjectMocks
    private Mst301Bean target;

    // Mockitoオブジェクト
    @Mock
    private FileBean fileBean;
    @Mock
    private AutoCompleteViewBean autoCompleteViewBean;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private KbnBean kbnBean;
    @Mock
    private MessagePropertyBean messagePropertyBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosaiBean;
    @Mock
    private SearchHelpBean searchHelpBean;
    @Mock
    private AuthorityConfBean authConfBean;
    @Mock
    private ListCheckBean listCheckBean;
    
    public Mst301BeanTest() {
    }

    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() {
    }

    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 戻ってきた場合(backFlg=true,preForm=mst301Form)
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst301Form mst301Form = new Mst301Form();
        
        //前画面情報[not null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst301Form);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst301Form form = new Mst301Form();
        target.setForm(form);
        // 戻ってきた場合、再検索を実施する。
        target.init("","MST031_SCREEN",true);

        //実施結果Outを取得
        String title = target.getTITLE();
        String url = target.getUrl();
        BreadCrumbBean breadBean = target.getBreadBean();
        AutoCompleteViewBean autoCompleteViewBean = target.getAutoCompleteViewBean();
        AuthorityConfBean authorityConfBean  = target.getAuthConfBean();
        FileBean fileBean = target.getFileBean();
        MessagePropertyBean messagePropertyBean = target.getMessagePropertyBean();
        PageCommonBean pageCommonBean = target.getPageCommon();
        SearchHelpBean searchHelpBean = target.getSearchHelpBean();
        RirekiSyosaiBean rirekiSyosaiBean = target.getRirekiSyosaiBean();
        ListCheckBean listCheckBean = target.getListCheckBean();
        Map<String, Object> rirekiSearchKey = target.getRirekiSearchKey();
        List<MessageModuleBean> msgList = target.getMsgList();
        target.setUrl(url);
        target.setBreadBean(breadBean);
        target.setAutoCompleteViewBean(autoCompleteViewBean);
        target.setAuthConfBean(authorityConfBean);
        target.setFileBean(fileBean);
        target.setMessagePropertyBean(messagePropertyBean);
        target.setPageCommon(pageCommonBean);
        target.setSearchHelpBean(searchHelpBean);
        target.setRirekiSyosaiBean(rirekiSyosaiBean);
        target.setListCheckBean(listCheckBean);
        target.setRirekiSearchKey(rirekiSearchKey);
        target.setMsgList(msgList);
        
        // 実行時に渡すパラメータの検証
        assertEquals("mst301Form", keyCaptor_1.getValue());
        //想定通りに再検索を実施する。
        assertEquals("search_mst301", keyCaptor_2.getValue());
        assertEquals("ロジ料金項目マスタ", title);
    }

    // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // backFlg=true,preForm=null
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        
        // preForm=null
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(null);
        
        //テスト実行
        Mst301Form form = new Mst301Form();
        target.setForm(form);
        // 戻ってきた場合、再検索を実施する。
        target.init("","MST031_SCREEN",true);

        // 実行時に渡すパラメータの検証
        assertEquals("mst301Form", keyCaptor_1.getValue());
        // 料金項目1コード
        assertEquals(null,form.getConRyokinKomoku1Cd());
        // 料金項目1名称
        assertEquals(null,form.getConRyokinKomoku1Mei());
        // 料金項目2コード
        assertEquals(null,form.getConRyokinKomoku2Cd());
        // 料金項目2名称
        assertEquals(null,form.getConRyokinKomoku2Mei());
        // 処理科目
        assertEquals(null,form.getConSyoriKamoku());
        // 補助科目
        assertEquals(null,form.getConHojoKamoku());
        // 卸値計算パターン
        assertEquals(null,form.getConOroshineKeisanPattern());
        // 適用名
        assertEquals(null,form.getConTekiyoMei());
        // 世代検索条件
        assertEquals(null,form.getConSedaiKensakuJoken()[0]);
        // 適用日
        assertEquals(null,form.getConTekiyoBi());
        // 削除のみ検索
        assertEquals(null,form.getConSakujoNomiKensaku());
    }

    // init_正常_初期処理_1-3
    //
    // -------------------テスト条件--------------------------
    // backFlg=false,flash != null, flash.get("mst301Form")=mst301Form
    // 前回検索パラメータ[料金項目1コード=null,料金項目1名称=null,料金項目2コード=null,
    //      料金項目2名称 = null,処理科目=null,補助科目=null,卸値計算パターン=01,
    //      適用名=null,世代検索条件=02,適用日=null,削除のみ検索=null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3() throws IllegalAccessException, InvocationTargetException,
            InstantiationException {

        // Mockitoオブジェクトの予想return値設定
        Mst301Form mst301Form = new Mst301Form();
        //前回検索パラメータ
        // 料金項目1コード
        mst301Form.setConRyokinKomoku1Cd(null);
        // 料金項目1名称
        mst301Form.setConRyokinKomoku1Mei(null);
        // 料金項目2コード
        mst301Form.setConRyokinKomoku2Cd(null);
        // 料金項目2名称
        mst301Form.setConRyokinKomoku2Mei(null);
        // 処理科目
        mst301Form.setConSyoriKamoku(null);
        // 補助科目
        mst301Form.setConHojoKamoku(null);
        // 卸値計算パターン
        mst301Form.setConOroshineKeisanPattern("01");
        // 適用名
        mst301Form.setConTekiyoMei(null);
        // 世代検索条件
        mst301Form.setConSedaiKensakuJoken(new String[]{"02"});
        // 適用日
        mst301Form.setConTekiyoBi(null);
        // 削除のみ検索
        mst301Form.setConSakujoNomiKensaku(null);
        
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        //前画面パラメータ[都道府県 = 01,仕向地名 = 地名23,削除済のみ検索 = null]
        flash.put("mst301Form", mst301Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);        

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst301Form form = new Mst301Form();
        target.setForm(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getForm();

        //想定通りに再検索を実施する。
        assertEquals("search_mst301",keyCaptor_2.getValue());
        // 料金項目1コード
        assertEquals(null,form.getConRyokinKomoku1Cd());
        // 料金項目1名称
        assertEquals(null,form.getConRyokinKomoku1Mei());
        // 料金項目2コード
        assertEquals(null,form.getConRyokinKomoku2Cd());
        // 料金項目2名称
        assertEquals(null,form.getConRyokinKomoku2Mei());
        // 処理科目
        assertEquals(null,form.getConSyoriKamoku());
        // 補助科目
        assertEquals(null,form.getConHojoKamoku());
        // 卸値計算パターン
        assertEquals("01",form.getConOroshineKeisanPattern());
        // 適用名
        assertEquals(null,form.getConTekiyoMei());
        // 世代検索条件
        assertEquals("02",form.getConSedaiKensakuJoken()[0]);
        // 適用日
        assertEquals(null,form.getConTekiyoBi());
        // 削除のみ検索
        assertEquals(null,form.getConSakujoNomiKensaku());
    }
    
    // init_正常_初期処理_1-4
    //
    // -------------------テスト条件--------------------------
    // backFlg=false,flash != null, flash.get("mst301Form")=null
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_4() throws IllegalAccessException, InvocationTargetException,
            InstantiationException {

        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        //前画面パラメータ[都道府県 = 01,仕向地名 = 地名23,削除済のみ検索 = null]
        flash.put("mst301Form", null);
        when(pageCommonBean.getPageParam()).thenReturn(flash);        

        //テスト実行
        Mst301Form form = new Mst301Form();
        target.setForm(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getForm();
        // 料金項目1コード
        assertEquals(null,form.getConRyokinKomoku1Cd());
        // 料金項目1名称
        assertEquals(null,form.getConRyokinKomoku1Mei());
        // 料金項目2コード
        assertEquals(null,form.getConRyokinKomoku2Cd());
        // 料金項目2名称
        assertEquals(null,form.getConRyokinKomoku2Mei());
        // 処理科目
        assertEquals(null,form.getConSyoriKamoku());
        // 補助科目
        assertEquals(null,form.getConHojoKamoku());
        // 卸値計算パターン
        assertEquals(null,form.getConOroshineKeisanPattern());
        // 適用名
        assertEquals(null,form.getConTekiyoMei());
        // 世代検索条件
        assertEquals(null,form.getConSedaiKensakuJoken()[0]);
        // 適用日
        assertEquals(null,form.getConTekiyoBi());
        // 削除のみ検索
        assertEquals(null,form.getConSakujoNomiKensaku());
    }

    // init_正常_初期処理_1-5
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_5 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        //前画面情報[null]
        doThrow(IllegalAccessException.class).when(pageCommonBean).getPageInfo(keyCaptor_1.capture());

        //テスト実行
        Mst301Form form = new Mst301Form();
        target.setForm(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getForm();

        // 実行時に渡すパラメータの検証
        assertEquals("mst301Form",keyCaptor_1.getValue());
        //想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null,form.getSearchResult());
    }

    // search_正常_検索処理_2-1
    //
    // -------------------テスト条件--------------------------
    // ロジ料金項目マスタ検索結果一覧取得
    // 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // ロジ料金項目マスタ検索結果一覧取得 件数 = 1
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i <= 0; i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst301Form mst301Form = new Mst301Form();
        // 料金項目1コード
        mst301Form.setConRyokinKomoku1Cd("conRyokinKomoku1Cd1");
        // 料金項目1名称
        mst301Form.setConRyokinKomoku1Mei("conRyokinKomoku1Mei1");
        // 料金項目2コード
        mst301Form.setConRyokinKomoku2Cd("conRyokinKomoku2Cd1");
        // 料金項目2名称
        mst301Form.setConRyokinKomoku2Mei("conRyokinKomoku2Mei1");
        // 処理科目
        AutoCompOptionBean conSyoriKamoku = new AutoCompOptionBean();
        conSyoriKamoku.setValue("conSyoriKamoku1");
        mst301Form.setConSyoriKamoku(conSyoriKamoku);
        // 補助科目
        AutoCompOptionBean conHojoKamoku = new AutoCompOptionBean();
        conHojoKamoku.setValue("conHojoKamoku1");
        mst301Form.setConHojoKamoku(conHojoKamoku);
        // 卸値計算パターン
        mst301Form.setConOroshineKeisanPattern("conOroshineKeisanPattern1");
        // 適用名
        mst301Form.setConTekiyoMei("conTekiyoMei1");
        // 世代検索条件
        mst301Form.setConSedaiKensakuJoken(new String[]{"01"});
        // 適用日
        mst301Form.setConTekiyoBi("2019/03/22");
        // 削除のみ検索
        mst301Form.setConSakujoNomiKensaku(new String[]{"conSakujoNomiKensaku1"});
        // 世代検索条件リスト
        List<KbnModuleBean> list = new ArrayList<>();
        KbnModuleBean kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnCd("01");
        list.add(kbnModuleBean);
        kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnCd("02");
        list.add(kbnModuleBean);
        mst301Form.setConSedaiKensakuJokenLabelValueList(list);
        target.setForm(mst301Form);
        target.search();

        //実施結果Outを取得
        mst301Form = target.getForm();

        // 実行時に渡すパラメータの検証
        assertEquals("conRyokinKomoku1Cd1", paramsCaptor_1.getValue().get("conRyokinkomoku1Cd"));
        assertEquals("conRyokinKomoku1Mei1", paramsCaptor_1.getValue().get("conRyokinkomoku1Mei"));
        assertEquals("conRyokinKomoku2Cd1", paramsCaptor_1.getValue().get("conRyokinkomoku2Cd"));
        assertEquals("conRyokinKomoku2Mei1", paramsCaptor_1.getValue().get("conRyokinkomoku2Mei"));
        assertEquals("conSyoriKamoku1", paramsCaptor_1.getValue().get("conShorikamokuCd"));
        assertEquals("conHojoKamoku1", paramsCaptor_1.getValue().get("conHojokamokuCd"));
        assertEquals("conOroshineKeisanPattern1", paramsCaptor_1.getValue().get("conOroshineKeisanPattern"));
        assertEquals("conTekiyoMei1", paramsCaptor_1.getValue().get("conTekiyoMei"));
        List<String> conSedaiKensakuJokenParam = (List<String>)paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals("1", conSedaiKensakuJokenParam.get(0));
        assertEquals("0", conSedaiKensakuJokenParam.get(1));
        assertEquals("2019/03/22", paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals("1", paramsCaptor_1.getValue().get("conSakujoSumiNomi"));
        assertEquals("mst301_search", functionCodeCaptor_2.getValue());
        //想定通りに仕向地名マスタ一覧を表示されること
        assertForRecList_2_1(mst301Form);
    }    

    // search_正常_検索処理_2-2
    //
    // -------------------テスト条件--------------------------
    // ロジ料金項目マスタ検索結果一覧取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得 取得件数 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i <= 1; i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst301Form form = new Mst301Form();
        List<KbnModuleBean> list = new ArrayList<>();
        KbnModuleBean kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnCd("01");
        list.add(kbnModuleBean);
        kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnCd("02");
        list.add(kbnModuleBean);
        form.setConSedaiKensakuJokenLabelValueList(list);
        // 世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01"});
        // 削除のみ検索
        form.setConSakujoNomiKensaku(new String[]{});
        target.setForm(form);
        target.search();

        //実施結果Outを取得
        form = target.getForm();

        // 実行時に渡すパラメータの検証
        assertEquals(null,paramsCaptor_1.getValue().get("conRyokinkomoku1Cd"));
        assertEquals(null,paramsCaptor_1.getValue().get("conRyokinkomoku1Mei"));
        assertEquals(null,paramsCaptor_1.getValue().get("conRyokinkomoku2Cd"));
        assertEquals(null,paramsCaptor_1.getValue().get("conRyokinkomoku2Mei"));
        assertEquals("",paramsCaptor_1.getValue().get("conShorikamokuCd"));
        assertEquals("",paramsCaptor_1.getValue().get("conHojokamokuCd"));
        assertEquals(null,paramsCaptor_1.getValue().get("conOroshineKeisanPattern"));
        assertEquals(null,paramsCaptor_1.getValue().get("conTekiyoMei"));
        List<String> conSedaiKensakuJokenParam = (List<String>)paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals("1", conSedaiKensakuJokenParam.get(0));
        assertEquals("0", conSedaiKensakuJokenParam.get(1));
        assertEquals(null,paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals("0",paramsCaptor_1.getValue().get("conSakujoSumiNomi"));
        assertEquals("mst301_search",functionCodeCaptor_2.getValue());
        //想定通りにロジ料金項目マスタ一覧を表示されること
        assertForRecList_2_2(form);
    }

    // search_異常_検索処理_2-3
    //
    // -------------------テスト条件--------------------------
    // ロジ料金項目マスタ検索結果一覧取得 取得件数 = 0
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得 取得件数 = 0
        List<Map<String, String>> result = new ArrayList<>();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst301Form form = new Mst301Form();
        List<KbnModuleBean> list = new ArrayList<>();
        KbnModuleBean kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnCd("01");
        list.add(kbnModuleBean);
        kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnCd("02");
        list.add(kbnModuleBean);
        form.setConSedaiKensakuJokenLabelValueList(list);
        // 世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01"});
        // 削除のみ検索
        form.setConSakujoNomiKensaku(new String[]{});
        target.setForm(form);
        target.search();

        //実施結果Outを取得
        form = target.getForm();

        // 実行時に渡すパラメータの検証
        assertEquals(null,paramsCaptor_1.getValue().get("conRyokinkomoku1Cd"));
        assertEquals(null,paramsCaptor_1.getValue().get("conRyokinkomoku1Mei"));
        assertEquals(null,paramsCaptor_1.getValue().get("conRyokinkomoku2Cd"));
        assertEquals(null,paramsCaptor_1.getValue().get("conRyokinkomoku2Mei"));
        assertEquals("",paramsCaptor_1.getValue().get("conShorikamokuCd"));
        assertEquals("",paramsCaptor_1.getValue().get("conHojokamokuCd"));
        assertEquals(null,paramsCaptor_1.getValue().get("conOroshineKeisanPattern"));
        assertEquals(null,paramsCaptor_1.getValue().get("conTekiyoMei"));
        List<String> conSedaiKensakuJokenParam = (List<String>)paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals("1", conSedaiKensakuJokenParam.get(0));
        assertEquals("0", conSedaiKensakuJokenParam.get(1));
        assertEquals(null,paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals("0",paramsCaptor_1.getValue().get("conSakujoSumiNomi"));
        assertEquals("mst301_search",functionCodeCaptor_2.getValue());
        //想定通りに・一覧は表示しない（ヘッダーのみ） 
        //想定通りに ・ファンクションボタンは表示（検索前と同じ） 
        assertEquals(0, form.getSearchResult().size());
    }

    // search_異常_検索処理_2-4
    //
    // -------------------テスト条件--------------------------
    // ロジ料金項目マスタ検索結果一覧取得 IOException
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得
        List<Map<String, String>> result = new ArrayList<>();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        doThrow(IOException.class).when(pageCommonBean).getDBInfo(paramsCaptor_1.capture(), 
                functionCodeCaptor_2.capture());

        //テスト実行
        Mst301Form form = new Mst301Form();
        List<KbnModuleBean> list = new ArrayList<>();
        KbnModuleBean kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnCd("01");
        list.add(kbnModuleBean);
        kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnCd("02");
        list.add(kbnModuleBean);
        form.setConSedaiKensakuJokenLabelValueList(list);
        // 世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01"});
        // 削除のみ検索
        form.setConSakujoNomiKensaku(new String[]{});
        target.setForm(form);
        target.search();

        // 実行時に渡すパラメータの検証
        assertEquals(null,paramsCaptor_1.getValue().get("conRyokinkomoku1Cd"));
        assertEquals(null,paramsCaptor_1.getValue().get("conRyokinkomoku1Mei"));
        assertEquals(null,paramsCaptor_1.getValue().get("conRyokinkomoku2Cd"));
        assertEquals(null,paramsCaptor_1.getValue().get("conRyokinkomoku2Mei"));
        assertEquals("",paramsCaptor_1.getValue().get("conShorikamokuCd"));
        assertEquals("",paramsCaptor_1.getValue().get("conHojokamokuCd"));
        assertEquals(null,paramsCaptor_1.getValue().get("conOroshineKeisanPattern"));
        assertEquals(null,paramsCaptor_1.getValue().get("conTekiyoMei"));
        List<String> conSedaiKensakuJokenParam = (List<String>)paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals("1", conSedaiKensakuJokenParam.get(0));
        assertEquals("0", conSedaiKensakuJokenParam.get(1));
        assertEquals(null,paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals("0",paramsCaptor_1.getValue().get("conSakujoSumiNomi"));
        assertEquals("mst301_search",functionCodeCaptor_2.getValue());
    }

    // getRecordCount_正常_件数取得処理_3-1
    //
    // -------------------テスト条件--------------------------
    // 仕向地検索件数取得 取得件数 = 2、サブ検索条件[適用名]あり
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_3_1 () throws IllegalAccessException, InvocationTargetException {

         // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst301Form mst301Form = new Mst301Form();
        // 適用名
        mst301Form.setConTekiyoMei("conTekiyoMei1");
        // 世代検索条件
        mst301Form.setConSedaiKensakuJoken(new String[]{"01"});
        // 適用日
        mst301Form.setConTekiyoBi("2019/03/22");
        // 削除のみ検索
        mst301Form.setConSakujoNomiKensaku(new String[]{"1"});
        // 世代検索条件リスト
        List<KbnModuleBean> list = new ArrayList<>();
        KbnModuleBean kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnCd("01");
        list.add(kbnModuleBean);
        kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnCd("02");
        list.add(kbnModuleBean);
        mst301Form.setConSedaiKensakuJokenLabelValueList(list);
        target.setForm(mst301Form);
        target.count(false);

        // 実行時に渡すパラメータの検証
        assertEquals("conTekiyoMei1", paramsCaptor_1.getValue().get("conTekiyoMei"));
        List<String> conSedaiKensakuJokenParam = (List<String>)paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals("1", conSedaiKensakuJokenParam.get(0));
        assertEquals("0", conSedaiKensakuJokenParam.get(1));
        assertEquals("2019/03/22", paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals("1", paramsCaptor_1.getValue().get("conSakujoSumiNomi"));
        assertEquals("mst301_count", functionCodeCaptor_2.getValue());
    }

    // getRecordCount_正常_件数取得処理_3-2
    //
    // -------------------テスト条件--------------------------
    // 仕向地検索件数取得 取得件数 = 2、サブ検索条件[世代検索条件]あり
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_3_2 () throws IllegalAccessException, InvocationTargetException {

         // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst301Form mst301Form = new Mst301Form();
        // 適用名
        mst301Form.setConTekiyoMei(null);
        // 世代検索条件
        mst301Form.setConSedaiKensakuJoken(new String[]{"01"});
        // 適用日
        mst301Form.setConTekiyoBi("2019/03/22");
        // 削除のみ検索
        mst301Form.setConSakujoNomiKensaku(new String[]{"1"});
        // 世代検索条件リスト
        List<KbnModuleBean> list = new ArrayList<>();
        KbnModuleBean kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnCd("01");
        list.add(kbnModuleBean);
        kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnCd("02");
        list.add(kbnModuleBean);
        mst301Form.setConSedaiKensakuJokenLabelValueList(list);
        target.setForm(mst301Form);
        target.count(false);

        // 実行時に渡すパラメータの検証
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoMei"));
        List<String> conSedaiKensakuJokenParam = (List<String>)paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals("1", conSedaiKensakuJokenParam.get(0));
        assertEquals("0", conSedaiKensakuJokenParam.get(1));
        assertEquals("2019/03/22", paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals("1", paramsCaptor_1.getValue().get("conSakujoSumiNomi"));
        assertEquals("mst301_count", functionCodeCaptor_2.getValue());
    }

    // getRecordCount_正常_件数取得処理_3-3
    //
    // -------------------テスト条件--------------------------
    // 仕向地検索件数取得 取得件数 = 2、サブ検索条件[適用日]あり
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_3_3 () throws IllegalAccessException, InvocationTargetException {

         // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst301Form mst301Form = new Mst301Form();
        // 適用名
        mst301Form.setConTekiyoMei(null);
        // 世代検索条件
        mst301Form.setConSedaiKensakuJoken(new String[]{});
        // 適用日
        mst301Form.setConTekiyoBi("2019/03/22");
        // 削除のみ検索
        mst301Form.setConSakujoNomiKensaku(new String[]{"1"});
        // 世代検索条件リスト
        List<KbnModuleBean> list = new ArrayList<>();
        KbnModuleBean kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnCd("01");
        list.add(kbnModuleBean);
        kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnCd("02");
        list.add(kbnModuleBean);
        mst301Form.setConSedaiKensakuJokenLabelValueList(list);
        target.setForm(mst301Form);
        target.count(false);

        // 実行時に渡すパラメータの検証
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoMei"));
        List<String> conSedaiKensakuJokenParam = (List<String>)paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals("0", conSedaiKensakuJokenParam.get(0));
        assertEquals("0", conSedaiKensakuJokenParam.get(1));
        assertEquals("2019/03/22", paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals("1", paramsCaptor_1.getValue().get("conSakujoSumiNomi"));
        assertEquals("mst301_count", functionCodeCaptor_2.getValue());
    }

    // getRecordCount_正常_件数取得処理_3-4
    //
    // -------------------テスト条件--------------------------
    // 仕向地検索件数取得 取得件数 = 2、サブ検索条件[削除のみ]あり
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_3_4 () throws IllegalAccessException, InvocationTargetException {

         // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst301Form mst301Form = new Mst301Form();
        // 適用名
        mst301Form.setConTekiyoMei(null);
        // 世代検索条件
        mst301Form.setConSedaiKensakuJoken(new String[]{});
        // 適用日
        mst301Form.setConTekiyoBi(null);
        // 削除のみ検索
        mst301Form.setConSakujoNomiKensaku(new String[]{"1"});
        // 世代検索条件リスト
        List<KbnModuleBean> list = new ArrayList<>();
        KbnModuleBean kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnCd("01");
        list.add(kbnModuleBean);
        kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnCd("02");
        list.add(kbnModuleBean);
        mst301Form.setConSedaiKensakuJokenLabelValueList(list);
        target.setForm(mst301Form);
        target.count(false);

        // 実行時に渡すパラメータの検証
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoMei"));
        List<String> conSedaiKensakuJokenParam = (List<String>)paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals("0", conSedaiKensakuJokenParam.get(0));
        assertEquals("0", conSedaiKensakuJokenParam.get(1));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals("1", paramsCaptor_1.getValue().get("conSakujoSumiNomi"));
        assertEquals("mst301_count", functionCodeCaptor_2.getValue());
    }

    // getRecordCount_正常_件数取得処理_3-5
    //
    // -------------------テスト条件--------------------------
    // 仕向地検索件数取得 取得件数 = 2、サブ検索条件なし
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_3_5 () throws IllegalAccessException, InvocationTargetException {

         // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst301Form mst301Form = new Mst301Form();
        // 料金項目1コード
        mst301Form.setConRyokinKomoku1Cd("conRyokinKomoku1Cd1");
        // 料金項目1名称
        mst301Form.setConRyokinKomoku1Mei("conRyokinKomoku1Mei1");
        // 料金項目2コード
        mst301Form.setConRyokinKomoku2Cd("conRyokinKomoku2Cd1");
        // 料金項目2名称
        mst301Form.setConRyokinKomoku2Mei("conRyokinKomoku2Mei1");
        // 処理科目
        AutoCompOptionBean conSyoriKamoku = new AutoCompOptionBean();
        conSyoriKamoku.setValue("conSyoriKamoku1");
        mst301Form.setConSyoriKamoku(conSyoriKamoku);
        // 補助科目
        AutoCompOptionBean conHojoKamoku = new AutoCompOptionBean();
        conHojoKamoku.setValue("conHojoKamoku1");
        mst301Form.setConHojoKamoku(conHojoKamoku);
        // 卸値計算パターン
        mst301Form.setConOroshineKeisanPattern("conOroshineKeisanPattern1");
        // 適用名
        mst301Form.setConTekiyoMei("");
        // 世代検索条件
        mst301Form.setConSedaiKensakuJoken(new String[]{});
        // 適用日
        mst301Form.setConTekiyoBi(null);
        // 削除のみ検索
        mst301Form.setConSakujoNomiKensaku(new String[]{});
        // 世代検索条件リスト
        List<KbnModuleBean> list = new ArrayList<>();
        KbnModuleBean kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnCd("01");
        list.add(kbnModuleBean);
        kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnCd("02");
        list.add(kbnModuleBean);
        mst301Form.setConSedaiKensakuJokenLabelValueList(list);
        target.setForm(mst301Form);
        target.count(false);

        // 実行時に渡すパラメータの検証
        assertEquals("conRyokinKomoku1Cd1", paramsCaptor_1.getValue().get("conRyokinkomoku1Cd"));
        assertEquals("conRyokinKomoku1Mei1", paramsCaptor_1.getValue().get("conRyokinkomoku1Mei"));
        assertEquals("conRyokinKomoku2Cd1", paramsCaptor_1.getValue().get("conRyokinkomoku2Cd"));
        assertEquals("conRyokinKomoku2Mei1", paramsCaptor_1.getValue().get("conRyokinkomoku2Mei"));
        assertEquals("conSyoriKamoku1", paramsCaptor_1.getValue().get("conShorikamokuCd"));
        assertEquals("conHojoKamoku1", paramsCaptor_1.getValue().get("conHojokamokuCd"));
        assertEquals("conOroshineKeisanPattern1", paramsCaptor_1.getValue().get("conOroshineKeisanPattern"));
        assertEquals("", paramsCaptor_1.getValue().get("conTekiyoMei"));
        List<String> conSedaiKensakuJokenParam = (List<String>)paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals("0", conSedaiKensakuJokenParam.get(0));
        assertEquals("0", conSedaiKensakuJokenParam.get(1));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals("0", paramsCaptor_1.getValue().get("conSakujoSumiNomi"));
        assertEquals("mst301_count", functionCodeCaptor_2.getValue());
    }    

    // clear_正常_クリア処理_4-1
    //
    // -------------------テスト条件--------------------------
    // 検索条件と検索結果がある
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_4_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst301Form mst301Form = new Mst301Form();
        // 検索条件と検索結果がある
        // 料金項目1コード
        mst301Form.setConRyokinKomoku1Cd("conRyokinKomoku1Cd1");
        // 料金項目1名称
        mst301Form.setConRyokinKomoku1Mei("conRyokinKomoku1Mei1");
        // 料金項目2コード
        mst301Form.setConRyokinKomoku2Cd("conRyokinKomoku2Cd1");
        // 料金項目2名称
        mst301Form.setConRyokinKomoku2Mei("conRyokinKomoku2Mei1");
        // 処理科目
        AutoCompOptionBean conSyoriKamoku = new AutoCompOptionBean();
        conSyoriKamoku.setValue("conSyoriKamoku1");
        mst301Form.setConSyoriKamoku(conSyoriKamoku);
        // 補助科目
        AutoCompOptionBean conHojoKamoku = new AutoCompOptionBean();
        conHojoKamoku.setValue("conHojoKamoku1");
        mst301Form.setConHojoKamoku(conHojoKamoku);
        // 卸値計算パターン
        mst301Form.setConOroshineKeisanPattern("conOroshineKeisanPattern1");
        // 適用名
        mst301Form.setConTekiyoMei("conTekiyoMei1");
        // 世代検索条件
        mst301Form.setConSedaiKensakuJoken(new String[]{"01"});
        // 適用日
        mst301Form.setConTekiyoBi("2019/03/22");
        // 削除のみ検索
        mst301Form.setConSakujoNomiKensaku(new String[]{"conSakujoNomiKensaku1"});
        
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i <= 0; i++){
            result.add(createRecMapFor_1_1(i));
        }
        mst301Form.setSearchResult(result);

        target.setForm(mst301Form);
        target.clear();

        //実施結果Outを取得
        mst301Form = target.getForm();

        // 想定通りに正常にClearを実施されること
        // 検索条件をクリアする
        assertEquals(null,mst301Form.getConRyokinKomoku1Cd());
        assertEquals(null,mst301Form.getConRyokinKomoku1Mei());
        assertEquals(null,mst301Form.getConRyokinKomoku2Cd());
        assertEquals(null,mst301Form.getConRyokinKomoku2Mei());
        assertEquals(null,mst301Form.getConSyoriKamoku());
        assertEquals(null,mst301Form.getConHojoKamoku());
        assertEquals(null,mst301Form.getConOroshineKeisanPattern());
        assertEquals(null,mst301Form.getConTekiyoMei());
        assertEquals(2,mst301Form.getConSedaiKensakuJoken().length);
        assertEquals(null,mst301Form.getConTekiyoBi());
        assertEquals(null,mst301Form.getConSakujoNomiKensaku());
        // 検索結果がクリアされない
        assertForRecList_2_1(mst301Form);
    }

    // clear_正常_クリア処理_4-2
    //
    // -------------------テスト条件--------------------------
    // 検索条件がある、検索結果がない
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_4_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst301Form form = new Mst301Form();
        // 料金項目1コード
        form.setConRyokinKomoku1Cd("conRyokinKomoku1Cd1");
        // 料金項目1名称
        form.setConRyokinKomoku1Mei("conRyokinKomoku1Mei1");
        // 料金項目2コード
        form.setConRyokinKomoku2Cd("conRyokinKomoku2Cd1");
        // 料金項目2名称
        form.setConRyokinKomoku2Mei("conRyokinKomoku2Mei1");
        // 処理科目
        AutoCompOptionBean conSyoriKamoku = new AutoCompOptionBean();
        conSyoriKamoku.setValue("conSyoriKamoku1");
        form.setConSyoriKamoku(conSyoriKamoku);
        // 補助科目
        AutoCompOptionBean conHojoKamoku = new AutoCompOptionBean();
        conHojoKamoku.setValue("conHojoKamoku1");
        form.setConHojoKamoku(conHojoKamoku);
        // 卸値計算パターン
        form.setConOroshineKeisanPattern("conOroshineKeisanPattern1");
        // 適用名
        form.setConTekiyoMei("conTekiyoMei1");
        // 世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01"});
        // 適用日
        form.setConTekiyoBi("2019/03/22");
        // 削除のみ検索
        form.setConSakujoNomiKensaku(new String[]{"conSakujoNomiKensaku1"});
        target.setForm(form);
        target.clear();

        //実施結果Outを取得
        form = target.getForm();

        //想定通りに正常にClearを実施されること
        assertEquals(null,form.getConRyokinKomoku1Cd());
        assertEquals(null,form.getConRyokinKomoku1Mei());
        assertEquals(null,form.getConRyokinKomoku2Cd());
        assertEquals(null,form.getConRyokinKomoku2Mei());
        assertEquals(null,form.getConSyoriKamoku());
        assertEquals(null,form.getConHojoKamoku());
        assertEquals(null,form.getConOroshineKeisanPattern());
        assertEquals(null,form.getConTekiyoMei());
        assertEquals(2,form.getConSedaiKensakuJoken().length);
        assertEquals(null,form.getConTekiyoBi());
        assertEquals(null,form.getConSakujoNomiKensaku());
        assertEquals(null, form.getSearchResult());
    }

    // getHeader_正常_ダウンロード_5-1
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void getHeader_正常_ダウンロード_5_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst301Form form = new Mst301Form();
        target.setForm(form);
        List<CSVDto> dto = target.getHeader();

        //実施結果Outを取得
        form = target.getForm();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にCVSのHeaderを設定されること
        assertEquals(null,form.getConRyokinKomoku1Cd());
        assertEquals(null,form.getConRyokinKomoku1Mei());
        assertEquals(null,form.getConRyokinKomoku2Cd());
        assertEquals(null,form.getConRyokinKomoku2Mei());
        assertEquals(null,form.getConSyoriKamoku());
        assertEquals(null,form.getConHojoKamoku());
        assertEquals(null,form.getConOroshineKeisanPattern());
        assertEquals(null,form.getConTekiyoMei());
        assertEquals(null,form.getConSedaiKensakuJoken());
        assertEquals(null,form.getConTekiyoBi());
        assertEquals(null,form.getConSakujoNomiKensaku());
        assertEquals("料金項目1コード",dto.get(0).getTitle());
        assertEquals("listRyokinkomoku1Cd",dto.get(0).getName());
        assertEquals("料金項目1名称",dto.get(1).getTitle());
        assertEquals("listRyokinkomoku1Mei",dto.get(1).getName());
        assertEquals("料金項目2コード",dto.get(2).getTitle());
        assertEquals("listRyokinkomoku2Cd",dto.get(2).getName());
        assertEquals("料金項目2名称",dto.get(3).getTitle());
        assertEquals("listRyokinkomoku2Mei",dto.get(3).getName());
        assertEquals("適用開始日",dto.get(4).getTitle());
        assertEquals("listTekiyoKaishibi",dto.get(4).getName());
        assertEquals("値引不可",dto.get(5).getTitle());
        assertEquals("listNebikiHuka",dto.get(5).getName());
        assertEquals("小数点区分",dto.get(6).getTitle());
        assertEquals("listShosutenKbn",dto.get(6).getName());
        assertEquals("税区分",dto.get(7).getTitle());
        assertEquals("listZeiKbn",dto.get(7).getName());
        assertEquals("スポット追加可能",dto.get(8).getTitle());
        assertEquals("listSpotTuikaKano",dto.get(8).getName());
        assertEquals("売上セット先",dto.get(9).getTitle());
        assertEquals("listUriageSetSaki",dto.get(9).getName());
        assertEquals("卸値計算パターン",dto.get(10).getTitle());
        assertEquals("listOroshineKeisanPattern",dto.get(10).getName());
        assertEquals("卸科目コード",dto.get(11).getTitle());
        assertEquals("listOroshikomokuCd",dto.get(11).getName());
        assertEquals("卸科目名称",dto.get(12).getTitle());
        assertEquals("listOroshikomokuMei",dto.get(12).getName());
        assertEquals("処理科目コード",dto.get(13).getTitle());
        assertEquals("listShorikamokuCd",dto.get(13).getName());
        assertEquals("処理科目名称",dto.get(14).getTitle());
        assertEquals("listShorikamokuMei",dto.get(14).getName());
        assertEquals("補助科目コード",dto.get(15).getTitle());
        assertEquals("listHojokamokuCd",dto.get(15).getName());
        assertEquals("補助科目名称",dto.get(16).getTitle());
        assertEquals("listHojokamokuMei",dto.get(16).getName());
        assertEquals("適用名",dto.get(17).getTitle());
        assertEquals("listTeikiyoMei",dto.get(17).getName());
        assertEquals("適用終了日",dto.get(18).getTitle());
        assertEquals("listTekiyoShuryobi",dto.get(18).getName());
    }

    // beforeDown_正常_ダウンロード_5-2
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=2件
    // -----------------------------------------------------
    @Test
    public void beforeDown_正常_ダウンロード_5_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst301Form form = new Mst301Form();
        target.setForm(form);
        try {
            target.beforeDown("testComment");
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(Mst301BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        //実施結果Outを取得
        form = target.getForm();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にダウンロード理由を記録すること
        assertEquals(null,form.getConRyokinKomoku1Cd());
    }    
    
    // checkParamas_正常_検索パラメータチェック_6-1
    //
    // -------------------テスト条件--------------------------
    // 世代検索条件=null
    // -----------------------------------------------------
    @Test
    public void checkParamas_正常_検索パラメータチェック_6_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst301Form form = new Mst301Form();
        form.setConSedaiKensakuJoken(null);
        target.setForm(form);
        String ret = target.checkParamas();

        //実施結果検証
        assertEquals("TRUE",ret);
    }

    // checkParamas_正常_検索パラメータチェック_6-2
    //
    // -------------------テスト条件--------------------------
    // 世代検索条件件数=0
    // -----------------------------------------------------
    @Test
    public void checkParamas_正常_検索パラメータチェック_6_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst301Form form = new Mst301Form();
        form.setConSedaiKensakuJoken(new String[0]);
        target.setForm(form);
        String ret = target.checkParamas();

        //実施結果検証
        assertEquals("TRUE",ret);
    }

    // checkParamas_正常_検索パラメータチェック_6-3
    //
    // -------------------テスト条件--------------------------
    // 適用日指定が選択されていない場合
    // -----------------------------------------------------
    @Test
    public void checkParamas_正常_検索パラメータチェック_6_3 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst301Form form = new Mst301Form();
        form.setConSedaiKensakuJoken(new String[]{"01"});
        target.setForm(form);
        when(kbnBean.getKbnCdOfKeyCd(MsCnst.SEDAI_KENSAKU_JOKEN_TEKIYO_HI_SHITEI)).thenReturn("05");
        String ret = target.checkParamas();

        //実施結果検証
        assertEquals("TRUE",ret);
    }

    // checkParamas_正常_検索パラメータチェック_6-4
    //
    // -------------------テスト条件--------------------------
    // 適用日指定が選択されている、適用日が入力されていない場合
    // -----------------------------------------------------
    @Test
    public void checkParamas_正常_検索パラメータチェック_6_4 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst301Form form = new Mst301Form();
        form.setConSedaiKensakuJoken(new String[]{"05"});
        form.setConTekiyoBi(null);
        target.setForm(form);
        when(kbnBean.getKbnCdOfKeyCd(MsCnst.SEDAI_KENSAKU_JOKEN_TEKIYO_HI_SHITEI)).thenReturn("05");
        String ret = target.checkParamas();

        //実施結果検証
        assertEquals("FALSE",ret);
    }

    // checkParamas_正常_検索パラメータチェック_6-5
    //
    // -------------------テスト条件--------------------------
    // 適用日指定が選択されている、適用日が入力されている場合
    // -----------------------------------------------------
    @Test
    public void checkParamas_正常_検索パラメータチェック_6_5 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst301Form form = new Mst301Form();
        form.setConSedaiKensakuJoken(new String[]{"05"});
        form.setConTekiyoBi("2019/03/22");
        target.setForm(form);
        when(kbnBean.getKbnCdOfKeyCd(MsCnst.SEDAI_KENSAKU_JOKEN_TEKIYO_HI_SHITEI)).thenReturn("05");
        String ret = target.checkParamas();

        //実施結果検証
        assertEquals("TRUE",ret);
    }

    // update_異常_更新処理_7-1-1
    //
    // -------------------テスト条件--------------------------
    // １行でも選択されていない場合
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_7_1_1 () throws IllegalAccessException, InvocationTargetException {

        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        MessageModuleBean messageModuleBean = new MessageModuleBean();
         
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);

        Mst301Form form = new Mst301Form();
        target.setForm(form);
        target.update();
        
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0029",summaryCaptor_2.getValue());
    }

    // update_異常_更新処理_7-1-2
    //
    // -------------------テスト条件--------------------------
    // １行でも選択されていない場合
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_7_1_2 () throws IllegalAccessException, InvocationTargetException {

        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        MessageModuleBean messageModuleBean = new MessageModuleBean();
         
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);

        Mst301Form form = new Mst301Form();
        List<Map<String, Object>> result = new ArrayList<>();
        form.setSelectedSearchResult(result);
        target.setForm(form);
        target.update();
        
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0029",summaryCaptor_2.getValue());
    }

    // update_異常_更新処理_7-2
    //
    // -------------------テスト条件--------------------------
    // 料金項目1コードなどの必須項目が入力されていない場合
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_7_2 () throws IllegalAccessException, InvocationTargetException {

        ArgumentCaptor<List> checksCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<List> checksCaptor_2 = ArgumentCaptor.forClass(List.class);
        Mst301Form form = new Mst301Form();
        List<Map<String, Object>> result = new ArrayList<>();
        Map recMap = new HashMap();
        // 料金項目1コード
        recMap.put("listRyokinkomoku1Cd", "");
        // 料金項目1名称
        recMap.put("listRyokinkomoku1Mei", "");
        // 料金項目2コード
        recMap.put("listRyokinkomoku2Cd", "");
        // 料金項目2名称
        recMap.put("listRyokinkomoku2Mei", "");
        // 適用開始日
        recMap.put("listTekiyoKaishibi", "");
        // 小数点区分
        recMap.put("listShosutenKbn", "");
        // 税区分
        recMap.put("listZeiKbn", "");
        // 処理科目コード
        recMap.put("listShorikamokuCd", "");
        // 処理科目名称
        recMap.put("listShorikamokuMei", "");
        // 補助科目コード
        recMap.put("listHojokamokuCd", "");
        // 補助科目名称
        recMap.put("listHojokamokuMei", "");
        // 適用名
        recMap.put("listTeikiyoMei", "");
        result.add(recMap);
        form.setSelectedSearchResult(result);

        List<MessageModuleBean> messageList = new ArrayList<>();
        MessageModuleBean message = messagePropertyBean.createMessageModule("ERROR", "COME0003", "料金項目1コード");
        messageList.add(message);
        
        when(listCheckBean.check(checksCaptor_1.capture(), checksCaptor_2.capture())).thenReturn(messageList);

        target.setForm(form);
        target.update();
    }

    // update_異常_更新処理_7-3
    //
    // -------------------テスト条件--------------------------
    // 入力した料金項目1コード・料金項目2コード・適用開始日と同一データがDBに存在する[MSTE0053]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_7_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力した料金項目1コード・料金項目2コード・適用開始日と同一データがDBに存在する[MSTE0053]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0053", "");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());

        //テスト実行
        Mst301Form form = new Mst301Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setForm(form);
        target.update();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listLogiRyokinKomokuDataVersion0", paramsCaptor_1_Param.get("listLogiRyokinKomokuDataVersion"));
        assertEquals("listRyokinkomoku1Cd0", paramsCaptor_1_Param.get("listRyokinkomoku1Cd"));
        assertEquals("listRyokinkomoku1Mei0", paramsCaptor_1_Param.get("listRyokinkomoku1Mei"));
        assertEquals("listRyokinkomoku2Cd0", paramsCaptor_1_Param.get("listRyokinkomoku2Cd"));
        assertEquals("listRyokinkomoku2Mei0", paramsCaptor_1_Param.get("listRyokinkomoku2Mei"));
        assertEquals("2019/03/22", paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals("listNebikiHuka0", paramsCaptor_1_Param.get("listNebikiHuka"));
        assertEquals("listShosutenKbn0", paramsCaptor_1_Param.get("listShosutenKbn"));
        assertEquals("listZeiKbn0", paramsCaptor_1_Param.get("listZeiKbn"));
        assertEquals("listSpotTuikaKano0", paramsCaptor_1_Param.get("listSpotTuikaKano"));
        assertEquals("listUriageSetSaki0", paramsCaptor_1_Param.get("listUriageSetSaki"));
        assertEquals("listOroshineKeisanPattern0", paramsCaptor_1_Param.get("listOroshineKeisanPattern"));
        assertEquals("listShorikamokuCd0", paramsCaptor_1_Param.get("listShorikamokuCd"));
        assertEquals("listShorikamokuMei0", paramsCaptor_1_Param.get("listShorikamokuMei"));
        assertEquals("listHojokamokuCd0", paramsCaptor_1_Param.get("listHojokamokuCd"));
        assertEquals("listHojokamokuMei0", paramsCaptor_1_Param.get("listHojokamokuMei"));
        assertEquals("listTeikiyoMei0", paramsCaptor_1_Param.get("listTeikiyoMei"));
        assertEquals("2099/03/22", paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("mst301_check_update",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0018）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("MSTE0053",summaryCaptor_4.getValue());
    }

    // update_正常_更新処理_7-4
    //
    // -------------------テスト条件--------------------------
    // 正常に登録と更新
    // -----------------------------------------------------
    @Test
    public void update_正常_更新処理_7_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        
        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得 件数 = 1
        List<Map<String, Object>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 1; i++) {
            resultS.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        //テスト実行
        Mst301Form form = new Mst301Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i <= 1; i++){
            result.add(createRecMapFor_11_1(i));
        }        
        form.setSelectedSearchResult(result);
        // 世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"02"});
        List<KbnModuleBean> list = new ArrayList<>();
        KbnModuleBean kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnCd("01");
        list.add(kbnModuleBean);
        kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnCd("02");
        list.add(kbnModuleBean);
        form.setConSedaiKensakuJokenLabelValueList(list);
        // 削除のみ検索
        form.setConSakujoNomiKensaku(new String[]{});
        target.setForm(form);
        target.update();

        // 実行時に渡すパラメータの検証
        assertEquals("mst301_insertupdate",functionCodeCaptor_2.getValue());
        //想定通りに正常終了メッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0011",summaryCaptor_4.getValue());
        assertEquals("更新",detailCaptor_5.getValue());
    }    

    // delRows_異常_削除処理_8-1
    //
    // -------------------テスト条件--------------------------
    // １行でも選択されていない
    // -----------------------------------------------------
    @Test
    public void delRows_異常_削除処理_8_1 () throws IllegalAccessException, InvocationTargetException {

        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        MessageModuleBean messageModuleBean = new MessageModuleBean();
         
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);

        Mst301Form form = new Mst301Form();
        List<Map<String, Object>> result = new ArrayList<>();
        form.setSelectedSearchResult(result);
        target.setForm(form);
        target.delete();
        
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0029",summaryCaptor_2.getValue());
    }    

    // delRows_異常_削除処理_8-2-1
    //
    // -------------------テスト条件--------------------------
    // 料金項目1コード・料金項目2コード・適用開始日の組み合わせがロジ料金項目マスタに存在しない場合
    // -----------------------------------------------------
    @Test
    public void delRows_異常_削除処理_8_2_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0109", "");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture());
        //テスト実行
        Mst301Form form = new Mst301Form();
        //行選択チェック選択 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setForm(form);
        target.delete();

        // 実行時に渡すパラメータの検証
        assertEquals("mst301_check_delete",functionCodeCaptor_2.getValue());
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("MSTE0109",summaryCaptor_4.getValue());
        assertEquals("ロジ料金項目",paramCaptor_5.getValue());
    }    

    // delRows_異常_削除処理_8-2-2
    //
    // -------------------テスト条件--------------------------
    // 他のユーザが更新した場合
    // -----------------------------------------------------
    @Test
    public void delRows_異常_削除処理_8_2_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("WARN", "COME0014", "");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture());
        //テスト実行
        Mst301Form form = new Mst301Form();
        //行選択チェック選択 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setForm(form);
        target.delete();

        // 実行時に渡すパラメータの検証
        assertEquals("mst301_check_delete",functionCodeCaptor_2.getValue());
        assertEquals("WARN",levelCaptor_3.getValue());
        assertEquals("COME0014",summaryCaptor_4.getValue());
    }    

    // delRows_正常_削除処理_8-3
    //
    // -------------------テスト条件--------------------------
    // 正常に削除の場合
    // -----------------------------------------------------
    @Test
    public void delRows_正常_削除処理_8_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        //テスト実行
        Mst301Form form = new Mst301Form();
        //行選択チェック選択 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        form.setSearchResult(result);
        form.setSelectedSearchResult(result);
        target.setForm(form);
        target.delete();

        // 実行時に渡すパラメータの検証
        assertEquals("mst301_delete",functionCodeCaptor_2.getValue());
        //想定通りに正常終了メッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0011",summaryCaptor_4.getValue());
        assertEquals("削除",detailCaptor_5.getValue());
    }  

    // rirekiIchiran_正常_更新履歴コンテキストメニュー_9-1
    //
    // -------------------テスト条件--------------------------
    // 正常に取得された場合
    // -----------------------------------------------------
    @Test
    public void rirekiIchiran_正常_更新履歴コンテキストメニュー_9_1 () throws IllegalAccessException, 
            InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> titleFlgCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> searchKeyCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(rirekiSyosaiBean).searchList(titleFlgCaptor_1.capture(),functionCodeCaptor_2.capture()
                ,searchKeyCaptor_3.capture());
        //テスト実行
        Mst301Form form = new Mst301Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setForm(form);
        target.rirekiIchiran();

        //想定通りに履歴を表示する。
        assertEquals("2",titleFlgCaptor_1.getValue());
        assertEquals("MST301_SEARCH_RIREKI",functionCodeCaptor_2.getValue());
        assertEquals("listRyokinkomoku1Cd0",searchKeyCaptor_3.getValue().get("listRyokinkomoku1Cd"));
        assertEquals("listRyokinkomoku2Cd0",searchKeyCaptor_3.getValue().get("listRyokinkomoku2Cd"));
        assertEquals(new Date("2019/03/22"),searchKeyCaptor_3.getValue().get("listTekiyoKaishibi"));
    }    

    // searchChange_正常_検索条件変更処理_10-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void searchChange_正常_検索条件変更処理_10_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst301Form form = new Mst301Form();
        target.setForm(form);
        target.searchChange();
    }

    // menuClick_正常_メニュークリック処理_11-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_メニュークリック処理_11_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst301Form form = new Mst301Form();
        target.setForm(form);
        target.menuClick("","");
    }

    // menuClick_正常_メニュークリック処理_11-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_メニュークリック処理_11_2 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(1);

        //テスト実行
        Mst301Form form = new Mst301Form();
        target.setForm(form);
        target.menuClick("","");
    }
    
    // breadClumClick_正常_パンくずクリック処理_12-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_パンくずクリック処理_12_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst301Form form = new Mst301Form();
        target.setForm(form);
        target.breadClumClick("", 0);
    }

    // breadClumClick_正常_パンくずクリック処理_12-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_パンくずクリック処理_12_2 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(0);        
        
        //テスト実行
        Mst301Form form = new Mst301Form();
        target.setForm(form);
        target.breadClumClick("", 0);
    }    
    
    // logoutClick_正常_ログアウト処理_13-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void logoutClick_正常_ログアウト処理_13_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst301Form form = new Mst301Form();
        target.setForm(form);
        target.logoutClick();
    }

    // setListCodeName_正常_AUTOCOMPLETE選択時コードと名称の設定処理_14-1
    //
    // -------------------テスト条件--------------------------
    // option=null
    // -----------------------------------------------------
    @Test
    public void setListCodeName_正常_AUTOCOMPLETE選択時コードと名称の設定処理_14_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst301Form form = new Mst301Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setForm(form);
        target.setListCodeName(form.getSelectedSearchResult(), "0", null, "colCodeName", "colNameName");
        
        //実施結果Outを取得
        form = target.getForm();

        //想定通りにコードと名称の値がクリアされること
        assertEquals("", form.getSelectedSearchResult().get(0).get("colCodeName"));
        assertEquals("", form.getSelectedSearchResult().get(0).get("colNameName"));
    }

    // setListCodeName_正常_AUTOCOMPLETE選択時コードと名称の設定処理_14-2
    //
    // -------------------テスト条件--------------------------
    // option!=null
    // -----------------------------------------------------
    @Test
    public void setListCodeName_正常_AUTOCOMPLETE選択時コードと名称の設定処理_14_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst301Form form = new Mst301Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setForm(form);
        AutoCompOptionBean option = new AutoCompOptionBean();
        option.setLabel("label0");
        option.setValue("value0");
        target.setListCodeName(form.getSelectedSearchResult(), "0", option, "colCodeName", "colNameName");
        
        //実施結果Outを取得
        form = target.getForm();

        //想定通りにコードと名称の値がクリアされること
        assertEquals("value0", form.getSelectedSearchResult().get(0).get("colCodeName"));
        assertEquals("label0", form.getSelectedSearchResult().get(0).get("colNameName"));
    }

    // delRowsFunc_正常_業務削除処理ファンクション領域_15-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void delRowsFunc_正常_業務削除処理ファンクション領域_15_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst301Form form = new Mst301Form();
        target.setForm(form);
        target.delRowsFunc();
    }

    private Map<String, Object> createRecMapFor_1_1(int i) {
        Map recMap = new HashMap();
        recMap.put("listRyokinkomoku1Cd", "listRyokinkomoku1Cd" + i);
        recMap.put("listRyokinkomoku2Cd", "listRyokinkomoku2Cd" + i);
        recMap.put("listTekiyoKaishibi", "listTekiyoKaishibi" + i);
        recMap.put("listRyokinkomoku1Mei", "listRyokinkomoku1Mei" + i);
        recMap.put("listRyokinkomoku2Mei", "listRyokinkomoku2Mei" + i);
        recMap.put("listNebikiHuka", "listNebikiHuka" + i);
        recMap.put("listShosutenKbn", "listShosutenKbn" + i);
        recMap.put("listZeiKbn", "listZeiKbn" + i);
        recMap.put("listSpotTuikaKano", "listSpotTuikaKano" + i);
        recMap.put("listUriageSetSaki", "listUriageSetSaki" + i);
        recMap.put("listOroshineKeisanPattern", "listOroshineKeisanPattern" + i);
        if (i == 0) {
            recMap.put("listOroshikomokuCd", "listOroshikomokuCd" + i);
        }
        recMap.put("listOroshikomokuMei", "listOroshikomokuMei" + i);
        if (i == 0) {
            recMap.put("listShorikamokuCd", "listShorikamokuCd" + i);
        }
        recMap.put("listShorikamokuMei", "listShorikamokuMei" + i);
        if (i == 0) {
            recMap.put("listHojokamokuCd", "listHojokamokuCd" + i);
        }
        recMap.put("listHojokamokuMei", "listHojokamokuMei" + i);
        recMap.put("listTeikiyoMei", "listTeikiyoMei" + i);
        recMap.put("listTekiyoShuryobi", "listTekiyoShuryobi" + i);
        recMap.put("listLogiRyokinKomokuDataVersion", "listLogiRyokinKomokuDataVersion" + i);
        recMap.put("listKoshinCounter", "listKoshinCounter" + i);
        recMap.put("listKoshinUser", "listKoshinUser" + i);
        return recMap;
    }

    private Map<String, Object> createRecMapFor_11_1(int i) {
        Map recMap = new HashMap();
        recMap.put("listLogiRyokinKomokuDataVersion", "listLogiRyokinKomokuDataVersion" + i);
        recMap.put("listRyokinkomoku1Cd", "listRyokinkomoku1Cd" + i);
        recMap.put("listRyokinkomoku1Mei", "listRyokinkomoku1Mei" + i);
        recMap.put("listRyokinkomoku2Cd", "listRyokinkomoku2Cd" + i);
        recMap.put("listRyokinkomoku2Mei", "listRyokinkomoku2Mei" + i);
        recMap.put("listTekiyoKaishibi", new Date("2019/03/22"));
        recMap.put("listNebikiHuka", "listNebikiHuka" + i);
        recMap.put("listShosutenKbn", "listShosutenKbn" + i);
        recMap.put("listZeiKbn", "listZeiKbn" + i);
        recMap.put("listSpotTuikaKano", "listSpotTuikaKano" + i);
        recMap.put("listUriageSetSaki", "listUriageSetSaki" + i);
        recMap.put("listOroshineKeisanPattern", "listOroshineKeisanPattern" + i);
        recMap.put("listShorikamokuCd", "listShorikamokuCd" + i);
        recMap.put("listShorikamokuMei", "listShorikamokuMei" + i);
        recMap.put("listHojokamokuCd", "listHojokamokuCd" + i);
        recMap.put("listHojokamokuMei", "listHojokamokuMei" + i);
        recMap.put("listTeikiyoMei", "listTeikiyoMei" + i);
        recMap.put("listTekiyoShuryobi", new Date("2099/03/22"));
        recMap.put("UNIQUE_KEY", String.valueOf(i));
        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }
    
    private void assertForRecList_2_1(Mst301Form form) {
        int i = 0;
        assertEquals(1, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listRyokinkomoku1Cd" + i, rec.get("listRyokinkomoku1Cd"));
            assertEquals("listRyokinkomoku2Cd" + i, rec.get("listRyokinkomoku2Cd"));
            assertEquals("listTekiyoKaishibi" + i, rec.get("listTekiyoKaishibi"));
            assertEquals("listRyokinkomoku1Mei" + i, rec.get("listRyokinkomoku1Mei"));
            assertEquals("listRyokinkomoku2Mei" + i, rec.get("listRyokinkomoku2Mei"));
            assertEquals("listNebikiHuka" + i, rec.get("listNebikiHuka"));
            assertEquals("listShosutenKbn" + i, rec.get("listShosutenKbn"));
            assertEquals("listZeiKbn" + i, rec.get("listZeiKbn"));
            assertEquals("listSpotTuikaKano" + i, rec.get("listSpotTuikaKano"));
            assertEquals("listUriageSetSaki" + i, rec.get("listUriageSetSaki"));
            assertEquals("listOroshineKeisanPattern" + i, rec.get("listOroshineKeisanPattern"));
            if (i == 0) {
                assertEquals("listOroshikomokuCd" + i, rec.get("listOroshikomokuCd"));
            } else {
                assertEquals(null, rec.get("listOroshikomokuCd"));
            }
            if (i == 0) {
                assertEquals("listShorikamokuCd" + i, rec.get("listShorikamokuCd"));
            } else {
                assertEquals(null, rec.get("listShorikamokuCd"));
            }
            if (i == 0) {
                assertEquals("listHojokamokuCd" + i, rec.get("listHojokamokuCd"));
            } else {
                assertEquals(null, rec.get("listHojokamokuCd"));
            }
            assertEquals("listOroshikomokuMei" + i, rec.get("listOroshikomokuMei"));
            assertEquals("listShorikamokuMei" + i, rec.get("listShorikamokuMei"));
            assertEquals("listHojokamokuMei" + i, rec.get("listHojokamokuMei"));
            assertEquals("listTeikiyoMei" + i, rec.get("listTeikiyoMei"));
            assertEquals("listTekiyoShuryobi" + i, rec.get("listTekiyoShuryobi"));
            assertEquals("listLogiRyokinKomokuDataVersion" + i, rec.get("listLogiRyokinKomokuDataVersion"));
            assertEquals("listKoshinCounter" + i, rec.get("listKoshinCounter"));
            assertEquals("listKoshinUser" + i, rec.get("listKoshinUser"));
            i++;
        }
    }    

    private void assertForRecList_2_2(Mst301Form form) {
        int i = 0;
        assertEquals(2, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listRyokinkomoku1Cd" + i, rec.get("listRyokinkomoku1Cd"));
            assertEquals("listRyokinkomoku2Cd" + i, rec.get("listRyokinkomoku2Cd"));
            assertEquals("listTekiyoKaishibi" + i, rec.get("listTekiyoKaishibi"));
            assertEquals("listRyokinkomoku1Mei" + i, rec.get("listRyokinkomoku1Mei"));
            assertEquals("listRyokinkomoku2Mei" + i, rec.get("listRyokinkomoku2Mei"));
            assertEquals("listNebikiHuka" + i, rec.get("listNebikiHuka"));
            assertEquals("listShosutenKbn" + i, rec.get("listShosutenKbn"));
            assertEquals("listZeiKbn" + i, rec.get("listZeiKbn"));
            assertEquals("listSpotTuikaKano" + i, rec.get("listSpotTuikaKano"));
            assertEquals("listUriageSetSaki" + i, rec.get("listUriageSetSaki"));
            assertEquals("listOroshineKeisanPattern" + i, rec.get("listOroshineKeisanPattern"));
            if (i == 0) {
                assertEquals("listOroshikomokuCd" + i, rec.get("listOroshikomokuCd"));
            } else {
                assertEquals(null, rec.get("listOroshikomokuCd"));
            }
            if (i == 0) {
                assertEquals("listShorikamokuCd" + i, rec.get("listShorikamokuCd"));
            } else {
                assertEquals(null, rec.get("listShorikamokuCd"));
            }
            if (i == 0) {
                assertEquals("listHojokamokuCd" + i, rec.get("listHojokamokuCd"));
            } else {
                assertEquals(null, rec.get("listHojokamokuCd"));
            }
            assertEquals("listOroshikomokuMei" + i, rec.get("listOroshikomokuMei"));
            assertEquals("listShorikamokuMei" + i, rec.get("listShorikamokuMei"));
            assertEquals("listHojokamokuMei" + i, rec.get("listHojokamokuMei"));
            assertEquals("listTeikiyoMei" + i, rec.get("listTeikiyoMei"));
            assertEquals("listTekiyoShuryobi" + i, rec.get("listTekiyoShuryobi"));
            assertEquals("listLogiRyokinKomokuDataVersion" + i, rec.get("listLogiRyokinKomokuDataVersion"));
            assertEquals("listKoshinCounter" + i, rec.get("listKoshinCounter"));
            assertEquals("listKoshinUser" + i, rec.get("listKoshinUser"));
            i++;
        }
    }
    
}
