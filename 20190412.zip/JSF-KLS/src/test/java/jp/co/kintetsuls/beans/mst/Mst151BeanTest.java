/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst151Form;
import jp.co.kintetsuls.utils.FlashUtil;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import org.junit.After;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import org.mockito.MockitoAnnotations;

/**
 * 品名マスタ画面
 *
 * @author 许博 (MBP)
 * @version 2019/3/12 新規作成
 */
public class Mst151BeanTest {
    
    // テストTarget
    @InjectMocks
    private Mst151Bean target;
    
    // Mockitoオブジェクト
    @Mock
    private FileBean fileBean;
    @Mock
    private AutoCompleteViewBean autoCompleteViewBean;
    @Mock
    private MasterInfoBean masterInfo;
    @Mock
    private MessagePropertyBean messageProperty;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosai;
    @Mock
    private SearchHelpBean searchHelpBean;
    @Mock
    private AuthorityConfBean authConfBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private MessagePropertyBean messagePropertyBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosaiBean;
    @Mock
    private ListCheckBean listCheckBean;
    @Mock
    private FlashUtil flashUtil;
    
    public Mst151BeanTest(){   
    }
    
    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }
    
    @After
    public void tearDown() {
    }
    
    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[not null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1 () throws IllegalAccessException, InvocationTargetException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst151Form mst151Form = new Mst151Form();
        
        // 前画面情報[not null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst151Form);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        // テスト実行
        Mst151Form form = new Mst151Form();
        target.setMst151Form(form);
        // 戻ってきた場合、再検索を実施する。
        target.init("","MST031_SCREEN",true);
        
        // 実施結果Outを取得
        form = target.getMst151Form();
        String title = target.getTITLE();
        String url = target.getUrl();
        BreadCrumbBean breadBean = target.getBreadBean();
        AutoCompleteViewBean autoCompleteViewBean = target.getAutoCompleteViewBean();
        AuthorityConfBean authorityConfBean  = target.getAuthConfBean();
        FileBean fileBean = target.getFileBean();
        MessagePropertyBean messagePropertyBean = target.getMessagePropertyBean();
        PageCommonBean pageCommonBean = target.getPageCommonBean();
        SearchHelpBean searchHelpBean = target.getSearchHelpBean();
        RirekiSyosaiBean rirekiSyosaiBean = target.getRirekiSyosai();
        ListCheckBean listCheckBean = target.getListCheckBean();
        Map<String, Object> rirekiSearchKey = target.getRirekiSearchKey();
        List<MessageModuleBean> msgList = target.getMsgList();
        target.setUrl(url);
        target.setBreadBean(breadBean);
        target.setAutoCompleteViewBean(autoCompleteViewBean);
        target.setAuthConfBean(authorityConfBean);
        target.setFileBean(fileBean);
        target.setMessagePropertyBean(messagePropertyBean);
        target.setPageCommonBean(pageCommonBean);
        target.setSearchHelpBean(searchHelpBean);
        target.setRirekiSyosai(rirekiSyosaiBean);
        target.setListCheckBean(listCheckBean);
        target.setRirekiSearchKey(rirekiSearchKey);
        target.setMsgList(msgList);
        
        // 実行時に渡すパラメータの検証
        assertEquals("mst151Form",keyCaptor_1.getValue());
        // 想定通りに再検索を実施する。
        assertEquals("search_mst151",keyCaptor_2.getValue());
    }
    
    // mst151init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[営業所コード = conEigyosho1,顧客コード = conKokyaku1]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void mst151init_正常_初期処理_1_2() throws IllegalAccessException, InvocationTargetException,
            InstantiationException {
        
        // Mockitoオブジェクトの予想return値設定
        Mst151Form mst151Form = new Mst151Form();
        // 前回検索パラメータ[営業所コード = conEigyosho1,顧客コード = conKokyaku1]
        AutoCompOptionBean conEigyosho = new AutoCompOptionBean();
        AutoCompOptionBean conKokyaku = new AutoCompOptionBean();
        conEigyosho.setValue("conEigyosho1");
        conKokyaku.setValue("conKokyaku1");
        mst151Form.setConEigyosho(conEigyosho);
        mst151Form.setConKokyaku(conKokyaku);
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        // 前画面パラメータ[営業所コード = conEigyosho1,顧客コード = conKokyaku1]
        flash.put("mst151Form", mst151Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);        

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        // テスト実行
        Mst151Form form = new Mst151Form();
        target.setMst151Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //　実施結果Outを取得
        form = target.getMst151Form();

        //　想定通りに再検索を実施する。
        assertEquals("search_mst151",keyCaptor_2.getValue());
        assertEquals("conEigyosho1",form.getConEigyosho().getValue());
        assertEquals("conKokyaku1",form.getConKokyaku().getValue());
    }
    
    // init_正常_初期処理_1-2_1
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[営業所コード = conEigyosho1,顧客コード = conKokyaku1]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2_1() throws IllegalAccessException, InvocationTargetException,
            InstantiationException {

        // Mockitoオブジェクトの予想return値設定
        Mst151Form mst151Form = new Mst151Form();
        //前回検索パラメータ[営業所コード = conEigyosho1,顧客コード = conKokyaku1]
        AutoCompOptionBean conEigyosho = new AutoCompOptionBean();
        AutoCompOptionBean conKokyaku = new AutoCompOptionBean();
        conEigyosho.setValue("conEigyosho1");
        conKokyaku.setValue("conKokyaku1");
        mst151Form.setConEigyosho(conEigyosho);
        mst151Form.setConKokyaku(conKokyaku);
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        //前画面パラメータ[都道府県 = 01,仕向地名 = 地名23,削除済のみ検索 = null]
        flash.put("mst151Form", null);
        when(pageCommonBean.getPageParam()).thenReturn(flash);        

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst151Form form = new Mst151Form();
        target.setMst151Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst151Form();

        //想定通りに再検索を実施する。
        assertEquals(null,form.getConEigyosho());
    } 
    
    // init_正常_初期処理_1-3
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        // 前画面情報[null]
        doThrow(IllegalAccessException.class).when(pageCommonBean).getPageInfo(keyCaptor_1.capture());

        // テスト実行
        Mst151Form form = new Mst151Form();
        target.setMst151Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        // 実施結果Outを取得
        form = target.getMst151Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst151Form",keyCaptor_1.getValue());
        // 想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null,form.getSearchResult());
    }
    
    // search_正常_検索処理_2-1
    //
    // -------------------テスト条件--------------------------
    // 品名検索結果一覧取得
    // 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 品名検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=0;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);

        // テスト実行
        Mst151Form form = new Mst151Form();
        AutoCompOptionBean conEigyosho = new AutoCompOptionBean();
        AutoCompOptionBean conKokyaku = new AutoCompOptionBean();
        conEigyosho.setValue("conEigyosho1");
        conKokyaku.setValue("conKokyaku1");
        form.setConEigyosho(conEigyosho);
        form.setConKokyaku(conKokyaku);
        target.setMst151Form(form);
        target.search();

        // 実施結果Outを取得
        form = target.getMst151Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conEigyosho1", paramsCaptor_1.getValue().get("conEigyosho"));
        assertEquals("conKokyaku1", paramsCaptor_1.getValue().get("conKokyaku"));
        assertEquals("mst151-get-himmei-detail", functionCodeCaptor_2.getValue());
        //想定通りに仕向地名マスタ一覧を表示されること
        assertForRecList_2_1(form);
    } 
    
    // search_正常_検索処理_2-2
    //
    // -------------------テスト条件--------------------------
    // 品名検索結果一覧取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 品名検索結果一覧取得 取得件数 = 2
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=1;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);

        //テスト実行
        Mst151Form form = new Mst151Form();
        AutoCompOptionBean conEigyosho = new AutoCompOptionBean();
        AutoCompOptionBean conKokyaku = new AutoCompOptionBean();
        conEigyosho.setValue("conEigyosho2");
        conKokyaku.setValue("conKokyaku2");
        form.setConEigyosho(conEigyosho);
        form.setConKokyaku(conKokyaku);
        target.setMst151Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst151Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conEigyosho2", paramsCaptor_1.getValue().get("conEigyosho"));
        assertEquals("conKokyaku2", paramsCaptor_1.getValue().get("conKokyaku"));
        assertEquals("mst151-get-himmei-detail", functionCodeCaptor_2.getValue());
        //想定通りに仕向地名マスタ一覧を表示されること
        assertForRecList_2_2(form);
    }
    
    // search_異常_検索処理_2-3
    //
    // -------------------テスト条件--------------------------
    // 品名検索結果一覧取得 取得件数 = 0
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 品名検索結果一覧取得 取得件数 = 0
        List<Map<String, String>> result = new ArrayList<>();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);

        // テスト実行
        Mst151Form form = new Mst151Form();
        AutoCompOptionBean conEigyosho = new AutoCompOptionBean();
        AutoCompOptionBean conKokyaku = new AutoCompOptionBean();
        conEigyosho.setValue("conEigyosho3");
        conKokyaku.setValue("conKokyaku3");
        form.setConEigyosho(conEigyosho);
        form.setConKokyaku(conKokyaku);
        target.setMst151Form(form);
        target.search();

        // 実施結果Outを取得
        form = target.getMst151Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conEigyosho3", paramsCaptor_1.getValue().get("conEigyosho"));
        assertEquals("conKokyaku3", paramsCaptor_1.getValue().get("conKokyaku"));
        assertEquals("mst151-get-himmei-detail", functionCodeCaptor_2.getValue());
        //想定通りに・一覧は表示しない（ヘッダーのみ） 
        //想定通りに ・ファンクションボタンは表示（検索前と同じ） 
        assertForRecList_2_3(form);
    }
    
    // getRecordCount_正常_件数取得処理_2-4
    //
    // -------------------テスト条件--------------------------
    // 品名検索件数取得
    // -----------------------------------------------------
    @Test
    public void getRecordCount_異常_件数取得処理_2_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 品名検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);

        // テスト実行       
        Mst151Form form = new Mst151Form(); 
        AutoCompOptionBean conEigyosho = new AutoCompOptionBean();
        AutoCompOptionBean conKokyaku = new AutoCompOptionBean();
        conEigyosho.setValue("conEigyosho");
        conKokyaku.setValue("conKokyaku");
        form.setConEigyosho(conEigyosho);
        form.setConKokyaku(conKokyaku);
        target.setMst151Form(form);
        target.getRecordCount();

        // 実施結果Outを取得
        form = target.getMst151Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conEigyosho", paramsCaptor_1.getValue().get("conEigyosho"));
        assertEquals("conKokyaku", paramsCaptor_1.getValue().get("conKokyaku"));
        assertEquals("mst151-get-himmei-kensu",functionCodeCaptor_2.getValue());
        // 想定通りに正常にCountを実施されること
    }
    
    // getRecordCount_正常_件数取得処理_2-4_2
    //
    // -------------------テスト条件--------------------------
    // 品名検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_4_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 品名検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);

        // テスト実行
        Mst151Form form = new Mst151Form();
        AutoCompOptionBean conEigyosho = new AutoCompOptionBean();
        AutoCompOptionBean conKokyaku = new AutoCompOptionBean();
        conEigyosho.setValue("conEigyosho");
        conKokyaku.setValue("conKokyaku");
        form.setConEigyosho(conEigyosho);
        form.setConKokyaku(conKokyaku);
        target.setMst151Form(form);
        target.getRecordCount();

        // 実施結果Outを取得
        form = target.getMst151Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conEigyosho", paramsCaptor_1.getValue().get("conEigyosho"));
        assertEquals("conKokyaku", paramsCaptor_1.getValue().get("conKokyaku"));
        assertEquals("mst151-get-himmei-kensu",functionCodeCaptor_2.getValue());
        // 想定通りに正常にCountを実施されること
    }
    
    // clear_正常_クリア処理_3-1
    //
    // -------------------テスト条件--------------------------
    // 検索条件と検索結果がある
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_1 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst151Form form = new Mst151Form();
        // 品名検索条件と検索結果がある
        AutoCompOptionBean conEigyosho = new AutoCompOptionBean();
        AutoCompOptionBean conKokyaku = new AutoCompOptionBean();
        conEigyosho.setValue("conEigyosho");
        conKokyaku.setValue("conKokyaku");
        form.setConEigyosho(conEigyosho);
        form.setConKokyaku(conKokyaku);
        target.setMst151Form(form);
        target.clear();

        // 実施結果Outを取得
        form = target.getMst151Form();

        // 想定通りに正常にClearを実施されること
        assertEquals(null, form.getConEigyosho());
        assertEquals(null, form.getConKokyaku());
    }
    
    // clear_正常_クリア処理_3-2
    //
    // -------------------テスト条件--------------------------
    // 検索条件がある、検索結果がない
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_2 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst151Form form = new Mst151Form();
        target.setMst151Form(form);
        target.clear();

        // 実施結果Outを取得
        form = target.getMst151Form();

        // 想定通りに正常にClearを実施されること
        assertEquals(null, form.getConEigyosho());
        assertEquals(null, form.getConKokyaku());
    }
    
    // getHeader_正常_ダウンロード_4-1
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void getHeader_正常_ダウンロード_4_1 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst151Form form = new Mst151Form();
        AutoCompOptionBean conEigyosho = new AutoCompOptionBean();
        AutoCompOptionBean conKokyaku = new AutoCompOptionBean();
        conEigyosho.setValue("conEigyosho");
        conKokyaku.setValue("conKokyaku");
        form.setConEigyosho(conEigyosho);
        form.setConKokyaku(conKokyaku);
        target.setMst151Form(form);
        List<CSVDto> dto = target.getHeader();

        // 実施結果Outを取得
        form = target.getMst151Form();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にCVSのHeaderを設定されること
        assertEquals("conEigyosho", form.getConEigyosho().getValue());
        assertEquals("conKokyaku", form.getConKokyaku().getValue());
        assertEquals("品名コード",dto.get(0).getTitle());
        assertEquals("listHimmeiCd",dto.get(0).getName());
        assertEquals("品名",dto.get(1).getTitle());
        assertEquals("listHimmei",dto.get(1).getName());
    }
    
    // beforeDown_正常_ダウンロード_4-2
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=2件
    // -----------------------------------------------------
    @Test
    public void beforeDown_正常_ダウンロード_4_2 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst151Form form = new Mst151Form();
        target.setMst151Form(form);
        try {
            target.beforeDown("testComment");
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(Mst151BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        //実施結果Outを取得
        form = target.getMst151Form();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にダウンロード理由を記録すること
        assertEquals(null,form.getConEigyosho());
    }
    
    // upload_正常_アップロード_5_1
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void upload_正常_アップロード_5_1() throws IllegalAccessException, InvocationTargetException {
        ArgumentCaptor<String> urlCaptor_1 = ArgumentCaptor.forClass(String.class);
        //テスト実行
        Mst151Form form = new Mst151Form();
        Flash flash = new FlashKls();
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        when(flashUtil.getPageParam()).thenReturn(flash);
        target.upload();
    }
    
    // update_異常_更新処理_新規登録_11-1
    //
    // -------------------テスト条件--------------------------
    // 営業所コード、顧客コード、品名コードの組み合わせが、品名マスタに存在しています[MSTE0098]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_新規登録_11_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 営業所コード、顧客コード、品名コードの組み合わせが、品名マスタに存在しています[MSTE0098]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0098", "");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());

        //テスト実行
        Mst151Form form = new Mst151Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        AutoCompOptionBean conEigyosho = new AutoCompOptionBean();
        AutoCompOptionBean conKokyaku = new AutoCompOptionBean();
        conEigyosho.setValue("conEigyosho");
        conKokyaku.setValue("conKokyaku");
        form.setConEigyosho(conEigyosho);
        form.setConKokyaku(conKokyaku);
        form.setSelectedSearchResult(result);
        target.setMst151Form(form);
        target.update();

        // 実施結果Outを取得
        form = target.getMst151Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listHimmeiCd0",paramsCaptor_1_Param.get("listHimmeiCd"));
        assertEquals("listHimmei0",paramsCaptor_1_Param.get("listHimmei"));
        assertEquals("conEigyosho",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("conKokyaku",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listDataVersion0",paramsCaptor_1_Param.get("listDataVersion"));
        assertEquals("mst151-insert-update-check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：MSTE0098）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("MSTE0098",summaryCaptor_4.getValue());
    }

    // update_正常_更新処理_新規登録_11-2
    //
    // -------------------テスト条件--------------------------
    //  営業所コード、顧客コード、品名コードの組み合わせが、品名マスタに存在していない
    // -----------------------------------------------------
    @Test
    public void update_正常_更新処理_新規登録_11_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 営業所コード、顧客コード、品名コードの組み合わせが、品名マスタに存在していない
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        // 品名検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);

        //テスト実行
        Mst151Form form = new Mst151Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }        
        AutoCompOptionBean conEigyosho = new AutoCompOptionBean();
        AutoCompOptionBean conKokyaku = new AutoCompOptionBean();
        conEigyosho.setValue("conEigyosho");
        conKokyaku.setValue("conKokyaku");
        form.setConEigyosho(conEigyosho);
        form.setConKokyaku(conKokyaku);
        form.setSelectedSearchResult(result);
        target.setMst151Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst151Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listHimmeiCd0",paramsCaptor_1_Param.get("listHimmeiCd"));
        assertEquals("listHimmei0",paramsCaptor_1_Param.get("listHimmei"));
        assertEquals("conEigyosho",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("conKokyaku",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listDataVersion0",paramsCaptor_1_Param.get("listDataVersion"));
        assertEquals("mst151-insert-update",functionCodeCaptor_2.getValue());
        //想定通りに正常終了メッセージ（メッセージID：COMI0007）を表示されること
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0007",summaryCaptor_4.getValue());
        assertEquals("更新",detailCaptor_5.getValue());
    }  
    
    // update_異常_更新処理_新規登録_11-3
    //
    // -------------------テスト条件--------------------------
    // 相関チェック
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_新規登録_11_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 営業所コードと顧客コードの組み合わせが存在しない場合[MSTE0097]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0097", "");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());

        //テスト実行
        Mst151Form form = new Mst151Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<=1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        AutoCompOptionBean conEigyosho = new AutoCompOptionBean();
        AutoCompOptionBean conKokyaku = new AutoCompOptionBean();
        conEigyosho.setValue("conEigyosho");
        conKokyaku.setValue("conKokyaku");
        form.setConEigyosho(conEigyosho);
        form.setConKokyaku(conKokyaku);
        form.setSelectedSearchResult(result);
        target.setMst151Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst151Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listHimmeiCd0",paramsCaptor_1_Param.get("listHimmeiCd"));
        assertEquals("listHimmei0",paramsCaptor_1_Param.get("listHimmei"));
        assertEquals("conEigyosho",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("conKokyaku",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listDataVersion0",paramsCaptor_1_Param.get("listDataVersion"));
        assertEquals("mst151-insert-update-check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：MSTE0097）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("MSTE0097",summaryCaptor_4.getValue());
    } 
    
    // update_異常_更新処理_更新登録_11-4
    //
    // -------------------テスト条件--------------------------
    // 営業所コード、顧客コード、品名コードの組み合わせが、品名マスタに存在しない[COME0006]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_11_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 営業所コード、顧客コード、品名コードの組み合わせが、品名マスタに存在しない[MSTE0099]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0099", "");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());

        // テスト実行
        Mst151Form form = new Mst151Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        AutoCompOptionBean conEigyosho = new AutoCompOptionBean();
        AutoCompOptionBean conKokyaku = new AutoCompOptionBean();
        conEigyosho.setValue("conEigyosho");
        conKokyaku.setValue("conKokyaku");
        form.setConEigyosho(conEigyosho);
        form.setConKokyaku(conKokyaku);
        form.setSelectedSearchResult(result);
        target.setMst151Form(form);
        target.update();

        // 実施結果Outを取得
        form = target.getMst151Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listHimmeiCd0",paramsCaptor_1_Param.get("listHimmeiCd"));
        assertEquals("listHimmei0",paramsCaptor_1_Param.get("listHimmei"));
        assertEquals("conEigyosho",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("conKokyaku",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listDataVersion0",paramsCaptor_1_Param.get("listDataVersion"));
        assertEquals("mst151-insert-update-check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0006）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("MSTE0099",summaryCaptor_4.getValue());
}    
    
    // update_正常_更新処理_更新登録_11-5
    //
    // -------------------テスト条件--------------------------
    // 営業所コード、顧客コード、品名コードの組み合わせが、品名マスタに存在しています
    // -----------------------------------------------------
    @Test
    public void update_正常_更新処理_更新登録_11_5 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 営業所コード、顧客コード、品名コードの組み合わせが、品名マスタに存在しています
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4
                .capture(),detailCaptor_5.capture());        

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        // 品名検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        
        //テスト実行
        Mst151Form form = new Mst151Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }        
        AutoCompOptionBean conEigyosho = new AutoCompOptionBean();
        AutoCompOptionBean conKokyaku = new AutoCompOptionBean();
        conEigyosho.setValue("conEigyosho");
        conKokyaku.setValue("conKokyaku");
        form.setConEigyosho(conEigyosho);
        form.setConKokyaku(conKokyaku);
        form.setSelectedSearchResult(result);
        target.setMst151Form(form);
        target.update();
        // 実施結果Outを取得
        form = target.getMst151Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listHimmeiCd0",paramsCaptor_1_Param.get("listHimmeiCd"));
        assertEquals("listHimmei0",paramsCaptor_1_Param.get("listHimmei"));
        assertEquals("conEigyosho",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("conKokyaku",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listDataVersion0",paramsCaptor_1_Param.get("listDataVersion"));
        assertEquals("mst151-insert-update",functionCodeCaptor_2.getValue());
        // 想定通りに正常終了メッセージ（メッセージID：COMI0007）を表示されること
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0007",summaryCaptor_4.getValue());
        assertEquals("更新",detailCaptor_5.getValue());
    }  
    
    // update_異常_更新処理_更新登録_11-6
    //
    // -------------------テスト条件--------------------------
    // 相関チェック
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_11_6 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 営業所コードと顧客コードの組み合わせが存在しない場合[MSTE0097]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0097", "");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());

        // テスト実行
        Mst151Form form = new Mst151Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        AutoCompOptionBean conEigyosho = new AutoCompOptionBean();
        AutoCompOptionBean conKokyaku = new AutoCompOptionBean();
        conEigyosho.setValue("conEigyosho");
        conKokyaku.setValue("conKokyaku");
        form.setConEigyosho(conEigyosho);
        form.setConKokyaku(conKokyaku);
        form.setSelectedSearchResult(result);
        target.setMst151Form(form);
        target.update();

        // 実施結果Outを取得
        form = target.getMst151Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listHimmeiCd0",paramsCaptor_1_Param.get("listHimmeiCd"));
        assertEquals("listHimmei0",paramsCaptor_1_Param.get("listHimmei"));
        assertEquals("conEigyosho",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("conKokyaku",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listDataVersion0",paramsCaptor_1_Param.get("listDataVersion"));
        assertEquals("mst151-insert-update-check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：MSTE0097）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("MSTE0097",summaryCaptor_4.getValue());
    }
    
    // update_異常_更新処理_更新登録_11-7
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_11_7 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        // テスト実行
        Mst151Form form = new Mst151Form();
        // 行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        form.setSelectedSearchResult(result);
        target.setMst151Form(form);
        target.update();

        // 実施結果Outを取得
        form = target.getMst151Form();

        // 想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0029",summaryCaptor_2.getValue());
    }
    
    // update_異常_更新処理_更新登録_11-8
    //
    // -------------------テスト条件--------------------------
    // 品名コード == NULL
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_11_8 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Boolean> datasCaptor_3 = ArgumentCaptor.forClass(Boolean.class);
        ArgumentCaptor<List> checksCaptor_4 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<List> checksCaptor_5 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean2 = new MessageModuleBean();
        List<MessageModuleBean> msgList = new ArrayList<>();
        msgList.add(messageModuleBean2);

        when(listCheckBean.check(checksCaptor_4.capture(), checksCaptor_5.capture(), datasCaptor_3.capture()))
                .thenReturn(msgList); 

        // テスト実行
        Mst151Form form = new Mst151Form();
        // 行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        AutoCompOptionBean conEigyosho = new AutoCompOptionBean();
        AutoCompOptionBean conKokyaku = new AutoCompOptionBean();
        conEigyosho.setValue("conEigyosho");
        conKokyaku.setValue("conKokyaku");
        form.setConEigyosho(conEigyosho);
        form.setConKokyaku(conKokyaku);
        form.setSelectedSearchResult(result);
        target.setMst151Form(form);
        target.update();

        // 実施結果Outを取得
        form = target.getMst151Form();
}   
    
    // delRows_正常_品名マスタ削除処理_12-1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 1
    // 営業所コード、顧客コード、品名コードの組み合わせが、品名マスタに存在している
    // -----------------------------------------------------
    @Test
    public void delRows_正常_品名マスタ削除処理_12_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture());
        
        // テスト実行
        Mst151Form form = new Mst151Form();
        // 行選択チェック選択 = 1
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        
        form.setSearchResult(result);
        form.setSelectedSearchResult(result);
        target.setMst151Form(form);
        target.delRows(result);

        // 実施結果Outを取得
        form = target.getMst151Form();

        // 実行時に渡すパラメータの検証
        // 想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること仕向地名マスタ削除処理を行う。
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0004",summaryCaptor_4.getValue());
        assertEquals("削除",detailCaptor_5.getValue());
    }
    
    // delRows_正常_品名マスタ削除処理_12-2
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 2
    // 営業所コード、顧客コード、品名コードの組み合わせが、品名マスタに存在している
    // -----------------------------------------------------
    @Test
    public void delRows_正常_仕向地名マスタ削除処理_12_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture());
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        
        // テスト実行
        Mst151Form form = new Mst151Form();
        // 行選択チェック選択 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        AutoCompOptionBean conEigyosho = new AutoCompOptionBean();
        AutoCompOptionBean conKokyaku = new AutoCompOptionBean();
        conEigyosho.setValue("conEigyosho");
        conKokyaku.setValue("conKokyaku");
        form.setConEigyosho(conEigyosho);
        form.setConKokyaku(conKokyaku);
        form.setSearchResult(result);
        form.setSelectedSearchResult(result);
        target.setMst151Form(form);
        target.delRows(result);

        // 実施結果Outを取得
        form = target.getMst151Form();

        //想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること仕向地名マスタ削除処理を行う。
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0004",summaryCaptor_4.getValue());
        assertEquals("削除",detailCaptor_5.getValue());
    }  
    
    // delRows_異常_品名マスタ削除処理_12-3
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // 営業所コード、顧客コード、品名コードの組み合わせが、品名マスタに存在している
    // -----------------------------------------------------
    @Test
    public void delRows_異常_仕向地名マスタ削除処理_12_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        // テスト実行
        Mst151Form form = new Mst151Form();
        // 行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        form.setSelectedSearchResult(result);
        target.setMst151Form(form);
        target.delRows(result);

        // 実施結果Outを取得
        form = target.getMst151Form();

        // 想定通りにエラーが発生。（メッセージID：MSTE0093）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("MSTE0093",summaryCaptor_2.getValue());
    } 
    
    // delRows_異常_品名マスタ削除処理_12-4
    //
    // -------------------テスト条件--------------------------
    // 営業所コード、顧客コード、品名コードの組み合わせが、品名マスタに存在しない
    // -----------------------------------------------------
    @Test
    public void delRows_異常_仕向地名マスタ削除処理_12_4 () throws IllegalAccessException, InvocationTargetException {

      // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 営業所コード、顧客コード、品名コードの組み合わせが、品名マスタに存在しない[MSTE0099]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0099", "");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        
        //テスト実行
        Mst151Form form = new Mst151Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst151Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst151Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listHimmeiCd0",paramsCaptor_1_Param.get("listHimmeiCd"));
        assertEquals("listHimmei0",paramsCaptor_1_Param.get("listHimmei"));
        assertEquals("listEigyoshoCd0",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listDataVersion0",paramsCaptor_1_Param.get("listDataVersion"));
        assertEquals("mst151-delete-exist",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：MSTE0099）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("MSTE0099",summaryCaptor_2.getValue());
    }
    
    // rirekiIchiran_正常_更新履歴コンテキストメニュー_13-1
    //
    // -------------------テスト条件--------------------------
    // 正常に取得された場合
    // -----------------------------------------------------
    @Test
    public void rirekiIchiran_正常_更新履歴コンテキストメニュー_13_1 () throws IllegalAccessException, 
            InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> titleFlgCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> searchKeyCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(rirekiSyosai).searchList(titleFlgCaptor_1.capture(),functionCodeCaptor_2.capture()
                ,searchKeyCaptor_3.capture());
        // テスト実行
        Mst151Form form = new Mst151Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst151Form(form);
        target.rirekiIchiran();

        // 実施結果Outを取得
        form = target.getMst151Form();

        // 想定通りに履歴を表示する。
        //assertEquals("2",titleFlgCaptor_1.getValue());
        assertEquals("MST151_GET_HIMMEI_RIREKI",functionCodeCaptor_2.getValue());
        assertEquals("listHimmeiCd0",searchKeyCaptor_3.getValue().get("listHimmeiCd"));
        assertEquals("listEigyoshoCd0",searchKeyCaptor_3.getValue().get("listEigyoshoCd"));
        assertEquals("listKokyakuCd0",searchKeyCaptor_3.getValue().get("listKokyakuCd"));
    }
    
    // searchChange_正常_補充ケース_14-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void searchChange_正常_補充ケース_14_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst151Form form = new Mst151Form();
        target.setMst151Form(form);
        target.searchChange();

        //実施結果Outを取得
        form = target.getMst151Form();

    }

    // menuClick_正常_補充ケース_14-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_14_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst151Form form = new Mst151Form();
        target.setMst151Form(form);
        target.menuClick("","");

        //実施結果Outを取得
        form = target.getMst151Form();

    }

    // menuClick_正常_補充ケース_14-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_14_2_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(1);

        //テスト実行
        Mst151Form form = new Mst151Form();
        target.setMst151Form(form);
        target.menuClick("","");

        //実施結果Outを取得
        form = target.getMst151Form();

    }    
    
    // breadClumClick_正常_補充ケース_14-3
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_14_3 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst151Form form = new Mst151Form();
        target.setMst151Form(form);
        target.breadClumClick("",0);

        //実施結果Outを取得
        form = target.getMst151Form();

    }

    // breadClumClick_正常_補充ケース_14-3_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_14_3_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(0);        
        
        //テスト実行
        Mst151Form form = new Mst151Form();
        target.setMst151Form(form);
        target.breadClumClick("",0);

        //実施結果Outを取得
        form = target.getMst151Form();

    }    
    
    // logoutClick_正常_補充ケース_14-4
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void logoutClick_正常_補充ケース_14_4 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst151Form form = new Mst151Form();
        target.setMst151Form(form);
        target.logoutClick();

        //実施結果Outを取得
        form = target.getMst151Form();

    }

    // delRowsFunc_正常_補充ケース_14-5
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void delRowsFunc_正常_補充ケース_14_5 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst151Form form = new Mst151Form();
        target.setMst151Form(form);
        target.delRowsFunc();

        //実施結果Outを取得
        form = target.getMst151Form();
    }
    
    // getSearchResult_正常_補充ケース_14_6-2
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=2件
    // -----------------------------------------------------
    @Test
    public void getSearchResult_正常_補充ケース_14_6 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst151Form form = new Mst151Form();
        target.setMst151Form(form);
        target.getSearchResult();

        // 実施結果Outを取得
        form = target.getMst151Form();

        // 実行時に渡すパラメータの検証
        // 想定通りに正常にダウンロード理由を記録すること
        assertEquals(null,form.getConEigyosho());
    }
    
    private Map<String, String> createRecMapFor_1_1(int i) {
        Map recMap = new HashMap();
        recMap.put("listHimmeiCd", "listHimmeiCd" + i);
        recMap.put("listHimmei", "listHimmei" + i);
        recMap.put("listEigyoshoCd", "listEigyoshoCd" + i);
        recMap.put("listKokyakuCd", "listKokyakuCd" + i);
        recMap.put("listDataVersion", "listDataVersion" + i);
        return recMap;
    }
    
    private Map<String, Object> createRecMapFor_11_1(int i) {
        Map recMap = new HashMap();
        recMap.put("listHimmeiCd", "listHimmeiCd" + i);
        recMap.put("listHimmei", "listHimmei" + i);
        recMap.put("listEigyoshoCd", "listEigyoshoCd" + i);
        recMap.put("listKokyakuCd", "listKokyakuCd" + i);
        recMap.put("listDataVersion", "listDataVersion" + i);
        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }
    
    private void assertForRecList_2_1(Mst151Form form) {
        int i = 0;
        assertEquals(1, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listHimmeiCd" + i, rec.get("listHimmeiCd"));
            assertEquals("listHimmei" + i, rec.get("listHimmei"));
            assertEquals("listEigyoshoCd" + i, rec.get("listEigyoshoCd"));
            assertEquals("listKokyakuCd" + i, rec.get("listKokyakuCd"));
            assertEquals("listDataVersion" + i, rec.get("listDataVersion"));
            i++;
        }
    }  
    
    private void assertForRecList_2_2(Mst151Form form) {
        int i = 0;
        assertEquals(2, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listHimmeiCd" + i, rec.get("listHimmeiCd"));
            assertEquals("listHimmei" + i, rec.get("listHimmei"));
            assertEquals("listEigyoshoCd" + i, rec.get("listEigyoshoCd"));
            assertEquals("listKokyakuCd" + i, rec.get("listKokyakuCd"));
            assertEquals("listDataVersion" + i, rec.get("listDataVersion"));
            i++;
        }
    }
    
    private void assertForRecList_2_3(Mst151Form form) {
        int i = 0;
        assertEquals(0, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listHimmeiCd" + i, rec.get("listHimmeiCd"));
            assertEquals("listHimmei" + i, rec.get("listHimmei"));
            assertEquals("listEigyoshoCd" + i, rec.get("listEigyoshoCd"));
            assertEquals("listKokyakuCd" + i, rec.get("listKokyakuCd"));
            assertEquals("listDataVersion" + i, rec.get("listDataVersion"));
            i++;
        }
    }
}
