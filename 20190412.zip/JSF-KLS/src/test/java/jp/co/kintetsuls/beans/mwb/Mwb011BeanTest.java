/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mwb;

import java.io.IOException;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import jp.co.kintetsuls.common.json.JSONUtil;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import javax.faces.model.SelectItem;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpNoDownloadBean;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.forms.mwb.Mwb011Form;
import jp.co.kintetsuls.utils.FlashUtil;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import static org.mockito.Mockito.doThrow;
import org.primefaces.model.CheckboxTreeNode;
import org.primefaces.model.TreeNode;

/**
 * MAWB一覧画面画面
 *
 * @author 張誠 (MBP)
 * @version 2019/03/25 新規作成
 */
public class Mwb011BeanTest {

    // テストTarget
    @InjectMocks
    private Mwb011Bean target;

    // Mockitoオブジェクト
    @Mock
    private AutoCompleteViewBean autoCompleteViewBean;
    @Mock
    private MessageModuleBean message;
    @Mock
    private MessagePropertyBean messagePropertyBean;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private AuthorityConfBean authConfBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private Mwb011MawbBangoBean selectedBea;
    @Mock
    private RirekiSyosaiBean rirekiSyosaiBean;
    @Mock
    private FlashUtil flashUtil;
    @Mock
    private BaseBean baseBean;
    @Mock
    private SearchHelpNoDownloadBean searchHelpNoDownloadBean;

    public Mwb011BeanTest() {
    }

    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() {
    }
    
    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[not null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mwb011Form mst011Form = new Mwb011Form();
        
        //前画面情報[not null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst011Form);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());

        //テスト実行
        Mwb011Form form = new Mwb011Form();
        target.setMwb011Form(form);
        target.init("","MST012_SCREEN",false);

        //実施結果Outを取得
        form = target.getMwb011Form();
        String title = target.getTITLE();
        String url = target.getUrl();
	Map searchCriteria = target.getSearchCriteria();
	List<SelectItem> kokuGaishaList = target.getKokuGaishaList();
	String [] mishiyoMawbHyojiValue = target.getMishiyoMawbHyojiValue();
        BreadCrumbBean breadBean = target.getBreadBean();
	SearchHelpNoDownloadBean searchHelpNoDownloadBean = target.getSearchHelpBean();
        AutoCompleteViewBean autoCompleteViewBean = target.getAutoCompleteViewBean();
	AuthorityConfBean authorityConfBean = target.getAuthorityConfBean();
        MessagePropertyBean messagePropertyBean = target.getMessagePropertyBean();
        PageCommonBean pageCommonBean = target.getPageCommonBean();
        target.setUrl(url);
        target.setBreadBean(breadBean);
        target.setAutoCompleteViewBean(autoCompleteViewBean);
        target.setAuthorityConfBean(authorityConfBean);
        target.setMessagePropertyBean(messagePropertyBean);
        target.setPageCommonBean(pageCommonBean);
        target.setMishiyoMawbHyojiValue(mishiyoMawbHyojiValue);
	target.setSearchHelpBean(searchHelpNoDownloadBean);
	target.setSearchCriteria(searchCriteria);
	target.setKokuGaishaList(kokuGaishaList);
	
        assertEquals(null, form.getSelectedBean().getHaifuMawbBango());
	
    }

    // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 前回画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mwb011Form mwb011Form = new Mwb011Form();
        
        //前回画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mwb011Form);
	
	// パラメータキャプチャー
	ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
	doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());

        // パラメータキャプチャー
        // Mockitoオブジェクトの予想return値設定
        Flash flash = new FlashKls();
        //前画面パラメータ[都道府県 = 01,仕向地名 = 地名23,削除済のみ検索 = null]
        flash.put("mwb011Form", mwb011Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);

        //テスト実行
        Mwb011Form form = new Mwb011Form();
        target.setMwb011Form(form);
        target.init("","",false);

        //実施結果Outを取得
        form = target.getMwb011Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mwb011Form",keyCaptor_1.getValue());
        //想定通りに再検索されること
	assertEquals("search_mwb011", keyCaptor_2.getValue());
	assertEquals(null, form.getRoot());
        assertEquals(null, form.getSelectedBean());
	
    }
    
    // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 前回画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mwb011Form mwb011Form = new Mwb011Form();
        
        //前回画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mwb011Form);
	
	// パラメータキャプチャー
	ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
	doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());

        // パラメータキャプチャー
        // Mockitoオブジェクトの予想return値設定
        Flash flash = new FlashKls();
        //前画面パラメータ[都道府県 = 01,仕向地名 = 地名23,削除済のみ検索 = null]
        flash.put("mwb011Form", mwb011Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);

        //テスト実行
        Mwb011Form form = new Mwb011Form();
        target.setMwb011Form(form);
        target.init("","",true);

        //実施結果Outを取得
        form = target.getMwb011Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mwb011Form",keyCaptor_1.getValue());
        //想定通りに再検索されること
	assertEquals("search_mwb011", keyCaptor_2.getValue());
	assertEquals(null, form.getRoot());
        assertEquals(null, form.getSelectedBean());
	
    }
    
    // init_正常_初期処理_1-3_1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        // 前画面情報[null]
        doThrow(IllegalAccessException.class).when(pageCommonBean).getPageInfo(keyCaptor_1.capture());

        // テスト実行
        Mwb011Form form = new Mwb011Form();
        target.setMwb011Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        // 実施結果Outを取得
        form = target.getMwb011Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mwb011Form",keyCaptor_1.getValue());
        // 想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null,form.getSearchResult());
    }

    // searchJusho_正常_検索処理_2-1
    //
    // -------------------テスト条件--------------------------
    // 営業所検索結果一覧取得 件数 = 1
    // 発券営業所コード = "conHakkenEigyosho1" 配布日付From = "conHaifuHizukeFrom1"
    // 航空会社コード = "conKokuGaishaCd1" 配布日付To = "conHaifuHizukeTo1"
    //  MAWB番号 = "conMawbBango1"
    // 配布先営業所コード = "conHakkenEigyosho1"
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_1 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
      
        // 営業所検索結果一覧取得 件数 = 1
	List<Map<String, Object>> resultList= new ArrayList();
        for(int i = 0; i<=0; i++) {
            resultList.add(createMwbBangoBeanMapForUpdateOrDelete());
        }
	serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),
                functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setMaxRows("10");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
	// テスト実行
	Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});
	AutoCompOptionBean hakkenEigyosho = new AutoCompOptionBean();
	hakkenEigyosho.setValue("conHakkenEigyosho1");
	// 発券営業所コード
	form.setConHakkenEigyosho(hakkenEigyosho);
	AutoCompOptionBean kokuGaishaCd = new AutoCompOptionBean();
	kokuGaishaCd.setValue("conKokuGaishaCd1");
	// 航空会社コード
	form.setConKokuGaishaCd(kokuGaishaCd);
	// 配布日付From
	form.setConHaifuHizukeFrom("conHaifuHizukeFrom1");
	// 配布日付To
	form.setConHaifuHizukeTo("conHaifuHizukeTo1");
	// 配布先営業所コード
	AutoCompOptionBean haifusakiEigyosho = new AutoCompOptionBean();
	haifusakiEigyosho.setValue("conHakkenEigyosho1");
	form.setConHaifusakiEigyosho(haifusakiEigyosho);
	// MAWB番号
	form.setConMawbBango("conMawbBango1");
        
        target.setSearchCriteria(new HashMap());
	target.setMwb011Form(form);
	target.search();
	
	// 実施結果Outを取得
	form = target.getMwb011Form();
	
	//想定通りに仕向地名マスタ一覧を表示されること
	assertForRecList_2_1(form);
    }
    
    // searchJusho_正常_検索処理_2-1
    //
    // -------------------テスト条件--------------------------
    // 営業所検索結果一覧取得 件数 = 1
    // 発券営業所コード = "conHakkenEigyosho1" 配布日付From = "conHaifuHizukeFrom1"
    // 航空会社コード = "conKokuGaishaCd1" 配布日付To = "conHaifuHizukeTo1"
    //  MAWB番号 = "conMawbBango1"
    // 配布先営業所コード = "conHakkenEigyosho1"
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_1_1 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
      
        // 営業所検索結果一覧取得 件数 = 1
	List<Map<String, Object>> resultList= new ArrayList();
        for(int i = 0; i<=0; i++) {
            resultList.add(createMwbBangoBeanMapForUpdateOrDelete());
        }
	serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),
                functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setMaxRows("2");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_3.capture(),summaryCaptor_4.capture());
	// テスト実行
	Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});
	AutoCompOptionBean hakkenEigyosho = new AutoCompOptionBean();
	hakkenEigyosho.setValue("conHakkenEigyosho1");
	// 発券営業所コード
	form.setConHakkenEigyosho(hakkenEigyosho);
	AutoCompOptionBean kokuGaishaCd = new AutoCompOptionBean();
	kokuGaishaCd.setValue("conKokuGaishaCd1");
	// 航空会社コード
	form.setConKokuGaishaCd(kokuGaishaCd);
	// 配布日付From
	form.setConHaifuHizukeFrom("conHaifuHizukeFrom1");
	// 配布日付To
	form.setConHaifuHizukeTo("conHaifuHizukeTo1");
	// 配布先営業所コード
	AutoCompOptionBean haifusakiEigyosho = new AutoCompOptionBean();
	haifusakiEigyosho.setValue("conHakkenEigyosho1");
	form.setConHaifusakiEigyosho(haifusakiEigyosho);
	// MAWB番号
	form.setConMawbBango("conMawbBango1");
        
        target.setSearchCriteria(new HashMap());
	target.setMwb011Form(form);
	target.search();
	
	// 実施結果Outを取得
	form = target.getMwb011Form();
	
		// 実行時に渡すパラメータの検証
	assertEquals("WARN", levelCaptor_3.getValue());
	assertEquals("COMW0002", summaryCaptor_4.getValue());
	
	//想定通りに仕向地名マスタ一覧を表示されること
	assertForRecList_2_1(form);
    }
    
    // search_異常_検索処理_2_2
    //
    // -------------------テスト条件--------------------------
    // 営業所検索結果一覧取得 件数 = 1
    // 発券営業所コード = "conHakkenEigyosho1" 配布日付From = "conHaifuHizukeFrom1"
    // 航空会社コード = "conKokuGaishaCd1" 配布日付To = "conHaifuHizukeTo1"
    //  MAWB番号 = "conMawbBango1"
    // 配布先営業所コード = "conHakkenEigyosho1"
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_2 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
      
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_3.capture(),summaryCaptor_4.capture());
        
        // 営業所検索結果一覧取得 件数 = 1
	List<Map<String, Object>> resultList= new ArrayList();
        for(int i = 0; i<=0; i++) {
            resultList.add(createMwbBangoBeanMapForUpdateOrDelete());
        }
	serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),
                functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setMaxRows("10");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
	// テスト実行
	Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{});
	AutoCompOptionBean hakkenEigyosho = new AutoCompOptionBean();
	hakkenEigyosho.setValue("conHakkenEigyosho1");
	// 発券営業所コード
	form.setConHakkenEigyosho(hakkenEigyosho);
	AutoCompOptionBean kokuGaishaCd = new AutoCompOptionBean();
	kokuGaishaCd.setValue("conKokuGaishaCd1");
	// 航空会社コード
	form.setConKokuGaishaCd(kokuGaishaCd);
	// 配布日付From
	form.setConHaifuHizukeFrom("conHaifuHizukeFrom1");
	// 配布日付To
	form.setConHaifuHizukeTo("conHaifuHizukeTo1");
	// 配布先営業所コード
	AutoCompOptionBean haifusakiEigyosho = new AutoCompOptionBean();
	haifusakiEigyosho.setValue("conHakkenEigyosho1");
	form.setConHaifusakiEigyosho(haifusakiEigyosho);
	// MAWB番号
	form.setConMawbBango("conMawbBango1");
        
        target.setSearchCriteria(new HashMap());
	target.setMwb011Form(form);
	target.search();

	// 実施結果Outを取得
	form = target.getMwb011Form();
	
	// 実行時に渡すパラメータの検証
	assertEquals("WARN", levelCaptor_3.getValue());
	assertEquals("COMW0001", summaryCaptor_4.getValue());
    }
    
        
    // search_異常_検索処理_2_2_1
    //
    // -------------------テスト条件--------------------------
    // 営業所検索結果一覧取得 件数 = 1
    // 発券営業所コード = "conHakkenEigyosho1" 配布日付From = "conHaifuHizukeFrom1"
    // 航空会社コード = "conKokuGaishaCd1" 配布日付To = "conHaifuHizukeTo1"
    //  MAWB番号 = "conMawbBango1"
    // 配布先営業所コード = "conHakkenEigyosho1"
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_2_1 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        
        doThrow(IOException.class).when(pageCommonBean).getDBInfo(
                paramsCaptor_1.capture(),functionCodeCaptor_2.capture());
      
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_3.capture(),summaryCaptor_4.capture());

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setMaxRows("10");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
	// テスト実行
	Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{});
	AutoCompOptionBean hakkenEigyosho = new AutoCompOptionBean();
	hakkenEigyosho.setValue("conHakkenEigyosho1");
	// 発券営業所コード
	form.setConHakkenEigyosho(hakkenEigyosho);
	AutoCompOptionBean kokuGaishaCd = new AutoCompOptionBean();
	kokuGaishaCd.setValue("conKokuGaishaCd1");
	// 航空会社コード
	form.setConKokuGaishaCd(kokuGaishaCd);
	// 配布日付From
	form.setConHaifuHizukeFrom("conHaifuHizukeFrom1");
	// 配布日付To
	form.setConHaifuHizukeTo("conHaifuHizukeTo1");
	// 配布先営業所コード
	AutoCompOptionBean haifusakiEigyosho = new AutoCompOptionBean();
	haifusakiEigyosho.setValue("conHakkenEigyosho1");
	form.setConHaifusakiEigyosho(haifusakiEigyosho);
	// MAWB番号
	form.setConMawbBango("conMawbBango1");
        
        target.setSearchCriteria(new HashMap());
	target.setMwb011Form(form);
	target.search();

	// 実施結果Outを取得
	form = target.getMwb011Form();
	
	// 実行時に渡すパラメータの検証
	assertEquals("WARN", levelCaptor_3.getValue());
	assertEquals("COMW0001", summaryCaptor_4.getValue());
    }
    
    // getRecordCount_正常__件数取得処理_2_2_2
    //
    // -------------------テスト条件--------------------------
    // 営業所検索結果一覧取得 件数 = 1
    // 発券営業所コード = "conHakkenEigyosho1" 配布日付From = "conHaifuHizukeFrom1"
    // 航空会社コード = "conKokuGaishaCd1" 配布日付To = "conHaifuHizukeTo1"
    //  MAWB番号 = "conMawbBango1"
    // 配布先営業所コード = "conHakkenEigyosho1"
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常__件数取得処理_2_2_2() throws IllegalAccessException, InvocationTargetException {

	// パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        List<Map<String, Object>> resultList = new ArrayList<>();  
        // テスト実行
        Mwb011Form form = new Mwb011Form();
	form.setSearchResult(resultList);
        target.setMwb011Form(form);

        target.setSearchCriteria(new HashMap());
	target.getRecordCount();

        // 実施結果Outを取得
        form = target.getMwb011Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mwb011-get-mawbbango-kensu",functionCodeCaptor_2.getValue());
    }  
    
    // search_正常_検索処理_2_3
    //
    // -------------------テスト条件--------------------------
    // 営業所検索結果一覧取得 件数 = 1
    // 発券営業所コード = "conHakkenEigyosho1" 配布日付From = "conHaifuHizukeFrom1"
    // 航空会社コード = "conKokuGaishaCd1" 配布日付To = "conHaifuHizukeTo1"
    //  MAWB番号 = "conMawbBango1"
    // 配布先営業所コード = "conHakkenEigyosho1"
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_3() throws IllegalAccessException, InvocationTargetException {

	
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
      
        // 営業所検索結果一覧取得 件数 = 1
	List<Map<String, Object>> resultList= new ArrayList();
        for(int i = 0; i<=0; i++) {
            resultList.add(createMwbBangoBeanMapForSearch());
        }
	serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),
                functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setMaxRows("10");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
	// テスト実行
	Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{});
	AutoCompOptionBean hakkenEigyosho = new AutoCompOptionBean();
	hakkenEigyosho.setValue("conHakkenEigyosho1");
	// 発券営業所コード
	form.setConHakkenEigyosho(hakkenEigyosho);
	AutoCompOptionBean kokuGaishaCd = new AutoCompOptionBean();
	kokuGaishaCd.setValue("conKokuGaishaCd1");
	// 航空会社コード
	form.setConKokuGaishaCd(kokuGaishaCd);
	// 配布日付From
	form.setConHaifuHizukeFrom("conHaifuHizukeFrom1");
	// 配布日付To
	form.setConHaifuHizukeTo("conHaifuHizukeTo1");
	// 配布先営業所コード
	AutoCompOptionBean haifusakiEigyosho = new AutoCompOptionBean();
	haifusakiEigyosho.setValue("conHakkenEigyosho1");
	form.setConHaifusakiEigyosho(haifusakiEigyosho);
	// MAWB番号
	form.setConMawbBango("conMawbBango1");
        
        target.setSearchCriteria(new HashMap());
	target.setMwb011Form(form);
	target.search();
	
	// 実施結果Outを取得
	form = target.getMwb011Form();
	
	//想定通りに仕向地名マスタ一覧を表示されること
	assertForRecList_2_1(form);
    }  
    
    // search_正常_検索処理_2_4
    //
    // -------------------テスト条件--------------------------
    // 営業所検索結果一覧取得 件数 = 1
    // 発券営業所コード = "conHakkenEigyosho1" 配布日付From = "conHaifuHizukeFrom1"
    // 航空会社コード = "conKokuGaishaCd1" 配布日付To = "conHaifuHizukeTo1"
    //  MAWB番号 = "conMawbBango1"
    // 配布先営業所コード = "conHakkenEigyosho1"
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_4() throws IllegalAccessException, InvocationTargetException {

	
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
      
        // 営業所検索結果一覧取得 件数 = 1
	List<Map<String, Object>> resultList= new ArrayList();
        for(int i = 0; i<=0; i++) {
            resultList.add(createMwbBangoBeanMapForSearch2());
        }
	serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),
                functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setMaxRows("10");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
	// テスト実行
	Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});
	AutoCompOptionBean hakkenEigyosho = new AutoCompOptionBean();
	hakkenEigyosho.setValue("conHakkenEigyosho1");
	// 発券営業所コード
	form.setConHakkenEigyosho(hakkenEigyosho);
	AutoCompOptionBean kokuGaishaCd = new AutoCompOptionBean();
	kokuGaishaCd.setValue("conKokuGaishaCd1");
	// 航空会社コード
	form.setConKokuGaishaCd(kokuGaishaCd);
	// 配布日付From
	form.setConHaifuHizukeFrom("conHaifuHizukeFrom1");
	// 配布日付To
	form.setConHaifuHizukeTo("conHaifuHizukeTo1");
	// 配布先営業所コード
	AutoCompOptionBean haifusakiEigyosho = new AutoCompOptionBean();
	haifusakiEigyosho.setValue("conHakkenEigyosho1");
	form.setConHaifusakiEigyosho(haifusakiEigyosho);
	// MAWB番号
	form.setConMawbBango("conMawbBango1");
        
        target.setSearchCriteria(new HashMap());
	target.setMwb011Form(form);
	target.search();
	
	// 実施結果Outを取得
	form = target.getMwb011Form();
	
	//想定通りに仕向地名マスタ一覧を表示されること
	assertForRecList_2_1(form);
    }  
    
    // search_正常_検索処理_2_5
    //
    // -------------------テスト条件--------------------------
    // 営業所検索結果一覧取得 件数 = 1
    // 発券営業所コード = "conHakkenEigyosho1" 配布日付From = "conHaifuHizukeFrom1"
    // 航空会社コード = "conKokuGaishaCd1" 配布日付To = "conHaifuHizukeTo1"
    //  MAWB番号 = "conMawbBango1"
    // 配布先営業所コード = "conHakkenEigyosho1"
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_5() throws IllegalAccessException, InvocationTargetException {

	
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
      
        // 営業所検索結果一覧取得 件数 = 1
	List<Map<String, Object>> resultList= new ArrayList();
        for(int i = 0; i<=0; i++) {
            resultList.add(createMwbBangoBeanMapForSearch2());
        }
	serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),
                functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setMaxRows("10");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
	// テスト実行
	Mwb011Form form = new Mwb011Form();
        List<Mwb011MawbBangoBean> childNodes = new ArrayList();
        List<Mwb011MawbBangoBean> childNodes2 = new ArrayList();
        List<Mwb011MawbBangoBean> childNodes3 = new ArrayList();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        Mwb011MawbBangoBean selectedBean2 = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        Mwb011MawbBangoBean selectedBean3 = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        Mwb011MawbBangoBean selectedBean4 = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        Mwb011MawbBangoBean selectedBean5 = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean2.setMishiyoMaisu(10);
        selectedBean.setMishiyoMaisu(10);
        selectedBean3.setMishiyoMaisu(10);
        selectedBean4.setMishiyoMaisu(10);
        selectedBean4.setChildNodes(new ArrayList());
        childNodes3.add(selectedBean4);
        selectedBean3.setChildNodes(childNodes3);
        childNodes2.add(selectedBean3);
        selectedBean2.setChildNodes(childNodes2);
        childNodes.add(selectedBean2);
        form.setSelectedBean(selectedBean);
        selectedBean.setChildNodes(childNodes);
        form.setMawbBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});
	AutoCompOptionBean hakkenEigyosho = new AutoCompOptionBean();
	hakkenEigyosho.setValue("conHakkenEigyosho1");
	// 発券営業所コード
	form.setConHakkenEigyosho(hakkenEigyosho);
	AutoCompOptionBean kokuGaishaCd = new AutoCompOptionBean();
	kokuGaishaCd.setValue("conKokuGaishaCd1");
	// 航空会社コード
	form.setConKokuGaishaCd(kokuGaishaCd);
	// 配布日付From
	form.setConHaifuHizukeFrom("conHaifuHizukeFrom1");
	// 配布日付To
	form.setConHaifuHizukeTo("conHaifuHizukeTo1");
	// 配布先営業所コード
	AutoCompOptionBean haifusakiEigyosho = new AutoCompOptionBean();
	haifusakiEigyosho.setValue("conHakkenEigyosho1");
	form.setConHaifusakiEigyosho(haifusakiEigyosho);
	// MAWB番号
	form.setConMawbBango("conMawbBango1");
        
        target.setSearchCriteria(new HashMap());
	target.setMwb011Form(form);
	target.search();
	
	// 実施結果Outを取得
	form = target.getMwb011Form();
	
	//想定通りに仕向地名マスタ一覧を表示されること
	assertForRecList_2_1(form);
    }
    
    // search_正常_検索処理_2_6
    //
    // -------------------テスト条件--------------------------
    // 営業所検索結果一覧取得 件数 = 1
    // 発券営業所コード = "conHakkenEigyosho1" 配布日付From = "conHaifuHizukeFrom1"
    // 航空会社コード = "conKokuGaishaCd1" 配布日付To = "conHaifuHizukeTo1"
    //  MAWB番号 = "conMawbBango1"
    // 配布先営業所コード = "conHakkenEigyosho1"
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_6() throws IllegalAccessException, InvocationTargetException {

	
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
      
        // 営業所検索結果一覧取得 件数 = 1
	List<Map<String, Object>> resultList= new ArrayList();
        for(int i = 0; i<=0; i++) {
            resultList.add(createMwbBangoBeanMapForSearch2());
        }
	serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),
                functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setMaxRows("10");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
	// テスト実行
	Mwb011Form form = new Mwb011Form();
        List<Mwb011MawbBangoBean> childNodes = new ArrayList();
        List<Mwb011MawbBangoBean> childNodes2 = new ArrayList();
        List<Mwb011MawbBangoBean> childNodes3 = new ArrayList();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        Mwb011MawbBangoBean selectedBean2 = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete2());
        Mwb011MawbBangoBean selectedBean3 = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete3());
        Mwb011MawbBangoBean selectedBean4 = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete4());
        Mwb011MawbBangoBean selectedBean5 = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete5());
        selectedBean2.setMishiyoMaisu(10);
        selectedBean.setMishiyoMaisu(10);
        selectedBean3.setMishiyoMaisu(10);
        selectedBean4.setMishiyoMaisu(10);
        selectedBean4.setChildNodes(new ArrayList());
        childNodes3.add(selectedBean4);
        selectedBean3.setChildNodes(childNodes3);
        childNodes2.add(selectedBean3);
        selectedBean2.setChildNodes(childNodes2);
        childNodes.add(selectedBean2);
        form.setSelectedBean(selectedBean);
        selectedBean.setChildNodes(childNodes);
        form.setMawbBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});
	AutoCompOptionBean hakkenEigyosho = new AutoCompOptionBean();
	hakkenEigyosho.setValue("conHakkenEigyosho1");
	// 発券営業所コード
	form.setConHakkenEigyosho(hakkenEigyosho);
	AutoCompOptionBean kokuGaishaCd = new AutoCompOptionBean();
	kokuGaishaCd.setValue("conKokuGaishaCd1");
	// 航空会社コード
	form.setConKokuGaishaCd(kokuGaishaCd);
	// 配布日付From
	form.setConHaifuHizukeFrom("conHaifuHizukeFrom1");
	// 配布日付To
	form.setConHaifuHizukeTo("conHaifuHizukeTo1");
	// 配布先営業所コード
	AutoCompOptionBean haifusakiEigyosho = new AutoCompOptionBean();
	haifusakiEigyosho.setValue("conHakkenEigyosho1");
	form.setConHaifusakiEigyosho(haifusakiEigyosho);
	// MAWB番号
	form.setConMawbBango("conMawbBango1");
        
        target.setSearchCriteria(new HashMap());
	target.setMwb011Form(form);
	target.search();
	
	// 実施結果Outを取得
	form = target.getMwb011Form();
	
	//想定通りに仕向地名マスタ一覧を表示されること
	assertForRecList_2_1(form);
    }
    
    // clear_正常_クリア処理_3-1
    //
    // -------------------テスト条件--------------------------
    // 検索条件と検索結果がある
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_1() throws IllegalAccessException, InvocationTargetException {

	// テスト実行
	Mwb011Form form = new Mwb011Form();
	// 検索条件と検索結果がある
	AutoCompOptionBean conHakkenEigyosho = new AutoCompOptionBean();
	conHakkenEigyosho.setValue("006");
	form.setConHaifusakiEigyosho(conHakkenEigyosho);
	AutoCompOptionBean kokuGaishaCd = new AutoCompOptionBean();
	kokuGaishaCd.setValue("0005");
	form.setConKokuGaishaCd(kokuGaishaCd);
	// 配布日付From
	form.setConHaifuHizukeFrom("conHaifuHizukeFrom1");
	// 配布日付To
	form.setConHaifuHizukeTo("conHaifuHizukeTo1");
	// 配布先営業所コード
	AutoCompOptionBean haifusakiEigyosho = new AutoCompOptionBean();
	haifusakiEigyosho.setValue("conHakkenEigyosho1");
	form.setConHaifusakiEigyosho(haifusakiEigyosho);
	// MAWB番号
	form.setConMawbBango("conMawbBango1");

	target.setMwb011Form(form);
	target.clear();

	// 実施結果Outを取得
	form = target.getMwb011Form();

	// 想定通りに正常にClearを実施されること
	// 発券営業所コード
	assertEquals(null, form.getConHaifusakiEigyosho());
	// 航空会社コード
	assertEquals(null, form.getConKokuGaishaCd());
	// 配布日付From
	assertEquals(null, form.getConHaifuHizukeFrom());
	// 配布日付To
	assertEquals(null, form.getConHaifuHizukeTo());
	// 配布先営業所コード
	assertEquals(null, form.getConHaifusakiEigyosho());
	// MAWB番号
	assertEquals("", form.getConMawbBango());
    }

    // clear_正常_クリア処理_3-2
    //
    // -------------------テスト条件--------------------------
    // 検索条件がある、検索結果がない
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_2() throws IllegalAccessException, InvocationTargetException {

	// テスト実行
	Mwb011Form form = new Mwb011Form();
	target.setMwb011Form(form);
	target.clear();

	// 実施結果Outを取得
	form = target.getMwb011Form();

	// 想定通りに正常にClearを実施されること
	// 発券営業所コード
	assertEquals(null, form.getConHaifusakiEigyosho());
	// 航空会社コード
	assertEquals(null, form.getConKokuGaishaCd());
	// 配布日付From
	assertEquals(null, form.getConHaifuHizukeFrom());
	// 配布日付To
	assertEquals(null, form.getConHaifuHizukeTo());
	// 配布先営業所コード
	assertEquals(null, form.getConHaifusakiEigyosho());
	// MAWB番号
	assertEquals("", form.getConMawbBango());
    }
    
    // onMawbBangoMenuClick_異常_MAWB配布登録処理_12_1
    //
    // -------------------テスト条件--------------------------
    //  1行選択しません
    // -----------------------------------------------------
    @Test
    public void onMawbBangoMenuClick_異常_MAWB配布登録処理_12_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_1.capture(),summaryCaptor_2.capture());
        
	// テスト実行
	Mwb011Form form = new Mwb011Form();
        //行選択チェック選択 = 0
        form.setSelectedNode(null);
	target.setMwb011Form(form);
	target.onMawbBangoMenuClick();

	// 実施結果Outを取得
	form = target.getMwb011Form();

        //想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("WARN",levelCaptor_1.getValue());
        assertEquals("COME0029",summaryCaptor_2.getValue());
	
    }
    
    // onMawbBangoMenuClick_異常_MAWB配布登録処理_12_2
    //
    // -------------------テスト条件--------------------------
    //  1行選択しません
    // -----------------------------------------------------
    @Test
    public void onMawbBangoMenuClick_異常_MAWB配布登録処理_12_2() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_1.capture(),summaryCaptor_2.capture());
        
	// テスト実行
	Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean mawbBean = null;
        TreeNode treeNode = new CheckboxTreeNode(mawbBean, null);
        form.setSelectedNode(treeNode);
	target.setMwb011Form(form);
	target.onMawbBangoMenuClick();

	// 実施結果Outを取得
	form = target.getMwb011Form();

        //想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("WARN",levelCaptor_1.getValue());
        assertEquals("COME0029",summaryCaptor_2.getValue());
	
    }
    
    // onMawbBangoMenuClick_異常_MAWB配布登録処理_12_3
    //
    // -------------------テスト条件--------------------------
    //  MAWB一覧のデータのlevelが3、登録MAWB番号From > 登録MAWB番号To
    // -----------------------------------------------------
    @Test
    public void onMawbBangoMenuClick_異常_MAWB配布登録処理_12_3() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_1.capture(),summaryCaptor_2.capture(),detailCaptor_3.capture());
        
	// テスト実行
	Mwb011Form form = new Mwb011Form();
        Map<String, Object> dataMapper = new HashMap<>(); 
        Mwb011MawbBangoBean mawbBean = new Mwb011MawbBangoBean(3, dataMapper);
        mawbBean.setStrUkeireHizuke("2019/04/04");
        mawbBean.setTorokuMawbBangoFrom("8888");
        mawbBean.setTorokuMawbBangoTo("7777");
        mawbBean.setSaiTorokuMawbBangoFrom("111");
        mawbBean.setSaiTorokuMawbBangoTo("9000");
        mawbBean.setSaiUkeireMaisu(new Integer(10));
        TreeNode treeNode = new CheckboxTreeNode(mawbBean, null);
        form.setSelectedNode(treeNode);
	target.setMwb011Form(form);
	target.onMawbBangoMenuClick();

	// 実施結果Outを取得
	form = target.getMwb011Form();
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);     
        doNothing().when(pageCommonBean).executeScript(keyCaptor_1.capture());
        
        // 実行時に渡すパラメータの検証
        assertEquals("2019/04/04", form.getSelectedBean().getSaiUkeireHizuke());
        assertEquals("8888", form.getSelectedBean().getSaiTorokuMawbBangoFrom());
        assertEquals("7777", form.getSelectedBean().getSaiTorokuMawbBangoTo());
        assertEquals(new Integer(10), form.getSelectedBean().getSaiUkeireMaisu());
        assertEquals("ERROR", levelCaptor_1.getValue());
        assertEquals("MWBE0001", summaryCaptor_2.getValue());
        assertEquals("登録MAWB番号", detailCaptor_3.getValue());
    }
    
    // onMawbBangoMenuClick_正常_MAWB配布登録処理_12_1
    //
    // -------------------テスト条件--------------------------
    //  MAWB一覧のデータのtypeがMwb011MawbBangoBeanではない
    // -----------------------------------------------------
    @Test
    public void onMawbBangoMenuClick_正常_MAWB配布登録処理_12_1() throws IllegalAccessException, InvocationTargetException {

	// テスト実行
	Mwb011Form form = new Mwb011Form();
        Mwb011BangoRangeBean mawbBean = new Mwb011BangoRangeBean();
        TreeNode treeNode = new CheckboxTreeNode(mawbBean, null);
        form.setSelectedNode(treeNode);
	target.setMwb011Form(form);
	target.onMawbBangoMenuClick();

	// 実施結果Outを取得
	form = target.getMwb011Form();
    }
    
    // onMawbBangoMenuClick_正常_MAWB配布登録処理_12_2
    //
    // -------------------テスト条件--------------------------
    //  MAWB一覧のデータのlevelが2、3以外の場合
    // -----------------------------------------------------
    @Test
    public void onMawbBangoMenuClick_正常_MAWB配布登録処理_12_2() throws IllegalAccessException, InvocationTargetException {

	// テスト実行
	Mwb011Form form = new Mwb011Form();
        Map<String, Object> dataMapper = new HashMap<>(); 
        Mwb011MawbBangoBean mawbBean = new Mwb011MawbBangoBean(1, dataMapper);
        TreeNode treeNode = new CheckboxTreeNode(mawbBean, null);
        form.setSelectedNode(treeNode);
	target.setMwb011Form(form);
	target.onMawbBangoMenuClick();

	// 実施結果Outを取得
	form = target.getMwb011Form();
    }
    
    // onMawbBangoMenuClick_正常_MAWB配布登録処理_12_2
    //
    // -------------------テスト条件--------------------------
    //  MAWB一覧のデータのlevelが2の場合
    // -----------------------------------------------------
    @Test
    public void onMawbBangoMenuClick_正常_MAWB配布登録処理_12_3() throws IllegalAccessException, InvocationTargetException {

	// テスト実行
	Mwb011Form form = new Mwb011Form();
        Map<String, Object> dataMapper = new HashMap<>(); 
        
        Mwb011MawbBangoBean mawbBean = new Mwb011MawbBangoBean(2, dataMapper);
        TreeNode treeNode = new CheckboxTreeNode(mawbBean, null);
        form.setSelectedNode(treeNode);
	target.setMwb011Form(form);
	target.onMawbBangoMenuClick();

	// 実施結果Outを取得
	form = target.getMwb011Form();
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);     
        doNothing().when(pageCommonBean).executeScript(keyCaptor_1.capture());
        
        // 実行時に渡すパラメータの検証
        assertEquals(null, form.getSelectedBean().getSaiUkeireHizuke());
        assertEquals("", form.getSelectedBean().getSaiTorokuMawbBangoFrom());
        assertEquals("", form.getSelectedBean().getSaiTorokuMawbBangoTo());
        assertEquals(new Integer(0), form.getSelectedBean().getSaiUkeireMaisu());
    }
    
    // onMawbBangoMenuClick_正常_MAWB配布登録処理_12_4
    //
    // -------------------テスト条件--------------------------
    //  MAWB一覧のデータのlevelが3、登録MAWB番号Fromが空白且つ再設定登録MAWB番号Fromが空以外の場合
    // -----------------------------------------------------
    @Test
    public void onMawbBangoMenuClick_正常_MAWB配布登録処理_12_4() throws IllegalAccessException, InvocationTargetException {

	// テスト実行
	Mwb011Form form = new Mwb011Form();
        Map<String, Object> dataMapper = new HashMap<>(); 
        Mwb011MawbBangoBean mawbBean = new Mwb011MawbBangoBean(3, dataMapper);
        mawbBean.setStrUkeireHizuke("2019/04/04");
        mawbBean.setTorokuMawbBangoFrom("");
        mawbBean.setTorokuMawbBangoTo("9999");
        mawbBean.setSaiTorokuMawbBangoFrom("0001");
        mawbBean.setSaiTorokuMawbBangoTo("9000");
        TreeNode treeNode = new CheckboxTreeNode(mawbBean, null);
        form.setSelectedNode(treeNode);
	target.setMwb011Form(form);
	target.onMawbBangoMenuClick();

	// 実施結果Outを取得
	form = target.getMwb011Form();
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);     
        doNothing().when(pageCommonBean).executeScript(keyCaptor_1.capture());
        
        // 実行時に渡すパラメータの検証
        assertEquals("2019/04/04", form.getSelectedBean().getSaiUkeireHizuke());
        assertEquals("", form.getSelectedBean().getSaiTorokuMawbBangoFrom());
        assertEquals("9999", form.getSelectedBean().getSaiTorokuMawbBangoTo());
        assertEquals(new Integer(0), form.getSelectedBean().getSaiUkeireMaisu());
    }
    
    // onMawbBangoMenuClick_正常_MAWB配布登録処理_12_5
    //
    // -------------------テスト条件--------------------------
    //  MAWB一覧のデータのlevelが3、登録MAWB番号Toが空白且つ再設定登録MAWB番号Toが空以外の場合
    // -----------------------------------------------------
    @Test
    public void onMawbBangoMenuClick_正常_MAWB配布登録処理_12_5() throws IllegalAccessException, InvocationTargetException {

	// テスト実行
	Mwb011Form form = new Mwb011Form();
        Map<String, Object> dataMapper = new HashMap<>(); 
        Mwb011MawbBangoBean mawbBean = new Mwb011MawbBangoBean(3, dataMapper);
        mawbBean.setStrUkeireHizuke("2019/04/04");
        mawbBean.setTorokuMawbBangoFrom("001");
        mawbBean.setTorokuMawbBangoTo("");
        mawbBean.setSaiTorokuMawbBangoFrom("111");
        mawbBean.setSaiTorokuMawbBangoTo("9000");
        TreeNode treeNode = new CheckboxTreeNode(mawbBean, null);
        form.setSelectedNode(treeNode);
	target.setMwb011Form(form);
	target.onMawbBangoMenuClick();

	// 実施結果Outを取得
	form = target.getMwb011Form();
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);     
        doNothing().when(pageCommonBean).executeScript(keyCaptor_1.capture());
        
        // 実行時に渡すパラメータの検証
        assertEquals("2019/04/04", form.getSelectedBean().getSaiUkeireHizuke());
        assertEquals("001", form.getSelectedBean().getSaiTorokuMawbBangoFrom());
        assertEquals("", form.getSelectedBean().getSaiTorokuMawbBangoTo());
        assertEquals(new Integer(0), form.getSelectedBean().getSaiUkeireMaisu());
    }
    
    // onMawbBangoMenuClick_正常_MAWB配布登録処理_12_6
    //
    // -------------------テスト条件--------------------------
    //  MAWB一覧のデータのlevelが3、登録MAWB番号Fromが空白且つ登録MAWB番号Toが空白の場合
    // -----------------------------------------------------
    @Test
    public void onMawbBangoMenuClick_正常_MAWB配布登録処理_12_6() throws IllegalAccessException, InvocationTargetException {

	// テスト実行
	Mwb011Form form = new Mwb011Form();
        Map<String, Object> dataMapper = new HashMap<>(); 
        Mwb011MawbBangoBean mawbBean = new Mwb011MawbBangoBean(3, dataMapper);
        mawbBean.setStrUkeireHizuke("2019/04/04");
        mawbBean.setTorokuMawbBangoFrom("");
        mawbBean.setTorokuMawbBangoTo("");
        mawbBean.setSaiTorokuMawbBangoFrom("111");
        mawbBean.setSaiTorokuMawbBangoTo("9000");
        TreeNode treeNode = new CheckboxTreeNode(mawbBean, null);
        form.setSelectedNode(treeNode);
	target.setMwb011Form(form);
	target.onMawbBangoMenuClick();

	// 実施結果Outを取得
	form = target.getMwb011Form();
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);     
        doNothing().when(pageCommonBean).executeScript(keyCaptor_1.capture());
        
        // 実行時に渡すパラメータの検証
        assertEquals("2019/04/04", form.getSelectedBean().getSaiUkeireHizuke());
        assertEquals("", form.getSelectedBean().getSaiTorokuMawbBangoFrom());
        assertEquals("", form.getSelectedBean().getSaiTorokuMawbBangoTo());
        assertEquals(new Integer(0), form.getSelectedBean().getSaiUkeireMaisu());
    }
    
    // onMawbBangoMenuClick_正常_MAWB配布登録処理_12_7
    //
    // -------------------テスト条件--------------------------
    //  MAWB一覧のデータのlevelが3、登録MAWB番号Fromのlengthが「7」以上、登録MAWB番号Toのlengthが「7」以上の場合
    // -----------------------------------------------------
    @Test
    public void onMawbBangoMenuClick_正常_MAWB配布登録処理_12_7() throws IllegalAccessException, InvocationTargetException {

	// テスト実行
	Mwb011Form form = new Mwb011Form();
        Map<String, Object> dataMapper = new HashMap<>(); 
        Mwb011MawbBangoBean mawbBean = new Mwb011MawbBangoBean(3, dataMapper);
        mawbBean.setStrUkeireHizuke("2019/04/04");
        mawbBean.setTorokuMawbBangoFrom("11111111");
        mawbBean.setTorokuMawbBangoTo("99999999");
        mawbBean.setSaiTorokuMawbBangoFrom("111");
        mawbBean.setSaiTorokuMawbBangoTo("9000");
        mawbBean.setSaiUkeireMaisu(new Integer(10));
        TreeNode treeNode = new CheckboxTreeNode(mawbBean, null);
        form.setSelectedNode(treeNode);
	target.setMwb011Form(form);
	target.onMawbBangoMenuClick();

	// 実施結果Outを取得
	form = target.getMwb011Form();
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);     
        doNothing().when(pageCommonBean).executeScript(keyCaptor_1.capture());
        
        // 実行時に渡すパラメータの検証
        assertEquals("2019/04/04", form.getSelectedBean().getSaiUkeireHizuke());
        assertEquals("11111111", form.getSelectedBean().getSaiTorokuMawbBangoFrom());
        assertEquals("99999999", form.getSelectedBean().getSaiTorokuMawbBangoTo());
        assertEquals(new Integer(8888889), form.getSelectedBean().getSaiUkeireMaisu());
    }
    
    // onMawbBangoMenuClick_正常_MAWB配布登録処理_12_8
    //
    // -------------------テスト条件--------------------------
    //  MAWB一覧のデータのlevelが3、登録MAWB番号Fromのlengthが「7」、登録MAWB番号Toのlengthが「7」の場合
    // -----------------------------------------------------
    @Test
    public void onMawbBangoMenuClick_正常_MAWB配布登録処理_12_8() throws IllegalAccessException, InvocationTargetException {

	// テスト実行
	Mwb011Form form = new Mwb011Form();
        Map<String, Object> dataMapper = new HashMap<>(); 
        Mwb011MawbBangoBean mawbBean = new Mwb011MawbBangoBean(3, dataMapper);
        mawbBean.setStrUkeireHizuke("2019/04/04");
        mawbBean.setTorokuMawbBangoFrom("1111111");
        mawbBean.setTorokuMawbBangoTo("9999999");
        mawbBean.setSaiTorokuMawbBangoFrom("111");
        mawbBean.setSaiTorokuMawbBangoTo("9000");
        mawbBean.setSaiUkeireMaisu(new Integer(10));
        TreeNode treeNode = new CheckboxTreeNode(mawbBean, null);
        form.setSelectedNode(treeNode);
	target.setMwb011Form(form);
	target.onMawbBangoMenuClick();

	// 実施結果Outを取得
	form = target.getMwb011Form();
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);     
        doNothing().when(pageCommonBean).executeScript(keyCaptor_1.capture());
        
        // 実行時に渡すパラメータの検証
        assertEquals("2019/04/04", form.getSelectedBean().getSaiUkeireHizuke());
        assertEquals("1111111", form.getSelectedBean().getSaiTorokuMawbBangoFrom());
        assertEquals("9999999", form.getSelectedBean().getSaiTorokuMawbBangoTo());
        assertEquals(new Integer(8888889), form.getSelectedBean().getSaiUkeireMaisu());
    }
    
    // onMawbHaifuMenuClick_異常_MAWB配布登録処理_13_1
    //
    // -------------------テスト条件--------------------------
    //  1行選択しません
    // -----------------------------------------------------
    @Test
    public void onMawbHaifuMenuClick_異常_MAWB配布登録処理_13_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_1.capture(),summaryCaptor_2.capture());
        
	// テスト実行
	Mwb011Form form = new Mwb011Form();
        //行選択チェック選択 = 0
        form.setSelectedNode(null);
	target.setMwb011Form(form);
	target.onMawbHaifuMenuClick();

	// 実施結果Outを取得
	form = target.getMwb011Form();

        //想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("WARN",levelCaptor_1.getValue());
        assertEquals("COME0029",summaryCaptor_2.getValue());
	
    }
    
    // onMawbHaifuMenuClick_異常_MAWB配布登録処理_13_2
    //
    // -------------------テスト条件--------------------------
    //  1行選択しません
    // -----------------------------------------------------
    @Test
    public void onMawbHaifuMenuClick_異常_MAWB配布登録処理_13_2() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_1.capture(),summaryCaptor_2.capture());
        
	// テスト実行
	Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean mawbBean = null;
        TreeNode treeNode = new CheckboxTreeNode(mawbBean, null);
        form.setSelectedNode(treeNode);
	target.setMwb011Form(form);
	target.onMawbHaifuMenuClick();

	// 実施結果Outを取得
	form = target.getMwb011Form();

        //想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("WARN",levelCaptor_1.getValue());
        assertEquals("COME0029",summaryCaptor_2.getValue());
	
    }
    
    // onMawbHaifuMenuClick_正常_MAWB配布登録処理_13_1
    //
    // -------------------テスト条件--------------------------
    //  MAWB一覧のデータのtypeがMwb011MawbBangoBeanではない
    // -----------------------------------------------------
    @Test
    public void onMawbHaifuMenuClick_正常_MAWB配布登録処理_13_1() throws IllegalAccessException, InvocationTargetException {

	// テスト実行
	Mwb011Form form = new Mwb011Form();
        Mwb011BangoRangeBean mawbBean = new Mwb011BangoRangeBean();
        TreeNode treeNode = new CheckboxTreeNode(mawbBean, null);
        form.setSelectedNode(treeNode);
	target.setMwb011Form(form);
	target.onMawbHaifuMenuClick();

	// 実施結果Outを取得
	form = target.getMwb011Form();
    }
    
    // onMawbHaifuMenuClick_正常_MAWB配布登録処理_13_2
    //
    // -------------------テスト条件--------------------------
    //  MAWB一覧のデータのlevelが4以外の場合
    // -----------------------------------------------------
    @Test
    public void onMawbHaifuMenuClick_正常_MAWB配布登録処理_13_2() throws IllegalAccessException, InvocationTargetException {

	// テスト実行
	Mwb011Form form = new Mwb011Form();
        Map<String, Object> dataMapper = new HashMap<>(); 
        Mwb011MawbBangoBean mawbBean = new Mwb011MawbBangoBean(1, dataMapper);
        TreeNode treeNode = new CheckboxTreeNode(mawbBean, null);
        form.setSelectedNode(treeNode);
	target.setMwb011Form(form);
	target.onMawbHaifuMenuClick();

	// 実施結果Outを取得
	form = target.getMwb011Form();
    }
    
    // onMawbHaifuMenuClick_正常_MAWB配布登録処理_13_3
    //
    // -------------------テスト条件--------------------------
    //  MAWB一覧のデータのlevelが4の場合
    // -----------------------------------------------------
    @Test
    public void onMawbHaifuMenuClick_正常_MAWB配布登録処理_13_3() throws IllegalAccessException, InvocationTargetException, SystemException {

	// テスト実行
	Mwb011Form form = new Mwb011Form();
        Map<String, Object> dataMapper = new HashMap<>(); 
        
        Mwb011MawbBangoBean mawbBean = new Mwb011MawbBangoBean(4, dataMapper);
        TreeNode treeNode = new CheckboxTreeNode(mawbBean, null);
        form.setSelectedNode(treeNode);
	target.setMwb011Form(form);
	target.onMawbHaifuMenuClick();

	// 実施結果Outを取得
	form = target.getMwb011Form();
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);     
        doNothing().when(pageCommonBean).executeScript(keyCaptor_1.capture());
    }
    
    // haifuMawbBangoRangeMaisuKeisan_正常_枚数計算範囲指定時_22_1
    //
    // -------------------テスト条件--------------------------
    // 再配布MAWB番号From = ""  再配布MAWB番号To = ""
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoRangeMaisuKeisan_正常_枚数計算範囲指定時_22_1() throws IllegalAccessException,
            InvocationTargetException, ParseException {
      
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuMawbBangoFrom("");
        selectedBean.setSaiHaifuMawbBangoTo("");
        form.setSelectedBean(selectedBean);

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoRangeMaisuKeisan();

        // 実施結果Outを取得
        form = target.getMwb011Form();

        // 想定通り
        assertEquals(0, form.getSelectedBean().getSaiHaifuMeisu());

    }
    
    // haifuMawbBangoRangeMaisuKeisan_正常_枚数計算範囲指定時_22_2
    //
    // -------------------テスト条件--------------------------
    // 再配布MAWB番号From = "77777770"  再配布MAWB番号To = "77777781"
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoRangeMaisuKeisan_正常_枚数計算範囲指定時_22_2() throws IllegalAccessException,
            InvocationTargetException, ParseException {
      
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuMawbBangoFrom("77777770");
        selectedBean.setSaiHaifuMawbBangoTo("77777781");
        form.setSelectedBean(selectedBean);

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoRangeMaisuKeisan();

        // 実施結果Outを取得
        form = target.getMwb011Form();

        // 想定通り
        assertEquals(2, form.getSelectedBean().getSaiHaifuMeisu());

    }
    
    // haifuMawbBangoRangeMaisuKeisan_正常_枚数計算範囲指定時_22_3
    //
    // -------------------テスト条件--------------------------
    // 再配布MAWB番号From = "7777755"  再配布MAWB番号To = "7777788"
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoRangeMaisuKeisan_正常_枚数計算範囲指定時_22_3() throws IllegalAccessException,
            InvocationTargetException, ParseException {
      
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuMawbBangoFrom("7777755");
        selectedBean.setSaiHaifuMawbBangoTo("7777788");
        form.setSelectedBean(selectedBean);

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoRangeMaisuKeisan();

        // 実施結果Outを取得
        form = target.getMwb011Form();

        // 想定通り
        assertEquals(34, form.getSelectedBean().getSaiHaifuMeisu());

    }
        
    // haifuMawbBangoRangeMaisuKeisan_異常_枚数計算範囲指定時_22_4
    //
    // -------------------テスト条件--------------------------
    // 再配布MAWB番号From = "77777781"  再配布MAWB番号To = "7777770"
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoRangeMaisuKeisan_異常_枚数計算範囲指定時_22_4() throws IllegalAccessException,
            InvocationTargetException, ParseException {
      
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_3.capture(), summaryCaptor_4.capture(), summaryCaptor_5.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuMawbBangoFrom("77777781");
        selectedBean.setSaiHaifuMawbBangoTo("7777770");
        form.setSelectedBean(selectedBean);

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoRangeMaisuKeisan();

        // 実施結果Outを取得
        form = target.getMwb011Form();

        // 想定通り
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("MWBE0001", summaryCaptor_4.getValue());
        assertEquals("再配布MAWB番号", summaryCaptor_5.getValue());

    }
    
    // onSaiHaifuTypeChange_正常_枚数計算番号指定時_23_1
    //
    // -------------------テスト条件--------------------------
    // 再配布形式 = 0
    // -----------------------------------------------------
    @Test
    public void onSaiHaifuTypeChange_正常_枚数計算番号指定時_23_1() throws IllegalAccessException,
            InvocationTargetException, ParseException {
      
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuType(0);
        selectedBean.setSaiHaifuMawbBangoFrom("");
        selectedBean.setSaiHaifuMawbBangoTo("");
        form.setSelectedBean(selectedBean);

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.onSaiHaifuTypeChange();

        // 実施結果Outを取得
        form = target.getMwb011Form();

        // 想定通り
        assertEquals(0, form.getSelectedBean().getSaiHaifuMeisu());

    }
    
    // onSaiHaifuTypeChange_正常_枚数計算番号指定時_23_1
    //
    // -------------------テスト条件--------------------------
    // 再配布形式 = 1
    // -----------------------------------------------------
    @Test
    public void onSaiHaifuTypeChange_正常_枚数計算番号指定時_23_2() throws IllegalAccessException,
            InvocationTargetException, ParseException {
      
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuType(1);
        selectedBean.setSelectedMawbBangoList(createMwbBangoBeanList());
        form.setSelectedBean(selectedBean);

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.onSaiHaifuTypeChange();

        // 実施結果Outを取得
        form = target.getMwb011Form();

        // 想定通り
        assertEquals(3, form.getSelectedBean().getSaiHaifuMeisu());

    }
    
    // onMawbBangoSelectColseClick_正常_閉じるボタンMAWB番号選択_30_1
    //
    // -------------------テスト条件--------------------------
    // 再配布MAWB番号リスト = null
    // -----------------------------------------------------
    @Test
    public void onMawbBangoSelectColseClick_正常_閉じるボタンMAWB番号選択_30_1() throws IllegalAccessException,
            InvocationTargetException, ParseException {
      
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        form.setSelectedBean(selectedBean);

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.onMawbBangoSelectColseClick();

        // 実施結果Outを取得
        form = target.getMwb011Form();

        // 想定通り
        assertEquals(0, form.getSelectedBean().getSaiHaifuMeisu());

    }
    
    // onMawbBangoSelectColseClick_正常_閉じるボタンMAWB番号選択_30_1
    //
    // -------------------テスト条件--------------------------
    // 再配布MAWB番号リスト not null
    // -----------------------------------------------------
    @Test
    public void onMawbBangoSelectColseClick_正常_閉じるボタンMAWB番号選択_30_2() throws IllegalAccessException,
            InvocationTargetException, ParseException {
      
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSelectedMawbBangoList(createMwbBangoBeanList());
        form.setSelectedBean(selectedBean);

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.onMawbBangoSelectColseClick();

        // 実施結果Outを取得
        form = target.getMwb011Form();

        // 想定通り
        assertEquals(3, form.getSelectedBean().getSaiHaifuMeisu());

    }
    
    // torokuMawbBangoInsert_正常_登録ボタンMAWB番号登録_18_1
    //
    // -------------------テスト条件--------------------------
    // 登録MAWB番号From = "77777770" 登録MAWB番号To = "77777781"
    // -----------------------------------------------------
    @Test
    public void torokuMawbBangoInsert_正常_登録ボタンMAWB番号登録_18_1() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> paramsCaptor_2 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 1
        int result = 0;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 1
        List<Map<String, Object>> resultList= new ArrayList();
        for(int i =0; i <= 0; i++) {
            resultList.add(createMwbBangoBeanMapForUpdateOrDelete());
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultList));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean, serviceInterfaceBean2);
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);     
        doNothing().when(pageCommonBean).executeScript(keyCaptor_2.capture());
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setMaxRows("10");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiTorokuMawbBangoFrom("77777770");
        selectedBean.setSaiTorokuMawbBangoTo("77777781");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.torokuMawbBangoInsert();

        // 実施結果Outを取得
        form = target.getMwb011Form();

        // 想定通り
        assertEquals(1, form.getRoot().getChildCount());

    }
        
    // torokuMawbBangoInsert_異常_登録ボタンMAWB番号登録_18_2
    //
    // -------------------テスト条件--------------------------
    // 登録MAWB番号From = "77777770" 登録MAWB番号To = "77777781"
    // 検索件数取得 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void torokuMawbBangoInsert_異常_登録ボタンMAWB番号登録_18_2() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> paramsCaptor_2 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 1
        int result = 1;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_3.capture(),summaryCaptor_4.capture());
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiTorokuMawbBangoFrom("77777770");
        selectedBean.setSaiTorokuMawbBangoTo("77777781");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.torokuMawbBangoInsert();

        // 実施結果Outを取得
        form = target.getMwb011Form();

        // 想定通り
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("MWBE0003", summaryCaptor_4.getValue());

    }
    
    // torokuMawbBangoInsert_異常_登録ボタンMAWB番号登録_18_3
    //
    // -------------------テスト条件--------------------------
    // 登録MAWB番号From = "77777770" 登録MAWB番号To = "77777781"
    // 検索件数取得 取得件数 = 0 検索エラーの場合
    // -----------------------------------------------------
    @Test
    public void torokuMawbBangoInsert_異常_登録ボタンMAWB番号登録_18_3() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> paramsCaptor_2 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 1
        int result = 0;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 1
        serviceInterfaceBean2.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean, serviceInterfaceBean2);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_3.capture(),summaryCaptor_4.capture());
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiTorokuMawbBangoFrom("77777770");
        selectedBean.setSaiTorokuMawbBangoTo("77777781");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.torokuMawbBangoInsert();

    }
    
    // torokuMawbBangoInsert_異常_登録ボタンMAWB番号登録_18_3
    //
    // -------------------テスト条件--------------------------
    // 登録MAWB番号From = null
    // -----------------------------------------------------
    @Test
    public void torokuMawbBangoInsert_異常_登録ボタンMAWB番号登録_18_4() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_3.capture(),summaryCaptor_4.capture(),summaryCaptor_5.capture());
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.torokuMawbBangoInsert();
        
        // 想定通り
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0003", summaryCaptor_4.getValue());
        assertEquals("登録MAWB番号From", summaryCaptor_5.getValue());

    }
    
    // torokuMawbBangoUpdate_正常_更新ボタン(MAWB番号登録)_19_1
    //
    // -------------------テスト条件--------------------------
    // 再登録MAWB番号From = "77777770" 再登録MAWB番号To = "77777781"
    // -----------------------------------------------------
    @Test
    public void torokuMawbBangoUpdate_正常_更新ボタン_19_1() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> paramsCaptor_2 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 1
        int result = 0;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 1
        List<Map<String, Object>> resultList= new ArrayList();
        for(int i =0; i <= 0; i++) {
            resultList.add(createMwbBangoBeanMapForUpdateOrDelete());
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultList));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean, serviceInterfaceBean2);
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);     
        doNothing().when(pageCommonBean).executeScript(keyCaptor_2.capture());
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setMaxRows("10");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiTorokuMawbBangoFrom("77777770");
        selectedBean.setSaiTorokuMawbBangoTo("77777781");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.torokuMawbBangoUpdate();

        // 実施結果Outを取得
        form = target.getMwb011Form();

        // 想定通り
        assertEquals(1, form.getRoot().getChildCount());

    }
    
    // torokuMawbBangoUpdate_異常_更新ボタン_19_2
    //
    // -------------------テスト条件--------------------------
    // // 再登録MAWB番号From = null
    // -----------------------------------------------------
    @Test
    public void torokuMawbBangoUpdate_異常_更新ボタン_19_2() throws IllegalAccessException,
            InvocationTargetException, ParseException {
       
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.torokuMawbBangoUpdate();

        // 実施結果Outを取得
        form = target.getMwb011Form();

        // 想定通り
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0003", summaryCaptor_4.getValue());
        assertEquals("登録MAWB番号From", detailCaptor_5.getValue());

    }
    
    // torokuMawbBangoUpdate_異常_更新ボタン_19_2_1
    //
    // -------------------テスト条件--------------------------
    // 再登録MAWB番号From = "77777770" 再登録MAWB番号To = null
    // -----------------------------------------------------
    @Test
    public void torokuMawbBangoUpdate_異常_更新ボタン_19_2_1() throws IllegalAccessException,
            InvocationTargetException, ParseException {
       
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiTorokuMawbBangoFrom("77777770");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.torokuMawbBangoUpdate();

        // 実施結果Outを取得
        form = target.getMwb011Form();

        // 想定通り
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0003", summaryCaptor_4.getValue());
        assertEquals("登録MAWB番号To", detailCaptor_5.getValue());

    }
    
    // torokuMawbBangoUpdate_異常_更新ボタン_19_2_2
    //
    // -------------------テスト条件--------------------------
    // 再登録MAWB番号From = "77777777" 再登録MAWB番号To = "77777781"
    // -----------------------------------------------------
    @Test
    public void torokuMawbBangoUpdate_異常_更新ボタン_19_2_2() throws IllegalAccessException,
            InvocationTargetException, ParseException {
       
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiTorokuMawbBangoFrom("77777777");
        selectedBean.setSaiTorokuMawbBangoTo("77777781");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.torokuMawbBangoUpdate();

        // 実施結果Outを取得
        form = target.getMwb011Form();

        // 想定通り
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0007", summaryCaptor_4.getValue());
        assertEquals("登録MAWB番号From", detailCaptor_5.getValue());

    }    
    
    // torokuMawbBangoUpdate_異常_更新ボタン_19_2_3
    //
    // -------------------テスト条件--------------------------
    // 再登録MAWB番号From = "77777777" 再登録MAWB番号To = "77777782"
    // -----------------------------------------------------
    @Test
    public void torokuMawbBangoUpdate_異常_更新ボタン_19_2_3() throws IllegalAccessException,
            InvocationTargetException, ParseException {
       
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiTorokuMawbBangoFrom("77777770");
        selectedBean.setSaiTorokuMawbBangoTo("77777782");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.torokuMawbBangoUpdate();

        // 想定通り
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0007", summaryCaptor_4.getValue());
        assertEquals("登録MAWB番号To", detailCaptor_5.getValue());

    }
    
    // torokuMawbBangoUpdate_異常_更新ボタン_19_2_4
    //
    // -------------------テスト条件--------------------------
    // 再登録MAWB番号From = "77777781" 再登録MAWB番号To = "77777770"
    // -----------------------------------------------------
    @Test
    public void torokuMawbBangoUpdate_異常_更新ボタン_19_2_4() throws IllegalAccessException,
            InvocationTargetException, ParseException {
       
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiTorokuMawbBangoFrom("77777781");
        selectedBean.setSaiTorokuMawbBangoTo("77777770");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.torokuMawbBangoUpdate();

        // 想定通り
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("MWBE0001", summaryCaptor_4.getValue());
        assertEquals("登録MAWB番号", detailCaptor_5.getValue());

    }
    
        
    // torokuMawbBangoUpdate_異常_更新ボタン_19_3
    //
    // -------------------テスト条件--------------------------
    // 検索件数取得 取得件数 = 1 
    // 再登録MAWB番号From = "77777770" 再登録MAWB番号To = "77777781"
    // -----------------------------------------------------
    @Test
    public void torokuMawbBangoUpdate_異常_更新ボタン_19_3() throws IllegalAccessException,
            InvocationTargetException, ParseException {
       
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> paramsCaptor_2 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 1
        List<Map<String, Object>> resultList= new ArrayList();
        for(int i =0; i <= 0; i++) {
            resultList.add(createMwbBangoBeanMapFor_19_3());
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_3.capture(),summaryCaptor_4.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapFor_19_3());
        selectedBean.setSaiTorokuMawbBangoFrom("77777770");
        selectedBean.setSaiTorokuMawbBangoTo("77777781");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.torokuMawbBangoUpdate();
        
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("MWBE0003", summaryCaptor_4.getValue());

    }
    
    // torokuMawbBangoUpdate_異常_更新ボタン_19_3_1
    //
    // -------------------テスト条件--------------------------
    // 検索件数取得 取得件数 = 1 
    // 再登録MAWB番号From = "77777770" 再登録MAWB番号To = "77777803"
    // -----------------------------------------------------
    @Test
    public void torokuMawbBangoUpdate_異常_更新ボタン_19_3_1() throws IllegalAccessException,
            InvocationTargetException, ParseException {
       
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 1
        List<Map<String, Object>> resultList= new ArrayList();
        for(int i =0; i <= 0; i++) {
            resultList.add(createMwbBangoBeanMapFor_19_3());
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_3.capture(),summaryCaptor_4.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapFor_19_3());
        selectedBean.setSaiTorokuMawbBangoFrom("77777770");
        selectedBean.setSaiTorokuMawbBangoTo("77777803");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.torokuMawbBangoUpdate();
        
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("MWBE0003", summaryCaptor_4.getValue());

    }
    
    // torokuMawbBangoUpdate_異常_更新ボタン_19_3_2
    //
    // -------------------テスト条件--------------------------
    // 検索件数取得 取得件数 = 1 
    // 再登録MAWB番号From = "77777755" 再登録MAWB番号To = "77777781"
    // -----------------------------------------------------
    @Test
    public void torokuMawbBangoUpdate_異常_更新ボタン_19_3_2() throws IllegalAccessException,
            InvocationTargetException, ParseException {
       
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 1
        List<Map<String, Object>> resultList= new ArrayList();
        for(int i =0; i <= 0; i++) {
            resultList.add(createMwbBangoBeanMapFor_19_3());
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_3.capture(),summaryCaptor_4.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapFor_19_3());
        selectedBean.setSaiTorokuMawbBangoFrom("77777755");
        selectedBean.setSaiTorokuMawbBangoTo("77777781");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.torokuMawbBangoUpdate();
        
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("MWBE0003", summaryCaptor_4.getValue());

    }
    
    // torokuMawbBangoUpdate_異常_更新ボタン_19_3_3
    //
    // -------------------テスト条件--------------------------
    // 検索件数取得 取得件数 = 1 
    // 再登録MAWB番号From = "77777803" 再登録MAWB番号To = "77777814"
    // -----------------------------------------------------
    @Test
    public void torokuMawbBangoUpdate_異常_更新ボタン_19_3_3() throws IllegalAccessException,
            InvocationTargetException, ParseException {
       
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 1
        List<Map<String, Object>> resultList= new ArrayList();
        for(int i =0; i <= 0; i++) {
            resultList.add(createMwbBangoBeanMapFor_19_3());
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_3.capture(),summaryCaptor_4.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapFor_19_3());
        selectedBean.setSaiTorokuMawbBangoFrom("77777803");
        selectedBean.setSaiTorokuMawbBangoTo("77777814");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.torokuMawbBangoUpdate();
        
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("MWBE0003", summaryCaptor_4.getValue());

    }
    
    // torokuMawbBangoUpdate_異常_更新ボタン_19_3_4
    //
    // -------------------テスト条件--------------------------
    // 検索件数取得 取得件数 = 1 
    // 再登録MAWB番号From = "77777744" 再登録MAWB番号To = "77777755"
    // -----------------------------------------------------
    @Test
    public void torokuMawbBangoUpdate_異常_更新ボタン_19_3_4() throws IllegalAccessException,
            InvocationTargetException, ParseException {
       
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 1
        List<Map<String, Object>> resultList= new ArrayList();
        for(int i =0; i <= 0; i++) {
            resultList.add(createMwbBangoBeanMapFor_19_3());
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_3.capture(),summaryCaptor_4.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapFor_19_3());
        selectedBean.setSaiTorokuMawbBangoFrom("77777744");
        selectedBean.setSaiTorokuMawbBangoTo("77777755");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.torokuMawbBangoUpdate();
        
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("MWBE0003", summaryCaptor_4.getValue());

    }
    
    // torokuMawbBangoUpdate_異常_更新ボタン_19_4
    //
    // -------------------テスト条件--------------------------
    // 検索件数取得 取得件数 = 1
    // 再登録MAWB番号From = "77777770" 再登録MAWB番号To = "77777781"
    // -----------------------------------------------------
    @Test
    public void torokuMawbBangoUpdate_異常_更新ボタン_19_4() throws IllegalAccessException,
            InvocationTargetException, ParseException {
       
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 1
        int result = 1;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiTorokuMawbBangoFrom("77777770");
        selectedBean.setSaiTorokuMawbBangoTo("77777781");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.torokuMawbBangoUpdate();
        
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("MWBE0004", summaryCaptor_4.getValue());
        assertEquals("登録", detailCaptor_5.getValue());

    }
    
    // torokuMawbBangoUpdate_異常_更新ボタン_19_5
    //
    // -------------------テスト条件--------------------------
    // 検索件数取得 取得件数 = 1
    // 再登録MAWB番号From = "77777770" 再登録MAWB番号To = "77777781"
    // 検索エラーの場合
    // -----------------------------------------------------
    @Test
    public void torokuMawbBangoUpdate_異常_更新ボタン_19_5() throws IllegalAccessException,
            InvocationTargetException, ParseException {
       
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 重複チェック検索件数取得 取得件数 =0
        int result = 0;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        serviceInterfaceBean2.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean,serviceInterfaceBean2);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiTorokuMawbBangoFrom("77777770");
        selectedBean.setSaiTorokuMawbBangoTo("77777781");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.torokuMawbBangoUpdate();

    }
    
    // torokuMawbBangoUpdate_正常_削除ボタン_20_1
    //
    // -------------------テスト条件--------------------------
    // 検索件数取得 取得件数 = 1
    // 再登録MAWB番号From = "77777770" 再登録MAWB番号To = "77777781"
    // -----------------------------------------------------
    @Test
    public void torokuMawbBangoDelete_正常_削除ボタン_20_1() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 1
        List<Map<String, Object>> resultList= new ArrayList();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
         List<Map<String, Object>> resultList2= new ArrayList();
        for(int i =0; i <= 0; i++) {
            resultList2.add(createMwbBangoBeanMapForUpdateOrDelete());
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultList2));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean, serviceInterfaceBean2);
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);     
        doNothing().when(pageCommonBean).executeScript(keyCaptor_2.capture());
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setMaxRows("10");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiTorokuMawbBangoFrom("77777770");
        selectedBean.setSaiTorokuMawbBangoTo("77777781");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.torokuMawbBangoDelete();

        // 実施結果Outを取得
        form = target.getMwb011Form();

        // 想定通り
        assertEquals(1, form.getRoot().getChildCount());

    }
    
    // torokuMawbBangoDelete_異常_削除ボタン_20_1_1
    //
    // -------------------テスト条件--------------------------
    // 再登録MAWB番号From = "77777765"
    // -----------------------------------------------------
    @Test
    public void torokuMawbBangoDelete_異常_削除ボタン_20_1_1() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiTorokuMawbBangoFrom("77777765");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.torokuMawbBangoDelete();

    }
    
    // torokuMawbBangoUpdate_異常_削除ボタン_20_2
    //
    // -------------------テスト条件--------------------------
    // 再登録MAWB番号From = "77777766" 再登録MAWB番号From = "77777792"
    // -----------------------------------------------------
    @Test
    public void torokuMawbBangoDelete_異常_削除ボタン_20_2() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);

        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiTorokuMawbBangoFrom("77777766");
        selectedBean.setSaiTorokuMawbBangoTo("77777792");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.torokuMawbBangoDelete();

        // 想定通り
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("MWBE0005", summaryCaptor_4.getValue());
        assertEquals("削除", detailCaptor_5.getValue());

    }
    
    // torokuMawbBangoUpdate_異常_削除ボタン_20_3
    //
    // -------------------テスト条件--------------------------
    // 検索件数取得 取得件数 = 1
    // 再登録MAWB番号From = "77777770" 再登録MAWB番号To = "77777781"
    // -----------------------------------------------------
    @Test
    public void torokuMawbBangoDelete_異常_削除ボタン_20_3() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        List<Map<String, Object>> resultList= new ArrayList();
        for(int i =0; i <= 0; i++) {
            resultList.add(createMwbBangoBeanMapForUpdateOrDelete());
        }
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_3.capture(),summaryCaptor_4.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiTorokuMawbBangoFrom("77777770");
        selectedBean.setSaiTorokuMawbBangoTo("77777781");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.torokuMawbBangoDelete();

        // 想定通り
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("MWBE0003", summaryCaptor_4.getValue());

    }
    
    // torokuMawbBangoDelete_異常_削除ボタン_20_4
    //
    // -------------------テスト条件--------------------------
    // 再登録MAWB番号From = "77777770" 再登録MAWB番号To = "77777781"
    // 検索エラーの場合
    // -----------------------------------------------------
    @Test
    public void torokuMawbBangoDelete_異常_削除ボタン_20_4() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        List<Map<String, Object>> resultList= new ArrayList();
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        serviceInterfaceBean2.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean2.addMessage("ERROR", "COME0007", "登録MAWB番号");
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean, serviceInterfaceBean2);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiTorokuMawbBangoFrom("77777770");
        selectedBean.setSaiTorokuMawbBangoTo("77777781");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.torokuMawbBangoDelete();

        // 想定通り
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0007", summaryCaptor_4.getValue());
        assertEquals("登録MAWB番号", detailCaptor_5.getValue());

    }
    
    // haifuMawbBangoUpdate_正常_再配布形式_21_1
    //
    // -------------------テスト条件--------------------------
    // 再登録MAWB番号From = "77777770" 再登録MAWB番号To = "77777781"
    //  配布日付 = "2019/01/02" 再配布先営業所コード = "132" 再配布先営業所名称 = "132" 
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoUpdate_正常_再配布形式_21_1() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiTorokuMawbBangoFrom("77777770");
        selectedBean.setSaiTorokuMawbBangoTo("77777781");
        selectedBean.setSaiHaifuHizuke("2019/01/02");
        AutoCompOptionBean saiHaifusakiEigyosho = new AutoCompOptionBean();
        saiHaifusakiEigyosho.setValue("132");
        saiHaifusakiEigyosho.setLabel("再配布先営業所");
        selectedBean.setSaiHaifusakiEigyosho(saiHaifusakiEigyosho);
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoUpdate();
        
        form = target.getMwb011Form();

        // 想定通り
        assertEquals("77777770", form.getSelectedBean().getSaiTorokuMawbBangoFrom());
        assertEquals("2019/01/02", form.getSelectedBean().getSaiHaifuHizuke());

    }
    
    // haifuMawbBangoUpdate_正常_再配布形式_21_2
    //
    // -------------------テスト条件--------------------------
    // 再登録MAWB番号From = "77777770" 再登録MAWB番号To = "77777781"
    //  配布日付 = "2019/01/02" 再配布先営業所 = "132" 再配布先営業所名称 = "再配布先営業所" 
    // 再配布先営業所コード　= "132" 
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoUpdate_正常_再配布形式_21_2() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
         // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_2 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_1.capture(),paramsCaptor_2.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiTorokuMawbBangoFrom("77777770");
        selectedBean.setSaiTorokuMawbBangoTo("77777781");
        selectedBean.setSaiHaifuHizuke("2019/01/02");
        selectedBean.setSaiHaifuType(1);
        AutoCompOptionBean saiHaifusakiEigyosho = new AutoCompOptionBean();
        saiHaifusakiEigyosho.setValue("132");
        saiHaifusakiEigyosho.setLabel("再配布先営業所");
        selectedBean.setSaiHaifusakiEigyosho(saiHaifusakiEigyosho);
        selectedBean.setHaifusakiEigyoshoCd("132");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoUpdate();
        
        form = target.getMwb011Form();

        // 想定通り
        assertEquals("ERROR", paramsCaptor_1.getValue());
        assertEquals("MWBE0006", paramsCaptor_2.getValue());

    }
    
    // haifuMawbBangoRangeUpdate_正常_範囲指定時MAWB配布登録_26_1
    //
    // -------------------テスト条件--------------------------
    // 再配布MAWB番号From = "77777770" 再配布MAWB番号To = "77777781"
    //  配布日付 = "2019/01/02" 再配布先営業所 = "132" 再配布先営業所名称 = "再配布先営業所" 
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoRangeUpdate_正常_範囲指定時MAWB配布登録_26_1() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 0
        List<Map<String, Object>> resultList= new ArrayList();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 0
        List<Map<String, Object>> resultList2= new ArrayList();
        for(int i = 0; i<=0; i++) {
            resultList2.add(createMwbBangoBeanMapForUpdateOrDelete());
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultList2));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean, serviceInterfaceBean2);
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);     
        doNothing().when(pageCommonBean).executeScript(keyCaptor_2.capture());
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setMaxRows("10");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuMawbBangoFrom("77777770");
        selectedBean.setSaiHaifuMawbBangoTo("77777781");
        selectedBean.setSaiHaifuHizuke("2019/01/02");
        AutoCompOptionBean saiHaifusakiEigyosho = new AutoCompOptionBean();
        saiHaifusakiEigyosho.setValue("132");
        saiHaifusakiEigyosho.setLabel("再配布先営業所");
        selectedBean.setSaiHaifusakiEigyosho(saiHaifusakiEigyosho);
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoRangeUpdate();

        // 想定通り
       assertEquals(1, form.getRoot().getChildCount());

    }
    
    // haifuMawbBangoRangeUpdate_正常_範囲指定時MAWB配布登録_26_2
    //
    // -------------------テスト条件--------------------------
    // 再配布MAWB番号From = "77777770" 再配布MAWB番号To = "77777781"
    //  配布日付 = "2019/01/02" 再配布先営業所 = "132" 再配布先営業所名称 = "再配布先営業所" 
    //  再配布先営業所コード = "132"
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoRangeUpdate_異常_範囲指定時MAWB配布登録_26_2() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
                 // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_2 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_1.capture(),paramsCaptor_2.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuMawbBangoFrom("77777770");
        selectedBean.setSaiHaifuMawbBangoTo("77777781");
        selectedBean.setSaiHaifuHizuke("2019/01/02");
        AutoCompOptionBean saiHaifusakiEigyosho = new AutoCompOptionBean();
        saiHaifusakiEigyosho.setValue("132");
        saiHaifusakiEigyosho.setLabel("再配布先営業所");
        selectedBean.setSaiHaifusakiEigyosho(saiHaifusakiEigyosho);
        selectedBean.setHaifusakiEigyoshoCd("132");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoRangeUpdate();

        // 想定通り
       assertEquals("ERROR", paramsCaptor_1.getValue());
       assertEquals("MWBE0006", paramsCaptor_2.getValue());

    }
    
    // haifuMawbBangoRangeUpdate_正常_範囲指定時MAWB配布登録_26_3
    //
    // -------------------テスト条件--------------------------
    //  配布日付 = null
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoRangeUpdate_異常_範囲指定時MAWB配布登録_26_3() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_3 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_1.capture(),paramsCaptor_2.capture(), paramsCaptor_3.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoRangeUpdate();

        // 想定通り
       assertEquals("ERROR", paramsCaptor_1.getValue());
       assertEquals("COME0003", paramsCaptor_2.getValue());
       assertEquals("再配布日付", paramsCaptor_3.getValue());

    }
    
    // haifuMawbBangoRangeUpdate_異常_範囲指定時MAWB配布登録_26_3_1
    //
    // -------------------テスト条件--------------------------
    //  配布日付 = "2019/01/02" 再配布先営業所 = null 
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoRangeUpdate_異常_範囲指定時MAWB配布登録_26_3_1() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_3 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_1.capture(),paramsCaptor_2.capture(), paramsCaptor_3.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuHizuke("2019/01/02");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoRangeUpdate();

        // 想定通り
       assertEquals("ERROR", paramsCaptor_1.getValue());
       assertEquals("COME0003", paramsCaptor_2.getValue());
       assertEquals("再配布先営業所コード", paramsCaptor_3.getValue());

    }
    
    // haifuMawbBangoRangeUpdate_異常_範囲指定時MAWB配布登録_26_3_2
    //
    // -------------------テスト条件--------------------------
    //  配布日付 = "2019/01/02" 再配布先営業所 = "132" 再配布先営業所名称 = null
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoRangeUpdate_異常_範囲指定時MAWB配布登録_26_3_2() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
         // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_3 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_1.capture(),paramsCaptor_2.capture(), paramsCaptor_3.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuHizuke("2019/01/02");
        AutoCompOptionBean saiHaifusakiEigyosho = new AutoCompOptionBean();
        saiHaifusakiEigyosho.setValue("132");
        selectedBean.setSaiHaifusakiEigyosho(saiHaifusakiEigyosho);
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoRangeUpdate();

        // 想定通り
       assertEquals("ERROR", paramsCaptor_1.getValue());
       assertEquals("COME0003", paramsCaptor_2.getValue());
       assertEquals("再配布先営業所名", paramsCaptor_3.getValue());

    }
    
    // haifuMawbBangoRangeUpdate_異常_範囲指定時MAWB配布登録_26_3_3
    //
    // -------------------テスト条件--------------------------
    // 再配布MAWB番号From = null
    //  配布日付 = "2019/01/02" 再配布先営業所 = "132" 再配布先営業所名称 = "再配布先営業所" 
    //  再配布先営業所コード = "133"
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoRangeUpdate_異常_範囲指定時MAWB配布登録_26_3_3() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
         // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_3 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_1.capture(),paramsCaptor_2.capture(), paramsCaptor_3.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuHizuke("2019/01/02");
        AutoCompOptionBean saiHaifusakiEigyosho = new AutoCompOptionBean();
        saiHaifusakiEigyosho.setValue("132");
        saiHaifusakiEigyosho.setLabel("再配布先営業所");
        selectedBean.setSaiHaifusakiEigyosho(saiHaifusakiEigyosho);
        selectedBean.setHaifusakiEigyoshoCd("133");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoRangeUpdate();

        // 想定通り
       assertEquals("ERROR", paramsCaptor_1.getValue());
       assertEquals("COME0003", paramsCaptor_2.getValue());
       assertEquals("再配布MAWB番号From", paramsCaptor_3.getValue());

    }
    
    // haifuMawbBangoRangeUpdate_異常_範囲指定時MAWB配布登録_26_3_4
    //
    // -------------------テスト条件--------------------------
    // 再配布MAWB番号From = "77777770" 再配布MAWB番号To = null
    //  配布日付 = "2019/01/02" 再配布先営業所 = "132" 再配布先営業所名称 = "再配布先営業所" 
    //  再配布先営業所コード = "133"
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoRangeUpdate_異常_範囲指定時MAWB配布登録_26_3_4() throws IllegalAccessException,
            InvocationTargetException, ParseException {
         // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_3 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_1.capture(),paramsCaptor_2.capture(), paramsCaptor_3.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuMawbBangoFrom("77777770");
        selectedBean.setSaiHaifuHizuke("2019/01/02");
        AutoCompOptionBean saiHaifusakiEigyosho = new AutoCompOptionBean();
        saiHaifusakiEigyosho.setValue("132");
        saiHaifusakiEigyosho.setLabel("再配布先営業所");
        selectedBean.setSaiHaifusakiEigyosho(saiHaifusakiEigyosho);
        selectedBean.setHaifusakiEigyoshoCd("133");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoRangeUpdate();

        // 想定通り
       assertEquals("ERROR", paramsCaptor_1.getValue());
       assertEquals("COME0003", paramsCaptor_2.getValue());
       assertEquals("再配布MAWB番号To", paramsCaptor_3.getValue());

    }
    
    // haifuMawbBangoRangeUpdate_異常_範囲指定時MAWB配布登録_26_3_5
    //
    // -------------------テスト条件--------------------------
    // 再配布MAWB番号From = "77777771" 再配布MAWB番号To = "77777781"
    //  配布日付 = "2019/01/02" 再配布先営業所 = "132" 再配布先営業所名称 = "再配布先営業所" 
    //  再配布先営業所コード = "132"
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoRangeUpdate_異常_範囲指定時MAWB配布登録_26_3_5() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_3 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_1.capture(),paramsCaptor_2.capture(), paramsCaptor_3.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuMawbBangoFrom("77777771");
        selectedBean.setSaiHaifuMawbBangoTo("77777781");
        selectedBean.setSaiHaifuHizuke("2019/01/02");
        AutoCompOptionBean saiHaifusakiEigyosho = new AutoCompOptionBean();
        saiHaifusakiEigyosho.setValue("132");
        saiHaifusakiEigyosho.setLabel("再配布先営業所");
        selectedBean.setSaiHaifusakiEigyosho(saiHaifusakiEigyosho);
        selectedBean.setHaifusakiEigyoshoCd("133");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoRangeUpdate();

        // 想定通り
       assertEquals("ERROR", paramsCaptor_1.getValue());
       assertEquals("COME0007", paramsCaptor_2.getValue());
       assertEquals("再配布MAWB番号From", paramsCaptor_3.getValue());

    }
    
    // haifuMawbBangoRangeUpdate_異常_範囲指定時MAWB配布登録_26_3_6
    //
    // -------------------テスト条件--------------------------
    // 再配布MAWB番号From = "77777770" 再配布MAWB番号To = "77777780"
    //  配布日付 = "2019/01/02" 再配布先営業所 = "132" 再配布先営業所名称 = "再配布先営業所" 
    //  再配布先営業所コード = "132"
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoRangeUpdate_異常_範囲指定時MAWB配布登録_26_3_6() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
       // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_3 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_1.capture(),paramsCaptor_2.capture(), paramsCaptor_3.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuMawbBangoFrom("77777770");
        selectedBean.setSaiHaifuMawbBangoTo("77777780");
        selectedBean.setSaiHaifuHizuke("2019/01/02");
        AutoCompOptionBean saiHaifusakiEigyosho = new AutoCompOptionBean();
        saiHaifusakiEigyosho.setValue("132");
        saiHaifusakiEigyosho.setLabel("再配布先営業所");
        selectedBean.setSaiHaifusakiEigyosho(saiHaifusakiEigyosho);
        selectedBean.setHaifusakiEigyoshoCd("133");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoRangeUpdate();

        // 想定通り
       assertEquals("ERROR", paramsCaptor_1.getValue());
       assertEquals("COME0007", paramsCaptor_2.getValue());
       assertEquals("再配布MAWB番号To", paramsCaptor_3.getValue());

    }
    
    // haifuMawbBangoRangeUpdate_異常_範囲指定時MAWB配布登録_26_3_7
    //
    // -------------------テスト条件--------------------------
    // 再配布MAWB番号From = "77777781" 再配布MAWB番号To = "77777770"
    //  配布日付 = "2019/01/02" 再配布先営業所 = "132" 再配布先営業所名称 = "再配布先営業所" 
    //  再配布先営業所コード = "132"
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoRangeUpdate_異常_範囲指定時MAWB配布登録_26_3_7() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_3 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_1.capture(),paramsCaptor_2.capture(), paramsCaptor_3.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuMawbBangoFrom("77777781");
        selectedBean.setSaiHaifuMawbBangoTo("77777770");
        selectedBean.setSaiHaifuHizuke("2019/01/02");
        AutoCompOptionBean saiHaifusakiEigyosho = new AutoCompOptionBean();
        saiHaifusakiEigyosho.setValue("132");
        saiHaifusakiEigyosho.setLabel("再配布先営業所");
        selectedBean.setSaiHaifusakiEigyosho(saiHaifusakiEigyosho);
        selectedBean.setHaifusakiEigyoshoCd("133");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoRangeUpdate();

        // 想定通り
       assertEquals("ERROR", paramsCaptor_1.getValue());
       assertEquals("MWBE0001", paramsCaptor_2.getValue());
       assertEquals("再配布MAWB番号", paramsCaptor_3.getValue());

    }
    
    // haifuMawbBangoRangeUpdate_正常_範囲指定時MAWB配布登録_26_4
    //
    // -------------------テスト条件--------------------------
    // MAWB番号Form = "77777781" MAWB番号To = "77777792"
    // 再配布MAWB番号From = "77777770" 再配布MAWB番号To = "77777781"
    //  配布日付 = "2019/01/02" 再配布先営業所 = "132" 再配布先営業所名称 = "再配布先営業所" 
    //  再配布先営業所コード = "132"
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoRangeUpdate_異常_範囲指定時MAWB配布登録_26_4() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_3 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_1.capture(),paramsCaptor_2.capture(), paramsCaptor_3.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuMawbBangoFrom("77777770");
        selectedBean.setSaiHaifuMawbBangoTo("77777781");
        selectedBean.setSaiHaifuHizuke("2019/01/02");
        selectedBean.setHaifuMawbBangoFrom("77777781");
        selectedBean.setHaifuMawbBangoTo("77777792");
        AutoCompOptionBean saiHaifusakiEigyosho = new AutoCompOptionBean();
        saiHaifusakiEigyosho.setValue("132");
        saiHaifusakiEigyosho.setLabel("再配布先営業所");
        selectedBean.setSaiHaifusakiEigyosho(saiHaifusakiEigyosho);
        selectedBean.setHaifusakiEigyoshoCd("133");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoRangeUpdate();

        // 想定通り
       assertEquals("ERROR", paramsCaptor_1.getValue());
       assertEquals("MWBE0005", paramsCaptor_2.getValue());
       assertEquals("更新", paramsCaptor_3.getValue());

    }
    
    // haifuMawbBangoRangeUpdate_正常_範囲指定時MAWB配布登録_26_5
    //
    // -------------------テスト条件--------------------------
    // 検索件数取得 取得件数 = 1
    // MAWB番号Form = "77777766" MAWB番号To = "77777781"
    // 再配布MAWB番号From = "77777770" 再配布MAWB番号To = "77777781"
    //  配布日付 = "2019/01/02" 再配布先営業所 = "132" 再配布先営業所名称 = "再配布先営業所" 
    //  再配布先営業所コード = "132"
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoRangeUpdate_異常_範囲指定時MAWB配布登録_26_5() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_4 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 1
        List<Map<String, Object>> resultList= new ArrayList();
         for(int i = 0; i<=0; i++) {
            resultList.add(createMwbBangoBeanMapForUpdateOrDelete());
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
         when(pageCommonBean.getDBInfo(paramsCaptor_4.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_1.capture(),paramsCaptor_2.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuMawbBangoFrom("77777770");
        selectedBean.setSaiHaifuMawbBangoTo("77777781");
        selectedBean.setSaiHaifuHizuke("2019/01/02");
        selectedBean.setHaifuMawbBangoFrom("77777766");
        selectedBean.setHaifuMawbBangoTo("77777781");
        AutoCompOptionBean saiHaifusakiEigyosho = new AutoCompOptionBean();
        saiHaifusakiEigyosho.setValue("132");
        saiHaifusakiEigyosho.setLabel("再配布先営業所");
        selectedBean.setSaiHaifusakiEigyosho(saiHaifusakiEigyosho);
        selectedBean.setHaifusakiEigyoshoCd("133");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoRangeUpdate();

        // 想定通り
       assertEquals("ERROR", paramsCaptor_1.getValue());
       assertEquals("MWBE0003", paramsCaptor_2.getValue());

    }
    
    // haifuMawbBangoRangeUpdate_正常_範囲指定時MAWB配布登録_26_6
    //
    // -------------------テスト条件--------------------------
    // 検索件数取得 取得件数 = 0
    // MAWB番号Form = "77777766" MAWB番号To = "77777781"
    // 再配布MAWB番号From = "77777770" 再配布MAWB番号To = "77777781"
    //  配布日付 = "2019/01/02" 再配布先営業所 = "132" 再配布先営業所名称 = "再配布先営業所" 
    //  再配布先営業所コード = "132"
    // 検索エラーの場合
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoRangeUpdate_異常_範囲指定時MAWB配布登録_26_6() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_4 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 0
        List<Map<String, Object>> resultList= new ArrayList();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
        // エラーの場合、処理終了
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        serviceInterfaceBean2.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        when(pageCommonBean.getDBInfo(paramsCaptor_4.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean, serviceInterfaceBean2);
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_1.capture(),paramsCaptor_2.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuMawbBangoFrom("77777770");
        selectedBean.setSaiHaifuMawbBangoTo("77777781");
        selectedBean.setSaiHaifuHizuke("2019/01/02");
        selectedBean.setHaifuMawbBangoFrom("77777766");
        selectedBean.setHaifuMawbBangoTo("77777781");
        AutoCompOptionBean saiHaifusakiEigyosho = new AutoCompOptionBean();
        saiHaifusakiEigyosho.setValue("132");
        saiHaifusakiEigyosho.setLabel("再配布先営業所");
        selectedBean.setSaiHaifusakiEigyosho(saiHaifusakiEigyosho);
        selectedBean.setHaifusakiEigyoshoCd("133");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoRangeUpdate();

    }
    
    // haifuMawbBangoRangeUpdate_正常_番号指定時MAWB配布登録_27_1
    //
    // -------------------テスト条件--------------------------
    // 再配布MAWB番号From = "77777766" 再配布MAWB番号To = "77777814"
    //  配布日付 = "2019/01/02" 再配布先営業所 = "132" 再配布先営業所名称 = "再配布先営業所" 
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoListUpdate_正常_番号指定時MAWB配布登録_27_1() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 0
        List<Map<String, Object>> resultList= new ArrayList();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 0
        List<Map<String, Object>> resultList2= new ArrayList();
        for(int i = 0; i<=0; i++) {
            resultList2.add(createMwbBangoBeanMapForUpdateOrDelete());
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultList2));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean, serviceInterfaceBean2);
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);     
        doNothing().when(pageCommonBean).executeScript(keyCaptor_2.capture());
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setMaxRows("10");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setHaifuMawbBangoFrom("77777766");
        selectedBean.setHaifuMawbBangoTo("77777814");
        selectedBean.setSaiHaifuHizuke("2019/01/02");
        selectedBean.setSelectedMawbBangoList(createMwbBangoBeanList());
        AutoCompOptionBean saiHaifusakiEigyosho = new AutoCompOptionBean();
        saiHaifusakiEigyosho.setValue("132");
        saiHaifusakiEigyosho.setLabel("再配布先営業所");
        selectedBean.setSaiHaifusakiEigyosho(saiHaifusakiEigyosho);
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoListUpdate();

        // 想定通り
       assertEquals(1, form.getRoot().getChildCount());

    }
    
    // haifuMawbBangoListUpdate_異常_番号指定時MAWB配布登録_27_2
    //
    // -------------------テスト条件--------------------------
    // 再配布MAWB番号From = "77777766" 再配布MAWB番号To = "77777814"
    //  配布日付 = "2019/01/02" 再配布先営業所 = "132" 再配布先営業所名称 = "再配布先営業所" 
    //  再配布先営業所コード = "132"
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoListUpdate_異常_番号指定時MAWB配布登録_27_2() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_2 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_1.capture(),paramsCaptor_2.capture());
       
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setHaifuMawbBangoFrom("77777766");
        selectedBean.setHaifuMawbBangoTo("77777814");
        selectedBean.setSaiHaifuHizuke("2019/01/02");
        selectedBean.setSelectedMawbBangoList(createMwbBangoBeanList());
        AutoCompOptionBean saiHaifusakiEigyosho = new AutoCompOptionBean();
        saiHaifusakiEigyosho.setValue("132");
        saiHaifusakiEigyosho.setLabel("再配布先営業所");
        selectedBean.setSaiHaifusakiEigyosho(saiHaifusakiEigyosho);
        selectedBean.setHaifusakiEigyoshoCd("132");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoListUpdate();

       // 想定通り
       assertEquals("ERROR", paramsCaptor_1.getValue());
       assertEquals("MWBE0006", paramsCaptor_2.getValue());

    }
    
    // haifuMawbBangoListUpdate_異常_番号指定時MAWB配布登録_27_3
    //
    // -------------------テスト条件--------------------------
    // 再配布MAWB番号From = "77777766" 再配布MAWB番号To = "77777814"
    //  配布日付 = "2019/01/02" 再配布先営業所 = "132" 再配布先営業所名称 = "再配布先営業所" 
    //  再配布先営業所コード = "133"
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoListUpdate_異常_番号指定時MAWB配布登録_27_3() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_3 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_1.capture(),paramsCaptor_2.capture(), paramsCaptor_3.capture());
       
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setHaifuMawbBangoFrom("77777766");
        selectedBean.setHaifuMawbBangoTo("77777814");
        selectedBean.setSaiHaifuHizuke("2019/01/02");
        selectedBean.setSelectedMawbBangoList( new ArrayList());
        AutoCompOptionBean saiHaifusakiEigyosho = new AutoCompOptionBean();
        saiHaifusakiEigyosho.setValue("132");
        saiHaifusakiEigyosho.setLabel("再配布先営業所");
        selectedBean.setSaiHaifusakiEigyosho(saiHaifusakiEigyosho);
        selectedBean.setHaifusakiEigyoshoCd("133");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoListUpdate();

       // 想定通り
       assertEquals("ERROR", paramsCaptor_1.getValue());
       assertEquals("COME0007", paramsCaptor_2.getValue());
       assertEquals("MAWB番号", paramsCaptor_3.getValue());

    }
    
    // haifuMawbBangoListUpdate_異常_番号指定時MAWB配布登録_27_4
    //
    // -------------------テスト条件--------------------------
    //  配布日付 = null
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoListUpdate_異常_番号指定時MAWB配布登録_27_4() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_3 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_1.capture(),paramsCaptor_2.capture(), paramsCaptor_3.capture());
       
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSelectedMawbBangoList(createMwbBangoBeanList());
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoListUpdate();

       // 想定通り
       assertEquals("ERROR", paramsCaptor_1.getValue());
       assertEquals("COME0003", paramsCaptor_2.getValue());
       assertEquals("再配布日付", paramsCaptor_3.getValue());

    }
    
     // haifuMawbBangoListUpdate_異常_番号指定時MAWB配布登録_27_4_1
    //
    // -------------------テスト条件--------------------------
    // 再配布MAWB番号From = "77777766" 再配布MAWB番号To = "77777814"
    //  配布日付 = "2019/01/02" 再配布先営業所 = null
    //  再配布先営業所コード = "133"
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoListUpdate_異常_番号指定時MAWB配布登録_27_4_1() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_3 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_1.capture(),paramsCaptor_2.capture(), paramsCaptor_3.capture());
       
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setHaifuMawbBangoFrom("77777766");
        selectedBean.setHaifuMawbBangoTo("77777814");
        selectedBean.setSaiHaifuHizuke("2019/01/02");
        selectedBean.setSelectedMawbBangoList(createMwbBangoBeanList());
        selectedBean.setHaifusakiEigyoshoCd("133");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoListUpdate();

       // 想定通り
       assertEquals("ERROR", paramsCaptor_1.getValue());
       assertEquals("COME0003", paramsCaptor_2.getValue());
       assertEquals("再配布先営業所コード", paramsCaptor_3.getValue());

    }
    
    // haifuMawbBangoListUpdate_異常_番号指定時MAWB配布登録_27_4_2
    //
    // -------------------テスト条件--------------------------
    //  再配布MAWB番号From = "77777766" 再配布MAWB番号To = "77777814"
    //  配布日付 = "2019/01/02" 再配布先営業所 = "132" 再配布先営業所名称 = null
    //  再配布先営業所コード = "133"
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoListUpdate_異常_番号指定時MAWB配布登録_27_4_2() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_3 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_1.capture(),paramsCaptor_2.capture(), paramsCaptor_3.capture());
       
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setHaifuMawbBangoFrom("77777766");
        selectedBean.setHaifuMawbBangoTo("77777814");
        selectedBean.setSaiHaifuHizuke("2019/01/02");
        selectedBean.setSelectedMawbBangoList(createMwbBangoBeanList());
        AutoCompOptionBean saiHaifusakiEigyosho = new AutoCompOptionBean();
        saiHaifusakiEigyosho.setValue("132");
        selectedBean.setSaiHaifusakiEigyosho(saiHaifusakiEigyosho);
        selectedBean.setHaifusakiEigyoshoCd("133");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoListUpdate();

       // 想定通り
       assertEquals("ERROR", paramsCaptor_1.getValue());
       assertEquals("COME0003", paramsCaptor_2.getValue());
       assertEquals("再配布先営業所名", paramsCaptor_3.getValue());

    }
    
    // haifuMawbBangoListUpdate_異常_番号指定時MAWB配布登録_27_4_3
    //
    // -------------------テスト条件--------------------------
    // 再配布MAWB番号From = "77777766" 再配布MAWB番号To = "77777814"
    //  配布日付 = "2019/01/02" 再配布先営業所 = "132" 再配布先営業所名称 = "再配布先営業所"
    //  再配布先営業所コード = "133"
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoListUpdate_異常_番号指定時MAWB配布登録_27_4_3() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_3 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_1.capture(),paramsCaptor_2.capture(), paramsCaptor_3.capture());
       
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setHaifuMawbBangoFrom("77777766");
        selectedBean.setHaifuMawbBangoTo("77777814");
        selectedBean.setSaiHaifuHizuke("2019/01/02");
        selectedBean.setSelectedMawbBangoList(createMwbBangoBeanListNoPass());
        AutoCompOptionBean saiHaifusakiEigyosho = new AutoCompOptionBean();
        saiHaifusakiEigyosho.setValue("132");
        saiHaifusakiEigyosho.setLabel("再配布先営業所");
        selectedBean.setSaiHaifusakiEigyosho(saiHaifusakiEigyosho);
        selectedBean.setHaifusakiEigyoshoCd("133");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoListUpdate();

       // 想定通り
       assertEquals("ERROR", paramsCaptor_1.getValue());
       assertEquals("COME0007", paramsCaptor_2.getValue());
       assertEquals("再配布MAWB番号リスト", paramsCaptor_3.getValue());

    }
        
    // haifuMawbBangoListUpdate_異常_番号指定時MAWB配布登録_27_5
    //
    // -------------------テスト条件--------------------------
    // 再配布MAWB番号From = "77777766" 再配布MAWB番号To = "77777814"
    //  配布日付 = "2019/01/02" 再配布先営業所 = "132" 再配布先営業所名称 = "再配布先営業所"
    //  再配布先営業所コード = "133"
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoListUpdate_異常_番号指定時MAWB配布登録_27_5() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_3 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_1.capture(),paramsCaptor_2.capture(), paramsCaptor_3.capture());
       
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setHaifuMawbBangoFrom("77777766");
        selectedBean.setHaifuMawbBangoTo("77777814");
        selectedBean.setSaiHaifuHizuke("2019/01/02");
        selectedBean.setSelectedMawbBangoList(createMwbBangoBeanListNoRange());
        AutoCompOptionBean saiHaifusakiEigyosho = new AutoCompOptionBean();
        saiHaifusakiEigyosho.setValue("132");
        saiHaifusakiEigyosho.setLabel("再配布先営業所");
        selectedBean.setSaiHaifusakiEigyosho(saiHaifusakiEigyosho);
        selectedBean.setHaifusakiEigyoshoCd("133");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoListUpdate();

       // 想定通り
       assertEquals("ERROR", paramsCaptor_1.getValue());
       assertEquals("MWBE0005", paramsCaptor_2.getValue());
       assertEquals("更新", paramsCaptor_3.getValue());

    }
            
    // haifuMawbBangoListUpdate_異常_番号指定時MAWB配布登録_27_6
    //
    // -------------------テスト条件--------------------------
    // 検索件数取得 取得件数 = 1
    // 再配布MAWB番号From = "77777766" 再配布MAWB番号To = "77777814"
    //  配布日付 = "2019/01/02" 再配布先営業所 = "132" 再配布先営業所名称 = "再配布先営業所"
    //  再配布先営業所コード = "133"
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoListUpdate_異常_番号指定時MAWB配布登録_27_6() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_4 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 1
        List<Map<String, Object>> resultList= new ArrayList();
         for(int i = 0; i<=0; i++) {
            resultList.add(createMwbBangoBeanMapForUpdateOrDelete());
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
        when(pageCommonBean.getDBInfo(paramsCaptor_4.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_1.capture(),paramsCaptor_2.capture());
       
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setHaifuMawbBangoFrom("77777766");
        selectedBean.setHaifuMawbBangoTo("77777814");
        selectedBean.setSaiHaifuHizuke("2019/01/02");
        selectedBean.setSelectedMawbBangoList(createMwbBangoBeanList());
        AutoCompOptionBean saiHaifusakiEigyosho = new AutoCompOptionBean();
        saiHaifusakiEigyosho.setValue("132");
        saiHaifusakiEigyosho.setLabel("再配布先営業所");
        selectedBean.setSaiHaifusakiEigyosho(saiHaifusakiEigyosho);
        selectedBean.setHaifusakiEigyoshoCd("133");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoListUpdate();

       // 想定通り
       assertEquals("ERROR", paramsCaptor_1.getValue());
       assertEquals("MWBE0003", paramsCaptor_2.getValue());

    }
                
    // haifuMawbBangoListUpdate_異常_番号指定時MAWB配布登録_27_7
    //
    // -------------------テスト条件--------------------------
    // 検索件数取得 取得件数 = 0
    // 再配布MAWB番号From = "77777766" 再配布MAWB番号To = "77777814"
    //  配布日付 = "2019/01/02" 再配布先営業所 = "132" 再配布先営業所名称 = "再配布先営業所"
    //  再配布先営業所コード = "133"
    // 検索エラーの場合
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoListUpdate_異常_番号指定時MAWB配布登録_27_7() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_4 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 0
        List<Map<String, Object>> resultList= new ArrayList();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        serviceInterfaceBean2.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR );
        when(pageCommonBean.getDBInfo(paramsCaptor_4.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean, serviceInterfaceBean2);
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setHaifuMawbBangoFrom("77777766");
        selectedBean.setHaifuMawbBangoTo("77777814");
        selectedBean.setSaiHaifuHizuke("2019/01/02");
        selectedBean.setSelectedMawbBangoList(createMwbBangoBeanList());
        AutoCompOptionBean saiHaifusakiEigyosho = new AutoCompOptionBean();
        saiHaifusakiEigyosho.setValue("132");
        saiHaifusakiEigyosho.setLabel("再配布先営業所");
        selectedBean.setSaiHaifusakiEigyosho(saiHaifusakiEigyosho);
        selectedBean.setHaifusakiEigyoshoCd("133");
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoListUpdate();

       // 想定通り
       assertEquals("mwb011-haifu-update", functionCodeCaptor_2.getValue());

    }
    
    // haifuMawbBangoDelete_正常_削除ボタンMAWB配布登録_28_1
    //
    // -------------------テスト条件--------------------------
    // 検索件数取得 取得件数 = 0
    // MAWB番号From = "77777766" MAWB番号To = "777777803"
    // 再配布MAWB番号From = "77777781" 再配布MAWB番号To = "77777792"
    //  配布日付 = "2019/01/02" 再配布先営業所 = "132" 再配布先営業所名称 = "再配布先営業所"
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoDelete_正常_削除ボタンMAWB配布登録_28_1() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 0
        List<Map<String, Object>> resultList= new ArrayList();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 0
        List<Map<String, Object>> resultList2= new ArrayList();
        for(int i = 0; i<=0; i++) {
            resultList2.add(createMwbBangoBeanMapForUpdateOrDelete());
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultList2));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean, serviceInterfaceBean2);
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);     
        doNothing().when(pageCommonBean).executeScript(keyCaptor_2.capture());
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setMaxRows("10");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuMawbBangoFrom("77777781");
        selectedBean.setSaiHaifuMawbBangoTo("77777792");
        selectedBean.setHaifuMawbBangoFrom("77777766");
        selectedBean.setHaifuMawbBangoTo("777777803");
        selectedBean.setSaiHaifuHizuke("2019/01/02");
        selectedBean.setSaiHaifuType(0);
        selectedBean.setSelectedMawbBangoList(createMwbBangoBeanList());
        AutoCompOptionBean saiHaifusakiEigyosho = new AutoCompOptionBean();
        saiHaifusakiEigyosho.setValue("132");
        saiHaifusakiEigyosho.setLabel("再配布先営業所");
        selectedBean.setSaiHaifusakiEigyosho(saiHaifusakiEigyosho);
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoDelete();

        // 想定通り
       assertEquals("mwb011-get-mawbbango-data", functionCodeCaptor_2.getValue());

    }
        
    // haifuMawbBangoDelete_異常_削除ボタンMAWB配布登録_28_2
    //
    // -------------------テスト条件--------------------------
    // 検索件数取得 取得件数 = 0
    // MAWB番号From = "77777766" MAWB番号To = "777777803"
    // 再配布MAWB番号From = "77777781" 再配布MAWB番号To = "77777792"
    //  配布日付 = "2019/01/02" 再配布先営業所 = "132" 再配布先営業所名称 = "再配布先営業所"
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoDelete_異常_削除ボタンMAWB配布登録_28_2() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 0
        List<Map<String, Object>> resultList= new ArrayList();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 0
        List<Map<String, Object>> resultList2= new ArrayList();
        for(int i = 0; i<=0; i++) {
            resultList2.add(createMwbBangoBeanMapForUpdateOrDelete());
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultList2));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean, serviceInterfaceBean2);
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);     
        doNothing().when(pageCommonBean).executeScript(keyCaptor_2.capture());
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setMaxRows("10");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_6 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_4.capture(),paramsCaptor_5.capture(), paramsCaptor_6.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuMawbBangoFrom("77777781");
        selectedBean.setSaiHaifuMawbBangoTo("77777792");
        selectedBean.setHaifuMawbBangoFrom("77777766");
        selectedBean.setHaifuMawbBangoTo("777777803");
        selectedBean.setSaiHaifuHizuke("2019/01/02");
        selectedBean.setSaiHaifuType(1);
        AutoCompOptionBean saiHaifusakiEigyosho = new AutoCompOptionBean();
        saiHaifusakiEigyosho.setValue("132");
        saiHaifusakiEigyosho.setLabel("再配布先営業所");
        selectedBean.setSaiHaifusakiEigyosho(saiHaifusakiEigyosho);
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoDelete();

        // 想定通り
       assertEquals("ERROR", paramsCaptor_4.getValue());
       assertEquals("COME0007", paramsCaptor_5.getValue());
       assertEquals("MAWB番号", paramsCaptor_6.getValue());

    }
            
    // haifuMawbBangoDelete_異常_削除ボタンMAWB配布登録_28_3
    //
    // -------------------テスト条件--------------------------
    // 再配布MAWB番号From = null 
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoDelete_異常_削除ボタンMAWB配布登録_28_3() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_6 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_4.capture(),paramsCaptor_5.capture(), paramsCaptor_6.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuType(0);
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoDelete();

        // 想定通り
       assertEquals("ERROR", paramsCaptor_4.getValue());
       assertEquals("COME0003", paramsCaptor_5.getValue());
       assertEquals("再配布MAWB番号From", paramsCaptor_6.getValue());

    }
            
    // haifuMawbBangoDelete_異常_削除ボタンMAWB配布登録_28_3_1
    //
    // -------------------テスト条件--------------------------
    // 再配布MAWB番号To = null
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoDelete_異常_削除ボタンMAWB配布登録_28_3_1() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_6 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_4.capture(),paramsCaptor_5.capture(), paramsCaptor_6.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuMawbBangoFrom("77777781");
        selectedBean.setSaiHaifuType(0);
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoDelete();

        // 想定通り
       assertEquals("ERROR", paramsCaptor_4.getValue());
       assertEquals("COME0003", paramsCaptor_5.getValue());
       assertEquals("再配布MAWB番号To", paramsCaptor_6.getValue());

    }
            
    // haifuMawbBangoDelete_異常_削除ボタンMAWB配布登録_28_3_2
    //
    // -------------------テスト条件--------------------------
    // 再配布MAWB番号From = "77777781" 再配布MAWB番号To = "77777770"
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoDelete_異常_削除ボタンMAWB配布登録_28_3_2() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_6 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_4.capture(),paramsCaptor_5.capture(), paramsCaptor_6.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuMawbBangoFrom("77777781");
        selectedBean.setSaiHaifuMawbBangoTo("77777770");
        selectedBean.setSaiHaifuType(0);
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoDelete();

        // 想定通り
       assertEquals("ERROR", paramsCaptor_4.getValue());
       assertEquals("MWBE0001", paramsCaptor_5.getValue());
       assertEquals("再配布MAWB番号", paramsCaptor_6.getValue());

    }
    
    // haifuMawbBangoDelete_異常_削除ボタンMAWB配布登録_28_4
    //
    // -------------------テスト条件--------------------------
    // MAWB番号From = "77777770" MAWB番号To = "777777781"
    // 再配布MAWB番号From = "77777766" 再配布MAWB番号To = "77777792"
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoDelete_異常_削除ボタンMAWB配布登録_28_4() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_3 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_1.capture(), paramsCaptor_2.capture(), 
                paramsCaptor_3.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuMawbBangoFrom("77777766");
        selectedBean.setSaiHaifuMawbBangoTo("77777792");
        selectedBean.setHaifuMawbBangoFrom("77777770");
        selectedBean.setHaifuMawbBangoTo("77777781");
        selectedBean.setSaiHaifuType(0);
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoDelete();

        // 想定通り
       assertEquals("ERROR", paramsCaptor_1.getValue());
       assertEquals("MWBE0012", paramsCaptor_2.getValue());
       assertEquals("削除", paramsCaptor_3.getValue());

    }
    
    // haifuMawbBangoDelete_異常_削除ボタンMAWB配布登録_28_5
    //
    // -------------------テスト条件--------------------------
    // 検索件数取得 取得件数 = 0
    // MAWB番号From = "77777766" MAWB番号To = "777777792"
    // 再配布MAWB番号From = "77777770" 再配布MAWB番号To = "77777781"
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoDelete_異常_削除ボタンMAWB配布登録_28_5() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 0
        List<Map<String, Object>> resultList= new ArrayList();
        for(int i = 0; i<=0; i++) {
            resultList.add(createMwbBangoBeanMapForUpdateOrDelete());
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_4 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_3.capture(), paramsCaptor_4.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuMawbBangoFrom("77777770");
        selectedBean.setSaiHaifuMawbBangoTo("77777781");
        selectedBean.setHaifuMawbBangoFrom("77777766");
        selectedBean.setHaifuMawbBangoTo("77777792");
        selectedBean.setSaiHaifuType(0);
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoDelete();

        // 想定通り
       assertEquals("ERROR", paramsCaptor_3.getValue());
       assertEquals("MWBE0003", paramsCaptor_4.getValue());

    }
        
    // haifuMawbBangoDelete_異常_削除ボタンMAWB配布登録_28_6
    //
    // -------------------テスト条件--------------------------
    // 検索件数取得 取得件数 = 0
    // MAWB番号From = "77777766" MAWB番号To = "777777792"
    // 再配布MAWB番号From = "77777770" 再配布MAWB番号To = "77777781"
    // 再配布形式 = 1
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoDelete_異常_削除ボタンMAWB配布登録_28_6() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 0
        List<Map<String, Object>> resultList= new ArrayList();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_5 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_3.capture(), paramsCaptor_4.capture(), paramsCaptor_5.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuMawbBangoFrom("77777770");
        selectedBean.setSaiHaifuMawbBangoTo("77777781");
        selectedBean.setHaifuMawbBangoFrom("77777766");
        selectedBean.setHaifuMawbBangoTo("77777792");
        selectedBean.setSelectedMawbBangoList(createMwbBangoBeanListNoRange());
        selectedBean.setSaiHaifuType(1);
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoDelete();

        // 想定通り
       assertEquals("ERROR", paramsCaptor_3.getValue());
       assertEquals("MWBE0012", paramsCaptor_4.getValue());
       assertEquals("削除", paramsCaptor_5.getValue());

    }
    
    // haifuMawbBangoDelete_異常_削除ボタンMAWB配布登録_28_7
    //
    // -------------------テスト条件--------------------------
    // 検索件数取得 取得件数 = 1
    // MAWB番号From = "77777766" MAWB番号To = "777777792"
    // 再配布MAWB番号From = "77777770" 再配布MAWB番号To = "77777781"
    // 再配布形式 = 1
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoDelete_異常_削除ボタンMAWB配布登録_28_7() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 1
        List<Map<String, Object>> resultList= new ArrayList();
        for(int i = 0; i<=0; i++) {
            resultList.add(createMwbBangoBeanMapForUpdateOrDelete());
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_4 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_3.capture(), paramsCaptor_4.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuMawbBangoFrom("77777770");
        selectedBean.setSaiHaifuMawbBangoTo("77777781");
        selectedBean.setHaifuMawbBangoFrom("77777766");
        selectedBean.setHaifuMawbBangoTo("77777792");
        selectedBean.setSaiHaifuType(1);
        selectedBean.setSelectedMawbBangoList(createMwbBangoBeanListInRange());
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoDelete();

        // 想定通り
       assertEquals("ERROR", paramsCaptor_3.getValue());
       assertEquals("MWBE0003", paramsCaptor_4.getValue());

    }
    
    // haifuMawbBangoDelete_異常_削除ボタンMAWB配布登録_28_8
    //
    // -------------------テスト条件--------------------------
    // 検索件数取得 取得件数 = 1
    // MAWB番号From = "77777766" MAWB番号To = "777777792"
    // 再配布MAWB番号From = "77777770" 再配布MAWB番号To = "77777781"
    // 再配布形式 = 0
    // 検索エラーの場合
    // -----------------------------------------------------
    @Test
    public void haifuMawbBangoDelete_異常_削除ボタンMAWB配布登録_28_8() throws IllegalAccessException,
            InvocationTargetException, ParseException {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 0
        List<Map<String, Object>> resultList= new ArrayList();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        serviceInterfaceBean2.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean, serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_4 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_3.capture(), paramsCaptor_4.capture());
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiHaifuMawbBangoFrom("77777770");
        selectedBean.setSaiHaifuMawbBangoTo("77777781");
        selectedBean.setHaifuMawbBangoFrom("77777766");
        selectedBean.setHaifuMawbBangoTo("77777792");
        selectedBean.setSaiHaifuType(0);
        form.setSelectedBean(selectedBean);
        form.setConMishiyoMawbHyoji(new String[]{"1"});

        Map<String, Object> searchCriteria = new HashMap();
        target.setMwb011Form(form);
        target.setSearchCriteria(searchCriteria);
        target.haifuMawbBangoDelete();

        // 想定通り
       assertEquals("mwb011-haifu-delete", functionCodeCaptor_2.getValue());

    }
    
    // searchCheck_正常_補充ケース_29_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void searchCheck_正常_補充ケース_29_1 () throws IllegalAccessException, InvocationTargetException, 
            SystemException {
        
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        target.setMwb011Form(form);
        target.searchCheck();

        // 実施結果Outを取得
        form = target.getMwb011Form();

    }
        
    // searchCheck_正常_補充ケース_29_1
    //
    // -------------------テスト条件--------------------------
    // 配布日付開始 = "2019/02/01"  配布年月日終了 = "2019/01/01"
    // -----------------------------------------------------
    @Test
    public void searchCheck_異常_補充ケース_29_2 () throws IllegalAccessException, InvocationTargetException, 
            SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsCaptor_4 = ArgumentCaptor.forClass(String.class);
         ArgumentCaptor<String> paramsCaptor_5 = ArgumentCaptor.forClass(String.class);
        
         // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                paramsCaptor_3.capture(), paramsCaptor_4.capture(), paramsCaptor_5.capture());
        // テスト実行
        Mwb011Form form = new Mwb011Form();
	AutoCompOptionBean hakkenEigyosho = new AutoCompOptionBean();
	hakkenEigyosho.setValue("conHakkenEigyosho1");
	AutoCompOptionBean haifusakiEigyosho = new AutoCompOptionBean();
	haifusakiEigyosho.setValue("haifusakiEigyosho1");
        form.setConHakkenEigyosho(hakkenEigyosho);
        form.setConHaifusakiEigyosho(haifusakiEigyosho);
        AutoCompOptionBean kokuGaishaCd = new AutoCompOptionBean();
	kokuGaishaCd.setValue("0005");
	form.setConKokuGaishaCd(kokuGaishaCd);
        form.setConHaifuHizukeFrom("2019/02/01");
        form.setConHaifuHizukeTo("2019/01/01");
        target.setMwb011Form(form);
        target.searchCheck();

        // 実施結果Outを取得
        form = target.getMwb011Form();
        
        // 想定通り
       assertEquals("2019/02/01", form.getConHaifuHizukeFrom());
       assertEquals("2019/01/01", form.getConHaifuHizukeTo());
       assertEquals("ERROR", paramsCaptor_3.getValue());
       assertEquals("COME0008", paramsCaptor_4.getValue());
       assertEquals("配布日付", paramsCaptor_5.getValue());

    }
    
    // menuClick_正常_補充ケース_29_2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_29_2 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mwb011Form form = new Mwb011Form();
        target.setMwb011Form(form);
        target.menuClick("","");

        // 実施結果Outを取得
        form = target.getMwb011Form();

    }
    
    // menuClick_正常_補充ケース_29_2_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_29_2_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(1);
       
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        target.setMwb011Form(form);
        target.menuClick("","");

        // 実施結果Outを取得
        form = target.getMwb011Form();

    }

    // breadClumClick_正常_補充ケース_29_3
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_29_3 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mwb011Form form = new Mwb011Form();
        target.setMwb011Form(form);
        target.breadClumClick("",0);

        // 実施結果Outを取得
        form = target.getMwb011Form();

    }
    
    // breadClumClick_正常_補充ケース_29_3_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_29_3_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(0); 
        // テスト実行
        Mwb011Form form = new Mwb011Form();
        target.setMwb011Form(form);
        target.breadClumClick("",0);

        // 実施結果Outを取得
        form = target.getMwb011Form();

    }

    // logoutClick_正常_補充ケース_29_4
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void logoutClick_正常_補充ケース_29_4 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mwb011Form form = new Mwb011Form();
        target.setMwb011Form(form);
        target.logoutClick();

        // 実施結果Outを取得
        form = target.getMwb011Form();

    }
    
    // reversalCheck_正常_補充ケース_29_5
    //
    // -------------------テスト条件--------------------------
    // 日付開始 = "2019/02/01"  日付終了 = "2019/01/01"
    // -----------------------------------------------------
    @Test
    public void reversalCheck_正常_補充ケース_29_5() throws IllegalAccessException, InvocationTargetException, ParseException {

        // テスト実行
        boolean isFormat = true;
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        String dateFrom = "2019/02/01";
        String dateTo = "2019/01/01";
        Date date1 = dateFormat.parse(dateFrom);
        Date date12 = dateFormat.parse(dateTo);
        isFormat = target.reversalCheck(date1, date12);

        // 想定通り
        assertEquals(false, isFormat);

    }
    
    // formatMawbBango_正常_補充ケース_29_6
    //
    // -------------------テスト条件--------------------------
    // MAWB番号 = "7777777" 
    // -----------------------------------------------------
    @Test
    public void formatMawbBango_正常_補充ケース_29_6() throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        String mawbBango = null;
        mawbBango = target.formatMawbBango(7777777);

        // 想定通り
        assertEquals("07777777", mawbBango);

    }
    
    // searchChange_正常_補充ケース_18-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void searchChange_正常_補充ケース_29_7 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mwb011Form form = new Mwb011Form();
        target.setMwb011Form(form);
        target.searchChange();

        // 実施結果Outを取得
        form = target.getMwb011Form();

    }
    
    // inputCheck_正常_補充ケース_29_8
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void inputCheck_正常_補充ケース_29_8 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        form.setSelectedBean(selectedBean);
        target.setMwb011Form(form);
        target.inputCheck(7);

        // 実施結果Outを取得
        form = target.getMwb011Form();

    }
    
        // inputCheck_正常_補充ケース_29_8
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void inputCheck_正常_補充ケース_29_8_1() throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiTorokuMawbBangoFrom("77777770");
        form.setSelectedBean(selectedBean);
        target.setMwb011Form(form);
        target.inputCheck(7);

        // 実施結果Outを取得
        form = target.getMwb011Form();

    }
    
        // inputCheck_正常_補充ケース_29_8
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void inputCheck_正常_補充ケース_29_8_2 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setStrHaifuHizuke("2019/01/01");
        selectedBean.setStrUkeireHizuke("2019/01/02");
        selectedBean.setHaifuHizuke(new Date(Long.valueOf("1546272000000")));
        selectedBean.setDispMawbBango("77777803");
        selectedBean.setLevel(3);
        selectedBean.setTorokuMawbBango("77777792");
        selectedBean.setMawbHaifuId(120);
        selectedBean.setHaifusakiEigyoshoMei("配布先営業所");
        selectedBean.setSaiTorokuMawbBangoFrom("77777782");
        selectedBean.setSaiTorokuMawbBangoTo("77777770");
        form.setSelectedBean(selectedBean);
        target.setMwb011Form(form);
        target.inputCheck(7);

        // 実施結果Outを取得
        form = target.getMwb011Form();
        
        assertEquals("配布先営業所", form.getSelectedBean().getHaifusakiEigyoshoMei());
        assertEquals("77777803", form.getSelectedBean().getDispMawbBango());
        assertEquals(new Date(Long.valueOf("1546272000000")), form.getSelectedBean().getHaifuHizuke());
        assertEquals("2019/01/01", form.getSelectedBean().getStrHaifuHizuke());

    }
    
    // createInputParams_正常_補充ケース_29_9
    //
    // -------------------テスト条件--------------------------
    // 受入日付 = "2019/01/01" 登録MAWB番号From = "77777770" 登録MAWB番号To = "77777781"
    // -----------------------------------------------------
    @Test
    public void createInputParams_正常_補充ケース_29_9() throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mwb011Form form = new Mwb011Form();
        Mwb011MawbBangoBean selectedBean = new Mwb011MawbBangoBean( 1, createMwbBangoBeanMapForUpdateOrDelete());
        selectedBean.setSaiTorokuMawbBangoFrom("77777770");
        selectedBean.setSaiTorokuMawbBangoTo("77777781");
        selectedBean.setSaiUkeireHizuke("2019/01/01");
        form.setSelectedBean(selectedBean);
        Map<String, Object> criteria = new HashMap();
        target.setMwb011Form(form);
        criteria = target.createInputParams(1);

        // 想定通り
        assertEquals("HAKKEN_EIGYOSHO_CD", criteria.get("bngTrkListHHakkenEigyoshoCd"));
        assertEquals("KOKU_GAISHA_CD", criteria.get("bngTrkListKokuGaishaCd"));
        assertEquals("2019/01/01", criteria.get("bngTrkListUkeireHizuke"));
        assertEquals("77777770", criteria.get("bngTrkListTorokuMawbBangoFrom"));
        assertEquals("77777781", criteria.get("bngTrkListTorokuMawbBangoTo"));

    }
    
    
    private Map<String, Object> createMwbBangoBeanMapForUpdateOrDelete() {
        Map recMap = new HashMap();
        // 発券営業所コード
        recMap.put("HAKKEN_EIGYOSHO_CD", "HAKKEN_EIGYOSHO_CD");
        // 発券営業所名
        recMap.put("HAKKEN_EIGYOSHO_MEI", "HAKKEN_EIGYOSHO_MEI");
        // 航空会社コード
        recMap.put("KOKU_GAISHA_CD", "KOKU_GAISHA_CD");
        // 発券営業所コード
        recMap.put("MAWB_TOROKU_ID", 77777770);
        // 発券営業所名
        recMap.put("HAIFUSAKI_EIGYOSHO_CD", "HAIFUSAKI_EIGYOSHO_CD");
        // 航空会社コード
        recMap.put("HAIFUSAKI_EIGYOSHO_MEI", "HAIFUSAKI_EIGYOSHO_MEI");
        // 発券営業所コード
        recMap.put("MAWB_HAIFU_ID", 777777781);
        // 発券営業所名
        recMap.put("HAKKEN_EIGYOSHO_MEI", "HAKKEN_EIGYOSHO_MEI");
        // 航空会社コード
        recMap.put("TOROKU_MAWB_BANGO", "TOROKU_MAWB_BANGO");
        // 発券営業所コード
        recMap.put("UKEIRE_HIZUKE", new Date(Long.valueOf("1546272000000")));
        // 発券営業所名
        recMap.put("UKEIRE_MAISU", 10);
        // 航空会社コード
        recMap.put("HAIFU_HIZUKE", new Date(Long.valueOf("1546272000000")));
        // 発券営業所コード
        recMap.put("HAIFU_MAWB_BANGO", 77777770);
        // 発券営業所名
        recMap.put("HAIFU_MAISU", 10);
        // 航空会社コード
        recMap.put("SHIYO_MAISU", 10);
        // 発券営業所コード
        recMap.put("VOID_MAISU", 10);
        // 発券営業所名
        recMap.put("KAISHI_MAWB_BANGO", 77777770);
        // 航空会社コード
        recMap.put("SHURYO_MAWB_BANGO", 77777781);
        // 発券営業所コード
        recMap.put("KAISHI_MAWB_HAIFU_BANGO", 77777770);
        // 発券営業所名
        recMap.put("SHURYO_MAWB_HAIFU_BANGO", 77777781);
        return recMap;
    }
    
        
    
    private Map<String, Object> createMwbBangoBeanMapForUpdateOrDelete2() {
        Map recMap = new HashMap();
        // 発券営業所コード
        recMap.put("HAKKEN_EIGYOSHO_CD", "HAKKEN_EIGYOSHO_CD2");
        // 発券営業所名
        recMap.put("HAKKEN_EIGYOSHO_MEI", "HAKKEN_EIGYOSHO_MEI2");
        // 航空会社コード
        recMap.put("KOKU_GAISHA_CD", "KOKU_GAISHA_CD2");
        // 発券営業所コード
        recMap.put("MAWB_TOROKU_ID", 77777770);
        // 発券営業所名
        recMap.put("HAIFUSAKI_EIGYOSHO_CD", "HAIFUSAKI_EIGYOSHO_CD2");
        // 航空会社コード
        recMap.put("HAIFUSAKI_EIGYOSHO_MEI", "HAIFUSAKI_EIGYOSHO_MEI2");
        // 発券営業所コード
        recMap.put("MAWB_HAIFU_ID", 777777781);
        // 発券営業所名
        recMap.put("HAKKEN_EIGYOSHO_MEI", "HAKKEN_EIGYOSHO_MEI2");
        // 航空会社コード
        recMap.put("TOROKU_MAWB_BANGO", "TOROKU_MAWB_BANGO2");
        // 発券営業所コード
        recMap.put("UKEIRE_HIZUKE", new Date(Long.valueOf("1546272000000")));
        // 発券営業所名
        recMap.put("UKEIRE_MAISU", 10);
        // 航空会社コード
        recMap.put("HAIFU_HIZUKE", new Date(Long.valueOf("1546272000000")));
        // 発券営業所コード
        recMap.put("HAIFU_MAWB_BANGO", 77777770);
        // 発券営業所名
        recMap.put("HAIFU_MAISU", 10);
        // 航空会社コード
        recMap.put("SHIYO_MAISU", 10);
        // 発券営業所コード
        recMap.put("VOID_MAISU", 10);
        // 発券営業所名
        recMap.put("KAISHI_MAWB_BANGO", 77777770);
        // 航空会社コード
        recMap.put("SHURYO_MAWB_BANGO", 77777781);
        // 発券営業所コード
        recMap.put("KAISHI_MAWB_HAIFU_BANGO", 77777770);
        // 発券営業所名
        recMap.put("SHURYO_MAWB_HAIFU_BANGO", 77777781);
        return recMap;
    }
    
        
    
    private Map<String, Object> createMwbBangoBeanMapForUpdateOrDelete3() {
        Map recMap = new HashMap();
        // 発券営業所コード
        recMap.put("HAKKEN_EIGYOSHO_CD", "HAKKEN_EIGYOSHO_CD3");
        // 発券営業所名
        recMap.put("HAKKEN_EIGYOSHO_MEI", "HAKKEN_EIGYOSHO_MEI3");
        // 航空会社コード
        recMap.put("KOKU_GAISHA_CD", "KOKU_GAISHA_CD3");
        // 発券営業所コード
        recMap.put("MAWB_TOROKU_ID", 77777770);
        // 発券営業所名
        recMap.put("HAIFUSAKI_EIGYOSHO_CD", "HAIFUSAKI_EIGYOSHO_CD3");
        // 航空会社コード
        recMap.put("HAIFUSAKI_EIGYOSHO_MEI", "HAIFUSAKI_EIGYOSHO_MEI3");
        // 発券営業所コード
        recMap.put("MAWB_HAIFU_ID", 777777781);
        // 発券営業所名
        recMap.put("HAKKEN_EIGYOSHO_MEI", "HAKKEN_EIGYOSHO_MEI");
        // 航空会社コード
        recMap.put("TOROKU_MAWB_BANGO", "TOROKU_MAWB_BANGO");
        // 発券営業所コード
        recMap.put("UKEIRE_HIZUKE", new Date(Long.valueOf("1546272000000")));
        // 発券営業所名
        recMap.put("UKEIRE_MAISU", 10);
        // 航空会社コード
        recMap.put("HAIFU_HIZUKE", new Date(Long.valueOf("1546272000000")));
        // 発券営業所コード
        recMap.put("HAIFU_MAWB_BANGO", 77777770);
        // 発券営業所名
        recMap.put("HAIFU_MAISU", 10);
        // 航空会社コード
        recMap.put("SHIYO_MAISU", 10);
        // 発券営業所コード
        recMap.put("VOID_MAISU", 10);
        // 発券営業所名
        recMap.put("KAISHI_MAWB_BANGO", 77777770);
        // 航空会社コード
        recMap.put("SHURYO_MAWB_BANGO", 77777781);
        // 発券営業所コード
        recMap.put("KAISHI_MAWB_HAIFU_BANGO", 77777770);
        // 発券営業所名
        recMap.put("SHURYO_MAWB_HAIFU_BANGO", 77777781);
        return recMap;
    }
    
        
    
    private Map<String, Object> createMwbBangoBeanMapForUpdateOrDelete4() {
        Map recMap = new HashMap();
        // 発券営業所コード
        recMap.put("HAKKEN_EIGYOSHO_CD", "HAKKEN_EIGYOSHO_CD");
        // 発券営業所名
        recMap.put("HAKKEN_EIGYOSHO_MEI", "HAKKEN_EIGYOSHO_MEI4");
        // 航空会社コード
        recMap.put("KOKU_GAISHA_CD", "KOKU_GAISHA_CD");
        // 発券営業所コード
        recMap.put("MAWB_TOROKU_ID", 77777770);
        // 発券営業所名
        recMap.put("HAIFUSAKI_EIGYOSHO_CD", "HAIFUSAKI_EIGYOSHO_CD");
        // 航空会社コード
        recMap.put("HAIFUSAKI_EIGYOSHO_MEI", "HAIFUSAKI_EIGYOSHO_MEI4");
        // 発券営業所コード
        recMap.put("MAWB_HAIFU_ID", 777777781);
        // 発券営業所名
        recMap.put("HAKKEN_EIGYOSHO_MEI", "HAKKEN_EIGYOSHO_MEI4");
        // 航空会社コード
        recMap.put("TOROKU_MAWB_BANGO", "TOROKU_MAWB_BANGO4");
        // 発券営業所コード
        recMap.put("UKEIRE_HIZUKE", new Date(Long.valueOf("1546272000000")));
        // 発券営業所名
        recMap.put("UKEIRE_MAISU", 10);
        // 航空会社コード
        recMap.put("HAIFU_HIZUKE", new Date(Long.valueOf("1546272000000")));
        // 発券営業所コード
        recMap.put("HAIFU_MAWB_BANGO", 77777770);
        // 発券営業所名
        recMap.put("HAIFU_MAISU", 10);
        // 航空会社コード
        recMap.put("SHIYO_MAISU", 10);
        // 発券営業所コード
        recMap.put("VOID_MAISU", 10);
        // 発券営業所名
        recMap.put("KAISHI_MAWB_BANGO", 77777770);
        // 航空会社コード
        recMap.put("SHURYO_MAWB_BANGO", 77777781);
        // 発券営業所コード
        recMap.put("KAISHI_MAWB_HAIFU_BANGO", 77777770);
        // 発券営業所名
        recMap.put("SHURYO_MAWB_HAIFU_BANGO", 77777781);
        return recMap;
    }
    
        
    
    private Map<String, Object> createMwbBangoBeanMapForUpdateOrDelete5() {
        Map recMap = new HashMap();
        // 発券営業所コード
        recMap.put("HAKKEN_EIGYOSHO_CD", "HAKKEN_EIGYOSHO_CD5");
        // 発券営業所名
        recMap.put("HAKKEN_EIGYOSHO_MEI", "HAKKEN_EIGYOSHO_MEI5");
        // 航空会社コード
        recMap.put("KOKU_GAISHA_CD", "KOKU_GAISHA_CD5");
        // 発券営業所コード
        recMap.put("MAWB_TOROKU_ID", 77777770);
        // 発券営業所名
        recMap.put("HAIFUSAKI_EIGYOSHO_CD", "HAIFUSAKI_EIGYOSHO_CD5");
        // 航空会社コード
        recMap.put("HAIFUSAKI_EIGYOSHO_MEI", "HAIFUSAKI_EIGYOSHO_MEI5");
        // 発券営業所コード
        recMap.put("MAWB_HAIFU_ID", 777777781);
        // 発券営業所名
        recMap.put("HAKKEN_EIGYOSHO_MEI", "HAKKEN_EIGYOSHO_MEI5");
        // 航空会社コード
        recMap.put("TOROKU_MAWB_BANGO", "TOROKU_MAWB_BANGO5");
        // 発券営業所コード
        recMap.put("UKEIRE_HIZUKE", new Date(Long.valueOf("1546272000000")));
        // 発券営業所名
        recMap.put("UKEIRE_MAISU", 10);
        // 航空会社コード
        recMap.put("HAIFU_HIZUKE", new Date(Long.valueOf("1546272000000")));
        // 発券営業所コード
        recMap.put("HAIFU_MAWB_BANGO", 77777770);
        // 発券営業所名
        recMap.put("HAIFU_MAISU", 10);
        // 航空会社コード
        recMap.put("SHIYO_MAISU", 10);
        // 発券営業所コード
        recMap.put("VOID_MAISU", 10);
        // 発券営業所名
        recMap.put("KAISHI_MAWB_BANGO", 77777770);
        // 航空会社コード
        recMap.put("SHURYO_MAWB_BANGO", 77777781);
        // 発券営業所コード
        recMap.put("KAISHI_MAWB_HAIFU_BANGO", 77777770);
        // 発券営業所名
        recMap.put("SHURYO_MAWB_HAIFU_BANGO", 77777781);
        return recMap;
    }
    
        
    private Map<String, Object> createMwbBangoBeanMapForSearch() {
        Map recMap = new HashMap();
        // 発券営業所コード
        recMap.put("HAKKEN_EIGYOSHO_CD", "HAKKEN_EIGYOSHO_CD");
        // 発券営業所名
        recMap.put("HAKKEN_EIGYOSHO_MEI", "HAKKEN_EIGYOSHO_MEI");
        // 航空会社コード
        recMap.put("KOKU_GAISHA_CD", "KOKU_GAISHA_CD");
        // 発券営業所コード
        recMap.put("MAWB_TOROKU_ID", 77777770);
        // 発券営業所名
        recMap.put("HAIFUSAKI_EIGYOSHO_CD", "HAIFUSAKI_EIGYOSHO_CD");
        // 航空会社コード
        recMap.put("HAIFUSAKI_EIGYOSHO_MEI", "HAIFUSAKI_EIGYOSHO_MEI");
        // 発券営業所コード
        recMap.put("MAWB_HAIFU_ID", 777777781);
        // 発券営業所名
        recMap.put("HAKKEN_EIGYOSHO_MEI", "HAKKEN_EIGYOSHO_MEI");
        // 航空会社コード
        recMap.put("TOROKU_MAWB_BANGO", "TOROKU_MAWB_BANGO");
        // 発券営業所コード
        recMap.put("UKEIRE_HIZUKE", new Date(Long.valueOf("1546272000000")));
        // 発券営業所名
        recMap.put("UKEIRE_MAISU", 10);
        // 航空会社コード
        recMap.put("HAIFU_HIZUKE", new Date(Long.valueOf("1546272000000")));
        // 発券営業所コード
        recMap.put("HAIFU_MAWB_BANGO", 77777770);
        // 発券営業所名
        recMap.put("HAIFU_MAISU", 20);
        // 航空会社コード
        recMap.put("SHIYO_MAISU", 10);
        // 発券営業所コード
        recMap.put("VOID_MAISU", 10);
        // 発券営業所名
        recMap.put("KAISHI_MAWB_BANGO", 77777770);
        // 航空会社コード
        recMap.put("SHURYO_MAWB_BANGO", 77777781);
        // 発券営業所コード
        recMap.put("KAISHI_MAWB_HAIFU_BANGO", 77777770);
        // 発券営業所名
        recMap.put("SHURYO_MAWB_HAIFU_BANGO", 77777781);
        return recMap;
    }
    
            
    private Map<String, Object> createMwbBangoBeanMapForSearch2() {
        Map recMap = new HashMap();
        // 発券営業所コード
        recMap.put("HAKKEN_EIGYOSHO_CD", "HAKKEN_EIGYOSHO_CD");
        // 発券営業所名
        recMap.put("HAKKEN_EIGYOSHO_MEI", "HAKKEN_EIGYOSHO_MEI");
        // 航空会社コード
        recMap.put("KOKU_GAISHA_CD", "KOKU_GAISHA_CD");
        // 発券営業所コード
        recMap.put("MAWB_TOROKU_ID", 77777770);
        // 発券営業所名
        recMap.put("HAIFUSAKI_EIGYOSHO_CD", "HAIFUSAKI_EIGYOSHO_CD");
        // 航空会社コード
        recMap.put("HAIFUSAKI_EIGYOSHO_MEI", "HAIFUSAKI_EIGYOSHO_MEI");
        // 発券営業所コード
        recMap.put("MAWB_HAIFU_ID", 777777781);
        // 発券営業所名
        recMap.put("HAKKEN_EIGYOSHO_MEI", "HAKKEN_EIGYOSHO_MEI");
        // 航空会社コード
        recMap.put("TOROKU_MAWB_BANGO", "TOROKU_MAWB_BANGO");
        // 発券営業所コード
        recMap.put("UKEIRE_HIZUKE", new Date(Long.valueOf("1546272000000")));
        // 発券営業所名
        recMap.put("UKEIRE_MAISU", 10);
        // 航空会社コード
        recMap.put("HAIFU_HIZUKE", new Date(Long.valueOf("1546272000000")));
        // 発券営業所コード
        recMap.put("HAIFU_MAWB_BANGO", 77777770);
        // 発券営業所名
        recMap.put("HAIFU_MAISU", 0);
        // 航空会社コード
        recMap.put("SHIYO_MAISU", 0);
        // 発券営業所コード
        recMap.put("VOID_MAISU", 0);
        // 発券営業所名
        recMap.put("KAISHI_MAWB_BANGO", 77777770);
        // 航空会社コード
        recMap.put("SHURYO_MAWB_BANGO", 77777781);
        // 発券営業所コード
        recMap.put("KAISHI_MAWB_HAIFU_BANGO", 77777770);
        // 発券営業所名
        recMap.put("SHURYO_MAWB_HAIFU_BANGO", 77777781);
        return recMap;
    }
    
    private Map<String, Object> createMwbBangoBeanMapFor_19_3() {
        Map recMap = new HashMap();
        // 発券営業所コード
        recMap.put("HAKKEN_EIGYOSHO_CD", "HAKKEN_EIGYOSHO_CD");
        // 発券営業所名
        recMap.put("HAKKEN_EIGYOSHO_MEI", "HAKKEN_EIGYOSHO_MEI");
        // 航空会社コード
        recMap.put("KOKU_GAISHA_CD", "KOKU_GAISHA_CD");
        // 発券営業所コード
        recMap.put("MAWB_TOROKU_ID", 77777770);
        // 発券営業所名
        recMap.put("HAIFUSAKI_EIGYOSHO_CD", "HAIFUSAKI_EIGYOSHO_CD");
        // 航空会社コード
        recMap.put("HAIFUSAKI_EIGYOSHO_MEI", "HAIFUSAKI_EIGYOSHO_MEI");
        // 発券営業所コード
        recMap.put("MAWB_HAIFU_ID", 777777781);
        // 発券営業所名
        recMap.put("HAKKEN_EIGYOSHO_MEI", "HAKKEN_EIGYOSHO_MEI");
        // 航空会社コード
        recMap.put("TOROKU_MAWB_BANGO", "TOROKU_MAWB_BANGO");
        // 発券営業所コード
        recMap.put("UKEIRE_HIZUKE", new Date(Long.valueOf("1546272000000")));
        // 発券営業所名
        recMap.put("UKEIRE_MAISU", 10);
        // 航空会社コード
        recMap.put("HAIFU_HIZUKE", new Date(Long.valueOf("1546272000000")));
        // 発券営業所コード
        recMap.put("HAIFU_MAWB_BANGO", 77777770);
        // 発券営業所名
        recMap.put("HAIFU_MAISU", 10);
        // 航空会社コード
        recMap.put("SHIYO_MAISU", 10);
        // 発券営業所コード
        recMap.put("VOID_MAISU", 10);
        // 発券営業所名
        recMap.put("KAISHI_MAWB_BANGO", 77777766);
        // 航空会社コード
        recMap.put("SHURYO_MAWB_BANGO", 77777792);
        // 発券営業所コード
        recMap.put("KAISHI_MAWB_HAIFU_BANGO", 77777770);
        // 発券営業所名
        recMap.put("SHURYO_MAWB_HAIFU_BANGO", 77777781);
        return recMap;
    }
    
    private List<String> createMwbBangoBeanList() {
        List<String> recList = new ArrayList();
        
        recList.add("77777781");
        
        recList.add("77777792");
        
        recList.add("77777803");
      
        return recList;
    }
        
    private List<String> createMwbBangoBeanListNoPass() {
        List<String> recList = new ArrayList();
        
        recList.add("77777782");
      
        return recList;
    }
            
    private List<String> createMwbBangoBeanListNoRange() {
        List<String> recList = new ArrayList();
        
        recList.add("77777755");
      
        return recList;
    }
    
    private List<String> createMwbBangoBeanListInRange() {
        List<String> recList = new ArrayList();
        
        recList.add("77777770");
      
        return recList;
    }
    
        
    private void assertForRecList_2_2(Mwb011Form form) {
	int i = 0;
	assertEquals(1, form.getSearchResult().size());
	for (Map<String, Object> rec : form.getSearchResult()) {
	    assertEquals("conHakkenEigyosho" + i, rec.get("conHakkenEigyosho"));
	    assertEquals("conKokuGaishaCd" + i, rec.get("conKokuGaishaCd"));
	    assertEquals("conHaifuHizukeFrom" + i, rec.get("conHaifuHizukeFrom"));
	    assertEquals("conHaifuHizukeTo" + i, rec.get("conHaifuHizukeTo"));
	    assertEquals("conHaifusakiEigyosho" + i, rec.get("conHaifusakiEigyosho"));
	    assertEquals("conMawbBango" + i, rec.get("conMawbBango"));
	    i++;
	}
    }
    
    // サンプルデータを作成フォ2-2
    private Map<String, Object> createRecMapFor_2_2(int i) {
	Map<String, Object> recMap = new HashMap();
	recMap.put("listHHakkenEigyoshoCd", "listHHakkenEigyoshoCd" + i);
	recMap.put("listHKokuGaishaCd", "listHKokuGaishaCd" + i);
	return recMap;
    }
    
      private void assertForRecList_2_1(Mwb011Form form) {
	int i = 0;
	assertEquals(1, form.getSearchResult().size());
	for (Map<String, Object> rec : form.getSearchResult()) {
	    rec.put("listHHakkenEigyoshoCd", "listHHakkenEigyoshoCd" + i);
	    rec.put("listHKokuGaishaCd", "listHKokuGaishaCd" + i);
	    i++;
	}
    }
    
    
}
