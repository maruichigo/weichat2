/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.mst;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.JushoComponentBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.forms.mst.Mst172Form;
import jp.co.kintetsuls.utils.FlashUtil;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import org.junit.After;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import org.mockito.MockitoAnnotations;

/**
 * 荷受人/荷送人マスタ画面
 *
 * @author 许博 (MBP)
 * @version 2019/4/3 新規作成
 */
public class Mst172BeanTest {
    
    // テストTarget
    @InjectMocks
    private Mst172Bean target;
    
    // Mockitoオブジェクト
    @Mock
    private AutoCompleteViewBean autoCompleteViewBean;
    @Mock
    private MasterInfoBean masterInfo;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private AuthorityConfBean authConfBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private MessagePropertyBean messagePropertyBean;
    @Mock
    private FlashUtil flashUtil;
    @Mock
    private JushoComponentBean jushoComponentBean;
    @Mock
    private PageCommonBean pageCommonBean1;
    @Mock
    private AuthorityConfBean authorityConfBean;
    
    public Mst172BeanTest(){   
    }
    
    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }
    
    @After
    public void tearDown() {
    }
    
    
    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 戻るフラグ = true
    // 前画面情報[not null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst172Form preForm = new Mst172Form();
        when((Mst172Form) pageCommonBean.getPageInfo("mst172Form")).thenReturn(preForm);
        target.setMst172Form(preForm);
        // メニューをクリックする(false)
        target.init("","MST031_SCREEN",true);

        // 実施結果Outを取得
        Mst172Form mst172Form = target.getMst172Form();
        String url = target.getUrl();
        BreadCrumbBean breadBean = target.getBreadBean();
        JushoComponentBean jushoComponentBean = target.getJushoComponentBean();
        AutoCompleteViewBean autoCompleteViewBean = target.getAutoCompleteViewBean();
        AuthorityConfBean authorityConfBean  = target.getAuthorityConfBean();
        MessagePropertyBean messagePropertyBean = target.getMessagePropertyBean();
        PageCommonBean pageCommonBean = target.getPageCommonBean();
        List<MessageModuleBean> msgList = target.getMsgList();
        target.setUrl(url);
        target.setJushoComponentBean(jushoComponentBean);
        target.setBreadBean(breadBean);
        target.setAutoCompleteViewBean(autoCompleteViewBean);
        target.setAuthorityConfBean(authorityConfBean);
        target.setMessagePropertyBean(messagePropertyBean);
        target.setPageCommonBean(pageCommonBean);
        target.setMsgList(msgList);

        // 想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(preForm,mst172Form);
    }

    // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[flash not null]
    // 戻るフラグ = false
    // 荷受人参照モード
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2 () throws IllegalAccessException, InvocationTargetException {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        Map<String, Object> result = new HashMap<>();
        Map<String, Object> result2 = createRecMapFor_1_1(0);
        result.put("searchResult",result2);

        when(pageCommonBean.getPageParam()).thenReturn(flash);
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_1.capture()))
                .thenReturn(serviceInterfaceBean);
        
        // テスト実行
        Mst172Form form = new Mst172Form();
        // 前回検索パラメータ[集約区分 = 1,　営業所コード = 001]
        flash.put("mst172Form", null);
        flash.put("conNiukeNiokurininMode", "1");
        flash.put("conSanshoHenshuShinkiMode", "0");
        flash.put("dtlNiukeninHakkoCd", "123456");
        flash.put("dtlKokyakuCd", "000001");
        flash.put("kokyakuCd", "000001");
        target.setMst172Form(form);
        // 戻ってきた場合、再検索を実施する。
        target.init("","MST131_SCREEN",false);
        
        // 実施結果Outを取得
        form = target.getMst172Form();
        
        // 実行時に渡すパラメータの検証
        assertEquals("000001", paramsCaptor_1.getValue().get("conKokyakuCd"));
        assertEquals("123456", paramsCaptor_1.getValue().get("conNiukeninHakkoCd"));
        assertEquals("mst172-search", functionCodeCaptor_1.getValue());
    }
    
    // init_正常_初期処理_1-3
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[flash not null]
    // 戻るフラグ = false
    // 荷送人编辑モード
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3 () throws IllegalAccessException, InvocationTargetException {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        Map<String, Object> result = new HashMap<>();
        Map<String, Object> result2 = createRecMapFor_1_2(0);
        result.put("searchResult",result2);

        when(pageCommonBean.getPageParam()).thenReturn(flash);
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_1.capture()))
                .thenReturn(serviceInterfaceBean);
        
        // テスト実行
        Mst172Form form = new Mst172Form();
        // 前回検索パラメータ[集約区分 = 1,　営業所コード = 001]
        flash.put("mst172Form", null);
        flash.put("conNiukeNiokurininMode", "2");
        flash.put("conSanshoHenshuShinkiMode", "1");
        flash.put("dtlNiokurininHakkoCd", "130130");
        flash.put("dtlKokyakuCd", "000001");
        flash.put("kokyakuCd", "000001");
        target.setMst172Form(form);
        // 戻ってきた場合、再検索を実施する。
        target.init("","MST131_SCREEN",false);
        
        // 実施結果Outを取得
        form = target.getMst172Form();
        
        // 実行時に渡すパラメータの検証
        assertEquals("000001", paramsCaptor_1.getValue().get("conKokyakuCd"));
        assertEquals("130130", paramsCaptor_1.getValue().get("conNiokurininHakkoCd"));
        assertEquals("mst172-search", functionCodeCaptor_1.getValue());
    }
    
    // init_正常_初期処理_1-4
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[flash not null]
    // 戻るフラグ = false
    // 荷受人新規登録モード
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_4 () throws IllegalAccessException, InvocationTargetException {

        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        
        // テスト実行
        Mst172Form form = new Mst172Form();
        // 前回検索パラメータ[集約区分 = 1,　営業所コード = 001]
        flash.put("mst172Form", null);
        flash.put("conNiukeNiokurininMode", "1");
        flash.put("conSanshoHenshuShinkiMode", "2");
        flash.put("kokyakuCd", "000001");
        target.setMst172Form(form);
        // 戻ってきた場合、再検索を実施する。
        target.init("","MST131_SCREEN",false);
        
        // 実施結果Outを取得
        form = target.getMst172Form();
        
        // 実行時に渡すパラメータの検証
        assertEquals(true, form.isDtlKokyakuCdDisabled());
    }
    
    // init_正常_初期処理_1-5
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[flash not null]
    // 戻るフラグ = false
    // 荷受人複写登録モード
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_5 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        Map<String, Object> result = new HashMap<>();
        Map<String, Object> result2 = createRecMapFor_1_3(0);
        result.put("searchResult",result2);

        when(pageCommonBean.getPageParam()).thenReturn(flash);
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_1.capture()))
                .thenReturn(serviceInterfaceBean);
        
        // テスト実行
        Mst172Form form = new Mst172Form();
        // 前回検索パラメータ[集約区分 = 1,　営業所コード = 001]
        flash.put("mst172Form", null);
        flash.put("conNiukeNiokurininMode", "1");
        flash.put("conSanshoHenshuShinkiMode", "2");
        flash.put("dtlNiukeninHakkoCd", "123456");
        flash.put("dtlKokyakuCd", "000001");
        flash.put("kokyakuCd", "000001");
        target.setMst172Form(form);
        // 戻ってきた場合、再検索を実施する。
        target.init("","MST131_SCREEN",false);
        
        // 実施結果Outを取得
        form = target.getMst172Form();
        
        // 実行時に渡すパラメータの検証
        assertEquals("000001", paramsCaptor_1.getValue().get("conKokyakuCd"));
        assertEquals("123456", paramsCaptor_1.getValue().get("conNiukeninHakkoCd"));
        assertEquals("mst172-search", functionCodeCaptor_1.getValue());
    }
    
    // init_正常_初期処理_1-6
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_6 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        // 前画面情報[null]
        doThrow(IllegalAccessException.class).when(pageCommonBean).getPageInfo(keyCaptor_1.capture());

        // テスト実行
        Mst172Form form = new Mst172Form();
        target.setMst172Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        // 実施結果Outを取得
        form = target.getMst172Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst172Form",keyCaptor_1.getValue());
        // 想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null,form.getSearchResult());
    }
    
    // init_異常_初期処理_1-7
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[flash not null]
    // 戻るフラグ = false
    // 荷受人参照モード
    // -----------------------------------------------------
    @Test
    public void init_異常_初期処理_1_7 () throws IllegalAccessException, InvocationTargetException, SystemException {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsStringCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsStringCaptor_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();

        when(pageCommonBean.getPageParam()).thenReturn(flash);
        doThrow(SystemException.class).when(pageCommonBean).getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_1.capture());
        // 検索条件保存
        doNothing().when(pageCommonBean).savePageInfo(paramsStringCaptor_2.capture(), paramsStringCaptor_3.capture());        
        
        // テスト実行
        Mst172Form form = new Mst172Form();
        // 前回検索パラメータ[集約区分 = 1,　営業所コード = 001]
        flash.put("mst172Form", null);
        flash.put("conNiukeNiokurininMode", "1");
        flash.put("conSanshoHenshuShinkiMode", "0");
        flash.put("dtlNiukeninHakkoCd", "123456");
        flash.put("dtlKokyakuCd", "000001");
        flash.put("kokyakuCd", "000001");
        target.setMst172Form(form);
        target.init("","MST131_SCREEN",false);
        
        // 実施結果Outを取得
        form = target.getMst172Form();
        
        // 実行時に渡すパラメータの検証
        assertEquals("000001", paramsCaptor_1.getValue().get("conKokyakuCd"));
        assertEquals("123456", paramsCaptor_1.getValue().get("conNiukeninHakkoCd"));
        assertEquals("mst172-search", functionCodeCaptor_1.getValue());
    }
    
    // menuClick_正常_補充ケース_18-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_18_2 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst172Form form = new Mst172Form();
        target.setMst172Form(form);
        target.menuClick("","");

        // 実施結果Outを取得
        form = target.getMst172Form();
    }
    
    // menuClick_正常_補充ケース_18-2-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_18_2_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(1);
       
        // テスト実行
        Mst172Form form = new Mst172Form();
        target.setMst172Form(form);
        target.menuClick("","");

        // 実施結果Outを取得
        form = target.getMst172Form();
    }

    // breadClumClick_正常_補充ケース_18-3
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_18_3 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst172Form form = new Mst172Form();
        target.setMst172Form(form);
        target.breadClumClick("",0);

        // 実施結果Outを取得
        form = target.getMst172Form();
    }
    
    // breadClumClick_正常_補充ケース_18-3-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_18_3_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(0); 
        // テスト実行
        Mst172Form form = new Mst172Form();
        target.setMst172Form(form);
        target.breadClumClick("",0);

        // 実施結果Outを取得
        form = target.getMst172Form();
    }
    
    // logoutClick_正常_補充ケース_18-4
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void logoutClick_正常_補充ケース_18_4 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst172Form form = new Mst172Form();
        target.setMst172Form(form);
        target.logoutClick();

        // 実施結果Outを取得
        form = target.getMst172Form();
    }
    
    // getHakkoCd_正常_自動採番情報取得する_10_1
    //
    // -------------------テスト条件--------------------------
    // 荷送人モード自動採番
    // [荷送人モード, 荷送人発行コード="" ]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void getHakkoCd_正常_自動採番情報取得する_10_1 () throws IllegalAccessException, InvocationTargetException {
    
        ArgumentCaptor<Map> paramsMapCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> paramsStringCaptor_2 = ArgumentCaptor.forClass(String.class);

        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        String result = "";
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsMapCaptor_1.capture(), paramsStringCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst172Form mst172Form = new Mst172Form();
        mst172Form.setConNiukeNiokurininMode("1");
        mst172Form.setDtlNiukeninHakkoCd("");
        target.setMst172Form(mst172Form);
        target.getHakkoCd();
        // 実行時に渡すパラメータの検証
        assertEquals("1",  mst172Form.getConNiukeNiokurininMode());

        // 想定通りに正常終了
        assertEquals("mst172-saiban",paramsStringCaptor_2.getValue());
        
    }

    // getHakkoCd_異常_自動採番情報取得する_10_2
    //
    // -------------------テスト条件--------------------------
    // 荷受人モード自動採番
    // [荷受人モード, 荷受人発行コード="", ]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void getHakkoCd_異常_自動採番情報取得する_10_2 () throws IllegalAccessException, InvocationTargetException {
    
        ArgumentCaptor<Map> paramsMapCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> paramsStringCaptor_2 = ArgumentCaptor.forClass(String.class);

        doThrow(IOException.class).when(pageCommonBean).getDBInfo(paramsMapCaptor_1.capture(), paramsStringCaptor_2.capture());

        //テスト実行
        Mst172Form mst172Form = new Mst172Form();
        mst172Form.setConNiukeNiokurininMode("2");
        mst172Form.setDtlNiokurininHakkoCd("");
        target.setMst172Form(mst172Form);
        target.getHakkoCd();
        // 実行時に渡すパラメータの検証
        assertEquals("2",  mst172Form.getConNiukeNiokurininMode());

        // 想定通りに異常終了
        assertEquals("mst172-saiban",paramsStringCaptor_2.getValue());
        
    }
    
    // updatecheck_正常_荷受人荷送人マスタ更新チェック処理_15_1
    //
    // -------------------テスト条件--------------------------
    // 新住所未反映, 新JISコード != null, 旧住所フラグ=1, 使用不可フラグ=0
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void updatecheck_正常_荷受人荷送人マスタ更新チェック処理_15_1 () throws IllegalAccessException, InvocationTargetException, SystemException {
        
        Map<String, Object> searchResult = new HashMap<>();
        when(jushoComponentBean.getSearchResult()).thenReturn(searchResult);

        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);

        doNothing().when(pageCommonBean).executeScript(paramsCaptor_1.capture());

        //テスト実行
        Mst172Form mst172Form = new Mst172Form();
        
        mst172Form.setDtlShinJisCd("dtlShinJisCd1");

        mst172Form.setDtlKyuJushoFlg("1");

        mst172Form.setDtlShiyoFukaFlg("0");

        target.setMst172Form(mst172Form);

        target.updatecheck();

        // 実行時に渡すパラメータの検証
        assertEquals(searchResult, jushoComponentBean.getSearchResult());
        assertEquals("dtlShinJisCd1",  mst172Form.getDtlShinJisCd());
        assertEquals("1",  mst172Form.getDtlKyuJushoFlg());
        assertEquals("0",  mst172Form.getDtlShiyoFukaFlg());

        // 想定通りに正常終了
        assertEquals("km.showConfirmDialog('mst172DialogShisetsu')",  paramsCaptor_1.getValue());

    }

    // updatecheck_正常_荷受人荷送人マスタ更新チェック処理_15_2
    //
    // -------------------テスト条件--------------------------
    // 新住所未反映, 新JISコード != null, 旧住所フラグ=1, 使用不可フラグ=1
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void updatecheck_正常_荷受人荷送人マスタ更新チェック処理_15_2 () throws IllegalAccessException, InvocationTargetException, SystemException {
        
        Map<String, Object> searchResult = new HashMap<>();
        when(jushoComponentBean.getSearchResult()).thenReturn(searchResult);

        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);

        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        doNothing().when(messagePropertyBean).message(levelCaptor_1.capture(), summaryCaptor_2.capture());

        //テスト実行
        Mst172Form mst172Form = new Mst172Form();

        mst172Form.setDtlShinJisCd("dtlShinJisCd1");

        mst172Form.setDtlKyuJushoFlg("1");

        mst172Form.setDtlShiyoFukaFlg("1");

        target.setMst172Form(mst172Form);

        target.updatecheck();
        
        // 実行時に渡すパラメータの検証
        assertEquals(searchResult, jushoComponentBean.getSearchResult());
        assertEquals("dtlShinJisCd1",  mst172Form.getDtlShinJisCd());
        assertEquals("1",  mst172Form.getDtlKyuJushoFlg());
        assertEquals("1",  mst172Form.getDtlShiyoFukaFlg());
        // 想定通りに正常終了メッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("WARN",levelCaptor_1.getValue());
        assertEquals("COME0023",summaryCaptor_2.getValue());

    }

    // updatecheck_正常_荷受人荷送人マスタ更新チェック処理_15_3
    //
    // -------------------テスト条件--------------------------
    // 「JISコードマスタチェック」で取得した値が0でないか
    // [新住所未反映, 新JISコード = null, JISコード = 111]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void updatecheck_正常_荷受人荷送人マスタ更新チェック処理_15_3 () throws IllegalAccessException, InvocationTargetException, SystemException {

        Map<String, Object> searchResult = new HashMap<>();
        when(jushoComponentBean.getSearchResult()).thenReturn(searchResult);

        List<String> loginUserShozokuEigyosh = new ArrayList<>(Arrays.asList("123", "130"));
        when(authorityConfBean.getLoginUserShozokuEigyosho()).thenReturn(loginUserShozokuEigyosh);

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 「1 JISコードマスタチェック」で取得した値が0でない(JISコード = 11)
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0006", "111");
        serviceInterfaceBean.setTableName("JISコードマスタ");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture(), tableNameCaptor_6.capture());

        //テスト実行
        Mst172Form mst172Form = new Mst172Form();
        mst172Form.setDtlShinJisCd(null);
        AutoCompOptionBean autoCompOptionBean = new AutoCompOptionBean();
        autoCompOptionBean.setValue("111");
        mst172Form.setDtlJisCd(autoCompOptionBean);

        mst172Form.setDtlYubinBango("11-0");

        target.setMst172Form(mst172Form);

        target.updatecheck();

        // 実行時に渡すパラメータの検証
        assertEquals(searchResult, jushoComponentBean.getSearchResult());
        assertEquals(null,  mst172Form.getDtlShinJisCd());
        assertEquals("111",  mst172Form.getDtlJisCd().getValue());

        // 想定通りに正常終了メッセージ（メッセージID：COME0006）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0006", summaryCaptor_4.getValue());
        assertEquals("JISコードマスタ", detailCaptor_5.getValue());

    }

    // updatecheck_正常_荷受人荷送人マスタ更新チェック処理_15_4
    //
    // -------------------テスト条件--------------------------
    // 荷受人荷送人マスタ正常登録
    // [新住所未反映, 新JISコード = null, JISコード = 111,荷受人発行コード]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void updatecheck_正常_荷受人荷送人マスタ更新チェック処理_15_4 () throws IllegalAccessException, InvocationTargetException, SystemException {

        Map<String, Object> searchResult = new HashMap<>();
        when(jushoComponentBean.getSearchResult()).thenReturn(searchResult);

        List<String> loginUserShozokuEigyosh = new ArrayList<>(Arrays.asList("123", "130"));
        when(authorityConfBean.getLoginUserShozokuEigyosho()).thenReturn(loginUserShozokuEigyosh);

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 「1 JISコードマスタチェック」で取得した値が0でない(JISコード = 11)
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> functionCodeCaptor_6 = ArgumentCaptor.forClass(String.class);

        ArgumentCaptor<Map> paramsMapCaptor_7 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_8 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsStringCaptor_9 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsStringCaptor_10 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsStringCaptor_11 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Mst172Form> paramsStringCaptor_12 = ArgumentCaptor.forClass(Mst172Form.class);
        ArgumentCaptor<Map> paramsMapCaptor_13 = ArgumentCaptor.forClass(Map.class);

        // 登録・更新を実施
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        when(pageCommonBean.getDBInfo(paramsMapCaptor_13.capture(), functionCodeCaptor_6.capture())).thenReturn(serviceInterfaceBean2);
        // メッセージを設定する
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture());

        // 荷受人マスタ情報を検索し、取得した値を画面項目にセット         
        ServiceInterfaceBean serviceInterfaceBean3 = new ServiceInterfaceBean();

        Map<String, String> resultMap = new HashMap<>();
        resultMap.put("searchResult", "");
        serviceInterfaceBean3.setJson(JSONUtil.makeJSONString(resultMap));
        when(pageCommonBean.getDBInfo(paramsMapCaptor_7.capture(), functionCodeCaptor_8.capture())).thenReturn(serviceInterfaceBean3);


        doNothing().when(messagePropertyBean).message(paramsStringCaptor_9.capture(), paramsStringCaptor_10.capture());

        // 検索条件保存
        doNothing().when(pageCommonBean).savePageInfo(paramsStringCaptor_11.capture(), paramsStringCaptor_12.capture());

        //テスト実行
        Mst172Form mst172Form = new Mst172Form();
        mst172Form.setDtlShinJisCd(null);
        AutoCompOptionBean autoCompOptionBean = new AutoCompOptionBean();
        autoCompOptionBean.setValue("111");

        mst172Form.setDtlJisCd(autoCompOptionBean);
        mst172Form.setDtlShimukechiCd(autoCompOptionBean);
        mst172Form.setDtlHaitatsuEigyoshoCd(autoCompOptionBean);
        mst172Form.setDtlKiji1Cd(autoCompOptionBean);

        mst172Form.setDtlKiji2Cd(autoCompOptionBean);
        mst172Form.setDtlKiji3Cd(autoCompOptionBean);
        mst172Form.setDtlKiji4Cd(autoCompOptionBean);
        mst172Form.setDtlKiji5Cd(autoCompOptionBean);
        mst172Form.setConNiukeNiokurininMode("1");

        mst172Form.setDtlYubinBango("11-0");

        target.setMst172Form(mst172Form);

        Map tempMap = new HashMap();
        tempMap.put("resultNiokurininInfo", "resultNiokurininInfo1");
        tempMap.put("dtlEibunTorokuAri", "dtlEibunTorokuAri1");
        tempMap.put("searchResult", "searchResult1");
        tempMap.put("rirekiSearchKey", "rirekiSearchKey1");

        when(pageCommonBean.transBean2Map(mst172Form)).thenReturn(tempMap);

        target.updatecheck();

        // 実行時に渡すパラメータの検証
        assertEquals(searchResult, jushoComponentBean.getSearchResult());
        assertEquals(null,  mst172Form.getDtlShinJisCd());
        assertEquals("111",  mst172Form.getDtlJisCd().getValue());
        assertEquals("111",  mst172Form.getDtlShimukechiCd().getValue());
        assertEquals("111",  mst172Form.getDtlHaitatsuEigyoshoCd().getValue());
        assertEquals("111",  mst172Form.getDtlKiji1Cd().getValue());
        assertEquals("111",  mst172Form.getDtlKiji2Cd().getValue());
        assertEquals("111",  mst172Form.getDtlKiji3Cd().getValue());
        assertEquals("111",  mst172Form.getDtlKiji4Cd().getValue());
        assertEquals("111",  mst172Form.getDtlKiji5Cd().getValue());

        // 想定通りに正常終了メッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0011",summaryCaptor_4.getValue());
        assertEquals("更新",detailCaptor_5.getValue());
        assertEquals("WARN",paramsStringCaptor_9.getValue());
        assertEquals("COMW0001",paramsStringCaptor_10.getValue());

    }


    // updatecheck_正常_荷受人荷送人マスタ更新チェック処理_15_5
    //
    // -------------------テスト条件--------------------------
    // 新住所反映完了の場合, 新JISコード != null, 旧住所フラグ=1, 使用不可フラグ=0
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void updatecheck_正常_荷受人荷送人マスタ更新チェック処理_15_5 () throws IllegalAccessException, InvocationTargetException, SystemException {
        
        Map<String, Object> searchResult = new HashMap<>();
        searchResult.put("shinJisCd", "shinJisCd1");
        searchResult.put("kyuJushoFlg", "1");
        searchResult.put("shiyoFukaFlg", "0");
        
        when(jushoComponentBean.getSearchResult()).thenReturn(searchResult);

        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);

        doNothing().when(pageCommonBean).executeScript(paramsCaptor_1.capture());

        //テスト実行
        Mst172Form mst172Form = new Mst172Form();

        target.setMst172Form(mst172Form);

        target.updatecheck();

        // 実行時に渡すパラメータの検証
        assertEquals("shinJisCd1", searchResult.get("shinJisCd"));
        assertEquals("1",  searchResult.get("kyuJushoFlg"));
        assertEquals("0",  searchResult.get("shiyoFukaFlg"));

        // 想定通りに正常終了
        assertEquals("km.showConfirmDialog('mst172DialogShisetsu')",  paramsCaptor_1.getValue());

    }

    // updatecheck_正常_荷受人荷送人マスタ更新チェック処理_15_6
    //
    // -------------------テスト条件--------------------------
    // 新住所反映完了の場合, 新JISコード != null, 旧住所フラグ=1, 使用不可フラグ=1
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void updatecheck_正常_荷受人荷送人マスタ更新チェック処理_15_6 () throws IllegalAccessException, InvocationTargetException, SystemException {
        
        Map<String, Object> searchResult = new HashMap<>();
        searchResult.put("shinJisCd", "shinJisCd1");
        searchResult.put("kyuJushoFlg", "1");
        searchResult.put("shiyoFukaFlg", "1");
        
        when(jushoComponentBean.getSearchResult()).thenReturn(searchResult);

        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);

        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        doNothing().when(messagePropertyBean).message(levelCaptor_1.capture(), summaryCaptor_2.capture());

        //テスト実行
        Mst172Form mst172Form = new Mst172Form();

        target.setMst172Form(mst172Form);

        target.updatecheck();

        // 実行時に渡すパラメータの検証
        assertEquals("shinJisCd1", searchResult.get("shinJisCd"));
        assertEquals("1",  searchResult.get("kyuJushoFlg"));
        assertEquals("1",  searchResult.get("shiyoFukaFlg"));

        // 想定通りに正常終了
        assertEquals("WARN",levelCaptor_1.getValue());
        assertEquals("COME0023",summaryCaptor_2.getValue());

    }

    // updatecheck_正常_荷受人荷送人マスタ更新チェック処理_15_7
    //
    // -------------------テスト条件--------------------------
    // 荷受人荷送人マスタ正常登録
    // [新住所反映完了の場合, 新JISコード = null, JISコード = 111,荷受人発行コード]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void updatecheck_正常_荷受人荷送人マスタ更新チェック処理_15_7 () throws IllegalAccessException, InvocationTargetException, SystemException {

        Map<String, Object> searchResult = new HashMap<>();
        AutoCompOptionBean autoCompOptionBean1 = new AutoCompOptionBean();
        autoCompOptionBean1.setValue("jisCd1");
        searchResult.put("shinJisCd", null);
        searchResult.put("jisCd", autoCompOptionBean1);
        searchResult.put("jusho1", "jusho2");
        when(jushoComponentBean.getSearchResult()).thenReturn(searchResult);

        List<String> loginUserShozokuEigyosh = new ArrayList<>(Arrays.asList("123", "130"));
        when(authorityConfBean.getLoginUserShozokuEigyosho()).thenReturn(loginUserShozokuEigyosh);

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 「1 JISコードマスタチェック」で取得した値が0でない(JISコード = 11)
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> functionCodeCaptor_6 = ArgumentCaptor.forClass(String.class);

        ArgumentCaptor<Map> paramsMapCaptor_7 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_8 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsStringCaptor_9 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsStringCaptor_10 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsStringCaptor_11 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Mst172Form> paramsStringCaptor_12 = ArgumentCaptor.forClass(Mst172Form.class);
        ArgumentCaptor<Map> paramsMapCaptor_13 = ArgumentCaptor.forClass(Map.class);

        // 登録・更新を実施
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        when(pageCommonBean.getDBInfo(paramsMapCaptor_13.capture(), functionCodeCaptor_6.capture())).thenReturn(serviceInterfaceBean2);
        // メッセージを設定する
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture());

        // 荷受人マスタ情報を検索し、取得した値を画面項目にセット         
        ServiceInterfaceBean serviceInterfaceBean3 = new ServiceInterfaceBean();

        Map<String, String> resultMap = new HashMap<>();
        resultMap.put("searchResult", "");
        
        
        serviceInterfaceBean3.setJson(JSONUtil.makeJSONString(resultMap));
        when(pageCommonBean.getDBInfo(paramsMapCaptor_7.capture(), functionCodeCaptor_8.capture())).thenReturn(serviceInterfaceBean3);


        doNothing().when(messagePropertyBean).message(paramsStringCaptor_9.capture(), paramsStringCaptor_10.capture());

        // 検索条件保存
        doNothing().when(pageCommonBean).savePageInfo(paramsStringCaptor_11.capture(), paramsStringCaptor_12.capture());

        //テスト実行
        Mst172Form mst172Form = new Mst172Form();
        mst172Form.setDtlShinJisCd(null);
        AutoCompOptionBean autoCompOptionBean = new AutoCompOptionBean();
        autoCompOptionBean.setValue("111");

        mst172Form.setDtlJisCd(autoCompOptionBean);
        mst172Form.setDtlShimukechiCd(autoCompOptionBean);
        mst172Form.setDtlHaitatsuEigyoshoCd(autoCompOptionBean);
        mst172Form.setDtlKiji1Cd(autoCompOptionBean);

        mst172Form.setDtlKiji2Cd(autoCompOptionBean);
        mst172Form.setDtlKiji3Cd(autoCompOptionBean);
        mst172Form.setDtlKiji4Cd(autoCompOptionBean);
        mst172Form.setDtlKiji5Cd(autoCompOptionBean);
        mst172Form.setConNiukeNiokurininMode("2");

        mst172Form.setDtlYubinBango("11-0");

        target.setMst172Form(mst172Form);

        Map tempMap = new HashMap();
        tempMap.put("resultNiokurininInfo", "resultNiokurininInfo1");
        tempMap.put("dtlEibunTorokuAri", "dtlEibunTorokuAri1");
        tempMap.put("searchResult", "searchResult1");
        tempMap.put("rirekiSearchKey", "rirekiSearchKey1");

        when(pageCommonBean.transBean2Map(mst172Form)).thenReturn(tempMap);

        target.updatecheck();

        // 実行時に渡すパラメータの検証
        assertEquals(searchResult, jushoComponentBean.getSearchResult());
        assertEquals(null,  mst172Form.getDtlShinJisCd());
        assertEquals("jisCd1",  mst172Form.getDtlJisCd().getValue());
        assertEquals("111",  mst172Form.getDtlShimukechiCd().getValue());
        assertEquals("111",  mst172Form.getDtlHaitatsuEigyoshoCd().getValue());
        assertEquals("111",  mst172Form.getDtlKiji1Cd().getValue());
        assertEquals("111",  mst172Form.getDtlKiji2Cd().getValue());
        assertEquals("111",  mst172Form.getDtlKiji3Cd().getValue());
        assertEquals("111",  mst172Form.getDtlKiji4Cd().getValue());
        assertEquals("111",  mst172Form.getDtlKiji5Cd().getValue());

        // 想定通りに正常終了メッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0011",summaryCaptor_4.getValue());
        assertEquals("更新",detailCaptor_5.getValue());
        assertEquals("WARN",paramsStringCaptor_9.getValue());
        assertEquals("COMW0001",paramsStringCaptor_10.getValue());

    }

    // updatecheck_異常_荷受人荷送人マスタ更新チェック処理_15_8
    //
    // -------------------テスト条件--------------------------
    // 荷受人荷送人マスタ正常登録
    // [新住所反映完了の場合, 新JISコード = null, JISコード = 111,荷受人発行コード]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void updatecheck_異常_荷受人荷送人マスタ更新チェック処理_15_8 () throws IllegalAccessException, InvocationTargetException, SystemException {

        Map<String, Object> searchResult = new HashMap<>();

        AutoCompOptionBean autoCompOptionBean1 = new AutoCompOptionBean();
        autoCompOptionBean1.setValue("jisCd1");
        searchResult.put("shinJisCd", null);
        searchResult.put("jisCd", autoCompOptionBean1);
        searchResult.put("jusho1", "jusho2");
        when(jushoComponentBean.getSearchResult()).thenReturn(searchResult);

        List<String> loginUserShozokuEigyosh = new ArrayList<>(Arrays.asList("123", "130"));
        when(authorityConfBean.getLoginUserShozokuEigyosho()).thenReturn(loginUserShozokuEigyosh);

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 「1 JISコードマスタチェック」で取得した値が0でない(JISコード = 11)
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> functionCodeCaptor_6 = ArgumentCaptor.forClass(String.class);

        ArgumentCaptor<Map> paramsMapCaptor_7 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_8 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsStringCaptor_11 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramsStringCaptor_12 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> paramsMapCaptor_13 = ArgumentCaptor.forClass(Map.class);

        // 登録・更新を実施
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        when(pageCommonBean.getDBInfo(paramsMapCaptor_13.capture(), functionCodeCaptor_6.capture())).thenReturn(serviceInterfaceBean2);
        // メッセージを設定する
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture());

        doThrow(IOException.class).when(pageCommonBean1).getDBInfo(paramsMapCaptor_7.capture(), functionCodeCaptor_8.capture());

        // 検索条件保存
        doNothing().when(pageCommonBean).savePageInfo(paramsStringCaptor_11.capture(), paramsStringCaptor_12.capture());

        //テスト実行
        Mst172Form mst172Form = new Mst172Form();
        mst172Form.setDtlShinJisCd(null);
        AutoCompOptionBean autoCompOptionBean = new AutoCompOptionBean();
        autoCompOptionBean.setValue("111");

        mst172Form.setDtlJisCd(autoCompOptionBean);
        mst172Form.setDtlShimukechiCd(autoCompOptionBean);
        mst172Form.setDtlHaitatsuEigyoshoCd(autoCompOptionBean);
        mst172Form.setDtlKiji1Cd(autoCompOptionBean);

        mst172Form.setDtlKiji2Cd(autoCompOptionBean);
        mst172Form.setDtlKiji3Cd(autoCompOptionBean);
        mst172Form.setDtlKiji4Cd(autoCompOptionBean);
        mst172Form.setDtlKiji5Cd(autoCompOptionBean);
        mst172Form.setConNiukeNiokurininMode("2");

        mst172Form.setDtlYubinBango("11-0");

        target.setMst172Form(mst172Form);

        Map tempMap = new HashMap();
        tempMap.put("resultNiokurininInfo", "resultNiokurininInfo1");
        tempMap.put("dtlEibunTorokuAri", "dtlEibunTorokuAri1");
        tempMap.put("searchResult", "searchResult1");
        tempMap.put("rirekiSearchKey", "rirekiSearchKey1");

        when(pageCommonBean.transBean2Map(mst172Form)).thenReturn(tempMap);

        target.updatecheck();

        // 実行時に渡すパラメータの検証
        assertEquals(searchResult, jushoComponentBean.getSearchResult());
        assertEquals(null,  mst172Form.getDtlShinJisCd());
        assertEquals("jisCd1",  mst172Form.getDtlJisCd().getValue());
        assertEquals("111",  mst172Form.getDtlShimukechiCd().getValue());
        assertEquals("111",  mst172Form.getDtlHaitatsuEigyoshoCd().getValue());
        assertEquals("111",  mst172Form.getDtlKiji1Cd().getValue());
        assertEquals("111",  mst172Form.getDtlKiji2Cd().getValue());
        assertEquals("111",  mst172Form.getDtlKiji3Cd().getValue());
        assertEquals("111",  mst172Form.getDtlKiji4Cd().getValue());
        assertEquals("111",  mst172Form.getDtlKiji5Cd().getValue());

        // 想定通りに正常終了メッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0011",summaryCaptor_4.getValue());
        assertEquals("更新",detailCaptor_5.getValue());

    }
    
    private Map<String, Object> createRecMapFor_1_1(int i) {
        Map recMap = new HashMap();
        recMap.put("dtlKokyakuCd", "dtlKokyakuCd" + i);
        recMap.put("dtlKokyakuMei", "dtlKokyakuMei" + i);
        recMap.put("dtlEigyoshoCd", "dtlEigyoshoCd" + i);
        recMap.put("dtlEigyoshoMei", "dtlEigyoshoMei" + i);
        recMap.put("dtlNiukeninHakkoCd", "dtlNiukeninHakkoCd" + i);
        recMap.put("dtlNiukeninMei1", "dtlNiukeninMei1" + i);
        recMap.put("dtlNiukeninMei2", "dtlNiukeninMei2" + i);
        recMap.put("dtlNiukeninMei3", "dtlNiukeninMei3" + i);
        recMap.put("dtlNiukeninMei4", "dtlNiukeninMei4" + i);
        recMap.put("dtlNiukeninRyaku", "dtlNiukeninRyaku" + i);
        recMap.put("dtlNiukeninKana", "dtlNiukeninKana" + i);
        recMap.put("dtlNiukeninEiMei1", "dtlNiukeninEiMei1" + i);
        recMap.put("dtlNiukeninEiMei2", "dtlNiukeninEiMei2" + i);
        recMap.put("dtlNiukeninEiMei3", "dtlNiukeninEiMei3" + i);
        recMap.put("dtlNiukeninEiMei4", "dtlNiukeninEiMei4" + i);
        recMap.put("dtlNiukeninEiRyaku", "dtlNiukeninEiRyaku" + i);
        recMap.put("dtlKyuJusho", "dtlKyuJusho" + i);
        recMap.put("dtlShiyoFuka", "dtlShiyoFuka" + i);
        recMap.put("dtlShinJushoHanei", "dtlShinJushoHanei" + i);
        recMap.put("dtlShinJisCd", "dtlShinJisCd" + i);
        recMap.put("dtlYubinBango", "dtlYubinBango" + i);
        recMap.put("dtlJisCd", "dtlJisCd" + i);
        recMap.put("dtlNiukeninJusho1", "dtlNiukeninJusho1" + i);
        recMap.put("dtlNiukeninJusho2", "dtlNiukeninJusho2" + i);
        recMap.put("dtlNiukeninJusho3", "dtlNiukeninJusho3" + i);
        recMap.put("dtlNiukeninJusho4", "dtlNiukeninJusho4" + i);
        recMap.put("dtlNiukeninTel", "dtlNiukeninTel" + i);
        recMap.put("dtlShimukechiCd", "dtlShimukechiCd" + i);
        recMap.put("dtlShimukechiMei", "dtlShimukechiMei" + i);
        recMap.put("dtlHaitatsuEigyoshoCd", "dtlHaitatsuEigyoshoCd" + i);
        recMap.put("dtlHaitatsuEigyoshoMei", "dtlHaitatsuEigyoshoMei" + i);
        recMap.put("dtlNiukeninEiJusho1", "dtlNiukeninEiJusho1" + i);
        recMap.put("dtlNiukeninEiJusho2", "dtlNiukeninEiJusho2" + i);
        recMap.put("dtlNiukeninEiJusho3", "dtlNiukeninEiJusho3" + i);
        recMap.put("dtlNiukeninEiJusho4", "dtlNiukeninEiJusho4" + i);
        recMap.put("dtlKensakuKey", "dtlKensakuKey" + i);
        recMap.put("dtlKiji1Cd", "dtlKiji1Cd" + i);
        recMap.put("dtlKiji1Naiyo", "dtlKiji1Naiyo" + i);
        recMap.put("dtlKiji2Cd", "dtlKiji2Cd" + i);
        recMap.put("dtlKiji2Naiyo", "dtlKiji2Naiyo" + i);
        recMap.put("dtlKiji3Cd", "dtlKiji3Cd" + i);
        recMap.put("dtlKiji3Naiyo", "dtlKiji3Naiyo" + i);
        recMap.put("dtlKiji4Cd", "dtlKiji4Cd" + i);
        recMap.put("dtlKiji4Naiyo", "dtlKiji4Naiyo" + i);
        recMap.put("dtlKiji5Cd", "dtlKiji5Cd" + i);
        recMap.put("dtlKiji5Naiyo", "dtlKiji5Naiyo" + i);
        recMap.put("dtlMemo", "dtlMemo" + i);
        recMap.put("dtlTekiyoKaishibi", "2019-01-01");
        recMap.put("dtlSaishuShiyobi", "2099-01-01");
        recMap.put("niukeninDataVersion", "niukeninDataVersion" + i);
        recMap.put("niukeninKoshinCounter", 0);
        recMap.put("dtlOkurijoNiukenin", "dtlOkurijoNiukenin" + i);
        recMap.put("dtlOkurijoNiokurinin", "dtlOkurijoNiokurinin" + i);
        recMap.put("niukeninKoshinUser", "niukeninKoshinUser" + i);
        recMap.put("dtlOkurijoNiukenin", "dtlOkurijoNiukenin" + i);
        recMap.put("dtlOkurijoNiukenin", "dtlOkurijoNiukenin" + i);
        recMap.put("dtlOkurijoNiukenin", "dtlOkurijoNiukenin" + i);
        recMap.put("dtlOkurijoNiukenin", "dtlOkurijoNiukenin" + i);
        return recMap;
    }
    
    
    private Map<String, Object> createRecMapFor_1_2(int i) {
        Map recMap = new HashMap();
        recMap.put("dtlKokyakuCd", "dtlKokyakuCd" + i);
        recMap.put("dtlKokyakuMei", "dtlKokyakuMei" + i);
        recMap.put("dtlEigyoshoCd", "dtlEigyoshoCd" + i);
        recMap.put("dtlEigyoshoMei", "dtlEigyoshoMei" + i);
        recMap.put("dtlNiokurininHakkoCd", "dtlNiokurininHakkoCd" + i);
        recMap.put("dtlNiokurininMei1", "dtlNiokurininMei1" + i);
        recMap.put("dtlNiokurininMei2", "dtlNiokurininMei2" + i);
        recMap.put("dtlNiokurininMei3", "dtlNiokurininMei3" + i);
        recMap.put("dtlNiokurininMei4", "dtlNiokurininMei4" + i);
        recMap.put("dtlNiokurininRyaku", "dtlNiokurininRyaku" + i);
        recMap.put("dtlNiokurininKana", "dtlNiokurininKana" + i);
        recMap.put("dtlNiokurininEiMei1", "dtlNiokurininEiMei1" + i);
        recMap.put("dtlNiokurininEiMei2", "dtlNiokurininEiMei2" + i);
        recMap.put("dtlNiokurininEiMei3", "dtlNiokurininEiMei3" + i);
        recMap.put("dtlNiokurininEiMei4", "dtlNiokurininEiMei4" + i);
        recMap.put("dtlNiokurininEiRyaku", "dtlNiokurininEiRyaku" + i);
        recMap.put("dtlKyuJusho", "dtlKyuJusho" + i);
        recMap.put("dtlShiyoFuka", "dtlShiyoFuka" + i);
        recMap.put("dtlShinJushoHanei", "dtlShinJushoHanei" + i);
        recMap.put("dtlShinJisCd", "dtlShinJisCd" + i);
        recMap.put("dtlYubinBango", "dtlYubinBango" + i);
        recMap.put("dtlJisCd", "dtlJisCd" + i);
        recMap.put("dtlNiokurininJusho1", "dtlNiokurininJusho1" + i);
        recMap.put("dtlNiokurininJusho2", "dtlNiokurininJusho2" + i);
        recMap.put("dtlNiokurininJusho3", "dtlNiokurininJusho3" + i);
        recMap.put("dtlNiokurininJusho4", "dtlNiokurininJusho4" + i);
        recMap.put("dtlNiokurininTel", "dtlNiokurininTel" + i);
        recMap.put("dtlNiokurininEiJusho1", "dtlNiokurininEiJusho1" + i);
        recMap.put("dtlNiokurininEiJusho2", "dtlNiokurininEiJusho2" + i);
        recMap.put("dtlNiokurininEiJusho3", "dtlNiokurininEiJusho3" + i);
        recMap.put("dtlNiokurininEiJusho4", "dtlNiokurininEiJusho4" + i);
        recMap.put("dtlKensakokuriy", "dtlKensakokuriy" + i);
        recMap.put("dtlMemo", "dtlMemo" + i);
        recMap.put("dtlTekiyoKaishibi", "2019-01-01");
        recMap.put("dtlSaishuShiyobi", "2099-01-01");
        recMap.put("niokurininDataVersion", "niokurininDataVersion" + i);
        recMap.put("niokurininKoshinCounter", 0);
        return recMap;
    }
    
    private Map<String, Object> createRecMapFor_1_3(int i) {
        Map recMap = new HashMap();
        recMap.put("dtlKokyakuCd", "dtlKokyakuCd" + i);
        recMap.put("dtlKokyakuMei", "dtlKokyakuMei" + i);
        recMap.put("dtlEigyoshoCd", "dtlEigyoshoCd" + i);
        recMap.put("dtlEigyoshoMei", "dtlEigyoshoMei" + i);
        recMap.put("dtlNiukeninHakkoCd", "dtlNiukeninHakkoCd" + i);
        recMap.put("dtlNiukeninMei1", "dtlNiukeninMei1" + i);
        recMap.put("dtlNiukeninMei2", "dtlNiukeninMei2" + i);
        recMap.put("dtlNiukeninMei3", "dtlNiukeninMei3" + i);
        recMap.put("dtlNiukeninMei4", "dtlNiukeninMei4" + i);
        recMap.put("dtlNiukeninRyaku", "dtlNiukeninRyaku" + i);
        recMap.put("dtlNiukeninKana", "dtlNiukeninKana" + i);
        recMap.put("dtlNiukeninEiMei1", "dtlNiukeninEiMei1" + i);
        recMap.put("dtlNiukeninEiMei2", "dtlNiukeninEiMei2" + i);
        recMap.put("dtlNiukeninEiMei3", "dtlNiukeninEiMei3" + i);
        recMap.put("dtlNiukeninEiMei4", "dtlNiukeninEiMei4" + i);
        recMap.put("dtlNiukeninEiRyaku", "dtlNiukeninEiRyaku" + i);
        recMap.put("dtlKyuJusho", "dtlKyuJusho" + i);
        recMap.put("dtlShiyoFuka", "dtlShiyoFuka" + i);
        recMap.put("dtlShinJushoHanei", "dtlShinJushoHanei" + i);
        recMap.put("dtlShinJisCd", "dtlShinJisCd" + i);
        recMap.put("dtlYubinBango", "dtlYubinBango" + i);
        recMap.put("dtlNiukeninJusho1", "dtlNiukeninJusho1" + i);
        recMap.put("dtlNiukeninJusho2", "dtlNiukeninJusho2" + i);
        recMap.put("dtlNiukeninJusho3", "dtlNiukeninJusho3" + i);
        recMap.put("dtlNiukeninJusho4", "dtlNiukeninJusho4" + i);
        recMap.put("dtlNiukeninTel", "dtlNiukeninTel" + i);
        recMap.put("dtlShimukechiMei", "dtlShimukechiMei" + i);
        recMap.put("dtlHaitatsuEigyoshoMei", "dtlHaitatsuEigyoshoMei" + i);
        recMap.put("dtlNiukeninEiJusho1", "dtlNiukeninEiJusho1" + i);
        recMap.put("dtlNiukeninEiJusho2", "dtlNiukeninEiJusho2" + i);
        recMap.put("dtlNiukeninEiJusho3", "dtlNiukeninEiJusho3" + i);
        recMap.put("dtlNiukeninEiJusho4", "dtlNiukeninEiJusho4" + i);
        recMap.put("dtlKensakuKey", "dtlKensakuKey" + i);
        recMap.put("dtlKiji1Naiyo", "dtlKiji1Naiyo" + i);
        recMap.put("dtlKiji2Naiyo", "dtlKiji2Naiyo" + i);
        recMap.put("dtlKiji3Naiyo", "dtlKiji3Naiyo" + i);
        recMap.put("dtlKiji4Naiyo", "dtlKiji4Naiyo" + i);
        recMap.put("dtlKiji5Naiyo", "dtlKiji5Naiyo" + i);
        recMap.put("dtlMemo", "dtlMemo" + i);
        recMap.put("dtlTekiyoKaishibi", "2019-01-01");
        recMap.put("dtlSaishuShiyobi", "2099-01-01");
        recMap.put("niukeninDataVersion", "niukeninDataVersion" + i);
        recMap.put("niukeninKoshinCounter", 0);
        recMap.put("dtlOkurijoNiukenin", "dtlOkurijoNiukenin" + i);
        recMap.put("dtlOkurijoNiokurinin", "dtlOkurijoNiokurinin" + i);
        recMap.put("niukeninKoshinUser", "niukeninKoshinUser" + i);
        return recMap;
    }
}
