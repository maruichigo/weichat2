package jp.co.kintetsuls.beans.mst;

import java.io.IOException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst091Form;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.utils.FlashUtil;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * 仕向地名マスタ画面
 *
 * @author 廖鈺 (MBP)
 * @version 2019/3/08 新規作成
 */
public class Mst091BeanTest {

    // テストTarget
    @InjectMocks
    private Mst091Bean target;

    // Mockitoオブジェクト
    @Mock
    private FileBean fileBean;
    @Mock
    private AutoCompleteViewBean autoCompleteViewBean;
    @Mock
    private MasterInfoBean masterInfo;
    @Mock
    private MessagePropertyBean messageProperty;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosai;
    @Mock
    private SearchHelpBean searchHelpBean;
    @Mock
    private AuthorityConfBean authConfBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private MessagePropertyBean messagePropertyBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosaiBean;
    @Mock
    private FlashUtil flashUtil;
    @Mock
    private BaseBean baseBean;
    
    public Mst091BeanTest() {
    }

    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() {
    }

    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[not null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst091Form mst091Form = new Mst091Form();
        
        //前画面情報[not null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst091Form);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        // テスト実行
        Mst091Form form = new Mst091Form();
        target.setMst091Form(form);
        // 戻ってきた場合、再検索を実施する。
        target.init("","MST031_SCREEN",true);

        // 実施結果Outを取得
        form = target.getMst091Form();
        String title = target.getTITLE();
        String url = target.getUrl();
        BreadCrumbBean breadBean = target.getBreadBean();
        AutoCompleteViewBean autoCompleteViewBean = target.getAutoCompleteViewBean();
        AuthorityConfBean authorityConfBean  = target.getAuthorityConfBean();
        FileBean fileBean = target.getFileBean();
        MessagePropertyBean messagePropertyBean = target.getMessagePropertyBean();
        PageCommonBean pageCommonBean = target.getPageCommonBean();
        SearchHelpBean searchHelpBean = target.getSearchHelpBean();
        RirekiSyosaiBean rirekiSyosaiBean = target.getRirekiSyosaiBean();
        Map<String, Object> rirekiSearchKey = target.getRirekiSearchKey();
        List<MessageModuleBean> msgList = target.getMsgList();
        target.setUrl(url);
        target.setBreadBean(breadBean);
        target.setAutoCompleteViewBean(autoCompleteViewBean);
        target.setAuthorityConfBean(authorityConfBean);
        target.setFileBean(fileBean);
        target.setMessagePropertyBean(messagePropertyBean);
        target.setPageCommonBean(pageCommonBean);
        target.setSearchHelpBean(searchHelpBean);
        target.setRirekiSyosaiBean(rirekiSyosaiBean);
        target.setRirekiSearchKey(rirekiSearchKey);
        target.setMsgList(msgList);

        // 実行時に渡すパラメータの検証
        assertEquals("mst091Form",keyCaptor_1.getValue());
        // 想定通りに再検索を実施する。
        assertEquals("search_mst091",keyCaptor_2.getValue());
    }

   // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[ 営業所コード = "001"仕入先コード（Axis） = "A00001"
    // 仕入先コード（SS） = "S00001"仕入区分 = "輸送機材"世代検索条件 = "適用日指定" 
    // 適用日 = "2019/01/01"削除済のみ =  null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2() throws IllegalAccessException, InvocationTargetException,
            InstantiationException, ParseException {

        // Mockitoオブジェクトの予想return値設定
        Mst091Form mst091Form = new Mst091Form();
        
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCdAxis = new AutoCompOptionBean();
        conShiiresakiCdAxis.setValue("A0001");
        AutoCompOptionBean conShiiresakiKbn = new AutoCompOptionBean();
        conShiiresakiKbn.setValue("1002");
        String[] conSedaiKensakuJoken = {"05"};
        String conTekiyobi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        mst091Form.setConEigyoshoCd(conEigyoshoCd);
        mst091Form.setConShiiresakiCdAxis(conShiiresakiCdAxis);
        mst091Form.setConShiireKbn(conShiiresakiKbn);
        mst091Form.setConShiiresakiCdSS("S00001");
        mst091Form.setConSedaiKensakuJoken(conSedaiKensakuJoken);
        mst091Form.setConTekiyobi("2019-01-01");
        mst091Form.setConSakujoSumiNomi(null);
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        
        flash.put("mst091Form", mst091Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);        

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        // テスト実行
        Mst091Form form = new Mst091Form();
        target.setMst091Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        // 実施結果Outを取得
        form = target.getMst091Form();

        // 想定通りに再検索を実施する。
        assertEquals("search_mst091",keyCaptor_2.getValue());
        assertEquals("001",form.getConEigyoshoCd().getValue());
        assertEquals("A0001",form.getConShiiresakiCdAxis().getValue());
        assertEquals("S00001",form.getConShiiresakiCdSS());
        assertEquals("1002",form.getConShiireKbn().getValue());
        assertEquals(new String[]{"05"},form.getConSedaiKensakuJoken());
        assertEquals("2019-01-01",form.getConTekiyobi());
        assertEquals(null,form.getConSakujoSumiNomi());
    }
    
    // init_正常_初期処理_1-2_1
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2_1() throws IllegalAccessException, InvocationTargetException,
            InstantiationException, ParseException {

        // Mockitoオブジェクトの予想return値設定
        Mst091Form mst091Form = new Mst091Form();
        
        // 前回検索パラメータ
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCdAxis = new AutoCompOptionBean();
        conShiiresakiCdAxis.setValue("A0001");
        AutoCompOptionBean conShiiresakiKbn = new AutoCompOptionBean();
        conShiiresakiKbn.setValue("1002");
        String[] conSedaiKensakuJoken = {"05"};
        String conTekiyobi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        mst091Form.setConEigyoshoCd(conEigyoshoCd);
        mst091Form.setConShiiresakiCdAxis(conShiiresakiCdAxis);
        mst091Form.setConShiireKbn(conShiiresakiKbn);
        mst091Form.setConShiiresakiCdSS("S00001");
        mst091Form.setConSedaiKensakuJoken(conSedaiKensakuJoken);
        mst091Form.setConTekiyobi("2019-01-01");
        mst091Form.setConSakujoSumiNomi(null);
        
        Flash flash =  new FlashKls();
        // 前画面パラメータ
        flash.put("mst501Form", null);
        when(pageCommonBean.getPageParam()).thenReturn(flash);        

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        // テスト実行
        Mst091Form form = new Mst091Form();
        target.setMst091Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        // 実施結果Outを取得
        form = target.getMst091Form();

        // 想定通りに再検索を実施する。
        assertEquals(null,form.getConSakujoSumiNomi());
    } 

    // init_正常_初期処理_1-3
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        // 前画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(null);

        // テスト実行
        Mst091Form form = new Mst091Form();
        target.setMst091Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        // 実施結果Outを取得
        form = target.getMst091Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst091Form",keyCaptor_1.getValue());
        // 想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null,form.getSearchResult());
    }
    
    // init_正常_初期処理_1-3_1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        // 前画面情報[null]
        doThrow(IllegalAccessException.class).when(pageCommonBean).getPageInfo(keyCaptor_1.capture());

        // テスト実行
        Mst091Form form = new Mst091Form();
        target.setMst091Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        // 実施結果Outを取得
        form = target.getMst091Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst091Form",keyCaptor_1.getValue());
        // 想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null,form.getSearchResult());
    }

    // search_正常_検索処理_2-1
    //
    // -------------------テスト条件--------------------------
    // 仕入予定検索結果一覧取得 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_1 () throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=0;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mst091Form form = new Mst091Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("conEigyoshoCd1");
        AutoCompOptionBean conShiiresakiCdAxis = new AutoCompOptionBean();
        conShiiresakiCdAxis.setValue("conShiiresakiCdAxis1");
        AutoCompOptionBean conShiiresakiKbn = new AutoCompOptionBean();
        conShiiresakiKbn.setValue("conShiiresakiKbn1");
        String conTekiyobi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiiresakiCdAxis(conShiiresakiCdAxis);
        form.setConShiireKbn(conShiiresakiKbn);
        form.setConShiiresakiCdSS("conShiiresakiCdSS1");
        form.setConSedaiKensakuJoken(new String[]{"conSedaiKensakuJoken1"});
        form.setConTekiyobi("2019-01-01");
        form.setConSakujoSumiNomi(new String[]{"conSakujoSumiNomi1"});
        target.setMst091Form(form);
        target.search();

        // 実施結果Outを取得
        form = target.getMst091Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conEigyoshoCd1", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("conShiiresakiCdAxis1", paramsCaptor_1.getValue().get("conShiiresakiCdAxis"));
        assertEquals("conShiiresakiKbn1", paramsCaptor_1.getValue().get("conShiireKbn"));
        assertEquals("conShiiresakiCdSS1", paramsCaptor_1.getValue().get("conShiiresakiCdSS"));
        assertEquals(new String[]{"conSedaiKensakuJoken1"},
                (String[]) paramsCaptor_1.getValue().get("conSedaiKensakuJoken"));
        assertEquals("2019-01-01", paramsCaptor_1.getValue().get("conTekiyobi"));
        assertEquals("1",paramsCaptor_1.getValue().get("conSakujoSumiNomi"));
        assertEquals("mst091_search", functionCodeCaptor_2.getValue());
        // 想定通りに一覧を表示されること
        assertForRecList_2_1(form);
    }    

   // search_異常_検索処理_2-2
    //
    // -------------------テスト条件--------------------------
    // 仕入予定検索結果一覧取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索結果一覧取得 取得件数 = 2
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=1;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mst091Form form = new Mst091Form();
        form.setConSedaiKensakuJoken(new String[]{"01", "02"});
        form.setConSakujoSumiNomi(new String[]{});
        target.setMst091Form(form);
        target.search();

        // 実施結果Outを取得
        form = target.getMst091Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null, paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conShiiresakiCdAxis"));
        assertEquals(null, paramsCaptor_1.getValue().get("conShiiresakiKbn"));
        assertEquals(null, paramsCaptor_1.getValue().get("conShiiresakiCdSS"));
        assertEquals(2,((String[]) paramsCaptor_1.getValue().get("conSedaiKensakuJoken")).length);
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyobi"));
        assertEquals("0", paramsCaptor_1.getValue().get("conSakujoSumiNomi"));
        assertEquals("mst091_search",functionCodeCaptor_2.getValue());
        // 想定通りに一覧を表示されること
        assertForRecList_2_2(form);
    }

    // search_正常_検索処理_2-3
    //
    // -------------------テスト条件--------------------------
    // 仕入予定検索結果一覧取得 取得件数 = 0
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得 取得件数 = 0
        List<Map<String, String>> result = new ArrayList<>();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mst091Form form = new Mst091Form();
        target.setMst091Form(form);
        target.search();

        // 実施結果Outを取得
        form = target.getMst091Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null, paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conShiiresakiCdAxis"));
        assertEquals(null, paramsCaptor_1.getValue().get("conShiiresakiKbn"));
        assertEquals(null, paramsCaptor_1.getValue().get("conShiiresakiCdSS"));
        assertEquals(null,(String[]) paramsCaptor_1.getValue().get("conSedaiKensakuJoken"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyobi"));
        assertEquals("0", paramsCaptor_1.getValue().get("conSakujoSumiNomi"));
        assertEquals("mst091_search",functionCodeCaptor_2.getValue());
        // 想定通りに・一覧は表示しない（ヘッダーのみ） 
        // 想定通りに ・ファンクションボタンは表示（検索前と同じ） 
        assertForRecList_2_3(form);
    }
    
    // search_異常_件数取得処理_2-4_2
    //
    // -------------------テスト条件--------------------------
    // 仕入予定検索結果一覧取得
    // -----------------------------------------------------
    @Test
    public void search_異常_件数取得処理_2_3_1 () throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        doThrow(IOException.class).when(pageCommonBean).getDBInfo(paramsCaptor_1.capture(), 
                functionCodeCaptor_2.capture());
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mst091Form form = new Mst091Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("conEigyoshoCd1");
        AutoCompOptionBean conShiiresakiCdAxis = new AutoCompOptionBean();
        conShiiresakiCdAxis.setValue("conShiiresakiCdAxis1");
        AutoCompOptionBean conShiiresakiKbn = new AutoCompOptionBean();
        conShiiresakiKbn.setValue("conShiiresakiKbn1");
        String conTekiyobi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiiresakiCdAxis(conShiiresakiCdAxis);
        form.setConShiireKbn(conShiiresakiKbn);
        form.setConShiiresakiCdSS("conShiiresakiCdSS1");
        form.setConSedaiKensakuJoken(new String[]{"conSedaiKensakuJoken1"});
        form.setConTekiyobi("2019-01-01");
        form.setConSakujoSumiNomi(new String[]{"conSakujoSumiNomi1"});
        target.setMst091Form(form);
        target.search();

        // 実施結果Outを取得
        form = target.getMst091Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conEigyoshoCd1", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("conShiiresakiCdAxis1", paramsCaptor_1.getValue().get("conShiiresakiCdAxis"));
        assertEquals("conShiiresakiKbn1", paramsCaptor_1.getValue().get("conShiireKbn"));
        assertEquals("conShiiresakiCdSS1", paramsCaptor_1.getValue().get("conShiiresakiCdSS"));
        assertEquals(new String[]{"conSedaiKensakuJoken1"},(String[]) paramsCaptor_1.getValue().get("conSedaiKensakuJoken"));
        assertEquals("2019-01-01", paramsCaptor_1.getValue().get("conTekiyobi"));
        assertEquals("1",paramsCaptor_1.getValue().get("conSakujoSumiNomi"));
        assertEquals("mst091_search", functionCodeCaptor_2.getValue());
    } 

    // getRecordCount_正常_件数取得処理_2-4
    //
    // -------------------テスト条件--------------------------
    // 仕入予定検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), 
                functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mst091Form form = new Mst091Form();
        target.setMst091Form(form);
        target.getRecordCount();

        // 実施結果Outを取得
        form = target.getMst091Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null, paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conShiiresakiCdAxis"));
        assertEquals(null, paramsCaptor_1.getValue().get("conShiiresakiKbn"));
        assertEquals(null, paramsCaptor_1.getValue().get("conShiiresakiCdSS"));
        assertEquals(null,(String[]) paramsCaptor_1.getValue().get("conSedaiKensakuJoken"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyobi"));
        assertEquals("0",  paramsCaptor_1.getValue().get("conSakujoSumiNomi"));
        assertEquals("mst091_count",functionCodeCaptor_2.getValue());
        // 想定通りに正常にCountを実施されること
        assertEquals(null,form.getConEigyoshoCd());
    }
    
    // getRecordCount_正常_件数取得処理_2-4_1
    //
    // -------------------テスト条件--------------------------
    // 仕入予定検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_4_1 () throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        

        // テスト実行
        Mst091Form form = new Mst091Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("conEigyoshoCd1");
        AutoCompOptionBean conShiiresakiCdAxis = new AutoCompOptionBean();
        conShiiresakiCdAxis.setValue("conShiiresakiCdAxis1");
        AutoCompOptionBean conShiiresakiKbn = new AutoCompOptionBean();
        conShiiresakiKbn.setValue("conShiiresakiKbn1");
        String conTekiyobi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiiresakiCdAxis(conShiiresakiCdAxis);
        form.setConShiireKbn(conShiiresakiKbn);
        form.setConShiiresakiCdSS("conShiiresakiCdSS1");
        form.setConSedaiKensakuJoken(new String[]{"conSedaiKensakuJoken1"});
        form.setConTekiyobi("2019-01-01");
        form.setConSakujoSumiNomi(new String[]{"conSakujoSumiNomi1"});
        target.setMst091Form(form);
        target.getRecordCount();

        // 実施結果Outを取得
        form = target.getMst091Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conEigyoshoCd1", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("conShiiresakiCdAxis1", paramsCaptor_1.getValue().get("conShiiresakiCdAxis"));
        assertEquals("conShiiresakiKbn1", paramsCaptor_1.getValue().get("conShiireKbn"));
        assertEquals("conShiiresakiCdSS1", paramsCaptor_1.getValue().get("conShiiresakiCdSS"));
        assertEquals(new String[]{"conSedaiKensakuJoken1"},(String[]) paramsCaptor_1.getValue().get("conSedaiKensakuJoken"));
        assertEquals("2019-01-01", paramsCaptor_1.getValue().get("conTekiyobi"));
        assertEquals("1",paramsCaptor_1.getValue().get("conSakujoSumiNomi"));
        assertEquals("mst091_count",functionCodeCaptor_2.getValue());
        //想定通りに正常にCountを実施されること
    }

    // clear_正常_クリア処理_3-1
    //
    // -------------------テスト条件--------------------------
    // 仕入予定検索条件と検索結果がある
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_1 () throws IllegalAccessException, InvocationTargetException, ParseException {

        // テスト実行
        Mst091Form form = new Mst091Form();
        // 検索条件と検索結果がある
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        conEigyoshoCd.setLabel("営業所1");
        AutoCompOptionBean conShiiresakiCdAxis = new AutoCompOptionBean();
        conShiiresakiCdAxis.setValue("A0001");
        conShiiresakiCdAxis.setLabel("仕入先01");
        AutoCompOptionBean conShiiresakiKbn = new AutoCompOptionBean();
        conShiiresakiKbn.setValue("1002");
        conShiiresakiKbn.setLabel("仕入区分");
        String[] conSedaiKensakuJoken = {"05"};
        String conTekiyobi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiiresakiCdAxis(conShiiresakiCdAxis);
        form.setConShiireKbn(conShiiresakiKbn);
        form.setConShiiresakiCdSS("S00001");
        form.setConSedaiKensakuJoken(conSedaiKensakuJoken);
        form.setConTekiyobi("2019-01-01");
        form.setConSakujoSumiNomi(new String[]{"1"});

        target.setMst091Form(form);
        target.clear();

        // 実施結果Outを取得
        form = target.getMst091Form();

        // 想定通りに正常にClearを実施されること
        assertEquals(null,form.getConEigyoshoCd());
        assertEquals(null,form.getConShiiresakiCdAxis());
        assertEquals(null,form.getConShiiresakiCdSS());
        assertEquals(null,form.getConShiireKbn());
        String[] conSedaiKensakuJokenDefault = {"01", "02"};
        assertEquals(conSedaiKensakuJokenDefault,form.getConSedaiKensakuJoken());
        assertEquals(null,form.getConTekiyobi());
        assertEquals(null, form.getConSakujoSumiNomi());
    }

    // clear_正常_クリア処理_3-2
    //
    // -------------------テスト条件--------------------------
    // 検索条件がある、検索結果がない
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_2 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst091Form form = new Mst091Form();
        target.setMst091Form(form);
        target.clear();

        // 実施結果Outを取得
        form = target.getMst091Form();

        // 想定通りに正常にClearを実施されること
        assertEquals(null,form.getConEigyoshoCd());
        assertEquals(null,form.getConShiiresakiCdAxis());
        assertEquals(null,form.getConShiiresakiCdSS());
        assertEquals(null,form.getConShiireKbn());
        String[] conSedaiKensakuJokenDefault = {"01", "02"};
        assertEquals(conSedaiKensakuJokenDefault,form.getConSedaiKensakuJoken());
        assertEquals(null,form.getConTekiyobi());
        assertEquals(null, form.getConSakujoSumiNomi());
    }

    // getHeader_正常_ダウンロード_4-1
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void getHeader_正常_ダウンロード_4_1 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst091Form form = new Mst091Form();
        target.setMst091Form(form);
        List<CSVDto> dto = target.getHeader();

        // 実施結果Outを取得
        form = target.getMst091Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null,form.getConEigyoshoCd());
        assertEquals(null,form.getConShiiresakiCdAxis());
        assertEquals(null,form.getConShiiresakiCdSS());
        assertEquals(null,form.getConShiireKbn());
        String[] conSedaiKensakuJokenDefault = {"01", "02"};
        assertEquals(null,form.getConSedaiKensakuJoken());
        assertEquals(null,form.getConTekiyobi());
        assertEquals(null, form.getConSakujoSumiNomi());
        
        // 想定通りに正常にCVSのHeaderを設定されること
        assertEquals("仕入区分",dto.get(0).getTitle());
        assertEquals("listShiireKbn",dto.get(0).getName());
        assertEquals("仕入先コード",dto.get(1).getTitle());
        assertEquals("listShiiresakiCd",dto.get(1).getName());
    }

    // beforeDown_正常_ダウンロード_4-2
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=2件
    // -----------------------------------------------------
    @Test
    public void beforeDown_正常_ダウンロード_4_2 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst091Form form = new Mst091Form();
        target.setMst091Form(form);
        try {
            target.beforeDown("testComment");
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(Mst091BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        // 実施結果Outを取得
        form = target.getMst091Form();

        // 実行時に渡すパラメータの検証
        // 想定通りに正常にダウンロード理由を記録すること
        assertEquals(null,form.getConEigyoshoCd());
    }    
    
    // getSearchResult_正常_ダウンロード_4-2
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=2件
    // -----------------------------------------------------
    @Test
    public void getSearchResult_正常_ダウンロード_4_3 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst091Form form = new Mst091Form();
        target.setMst091Form(form);
        target.getSearchResult();

        // 実施結果Outを取得
        form = target.getMst091Form();

        // 実行時に渡すパラメータの検証
        // 想定通りに正常にダウンロード理由を記録すること
        assertEquals(null,form.getConEigyoshoCd());
    }

   // delRows_正常_削除処理_13-1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 1
    // 仕入予定マスタと仕入予定明細に存在している
    // -----------------------------------------------------
    @Test
    public void delRows_正常_削除処理_13_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());
        // テスト実行
        Mst091Form form = new Mst091Form();
        // 行選択チェック選択 = 1
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        form.setSearchResult(result);
        form.setSelectedSearchResult(result);
        target.setMst091Form(form);
        target.delRows(result);

        // 実施結果Outを取得
        form = target.getMst091Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst091_delete",functionCodeCaptor_2.getValue());
        // 想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること削除処理を行う。
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0004",summaryCaptor_4.getValue());
        assertEquals("削除",detailCaptor_5.getValue());
    }    

   // delRows_正常_削除処理_13-2
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 2
    // 仕入予定マスタと仕入予定明細に存在している
    // -----------------------------------------------------
    @Test
    public void delRows_正常_削除処理_13_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        serviceInterfaceBean2.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean, serviceInterfaceBean2);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());
        //　テスト実行
        Mst091Form form = new Mst091Form();
        //　行選択チェック選択 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        form.setSearchResult(result);
        target.setMst091Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst091Form();
    }     
    
    // delBeforeCheck_正常_削除処理_13-3
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 1
    // -----------------------------------------------------
    @Test
    public void delBeforeCheck_正常_削除処理_13_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).executeScript(keyCaptor_2.capture());
        
        // テスト実行
        Mst091Form form = new Mst091Form();
        // 行選択チェック選択 = 1
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst091Form(form);
        target.delBeforeCheck();
        
        // 実施結果Outを取得
        form = target.getMst091Form();
    }    

    // delBeforeCheck_異常_削除処理_13-3_1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // -----------------------------------------------------
    @Test
    public void delBeforeCheck_異常_削除処理_13_3_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(
                levelCaptor_1.capture(),summaryCaptor_2.capture())).thenReturn(messageModuleBean);
        // テスト実行
        Mst091Form form = new Mst091Form();
        // 行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        form.setSelectedSearchResult(result);
        target.setMst091Form(form);
        target.delBeforeCheck();

        // 実施結果Outを取得
        form = target.getMst091Form();

        // 想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0029",summaryCaptor_2.getValue());
    }    

    // delRows_異常_削除処理_13-4
    //
    // -------------------テスト条件--------------------------
    // 仕入予定明細マスタに存在しない
    // -----------------------------------------------------
    @Test
    public void delRows_異常_削除処理_13_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕入予定明細マスタに存在しない[COME0006]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0043",
                "仕入予定明細データ");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), 
                functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture(),
                summaryCaptor_3.capture(),summaryCaptor_4.capture())).thenReturn(messageModuleBean);

        // テスト実行
        Mst091Form form = new Mst091Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        form.setSearchResult(result);
        target.setMst091Form(form);
        target.delRows(result);

        // 実施結果Outを取得
        form = target.getMst091Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listShiireKbnCd0",paramsCaptor_1_Param.get("listShiireKbnCd"));
        assertEquals("listShiiresakiCd0",paramsCaptor_1_Param.get("listShiiresakiCd"));
        assertEquals("listEigyoshoCd0",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("2019/01/01",
                 DateFormat.getDateInstance(DateFormat.DEFAULT).format(paramsCaptor_1_Param.get("listTekiyoKaisibi")));
        assertEquals("listTani0",paramsCaptor_1_Param.get("listTani"));
        assertEquals("listTanka0",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("listYobibetuShiiregakuGetuyo0",paramsCaptor_1_Param.get("listYobibetuShiiregakuGetuyo"));
        assertEquals("listYobibetuShiiregakuKayo0",
                paramsCaptor_1_Param.get("listYobibetuShiiregakuKayo"));
        assertEquals("listYobibetuShiiregakuSuiyo0",
                paramsCaptor_1_Param.get("listYobibetuShiiregakuSuiyo"));
        assertEquals("listYobibetuShiiregakuMokuyo0",paramsCaptor_1_Param.get("listYobibetuShiiregakuMokuyo"));
        assertEquals("listYobibetuShiiregakuKinyo0",paramsCaptor_1_Param.get("listYobibetuShiiregakuKinyo"));
        assertEquals("listYobibetuShiiregakuDoyo0",paramsCaptor_1_Param.get("listYobibetuShiiregakuDoyo"));
        assertEquals("listYobibetuShiiregakuNitiShuku0",paramsCaptor_1_Param.get("listYobibetuShiiregakuNitiShuku"));
        assertEquals("listShiireYoteiMeisaiGokeiKingaku0",
                paramsCaptor_1_Param.get("listShiireYoteiMeisaiGokeiKingaku"));
        assertEquals("listEigyoshoCd0",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("listEigyoshoMei0",paramsCaptor_1_Param.get("listEigyoshoMei"));
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("mst091_delete_exist_check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0043）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0043",summaryCaptor_2.getValue());
    }    
    
    // delRows_異常_削除処理_13-4
    //
    // -------------------テスト条件--------------------------
    // 仕入予定マスタに存在しない
    // -----------------------------------------------------
    @Test
    public void delRows_異常_削除処理_13_5 () throws IllegalAccessException, InvocationTargetException {

      // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕入予定マスタに存在しない[COME0006]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0043",
                "仕入予定データ");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), 
                functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture(),
                summaryCaptor_3.capture(),summaryCaptor_4.capture())).thenReturn(messageModuleBean);

        // テスト実行
        Mst091Form form = new Mst091Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        form.setSearchResult(result);
        target.setMst091Form(form);
        target.delRows(result);

        // 実施結果Outを取得
        form = target.getMst091Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listShiireKbnCd0",paramsCaptor_1_Param.get("listShiireKbnCd"));
        assertEquals("listShiiresakiCd0",paramsCaptor_1_Param.get("listShiiresakiCd"));
        assertEquals("listEigyoshoCd0",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("2019/01/01",
                 DateFormat.getDateInstance(DateFormat.DEFAULT).format(paramsCaptor_1_Param.get("listTekiyoKaisibi")));
        assertEquals("listTani0",paramsCaptor_1_Param.get("listTani"));
        assertEquals("listTanka0",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("listYobibetuShiiregakuGetuyo0",paramsCaptor_1_Param.get("listYobibetuShiiregakuGetuyo"));
        assertEquals("listYobibetuShiiregakuKayo0",
                paramsCaptor_1_Param.get("listYobibetuShiiregakuKayo"));
        assertEquals("listYobibetuShiiregakuSuiyo0",
                paramsCaptor_1_Param.get("listYobibetuShiiregakuSuiyo"));
        assertEquals("listYobibetuShiiregakuMokuyo0",paramsCaptor_1_Param.get("listYobibetuShiiregakuMokuyo"));
        assertEquals("listYobibetuShiiregakuKinyo0",paramsCaptor_1_Param.get("listYobibetuShiiregakuKinyo"));
        assertEquals("listYobibetuShiiregakuDoyo0",paramsCaptor_1_Param.get("listYobibetuShiiregakuDoyo"));
        assertEquals("listYobibetuShiiregakuNitiShuku0",paramsCaptor_1_Param.get("listYobibetuShiiregakuNitiShuku"));
        assertEquals("listShiireYoteiMeisaiGokeiKingaku0",
                paramsCaptor_1_Param.get("listShiireYoteiMeisaiGokeiKingaku"));
        assertEquals("listEigyoshoCd0",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("listEigyoshoMei0",paramsCaptor_1_Param.get("listEigyoshoMei"));
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("mst091_delete_exist_check",functionCodeCaptor_2.getValue());
        // 想定通りにエラーが発生。（メッセージID：COME0043）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0043",summaryCaptor_2.getValue());
    }
    
    // btnCopyTorokuClick_正常_複写登録_14_1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 1
    // -----------------------------------------------------
    @Test
    public void btnCopyTorokuClick_正常_複写登録_14_1 () throws IllegalAccessException, InvocationTargetException {

         // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),
                functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),
                detailCaptor_5.capture());
        when(baseBean.forward("", null, "", false)).thenReturn(" ");
        // テスト実行
        Mst091Form form = new Mst091Form();
        // 行選択チェック選択 = 1
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst091Form(form);
        Flash flash =  new FlashKls();
        flash.put("mst091form", null);
        when(pageCommonBean.getPageParam()).thenReturn(flash); 
        
        when(flashUtil.getPageParam()).thenReturn(flash);

        target.btnCopyTorokuClick();

        // 実施結果Outを取得
        form = target.getMst091Form();
    }    
    
    // btnCopyTorokuClick_異常_複写登録_14_2
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // -----------------------------------------------------
    @Test
    public void btnCopyTorokuClick_異常_複写登録_14_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(
                levelCaptor_1.capture(),summaryCaptor_2.capture())).thenReturn(messageModuleBean);
        // テスト実行
        Mst091Form form = new Mst091Form();
        // 行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        form.setSelectedSearchResult(result);
        target.setMst091Form(form);
        target.btnCopyTorokuClick();

        // 実施結果Outを取得
        form = target.getMst091Form();

        // 想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0029",summaryCaptor_2.getValue());
    }
    
    // btnCopyTorokuClick_異常_複写登録_14_3
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 2
    // -----------------------------------------------------
    @Test
    public void btnCopyTorokuClick_異常_複写登録_14_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(
                levelCaptor_1.capture(),summaryCaptor_2.capture())).thenReturn(messageModuleBean);
        // テスト実行
        Mst091Form form = new Mst091Form();
        // 行選択チェック選択 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst091Form(form);
        target.btnCopyTorokuClick();

        // 実施結果Outを取得
        form = target.getMst091Form();

        // 想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0029",summaryCaptor_2.getValue());
    }

    // rirekiIchiran_正常_更新履歴コンテキストメニュー_15-1
    //
    // -------------------テスト条件--------------------------
    // 正常に取得された場合
    // -----------------------------------------------------
    @Test
    public void rirekiIchiran_正常_更新履歴コンテキストメニュー_15_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> titleFlgCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> searchKeyCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(rirekiSyosaiBean).searchList(titleFlgCaptor_1.capture(),
                functionCodeCaptor_2.capture(),searchKeyCaptor_3.capture());
        // テスト実行
        Mst091Form form = new Mst091Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_2(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst091Form(form);
        target.rirekiIchiran();

        // 実施結果Outを取得
        form = target.getMst091Form();

        // 想定通りに履歴を表示する。
        assertEquals("2",titleFlgCaptor_1.getValue());
        assertEquals("MST091_SEARCH_RIREKI",functionCodeCaptor_2.getValue());
        assertEquals("listShiireKbnCd0",searchKeyCaptor_3.getValue().get("listShiireKbnCd"));
        assertEquals("listShiiresakiCd0",searchKeyCaptor_3.getValue().get("listShiiresakiCd"));
        assertEquals("listEigyoshoCd0",searchKeyCaptor_3.getValue().get("listEigyoshoCd"));
    }    
    
    // btnShinkiTorokuClick_正常_新規登録_17_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void linkClick_正常_仕入区分リンク_16_1 () throws IllegalAccessException, InvocationTargetException {

        when(baseBean.forward("", null, "", false)).thenReturn(" ");
         // テスト実行
        Mst091Form form = new Mst091Form();
        Map<String, Object> result = new HashMap();
        for (int i=0;i<1;i++){
            result = createRecMapFor_11_1(i);
        }
        form.setLinkSearchResult(result);
        target.setMst091Form(form);   
        
        Flash flash =  new FlashKls();
        flash.put("mst091form", null);
        when(pageCommonBean.getPageParam()).thenReturn(flash);     
        
        when(flashUtil.getPageParam()).thenReturn(flash);

        target.linkClick();

        // 実施結果Outを取得
        form = target.getMst091Form();
    }
    
    // btnShinkiTorokuClick_正常_新規登録_17_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void btnShinkiTorokuClick_正常_新規登録_17_1 () throws IllegalAccessException, InvocationTargetException {

        when(baseBean.forward("", null, "", false)).thenReturn(" ");
        // テスト実行
        Mst091Form form = new Mst091Form();
        target.setMst091Form(form);
        Flash flash =  new FlashKls();
        flash.put("mst091form", null);
        when(pageCommonBean.getPageParam()).thenReturn(flash);   
        
        when(flashUtil.getPageParam()).thenReturn(flash);
        
        target.btnShinkiTorokuClick();

        // 実施結果Outを取得
        form = target.getMst091Form();
    }
    
    // searchChange_正常_補充ケース_18-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void searchChange_正常_補充ケース_18_1 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst091Form form = new Mst091Form();
        target.setMst091Form(form);
        target.searchChange();

        // 実施結果Outを取得
        form = target.getMst091Form();

    }

    // menuClick_正常_補充ケース_18-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_18_2 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst091Form form = new Mst091Form();
        target.setMst091Form(form);
        target.menuClick("","");

        // 実施結果Outを取得
        form = target.getMst091Form();

    }
    
    // menuClick_正常_補充ケース_18-2-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_18_2_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(1);
       
        // テスト実行
        Mst091Form form = new Mst091Form();
        target.setMst091Form(form);
        target.menuClick("","");

        // 実施結果Outを取得
        form = target.getMst091Form();

    }

    // breadClumClick_正常_補充ケース_18-3
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_18_3 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst091Form form = new Mst091Form();
        target.setMst091Form(form);
        target.breadClumClick("",0);

        // 実施結果Outを取得
        form = target.getMst091Form();

    }
    
    // breadClumClick_正常_補充ケース_18-3-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_18_3_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(0); 
        // テスト実行
        Mst091Form form = new Mst091Form();
        target.setMst091Form(form);
        target.breadClumClick("",0);

        // 実施結果Outを取得
        form = target.getMst091Form();

    }

    // logoutClick_正常_補充ケース_18-4
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void logoutClick_正常_補充ケース_18_4 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst091Form form = new Mst091Form();
        target.setMst091Form(form);
        target.logoutClick();

        // 実施結果Outを取得
        form = target.getMst091Form();

    }

    // delRowsFunc_正常_補充ケース_18-5
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void delRowsFunc_正常_補充ケース_18_5 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst091Form form = new Mst091Form();
        target.setMst091Form(form);
        target.delRowsFunc();

        // 実施結果Outを取得
        form = target.getMst091Form();

    }    
    
    
    private Map<String, String> createRecMapFor_1_1(int i) {
        Map recMap = new HashMap();
        recMap.put("listShiireKbnCd", "listShiireKbnCd" + i);
        recMap.put("listShiiresakiCd", "listShiiresakiCd" + i);
        recMap.put("listEigyoshoCd", "listEigyoshoCd" + i);
        String conTekiyobi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        BigDecimal money = new BigDecimal(1111111111);
        recMap.put("listTekiyoKaisibi", Long.valueOf("1546272000000")); 
        recMap.put("listShiiresakiMei", "listShiiresakiMei" + i);
        recMap.put("listTani", "listTani" + i);
        recMap.put("listTanka", money);
        recMap.put("listYobibetuShiiregakuGetuyo", money);
        recMap.put("listYobibetuShiiregakuKayo", money);
        recMap.put("listYobibetuShiiregakuSuiyo", money);
        recMap.put("listYobibetuShiiregakuMokuyo", money);
        recMap.put("listYobibetuShiiregakuKinyo", money);
        recMap.put("listYobibetuShiiregakuDoyo", money);
        recMap.put("listYobibetuShiiregakuNitiShuku", money);
        recMap.put("listShiireYoteiMeisaiGokeiKingaku", money);
        recMap.put("listEigyoshoMei", "listEigyoshoMei" + i);
        recMap.put("listShuryoFlg", "listShuryoFlg" + i);
        return recMap;
    }

    private Map<String, Object> createRecMapFor_11_1(int i) {
        Map recMap = new HashMap();
        recMap.put("listShiireKbnCd", "listShiireKbnCd" + i);
        recMap.put("listShiireKbn", "listShiireKbn" + i);
        recMap.put("listShiiresakiCd", "listShiiresakiCd" + i);
        recMap.put("listEigyoshoCd", "listEigyoshoCd" + i);
        String conTekiyobi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        recMap.put("listTekiyoKaisibi", Long.valueOf("1546272000000"));
        recMap.put("listShiiresakiMei", "listShiiresakiMei" + i);
        recMap.put("listTani", "listTani" + i);
        recMap.put("listTanka", "listTanka" + i);
        recMap.put("listYobibetuShiiregakuGetuyo", "listYobibetuShiiregakuGetuyo" + i);
        recMap.put("listYobibetuShiiregakuKayo", "listYobibetuShiiregakuKayo" + i);
        recMap.put("listYobibetuShiiregakuSuiyo", "listYobibetuShiiregakuSuiyo" + i);
        recMap.put("listYobibetuShiiregakuMokuyo", "listYobibetuShiiregakuMokuyo" + i);
        recMap.put("listYobibetuShiiregakuKinyo", "listYobibetuShiiregakuKinyo" + i);
        recMap.put("listYobibetuShiiregakuDoyo", "listYobibetuShiiregakuDoyo" + i);
        recMap.put("listYobibetuShiiregakuNitiShuku", "listYobibetuShiiregakuNitiShuku" + i);
        recMap.put("listShiireYoteiMeisaiGokeiKingaku", "listShiireYoteiMeisaiGokeiKingaku" + i);
        recMap.put("listEigyoshoMei", "listEigyoshoMei" + i);
        recMap.put("listShuryoFlg" , "listShuryoFlg" + i);
        return recMap;
    }
    
        private Map<String, Object> createRecMapFor_11_2(int i) {
        Map recMap = new HashMap();
        recMap.put("listDataVersion", "listDataVersion" + i);
        recMap.put("listShiireKbnCd", "listShiireKbnCd" + i);
        recMap.put("listShiiresakiCd", "listShiiresakiCd" + i);
        recMap.put("listEigyoshoCd", "listEigyoshoCd" + i);
        String conTekiyobi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        recMap.put("listTekiyoKaisibi", Long.valueOf("1546272000000"));
        recMap.put("listShiiresakiMei", "listShiiresakiMei" + i);
        recMap.put("listTani", "listTani" + i);
        recMap.put("listTanka", "listTanka" + i);
        recMap.put("listYobibetuShiiregakuGetuyo", "listYobibetuShiiregakuGetuyo" + i);
        recMap.put("listYobibetuShiiregakuKayo", "listYobibetuShiiregakuKayo" + i);
        recMap.put("listYobibetuShiiregakuSuiyo", "listYobibetuShiiregakuSuiyo" + i);
        recMap.put("listYobibetuShiiregakuMokuyo", "listYobibetuShiiregakuMokuyo" + i);
        recMap.put("listYobibetuShiiregakuKinyo", "listYobibetuShiiregakuKinyo" + i);
        recMap.put("listYobibetuShiiregakuDoyo", "listYobibetuShiiregakuDoyo" + i);
        recMap.put("listYobibetuShiiregakuNitiShuku", "listYobibetuShiiregakuNitiShuku" + i);
        recMap.put("listShiireYoteiMeisaiGokeiKingaku", "listShiireYoteiMeisaiGokeiKingaku" + i);
        recMap.put("listEigyoshoMei", "listEigyoshoMei" + i);
        recMap.put("listShuryoFlg" , "listShuryoFlg" + i);
        return recMap;
    }
    
    private void assertForRecList_2_1(Mst091Form form) {
        int i = 0;
        assertEquals(1, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listShiireKbnCd" + i, rec.get("listShiireKbnCd"));
            assertEquals("listShiiresakiCd" + i, rec.get("listShiiresakiCd"));
            assertEquals("listEigyoshoCd" + i, rec.get("listEigyoshoCd"));
            assertEquals("2019/01/01", rec.get("listTekiyoKaisibi"));
            assertEquals("listShiiresakiMei" + i, rec.get("listShiiresakiMei"));
            assertEquals("listTani" + i, rec.get("listTani"));
            assertEquals("1,111,111,111", rec.get("listTanka"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuGetuyo"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuKayo"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuSuiyo"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuMokuyo"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuKinyo"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuDoyo"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuNitiShuku"));
            assertEquals("1,111,111,111", rec.get("listShiireYoteiMeisaiGokeiKingaku"));
            assertEquals("listEigyoshoMei" + i, rec.get("listEigyoshoMei"));
            assertEquals("listShuryoFlg" + i, rec.get("listShuryoFlg"));
            i++;
        }
    }    

    private void assertForRecList_2_2(Mst091Form form) {
        int i = 0;
        assertEquals(2, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listShiireKbnCd" + i, rec.get("listShiireKbnCd"));
            assertEquals("listShiiresakiCd" + i, rec.get("listShiiresakiCd"));
            assertEquals("listEigyoshoCd" + i, rec.get("listEigyoshoCd"));
            assertEquals("2019/01/01", rec.get("listTekiyoKaisibi"));
            assertEquals("listShiiresakiMei" + i, rec.get("listShiiresakiMei"));
            assertEquals("listTani" + i, rec.get("listTani"));
            assertEquals("1,111,111,111", rec.get("listTanka"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuGetuyo"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuKayo"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuSuiyo"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuMokuyo"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuKinyo"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuDoyo"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuNitiShuku"));
            assertEquals("1,111,111,111", rec.get("listShiireYoteiMeisaiGokeiKingaku"));
            assertEquals("listEigyoshoMei" + i, rec.get("listEigyoshoMei"));
            assertEquals("listShuryoFlg" + i, rec.get("listShuryoFlg"));
            i++;
        }
    }      

    private void assertForRecList_2_3(Mst091Form form) {
        int i = 0;
        assertEquals(0, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listShiireKbnCd" + i, rec.get("listShiireKbnCd"));
            assertEquals("listShiiresakiCd" + i, rec.get("listShiiresakiCd"));
            assertEquals("listEigyoshoCd" + i, rec.get("listEigyoshoCd"));
            assertEquals("2019/01/01",rec.get("listTekiyoKaisibi"));
            assertEquals("listShiiresakiMei" + i, rec.get("listShiiresakiMei"));
            assertEquals("listTani" + i, rec.get("listTani"));
            assertEquals("1,111,111,111", rec.get("listTanka"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuGetuyo"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuKayo"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuSuiyo"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuMokuyo"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuKinyo"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuDoyo"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuNitiShuku"));
            assertEquals("1,111,111,111", rec.get("listShiireYoteiMeisaiGokeiKingaku"));
            assertEquals("listEigyoshoMei" + i, rec.get("listEigyoshoMei"));
            assertEquals("listShuryoFlg" + i, rec.get("listShuryoFlg"));
            i++;
        }
    }
    
}
