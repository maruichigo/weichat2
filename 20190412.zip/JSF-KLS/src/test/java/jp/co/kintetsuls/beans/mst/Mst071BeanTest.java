/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.mst;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst071Form;
import jp.co.kintetsuls.utils.FlashUtil;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import org.junit.After;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import org.mockito.MockitoAnnotations;

/**
 * 品名マスタ画面
 *
 * @author 许博 (MBP)
 * @version 2019/3/15 新規作成
 */
public class Mst071BeanTest {
    
    // テストTarget
    @InjectMocks
    private Mst071Bean target;
    
    // Mockitoオブジェクト
    @Mock
    private FileBean fileBean;
    @Mock
    private AutoCompleteViewBean autoCompleteViewBean;
    @Mock
    private MasterInfoBean masterInfo;
    @Mock
    private MessagePropertyBean messageProperty;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosai;
    @Mock
    private SearchHelpBean searchHelpBean;
    @Mock
    private AuthorityConfBean authConfBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private MessagePropertyBean messagePropertyBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosaiBean;
    @Mock
    private ListCheckBean listCheckBean;
    @Mock
    private FlashUtil flashUtil;
    
    public Mst071BeanTest(){   
    }
    
    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }
    
    @After
    public void tearDown() {
    }
    
    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[not null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1 () throws IllegalAccessException, InvocationTargetException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst071Form mst071Form = new Mst071Form();
        
        // 前画面情報[not null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst071Form);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        // テスト実行
        Mst071Form form = new Mst071Form();
        target.setMst071Form(form);
        // 戻ってきた場合、再検索を実施する。
        target.init("","MST031_SCREEN",true);
        
        // 実施結果Outを取得
        form = target.getMst071Form();
        String title = target.getTITLE();
        String url = target.getUrl();
        BreadCrumbBean breadBean = target.getBreadBean();
        AutoCompleteViewBean autoCompleteViewBean = target.getAutoCompleteViewBean();
        AuthorityConfBean authorityConfBean  = target.getAuthConfBean();
        FileBean fileBean = target.getFileBean();
        MessagePropertyBean messagePropertyBean = target.getMessagePropertyBean();
        PageCommonBean pageCommonBean = target.getPageCommonBean();
        SearchHelpBean searchHelpBean = target.getSearchHelpBean();
        RirekiSyosaiBean rirekiSyosaiBean = target.getRirekiSyosai();
        ListCheckBean listCheckBean = target.getListCheckBean();
        Map<String, Object> rirekiSearchKey = target.getRirekiSearchKey();
        List<MessageModuleBean> msgList = target.getMsgList();
        target.setUrl(url);
        target.setBreadBean(breadBean);
        target.setAutoCompleteViewBean(autoCompleteViewBean);
        target.setAuthConfBean(authorityConfBean);
        target.setFileBean(fileBean);
        target.setMessagePropertyBean(messagePropertyBean);
        target.setPageCommonBean(pageCommonBean);
        target.setSearchHelpBean(searchHelpBean);
        target.setRirekiSyosai(rirekiSyosaiBean);
        target.setListCheckBean(listCheckBean);
        target.setRirekiSearchKey(rirekiSearchKey);
        target.setMsgList(msgList);
        
        // 実行時に渡すパラメータの検証
        assertEquals("mst071Form",keyCaptor_1.getValue());
        // 想定通りに再検索を実施する。
        assertEquals("search_mst071",keyCaptor_2.getValue());
    }
    
    // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[集約区分 = 1,　営業所コード = 001]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2() throws IllegalAccessException, InvocationTargetException,
            InstantiationException {
        
        // Mockitoオブジェクトの予想return値設定
        Mst071Form mst071Form = new Mst071Form();
        // 前回検索パラメータ[集約区分 = 1,　営業所コード = 001]
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        mst071Form.setConEigyoshoCd(conEigyoshoCd);
        mst071Form.setConShuyakuKbn("1");
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        // 前画面パラメータ[集約区分 = 1,　営業所コード = 001]
        flash.put("mst071Form", mst071Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);        

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        // テスト実行
        Mst071Form form = new Mst071Form();
        target.setMst071Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //　実施結果Outを取得
        form = target.getMst071Form();

        //　想定通りに再検索を実施する。
        assertEquals("search_mst071",keyCaptor_2.getValue());
        assertEquals("001",form.getConEigyoshoCd().getValue());
        assertEquals("1",form.getConShuyakuKbn());
    }
    
    // init_正常_初期処理_1-2_1
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[集約区分 = 1,　営業所コード = 001]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2_1() throws IllegalAccessException, InvocationTargetException,
            InstantiationException {

        // Mockitoオブジェクトの予想return値設定
        Mst071Form mst071Form = new Mst071Form();
        // 前回検索パラメータ[集約区分 = 1,　営業所コード = 001]
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        mst071Form.setConEigyoshoCd(conEigyoshoCd);
        mst071Form.setConShuyakuKbn("1");
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        // 前回検索パラメータ[集約区分 = 1,　営業所コード = 001]
        flash.put("mst071Form", null);
        when(pageCommonBean.getPageParam()).thenReturn(flash);        

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst071Form form = new Mst071Form();
        target.setMst071Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst071Form();

        //想定通りに再検索を実施する。
        assertEquals(null,form.getConSakujoNomiKensaku());
    } 
    
    // init_正常_初期処理_1-3
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        // 前画面情報[null]
        doThrow(IllegalAccessException.class).when(pageCommonBean).getPageInfo(keyCaptor_1.capture());

        // テスト実行
        Mst071Form form = new Mst071Form();
        target.setMst071Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        // 実施結果Outを取得
        form = target.getMst071Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst071Form",keyCaptor_1.getValue());
        // 想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null,form.getSearchResult());
    }
    
    // search_正常_検索処理_2-1
    //
    // -------------------テスト条件--------------------------
    // 集約コード検索結果一覧取得
    // 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 集約コード検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=0;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // テスト実行
        Mst071Form form = new Mst071Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        AutoCompOptionBean conShuyakuCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        conShuyakuCd.setValue("0000000001");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShuyakuCd(conShuyakuCd);
        form.setConShuyakuKbn("1");
        form.setConSakujoNomiKensaku(null);
        target.setMst071Form(form);
        target.search();

        // 実施結果Outを取得
        form = target.getMst071Form();

        // 実行時に渡すパラメータの検証
        assertEquals("001", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("0000000001", paramsCaptor_1.getValue().get("conShuyakuCd"));
        assertEquals("1", paramsCaptor_1.getValue().get("conShuyakuKbn"));
        assertEquals("mst071-get-shuyakucd-detail", functionCodeCaptor_2.getValue());
        //想定通りに仕向地名マスタ一覧を表示されること
        assertForRecList_2_1(form);
        assertEquals(false, form.isBtnEditeDisabled());
    } 
    
    // search_正常_検索処理_2-1
    //
    // -------------------テスト条件--------------------------
    // 集約コード検索結果一覧取得
    // 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_1_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 集約コード検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=0;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // テスト実行
        Mst071Form form = new Mst071Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        AutoCompOptionBean conShuyakuCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        conShuyakuCd.setValue("0000000001");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShuyakuCd(conShuyakuCd);
        form.setConShuyakuKbn("1");
        String[] strArray = {"1"};
        form.setConSakujoNomiKensaku(strArray);
        target.setMst071Form(form);
        target.search();

        // 実施結果Outを取得
        form = target.getMst071Form();

        // 実行時に渡すパラメータの検証
        assertEquals("001", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("0000000001", paramsCaptor_1.getValue().get("conShuyakuCd"));
        assertEquals("1", paramsCaptor_1.getValue().get("conShuyakuKbn"));
        assertEquals("mst071-get-shuyakucd-detail", functionCodeCaptor_2.getValue());
        //想定通りに仕向地名マスタ一覧を表示されること
        assertForRecList_2_1(form);
        assertEquals(true, form.isBtnEditeDisabled());
    } 
    
    // search_正常_検索処理_2-2
    //
    // -------------------テスト条件--------------------------
    // 集約コード検索結果一覧取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 集約コード検索結果一覧取得 取得件数 = 2
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=1;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst071Form form = new Mst071Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShuyakuKbn("1");
        target.setMst071Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst071Form();

        // 実行時に渡すパラメータの検証
        assertEquals("001", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("1", paramsCaptor_1.getValue().get("conShuyakuKbn"));
        assertEquals("mst071-get-shuyakucd-detail", functionCodeCaptor_2.getValue());
        //想定通りに仕向地名マスタ一覧を表示されること
        assertForRecList_2_2(form);
    }
    
    // search_異常_検索処理_2-3
    //
    // -------------------テスト条件--------------------------
    // 集約コード検索結果一覧取得 取得件数 = 0
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 集約コード検索結果一覧取得 取得件数 = 0
        List<Map<String, String>> result = new ArrayList<>();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // テスト実行
        Mst071Form form = new Mst071Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        AutoCompOptionBean conShuyakuCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        conShuyakuCd.setValue("0000000001");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShuyakuCd(conShuyakuCd);
        form.setConShuyakuKbn("1");
        target.setMst071Form(form);
        target.search();

        // 実施結果Outを取得
        form = target.getMst071Form();

        // 実行時に渡すパラメータの検証
        assertEquals("001", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("0000000001", paramsCaptor_1.getValue().get("conShuyakuCd"));
        assertEquals("1", paramsCaptor_1.getValue().get("conShuyakuKbn"));
        assertEquals("mst071-get-shuyakucd-detail", functionCodeCaptor_2.getValue());
        //想定通りに・一覧は表示しない（ヘッダーのみ） 
        //想定通りに ・ファンクションボタンは表示（検索前と同じ） 
        assertForRecList_2_3(form);
    }
    
    // getRecordCount_正常_件数取得処理_2-4
    //
    // -------------------テスト条件--------------------------
    // 集約コード検索件数取得
    // -----------------------------------------------------
    @Test
    public void getRecordCount_異常_件数取得処理_2_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 品名検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // テスト実行       
        Mst071Form form = new Mst071Form(); 
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShuyakuKbn("1");
        target.setMst071Form(form);
        target.getRecordCount(true);

        // 実施結果Outを取得
        form = target.getMst071Form();

        // 実行時に渡すパラメータの検証
        assertEquals("001", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("1", paramsCaptor_1.getValue().get("conShuyakuKbn"));
        assertEquals("mst071-get-shuyakucd-kensu",functionCodeCaptor_2.getValue());
        // 想定通りに正常にCountを実施されること
    }
    
    // getRecordCount_正常_件数取得処理_2-4_2
    //
    // -------------------テスト条件--------------------------
    // 集約コード検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_4_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 集約コード検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // テスト実行
        Mst071Form form = new Mst071Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        AutoCompOptionBean conShuyakuCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        conShuyakuCd.setValue("0000000001");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShuyakuCd(conShuyakuCd);
        form.setConShuyakuKbn("1");
        target.setMst071Form(form);
        target.getRecordCount(true);

        // 実施結果Outを取得
        form = target.getMst071Form();

        // 実行時に渡すパラメータの検証
        assertEquals("001", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("0000000001", paramsCaptor_1.getValue().get("conShuyakuCd"));
        assertEquals("1", paramsCaptor_1.getValue().get("conShuyakuKbn"));
        assertEquals("mst071-get-shuyakucd-kensu", functionCodeCaptor_2.getValue());
        // 想定通りに正常にCountを実施されること
    }
    
    // search_異常_件数取得処理_2_3_1
    //
    // -------------------テスト条件--------------------------
    // 集約コード検索件数取得
    // -----------------------------------------------------
    @Test
    public void search_異常_件数取得処理_2_3_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 集約コード検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        doThrow(IOException.class).when(pageCommonBean).getDBInfo(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture());

        // テスト実行
        Mst071Form form = new Mst071Form();
        
        target.setMst071Form(form);
        target.search();

        // 実施結果Outを取得
        form = target.getMst071Form();

        // 実行時に渡すパラメータの検証
        
        assertEquals("mst071-get-shuyakucd-detail",functionCodeCaptor_2.getValue());
        // 想定通りに正常にCountを実施されること
    }
    
    // eigyoshoCheck_正常_件数取得処理_2-4
    //
    // -------------------テスト条件--------------------------
    // 集約コード検索件数取得
    // -----------------------------------------------------
    @Test
    public void eigyoshoCheck_異常_件数取得処理_2_4_2 () throws IllegalAccessException, InvocationTargetException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());

        // テスト実行       
        Mst071Form form = new Mst071Form(); 
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue(null);
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShuyakuKbn("1");
        target.setMst071Form(form);
        target.eigyoshoCheck();

        // 実施結果Outを取得
        form = target.getMst071Form();

        //　想定通りにエラーが発生。（メッセージID：MSTE0045）
//        assertEquals("ERROR",levelCaptor_3.getValue());
//        assertEquals("MSTE0045",summaryCaptor_4.getValue());   
    }
    
    // eigyoshoCheck_正常_件数取得処理_2-4-3
    //
    // -------------------テスト条件--------------------------
    // 集約コード検索件数取得
    // -----------------------------------------------------
    @Test
    public void eigyoshoCheck_異常_件数取得処理_2_4_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());

        // テスト実行       
        Mst071Form form = new Mst071Form(); 
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShuyakuKbn("1");
        target.setMst071Form(form);
        target.eigyoshoCheck();

        // 実施結果Outを取得
        form = target.getMst071Form();

        //　想定通りにエラーが発生。（メッセージID：MSTE0045）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("MSTE0045",summaryCaptor_4.getValue());  
    }
    
    // eigyoshoCheck_正常_件数取得処理_2-4-3
    //
    // -------------------テスト条件--------------------------
    // 集約コード検索件数取得
    // -----------------------------------------------------
    @Test
    public void eigyoshoCheck_異常_件数取得処理_2_4_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());

        // テスト実行       
        Mst071Form form = new Mst071Form(); 
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShuyakuKbn("2");
        target.setMst071Form(form);
        target.eigyoshoCheck();

        // 実施結果Outを取得
        form = target.getMst071Form();

        //　想定通りにエラーが発生。（メッセージID：MSTE0045）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("MSTE0046",summaryCaptor_4.getValue());  
    }
    
    // clear_正常_クリア処理_3-1
    //
    // -------------------テスト条件--------------------------
    // 検索条件と検索結果がある
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_1 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst071Form form = new Mst071Form();
        // 集約コード検索条件と検索結果がある
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShuyakuKbn("1");
        target.setMst071Form(form);
        target.clear();

        // 実施結果Outを取得
        form = target.getMst071Form();

        // 想定通りに正常にClearを実施されること
        assertEquals(null, form.getConEigyoshoCd());
        assertEquals(null, form.getConShuyakuKbn());
    }
    
    // clear_正常_クリア処理_3-2
    //
    // -------------------テスト条件--------------------------
    // 検索条件がある、検索結果がない
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_2 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst071Form form = new Mst071Form();
        target.setMst071Form(form);
        target.clear();

        // 実施結果Outを取得
        form = target.getMst071Form();

        // 想定通りに正常にClearを実施されること
        assertEquals(null, form.getConEigyoshoCd());
        assertEquals(null, form.getConShuyakuKbn());
    }
    
    // getHeader_正常_ダウンロード_4-1
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void getHeader_正常_ダウンロード_4_1 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst071Form form = new Mst071Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShuyakuKbn("1");
        target.setMst071Form(form);
        List<CSVDto> dto = target.getHeader();

        // 実施結果Outを取得
        form = target.getMst071Form();

        // 実行時に渡すパラメータの検証
        // 想定通りに正常にCVSのHeaderを設定されること
        assertEquals("001", form.getConEigyoshoCd().getValue());
        assertEquals("1", form.getConShuyakuKbn());
        assertEquals("集約コード",dto.get(0).getTitle());
        assertEquals("listShuyakuCd",dto.get(0).getName());
        assertEquals("集約コード名称",dto.get(1).getTitle());
        assertEquals("listShuyakuCdMei",dto.get(1).getName());
        assertEquals("備考",dto.get(2).getTitle());
        assertEquals("listBiko",dto.get(2).getName());
        assertEquals("設定数",dto.get(3).getTitle());
        assertEquals("listSetteisu",dto.get(3).getName());
    }
    
    // beforeDown_正常_ダウンロード_4-2
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=2件
    // -----------------------------------------------------
    @Test
    public void beforeDown_正常_ダウンロード_4_2 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst071Form form = new Mst071Form();
        target.setMst071Form(form);
        try {
            target.beforeDown("testComment");
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(Mst071BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        //実施結果Outを取得
        form = target.getMst071Form();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にダウンロード理由を記録すること
        assertEquals(null,form.getConEigyoshoCd());
    }
    
    // upload_正常_アップロード_5_1
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void upload_正常_アップロード_5_1() throws IllegalAccessException, InvocationTargetException {
        ArgumentCaptor<String> urlCaptor_1 = ArgumentCaptor.forClass(String.class);
        //テスト実行
        Mst071Form form = new Mst071Form();
        Flash flash = new FlashKls();
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        when(flashUtil.getPageParam()).thenReturn(flash);
        target.upload();
    }
    
    // update_異常_更新処理_新規登録_11-1
    //
    // -------------------テスト条件--------------------------
    // 登録処理で集約区分、集約コード、営業所コードすべてが同一のレコードがある[MSTE0047]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_新規登録_11_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 登録処理で集約区分、集約コード、営業所コードすべてが同一のレコードがある[MSTE0047]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0047", "");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());

        //テスト実行
        Mst071Form form = new Mst071Form();
        when((Mst071Form) pageCommonBean.getPageInfo("mst071Form")).thenReturn(form);

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShuyakuKbn("1");
        form.setSelectedSearchResult(result);
        target.setMst071Form(form);
        target.update();

        // 実施結果Outを取得
        form = target.getMst071Form();
        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("001",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("listShuyakuCd0",paramsCaptor_1_Param.get("listShuyakuCd"));
        assertEquals("listShuyakuCdMei0",paramsCaptor_1_Param.get("listShuyakuCdMei"));
        assertEquals("listBiko0",paramsCaptor_1_Param.get("listBiko"));
        assertEquals("listSetteisu0",paramsCaptor_1_Param.get("listSetteisu"));
        assertEquals("listDataVersion0",paramsCaptor_1_Param.get("listDataVersion"));
        assertEquals("mst071-insert-update-check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：MSTE0047）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("MSTE0047",summaryCaptor_4.getValue());
    }
    
    // update_正常_更新処理_新規登録_11-2
    //
    // -------------------テスト条件--------------------------
    // 集約区分、集約コード、営業所コードの組み合わせが、集約コードマスタに存在していない
    // -----------------------------------------------------
    @Test
    public void update_正常_更新処理_新規登録_11_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 集約区分、集約コード、営業所コードの組み合わせが、集約コードマスタに存在していない
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        // 品名検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        // テスト実行
        Mst071Form form = new Mst071Form();
        when((Mst071Form) pageCommonBean.getPageInfo("mst071Form")).thenReturn(form);
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }        
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShuyakuKbn("1");
        form.setSelectedSearchResult(result);
        target.setMst071Form(form);
        target.update();
        // 実施結果Outを取得
        form = target.getMst071Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("001",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("listShuyakuCd0",paramsCaptor_1_Param.get("listShuyakuCd"));
        assertEquals("listShuyakuCdMei0",paramsCaptor_1_Param.get("listShuyakuCdMei"));
        assertEquals("listBiko0",paramsCaptor_1_Param.get("listBiko"));
        assertEquals("listSetteisu0",paramsCaptor_1_Param.get("listSetteisu"));
        assertEquals("listDataVersion0",paramsCaptor_1_Param.get("listDataVersion"));
        assertEquals("mst071-insert-update",functionCodeCaptor_2.getValue());
        // 想定通りに正常終了メッセージ（メッセージID：COMI0007）を表示されること
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0007",summaryCaptor_4.getValue());
        assertEquals("更新",detailCaptor_5.getValue());
    } 
    
    // update_正常_更新処理_新規登録_11-2
    //
    // -------------------テスト条件--------------------------
    // 集約区分、集約コード、営業所コードの組み合わせが、集約コードマスタに存在していない
    // -----------------------------------------------------
    @Test
    public void update_正常_更新処理_新規登録_11_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 集約区分、集約コード、営業所コードの組み合わせが、集約コードマスタに存在していない
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        // 品名検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        // テスト実行
        Mst071Form form = new Mst071Form();
        when((Mst071Form) pageCommonBean.getPageInfo("mst071Form")).thenReturn(form);
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }        
        AutoCompOptionBean conShuyakuCd = new AutoCompOptionBean();
        conShuyakuCd.setValue("0000000001");
        form.setConShuyakuCd(conShuyakuCd);
        form.setConShuyakuKbn("2");
        form.setSelectedSearchResult(result);
        target.setMst071Form(form);
        target.update();
        // 実施結果Outを取得
        form = target.getMst071Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("DEF",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("listShuyakuCd0",paramsCaptor_1_Param.get("listShuyakuCd"));
        assertEquals("listShuyakuCdMei0",paramsCaptor_1_Param.get("listShuyakuCdMei"));
        assertEquals("listBiko0",paramsCaptor_1_Param.get("listBiko"));
        assertEquals("listSetteisu0",paramsCaptor_1_Param.get("listSetteisu"));
        assertEquals("listDataVersion0",paramsCaptor_1_Param.get("listDataVersion"));
        assertEquals("mst071-insert-update",functionCodeCaptor_2.getValue());
        //想定通りに正常終了メッセージ（メッセージID：COMI0007）を表示されること
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0007",summaryCaptor_4.getValue());
        assertEquals("更新",detailCaptor_5.getValue());
    }
    
    // update_異常_更新処理_更新登録_11-4
    //
    // -------------------テスト条件--------------------------
    // 更新処理で集約区分、集約コード、営業所コードすべてが同一のレコードがない[MSTE0048]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_11_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 更新処理で集約区分、集約コード、営業所コードすべてが同一のレコードがない[MSTE0048]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0048", "");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());

        // テスト実行
        Mst071Form form = new Mst071Form();
        when((Mst071Form) pageCommonBean.getPageInfo("mst071Form")).thenReturn(form);
        
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShuyakuKbn("1");
        form.setSelectedSearchResult(result);
        target.setMst071Form(form);
        target.update();

        // 実施結果Outを取得
        form = target.getMst071Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("001",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("listShuyakuCd0",paramsCaptor_1_Param.get("listShuyakuCd"));
        assertEquals("listShuyakuCdMei0",paramsCaptor_1_Param.get("listShuyakuCdMei"));
        assertEquals("listBiko0",paramsCaptor_1_Param.get("listBiko"));
        assertEquals("listSetteisu0",paramsCaptor_1_Param.get("listSetteisu"));
        assertEquals("listDataVersion0",paramsCaptor_1_Param.get("listDataVersion"));
        assertEquals("mst071-insert-update-check",functionCodeCaptor_2.getValue());
        //　想定通りにエラーが発生。（メッセージID：MSTE0048）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("MSTE0048",summaryCaptor_4.getValue());
}    
    
    // update_正常_更新処理_更新登録_11-5
    //
    // -------------------テスト条件--------------------------
    // 集約区分、集約コード、営業所コードの組み合わせが、集約コードマスタに存在しています
    // -----------------------------------------------------
    @Test
    public void update_正常_更新処理_更新登録_11_5 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 営業所コード、顧客コード、品名コードの組み合わせが、品名マスタに存在しています
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4
                .capture(),detailCaptor_5.capture());        

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        // 品名検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        
        //テスト実行
        Mst071Form form = new Mst071Form();
        when((Mst071Form) pageCommonBean.getPageInfo("mst071Form")).thenReturn(form);
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }        
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShuyakuKbn("1");
        form.setSelectedSearchResult(result);
        target.setMst071Form(form);
        target.update();
        // 実施結果Outを取得
        form = target.getMst071Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("001",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("listShuyakuCd0",paramsCaptor_1_Param.get("listShuyakuCd"));
        assertEquals("listShuyakuCdMei0",paramsCaptor_1_Param.get("listShuyakuCdMei"));
        assertEquals("listBiko0",paramsCaptor_1_Param.get("listBiko"));
        assertEquals("listSetteisu0",paramsCaptor_1_Param.get("listSetteisu"));
        assertEquals("listDataVersion0",paramsCaptor_1_Param.get("listDataVersion"));
        assertEquals("mst071-insert-update",functionCodeCaptor_2.getValue());
        // 想定通りに正常終了メッセージ（メッセージID：COMI0007）を表示されること
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0007",summaryCaptor_4.getValue());
        assertEquals("更新",detailCaptor_5.getValue());
    }  
    
    // update_異常_更新処理_更新登録_11-6
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_11_6 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        // テスト実行
        Mst071Form form = new Mst071Form();
        // 行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        form.setSelectedSearchResult(result);
        target.setMst071Form(form);
        target.update();

        // 実施結果Outを取得
        form = target.getMst071Form();

        // 想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0029",summaryCaptor_2.getValue());
    }
    
    // update_異常_更新処理_更新登録_11-7
    //
    // -------------------テスト条件--------------------------
    // 一覧条件入力チェック：集約コード名称 == NULL
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_11_7 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Boolean> datasCaptor_3 = ArgumentCaptor.forClass(Boolean.class);
        ArgumentCaptor<List> checksCaptor_4 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<List> checksCaptor_5 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean2 = new MessageModuleBean();
        List<MessageModuleBean> msgList = new ArrayList<>();
        msgList.add(messageModuleBean2);

        when(listCheckBean.check(checksCaptor_4.capture(), checksCaptor_5.capture(), datasCaptor_3.capture()))
                .thenReturn(msgList); 

        // テスト実行
        Mst071Form form = new Mst071Form();
        // 行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        AutoCompOptionBean conShuyakuCd = new AutoCompOptionBean();
        conShuyakuCd.setValue("0000000001");
        form.setConEigyoshoCd(conShuyakuCd);
        form.setConShuyakuKbn("2");
        target.setMst071Form(form);
        target.update();

        // 実施結果Outを取得
        form = target.getMst071Form();
}   
    
    // delRows_正常_品名マスタ削除処理_12-1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 1
    // 営業所コード、顧客コード、品名コードの組み合わせが、品名マスタに存在している
    // -----------------------------------------------------
    @Test
    public void delRows_正常_品名マスタ削除処理_12_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture());
        
        // テスト実行
        Mst071Form form = new Mst071Form();
        // 行選択チェック選択 = 1
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        
        form.setSearchResult(result);
        form.setSelectedSearchResult(result);
        target.setMst071Form(form);
        target.delRows(result);

        // 実施結果Outを取得
        form = target.getMst071Form();

        // 実行時に渡すパラメータの検証
        // 想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること仕向地名マスタ削除処理を行う。
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0004",summaryCaptor_4.getValue());
        assertEquals("削除",detailCaptor_5.getValue());
    }
    
    // delRows_正常_品名マスタ削除処理_12-2
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 2
    // 営業所コード、顧客コード、品名コードの組み合わせが、品名マスタに存在している
    // -----------------------------------------------------
    @Test
    public void delRows_正常_仕向地名マスタ削除処理_12_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture());
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        
        // テスト実行
        Mst071Form form = new Mst071Form();
        // 行選択チェック選択 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShuyakuKbn("1");
        form.setSearchResult(result);
        form.setSelectedSearchResult(result);
        target.setMst071Form(form);
        target.delRows(result);

        // 実施結果Outを取得
        form = target.getMst071Form();

        //想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること仕向地名マスタ削除処理を行う。
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0004",summaryCaptor_4.getValue());
        assertEquals("削除",detailCaptor_5.getValue());
    }  
    
    // delRows_異常_品名マスタ削除処理_12-3
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // 営業所コード、顧客コード、品名コードの組み合わせが、品名マスタに存在している
    // -----------------------------------------------------
    @Test
    public void delRows_異常_仕向地名マスタ削除処理_12_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        // テスト実行
        Mst071Form form = new Mst071Form();
        // 行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        form.setSelectedSearchResult(result);
        target.setMst071Form(form);
        target.delRows(result);

        // 実施結果Outを取得
        form = target.getMst071Form();

        // 想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0029",summaryCaptor_2.getValue());
    } 
    
    // delRows_異常_品名マスタ削除処理_12-4
    //
    // -------------------テスト条件--------------------------
    // 営業所コード、顧客コード、品名コードの組み合わせが、品名マスタに存在しない
    // -----------------------------------------------------
    @Test
    public void delRows_異常_仕向地名マスタ削除処理_12_4 () throws IllegalAccessException, InvocationTargetException {

      // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 営業所コード、顧客コード、品名コードの組み合わせが、品名マスタに存在しない[MSTE0099]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0049", "");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        
        //テスト実行
        Mst071Form form = new Mst071Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst071Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst071Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listShuyakuCd0",paramsCaptor_1_Param.get("listShuyakuCd"));
        assertEquals("listShuyakuCdMei0",paramsCaptor_1_Param.get("listShuyakuCdMei"));
        assertEquals("listBiko0",paramsCaptor_1_Param.get("listBiko"));
        assertEquals("listSetteisu0",paramsCaptor_1_Param.get("listSetteisu"));
        assertEquals("listDataVersion0",paramsCaptor_1_Param.get("listDataVersion"));
        assertEquals("mst071-delete-exist",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：MSTE0049）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("MSTE0049",summaryCaptor_2.getValue());
    }
    
    // rirekiIchiran_正常_更新履歴コンテキストメニュー_13-1
    //
    // -------------------テスト条件--------------------------
    // 正常に取得された場合
    // -----------------------------------------------------
    @Test
    public void rirekiIchiran_正常_更新履歴コンテキストメニュー_13_1 () throws IllegalAccessException, 
            InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> titleFlgCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> searchKeyCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(rirekiSyosai).searchList(titleFlgCaptor_1.capture(),functionCodeCaptor_2.capture()
                ,searchKeyCaptor_3.capture());
        // テスト実行
        Mst071Form form = new Mst071Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setSelectedSearchResult(result);
        target.setMst071Form(form);
        target.rirekiIchiran();

        // 実施結果Outを取得
        form = target.getMst071Form();

        // 想定通りに履歴を表示する。
        assertEquals("2",titleFlgCaptor_1.getValue());
        assertEquals("MST071_GET_SHUYAKU_RIREKI",functionCodeCaptor_2.getValue());
        assertEquals("listShuyakuCd0",searchKeyCaptor_3.getValue().get("listShuyakuCd"));
        assertEquals("001",searchKeyCaptor_3.getValue().get("listEigyoshoCd"));
    }
    
    // searchChange_正常_補充ケース_14-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void searchChange_正常_補充ケース_14_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst071Form form = new Mst071Form();
        target.setMst071Form(form);
        target.searchChange();

        //実施結果Outを取得
        form = target.getMst071Form();

    }

    // menuClick_正常_補充ケース_14-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_14_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst071Form form = new Mst071Form();
        target.setMst071Form(form);
        target.menuClick("","");

        //実施結果Outを取得
        form = target.getMst071Form();

    }

    // menuClick_正常_補充ケース_14-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_14_2_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(1);

        //テスト実行
        Mst071Form form = new Mst071Form();
        target.setMst071Form(form);
        target.menuClick("","");

        //実施結果Outを取得
        form = target.getMst071Form();

    }    
    
    // breadClumClick_正常_補充ケース_14-3
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_14_3 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst071Form form = new Mst071Form();
        target.setMst071Form(form);
        target.breadClumClick("",0);

        //実施結果Outを取得
        form = target.getMst071Form();

    }

    // breadClumClick_正常_補充ケース_14-3_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_14_3_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(0);        
        
        //テスト実行
        Mst071Form form = new Mst071Form();
        target.setMst071Form(form);
        target.breadClumClick("",0);

        //実施結果Outを取得
        form = target.getMst071Form();

    }    
    
    // logoutClick_正常_補充ケース_14-4
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void logoutClick_正常_補充ケース_14_4 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst071Form form = new Mst071Form();
        target.setMst071Form(form);
        target.logoutClick();

        //実施結果Outを取得
        form = target.getMst071Form();

    }

    // delRowsFunc_正常_補充ケース_14-5
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void delRowsFunc_正常_補充ケース_14_5 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst071Form form = new Mst071Form();
        target.setMst071Form(form);
        target.delRowsFunc();

        //実施結果Outを取得
        form = target.getMst071Form();
    }
    
    // getSearchResult_正常_補充ケース_14_6-2
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=2件
    // -----------------------------------------------------
    @Test
    public void getSearchResult_正常_補充ケース_14_6 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst071Form form = new Mst071Form();
        target.setMst071Form(form);
        target.getSearchResult();

        // 実施結果Outを取得
        form = target.getMst071Form();

        // 実行時に渡すパラメータの検証
        // 想定通りに正常にダウンロード理由を記録すること
        assertEquals(null,form.getConEigyoshoCd());
    }
    
    private Map<String, String> createRecMapFor_1_1(int i) {
        Map recMap = new HashMap();
        recMap.put("listEigyoshoCd", "listEigyoshoCd" + i);
        recMap.put("listShuyakuCd", "listShuyakuCd" + i);
        recMap.put("listShuyakuCdMei", "listShuyakuCdMei" + i);
        recMap.put("listBiko", "listBiko" + i);
        recMap.put("listSetteisu", "listSetteisu" + i);
        recMap.put("listDataVersion", "listDataVersion" + i);
        return recMap;
    }
    
    private Map<String, Object> createRecMapFor_11_1(int i) {
        Map recMap = new HashMap();
        recMap.put("listEigyoshoCd", "listEigyoshoCd" + i);
        recMap.put("listShuyakuCd", "listShuyakuCd" + i);
        recMap.put("listShuyakuCdMei", "listShuyakuCdMei" + i);
        recMap.put("listBiko", "listBiko" + i);
        recMap.put("listSetteisu", "listSetteisu" + i);
        recMap.put("listDataVersion", "listDataVersion" + i);
        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }
    
    private void assertForRecList_2_1(Mst071Form form) {
        int i = 0;
        assertEquals(1, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listEigyoshoCd" + i, rec.get("listEigyoshoCd"));
            assertEquals("listShuyakuCd" + i, rec.get("listShuyakuCd"));
            assertEquals("listShuyakuCdMei" + i, rec.get("listShuyakuCdMei"));
            assertEquals("listBiko" + i, rec.get("listBiko"));
            assertEquals("listSetteisu" + i, rec.get("listSetteisu"));
            assertEquals("listDataVersion" + i, rec.get("listDataVersion"));
            i++;
        }
    } 
    
    private void assertForRecList_2_2(Mst071Form form) {
        int i = 0;
        assertEquals(2, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listEigyoshoCd" + i, rec.get("listEigyoshoCd"));
            assertEquals("listShuyakuCd" + i, rec.get("listShuyakuCd"));
            assertEquals("listShuyakuCdMei" + i, rec.get("listShuyakuCdMei"));
            assertEquals("listBiko" + i, rec.get("listBiko"));
            assertEquals("listSetteisu" + i, rec.get("listSetteisu"));
            assertEquals("listDataVersion" + i, rec.get("listDataVersion"));
            i++;
        }
    }
    
    private void assertForRecList_2_3(Mst071Form form) {
        int i = 0;
        assertEquals(0, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listEigyoshoCd" + i, rec.get("listEigyoshoCd"));
            assertEquals("listShuyakuCd" + i, rec.get("listShuyakuCd"));
            assertEquals("listShuyakuCdMei" + i, rec.get("listShuyakuCdMei"));
            assertEquals("listBiko" + i, rec.get("listBiko"));
            assertEquals("listSetteisu" + i, rec.get("listSetteisu"));
            assertEquals("listDataVersion" + i, rec.get("listDataVersion"));
            i++;
        }
    }
}
