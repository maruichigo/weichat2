/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import java.io.IOException;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.KbnBean;
import jp.co.kintetsuls.beans.common.KbnModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.beans.common.SystemMasterBean;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.forms.mst.Mst461Form;
import jp.co.kintetsuls.utils.DateUtils;
import jp.co.kintetsuls.utils.FlashUtil;
import jp.co.kintetsuls.utils.StrUtils;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

/**
 * 営業日カレンダー画面
 *
 * @author 曾鳳(MBP)
 * @version 2019/4/12 新規作成
 */
public class Mst461BeanTest {

    // テストTarget
    @InjectMocks
    private Mst461Bean target;

    // Mockitoオブジェクト
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private AuthorityConfBean authConfBean;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private SystemMasterBean systemMasterBean;
    @Mock
    private KbnBean kbnBean;
    @Mock
    private FileBean fileBean;
    @Mock
    private SearchHelpBean searchHelpBean;
    @Mock
    private MessagePropertyBean messagePropertyBean;
    @Mock
    FlashUtil flashUtil;
    
    public Mst461BeanTest() {
    }

    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() {
    }

    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 戻ってきた場合(backFlg=true,preForm=dem012Form)
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1 () {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> sysCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String[]> sysCaptor_2 = ArgumentCaptor.forClass(String[].class);

        // Mockitoオブジェクトの予想return値設定
        Mst461Form mst461Form = new Mst461Form();
        // 年月
        mst461Form.setConKensakuNengetsu("2019/05");
        
        // 売上締日 = 3
        String uriageShimebi = "3";
        // 入金締日 = 4
        String nyukinShimebi = "4";
        // 設定済一覧前 = 1
        String setteisumiIchiranMae = "1";
        // 設定済一覧後 = 3
        String setteisumiIchiranUshiro = "3";
        // カレンダー警告日数 = 20
        String calendarKeikokuNissu = "20";
        
        when(systemMasterBean.getSysValByCdAndKanriGroup(
                sysCaptor_1.capture(), sysCaptor_2.capture()))
                .thenReturn(uriageShimebi, nyukinShimebi, setteisumiIchiranMae,
                        setteisumiIchiranUshiro, calendarKeikokuNissu);

        //前画面情報[not null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst461Form);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        target.setMst461Form(mst461Form);
        // 戻ってきた場合、再検索を実施する。
        target.init("","DEM012_SCREEN",true);

        //実施結果Outを取得
        String title = target.getTITLE();
        
        // 実行時に渡すパラメータの検証
        assertEquals("mst461Form", keyCaptor_1.getValue());
        // 売上締日
        assertEquals("uriage_shimebi", sysCaptor_1.getAllValues().get(0));
        assertEquals("mst461", sysCaptor_2.getAllValues().get(0));
        assertEquals("system", sysCaptor_2.getAllValues().get(1));
        // 入金締日
        assertEquals("nyukin_shimebi", sysCaptor_1.getAllValues().get(1));
        assertEquals("mst461", sysCaptor_2.getAllValues().get(2));
        assertEquals("system", sysCaptor_2.getAllValues().get(3));
        // 設定済一覧前
        assertEquals("setteisumi_ichiran_mae", sysCaptor_1.getAllValues().get(2));
        assertEquals("mst461", sysCaptor_2.getAllValues().get(4));
        assertEquals("system", sysCaptor_2.getAllValues().get(5));
        // 設定済一覧後
        assertEquals("setteisumi_ichiran_ushiro", sysCaptor_1.getAllValues().get(3));
        assertEquals("mst461", sysCaptor_2.getAllValues().get(6));
        assertEquals("system", sysCaptor_2.getAllValues().get(7));
        // カレンダー警告日数
        assertEquals("calendar_keikoku_nissu", sysCaptor_1.getAllValues().get(4));
        assertEquals("mst461", sysCaptor_2.getAllValues().get(8));
        assertEquals("system", sysCaptor_2.getAllValues().get(9));
        //想定通りに再検索を実施する。
        assertEquals("search_mst461", keyCaptor_2.getValue());
        assertEquals("営業日カレンダー", title);
    }

    // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 進んできた場合
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2 () {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> sysCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String[]> sysCaptor_2 = ArgumentCaptor.forClass(String[].class);

        // 売上締日 = 3
        String uriageShimebi = "3";
        // 入金締日 = 4
        String nyukinShimebi = "4";
        // 設定済一覧前 = 1
        String setteisumiIchiranMae = "1";
        // 設定済一覧後 = 3
        String setteisumiIchiranUshiro = "3";
        // カレンダー警告日数 = 20
        String calendarKeikokuNissu = "20";
        
        when(systemMasterBean.getSysValByCdAndKanriGroup(
                sysCaptor_1.capture(), sysCaptor_2.capture()))
                .thenReturn(uriageShimebi, nyukinShimebi, setteisumiIchiranMae,
                        setteisumiIchiranUshiro, calendarKeikokuNissu);

        //前画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(null);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst461Form mst461Form = new Mst461Form();
        target.setMst461Form(mst461Form);
        // 進んできた場合、再検索を実施する。
        target.init("","TOP011_SCREEN",false);

        //実施結果Outを取得
        String title = target.getTITLE();
        
        // 実行時に渡すパラメータの検証
        assertEquals("mst461Form", keyCaptor_1.getValue());
        // 売上締日
        assertEquals("uriage_shimebi", sysCaptor_1.getAllValues().get(0));
        assertEquals("mst461", sysCaptor_2.getAllValues().get(0));
        assertEquals("system", sysCaptor_2.getAllValues().get(1));
        // 入金締日
        assertEquals("nyukin_shimebi", sysCaptor_1.getAllValues().get(1));
        assertEquals("mst461", sysCaptor_2.getAllValues().get(2));
        assertEquals("system", sysCaptor_2.getAllValues().get(3));
        // 設定済一覧前
        assertEquals("setteisumi_ichiran_mae", sysCaptor_1.getAllValues().get(2));
        assertEquals("mst461", sysCaptor_2.getAllValues().get(4));
        assertEquals("system", sysCaptor_2.getAllValues().get(5));
        // 設定済一覧後
        assertEquals("setteisumi_ichiran_ushiro", sysCaptor_1.getAllValues().get(3));
        assertEquals("mst461", sysCaptor_2.getAllValues().get(6));
        assertEquals("system", sysCaptor_2.getAllValues().get(7));
        // カレンダー警告日数
        assertEquals("calendar_keikoku_nissu", sysCaptor_1.getAllValues().get(4));
        assertEquals("mst461", sysCaptor_2.getAllValues().get(8));
        assertEquals("system", sysCaptor_2.getAllValues().get(9));
        //想定通りに再検索を実施する。
        assertEquals("search_mst461", keyCaptor_2.getValue());
        assertEquals("営業日カレンダー", title);
        // 年月 = サーバー日付の年月
        assertEquals("2019/04", target.getMst461Form().getConKensakuNengetsu());
    }

    // init_異常_初期処理_1-3
    @Test
    public void init_異常_初期処理_1_3 () throws IllegalAccessException, InvocationTargetException {
        
        // Mockitoオブジェクトの予想return値設定
        Mst461Form mst461Form = new Mst461Form();

        doThrow(IllegalAccessException.class).when(breadBean)
                .push("営業日カレンダー", Cnst.SCREEN.MST461_SCREEN.name(), target);
        
        target.setMst461Form(mst461Form);
        // 初期処理を行う
        target.init("","TOP011_SCREEN",false);

        //実施結果Outを取得
        String title = target.getTITLE();
        
        // 実行結果の検証
        assertEquals("営業日カレンダー", title);
        // 年月 = サーバー日付の年月
        assertEquals(null, target.getMst461Form().getConKensakuNengetsu());
    }

    // count_正常_カウント処理_2-1
    //
    // -------------------テスト条件--------------------------
    // 画面からの検索処理[downloadFlg = false]
    // -----------------------------------------------------
    @Test
    public void count_正常_カウント処理_2_1 () throws SystemException {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

        // Mockitoオブジェクトの予想return値設定
        Mst461Form mst461Form = new Mst461Form();
        // 検索年月
        mst461Form.setConKensakuNengetsu("2019/04");
        // 売上締日 = 3
        mst461Form.setUriageShimebi("3");
        // 入金締日 = 4
        mst461Form.setNyukinShimebi("4");
        // 設定済一覧前 = 1
        mst461Form.setSetteisumiIchiranMae("1");
        // 設定済一覧後 = 3
        mst461Form.setSetteisumiIchiranUshiro("3");

        // 設定済区分[0].名称 = 未設定
        String kbnName0 = "未設定";
        String kbnName1 = "設定済";
        List<KbnModuleBean> kbnList = new ArrayList();
        KbnModuleBean kbnDto = new KbnModuleBean();
        kbnDto.setKbnMei(kbnName0);
        kbnList.add(kbnDto);
        kbnDto = new KbnModuleBean();
        kbnDto.setKbnMei(kbnName1);
        kbnList.add(kbnDto);
        when(kbnBean.getKbnsOfGroupCd(MsCnst.SETTEISUMI_KUBUN, "")).thenReturn(kbnList);

        // 各プロジェクトのRestFullサービスの受け渡しクラス
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 件数 = 30
        long kensu = 30;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(kensu));

        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        
        target.setMst461Form(mst461Form);
        long retCount = target.count(false);
        
        // 実行時に渡すパラメータの検証
        // 検索年月
        assertEquals("201904", paramsCaptor_1.getValue().get("conKensakuNengetsu"));
        // 売上締日 = 3
        assertEquals("3", paramsCaptor_1.getValue().get("uriageShimebi"));
        // 入金締日 = 4
        assertEquals("4", paramsCaptor_1.getValue().get("nyukinShimebi"));
        // 設定済一覧前 = 1
        assertEquals("1", paramsCaptor_1.getValue().get("setteisumiIchiranMae"));
        // 設定済一覧後 = 3
        assertEquals("3", paramsCaptor_1.getValue().get("setteisumiIchiranUshiro"));
        // 設定済区分[0].名称 = 未設定
        assertEquals("未設定", paramsCaptor_1.getValue().get("setteisumiKubunMiSettei"));
        assertEquals("mst461-count-calendar", functionCodeCaptor_2.getValue());
        // 実行結果の検証
        assertEquals(kensu, retCount);
    }
    
    // count_正常_カウント処理_2-2
    //
    // -------------------テスト条件--------------------------
    // ダウンロードからの検索処理[downloadFlg = true]
    // -----------------------------------------------------
    @Test
    public void count_正常_カウント処理_2_2 () throws SystemException {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

        // Mockitoオブジェクトの予想return値設定
        Mst461Form mst461Form = new Mst461Form();
        // 検索年月
        mst461Form.setConKensakuNengetsu("2019/04");
        // 売上締日 = 3
        mst461Form.setUriageShimebi("3");
        // 入金締日 = 4
        mst461Form.setNyukinShimebi("4");
        // 設定済一覧前 = 1
        mst461Form.setSetteisumiIchiranMae("1");
        // 設定済一覧後 = 3
        mst461Form.setSetteisumiIchiranUshiro("3");

        // 設定済区分[0].名称 = 未設定
        String kbnName0 = "未設定";
        String kbnName1 = "設定済";
        List<KbnModuleBean> kbnList = new ArrayList();
        KbnModuleBean kbnDto = new KbnModuleBean();
        kbnDto.setKbnMei(kbnName0);
        kbnList.add(kbnDto);
        kbnDto = new KbnModuleBean();
        kbnDto.setKbnMei(kbnName1);
        kbnList.add(kbnDto);
        when(kbnBean.getKbnsOfGroupCd(MsCnst.SETTEISUMI_KUBUN, "")).thenReturn(kbnList);

        //前画面情報
        Mst461Form preForm = new Mst461Form();
        // 検索年月
        preForm.setConKensakuNengetsu("2019/05");
        // 売上締日 = 4
        preForm.setUriageShimebi("4");
        // 入金締日 = 5
        preForm.setNyukinShimebi("5");
        // 設定済一覧前 = 6
        preForm.setSetteisumiIchiranMae("6");
        // 設定済一覧後 = 7
        preForm.setSetteisumiIchiranUshiro("7");
        when(pageCommonBean.getPageInfo("mst461Form")).thenReturn(preForm);

        // 各プロジェクトのRestFullサービスの受け渡しクラス
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 件数 = 31
        long kensu = 31;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(kensu));

        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        
        target.setMst461Form(mst461Form);
        long retCount = target.count(true);
        
        // 実行時に渡すパラメータの検証
        // 検索年月
        assertEquals("201905", paramsCaptor_1.getValue().get("conKensakuNengetsu"));
        // 売上締日 = 4
        assertEquals("4", paramsCaptor_1.getValue().get("uriageShimebi"));
        // 入金締日 = 5
        assertEquals("5", paramsCaptor_1.getValue().get("nyukinShimebi"));
        // 設定済一覧前 = 6
        assertEquals("6", paramsCaptor_1.getValue().get("setteisumiIchiranMae"));
        // 設定済一覧後 = 7
        assertEquals("7", paramsCaptor_1.getValue().get("setteisumiIchiranUshiro"));
        // 設定済区分[0].名称 = 未設定
        assertEquals("未設定", paramsCaptor_1.getValue().get("setteisumiKubunMiSettei"));
        assertEquals("mst461-count-calendar", functionCodeCaptor_2.getValue());
        // 実行結果の検証
        assertEquals(kensu, retCount);
    }
    
    // search_正常_検索処理_3-1
    @Test
    public void search_正常_検索処理_3_1 () throws SystemException {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

        // Mockitoオブジェクトの予想return値設定
        Mst461Form mst461Form = new Mst461Form();
        // 検索年月
        mst461Form.setConKensakuNengetsu("2019/04");
        // 売上締日 = 3
        mst461Form.setUriageShimebi("3");
        // 入金締日 = 4
        mst461Form.setNyukinShimebi("4");
        // 設定済一覧前 = 1
        mst461Form.setSetteisumiIchiranMae("1");
        // 設定済一覧後 = 3
        mst461Form.setSetteisumiIchiranUshiro("3");

        // 設定済区分[0].名称 = 未設定
        String kbnName0 = "未設定";
        String kbnName1 = "設定済";
        List<KbnModuleBean> kbnList = new ArrayList();
        KbnModuleBean kbnDto = new KbnModuleBean();
        kbnDto.setKbnMei(kbnName0);
        kbnList.add(kbnDto);
        kbnDto = new KbnModuleBean();
        kbnDto.setKbnMei(kbnName1);
        kbnList.add(kbnDto);
        when(kbnBean.getKbnsOfGroupCd(MsCnst.SETTEISUMI_KUBUN, "")).thenReturn(kbnList);

        // 各プロジェクトのRestFullサービスの受け渡しクラス
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // カレンダー情報を設定する
        List<Map<String, Object>> resultS = new ArrayList<>();
        for (int i = 1; i <= 30; i++) {
            resultS.add(createRecMap("201904", i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultS));

        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        
        target.setMst461Form(mst461Form);
        target.search();
        
        // 実行時に渡すパラメータの検証
        // 検索年月
        assertEquals("201904", paramsCaptor_1.getValue().get("conKensakuNengetsu"));
        // 売上締日 = 3
        assertEquals("3", paramsCaptor_1.getValue().get("uriageShimebi"));
        // 入金締日 = 4
        assertEquals("4", paramsCaptor_1.getValue().get("nyukinShimebi"));
        // 設定済一覧前 = 1
        assertEquals("1", paramsCaptor_1.getValue().get("setteisumiIchiranMae"));
        // 設定済一覧後 = 3
        assertEquals("3", paramsCaptor_1.getValue().get("setteisumiIchiranUshiro"));
        // 設定済区分[0].名称 = 未設定
        assertEquals("未設定", paramsCaptor_1.getValue().get("setteisumiKubunMiSettei"));
        assertEquals("mst461-search-calendar", functionCodeCaptor_2.getAllValues().get(0));
        assertEquals("mst461-search-settei", functionCodeCaptor_2.getAllValues().get(1));
        // 実行結果の検証
        //想定通りにカレンダー情報を表示されること
        assertForRecList_3_1(mst461Form);
    }
    
    // search_異常_検索処理_3-2
    //
    // -------------------テスト条件--------------------------
    // カレンダー情報取得異常
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_3_2 () throws SystemException {

        // Mockitoオブジェクトの予想return値設定
        Mst461Form mst461Form = new Mst461Form();
        // 検索年月
        mst461Form.setConKensakuNengetsu("2019/04");
        // 売上締日 = 3
        mst461Form.setUriageShimebi("3");
        // 入金締日 = 4
        mst461Form.setNyukinShimebi("4");
        // 設定済一覧前 = 1
        mst461Form.setSetteisumiIchiranMae("1");
        // 設定済一覧後 = 3
        mst461Form.setSetteisumiIchiranUshiro("3");

        // 設定済区分[0].名称 = 未設定
        String kbnName0 = "未設定";
        String kbnName1 = "設定済";
        List<KbnModuleBean> kbnList = new ArrayList();
        KbnModuleBean kbnDto = new KbnModuleBean();
        kbnDto.setKbnMei(kbnName0);
        kbnList.add(kbnDto);
        kbnDto = new KbnModuleBean();
        kbnDto.setKbnMei(kbnName1);
        kbnList.add(kbnDto);
        when(kbnBean.getKbnsOfGroupCd(MsCnst.SETTEISUMI_KUBUN, "")).thenReturn(kbnList);

        // カレンダー情報取得異常
        Map<String, Object> params = new HashMap<>();
        // 検索年月
        params.put("conKensakuNengetsu",
                DateUtils.format(mst461Form.getConKensakuNengetsu(), StndConsIF.DF_YYYY_MM, StndConsIF.DF_YYYYMM));
        // ワーク.設定済一覧前
        params.put("setteisumiIchiranMae", mst461Form.getSetteisumiIchiranMae());
        // ワーク.設定済一覧後
        params.put("setteisumiIchiranUshiro", mst461Form.getSetteisumiIchiranUshiro());
        // ワーク.売上締日
        params.put("uriageShimebi", mst461Form.getUriageShimebi());
        // ワーク.入金締日
        params.put("nyukinShimebi", mst461Form.getNyukinShimebi());
        // ワーク.設定済区分[0].名称
        params.put("setteisumiKubunMiSettei", "未設定");
        doThrow(IOException.class).when(pageCommonBean).getDBInfo(params,"mst461-search-calendar");
        
        // 設定済一覧情報
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 設定済一覧情報を設定する
        List<Map<String, Object>> resultS = new ArrayList<>();
        for (int i = 1; i <= 6; i++) {
            resultS.add(createRecMapSettei("201904", i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultS));

        when(pageCommonBean.getDBInfo(params,"mst461-search-settei"))
                .thenReturn(serviceInterfaceBean);

        target.setMst461Form(mst461Form);
        target.search();
        
        // 実行結果の検証
        //想定通りにカレンダー情報を表示されること
        assertForRecList_3_2(mst461Form);
    }

    // search_異常_検索処理_3-3
    //
    // -------------------テスト条件--------------------------
    // 設定済一覧情報取得異常
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_3_3 () throws SystemException {

        // Mockitoオブジェクトの予想return値設定
        Mst461Form mst461Form = new Mst461Form();
        // 検索年月
        mst461Form.setConKensakuNengetsu("2019/04");
        // 売上締日 = 3
        mst461Form.setUriageShimebi("3");
        // 入金締日 = 4
        mst461Form.setNyukinShimebi("4");
        // 設定済一覧前 = 1
        mst461Form.setSetteisumiIchiranMae("1");
        // 設定済一覧後 = 3
        mst461Form.setSetteisumiIchiranUshiro("3");

        // 設定済区分[0].名称 = 未設定
        String kbnName0 = "未設定";
        String kbnName1 = "設定済";
        List<KbnModuleBean> kbnList = new ArrayList();
        KbnModuleBean kbnDto = new KbnModuleBean();
        kbnDto.setKbnMei(kbnName0);
        kbnList.add(kbnDto);
        kbnDto = new KbnModuleBean();
        kbnDto.setKbnMei(kbnName1);
        kbnList.add(kbnDto);
        when(kbnBean.getKbnsOfGroupCd(MsCnst.SETTEISUMI_KUBUN, "")).thenReturn(kbnList);

        // カレンダー情報
        Map<String, Object> params = new HashMap<>();
        // 検索年月
        params.put("conKensakuNengetsu",
                DateUtils.format(mst461Form.getConKensakuNengetsu(), StndConsIF.DF_YYYY_MM, StndConsIF.DF_YYYYMM));
        // ワーク.設定済一覧前
        params.put("setteisumiIchiranMae", mst461Form.getSetteisumiIchiranMae());
        // ワーク.設定済一覧後
        params.put("setteisumiIchiranUshiro", mst461Form.getSetteisumiIchiranUshiro());
        // ワーク.売上締日
        params.put("uriageShimebi", mst461Form.getUriageShimebi());
        // ワーク.入金締日
        params.put("nyukinShimebi", mst461Form.getNyukinShimebi());
        // ワーク.設定済区分[0].名称
        params.put("setteisumiKubunMiSettei", "未設定");
        
        // 各プロジェクトのRestFullサービスの受け渡しクラス
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // カレンダー情報を設定する
        List<Map<String, Object>> resultS = new ArrayList<>();
        for (int i = 1; i <= 30; i++) {
            resultS.add(createRecMap("201904", i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultS));

        when(pageCommonBean.getDBInfo(params,"mst461-search-calendar")).thenReturn(serviceInterfaceBean);
        
        // 設定済一覧情報取得異常
        doThrow(IOException.class).when(pageCommonBean).getDBInfo(params,"mst461-search-settei");

        target.setMst461Form(mst461Form);
        target.search();
        
        // 実行結果の検証
        //想定通りにカレンダー情報を表示されること
        assertForRecList_3_1(mst461Form);
    }

    // clear_正常_クリア処理_4-1
    //
    // -------------------テスト条件--------------------------
    // 検索条件と検索結果がある
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_4_1 () {

        //テスト実行
        Mst461Form mst461Form = new Mst461Form();
        // 検索年月
        mst461Form.setConKensakuNengetsu("2019/05");
        // 営業日カレンダー情報
        List<Map<String, Object>> resultC = new ArrayList<>();
        for (int i = 1; i <= 30; i++) {
            resultC.add(createRecMap("201904", i));
        }
        mst461Form.setCalendarNoNullList(resultC);
        // 設定済一覧情報
        List<Map<String, Object>> resultS = new ArrayList<>();
        for (int i = 1; i <= 6; i++) {
            resultS.add(createRecMapSettei("201904", i));
        }
        mst461Form.setSetteisumiList(resultS);

        target.setMst461Form(mst461Form);
        target.clear();

        //実施結果Outを取得
        mst461Form = target.getMst461Form();

        //想定通りに正常にClearを実施されること
        assertEquals("2019/04", mst461Form.getConKensakuNengetsu());
        assertEquals(30, mst461Form.getCalendarNoNullList().size());
        assertEquals(6, mst461Form.getSetteisumiList().size());
    }

    // clear_正常_クリア処理_4-2
    //
    // -------------------テスト条件--------------------------
    // 検索条件がある、検索結果がない
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_4_2 () {

        //テスト実行
        Mst461Form mst461Form = new Mst461Form();
        // 検索年月
        mst461Form.setConKensakuNengetsu("2019/05");

        target.setMst461Form(mst461Form);
        target.clear();

        //実施結果Outを取得
        mst461Form = target.getMst461Form();

        //想定通りに正常にClearを実施されること
        assertEquals("2019/04", mst461Form.getConKensakuNengetsu());
        assertEquals(null, mst461Form.getCalendarNoNullList());
        assertEquals(null, mst461Form.getSetteisumiList());
    }

    // searchChange_正常_検索条件変更処理_5-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void searchChange_正常_検索条件変更処理_5_1 () {

        //テスト実行
        Mst461Form mst461Form = new Mst461Form();
        // 検索年月
        mst461Form.setConKensakuNengetsu("2019/05");

        target.setMst461Form(mst461Form);
        target.searchChange();

        //実施結果Outを取得
        mst461Form = target.getMst461Form();

        // 編集ボタン状態:活性
        assertEquals(false, mst461Form.isMode());
        // 検索年月
        assertEquals("2019/05", mst461Form.getConKensakuNengetsu());
    }

    // changeMode_正常_編集ボタン押下処理_6-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void changeMode_正常_編集ボタン押下処理_6_1 () {

        //テスト実行
        Mst461Form mst461Form = new Mst461Form();
        // 検索年月
        mst461Form.setConKensakuNengetsu("2019/05");
        // 編集ボタン状態:活性
        mst461Form.setMode(false);

        target.setMst461Form(mst461Form);
        target.changeMode();

        //実施結果Outを取得
        mst461Form = target.getMst461Form();

        // 編集ボタン状態:非活性
        assertEquals(true, mst461Form.isMode());
        // 検索年月
        assertEquals("2019/05", mst461Form.getConKensakuNengetsu());
    }

    // update_異常_登録申請_7-1
    //
    // -------------------テスト条件--------------------------
    // 売上締日フラグが選択されている日 = 0
    // -----------------------------------------------------
    @Test
    public void update_異常_登録申請_7_1 () {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_1 = ArgumentCaptor.forClass(String.class);
        
        //テスト実行
        Mst461Form mst461Form = new Mst461Form();
        // 検索年月
        mst461Form.setConKensakuNengetsu("2019/04");
        // 営業日カレンダー情報
        List<Map<String, Object>> resultC = new ArrayList<>();
        for (int i = 0; i < 30; i++) {
            resultC.add(createRecMap("201904", i));
        }
        resultC.get(3).put("listCalendarUriageShimebi", "false");
        mst461Form.setCalendarList(resultC);
        
        doNothing().when(messagePropertyBean).message(levelCaptor_1.capture(),summaryCaptor_1.capture());
        
        target.setMst461Form(mst461Form);
        target.update();

        // 実行時に渡すパラメータの検証
        assertEquals("ERROR", levelCaptor_1.getValue());
        assertEquals("MSTE0038", summaryCaptor_1.getValue());
    }

    // update_異常_登録申請_7-2
    //
    // -------------------テスト条件--------------------------
    // 売上締日フラグが選択されている日 = 2
    // -----------------------------------------------------
    @Test
    public void update_異常_登録申請_7_2 () {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_1 = ArgumentCaptor.forClass(String.class);
        
        //テスト実行
        Mst461Form mst461Form = new Mst461Form();
        // 検索年月
        mst461Form.setConKensakuNengetsu("2019/04");
        // 営業日カレンダー情報
        List<Map<String, Object>> resultC = new ArrayList<>();
        for (int i = 0; i < 30; i++) {
            resultC.add(createRecMap("201904", i));
        }
        resultC.get(4).put("listCalendarUriageShimebi", "true");
        mst461Form.setCalendarList(resultC);
        
        doNothing().when(messagePropertyBean).message(levelCaptor_1.capture(),summaryCaptor_1.capture());
        
        target.setMst461Form(mst461Form);
        target.update();

        // 実行時に渡すパラメータの検証
        assertEquals("ERROR", levelCaptor_1.getValue());
        assertEquals("MSTE0038", summaryCaptor_1.getValue());
    }

    // update_異常_登録申請_7-3
    //
    // -------------------テスト条件--------------------------
    // 入金締日フラグが選択されている日 = 0
    // -----------------------------------------------------
    @Test
    public void update_異常_登録申請_7_3 () {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_1 = ArgumentCaptor.forClass(String.class);
        
        //テスト実行
        Mst461Form mst461Form = new Mst461Form();
        // 検索年月
        mst461Form.setConKensakuNengetsu("2019/04");
        // 営業日カレンダー情報
        List<Map<String, Object>> resultC = new ArrayList<>();
        for (int i = 0; i < 30; i++) {
            resultC.add(createRecMap("201904", i));
        }
        resultC.get(4).put("listCalendarNyukinShimebi", "false");
        mst461Form.setCalendarList(resultC);
        
        doNothing().when(messagePropertyBean).message(levelCaptor_1.capture(),summaryCaptor_1.capture());
        
        target.setMst461Form(mst461Form);
        target.update();

        // 実行時に渡すパラメータの検証
        assertEquals("ERROR", levelCaptor_1.getValue());
        assertEquals("MSTE0039", summaryCaptor_1.getValue());
    }

    // update_異常_登録申請_7-4
    //
    // -------------------テスト条件--------------------------
    // 入金締日フラグが選択されている日 = 2
    // -----------------------------------------------------
    @Test
    public void update_異常_登録申請_7_4 () {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_1 = ArgumentCaptor.forClass(String.class);
        
        //テスト実行
        Mst461Form mst461Form = new Mst461Form();
        // 検索年月
        mst461Form.setConKensakuNengetsu("2019/04");
        // 営業日カレンダー情報
        List<Map<String, Object>> resultC = new ArrayList<>();
        for (int i = 0; i < 30; i++) {
            resultC.add(createRecMap("201904", i));
        }
        resultC.get(5).put("listCalendarNyukinShimebi", "true");
        mst461Form.setCalendarList(resultC);
        
        doNothing().when(messagePropertyBean).message(levelCaptor_1.capture(),summaryCaptor_1.capture());
        
        target.setMst461Form(mst461Form);
        target.update();

        // 実行時に渡すパラメータの検証
        assertEquals("ERROR", levelCaptor_1.getValue());
        assertEquals("MSTE0039", summaryCaptor_1.getValue());
    }

    // update_異常_登録申請_7-5
    //
    // -------------------テスト条件--------------------------
    // 売上締日フラグが選択されている日 = 1
    // 入金締日フラグが選択されている日 = 1
    // 排他チェックエラー
    // -----------------------------------------------------
    @Test
    public void update_異常_登録申請_7_5 () {
        
        // パラメータキャプチャー
        ArgumentCaptor<List> parmCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> funcCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_1 = ArgumentCaptor.forClass(String.class);
        
        //テスト実行
        Mst461Form mst461Form = new Mst461Form();
        // 検索年月
        mst461Form.setConKensakuNengetsu("2019/04");
        // 営業日カレンダー情報
        List<Map<String, Object>> resultC = new ArrayList<>();
        for (int i = 0; i < 30; i++) {
            resultC.add(createRecMap("201904", i));
        }
        mst461Form.setCalendarList(resultC);
        
        ServiceInterfaceBean sib = new ServiceInterfaceBean();
        sib.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        sib.addMessage("WARN", "COME0014", "");
        when(pageCommonBean.accsessDBWithList(parmCaptor_1.capture(), funcCaptor_1.capture())).thenReturn(sib);
        doNothing().when(messagePropertyBean).message(levelCaptor_1.capture(),summaryCaptor_1.capture());
        
        target.setMst461Form(mst461Form);
        target.update();

        // 実行時に渡すパラメータの検証
        assertEquals(mst461Form.getCalendarList(), parmCaptor_1.getValue());
        assertEquals("mst461-touroku-shinsei", funcCaptor_1.getValue());
        assertEquals("WARN", levelCaptor_1.getValue());
        assertEquals("COME0014", summaryCaptor_1.getValue());
    }
    
    // update_正常_登録申請_7-6
    //
    // -------------------テスト条件--------------------------
    // 売上締日フラグが選択されている日 = 1
    // 入金締日フラグが選択されている日 = 1
    // 排他チェックエラーなし
    // -----------------------------------------------------
    @Test
    public void update_正常_登録申請_7_6 () {
        
        // パラメータキャプチャー
        ArgumentCaptor<List> parmCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> funcCaptor_1 = ArgumentCaptor.forClass(String.class);
        
        //テスト実行
        Mst461Form mst461Form = new Mst461Form();
        // 検索年月
        mst461Form.setConKensakuNengetsu("2019/04");
        // 営業日カレンダー情報
        List<Map<String, Object>> resultC = new ArrayList<>();
        for (int i = 0; i < 30; i++) {
            resultC.add(createRecMap("201904", i));
        }
        mst461Form.setCalendarList(resultC);
        
        ServiceInterfaceBean sib = new ServiceInterfaceBean();
        sib.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(parmCaptor_1.capture(), funcCaptor_1.capture())).thenReturn(sib);
        
        // flash
        Flash flash =  new FlashKls();
        when(flashUtil.getPageParam()).thenReturn(flash);
        
        target.setMst461Form(mst461Form);
        target.update();

        // 実行時に渡すパラメータの検証
        assertEquals(mst461Form.getCalendarList(), parmCaptor_1.getValue());
        assertEquals("mst461-touroku-shinsei", funcCaptor_1.getValue());
        // 実行結果の検証
        assertEquals("/contents/dem/dem012.xhtml?faces-redirect=true", target.getUrl());
    }
    
    // shonin_正常_承認後処理_8-1
    @Test
    public void shonin_正常_承認後処理_8_1 () {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> parmCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> funcCaptor_1 = ArgumentCaptor.forClass(String.class);
        
        // flash
        Flash flash =  new FlashKls();
        // 年月(YYYYMM形式)
        flash.put("nengetsu", "201904");
        // 申請ステータス
        flash.put("shinseiStatus", "01");
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        when(pageCommonBean.getDBInfo(parmCaptor_1.capture(),funcCaptor_1.capture())).thenReturn(serviceInterfaceBean);
        
        target.shonin();
        
        // 実行時に渡すパラメータの検証
        assertEquals("201904", parmCaptor_1.getValue().get("nengetsu"));
        assertEquals("01", parmCaptor_1.getValue().get("shinseiStatus"));
        assertEquals("mst461-shonin", funcCaptor_1.getValue());
    }

    // misetteiCalendarCheck_異常_未設定カレンダーチェック処理_9-1
    //
    // -------------------テスト条件--------------------------
    // 取得件数 = 0の場合
    // -----------------------------------------------------
    @Test
    public void misetteiCalendarCheck_異常_未設定カレンダーチェック処理_9_1 () {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> parmCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> funcCaptor_1 = ArgumentCaptor.forClass(String.class);
        
        Mst461Form mst461Form = new Mst461Form();
        // カレンダー警告日数
        mst461Form.setCalendarKeikokuNissu("20");
        
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        String result = "";
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(parmCaptor_1.capture(),funcCaptor_1.capture())).thenReturn(serviceInterfaceBean);
        
        doNothing().when(pageCommonBean).executeScript("km.showConfirmDialog('mste0113Dialog')");
        
        //テスト実行
        target.setMst461Form(mst461Form);
        target.misetteiCalendarCheck();

        // 実行時に渡すパラメータの検証
        assertEquals("201905", parmCaptor_1.getValue().get("kensakuTaishoNengetsu"));
        assertEquals("mst461-misettei-calendar-check", funcCaptor_1.getValue());
    }
    
    // misetteiCalendarCheck_異常_未設定カレンダーチェック処理_9-2
    //
    // -------------------テスト条件--------------------------
    // 実行結果.SHONIN_STATUS = "0"の場合
    // -----------------------------------------------------
    @Test
    public void misetteiCalendarCheck_異常_未設定カレンダーチェック処理_9_2 () {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> parmCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> funcCaptor_1 = ArgumentCaptor.forClass(String.class);
        
        Mst461Form mst461Form = new Mst461Form();
        // カレンダー警告日数
        mst461Form.setCalendarKeikokuNissu("20");
        
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        String result = "0";
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(parmCaptor_1.capture(),funcCaptor_1.capture())).thenReturn(serviceInterfaceBean);
        
        doNothing().when(pageCommonBean).executeScript("km.showConfirmDialog('mste0113Dialog')");
        
        //テスト実行
        target.setMst461Form(mst461Form);
        target.misetteiCalendarCheck();

        // 実行時に渡すパラメータの検証
        assertEquals("201905", parmCaptor_1.getValue().get("kensakuTaishoNengetsu"));
        assertEquals("mst461-misettei-calendar-check", funcCaptor_1.getValue());
    }
    
    // misetteiCalendarCheck_異常_未設定カレンダーチェック処理_9-3
    //
    // -------------------テスト条件--------------------------
    // 取得異常の場合
    // -----------------------------------------------------
    @Test
    public void misetteiCalendarCheck_異常_未設定カレンダーチェック処理_9_3 () {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> parmCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> funcCaptor_1 = ArgumentCaptor.forClass(String.class);
        
        Mst461Form mst461Form = new Mst461Form();
        // カレンダー警告日数
        mst461Form.setCalendarKeikokuNissu("20");
        
        doThrow(IOException.class).when(pageCommonBean).getDBInfo(parmCaptor_1.capture(),funcCaptor_1.capture());
        
        //テスト実行
        target.setMst461Form(mst461Form);
        target.misetteiCalendarCheck();

        // 実行時に渡すパラメータの検証
        assertEquals("201905", parmCaptor_1.getValue().get("kensakuTaishoNengetsu"));
        assertEquals("mst461-misettei-calendar-check", funcCaptor_1.getValue());
    }
    
    // misetteiCalendarCheck_正常_未設定カレンダーチェック処理_9-4
    //
    // -------------------テスト条件--------------------------
    // 実行結果.SHONIN_STATUS = "1"の場合
    // -----------------------------------------------------
    @Test
    public void misetteiCalendarCheck_正常_未設定カレンダーチェック処理_9_4 () {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> parmCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> funcCaptor_1 = ArgumentCaptor.forClass(String.class);
        
        Mst461Form mst461Form = new Mst461Form();
        // カレンダー警告日数
        mst461Form.setCalendarKeikokuNissu("20");
        
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        String result = "1";
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(parmCaptor_1.capture(),funcCaptor_1.capture())).thenReturn(serviceInterfaceBean);
        
        //テスト実行
        target.setMst461Form(mst461Form);
        target.misetteiCalendarCheck();

        // 実行時に渡すパラメータの検証
        assertEquals("201905", parmCaptor_1.getValue().get("kensakuTaishoNengetsu"));
        assertEquals("mst461-misettei-calendar-check", funcCaptor_1.getValue());
    }
    
    // upload_正常_アップロード_10-1
    @Test
    public void upload_正常_アップロード_10_1() {
        
        //テスト実行
        Flash flash = new FlashKls();
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        when(flashUtil.getPageParam()).thenReturn(flash);
        target.upload();
        
        // 実行結果の検証
        assertEquals("/contents/upload/upload.xhtml?faces-redirect=true", target.getUrl());
    }
    
    // beforeDown_正常_ダウンロード理由を記録する処理_11-1
    @Test
    public void beforeDown_正常_ダウンロード理由を記録する処理_11_1() throws Exception {
        
        //テスト実行
        target.beforeDown("test");
    }
    
    // menuClick_正常_メニュークリック処理_12-1
    @Test
    public void menuClick_正常_メニュークリック処理_12_1() {
        
        Flash flash =  new FlashKls();
        when(flashUtil.getPageParam()).thenReturn(flash);
        
        //テスト実行
        target.menuClick("", "TOP011_SCREEN");
        
        // 実行結果の検証
        assertEquals("/contents/top/top011.xhtml?faces-redirect=true", target.getUrl());
    }

    // menuClick_異常_メニュークリック処理_12-2
    @Test
    public void menuClick_異常_メニュークリック処理_12_2() throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(1);

        //テスト実行
        target.menuClick("", "");
        
        // 実行結果の検証
        assertEquals("", target.getUrl());
    }    
    
    // breadClumClick_正常_パンくずクリック処理_13-1
    @Test
    public void breadClumClick_正常_パンくずクリック処理_13_1() {
        
        Flash flash =  new FlashKls();
        when(flashUtil.getPageParam()).thenReturn(flash);
        
        //テスト実行
        target.breadClumClick("TOP011_SCREEN", 0);
        
        // 実行結果の検証
        assertEquals("/contents/top/top011.xhtml?faces-redirect=true", target.getUrl());
    }

    // breadClumClick_異常_パンくずクリック処理_13-2
    @Test
    public void breadClumClick_異常_パンくずクリック処理_13_2()
            throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(1);

        //テスト実行
        target.breadClumClick("", 1);
        
        // 実行結果の検証
        assertEquals("", target.getUrl());
    }    
    
    // logoutClick_正常_ログアウトクリック_14-1
    @Test
    public void logoutClick_正常_ログアウトクリック_14_1() {
        
        //テスト実行
        target.logoutClick();
    }
    
    private Map<String, Object> createRecMap(String yearMonth, int i) {
        Map recMap = new HashMap();
        // 年月日
        recMap.put("nengappi", yearMonth + StrUtils.leftPad(StrUtils.defaultString(i), 2, "0"));
        // 日付
        recMap.put("listCalendarHizuke", i);
        // 休日フラグ
        recMap.put("listCalendarKyujitsu", "false" + i);
        // 日曜フラグ
        recMap.put("nichiyoFlg", "false" + i);
        // 祝日フラグ
        recMap.put("shukujitsuFlg", "false" + i);
        // 売上締日フラグ
        if (i == 3) {
            recMap.put("listCalendarUriageShimebi", "true");
        } else {
            recMap.put("listCalendarUriageShimebi", "false");
        }
        // 入金締日フラグ
        if (i == 4) {
            recMap.put("listCalendarNyukinShimebi", "true");
        } else {
            recMap.put("listCalendarNyukinShimebi", "false");
        }
        return recMap;
    }

    private void assertForRecList_3_1(Mst461Form form) {
        int i = 0;
        assertEquals(35, form.getCalendarList().size());
        for (Map<String, Object> rec : form.getCalendarList()) {
            if (i == 0 || i > 30) {
                assertEquals(0, rec.size());
            } else {
                // 年月日
                assertEquals(
                        form.getConKensakuNengetsu().replace("/", "") + StrUtils.leftPad(StrUtils.defaultString(i), 2, "0"),
                        rec.get("nengappi"));
                // 日付
                assertEquals(i, rec.get("listCalendarHizuke"));
                // 休日フラグ
                assertEquals("false" + i, rec.get("listCalendarKyujitsu"));
                // 日曜フラグ
                assertEquals("false" + i, rec.get("nichiyoFlg"));
                // 祝日フラグ
                assertEquals("false" + i, rec.get("shukujitsuFlg"));
                // 売上締日フラグ
                if (i == 3) {
                    assertEquals("true", rec.get("listCalendarUriageShimebi"));
                } else {
                    assertEquals("false", rec.get("listCalendarUriageShimebi"));
                }
                // 入金締日フラグ
                if (i == 4) {
                    assertEquals("true", rec.get("listCalendarNyukinShimebi"));
                } else {
                    assertEquals("false", rec.get("listCalendarNyukinShimebi"));
                }
            }
            i++;
        }
    }

    private Map<String, Object> createRecMapSettei(String yearMonth, int i) {
        Map recMap = new HashMap();
        // カレンダー設定状況マスタ.年月
        recMap.put("ksSetteiZumiIchiranNengetsu", yearMonth + StrUtils.leftPad(StrUtils.defaultString(i), 2, "0"));
        // カレンダー設定状況マスタ.設定状況
        recMap.put("ksSetteiZumiIchiranSetteiJokyo", "ksSetteiZumiIchiranSetteiJokyo" + i);
        return recMap;
    }

    private void assertForRecList_3_2(Mst461Form form) {
        int i = 1;
        assertEquals(6, form.getSetteisumiList().size());
        for (Map<String, Object> rec : form.getSetteisumiList()) {
            // カレンダー設定状況マスタ.年月
            assertEquals(
                    form.getConKensakuNengetsu().replace("/", "") + StrUtils.leftPad(StrUtils.defaultString(i), 2, "0"),
                    rec.get("ksSetteiZumiIchiranNengetsu"));
            // カレンダー設定状況マスタ.設定状況
            assertEquals("ksSetteiZumiIchiranSetteiJokyo" + i, rec.get("ksSetteiZumiIchiranSetteiJokyo"));
            i++;
        }
    }      

}
