package jp.co.kintetsuls.beans.mst;

import java.io.IOException;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.doThrow;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst511Form;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import org.mockito.Mockito;

/**
 * 代理承認マスタ画面
 *
 * @author 李信志 (MBP)
 * @version 2019/1/24 新規作成
 */
public class Mst511BeanTest {

    // テストTarget
    @InjectMocks
    private Mst511Bean target;

    // Mockitoオブジェクト
    @Mock
    private FileBean fileBean;
    @Mock
    private AutoCompleteViewBean autoCompleteViewBean;
    @Mock
    private MasterInfoBean masterInfo;
    @Mock
    private MessagePropertyBean messageProperty;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosai;
    @Mock
    private SearchHelpBean searchHelpBean;
    @Mock
    private AuthorityConfBean authorityConfBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private MessagePropertyBean messagePropertyBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosaiBean;
    @Mock
    private ListCheckBean listCheckBean;
    
    public Mst511BeanTest() {
    }

    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() {
    }

    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[not null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst511Form mst511Form = new Mst511Form();
        
        //前画面情報[not null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst511Form);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst511Form form = new Mst511Form();
        target.setMst511Form(form);
        // 戻ってきた場合、再検索を実施する。
        target.init("","MST042_SCREEN",true);

        //実施結果Outを取得
        form = target.getMst511Form();
        String title = target.getTITLENAME();
        String url = target.getURL();
        BreadCrumbBean breadBean = target.getBreadBean();
        AutoCompleteViewBean autoCompleteViewBean = target.getAutoCompleteViewBean();
        AuthorityConfBean authorityConfBean  = target.getAuthorityConfBean();
        FileBean fileBean = target.getFileBean();
        MessagePropertyBean messagePropertyBean = target.getMessagePropertyBean();
        PageCommonBean pageCommonBean = target.getPageCommonBean();
        SearchHelpBean searchHelpBean = target.getSearchHelpBean();
        RirekiSyosaiBean rirekiSyosai = target.getRirekiSyosai();
        ListCheckBean listCheckBean = target.getListCheckBean();
        Map<String, Object> rirekiSearchKey = target.getRirekiSearchKey();
        List<MessageModuleBean> msgList = target.getMsgList();
        target.setURL(url);
        target.setBreadBean(breadBean);
        target.setAutoCompleteViewBean(autoCompleteViewBean);
        target.setAuthorityConfBean(authorityConfBean);
        target.setFileBean(fileBean);
        target.setMessagePropertyBean(messagePropertyBean);
        target.setPageCommonBean(pageCommonBean);
        target.setSearchHelpBean(searchHelpBean);
        target.setRirekiSyosai(rirekiSyosai);
        target.setListCheckBean(listCheckBean);
        target.setRirekiSearchKey(rirekiSearchKey);
        target.setMsgList(msgList);
        
        // 実行時に渡すパラメータの検証
        assertEquals("mst511Form",keyCaptor_1.getValue());
        //想定通りに再検索を実施する。
        assertEquals("search_mst511",keyCaptor_2.getValue());
    }

    // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[営業所 = 130,所属終了を含む = null,削除済のみ検索 = null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2() throws IllegalAccessException, InvocationTargetException,
            InstantiationException {

        // Mockitoオブジェクトの予想return値設定
        Mst511Form mst511Form = new Mst511Form();
        //前回検索パラメータ[営業所 = 130,所属終了を含む = null,削除済のみ検索 = null]
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("130");
        mst511Form.setEigyoshokodo(conEigyoshoCd);
        mst511Form.setConShozokuShuryoWoFukumu(null);
        mst511Form.setConSakujoSumiNomi(null);
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        //前画面パラメータ[営業所 = 130,所属終了を含む = null,削除済のみ検索 = null]
        flash.put("mst511Form", mst511Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);        

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst511Form form = new Mst511Form();
        target.setMst511Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst511Form();

        //想定通りに再検索を実施する。
         assertEquals("search_mst511",keyCaptor_2.getValue());
        assertEquals("130",form.getEigyoshokodo().getValue());
        assertEquals(null,form.getConShozokuShuryoWoFukumu());
        assertEquals(null,form.getConSakujoSumiNomi());
    }

    // init_正常_初期処理_1-2_1
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[営業所 = 130,所属終了を含む = null,削除済のみ検索 = null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2_1() throws IllegalAccessException, InvocationTargetException,
            InstantiationException {

        // Mockitoオブジェクトの予想return値設定
        Mst511Form mst511Form = new Mst511Form();
        //前回検索パラメータ[営業所 = 130,所属終了を含む = null,削除済のみ検索 = null]
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("130");
        mst511Form.setEigyoshokodo(conEigyoshoCd);
        mst511Form.setConShozokuShuryoWoFukumu(null);
        mst511Form.setConSakujoSumiNomi(null);
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        //前画面パラメータ[営業所 = 130,所属終了を含む = null,削除済のみ検索 = null]
        flash.put("mst511Form", null);
        when(pageCommonBean.getPageParam()).thenReturn(flash);        

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst511Form form = new Mst511Form();
        target.setMst511Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst511Form();

        //想定通りに再検索を実施する。
        assertEquals(null,form.getConSakujoSumiNomi());
    }    
    
    // init_正常_初期処理_1-3
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        //前画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(null);

        //テスト実行
        Mst511Form form = new Mst511Form();
        target.setMst511Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst511Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst511Form",keyCaptor_1.getValue());
        //想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null,form.getSearchResult());
    }

    // init_正常_初期処理_1-3_1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        //前画面情報[null]
        doThrow(IllegalAccessException.class).when(pageCommonBean).getPageInfo(keyCaptor_1.capture());

        //テスト実行
        Mst511Form form = new Mst511Form();
        target.setMst511Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst511Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst511Form",keyCaptor_1.getValue());
        //想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null,form.getSearchResult());
    }

   // search_正常_検索処理_2-1
    //
    // -------------------テスト条件--------------------------
    // 代理承認者設定検索結果一覧取得
    // 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //代理承認者設定検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=0;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst511Form form = new Mst511Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("conEigyoshoCd2");
        form.setEigyoshokodo(conEigyoshoCd);
        form.setConShozokuShuryoWoFukumu(new String[]{"conShozokuShuryoWoFukumu1"});
        form.setConSakujoSumiNomi(new String[]{"conSakujoSumiNomi1"});
        target.setMst511Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst511Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conEigyoshoCd2", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        String[] conShozokuShuryoWoFukumuParam = (String[]) paramsCaptor_1.getValue().get("conShozokuShuryoWoFukumu");
        assertEquals("conShozokuShuryoWoFukumu1", conShozokuShuryoWoFukumuParam[0]);
        String[] conSakujoSumiNomParam = (String[]) paramsCaptor_1.getValue().get("conSakujoSumiNomi");
        assertEquals("conSakujoSumiNomi1", conSakujoSumiNomParam[0]);
        assertEquals("mst511-get-eigyosho-detail", functionCodeCaptor_2.getValue());
        //想定通りに代理承認者設定名マスタ一覧を表示されること
        assertForRecList_2_1(form);
    }    

   // search_正常_検索処理_2-2
    //
    // -------------------テスト条件--------------------------
    // 代理承認者設定検索結果一覧取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //代理承認者設定検索結果一覧取得 取得件数 = 2
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=1;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst511Form form = new Mst511Form();
        target.setMst511Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst511Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null,paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals(null,paramsCaptor_1.getValue().get("conSakujoSumiNomi"));
        assertEquals("mst511-get-eigyosho-detail",functionCodeCaptor_2.getValue());
        //想定通りに代理承認者設定名マスタ一覧を表示されること
        assertForRecList_2_2(form);
    }

    // search_異常_検索処理_2-3
    //
    // -------------------テスト条件--------------------------
    // 代理承認者設定検索結果一覧取得 取得件数 = 0
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //代理承認者設定検索結果一覧取得 取得件数 = 0
        List<Map<String, String>> result = new ArrayList<>();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst511Form form = new Mst511Form();
        form.setConSakujoSumiNomi(new String[]{});
        target.setMst511Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst511Form();

        // 実行時に渡すパラメータの検証
        String[] st = (String[]) paramsCaptor_1.getValue().get("conSakujoSumiNomi");
        assertEquals(null, paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals(0, st.length);
        assertEquals("mst511-get-eigyosho-detail",functionCodeCaptor_2.getValue());
        //想定通りに・一覧は表示しない（ヘッダーのみ） 
        //想定通りに ・ファンクションボタンは表示（検索前と同じ） 
        assertForRecList_2_3(form);
    }

    // getRecordCount_正常_件数取得処理_2-4
    //
    // -------------------テスト条件--------------------------
    // 代理承認者設定検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //代理承認者設定検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst511Form form = new Mst511Form();
        target.setMst511Form(form);
        target.getRecordCount();

        //実施結果Outを取得
        form = target.getMst511Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null,paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals(null,paramsCaptor_1.getValue().get("conSakujoSumiNomi"));
        assertEquals("mst511-get-eigyosho-kensu",functionCodeCaptor_2.getValue());
        //想定通りに正常にCountを実施されること
        assertEquals(null,form.getEigyoshokodo());
    }

    // getRecordCount_正常_件数取得処理_2-4_1
    //
    // -------------------テスト条件--------------------------
    // 代理承認者設定検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_4_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //代理承認者設定検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst511Form form = new Mst511Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("conEigyoshoCd1");
        form.setEigyoshokodo(conEigyoshoCd);
        form.setConShozokuShuryoWoFukumu(new String[]{"conShozokuShuryoWoFukumu"});
        form.setConSakujoSumiNomi(new String[]{"conSakujoSumiNomi1"});
        target.setMst511Form(form);
        target.getRecordCount();

        //実施結果Outを取得
        form = target.getMst511Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conEigyoshoCd1",paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("mst511-get-eigyosho-kensu",functionCodeCaptor_2.getValue());
        //想定通りに正常にCountを実施されること
        assertEquals("conEigyoshoCd1",form.getEigyoshokodo().getValue());
    }    
    
    // getRecordCount_正常_件数取得処理_2-4_2
    //
    // -------------------テスト条件--------------------------
    // 代理承認者設定検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_4_2 () throws IllegalAccessException, InvocationTargetException {

         // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //代理承認者設定検索件数取得 取得件数 = 2
       int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
//       when(pageCommonBean).getDBInfo(paramsCaptor_1.capture(), 
//                functionCodeCaptor_2.capture());
       when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
       
       
        //テスト実行
        Mst511Form form = new Mst511Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("conEigyoshoCd1");
        form.setEigyoshokodo(conEigyoshoCd);
        form.setConShozokuShuryoWoFukumu(new String[]{"conShozokuShuryoWoFukumu"});
        form.setConSakujoSumiNomi(new String[]{"conSakujoSumiNomi1"});
        target.setMst511Form(form);
        target.getRecordCount();

        //実施結果Outを取得
        form = target.getMst511Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conEigyoshoCd1",paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("mst511-get-eigyosho-kensu",functionCodeCaptor_2.getValue());
        //想定通りに正常にCountを実施されること
        assertEquals("conEigyoshoCd1",form.getEigyoshokodo().getValue());
    } 
    
    // clear_正常_クリア処理_3-1
    //
    // -------------------テスト条件--------------------------
    // 検索条件と検索結果がある
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst511Form form = new Mst511Form();
        // 検索条件と検索結果がある
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("130");
        conEigyoshoCd.setLabel("東京");
        form.setEigyoshokodo(conEigyoshoCd);
        form.setConShozokuShuryoWoFukumu(new String[]{"00"});
        form.setConSakujoSumiNomi(new String[]{"01"});

        target.setMst511Form(form);
        target.clear();

        //実施結果Outを取得
        form = target.getMst511Form();

        //想定通りに正常にClearを実施されること
        assertEquals(null, form.getEigyoshokodo());
        assertEquals(null, form.getConShozokuShuryoWoFukumu());
        assertEquals(null, form.getConSakujoSumiNomi());
    }

    // clear_正常_クリア処理_3-2
    //
    // -------------------テスト条件--------------------------
    // 検索条件がある、検索結果がない
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst511Form form = new Mst511Form();
        target.setMst511Form(form);
        target.clear();

        //実施結果Outを取得
        form = target.getMst511Form();

        //想定通りに正常にClearを実施されること
        assertEquals(null, form.getEigyoshokodo());
        assertEquals(null, form.getConShozokuShuryoWoFukumu());
        assertEquals(null, form.getConSakujoSumiNomi());
    }
    
    // update_異常_更新処理_新規登録_11-1
    //
    // -------------------テスト条件--------------------------
    // 代理承認コード、代理承認者設定名コードの組み合わせが、代理承認者設定名マスタに存在しています[COME0018]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_新規登録_11_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //代理承認コード、代理承認者設定名コードの組み合わせが、代理承認者設定名マスタに存在しています[COME0018]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0018",
                "listTodofukenCdlistShimukeChiMeiCd");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());

        //テスト実行
        Mst511Form form = new Mst511Form();
        AutoCompOptionBean listEigyoshoCd = new AutoCompOptionBean();
        listEigyoshoCd.setValue("listEigyoshoCd0");
        form.setEigyoshokodo(listEigyoshoCd);
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst511Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst511Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listEigyoshoCd0",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("listUserCd0",paramsCaptor_1_Param.get("listUserCd"));
        assertEquals("listDairiShoninshaSetteiDataVersion0",paramsCaptor_1_Param.get("listDairiShoninshaSetteiDataVersion"));
        assertEquals("listTeianShinsei0",paramsCaptor_1_Param.get("listTeianShinsei"));
        assertEquals("listRyokinTorokuShinsei0",paramsCaptor_1_Param.get("listRyokinTorokuShinsei"));
        assertEquals("listUriageSakujo0",paramsCaptor_1_Param.get("listUriageSakujo"));
        assertEquals("listSonotaSeikyuUriageSakujo0",paramsCaptor_1_Param.get("listSonotaSeikyuUriageSakujo"));
        assertEquals("listGenkinKaishuSakujo0",paramsCaptor_1_Param.get("listGenkinKaishuSakujo"));
        assertEquals("listTraceSakujo0",paramsCaptor_1_Param.get("listTraceSakujo"));
        assertEquals("listShimeKaijo0",paramsCaptor_1_Param.get("listShimeKaijo"));
        assertEquals("listLogiDataSakujo0",paramsCaptor_1_Param.get("listLogiDataSakujo"));
        assertEquals("listShukinKaijo0",paramsCaptor_1_Param.get("listShukinKaijo"));
        assertEquals("listPasswordShokika0",paramsCaptor_1_Param.get("listPasswordShokika"));
        assertEquals("listUserMaster0",paramsCaptor_1_Param.get("listUserMaster"));
        assertEquals("listKokyakuMaster0",paramsCaptor_1_Param.get("listKokyakuMaster"));
        assertEquals("listShiiresakiMaster0",paramsCaptor_1_Param.get("listShiiresakiMaster"));
        assertEquals("listShisetsuMaster0",paramsCaptor_1_Param.get("listShisetsuMaster"));
        assertEquals("listGetsugakuJidoSeikyuMaster0",paramsCaptor_1_Param.get("listGetsugakuJidoSeikyuMaster"));
        assertEquals("listEigyobiCalender0",paramsCaptor_1_Param.get("listEigyobiCalender"));
        assertEquals("listLogiRyokinHyo0",paramsCaptor_1_Param.get("listLogiRyokinHyo"));
        assertEquals("listTairyoDataDl0",paramsCaptor_1_Param.get("listTairyoDataDl"));

        assertEquals("mst511-insert-update-check",functionCodeCaptor_2.getValue());
            
        //想定通りにエラーが発生。（メッセージID：COME0018）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0018",summaryCaptor_4.getValue());
    }

    // update_正常_更新処理_新規登録_11-2
    //
    // -------------------テスト条件--------------------------
    // 代理承認コード、代理承認者設定名コードの組み合わせが、代理承認者設定名マスタに存在していない
    // -----------------------------------------------------
    @Test
    public void update_正常_更新処理_新規登録_11_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //代理承認コード、代理承認者設定名コードの組み合わせが、代理承認者設定名マスタに存在していない
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //代理承認者設定検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        //テスト実行
        Mst511Form form = new Mst511Form();
        AutoCompOptionBean listEigyoshoCd = new AutoCompOptionBean();
        listEigyoshoCd.setValue("listEigyoshoCd0");
        form.setEigyoshokodo(listEigyoshoCd);
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst511Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst511Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listEigyoshoCd0",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("listUserCd0",paramsCaptor_1_Param.get("listUserCd"));
        assertEquals("listDairiShoninshaSetteiDataVersion0",paramsCaptor_1_Param.get("listDairiShoninshaSetteiDataVersion"));
        assertEquals("listTeianShinsei0",paramsCaptor_1_Param.get("listTeianShinsei"));
        assertEquals("listRyokinTorokuShinsei0",paramsCaptor_1_Param.get("listRyokinTorokuShinsei"));
        assertEquals("listUriageSakujo0",paramsCaptor_1_Param.get("listUriageSakujo"));
        assertEquals("listSonotaSeikyuUriageSakujo0",paramsCaptor_1_Param.get("listSonotaSeikyuUriageSakujo"));
        assertEquals("listGenkinKaishuSakujo0",paramsCaptor_1_Param.get("listGenkinKaishuSakujo"));
        assertEquals("listTraceSakujo0",paramsCaptor_1_Param.get("listTraceSakujo"));
        assertEquals("listShimeKaijo0",paramsCaptor_1_Param.get("listShimeKaijo"));
        assertEquals("listLogiDataSakujo0",paramsCaptor_1_Param.get("listLogiDataSakujo"));
        assertEquals("listShukinKaijo0",paramsCaptor_1_Param.get("listShukinKaijo"));
        assertEquals("listPasswordShokika0",paramsCaptor_1_Param.get("listPasswordShokika"));
        assertEquals("listUserMaster0",paramsCaptor_1_Param.get("listUserMaster"));
        assertEquals("listKokyakuMaster0",paramsCaptor_1_Param.get("listKokyakuMaster"));
        assertEquals("listShiiresakiMaster0",paramsCaptor_1_Param.get("listShiiresakiMaster"));
        assertEquals("listShisetsuMaster0",paramsCaptor_1_Param.get("listShisetsuMaster"));
        assertEquals("listGetsugakuJidoSeikyuMaster0",paramsCaptor_1_Param.get("listGetsugakuJidoSeikyuMaster"));
        assertEquals("listEigyobiCalender0",paramsCaptor_1_Param.get("listEigyobiCalender"));
        assertEquals("listLogiRyokinHyo0",paramsCaptor_1_Param.get("listLogiRyokinHyo"));
        assertEquals("listTairyoDataDl0",paramsCaptor_1_Param.get("listTairyoDataDl"));
        assertEquals("mst511-insert-update-ichiran",functionCodeCaptor_2.getValue());
        //想定通りに正常終了メッセージ（メッセージID：COMI0007）を表示されること
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0011",summaryCaptor_4.getValue());
        assertEquals("更新",detailCaptor_5.getValue());
    }    

    // update_異常_更新処理_新規登録_11-3
    //
    // -------------------テスト条件--------------------------
    // 代理承認コードが代理承認マスタに存在しない
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_新規登録_11_3 () throws IllegalAccessException, InvocationTargetException {

       // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //代理承認コードが代理承認マスタに存在しない[COME0006]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0006",
                "todofukenCd");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture());

        //テスト実行
        Mst511Form form = new Mst511Form();
        AutoCompOptionBean listEigyoshoCd = new AutoCompOptionBean();
        listEigyoshoCd.setValue("listEigyoshoCd0");
        form.setEigyoshokodo(listEigyoshoCd);
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<=1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst511Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst511Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
       assertEquals("listEigyoshoCd0",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("listUserCd0",paramsCaptor_1_Param.get("listUserCd"));
        assertEquals("listDairiShoninshaSetteiDataVersion0",paramsCaptor_1_Param.get("listDairiShoninshaSetteiDataVersion"));
        assertEquals("listTeianShinsei0",paramsCaptor_1_Param.get("listTeianShinsei"));
        assertEquals("listRyokinTorokuShinsei0",paramsCaptor_1_Param.get("listRyokinTorokuShinsei"));
        assertEquals("listUriageSakujo0",paramsCaptor_1_Param.get("listUriageSakujo"));
        assertEquals("listSonotaSeikyuUriageSakujo0",paramsCaptor_1_Param.get("listSonotaSeikyuUriageSakujo"));
        assertEquals("listGenkinKaishuSakujo0",paramsCaptor_1_Param.get("listGenkinKaishuSakujo"));
        assertEquals("listTraceSakujo0",paramsCaptor_1_Param.get("listTraceSakujo"));
        assertEquals("listShimeKaijo0",paramsCaptor_1_Param.get("listShimeKaijo"));
        assertEquals("listLogiDataSakujo0",paramsCaptor_1_Param.get("listLogiDataSakujo"));
        assertEquals("listShukinKaijo0",paramsCaptor_1_Param.get("listShukinKaijo"));
        assertEquals("listPasswordShokika0",paramsCaptor_1_Param.get("listPasswordShokika"));
        assertEquals("listUserMaster0",paramsCaptor_1_Param.get("listUserMaster"));
        assertEquals("listKokyakuMaster0",paramsCaptor_1_Param.get("listKokyakuMaster"));
        assertEquals("listShiiresakiMaster0",paramsCaptor_1_Param.get("listShiiresakiMaster"));
        assertEquals("listShisetsuMaster0",paramsCaptor_1_Param.get("listShisetsuMaster"));
        assertEquals("listGetsugakuJidoSeikyuMaster0",paramsCaptor_1_Param.get("listGetsugakuJidoSeikyuMaster"));
        assertEquals("listEigyobiCalender0",paramsCaptor_1_Param.get("listEigyobiCalender"));
        assertEquals("listLogiRyokinHyo0",paramsCaptor_1_Param.get("listLogiRyokinHyo"));
        assertEquals("listTairyoDataDl0",paramsCaptor_1_Param.get("listTairyoDataDl"));
        //想定通りにエラーが発生。（メッセージID：COME0006）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0006",summaryCaptor_4.getValue());
    }    

    // update_異常_更新処理_更新登録_11-4
    //
    // -------------------テスト条件--------------------------
    // 代理承認コード、代理承認者設定名コードの組み合わせが、代理承認者設定名マスタに存在しない[COME0006]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_11_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        ////代理承認コード、代理承認者設定名コードの組み合わせが、代理承認者設定名マスタに存在しない[COME0006]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0089",
                "listEigyoshoCd");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());

        //テスト実行
        Mst511Form form = new Mst511Form();
        AutoCompOptionBean listEigyoshoCd = new AutoCompOptionBean();
        listEigyoshoCd.setValue("listEigyoshoCd0");
        form.setEigyoshokodo(listEigyoshoCd);
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst511Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst511Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listEigyoshoCd0",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("listUserCd0",paramsCaptor_1_Param.get("listUserCd"));
        assertEquals("listDairiShoninshaSetteiDataVersion0",paramsCaptor_1_Param.get("listDairiShoninshaSetteiDataVersion"));
        assertEquals("listTeianShinsei0",paramsCaptor_1_Param.get("listTeianShinsei"));
        assertEquals("listRyokinTorokuShinsei0",paramsCaptor_1_Param.get("listRyokinTorokuShinsei"));
        assertEquals("listUriageSakujo0",paramsCaptor_1_Param.get("listUriageSakujo"));
        assertEquals("listSonotaSeikyuUriageSakujo0",paramsCaptor_1_Param.get("listSonotaSeikyuUriageSakujo"));
        assertEquals("listGenkinKaishuSakujo0",paramsCaptor_1_Param.get("listGenkinKaishuSakujo"));
        assertEquals("listTraceSakujo0",paramsCaptor_1_Param.get("listTraceSakujo"));
        assertEquals("listShimeKaijo0",paramsCaptor_1_Param.get("listShimeKaijo"));
        assertEquals("listLogiDataSakujo0",paramsCaptor_1_Param.get("listLogiDataSakujo"));
        assertEquals("listShukinKaijo0",paramsCaptor_1_Param.get("listShukinKaijo"));
        assertEquals("listPasswordShokika0",paramsCaptor_1_Param.get("listPasswordShokika"));
        assertEquals("listUserMaster0",paramsCaptor_1_Param.get("listUserMaster"));
        assertEquals("listKokyakuMaster0",paramsCaptor_1_Param.get("listKokyakuMaster"));
        assertEquals("listShiiresakiMaster0",paramsCaptor_1_Param.get("listShiiresakiMaster"));
        assertEquals("listShisetsuMaster0",paramsCaptor_1_Param.get("listShisetsuMaster"));
        assertEquals("listGetsugakuJidoSeikyuMaster0",paramsCaptor_1_Param.get("listGetsugakuJidoSeikyuMaster"));
        assertEquals("listEigyobiCalender0",paramsCaptor_1_Param.get("listEigyobiCalender"));
        assertEquals("listLogiRyokinHyo0",paramsCaptor_1_Param.get("listLogiRyokinHyo"));
        assertEquals("listTairyoDataDl0",paramsCaptor_1_Param.get("listTairyoDataDl"));
        assertEquals("mst511-insert-update-check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0006）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("MSTE0089",summaryCaptor_4.getValue());
}    

    // update_正常_更新処理_更新登録_11-5
    //
    // -------------------テスト条件--------------------------
    // 代理承認コード、代理承認者設定名コードの組み合わせが、代理承認者設定名マスタに存在しています
    // -----------------------------------------------------
    @Test
    public void update_正常_更新処理_更新登録_11_5 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //代理承認コード、代理承認者設定名コードの組み合わせが、代理承認者設定名マスタに存在しています
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4
                .capture(),detailCaptor_5.capture());        

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //代理承認者設定検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        //テスト実行
        Mst511Form form = new Mst511Form();
        AutoCompOptionBean listEigyoshoCd = new AutoCompOptionBean();
        listEigyoshoCd.setValue("listEigyoshoCd0");
        form.setEigyoshokodo(listEigyoshoCd);
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst511Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst511Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listEigyoshoCd0",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("listUserCd0",paramsCaptor_1_Param.get("listUserCd"));
        assertEquals("listDairiShoninshaSetteiDataVersion0",paramsCaptor_1_Param.get("listDairiShoninshaSetteiDataVersion"));
        assertEquals("listTeianShinsei0",paramsCaptor_1_Param.get("listTeianShinsei"));
        assertEquals("listRyokinTorokuShinsei0",paramsCaptor_1_Param.get("listRyokinTorokuShinsei"));
        assertEquals("listUriageSakujo0",paramsCaptor_1_Param.get("listUriageSakujo"));
        assertEquals("listSonotaSeikyuUriageSakujo0",paramsCaptor_1_Param.get("listSonotaSeikyuUriageSakujo"));
        assertEquals("listGenkinKaishuSakujo0",paramsCaptor_1_Param.get("listGenkinKaishuSakujo"));
        assertEquals("listTraceSakujo0",paramsCaptor_1_Param.get("listTraceSakujo"));
        assertEquals("listShimeKaijo0",paramsCaptor_1_Param.get("listShimeKaijo"));
        assertEquals("listLogiDataSakujo0",paramsCaptor_1_Param.get("listLogiDataSakujo"));
        assertEquals("listShukinKaijo0",paramsCaptor_1_Param.get("listShukinKaijo"));
        assertEquals("listPasswordShokika0",paramsCaptor_1_Param.get("listPasswordShokika"));
        assertEquals("listUserMaster0",paramsCaptor_1_Param.get("listUserMaster"));
        assertEquals("listKokyakuMaster0",paramsCaptor_1_Param.get("listKokyakuMaster"));
        assertEquals("listShiiresakiMaster0",paramsCaptor_1_Param.get("listShiiresakiMaster"));
        assertEquals("listShisetsuMaster0",paramsCaptor_1_Param.get("listShisetsuMaster"));
        assertEquals("listGetsugakuJidoSeikyuMaster0",paramsCaptor_1_Param.get("listGetsugakuJidoSeikyuMaster"));
        assertEquals("listEigyobiCalender0",paramsCaptor_1_Param.get("listEigyobiCalender"));
        assertEquals("listLogiRyokinHyo0",paramsCaptor_1_Param.get("listLogiRyokinHyo"));
        assertEquals("listTairyoDataDl0",paramsCaptor_1_Param.get("listTairyoDataDl"));
        assertEquals("mst511-insert-update-ichiran",functionCodeCaptor_2.getValue());
        //想定通りに正常終了メッセージ（メッセージID：COMI0007）を表示されること
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0011",summaryCaptor_4.getValue());
        assertEquals("更新",detailCaptor_5.getValue());

    }    

    // update_異常_更新処理_更新登録_11-6
    //
    // -------------------テスト条件--------------------------
    // 代理承認コードが代理承認マスタに存在する[MSTE0089]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_11_6 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //代理承認コードが代理承認マスタに存在する[COME0006]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0089",
                "listTodofukenCdlistShimukeChiMeiCd");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());

        //テスト実行
        Mst511Form form = new Mst511Form();
        AutoCompOptionBean listEigyoshoCd = new AutoCompOptionBean();
        listEigyoshoCd.setValue("listEigyoshoCd0");
        form.setEigyoshokodo(listEigyoshoCd);
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst511Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst511Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listEigyoshoCd0",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("listUserCd0",paramsCaptor_1_Param.get("listUserCd"));
        assertEquals("listDairiShoninshaSetteiDataVersion0",paramsCaptor_1_Param.get("listDairiShoninshaSetteiDataVersion"));
        assertEquals("listTeianShinsei0",paramsCaptor_1_Param.get("listTeianShinsei"));
        assertEquals("listRyokinTorokuShinsei0",paramsCaptor_1_Param.get("listRyokinTorokuShinsei"));
        assertEquals("listUriageSakujo0",paramsCaptor_1_Param.get("listUriageSakujo"));
        assertEquals("listSonotaSeikyuUriageSakujo0",paramsCaptor_1_Param.get("listSonotaSeikyuUriageSakujo"));
        assertEquals("listGenkinKaishuSakujo0",paramsCaptor_1_Param.get("listGenkinKaishuSakujo"));
        assertEquals("listTraceSakujo0",paramsCaptor_1_Param.get("listTraceSakujo"));
        assertEquals("listShimeKaijo0",paramsCaptor_1_Param.get("listShimeKaijo"));
        assertEquals("listLogiDataSakujo0",paramsCaptor_1_Param.get("listLogiDataSakujo"));
        assertEquals("listShukinKaijo0",paramsCaptor_1_Param.get("listShukinKaijo"));
        assertEquals("listPasswordShokika0",paramsCaptor_1_Param.get("listPasswordShokika"));
        assertEquals("listUserMaster0",paramsCaptor_1_Param.get("listUserMaster"));
        assertEquals("listKokyakuMaster0",paramsCaptor_1_Param.get("listKokyakuMaster"));
        assertEquals("listShiiresakiMaster0",paramsCaptor_1_Param.get("listShiiresakiMaster"));
        assertEquals("listShisetsuMaster0",paramsCaptor_1_Param.get("listShisetsuMaster"));
        assertEquals("listGetsugakuJidoSeikyuMaster0",paramsCaptor_1_Param.get("listGetsugakuJidoSeikyuMaster"));
        assertEquals("listEigyobiCalender0",paramsCaptor_1_Param.get("listEigyobiCalender"));
        assertEquals("listLogiRyokinHyo0",paramsCaptor_1_Param.get("listLogiRyokinHyo"));
        assertEquals("listTairyoDataDl0",paramsCaptor_1_Param.get("listTairyoDataDl"));
        assertEquals("mst511-insert-update-check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：MSTE0089）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("MSTE0089",summaryCaptor_4.getValue());
    }    

    // update_異常_更新処理_更新登録_11-7
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_11_7 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        //テスト実行
        Mst511Form form = new Mst511Form();
        AutoCompOptionBean listEigyoshoCd = new AutoCompOptionBean();
        listEigyoshoCd.setValue("listEigyoshoCd0");
        form.setEigyoshokodo(listEigyoshoCd);
        //行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        form.setSelectedSearchResult(result);
        target.setMst511Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst511Form();

        //想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("MSTE0093",summaryCaptor_2.getValue());
    }

//    // update_異常_更新処理_更新登録_11-7_1
//    //
//    // -------------------テスト条件--------------------------
//    // 行選択チェック選択 = 0
//    // -----------------------------------------------------
//    @Test
//    public void update_異常_更新処理_更新登録_11_7_1 () throws IllegalAccessException, InvocationTargetException {
//
//        // パラメータキャプチャー
//        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
//        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
//        // Mockitoオブジェクトの予想return値設定
//        MessageModuleBean messageModuleBean = new MessageModuleBean();
//        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture()))
//                .thenReturn(messageModuleBean);
//        //テスト実行
//        Mst511Form form = new Mst511Form();
//        AutoCompOptionBean listEigyoshoCd = new AutoCompOptionBean();
//        listEigyoshoCd.setValue("listEigyoshoCd0");
//        form.setEigyoshokodo(listEigyoshoCd);
//        target.setMst511Form(form);
//        target.update();
//
//        //実施結果Outを取得
//        form = target.getMst511Form();
//
//        //想定通りにエラーが発生。（メッセージID：COME0029）
//        assertEquals("ERROR",levelCaptor_1.getValue());
//        assertEquals("COME0029",summaryCaptor_2.getValue());
//    }    

    // update_異常_更新処理_更新登録_11-8
    //
    // -------------------テスト条件--------------------------
    // 代理承認者設定名コード = ああああ
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_11_8 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Boolean> datasCaptor_3 = ArgumentCaptor.forClass(Boolean.class);
        ArgumentCaptor<List> checksCaptor_4 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<List> checksCaptor_5 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean2 = new MessageModuleBean();
        List<MessageModuleBean> msgList = new ArrayList<>();
        msgList.add(messageModuleBean2);

        when(listCheckBean.check(checksCaptor_4.capture(), checksCaptor_5.capture(), datasCaptor_3.capture()))
                .thenReturn(msgList); 

        //テスト実行
        Mst511Form form = new Mst511Form();
        //行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst511Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst511Form();

}    
    
//   // delRows_正常_代理承認者設定名マスタ削除処理_12-1
//    //
//    // -------------------テスト条件--------------------------
//    // 行選択チェック選択 = 1
//    // 代理承認コード、ユーザーコードの組み合わせが、代理承認者設定名マスタに存在している
//    // -----------------------------------------------------
//    @Test
//    public void delRows_正常_代理承認者設定名マスタ削除処理_12_1 () throws IllegalAccessException, InvocationTargetException {
//
//        // パラメータキャプチャー
//        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
//        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
//        // Mockitoオブジェクトの予想return値設定
//        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
//        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
//        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
//                .thenReturn(serviceInterfaceBean);
//
//        // パラメータキャプチャー
//        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
//        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
//        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
//        // Mockitoオブジェクトの予想return値設定
//        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
//                .capture());
//        //テスト実行
//        List<Map<String, Object>> allList = new ArrayList();
//        Map<String, Object> record = new HashMap<String,Object>();
//        record.put("listEigyoshoCd", "listEigyoshoCd0");
//        allList.add(record);
//        Mst511Form form = new Mst511Form();
//        form.setSelectedSearchResult(allList);
//        //行選択チェック選択 = 1
//        List<Map<String, Object>> result = new ArrayList<>();
//        for (int i = 0; i < 1; i++) {
//            result.add(createRecMapFor_11_1(i));
//        }
//        form.setSelectedSearchResult(result);
//        target.setMst511Form(form);
//        target.delRows(result);
//
//        //実施結果Outを取得
//        form = target.getMst511Form();
//        
//        //想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること代理承認者設定名マスタ削除処理を行う。
//        assertEquals("INFO",levelCaptor_3.getValue());
//        assertEquals("COMI0004",summaryCaptor_4.getValue());
//        assertEquals("削除",detailCaptor_5.getValue());
//    }    

   // delRows_正常_代理承認者設定名マスタ削除処理_12-2
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 2
    // 代理承認コード、代理承認者設定名コードの組み合わせが、代理承認者設定名マスタに存在している
    // -----------------------------------------------------
    @Test
    public void delRows_正常_代理承認者設定名マスタ削除処理_12_2 () throws IllegalAccessException, InvocationTargetException {
        
        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        
        

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture());
        //テスト実行
        Mst511Form form = new Mst511Form();
        AutoCompOptionBean listEigyoshoCd = new AutoCompOptionBean();
        listEigyoshoCd.setValue("listEigyoshoCd0");
        form.setEigyoshokodo(listEigyoshoCd);
        //行選択チェック選択 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        form.setSearchResult(result);
        form.setSelectedSearchResult(result);
        target.setMst511Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst511Form();

        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0011",summaryCaptor_4.getValue());
        assertEquals("削除",detailCaptor_5.getValue());
    }        

   // delRows_正常_代理承認者設定名マスタ削除処理_12-2_1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 2
    // 代理承認コード、代理承認者設定名コードの組み合わせが、代理承認者設定名マスタに存在している
    // -----------------------------------------------------
    @Test
    public void delRows_正常_代理承認者設定名マスタ削除処理_12_2_1 () throws IllegalAccessException, 
            InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        serviceInterfaceBean2.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean,serviceInterfaceBean2);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture());
        //テスト実行
        Mst511Form form = new Mst511Form();
        AutoCompOptionBean listEigyoshoCd = new AutoCompOptionBean();
        listEigyoshoCd.setValue("listEigyoshoCd0");
        form.setEigyoshokodo(listEigyoshoCd);
        //行選択チェック選択 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst511Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst511Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
       assertEquals("listEigyoshoCd0",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("listUserCd0",paramsCaptor_1_Param.get("listUserCd"));
        assertEquals("listDairiShoninshaSetteiDataVersion0",paramsCaptor_1_Param.get("listDairiShoninshaSetteiDataVersion"));
        assertEquals("listTeianShinsei0",paramsCaptor_1_Param.get("listTeianShinsei"));
        assertEquals("listRyokinTorokuShinsei0",paramsCaptor_1_Param.get("listRyokinTorokuShinsei"));
        assertEquals("listUriageSakujo0",paramsCaptor_1_Param.get("listUriageSakujo"));
        assertEquals("listSonotaSeikyuUriageSakujo0",paramsCaptor_1_Param.get("listSonotaSeikyuUriageSakujo"));
        assertEquals("listGenkinKaishuSakujo0",paramsCaptor_1_Param.get("listGenkinKaishuSakujo"));
        assertEquals("listTraceSakujo0",paramsCaptor_1_Param.get("listTraceSakujo"));
        assertEquals("listShimeKaijo0",paramsCaptor_1_Param.get("listShimeKaijo"));
        assertEquals("listLogiDataSakujo0",paramsCaptor_1_Param.get("listLogiDataSakujo"));
        assertEquals("listShukinKaijo0",paramsCaptor_1_Param.get("listShukinKaijo"));
        assertEquals("listPasswordShokika0",paramsCaptor_1_Param.get("listPasswordShokika"));
        assertEquals("listUserMaster0",paramsCaptor_1_Param.get("listUserMaster"));
        assertEquals("listKokyakuMaster0",paramsCaptor_1_Param.get("listKokyakuMaster"));
        assertEquals("listShiiresakiMaster0",paramsCaptor_1_Param.get("listShiiresakiMaster"));
        assertEquals("listShisetsuMaster0",paramsCaptor_1_Param.get("listShisetsuMaster"));
        assertEquals("listGetsugakuJidoSeikyuMaster0",paramsCaptor_1_Param.get("listGetsugakuJidoSeikyuMaster"));
        assertEquals("listEigyobiCalender0",paramsCaptor_1_Param.get("listEigyobiCalender"));
        assertEquals("listLogiRyokinHyo0",paramsCaptor_1_Param.get("listLogiRyokinHyo"));
        assertEquals("listTairyoDataDl0",paramsCaptor_1_Param.get("listTairyoDataDl"));
        assertEquals("mst511-delete-row-detail",functionCodeCaptor_2.getValue());
    }

    // delRows_異常_代理承認者設定名マスタ削除処理_12-3
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // 代理承認コード、代理承認者設定名コードの組み合わせが、代理承認者設定名マスタに存在している
    // -----------------------------------------------------
    @Test
    public void delRows_異常_代理承認者設定名マスタ削除処理_12_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        doNothing().when(messagePropertyBean).message(levelCaptor_1.capture(),summaryCaptor_2.capture());
        //テスト実行
        Mst511Form form = new Mst511Form();
        //行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        form.setSelectedSearchResult(result);
        form.setSearchResult(result);
        target.setMst511Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst511Form();
    }    

    // delRows_異常_代理承認者設定名マスタ削除処理_12-4
    //
    // -------------------テスト条件--------------------------
    // 代理承認コード、代理承認者設定名コードの組み合わせが、代理承認者設定名マスタに存在しない
    // -----------------------------------------------------
    @Test
    public void delRows_異常_代理承認者設定名マスタ削除処理_12_4 () throws IllegalAccessException, InvocationTargetException {

      // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //営業所コード、代理承認者設定名コードの組み合わせが、代理承認者設定名マスタに存在しない[COME0046]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0046","");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2
                .capture())).thenReturn(messageModuleBean);

        //テスト実行
        Mst511Form form = new Mst511Form();
        AutoCompOptionBean listEigyoshoCd = new AutoCompOptionBean();
        listEigyoshoCd.setValue("listEigyoshoCd0");
        form.setEigyoshokodo(listEigyoshoCd);
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        form.setSearchResult(result);
        target.setMst511Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst511Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listEigyoshoCd0",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("listUserCd0",paramsCaptor_1_Param.get("listUserCd"));
        assertEquals("listDairiShoninshaSetteiDataVersion0",paramsCaptor_1_Param.get("listDairiShoninshaSetteiDataVersion"));
        assertEquals("listTeianShinsei0",paramsCaptor_1_Param.get("listTeianShinsei"));
        assertEquals("listRyokinTorokuShinsei0",paramsCaptor_1_Param.get("listRyokinTorokuShinsei"));
        assertEquals("listUriageSakujo0",paramsCaptor_1_Param.get("listUriageSakujo"));
        assertEquals("listSonotaSeikyuUriageSakujo0",paramsCaptor_1_Param.get("listSonotaSeikyuUriageSakujo"));
        assertEquals("listGenkinKaishuSakujo0",paramsCaptor_1_Param.get("listGenkinKaishuSakujo"));
        assertEquals("listTraceSakujo0",paramsCaptor_1_Param.get("listTraceSakujo"));
        assertEquals("listShimeKaijo0",paramsCaptor_1_Param.get("listShimeKaijo"));
        assertEquals("listLogiDataSakujo0",paramsCaptor_1_Param.get("listLogiDataSakujo"));
        assertEquals("listShukinKaijo0",paramsCaptor_1_Param.get("listShukinKaijo"));
        assertEquals("listPasswordShokika0",paramsCaptor_1_Param.get("listPasswordShokika"));
        assertEquals("listUserMaster0",paramsCaptor_1_Param.get("listUserMaster"));
        assertEquals("listKokyakuMaster0",paramsCaptor_1_Param.get("listKokyakuMaster"));
        assertEquals("listShiiresakiMaster0",paramsCaptor_1_Param.get("listShiiresakiMaster"));
        assertEquals("listShisetsuMaster0",paramsCaptor_1_Param.get("listShisetsuMaster"));
        assertEquals("listGetsugakuJidoSeikyuMaster0",paramsCaptor_1_Param.get("listGetsugakuJidoSeikyuMaster"));
        assertEquals("listEigyobiCalender0",paramsCaptor_1_Param.get("listEigyobiCalender"));
        assertEquals("listLogiRyokinHyo0",paramsCaptor_1_Param.get("listLogiRyokinHyo"));
        assertEquals("listTairyoDataDl0",paramsCaptor_1_Param.get("listTairyoDataDl"));
        assertEquals("mst511-delete-exist",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0046）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0046",summaryCaptor_2.getValue());
    }    

    // rirekiIchiran_正常_更新履歴コンテキストメニュー_13-1
    //
    // -------------------テスト条件--------------------------
    // 正常に取得された場合
    // -----------------------------------------------------
    @Test
    public void rirekiIchiran_正常_更新履歴コンテキストメニュー_13_1 () throws IllegalAccessException, 
            InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> titleFlgCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> searchKeyCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(rirekiSyosaiBean).searchList(titleFlgCaptor_1.capture(),functionCodeCaptor_2.capture()
                ,searchKeyCaptor_3.capture());
        //テスト実行
        Mst511Form form = new Mst511Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        form.setSearchResult(result);
        target.setMst511Form(form);
        target.rirekiIchiran();

        //実施結果Outを取得
        form = target.getMst511Form();

    }    

    // searchChange_正常_補充ケース_14-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void searchChange_正常_補充ケース_14_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst511Form form = new Mst511Form();
        target.setMst511Form(form);
        target.searchChange();

        //実施結果Outを取得
        form = target.getMst511Form();

    }

    // menuClick_正常_補充ケース_14-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_14_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst511Form form = new Mst511Form();
        target.setMst511Form(form);
        target.menuClick("","");

        //実施結果Outを取得
        form = target.getMst511Form();

    }

    // menuClick_正常_補充ケース_14-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_14_2_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(1);

        //テスト実行
        Mst511Form form = new Mst511Form();
        target.setMst511Form(form);
        target.menuClick("","");

        //実施結果Outを取得
        form = target.getMst511Form();

    }    
    
    // breadClumClick_正常_補充ケース_14-3
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_14_3 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst511Form form = new Mst511Form();
        target.setMst511Form(form);
        target.breadClumClick("",0);

        //実施結果Outを取得
        form = target.getMst511Form();

    }

    // breadClumClick_正常_補充ケース_14-3_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_14_3_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(0);        
        
        //テスト実行
        Mst511Form form = new Mst511Form();
        target.setMst511Form(form);
        target.breadClumClick("",0);

        //実施結果Outを取得
        form = target.getMst511Form();

    }    
    
    // logoutClick_正常_補充ケース_14-4
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void logoutClick_正常_補充ケース_14_4 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst511Form form = new Mst511Form();
        target.setMst511Form(form);
        target.logoutClick();

        //実施結果Outを取得
        form = target.getMst511Form();

    }

    // delRowsFunc_正常_補充ケース_14-5
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void delRowsFunc_正常_補充ケース_14_5 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst511Form form = new Mst511Form();
        target.setMst511Form(form);
        target.delRowsFunc();

        //実施結果Outを取得
        form = target.getMst511Form();

    }    
    
    private Map<String, String> createRecMapFor_1_1(int i) {
        Map recMap = new HashMap();
        recMap.put("listEigyoshoCd","listEigyoshoCd"+i);
        recMap.put("listUserCd","listUserCd"+i);
        recMap.put("listDairiShoninshaSetteiDataVersion","listDairiShoninshaSetteiDataVersion"+i);
        recMap.put("listTeianShinsei","listTeianShinsei"+i);
        recMap.put("listRyokinTorokuShinsei","listRyokinTorokuShinsei"+i);
        recMap.put("listUriageSakujo","listUriageSakujo"+i);
        recMap.put("listSonotaSeikyuUriageSakujo","listSonotaSeikyuUriageSakujo"+i);
        recMap.put("listGenkinKaishuSakujo","listGenkinKaishuSakujo"+i);
        recMap.put("listTraceSakujo","listTraceSakujo"+i);
        recMap.put("listShimeKaijo","listShimeKaijo"+i);
        recMap.put("listLogiDataSakujo","listLogiDataSakujo"+i);
        recMap.put("listShukinKaijo","listShukinKaijo"+i);
        recMap.put("listPasswordShokika","listPasswordShokika"+i);
        recMap.put("listUserMaster","listUserMaster"+i);
        recMap.put("listKokyakuMaster","listKokyakuMaster"+i);
        recMap.put("listShiiresakiMaster","listShiiresakiMaster"+i);
        recMap.put("listShisetsuMaster","listShisetsuMaster"+i);
        recMap.put("listGetsugakuJidoSeikyuMaster","listGetsugakuJidoSeikyuMaster"+i);
        recMap.put("listEigyobiCalender","listEigyobiCalender"+i);
        recMap.put("listLogiRyokinHyo","listLogiRyokinHyo"+i);
        recMap.put("listTairyoDataDl","listTairyoDataDl"+i);

        return recMap;
    }

    private Map<String, Object> createRecMapFor_11_1(int i) {
        Map recMap = new HashMap();
        recMap.put("listEigyoshoCd","listEigyoshoCd"+i);
        recMap.put("listUserCd","listUserCd"+i);
        recMap.put("listDairiShoninshaSetteiDataVersion","listDairiShoninshaSetteiDataVersion"+i);
        recMap.put("listTeianShinsei","listTeianShinsei"+i);
        recMap.put("listRyokinTorokuShinsei","listRyokinTorokuShinsei"+i);
        recMap.put("listUriageSakujo","listUriageSakujo"+i);
        recMap.put("listSonotaSeikyuUriageSakujo","listSonotaSeikyuUriageSakujo"+i);
        recMap.put("listGenkinKaishuSakujo","listGenkinKaishuSakujo"+i);
        recMap.put("listTraceSakujo","listTraceSakujo"+i);
        recMap.put("listShimeKaijo","listShimeKaijo"+i);
        recMap.put("listLogiDataSakujo","listLogiDataSakujo"+i);
        recMap.put("listShukinKaijo","listShukinKaijo"+i);
        recMap.put("listPasswordShokika","listPasswordShokika"+i);
        recMap.put("listUserMaster","listUserMaster"+i);
        recMap.put("listKokyakuMaster","listKokyakuMaster"+i);
        recMap.put("listShiiresakiMaster","listShiiresakiMaster"+i);
        recMap.put("listShisetsuMaster","listShisetsuMaster"+i);
        recMap.put("listGetsugakuJidoSeikyuMaster","listGetsugakuJidoSeikyuMaster"+i);
        recMap.put("listEigyobiCalender","listEigyobiCalender"+i);
        recMap.put("listLogiRyokinHyo","listLogiRyokinHyo"+i);
        recMap.put("listTairyoDataDl","listTairyoDataDl"+i);

        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }
    
    private void assertForRecList_2_1(Mst511Form form) {
        int i = 0;
        assertEquals(1, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listEigyoshoCd"+i,rec.get("listEigyoshoCd"));
            assertEquals("listUserCd"+i,rec.get("listUserCd"));
            assertEquals("listDairiShoninshaSetteiDataVersion"+i,rec.get("listDairiShoninshaSetteiDataVersion"));
            assertEquals("listTeianShinsei"+i,rec.get("listTeianShinsei"));
            assertEquals("listRyokinTorokuShinsei"+i,rec.get("listRyokinTorokuShinsei"));
            assertEquals("listUriageSakujo"+i,rec.get("listUriageSakujo"));
            assertEquals("listSonotaSeikyuUriageSakujo"+i,rec.get("listSonotaSeikyuUriageSakujo"));
            assertEquals("listGenkinKaishuSakujo"+i,rec.get("listGenkinKaishuSakujo"));
            assertEquals("listTraceSakujo"+i,rec.get("listTraceSakujo"));
            assertEquals("listShimeKaijo"+i,rec.get("listShimeKaijo"));
            assertEquals("listLogiDataSakujo"+i,rec.get("listLogiDataSakujo"));
            assertEquals("listShukinKaijo"+i,rec.get("listShukinKaijo"));
            assertEquals("listPasswordShokika"+i,rec.get("listPasswordShokika"));
            assertEquals("listUserMaster"+i,rec.get("listUserMaster"));
            assertEquals("listKokyakuMaster"+i,rec.get("listKokyakuMaster"));
            assertEquals("listShiiresakiMaster"+i,rec.get("listShiiresakiMaster"));
            assertEquals("listShisetsuMaster"+i,rec.get("listShisetsuMaster"));
            assertEquals("listGetsugakuJidoSeikyuMaster"+i,rec.get("listGetsugakuJidoSeikyuMaster"));
            assertEquals("listEigyobiCalender"+i,rec.get("listEigyobiCalender"));
            assertEquals("listLogiRyokinHyo"+i,rec.get("listLogiRyokinHyo"));
            assertEquals("listTairyoDataDl"+i,rec.get("listTairyoDataDl"));

            i++;
        }
    }    

    private void assertForRecList_2_2(Mst511Form form) {
        int i = 0;
        assertEquals(2, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listEigyoshoCd"+i,rec.get("listEigyoshoCd"));
            assertEquals("listUserCd"+i,rec.get("listUserCd"));
            assertEquals("listDairiShoninshaSetteiDataVersion"+i,rec.get("listDairiShoninshaSetteiDataVersion"));
            assertEquals("listTeianShinsei"+i,rec.get("listTeianShinsei"));
            assertEquals("listRyokinTorokuShinsei"+i,rec.get("listRyokinTorokuShinsei"));
            assertEquals("listUriageSakujo"+i,rec.get("listUriageSakujo"));
            assertEquals("listSonotaSeikyuUriageSakujo"+i,rec.get("listSonotaSeikyuUriageSakujo"));
            assertEquals("listGenkinKaishuSakujo"+i,rec.get("listGenkinKaishuSakujo"));
            assertEquals("listTraceSakujo"+i,rec.get("listTraceSakujo"));
            assertEquals("listShimeKaijo"+i,rec.get("listShimeKaijo"));
            assertEquals("listLogiDataSakujo"+i,rec.get("listLogiDataSakujo"));
            assertEquals("listShukinKaijo"+i,rec.get("listShukinKaijo"));
            assertEquals("listPasswordShokika"+i,rec.get("listPasswordShokika"));
            assertEquals("listUserMaster"+i,rec.get("listUserMaster"));
            assertEquals("listKokyakuMaster"+i,rec.get("listKokyakuMaster"));
            assertEquals("listShiiresakiMaster"+i,rec.get("listShiiresakiMaster"));
            assertEquals("listShisetsuMaster"+i,rec.get("listShisetsuMaster"));
            assertEquals("listGetsugakuJidoSeikyuMaster"+i,rec.get("listGetsugakuJidoSeikyuMaster"));
            assertEquals("listEigyobiCalender"+i,rec.get("listEigyobiCalender"));
            assertEquals("listLogiRyokinHyo"+i,rec.get("listLogiRyokinHyo"));
            assertEquals("listTairyoDataDl"+i,rec.get("listTairyoDataDl"));
            i++;
        }
    }      

    private void assertForRecList_2_3(Mst511Form form) {
        int i = 0;
        assertEquals(0, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listEigyoshoCd"+i,rec.get("listEigyoshoCd"));
            assertEquals("listUserCd"+i,rec.get("listUserCd"));
            assertEquals("listDairiShoninshaSetteiDataVersion"+i,rec.get("listDairiShoninshaSetteiDataVersion"));
            assertEquals("listTeianShinsei"+i,rec.get("listTeianShinsei"));
            assertEquals("listRyokinTorokuShinsei"+i,rec.get("listRyokinTorokuShinsei"));
            assertEquals("listUriageSakujo"+i,rec.get("listUriageSakujo"));
            assertEquals("listSonotaSeikyuUriageSakujo"+i,rec.get("listSonotaSeikyuUriageSakujo"));
            assertEquals("listGenkinKaishuSakujo"+i,rec.get("listGenkinKaishuSakujo"));
            assertEquals("listTraceSakujo"+i,rec.get("listTraceSakujo"));
            assertEquals("listShimeKaijo"+i,rec.get("listShimeKaijo"));
            assertEquals("listLogiDataSakujo"+i,rec.get("listLogiDataSakujo"));
            assertEquals("listShukinKaijo"+i,rec.get("listShukinKaijo"));
            assertEquals("listPasswordShokika"+i,rec.get("listPasswordShokika"));
            assertEquals("listUserMaster"+i,rec.get("listUserMaster"));
            assertEquals("listKokyakuMaster"+i,rec.get("listKokyakuMaster"));
            assertEquals("listShiiresakiMaster"+i,rec.get("listShiiresakiMaster"));
            assertEquals("listShisetsuMaster"+i,rec.get("listShisetsuMaster"));
            assertEquals("listGetsugakuJidoSeikyuMaster"+i,rec.get("listGetsugakuJidoSeikyuMaster"));
            assertEquals("listEigyobiCalender"+i,rec.get("listEigyobiCalender"));
            assertEquals("listLogiRyokinHyo"+i,rec.get("listLogiRyokinHyo"));
            assertEquals("listTairyoDataDl"+i,rec.get("listTairyoDataDl"));

            i++;
        }
    }
    
}
