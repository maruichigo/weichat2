package jp.co.kintetsuls.beans.mst;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst181Form;
import jp.co.kintetsuls.forms.mst.Mst211Form;
import jp.co.kintetsuls.forms.mst.Mst501Form;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;


/**
 * 記事マスタ画面
 *
 * @author 謝航宇
 * @version 2019/3/04 新規作成
 */
public class Mst181BeanTest {

    // テストTarget
    @InjectMocks
    private Mst181Bean target;

    // Mockitoオブジェクト
    @Mock
    private FileBean fileBean;
    @Mock
    private AutoCompleteViewBean autoCompleteViewBean;
    @Mock
    private MasterInfoBean masterInfo;
    @Mock
    private MessagePropertyBean messageProperty;
    @Mock
    private PageCommonBean pageCommon;
    @Mock
    private RirekiSyosaiBean rirekiSyosai;
    @Mock
    private SearchHelpBean searchHelpBean;
    @Mock
    private AuthorityConfBean authConfBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosaiBean;
    @Mock
    private ListCheckBean listCheckBean;

    public Mst181BeanTest() {
    }

    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() {
    }

    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[not null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst181Form mst181Form = new Mst181Form();
        
        //前画面情報[not null]
        when(pageCommon.getPageInfo(keyCaptor_1.capture())).thenReturn(mst181Form);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommon).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst181Form form = new Mst181Form();
        target.setMst181Form(form);
        // 戻ってきた場合、再検索を実施する。
        target.init("","MST031_SCREEN",true);

        //実施結果Outを取得
        form = target.getMst181Form();
        String title = target.getStrTitle();
        String url = target.getUrl();
        BreadCrumbBean breadBean = target.getBreadBean();
        AutoCompleteViewBean autoCompleteViewBean = target.getAutoCompleteViewBean();
        FileBean fileBean = target.getFileBean();
        MessagePropertyBean messagePropertyBean = target.getMessageProperty();
        PageCommonBean pageCommonBean = target.getPageCommon();
        SearchHelpBean searchHelpBean = target.getSearchHelpBean();
        RirekiSyosaiBean rirekiSyosaiBean = target.getRirekiSyosai();
        ListCheckBean listCheckBean = target.getListCheckBean();
        Map<String, Object> rirekiSearchKey = target.getRirekiSearchKey();
        List<MessageModuleBean> msgList = target.getMsgList();
        target.setUrl(url);
        target.setBreadBean(breadBean);
        target.setAutoCompleteViewBean(autoCompleteViewBean);
        target.setFileBean(fileBean);
        target.setMessageProperty(messagePropertyBean);
        target.setPageCommon(pageCommonBean);
        target.setSearchHelpBean(searchHelpBean);
        target.setRirekiSyosai(rirekiSyosaiBean);
        target.setListCheckBean(listCheckBean);
        target.setRirekiSearchKey(rirekiSearchKey);
        target.setMsgList(msgList);
        
        // 実行時に渡すパラメータの検証
        assertEquals("mst181Form",keyCaptor_1.getValue());
        //想定通りに再検索を実施する。
        assertEquals("search_mst181",keyCaptor_2.getValue());
    }

   // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[営業所コード = 111,顧客コード = 111111]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2 () throws IllegalAccessException, InvocationTargetException {
        // Mockitoオブジェクトの予想return値設定
        Mst181Form mst181Form = new Mst181Form();
        //前回検索パラメータ[営業所コード = 111,顧客コード = 111111]
        AutoCompOptionBean eigyoCd = new AutoCompOptionBean();
        eigyoCd.setValue("111");
        mst181Form.setConEigyoshoCd(eigyoCd);
        AutoCompOptionBean kouKyakuCd = new AutoCompOptionBean();
        kouKyakuCd.setValue("111111");
        mst181Form.setConKokyakuCd(kouKyakuCd);
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        //前画面パラメータ[営業所コード = 111,顧客コード = 111111]
        flash.put("mst181Form", mst181Form);
        when(pageCommon.getPageParam()).thenReturn(flash); 
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommon).searchAgain(keyCaptor_2.capture());
        
        // テスト実行
        Mst181Form form = new Mst181Form();
        target.setMst181Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        // 実施結果Outを取得
        form = target.getMst181Form();
        //想定通りに再検索を実施する。
        assertEquals("search_mst181",keyCaptor_2.getValue());
        assertEquals("111",form.getConEigyoshoCd().getValue());
        assertEquals("111111",form.getConKokyakuCd().getValue());
    }  
    
    // init_正常_初期処理_1-2_1
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[営業所コード = 111,顧客コード = 111111]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2_1() throws IllegalAccessException, InvocationTargetException,
            InstantiationException {

        // Mockitoオブジェクトの予想return値設定
        Mst181Form mst181Form = new Mst181Form();
        //前回検索パラメータ[営業所コード = 111,顧客コード = 111111]
        AutoCompOptionBean eigyoCd = new AutoCompOptionBean();
        eigyoCd.setValue("111");
        mst181Form.setConEigyoshoCd(eigyoCd);
        AutoCompOptionBean kouKyakuCd = new AutoCompOptionBean();
        kouKyakuCd.setValue("111111");
        mst181Form.setConKokyakuCd(kouKyakuCd);
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();

        flash.put("mst181Form", null);
        when(pageCommon.getPageParam()).thenReturn(flash);        

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommon).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        // テスト実行
        Mst181Form form = new Mst181Form();
        target.setMst181Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst181Form();

        //想定通りに再検索を実施する。
        assertEquals(null,form.getConEigyoshoCd());
        assertEquals(null,form.getConKokyakuCd());
    } 

    // init_正常_初期処理_1-3
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        //前画面情報[null]
        when(pageCommon.getPageInfo(keyCaptor_1.capture())).thenReturn(null);

        //テスト実行
        Mst181Form form = new Mst181Form();
        target.setMst181Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst181Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst181Form",keyCaptor_1.getValue());
        //想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null,form.getSearchResult());
    }
    
    // init_正常_初期処理_1-3_1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        //前画面情報[null]
        doThrow(IllegalAccessException.class).when(pageCommon).getPageInfo(keyCaptor_1.capture());

        //テスト実行
        Mst181Form form = new Mst181Form();
        target.setMst181Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst181Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst181Form",keyCaptor_1.getValue());
        //想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null,form.getSearchResult());
    }

   // search_正常_検索処理_2-1
    //
    // -------------------テスト条件--------------------------
    // 仕向地検索結果一覧取得
    // 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=0;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommon.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst181Form form = new Mst181Form();
        AutoCompOptionBean eigyoCd = new AutoCompOptionBean();
        eigyoCd.setValue("111");
        form.setConEigyoshoCd(eigyoCd);
        AutoCompOptionBean kouKyakuCd = new AutoCompOptionBean();
        kouKyakuCd.setValue("111111");
        form.setConKokyakuCd(kouKyakuCd);
        target.setMst181Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst181Form();

        // 実行時に渡すパラメータの検証
        assertEquals("111", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("111111", paramsCaptor_1.getValue().get("conKokyakuCd"));
        assertEquals("MST181_SEARCH", functionCodeCaptor_2.getValue());
        //想定通りに仕向地名マスタ一覧を表示されること
        assertForRecList_2_1(form);
    }    

   // search_正常_検索処理_2-2
    //
    // -------------------テスト条件--------------------------
    // 仕向地検索結果一覧取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得 取得件数 = 2
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=1;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommon.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst181Form form = new Mst181Form();
        AutoCompOptionBean eigyoCd = new AutoCompOptionBean();
        eigyoCd.setValue("111");
        form.setConEigyoshoCd(eigyoCd);
        AutoCompOptionBean kouKyakuCd = new AutoCompOptionBean();
        kouKyakuCd.setValue("111111");
        form.setConKokyakuCd(kouKyakuCd);
        target.setMst181Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst181Form();

        // 実行時に渡すパラメータの検証
        assertEquals("111", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("111111", paramsCaptor_1.getValue().get("conKokyakuCd"));
        assertEquals("MST181_SEARCH",functionCodeCaptor_2.getValue());
        //想定通りに仕向地名マスタ一覧を表示されること
        assertForRecList_2_2(form);
    }

    // search_異常_検索処理_2-3
    //
    // -------------------テスト条件--------------------------
    // 仕向地検索結果一覧取得 取得件数 = 0
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得 取得件数 = 0
        List<Map<String, String>> result = new ArrayList<>();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommon.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst181Form form = new Mst181Form();
        AutoCompOptionBean eigyoCd = new AutoCompOptionBean();
        eigyoCd.setValue("全て");
        form.setConEigyoshoCd(eigyoCd);
        AutoCompOptionBean kouKyakuCd = new AutoCompOptionBean();
        kouKyakuCd.setValue("111111");
        form.setConKokyakuCd(kouKyakuCd);
        target.setMst181Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst181Form();

        // 実行時に渡すパラメータの検証
        //想定通りに・一覧は表示しない（ヘッダーのみ） 
        assertEquals("全て", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("111111", paramsCaptor_1.getValue().get("conKokyakuCd"));
        assertEquals("MST181_SEARCH",functionCodeCaptor_2.getValue());
        //想定通りに ・ファンクションボタンは表示（検索前と同じ） 
        assertForRecList_2_3(form);
    }
    
    // count_正常_件数取得処理_2_4
    //
    // -------------------テスト条件--------------------------
    // 記事検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void count_正常_件数取得処理_2_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommon.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // テスト実行
        Mst181Form form = new Mst181Form();
        AutoCompOptionBean eigyoCd = new AutoCompOptionBean();
        eigyoCd.setValue("111");
        form.setConEigyoshoCd(eigyoCd);
        AutoCompOptionBean kouKyakuCd = new AutoCompOptionBean();
        kouKyakuCd.setValue("111111");
        form.setConKokyakuCd(kouKyakuCd);
        target.setMst181Form(form);
        target.count();

        // 実施結果Outを取得
        form = target.getMst181Form();

        // 実行時に渡すパラメータの検証
        assertEquals("111",paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("111111",paramsCaptor_1.getValue().get("conKokyakuCd"));
        assertEquals("MST181_KENSU",functionCodeCaptor_2.getValue());
    }
    
    // clear_正常_クリア処理_3-1
    //
    // -------------------テスト条件--------------------------
    // 検索条件と検索結果がある
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst181Form form = new Mst181Form();
        // 検索条件と検索結果がある
        AutoCompOptionBean eigyoCd = new AutoCompOptionBean();
        eigyoCd.setValue("111");
        eigyoCd.setLabel("営業所");
        form.setConEigyoshoCd(eigyoCd);
        AutoCompOptionBean kouKyakuCd = new AutoCompOptionBean();
        kouKyakuCd.setValue("111111");
        kouKyakuCd.setLabel("13");
        form.setConKokyakuCd(kouKyakuCd);
        target.setMst181Form(form);
        target.clear();
        //実施結果Outを取得
        form = target.getMst181Form();

        //想定通りに正常にClearを実施されること
        assertEquals(null, form.getConEigyoshoCd());
        assertEquals(null, form.getConKokyakuCd());
    }
    
    // clear_正常_クリア処理_3-2
    //
    // -------------------テスト条件--------------------------
    // 検索条件がある、検索結果がない
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst181Form form = new Mst181Form();
        target.setMst181Form(form);
        target.clear();

        //実施結果Outを取得
        form = target.getMst181Form();

        //想定通りに正常にClearを実施されること
        assertEquals(null, form.getConEigyoshoCd());
        assertEquals(null, form.getConKokyakuCd());
    }
    
    // getHeader_正常_ダウンロード_4-1
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void getHeader_正常_ダウンロード_4_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst181Form form = new Mst181Form();
        target.setMst181Form(form);
        List<CSVDto> dto = target.getHeader();

        //実施結果Outを取得
        form = target.getMst181Form();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にCVSのHeaderを設定されること
        assertEquals(null, form.getConEigyoshoCd());
        assertEquals(null, form.getConKokyakuCd());
        assertEquals("営業所コード",dto.get(0).getTitle());
        assertEquals("listEigyoshoCd",dto.get(0).getName());
        assertEquals("顧客コード",dto.get(1).getTitle());
        assertEquals("listKokyakuCd",dto.get(1).getName());
        assertEquals("記事コード",dto.get(2).getTitle());
        assertEquals("listKijiCd",dto.get(2).getName());
        assertEquals("記事内容",dto.get(3).getTitle());
        assertEquals("listKijiNaiyo",dto.get(3).getName());
    }
    
    // beforeDown_正常_ダウンロード_4-2
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=2件
    // -----------------------------------------------------
    @Test
    public void beforeDown_正常_ダウンロード_4_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst181Form form = new Mst181Form();
        target.setMst181Form(form);
        try {
            target.beforeDown("testComment");
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(Mst181BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        //実施結果Outを取得
        form = target.getMst181Form();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にダウンロード理由を記録すること
        assertEquals(null,form.getConEigyoshoCd());
        assertEquals(null,form.getConKokyakuCd());
    } 
    
    // upload_正常_アップロード_5_1
    //
    // -------------------テスト条件--------------------------
    // 
    // -----------------------------------------------------
    @Test
    public void upload_正常_アップロード_5_1() throws IllegalAccessException, InvocationTargetException {
        //テスト実行
        // Mockitoオブジェクトの予想return値設定
        Mst181Form mst181Form = new Mst181Form();
        //前回検索パラメータ[営業所コード = 111,顧客コード = 111111]
        AutoCompOptionBean eigyoCd = new AutoCompOptionBean();
        eigyoCd.setValue("111");
        mst181Form.setConEigyoshoCd(eigyoCd);
        AutoCompOptionBean kouKyakuCd = new AutoCompOptionBean();
        kouKyakuCd.setValue("111111");
        mst181Form.setConKokyakuCd(kouKyakuCd);
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        //前画面パラメータ[営業所コード = 111,顧客コード = 111111]
        flash.put("mst181Form", mst181Form);
        when(pageCommon.getPageParam()).thenReturn(flash);
        target.setMst181Form(mst181Form);
        target.update();

        //実施結果Outを取得
        mst181Form = target.getMst181Form();
        //想定通りに正常にダウンロード理由を記録すること
        assertEquals(null,target.getUrl());
    }
    
    // update_異常_更新処理_新規登録_12-1
    //
    // -------------------テスト条件--------------------------
    // 営業所コード、顧客コード、記事コードの組み合わせが、記事マスタに重複しています[MSTE0100]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_新規登録_12_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 営業所コード、顧客コード、記事コードの組み合わせが、記事マスタに重複しています[MSTE0101]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0100",
                "listEigyoshoCdlistKokyakuCdlistKijiCd");
        when(pageCommon.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst181Form form = new Mst181Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_12_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst181Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst181Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listEigyoshoCd0",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKijiCd0",paramsCaptor_1_Param.get("listKijiCd"));
        assertEquals("listKijiNaiyo0",paramsCaptor_1_Param.get("listKijiNaiyo"));
        assertEquals("listKoshinCounter0",paramsCaptor_1_Param.get("listKoshinCounter"));
        assertEquals("listKijiDataVersion0",paramsCaptor_1_Param.get("listKijiDataVersion"));
        assertEquals("MST181_INSERT_UPDATE_EXIST",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0018）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("MSTE0100",summaryCaptor_4.getValue());
    }
    
    // update_正常_更新処理_新規登録_12-2
    //
    // -------------------テスト条件--------------------------
    // 営業所コード、顧客コード、記事コードの組み合わせが、記事マスタに存在していない
    // -----------------------------------------------------
    @Test
    public void update_正常_更新処理_新規登録_12_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 営業所コード、顧客コード、記事コードの組み合わせが、記事マスタに存在していない
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommon.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommon.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        //テスト実行
        Mst181Form form = new Mst181Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_12_1(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst181Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst181Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listEigyoshoCd0",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKijiCd0",paramsCaptor_1_Param.get("listKijiCd"));
        assertEquals("listKijiNaiyo0",paramsCaptor_1_Param.get("listKijiNaiyo"));
        assertEquals("listKoshinCounter0",paramsCaptor_1_Param.get("listKoshinCounter"));
        assertEquals("listKijiDataVersion0",paramsCaptor_1_Param.get("listKijiDataVersion"));
        assertEquals("MST181_UPDATE",functionCodeCaptor_2.getValue());
        //想定通りに正常終了メッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0011",summaryCaptor_4.getValue());
        assertEquals("更新",detailCaptor_5.getValue());
    } 
    
    // update_異常_更新処理_更新登録_11-3
    //
    // -------------------テスト条件--------------------------
    // 営業所コード、顧客コード、記事コードの組み合わせが、記事マスタに存在しない[MSTE0101]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_11_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        ////都道府県コード、仕向地名コードの組み合わせが、仕向地名マスタに存在しない[COME0006]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0101",
                "listEigyoshoCdlistKokyakuCdlistKijiCd");
        when(pageCommon.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst181Form form = new Mst181Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_12_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst181Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst181Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listEigyoshoCd0",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKijiCd0",paramsCaptor_1_Param.get("listKijiCd"));
        assertEquals("listKijiNaiyo0",paramsCaptor_1_Param.get("listKijiNaiyo"));
        assertEquals("listKoshinCounter0",paramsCaptor_1_Param.get("listKoshinCounter"));
        assertEquals("listKijiDataVersion0",paramsCaptor_1_Param.get("listKijiDataVersion"));
        assertEquals("MST181_INSERT_UPDATE_EXIST",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：MSTE0101）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("MSTE0101",summaryCaptor_4.getValue());
    }  
    
    // update_正常_更新処理_更新登録_12-4
    //
    // -------------------テスト条件--------------------------
    // 営業所コード、顧客コード、記事コードの組み合わせが、記事マスタに存在しています
    // -----------------------------------------------------
    @Test
    public void update_正常_更新処理_更新登録_12_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 営業所コード、顧客コード、記事コードの組み合わせが、記事マスタに存在しています
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommon.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4
                .capture(),detailCaptor_5.capture());        

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommon.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        //テスト実行
        Mst181Form form = new Mst181Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_12_1(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst181Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst181Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listEigyoshoCd0",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKijiCd0",paramsCaptor_1_Param.get("listKijiCd"));
        assertEquals("listKijiNaiyo0",paramsCaptor_1_Param.get("listKijiNaiyo"));
        assertEquals("listKoshinCounter0",paramsCaptor_1_Param.get("listKoshinCounter"));
        assertEquals("listKijiDataVersion0",paramsCaptor_1_Param.get("listKijiDataVersion"));
        assertEquals("MST181_UPDATE",functionCodeCaptor_2.getValue());
        //想定通りに正常終了メッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0011",summaryCaptor_4.getValue());
        assertEquals("更新",detailCaptor_5.getValue());

    } 
  

    // update_異常_更新処理_更新登録_12-5
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_12_5 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messageProperty.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        //テスト実行
        Mst181Form form = new Mst181Form();
        //行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        form.setSelectedSearchResult(result);
        target.setMst181Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst181Form();

        //想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("MSTE0093",summaryCaptor_2.getValue());
    }

    // update_異常_更新処理_更新登録_12_6_1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_12_5_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messageProperty.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        //テスト実行
        Mst181Form form = new Mst181Form();
        target.setMst181Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst181Form();

        //想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("MSTE0093",summaryCaptor_2.getValue());
    }   
    
    // delRows_正常_記事マスタ削除処理_13-1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 1
    // 営業所コード、顧客コード、記事コードの組み合わせが、記事マスタに存在している
    // -----------------------------------------------------
    @Test
    public void delRows_正常_記事マスタ削除処理_13_1 () throws IllegalAccessException, InvocationTargetException {
    
        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommon.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
    
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture());
        //テスト実行
        Mst181Form form = new Mst181Form();
        //行選択チェック選択 = 1
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_12_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst181Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst181Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listEigyoshoCd0",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKijiCd0",paramsCaptor_1_Param.get("listKijiCd"));
        assertEquals("listKijiNaiyo0",paramsCaptor_1_Param.get("listKijiNaiyo"));
        assertEquals("listKoshinCounter0",paramsCaptor_1_Param.get("listKoshinCounter"));
        assertEquals("listKijiDataVersion0",paramsCaptor_1_Param.get("listKijiDataVersion"));
        assertEquals("MST181_DELETE",functionCodeCaptor_2.getValue());
        //想定通りに正常終了メッセージ（メッセージID：COMI0011）を表示されること仕向地名マスタ削除処理を行う。
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0011",summaryCaptor_4.getValue());
        assertEquals("削除",detailCaptor_5.getValue());
    }
    
    // delRows_正常_仕向地名マスタ削除処理_13-2
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 2
    // 営業所コード、顧客コード、記事コードの組み合わせが、記事マスタに存在している
    // -----------------------------------------------------
    @Test
    public void delRows_正常_記事マスタ削除処理_13_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommon.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture());
        //テスト実行
        Mst181Form form = new Mst181Form();
        //行選択チェック選択 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            result.add(createRecMapFor_12_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst181Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst181Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listEigyoshoCd0",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKijiCd0",paramsCaptor_1_Param.get("listKijiCd"));
        assertEquals("listKijiNaiyo0",paramsCaptor_1_Param.get("listKijiNaiyo"));
        assertEquals("listKoshinCounter0",paramsCaptor_1_Param.get("listKoshinCounter"));
        assertEquals("listKijiDataVersion0",paramsCaptor_1_Param.get("listKijiDataVersion"));
        assertEquals("MST181_DELETE",functionCodeCaptor_2.getValue());
        //想定通りに正常終了メッセージ（メッセージID：COMI0011）を表示されること仕向地名マスタ削除処理を行う。
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0011",summaryCaptor_4.getValue());
        assertEquals("削除",detailCaptor_5.getValue());
    } 
    
    // delRows_正常_記事マスタ削除処理_13-2_1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 2
    // 営業所コード、顧客コード、記事コードの組み合わせが、記事マスタに存在している
    // -----------------------------------------------------
    @Test
    public void delRows_正常_記事マスタ削除処理_13_2_1 () throws IllegalAccessException, 
            InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        serviceInterfaceBean2.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        when(pageCommon.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean,serviceInterfaceBean2);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture());
        //テスト実行
        Mst181Form form = new Mst181Form();
        //行選択チェック選択 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            result.add(createRecMapFor_12_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst181Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst181Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listEigyoshoCd0",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKijiCd0",paramsCaptor_1_Param.get("listKijiCd"));
        assertEquals("listKijiNaiyo0",paramsCaptor_1_Param.get("listKijiNaiyo"));
        assertEquals("listKoshinCounter0",paramsCaptor_1_Param.get("listKoshinCounter"));
        assertEquals("listKijiDataVersion0",paramsCaptor_1_Param.get("listKijiDataVersion"));
        assertEquals("MST181_DELETE",functionCodeCaptor_2.getValue());
    }
    
    // delRows_異常_記事マスタ削除処理_13-3
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // 営業所コード、顧客コード、記事コードの組み合わせが、記事マスタに存在している
    // -----------------------------------------------------
    @Test
    public void delRows_異常_記事マスタ削除処理_13_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messageProperty.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        //テスト実行
        Mst181Form form = new Mst181Form();
        //行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        form.setSelectedSearchResult(result);
        target.setMst181Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst181Form();

        //想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0029",summaryCaptor_2.getValue());
    }
    
    // delRows_異常_仕向地名マスタ削除処理_13-4
    //
    // -------------------テスト条件--------------------------
    // 営業所コード、顧客コード、記事コードの組み合わせが、記事マスタに存在しない
    // -----------------------------------------------------
    @Test
    public void delRows_異常_仕向地名マスタ削除処理_13_4 () throws IllegalAccessException, InvocationTargetException {

      // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //都道府県コード、仕向地名コードの組み合わせが、仕向地名マスタに存在しない[COME0006]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0101",
                "listEigyoshoCdlistKokyakuCdlistKijiCd");
        when(pageCommon.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messageProperty.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2
                .capture(),summaryCaptor_3.capture(),summaryCaptor_4.capture())).thenReturn(messageModuleBean);

        //テスト実行
        Mst181Form form = new Mst181Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_12_1(i));
        }
        form.setSelectedSearchResult(result);
        form.setSearchResult(result);
        target.setMst181Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst181Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listEigyoshoCd0",paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKijiCd0",paramsCaptor_1_Param.get("listKijiCd"));
        assertEquals("listKijiNaiyo0",paramsCaptor_1_Param.get("listKijiNaiyo"));
        assertEquals("listKoshinCounter0",paramsCaptor_1_Param.get("listKoshinCounter"));
        assertEquals("listKijiDataVersion0",paramsCaptor_1_Param.get("listKijiDataVersion"));
        assertEquals("MST181_DELETE_EXIST",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：MSTE0101）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("MSTE0101",summaryCaptor_2.getValue());
    } 
    
    // rirekiIchiran_正常_更新履歴コンテキストメニュー_14-1
    //
    // -------------------テスト条件--------------------------
    // 正常に取得された場合
    // -----------------------------------------------------
    @Test
    public void rirekiIchiran_正常_更新履歴コンテキストメニュー_14_1 () throws IllegalAccessException, 
            InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> titleFlgCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> searchKeyCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(rirekiSyosai).searchList(titleFlgCaptor_1.capture(),functionCodeCaptor_2.capture()
                ,searchKeyCaptor_3.capture());
        //テスト実行
        Mst181Form form = new Mst181Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_12_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst181Form(form);
        target.rirekiIchiran();

        //実施結果Outを取得
        form = target.getMst181Form();

        //想定通りに履歴を表示する。
        assertEquals("2",titleFlgCaptor_1.getValue());
        assertEquals("MST181_RIREKI",functionCodeCaptor_2.getValue());
        assertEquals("listEigyoshoCd0",searchKeyCaptor_3.getValue().get("listEigyoshoCd"));
        assertEquals("listKokyakuCd0",searchKeyCaptor_3.getValue().get("listKokyakuCd"));
        assertEquals("listKijiCd0",searchKeyCaptor_3.getValue().get("listKijiCd"));
    }   
    
    // searchChange_正常_補充ケース_15-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void searchChange_正常_補充ケース_15_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst181Form form = new Mst181Form();
        target.setMst181Form(form);
        target.searchChange();

        //実施結果Outを取得
        form = target.getMst181Form();

    }

    // menuClick_正常_補充ケース_14-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_15_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst181Form form = new Mst181Form();
        target.setMst181Form(form);
        target.menuClick("","");

        //実施結果Outを取得
        form = target.getMst181Form();

    }

    // menuClick_正常_補充ケース_14-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_15_2_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(1);

        //テスト実行
        Mst181Form form = new Mst181Form();
        target.setMst181Form(form);
        target.menuClick("","");

        //実施結果Outを取得
        form = target.getMst181Form();

    }    
    
    // breadClumClick_正常_補充ケース_15-3
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_15_3 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst181Form form = new Mst181Form();
        target.setMst181Form(form);
        target.breadClumClick("",0);

        //実施結果Outを取得
        form = target.getMst181Form();

    }

    // breadClumClick_正常_補充ケース_15-3_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_15_3_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(0);        
        
        //テスト実行
        Mst181Form form = new Mst181Form();
        target.setMst181Form(form);
        target.breadClumClick("",0);

        //実施結果Outを取得
        form = target.getMst181Form();

    }    
    
    // logoutClick_正常_補充ケース_14-4
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void logoutClick_正常_補充ケース_15_4 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst181Form form = new Mst181Form();
        target.setMst181Form(form);
        target.logoutClick();

        //実施結果Outを取得
        form = target.getMst181Form();

    }

    // delRowsFunc_正常_補充ケース_14-5
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void delRowsFunc_正常_補充ケース_15_5 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst181Form form = new Mst181Form();
        target.setMst181Form(form);
        target.delRowsFunc();

        //実施結果Outを取得
        form = target.getMst181Form();

    }
    
    private Map<String, String> createRecMapFor_1_1(int i) {
        Map recMap = new HashMap();
        recMap.put("listKijiCd", "listKijiCd" + i);
        recMap.put("listKijiNaiyo", "listKijiNaiyo" + i);
        recMap.put("listEigyoshoCd", "listEigyoshoCd" + i);
        recMap.put("listKokyakuCd", "listKokyakuCd" + i);
        return recMap;
    }

    private void assertForRecList_2_1(Mst181Form form) {
        int i = 0;
        assertEquals(1, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listKijiCd" + i, rec.get("listKijiCd"));
            assertEquals("listKijiNaiyo" + i, rec.get("listKijiNaiyo"));
            i++;
        }
    }    

    private void assertForRecList_2_2(Mst181Form form) {
        int i = 0;
        assertEquals(2, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listKijiCd" + i, rec.get("listKijiCd"));
            assertEquals("listKijiNaiyo" + i, rec.get("listKijiNaiyo"));
            i++;
        }
    }      

    private void assertForRecList_2_3(Mst181Form form) {
        int i = 0;
        assertEquals(0, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listKijiCd" + i, rec.get("listKijiCd"));
            assertEquals("listKijiNaiyo" + i, rec.get("listKijiNaiyo"));
            i++;
        }
    }

    private Map<String, Object> createRecMapFor_12_1(int i) {
        Map recMap = new HashMap();
        recMap.put("listEigyoshoCd", "listEigyoshoCd" + i);
        recMap.put("listKokyakuCd", "listKokyakuCd" + i);
        recMap.put("listKijiCd", "listKijiCd" + i);
        recMap.put("listKijiNaiyo", "listKijiNaiyo" + i);
        recMap.put("listKoshinCounter", "listKoshinCounter" + i);
        recMap.put("listKijiDataVersion", "listKijiDataVersion" + i);
        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }    
    
}
