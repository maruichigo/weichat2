package jp.co.kintetsuls.beans.mst;

import java.io.IOException;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.doThrow;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.KbnBean;
import jp.co.kintetsuls.beans.common.KbnModuleBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst031Form;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import static org.junit.Assert.assertNull;
import org.mockito.Mockito;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.forms.mst.Mst032Form;
import jp.co.kintetsuls.forms.mst.Mst301Form;
import jp.co.kintetsuls.utils.FlashUtil;
import jp.co.sharedsys.beans.base.BaseBean;
import static org.mockito.Mockito.doThrow;


/**
 * 代理承認マスタ画面
 *
 * @author 李信志 (MBP)
 * @version 2019/1/24 新規作成
 */
public class Mst031BeanTest {

    // テストTarget
    @InjectMocks
    private Mst031Bean target;

    // Mockitoオブジェクト
    @Mock
    private FileBean fileBean;
    @Mock
    private AutoCompleteViewBean autoCompleteViewBean;
    @Mock
    private MasterInfoBean masterInfo;
    @Mock
    private MessagePropertyBean messageProperty;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosai;
    @Mock
    private SearchHelpBean searchHelpBean;
    @Mock
    private AuthorityConfBean authorityConfBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private MessagePropertyBean messagePropertyBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosaiBean;
    @Mock
    private ListCheckBean listCheckBean;
    @Mock
    private List<KbnModuleBean> KbnModuleBean;
    @Mock
    private KbnModuleBean kb;
    @Mock
    private KbnBean kbnBean;
    @Mock
    private AuthorityConfBean authConfBean;
    @Mock
    private FlashUtil flashUtil;
    @Mock
    private List<Map<String, Object>> recordList;
    
    public Mst031BeanTest() {
    }

    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() {
    }

    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[not null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst031Form mst031Form = new Mst031Form();
        
        //前画面情報[not null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst031Form);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst031Form form = new Mst031Form();
        target.setMst031Form(form);
        // 戻ってきた場合、再検索を実施する。
        target.init("","MST042_SCREEN",true);

        //実施結果Outを取得
        form = target.getMst031Form();
         String title = target.getTITLE();
        String url = target.getUrl();
        BreadCrumbBean breadBean = target.getBreadBean();
        AutoCompleteViewBean autoCompleteViewBean = target.getAutoCompleteViewBean();
        AuthorityConfBean authorityConfBean  = target.getAuthConfBean();
        FileBean fileBean = target.getFileBean();
        MessagePropertyBean messagePropertyBean = target.getMessagePropertyBean();
        PageCommonBean pageCommonBean = target.getPageCommonBean();
        SearchHelpBean searchHelpBean = target.getSearchHelpBean();
        RirekiSyosaiBean rirekiSyosai = target.getRirekiSyosaiBean();
        KbnBean kbnBean=target.getKbnBean();
        
        //目標方法の值を設定
        target.setKbnBean(kbnBean);
        target.setBreadBean(breadBean);
        target.setAutoCompleteViewBean(autoCompleteViewBean);
        target.setAuthConfBean(authorityConfBean);
        target.setFileBean(fileBean);
        target.setMessagePropertyBean(messagePropertyBean);
        target.setPageCommonBean(pageCommonBean);
        target.setSearchHelpBean(searchHelpBean);
        target.setRirekiSyosaiBean(rirekiSyosai);
        
        // 実行時に渡すパラメータの検証
        assertEquals("mst031Form",keyCaptor_1.getValue());
        //想定通りに再検索を実施する。
        assertEquals("search_mst031",keyCaptor_2.getValue());
    }

    // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[都道府県 = 130,所属終了を含む = null,]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2() throws IllegalAccessException, InvocationTargetException,
            InstantiationException {

        // Mockitoオブジェクトの予想return値設定
        Mst031Form mst031Form = new Mst031Form();
        //前回検索パラメータ[都道府県 = 130,所属終了を含む = null,]
        AutoCompOptionBean conKankatsuEigyoshoCd= new AutoCompOptionBean();
        conKankatsuEigyoshoCd.setValue("130");
        mst031Form.setConKankatsuEigyoshoCd(conKankatsuEigyoshoCd);
        String conSedaiKensakuJoken[] = new String[5];
        conSedaiKensakuJoken[0] = "02";
        mst031Form.setConSedaiKensakuJoken(conSedaiKensakuJoken);
        mst031Form.setConJisCheckKekka(new String[]{"01"});
 
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        //前画面パラメータ[都道府県 = 130,所属終了を含む = null,]
        flash.put("mst031Form", mst031Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);        

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst031Form form = new Mst031Form();
        target.setMst031Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst031Form();

        //想定通りに再検索を実施する。
        assertEquals("search_mst031",keyCaptor_2.getValue());
        assertEquals("130",form.getConKankatsuEigyoshoCd().getValue());
        assertEquals(5,form.getConSedaiKensakuJoken().length);
        assertEquals("01",form.getConJisCheckKekka()[0]);
        
    }

    // init_正常_初期処理_1-2_1
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[都道府県 = 130,所属終了を含む = null,]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2_1() throws IllegalAccessException, InvocationTargetException,
            InstantiationException {

        // Mockitoオブジェクトの予想return値設定
        Mst031Form mst031Form = new Mst031Form();
        //前回検索パラメータ[都道府県 = 130,所属終了を含む = null,]
        AutoCompOptionBean conKankatsuEigyoshoCd = new AutoCompOptionBean();
        conKankatsuEigyoshoCd.setValue("130");
        mst031Form.setConKankatsuEigyoshoCd(conKankatsuEigyoshoCd);
        
        String conSedaiKensakuJoken[] = new String[5];
        conSedaiKensakuJoken[0] = "02";
        mst031Form.setConJisCheckKekka(new String[]{"01"});
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        //前画面パラメータ[都道府県 = 130,所属終了を含む = null,]
        flash.put("mst031Form", null);
        when(pageCommonBean.getPageParam()).thenReturn(flash);        

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst031Form form = new Mst031Form();
        KbnModuleBean kb=new KbnModuleBean();
        List<KbnModuleBean> KbnModuleBean=new ArrayList<>();
        kb.setKbnMei("bbb");
        kb.setKbnCd("aaa");
        KbnModuleBean.add(kb);
        when( kbnBean.getKbnsOfGroupCd("aaa")).thenReturn(KbnModuleBean);

        target.setMst031Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst031Form();

        //想定通りに再検索を実施する。
        assertEquals(0,form.getConJisCheckKekka().length);
        assertEquals(2,form.getConSedaiKensakuJoken().length);
    }    
    
    // init_正常_初期処理_1-3
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        //前画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(null);

        //テスト実行
        Mst031Form form = new Mst031Form();
        target.setMst031Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst031Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst031Form",keyCaptor_1.getValue());
        //想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null,form.getSearchResult());
    }

    // init_正常_初期処理_1-3_1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        //前画面情報[null]
        doThrow(IllegalAccessException.class).when(pageCommonBean).getPageInfo(keyCaptor_1.capture());

        //テスト実行
        Mst031Form form = new Mst031Form();
        target.setMst031Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst031Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst031Form",keyCaptor_1.getValue());
        //想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null,form.getSearchResult());
    }

   // search_正常_検索処理_2-1
    //
    // -------------------テスト条件--------------------------
    // 住所マスタ設定検索結果一覧取得
    // 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //住所マスタ設定検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=0;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        
        //必要な値を設定
        List<String> ssList=new ArrayList<>();
        ssList.add("aaa");
        KbnModuleBean kb=new KbnModuleBean();
        List<KbnModuleBean> KbnModuleBean=new ArrayList<>();
        kb.setKbnMei("bbb");
        kb.setKbnCd("aaa");
        KbnModuleBean.add(kb);
        when( kbnBean.getKbnsOfGroupCd("aaa")).thenReturn(KbnModuleBean);
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        when(authConfBean.getLoginUserShozokuEigyosho()).thenReturn(ssList);
        
        //テスト実行
        Mst031Form form = new Mst031Form();
        String conSedaiKensakuJoken[] = new String[5];
        conSedaiKensakuJoken[0] = "02";
        String ConJisCheckKekka[] = new String[5];
        ConJisCheckKekka[0] = "02";
        String ConRitoKannaiHaiso[] = new String[3];
        ConRitoKannaiHaiso[0] = "02";
        String ConJisCdNomiKensaku[] = new String[3];
        ConJisCdNomiKensaku[0] = "02";
        String ConSakujoZumiNomiKensaku[] = new String[3];
        ConSakujoZumiNomiKensaku[0] = "02";
        AutoCompOptionBean conConJisCd = new AutoCompOptionBean();
        conConJisCd.setValue("conJisCd");
        form.setConJisCd(conConJisCd);
        AutoCompOptionBean conKankatsuEigyoshoCd = new AutoCompOptionBean();
        conKankatsuEigyoshoCd.setValue("conKankatsuEigyoshoCd2");
        
        //フォームを設定
        form.setConTekiyoBi("2019/12/12");
        form.setConJisCdNomiKensaku(ConJisCdNomiKensaku);
        form.setConKankatsuEigyoshoCd(conKankatsuEigyoshoCd);
        form.setConSedaiKensakuJoken(conSedaiKensakuJoken);
        form.setConJisCheckKekka(ConJisCheckKekka);
        form.setConRitoKannaiHaiso(ConRitoKannaiHaiso);
        form.setConSakujoZumiNomiKensaku(ConSakujoZumiNomiKensaku);
        target.setMst031Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst031Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conKankatsuEigyoshoCd2", paramsCaptor_1.getValue().get("conKankatsuEigyoshoCd"));
        assertEquals("02", form.getConSedaiKensakuJoken()[0]);
        assertEquals("02", form.getConJisCheckKekka()[0]);
        assertEquals("02", form.getConRitoKannaiHaiso()[0]);
        assertEquals("mst031-get-detail", functionCodeCaptor_2.getValue());
        //想定通りに住所マスタ設定名マスタ一覧を表示されること
        assertForRecList_2_1(form);
    }    

   // search_正常_検索処理_2-2
    //
    // -------------------テスト条件--------------------------
    // 住所マスタ設定検索結果一覧取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //住所マスタ設定検索結果一覧取得 取得件数 = 2
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=1;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        
        //必要な値を設定
        KbnModuleBean kb=new KbnModuleBean();
        List<KbnModuleBean> KbnModuleBean=new ArrayList<>();
        kb.setKbnMei("bbb");
        kb.setKbnCd("aaa");
        KbnModuleBean.add(kb);
        when( kbnBean.getKbnsOfGroupCd("aaa")).thenReturn(KbnModuleBean);
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        
        //テスト実行
        Mst031Form form = new Mst031Form();
        String conSedaiKensakuJoken[] = new String[5];
        conSedaiKensakuJoken[0] = "02";
        String ConJisCheckKekka[] = new String[5];
        ConJisCheckKekka[0] = "02";
        String ConRitoKannaiHaiso[] = new String[3];
        ConRitoKannaiHaiso[0] = "02";
        String ConJisCdNomiKensaku[] = new String[3];
        ConJisCdNomiKensaku[0] = "02";
        String ConSakujoZumiNomiKensaku[] = new String[3];
        ConSakujoZumiNomiKensaku[0] = "02";
        AutoCompOptionBean conConJisCd = new AutoCompOptionBean();
        conConJisCd.setValue("conJisCd");
        form.setConJisCd(conConJisCd);
        AutoCompOptionBean conKankatsuEigyoshoCd = new AutoCompOptionBean();
        conKankatsuEigyoshoCd.setValue("conKankatsuEigyoshoCd2");
        
        //フォームを設定
        form.setConTekiyoBi("2019/12/12");
        form.setConJisCdNomiKensaku(ConJisCdNomiKensaku);
        form.setConKankatsuEigyoshoCd(conKankatsuEigyoshoCd);
        form.setConSedaiKensakuJoken(conSedaiKensakuJoken);
        form.setConJisCheckKekka(ConJisCheckKekka);
        form.setConRitoKannaiHaiso(ConRitoKannaiHaiso);
        form.setConTekiyoMei("aaa");
        form.setConSakujoZumiNomiKensaku(ConSakujoZumiNomiKensaku);
        target.setMst031Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst031Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null,paramsCaptor_1.getValue().get("jisCd"));
        assertEquals(null,paramsCaptor_1.getValue().get("listShimukeChiCd"));
        assertEquals("mst031-get-detail",functionCodeCaptor_2.getValue());
        //想定通りに住所マスタ設定名マスタ一覧を表示されること
        assertForRecList_2_2(form);
    }

    // search_異常_検索処理_2-3
    //
    // -------------------テスト条件--------------------------
    // 住所マスタ設定検索結果一覧取得 取得件数 = 0
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_3 () throws IllegalAccessException, InvocationTargetException {

       // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得
        List<Map<String, String>> result = new ArrayList<>();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
       when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        
        //必要な値を設定
        KbnModuleBean kb=new KbnModuleBean();
        List<KbnModuleBean> KbnModuleBean=new ArrayList<>();
        kb.setKbnMei("bbb");
        kb.setKbnCd("aaa");
        KbnModuleBean.add(kb);
        when( kbnBean.getKbnsOfGroupCd("aaa")).thenReturn(KbnModuleBean);
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        
        //テスト実行
        Mst031Form form = new Mst031Form();
        String conSedaiKensakuJoken[] = new String[5];
        conSedaiKensakuJoken[0] = "02";
        String ConJisCheckKekka[] = new String[5];
        ConJisCheckKekka[0] = "02";
        String ConRitoKannaiHaiso[] = new String[3];
        ConRitoKannaiHaiso[0] = "02";
        String ConJisCdNomiKensaku[] = new String[3];
        ConJisCdNomiKensaku[0] = "02";
        AutoCompOptionBean conConJisCd = new AutoCompOptionBean();
        conConJisCd.setValue("conJisCd");
        form.setConJisCd(conConJisCd);
        AutoCompOptionBean conKankatsuEigyoshoCd = new AutoCompOptionBean();
        conKankatsuEigyoshoCd.setValue("conKankatsuEigyoshoCd2");
        
        //フォームを設定
        form.setConJisCdNomiKensaku(ConJisCdNomiKensaku);
        form.setConTekiyoBi("2019/12/12");
        form.setConKankatsuEigyoshoCd(conKankatsuEigyoshoCd);
        form.setConSedaiKensakuJoken(conSedaiKensakuJoken);
        form.setConJisCheckKekka(ConJisCheckKekka);
        form.setConRitoKannaiHaiso(ConRitoKannaiHaiso);
        form.setConTekiyoMei("aaa");
        target.setMst031Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst031Form();
        
        // 実行時に渡すパラメータの検証
//        assertEquals(null,paramsCaptor_1.getValue().get("jisCd"));
        assertEquals(null,paramsCaptor_1.getValue().get("listShimukeChiCd"));
        assertEquals(null,paramsCaptor_1.getValue().get("listJusho"));
        assertEquals(null,paramsCaptor_1.getValue().get("listChoAza"));
        assertEquals(null,paramsCaptor_1.getValue().get("listTekiyoKaishiBi"));
        assertEquals(null,paramsCaptor_1.getValue().get("listShimukeChiMei"));
        assertEquals(null,paramsCaptor_1.getValue().get("listKuko"));
        assertEquals(null,paramsCaptor_1.getValue().get("listShuhaiChiku"));
        assertEquals(null,paramsCaptor_1.getValue().get("listKankatsuEigyoshoCd"));
        assertEquals(null,paramsCaptor_1.getValue().get("listKankatsuEigyoshoMei"));
        assertEquals(null,paramsCaptor_1.getValue().get("listKyuEdiJusho"));
        assertEquals(null,paramsCaptor_1.getValue().get("listShinEdiJusho"));
        assertEquals(null,paramsCaptor_1.getValue().get("listRitoFukumu"));
        assertEquals(null,paramsCaptor_1.getValue().get("listRitoKensu"));
        assertEquals(null,paramsCaptor_1.getValue().get("listKannaiHaisoKensu"));
        assertEquals(null,paramsCaptor_1.getValue().get("listKyuJusho"));
        assertEquals(null,paramsCaptor_1.getValue().get("listJisCheck"));
        assertEquals(null,paramsCaptor_1.getValue().get("listTekiyoMei"));
        assertEquals(null,paramsCaptor_1.getValue().get("listShuryo"));
        assertEquals("mst031-get-detail",functionCodeCaptor_2.getValue());
        //想定通りに・一覧は表示しない（ヘッダーのみ） 
        //想定通りに ・ファンクションボタンは表示（検索前と同じ） 
        assertForRecList_2_3(form);
    }

    // count_正常_件数取得処理_2-4
    //
    // -------------------テスト条件--------------------------
    // 住所マスタ設定検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void count_正常_件数取得処理_2_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        
        //必要な値を設定
        KbnModuleBean kb=new KbnModuleBean();
        List<KbnModuleBean> KbnModuleBean=new ArrayList<>();
        kb.setKbnMei("bbb");
        kb.setKbnCd("aaa");
        KbnModuleBean.add(kb);
        when( kbnBean.getKbnsOfGroupCd("aaa")).thenReturn(KbnModuleBean);
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        
        //テスト実行
        Mst031Form form = new Mst031Form();
        String conSedaiKensakuJoken[] = new String[5];
        conSedaiKensakuJoken[0] = "02";
        String ConJisCheckKekka[] = new String[5];
        ConJisCheckKekka[0] = "02";
        String ConRitoKannaiHaiso[] = new String[3];
        ConRitoKannaiHaiso[0] = "02";
        AutoCompOptionBean conKankatsuEigyoshoCd = new AutoCompOptionBean();
        conKankatsuEigyoshoCd.setValue("conKankatsuEigyoshoCd2");
        
        //フォームを設定
        form.setConKankatsuEigyoshoCd(conKankatsuEigyoshoCd);
        form.setConSedaiKensakuJoken(conSedaiKensakuJoken);
        form.setConJisCheckKekka(ConJisCheckKekka);
        form.setConRitoKannaiHaiso(ConRitoKannaiHaiso);
        form.setConTekiyoMei("aaa");
        target.setMst031Form(form);
        target.count(false);

        //実施結果Outを取得
        form = target.getMst031Form();
        
        // 実行時に渡すパラメータの検証
        assertEquals("conKankatsuEigyoshoCd2",form.getConKankatsuEigyoshoCd().getValue());
        assertEquals("02",form.getConSedaiKensakuJoken()[0]);
        assertEquals("02",form.getConJisCheckKekka()[0]);
        assertEquals("02",form.getConRitoKannaiHaiso()[0]);
        assertEquals("mst031-get-kensu",functionCodeCaptor_2.getValue());
        //想定通りに正常にCountを実施されること
      
    }

    // count_正常_件数取得処理_2-4_1
    //
    // -------------------テスト条件--------------------------
    // 住所マスタ設定検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void count_正常_件数取得処理_2_4_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //住所マスタ設定検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        
        //必要な値を設定
        KbnModuleBean kb=new KbnModuleBean();
        List<KbnModuleBean> KbnModuleBean=new ArrayList<>();
        kb.setKbnMei("bbb");
        kb.setKbnCd("aaa");
        KbnModuleBean.add(kb);
        when( kbnBean.getKbnsOfGroupCd("aaa")).thenReturn(KbnModuleBean);
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        
        //テスト実行
        Mst031Form form = new Mst031Form();
        String conSedaiKensakuJoken[] = new String[5];
        conSedaiKensakuJoken[0] = "02";
        String ConJisCheckKekka[] = new String[5];
        ConJisCheckKekka[0] = "02";
        String ConRitoKannaiHaiso[] = new String[3];
        ConRitoKannaiHaiso[0] = "02";
        AutoCompOptionBean conKankatsuEigyoshoCd = new AutoCompOptionBean();
        conKankatsuEigyoshoCd.setValue("conKankatsuEigyoshoCd2");
        
        //フォームを設定
        form.setConKankatsuEigyoshoCd(conKankatsuEigyoshoCd);
        form.setConSedaiKensakuJoken(conSedaiKensakuJoken);
        form.setConJisCheckKekka(ConJisCheckKekka);
        form.setConRitoKannaiHaiso(ConRitoKannaiHaiso);
        form.setConTekiyoMei("aaa");
        target.setMst031Form(form);
        target.count(false);

        //実施結果Outを取得
        form = target.getMst031Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conKankatsuEigyoshoCd2",paramsCaptor_1.getValue().get("conKankatsuEigyoshoCd"));
        assertEquals("mst031-get-kensu",functionCodeCaptor_2.getValue());
        //想定通りに正常にCountを実施されること
        assertEquals("conKankatsuEigyoshoCd2",form.getConKankatsuEigyoshoCd().getValue());
    }    
    
    // count_正常_件数取得処理_2-4_1_1
    //
    // -------------------テスト条件--------------------------
    // 住所マスタ設定検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void count_正常_件数取得処理_2_4_1_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //住所マスタ設定検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        
        //必要な値を設定
        KbnModuleBean kb=new KbnModuleBean();
        List<KbnModuleBean> KbnModuleBean=new ArrayList<>();
        kb.setKbnMei("bbb");
        kb.setKbnCd("aaa");
        KbnModuleBean.add(kb);
        when( kbnBean.getKbnsOfGroupCd("aaa")).thenReturn(KbnModuleBean);
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        
        //テスト実行
        Mst031Form form = new Mst031Form();
        String conSedaiKensakuJoken[] = new String[5];
        conSedaiKensakuJoken[0] = "02";
        String ConJisCheckKekka[] = new String[5];
        ConJisCheckKekka[0] = "02";
        String ConRitoKannaiHaiso[] = new String[0];
        AutoCompOptionBean conKankatsuEigyoshoCd = new AutoCompOptionBean();
        conKankatsuEigyoshoCd.setValue("conKankatsuEigyoshoCd2");
        
        //フォームを設定
        form.setConKankatsuEigyoshoCd(conKankatsuEigyoshoCd);
        form.setConSedaiKensakuJoken(conSedaiKensakuJoken);
        form.setConJisCheckKekka(ConJisCheckKekka);
        form.setConRitoKannaiHaiso(ConRitoKannaiHaiso);
        form.setConTekiyoMei("aaa");
        target.setMst031Form(form);
        target.count(false);

        //実施結果Outを取得
        form = target.getMst031Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conKankatsuEigyoshoCd2",paramsCaptor_1.getValue().get("conKankatsuEigyoshoCd"));
        assertEquals("mst031-get-kensu",functionCodeCaptor_2.getValue());
        //想定通りに正常にCountを実施されること
        assertEquals("conKankatsuEigyoshoCd2",form.getConKankatsuEigyoshoCd().getValue());
    }    
    
    // count_正常_件数取得処理_2-4_2
    //
    // -------------------テスト条件--------------------------
    // 住所マスタ設定検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void count_正常_件数取得処理_2_4_2 () throws IllegalAccessException, InvocationTargetException {

         // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //住所マスタ設定検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        
        //必要な値を設定
        KbnModuleBean kb=new KbnModuleBean();
        List<KbnModuleBean> KbnModuleBean=new ArrayList<>();
        kb.setKbnMei("bbb");
        kb.setKbnCd("aaa");
        KbnModuleBean.add(kb);
        when( kbnBean.getKbnsOfGroupCd("aaa")).thenReturn(KbnModuleBean);
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
       
        //テスト実行
        Mst031Form form = new Mst031Form();
        String conSedaiKensakuJoken[] = new String[5];
        conSedaiKensakuJoken[0] = "02";
        String ConJisCheckKekka[] = new String[5];
        ConJisCheckKekka[0] = "02";
        String ConRitoKannaiHaiso[] = new String[3];
        ConRitoKannaiHaiso[0] = "02";
        AutoCompOptionBean conKankatsuEigyoshoCd = new AutoCompOptionBean();
        conKankatsuEigyoshoCd.setValue("conKankatsuEigyoshoCd2");
        
        //フォームを設定
        form.setConKankatsuEigyoshoCd(conKankatsuEigyoshoCd);
        form.setConSedaiKensakuJoken(conSedaiKensakuJoken);
        form.setConJisCheckKekka(ConJisCheckKekka);
        form.setConRitoKannaiHaiso(ConRitoKannaiHaiso);
        form.setConTekiyoMei("aaa");
        target.setMst031Form(form);
        target.count(false);

        //実施結果Outを取得
        form = target.getMst031Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conKankatsuEigyoshoCd2",paramsCaptor_1.getValue().get("conKankatsuEigyoshoCd"));
        assertEquals("mst031-get-kensu",functionCodeCaptor_2.getValue());
        //想定通りに正常にCountを実施されること
        assertEquals("conKankatsuEigyoshoCd2",form.getConKankatsuEigyoshoCd().getValue());
    } 
    
    // search_正常_検索チェック処理_2_5
    //
    // -------------------テスト条件--------------------------
    // 世代検索条件で適用日指定が選択されている場合
    // -----------------------------------------------------
    @Test
    public void search_正常_検索チェック処理_2_5 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_5 = ArgumentCaptor.forClass(String.class);
        
        doNothing().when(messagePropertyBean).messageToArea(levelCaptor_1.capture(), summaryCaptor_2.capture()
                ,summaryCaptor_3.capture(),summaryCaptor_4.capture(),summaryCaptor_5.capture());
               
        //必要な値を設定
        String aa="ok";
        when( kbnBean.getKbnCdOfKeyCd("SEDAI_KENSAKU_JOKEN_TEKIYO_HI_SHITEI")).thenReturn(aa);
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        
        //テスト実行
        Mst031Form form = new Mst031Form();
        String conSedaiKensakuJoken[] = new String[5];
        conSedaiKensakuJoken[0] = "02";
        conSedaiKensakuJoken[4] = "ok";
        String ConJisCheckKekka[] = new String[5];
        ConJisCheckKekka[0] = "02";
        String ConRitoKannaiHaiso[] = new String[3];
        ConRitoKannaiHaiso[0] = "02";
        AutoCompOptionBean conKankatsuEigyoshoCd = new AutoCompOptionBean();
        conKankatsuEigyoshoCd.setValue("conKankatsuEigyoshoCd2");
        
        //フォームを設定
        form.setConKankatsuEigyoshoCd(conKankatsuEigyoshoCd);
        form.setConSedaiKensakuJoken(conSedaiKensakuJoken);
        form.setConJisCheckKekka(ConJisCheckKekka);
        form.setConRitoKannaiHaiso(ConRitoKannaiHaiso);
        form.setConTekiyoMei("aaa");
        target.setMst031Form(form);
        target.searchCheck();

        //実施結果Outを取得
        form = target.getMst031Form();

        // 実行時に渡すパラメータの検証
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0028",summaryCaptor_2.getValue());
        assertEquals("searchForm:sk:skc:sedaiKensaku_sedaiKensakuCalendar",summaryCaptor_3.getValue());
    }
    
    // search_正常_検索チェック処理_2_6
    //
    // -------------------テスト条件--------------------------
    // 世代検索条件で適用日指定が選択されている場合
    // -----------------------------------------------------
    @Test
    public void search_正常_検索チェック処理_2_6 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_5 = ArgumentCaptor.forClass(String.class);
        doNothing().when(messagePropertyBean).messageToArea(levelCaptor_1.capture(), summaryCaptor_2.capture()
                ,summaryCaptor_3.capture(),summaryCaptor_4.capture(),summaryCaptor_5.capture());
               
        //必要な値を設定
        String aa="ok";
        when( kbnBean.getKbnCdOfKeyCd("SEDAI_KENSAKU_JOKEN_TEKIYO_HI_SHITEI")).thenReturn(aa);
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        
        //テスト実行
        Mst031Form form = new Mst031Form();
        String conSedaiKensakuJoken[] = new String[5];
        conSedaiKensakuJoken[0] = "";
        form.setConSedaiKensakuJoken(conSedaiKensakuJoken);
        form.setConTekiyoMei("aaa");
        target.setMst031Form(form);
        target.searchCheck();

        //実施結果Outを取得
        form = target.getMst031Form();

    }
    
    // search_正常_検索処理_2_7
    //
    // -------------------テスト条件--------------------------
    // DB検索用のチェックボックスパラメータを設定する

    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_7 () throws IllegalAccessException, InvocationTargetException {

        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //住所マスタ設定検索結果一覧取得 取得件数 = 2
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=1;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        
        //必要な値を設定
        KbnModuleBean kb=new KbnModuleBean();
        List<KbnModuleBean> KbnModuleBean=new ArrayList<>();
        kb.setKbnMei("bbb");
        kb.setKbnCd("02");
        KbnModuleBean.add(kb);
        when( kbnBean.getKbnsOfGroupCd("SEDAI_KENSAKU_JOKEN")).thenReturn(KbnModuleBean);
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        
        //テスト実行
        Mst031Form form = new Mst031Form();
        String conSedaiKensakuJoken[] = new String[5];
        conSedaiKensakuJoken[0] = "02";
        String ConJisCheckKekka[] = new String[5];
        ConJisCheckKekka[0] = "02";
        String ConRitoKannaiHaiso[] = new String[3];
        ConRitoKannaiHaiso[0] = "02";
        String ConJisCdNomiKensaku[] = new String[3];
        ConJisCdNomiKensaku[0] = "02";
        String ConSakujoZumiNomiKensaku[] = new String[3];
        ConSakujoZumiNomiKensaku[0] = "02";
        AutoCompOptionBean conConJisCd = new AutoCompOptionBean();
        conConJisCd.setValue("conJisCd");
        form.setConJisCd(conConJisCd);
        AutoCompOptionBean conKankatsuEigyoshoCd = new AutoCompOptionBean();
        conKankatsuEigyoshoCd.setValue("conKankatsuEigyoshoCd2");
        
        //フォームを設定
        form.setConTekiyoBi("2019/12/12");
        form.setConJisCdNomiKensaku(ConJisCdNomiKensaku);
        form.setConKankatsuEigyoshoCd(conKankatsuEigyoshoCd);
        form.setConSedaiKensakuJoken(conSedaiKensakuJoken);
        form.setConJisCheckKekka(ConJisCheckKekka);
        form.setConRitoKannaiHaiso(ConRitoKannaiHaiso);
        form.setConTekiyoMei("aaa");
        form.setConSakujoZumiNomiKensaku(ConSakujoZumiNomiKensaku);
        target.setMst031Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst031Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null,paramsCaptor_1.getValue().get("jisCd"));
        assertEquals(null,paramsCaptor_1.getValue().get("listShimukeChiCd"));
        assertEquals("mst031-get-detail",functionCodeCaptor_2.getValue());
        //想定通りに住所マスタ設定名マスタ一覧を表示されること
        assertForRecList_2_2(form);

    }
    
    // search_正常_検索処理_2_7_1
    //
    // -------------------テスト条件--------------------------
    // DB検索用のチェックボックスパラメータを設定する

    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_7_1 () throws IllegalAccessException, InvocationTargetException {

        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //住所マスタ設定検索結果一覧取得 取得件数 = 2
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=1;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        
        //必要な値を設定
        KbnModuleBean kb=new KbnModuleBean();
        List<KbnModuleBean> KbnModuleBean=new ArrayList<>();
        kb.setKbnMei("bbb");
        kb.setKbnCd("021");
        KbnModuleBean.add(kb);
        when( kbnBean.getKbnsOfGroupCd("SEDAI_KENSAKU_JOKEN")).thenReturn(KbnModuleBean);
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        
        //テスト実行
        Mst031Form form = new Mst031Form();
        String conSedaiKensakuJoken[] = new String[5];
        conSedaiKensakuJoken[0] = "02";
        String ConJisCheckKekka[] = new String[5];
        ConJisCheckKekka[0] = "02";
        String ConRitoKannaiHaiso[] = new String[3];
        ConRitoKannaiHaiso[0] = "02";
        String ConJisCdNomiKensaku[] = new String[3];
        ConJisCdNomiKensaku[0] = "02";
        String ConSakujoZumiNomiKensaku[] = new String[3];
        ConSakujoZumiNomiKensaku[0] = "02";
        AutoCompOptionBean conConJisCd = new AutoCompOptionBean();
        conConJisCd.setValue("conJisCd");
        form.setConJisCd(conConJisCd);
        AutoCompOptionBean conKankatsuEigyoshoCd = new AutoCompOptionBean();
        conKankatsuEigyoshoCd.setValue("conKankatsuEigyoshoCd2");
        
        //フォームを設定
        form.setConTekiyoBi("2019/12/12");
        form.setConJisCdNomiKensaku(ConJisCdNomiKensaku);
        form.setConKankatsuEigyoshoCd(conKankatsuEigyoshoCd);
        form.setConSedaiKensakuJoken(conSedaiKensakuJoken);
        form.setConJisCheckKekka(ConJisCheckKekka);
        form.setConRitoKannaiHaiso(ConRitoKannaiHaiso);
        form.setConTekiyoMei("aaa");
        form.setConSakujoZumiNomiKensaku(ConSakujoZumiNomiKensaku);
        target.setMst031Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst031Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null,paramsCaptor_1.getValue().get("jisCd"));
        assertEquals(null,paramsCaptor_1.getValue().get("listShimukeChiCd"));
        assertEquals("mst031-get-detail",functionCodeCaptor_2.getValue());
        //想定通りに住所マスタ設定名マスタ一覧を表示されること
        assertForRecList_2_2(form);

    }
    
     // search_正常_検索処理_2_8
    //
    // -------------------テスト条件--------------------------
    // 未能檢索
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_8 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得
        List<Map<String, String>> result = new ArrayList<>();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        doThrow(IOException.class).when(pageCommonBean).getDBInfo(paramsCaptor_1.capture(), 
                functionCodeCaptor_2.capture());
        
        //必要な値を設定
        KbnModuleBean kb=new KbnModuleBean();
        List<KbnModuleBean> KbnModuleBean=new ArrayList<>();
        kb.setKbnMei("bbb");
        kb.setKbnCd("02");
        KbnModuleBean.add(kb);
        when( kbnBean.getKbnsOfGroupCd("SEDAI_KENSAKU_JOKEN")).thenReturn(KbnModuleBean);
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        Mst031Form form = new Mst031Form();
        String conSedaiKensakuJoken[] = new String[5];
        conSedaiKensakuJoken[0] = "02";
        String ConJisCheckKekka[] = new String[5];
        ConJisCheckKekka[0] = "02";
        String ConRitoKannaiHaiso[] = new String[3];
        ConRitoKannaiHaiso[0] = "02";
        String ConJisCdNomiKensaku[] = new String[3];
        ConJisCdNomiKensaku[0] = "02";
        String ConSakujoZumiNomiKensaku[] = new String[3];
        ConSakujoZumiNomiKensaku[0] = "02";
        AutoCompOptionBean conConJisCd = new AutoCompOptionBean();
        conConJisCd.setValue("conJisCd");
        form.setConJisCd(conConJisCd);
        AutoCompOptionBean conKankatsuEigyoshoCd = new AutoCompOptionBean();
        conKankatsuEigyoshoCd.setValue("conKankatsuEigyoshoCd2");
        
        //フォームを設定
        form.setConTekiyoBi("2019/12/12");
        form.setConJisCdNomiKensaku(ConJisCdNomiKensaku);
        form.setConKankatsuEigyoshoCd(conKankatsuEigyoshoCd);
        form.setConSedaiKensakuJoken(conSedaiKensakuJoken);
        form.setConJisCheckKekka(ConJisCheckKekka);
        form.setConRitoKannaiHaiso(ConRitoKannaiHaiso);
        form.setConTekiyoMei("aaa");
        form.setConSakujoZumiNomiKensaku(ConSakujoZumiNomiKensaku);
        target.setMst031Form(form);
        
        //テスト実行
        target.search();

    }
    
    // clear_正常_クリア処理_3-1
    //
    // -------------------テスト条件--------------------------
    // 検索条件と検索結果がある
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_1 () throws IllegalAccessException, InvocationTargetException {

        //フォームを設定
        Mst031Form form = new Mst031Form();
        //必要な値を設定
        AutoCompOptionBean conKankatsuEigyoshoCd = new AutoCompOptionBean();
        conKankatsuEigyoshoCd.setValue("130");
        conKankatsuEigyoshoCd.setLabel("東京");
        form.setConKankatsuEigyoshoCd(conKankatsuEigyoshoCd);
        form.setConSedaiKensakuJoken(new String[]{"01"});
        form.setConJisCdNomiKensaku(new String[]{"01"});
        KbnModuleBean kb=new KbnModuleBean();
        List<KbnModuleBean> KbnModuleBean=new ArrayList<>();
        kb.setKbnMei("bbb");
        kb.setKbnCd("aaa");
        KbnModuleBean.add(kb);
        when( kbnBean.getKbnsOfGroupCd("JIS_CHECK_KEKKA")).thenReturn(KbnModuleBean);
        
        //テスト実行
        target.setMst031Form(form);
        target.clear();

        //実施結果Outを取得
        form = target.getMst031Form();

        //想定通りに正常にClearを実施されること
        assertEquals(null, form.getConKankatsuEigyoshoCd());
        assertEquals(null, form.getConSedaiKensakuJoken()[0]);
        assertEquals(null, form.getConJisCdNomiKensaku());
    }

    // clear_正常_クリア処理_3-2
    //
    // -------------------テスト条件--------------------------
    // 検索条件がある、検索結果がない
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst031Form form = new Mst031Form();
        target.setMst031Form(form);
        target.clear();

        //実施結果Outを取得
        form = target.getMst031Form();

        //想定通りに正常にClearを実施されること
        assertEquals(null, form.getConKankatsuEigyoshoCd());
        assertEquals(null, form.getConSedaiKensakuJoken()[0]);
        assertEquals(null, form.getConJisCdNomiKensaku());
    }
    
    // upload_正常_upload処理_4_1
    //
    // -------------------テスト条件--------------------------
    // 検索条件がある、検索結果がない
    // -----------------------------------------------------
    @Test
    public void upload_正常処理_4_11 () throws IllegalAccessException, InvocationTargetException {
        
        //必要な値を設定
        Flash flash = new FlashKls();
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        Flash flash2 = new FlashKls();
        when(flashUtil.getPageParam()).thenReturn(flash2);
        //テスト実行
        target.upload();
    }
    
    
     // detailClick_正常_jisチェック_7-1
    //
    // -------------------テスト条件--------------------------
    // 検索条件と検索結果がある buttonflg=true
    // -----------------------------------------------------
    @Test
    public void detailClick_正常_処理_7_1 () throws IllegalAccessException, InvocationTargetException, SystemException {
        
        //必要な値を設定
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        String ConJisCheckKekka[] = new String[6];
        ConJisCheckKekka[0] = "02";
        doNothing().when(messagePropertyBean).message(levelCaptor_1.capture(),summaryCaptor_2.capture());
         Flash flash = new FlashKls();
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        when(flashUtil.getPageParam()).thenReturn(flash);
        
        //テスト実行
        Mst031Form form = new Mst031Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<3;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        
        // 検索条件と検索結果がある
        target.setMst031Form(form);
        target.detailClick(true);
        
        //実施結果Outを取得
        form = target.getMst031Form();
    }
    
    // detailClick_正常_jisチェック_7-2
    //
    // -------------------テスト条件--------------------------
    // 検索条件と検索結果がある buttonflg=false
    // -----------------------------------------------------
    @Test
    public void detailClick_正常_処理_7_2 () throws IllegalAccessException, InvocationTargetException, SystemException {
        
        //必要な値を設定
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        String ConJisCheckKekka[] = new String[6];
        ConJisCheckKekka[0] = "02";
        doNothing().when(messagePropertyBean).message(levelCaptor_1.capture(),summaryCaptor_2.capture());
         Flash flash = new FlashKls();
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        when(flashUtil.getPageParam()).thenReturn(flash);
        
        //テスト実行
        Mst031Form form = new Mst031Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<3;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setConTekiyoBi("2019/12/12");
        form.setSelectedSearchResult(result);
        
        // 検索条件と検索結果がある
        target.setMst031Form(form);
        target.detailClick(false);
        
        //実施結果Outを取得
        form = target.getMst031Form();
    }
    
    // 仕向地コードリンククリック処理_正常_処理_8-1
    //
    // -------------------テスト条件--------------------------
    // 検索条件と検索結果がある
    // -----------------------------------------------------
    @Test
    public void linkClick_正常_処理_8_1 () throws IllegalAccessException, InvocationTargetException, SystemException {
        
        //仮想の値を設定
        String shimukeChiCd="day1";
        String tekiyoKaishiBi="day2";
        
        //テスト実行
        Mst032Form mst032Form = new Mst032Form();
        mst032Form.setConTekiyoKaishibi(tekiyoKaishiBi);
        mst032Form.setConJisCdTaihi(shimukeChiCd);
        Flash flash = new FlashKls();
        flash.put("mst032Form", mst032Form);
        Flash flash2 = new FlashKls();
        flash2.put("nextScreen", "mst032");
        when(flashUtil.getPageParam()) .thenReturn(flash2);
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        
        // 検索条件と検索結果がある
        target.linkClick(shimukeChiCd, tekiyoKaishiBi);
        
    }
    
     // getHeader_正常_ダウンロード_5-1
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void getHeader_正常_ダウンロード_5_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst031Form form = new Mst031Form();
        target.setMst031Form(form);

        List<CSVDto> dto = target.getHeader();

        //実施結果Outを取得
        form = target.getMst031Form();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にCVSのHeaderを設定されること
        assertEquals(null,form.getConJisCd());
        assertEquals(null,form.getConJisCdNomiKensaku());
        assertEquals(null,form.getConJisCheckKekka());
        assertEquals(null,form.getConJisJusho());
        assertEquals(null,form.getConKanjiJusho());
        assertEquals(null,form.getConKankatsuEigyoshoCd());
        assertEquals(null,form.getConRitoKannaiHaiso());
        assertEquals(null,form.getConSakujoZumiNomiKensaku());
        assertEquals(null,form.getConSedaiKensakuJoken());
        assertEquals(null,form.getConTekiyoBi());
        assertEquals(null,form.getConTekiyoMei());
        assertEquals(null,form.getConTodofuken());
        //仕向地コード
        assertEquals("仕向地コード",dto.get(0).getTitle());
        assertEquals("listShimukeChiCd",dto.get(0).getName());
        //住所
        assertEquals("住所",dto.get(1).getTitle());
        assertEquals("listJusho",dto.get(1).getName());
        //町字
        assertEquals("町字",dto.get(2).getTitle());
        assertEquals("listChoAza",dto.get(2).getName());
        //適用開始日
        assertEquals("適用開始日",dto.get(3).getTitle());
        assertEquals("listTekiyoKaishiBi",dto.get(3).getName());
        //仕向地名
        assertEquals("仕向地名",dto.get(4).getTitle());
        assertEquals("listShimukeChiMei",dto.get(4).getName());
        //空港
        assertEquals("空港",dto.get(5).getTitle());
        assertEquals("listKuko",dto.get(5).getName());
        //集配地区
        assertEquals("集配地区",dto.get(6).getTitle());
        assertEquals("listShuhaiChiku",dto.get(6).getName());
        //管轄営業所コード
        assertEquals("管轄営業所コード",dto.get(7).getTitle());
        assertEquals("listKankatsuEigyoshoCd",dto.get(7).getName());
        //管轄営業所名
        assertEquals("管轄営業所名",dto.get(8).getTitle());
        assertEquals("listKankatsuEigyoshoMei",dto.get(8).getName());
        //旧EDI住所
        assertEquals("旧EDI住所",dto.get(9).getTitle());
        assertEquals("listKyuEdiJusho",dto.get(9).getName());
        //新EDI住所
        assertEquals("新EDI住所",dto.get(10).getTitle());
        assertEquals("listShinEdiJusho",dto.get(10).getName());
        //離島含む
        assertEquals("離島含む",dto.get(11).getTitle());
        assertEquals("listRitoFukumu",dto.get(11).getName());
        //離島件数
        assertEquals("離島件数",dto.get(12).getTitle());
        assertEquals("listRitoKensu",dto.get(12).getName());
        //館内配送件数
        assertEquals("館内配送件数",dto.get(13).getTitle());
        assertEquals("listKannaiHaisoKensu",dto.get(13).getName());
        //旧住所
        assertEquals("旧住所",dto.get(14).getTitle());
        assertEquals("listKyuJusho",dto.get(14).getName());
        //JISチェック
        assertEquals("JISチェック",dto.get(15).getTitle());
        assertEquals("listJisCheck",dto.get(15).getName());
        //適用名
        assertEquals("適用名",dto.get(16).getTitle());
        assertEquals("conTekiyoMei",dto.get(16).getName());
        //終了
        assertEquals("終了",dto.get(17).getTitle());
        assertEquals("listShuryo",dto.get(17).getName());

        
    }
    
    // beforeDown_正常_ダウンロード_5-2
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=2件
    // -----------------------------------------------------
    @Test
    public void beforeDown_正常_ダウンロード_5_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst031Form form = new Mst031Form();
        target.setMst031Form(form);
        try {
            target.beforeDown("testComment");
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(Mst031BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        //実施結果Outを取得
        form = target.getMst031Form();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にダウンロード理由を記録すること
        assertEquals(null,form.getConJisCd());
    }
    
    
    // rirekiIchiran_正常_更新履歴コンテキストメニュー_13-1
    //
    // -------------------テスト条件--------------------------
    // 正常に取得された場合
    // -----------------------------------------------------
    @Test
    public void rirekiIchiran_正常_更新履歴コンテキストメニュー_13_1 () throws IllegalAccessException, 
            InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> titleFlgCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> searchKeyCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(rirekiSyosaiBean).searchList(titleFlgCaptor_1.capture(),functionCodeCaptor_2.capture()
                ,searchKeyCaptor_3.capture());
        //テスト実行
        Mst031Form form = new Mst031Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        form.setSearchResult(result);
        target.setMst031Form(form);
        target.rirekiIchiran();

        //実施結果Outを取得
        form = target.getMst031Form();

    }    

    // searchChange_正常_補充ケース_14-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void searchChange_正常_補充ケース_14_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst031Form form = new Mst031Form();
        target.setMst031Form(form);
        target.searchChange();

        //実施結果Outを取得
        form = target.getMst031Form();

    }

    // menuClick_正常_補充ケース_14-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_14_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst031Form form = new Mst031Form();
        target.setMst031Form(form);
        target.menuClick("","");

        //実施結果Outを取得
        form = target.getMst031Form();

    }

    // menuClick_正常_補充ケース_14-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_14_2_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(1);

        //テスト実行
        Mst031Form form = new Mst031Form();
        target.setMst031Form(form);
        target.menuClick("","");

        //実施結果Outを取得
        form = target.getMst031Form();

    }    
    
    // breadClumClick_正常_補充ケース_14-3
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_14_3 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst031Form form = new Mst031Form();
        target.setMst031Form(form);
        target.breadClumClick("",0);

        //実施結果Outを取得
        form = target.getMst031Form();

    }
    
    // breadClumClick_正常_補充ケース_14-3_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_14_3_1 () throws IllegalAccessException, InvocationTargetException {
        
        //ぱんくつを削除
        doThrow(IllegalAccessException.class).when(breadBean).pop(0);        
        
        //テスト実行
        Mst031Form form = new Mst031Form();
        target.setMst031Form(form);
        target.breadClumClick("",0);

        //実施結果Outを取得
        form = target.getMst031Form();

    }    
    
    // logoutClick_正常_補充ケース_14-4
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void logoutClick_正常_補充ケース_14_4 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst031Form form = new Mst031Form();
        target.setMst031Form(form);
        target.logoutClick();

        //実施結果Outを取得
        form = target.getMst031Form();

    }

    // shimukeChiClick_正常_画面遷移ケース_15
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void shimukeChiClick_正常_画面遷移ケース_15 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Flash flash = new FlashKls();
        Flash flash2 = new FlashKls();
        flash2.put("nextScreen", "mst032");
        when(flashUtil.getPageParam()) .thenReturn(flash2);
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        target.shimukeChiClick();

    }
    
    
    private Map<String, String> createRecMapFor_1_1(int i) {
        
        //仮想の値を設定
        Map recMap = new HashMap();
        //JISコード
        recMap.put("jisCd","jisCd"+i);
        //仕向地コード
        recMap.put("listShimukeChiCd","listShimukeChiCd"+i);
        //住所
        recMap.put("listJusho","listJusho"+i);
        //町字
        recMap.put("listChoAza","listChoAza"+i);
        //適用開始日
        recMap.put("listTekiyoKaishiBi","listTekiyoKaishiBi"+i);
        //仕向地名
        recMap.put("listShimukeChiMei","listShimukeChiMei"+i);
        //空港
        recMap.put("listKuko","listKuko"+i);
        //集配地区
        recMap.put("listShuhaiChiku","listShuhaiChiku"+i);
        //管轄営業所コード
        recMap.put("listKankatsuEigyoshoCd","listKankatsuEigyoshoCd"+i);
        //管轄営業所名
        recMap.put("listKankatsuEigyoshoMei","listKankatsuEigyoshoMei"+i);
        //旧EDI住所
        recMap.put("listKyuEdiJusho","listKyuEdiJusho"+i);
        //新EDI住所
        recMap.put("listShinEdiJusho","listShinEdiJusho"+i);
        //離島含む
        recMap.put("listRitoFukumu","listRitoFukumu"+i);
        //離島件数
        recMap.put("listRitoKensu","listRitoKensu"+i);
        //館内配送件数
        recMap.put("listKannaiHaisoKensu","listKannaiHaisoKensu"+i);
        //旧住所
        recMap.put("listKyuJusho","listKyuJusho"+i);
        //JISチェック
        recMap.put("listJisCheck","listJisCheck"+i);
        //適用名
        recMap.put("listTekiyoMei","listTekiyoMei"+i);
        //終了日
        recMap.put("listShuryo","listShuryo"+i);
        
        return recMap;
    }

    private Map<String, Object> createRecMapFor_11_1(int i) {
        
        //仮想の値を設定
        Map recMap = new HashMap();
        //JISコード
        recMap.put("jisCd","jisCd"+i);
        //仕向地コード
        recMap.put("listShimukeChiCd","listShimukeChiCd"+i);
        //住所
        recMap.put("listJusho","listJusho"+i);
        //町字
        recMap.put("listChoAza","listChoAza"+i);
        //適用開始日
        recMap.put("listTekiyoKaishiBi","listTekiyoKaishiBi"+i);
        //仕向地名
        recMap.put("listShimukeChiMei","listShimukeChiMei"+i);
        //空港
        recMap.put("listKuko","listKuko"+i);
        //集配地区
        recMap.put("listShuhaiChiku","listShuhaiChiku"+i);
        //管轄営業所コード
        recMap.put("listKankatsuEigyoshoCd","listKankatsuEigyoshoCd"+i);
        //管轄営業所名
        recMap.put("listKankatsuEigyoshoMei","listKankatsuEigyoshoMei"+i);
        //旧EDI住所
        recMap.put("listKyuEdiJusho","listKyuEdiJusho"+i);
        //新EDI住所
        recMap.put("listShinEdiJusho","listShinEdiJusho"+i);
        //離島含む
        recMap.put("listRitoFukumu","listRitoFukumu"+i);
        //離島件数
        recMap.put("listRitoKensu","listRitoKensu"+i);
        //館内配送件数
        recMap.put("listKannaiHaisoKensu","listKannaiHaisoKensu"+i);
        //旧住所
        recMap.put("listKyuJusho","listKyuJusho"+i);
        //JISチェック
        recMap.put("listJisCheck","listJisCheck"+i);
        //適用名
        recMap.put("listTekiyoMei","listTekiyoMei"+i);
        //終了日
        recMap.put("listShuryo","listShuryo"+i);

        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }
    
    private void assertForRecList_2_1(Mst031Form form) {
        
        //仮想の値を設定
        int i = 0;
        assertEquals(1, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            //JISコード
            assertEquals("jisCd"+i,rec.get("jisCd"));
            //仕向地コード
            assertEquals("listShimukeChiCd"+i,rec.get("listShimukeChiCd"));
            //住所
            assertEquals("listJusho"+i,rec.get("listJusho"));
            //町字
            assertEquals("listChoAza"+i,rec.get("listChoAza"));
            //適用開始日
            assertEquals("listTekiyoKaishiBi"+i,rec.get("listTekiyoKaishiBi"));
            //仕向地名
            assertEquals("listShimukeChiMei"+i,rec.get("listShimukeChiMei"));
            //空港
            assertEquals("listKuko"+i,rec.get("listKuko"));
            //集配地区
            assertEquals("listShuhaiChiku"+i,rec.get("listShuhaiChiku"));
            //管轄営業所コード
            assertEquals("listKankatsuEigyoshoCd"+i,rec.get("listKankatsuEigyoshoCd"));
            //管轄営業所名
            assertEquals("listKankatsuEigyoshoMei"+i,rec.get("listKankatsuEigyoshoMei"));
            //旧EDI住所
            assertEquals("listKyuEdiJusho"+i,rec.get("listKyuEdiJusho"));
            //新EDI住所
            assertEquals("listShinEdiJusho"+i,rec.get("listShinEdiJusho"));
            //離島含む
            assertEquals("listRitoFukumu"+i,rec.get("listRitoFukumu"));
            //離島件数
            assertEquals("listRitoKensu"+i,rec.get("listRitoKensu"));
            //館内配送件数
            assertEquals("listKannaiHaisoKensu"+i,rec.get("listKannaiHaisoKensu"));
            //旧住所
            assertEquals("listKyuJusho"+i,rec.get("listKyuJusho"));
            //JISチェック
            assertEquals("listJisCheck"+i,rec.get("listJisCheck"));
            //適用名
            assertEquals("listTekiyoMei"+i,rec.get("listTekiyoMei"));
            //終了
            assertEquals("listShuryo"+i,rec.get("listShuryo"));

            i++;
        }
    }    

    private void assertForRecList_2_2(Mst031Form form) {
        
        //仮想の値を設定
        int i = 0;
        assertEquals(2, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
           //JISコード
            assertEquals("jisCd"+i,rec.get("jisCd"));
            //仕向地コード
            assertEquals("listShimukeChiCd"+i,rec.get("listShimukeChiCd"));
            //住所
            assertEquals("listJusho"+i,rec.get("listJusho"));
            //町字
            assertEquals("listChoAza"+i,rec.get("listChoAza"));
            //適用開始日
            assertEquals("listTekiyoKaishiBi"+i,rec.get("listTekiyoKaishiBi"));
            //仕向地名
            assertEquals("listShimukeChiMei"+i,rec.get("listShimukeChiMei"));
            //空港
            assertEquals("listKuko"+i,rec.get("listKuko"));
            //集配地区
            assertEquals("listShuhaiChiku"+i,rec.get("listShuhaiChiku"));
            //管轄営業所コード
            assertEquals("listKankatsuEigyoshoCd"+i,rec.get("listKankatsuEigyoshoCd"));
            //管轄営業所名
            assertEquals("listKankatsuEigyoshoMei"+i,rec.get("listKankatsuEigyoshoMei"));
            //旧EDI住所
            assertEquals("listKyuEdiJusho"+i,rec.get("listKyuEdiJusho"));
            //新EDI住所
            assertEquals("listShinEdiJusho"+i,rec.get("listShinEdiJusho"));
            //離島含む
            assertEquals("listRitoFukumu"+i,rec.get("listRitoFukumu"));
            //離島件数
            assertEquals("listRitoKensu"+i,rec.get("listRitoKensu"));
            //館内配送件数
            assertEquals("listKannaiHaisoKensu"+i,rec.get("listKannaiHaisoKensu"));
            //旧住所
            assertEquals("listKyuJusho"+i,rec.get("listKyuJusho"));
            //JISチェック
            assertEquals("listJisCheck"+i,rec.get("listJisCheck"));
            //適用名
            assertEquals("listTekiyoMei"+i,rec.get("listTekiyoMei"));
            //終了
            assertEquals("listShuryo"+i,rec.get("listShuryo"));
            i++;
        }
    }      

    private void assertForRecList_2_3(Mst031Form form) {
        
        //仮想の値を設定
        int i = 0;
        assertEquals(0, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            //JISコード
            assertEquals("jisCd"+i,rec.get("jisCd"));
            //仕向地コード
            assertEquals("listShimukeChiCd"+i,rec.get("listShimukeChiCd"));
            //住所
            assertEquals("listJusho"+i,rec.get("listJusho"));
            //町字
            assertEquals("listChoAza"+i,rec.get("listChoAza"));
            //適用開始日
            assertEquals("listTekiyoKaishiBi"+i,rec.get("listTekiyoKaishiBi"));
            //仕向地名
            assertEquals("listShimukeChiMei"+i,rec.get("listShimukeChiMei"));
            //空港
            assertEquals("listKuko"+i,rec.get("listKuko"));
            //集配地区
            assertEquals("listShuhaiChiku"+i,rec.get("listShuhaiChiku"));
            //管轄営業所コード
            assertEquals("listKankatsuEigyoshoCd"+i,rec.get("listKankatsuEigyoshoCd"));
            //管轄営業所名
            assertEquals("listKankatsuEigyoshoMei"+i,rec.get("listKankatsuEigyoshoMei"));
            //旧EDI住所
            assertEquals("listKyuEdiJusho"+i,rec.get("listKyuEdiJusho"));
            //新EDI住所
            assertEquals("listShinEdiJusho"+i,rec.get("listShinEdiJusho"));
            //離島含む
            assertEquals("listRitoFukumu"+i,rec.get("listRitoFukumu"));
            //離島件数
            assertEquals("listRitoKensu"+i,rec.get("listRitoKensu"));
            //館内配送件数
            assertEquals("listKannaiHaisoKensu"+i,rec.get("listKannaiHaisoKensu"));
            //旧住所
            assertEquals("listKyuJusho"+i,rec.get("listKyuJusho"));
            //JISチェック
            assertEquals("listJisCheck"+i,rec.get("listJisCheck"));
            //適用名
            assertEquals("listTekiyoMei"+i,rec.get("listTekiyoMei"));
            //終了
            assertEquals("listShuryo"+i,rec.get("listShuryo"));

            i++;
        }
    }
    
}
