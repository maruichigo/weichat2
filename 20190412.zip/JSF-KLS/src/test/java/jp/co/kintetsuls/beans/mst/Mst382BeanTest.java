package jp.co.kintetsuls.beans.mst;

import java.io.IOException;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst382Form;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import static org.mockito.Mockito.when;

/**
 * チャーター料金項目名マスタ画面
 *
 * @author 黄義輝 (MBP)
 * @version 2019/1/24 新規作成
 */
public class Mst382BeanTest {

    // テストTarget
    @InjectMocks
    private Mst382Bean target;

    // Mockitoオブジェクト
    @Mock
    private FileBean fileBean;
    @Mock
    private AutoCompleteViewBean autoCompleteViewBean;
    @Mock
    private MasterInfoBean masterInfo;
    @Mock
    private MessagePropertyBean messageProperty;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosai;
    @Mock
    private SearchHelpBean searchHelpBean;
    @Mock
    private AuthorityConfBean authConfBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private MessagePropertyBean messagePropertyBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosaiBean;
    @Mock
    private ListCheckBean listCheckBean;
    
    public Mst382BeanTest() {
    }

    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() {
    }

    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[not null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst382Form mst382Form = new Mst382Form();
        
        //前画面情報[not null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst382Form);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst382Form form = new Mst382Form();
        target.setMst382Form(form);
        // 戻ってきた場合、再検索を実施する。
        target.init("", "MST031_SCREEN", true);

        //実施結果Outを取得
        form = target.getMst382Form();
        String url = target.getUrl();
        BreadCrumbBean breadBean = target.getBreadBean();
        AutoCompleteViewBean autoCompleteViewBean = target.getAutoCompleteViewBean();
        AuthorityConfBean authorityConfBean  = target.getAuthorityConfBean();
        FileBean fileBean = target.getFileBean();
        MessagePropertyBean messagePropertyBean = target.getMessagePropertyBean();
        PageCommonBean pageCommonBean = target.getPageCommonBean();
        SearchHelpBean searchHelpBean = target.getSearchHelpBean();
        RirekiSyosaiBean rirekiSyosaiBean = target.getRirekiSyosaiBean();
        ListCheckBean listCheckBean = target.getListCheckBean();
        Map<String, Object> rirekiSearchKey = target.getRirekiSearchKey();
        List<MessageModuleBean> msgList = target.getMsgList();
        target.setUrl(url);
        target.setBreadBean(breadBean);
        target.setAutoCompleteViewBean(autoCompleteViewBean);
        target.setAuthorityConfBean(authorityConfBean);
        target.setFileBean(fileBean);
        target.setMessagePropertyBean(messagePropertyBean);
        target.setPageCommonBean(pageCommonBean);
        target.setSearchHelpBean(searchHelpBean);
        target.setRirekiSyosaiBean(rirekiSyosaiBean);
        target.setListCheckBean(listCheckBean);
        target.setRirekiSearchKey(rirekiSearchKey);
        target.setMsgList(msgList);
        
        // 実行時に渡すパラメータの検証
        assertEquals("mst382Form",keyCaptor_1.getValue());
        //想定通りに再検索を実施する。
        assertEquals("search_mst382",keyCaptor_2.getValue());
    }

    // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[処理科目 = [0001], 補助科目 = [01], 世代検索条件[02],削除済のみ検索 = null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2() throws IllegalAccessException, InvocationTargetException,
            InstantiationException {

        // Mockitoオブジェクトの予想return値設定
        Mst382Form mst382Form = new Mst382Form();
        // 前回検索パラメータ[処理科目 = [0001], 補助科目 = [01], 世代検索条件[02],削除済のみ検索 = null]
        AutoCompOptionBean conShorikamoku = new AutoCompOptionBean();
        conShorikamoku.setValue("0001");
        AutoCompOptionBean conHojoKamoku = new AutoCompOptionBean();
        conHojoKamoku.setValue("001");
        String conSedaiKensakuJoken[] = new String[5];
        conSedaiKensakuJoken[0] = "02";
        mst382Form.setConSyoriKamoku(conShorikamoku);
        mst382Form.setConHojoKamoku(conHojoKamoku);
        mst382Form.setConSedaiKensakuJoken(conSedaiKensakuJoken);
        mst382Form.setConSakujoSumiNomi(null);
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        // 前画面パラメータ[世代検索条件[02],削除済のみ検索 = null]
        flash.put("mst382Form", mst382Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);        

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst382Form form = new Mst382Form();
        target.setMst382Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst382Form();

        //想定通りに再検索を実施する。
        assertEquals("search_mst382",keyCaptor_2.getValue());
        assertEquals("0001",form.getConSyoriKamoku().getValue());
        assertEquals("001",form.getConHojoKamoku().getValue());
        assertEquals("02",form.getConSedaiKensakuJoken()[1]);
        assertEquals(null,form.getConSakujoSumiNomi());
    }

    // init_正常_初期処理_1-2_1
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[世代検索条件[02],削除済のみ検索 = null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2_1() throws IllegalAccessException, InvocationTargetException,
            InstantiationException {

        // Mockitoオブジェクトの予想return値設定
        Mst382Form mst382Form = new Mst382Form();
        // 前回検索パラメータ[世代検索条件[02],削除済のみ検索 = null]
        String conSedaiKensakuJoken[] = new String[5];
        conSedaiKensakuJoken[0] = "02";
        mst382Form.setConSedaiKensakuJoken(conSedaiKensakuJoken);
        mst382Form.setConSakujoSumiNomi(null);
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        // 前回検索パラメータ[世代検索条件[02],削除済のみ検索 = null]
        flash.put("mst382Form", null);
        when(pageCommonBean.getPageParam()).thenReturn(flash);        

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst382Form form = new Mst382Form();
        target.setMst382Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst382Form();

        //想定通りに再検索を実施する。
        assertEquals(null,form.getConSakujoSumiNomi());
    }    
    
    // init_正常_初期処理_1-3
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        //前画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(null);

        //テスト実行
        Mst382Form form = new Mst382Form();
        target.setMst382Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst382Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst382Form",keyCaptor_1.getValue());
        //想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null,form.getSearchResult());
    }

    // init_正常_初期処理_1-3_1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        //前画面情報[null]
        doThrow(IllegalAccessException.class).when(pageCommonBean).getPageInfo(keyCaptor_1.capture());

        //テスト実行
        Mst382Form form = new Mst382Form();
        target.setMst382Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst382Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst382Form",keyCaptor_1.getValue());
        //想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null,form.getSearchResult());
    }

    // search_正常_検索処理_2-3
    //
    // -------------------テスト条件--------------------------
    // チャーター料金項目マスタ検索結果一覧  取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // チャーター料金項目マスタ検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=0;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst382Form form = new Mst382Form();
        AutoCompOptionBean conShorikamoku = new AutoCompOptionBean();
        conShorikamoku.setValue("0001");
        AutoCompOptionBean conHojoKamoku = new AutoCompOptionBean();
        conHojoKamoku.setValue("001");
        form.setConSyoriKamoku(conShorikamoku);
        form.setConHojoKamoku(conHojoKamoku);
        form.setConRyokinKomokuCd("conRyokinKomokuCd1");
        form.setConSakujoSumiNomi(new String[]{"conSakujoSumiNomi1"});
        target.setMst382Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst382Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conRyokinKomokuCd1", paramsCaptor_1.getValue().get("conRyokinKomokuCd"));
        String[] conSakujoSumiNomParam = (String[]) paramsCaptor_1.getValue().get("conSakujoSumiNomi");
        assertEquals("conSakujoSumiNomi1", conSakujoSumiNomParam[0]);
        assertEquals("0001", paramsCaptor_1.getValue().get("conShorikamoku"));
        assertEquals("001", paramsCaptor_1.getValue().get("conHojoKamoku"));
        assertEquals("mst382-get-charterRyokinKomoku-detail", functionCodeCaptor_2.getValue());
        //想定通りにチャーター料金項目名マスタ一覧を表示されること
        assertForRecList_2_3(form);
    }    

    // search_正常_検索処理_2-4
    //
    // -------------------テスト条件--------------------------
    // チャーター料金項目検索結果一覧  取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // チャーター料金項目検索結果一覧取得 取得件数 = 2
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=1;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst382Form form = new Mst382Form();
        String conSedaiKensakuJoken[] = new String[5];
        conSedaiKensakuJoken[0] = "01";
        form.setConSedaiKensakuJoken(conSedaiKensakuJoken);
        form.setConSakujoSumiNomi(null);
        target.setMst382Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst382Form();

        // 実行時に渡すパラメータの検証
        assertEquals(conSedaiKensakuJoken, paramsCaptor_1.getValue().get("conSedaiKensakuJoken"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSakujoSumiNomi"));
        assertEquals("mst382-get-charterRyokinKomoku-detail",functionCodeCaptor_2.getValue());
        //想定通りにチャーター料金項目マスタ一覧を表示されること
        assertForRecList_2_4(form);
    }

    // search_異常_検索処理_2-3
    //
    // -------------------テスト条件--------------------------
    // チャーター料金項目検索結果一覧取得 取得件数 = 0
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_5 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //チャーター料金項目検索結果一覧取得 取得件数 = 0
        List<Map<String, String>> result = new ArrayList<>();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        doThrow(IOException.class).when(pageCommonBean).getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture());

        //テスト実行
        Mst382Form form = new Mst382Form();
        target.setMst382Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst382Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null, paramsCaptor_1.getValue().get("conSedaiKensakuJoken"));
        assertEquals("mst382-get-charterRyokinKomoku-detail",functionCodeCaptor_2.getValue());
        //想定通りに・一覧は表示しない（ヘッダーのみ） 
        //想定通りに ・ファンクションボタンは表示（検索前と同じ） 
    }

    // getRecordCount_正常_件数取得処理_2-6
    //
    // -------------------テスト条件--------------------------
    // チャーター料金項目検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_6 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //チャーター料金項目検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst382Form form = new Mst382Form();
        target.setMst382Form(form);
        target.getRecordCount();

        //実施結果Outを取得
        form = target.getMst382Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null,paramsCaptor_1.getValue().get("conSedaiKensakuJoken"));
        assertEquals(null,paramsCaptor_1.getValue().get("conSakujoSumiNomi"));
        assertEquals("mst382-get-charterRyokinKomoku-kensu",functionCodeCaptor_2.getValue());
        //想定通りに正常にCountを実施されること
        assertEquals(null,form.getConSyoriKamoku());
        assertEquals(null,form.getConHojoKamoku());
    }

    // getRecordCount_正常_件数取得処理_2-6_1
    //
    // -------------------テスト条件--------------------------
    // チャーター料金項目検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_6_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //チャーター料金項目検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst382Form form = new Mst382Form();
        AutoCompOptionBean conSyoriKamoku = new AutoCompOptionBean();
        conSyoriKamoku.setValue("conSyoriKamoku1");
        
        AutoCompOptionBean conHojoKamoku = new AutoCompOptionBean();
        conHojoKamoku.setValue("conHojoKamoku1");
        
        
        form.setConSyoriKamoku(conSyoriKamoku);
        form.setConHojoKamoku(conHojoKamoku);
        form.setConRyokinKomokuCd("conRyokinKomokuCd1");
        form.setConSakujoSumiNomi(new String[]{"conSakujoSumiNomi1"});
        target.setMst382Form(form);
        target.getRecordCount();

        //実施結果Outを取得
        form = target.getMst382Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conRyokinKomokuCd1",paramsCaptor_1.getValue().get("conRyokinKomokuCd"));
        assertEquals("mst382-get-charterRyokinKomoku-kensu",functionCodeCaptor_2.getValue());
        //想定通りに正常にCountを実施されること
        assertEquals("conSyoriKamoku1",form.getConSyoriKamoku().getValue());
        assertEquals("conHojoKamoku1",form.getConHojoKamoku().getValue());
    }    
    
    // getRecordCount_正常_件数取得処理_2-4_2
    //
    // -------------------テスト条件--------------------------
    // チャーター料金項目検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_6_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //チャーター料金項目検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst382Form form = new Mst382Form();
        AutoCompOptionBean conSyoriKamoku = new AutoCompOptionBean();
        conSyoriKamoku.setValue("conSyoriKamoku1");
        form.setConSyoriKamoku(conSyoriKamoku);
        form.setConRyokinKomokuCd("conRyokinKomokuCd1");
        form.setConSakujoSumiNomi(new String[]{"conSakujoSumiNomi1"});
        target.setMst382Form(form);
        target.getRecordCount();

        //実施結果Outを取得
        form = target.getMst382Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conRyokinKomokuCd1",paramsCaptor_1.getValue().get("conRyokinKomokuCd"));
        assertEquals("mst382-get-charterRyokinKomoku-kensu",functionCodeCaptor_2.getValue());
        //想定通りに正常にCountを実施されること
        assertEquals("conSyoriKamoku1", form.getConSyoriKamoku().getValue());
    } 
    
    // clear_正常_クリア処理_3-1
    //
    // -------------------テスト条件--------------------------
    // 検索条件と検索結果がある
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst382Form form = new Mst382Form();
        // 検索条件と検索結果がある
        AutoCompOptionBean conSyoriKamoku = new AutoCompOptionBean();
        conSyoriKamoku.setValue("0001");
        conSyoriKamoku.setLabel("処理科目01");
        form.setConSyoriKamoku(conSyoriKamoku);
        form.setConRyokinKomokuMeisho("料金項目名称");
        form.setConSakujoSumiNomi(new String[]{"01"});

        target.setMst382Form(form);
        target.clear();

        //実施結果Outを取得
        form = target.getMst382Form();

        //想定通りに正常にClearを実施されること
        assertEquals(null, form.getConSyoriKamoku());
        assertEquals(null, form.getConRyokinKomokuMeisho());
        assertEquals(null, form.getConSakujoSumiNomi());
    }

    // clear_正常_クリア処理_3-2
    //
    // -------------------テスト条件--------------------------
    // 検索条件がある、検索結果がない
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst382Form form = new Mst382Form();
        target.setMst382Form(form);
        target.clear();

        //実施結果Outを取得
        form = target.getMst382Form();

        //想定通りに正常にClearを実施されること
        assertEquals(null, form.getConSyoriKamoku());
        assertEquals(null, form.getConRyokinKomokuMeisho());
        assertEquals(null, form.getConSakujoSumiNomi());
    }

    // getHeader_正常_ダウンロード_4-1
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void getHeader_正常_ダウンロード_4_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst382Form form = new Mst382Form();
        target.setMst382Form(form);
        List<CSVDto> dto = target.getHeader();

        //実施結果Outを取得
        form = target.getMst382Form();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にCVSのHeaderを設定されること
        assertEquals(null, form.getConSyoriKamoku());
        assertEquals(null, form.getConRyokinKomokuMeisho());
        assertEquals("料金項目コード",dto.get(0).getTitle());
        assertEquals("listRyokinKomokuCd",dto.get(0).getName());
        assertEquals("料金項目名称",dto.get(1).getTitle());
        assertEquals("listRyokinKomokuMeisho",dto.get(1).getName());
    }

    // beforeDown_正常_ダウンロード_4-2
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=2件
    // -----------------------------------------------------
    @Test
    public void beforeDown_正常_ダウンロード_4_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst382Form form = new Mst382Form();
        target.setMst382Form(form);
        try {
            target.beforeDown("testComment");
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(Mst382BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        //実施結果Outを取得
        form = target.getMst382Form();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にダウンロード理由を記録すること
        assertEquals(null,form.getConSyoriKamoku());
    }    
    
    // update_異常_更新処理_新規登録_11-1
    //
    // -------------------テスト条件--------------------------
    // 料金項目コード、適用開始日の組み合わせが、チャーター料金項目名マスタに存在しています[COME0018]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_新規登録_11_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 料金項目コード、適用開始日の組み合わせが、チャーター料金項目名マスタに存在しています[COME0018]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0018",
                "listRyokinKomokuCdlistTekiyoKaishibi");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst382Form form = new Mst382Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst382Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst382Form();

         Date tekiyoKaishibi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoKaishibi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst382BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listRyokinKomokuCd0",paramsCaptor_1_Param.get("listRyokinKomokuCd"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals(tekiyoKaishibi,paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals("listMeisaiKbn0",paramsCaptor_1_Param.get("listMeisaiKbn"));
        assertEquals("listNebikifukaFlg0",paramsCaptor_1_Param.get("listNebikifukaFlg"));
        assertEquals("listShosutenKbn0",paramsCaptor_1_Param.get("listShosutenKbn"));
        assertEquals("listSeigyoKbn0",paramsCaptor_1_Param.get("listSeigyoKbn"));
        assertEquals("listSeigyoKbnName0",paramsCaptor_1_Param.get("listSeigyoKbnName"));
        assertEquals("listZeiKbn0",paramsCaptor_1_Param.get("listZeiKbn"));
        assertEquals("listYusoUriageSetSaki0",paramsCaptor_1_Param.get("listYusoUriageSetSaki"));
        assertEquals("listOroshitanka0",paramsCaptor_1_Param.get("listOroshitanka"));
        assertEquals("listOroshineritsu0",paramsCaptor_1_Param.get("listOroshineritsu"));
        assertEquals("listOroshiKamokuCd0",paramsCaptor_1_Param.get("listOroshiKamokuCd"));
        assertEquals("listOroshiKamokuMeisho0",paramsCaptor_1_Param.get("listOroshiKamokuMeisho"));
        assertEquals("listShoriKamokuCd0",paramsCaptor_1_Param.get("listShoriKamokuCd"));
        assertEquals("listShoriKamokuMeisho0",paramsCaptor_1_Param.get("listShoriKamokuMeisho"));
        assertEquals("listHojoKamokuCd0",paramsCaptor_1_Param.get("listHojoKamokuCd"));
        assertEquals("listHojoKamokuMeisho0",paramsCaptor_1_Param.get("listHojoKamokuMeisho"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listTekiyoKaishibiRire0",paramsCaptor_1_Param.get("listTekiyoKaishibiRire"));
        assertEquals("listTekiyoShuryobiRire0",paramsCaptor_1_Param.get("listTekiyoShuryobiRire"));
        assertEquals("listCharterRyokinKomokuVersion0",paramsCaptor_1_Param.get("listCharterRyokinKomokuVersion"));
        assertEquals("listKoshinCounter0",paramsCaptor_1_Param.get("listKoshinCounter"));                                
        assertEquals("listCharterRyokinKomokuVersion0",paramsCaptor_1_Param.get("listCharterRyokinKomokuVersion"));
        
        assertEquals("mst382-insert-update-check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0018）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0018",summaryCaptor_4.getValue());
    }

    // update_正常_更新処理_新規登録_11-2
    //
    // -------------------テスト条件--------------------------
    // 料金項目コード、適用開始日の組み合わせが、チャーター料金項目名マスタに存在していない
    // -----------------------------------------------------
    @Test
    public void update_正常_更新処理_新規登録_11_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 料金項目コード、適用開始日の組み合わせが、チャーター料金項目名マスタに存在していない
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //チャーター料金項目検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        //テスト実行
        Mst382Form form = new Mst382Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst382Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst382Form();

        Date tekiyoKaishibi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoKaishibi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst382BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listRyokinKomokuCd0",paramsCaptor_1_Param.get("listRyokinKomokuCd"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals(tekiyoKaishibi,paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals("listMeisaiKbn0",paramsCaptor_1_Param.get("listMeisaiKbn"));
        assertEquals("listNebikifukaFlg0",paramsCaptor_1_Param.get("listNebikifukaFlg"));
        assertEquals("listShosutenKbn0",paramsCaptor_1_Param.get("listShosutenKbn"));
        assertEquals("listSeigyoKbn0",paramsCaptor_1_Param.get("listSeigyoKbn"));
        assertEquals("listSeigyoKbnName0",paramsCaptor_1_Param.get("listSeigyoKbnName"));
        assertEquals("listZeiKbn0",paramsCaptor_1_Param.get("listZeiKbn"));
        assertEquals("listYusoUriageSetSaki0",paramsCaptor_1_Param.get("listYusoUriageSetSaki"));
        assertEquals("listOroshitanka0",paramsCaptor_1_Param.get("listOroshitanka"));
        assertEquals("listOroshineritsu0",paramsCaptor_1_Param.get("listOroshineritsu"));
        assertEquals("listOroshiKamokuCd0",paramsCaptor_1_Param.get("listOroshiKamokuCd"));
        assertEquals("listOroshiKamokuMeisho0",paramsCaptor_1_Param.get("listOroshiKamokuMeisho"));
        assertEquals("listShoriKamokuCd0",paramsCaptor_1_Param.get("listShoriKamokuCd"));
        assertEquals("listShoriKamokuMeisho0",paramsCaptor_1_Param.get("listShoriKamokuMeisho"));
        assertEquals("listHojoKamokuCd0",paramsCaptor_1_Param.get("listHojoKamokuCd"));
        assertEquals("listHojoKamokuMeisho0",paramsCaptor_1_Param.get("listHojoKamokuMeisho"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listTekiyoKaishibiRire0",paramsCaptor_1_Param.get("listTekiyoKaishibiRire"));
        assertEquals("listTekiyoShuryobiRire0",paramsCaptor_1_Param.get("listTekiyoShuryobiRire"));
        assertEquals("listCharterRyokinKomokuVersion0",paramsCaptor_1_Param.get("listCharterRyokinKomokuVersion"));
        assertEquals("listKoshinCounter0",paramsCaptor_1_Param.get("listKoshinCounter"));                                
        assertEquals("listCharterRyokinKomokuVersion0",paramsCaptor_1_Param.get("listCharterRyokinKomokuVersion"));
        assertEquals("mst382-insert-update",functionCodeCaptor_2.getValue());
        //想定通りに正常終了メッセージ（メッセージID：COMI0007）を表示されること
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0007",summaryCaptor_4.getValue());
        assertEquals("更新",detailCaptor_5.getValue());
    }    

    // update_異常_更新処理_新規登録_11-3
    //
    // -------------------テスト条件--------------------------
    // 処理科目コードが経理科目マスタに存在しない
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_新規登録_11_3 () throws IllegalAccessException, InvocationTargetException {

       // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 処理科目コードが経理科目マスタに存在しない[COME0043]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0043",
                "shoriKamokuCd");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture(),tableNameCaptor_6
                        .capture());

        //テスト実行
        Mst382Form form = new Mst382Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<=1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst382Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst382Form();

        Date tekiyoKaishibi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoKaishibi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst382BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listRyokinKomokuCd0",paramsCaptor_1_Param.get("listRyokinKomokuCd"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals(tekiyoKaishibi,paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals("listMeisaiKbn0",paramsCaptor_1_Param.get("listMeisaiKbn"));
        assertEquals("listNebikifukaFlg0",paramsCaptor_1_Param.get("listNebikifukaFlg"));
        assertEquals("listShosutenKbn0",paramsCaptor_1_Param.get("listShosutenKbn"));
        assertEquals("listSeigyoKbn0",paramsCaptor_1_Param.get("listSeigyoKbn"));
        assertEquals("listSeigyoKbnName0",paramsCaptor_1_Param.get("listSeigyoKbnName"));
        assertEquals("listZeiKbn0",paramsCaptor_1_Param.get("listZeiKbn"));
        assertEquals("listYusoUriageSetSaki0",paramsCaptor_1_Param.get("listYusoUriageSetSaki"));
        assertEquals("listOroshitanka0",paramsCaptor_1_Param.get("listOroshitanka"));
        assertEquals("listOroshineritsu0",paramsCaptor_1_Param.get("listOroshineritsu"));
        assertEquals("listOroshiKamokuCd0",paramsCaptor_1_Param.get("listOroshiKamokuCd"));
        assertEquals("listOroshiKamokuMeisho0",paramsCaptor_1_Param.get("listOroshiKamokuMeisho"));
        assertEquals("listShoriKamokuCd0",paramsCaptor_1_Param.get("listShoriKamokuCd"));
        assertEquals("listShoriKamokuMeisho0",paramsCaptor_1_Param.get("listShoriKamokuMeisho"));
        assertEquals("listHojoKamokuCd0",paramsCaptor_1_Param.get("listHojoKamokuCd"));
        assertEquals("listHojoKamokuMeisho0",paramsCaptor_1_Param.get("listHojoKamokuMeisho"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listTekiyoKaishibiRire0",paramsCaptor_1_Param.get("listTekiyoKaishibiRire"));
        assertEquals("listTekiyoShuryobiRire0",paramsCaptor_1_Param.get("listTekiyoShuryobiRire"));
        assertEquals("listCharterRyokinKomokuVersion0",paramsCaptor_1_Param.get("listCharterRyokinKomokuVersion"));
        assertEquals("listKoshinCounter0",paramsCaptor_1_Param.get("listKoshinCounter"));                                
        assertEquals("listCharterRyokinKomokuVersion0",paramsCaptor_1_Param.get("listCharterRyokinKomokuVersion"));
        assertEquals("mst382-insert-update-check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0043）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0043",summaryCaptor_4.getValue());
    }    

    // update_異常_更新処理_更新登録_11-4
    //
    // -------------------テスト条件--------------------------
    // 料金項目コード、適用開始日の組み合わせが、チャーター料金項目名マスタに存在しない[COME0043]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_11_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 料金項目コード、適用開始日の組み合わせが、チャーター料金項目名マスタに存在しない[COME0043]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0043",
                "listRyokinKomokuCdlistTekiyoKaishibi");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst382Form form = new Mst382Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst382Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst382Form();

        Date tekiyoKaishibi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoKaishibi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst382BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listRyokinKomokuCd0",paramsCaptor_1_Param.get("listRyokinKomokuCd"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals(tekiyoKaishibi,paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals("listMeisaiKbn0",paramsCaptor_1_Param.get("listMeisaiKbn"));
        assertEquals("listNebikifukaFlg0",paramsCaptor_1_Param.get("listNebikifukaFlg"));
        assertEquals("listShosutenKbn0",paramsCaptor_1_Param.get("listShosutenKbn"));
        assertEquals("listSeigyoKbn0",paramsCaptor_1_Param.get("listSeigyoKbn"));
        assertEquals("listSeigyoKbnName0",paramsCaptor_1_Param.get("listSeigyoKbnName"));
        assertEquals("listZeiKbn0",paramsCaptor_1_Param.get("listZeiKbn"));
        assertEquals("listYusoUriageSetSaki0",paramsCaptor_1_Param.get("listYusoUriageSetSaki"));
        assertEquals("listOroshitanka0",paramsCaptor_1_Param.get("listOroshitanka"));
        assertEquals("listOroshineritsu0",paramsCaptor_1_Param.get("listOroshineritsu"));
        assertEquals("listOroshiKamokuCd0",paramsCaptor_1_Param.get("listOroshiKamokuCd"));
        assertEquals("listOroshiKamokuMeisho0",paramsCaptor_1_Param.get("listOroshiKamokuMeisho"));
        assertEquals("listShoriKamokuCd0",paramsCaptor_1_Param.get("listShoriKamokuCd"));
        assertEquals("listShoriKamokuMeisho0",paramsCaptor_1_Param.get("listShoriKamokuMeisho"));
        assertEquals("listHojoKamokuCd0",paramsCaptor_1_Param.get("listHojoKamokuCd"));
        assertEquals("listHojoKamokuMeisho0",paramsCaptor_1_Param.get("listHojoKamokuMeisho"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listTekiyoKaishibiRire0",paramsCaptor_1_Param.get("listTekiyoKaishibiRire"));
        assertEquals("listTekiyoShuryobiRire0",paramsCaptor_1_Param.get("listTekiyoShuryobiRire"));
        assertEquals("listCharterRyokinKomokuVersion0",paramsCaptor_1_Param.get("listCharterRyokinKomokuVersion"));
        assertEquals("listKoshinCounter0",paramsCaptor_1_Param.get("listKoshinCounter"));                                
        assertEquals("listCharterRyokinKomokuVersion0",paramsCaptor_1_Param.get("listCharterRyokinKomokuVersion"));
        assertEquals("mst382-insert-update-check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0043）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0043",summaryCaptor_4.getValue());
}    

    // update_正常_更新処理_更新登録_11-5
    //
    // -------------------テスト条件--------------------------
    // 料金項目コード、適用開始日の組み合わせが、チャーター料金項目名マスタに存在しています
    // -----------------------------------------------------
    @Test
    public void update_正常_更新処理_更新登録_11_5 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 料金項目コード、適用開始日の組み合わせが、チャーター料金項目名マスタに存在しています
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4
                .capture(),detailCaptor_5.capture());        

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //チャーター料金項目検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        //テスト実行
        Mst382Form form = new Mst382Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst382Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst382Form();

        Date tekiyoKaishibi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoKaishibi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst382BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listRyokinKomokuCd0",paramsCaptor_1_Param.get("listRyokinKomokuCd"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals(tekiyoKaishibi,paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals("listMeisaiKbn0",paramsCaptor_1_Param.get("listMeisaiKbn"));
        assertEquals("listNebikifukaFlg0",paramsCaptor_1_Param.get("listNebikifukaFlg"));
        assertEquals("listShosutenKbn0",paramsCaptor_1_Param.get("listShosutenKbn"));
        assertEquals("listSeigyoKbn0",paramsCaptor_1_Param.get("listSeigyoKbn"));
        assertEquals("listSeigyoKbnName0",paramsCaptor_1_Param.get("listSeigyoKbnName"));
        assertEquals("listZeiKbn0",paramsCaptor_1_Param.get("listZeiKbn"));
        assertEquals("listYusoUriageSetSaki0",paramsCaptor_1_Param.get("listYusoUriageSetSaki"));
        assertEquals("listOroshitanka0",paramsCaptor_1_Param.get("listOroshitanka"));
        assertEquals("listOroshineritsu0",paramsCaptor_1_Param.get("listOroshineritsu"));
        assertEquals("listOroshiKamokuCd0",paramsCaptor_1_Param.get("listOroshiKamokuCd"));
        assertEquals("listOroshiKamokuMeisho0",paramsCaptor_1_Param.get("listOroshiKamokuMeisho"));
        assertEquals("listShoriKamokuCd0",paramsCaptor_1_Param.get("listShoriKamokuCd"));
        assertEquals("listShoriKamokuMeisho0",paramsCaptor_1_Param.get("listShoriKamokuMeisho"));
        assertEquals("listHojoKamokuCd0",paramsCaptor_1_Param.get("listHojoKamokuCd"));
        assertEquals("listHojoKamokuMeisho0",paramsCaptor_1_Param.get("listHojoKamokuMeisho"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listTekiyoKaishibiRire0",paramsCaptor_1_Param.get("listTekiyoKaishibiRire"));
        assertEquals("listTekiyoShuryobiRire0",paramsCaptor_1_Param.get("listTekiyoShuryobiRire"));
        assertEquals("listCharterRyokinKomokuVersion0",paramsCaptor_1_Param.get("listCharterRyokinKomokuVersion"));
        assertEquals("listKoshinCounter0",paramsCaptor_1_Param.get("listKoshinCounter"));                                
        assertEquals("listCharterRyokinKomokuVersion0",paramsCaptor_1_Param.get("listCharterRyokinKomokuVersion"));
        assertEquals("mst382-insert-update",functionCodeCaptor_2.getValue());
        //想定通りに正常終了メッセージ（メッセージID：COMI0007）を表示されること
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0007",summaryCaptor_4.getValue());
        assertEquals("更新",detailCaptor_5.getValue());

    }    

    // update_異常_更新処理_更新登録_11-6
    //
    // -------------------テスト条件--------------------------
    // 処理科目コードが経理科目マスタに存在する[COME0043]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_11_6 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 処理科目コードが経理科目マスタに存在する[COME0043]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0006",
                "listRyokinKomokuCdlistTekiyoKaishibi");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst382Form form = new Mst382Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst382Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst382Form();
        
        Date tekiyoKaishibi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoKaishibi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst382BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }


        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listRyokinKomokuCd0",paramsCaptor_1_Param.get("listRyokinKomokuCd"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals(tekiyoKaishibi,paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals("listMeisaiKbn0",paramsCaptor_1_Param.get("listMeisaiKbn"));
        assertEquals("listNebikifukaFlg0",paramsCaptor_1_Param.get("listNebikifukaFlg"));
        assertEquals("listShosutenKbn0",paramsCaptor_1_Param.get("listShosutenKbn"));
        assertEquals("listSeigyoKbn0",paramsCaptor_1_Param.get("listSeigyoKbn"));
        assertEquals("listSeigyoKbnName0",paramsCaptor_1_Param.get("listSeigyoKbnName"));
        assertEquals("listZeiKbn0",paramsCaptor_1_Param.get("listZeiKbn"));
        assertEquals("listYusoUriageSetSaki0",paramsCaptor_1_Param.get("listYusoUriageSetSaki"));
        assertEquals("listOroshitanka0",paramsCaptor_1_Param.get("listOroshitanka"));
        assertEquals("listOroshineritsu0",paramsCaptor_1_Param.get("listOroshineritsu"));
        assertEquals("listOroshiKamokuCd0",paramsCaptor_1_Param.get("listOroshiKamokuCd"));
        assertEquals("listOroshiKamokuMeisho0",paramsCaptor_1_Param.get("listOroshiKamokuMeisho"));
        assertEquals("listShoriKamokuCd0",paramsCaptor_1_Param.get("listShoriKamokuCd"));
        assertEquals("listShoriKamokuMeisho0",paramsCaptor_1_Param.get("listShoriKamokuMeisho"));
        assertEquals("listHojoKamokuCd0",paramsCaptor_1_Param.get("listHojoKamokuCd"));
        assertEquals("listHojoKamokuMeisho0",paramsCaptor_1_Param.get("listHojoKamokuMeisho"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listTekiyoKaishibiRire0",paramsCaptor_1_Param.get("listTekiyoKaishibiRire"));
        assertEquals("listTekiyoShuryobiRire0",paramsCaptor_1_Param.get("listTekiyoShuryobiRire"));
        assertEquals("listCharterRyokinKomokuVersion0",paramsCaptor_1_Param.get("listCharterRyokinKomokuVersion"));
        assertEquals("listKoshinCounter0",paramsCaptor_1_Param.get("listKoshinCounter"));                                
        assertEquals("listCharterRyokinKomokuVersion0",paramsCaptor_1_Param.get("listCharterRyokinKomokuVersion"));
        assertEquals("mst382-insert-update-check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0006）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0006",summaryCaptor_4.getValue());
    }    

    // update_異常_更新処理_更新登録_11-7
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_11_7 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        //テスト実行
        Mst382Form form = new Mst382Form();
        //行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        form.setSelectedSearchResult(result);
        target.setMst382Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst382Form();

        //想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0029",summaryCaptor_2.getValue());
    }

    // update_異常_更新処理_更新登録_11-7_1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_11_7_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        //テスト実行
        Mst382Form form = new Mst382Form();
        target.setMst382Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst382Form();

        //想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0029",summaryCaptor_2.getValue());
    }    

    // update_異常_更新処理_更新登録_11-8
    //
    // -------------------テスト条件--------------------------
    // 処理科目コード = ああああ
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_11_8 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Boolean> datasCaptor_3 = ArgumentCaptor.forClass(Boolean.class);
        ArgumentCaptor<List> checksCaptor_4 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<List> checksCaptor_5 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean2 = new MessageModuleBean();
        List<MessageModuleBean> msgList = new ArrayList<>();
        msgList.add(messageModuleBean2);

        when(listCheckBean.check(checksCaptor_4.capture(), checksCaptor_5.capture(), datasCaptor_3.capture()))
                .thenReturn(msgList); 

        //テスト実行
        Mst382Form form = new Mst382Form();
        //行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst382Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst382Form();

}    
    
   // delRows_正常_チャーター料金項目名マスタ削除処理_12-1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 1
    // 料金項目コード、適用開始日の組み合わせが、チャーター料金項目名マスタに存在している
    // -----------------------------------------------------
    @Test
    public void delRows_正常_チャーター料金項目名マスタ削除処理_12_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_4.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture());
        //テスト実行
        Mst382Form form = new Mst382Form();
        //行選択チェック選択 = 1
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        form.setSearchResult(result);
        form.setSelectedSearchResult(result);
        target.setMst382Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst382Form();
        
        Date tekiyoKaishibi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoKaishibi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst382BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        //想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されることチャーター料金項目名マスタ削除処理を行う。
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0004",summaryCaptor_4.getValue());
        assertEquals("削除",detailCaptor_5.getValue());
    }    

   // delRows_正常_チャーター料金項目名マスタ削除処理_12-2
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 2
    // 料金項目コード、適用開始日の組み合わせが、チャーター料金項目名マスタに存在している
    // -----------------------------------------------------
    @Test
    public void delRows_正常_チャーター料金項目名マスタ削除処理_12_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture());
        //テスト実行
        Mst382Form form = new Mst382Form();
        //行選択チェック選択 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        form.setSearchResult(result);
        form.setSelectedSearchResult(result);
        target.setMst382Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst382Form();
        
        Date tekiyoKaishibi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoKaishibi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst382BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        //想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されることチャーター料金項目名マスタ削除処理を行う。
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0004",summaryCaptor_4.getValue());
        assertEquals("削除",detailCaptor_5.getValue());
    }        

   // delRows_正常_チャーター料金項目名マスタ削除処理_12-2_1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 2
    // 料金項目コード、適用開始日の組み合わせが、チャーター料金項目名マスタに存在している
    // -----------------------------------------------------
    @Test
    public void delRows_正常_チャーター料金項目名マスタ削除処理_12_2_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        serviceInterfaceBean2.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean,serviceInterfaceBean2);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture());
        //テスト実行
        Mst382Form form = new Mst382Form();
        //行選択チェック選択 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        form.setSearchResult(result);
        form.setSelectedSearchResult(result);
        target.setMst382Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst382Form();

        Date tekiyoKaishibi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoKaishibi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst382BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listRyokinKomokuCd0",paramsCaptor_1_Param.get("listRyokinKomokuCd"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals(tekiyoKaishibi,paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals("listMeisaiKbn0",paramsCaptor_1_Param.get("listMeisaiKbn"));
        assertEquals("listNebikifukaFlg0",paramsCaptor_1_Param.get("listNebikifukaFlg"));
        assertEquals("listShosutenKbn0",paramsCaptor_1_Param.get("listShosutenKbn"));
        assertEquals("listSeigyoKbn0",paramsCaptor_1_Param.get("listSeigyoKbn"));
        assertEquals("listSeigyoKbnName0",paramsCaptor_1_Param.get("listSeigyoKbnName"));
        assertEquals("listZeiKbn0",paramsCaptor_1_Param.get("listZeiKbn"));
        assertEquals("listYusoUriageSetSaki0",paramsCaptor_1_Param.get("listYusoUriageSetSaki"));
        assertEquals("listOroshitanka0",paramsCaptor_1_Param.get("listOroshitanka"));
        assertEquals("listOroshineritsu0",paramsCaptor_1_Param.get("listOroshineritsu"));
        assertEquals("listOroshiKamokuCd0",paramsCaptor_1_Param.get("listOroshiKamokuCd"));
        assertEquals("listOroshiKamokuMeisho0",paramsCaptor_1_Param.get("listOroshiKamokuMeisho"));
        assertEquals("listShoriKamokuCd0",paramsCaptor_1_Param.get("listShoriKamokuCd"));
        assertEquals("listShoriKamokuMeisho0",paramsCaptor_1_Param.get("listShoriKamokuMeisho"));
        assertEquals("listHojoKamokuCd0",paramsCaptor_1_Param.get("listHojoKamokuCd"));
        assertEquals("listHojoKamokuMeisho0",paramsCaptor_1_Param.get("listHojoKamokuMeisho"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listTekiyoKaishibiRire0",paramsCaptor_1_Param.get("listTekiyoKaishibiRire"));
        assertEquals("listTekiyoShuryobiRire0",paramsCaptor_1_Param.get("listTekiyoShuryobiRire"));
        assertEquals("listCharterRyokinKomokuVersion0",paramsCaptor_1_Param.get("listCharterRyokinKomokuVersion"));
        assertEquals("listKoshinCounter0",paramsCaptor_1_Param.get("listKoshinCounter"));                                
        assertEquals("listCharterRyokinKomokuVersion0",paramsCaptor_1_Param.get("listCharterRyokinKomokuVersion"));
        assertEquals("mst382-delete-row-detail",functionCodeCaptor_2.getValue());
    }

    // delRows_異常_チャーター料金項目名マスタ削除処理_12-3
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // 料金項目コード、適用開始日の組み合わせが、チャーター料金項目名マスタに存在している
    // -----------------------------------------------------
    @Test
    public void delRows_異常_チャーター料金項目名マスタ削除処理_12_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        //テスト実行
        Mst382Form form = new Mst382Form();
        //行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        form.setSelectedSearchResult(result);
        target.setMst382Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst382Form();

        //想定通りにエラーが発生。（メッセージID：COME0013）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0013",summaryCaptor_2.getValue());
    }    

    // delRows_異常_チャーター料金項目名マスタ削除処理_12-4
    //
    // -------------------テスト条件--------------------------
    // 料金項目コード、適用開始日の組み合わせが、チャーター料金項目名マスタに存在しない
    // -----------------------------------------------------
    @Test
    public void delRows_異常_チャーター料金項目名マスタ削除処理_12_4 () throws IllegalAccessException, InvocationTargetException {

      // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 料金項目コード、適用開始日の組み合わせが、チャーター料金項目名マスタに存在しない[COME0006]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0006",
                "ryokinKomokuCd");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2
                .capture(),summaryCaptor_3.capture(),summaryCaptor_4.capture())).thenReturn(messageModuleBean);

        //テスト実行
        Mst382Form form = new Mst382Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        form.setSearchResult(result);
        target.setMst382Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst382Form();

        Date tekiyoKaishibi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoKaishibi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst382BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listRyokinKomokuCd0",paramsCaptor_1_Param.get("listRyokinKomokuCd"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals(tekiyoKaishibi,paramsCaptor_1_Param.get("listTekiyoKaishibi"));
        assertEquals("listMeisaiKbn0",paramsCaptor_1_Param.get("listMeisaiKbn"));
        assertEquals("listNebikifukaFlg0",paramsCaptor_1_Param.get("listNebikifukaFlg"));
        assertEquals("listShosutenKbn0",paramsCaptor_1_Param.get("listShosutenKbn"));
        assertEquals("listSeigyoKbn0",paramsCaptor_1_Param.get("listSeigyoKbn"));
        assertEquals("listSeigyoKbnName0",paramsCaptor_1_Param.get("listSeigyoKbnName"));
        assertEquals("listZeiKbn0",paramsCaptor_1_Param.get("listZeiKbn"));
        assertEquals("listYusoUriageSetSaki0",paramsCaptor_1_Param.get("listYusoUriageSetSaki"));
        assertEquals("listOroshitanka0",paramsCaptor_1_Param.get("listOroshitanka"));
        assertEquals("listOroshineritsu0",paramsCaptor_1_Param.get("listOroshineritsu"));
        assertEquals("listOroshiKamokuCd0",paramsCaptor_1_Param.get("listOroshiKamokuCd"));
        assertEquals("listOroshiKamokuMeisho0",paramsCaptor_1_Param.get("listOroshiKamokuMeisho"));
        assertEquals("listShoriKamokuCd0",paramsCaptor_1_Param.get("listShoriKamokuCd"));
        assertEquals("listShoriKamokuMeisho0",paramsCaptor_1_Param.get("listShoriKamokuMeisho"));
        assertEquals("listHojoKamokuCd0",paramsCaptor_1_Param.get("listHojoKamokuCd"));
        assertEquals("listHojoKamokuMeisho0",paramsCaptor_1_Param.get("listHojoKamokuMeisho"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listShuryoFlg0",paramsCaptor_1_Param.get("listShuryoFlg"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listTekiyoKaishibiRire0",paramsCaptor_1_Param.get("listTekiyoKaishibiRire"));
        assertEquals("listTekiyoShuryobiRire0",paramsCaptor_1_Param.get("listTekiyoShuryobiRire"));
        assertEquals("listCharterRyokinKomokuVersion0",paramsCaptor_1_Param.get("listCharterRyokinKomokuVersion"));
        assertEquals("listKoshinCounter0",paramsCaptor_1_Param.get("listKoshinCounter"));                                
        assertEquals("listCharterRyokinKomokuVersion0",paramsCaptor_1_Param.get("listCharterRyokinKomokuVersion"));
        assertEquals("mst382-delete-exist",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0006）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0006",summaryCaptor_2.getValue());
    }    

    // rirekiIchiran_正常_更新履歴コンテキストメニュー_13-1
    //
    // -------------------テスト条件--------------------------
    // 正常に取得された場合
    // -----------------------------------------------------
    @Test
    public void rirekiIchiran_正常_更新履歴コンテキストメニュー_13_1 () throws IllegalAccessException, 
            InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> titleFlgCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> searchKeyCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(rirekiSyosaiBean).searchList(titleFlgCaptor_1.capture(),functionCodeCaptor_2.capture()
                ,searchKeyCaptor_3.capture());
        //テスト実行
        Mst382Form form = new Mst382Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst382Form(form);
        target.rirekiIchiran();

        //実施結果Outを取得
        form = target.getMst382Form();
        
        Date tekiyoKaishibi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoKaishibi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst382BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        //想定通りに履歴を表示する。
        assertEquals("2",titleFlgCaptor_1.getValue());
        assertEquals("MST382_SEARCH_RIREKI",functionCodeCaptor_2.getValue());
        assertEquals("listRyokinKomokuCd0",searchKeyCaptor_3.getValue().get("listRyokinKomokuCd"));
        assertEquals(tekiyoKaishibi,searchKeyCaptor_3.getValue().get("listTekiyoKaishibi"));
    }    

    // searchChange_正常_補充ケース_14-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void searchChange_正常_補充ケース_14_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst382Form form = new Mst382Form();
        target.setMst382Form(form);
        target.searchChange();

        //実施結果Outを取得
        form = target.getMst382Form();

    }

    // menuClick_正常_補充ケース_14-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_14_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst382Form form = new Mst382Form();
        target.setMst382Form(form);
        target.menuClick("","");

        //実施結果Outを取得
        form = target.getMst382Form();

    }

    // menuClick_正常_補充ケース_14-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_14_2_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(1);

        //テスト実行
        Mst382Form form = new Mst382Form();
        target.setMst382Form(form);
        target.menuClick("","");

        //実施結果Outを取得
        form = target.getMst382Form();

    }    
    
    // breadClumClick_正常_補充ケース_14-3
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_14_3 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst382Form form = new Mst382Form();
        target.setMst382Form(form);
        target.breadClumClick("",0);

        //実施結果Outを取得
        form = target.getMst382Form();

    }

    // breadClumClick_正常_補充ケース_14-3_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_14_3_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(0);        
        
        //テスト実行
        Mst382Form form = new Mst382Form();
        target.setMst382Form(form);
        target.breadClumClick("",0);

        //実施結果Outを取得
        form = target.getMst382Form();

    }    
    
    // logoutClick_正常_補充ケース_14-4
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void logoutClick_正常_補充ケース_14_4 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst382Form form = new Mst382Form();
        target.setMst382Form(form);
        target.logoutClick();

        //実施結果Outを取得
        form = target.getMst382Form();

    }

    // delRowsFunc_正常_補充ケース_14-5
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void delRowsFunc_正常_補充ケース_14_5 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst382Form form = new Mst382Form();
        target.setMst382Form(form);
        target.delRowsFunc();

        //実施結果Outを取得
        form = target.getMst382Form();

    }    
    
    private Map<String, String> createRecMapFor_1_1(int i) {
        Date listTekiyobiDownload = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            listTekiyobiDownload = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst382BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        Map recMap = new HashMap();
        recMap.put("listRyokinKomokuCd", "listRyokinKomokuCd" + i);
        recMap.put("listRyokinKomokuMeisho", "listRyokinKomokuMeisho" + i);
        recMap.put("listTekiyoKaishibi", "listTekiyoKaishibi" + i);
        recMap.put("listMeisaiKbn", "listMeisaiKbn" + i);
        recMap.put("listNebikifukaFlg", "listNebikifukaFlg" + i);
        recMap.put("listShosutenKbn", "listShosutenKbn" + i);
        recMap.put("listSeigyoKbn", "listSeigyoKbn" + i);
        recMap.put("listSeigyoKbnName", "listSeigyoKbnName" + i);
        recMap.put("listZeiKbn", "listZeiKbn" + i);
        recMap.put("listYusoUriageSetSaki", "listYusoUriageSetSaki" + i);
        recMap.put("listOroshitanka", 1000);
        recMap.put("listOroshineritsu", 1.2);
        recMap.put("listOroshiKamokuCd", "listOroshiKamokuCd" + i);
        recMap.put("listOroshiKamokuMeisho", "listOroshiKamokuMeisho" + i);
        recMap.put("listShoriKamokuCd", "listShoriKamokuCd" + i);
        recMap.put("listShoriKamokuMeisho", "listShoriKamokuMeisho" + i);
        recMap.put("listHojoKamokuCd", "listHojoKamokuCd" + i);
        recMap.put("listHojoKamokuMeisho", "listHojoKamokuMeisho" + i);
        recMap.put("listTekiyoMei", "listTekiyoMei" + i);
        recMap.put("listShuryoFlg", "listShuryoFlg" + i);
        recMap.put("listTekiyoShuryobi", "listTekiyoShuryobi" + i);
        recMap.put("listTekiyoKaishibiRire", "listTekiyoKaishibiRire" + i);
        recMap.put("listTekiyoShuryobiRire", "listTekiyoShuryobiRire" + i);
        recMap.put("listCharterRyokinKomokuVersion", "listCharterRyokinKomokuVersion" + i);
        recMap.put("listKoshinCounter", "listKoshinCounter" + i);
        
        recMap.put("listTekiyoKaishibiDownload", listTekiyobiDownload);
        recMap.put("listTekiyoShuryobiDownload", listTekiyobiDownload);
        
        return recMap;
    }

    private Map<String, Object> createRecMapFor_11_1(int i) {
        Date tekiyoKaishibi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoKaishibi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst382BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        Map recMap = new HashMap();
        recMap.put("listRyokinKomokuCd", "listRyokinKomokuCd" + i);
        recMap.put("listRyokinKomokuMeisho", "listRyokinKomokuMeisho" + i);
        recMap.put("listTekiyoKaishibi", tekiyoKaishibi);
        recMap.put("listMeisaiKbn", "listMeisaiKbn" + i);
        recMap.put("listNebikifukaFlg", "listNebikifukaFlg" + i);
        recMap.put("listShosutenKbn", "listShosutenKbn" + i);
        recMap.put("listSeigyoKbn", "listSeigyoKbn" + i);
        recMap.put("listSeigyoKbnName", "listSeigyoKbnName" + i);
        recMap.put("listZeiKbn", "listZeiKbn" + i);
        recMap.put("listYusoUriageSetSaki", "listYusoUriageSetSaki" + i);
        recMap.put("listOroshitanka", "listOroshitanka" + i);
        recMap.put("listOroshineritsu", "listOroshineritsu" + i);
        recMap.put("listOroshiKamokuCd", "listOroshiKamokuCd" + i);
        recMap.put("listOroshiKamokuMeisho", "listOroshiKamokuMeisho" + i);
        recMap.put("listShoriKamokuCd", "listShoriKamokuCd" + i);
        recMap.put("listShoriKamokuMeisho", "listShoriKamokuMeisho" + i);
        recMap.put("listHojoKamokuCd", "listHojoKamokuCd" + i);
        recMap.put("listHojoKamokuMeisho", "listHojoKamokuMeisho" + i);
        recMap.put("listTekiyoMei", "listTekiyoMei" + i);
        recMap.put("listShuryoFlg", "listShuryoFlg" + i);
        recMap.put("listTekiyoShuryobi", "listTekiyoShuryobi" + i);
        recMap.put("listTekiyoKaishibiRire", "listTekiyoKaishibiRire" + i);
        recMap.put("listTekiyoShuryobiRire", "listTekiyoShuryobiRire" + i);
        recMap.put("listCharterRyokinKomokuVersion", "listCharterRyokinKomokuVersion" + i);
        recMap.put("listKoshinCounter", "listKoshinCounter" + i);
        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }
    
    private void assertForRecList_2_3(Mst382Form form) {
        int i = 0;
        assertEquals(1, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listRyokinKomokuCd" + i, rec.get("listRyokinKomokuCd"));
            assertEquals("listRyokinKomokuMeisho" + i, rec.get("listRyokinKomokuMeisho"));
            assertEquals("listTekiyoKaishibi" + i, rec.get("listTekiyoKaishibi"));
            assertEquals("listMeisaiKbn" + i, rec.get("listMeisaiKbn"));
            assertEquals("listNebikifukaFlg" + i, rec.get("listNebikifukaFlg"));
            assertEquals("listShosutenKbn" + i, rec.get("listShosutenKbn"));
            assertEquals("listSeigyoKbn" + i, rec.get("listSeigyoKbn"));
            assertEquals("listSeigyoKbnName" + i, rec.get("listSeigyoKbnName"));
            assertEquals("listZeiKbn" + i, rec.get("listZeiKbn"));
            assertEquals("listYusoUriageSetSaki" + i, rec.get("listYusoUriageSetSaki"));
            assertEquals("1,000", rec.get("listOroshitanka"));
            assertEquals("1.2", rec.get("listOroshineritsu"));
            assertEquals("listOroshiKamokuCd" + i, rec.get("listOroshiKamokuCd"));
            assertEquals("listOroshiKamokuMeisho" + i, rec.get("listOroshiKamokuMeisho"));
            assertEquals("listShoriKamokuCd" + i, rec.get("listShoriKamokuCd"));
            assertEquals("listShoriKamokuMeisho" + i, rec.get("listShoriKamokuMeisho"));
            assertEquals("listHojoKamokuCd" + i, rec.get("listHojoKamokuCd"));
            assertEquals("listHojoKamokuMeisho" + i, rec.get("listHojoKamokuMeisho"));
            assertEquals("listTekiyoMei" + i, rec.get("listTekiyoMei"));
            assertEquals("listShuryoFlg" + i, rec.get("listShuryoFlg"));
            assertEquals("listTekiyoShuryobi" + i, rec.get("listTekiyoShuryobi"));
            assertEquals("listTekiyoKaishibiRire" + i, rec.get("listTekiyoKaishibiRire"));
            assertEquals("listTekiyoShuryobiRire" + i, rec.get("listTekiyoShuryobiRire"));
            assertEquals("listCharterRyokinKomokuVersion" + i, rec.get("listCharterRyokinKomokuVersion"));
            assertEquals("listKoshinCounter" + i, rec.get("listKoshinCounter"));
            assertEquals("2019/01/01", rec.get("listTekiyoKaishibiDownload"));
            assertEquals("2019/01/01", rec.get("listTekiyoShuryobiDownload"));
            
            i++;
        }
    }    

    private void assertForRecList_2_4(Mst382Form form) {
        int i = 0;
        assertEquals(2, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listRyokinKomokuCd" + i, rec.get("listRyokinKomokuCd"));
            assertEquals("listRyokinKomokuMeisho" + i, rec.get("listRyokinKomokuMeisho"));
            assertEquals("listTekiyoKaishibi" + i, rec.get("listTekiyoKaishibi"));
            assertEquals("listMeisaiKbn" + i, rec.get("listMeisaiKbn"));
            assertEquals("listNebikifukaFlg" + i, rec.get("listNebikifukaFlg"));
            assertEquals("listShosutenKbn" + i, rec.get("listShosutenKbn"));
            assertEquals("listSeigyoKbn" + i, rec.get("listSeigyoKbn"));
            assertEquals("listSeigyoKbnName" + i, rec.get("listSeigyoKbnName"));
            assertEquals("listZeiKbn" + i, rec.get("listZeiKbn"));
            assertEquals("listYusoUriageSetSaki" + i, rec.get("listYusoUriageSetSaki"));
            assertEquals("1,000" , rec.get("listOroshitanka"));
            assertEquals("1.2", rec.get("listOroshineritsu"));
            assertEquals("listOroshiKamokuCd" + i, rec.get("listOroshiKamokuCd"));
            assertEquals("listOroshiKamokuMeisho" + i, rec.get("listOroshiKamokuMeisho"));
            assertEquals("listShoriKamokuCd" + i, rec.get("listShoriKamokuCd"));
            assertEquals("listShoriKamokuMeisho" + i, rec.get("listShoriKamokuMeisho"));
            assertEquals("listHojoKamokuCd" + i, rec.get("listHojoKamokuCd"));
            assertEquals("listHojoKamokuMeisho" + i, rec.get("listHojoKamokuMeisho"));
            assertEquals("listTekiyoMei" + i, rec.get("listTekiyoMei"));
            assertEquals("listShuryoFlg" + i, rec.get("listShuryoFlg"));
            assertEquals("listTekiyoShuryobi" + i, rec.get("listTekiyoShuryobi"));
            assertEquals("listTekiyoKaishibiRire" + i, rec.get("listTekiyoKaishibiRire"));
            assertEquals("listTekiyoShuryobiRire" + i, rec.get("listTekiyoShuryobiRire"));
            assertEquals("listCharterRyokinKomokuVersion" + i, rec.get("listCharterRyokinKomokuVersion"));
            assertEquals("listKoshinCounter" + i, rec.get("listKoshinCounter"));
            i++;
        }
    }      

    private void assertForRecList_2_5(Mst382Form form) {
        int i = 0;
        assertEquals(0, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listRyokinKomokuCd" + i, rec.get("listRyokinKomokuCd"));
            assertEquals("listRyokinKomokuMeisho" + i, rec.get("listRyokinKomokuMeisho"));
            assertEquals("listTekiyoKaishibi" + i, rec.get("listTekiyoKaishibi"));
            assertEquals("listMeisaiKbn" + i, rec.get("listMeisaiKbn"));
            assertEquals("listNebikifukaFlg" + i, rec.get("listNebikifukaFlg"));
            assertEquals("listShosutenKbn" + i, rec.get("listShosutenKbn"));
            assertEquals("listSeigyoKbn" + i, rec.get("listSeigyoKbn"));
            assertEquals("listSeigyoKbnName" + i, rec.get("listSeigyoKbnName"));
            assertEquals("listZeiKbn" + i, rec.get("listZeiKbn"));
            assertEquals("listYusoUriageSetSaki" + i, rec.get("listYusoUriageSetSaki"));
            assertEquals("listOroshitanka" + i, rec.get("listOroshitanka"));
            assertEquals("listOroshineritsu" + i, rec.get("listOroshineritsu"));
            assertEquals("listOroshiKamokuCd" + i, rec.get("listOroshiKamokuCd"));
            assertEquals("listOroshiKamokuMeisho" + i, rec.get("listOroshiKamokuMeisho"));
            assertEquals("listShoriKamokuCd" + i, rec.get("listShoriKamokuCd"));
            assertEquals("listShoriKamokuMeisho" + i, rec.get("listShoriKamokuMeisho"));
            assertEquals("listHojoKamokuCd" + i, rec.get("listHojoKamokuCd"));
            assertEquals("listHojoKamokuMeisho" + i, rec.get("listHojoKamokuMeisho"));
            assertEquals("listTekiyoMei" + i, rec.get("listTekiyoMei"));
            assertEquals("listShuryoFlg" + i, rec.get("listShuryoFlg"));
            assertEquals("listTekiyoShuryobi" + i, rec.get("listTekiyoShuryobi"));
            assertEquals("listTekiyoKaishibiRire" + i, rec.get("listTekiyoKaishibiRire"));
            assertEquals("listTekiyoShuryobiRire" + i, rec.get("listTekiyoShuryobiRire"));
            assertEquals("listCharterRyokinKomokuVersion" + i, rec.get("listCharterRyokinKomokuVersion"));
            assertEquals("listKoshinCounter" + i, rec.get("listKoshinCounter"));
            i++;
        }
    }
    
}
