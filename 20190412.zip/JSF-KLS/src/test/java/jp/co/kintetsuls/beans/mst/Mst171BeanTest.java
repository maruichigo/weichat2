/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import java.io.IOException;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import jp.co.kintetsuls.common.json.JSONUtil;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.KbnBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst171Form;
import jp.co.kintetsuls.utils.FlashUtil;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import static org.mockito.Mockito.doThrow;

/**
 * MAWB一覧画面画面
 *
 * @author 張誠 (MBP)
 * @version 2019/03/25 新規作成
 */
public class Mst171BeanTest {

    // テストTarget
    @InjectMocks
    private Mst171Bean target;

    // Mockitoオブジェクト
    @Mock
    private FileBean fileBean;
    @Mock
    private AutoCompleteViewBean autoCompleteViewBean;
    @Mock
    private MasterInfoBean masterInfo;
    @Mock
    private MessagePropertyBean messageProperty;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosai;
    @Mock
    private SearchHelpBean searchHelpBean;
    @Mock
    private AuthorityConfBean authConfBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private MessagePropertyBean messagePropertyBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosaiBean;
    @Mock
    private FlashUtil flashUtil;
    @Mock
    private BaseBean baseBean;
    @Mock
    private KbnBean kbnBean;

    public Mst171BeanTest() {
    }

    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() {
    }

    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[not null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst171Form mst171Form = new Mst171Form();

        //前画面情報[not null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst171Form);
        when(kbnBean.getKbnCdOfKeyCd(keyCaptor_1_1.capture())).thenReturn("kbnCd");

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());

        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setConNiukeNiokurininMode("1");
        target.setMst171Form(form);
        target.init("", "MST012_SCREEN", false);

        //実施結果Outを取得
        form = target.getMst171Form();
        String title1 = target.getTITLE1();
        String title2 = target.getTITLE2();
        String fileName1 = target.getFILE_NAME1();
        String fileName2 = target.getFILE_NAME2();
        String url = target.getUrl();
        BreadCrumbBean breadBean = target.getBreadBean();
        KbnBean kbnBean = target.getKbnBean();
        AutoCompleteViewBean autoCompleteViewBean = target.getAutoCompleteViewBean();
        AuthorityConfBean authorityConfBean = target.getAuthConfBean();
        FileBean fileBean = target.getFileBean();
        MessagePropertyBean messagePropertyBean = target.getMessagePropertyBean();
        PageCommonBean pageCommonBean = target.getPageCommonBean();
        SearchHelpBean searchHelpBean = target.getSearchHelpBean();
        RirekiSyosaiBean rirekiSyosaiBean = target.getRirekiSyosaiBean();
        target.setUrl(url);
        target.setBreadBean(breadBean);
        target.setAutoCompleteViewBean(autoCompleteViewBean);
        target.setAuthConfBean(authorityConfBean);
        target.setMessagePropertyBean(messagePropertyBean);
        target.setKbnBean(kbnBean);
        target.setPageCommonBean(pageCommonBean);
        target.setSearchHelpBean(searchHelpBean);

        // 実行時に渡すパラメータの検証
        assertEquals("mst171Form", keyCaptor_1.getValue());

    }

    // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 前回画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> keyCaptor_1_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst171Form mst171Form = new Mst171Form();

        //前回画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst171Form);
        when(kbnBean.getKbnCdOfKeyCd(keyCaptor_1_1.capture())).thenReturn("kbnCd");

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());

        // パラメータキャプチャー
        // Mockitoオブジェクトの予想return値設定
        Flash flash = new FlashKls();
        //前画面パラメータ[都道府県 = 01,仕向地名 = 地名23,削除済のみ検索 = null]
        flash.put("mst171Form", mst171Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);

        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setConNiukeNiokurininMode("2");
        target.setMst171Form(form);
        target.init("", "", false);

        //実施結果Outを取得
        form = target.getMst171Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst171Form", keyCaptor_1.getValue());
        // 想定通りに再検索を実施する。
        assertEquals("search_mst171", keyCaptor_2.getValue());

    }

    // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 前回画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> keyCaptor_1_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst171Form mst171Form = new Mst171Form();

        //前回画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst171Form);
        when(kbnBean.getKbnCdOfKeyCd(keyCaptor_1_1.capture())).thenReturn("kbnCd");

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());

        // パラメータキャプチャー
        // Mockitoオブジェクトの予想return値設定
        Flash flash = new FlashKls();
        //前画面パラメータ[都道府県 = 01,仕向地名 = 地名23,削除済のみ検索 = null]
        flash.put("mst171Form", mst171Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);

        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setConNiukeNiokurininMode("2");
        target.setMst171Form(form);
        target.init("", "", true);

        //実施結果Outを取得
        form = target.getMst171Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst171Form", keyCaptor_1.getValue());
        // 想定通りに再検索を実施する。
        assertEquals("search_mst171", keyCaptor_2.getValue());

    }

    // init_正常_初期処理_1-3_1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> keyCaptor_1_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        // 前画面情報[null]
        doThrow(IllegalAccessException.class).when(pageCommonBean).getPageInfo(keyCaptor_1.capture());
        when(kbnBean.getKbnCdOfKeyCd(keyCaptor_1_1.capture())).thenReturn("kbnCd");

        // テスト実行
        Mst171Form form = new Mst171Form();
        form.setConNiukeNiokurininMode("2");
        target.setMst171Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID", "", false);

        // 実施結果Outを取得
        form = target.getMst171Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst171Form", keyCaptor_1.getValue());
        // 想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null, form.getSearchResult());
    }

    // search_正常_検索処理_2_1
    //
    // -------------------テスト条件--------------------------
    // 検索結果一覧取得 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_1() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索結果一覧取得 取得件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 0; i++) {
            result.add(createRecMapForSearchResult(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mst171Form form = new Mst171Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("132");
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("0000007");
        form.setConNiukeNiokurininMode("1");
        form.setConHKokyakuCd("0000007");
        form.setConKokyakuCd(conKokyakuCd);
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConNiukeninHakkoCd("0000008");
        form.setConNiukeninMei("荷受人名称1");
        form.setConNiukeninKanaMei("荷受人カナ名称1");
        form.setConNiukeninJusho("荷受人住所1");
        form.setConNiukeninTel("荷受人電話番号1");
        form.setConNiukeninKey("荷受人検索キー1");
        form.setConSortJun("1");
        form.setConYoshuseiNomi(new String[]{"01"});
        form.setConKyuJushoHyoji(new String[]{"01"});
        form.setConMishiyoKikanNen("10");
        form.setConMishiyoKikanTsuki("10");
        form.setConSakujozumiFukumu(new String[]{"01"});
        target.setMst171Form(form);
        target.search();

        // 実施結果Outを取得
        form = target.getMst171Form();

        // 実行時に渡すパラメータの検証
        assertEquals("132", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("1", paramsCaptor_1.getValue().get("conNiukeNiokurininMode"));
        assertEquals("0000007", paramsCaptor_1.getValue().get("conKokyakuCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conHKokyakuCd"));
        assertEquals("0000008", paramsCaptor_1.getValue().get("conNiukeninHakkoCd"));
        assertEquals("荷受人名称1", paramsCaptor_1.getValue().get("conNiukeninMei"));
        assertEquals("mst171-get-detail", functionCodeCaptor_2.getValue());
        // 想定通りに一覧を表示されること
        assertForRecList_2_1(form);
    }

    // search_正常_検索処理_2_1_1
    //
    // -------------------テスト条件--------------------------
    // 検索結果一覧取得 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_1_1() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索結果一覧取得 取得件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 0; i++) {
            result.add(createRecMapForSearchResult(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mst171Form form = new Mst171Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("132");
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("0000007");
        form.setConNiukeNiokurininMode("2");
        form.setConHKokyakuCd("0000007");
        form.setConKokyakuCd(conKokyakuCd);
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConNiokurininHakkoCd("0000008");
        form.setConNiokurininMei("荷送人名称1");
        form.setConNiokurininKanaMei("荷送人カナ名称1");
        form.setConNiokurininJusho("荷送人住所名称1");
        form.setConNiokurininTel("荷送人電話番号1");
        form.setConNiokurininKey("荷送人検索キー1");
        form.setConSortJun("1");
        form.setConMishiyoKikanNen("10");
        form.setConMishiyoKikanTsuki("10");
        target.setMst171Form(form);
        target.search();

        // 実施結果Outを取得
        form = target.getMst171Form();

        // 実行時に渡すパラメータの検証
        assertEquals("132", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("2", paramsCaptor_1.getValue().get("conNiukeNiokurininMode"));
        assertEquals("0000007", paramsCaptor_1.getValue().get("conKokyakuCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conHKokyakuCd"));
        assertEquals("0000008", paramsCaptor_1.getValue().get("conNiokurininHakkoCd"));
        assertEquals("荷送人名称1", paramsCaptor_1.getValue().get("conNiokurininMei"));
        assertEquals("mst171-get-detail", functionCodeCaptor_2.getValue());
        // 想定通りに一覧を表示されること
        assertForRecList_2_1(form);
    }

    // search_異常_検索処理_2_2
    //
    // -------------------テスト条件--------------------------
    // 検索結果一覧取得 取得件数 = 0
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_2() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

        doThrow(IOException.class).when(pageCommonBean).getDBInfo(paramsCaptor_1.capture(),
                functionCodeCaptor_2.capture());

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mst171Form form = new Mst171Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("132");
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("0000007");
        form.setConNiukeNiokurininMode("2");
        form.setConHKokyakuCd("0000007");
        form.setConKokyakuCd(conKokyakuCd);
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConNiokurininHakkoCd("0000008");
        form.setConNiokurininMei("荷送人名称1");
        form.setConNiokurininKanaMei("荷送人カナ名称1");
        form.setConNiokurininJusho("荷送人住所名称1");
        form.setConNiokurininTel("荷送人電話番号1");
        form.setConNiokurininKey("荷送人検索キー1");
        form.setConSortJun("1");
        form.setConMishiyoKikanNen("10");
        form.setConMishiyoKikanTsuki("10");
        target.setMst171Form(form);
        target.search();

        // 実施結果Outを取得
        form = target.getMst171Form();

        // 実行時に渡すパラメータの検証
        assertEquals("132", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("2", paramsCaptor_1.getValue().get("conNiukeNiokurininMode"));
        assertEquals("0000007", paramsCaptor_1.getValue().get("conKokyakuCd"));
        assertEquals("0000008", paramsCaptor_1.getValue().get("conNiokurininHakkoCd"));
        assertEquals("荷送人名称1", paramsCaptor_1.getValue().get("conNiokurininMei"));
        assertEquals("mst171-get-detail", functionCodeCaptor_2.getValue());
    }

    // count_正常_カウント処理_2_3
    //
    // -------------------テスト条件--------------------------
    // 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void count_正常_カウント処理_2_3() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索結果一覧取得 取得件数 = 1
        int result = 1;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);

        // テスト実行
        Mst171Form form = new Mst171Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("132");
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("0000007");
        form.setConNiukeNiokurininMode("2");
        form.setConHKokyakuCd("0000007");
        form.setConKokyakuCd(conKokyakuCd);
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConNiokurininHakkoCd("0000008");
        form.setConNiokurininMei("荷送人名称1");
        form.setConNiokurininKanaMei("荷送人カナ名称1");
        form.setConNiokurininJusho("荷送人住所名称1");
        form.setConNiokurininTel("荷送人電話番号1");
        form.setConNiokurininKey("荷送人検索キー1");
        form.setConSortJun("1");
        form.setConMishiyoKikanNen("10");
        target.setMst171Form(form);
        when(pageCommonBean.getPageInfo("mst171Form")).thenReturn(form);
        long kensu = target.count(true);

        // 実施結果Outを取得
        form = target.getMst171Form();

        // 実行時に渡すパラメータの検証
        assertEquals("132", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("2", paramsCaptor_1.getValue().get("conNiukeNiokurininMode"));
        assertEquals("0000007", paramsCaptor_1.getValue().get("conKokyakuCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conHKokyakuCd"));
        assertEquals("0000008", paramsCaptor_1.getValue().get("conNiokurininHakkoCd"));
        assertEquals("荷送人名称1", paramsCaptor_1.getValue().get("conNiokurininMei"));
        assertEquals("mst171-get-kensu", functionCodeCaptor_2.getValue());
        assertEquals(1, kensu);
    }

    // count_正常_カウント処理_2_3_1
    //
    // -------------------テスト条件--------------------------
    // 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void count_正常_カウント処理_2_3_1() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索結果一覧取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);

        // テスト実行
        Mst171Form form = new Mst171Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("132");
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("0000007");
        form.setConNiukeNiokurininMode("2");
        form.setConHKokyakuCd("0000007");
        form.setConKokyakuCd(conKokyakuCd);
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConNiokurininHakkoCd("0000008");
        form.setConNiokurininMei("荷送人名称1");
        form.setConNiokurininKanaMei("荷送人カナ名称1");
        form.setConNiokurininJusho("荷送人住所名称1");
        form.setConNiokurininTel("荷送人電話番号1");
        form.setConNiokurininKey("荷送人検索キー1");
        form.setConSortJun("1");
        form.setConMishiyoKikanTsuki("10");
        target.setMst171Form(form);
        when(pageCommonBean.getPageInfo("mst171Form")).thenReturn(form);
        long kensu = target.count(false);

        // 実施結果Outを取得
        form = target.getMst171Form();

        // 実行時に渡すパラメータの検証
        assertEquals("132", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("2", paramsCaptor_1.getValue().get("conNiukeNiokurininMode"));
        assertEquals("0000007", paramsCaptor_1.getValue().get("conKokyakuCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conHKokyakuCd"));
        assertEquals("0000008", paramsCaptor_1.getValue().get("conNiokurininHakkoCd"));
        assertEquals("荷送人名称1", paramsCaptor_1.getValue().get("conNiokurininMei"));
        assertEquals("mst171-get-kensu", functionCodeCaptor_2.getValue());
        assertEquals(2, kensu);
    }
    
    // count_正常_カウント処理_2_3_2
    //
    // -------------------テスト条件--------------------------
    // 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void count_正常_カウント処理_2_3_2() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索結果一覧取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);

        // テスト実行
        Mst171Form form = new Mst171Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("132");
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("0000007");
        form.setConNiukeNiokurininMode("2");
        form.setConHKokyakuCd("0000007");
        form.setConKokyakuCd(conKokyakuCd);
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConNiokurininHakkoCd("0000008");
        form.setConNiokurininMei("荷送人名称1");
        form.setConNiokurininKanaMei("荷送人カナ名称1");
        form.setConNiokurininJusho("荷送人住所名称1");
        form.setConNiokurininTel("荷送人電話番号1");
        form.setConNiokurininKey("荷送人検索キー1");
        form.setConSortJun("1");
        form.setConSakujozumiFukumu(new String[]{"01"});
        target.setMst171Form(form);
        when(pageCommonBean.getPageInfo("mst171Form")).thenReturn(form);
        long kensu = target.count(false);

        // 実施結果Outを取得
        form = target.getMst171Form();

        // 実行時に渡すパラメータの検証
        assertEquals("132", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("2", paramsCaptor_1.getValue().get("conNiukeNiokurininMode"));
        assertEquals("0000007", paramsCaptor_1.getValue().get("conKokyakuCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conHKokyakuCd"));
        assertEquals("0000008", paramsCaptor_1.getValue().get("conNiokurininHakkoCd"));
        assertEquals("荷送人名称1", paramsCaptor_1.getValue().get("conNiokurininMei"));
        assertEquals("mst171-get-kensu", functionCodeCaptor_2.getValue());
        assertEquals(2, kensu);
    }
        
    // count_正常_カウント処理_2_3_3
    //
    // -------------------テスト条件--------------------------
    // 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void count_正常_カウント処理_2_3_3() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索結果一覧取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);

        // テスト実行
        Mst171Form form = new Mst171Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("132");
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("0000007");
        form.setConNiukeNiokurininMode("2");
        form.setConHKokyakuCd("0000007");
        form.setConKokyakuCd(conKokyakuCd);
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConNiokurininHakkoCd("0000008");
        form.setConNiokurininMei("荷送人名称1");
        form.setConNiokurininKanaMei("荷送人カナ名称1");
        form.setConNiokurininJusho("荷送人住所名称1");
        form.setConNiokurininTel("荷送人電話番号1");
        form.setConNiokurininKey("荷送人検索キー1");
        form.setConSortJun("1");
        target.setMst171Form(form);
        when(pageCommonBean.getPageInfo("mst171Form")).thenReturn(form);
        long kensu = target.count(false);

        // 実施結果Outを取得
        form = target.getMst171Form();

        // 実行時に渡すパラメータの検証
        assertEquals("132", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("2", paramsCaptor_1.getValue().get("conNiukeNiokurininMode"));
        assertEquals("0000007", paramsCaptor_1.getValue().get("conKokyakuCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conHKokyakuCd"));
        assertEquals("0000008", paramsCaptor_1.getValue().get("conNiokurininHakkoCd"));
        assertEquals("荷送人名称1", paramsCaptor_1.getValue().get("conNiokurininMei"));
        assertEquals("mst171-get-kensu", functionCodeCaptor_2.getValue());
        assertEquals(2, kensu);
    }

    // clear_正常_クリア処理_3-1
    //
    // -------------------テスト条件--------------------------
    // 検索結果がある
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_1() throws IllegalAccessException, InvocationTargetException, ParseException {

        // テスト実行
        Mst171Form form = new Mst171Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("132");
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("0000007");
        form.setConNiukeNiokurininMode("2");
        form.setConHKokyakuCd("0000007");
        form.setConKokyakuCd(conKokyakuCd);
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConNiokurininHakkoCd("0000008");
        form.setConNiokurininMei("荷送人名称1");
        form.setConNiokurininKanaMei("荷送人カナ名称1");
        form.setConNiokurininJusho("荷送人住所名称1");
        form.setConNiokurininTel("荷送人電話番号1");
        form.setConNiokurininKey("荷送人検索キー1");
        form.setConSortJun("1");
        form.setConMishiyoKikanNen("10");
        form.setConMishiyoKikanTsuki("10");

        target.setMst171Form(form);
        target.clear();

        // 実施結果Outを取得
        form = target.getMst171Form();

        // 想定通りに正常にClearを実施されること
        assertEquals(null, form.getConEigyoshoCd());
        assertEquals(null, form.getConKokyakuCd());
        assertEquals(null, form.getConNiokurininHakkoCd());
        assertEquals(null, form.getConNiokurininMei());
        assertEquals(null, form.getConNiokurininKanaMei());
        assertEquals(null, form.getConNiokurininJusho());
    }

    // clear_正常_クリア処理_3-2
    //
    // -------------------テスト条件--------------------------
    // 検索条件がない
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_2() throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst171Form form = new Mst171Form();
        form.setConNiukeNiokurininMode("1");
        target.setMst171Form(form);
        target.clear();

        // 実施結果Outを取得
        form = target.getMst171Form();

        // 想定通りに正常にClearを実施されること
        assertEquals(null, form.getConEigyoshoCd());
        assertEquals(null, form.getConNiukeninHakkoCd());
        assertEquals(null, form.getConKokyakuCd());
        assertEquals(null, form.getConNiukeninMei());
        assertEquals(null, form.getConNiukeninKanaMei());
        assertEquals(null, form.getConNiukeninJusho());
        assertEquals(null, form.getConNiukeninTel());
    }

    // getHeader_正常_ダウンロード_4-1
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void getHeader_正常_ダウンロード_4_1() throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst171Form form = new Mst171Form();
        form.setConNiukeNiokurininMode("1");
        target.setMst171Form(form);
        List<CSVDto> dto = target.getHeader();

        // 想定通りに正常にCVSのHeaderを設定されること
        assertEquals("荷受人発行コード", dto.get(0).getTitle());
        assertEquals("listNiukeninHakkoCd", dto.get(0).getName());
        assertEquals("荷受人名称", dto.get(1).getTitle());
        assertEquals("listNiukeninMei", dto.get(1).getName());
    }

    // getHeader_正常_ダウンロード_4_1_1
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void getHeader_正常_ダウンロード_4_1_1() throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst171Form form = new Mst171Form();
        form.setConNiukeNiokurininMode("2");
        target.setMst171Form(form);
        List<CSVDto> dto = target.getHeader();

        // 想定通りに正常にCVSのHeaderを設定されること
        assertEquals("荷送人発行コード", dto.get(0).getTitle());
        assertEquals("listNiokurininHakkoCd", dto.get(0).getName());
        assertEquals("荷送人名称", dto.get(1).getTitle());
        assertEquals("listNiokurininMei", dto.get(1).getName());
    }

    // beforeDown_正常_ダウンロード_4_2
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=2件
    // -----------------------------------------------------
    @Test
    public void beforeDown_正常_ダウンロード_4_2() throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst171Form form = new Mst171Form();
        target.setMst171Form(form);
        try {
            target.beforeDown("testComment");
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(Mst171BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        // 実施結果Outを取得
        form = target.getMst171Form();

        // 実行時に渡すパラメータの検証
        // 想定通りに正常にダウンロード理由を記録すること
        assertEquals(null, form.getConEigyoshoCd());
    }
    
    // upload_正常_アップロード_5_1
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void upload_正常_アップロード_5_1() throws IllegalAccessException, InvocationTargetException {
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setConNiukeNiokurininMode("1");
        Flash flash = new FlashKls();
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        when(flashUtil.getPageParam()).thenReturn(flash);
        target.setMst171Form(form);
        String url = target.upload();
        
        assertEquals("/contents/upload/upload.xhtml?faces-redirect=true", url);
    }
    
    // upload_正常_アップロード_5_2
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void upload_正常_アップロード_5_2() throws IllegalAccessException, InvocationTargetException {
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setConNiukeNiokurininMode("2");
        Flash flash = new FlashKls();
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        when(flashUtil.getPageParam()).thenReturn(flash);
        target.setMst171Form(form);
        String url = target.upload();
        
        assertEquals("/contents/upload/upload.xhtml?faces-redirect=true", url);
    }
    
    // detailClick_正常_詳細コンテキストメニュー_13_1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェックある
    // -----------------------------------------------------
    @Test
    public void detailClick_正常_詳細コンテキストメニュー_12_1() throws IllegalAccessException, InvocationTargetException {
      
        List<Map<String, Object>> resultList = new ArrayList<>();
        for(int i = 0; i <= 0; i++) {
            resultList.add(createRecMapForResultList(i));
        }
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setConNiukeNiokurininMode("1");
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("0000007");
        form.setConKokyakuCd(conKokyakuCd);
        form.setSelectedSearchResult(resultList);
        Flash flash = new FlashKls();
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        when(flashUtil.getPageParam()).thenReturn(flash);
        target.setMst171Form(form);
        String url = target.detailClick(false);
        
        assertEquals("/contents/mst/mst172.xhtml?faces-redirect=true", url);
    }
    
    // deleteRecord_正常_削除コンテキストメニュー_14_1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェックある
    // -----------------------------------------------------
    @Test
    public void deleteRecord_正常_削除コンテキストメニュー_13_1() throws IllegalAccessException, InvocationTargetException {
      
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);     
        doNothing().when(pageCommonBean).executeScript(keyCaptor_2.capture());
        
        List<Map<String, Object>> resultList = new ArrayList<>();
        for(int i = 0; i <= 0; i++) {
            resultList.add(createRecMapForResultList(i));
        }
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setSelectedSearchResult(resultList);
        target.setMst171Form(form);
        target.deleteRecord(false);
        
    }
    
    // shinkiToroku_正常_新規追加_14_1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェックある
    // -----------------------------------------------------
    @Test
    public void shinkiToroku_正常_新規追加_14_1() throws IllegalAccessException, InvocationTargetException {
        
        List<Map<String, Object>> resultList = new ArrayList<>();
        for(int i = 0; i <= 0; i++) {
            resultList.add(createRecMapForResultList(i));
        }
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setConNiukeNiokurininMode("1");
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("0000007");
        form.setConKokyakuCd(conKokyakuCd);
        form.setSelectedSearchResult(resultList);
        target.setMst171Form(form);
        Flash flash = new FlashKls();
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        when(flashUtil.getPageParam()).thenReturn(flash);
        String url = target.shinkiToroku();
        
        assertEquals("/contents/mst/mst172.xhtml?faces-redirect=true", url);
        
    }
    
    // copyToroku_正常_複写登録_15_1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェックある
    // -----------------------------------------------------
    @Test
    public void copyToroku_正常_複写登録_15_1() throws IllegalAccessException, InvocationTargetException {
        
        List<Map<String, Object>> resultList = new ArrayList<>();
        for(int i = 0; i <= 0; i++) {
            resultList.add(createRecMapForResultList(i));
        }
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setConNiukeNiokurininMode("1");
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("0000007");
        form.setConKokyakuCd(conKokyakuCd);
        form.setSelectedSearchResult(resultList);
        target.setMst171Form(form);
        Flash flash = new FlashKls();
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        when(flashUtil.getPageParam()).thenReturn(flash);
        String url = target.copyToroku();
        
        assertEquals("/contents/mst/mst172.xhtml?faces-redirect=true", url);
        
    }
    
    // copyToroku_正常_複写登録_15_1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェックある
    // -----------------------------------------------------
    @Test
    public void copyToroku_正常_複写登録_15_1_1() throws IllegalAccessException, InvocationTargetException {
        
        List<Map<String, Object>> resultList = new ArrayList<>();
        for(int i = 0; i <= 0; i++) {
            resultList.add(createRecMapForResultList(i));
        }
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setConNiukeNiokurininMode("2");
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("0000007");
        form.setConKokyakuCd(conKokyakuCd);
        form.setSelectedSearchResult(resultList);
        target.setMst171Form(form);
        Flash flash = new FlashKls();
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        when(flashUtil.getPageParam()).thenReturn(flash);
        String url = target.copyToroku();
        
        assertEquals("/contents/mst/mst172.xhtml?faces-redirect=true", url);
        
    }
    
    // copyToroku_異常_複写登録_15_2
    //
    // -------------------テスト条件--------------------------
    // 行選択チェックなし
    // -----------------------------------------------------
    @Test
    public void copyToroku_異常_複写登録_15_2() throws IllegalAccessException, InvocationTargetException {
      
         // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_1.capture(),summaryCaptor_2.capture());
        
        List<Map<String, Object>> resultList = new ArrayList<>();
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setSelectedSearchResult(resultList);

        target.setMst171Form(form);
        target.copyToroku();
        
        // 想定通り
        assertEquals("ERROR", levelCaptor_1.getValue());
        assertEquals("COME0022", summaryCaptor_2.getValue());
        
    }
    
        // copyToroku_正常_複写登録_15_2_1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェックあり
    // -----------------------------------------------------
    @Test
    public void copyToroku_正常_複写登録_15_2_1() throws IllegalAccessException, InvocationTargetException {
      
         // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_1.capture(),summaryCaptor_2.capture());
        
        List<Map<String, Object>> resultList = new ArrayList<>();
        for(int i = 0; i <= 1; i++) {
            resultList.add(createRecMapForResultList(i));
        }
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setSelectedSearchResult(resultList);
        target.setMst171Form(form);
        target.copyToroku();
        
        // 想定通り
        assertEquals("ERROR", levelCaptor_1.getValue());
        assertEquals("COME0020", summaryCaptor_2.getValue());
        
    }
    
    // detailClick_正常_詳細ボタン_16_1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェックある
    // -----------------------------------------------------
    @Test
    public void detailClick_正常_詳細ボタン_16_1() throws IllegalAccessException, InvocationTargetException {
      
        List<Map<String, Object>> resultList = new ArrayList<>();
        for(int i = 0; i <= 0; i++) {
            resultList.add(createRecMapForResultList(i));
        }
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setConNiukeNiokurininMode("2");
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("0000007");
        form.setConKokyakuCd(conKokyakuCd);
        form.setSelectedSearchResult(resultList);
        Flash flash = new FlashKls();
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        when(flashUtil.getPageParam()).thenReturn(flash);
        target.setMst171Form(form);
        String url = target.detailClick(true);
        
        assertEquals("/contents/mst/mst172.xhtml?faces-redirect=true", url);
    }
    
    // detailClick_異常_詳細ボタン_16_2
    //
    // -------------------テスト条件--------------------------
    // 行選択チェックなし
    // -----------------------------------------------------
    @Test
    public void detailClick_異常_詳細ボタン_16_2() throws IllegalAccessException, InvocationTargetException {
      
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_1.capture(),summaryCaptor_2.capture());
        
        List<Map<String, Object>> resultList = new ArrayList<>();
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setSelectedSearchResult(resultList);
        target.setMst171Form(form);
        String url = target.detailClick(true);
        
       // 想定通り
       assertEquals("ERROR", levelCaptor_1.getValue());
       assertEquals("COME0022", summaryCaptor_2.getValue());
    }
    
    // detailClick_異常_詳細ボタン_16_2_1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェックなし
    // 2行選択
    // -----------------------------------------------------
    @Test
    public void detailClick_異常_詳細ボタン_16_2_1() throws IllegalAccessException, InvocationTargetException {
      
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_1.capture(),summaryCaptor_2.capture());
        
        List<Map<String, Object>> resultList = new ArrayList<>();
        for(int i = 0; i <= 1; i++) {
            resultList.add(createRecMapForResultList(i));
        }
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setSelectedSearchResult(resultList);
        target.setMst171Form(form);
        String url = target.detailClick(true);
        
       // 想定通り
       assertEquals("ERROR", levelCaptor_1.getValue());
       assertEquals("COME0020", summaryCaptor_2.getValue());
    }
    
    // detailClick_異常_詳細ボタン_16_2_2
    //
    // -------------------テスト条件--------------------------
    // 行選択チェックなし
    // -----------------------------------------------------
    @Test
    public void detailClick_異常_詳細ボタン_16_2_2() throws IllegalAccessException, InvocationTargetException {
      
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_1.capture(),summaryCaptor_2.capture());
        
        //テスト実行
        Mst171Form form = new Mst171Form();
        target.setMst171Form(form);
        String url = target.detailClick(true);
        
       // 想定通り
       assertEquals("ERROR", levelCaptor_1.getValue());
       assertEquals("COME0022", summaryCaptor_2.getValue());
    }
    
    // deleteRecord_正常_削除ボタンクリック処理_17_1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェックある
    // -----------------------------------------------------
    @Test
    public void deleteRecord_正常_削除ボタンクリック処理_17_1() throws IllegalAccessException, InvocationTargetException {
      
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);     
        doNothing().when(pageCommonBean).executeScript(keyCaptor_2.capture());
        
        List<Map<String, Object>> resultList = new ArrayList<>();
        for(int i = 0; i <= 0; i++) {
            resultList.add(createRecMapForResultList(i));
        }
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setSelectedSearchResult(resultList);
        target.setMst171Form(form);
        target.deleteRecord(true);
        
    }
    
    // deleteRecord_異常_削除ボタンクリック処理_17_2
    //
    // -------------------テスト条件--------------------------
    // 行選択チェックある
    // -----------------------------------------------------
    @Test
    public void deleteRecord_異常_削除ボタンクリック処理_17_2() throws IllegalAccessException, InvocationTargetException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_1.capture(),summaryCaptor_2.capture());
        
        List<Map<String, Object>> resultList = new ArrayList<>();
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setSelectedSearchResult(resultList);
        target.setMst171Form(form);
        target.deleteRecord(true);
        
        // 想定通り
       assertEquals("ERROR", levelCaptor_1.getValue());
       assertEquals("COME0013", summaryCaptor_2.getValue());
        
    }
    
    // deleteRows_正常_削除ボタンクリック処理_17_3
    //
    // -------------------テスト条件--------------------------
    // 行選択チェックある
    // -----------------------------------------------------
    @Test
    public void deleteRows_正常_削除ボタンクリック処理_17_3() throws IllegalAccessException, InvocationTargetException {
      
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),
                functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_1.capture(),summaryCaptor_2.capture(), summaryCaptor_3.capture());
        
        List<Map<String, Object>> resultList = new ArrayList<>();
        for(int i = 0; i <= 0; i++) {
            resultList.add(createRecMapForResultList(i));
        }
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setConNiukeNiokurininMode("1");
        form.setSelectedSearchResult(resultList);
        form.setSearchResult(resultList);
        target.setMst171Form(form);
        target.deleteRows();
        
        // 想定通り
        assertEquals("INFO", levelCaptor_1.getValue());
        assertEquals("COMI0011", summaryCaptor_2.getValue());
        assertEquals("更新", summaryCaptor_3.getValue());
    }
    
    // deleteRows_異常_削除ボタンクリック処理_17_4
    //
    // -------------------テスト条件--------------------------
    // 行選択チェックある
    // -----------------------------------------------------
    @Test
    public void deleteRows_異常_削除ボタンクリック処理_17_4() throws IllegalAccessException, InvocationTargetException {
      
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("WARN", "COME0014", "NIUKENIN_HAKKO_CD ");
        serviceInterfaceBean.setTableName("MS_NIUKENIN");
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),
                functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> levelCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_1.capture(),summaryCaptor_2.capture(), 
                summaryCaptor_3.capture());
        
        List<Map<String, Object>> resultList = new ArrayList<>();
        for(int i = 0; i <= 0; i++) {
            resultList.add(createRecMapForResultList(i));
        }
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setConNiukeNiokurininMode("1");
        form.setSelectedSearchResult(resultList);
        form.setSearchResult(resultList);
        target.setMst171Form(form);
        target.deleteRows();
        
        // 想定通り
        assertEquals("WARN", levelCaptor_1.getValue());
        assertEquals("COME0014", summaryCaptor_2.getValue());
        assertEquals("MS_NIUKENIN", summaryCaptor_3.getValue());
    }
    
    // takukyakuCdKaraIkkatsuFukusha_正常_他顧客コードから一括複写_18_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void takukyakuCdKaraIkkatsuFukusha_正常_他顧客コードから一括複写_18_1() {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);     
        doNothing().when(pageCommonBean).executeScript(keyCaptor_2.capture());
        
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setConEigyoshoCdTaihi("132");
        form.setConKokyakuCdTaihi("000003");
        target.setMst171Form(form);
        target.takokyakuCdKaraIkkatsuFukusha();
        
        assertEquals("PF('widFukusha').show();", keyCaptor_2.getValue());
    }
        
    // takukyakuCdKaraIkkatsuFukusha_異常_他顧客コードから一括複写_18_2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void takukyakuCdKaraIkkatsuFukusha_異常_他顧客コードから一括複写_18_2() {
        
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_1.capture(),summaryCaptor_2.capture(), 
                summaryCaptor_3.capture());
        
        //テスト実行
        Mst171Form form = new Mst171Form();
        
        target.setMst171Form(form);
        target.takokyakuCdKaraIkkatsuFukusha();
        
        // 想定通り
        assertEquals("ERROR", levelCaptor_1.getValue());
        assertEquals("COME0003", summaryCaptor_2.getValue());
        assertEquals("営業所コード", summaryCaptor_3.getValue());
    }
        
    // takukyakuCdKaraIkkatsuFukusha_異常_他顧客コードから一括複写_18_2_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void takukyakuCdKaraIkkatsuFukusha_異常_他顧客コードから一括複写_18_2_1() {
        
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_1.capture(),summaryCaptor_2.capture(), 
                summaryCaptor_3.capture());
        
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setConEigyoshoCdTaihi("132");
        target.setMst171Form(form);
        target.takokyakuCdKaraIkkatsuFukusha();
        
        // 想定通り
        assertEquals("ERROR", levelCaptor_1.getValue());
        assertEquals("COME0003", summaryCaptor_2.getValue());
        assertEquals("顧客コード", summaryCaptor_3.getValue());
    }
    
    // ikkatsuToroku_正常_一括登録_19_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void ikkatsuToroku_正常_一括登録_19_1() {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> mapCaptor_2 = ArgumentCaptor.forClass(Map.class);    
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class); 
        ArgumentCaptor<String> keyCaptor_3 = ArgumentCaptor.forClass(String.class); 
        
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.getDBInfo(mapCaptor_2.capture(),
                keyCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_3.capture());
        
        // テスト実行
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setConHKokyakuCd("000003");
        form.setConEigyoshoCdTaihi("132");
        form.setConKokyakuCdTaihi("0000007");
        form.setConMishiyoKikanTsuki("10");
        form.setConNiukeNiokurininMode("1");
        target.setMst171Form(form);
        target.ikkatsuToroku();
        
        // 想定通り
        assertEquals("mst171_ikkatutoroku", keyCaptor_2.getValue());
        assertEquals("search_mst171", keyCaptor_3.getValue());
        assertEquals("1", mapCaptor_2.getValue().get("conNiukeNiokurininMode"));
    }
    
    // ikkatsuToroku_異常_一括登録_19_2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void ikkatsuToroku_異常_一括登録_19_2() {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);    
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class); 
        ArgumentCaptor<String> keyCaptor_3 = ArgumentCaptor.forClass(String.class); 
       
        doNothing().when(messagePropertyBean).message(keyCaptor_1.capture(), 
                keyCaptor_2.capture(), keyCaptor_3.capture());
        
        //テスト実行
        Mst171Form form = new Mst171Form();
        target.setMst171Form(form);
        target.ikkatsuToroku();
        
        // 想定通り
        assertEquals("ERROR", keyCaptor_1.getValue());
        assertEquals("COME0003", keyCaptor_2.getValue());
        assertEquals("営業所コード", keyCaptor_3.getValue());
    }
    
    // ikkatsuToroku_異常_一括登録_19_2_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void ikkatsuToroku_異常_一括登録_19_2_1() {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);    
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class); 
        ArgumentCaptor<String> keyCaptor_3 = ArgumentCaptor.forClass(String.class); 
       
        doNothing().when(messagePropertyBean).message(keyCaptor_1.capture(), 
                keyCaptor_2.capture(), keyCaptor_3.capture());
        
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setConEigyoshoCdTaihi("132");
        target.setMst171Form(form);
        target.ikkatsuToroku();
        
        // 想定通り
        assertEquals("ERROR", keyCaptor_1.getValue());
        assertEquals("COME0003", keyCaptor_2.getValue());
        assertEquals("顧客コード", keyCaptor_3.getValue());
    }
    
    // ikkatsuToroku_異常_一括登録_19_2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void ikkatsuToroku_異常_一括登録_19_2_2() {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);    
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class); 
        ArgumentCaptor<String> keyCaptor_3 = ArgumentCaptor.forClass(String.class); 
       
        doNothing().when(messagePropertyBean).message(keyCaptor_1.capture(), 
                keyCaptor_2.capture(), keyCaptor_3.capture());
        
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setConHKokyakuCd("000003");
        form.setConEigyoshoCdTaihi("132");
        form.setConKokyakuCdTaihi("0000007");
        form.setConMishiyoKikanTsukiTaihi("13");
        form.setConNiukeNiokurininMode("1");
        target.setMst171Form(form);
        target.ikkatsuToroku();
        
        // 想定通り
        assertEquals("ERROR", keyCaptor_1.getValue());
        assertEquals("COME0026", keyCaptor_2.getValue());
        assertEquals("11", keyCaptor_3.getValue());
    }
    
    // ikkatsuToroku_異常_一括登録_19_2_3
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void ikkatsuToroku_異常_一括登録_19_2_3() {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);    
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class); 
        ArgumentCaptor<String> keyCaptor_3 = ArgumentCaptor.forClass(String.class); 
       
        doNothing().when(messagePropertyBean).message(keyCaptor_1.capture(), 
                keyCaptor_2.capture(), keyCaptor_3.capture());
        
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setConHKokyakuCd("000003");
        form.setConEigyoshoCdTaihi("132");
        form.setConKokyakuCdTaihi("0000007");
        form.setConMishiyoKikanTsukiTaihi("0");
        form.setConNiukeNiokurininMode("1");
        target.setMst171Form(form);
        target.ikkatsuToroku();
        
        // 想定通り
        assertEquals("ERROR", keyCaptor_1.getValue());
        assertEquals("COME0026", keyCaptor_2.getValue());
        assertEquals("11", keyCaptor_3.getValue());
    }
        
    // ikkatsuToroku_異常_一括登録_19_3
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void ikkatsuToroku_異常_一括登録_19_3() {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> mapCaptor_2 = ArgumentCaptor.forClass(Map.class);    
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class); 
        
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0006", "顧客コード");
        when(pageCommonBean.getDBInfo(mapCaptor_2.capture(),
                keyCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_3 = ArgumentCaptor.forClass(String.class);    
        ArgumentCaptor<String> keyCaptor_4 = ArgumentCaptor.forClass(String.class); 
        ArgumentCaptor<String> keyCaptor_5 = ArgumentCaptor.forClass(String.class); 
       
        doNothing().when(messagePropertyBean).message(keyCaptor_3.capture(), 
                keyCaptor_4.capture(), keyCaptor_5.capture());
        
        // テスト実行
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setConHKokyakuCd("000003");
        form.setConEigyoshoCdTaihi("132");
        form.setConKokyakuCdTaihi("0000007");
        form.setConMishiyoKikanTsuki("10");
        form.setConNiukeNiokurininMode("1");
        target.setMst171Form(form);
        target.ikkatsuToroku();
        
        // 想定通り
        assertEquals("mst171_ikkatutoroku", keyCaptor_2.getValue());
        assertEquals("ERROR", keyCaptor_3.getValue());
        assertEquals("COME0006", keyCaptor_4.getValue());
        assertEquals("顧客コード", keyCaptor_5.getValue());
    }
    
    // torikeshiKakunin_正常取消ボタン_20_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void torikeshiKakunin_正常_取消ボタン_20_1() {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class); 

        
        doNothing().when(pageCommonBean).executeScript(keyCaptor_1.capture());
        
        //テスト実行
        Mst171Form form = new Mst171Form();
        target.setMst171Form(form);
        target.torikeshiKakunin();
        
        // 想定通り
        assertEquals("km.showConfirmDialog('mst171DialogTorikeshi')", keyCaptor_1.getValue());
    }
    
    // torikeshi_取消処理_20_2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void torikeshi_正常_取消処理_20_2() {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class); 
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class); 

        
        doNothing().when(pageCommonBean).executeScript(keyCaptor_1.capture());
        
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst171Form form = new Mst171Form();
        target.setMst171Form(form);
        target.torikeshi();
        
        form = target.getMst171Form();
        
        // 想定通り
        assertEquals(null, form.getConHKokyakuCd());
        assertEquals("search_mst171", keyCaptor_2.getValue());
         
    }
    
    // gamenHidenKakunin_正常_閉じるボタン_22_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void gamenHidenKakunin_正常_閉じるボタン_22_1() {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class); 

        
        doNothing().when(pageCommonBean).executeScript(keyCaptor_1.capture());
        
        //テスト実行
        Mst171Form form = new Mst171Form();
        target.setMst171Form(form);
        target.gamenHidenKakunin();
        
        // 想定通り
        assertEquals("km.showConfirmDialog('mst171DialogClose')", keyCaptor_1.getValue());
         
    }
    
    // gamenHiden_正常_閉じるボタン_22_2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void gamenHiden_正常_閉じるボタン_22_2() {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class); 

        
        doNothing().when(pageCommonBean).executeScript(keyCaptor_1.capture());
        
        //テスト実行
        Mst171Form form = new Mst171Form();
        target.setMst171Form(form);
        target.gamenHiden();
         
        // 想定通り
        assertEquals("PF('widFukusha').hide();", keyCaptor_1.getValue());
    }
    
    // fukusha_正常_複写ボタン_23_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void fukusha_正常_複写ボタン_23_1() {
       
        // パラメータキャプチャー
        ArgumentCaptor<Map> keyCaptor_1 = ArgumentCaptor.forClass(Map.class); 
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class); 

        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索結果一覧取得 取得件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 0; i++) {
            result.add(createRecMapForSearchResult(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.getDBInfo(keyCaptor_1.capture(), 
                keyCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setConHKokyakuCd("0000008");
        form.setConKokyakuCdTaihi("0000007");
        form.setConNiukeNiokurininMode("1");
        target.setMst171Form(form);
        target.fukusha();
         
        // 想定通り
        assertEquals("1", keyCaptor_1.getValue().get("conNiukeNiokurininMode"));
        assertEquals("mst171_fukusha", keyCaptor_2.getValue());
    }
    
    // fukusha_異常_複写ボタン_23_2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void fukusha_異常_複写ボタン_23_2() {
       
        // パラメータキャプチャー
        ArgumentCaptor<Map> keyCaptor_1 = ArgumentCaptor.forClass(Map.class); 
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class); 

        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0006", "顧客コード");
        serviceInterfaceBean.setTableName("顧客マスタ");
        when(pageCommonBean.getDBInfo(keyCaptor_1.capture(), 
                keyCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_3 = ArgumentCaptor.forClass(String.class);    
        ArgumentCaptor<String> keyCaptor_4 = ArgumentCaptor.forClass(String.class); 
        ArgumentCaptor<String> keyCaptor_5 = ArgumentCaptor.forClass(String.class); 
        ArgumentCaptor<String> keyCaptor_6 = ArgumentCaptor.forClass(String.class); 
       
        doNothing().when(messagePropertyBean).message(keyCaptor_3.capture(), 
                keyCaptor_4.capture(), keyCaptor_5.capture(), keyCaptor_6.capture());
        
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setConHKokyakuCd("0000008");
        form.setConKokyakuCdTaihi("0000007");
        form.setConNiukeNiokurininMode("1");
        target.setMst171Form(form);
        target.fukusha();
         
        // 想定通り
        assertEquals("1", keyCaptor_1.getValue().get("conNiukeNiokurininMode"));
        assertEquals("mst171_fukusha", keyCaptor_2.getValue());
        assertEquals("ERROR", keyCaptor_3.getValue());
        assertEquals("COME0006", keyCaptor_4.getValue());
        assertEquals("顧客マスタ", keyCaptor_5.getValue());
    }
    
    // fukusha_異常_複写ボタン_23_3
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void fukusha_異常_複写ボタン_23_3() {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_3 = ArgumentCaptor.forClass(String.class);    
        ArgumentCaptor<String> keyCaptor_4 = ArgumentCaptor.forClass(String.class); 
        ArgumentCaptor<String> keyCaptor_5 = ArgumentCaptor.forClass(String.class); 
       
        doNothing().when(messagePropertyBean).message(keyCaptor_3.capture(), 
                keyCaptor_4.capture(), keyCaptor_5.capture());
        
        //テスト実行
        Mst171Form form = new Mst171Form();
        target.setMst171Form(form);
        target.fukusha();
    }
    
    // fukusha_異常_複写ボタン_23_3_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void fukusha_異常_複写ボタン_23_3_1() {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_3 = ArgumentCaptor.forClass(String.class);    
        ArgumentCaptor<String> keyCaptor_4 = ArgumentCaptor.forClass(String.class); 
        ArgumentCaptor<String> keyCaptor_5 = ArgumentCaptor.forClass(String.class); 
       
        doNothing().when(messagePropertyBean).message(keyCaptor_3.capture(), 
                keyCaptor_4.capture(), keyCaptor_5.capture());
        
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setConHKokyakuCd("");
        target.setMst171Form(form);
        target.fukusha();
    }
    
    // fukusha_異常_複写ボタン_23_3_2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void fukusha_異常_複写ボタン_23_3_2() {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_3 = ArgumentCaptor.forClass(String.class);    
        ArgumentCaptor<String> keyCaptor_4 = ArgumentCaptor.forClass(String.class); 
        ArgumentCaptor<String> keyCaptor_5 = ArgumentCaptor.forClass(String.class);
       
        doNothing().when(messagePropertyBean).message(keyCaptor_3.capture(), 
                keyCaptor_4.capture(), keyCaptor_5.capture());
        
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setConHKokyakuCd("0000008");
        form.setConKokyakuCdTaihi("0000008");
        target.setMst171Form(form);
        target.fukusha();
        
        // 想定通り
        assertEquals("ERROR", keyCaptor_3.getValue());
        assertEquals("MSTE0002", keyCaptor_4.getValue());
        assertEquals("顧客コード", keyCaptor_5.getValue());
    }
    
    // fukusha_異常_複写ボタン_23_4
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void fukusha_異常_複写ボタン_23_4() {
        
         // パラメータキャプチャー
        ArgumentCaptor<Map> keyCaptor_1 = ArgumentCaptor.forClass(Map.class); 
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class); 

        doThrow(IOException.class).when(pageCommonBean).getDBInfo(keyCaptor_1.capture(),
                keyCaptor_2.capture());
        
        //テスト実行
        Mst171Form form = new Mst171Form();
        form.setConHKokyakuCd("0000008");
        form.setConKokyakuCdTaihi("0000007");
        form.setConNiukeNiokurininMode("1");
        target.setMst171Form(form);
        target.fukusha();
         
        // 想定通り
        assertEquals("1", keyCaptor_1.getValue().get("conNiukeNiokurininMode"));
        assertEquals("mst171_fukusha", keyCaptor_2.getValue());
    }
    
    // rirekiIchiran_正常_更新履歴コンテキストメニュー_24_1
    //
    // -------------------テスト条件--------------------------
    // 正常に取得された場合
    // -----------------------------------------------------
    @Test
    public void rirekiIchiran_正常_更新履歴コンテキストメニュー_24_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> titleFlgCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> searchKeyCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(rirekiSyosaiBean).searchList(titleFlgCaptor_1.capture(),
                functionCodeCaptor_2.capture(), searchKeyCaptor_3.capture());
        // テスト実行
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        Mst171Form form = new Mst171Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapForResultList(i));
        }
        form.setSelectedSearchResult(result);
        form.setConEigyoshoCdTaihi("132");
        form.setConKokyakuCdTaihi("0000007");
        form.setConNiukeNiokurininMode("1");
        form.setConHKokyakuCd("0000008");
        target.setMst171Form(form);
        target.rirekiIchiran();

        // 実施結果Outを取得
        form = target.getMst171Form();

        // 想定通りに履歴を表示する。
        assertEquals("2", titleFlgCaptor_1.getValue());
        assertEquals("MST171_SEARCH_RIREKI", functionCodeCaptor_2.getValue());
        assertEquals("1", form.getConNiukeNiokurininMode());
        assertEquals("132", searchKeyCaptor_3.getValue().get("conEigyoshoCd"));
        assertEquals("0000007", searchKeyCaptor_3.getValue().get("conKokyakuCd"));
        assertEquals("0000008", searchKeyCaptor_3.getValue().get("conHKokyakuCd"));
    }
        
    // rirekiIchiran_正常_更新履歴コンテキストメニュー_24_2
    //
    // -------------------テスト条件--------------------------
    // 正常に取得された場合
    // -----------------------------------------------------
    @Test
    public void rirekiIchiran_正常_更新履歴コンテキストメニュー_24_2() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> titleFlgCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> searchKeyCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(rirekiSyosaiBean).searchList(titleFlgCaptor_1.capture(),
                functionCodeCaptor_2.capture(), searchKeyCaptor_3.capture());
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mst171Form form = new Mst171Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapForResultList(i));
        }
        form.setSelectedSearchResult(result);
        form.setConEigyoshoCdTaihi("132");
        form.setConKokyakuCdTaihi("0000007");
        form.setConNiukeNiokurininMode("2");
        form.setConHKokyakuCd("0000008");
        target.setMst171Form(form);
        target.rirekiIchiran();

        // 実施結果Outを取得
        form = target.getMst171Form();

        // 想定通りに履歴を表示する。
        assertEquals("2", titleFlgCaptor_1.getValue());
        assertEquals("MST171_SEARCH_RIREKI", functionCodeCaptor_2.getValue());
        assertEquals("2", form.getConNiukeNiokurininMode());
        assertEquals("132", searchKeyCaptor_3.getValue().get("conEigyoshoCd"));
        assertEquals("0000007", searchKeyCaptor_3.getValue().get("conKokyakuCd"));
        assertEquals("0000008", searchKeyCaptor_3.getValue().get("conHKokyakuCd"));
    }
    
    // linkClick_正常_発行コードリンク_25_1
    //
    // -------------------テスト条件--------------------------
    // 正常に取得された場合
    // -----------------------------------------------------
    @Test
    public void linkClick_正常_発行コードリンク_25_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> titleFlgCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> searchKeyCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(rirekiSyosaiBean).searchList(titleFlgCaptor_1.capture(),
                functionCodeCaptor_2.capture(), searchKeyCaptor_3.capture());
        // テスト実行
        Mst171Form form = new Mst171Form();
        form.setConNiukeNiokurininMode("1");
        target.setMst171Form(form);
        Flash flash = new FlashKls();
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        when(flashUtil.getPageParam()).thenReturn(flash);
        String url = target.linkClick("0000008", "0000008", "Flg0");
        
        
        
        assertEquals("/contents/mst/mst172.xhtml?faces-redirect=true", url);
    }

    // searchChange_正常_補充ケース_26_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void searchChange_正常_補充ケース_26_1() throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst171Form form = new Mst171Form();
        target.setMst171Form(form);
        target.searchChange();

        // 実施結果Outを取得
        form = target.getMst171Form();

        // 想定通り
        assertEquals(false, form.isConEigyoshoCdDisabled());

    }

    // getSearchResult_正常_補充ケース_26_2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void getSearchResult_正常_補充ケース_26_2() throws IllegalAccessException, InvocationTargetException {

        List<Map<String, Object>> resultList = new ArrayList<>();
        for (int i = 0; i <= 0; i++) {
            resultList.add(createRecMapForResultList(i));
        }

        // テスト実行
        Mst171Form form = new Mst171Form();
        form.setSearchResult(resultList);
        target.setMst171Form(form);
        target.getSearchResult();

        // 実施結果Outを取得
        form = target.getMst171Form();

        // 想定通り
        assertEquals(false, form.isConEigyoshoCdDisabled());

    }
    
    // menuClick_正常_補充ケース_26_3
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_26_3 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst171Form form = new Mst171Form();
        target.setMst171Form(form);
        target.menuClick("","");

        // 実施結果Outを取得
        form = target.getMst171Form();

    }
    
    // menuClick_正常_補充ケース_26-2-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_26_3_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(1);
       
        // テスト実行
        Mst171Form form = new Mst171Form();
        target.setMst171Form(form);
        target.menuClick("","");

        // 実施結果Outを取得
        form = target.getMst171Form();

    }

    // breadClumClick_正常_補充ケース_26_4
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_26_4 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst171Form form = new Mst171Form();
        target.setMst171Form(form);
        target.breadClumClick("",0);

        // 実施結果Outを取得
        form = target.getMst171Form();

    }
    
    // breadClumClick_正常_補充ケース_26_4_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_26_4_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(0); 
        // テスト実行
        Mst171Form form = new Mst171Form();
        target.setMst171Form(form);
        target.breadClumClick("",0);

        // 実施結果Outを取得
        form = target.getMst171Form();

    }

    // logoutClick_正常_補充ケース_26_5
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void logoutClick_正常_補充ケース_26_5 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst171Form form = new Mst171Form();
        target.setMst171Form(form);
        target.logoutClick();

        // 実施結果Outを取得
        form = target.getMst171Form();

    }
    
    // fukushaAtoSearch_正常_補充ケース_26_6
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void fukushaAtoSearch_正常_補充ケース_26_6 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        // テスト実行
        Mst171Form form = new Mst171Form();
        target.setMst171Form(form);
        target.fukushaAtoSearch();

        assertEquals("search_mst171", keyCaptor_2.getValue());

    }
    
    // fukushaAtoSearch_正常_補充ケース_26_6
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void searchCheck_正常_補充ケース_26_7 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);     
        doNothing().when(pageCommonBean).executeScript(keyCaptor_2.capture());
        // テスト実行
        Mst171Form form = new Mst171Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("132");
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("0000007");
        form.setConMishiyoKikanTsuki("10");
        form.setConKokyakuCd(conKokyakuCd);
        form.setConEigyoshoCd(conEigyoshoCd);
        target.setMst171Form(form);
        boolean flg = target.searchCheck();
        
        assertEquals(true, flg);

    }
    
    // fukushaAtoSearch_正常_補充ケース_26_6
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void searchCheck_正常_補充ケース_26_8 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);     
        doNothing().when(pageCommonBean).executeScript(keyCaptor_2.capture());
        // テスト実行
        Mst171Form form = new Mst171Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("132");
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("0000007");
        form.setConHKokyakuCdTaihi("0000003");
        form.setConMishiyoKikanTsuki("10");
        form.setConKokyakuCd(conKokyakuCd);
        form.setConEigyoshoCd(conEigyoshoCd);
        target.setMst171Form(form);
        boolean flg = target.searchCheck();

        assertEquals("km.showConfirmDialog('mst171DialogSearch')", keyCaptor_2.getValue());
        assertEquals(false, flg);

    }
    
    // fukushaAtoSearch_正常_補充ケース_26_6
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void searchCheck_正常_補充ケース_26_9 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst171Form form = new Mst171Form();
        target.getKokyakuCdList();

    }

    private Map<String, String> createRecMapForSearchResult(int i) {
        Map recMap = new HashMap();
        // 荷受人発行コード
        recMap.put("listNiukeninHakkoCd", "listNiukeninHakkoCd" + i);
        // 荷受人名称
        recMap.put("listNiukeninMei", "listNiukeninMei" + i);
        // カナ名称
        recMap.put("listKanaMei", "listKanaMei" + i);
        // 荷送人発行コード
        recMap.put("listNiokurininHakkoCd", "listNiokurininHakkoCd" + i);
        // 荷送人名称
        recMap.put("listNiokurininMei", "listNiokurininMei" + i);
        // 荷送人カナ名称
        recMap.put("listKanaMei", "listKanaMei" + i);
        // 住所
        recMap.put("listJusho", "listJusho" + i);
        // 旧住所
        recMap.put("listKyuJusho", "listKyuJusho" + i);
        // 電話番号
        recMap.put("listTel", "listTel" + i);
        // 検索キー
        recMap.put("listKensakuKey", "listKensakuKey" + i);
        // 記事有無
        recMap.put("listKijiUmu", "listKijiUmu" + i);
        // 最終使用日
        recMap.put("listSaishuShiyobi", "listSaishuShiyobi" + i);
        // エラー内容
        recMap.put("listErrorNaiyo", "使用不可住所");
        // 顧客コード
        recMap.put("listKokyakuCd", "listKokyakuCd" + i);
        // 自営業所フラグ
        recMap.put("listJieigyoshoFlg", "listJieigyoshoFlg" + i);
        // データバージョン
        recMap.put("listDataVersion", "listDataVersion" + i);
        // 更新ユーザ
        recMap.put("listKoshiUser", "listKoshiUser" + i);
        // 更新カウンタ
        recMap.put("listKoshinCounter", "listKoshinCounter" + i);
        return recMap;
    }

    private Map<String, Object> createRecMapForResultList(int i) {
        Map recMap = new HashMap();
        // 荷受人発行コード
        recMap.put("listNiukeninHakkoCd", "listNiukeninHakkoCd" + i);
        // 荷受人名称
        recMap.put("listNiukeninMei", "listNiukeninMei" + i);
        // カナ名称
        recMap.put("listKanaMei", "listKanaMei" + i);
        // 荷送人発行コード
        recMap.put("listNiokurininHakkoCd", "listNiokurininHakkoCd" + i);
        // 荷送人名称
        recMap.put("listNiokurininMei", "listNiokurininMei" + i);
        // 荷送人カナ名称
        recMap.put("listKanaMei", "listKanaMei" + i);
        // 住所
        recMap.put("listJusho", "listJusho" + i);
        // 旧住所
        recMap.put("listKyuJusho", "listKyuJusho" + i);
        // 電話番号
        recMap.put("listTel", "listTel" + i);
        // 検索キー
        recMap.put("listKensakuKey", "listKensakuKey" + i);
        // 記事有無
        recMap.put("listKijiUmu", "listKijiUmu" + i);
        // 最終使用日
        recMap.put("listSaishuShiyobi", "listSaishuShiyobi" + i);
        // エラー内容
        recMap.put("listErrorNaiyo", "listErrorNaiyo" + i);
        // 顧客コード
        recMap.put("listKokyakuCd", "listKokyakuCd" + i);
        // 自営業所フラグ
        recMap.put("listJieigyoshoFlg", "listJieigyoshoFlg" + i);
        // データバージョン
        recMap.put("listDataVersion", "listDataVersion" + i);
        // 更新ユーザ
        recMap.put("listKoshiUser", "listKoshiUser" + i);
        // 更新カウンタ
        recMap.put("listKoshinCounter", "listKoshinCounter" + i);
        return recMap;
    }

    private void assertForRecList_2_1(Mst171Form form) {
        int i = 0;
        assertEquals(1, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            // 荷受人発行コード 
            assertEquals("listNiukeninHakkoCd" + i, rec.get("listNiukeninHakkoCd"));
            // 荷受人名称
            assertEquals("listNiukeninMei" + i, rec.get("listNiukeninMei"));
            // カナ名称
            assertEquals("listKanaMei" + i, rec.get("listKanaMei"));
            // 荷送人発行コード
            assertEquals("listNiokurininHakkoCd" + i, rec.get("listNiokurininHakkoCd"));
            // 荷送人名称
            assertEquals("listNiokurininMei" + i, rec.get("listNiokurininMei"));
            // 荷送人カナ名称
            assertEquals("listKanaMei" + i, rec.get("listKanaMei"));
            // 住所
            assertEquals("listJusho" + i, rec.get("listJusho"));
            // 旧住所
            assertEquals("listKyuJusho" + i, rec.get("listKyuJusho"));
            // 電話番号
            assertEquals("listTel" + i, rec.get("listTel"));
            // 検索キー
            assertEquals("listKensakuKey" + i, rec.get("listKensakuKey"));
            // 記事有無
            assertEquals("listKijiUmu" + i, rec.get("listKijiUmu"));
            // 最終使用日
            assertEquals("listSaishuShiyobi" + i, rec.get("listSaishuShiyobi"));
            // エラー内容
            assertEquals("使用不可住所", rec.get("listErrorNaiyo"));
            // 顧客コード
            assertEquals("listKokyakuCd" + i, rec.get("listKokyakuCd"));
            // 自営業所フラグ
            assertEquals("listJieigyoshoFlg" + i, rec.get("listJieigyoshoFlg"));
            // データバージョン
            // 更新ユーザ
            assertEquals("listKoshiUser" + i, rec.get("listKoshiUser"));
            // 更新カウンタ
            assertEquals("listKoshinCounter" + i, rec.get("listKoshinCounter"));
            i++;
        }
    }

}