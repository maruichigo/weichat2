package jp.co.kintetsuls.beans.mst;

import java.io.IOException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.forms.mst.Mst111Form;
import jp.co.kintetsuls.utils.FlashUtil;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * ルートマスタ画面
 *
 * @author 黄義輝 (MBP)
 * @version 2019/03/25 新規作成
 */
public class Mst111BeanTest {

    // テストTarget
    @InjectMocks
    private Mst111Bean target;

    // Mockitoオブジェクト
    @Mock
    private FileBean fileBean;
    @Mock
    private AutoCompleteViewBean autoCompleteViewBean;
    @Mock
    private AutoCompleteBean autoCompleteBean;
    @Mock
    private MasterInfoBean masterInfo;
    @Mock
    private MessagePropertyBean messageProperty;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosai;
    @Mock
    private SearchHelpBean searchHelpBean;
    @Mock
    private AuthorityConfBean authConfBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private MessagePropertyBean messagePropertyBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosaiBean;
    @Mock
    private ListCheckBean listCheckBean;
    @Mock
    private FlashUtil flashUtil;
    
    public Mst111BeanTest() {
    }

    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() {
    }

    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[not null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst111Form mst111Form = new Mst111Form();
        
        //前画面情報[not null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst111Form);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst111Form form = new Mst111Form();
        target.setMst111Form(form);
        // 戻ってきた場合、再検索を実施する。
        target.init("", "MST031_SCREEN", true);

        //実施結果Outを取得
        form = target.getMst111Form();
        String url = target.getUrl();
        BreadCrumbBean breadBean = target.getBreadBean();
        AutoCompleteViewBean autoCompleteViewBean = target.getAutoCompleteViewBean();
        AuthorityConfBean authorityConfBean  = target.getAuthorityConfBean();
        FileBean fileBean = target.getFileBean();
        MessagePropertyBean messagePropertyBean = target.getMessagePropertyBean();
        PageCommonBean pageCommonBean = target.getPageCommonBean();
        SearchHelpBean searchHelpBean = target.getSearchHelpBean();
        RirekiSyosaiBean rirekiSyosaiBean = target.getRirekiSyosaiBean();
        ListCheckBean listCheckBean = target.getListCheckBean();
        Map<String, Object> rirekiSearchKey = target.getRirekiSearchKey();
        List<MessageModuleBean> msgList = target.getMsgList();
        target.setUrl(url);
        target.setBreadBean(breadBean);
        target.setAutoCompleteViewBean(autoCompleteViewBean);
        target.setAuthorityConfBean(authorityConfBean);
        target.setFileBean(fileBean);
        target.setMessagePropertyBean(messagePropertyBean);
        target.setPageCommonBean(pageCommonBean);
        target.setSearchHelpBean(searchHelpBean);
        target.setRirekiSyosaiBean(rirekiSyosaiBean);
        target.setListCheckBean(listCheckBean);
        target.setRirekiSearchKey(rirekiSearchKey);
        target.setMsgList(msgList);
        
        // 実行時に渡すパラメータの検証
        assertEquals("mst111Form",keyCaptor_1.getValue());
        //想定通りに再検索を実施する。
        assertEquals("search_mst111",keyCaptor_2.getValue());
    }

    // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[発地コード = '101', 着地コード = '102', デフォルトルート検索 = null,削除済のみ検索 = null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2() throws IllegalAccessException, InvocationTargetException,
            InstantiationException {

        // Mockitoオブジェクトの予想return値設定
        Mst111Form mst111Form = new Mst111Form();
        // 前回検索パラメータ[発地コード = '101', 着地コード = '102', デフォルトルート検索 = null,削除済のみ検索 = null]
        AutoCompOptionBean conHatsuchi = new AutoCompOptionBean();
        conHatsuchi.setValue("101");
        AutoCompOptionBean conChakuchi = new AutoCompOptionBean();
        conChakuchi.setValue("102");
        mst111Form.setConHatsuchi(conHatsuchi);
        mst111Form.setConChakuchi(conChakuchi);
        mst111Form.setConDefaultRouteKensaku(null);
        mst111Form.setConSakujoSumiNomi(null);
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        // 前画面パラメータ[世代検索条件[02],削除済のみ検索 = null]
        flash.put("mst111Form", mst111Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);        

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst111Form form = new Mst111Form();
        target.setMst111Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst111Form();

        //想定通りに再検索を実施する。
        assertEquals("search_mst111",keyCaptor_2.getValue());
        assertEquals("101",form.getConHatsuchi().getValue());
        assertEquals("102",form.getConChakuchi().getValue());
    }

    // init_正常_初期処理_1-2_1
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[デフォルトルート検索 = 1, 削除済のみ検索 = 1]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2_1() throws IllegalAccessException, InvocationTargetException,
            InstantiationException {

        // Mockitoオブジェクトの予想return値設定
        Mst111Form mst111Form = new Mst111Form();
        // 前回検索パラメータ[デフォルトルート検索 = 1, 削除済のみ検索 = 1]
        String conDefaultRouteKensaku[] = new String[5];
        conDefaultRouteKensaku[0] = "1";
        mst111Form.setConDefaultRouteKensaku(conDefaultRouteKensaku);
        String conSakujoSumiNomi[] = new String[5];
        conSakujoSumiNomi[0] = "1";
        mst111Form.setConSakujoSumiNomi(conSakujoSumiNomi);
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        // 前回検索パラメータ[世代検索条件[02],削除済のみ検索 = null]
        flash.put("mst111Form", null);
        when(pageCommonBean.getPageParam()).thenReturn(flash);        

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst111Form form = new Mst111Form();
        target.setMst111Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst111Form();

        //想定通りに再検索を実施する。
    }    
    
    // init_正常_初期処理_1-3
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        //前画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(null);

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        target.setMst111Form(mst111Form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst111Form",keyCaptor_1.getValue());
        //想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null,mst111Form.getSearchResult());
    }

    // init_正常_初期処理_1-3_1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_異常_初期処理_1_3_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        //前画面情報[null]
        doThrow(IllegalAccessException.class).when(pageCommonBean).getPageInfo(keyCaptor_1.capture());

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        target.setMst111Form(mst111Form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst111Form",keyCaptor_1.getValue());
        // 想定通りにルートマスタ一覧を表示されること
        assertEquals(null,mst111Form.getSearchResult());
    }

    // search_正常_検索処理_2-1
    //
    // -------------------テスト条件--------------------------
    // ルート検索結果一覧取得
    // 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // ルートマスタ検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 0; i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        target.setMst111Form(mst111Form);
        target.search();

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        //想定通りにルート名マスタ一覧を表示されること
        assertForRecList_2_1(mst111Form);
    }    

    // search_正常_検索処理_2-2
    //
    // -------------------テスト条件--------------------------
    // ルート検索結果一覧取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //ルート検索結果一覧取得 取得件数 = 2
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 1; i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        target.setMst111Form(mst111Form);
        target.search();

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null,paramsCaptor_1.getValue().get("conHatsuchi"));
        assertEquals(null,paramsCaptor_1.getValue().get("conChakuchi"));
        assertEquals("mst111-get-route-detail",functionCodeCaptor_2.getValue());
        //想定通りにルート名マスタ一覧を表示されること
        assertForRecList_2_2(mst111Form);
    }

    // search_正常_検索処理_2-3
    //
    // -------------------テスト条件--------------------------
    // ルートマスタ検索結果一覧  取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // ルートマスタ検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 0; i++) {
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        AutoCompOptionBean conHatsuchi = new AutoCompOptionBean();
        conHatsuchi.setValue("101");
        AutoCompOptionBean conChakuchi = new AutoCompOptionBean();
        conChakuchi.setValue("102");
        mst111Form.setConHatsuchi(conHatsuchi);
        mst111Form.setConChakuchi(conChakuchi);
        mst111Form.setConDefaultRouteKensaku(null);
        String[] conSakujoSumiNomi = new String[]{"1"};
        mst111Form.setConSakujoSumiNomi(conSakujoSumiNomi);

        target.setMst111Form(mst111Form);
        target.search();

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        // 実行時に渡すパラメータの検証
        assertEquals("101", paramsCaptor_1.getValue().get("conHatsuchi"));
        assertEquals("102", paramsCaptor_1.getValue().get("conChakuchi"));
        assertEquals("1", mst111Form.getConSakujoSumiNomi()[0]);
        assertEquals("mst111-get-route-detail", functionCodeCaptor_2.getValue());
        //想定通りにルートマスタ一覧を表示されること
        assertForRecList_2_1(mst111Form);
    }    

    // search_正常_検索処理_2-4
    //
    // -------------------テスト条件--------------------------
    // ルート検索結果一覧  取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // ルート検索結果一覧取得 取得件数 = 2
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=1;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        AutoCompOptionBean conHatsuchi = new AutoCompOptionBean();
        conHatsuchi.setValue("101");
        AutoCompOptionBean conChakuchi = new AutoCompOptionBean();
        conChakuchi.setValue("102");
        mst111Form.setConHatsuchi(conHatsuchi);
        mst111Form.setConChakuchi(conChakuchi);
        mst111Form.setConDefaultRouteKensaku(null);
        mst111Form.setConSakujoSumiNomi(null);
        target.setMst111Form(mst111Form);
        target.search();

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        // 実行時に渡すパラメータの検証
        assertEquals("101", paramsCaptor_1.getValue().get("conHatsuchi"));
        assertEquals("102", paramsCaptor_1.getValue().get("conChakuchi"));
        assertEquals("mst111-get-route-detail", functionCodeCaptor_2.getValue());
        //想定通りにルートマスタ一覧を表示されること
        assertForRecList_2_2(mst111Form);
    }

    // search_異常_検索処理_2-5
    //
    // -------------------テスト条件--------------------------
    // ルート検索結果一覧取得 取得件数 = 0
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_5 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //ルート検索結果一覧取得 取得件数 = 0
        List<Map<String, String>> result = new ArrayList<>();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        doThrow(IOException.class).when(pageCommonBean).getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture());

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        target.setMst111Form(mst111Form);
        target.search();

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst111-get-route-detail",functionCodeCaptor_2.getValue());
        //想定通りに・一覧は表示しない（ヘッダーのみ） 
        //想定通りに ・ファンクションボタンは表示（検索前と同じ） 
    }

    // getRecordCount_正常_件数取得処理_2-6
    //
    // -------------------テスト条件--------------------------
    // ルート検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_6 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //ルート検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        target.setMst111Form(mst111Form);
        target.getRecordCount(false);

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null, paramsCaptor_1.getValue().get("conHatsuchi"));
        assertEquals(null, paramsCaptor_1.getValue().get("conChakuchi"));
        assertEquals("mst111-get-route-kensu",functionCodeCaptor_2.getValue());
        //想定通りに正常にCountを実施されること
    }

    // getRecordCount_正常_件数取得処理_2-6_1
    //
    // -------------------テスト条件--------------------------
    // ルート検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_6_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //ルート検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        AutoCompOptionBean conHatsuchi = new AutoCompOptionBean();
        conHatsuchi.setValue("101");
        AutoCompOptionBean conChakuchi = new AutoCompOptionBean();
        conChakuchi.setValue("102");
        mst111Form.setConHatsuchi(conHatsuchi);
        mst111Form.setConChakuchi(conChakuchi);
        mst111Form.setConDefaultRouteKensaku(null);
        mst111Form.setConSakujoSumiNomi(null);
        when(pageCommonBean.getPageInfo("mst111Form")).thenReturn(mst111Form);
        target.setMst111Form(mst111Form);
        long count = target.getRecordCount(true);

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        // 実行時に渡すパラメータの検証
        assertEquals("101", paramsCaptor_1.getValue().get("conHatsuchi"));
        assertEquals("102", paramsCaptor_1.getValue().get("conChakuchi"));
        assertEquals("mst111-get-route-kensu",functionCodeCaptor_2.getValue());
        //想定通りに正常にCountを実施されること
        assertEquals(2, count);
    }    

    // getRecordCount_正常_件数取得処理_2_6_2
    //
    // -------------------テスト条件--------------------------
    // ルート検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_6_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //ルート検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        AutoCompOptionBean conHatsuchi = new AutoCompOptionBean();
        conHatsuchi.setValue("101");
        AutoCompOptionBean conChakuchi = new AutoCompOptionBean();
        conChakuchi.setValue("102");
        mst111Form.setConHatsuchi(conHatsuchi);
        mst111Form.setConChakuchi(conChakuchi);
        mst111Form.setConDefaultRouteKensaku(null);
        mst111Form.setConSakujoSumiNomi(null);
        target.setMst111Form(mst111Form);
        target.getRecordCount(false);

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        // 実行時に渡すパラメータの検証
        assertEquals("101", paramsCaptor_1.getValue().get("conHatsuchi"));
        assertEquals("102", paramsCaptor_1.getValue().get("conChakuchi"));
        assertEquals("mst111-get-route-kensu",functionCodeCaptor_2.getValue());
        //想定通りに正常にCountを実施されること
    } 

    // clear_正常_クリア処理_3-1
    //
    // -------------------テスト条件--------------------------
    // 検索条件と検索結果がある
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        // 検索条件と検索結果がある
        AutoCompOptionBean conHatsuchi = new AutoCompOptionBean();
        conHatsuchi.setValue("101");
        AutoCompOptionBean conChakuchi = new AutoCompOptionBean();
        conChakuchi.setValue("102");
        mst111Form.setConHatsuchi(conHatsuchi);
        mst111Form.setConChakuchi(conChakuchi);
        mst111Form.setConDefaultRouteKensaku(null);
        mst111Form.setConSakujoSumiNomi(null);
        target.setMst111Form(mst111Form);
        target.clear();

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        //想定通りに正常にClearを実施されること
        assertEquals(null, mst111Form.getConHatsuchi());
        assertEquals(null, mst111Form.getConChakuchi());
        // 想定通りに正常にClearを実施されること
        
    }

    // clear_正常_クリア処理_3-2
    //
    // -------------------テスト条件--------------------------
    // 検索条件がある、検索結果がない
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        target.setMst111Form(mst111Form);
        target.clear();

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        //想定通りに正常にClearを実施されること
        assertEquals(null, mst111Form.getConHatsuchi());
        assertEquals(null, mst111Form.getConChakuchi());
        // 想定通りに正常にClearを実施されること

    }

    // getHeader_正常_ダウンロード_4-1
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void getHeader_正常_ダウンロード_4_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        target.setMst111Form(mst111Form);
        List<CSVDto> dto = target.getHeader();

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        // 実行時に渡すパラメータの検証
        // 想定通りに正常にCVSのHeaderを設定されること
        assertEquals(null, mst111Form.getConHatsuchi());
        assertEquals(null, mst111Form.getConChakuchi());
        assertEquals("発地コード",dto.get(0).getTitle());
        assertEquals("listHatsuchiCd",dto.get(0).getName());
        assertEquals("発地名称",dto.get(1).getTitle());
        assertEquals("listHatsuchiMeisho",dto.get(1).getName());
    }

    // beforeDown_正常_ダウンロード_4-2
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=2件
    // -----------------------------------------------------
    @Test
    public void beforeDown_正常_ダウンロード_4_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        target.setMst111Form(mst111Form);
        try {
            target.beforeDown("testComment");
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(Mst111BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null, mst111Form.getConHatsuchi());
        assertEquals(null, mst111Form.getConChakuchi());
        // 想定通りに正常にダウンロード理由を記録すること
    }    
    
    // update_異常_更新処理_新規登録_11-1
    //
    // -------------------テスト条件--------------------------
    // 発地・着地単位で、優先順位が重複する[MSTE0074]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_新規登録_11_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 発地・着地単位で、優先順位が重複する[MSTE0074]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0074", null);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        mst111Form.setSelectedSearchResult(result);
        target.setMst111Form(mst111Form);
        target.update();

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);

        assertEquals("listHatsuchiCd0", paramsCaptor_1_Param.get("listHatsuchiCd"));
        assertEquals("listHatsuchiMeisho0", paramsCaptor_1_Param.get("listHatsuchiMeisho"));
        assertEquals("listChakuchiCd0", paramsCaptor_1_Param.get("listChakuchiCd"));
        assertEquals("listChakuchiMeisho0", paramsCaptor_1_Param.get("listChakuchiMeisho"));
        assertEquals("listYusenjuni0", paramsCaptor_1_Param.get("listYusenjuni"));
        assertEquals("listKeiyuchi1Cd0", paramsCaptor_1_Param.get("listKeiyuchi1Cd"));
        assertEquals("listKeiyuchi1Meisho0", paramsCaptor_1_Param.get("listKeiyuchi1Meisho"));
        assertEquals("listKeiyuchi2Cd0", paramsCaptor_1_Param.get("listKeiyuchi2Cd"));
        assertEquals("listKeiyuchi2Meisho0", paramsCaptor_1_Param.get("listKeiyuchi2Meisho"));
        assertEquals("listKeiyuchi3Cd0", paramsCaptor_1_Param.get("listKeiyuchi3Cd"));
        assertEquals("listKeiyuchi3Meisho0", paramsCaptor_1_Param.get("listKeiyuchi3Meisho"));
        assertEquals("listRouteMei0", paramsCaptor_1_Param.get("listRouteMei"));
        assertEquals("listRouteEdaban0", paramsCaptor_1_Param.get("listRouteEdaban"));
        assertEquals("listRouteDataVersion0", paramsCaptor_1_Param.get("listRouteDataVersion"));
        assertEquals("listKoshinCounter0", paramsCaptor_1_Param.get("listKoshinCounter"));
        assertEquals("komFromKyotenCd0", paramsCaptor_1_Param.get("komFromKyotenCd"));
        assertEquals("komToKyotenCd0", paramsCaptor_1_Param.get("komToKyotenCd"));

        assertEquals("mst111-insert-update-check",functionCodeCaptor_2.getValue());
        // 想定通りにエラーが発生。（メッセージID：MSTE0074）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("MSTE0074",summaryCaptor_4.getValue());
    }

    // update_正常_更新処理_新規登録_11-2
    //
    // -------------------テスト条件--------------------------
    // 発地・着地単位で、優先順位が重複していない
    // -----------------------------------------------------
    @Test
    public void update_正常_更新処理_新規登録_11_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 発地・着地単位で、優先順位が重複していない
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //ルート検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++){
            result.add(createRecMapFor_11_1(i));
        }        
        mst111Form.setSelectedSearchResult(result);
        target.setMst111Form(mst111Form);
        target.update();
        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);

        assertEquals("listHatsuchiCd0", paramsCaptor_1_Param.get("listHatsuchiCd"));
        assertEquals("listHatsuchiMeisho0", paramsCaptor_1_Param.get("listHatsuchiMeisho"));
        assertEquals("listChakuchiCd0", paramsCaptor_1_Param.get("listChakuchiCd"));
        assertEquals("listChakuchiMeisho0", paramsCaptor_1_Param.get("listChakuchiMeisho"));
        assertEquals("listYusenjuni0", paramsCaptor_1_Param.get("listYusenjuni"));
        assertEquals("listKeiyuchi1Cd0", paramsCaptor_1_Param.get("listKeiyuchi1Cd"));
        assertEquals("listKeiyuchi1Meisho0", paramsCaptor_1_Param.get("listKeiyuchi1Meisho"));
        assertEquals("listKeiyuchi2Cd0", paramsCaptor_1_Param.get("listKeiyuchi2Cd"));
        assertEquals("listKeiyuchi2Meisho0", paramsCaptor_1_Param.get("listKeiyuchi2Meisho"));
        assertEquals("listKeiyuchi3Cd0", paramsCaptor_1_Param.get("listKeiyuchi3Cd"));
        assertEquals("listKeiyuchi3Meisho0", paramsCaptor_1_Param.get("listKeiyuchi3Meisho"));
        assertEquals("listRouteMei0", paramsCaptor_1_Param.get("listRouteMei"));
        assertEquals("listRouteEdaban0", paramsCaptor_1_Param.get("listRouteEdaban"));
        assertEquals("listRouteDataVersion0", paramsCaptor_1_Param.get("listRouteDataVersion"));
        assertEquals("listKoshinCounter0", paramsCaptor_1_Param.get("listKoshinCounter"));
        assertEquals("komFromKyotenCd0", paramsCaptor_1_Param.get("komFromKyotenCd"));
        assertEquals("komToKyotenCd0", paramsCaptor_1_Param.get("komToKyotenCd"));

        // 想定通りに正常終了メッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0011",summaryCaptor_4.getValue());
        assertEquals("更新",detailCaptor_5.getValue());
    }    

    // update_異常_更新処理_新規登録_11-3
    //
    // -------------------テスト条件--------------------------
    // 発地・着地・経由地が全て重複する[MSTE0075]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_新規登録_11_3 () throws IllegalAccessException, InvocationTargetException {

       // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 発地・着地・経由地が全て重複する[MSTE0075]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0075", null);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture(),tableNameCaptor_6
                        .capture());

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i <= 1; i++){
            result.add(createRecMapFor_11_1(i));
        }
        mst111Form.setSelectedSearchResult(result);
        target.setMst111Form(mst111Form);
        target.update();

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listHatsuchiCd0", paramsCaptor_1_Param.get("listHatsuchiCd"));
        assertEquals("listHatsuchiMeisho0", paramsCaptor_1_Param.get("listHatsuchiMeisho"));
        assertEquals("listChakuchiCd0", paramsCaptor_1_Param.get("listChakuchiCd"));
        assertEquals("listChakuchiMeisho0", paramsCaptor_1_Param.get("listChakuchiMeisho"));
        assertEquals("listYusenjuni0", paramsCaptor_1_Param.get("listYusenjuni"));
        assertEquals("listKeiyuchi1Cd0", paramsCaptor_1_Param.get("listKeiyuchi1Cd"));
        assertEquals("listKeiyuchi1Meisho0", paramsCaptor_1_Param.get("listKeiyuchi1Meisho"));
        assertEquals("listKeiyuchi2Cd0", paramsCaptor_1_Param.get("listKeiyuchi2Cd"));
        assertEquals("listKeiyuchi2Meisho0", paramsCaptor_1_Param.get("listKeiyuchi2Meisho"));
        assertEquals("listKeiyuchi3Cd0", paramsCaptor_1_Param.get("listKeiyuchi3Cd"));
        assertEquals("listKeiyuchi3Meisho0", paramsCaptor_1_Param.get("listKeiyuchi3Meisho"));
        assertEquals("listRouteMei0", paramsCaptor_1_Param.get("listRouteMei"));
        assertEquals("listRouteEdaban0", paramsCaptor_1_Param.get("listRouteEdaban"));
        assertEquals("listRouteDataVersion0", paramsCaptor_1_Param.get("listRouteDataVersion"));
        assertEquals("listKoshinCounter0", paramsCaptor_1_Param.get("listKoshinCounter"));
        assertEquals("komFromKyotenCd0", paramsCaptor_1_Param.get("komFromKyotenCd"));
        assertEquals("komToKyotenCd0", paramsCaptor_1_Param.get("komToKyotenCd"));

        // 想定通りにエラーが発生。（メッセージID：MSTE0075）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("MSTE0075",summaryCaptor_4.getValue());
    }    
    
    // update_異常_更新処理_更新登録_11-4
    //
    // -------------------テスト条件--------------------------
    // 発地→経由地、経由地→次の経由地、経由地→着地のルートが拠点間卸値マスタに存在しない[MSTE0076]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_11_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 発地→経由地、経由地→次の経由地、経由地→着地のルートが拠点間卸値マスタに存在しない[MSTE0076]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0076", null);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++){
            result.add(createRecMapFor_11_2(i));
        }
        mst111Form.setSelectedSearchResult(result);
        target.setMst111Form(mst111Form);
        target.update();

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listHatsuchiCd0", paramsCaptor_1_Param.get("listHatsuchiCd"));
        assertEquals("listHatsuchiMeisho0", paramsCaptor_1_Param.get("listHatsuchiMeisho"));
        assertEquals("listChakuchiCd0", paramsCaptor_1_Param.get("listChakuchiCd"));
        assertEquals("listChakuchiMeisho0", paramsCaptor_1_Param.get("listChakuchiMeisho"));
        assertEquals("listYusenjuni0", paramsCaptor_1_Param.get("listYusenjuni"));
        assertEquals("listKeiyuchi1Cd0", paramsCaptor_1_Param.get("listKeiyuchi1Cd"));
        assertEquals("listKeiyuchi1Meisho0", paramsCaptor_1_Param.get("listKeiyuchi1Meisho"));
        assertEquals("listKeiyuchi2Cd0", paramsCaptor_1_Param.get("listKeiyuchi2Cd"));
        assertEquals("listKeiyuchi2Meisho0", paramsCaptor_1_Param.get("listKeiyuchi2Meisho"));
        assertEquals("listKeiyuchi3Cd0", paramsCaptor_1_Param.get("listKeiyuchi3Cd"));
        assertEquals("listKeiyuchi3Meisho0", paramsCaptor_1_Param.get("listKeiyuchi3Meisho"));
        assertEquals("listRouteMei0", paramsCaptor_1_Param.get("listRouteMei"));
        assertEquals("listRouteEdaban0", paramsCaptor_1_Param.get("listRouteEdaban"));
        assertEquals("listRouteDataVersion0", paramsCaptor_1_Param.get("listRouteDataVersion"));
        assertEquals("listKoshinCounter0", paramsCaptor_1_Param.get("listKoshinCounter"));
        assertEquals("komFromKyotenCd0", paramsCaptor_1_Param.get("komFromKyotenCd"));
        assertEquals("komToKyotenCd0", paramsCaptor_1_Param.get("komToKyotenCd"));
        // 想定通りにエラーが発生。（メッセージID：MSTE0076
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("MSTE0076",summaryCaptor_4.getValue());
}    

    // update_正常_更新処理_更新登録_11-5
    //
    // -------------------テスト条件--------------------------
    // 発地→経由地、経由地→次の経由地、経由地→着地のルートが拠点間卸値マスタに存在する
    // -----------------------------------------------------
    @Test
    public void update_正常_更新処理_更新登録_11_5 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 発地→経由地、経由地→次の経由地、経由地→着地のルートが拠点間卸値マスタに存在する
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4
                .capture(),detailCaptor_5.capture());        

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //ルート検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }        
        mst111Form.setSelectedSearchResult(result);
        target.setMst111Form(mst111Form);
        target.update();
        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listHatsuchiCd0", paramsCaptor_1_Param.get("listHatsuchiCd"));
        assertEquals("listHatsuchiMeisho0", paramsCaptor_1_Param.get("listHatsuchiMeisho"));
        assertEquals("listChakuchiCd0", paramsCaptor_1_Param.get("listChakuchiCd"));
        assertEquals("listChakuchiMeisho0", paramsCaptor_1_Param.get("listChakuchiMeisho"));
        assertEquals("listYusenjuni0", paramsCaptor_1_Param.get("listYusenjuni"));
        assertEquals("listKeiyuchi1Cd0", paramsCaptor_1_Param.get("listKeiyuchi1Cd"));
        assertEquals("listKeiyuchi1Meisho0", paramsCaptor_1_Param.get("listKeiyuchi1Meisho"));
        assertEquals("listKeiyuchi2Cd0", paramsCaptor_1_Param.get("listKeiyuchi2Cd"));
        assertEquals("listKeiyuchi2Meisho0", paramsCaptor_1_Param.get("listKeiyuchi2Meisho"));
        assertEquals("listKeiyuchi3Cd0", paramsCaptor_1_Param.get("listKeiyuchi3Cd"));
        assertEquals("listKeiyuchi3Meisho0", paramsCaptor_1_Param.get("listKeiyuchi3Meisho"));
        assertEquals("listRouteMei0", paramsCaptor_1_Param.get("listRouteMei"));
        assertEquals("listRouteEdaban0", paramsCaptor_1_Param.get("listRouteEdaban"));
        assertEquals("listRouteDataVersion0", paramsCaptor_1_Param.get("listRouteDataVersion"));
        assertEquals("listKoshinCounter0", paramsCaptor_1_Param.get("listKoshinCounter"));
        assertEquals("komFromKyotenCd0", paramsCaptor_1_Param.get("komFromKyotenCd"));
        assertEquals("komToKyotenCd0", paramsCaptor_1_Param.get("komToKyotenCd"));
        // 想定通りに正常終了メッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0011",summaryCaptor_4.getValue());
        assertEquals("更新",detailCaptor_5.getValue());

    }

    // update_異常_更新処理_更新登録_11-6
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_11_6 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        //行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        mst111Form.setSelectedSearchResult(result);
        target.setMst111Form(mst111Form);
        target.update();

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        // 想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0029",summaryCaptor_2.getValue());
    }

    // update_異常_更新処理_更新登録_11-7_1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_11_6_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        target.setMst111Form(mst111Form);
        target.update();

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        //想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0029",summaryCaptor_2.getValue());
    }    

    // update_正常_更新処理_更新登録_11-8
    //
    // -------------------テスト条件--------------------------
    // 一覧の単項目チェックメッセージリスト　= 0
    // -----------------------------------------------------
    @Test
    public void update_正常_更新処理_更新登録_11_7 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Boolean> datasCaptor_3 = ArgumentCaptor.forClass(Boolean.class);
        ArgumentCaptor<List> checksCaptor_4 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<List> checksCaptor_5 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean2 = new MessageModuleBean();
        List<MessageModuleBean> msgList = new ArrayList<>();
        msgList.add(messageModuleBean2);

        when(listCheckBean.check(checksCaptor_4.capture(), checksCaptor_5.capture(), datasCaptor_3.capture()))
                .thenReturn(msgList);

        //テスト実行
        Mst111Form form = new Mst111Form();
        //行選択チェック選択 = 1
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst111Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst111Form();

    }

    // delRows_正常_ルートマスタ削除処理_12-1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 1
    // 発地、着地の組み合わせが、ルートマスタに存在している
    // -----------------------------------------------------
    @Test
    public void delRows_正常_ルートマスタ削除処理_12_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_4.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture());
        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        //行選択チェック選択 = 1
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        mst111Form.setSearchResult(result);
        mst111Form.setSelectedSearchResult(result);
        target.setMst111Form(mst111Form);
        target.delRows(result);

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        // 想定通りに正常終了メッセージ（メッセージID：COMI0011）を表示されることルートマスタ削除処理を行う。
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0011",summaryCaptor_4.getValue());
        assertEquals("削除",detailCaptor_5.getValue());
    }    

   // delRows_正常_ルートマスタ削除処理_12-2
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 2
    // 発地、着地の組み合わせが、ルートマスタに存在している
    // -----------------------------------------------------
    @Test
    public void delRows_正常_ルートマスタ削除処理_12_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture());
        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        //行選択チェック選択 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        mst111Form.setSearchResult(result);
        mst111Form.setSelectedSearchResult(result);
        target.setMst111Form(mst111Form);
        target.delRows(result);

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        // 想定通りに正常終了メッセージ（メッセージID：COMI0011）を表示されることルートマスタ削除処理を行う。
        assertEquals("INFO",levelCaptor_3.getValue());
        assertEquals("COMI0011",summaryCaptor_4.getValue());
        assertEquals("削除",detailCaptor_5.getValue());
    }        

   // delRows_正常_ルートマスタ削除処理_12-2_1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 2
    // 発地、着地の組み合わせが、ルートマスタに存在しない
    // -----------------------------------------------------
    @Test
    public void delRows_正常_ルートマスタ削除処理_12_2_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        serviceInterfaceBean2.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean,serviceInterfaceBean2);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture());
        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        //行選択チェック選択 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        mst111Form.setSearchResult(result);
        mst111Form.setSelectedSearchResult(result);
        target.setMst111Form(mst111Form);
        target.delRows(result);

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);

        assertEquals("listHatsuchiCd0", paramsCaptor_1_Param.get("listHatsuchiCd"));
        assertEquals("listHatsuchiMeisho0", paramsCaptor_1_Param.get("listHatsuchiMeisho"));
        assertEquals("listChakuchiCd0", paramsCaptor_1_Param.get("listChakuchiCd"));
        assertEquals("listChakuchiMeisho0", paramsCaptor_1_Param.get("listChakuchiMeisho"));
        assertEquals("listYusenjuni0", paramsCaptor_1_Param.get("listYusenjuni"));
        assertEquals("listKeiyuchi1Cd0", paramsCaptor_1_Param.get("listKeiyuchi1Cd"));
        assertEquals("listKeiyuchi1Meisho0", paramsCaptor_1_Param.get("listKeiyuchi1Meisho"));
        assertEquals("listKeiyuchi2Cd0", paramsCaptor_1_Param.get("listKeiyuchi2Cd"));
        assertEquals("listKeiyuchi2Meisho0", paramsCaptor_1_Param.get("listKeiyuchi2Meisho"));
        assertEquals("listKeiyuchi3Cd0", paramsCaptor_1_Param.get("listKeiyuchi3Cd"));
        assertEquals("listKeiyuchi3Meisho0", paramsCaptor_1_Param.get("listKeiyuchi3Meisho"));
        assertEquals("listRouteMei0", paramsCaptor_1_Param.get("listRouteMei"));
        assertEquals("listRouteEdaban0", paramsCaptor_1_Param.get("listRouteEdaban"));
        assertEquals("listRouteDataVersion0", paramsCaptor_1_Param.get("listRouteDataVersion"));
        assertEquals("listKoshinCounter0", paramsCaptor_1_Param.get("listKoshinCounter"));
        assertEquals("komFromKyotenCd0", paramsCaptor_1_Param.get("komFromKyotenCd"));
        assertEquals("komToKyotenCd0", paramsCaptor_1_Param.get("komToKyotenCd"));

        assertEquals("mst111-delete-row-detail", functionCodeCaptor_2.getValue());
    }

    // delRows_異常_ルートマスタ削除処理_12-3
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // 
    // -----------------------------------------------------
    @Test
    public void delRows_異常_ルートマスタ削除処理_12_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        //行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        mst111Form.setSelectedSearchResult(result);
        target.setMst111Form(mst111Form);
        target.delRows(result);

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        // 想定通りにエラーが発生。（メッセージID：COME0013）
//        assertEquals("ERROR",levelCaptor_1.getValue());
//        assertEquals("COME0013",summaryCaptor_2.getValue());
    }    

    // delRows_異常_ルートマスタ削除処理_12-4
    //
    // -------------------テスト条件--------------------------
    // 発地、着地の組み合わせが、ルートマスタに存在しない[COME0006]が返却
    // -----------------------------------------------------
    @Test
    public void delRows_異常_ルートマスタ削除処理_12_4 () throws IllegalAccessException, InvocationTargetException {

      // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 発地、着地の組み合わせが、ルートマスタに存在しない[COME0006]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0006",
                "listHatsuchiCd");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2
                .capture(),summaryCaptor_3.capture(),summaryCaptor_4.capture())).thenReturn(messageModuleBean);

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        mst111Form.setSelectedSearchResult(result);
        mst111Form.setSearchResult(result);
        target.setMst111Form(mst111Form);
        target.delRows(result);

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listHatsuchiCd0", paramsCaptor_1_Param.get("listHatsuchiCd"));
        assertEquals("listHatsuchiMeisho0", paramsCaptor_1_Param.get("listHatsuchiMeisho"));
        assertEquals("listChakuchiCd0", paramsCaptor_1_Param.get("listChakuchiCd"));
        assertEquals("listChakuchiMeisho0", paramsCaptor_1_Param.get("listChakuchiMeisho"));
        assertEquals("listYusenjuni0", paramsCaptor_1_Param.get("listYusenjuni"));
        assertEquals("listKeiyuchi1Cd0", paramsCaptor_1_Param.get("listKeiyuchi1Cd"));
        assertEquals("listKeiyuchi1Meisho0", paramsCaptor_1_Param.get("listKeiyuchi1Meisho"));
        assertEquals("listKeiyuchi2Cd0", paramsCaptor_1_Param.get("listKeiyuchi2Cd"));
        assertEquals("listKeiyuchi2Meisho0", paramsCaptor_1_Param.get("listKeiyuchi2Meisho"));
        assertEquals("listKeiyuchi3Cd0", paramsCaptor_1_Param.get("listKeiyuchi3Cd"));
        assertEquals("listKeiyuchi3Meisho0", paramsCaptor_1_Param.get("listKeiyuchi3Meisho"));
        assertEquals("listRouteMei0", paramsCaptor_1_Param.get("listRouteMei"));
        assertEquals("listRouteEdaban0", paramsCaptor_1_Param.get("listRouteEdaban"));
        assertEquals("listRouteDataVersion0", paramsCaptor_1_Param.get("listRouteDataVersion"));
        assertEquals("listKoshinCounter0", paramsCaptor_1_Param.get("listKoshinCounter"));
        assertEquals("komFromKyotenCd0", paramsCaptor_1_Param.get("komFromKyotenCd"));
        assertEquals("komToKyotenCd0", paramsCaptor_1_Param.get("komToKyotenCd"));
        assertEquals("mst111-delete-exist",functionCodeCaptor_2.getValue());
        // 想定通りにエラーが発生。（メッセージID：COME0006
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0006",summaryCaptor_2.getValue());
    }    

    // rirekiIchiran_正常_更新履歴コンテキストメニュー_13-1
    //
    // -------------------テスト条件--------------------------
    // 正常に取得された場合
    // -----------------------------------------------------
    @Test
    public void rirekiIchiran_正常_更新履歴コンテキストメニュー_13_1 () throws IllegalAccessException, 
            InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> titleFlgCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> searchKeyCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(rirekiSyosaiBean).searchList(titleFlgCaptor_1.capture(),functionCodeCaptor_2.capture()
                ,searchKeyCaptor_3.capture());
        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        mst111Form.setSelectedSearchResult(result);
        target.setMst111Form(mst111Form);
        target.rirekiIchiran();

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        //想定通りに履歴を表示する。
        assertEquals("2",titleFlgCaptor_1.getValue());
        assertEquals("MST111_SEARCH_RIREKI",functionCodeCaptor_2.getValue());
        assertEquals("listHatsuchiCd0",searchKeyCaptor_3.getValue().get("listHatsuchiCd"));
        assertEquals("listChakuchiCd0",searchKeyCaptor_3.getValue().get("listChakuchiCd"));
    }    

    // searchChange_正常_補充ケース_14-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void searchChange_正常_補充ケース_14_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        target.setMst111Form(mst111Form);
        target.searchChange();

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

    }

    // menuClick_正常_補充ケース_14-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_14_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        target.setMst111Form(mst111Form);
        target.menuClick("","");

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

    }

    // menuClick_正常_補充ケース_14-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_14_2_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(1);

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        target.setMst111Form(mst111Form);
        target.menuClick("","");

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

    }    
    
    // breadClumClick_正常_補充ケース_14-3
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_14_3 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        target.setMst111Form(mst111Form);
        target.breadClumClick("",0);

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

    }

    // breadClumClick_正常_補充ケース_14-3_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_14_3_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(0);        
        
        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        target.setMst111Form(mst111Form);
        target.breadClumClick("",0);

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

    }    
    
    // logoutClick_正常_補充ケース_14-4
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void logoutClick_正常_補充ケース_14_4 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        target.setMst111Form(mst111Form);
        target.logoutClick();

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

    }

    // delRowsFunc_正常_補充ケース_14-5
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void delRowsFunc_正常_補充ケース_14_5 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        target.setMst111Form(mst111Form);
        target.delRowsFunc();

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

    }

    // getAutoCompForHatsuchiCdList_正常_発地コード取得Autocomplete一覧を取得_15_1
    //
    // -------------------テスト条件--------------------------
    // 検索キー"101"
    // -----------------------------------------------------
    @Test
    public void getAutoCompForHatsuchiCdList_正常_発地コード取得Autocomplete一覧を取得_15_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> sqlIdCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        List<String> autoCompleteBeanList = new ArrayList<>();
        when(autoCompleteBean.getStringListByKey(sqlIdCaptor_1.capture(), keyCaptor_2.capture())).thenReturn(autoCompleteBeanList);
        //テスト実行
        Mst111Form mst111Form = new Mst111Form();

        target.setMst111Form(mst111Form);
        target.getAutoCompForHatsuchiCdList("101");

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        // 想定通りにAutocomplete一覧表示する。
        assertEquals("101",keyCaptor_2.getValue());
    } 

    // getAutoCompForChakuchiCdList_正常_着地コード取得Autocomplete一覧を取得_16_1
    //
    // -------------------テスト条件--------------------------
    // 検索キー"101"
    // -----------------------------------------------------
    @Test
    public void getAutoCompForChakuchiCdList_正常_着地コード取得Autocomplete一覧を取得_16_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> sqlIdCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        List<String> autoCompleteBeanList = new ArrayList<>();
        when(autoCompleteBean.getStringListByKey(sqlIdCaptor_1.capture(), keyCaptor_2.capture())).thenReturn(autoCompleteBeanList);
        //テスト実行
        Mst111Form mst111Form = new Mst111Form();

        target.setMst111Form(mst111Form);
        target.getAutoCompForChakuchiCdList("101");

        //実施結果Outを取得
        mst111Form = target.getMst111Form();

        //想定通りに履歴を表示する。
        assertEquals("101",keyCaptor_2.getValue());
    }

    // getAutoCompForKeiyuchi1CdList_正常_経由地1コードAutocomplete一覧を取得_17_1
    //
    // -------------------テスト条件--------------------------
    // 経由地1コード = "104"
    // -----------------------------------------------------
    @Test
    public void getAutoCompForKeiyuchi1CdList_正常_経由地1コードAutocomplete一覧を取得_17_1() throws IllegalAccessException, InvocationTargetException {
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> paramsMapCaptor_2 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> sqlIdCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<AutoCompOptionBean> paramsAutoCaptor_4 = ArgumentCaptor.forClass(AutoCompOptionBean.class);

        // 循環DataTable該当行の情報を取得する
        Map<String, Object> rowMap = new HashMap<String, Object>();
        rowMap.put("listHatsuchiCd", "101");
        when(pageCommonBean.getEvaluateExpression(paramsCaptor_1.capture())).thenReturn(rowMap);

        // 拠点コード関連表リスト
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        List<Map<String, String>> kanrenhyoList = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            kanrenhyoList.add(createRecMapFor_17_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(kanrenhyoList));
        when(pageCommonBean.getDBInfo(paramsMapCaptor_2.capture(), sqlIdCaptor_3.capture())).thenReturn(serviceInterfaceBean);

        // ワーク.経由地1リスト
        List<AutoCompOptionBean> keiyuchiList = new ArrayList<>();
        AutoCompOptionBean keiyuchi1 = new AutoCompOptionBean();
        keiyuchi1.setValue("104");
        keiyuchi1.setLabel("keiyuchi4");
        keiyuchiList.add(keiyuchi1);
        AutoCompOptionBean keiyuchi2 = new AutoCompOptionBean();
        keiyuchi2.setValue("105");
        keiyuchi2.setLabel("keiyuchi5");
        keiyuchiList.add(keiyuchi2);
        // Mockitoオブジェクトの予想return値設定
        when(autoCompleteBean.getValueLabelFromDB(sqlIdCaptor_3.capture(), paramsMapCaptor_2.capture(), paramsAutoCaptor_4.capture())).thenReturn(keiyuchiList);

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        // ワーク.選択肢リスト
        List<AutoCompOptionBean> sentakushiList = new ArrayList();

        target.setMst111Form(mst111Form);
        sentakushiList = target.getAutoCompForKeiyuchi1CdList("104");
        //実施結果Outを取得
        //想定通りに履歴を表示する。
        assertEquals("104", sentakushiList.get(0).getValue());
        assertEquals("keiyuchi4", sentakushiList.get(0).getLabel());
 
    }

    // getAutoCompForKeiyuchi2CdList_正常_経由地2コードAutocomplete一覧を取得_18_1
    //
    // -------------------テスト条件--------------------------
    // 経由地2コード = "104"
    // -----------------------------------------------------
    @Test
    public void getAutoCompForKeiyuchi2CdList_正常_経由地2コードAutocomplete一覧を取得_18_1() throws IllegalAccessException, InvocationTargetException {
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> paramsMapCaptor_2 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> sqlIdCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<AutoCompOptionBean> paramsAutoCaptor_4 = ArgumentCaptor.forClass(AutoCompOptionBean.class);

        // 循環DataTable該当行の情報を取得する
        Map<String, Object> rowMap = new HashMap<String, Object>();
        rowMap.put("listKeiyuchi1Cd", "101");
        when(pageCommonBean.getEvaluateExpression(paramsCaptor_1.capture())).thenReturn(rowMap);

        // 拠点コード関連表リスト
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        List<Map<String, String>> kanrenhyoList = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            kanrenhyoList.add(createRecMapFor_17_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(kanrenhyoList));
        when(pageCommonBean.getDBInfo(paramsMapCaptor_2.capture(), sqlIdCaptor_3.capture())).thenReturn(serviceInterfaceBean);

        // ワーク.経由地1リスト
        List<AutoCompOptionBean> keiyuchiList = new ArrayList<>();
        AutoCompOptionBean keiyuchi1 = new AutoCompOptionBean();
        keiyuchi1.setValue("104");
        keiyuchi1.setLabel("keiyuchi4");
        keiyuchiList.add(keiyuchi1);
        AutoCompOptionBean keiyuchi2 = new AutoCompOptionBean();
        keiyuchi2.setValue("105");
        keiyuchi2.setLabel("keiyuchi5");
        keiyuchiList.add(keiyuchi2);
        // Mockitoオブジェクトの予想return値設定
        when(autoCompleteBean.getValueLabelFromDB(sqlIdCaptor_3.capture(), paramsMapCaptor_2.capture(), paramsAutoCaptor_4.capture())).thenReturn(keiyuchiList);

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        // ワーク.選択肢リスト
        List<AutoCompOptionBean> sentakushiList = new ArrayList();

        target.setMst111Form(mst111Form);
        sentakushiList = target.getAutoCompForKeiyuchi2CdList("104");
        //実施結果Outを取得
        //想定通りに履歴を表示する。
        assertEquals("104", sentakushiList.get(0).getValue());
        assertEquals("keiyuchi4", sentakushiList.get(0).getLabel());
 
    }

    // getAutoCompForKeiyuchi3CdList_正常_経由地3コードAutocomplete一覧を取得_19_1
    //
    // -------------------テスト条件--------------------------
    // 経由地3コード = "104"
    // -----------------------------------------------------
    @Test
    public void getAutoCompForKeiyuchi3CdList_正常_経由地3コードAutocomplete一覧を取得_19_1() throws IllegalAccessException, InvocationTargetException {
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> paramsMapCaptor_2 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> sqlIdCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<AutoCompOptionBean> paramsAutoCaptor_4 = ArgumentCaptor.forClass(AutoCompOptionBean.class);

        // 循環DataTable該当行の情報を取得する
        Map<String, Object> rowMap = new HashMap<String, Object>();
        rowMap.put("listKeiyuchi2Cd", "101");
        when(pageCommonBean.getEvaluateExpression(paramsCaptor_1.capture())).thenReturn(rowMap);

        // 拠点コード関連表リスト
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        List<Map<String, String>> kanrenhyoList = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            kanrenhyoList.add(createRecMapFor_17_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(kanrenhyoList));
        when(pageCommonBean.getDBInfo(paramsMapCaptor_2.capture(), sqlIdCaptor_3.capture())).thenReturn(serviceInterfaceBean);

        // ワーク.経由地1リスト
        List<AutoCompOptionBean> keiyuchiList = new ArrayList<>();
        AutoCompOptionBean keiyuchi1 = new AutoCompOptionBean();
        keiyuchi1.setValue("104");
        keiyuchi1.setLabel("keiyuchi4");
        keiyuchiList.add(keiyuchi1);
        AutoCompOptionBean keiyuchi2 = new AutoCompOptionBean();
        keiyuchi2.setValue("105");
        keiyuchi2.setLabel("keiyuchi5");
        keiyuchiList.add(keiyuchi2);
        // Mockitoオブジェクトの予想return値設定
        when(autoCompleteBean.getValueLabelFromDB(sqlIdCaptor_3.capture(), paramsMapCaptor_2.capture(), paramsAutoCaptor_4.capture())).thenReturn(keiyuchiList);

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        // ワーク.選択肢リスト
        List<AutoCompOptionBean> sentakushiList = new ArrayList();

        target.setMst111Form(mst111Form);
        sentakushiList = target.getAutoCompForKeiyuchi3CdList("104");
        // 実施結果Outを取得
        // 想定通りに履歴を表示する。
        assertEquals("104", sentakushiList.get(0).getValue());
        assertEquals("keiyuchi4", sentakushiList.get(0).getLabel());

    }

    // getAutoCompForKeiyuchi3CdList_正常_経由地3コードAutocomplete一覧を取得_19_2
    //
    // -------------------テスト条件--------------------------
    // 経由地3コード = "104"
    // -----------------------------------------------------
    @Test
    public void getAutoCompForKeiyuchi3CdList_正常_経由地3コードAutocomplete一覧を取得_19_2() throws IllegalAccessException, InvocationTargetException {
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> paramsMapCaptor_2 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> sqlIdCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<AutoCompOptionBean> paramsAutoCaptor_4 = ArgumentCaptor.forClass(AutoCompOptionBean.class);

        // 循環DataTable該当行の情報を取得する
        Map<String, Object> rowMap = new HashMap<String, Object>();
        rowMap.put("listKeiyuchi2Cd", "101");
        when(pageCommonBean.getEvaluateExpression(paramsCaptor_1.capture())).thenReturn(rowMap);

        // 拠点コード関連表リスト
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        int kanrenhyoList = 1;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(kanrenhyoList));
        doThrow(IOException.class).when(pageCommonBean).getDBInfo(paramsMapCaptor_2.capture(), sqlIdCaptor_3.capture());

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        // ワーク.選択肢リスト
        List<AutoCompOptionBean> sentakushiList = new ArrayList();

        target.setMst111Form(mst111Form);
        sentakushiList = target.getAutoCompForKeiyuchi3CdList("104");
        //実施結果Outを取得
        //想定通りに履歴を表示する。

    }

    // getAutoCompForKeiyuchi3CdList_正常_経由地3コードAutocomplete一覧を取得_19_3
    //
    // -------------------テスト条件--------------------------
    // 経由地3コード = ""
    // -----------------------------------------------------
    @Test
    public void getAutoCompForKeiyuchi3CdList_正常_経由地3コードAutocomplete一覧を取得_19_3() throws IllegalAccessException, InvocationTargetException {
        // パラメータキャプチャー
        ArgumentCaptor<String> paramsCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> paramsMapCaptor_2 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> sqlIdCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<AutoCompOptionBean> paramsAutoCaptor_4 = ArgumentCaptor.forClass(AutoCompOptionBean.class);

        // 循環DataTable該当行の情報を取得する
        Map<String, Object> rowMap = new HashMap<String, Object>();
        rowMap.put("listKeiyuchi2Cd", "101");
        when(pageCommonBean.getEvaluateExpression(paramsCaptor_1.capture())).thenReturn(rowMap);

        // 拠点コード関連表リスト
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        List<Map<String, String>> kanrenhyoList = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            kanrenhyoList.add(createRecMapFor_17_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(kanrenhyoList));
        when(pageCommonBean.getDBInfo(paramsMapCaptor_2.capture(), sqlIdCaptor_3.capture())).thenReturn(serviceInterfaceBean);

        // ワーク.経由地1リスト
        List<AutoCompOptionBean> keiyuchiList = new ArrayList<>();
        AutoCompOptionBean keiyuchi1 = new AutoCompOptionBean();
        keiyuchi1.setValue("104");
        keiyuchi1.setLabel("keiyuchi4");
        keiyuchiList.add(keiyuchi1);
        AutoCompOptionBean keiyuchi2 = new AutoCompOptionBean();
        keiyuchi2.setValue("105");
        keiyuchi2.setLabel("keiyuchi5");
        keiyuchiList.add(keiyuchi2);
        // Mockitoオブジェクトの予想return値設定
        when(autoCompleteBean.getValueLabelFromDB(sqlIdCaptor_3.capture(), paramsMapCaptor_2.capture(), paramsAutoCaptor_4.capture())).thenReturn(keiyuchiList);

        //テスト実行
        Mst111Form mst111Form = new Mst111Form();
        // ワーク.選択肢リスト
        List<AutoCompOptionBean> sentakushiList = new ArrayList();

        target.setMst111Form(mst111Form);
        sentakushiList = target.getAutoCompForKeiyuchi3CdList(null);
        //実施結果Outを取得
        //想定通りに履歴を表示する。
        assertEquals("104", sentakushiList.get(0).getValue());
        assertEquals("keiyuchi4", sentakushiList.get(0).getLabel());

    }

    // upload_正常_アップロード_20_1
    //
    // -------------------テスト条件--------------------------
    // 
    // -----------------------------------------------------
    @Test
    public void upload_正常_アップロード_20_1() throws IllegalAccessException, InvocationTargetException {
        Mst111Form mst111Form = new Mst111Form();
        //テスト実行
        Flash flash = new FlashKls();
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        when(flashUtil.getPageParam()).thenReturn(flash);
        target.upload();

    }

    // setListCodeName_正常_AUTOCOMPLETE選択時コードと名称の設定処理_21-1
    //
    // -------------------テスト条件--------------------------
    // 選択されたAUTOCOMPLETEデータ != null
    // -----------------------------------------------------
    @Test
    public void setListCodeName_正常_AUTOCOMPLETE選択時コードと名称の設定処理_21_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst111Form form = new Mst111Form();
        // 明細リスト
        List<Map<String, Object>> resultList = new ArrayList<>();
        Map<String, Object> resultMap = null;
        for (int i = 0; i < 1; i++) {
            resultMap = new HashMap<>();
            resultMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        }
        resultList.add(resultMap);

        // 選択されたAUTOCOMPLETEデータ
        AutoCompOptionBean option = new AutoCompOptionBean();
        option.setLabel("AutoCompOption");
        option.setValue("101");

        target.setMst111Form(form);
        target.setListCodeName(resultList, "UNIQUE_KEY", option, "colCodeName", "colNameName");
        
        //実施結果Outを取得
        form = target.getMst111Form();

        // 想定通りにコードと名称の値がクリアされること
        assertEquals("101", resultList.get(0).get("colCodeName"));
        assertEquals("AutoCompOption", resultList.get(0).get("colNameName"));
    }

    // setListCodeName_正常_AUTOCOMPLETE選択時コードと名称の設定処理_21-2
    //
    // -------------------テスト条件--------------------------
    // 選択されたAUTOCOMPLETEデータ = null
    // -----------------------------------------------------
    @Test
    public void setListCodeName_正常_AUTOCOMPLETE選択時コードと名称の設定処理_21_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst111Form form = new Mst111Form();
        // 明細リスト
        List<Map<String, Object>> resultList = new ArrayList<>();
        Map<String, Object> resultMap = null;
        for (int i = 0; i < 1; i++) {
            resultMap = new HashMap<>();
            resultMap.put("UNIQUE_KEY", "UNIQUE_KEY");
            resultList.add(resultMap);
        }

        target.setMst111Form(form);
        target.setListCodeName(resultList, "UNIQUE_KEY", null, "colCodeName", "colNameName");
        
        //実施結果Outを取得
        form = target.getMst111Form();

        // 想定通りにコードと名称の値がクリアされること
        assertEquals("", resultList.get(0).get("colCodeName"));
        assertEquals("", resultList.get(0).get("colNameName"));
    }

    private Map<String, String> createRecMapFor_1_1(int i) {

        Map recMap = new HashMap();
        recMap.put("listHatsuchiCd", "listHatsuchiCd" + i);
        recMap.put("listHatsuchiMeisho", "listHatsuchiMeisho" + i);
        recMap.put("listChakuchiCd", "listChakuchiCd" + i);
        recMap.put("listChakuchiMeisho", "listChakuchiMeisho" + i);
        recMap.put("listYusenjuni", "listYusenjuni" + i);
        recMap.put("listKeiyuchi1Cd", "listKeiyuchi1Cd" + i);
        recMap.put("listKeiyuchi1Meisho", "listKeiyuchi1Meisho" + i);
        recMap.put("listKeiyuchi2Cd", "listKeiyuchi2Cd" + i);
        recMap.put("listKeiyuchi2Meisho", "listKeiyuchi2Meisho" + i);
        recMap.put("listKeiyuchi3Cd", "listKeiyuchi3Cd" + i);
        recMap.put("listKeiyuchi3Meisho", "listKeiyuchi3Meisho" + i);
        recMap.put("listRouteMei", "listRouteMei" + i);
        recMap.put("listRouteEdaban", "listRouteEdaban" + i);
        recMap.put("listRouteDataVersion", "listRouteDataVersion" + i);
        recMap.put("listKoshinCounter", "listKoshinCounter" + i);
        recMap.put("komFromKyotenCd", "komFromKyotenCd" + i);
        recMap.put("komToKyotenCd", "komToKyotenCd" + i);
        return recMap;
    }

    private Map<String, Object> createRecMapFor_11_1(int i) {
        Map recMap = new HashMap();
        recMap.put("listHatsuchiCd", "listHatsuchiCd" + i);
        recMap.put("listHatsuchiMeisho", "listHatsuchiMeisho" + i);
        recMap.put("listChakuchiCd", "listChakuchiCd" + i);
        recMap.put("listChakuchiMeisho", "listChakuchiMeisho" + i);
        recMap.put("listYusenjuni", "listYusenjuni" + i);
        recMap.put("listKeiyuchi1Cd", "listKeiyuchi1Cd" + i);
        recMap.put("listKeiyuchi1Meisho", "listKeiyuchi1Meisho" + i);
        recMap.put("listKeiyuchi2Cd", "listKeiyuchi2Cd" + i);
        recMap.put("listKeiyuchi2Meisho", "listKeiyuchi2Meisho" + i);
        recMap.put("listKeiyuchi3Cd", "listKeiyuchi3Cd" + i);
        recMap.put("listKeiyuchi3Meisho", "listKeiyuchi3Meisho" + i);
        recMap.put("listRouteMei", "listRouteMei" + i);
        recMap.put("listRouteEdaban", "listRouteEdaban" + i);
        recMap.put("listRouteDataVersion", "listRouteDataVersion" + i);
        recMap.put("listKoshinCounter", "listKoshinCounter" + i);
        recMap.put("komFromKyotenCd", "komFromKyotenCd" + i);
        recMap.put("komToKyotenCd", "komToKyotenCd" + i);
        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }
    
    private Map<String, Object> createRecMapFor_11_2(int i) {
        Map recMap = new HashMap();
        recMap.put("listHatsuchiCd", "listHatsuchiCd" + i);
        recMap.put("listHatsuchiMeisho", "listHatsuchiMeisho" + i);
        recMap.put("listChakuchiCd", "listChakuchiCd" + i);
        recMap.put("listChakuchiMeisho", "listChakuchiMeisho" + i);
        recMap.put("listYusenjuni", "listYusenjuni" + i);
        recMap.put("listKeiyuchi1Cd", "listKeiyuchi1Cd" + i);
        recMap.put("listKeiyuchi1Meisho", "listKeiyuchi1Meisho" + i);
        recMap.put("listKeiyuchi2Cd", "listKeiyuchi2Cd" + i);
        recMap.put("listKeiyuchi2Meisho", "listKeiyuchi2Meisho" + i);
        recMap.put("listKeiyuchi3Cd", "listKeiyuchi3Cd" + i);
        recMap.put("listKeiyuchi3Meisho", "listKeiyuchi3Meisho" + i);
        recMap.put("listRouteMei", "listRouteMei" + i);
        recMap.put("listRouteEdaban", "listRouteEdaban" + i);
        recMap.put("listRouteDataVersion", "listRouteDataVersion" + i);
        recMap.put("listKoshinCounter", "listKoshinCounter" + i);
        recMap.put("komFromKyotenCd", "komFromKyotenCd" + i);
        recMap.put("komToKyotenCd", "komToKyotenCd" + i);
        if (i == 0) {
            recMap.put("addFlg", null);
        }
        return recMap;
    }

    private Map<String, String> createRecMapFor_17_1(int i) {

        Map recMap = new HashMap();
        recMap.put("komFromKyotenCd", 101);
        recMap.put("komToKyotenCd", 104 + i);
        return recMap;
    }

    private void assertForRecList_2_1(Mst111Form mst111Form) {
        int i = 0;
        assertEquals(1, mst111Form.getSearchResult().size());
        for (Map<String, Object> rec : mst111Form.getSearchResult()) {
            assertEquals("listHatsuchiCd" + i, rec.get("listHatsuchiCd"));
            assertEquals("listHatsuchiMeisho" + i, rec.get("listHatsuchiMeisho"));
            assertEquals("listChakuchiCd" + i, rec.get("listChakuchiCd"));
            assertEquals("listChakuchiMeisho" + i, rec.get("listChakuchiMeisho"));
            assertEquals("listYusenjuni" + i, rec.get("listYusenjuni"));
            assertEquals("listKeiyuchi1Cd" + i, rec.get("listKeiyuchi1Cd"));
            assertEquals("listKeiyuchi1Meisho" + i, rec.get("listKeiyuchi1Meisho"));
            assertEquals("listKeiyuchi2Cd" + i, rec.get("listKeiyuchi2Cd"));
            assertEquals("listKeiyuchi2Meisho" + i, rec.get("listKeiyuchi2Meisho"));
            assertEquals("listKeiyuchi3Cd" + i, rec.get("listKeiyuchi3Cd"));
            assertEquals("listKeiyuchi3Meisho" + i, rec.get("listKeiyuchi3Meisho"));
            assertEquals("listRouteMei" + i, rec.get("listRouteMei"));
            assertEquals("listRouteEdaban" + i, rec.get("listRouteEdaban"));
            assertEquals("listRouteDataVersion" + i, rec.get("listRouteDataVersion"));
            assertEquals("listKoshinCounter" + i, rec.get("listKoshinCounter"));
            assertEquals("komFromKyotenCd" + i, rec.get("komFromKyotenCd"));
            assertEquals("komToKyotenCd" + i, rec.get("komToKyotenCd"));

            i++;
        }
    }    

    private void assertForRecList_2_2(Mst111Form mst111Form) {
        int i = 0;
        assertEquals(2, mst111Form.getSearchResult().size());
        for (Map<String, Object> rec : mst111Form.getSearchResult()) {
            assertEquals("listHatsuchiCd" + i, rec.get("listHatsuchiCd"));
            assertEquals("listHatsuchiMeisho" + i, rec.get("listHatsuchiMeisho"));
            assertEquals("listChakuchiCd" + i, rec.get("listChakuchiCd"));
            assertEquals("listChakuchiMeisho" + i, rec.get("listChakuchiMeisho"));
            assertEquals("listYusenjuni" + i, rec.get("listYusenjuni"));
            assertEquals("listKeiyuchi1Cd" + i, rec.get("listKeiyuchi1Cd"));
            assertEquals("listKeiyuchi1Meisho" + i, rec.get("listKeiyuchi1Meisho"));
            assertEquals("listKeiyuchi2Cd" + i, rec.get("listKeiyuchi2Cd"));
            assertEquals("listKeiyuchi2Meisho" + i, rec.get("listKeiyuchi2Meisho"));
            assertEquals("listKeiyuchi3Cd" + i, rec.get("listKeiyuchi3Cd"));
            assertEquals("listKeiyuchi3Meisho" + i, rec.get("listKeiyuchi3Meisho"));
            assertEquals("listRouteMei" + i, rec.get("listRouteMei"));
            assertEquals("listRouteEdaban" + i, rec.get("listRouteEdaban"));
            assertEquals("listRouteDataVersion" + i, rec.get("listRouteDataVersion"));
            assertEquals("listKoshinCounter" + i, rec.get("listKoshinCounter"));
            assertEquals("komFromKyotenCd" + i, rec.get("komFromKyotenCd"));
            assertEquals("komToKyotenCd" + i, rec.get("komToKyotenCd"));
            i++;
        }
    }      

    private void assertForRecList_2_5(Mst111Form mst111Form) {
        int i = 0;
        assertEquals(0, mst111Form.getSearchResult().size());
        for (Map<String, Object> rec : mst111Form.getSearchResult()) {
            assertEquals("listHatsuchiCd" + i, rec.get("listHatsuchiCd"));
            assertEquals("listHatsuchiMeisho" + i, rec.get("listHatsuchiMeisho"));
            assertEquals("listChakuchiCd" + i, rec.get("listChakuchiCd"));
            assertEquals("listChakuchiMeisho" + i, rec.get("listChakuchiMeisho"));
            assertEquals("listYusenjuni" + i, rec.get("listYusenjuni"));
            assertEquals("listKeiyuchi1Cd" + i, rec.get("listKeiyuchi1Cd"));
            assertEquals("listKeiyuchi1Meisho" + i, rec.get("listKeiyuchi1Meisho"));
            assertEquals("listKeiyuchi2Cd" + i, rec.get("listKeiyuchi2Cd"));
            assertEquals("listKeiyuchi2Meisho" + i, rec.get("listKeiyuchi2Meisho"));
            assertEquals("listKeiyuchi3Cd" + i, rec.get("listKeiyuchi3Cd"));
            assertEquals("listKeiyuchi3Meisho" + i, rec.get("listKeiyuchi3Meisho"));
            assertEquals("listRouteMei" + i, rec.get("listRouteMei"));
            assertEquals("listRouteEdaban" + i, rec.get("listRouteEdaban"));
            assertEquals("listRouteDataVersion" + i, rec.get("listRouteDataVersion"));
            assertEquals("listKoshinCounter" + i, rec.get("listKoshinCounter"));
            assertEquals("komFromKyotenCd" + i, rec.get("komFromKyotenCd"));
            assertEquals("komToKyotenCd" + i, rec.get("komToKyotenCd"));
            i++;
        }
    }
    
}
