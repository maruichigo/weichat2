/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.mst;

import jp.co.kintetsuls.forms.mst.Mst271Form;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import org.junit.After;
import org.junit.Before;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.utils.DateUtils;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import org.junit.Test;
import static org.mockito.Mockito.when;

/**
 * Junit Test
 * @author 強 超 (MBP)
 * @version 2019/1/24 新規作成
 */
public class Mst271BeanTest {
    
    // テストTarget
    @InjectMocks
    private Mst271Bean target;

    // Mockitoオブジェクト
    @Mock
    private FileBean fileBean;
    @Mock
    private AutoCompleteViewBean autoCompleteViewBean;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosai;
    @Mock
    private SearchHelpBean searchHelpBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private MessagePropertyBean messagePropertyBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosaiBean;
    @Mock
    private ListCheckBean listCheckBean;
    
    public Mst271BeanTest() {
    }
    
    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }
    
    @After
    public void tearDown() {
    }

    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[not null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1() {
       // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst271Form mst271Form = new Mst271Form();
        
        //前画面情報[not null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst271Form);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst271Form form = new Mst271Form();
        target.setMst271Form(form);
        // 戻ってきた場合、再検索を実施する。
        target.init("","MST271_SCREEN",true);

        //実施結果Outを取得
        form = target.getMst271Form();
        String url = target.getUrl();
        AuthorityConfBean authorityConfBean  = target.getAuthConfBean();
        Map<String, Object> rirekiSearchKey = target.getRirekiSearchKey();
        List<MessageModuleBean> msgList = target.getMsgList();
        target.setUrl(url);
        target.setBreadBean(breadBean);
        target.setAutoCompleteViewBean(autoCompleteViewBean);
        target.setAuthConfBean(authorityConfBean);
        target.setFileBean(fileBean);
        target.setMessageProperty(messagePropertyBean);
        target.setPageCommonBean(pageCommonBean);
        target.setSearchHelpBean(searchHelpBean);
        target.setRirekiSyosai(rirekiSyosaiBean);
        target.setListCheckBean(listCheckBean);
        target.setRirekiSearchKey(rirekiSearchKey);
        target.setMsgList(msgList);

        // 実行時に渡すパラメータの検証
        assertEquals("mst271Form",keyCaptor_1.getValue());
        //想定通りに再検索を実施する。
        assertEquals("search_mst271",keyCaptor_2.getValue());
    }

    // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[業者区分 = 1,代理店 = 10001,管轄営業所 = 121,仕入先 = 10001，世代検索条件 = [1,1,0,0,0],
    // 適用日指定 = 2019/01/02, 削除済のみ = 0 , 料金表設定 = 0, 会社名 = null, 支店/営業所 = null, 
    // 伝票種別コード = 11, 仕入先名称 = null  仕入先略称 = null   デフォルトのみ = 0]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2() throws IllegalAccessException, InvocationTargetException,
            InstantiationException, SystemException {

        // Mockitoオブジェクトの予想return値設定
        Mst271Form mst271Form = new Mst271Form();
        
        //前回検索パラメータ[業者区分 = 1]
        mst271Form.setConGyoshaKbn("1");
        //前回検索パラメータ[代理店 = 10001]
        AutoCompOptionBean conDairiten = new AutoCompOptionBean();
        conDairiten.setValue("conDairiten");
        mst271Form.setConDairiten(conDairiten);
        //前回検索パラメータ[管轄営業所 = 121]
        AutoCompOptionBean conKankatsuEigyosho = new AutoCompOptionBean();
        conKankatsuEigyosho.setValue("conKankatsuEigyosho");
        mst271Form.setConKankatsuEigyosho(conKankatsuEigyosho);
        //前回検索パラメータ[仕入先 = 10001]
        AutoCompOptionBean conSiiresaki = new AutoCompOptionBean();
        conSiiresaki.setValue("conSiiresaki");
        mst271Form.setConSiiresaki(conSiiresaki);
        //前回検索パラメータ[伝票種別コード = 11]
        AutoCompOptionBean conDempyoShubetu = new AutoCompOptionBean();
        conDempyoShubetu.setValue("conDempyoShubetu");
        mst271Form.setConDempyoShubetu(conDempyoShubetu);
        // 前回検索パラメータ[世代検索条件 = [1,1,0,0,0]]
        mst271Form.setConSedaiKensakuJoken(new String[]{"01","02"});
        // 前回検索パラメータ[適用日指定 = 2019/01/02]
        mst271Form.setConTekiyoHi("Wed Jan 02 00:00:00 CST 2019");
        // 前回検索パラメータ[削除済のみ = 0]
        mst271Form.setConSakujoSumiNomi(new ArrayList<>());
        mst271Form.getConSakujoSumiNomi().add("0");
        // 前回検索パラメータ[料金表設定 = 0]
        mst271Form.setConRyokinhyoSettei(new ArrayList<>());
        mst271Form.getConRyokinhyoSettei().add("0");
        // 前回検索パラメータ[デフォルトのみ  = 0]
        mst271Form.setConDefaultNomi(new ArrayList<>());
        mst271Form.getConDefaultNomi().add("0");
        //会社名 = null
        AutoCompOptionBean ConKaishaMei = new AutoCompOptionBean();
        ConKaishaMei.setValue("ConKaishaMei");
        mst271Form.setConKaishaMei(ConKaishaMei);
        //支店/営業所 = null
        AutoCompOptionBean ConSitenEigyosho = new AutoCompOptionBean();
        ConSitenEigyosho.setValue("ConSitenEigyosho");
        mst271Form.setConSitenEigyosho(ConSitenEigyosho);
        //仕入先名称 = null  
        mst271Form.setConSiiresakiMeisho("ConSiiresakiMeisho");
        //仕入先略称 = null 
        mst271Form.setConSiiresakiRyakusho("ConSiiresakiRyakusho");
        
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        //前画面パラメータ
        flash.put("mst271Form", mst271Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);        

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst271Form form = new Mst271Form();
        target.setMst271Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst271Form();

        //想定通りに再検索を実施する。
        assertEquals("search_mst271",keyCaptor_2.getValue());
        assertEquals("1",form.getConGyoshaKbn());
        assertEquals("conDairiten",form.getConDairiten().getValue());
        assertEquals("conKankatsuEigyosho",form.getConKankatsuEigyosho().getValue());
        assertEquals("conSiiresaki",form.getConSiiresaki().getValue());
        assertEquals("conDempyoShubetu",form.getConDempyoShubetu().getValue());
        //世代検索条件
        assertEquals("01",form.getConSedaiKensakuJoken()[0]);
        assertEquals("02",form.getConSedaiKensakuJoken()[1]);
        assertEquals("Wed Jan 02 00:00:00 CST 2019",form.getConTekiyoHi());
        assertEquals("[0]",form.getConSakujoSumiNomi().toString());
        assertEquals("[0]",form.getConRyokinhyoSettei().toString());
        assertEquals("[0]",form.getConDefaultNomi().toString());
        assertEquals("ConKaishaMei",form.getConKaishaMei().getValue());
        assertEquals("ConSitenEigyosho",form.getConSitenEigyosho().getValue());
        assertEquals("ConSiiresakiMeisho",form.getConSiiresakiMeisho());
        assertEquals("ConSiiresakiRyakusho",form.getConSiiresakiRyakusho());
    }  
    
    // init_正常_初期処理_1-3
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3 () throws IllegalAccessException, InvocationTargetException {
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        // 前画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(null);

        // テスト実行
        Mst271Form form = new Mst271Form();
        target.setMst271Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);
        
        // 実施結果Outを取得
        form = target.getMst271Form();
        // 実行時に渡すパラメータの検証
        assertEquals("mst271Form",keyCaptor_1.getValue());
        // 想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null,form.getSearchResult());
    }
    
    // search_正常_検索処理_2-1
    //
    // -------------------テスト条件--------------------------
    // 代理店・中継配達料金表検索結果一覧取得
    // 取得件数 = 1
    // -----------------------------------------------------    
    @Test
    public void search_正常_検索処理_2_1 () throws IllegalAccessException, InvocationTargetException, SystemException {
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 1; i <= 1; i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // テスト実行
        Mst271Form form = new Mst271Form();
        //前回検索パラメータ[業者区分 = 1]
        form.setConGyoshaKbn("1");
        //代理店
        AutoCompOptionBean conDairiten = new AutoCompOptionBean();
        conDairiten.setValue("conDairiten1");
        form.setConDairiten(conDairiten);
        //管轄営業所
        AutoCompOptionBean conKankatsuEigyosho = new AutoCompOptionBean();
        conKankatsuEigyosho.setValue("conKankatsuEigyosho1");
        form.setConKankatsuEigyosho(conKankatsuEigyosho);
        //仕入先
        AutoCompOptionBean conSiiresaki = new AutoCompOptionBean();
        conSiiresaki.setValue("conSiiresaki1");
        form.setConSiiresaki(conSiiresaki);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        //会社名
        AutoCompOptionBean conKaishaMei = new AutoCompOptionBean();
        conKaishaMei.setValue("conKaishaMei1");
        form.setConKaishaMei(conKaishaMei);
        //支店/営業所
        AutoCompOptionBean conSitenEigyosho = new AutoCompOptionBean();
        conSitenEigyosho.setValue("conSitenEigyosho1");
        form.setConSitenEigyosho(conSitenEigyosho);
        //伝票種別コード
        AutoCompOptionBean conDempyoShubetu1 = new AutoCompOptionBean();
        conDempyoShubetu1.setValue("conDempyoShubetu1");
        form.setConDempyoShubetu1(conDempyoShubetu1);
        // 前回検索パラメータ[適用日指定 = 2019/01/02]
        form.setConTekiyoHi("Wed Jan 02 00:00:00 CST 2019");
        // 前回検索パラメータ[削除済のみ = 0]
        form.setConSakujoSumiNomi(new ArrayList<>());
        // 前回検索パラメータ[料金表設定 = 0]
        form.setConRyokinhyoSettei(new ArrayList<>());
        // 前回検索パラメータ[デフォルトのみ  = 0]
        form.setConDefaultNomi(new ArrayList<>());
        //仕入先名称 = null  
        form.setConSiiresakiMeisho("ConSiiresakiMeisho");
        //仕入先略称 = null 
        form.setConSiiresakiRyakusho("ConSiiresakiRyakusho1");
        
        target.setMst271Form(form);
        target.search();
        
        //実施結果Outを取得
        form = target.getMst271Form();
        
        // 実行時に渡すパラメータの検証
        assertEquals("conSiiresaki1", paramsCaptor_1.getValue().get("conSiiresaki"));
        assertEquals(null, paramsCaptor_1.getValue().get("conKaishaMei"));
        assertEquals("conKankatsuEigyosho1", paramsCaptor_1.getValue().get("conKankatsuEigyosho"));
        assertEquals("0", paramsCaptor_1.getValue().get("conRyokinhyoSettei"));
        String[] conSedaiKensakuJoken = (String[]) paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals("1", conSedaiKensakuJoken[0]);
        assertEquals("1", conSedaiKensakuJoken[1]);
        assertEquals("0", paramsCaptor_1.getValue().get("conDefaultNomi"));
        assertEquals("1", paramsCaptor_1.getValue().get("conSakujoSumiNomi"));
        assertEquals("conDairiten1", paramsCaptor_1.getValue().get("conDairiten"));
        assertEquals("mst271_search", functionCodeCaptor_2.getValue());
        //想定通りに一覧を表示されること
        assertForRecList_2_3(1, form);
    }
    
    // search_正常_検索処理_2-2
    //
    // -------------------テスト条件--------------------------
    // 代理店・中継配達料金表検索結果一覧取得
    // 取得件数 = 2
    // -----------------------------------------------------    
    @Test
    public void search_正常_検索処理_2_2 () throws IllegalAccessException, InvocationTargetException, SystemException {
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 1; i <= 2; i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // テスト実行
        Mst271Form form = new Mst271Form();
        //前回検索パラメータ[業者区分 = 1]
        form.setConGyoshaKbn("1");
        //代理店
        AutoCompOptionBean conDairiten = new AutoCompOptionBean();
        conDairiten.setValue("conDairiten1");
        form.setConDairiten(conDairiten);
        //管轄営業所
        AutoCompOptionBean conKankatsuEigyosho = new AutoCompOptionBean();
        conKankatsuEigyosho.setValue("conKankatsuEigyosho1");
        form.setConKankatsuEigyosho(conKankatsuEigyosho);
        //仕入先
        AutoCompOptionBean conSiiresaki = new AutoCompOptionBean();
        conSiiresaki.setValue("conSiiresaki1");
        form.setConSiiresaki(conSiiresaki);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        //会社名
        AutoCompOptionBean conKaishaMei = new AutoCompOptionBean();
        conKaishaMei.setValue("conKaishaMei1");
        form.setConKaishaMei(conKaishaMei);
        //支店/営業所
        AutoCompOptionBean conSitenEigyosho = new AutoCompOptionBean();
        conSitenEigyosho.setValue("conSitenEigyosho1");
        form.setConSitenEigyosho(conSitenEigyosho);
        //伝票種別コード
        AutoCompOptionBean conDempyoShubetu1 = new AutoCompOptionBean();
        conDempyoShubetu1.setValue("conDempyoShubetu1");
        form.setConDempyoShubetu1(conDempyoShubetu1);
        // 前回検索パラメータ[適用日指定 = 2019/01/02]
        form.setConTekiyoHi("Wed Jan 02 00:00:00 CST 2019");
        // 前回検索パラメータ[削除済のみ = 0]
        form.setConSakujoSumiNomi(new ArrayList<>());
        form.getConSakujoSumiNomi().add("0");
        // 前回検索パラメータ[料金表設定 = 0]
        form.setConRyokinhyoSettei(new ArrayList<>());
        form.getConRyokinhyoSettei().add("0");
        // 前回検索パラメータ[デフォルトのみ  = 0]
        form.setConDefaultNomi(new ArrayList<>());
        form.getConDefaultNomi().add("0");
        //仕入先名称 = null  
        form.setConSiiresakiMeisho("ConSiiresakiMeisho");
        //仕入先略称 = null 
        form.setConSiiresakiRyakusho("ConSiiresakiRyakusho1");
        
        target.setMst271Form(form);
        target.search();
        
        //実施結果Outを取得
        form = target.getMst271Form();
        
        // 実行時に渡すパラメータの検証
        assertEquals("mst271_search", functionCodeCaptor_2.getValue());
        //想定通りに一覧を表示されること
        assertForRecList_2_3(2, form);
    }
    
    // search_異常_検索処理_2-3
    //
    // -------------------テスト条件--------------------------
    // 代理店・中継配達料金表検索結果一覧取得
    // 取得件数 = 0
    // -----------------------------------------------------    
    @Test
    public void search_異常_検索処理_2_3 () throws IllegalAccessException, InvocationTargetException, SystemException {
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 1; i <= 1; i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // テスト実行
        Mst271Form form = new Mst271Form();
        //前回検索パラメータ[業者区分 = 1]
        form.setConGyoshaKbn("1");
        //代理店
        AutoCompOptionBean conDairiten = new AutoCompOptionBean();
        conDairiten.setValue("conDairiten1");
        form.setConDairiten(conDairiten);
        //管轄営業所
        AutoCompOptionBean conKankatsuEigyosho = new AutoCompOptionBean();
        conKankatsuEigyosho.setValue("conKankatsuEigyosho1");
        form.setConKankatsuEigyosho(conKankatsuEigyosho);
        //仕入先
        AutoCompOptionBean conSiiresaki = new AutoCompOptionBean();
        conSiiresaki.setValue("conSiiresaki1");
        form.setConSiiresaki(conSiiresaki);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        //会社名
        AutoCompOptionBean conKaishaMei = new AutoCompOptionBean();
        conKaishaMei.setValue("conKaishaMei1");
        form.setConKaishaMei(conKaishaMei);
        //支店/営業所
        AutoCompOptionBean conSitenEigyosho = new AutoCompOptionBean();
        conSitenEigyosho.setValue("conSitenEigyosho1");
        form.setConSitenEigyosho(conSitenEigyosho);
        //伝票種別コード
        AutoCompOptionBean conDempyoShubetu1 = new AutoCompOptionBean();
        conDempyoShubetu1.setValue("conDempyoShubetu1");
        form.setConDempyoShubetu1(conDempyoShubetu1);
        // 前回検索パラメータ[適用日指定 = 2019/01/02]
        form.setConTekiyoHi("Wed Jan 02 00:00:00 CST 2019");
        // 前回検索パラメータ[削除済のみ = 0]
        form.setConSakujoSumiNomi(new ArrayList<>());
        form.getConSakujoSumiNomi().add("0");
        // 前回検索パラメータ[料金表設定 = 0]
        form.setConRyokinhyoSettei(new ArrayList<>());
        form.getConRyokinhyoSettei().add("0");
        // 前回検索パラメータ[デフォルトのみ  = 0]
        form.setConDefaultNomi(new ArrayList<>());
        form.getConDefaultNomi().add("0");
        //仕入先名称 = null  
        form.setConSiiresakiMeisho("ConSiiresakiMeisho");
        //仕入先略称 = null 
        form.setConSiiresakiRyakusho("ConSiiresakiRyakusho1");
        
        target.setMst271Form(form);
        target.search();
        
        //実施結果Outを取得
        form = target.getMst271Form();
        
        // 実行時に渡すパラメータの検証
        assertEquals("conDairiten1",paramsCaptor_1.getValue().get("conDairiten"));
        assertEquals("mst271_search",functionCodeCaptor_2.getValue());
        //想定通りに一覧を表示されること
        assertEquals("1", form.getConGyoshaKbn());
    }
    
    // search_正常_検索処理_2-4
    //
    // -------------------テスト条件--------------------------
    // 代理店・中継配達料金表件数検索結果取得
    // 取得件数 = 2
    // -----------------------------------------------------    
    @Test
    public void search_正常_検索処理_2_4 () throws IllegalAccessException, InvocationTargetException, SystemException {
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索結果一覧取得 件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // テスト実行
        Mst271Form form = new Mst271Form();
        //前回検索パラメータ[業者区分 = 1]
        form.setConGyoshaKbn("1");
        //代理店
        AutoCompOptionBean conDairiten = new AutoCompOptionBean();
        conDairiten.setValue("conDairiten1");
        form.setConDairiten(conDairiten);
        //管轄営業所
        AutoCompOptionBean conKankatsuEigyosho = new AutoCompOptionBean();
        conKankatsuEigyosho.setValue("conKankatsuEigyosho1");
        form.setConKankatsuEigyosho(conKankatsuEigyosho);
        //仕入先
        AutoCompOptionBean conSiiresaki = new AutoCompOptionBean();
        conSiiresaki.setValue("conSiiresaki1");
        form.setConSiiresaki(conSiiresaki);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        //会社名
        AutoCompOptionBean conKaishaMei = new AutoCompOptionBean();
        conKaishaMei.setValue("conKaishaMei1");
        form.setConKaishaMei(conKaishaMei);
        //支店/営業所
        AutoCompOptionBean conSitenEigyosho = new AutoCompOptionBean();
        conSitenEigyosho.setValue("conSitenEigyosho1");
        form.setConSitenEigyosho(conSitenEigyosho);
        //伝票種別コード
        AutoCompOptionBean conDempyoShubetu1 = new AutoCompOptionBean();
        conDempyoShubetu1.setValue("conDempyoShubetu1");
        form.setConDempyoShubetu1(conDempyoShubetu1);
        // 前回検索パラメータ[適用日指定 = 2019/01/02]
        form.setConTekiyoHi("Wed Jan 02 00:00:00 CST 2019");
        // 前回検索パラメータ[削除済のみ = 0]
        form.setConSakujoSumiNomi(new ArrayList<>());
        form.getConSakujoSumiNomi().add("0");
        // 前回検索パラメータ[料金表設定 = 0]
        form.setConRyokinhyoSettei(new ArrayList<>());
        form.getConRyokinhyoSettei().add("0");
        // 前回検索パラメータ[デフォルトのみ  = 0]
        form.setConDefaultNomi(new ArrayList<>());
        form.getConDefaultNomi().add("0");
        //仕入先名称 = null  
        form.setConSiiresakiMeisho("ConSiiresakiMeisho");
        //仕入先略称 = null 
        form.setConSiiresakiRyakusho("ConSiiresakiRyakusho1");
        
        target.setMst271Form(form);
        target.getRecordCount();
        
        //実施結果Outを取得
        form = target.getMst271Form();
        assertEquals("conDairiten1",paramsCaptor_1.getValue().get("conDairiten"));
        assertEquals("mst271_kensu",functionCodeCaptor_2.getValue());
        // 実行時に渡すパラメータの検証
        assertEquals("1", form.getConGyoshaKbn());
        
    }
    
    // clear_正常_クリア処理_3-1
    //
    // -------------------テスト条件--------------------------
    // 検索条件と検索結果がある
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_1 () throws IllegalAccessException, InvocationTargetException, SystemException {

         // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 0; i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // テスト実行
        Mst271Form form = new Mst271Form();
        //[業者区分 = 1]
        form.setConGyoshaKbn("1");
        //代理店
        AutoCompOptionBean conDairiten = new AutoCompOptionBean();
        conDairiten.setValue("conDairiten1");
        form.setConDairiten(conDairiten);
        //管轄営業所
        AutoCompOptionBean conKankatsuEigyosho = new AutoCompOptionBean();
        conKankatsuEigyosho.setValue("conKankatsuEigyosho1");
        form.setConKankatsuEigyosho(conKankatsuEigyosho);
        //仕入先
        AutoCompOptionBean conSiiresaki = new AutoCompOptionBean();
        conSiiresaki.setValue("conSiiresaki1");
        form.setConSiiresaki(conSiiresaki);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        //会社名
        AutoCompOptionBean conKaishaMei = new AutoCompOptionBean();
        conKaishaMei.setValue("conKaishaMei1");
        form.setConKaishaMei(conKaishaMei);
        //支店/営業所
        AutoCompOptionBean conSitenEigyosho = new AutoCompOptionBean();
        conSitenEigyosho.setValue("conSitenEigyosho1");
        form.setConSitenEigyosho(conSitenEigyosho);
        //伝票種別コード
        AutoCompOptionBean conDempyoShubetu1 = new AutoCompOptionBean();
        conDempyoShubetu1.setValue("conDempyoShubetu1");
        form.setConDempyoShubetu1(conDempyoShubetu1);
        // 前回検索パラメータ[適用日指定 = 2019/01/02]
        form.setConTekiyoHi("Wed Jan 02 00:00:00 CST 2019");
        // 前回検索パラメータ[削除済のみ = 0]
        form.setConSakujoSumiNomi(new ArrayList<>());
        form.getConSakujoSumiNomi().add("0");
        // 前回検索パラメータ[料金表設定 = 0]
        form.setConRyokinhyoSettei(new ArrayList<>());
        form.getConRyokinhyoSettei().add("0");
        // 前回検索パラメータ[デフォルトのみ  = 0]
        form.setConDefaultNomi(new ArrayList<>());
        form.getConDefaultNomi().add("0");
        //仕入先名称 = null  
        form.setConSiiresakiMeisho("ConSiiresakiMeisho");
        //仕入先略称 = null 
        form.setConSiiresakiRyakusho("ConSiiresakiRyakusho1");

        target.setMst271Form(form);
        target.clear();

        //実施結果Outを取得
        form = target.getMst271Form();

        //想定通りに正常にClearを実施されること
        assertEquals("1", form.getConGyoshaKbn());
        assertEquals(null,form.getConDairiten());
        assertEquals(null,form.getConKankatsuEigyosho());
        assertEquals(null,form.getConSiiresaki());
        assertEquals(null,form.getConDempyoShubetu());
        //世代検索条件
        assertEquals(null,form.getConDempyoShubetu());
        assertEquals(null,form.getConTekiyoHi());
        assertEquals(null,form.getConSakujoSumiNomi());
        assertEquals(null,form.getConRyokinhyoSettei());
        assertEquals(null,form.getConDefaultNomi());
        assertEquals(null,form.getConKaishaMei());
        assertEquals(null,form.getConSitenEigyosho());
        assertEquals(null,form.getConSiiresakiMeisho());
        assertEquals(null,form.getConSiiresakiRyakusho());
        //検索結果がない
        assertEquals(null,form.getSearchResult());
        assertEquals(null,form.getSearchResultSelectable());
        assertEquals(null,form.getSelectedSearchResult());
    }
    
    // clear_正常_クリア処理_3-2
    //
    // -------------------テスト条件--------------------------
    // 検索条件がある、検索結果がない
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst271Form form = new Mst271Form();
        target.setMst271Form(form);
        target.clear();

        //実施結果Outを取得
        form = target.getMst271Form();

        //想定通りに正常にClearを実施されること
        assertEquals(null,form.getConDairiten());
        assertEquals(null,form.getConKankatsuEigyosho());
        assertEquals(null,form.getConSiiresaki());
        assertEquals(null,form.getConDempyoShubetu());
        //世代検索条件
        assertEquals(null,form.getConDempyoShubetu());
        assertEquals(null,form.getConTekiyoHi());
        assertEquals(null,form.getConSakujoSumiNomi());
        assertEquals(null,form.getConRyokinhyoSettei());
        assertEquals(null,form.getConDefaultNomi());
        assertEquals(null,form.getConKaishaMei());
        assertEquals(null,form.getConSitenEigyosho());
        assertEquals(null,form.getConSiiresakiMeisho());
        assertEquals(null,form.getConSiiresakiRyakusho());
        //検索結果がない
        assertEquals(null,form.getSearchResult());
        assertEquals(null,form.getSearchResultSelectable());
        assertEquals(null,form.getSelectedSearchResult());
    }
    // getHeader_正常_ダウンロード_4-1
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void getHeader_正常_ダウンロード_4_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst271Form form = new Mst271Form();
        form.setConGyoshaKbn("1");
        target.setMst271Form(form);
        List<CSVDto> dto = target.getHeader();
        
        //実施結果Outを取得
        form = target.getMst271Form();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にCVSのHeaderを設定されること
        assertEquals("1", form.getConGyoshaKbn());
        assertEquals("区分",dto.get(0).getTitle());
        assertEquals("listKbnMei",dto.get(0).getName());
        assertEquals("コード",dto.get(1).getTitle());
        assertEquals("listDairitenCd",dto.get(1).getName());
        assertEquals("代理店",dto.get(2).getTitle());
        assertEquals("listDairitenMei",dto.get(2).getName());
        assertEquals("仕入先コード",dto.get(3).getTitle());
        assertEquals("listShiiresakiCd",dto.get(3).getName());
        assertEquals("会社名",dto.get(4).getTitle());
        assertEquals("listKaishaMei",dto.get(4).getName());
        assertEquals("支店/営業所",dto.get(5).getTitle());
        assertEquals("listShitenEigyoshoMei",dto.get(5).getName());
        assertEquals("デフォルト",dto.get(6).getTitle());
        assertEquals("listDefaultFlg",dto.get(6).getName());
        assertEquals("伝票種別",dto.get(7).getTitle());
        assertEquals("listDempyoShubetsuCd",dto.get(7).getName());
        assertEquals("ステータス",dto.get(8).getTitle());
        assertEquals("listStatus",dto.get(8).getName());
        assertEquals("適用開始日",dto.get(9).getTitle());
        assertEquals("listTekiyoKaishibi",dto.get(9).getName());
        assertEquals("適用名",dto.get(10).getTitle());
        assertEquals("listTekiyoMei",dto.get(10).getName());
        assertEquals("代理店中継配達料金表データバージョン",dto.get(11).getTitle());
        assertEquals("listDairitenChukeiHaitatsuRyokinhyoDataVersion",dto.get(11).getName());
    }
    
    // getHeader_正常_ダウンロード_4-1
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void getHeader_正常_ダウンロード_4_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst271Form form = new Mst271Form();
        form.setConGyoshaKbn("2");
        target.setMst271Form(form);
        List<CSVDto> dto = target.getHeader();
        
        //実施結果Outを取得
        form = target.getMst271Form();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にCVSのHeaderを設定されること
        assertEquals("2", form.getConGyoshaKbn());
        assertEquals("区分",dto.get(0).getTitle());
        assertEquals("listKbnMei",dto.get(0).getName());
        assertEquals("コード",dto.get(1).getTitle());
        assertEquals("listEigyoshoCd",dto.get(1).getName());
        assertEquals("営業所",dto.get(2).getTitle());
        assertEquals("listEigyoshoMei",dto.get(2).getName());
        assertEquals("仕入先コード",dto.get(3).getTitle());
        assertEquals("listShiiresakiCd",dto.get(3).getName());
        assertEquals("会社名",dto.get(4).getTitle());
        assertEquals("listKaishaMei",dto.get(4).getName());
        assertEquals("支店/営業所",dto.get(5).getTitle());
        assertEquals("listShitenEigyoshoMei",dto.get(5).getName());
        assertEquals("デフォルト",dto.get(6).getTitle());
        assertEquals("listDefaultFlg",dto.get(6).getName());
        assertEquals("伝票種別",dto.get(7).getTitle());
        assertEquals("listDempyoShubetsuCd",dto.get(7).getName());
        assertEquals("ステータス",dto.get(8).getTitle());
        assertEquals("listStatus",dto.get(8).getName());
        assertEquals("適用開始日",dto.get(9).getTitle());
        assertEquals("listTekiyoKaishibi",dto.get(9).getName());
        assertEquals("適用名",dto.get(10).getTitle());
        assertEquals("listTekiyoMei",dto.get(10).getName());
        assertEquals("代理店中継配達料金表データバージョン",dto.get(11).getTitle());
        assertEquals("listDairitenChukeiHaitatsuRyokinhyoDataVersion",dto.get(11).getName());
    }
    
    // beforeDown_正常_ダウンロード_4-2
    //
    // -------------------テスト条件--------------------------
    // 
    // -----------------------------------------------------
    @Test
    public void beforeDown_正常_ダウンロード_4_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst271Form form = new Mst271Form();
        target.setMst271Form(form);
        try {
            target.beforeDown("testComment");
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(Mst271BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        //実施結果Outを取得
        form = target.getMst271Form();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にダウンロード理由を記録すること
    } 
    
    // change_正常_項目表示切替_10_1
    //
    // -------------------テスト条件--------------------------
    // 項目表示切替
    // -----------------------------------------------------
    @Test
    public void change_正常_項目表示切替_10_1 () throws IllegalAccessException, InvocationTargetException,SystemException {

         // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 0; i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // テスト実行
        Mst271Form form = new Mst271Form();
        //代理店
        AutoCompOptionBean conDairiten = new AutoCompOptionBean();
        conDairiten.setValue("conDairiten1");
        form.setConDairiten(conDairiten);
        //管轄営業所
        AutoCompOptionBean conKankatsuEigyosho = new AutoCompOptionBean();
        conKankatsuEigyosho.setValue("conKankatsuEigyosho1");
        form.setConKankatsuEigyosho(conKankatsuEigyosho);
        //仕入先
        AutoCompOptionBean conSiiresaki = new AutoCompOptionBean();
        conSiiresaki.setValue("conSiiresaki1");
        form.setConSiiresaki(conSiiresaki);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        //会社名
        AutoCompOptionBean conKaishaMei = new AutoCompOptionBean();
        conKaishaMei.setValue("conKaishaMei1");
        form.setConKaishaMei(conKaishaMei);
        //支店/営業所
        AutoCompOptionBean conSitenEigyosho = new AutoCompOptionBean();
        conSitenEigyosho.setValue("conSitenEigyosho1");
        form.setConSitenEigyosho(conSitenEigyosho);
        //伝票種別コード
        AutoCompOptionBean conDempyoShubetu1 = new AutoCompOptionBean();
        conDempyoShubetu1.setValue("conDempyoShubetu1");
        form.setConDempyoShubetu(conDempyoShubetu1);
        //業者区分(代理店)
        form.setConGyoshaKbn("1");
        // 前回検索パラメータ[適用日指定 = 2019/01/02]
        form.setConTekiyoHi("Wed Jan 02 00:00:00 CST 2019");
        // 前回検索パラメータ[削除済のみ = 0]
        form.setConSakujoSumiNomi(new ArrayList<>());
        form.getConSakujoSumiNomi().add("0");
        // 前回検索パラメータ[料金表設定 = 0]
        form.setConRyokinhyoSettei(new ArrayList<>());
        form.getConRyokinhyoSettei().add("0");
        // 前回検索パラメータ[デフォルトのみ  = 0]
        form.setConDefaultNomi(new ArrayList<>());
        form.getConDefaultNomi().add("0");
        //仕入先名称 = null  
        form.setConSiiresakiMeisho("ConSiiresakiMeisho1");
        //仕入先略称 = null 
        form.setConSiiresakiRyakusho("ConSiiresakiRyakusho1");
        
        target.setMst271Form(form);
        target.change();
        //実施結果Outを取得
        form = target.getMst271Form();

        //想定通りに正常にダウンロード理由を記録すること
        assertEquals(null,form.getConDairiten());
        assertEquals(null,form.getConKankatsuEigyosho());
        assertEquals(null,form.getConSiiresaki());
        assertEquals(null,form.getConDempyoShubetu());
        //世代検索条件
        assertEquals(null,form.getConDempyoShubetu());
        assertEquals(null,form.getConTekiyoHi());
        assertEquals(null,form.getConSakujoSumiNomi());
        assertEquals(null,form.getConRyokinhyoSettei());
        assertEquals(null,form.getConDefaultNomi());
        assertEquals(null,form.getConKaishaMei());
        assertEquals(null,form.getConSitenEigyosho());
        assertEquals(null,form.getConSiiresakiMeisho());
        assertEquals(null,form.getConSiiresakiRyakusho());
        //検索結果がない
        assertEquals(null,form.getSearchResult());
        assertEquals(null,form.getSearchResultSelectable());
        assertEquals(null,form.getSelectedSearchResult());
    } 
    
    // 更新履歴を表示コンテキストメニュー
    //
    // -------------------テスト条件--------------------------
    // 正常に取得された場合
    // -----------------------------------------------------
    @Test
    public void rirekiIchiran_正常_更新履歴_17_1 () throws IllegalAccessException, InvocationTargetException, SystemException {
        // パラメータキャプチャー
        ArgumentCaptor<String> titleFlgCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> searchKeyCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(rirekiSyosai).searchList(titleFlgCaptor_1.capture(),functionCodeCaptor_2.capture()
                ,searchKeyCaptor_3.capture());
        //テスト実行
        Mst271Form form = new Mst271Form();
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_17_1(i));
        }
        //代理店
        AutoCompOptionBean conDairiten = new AutoCompOptionBean();
        conDairiten.setValue("conDairiten1");
        form.setConDairiten(conDairiten);
        //管轄営業所
        AutoCompOptionBean conKankatsuEigyosho = new AutoCompOptionBean();
        conKankatsuEigyosho.setValue("conKankatsuEigyosho1");
        form.setConKankatsuEigyosho(conKankatsuEigyosho);
        //仕入先
        AutoCompOptionBean conSiiresaki = new AutoCompOptionBean();
        conSiiresaki.setValue("conSiiresaki1");
        form.setConSiiresaki(conSiiresaki);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        //会社名
        AutoCompOptionBean conKaishaMei = new AutoCompOptionBean();
        conKaishaMei.setValue("conKaishaMei1");
        form.setConKaishaMei(conKaishaMei);
        //支店/営業所
        AutoCompOptionBean conSitenEigyosho = new AutoCompOptionBean();
        conSitenEigyosho.setValue("conSitenEigyosho1");
        form.setConSitenEigyosho(conSitenEigyosho);
        //伝票種別コード
        AutoCompOptionBean conDempyoShubetu1 = new AutoCompOptionBean();
        conDempyoShubetu1.setValue("conDempyoShubetu1");
        form.setConDempyoShubetu1(conDempyoShubetu1);
        //業者区分(代理店)
        form.setConGyoshaKbn("1");
        // 前回検索パラメータ[適用日指定 = 2019/01/02]
        form.setConTekiyoHi("Wed Jan 02 00:00:00 CST 2019");
        // 前回検索パラメータ[削除済のみ = 0]
        form.setConSakujoSumiNomi(new ArrayList<>());
        form.getConSakujoSumiNomi().add("0");
        // 前回検索パラメータ[料金表設定 = 0]
        form.setConRyokinhyoSettei(new ArrayList<>());
        form.getConRyokinhyoSettei().add("0");
        // 前回検索パラメータ[デフォルトのみ  = 0]
        form.setConDefaultNomi(new ArrayList<>());
        form.getConDefaultNomi().add("0");
        //仕入先名称 = null  
        form.setConSiiresakiMeisho("ConSiiresakiMeisho1");
        //仕入先略称 = null 
        form.setConSiiresakiRyakusho("ConSiiresakiRyakusho1");
        
        form.setSelectedSearchResult(result);
        target.setMst271Form(form);
        target.rirekiIchiran();

        //実施結果Outを取得
        form = target.getMst271Form();

        //想定通りに履歴を表示する。
       assertEquals("2",titleFlgCaptor_1.getValue());
       assertEquals("MST271_SEARCH_RIREKI",functionCodeCaptor_2.getValue());
       assertEquals("1",searchKeyCaptor_3.getValue().get("listKbnCd"));
       assertEquals("listShiiresakiCd0",searchKeyCaptor_3.getValue().get("conSiiresakiCd"));
       assertEquals("listDairitenCd0",searchKeyCaptor_3.getValue().get("conKankatsuEigyoshoCd"));
       assertEquals("listDempyoShubetsuCd0",searchKeyCaptor_3.getValue().get("conDempyoShubetuCd"));
    }
    
    // create_正常_新規登録_18_1
    //
    // -------------------テスト条件--------------------------
    // 
    // -----------------------------------------------------
    //@Test
    public void create_正常_新規登録_18_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst271Form form = new Mst271Form();
        
        target.setMst271Form(form);
        target.create();

        //実施結果Outを取得
        form = target.getMst271Form();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にダウンロード理由を記録すること
    } 
    
    // copy_正常_複製登録ボタン_19_1
    //
    // -------------------テスト条件--------------------------
    // 行選択 = 1
    // -----------------------------------------------------
    @Test
    public void copy_正常_複製登録ボタン_19_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst271Form form = new Mst271Form();
        Map map = new HashMap();
        List<Map<String, String>> list = new ArrayList<>();
        //行選択 = 1
        map.put("key1", "value1");
        form.setSelectedSearchResult(list);
        // 前回検索パラメータ[料金表設定 = 0]
        form.setConRyokinhyoSettei(new ArrayList<>());
        form.getConRyokinhyoSettei().add("0");
        
        target.setMst271Form(form);
        target.copy();

        //実施結果Outを取得
        form = target.getMst271Form();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にダウンロード理由を記録すること
    } 
    
    // copy_異常_複製登録ボタン_19_2
    //
    // -------------------テスト条件--------------------------
    // 行選択 = 2
    // -----------------------------------------------------
    @Test
    public void copy_異常_複製登録ボタン_19_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst271Form form = new Mst271Form();
        Map map1 = new HashMap();
        Map map2 = new HashMap();
        List<Map<String, String>> list = new ArrayList<>();
        //行選択 = 2
        map1.put("key1", "value1");
        map2.put("key2", "value2");
        list.add(map1);
        list.add(map2);
        form.setSelectedSearchResult(list);
        // 前回検索パラメータ[料金表設定 = 0]
        form.setConRyokinhyoSettei(new ArrayList<>());
        form.getConRyokinhyoSettei().add("0");
        
        target.setMst271Form(form);
        target.copy();

        //実施結果Outを取得
        form = target.getMst271Form();

    } 
    
    // copy_異常_複製登録ボタン_19_3
    //
    // -------------------テスト条件--------------------------
    // 行選択 = 0
    // -----------------------------------------------------
    @Test
    public void copy_異常_複製登録ボタン_19_3 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst271Form form = new Mst271Form();
        Map map1 = new HashMap();
        Map map2 = new HashMap();
        List<Map<String, String>> list = new ArrayList<>();
        //行選択 = 0
        form.setSelectedSearchResult(list);
        // 前回検索パラメータ[料金表設定 = 0]
        form.setConRyokinhyoSettei(new ArrayList<>());
        form.getConRyokinhyoSettei().add("0");
        
        target.setMst271Form(form);
        target.copy();

        //実施結果Outを取得
        form = target.getMst271Form();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にダウンロード理由を記録すること
    } 
    
    // details_正常_詳細ボタン_20_1
    //
    // -------------------テスト条件--------------------------
    // 行選択 = 1
    // -----------------------------------------------------
    @Test
    public void details_正常_詳細ボタン_20_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst271Form form = new Mst271Form();
        Map map = new HashMap();
        List<Map<String, String>> list = new ArrayList<>();
        //行選択 = 1
        map.put("key1", "value1");
        form.setSelectedSearchResult(list);
        // 前回検索パラメータ[料金表設定 = 0]
        form.setConRyokinhyoSettei(new ArrayList<>());
        form.getConRyokinhyoSettei().add("0");
        
        target.setMst271Form(form);
        target.copy();

        //実施結果Outを取得
        form = target.getMst271Form();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にダウンロード理由を記録すること
    } 
    
    // details_異常_詳細ボタン_20_2
    //
    // -------------------テスト条件--------------------------
    // 行選択 = 2
    // -----------------------------------------------------
    @Test
    public void details_異常_詳細ボタン_20_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst271Form form = new Mst271Form();
        Map map1 = new HashMap();
        Map map2 = new HashMap();
        List<Map<String, String>> list = new ArrayList<>();
        //行選択 = 2
        map1.put("key1", "value1");
        map2.put("key2", "value2");
        list.add(map1);
        list.add(map2);
        form.setSelectedSearchResult(list);
        // 前回検索パラメータ[料金表設定 = 0]
        form.setConRyokinhyoSettei(new ArrayList<>());
        form.getConRyokinhyoSettei().add("0");
        
        target.setMst271Form(form);
        target.copy();

        //実施結果Outを取得
        form = target.getMst271Form();

    } 
    
    // details_異常_詳細ボタン_20_3
    //
    // -------------------テスト条件--------------------------
    // 行選択 = 0
    // -----------------------------------------------------
    @Test
    public void details_異常_詳細ボタン_20_3 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst271Form form = new Mst271Form();
        Map map1 = new HashMap();
        Map map2 = new HashMap();
        List<Map<String, String>> list = new ArrayList<>();
        //行選択 = 0
        form.setSelectedSearchResult(list);
        // 前回検索パラメータ[料金表設定 = 0]
        form.setConRyokinhyoSettei(new ArrayList<>());
        form.getConRyokinhyoSettei().add("0");
        
        target.setMst271Form(form);
        target.copy();

        //実施結果Outを取得
        form = target.getMst271Form();

    } 
    
    // details_正常_詳細コンテキストメニュー_21_1
    //
    // -------------------テスト条件--------------------------
    // 行選択 = 1
    // -----------------------------------------------------
    @Test
    public void details_正常_詳細コンテキストメニュー_21_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst271Form form = new Mst271Form();
        Map map = new HashMap();
        List<Map<String, String>> list = new ArrayList<>();
        //行選択 = 1
        map.put("key1", "value1");
        form.setSelectedSearchResult(list);
        // 前回検索パラメータ[料金表設定 = 0]
        form.setConRyokinhyoSettei(new ArrayList<>());
        form.getConRyokinhyoSettei().add("0");
        
        target.setMst271Form(form);
        target.copy();

        //実施結果Outを取得
        form = target.getMst271Form();
    } 
    
    // details_異常_詳細コンテキストメニュー_21_2
    //
    // -------------------テスト条件--------------------------
    // 行選択 = 2
    // -----------------------------------------------------
    @Test
    public void details_異常_詳細コンテキストメニュー_21_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst271Form form = new Mst271Form();
        Map map1 = new HashMap();
        Map map2 = new HashMap();
        List<Map<String, String>> list = new ArrayList<>();
        //行選択 = 2
        map1.put("key1", "value1");
        map2.put("key2", "value2");
        list.add(map1);
        list.add(map2);
        form.setSelectedSearchResult(list);
        // 前回検索パラメータ[料金表設定 = 0]
        form.setConRyokinhyoSettei(new ArrayList<>());
        form.getConRyokinhyoSettei().add("0");
        
        target.setMst271Form(form);
        target.copy();

        //実施結果Outを取得
        form = target.getMst271Form();
    } 
    
    // details_異常_詳細コンテキストメニュー_21_3
    //
    // -------------------テスト条件--------------------------
    // 行選択 = 0
    // -----------------------------------------------------
    @Test
    public void details_異常_詳細コンテキストメニュー_21_3 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst271Form form = new Mst271Form();
        Map map1 = new HashMap();
        Map map2 = new HashMap();
        List<Map<String, String>> list = new ArrayList<>();
        //行選択 = 0
        form.setSelectedSearchResult(list);
        // 前回検索パラメータ[料金表設定 = 0]
        form.setConRyokinhyoSettei(new ArrayList<>());
        form.getConRyokinhyoSettei().add("0");
        
        target.setMst271Form(form);
        target.copy();

        //実施結果Outを取得
        form = target.getMst271Form();
    } 
    
    private Map<String, String> createRecMapFor_1_1(int i) {
        Map recMap = new HashMap();
        //区分
        recMap.put("listKbnMei", "代理店" + i);
        //代理店.コード
        recMap.put("listDairitenCd", "listDairitenCd" + i);
        //営業所.コード
        recMap.put("listEigyoshoCd", "listEigyoshoCd" + i);
        //代理店
        recMap.put("listDairitenMei", "listDairitenMei" + i);
        //営業所
        recMap.put("listEigyoshoMei", "listEigyoshoMei" + i);
        //仕入先コード
        recMap.put("listShiiresakiCd", "listShiiresakiCd" + i);
        //会社名
        recMap.put("listKaishaMei", "listKaishaMei" + i);
        //支店/営業所
        recMap.put("listShitenEigyoshoMei", "listShitenEigyoshoMei" + i);
        //デフォルト
        recMap.put("listDefaultFlg", "listDefaultFlg" + i);
        //伝票種別
        recMap.put("listDefaultDempyoShubetsuCd", "listDefaultDempyoShubetsuCd" + i);
        //ステータス
        recMap.put("listStatus", "listStatus" + i);
        //適用開始日
        recMap.put("listTekiyoKaishibi", "listTekiyoKaishibi" + i);
        //適用名
        recMap.put("listTekiyoMei", "listTekiyoMei" + i);
        //代理店中継配達料金表データバージョン
        recMap.put("listdairitenChukeiHaitatsuRyokinhyoDataVersion", "listdairitenChukeiHaitatsuRyokinhyoDataVersion" + i);
        return recMap;
    }
    
    private void assertForRecList_2_3(int count, Mst271Form form) {
        int i = 1;
        assertEquals(count, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            //区分
            assertEquals("代理店"  + i, rec.get("listKbnMei"));
            //業者区分 = 1
            if ("1".equals(form.getConGyoshaKbn())) {
                //代理店.コード
                assertEquals("listDairitenCd" + i, rec.get("listDairitenCd"));
                //代理店
                assertEquals("listDairitenMei" + i, rec.get("listDairitenMei"));
            } else {
                //営業所.コード
                assertEquals("listEigyoshoCd" + i, rec.get("listEigyoshoCd"));
                //営業所
                assertEquals("listEigyoshoMei" + i, rec.get("listEigyoshoMei"));
            }
            //仕入先コード
            assertEquals("listShiiresakiCd" + i, rec.get("listShiiresakiCd"));
            //会社名
            assertEquals("listKaishaMei" + i, rec.get("listKaishaMei"));
            //支店/営業所
            assertEquals("listShitenEigyoshoMei" + i, rec.get("listShitenEigyoshoMei"));
            //デフォルト
            assertEquals("listDefaultFlg" + i, rec.get("listDefaultFlg"));
            //伝票種別
            assertEquals("listDefaultDempyoShubetsuCd" + i, rec.get("listDefaultDempyoShubetsuCd"));
            //ステータス
            assertEquals("listStatus" + i, rec.get("listStatus"));
            //適用開始日
            assertEquals("listTekiyoKaishibi" + i, rec.get("listTekiyoKaishibi"));
            //適用名
            assertEquals("listTekiyoMei" + i, rec.get("listTekiyoMei"));
            //代理店中継配達料金表データバージョン
            assertEquals("listdairitenChukeiHaitatsuRyokinhyoDataVersion" + i, rec.get("listdairitenChukeiHaitatsuRyokinhyoDataVersion"));
            i++;
        }
    }
    private void assertForRecList_17_1(Mst271Form form) {
        int i = 1;
        assertEquals(0, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            //区分
            assertEquals("listKbnMei"  + i, rec.get("listKbnMei"));
            //業者区分 = 1
            if ("1".equals(form.getConGyoshaKbn())) {
                //代理店.コード
                assertEquals("listDairitenCd" + i, rec.get("listDairitenCd"));
                //代理店
                assertEquals("listDairitenMei" + i, rec.get("listDairitenMei"));
            } else {
                //営業所.コード
                assertEquals("listEigyoshoCd" + i, rec.get("listEigyoshoCd"));
                //営業所
                assertEquals("listEigyoshoMei" + i, rec.get("listEigyoshoMei"));
            }
            //仕入先コード
            assertEquals("listShiiresakiCd" + i, rec.get("listShiiresakiCd"));
            //会社名
            assertEquals("listKaishaMei" + i, rec.get("listKaishaMei"));
            //支店/営業所
            assertEquals("listShitenEigyoshoMei" + i, rec.get("listShitenEigyoshoMei"));
            //デフォルト
            assertEquals("listDefaultFlg" + i, rec.get("listDefaultFlg"));
            //伝票種別
            assertEquals("listDefaultDempyoShubetsuCd" + i, rec.get("listDefaultDempyoShubetsuCd"));
            //ステータス
            assertEquals("listStatus" + i, rec.get("listStatus"));
            //適用開始日
            assertEquals("listTekiyoKaishibi" + i, rec.get("listTekiyoKaishibi"));
            //適用名
            assertEquals("listTekiyoMei" + i, rec.get("listTekiyoMei"));
            //代理店中継配達料金表データバージョン
            assertEquals("listdairitenChukeiHaitatsuRyokinhyoDataVersion" + i, rec.get("listdairitenChukeiHaitatsuRyokinhyoDataVersion"));
            i++;
        }
    }
    
    private Map<String, String> createRecMapFor_17_1(int i) {
        Map recMap = new HashMap();
        recMap.put("listKbnMei", "listKbnMei" + i);
        //業者区分 = 1
        recMap.put("listDairitenCd", "listDairitenCd" + i);
        recMap.put("listDairitenMei", "listDairitenMei" + i);
        //業者区分 = 2
        recMap.put("listEigyoshoCd", "listEigyoshoCd" + i);
        recMap.put("listEigyoshoMei", "listEigyoshoMei" + i);
        
        recMap.put("listShiiresakiCd", "listShiiresakiCd" + i);
        recMap.put("listKaishaMei", "listKaishaMei" + i);
        recMap.put("listShitenEigyoshoMei", "listShitenEigyoshoMei" + i);
        recMap.put("listDefaultFlg", "listDefaultFlg" + i);
        recMap.put("listDempyoShubetsuCd", "listDempyoShubetsuCd" + i);
        recMap.put("listStatus", "listStatus" + i);
        recMap.put("listTekiyoKaishibi", "2019-01-05 00:00:00.0");
        recMap.put("listTekiyoMei", "listTekiyoMei" + i);
        recMap.put("listdairitenChukeiHaitatsuRyokinhyoDataVersion", "listdairitenChukeiHaitatsuRyokinhyoDataVersion" + i);
        recMap.put("listKoshinCounter", "listKoshinCounter" + i);
        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }
}
