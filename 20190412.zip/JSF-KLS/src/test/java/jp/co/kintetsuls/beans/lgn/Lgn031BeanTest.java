package jp.co.kintetsuls.beans.lgn;

import java.io.IOException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import jp.co.kintetsuls.beans.common.DirContextBean;
import jp.co.kintetsuls.beans.common.KbnBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.SystemMasterBean;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.forms.lgn.Lgn031Form;
import jp.co.kintetsuls.utils.DateUtils;
import jp.co.kintetsuls.utils.FlashUtil;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import org.mockito.Mockito;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * ルートマスタ画面
 *
 * @author 黄義輝 (MBP)
 * @version 2019/03/25 新規作成
 */
public class Lgn031BeanTest {

    // テストTarget
    @InjectMocks
    private Lgn031Bean target;

    // Mockitoオブジェクト
    @Mock
    private SystemMasterBean systemMasterBean;       
    @Mock
    private MessagePropertyBean messagePropertyBean;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private PageCommonBean pageCommonBean1;
    @Mock
    private KbnBean kbnBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private DirContextBean dirContextBean;
    @Mock
    private FlashUtil flashUtil;
    @Mock
    private AuthorityConfBean authorityConfBean;

    public Lgn031BeanTest() {
    }

    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() {
    }

    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 戻ってきた場合前画面情報[not null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1 () throws IllegalAccessException, InvocationTargetException {

        ArgumentCaptor<String> paramString_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_5 = ArgumentCaptor.forClass(String.class);
        
        ArgumentCaptor<Map> paramMap_6 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> paramString_7 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_8 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_9 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_10 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> paramMap_11 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> paramString_12 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_13 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_14 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<BaseBean> paramBaseBean_15 = ArgumentCaptor.forClass(BaseBean.class);
        
        ArgumentCaptor<Object> paramString_16 = ArgumentCaptor.forClass(Object.class);
        ArgumentCaptor<String> paramString_17 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Boolean> paramString_18 = ArgumentCaptor.forClass(Boolean.class);

        // パンくず追加
        doNothing().when(breadBean).push(paramString_13.capture(), paramString_14.capture(), paramBaseBean_15.capture());
    
        // システムマスタ取得
        when(systemMasterBean.getSysValByCdAndKanriGroup(paramString_1.capture(), paramString_4.capture(),
                paramString_5.capture())).thenReturn("1");
        
        // システムマスタからパスワード誤入力最大回数取得
        when(systemMasterBean.getSysValByCdAndKanriGroup(paramString_2.capture(), paramString_4.capture(),
                paramString_5.capture())).thenReturn("2");
        
        // メールアドレス不一致最大回数
        when(systemMasterBean.getSysValByCdAndKanriGroup(paramString_3.capture(), paramString_4.capture(),
                paramString_5.capture())).thenReturn("1");

        // 承認者情報の取得
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        List<Map<String,Object>> shoninshaInfoList = new ArrayList();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(shoninshaInfoList));

        // 戻ってきた場合
        when(pageCommonBean.getDBInfo(paramMap_6.capture(), paramString_7.capture())).thenReturn(serviceInterfaceBean);

        Lgn031Form preForm = new Lgn031Form();
        
        when(pageCommonBean.getPageInfo(paramString_8.capture())).thenReturn(preForm);
        when(kbnBean.getKbnMeiOfKeyCd(paramString_9.capture())).thenReturn("Axis処理");
        when(kbnBean.getKbnMeiOfKeyCd(paramString_10.capture())).thenReturn("自動実行");

        ServiceInterfaceBean serviceInterfaceBean1 = new ServiceInterfaceBean();

        Map paraMap = new HashMap();
        List<Map<String, String>> getShinseiInfoList = new ArrayList<>();
        getShinseiInfoList.add(createRecMapFor_1_1(1));
        // 申請情報取得
        paraMap.put("getShinseiInfoList", getShinseiInfoList);
        List<Map<String, String>> getSyouninJyoukyouList = new ArrayList<>();
        // 承認状況取得
        paraMap.put("getSyouninJyoukyouList", getSyouninJyoukyouList);
        
        serviceInterfaceBean1.setJson(JSONUtil.makeJSONString(paraMap));
        when(pageCommonBean1.getDBInfo(paramMap_11.capture(), paramString_12.capture())).thenReturn(serviceInterfaceBean1);

        doNothing().when(pageCommonBean).setAuthControll(paramString_16.capture(),
        paramString_17.capture(), paramString_18.capture());

        //テスト実行
        Lgn031Form lgn031Form = new Lgn031Form();
        target.setLgn031Form(lgn031Form);

        // 戻ってきた場合、再検索を実施する。
        target.init("", "LGN031_SCREEN", true);
    
    }

    // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 進んできた場合前画面情報[前画面情報.prevScreen = Lgn011]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2 () throws IllegalAccessException, InvocationTargetException {

        ArgumentCaptor<String> paramString_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_5 = ArgumentCaptor.forClass(String.class);
        
        ArgumentCaptor<Map> paramMap_6 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> paramString_7 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_8 = ArgumentCaptor.forClass(String.class);

        ArgumentCaptor<String> paramString_9 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_10 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Boolean> paramBoolean_11 = ArgumentCaptor.forClass(Boolean.class);
        ArgumentCaptor<String> paramString_13 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_14 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<BaseBean> paramBaseBean_15 = ArgumentCaptor.forClass(BaseBean.class);

        // パンくず追加
        doNothing().when(breadBean).push(paramString_13.capture(), paramString_14.capture(), paramBaseBean_15.capture());
    
        // システムマスタ取得
        when(systemMasterBean.getSysValByCdAndKanriGroup(paramString_1.capture(), paramString_4.capture(),
                paramString_5.capture())).thenReturn("1");
        
        // システムマスタからパスワード誤入力最大回数取得
        when(systemMasterBean.getSysValByCdAndKanriGroup(paramString_2.capture(), paramString_4.capture(),
                paramString_5.capture())).thenReturn("2");
        
        // メールアドレス不一致最大回数
        when(systemMasterBean.getSysValByCdAndKanriGroup(paramString_3.capture(), paramString_4.capture(),
                paramString_5.capture())).thenReturn("1");

        // 承認者情報の取得
        doThrow(IOException.class).when(pageCommonBean).getDBInfo(paramMap_6.capture(), paramString_7.capture());

        // 進んできた場合
        Lgn031Form preForm = new Lgn031Form();
        when(pageCommonBean.getPageInfo(paramString_8.capture())).thenReturn(preForm);

        // component初期化とユーザ権限により制御設定
        doNothing().when(pageCommonBean).setAuthControll(paramString_9.capture(),
                paramString_10.capture(), paramBoolean_11.capture());

        //テスト実行
        Lgn031Form lgn031Form = new Lgn031Form();
        
        List<Map<String,Object>> shoninshaInfoList = new ArrayList();
        Map<String, Object> shoninshaInfoMap = new HashMap();
        shoninshaInfoMap.put("saishuShoninShaFlg", "1");
        
        shoninshaInfoList.add(shoninshaInfoMap);
        lgn031Form.setShoninshaInfoList(shoninshaInfoList);

        target.setLgn031Form(lgn031Form);

        // 戻ってきた場合、再検索を実施する。
        target.init("", "LGN011_SCREEN", false);
    
    }

    // init_正常_初期処理_1-3
    //
    // -------------------テスト条件--------------------------
    // 進んできた場合前画面情報[ 前画面情報.prevScreen = Dem011, 申請ステータスが"承認済"の場合(04)]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3 () throws IllegalAccessException, InvocationTargetException {

        ArgumentCaptor<String> paramString_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_5 = ArgumentCaptor.forClass(String.class);
        
        ArgumentCaptor<Map> paramMap_6 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> paramString_7 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_8 = ArgumentCaptor.forClass(String.class);

        ArgumentCaptor<String> paramString_9 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_10 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Boolean> paramBoolean_11 = ArgumentCaptor.forClass(Boolean.class);
        ArgumentCaptor<String> paramString_13 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_14 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<BaseBean> paramBaseBean_15 = ArgumentCaptor.forClass(BaseBean.class);

        // パンくず追加
        doNothing().when(breadBean).push(paramString_13.capture(), paramString_14.capture(), paramBaseBean_15.capture());
    
        // システムマスタ取得
        when(systemMasterBean.getSysValByCdAndKanriGroup(paramString_1.capture(), paramString_4.capture(),
                paramString_5.capture())).thenReturn("1");
        
        // システムマスタからパスワード誤入力最大回数取得
        when(systemMasterBean.getSysValByCdAndKanriGroup(paramString_2.capture(), paramString_4.capture(),
                paramString_5.capture())).thenReturn("2");
        
        // メールアドレス不一致最大回数
        when(systemMasterBean.getSysValByCdAndKanriGroup(paramString_3.capture(), paramString_4.capture(),
                paramString_5.capture())).thenReturn("1");

        // 承認者情報の取得
        doThrow(IOException.class).when(pageCommonBean).getDBInfo(paramMap_6.capture(), paramString_7.capture());

        // 進んできた場合
        Lgn031Form preForm = new Lgn031Form();
        when(pageCommonBean.getPageInfo(paramString_8.capture())).thenReturn(preForm);

        Flash flash = new FlashKls();
        flash.put("shinseiId", "shinseiId1");
        flash.put("shinseiStatus", "04");

        when(pageCommonBean.getPageParam()).thenReturn(flash);

        // component初期化とユーザ権限により制御設定
        doNothing().when(pageCommonBean).setAuthControll(paramString_9.capture(),
                paramString_10.capture(), paramBoolean_11.capture());

        //テスト実行
        Lgn031Form lgn031Form = new Lgn031Form();
        
        List<Map<String,Object>> shoninshaInfoList = new ArrayList();
        Map<String, Object> shoninshaInfoMap = new HashMap();
        shoninshaInfoMap.put("saishuShoninShaFlg", "1");
        
        shoninshaInfoList.add(shoninshaInfoMap);
        lgn031Form.setShoninshaInfoList(shoninshaInfoList);

        target.setLgn031Form(lgn031Form);

        // 戻ってきた場合、再検索を実施する。
        target.init(null, "DEM011_SCREEN", false);
    
    }

    // init_異常_初期処理_1-4
    //
    // -------------------テスト条件--------------------------
    // 進んできた場合前画面情報[ 前画面情報.prevScreen = Dem011, 申請ステータスが"承認済"以外の場合(03)]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_異常_初期処理_1_4 () throws IllegalAccessException, InvocationTargetException {

        ArgumentCaptor<String> paramString_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_5 = ArgumentCaptor.forClass(String.class);
        
        ArgumentCaptor<Map> paramMap_6 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> paramString_7 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_8 = ArgumentCaptor.forClass(String.class);

        ArgumentCaptor<String> paramString_9 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_10 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Boolean> paramBoolean_11 = ArgumentCaptor.forClass(Boolean.class);
        ArgumentCaptor<String> paramString_13 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_14 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<BaseBean> paramBaseBean_15 = ArgumentCaptor.forClass(BaseBean.class);

        // パンくず追加
        doNothing().when(breadBean).push(paramString_13.capture(), paramString_14.capture(), paramBaseBean_15.capture());
    
        // システムマスタ取得
        when(systemMasterBean.getSysValByCdAndKanriGroup(paramString_1.capture(), paramString_4.capture(),
                paramString_5.capture())).thenReturn("1");
        
        // システムマスタからパスワード誤入力最大回数取得
        when(systemMasterBean.getSysValByCdAndKanriGroup(paramString_2.capture(), paramString_4.capture(),
                paramString_5.capture())).thenReturn("2");
        
        // メールアドレス不一致最大回数
        when(systemMasterBean.getSysValByCdAndKanriGroup(paramString_3.capture(), paramString_4.capture(),
                paramString_5.capture())).thenReturn("1");

        // 承認者情報の取得
        doThrow(IOException.class).when(pageCommonBean).getDBInfo(paramMap_6.capture(), paramString_7.capture());

        // 進んできた場合
        Lgn031Form preForm = new Lgn031Form();
        when(pageCommonBean.getPageInfo(paramString_8.capture())).thenReturn(preForm);

        Flash flash = new FlashKls();
        flash.put("shinseiId", "shinseiId1");
        flash.put("shinseiStatus", "03");

        when(pageCommonBean.getPageParam()).thenReturn(flash);

        // component初期化とユーザ権限により制御設定
        doNothing().when(pageCommonBean).setAuthControll(paramString_9.capture(),
                paramString_10.capture(), paramBoolean_11.capture());

        //テスト実行
        Lgn031Form lgn031Form = new Lgn031Form();
        
        List<Map<String,Object>> shoninshaInfoList = new ArrayList();
        Map<String, Object> shoninshaInfoMap = new HashMap();
        shoninshaInfoMap.put("saishuShoninShaFlg", "1");
        
        shoninshaInfoList.add(shoninshaInfoMap);
        lgn031Form.setShoninshaInfoList(shoninshaInfoList);

        target.setLgn031Form(lgn031Form);

        // 戻ってきた場合、再検索を実施する。
        target.init(null, "DEM011_SCREEN", false);
    
    }

    // init_異常_初期処理_1-5
    //
    // -------------------テスト条件--------------------------
    // 進んできた場合前画面情報[ 前画面情報.prevScreen = Dem011, ログインユーザーが承認者ではない場合]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_異常_初期処理_1_5 () throws IllegalAccessException, InvocationTargetException {

        ArgumentCaptor<String> paramString_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_5 = ArgumentCaptor.forClass(String.class);
        
        ArgumentCaptor<Map> paramMap_6 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> paramString_7 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_8 = ArgumentCaptor.forClass(String.class);

        ArgumentCaptor<String> paramString_9 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_10 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Boolean> paramBoolean_11 = ArgumentCaptor.forClass(Boolean.class);
        ArgumentCaptor<String> paramString_13 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramString_14 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<BaseBean> paramBaseBean_15 = ArgumentCaptor.forClass(BaseBean.class);

        // パンくず追加
        doNothing().when(breadBean).push(paramString_13.capture(), paramString_14.capture(), paramBaseBean_15.capture());
    
        // システムマスタ取得
        when(systemMasterBean.getSysValByCdAndKanriGroup(paramString_1.capture(), paramString_4.capture(),
                paramString_5.capture())).thenReturn("1");
        
        // システムマスタからパスワード誤入力最大回数取得
        when(systemMasterBean.getSysValByCdAndKanriGroup(paramString_2.capture(), paramString_4.capture(),
                paramString_5.capture())).thenReturn("2");
        
        // メールアドレス不一致最大回数
        when(systemMasterBean.getSysValByCdAndKanriGroup(paramString_3.capture(), paramString_4.capture(),
                paramString_5.capture())).thenReturn("1");

        // 承認者情報の取得
        doThrow(IOException.class).when(pageCommonBean).getDBInfo(paramMap_6.capture(), paramString_7.capture());

        // 進んできた場合
        Lgn031Form preForm = new Lgn031Form();
        when(pageCommonBean.getPageInfo(paramString_8.capture())).thenReturn(preForm);

        Flash flash = new FlashKls();
        flash.put("shinseiId", "shinseiId1");
        flash.put("shinseiStatus", "03");

        when(pageCommonBean.getPageParam()).thenReturn(flash);

        // component初期化とユーザ権限により制御設定
        doThrow(IllegalAccessException.class).when(pageCommonBean).setAuthControll(paramString_9.capture(),
                paramString_10.capture(), paramBoolean_11.capture());

        //テスト実行
        Lgn031Form lgn031Form = new Lgn031Form();
        target.setLgn031Form(lgn031Form);

        // 戻ってきた場合、再検索を実施する。
        target.init(null, "DEM011_SCREEN", false);
    
    }

    // doApply_異常_申請処理_2-1_1
    //
    // -------------------テスト条件--------------------------
    // 画面入力項目チェックエラー[ メール、電話のどちらかが選択しません]
    // DBデータ戻り値
    // -----------------------------------------------------  
    @Test
    public void doApply_異常_申請処理_2_1_1(){
         // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
         // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<List> keyCaptor_3 = ArgumentCaptor.forClass(List.class);
        
        Lgn031Form lgn031Form = new Lgn031Form();
        lgn031Form.setHyoDtlTsuchiHoho(null);
        target.setLgn031Form(lgn031Form);
        MessageModuleBean message = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(keyCaptor_1.capture(), keyCaptor_2.capture())).thenReturn(message);
        
        doNothing().when(messagePropertyBean).messageList(keyCaptor_3.capture());
        target.doApply();
    }
    
    // doApply_異常_申請処理_2-1-2
    //
    // -------------------テスト条件--------------------------
    // 画面入力項目チェックエラー[ メールアドレス ワーク.通知方法 = 1(メール)の場合]
    // DBデータ戻り値
    // -----------------------------------------------------  
    @Test
    public void doApply_異常_申請処理_2_1_2(){
         // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
         // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<List> keyCaptor_3 = ArgumentCaptor.forClass(List.class);
        
        Lgn031Form lgn031Form = new Lgn031Form();
        // 通知方法
        lgn031Form.setHyoDtlTsuchiHoho("1");
        target.setLgn031Form(lgn031Form);
        MessageModuleBean message = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(keyCaptor_1.capture(), keyCaptor_2.capture())).thenReturn(message);
        
        doNothing().when(messagePropertyBean).messageList(keyCaptor_3.capture());
        target.doApply();
    }
    
    // doApply_異常_申請処理_2-1-3
    //
    // -------------------テスト条件--------------------------
    // 画面入力項目チェックエラー[ 電話番号 ワーク.通知方法 = 2(電話)の場合]
    // DBデータ戻り値
    // -----------------------------------------------------  
    @Test
    public void doApply_異常_申請処理_2_1_3(){
         // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
         // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<List> keyCaptor_3 = ArgumentCaptor.forClass(List.class);
        
        Lgn031Form lgn031Form = new Lgn031Form();
        // 通知方法
        lgn031Form.setHyoDtlTsuchiHoho("2");
        target.setLgn031Form(lgn031Form);
        MessageModuleBean message = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(keyCaptor_1.capture(), keyCaptor_2.capture())).thenReturn(message);
        
        doNothing().when(messagePropertyBean).messageList(keyCaptor_3.capture());
        target.doApply();
    }

    // doApply_異常_申請処理_2-1-4
    //
    // -------------------テスト条件--------------------------
    // 画面入力項目チェックエラー[ 電話番号 ワーク.通知方法 = 2(電話)の場合]
    // DBデータ戻り値
    // -----------------------------------------------------  
    @Test
    public void doApply_異常_申請処理_2_1_4(){
         // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
         // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<List> keyCaptor_3 = ArgumentCaptor.forClass(List.class);
        
        Lgn031Form lgn031Form = new Lgn031Form();
        // 通知方法
        lgn031Form.setHyoDtlTsuchiHoho("2");
        // 連絡先担当者名
        lgn031Form.setHyoDtlRenrakusakiTantoshaMei("");
        target.setLgn031Form(lgn031Form);
        MessageModuleBean message = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(keyCaptor_1.capture(), keyCaptor_2.capture())).thenReturn(message);
        
        doNothing().when(messagePropertyBean).messageList(keyCaptor_3.capture());
        target.doApply();
    }

    // doApply_異常_申請処理_2-2
    //
    // -------------------テスト条件--------------------------
    // ユーザーコードの存在チェックを行う。
    // DBデータ戻り値
    // -----------------------------------------------------  
    @Test
    public void doApply_異常_申請処理_2_2(){
         // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> keyCaptor_2 = ArgumentCaptor.forClass(Map.class);
        Lgn031Form lgn031Form = new Lgn031Form();
        // ユーザーコード
        lgn031Form.setHyoDtlUserCd("123");
        // メールアドレス
        lgn031Form.setHyoDtlMailAddress("1234564");
        // メール申請ロック期間
        lgn031Form.setMailShinseiLockKikan("1233");
        // メールアドレス不一致最大回数
        lgn031Form.setMailAddressFuitchiKaisu(5);
        // 通知方法
        lgn031Form.setHyoDtlTsuchiHoho("120a");
        // 電話番号
        lgn031Form.setHyoDtlTelBango("1234567");
        // 連絡先担当者名
        lgn031Form.setHyoDtlRenrakusakiTantoshaMei("name");
        // 申請理由
        lgn031Form.setHyoDtlShinseiRiyu("comment");
        target.setLgn031Form(lgn031Form);
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(-1);
        serviceInterfaceBean.addMessage("warn", "111", "not null");
        when(pageCommonBean.getDBInfo(keyCaptor_2.capture(), keyCaptor_1.capture())).thenReturn(serviceInterfaceBean);
        target.doApply();
    }

    // doApply_正常_申請処理_2-3
    //
    // -------------------テスト条件--------------------------
    // ワンタイムパスワード発失敗
    // DBデータ戻り値
    // -----------------------------------------------------  
        
     @Test
    public void doApply_正常_申請処理_2_3() throws NamingException{
         // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> keyCaptor_2 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> keyCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> keyCaptor_4 = ArgumentCaptor.forClass(String.class);
        Lgn031Form lgn031Form = new Lgn031Form();
        // ユーザーコード
        lgn031Form.setHyoDtlUserCd("123");
        // メールアドレス
        lgn031Form.setHyoDtlMailAddress("1234564");
        // メール申請ロック期間
        lgn031Form.setMailShinseiLockKikan("1233");
        // メールアドレス不一致最大回数
        lgn031Form.setMailAddressFuitchiKaisu(5);
        // 通知方法
        lgn031Form.setHyoDtlTsuchiHoho("1");
        // 電話番号
        lgn031Form.setHyoDtlTelBango("1234567");
        // 連絡先担当者名
        lgn031Form.setHyoDtlRenrakusakiTantoshaMei("name");
        // 申請理由
        lgn031Form.setHyoDtlShinseiRiyu("comment");
        target.setLgn031Form(lgn031Form);
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(1);
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(setRes_Map02()));
        when(pageCommonBean.getDBInfo(keyCaptor_2.capture(), keyCaptor_1.capture())).thenReturn(serviceInterfaceBean);
        doNothing().when(pageCommonBean).sendMailWithDataSpider(keyCaptor_1.capture(),
                keyCaptor_3.capture(), keyCaptor_4.capture());
        doNothing().when(messagePropertyBean).message(keyCaptor_1.capture(), keyCaptor_1.capture());
        
        // バインドユーザ
        String bindUser = "bindUser";
        // バインドユーザのパスワード
        String bindUserPassword = "bindUserPassword";
        // ユーザーコード に対応したdn
        String dn = "dn";
        when(messagePropertyBean.getProperties(keyCaptor_1.capture())).thenReturn(bindUser, bindUserPassword, dn);
        
        // ADサーバログイン処理
        InitialDirContext ctx = Mockito.mock(InitialDirContext.class);
        when(dirContextBean.initialDirContext(lgn031Form.getHyoDtlUserCd(),null)).thenReturn(ctx);
        // ADサーバのパスワード更新処理
        when(dirContextBean.initialDirContext(bindUser, bindUserPassword)).thenReturn(ctx);
        ArgumentCaptor<String> targetCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<ModificationItem[]> modCaptor_1 = ArgumentCaptor.forClass(ModificationItem[].class);
        doNothing().when(ctx).modifyAttributes(targetCaptor_1.capture(), modCaptor_1.capture());
        target.doApply();
    }

    // doApply_正常_申請処理_2-4
    //
    // -------------------テスト条件--------------------------
    // ワンタイムパスワード発失敗成功
    // DBデータ戻り値
    // -----------------------------------------------------  
    @Test
    public void doApply_正常_申請処理_2_4() throws NamingException{
         // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> keyCaptor_2 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> keyCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> keyCaptor_4 = ArgumentCaptor.forClass(String.class);
        Lgn031Form lgn031Form = new Lgn031Form();
        // ユーザーコード
        lgn031Form.setHyoDtlUserCd("123");
        // メールアドレス
        lgn031Form.setHyoDtlMailAddress("1234564");
        // メール申請ロック期間
        lgn031Form.setMailShinseiLockKikan("1233");
        // メールアドレス不一致最大回数
        lgn031Form.setMailAddressFuitchiKaisu(5);
        // 通知方法
        lgn031Form.setHyoDtlTsuchiHoho("1");
        // 電話番号
        lgn031Form.setHyoDtlTelBango("1234567");
        // 連絡先担当者名
        lgn031Form.setHyoDtlRenrakusakiTantoshaMei("name");
        // 申請理由
        lgn031Form.setHyoDtlShinseiRiyu("comment");
        target.setLgn031Form(lgn031Form);
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(1);
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(setRes_Map02()));
        when(pageCommonBean.getDBInfo(keyCaptor_2.capture(), keyCaptor_1.capture())).thenReturn(serviceInterfaceBean);
        doNothing().when(pageCommonBean).sendMailWithDataSpider(keyCaptor_1.capture(),
                keyCaptor_3.capture(), keyCaptor_4.capture());
        doNothing().when(messagePropertyBean).message(keyCaptor_1.capture(), keyCaptor_1.capture());
        // バインドユーザ
        String bindUser = "bindUser";
        // バインドユーザのパスワード
        String bindUserPassword = "bindUserPassword";
        // ユーザーコード に対応したdn
        String dn = "dn";
        when(messagePropertyBean.getProperties(keyCaptor_1.capture())).thenReturn(bindUser, bindUserPassword, dn);
        
        // ADサーバログイン処理
        InitialDirContext ctx = Mockito.mock(InitialDirContext.class);
        when(dirContextBean.initialDirContext(lgn031Form.getHyoDtlUserCd(),null)).thenReturn(ctx);
        // ADサーバのパスワード更新処理
        when(dirContextBean.initialDirContext(bindUser, bindUserPassword)).thenReturn(ctx);
        ArgumentCaptor<String> targetCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<ModificationItem[]> modCaptor_1 = ArgumentCaptor.forClass(ModificationItem[].class);
        doNothing().when(ctx).modifyAttributes(targetCaptor_1.capture(), modCaptor_1.capture());
        
        target.doApply();
    }

    // honninrenrakuSumiSyori_正常_本人連絡済処理_3-1-1
    //
    // -------------------テスト条件--------------------------
    // チェック処理エラー
    // DBデータ戻り値
    // -----------------------------------------------------  
    @Test
    public void honninrenrakuSumiSyori_正常_本人連絡済処理_3_1_1() throws NamingException {
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> keyCaptor_2 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> ctxCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> ctxCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<SearchControls> ctxCaptor_3 = ArgumentCaptor.forClass(SearchControls.class);
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(1);
        Map<String, Object> resMap = new HashMap<>();
        // 申請情報取得
        List<Map<String, String>> getShinseiInfoList = new ArrayList();
        getShinseiInfoList.add(createRecMapFor_1_1(1));
        
        // 承認状況取得
        List<Map<String, String>> getSyouninJyoukyouList = new ArrayList();
        
        resMap.put("getSyouninJyoukyouList", getSyouninJyoukyouList);

        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resMap));

        when(pageCommonBean.getDBInfo(keyCaptor_2.capture(), keyCaptor_1.capture())).thenReturn(serviceInterfaceBean);

        doNothing().when(messagePropertyBean).message(keyCaptor_1.capture(), keyCaptor_1.capture());
        // バインドユーザ
        when(messagePropertyBean.getProperties(keyCaptor_1.capture())).thenReturn("bindUser");
        // バインドユーザ
        when(messagePropertyBean.getProperties(keyCaptor_1.capture())).thenReturn("bindUserPassword");
        
        InitialDirContext ctx = Mockito.mock(InitialDirContext.class);

        when(dirContextBean.initialDirContext("1", "a")).thenReturn(ctx);
     
        ArgumentCaptor<String> userCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> psswCaptor_2 = ArgumentCaptor.forClass(String.class);
        // ユーザのADサーバ情報を取得する
        NamingEnumeration ctxr = Mockito.mock(NamingEnumeration.class);
        when(dirContextBean.initialDirContext(userCaptor_1.capture(), psswCaptor_2.capture())).thenReturn(ctx);
        
        when(ctxr.hasMore()).thenReturn(true, false);
        // ワンタイムパスワードフラグ = 0
        Attributes attr = new BasicAttributes();
        attr.put("userCertificate", "0");
        attr.put("userCert", "2019/04/10");
        attr.put("userParameters", "0");

        SearchResult sr = new SearchResult("", "", attr);
        when(ctxr.next()).thenReturn(sr);
        when(ctx.search(ctxCaptor_1.capture(), ctxCaptor_2.capture(), ctxCaptor_3.capture())).thenReturn(ctxr);
        Lgn031Form lgn031Form = new Lgn031Form();

        List<Map<String, Object>> shoninshaInfoList = new ArrayList();
        Map<String, Object> shoninshaInfoMap = new HashMap();
        shoninshaInfoMap.put("saishuShoninShaFlg", "1");
        shoninshaInfoList.add(shoninshaInfoMap);
        lgn031Form.setShoninshaInfoList(shoninshaInfoList);
        // ユーザコード
        lgn031Form.setHyoDtlUserCd("test001");

        target.setLgn031Form(lgn031Form);
        target.honninrenrakuSumiSyori();
    
    }

    // honninrenrakuSumiSyori_正常_本人連絡済処理_3-1-2
    //
    // -------------------テスト条件--------------------------
    // チェック処理エラー
    // DBデータ戻り値
    // -----------------------------------------------------  
    @Test
    public void honninrenrakuSumiSyori_正常_本人連絡済処理_3_1_2() throws NamingException {
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> keyCaptor_2 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> ctxCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> ctxCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<SearchControls> ctxCaptor_3 = ArgumentCaptor.forClass(SearchControls.class);
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(1);
        Map<String, Object> resMap = new HashMap<>();
        // 申請情報取得
        List<Map<String, String>> getShinseiInfoList = new ArrayList();
        getShinseiInfoList.add(createRecMapFor_1_1(1));
        resMap.put("getShinseiInfoList", getShinseiInfoList);
        // 承認状況取得
        List<Map<String, String>> getSyouninJyoukyouList = new ArrayList();
        
        resMap.put("getSyouninJyoukyouList", getSyouninJyoukyouList);

        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resMap));

        when(pageCommonBean.getDBInfo(keyCaptor_2.capture(), keyCaptor_1.capture())).thenReturn(serviceInterfaceBean);

        doNothing().when(messagePropertyBean).message(keyCaptor_1.capture(), keyCaptor_1.capture());
        // バインドユーザ
        when(messagePropertyBean.getProperties(keyCaptor_1.capture())).thenReturn("bindUser");
        // バインドユーザ
        when(messagePropertyBean.getProperties(keyCaptor_1.capture())).thenReturn("bindUserPassword");
        
        InitialDirContext ctx = Mockito.mock(InitialDirContext.class);

        when(dirContextBean.initialDirContext("1", "a")).thenReturn(ctx);
     
        ArgumentCaptor<String> userCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> psswCaptor_2 = ArgumentCaptor.forClass(String.class);
        // ユーザのADサーバ情報を取得する
        NamingEnumeration ctxr = Mockito.mock(NamingEnumeration.class);
        when(dirContextBean.initialDirContext(userCaptor_1.capture(), psswCaptor_2.capture())).thenReturn(ctx);
        
        when(ctxr.hasMore()).thenReturn(true, false);
        // ワンタイムパスワードフラグ = 0
        Attributes attr = new BasicAttributes();
        attr.put("userCertificate", "1");
        attr.put("userCert", "2019/04/10");
        attr.put("userParameters", "0");

        SearchResult sr = new SearchResult("", "", attr);
        when(ctxr.next()).thenReturn(sr);
        when(ctx.search(ctxCaptor_1.capture(), ctxCaptor_2.capture(), ctxCaptor_3.capture())).thenReturn(ctxr);
        Lgn031Form lgn031Form = new Lgn031Form();

        List<Map<String, Object>> shoninshaInfoList = new ArrayList();
        Map<String, Object> shoninshaInfoMap = new HashMap();
        shoninshaInfoMap.put("saishuShoninShaFlg", "1");
        shoninshaInfoList.add(shoninshaInfoMap);
        lgn031Form.setShoninshaInfoList(shoninshaInfoList);
        // ユーザコード
        lgn031Form.setHyoDtlUserCd("test001");

        target.setLgn031Form(lgn031Form);
        target.honninrenrakuSumiSyori();
    
    }

    // honninrenrakuSumiSyori_正常_本人連絡済処理_3-1-3
    //
    // -------------------テスト条件--------------------------
    // 本人連絡済処理、ワーク.ワンタイムパスワードフラグ = 0の場合
    // DBデータ戻り値
    // -----------------------------------------------------  
    @Test
    public void honninrenrakuSumiSyori_正常_本人連絡済処理_3_1_3() throws NamingException {
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> keyCaptor_2 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> ctxCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> ctxCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<SearchControls> ctxCaptor_3 = ArgumentCaptor.forClass(SearchControls.class);
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(1);
        Map<String, Object> resMap = new HashMap<>();
        // 申請情報取得
        List<Map<String, String>> getShinseiInfoList = new ArrayList();
        getShinseiInfoList.add(createRecMapFor_1_1(1));
        resMap.put("getShinseiInfoList", getShinseiInfoList);
        // 承認状況取得
        List<Map<String, String>> getSyouninJyoukyouList = new ArrayList();
        resMap.put("getSyouninJyoukyouList", getSyouninJyoukyouList);

        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resMap));

        when(pageCommonBean.getDBInfo(keyCaptor_2.capture(), keyCaptor_1.capture())).thenReturn(serviceInterfaceBean);

        doNothing().when(messagePropertyBean).message(keyCaptor_1.capture(), keyCaptor_1.capture());
        // バインドユーザ
        when(messagePropertyBean.getProperties(keyCaptor_1.capture())).thenReturn("bindUser");
        // バインドユーザ
        when(messagePropertyBean.getProperties(keyCaptor_1.capture())).thenReturn("bindUserPassword");
        
        InitialDirContext ctx = Mockito.mock(InitialDirContext.class);

        when(dirContextBean.initialDirContext("1", "a")).thenReturn(ctx);
     
        ArgumentCaptor<String> userCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> psswCaptor_2 = ArgumentCaptor.forClass(String.class);
        // ユーザのADサーバ情報を取得する
        NamingEnumeration ctxr = Mockito.mock(NamingEnumeration.class);
        when(dirContextBean.initialDirContext(userCaptor_1.capture(), psswCaptor_2.capture())).thenReturn(ctx);
        
        when(ctxr.hasMore()).thenReturn(true, false);
        // ワンタイムパスワードフラグ = 0
        Attributes attr = new BasicAttributes();
        DateUtils.addDays(DateUtils.getSysDate(), 1);
        attr.put("userCertificate", "1");
        attr.put("userCert", DateUtils.format(DateUtils.addDays(DateUtils.getSysDate(), 1), "yyyy/MM/dd"));
        attr.put("userParameters", "0");

        SearchResult sr = new SearchResult("", "", attr);
        when(ctxr.next()).thenReturn(sr);
        when(ctx.search(ctxCaptor_1.capture(), ctxCaptor_2.capture(), ctxCaptor_3.capture())).thenReturn(ctxr);
        Lgn031Form lgn031Form = new Lgn031Form();

        List<Map<String, Object>> shoninshaInfoList = new ArrayList();
        Map<String, Object> shoninshaInfoMap = new HashMap();
        shoninshaInfoMap.put("saishuShoninShaFlg", "1");
        shoninshaInfoList.add(shoninshaInfoMap);
        lgn031Form.setShoninshaInfoList(shoninshaInfoList);
        // ユーザコード
        lgn031Form.setHyoDtlUserCd("test001");

        target.setLgn031Form(lgn031Form);
        target.honninrenrakuSumiSyori();
    
    }

    // honninrenrakuSumiSyori_正常_本人連絡済処理_3-1-4
    //
    // -------------------テスト条件--------------------------
    // 本人連絡済処理、ワーク.ワンタイムパスワード有効期限 >= サーバ日付の場合
    // DBデータ戻り値
    // -----------------------------------------------------  
    @Test
    public void honninrenrakuSumiSyori_正常_本人連絡済処理_3_1_4() throws NamingException {
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> keyCaptor_2 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> ctxCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> ctxCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<SearchControls> ctxCaptor_3 = ArgumentCaptor.forClass(SearchControls.class);
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(1);
        Map<String, Object> resMap = new HashMap<>();
        // 申請情報取得
        List<Map<String, String>> getShinseiInfoList = new ArrayList();
        getShinseiInfoList.add(createRecMapFor_1_1(1));
        resMap.put("getShinseiInfoList", getShinseiInfoList);
        // 承認状況取得
        List<Map<String, String>> getSyouninJyoukyouList = new ArrayList();
        
        resMap.put("getSyouninJyoukyouList", getSyouninJyoukyouList);

        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resMap));

        when(pageCommonBean.getDBInfo(keyCaptor_2.capture(), keyCaptor_1.capture())).thenReturn(serviceInterfaceBean);

        doNothing().when(messagePropertyBean).message(keyCaptor_1.capture(), keyCaptor_1.capture());
        // バインドユーザ
        when(messagePropertyBean.getProperties(keyCaptor_1.capture())).thenReturn("bindUser");
        // バインドユーザ
        when(messagePropertyBean.getProperties(keyCaptor_1.capture())).thenReturn("bindUserPassword");
        
        InitialDirContext ctx = Mockito.mock(InitialDirContext.class);

        when(dirContextBean.initialDirContext("1", "a")).thenReturn(ctx);
     
        ArgumentCaptor<String> userCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> psswCaptor_2 = ArgumentCaptor.forClass(String.class);
        // ユーザのADサーバ情報を取得する
        NamingEnumeration ctxr = Mockito.mock(NamingEnumeration.class);
        when(dirContextBean.initialDirContext(userCaptor_1.capture(), psswCaptor_2.capture())).thenReturn(ctx);
        
        when(ctxr.hasMore()).thenReturn(true, false);
        // ワンタイムパスワードフラグ = 0
        Attributes attr = new BasicAttributes();
        DateUtils.addDays(DateUtils.getSysDate(), 1);
        attr.put("userCertificate1", "1");

        SearchResult sr = new SearchResult("", "", attr);
        when(ctxr.next()).thenReturn(sr);
        when(ctx.search(ctxCaptor_1.capture(), ctxCaptor_2.capture(), ctxCaptor_3.capture())).thenReturn(ctxr);
        Lgn031Form lgn031Form = new Lgn031Form();

        List<Map<String, Object>> shoninshaInfoList = new ArrayList();
        Map<String, Object> shoninshaInfoMap = new HashMap();
        shoninshaInfoMap.put("saishuShoninShaFlg", "1");
        shoninshaInfoList.add(shoninshaInfoMap);
        lgn031Form.setShoninshaInfoList(shoninshaInfoList);
        // ユーザコード
        lgn031Form.setHyoDtlUserCd("test001");

        target.setLgn031Form(lgn031Form);
        target.honninrenrakuSumiSyori();
    
    }

    private Map<String, String> createRecMapFor_1_1(int i) {

        Map recMap = new HashMap();
        recMap.put("userCd", "userCd" + i);
        recMap.put("userMei", "userMei" + i);
        recMap.put("tekiyoKaishibi", "tekiyoKaishibi" + i);
        recMap.put("tsuchiHoho", "tsuchiHoho" + i);
        recMap.put("telBango", "telBango" + i);
        recMap.put("renrakusaki", "renrakusaki" + i);
        recMap.put("mailAddress", "mailAddress" + i);
        recMap.put("shinseiRiyu", "shinseiRiyu" + i);
        recMap.put("eigyoshoMei", "eigyoshoMei" + i);
        recMap.put("roleMei", "roleMei" + i);
        recMap.put("shinseiKaisu", "shinseiKaisu" + i);
        recMap.put("shinseiKaisu", "shinseiKaisu" + i);
        recMap.put("passwordGoNyuryokuKaisu", "passwordGoNyuryokuKaisu" + i);
        recMap.put("honninRenraku", "honninRenraku" + i);
        recMap.put("passwordHenko", "passwordHenko" + i);
        return recMap;
    }

    // commentCheckSyori_正常_コメントチェック処理_4_1_1
    //
    // -------------------テスト条件--------------------------
    // [コメント != null, 区分 = 1]
    // DBデータ戻り値
    // -----------------------------------------------------  
    @Test
    public void commentCheckSyori_正常_コメントチェック処理_4_1_1(){
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).executeScript(keyCaptor_1.capture());  
        Lgn031Form lgn031Form = new Lgn031Form();
        lgn031Form.setSyouninJyoukyouList(new ArrayList());
        target.setLgn031Form(lgn031Form);
        target.commentCheckSyori(1);
    }

    // commentCheckSyori_正常_コメントチェック処理_4_1_2
    //
    // -------------------テスト条件--------------------------
    // [コメント = null, 区分 = 1]
    // DBデータ戻り値
    // -----------------------------------------------------  
    @Test
    public void commentCheckSyori_正常_コメントチェック処理_4_1_2() throws NamingException{
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> keyCaptor_2 = ArgumentCaptor.forClass(Map.class);

        Lgn031Form lgn031Form = new Lgn031Form();
        List<Map<String, String>> list = new ArrayList<>();
        Map<String, String> map = new HashMap<>();
        // 承認状況
        map.put("shinseiCommentDisabled", "false");
        // コメント
        map.put("shinseiComment", "123");
        list.add(map);
        // 承認状況
        lgn031Form.setSyouninJyoukyouList(list);
        
        doNothing().when(pageCommonBean).executeScript(keyCaptor_1.capture());
        List<Map<String, Object>> list1 = new ArrayList<>();
        Map<String, Object> map1 = new HashMap<>();
        map1.put("saishuShoninShaFlg", "1");
        list1.add(map1);
        // 申請ID
        lgn031Form.setHyoDtlShinseiId("123");
        // コメント
        lgn031Form.setShnDtlListComment("comment");
        // 承認者情報
        lgn031Form.setShoninshaInfoList(list1);
        target.setLgn031Form(lgn031Form);
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        Map<String, Object> resMap = setRes_Map();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resMap));
        // 登録処理
        when(pageCommonBean.getDBInfo(keyCaptor_2.capture(), keyCaptor_1.capture())).thenReturn(serviceInterfaceBean);
        doNothing().when(messagePropertyBean).message(keyCaptor_1.capture(), keyCaptor_1.capture());
        doThrow(IOException.class).when(kbnBean).getKbnCdOfKeyCd(keyCaptor_1.capture()); 

        // バインドユーザ
        when(messagePropertyBean.getProperties(keyCaptor_1.capture())).thenReturn("bindUser");
        // バインドユーザ
        when(messagePropertyBean.getProperties(keyCaptor_1.capture())).thenReturn("bindUserPassword");
        
        InitialDirContext ctx = Mockito.mock(InitialDirContext.class);

        when(dirContextBean.initialDirContext("1", "a")).thenReturn(ctx);
     
        ArgumentCaptor<String> userCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> psswCaptor_2 = ArgumentCaptor.forClass(String.class);
        // ユーザのADサーバ情報を取得する
        NamingEnumeration ctxr = Mockito.mock(NamingEnumeration.class);
        when(dirContextBean.initialDirContext(userCaptor_1.capture(), psswCaptor_2.capture())).thenReturn(ctx);
        
        when(ctxr.hasMore()).thenReturn(true, false);
        // ワンタイムパスワードフラグ = 0
        Attributes attr = new BasicAttributes();
        DateUtils.addDays(DateUtils.getSysDate(), 1);
        attr.put("userCertificate", "1");
        attr.put("userCert", DateUtils.format(DateUtils.addDays(DateUtils.getSysDate(), 1), "yyyy/MM/dd"));
        attr.put("userParameters", "0");

        SearchResult sr = new SearchResult("", "", attr);
        when(ctxr.next()).thenReturn(sr);
        ArgumentCaptor<String> ctxCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> ctxCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<SearchControls> ctxCaptor_3 = ArgumentCaptor.forClass(SearchControls.class);
        when(ctx.search(ctxCaptor_1.capture(), ctxCaptor_2.capture(), ctxCaptor_3.capture())).thenReturn(ctxr);

        List<Map<String, Object>> shoninshaInfoList = new ArrayList();
        Map<String, Object> shoninshaInfoMap = new HashMap();
        shoninshaInfoMap.put("saishuShoninShaFlg", "1");
        shoninshaInfoList.add(shoninshaInfoMap);
        lgn031Form.setShoninshaInfoList(shoninshaInfoList);
        // ユーザコード
        lgn031Form.setHyoDtlUserCd("test001");

        target.setLgn031Form(lgn031Form);

        target.commentCheckSyori(1);
    }

    // commentCheckSyori_正常_コメントチェック処理_4_2_1
    //
    // -------------------テスト条件--------------------------
    // [コメント = null, 区分 = 2]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void commentCheckSyori_正常_コメントチェック処理_4_2_1(){
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).executeScript(keyCaptor_1.capture());  
        Lgn031Form lgn031Form = new Lgn031Form();
        lgn031Form.setSyouninJyoukyouList(new ArrayList());
        target.setLgn031Form(lgn031Form);
        target.commentCheckSyori(2);
    }

    // commentCheckSyori_正常_コメントチェック処理_4_2_1
    //
    // -------------------テスト条件--------------------------
    // [コメント != null, 区分 = 2]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void commentCheckSyori_正常_コメントチェック処理_4_2_2() throws NamingException{
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> keyCaptor_2 = ArgumentCaptor.forClass(Map.class);
        Lgn031Form lgn031Form = new Lgn031Form();
        List<Map<String, String>> list = new ArrayList<>();
        Map<String, String> map = new HashMap<>();
        // 承認状況
        map.put("shinseiCommentDisabled", "false");
        // コメント
        map.put("shinseiComment", "123");
        list.add(map);
        // 承認状況
        lgn031Form.setSyouninJyoukyouList(list);
        
        doNothing().when(pageCommonBean).executeScript(keyCaptor_1.capture());
        List<Map<String, Object>> list1 = new ArrayList<>();
        Map<String, Object> map1 = new HashMap<>();
        map1.put("saishuShoninShaFlg", "1");
        list1.add(map1);
        // 申請ID
        lgn031Form.setHyoDtlShinseiId("123");
        // 承認者情報
        lgn031Form.setShoninshaInfoList(list1);
        target.setLgn031Form(lgn031Form);
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        Map<String, Object> resMap = setRes_Map01();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resMap));
        when(pageCommonBean.getDBInfo(keyCaptor_2.capture(), keyCaptor_1.capture())).thenReturn(serviceInterfaceBean);
        doNothing().when(messagePropertyBean).message(keyCaptor_1.capture(), keyCaptor_1.capture());
        when(kbnBean.getKbnCdOfKeyCd(keyCaptor_1.capture())).thenReturn("01"); 

        // バインドユーザ
        when(messagePropertyBean.getProperties(keyCaptor_1.capture())).thenReturn("bindUser");
        // バインドユーザ
        when(messagePropertyBean.getProperties(keyCaptor_1.capture())).thenReturn("bindUserPassword");
        
        InitialDirContext ctx = Mockito.mock(InitialDirContext.class);

        when(dirContextBean.initialDirContext("1", "a")).thenReturn(ctx);
     
        ArgumentCaptor<String> userCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> psswCaptor_2 = ArgumentCaptor.forClass(String.class);
        // ユーザのADサーバ情報を取得する
        NamingEnumeration ctxr = Mockito.mock(NamingEnumeration.class);
        when(dirContextBean.initialDirContext(userCaptor_1.capture(), psswCaptor_2.capture())).thenReturn(ctx);
        
        when(ctxr.hasMore()).thenReturn(true, false);
        // ワンタイムパスワードフラグ = 0
        Attributes attr = new BasicAttributes();
        DateUtils.addDays(DateUtils.getSysDate(), 1);
        attr.put("userCertificate", "1");
        attr.put("userCert", DateUtils.format(DateUtils.addDays(DateUtils.getSysDate(), 1), "yyyy/MM/dd"));
        attr.put("userParameters", "0");

        SearchResult sr = new SearchResult("", "", attr);
        when(ctxr.next()).thenReturn(sr);
        ArgumentCaptor<String> ctxCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> ctxCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<SearchControls> ctxCaptor_3 = ArgumentCaptor.forClass(SearchControls.class);
        when(ctx.search(ctxCaptor_1.capture(), ctxCaptor_2.capture(), ctxCaptor_3.capture())).thenReturn(ctxr);

        List<Map<String, Object>> shoninshaInfoList = new ArrayList();
        Map<String, Object> shoninshaInfoMap = new HashMap();
        shoninshaInfoMap.put("saishuShoninShaFlg", "1");
        shoninshaInfoList.add(shoninshaInfoMap);
        lgn031Form.setShoninshaInfoList(shoninshaInfoList);
        // ユーザコード
        lgn031Form.setHyoDtlUserCd("test001");

        target.setLgn031Form(lgn031Form);

        target.commentCheckSyori(2);
    }

    // commentCheckSyori_正常_コメントチェック処理_4_2_3
    //
    // -------------------テスト条件--------------------------
    // [コメント != null, 区分 = 2, 申請.申請ステータス != '04'(承認済) ]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void commentCheckSyori_正常_コメントチェック処理_4_2_3() throws NamingException{
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> keyCaptor_2 = ArgumentCaptor.forClass(Map.class);
        Lgn031Form lgn031Form = new Lgn031Form();
        List<Map<String, String>> list = new ArrayList<>();
        Map<String, String> map = new HashMap<>();
        // 承認状況
        map.put("shinseiCommentDisabled", "false");
        // コメント
        map.put("shinseiComment", "123");
        list.add(map);
        // 承認状況
        lgn031Form.setSyouninJyoukyouList(list);
        
        doNothing().when(pageCommonBean).executeScript(keyCaptor_1.capture());
        List<Map<String, Object>> list1 = new ArrayList<>();
        Map<String, Object> map1 = new HashMap<>();
        map1.put("saishuShoninShaFlg", "1");
        list1.add(map1);
        // 申請ID
        lgn031Form.setHyoDtlShinseiId("123");
        // 承認者情報
        lgn031Form.setShoninshaInfoList(list1);
        target.setLgn031Form(lgn031Form);
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        Map<String, Object> resMap = setRes_Map03();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resMap));
        when(pageCommonBean.getDBInfo(keyCaptor_2.capture(), keyCaptor_1.capture())).thenReturn(serviceInterfaceBean);
        doNothing().when(messagePropertyBean).message(keyCaptor_1.capture(), keyCaptor_1.capture());
        when(kbnBean.getKbnCdOfKeyCd(keyCaptor_1.capture())).thenReturn("01"); 

        // バインドユーザ
        when(messagePropertyBean.getProperties(keyCaptor_1.capture())).thenReturn("bindUser");
        // バインドユーザ
        when(messagePropertyBean.getProperties(keyCaptor_1.capture())).thenReturn("bindUserPassword");
        
        InitialDirContext ctx = Mockito.mock(InitialDirContext.class);

        when(dirContextBean.initialDirContext("1", "a")).thenReturn(ctx);
     
        ArgumentCaptor<String> userCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> psswCaptor_2 = ArgumentCaptor.forClass(String.class);
        // ユーザのADサーバ情報を取得する
        NamingEnumeration ctxr = Mockito.mock(NamingEnumeration.class);
        when(dirContextBean.initialDirContext(userCaptor_1.capture(), psswCaptor_2.capture())).thenReturn(ctx);
        
        when(ctxr.hasMore()).thenReturn(true, false);
        // ワンタイムパスワードフラグ = 0
        Attributes attr = new BasicAttributes();
        DateUtils.addDays(DateUtils.getSysDate(), 1);
        attr.put("userCertificate", "1");
        attr.put("userCert", DateUtils.format(DateUtils.addDays(DateUtils.getSysDate(), 1), "yyyy/MM/dd"));
        attr.put("userParameters", "0");

        SearchResult sr = new SearchResult("", "", attr);
        when(ctxr.next()).thenReturn(sr);
        ArgumentCaptor<String> ctxCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> ctxCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<SearchControls> ctxCaptor_3 = ArgumentCaptor.forClass(SearchControls.class);
        when(ctx.search(ctxCaptor_1.capture(), ctxCaptor_2.capture(), ctxCaptor_3.capture())).thenReturn(ctxr);

        List<Map<String, Object>> shoninshaInfoList = new ArrayList();
        Map<String, Object> shoninshaInfoMap = new HashMap();
        shoninshaInfoMap.put("saishuShoninShaFlg", "1");
        shoninshaInfoList.add(shoninshaInfoMap);
        lgn031Form.setShoninshaInfoList(shoninshaInfoList);
        // ユーザコード
        lgn031Form.setHyoDtlUserCd("test001");

        target.setLgn031Form(lgn031Form);

        target.commentCheckSyori(2);
    }

    // commentCheckSyori_正常_コメントチェック処理_4_3_1
    //
    // -------------------テスト条件--------------------------
    // [コメント = null, 区分 = 3]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void commentCheckSyori_コメントチェック処理_4_3_1(){
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).executeScript(keyCaptor_1.capture());  
        Lgn031Form lgn031Form = new Lgn031Form();
        lgn031Form.setSyouninJyoukyouList(new ArrayList());
        target.setLgn031Form(lgn031Form);
        target.commentCheckSyori(3);
    }

    // commentCheckSyori_正常_コメントチェック処理_4_3_2
    //
    // -------------------テスト条件--------------------------
    // [コメント != null, 区分 = 3]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void commentCheckSyori_コメントチェック処理_4_3_2() throws NamingException{
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> keyCaptor_2 = ArgumentCaptor.forClass(Map.class);
        Lgn031Form lgn031Form = new Lgn031Form();
        List<Map<String, String>> list = new ArrayList<>();
        Map<String, String> map = new HashMap<>();
        // 承認状況
        map.put("shinseiCommentDisabled", "true");
        // コメント
        map.put("shinseiComment", "123");
        list.add(map);
        Map<String, String> map0 = new HashMap<>();
        map0.put("shinseiCommentDisabled", "false");
        // コメント
        map0.put("shinseiComment", "123");
        list.add(map0);
        // 承認状況
        lgn031Form.setSyouninJyoukyouList(list);
        
        doNothing().when(pageCommonBean).executeScript(keyCaptor_1.capture());
        List<Map<String, Object>> list1 = new ArrayList<>();
        Map<String, Object> map1 = new HashMap<>();
        map1.put("saishuShoninShaFlg", "1");
        list1.add(map1);
        // 申請ID
        lgn031Form.setHyoDtlShinseiId("123");
        // 承認者情報
        lgn031Form.setShoninshaInfoList(list1);
        target.setLgn031Form(lgn031Form);
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        Map<String, Object> resMap = setRes_Map01();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resMap));
        when(pageCommonBean.getDBInfo(keyCaptor_2.capture(), keyCaptor_1.capture())).thenReturn(serviceInterfaceBean);
        doNothing().when(messagePropertyBean).message(keyCaptor_1.capture(), keyCaptor_1.capture());
        when(kbnBean.getKbnCdOfKeyCd(keyCaptor_1.capture())).thenReturn("01"); 

        // バインドユーザ
        when(messagePropertyBean.getProperties(keyCaptor_1.capture())).thenReturn("bindUser");
        // バインドユーザ
        when(messagePropertyBean.getProperties(keyCaptor_1.capture())).thenReturn("bindUserPassword");
        
        InitialDirContext ctx = Mockito.mock(InitialDirContext.class);

        when(dirContextBean.initialDirContext("1", "a")).thenReturn(ctx);
     
        ArgumentCaptor<String> userCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> psswCaptor_2 = ArgumentCaptor.forClass(String.class);
        // ユーザのADサーバ情報を取得する
        NamingEnumeration ctxr = Mockito.mock(NamingEnumeration.class);
        when(dirContextBean.initialDirContext(userCaptor_1.capture(), psswCaptor_2.capture())).thenReturn(ctx);
        
        when(ctxr.hasMore()).thenReturn(true, false);
        // ワンタイムパスワードフラグ = 0
        Attributes attr = new BasicAttributes();
        DateUtils.addDays(DateUtils.getSysDate(), 1);
        attr.put("userCertificate", "1");
        attr.put("userCert", DateUtils.format(DateUtils.addDays(DateUtils.getSysDate(), 1), "yyyy/MM/dd"));
        attr.put("userParameters", "0");

        SearchResult sr = new SearchResult("", "", attr);
        when(ctxr.next()).thenReturn(sr);
        ArgumentCaptor<String> ctxCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> ctxCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<SearchControls> ctxCaptor_3 = ArgumentCaptor.forClass(SearchControls.class);
        when(ctx.search(ctxCaptor_1.capture(), ctxCaptor_2.capture(), ctxCaptor_3.capture())).thenReturn(ctxr);

        List<Map<String, Object>> shoninshaInfoList = new ArrayList();
        Map<String, Object> shoninshaInfoMap = new HashMap();
        shoninshaInfoMap.put("saishuShoninShaFlg", "1");
        shoninshaInfoList.add(shoninshaInfoMap);
        lgn031Form.setShoninshaInfoList(shoninshaInfoList);
        // ユーザコード
        lgn031Form.setHyoDtlUserCd("test001");

        target.setLgn031Form(lgn031Form); 

        target.commentCheckSyori(3);
    }

    // userClick_正常_ユーザーコードリンク処理_5-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void userClick_正常_ユーザーコードリンク処理_5_1(){
        Lgn031Form lgn031Form = new Lgn031Form();
        lgn031Form.setHyoDtlUserCd("123");
        lgn031Form.setHyoDtlUserTekiyoKaishibi("2018/01/02");
        target.setLgn031Form(lgn031Form);
        Flash flash = new FlashKls();
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        when(flashUtil.getPageParam()).thenReturn(flash);
        target.userClick();
    }

    // saiHakko_再発行処理_6-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void saiHakko_再発行処理_6_1() throws NamingException{
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> keyCaptor_3 = ArgumentCaptor.forClass(Map.class);
        doNothing().when(messagePropertyBean).message(keyCaptor_1.capture(), keyCaptor_2.capture());
        when(messagePropertyBean.getProperty(keyCaptor_1.capture())).thenReturn("123");
        when(dirContextBean.initialDirContext(keyCaptor_1.capture(), keyCaptor_2.capture())).thenReturn(null);
        
        Lgn031Form lgn031Form = new Lgn031Form();
        List<Map<String, Object>> list1 = new ArrayList<>();
        Map<String, Object> map1 = new HashMap<>();
        map1.put("saishuShoninShaFlg", "1");
        list1.add(map1);
        // 申請ID
        lgn031Form.setHyoDtlShinseiId("123");
        // 承認者情報
        lgn031Form.setShoninshaInfoList(list1);
        target.setLgn031Form(lgn031Form);
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        Map<String, Object> resMap = setRes_Map01();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resMap));
        when(pageCommonBean.getDBInfo(keyCaptor_3.capture(), keyCaptor_1.capture())).thenReturn(serviceInterfaceBean);
        when(kbnBean.getKbnCdOfKeyCd(keyCaptor_1.capture())).thenReturn("01"); 

        // バインドユーザ
        when(messagePropertyBean.getProperties(keyCaptor_1.capture())).thenReturn("bindUser");
        // バインドユーザ
        when(messagePropertyBean.getProperties(keyCaptor_1.capture())).thenReturn("bindUserPassword");
        
        InitialDirContext ctx = Mockito.mock(InitialDirContext.class);

        when(dirContextBean.initialDirContext("1", "a")).thenReturn(ctx);
     
        ArgumentCaptor<String> userCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> psswCaptor_2 = ArgumentCaptor.forClass(String.class);
        // ユーザのADサーバ情報を取得する
        NamingEnumeration ctxr = Mockito.mock(NamingEnumeration.class);
        when(dirContextBean.initialDirContext(userCaptor_1.capture(), psswCaptor_2.capture())).thenReturn(ctx);

        when(ctxr.hasMore()).thenReturn(true, false);
        // ワンタイムパスワードフラグ = 0
        Attributes attr = new BasicAttributes();
        DateUtils.addDays(DateUtils.getSysDate(), 1);
        attr.put("userCertificate", "1");
        attr.put("userCert", DateUtils.format(DateUtils.addDays(DateUtils.getSysDate(), 1), "yyyy/MM/dd"));
        attr.put("userParameters", "0");

        SearchResult sr = new SearchResult("", "", attr);
        when(ctxr.next()).thenReturn(sr);
        ArgumentCaptor<String> ctxCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> ctxCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<SearchControls> ctxCaptor_3 = ArgumentCaptor.forClass(SearchControls.class);
        when(ctx.search(ctxCaptor_1.capture(), ctxCaptor_2.capture(), ctxCaptor_3.capture())).thenReturn(ctxr);

        List<Map<String, Object>> shoninshaInfoList = new ArrayList();
        Map<String, Object> shoninshaInfoMap = new HashMap();
        shoninshaInfoMap.put("saishuShoninShaFlg", "1");
        shoninshaInfoList.add(shoninshaInfoMap);
        lgn031Form.setShoninshaInfoList(shoninshaInfoList);
        // ユーザコード
        lgn031Form.setHyoDtlUserCd("test001");
        target.setLgn031Form(lgn031Form); 
        target.saiHakko();
    }

    // saiHakko_再発行処理_6-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void saiHakko_再発行処理_6_2() throws NamingException{
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> keyCaptor_3 = ArgumentCaptor.forClass(Map.class);
        doNothing().when(messagePropertyBean).message(keyCaptor_1.capture(), keyCaptor_2.capture());
        when(messagePropertyBean.getProperty(keyCaptor_1.capture())).thenReturn("123");
        doThrow(NamingException.class).when(dirContextBean).initialDirContext(keyCaptor_1.capture(),
                keyCaptor_2.capture());

        Lgn031Form lgn031Form = new Lgn031Form();
        List<Map<String, Object>> list1 = new ArrayList<>();
        Map<String, Object> map1 = new HashMap<>();
        map1.put("saishuShoninShaFlg", "1");
        list1.add(map1);
        // 申請ID
        lgn031Form.setHyoDtlShinseiId("123");
        // 承認者情報
        lgn031Form.setShoninshaInfoList(list1);
        target.setLgn031Form(lgn031Form);
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        Map<String, Object> resMap = setRes_Map01();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resMap));
        when(pageCommonBean.getDBInfo(keyCaptor_3.capture(), keyCaptor_1.capture())).thenReturn(serviceInterfaceBean);
        when(kbnBean.getKbnCdOfKeyCd(keyCaptor_1.capture())).thenReturn("01"); 
        target.saiHakko();
    }

    // menuClick_正常_補充ケース_7-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_7_1 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Lgn031Form form = new Lgn031Form();
        target.setLgn031Form(form);
        target.menuClick("","");

        // 実施結果Outを取得
        form = target.getLgn031Form();

    }
    
    // menuClick_正常_補充ケース_7-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_7_2 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(1);
       
        // テスト実行
        Lgn031Form form = new Lgn031Form();
        target.setLgn031Form(form);
        target.menuClick("","");

        // 実施結果Outを取得
        form = target.getLgn031Form();

    }

    // breadClumClick_正常_補充ケース_7-3
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_7_3 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Lgn031Form form = new Lgn031Form();
        target.setLgn031Form(form);
        target.breadClumClick("",0);

        // 実施結果Outを取得
        form = target.getLgn031Form();

    }
    
    // breadClumClick_正常_補充ケース_7-3-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_7_3_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(0); 
        // テスト実行
        Lgn031Form form = new Lgn031Form();
        target.setLgn031Form(form);
        target.breadClumClick("",0);

        // 実施結果Outを取得
        form = target.getLgn031Form();

    }

    // logoutClick_正常_補充ケース_18-4
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void logoutClick_正常_補充ケース_18_4 () throws IllegalAccessException, InvocationTargetException {

        when(authorityConfBean.logout()).thenReturn("");
        
        // テスト実行
        Lgn031Form form = new Lgn031Form();
        target.setLgn031Form(form);
        target.logoutClick();

        // 実施結果Outを取得
        form = target.getLgn031Form();

    }

    public Map<String, Object> setRes_Map(){
        Map<String, Object> resMap = new HashMap<>();
        List<Map<String, String>> list = new ArrayList<>();
        Map<String, String> map = new HashMap<>();
        map.put("1", "10");
        map.put("2", "20");
        map.put("3", "30");
        list.add(map);
        List<Map<String, String>> list1 = new ArrayList<>();
        Map<String, String> map1 = new HashMap<>();
        map1.put("1", "01");
        map1.put("2", "02");
        map1.put("3", "03");
        list1.add(map1);
        resMap.put("getShinseiInfoList", list);
        resMap.put("getSyouninJyoukyouList", list1);
        return resMap;
    }
   
    public Map<String, Object> setRes_Map01(){
        Map<String, Object> resMap = new HashMap<>();
        resMap.put("shinseiStatus", "04");
        return resMap;
    }

    public Map<String, Object> setRes_Map02(){
        Map<String, Object> resMap = new HashMap<>();
        resMap.put("shinseiId", "0112");
        return resMap;
    }

    public Map<String, Object> setRes_Map03(){
        Map<String, Object> resMap = new HashMap<>();
        resMap.put("shinseiStatus", "03");
        return resMap;
    }

}
