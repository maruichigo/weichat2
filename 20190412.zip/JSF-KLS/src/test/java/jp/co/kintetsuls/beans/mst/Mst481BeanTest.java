package jp.co.kintetsuls.beans.mst;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.LabelValueBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst481Form;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.utils.FlashUtil;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import static org.mockito.Mockito.doThrow;

/**
 * K-INGコード変換マスタ画面
 *
 * @author 雷新然 (MBP)
 * @version 2019/2/18 新規作成
 */
public class Mst481BeanTest {

    // テストTarget
    @InjectMocks
    private Mst481Bean target;

    // Mockitoオブジェクト
    @Mock
    private FileBean fileBean;
    @Mock
    private AutoCompleteViewBean autoCompleteViewBean;
    @Mock
    private AutoCompleteBean autoCompleteBean;
    @Mock
    private MasterInfoBean masterInfo;
    @Mock
    private MessagePropertyBean messageProperty;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosai;
    @Mock
    private SearchHelpBean searchHelpBean;
    @Mock
    private AuthorityConfBean authConfBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private MessagePropertyBean messagePropertyBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosaiBean;
    @Mock
    private ListCheckBean listCheckBean;
    @Mock
    private FlashUtil flashUtil;
    @Mock
    private LabelValueBean labelValueBean;

    public Mst481BeanTest() {
    }

    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() {
    }

    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[not null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst481Form mst481Form = new Mst481Form();
        target.setAutoCompleteBean(autoCompleteBean);
        target.setAuthorityConfBean(authConfBean);
        target.setAutoCompleteViewBean(autoCompleteViewBean);
        target.setFileBean(fileBean);
        target.setMessagePropertyBean(messagePropertyBean);
        target.setPageCommonBean(pageCommonBean);
        target.setSearchHelpBean(searchHelpBean);
        target.setLabelValueBean(labelValueBean);
        target.setListCheckBean(listCheckBean);
        target.setRirekiSyosaiBean(rirekiSyosaiBean);
        target.setBreadBean(breadBean);
        target.setRirekiSearchKey(new HashMap<String, Object>());
        target.setMsgList(new ArrayList<MessageModuleBean>());

        //前画面情報[not null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst481Form);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());

        //テスト実行
        Mst481Form form = new Mst481Form();
        target.setMst481Form(form);
        
        AutoCompleteBean autoCompleteBean1 = target.getAutoCompleteBean();
        AuthorityConfBean authorityConfBean1 = target.getAuthorityConfBean();
        AutoCompleteViewBean autoCompleteViewBean1 = target.getAutoCompleteViewBean();
        FileBean fileBean1 = target.getFileBean();
        MessagePropertyBean messagePropertyBean1 = target.getMessagePropertyBean();
        PageCommonBean pageCommonBean1 = target.getPageCommonBean();
        SearchHelpBean searchHelpBean1 = target.getSearchHelpBean();
        LabelValueBean labelValueBean1 = target.getLabelValueBean();
        ListCheckBean listCheckBean1 = target.getListCheckBean();
        RirekiSyosaiBean rirekiSyosaiBean1 = target.getRirekiSyosaiBean();
        BreadCrumbBean breadBean1 = target.getBreadBean();
        Map<String, Object> rirekiSearchKey = target.getRirekiSearchKey();
        List<MessageModuleBean> msgList = target.getMsgList();
        
        target.init("", "MST481_SCREEN", true);

        //実施結果Outを取得
        form = target.getMst481Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst481Form", keyCaptor_1.getValue());
        //想定通りに再検索を実施する。
        assertEquals("search_mst481", keyCaptor_2.getValue());
        assertEquals(autoCompleteBean, autoCompleteBean1);
        assertEquals(authConfBean, authorityConfBean1);
        assertEquals(autoCompleteViewBean, autoCompleteViewBean1);
        assertEquals(fileBean, fileBean1);
        assertEquals(messagePropertyBean, messagePropertyBean1);
        assertEquals(pageCommonBean, pageCommonBean1);
        assertEquals(searchHelpBean, searchHelpBean1);
        assertEquals(labelValueBean, labelValueBean1);
        assertEquals(listCheckBean, listCheckBean1);
        assertEquals(breadBean, breadBean1);
        assertEquals(rirekiSyosaiBean, rirekiSyosaiBean1);
    }

    // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[顧客コード = 000001,国内箇所区分 = FUK,輸入箇所コード = "",輸入顧客コード = "",販売形態区分 = "",削除済のみ検索 = null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2() throws IllegalAccessException, InvocationTargetException,
            InstantiationException {

        // Mockitoオブジェクトの予想return値設定
        Mst481Form mst481Form = new Mst481Form();
        //前回検索パラメータ[都道府県 = 01,仕向地名 = 地名23,削除済のみ検索 = null]
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("000001");
        mst481Form.setConKokyakuCd(conKokyakuCd);
        mst481Form.setConKokunaiKashoKbn("FUK");
        mst481Form.setConYunyuKashoCd("");
        mst481Form.setConYunyuKokyakuCd("");
        mst481Form.setConHambaiKeitaiKbn("");
        mst481Form.setConSakujonomiKensaku(null);
        // Mockitoオブジェクトの予想return値設定
        Flash flash = new FlashKls();
        //前画面パラメータ[顧客コード = 000001,国内箇所区分 = FUK,輸入箇所コード = "",輸入顧客コード = "",販売形態区分 = "",削除済のみ検索 = null]
        flash.put("mst481Form", mst481Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());

        //テスト実行
        Mst481Form form = new Mst481Form();
        target.setMst481Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID", "", false);

        //実施結果Outを取得
        form = target.getMst481Form();

        //想定通りに再検索を実施する。
        assertEquals("search_mst481", keyCaptor_2.getValue());
        assertEquals("000001", form.getConKokyakuCd().getValue());
        assertEquals("FUK", form.getConKokunaiKashoKbn());
        assertEquals("", form.getConYunyuKashoCd());
        assertEquals("", form.getConYunyuKokyakuCd());
        assertEquals("", form.getConHambaiKeitaiKbn());
        assertEquals(null, form.getConSakujonomiKensaku());
    }

    // init_正常_初期処理_1-3
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        //前画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(null);

        //テスト実行
        Mst481Form form = new Mst481Form();
        target.setMst481Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID", "", false);

        //実施結果Outを取得
        form = target.getMst481Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst481Form", keyCaptor_1.getValue());
        //想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null, form.getSearchResult());
    }

    // init_正常_初期処理_1-2_1
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[顧客コード = 1, 顧客名 = 顧客名1, 輸入箇所コード = 1]
    // DBデータ戻り値
    // -----------------------------------------------------
    public void init_正常_初期処理_1_4() throws IllegalAccessException, InvocationTargetException {
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        //前画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(null);
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        Map<String, Object> shashu = new HashMap<>();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(shashu));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        //テスト実行
        Mst481Form form = new Mst481Form();
        target.setMst481Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID", "", false);

        //実施結果Outを取得
        form = target.getMst481Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst211Form", keyCaptor_1.getValue());
        //想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null, form.getSearchResult());
    }

    // search_正常_検索処理_2-1
    //
    // -------------------テスト条件--------------------------
    // K-INGコード検索結果一覧取得
    // 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //K-INGコード検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 0; i++) {
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst481Form form = new Mst481Form();
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("conKokyakuCd1");
        form.setConKokyakuCd(conKokyakuCd);
        form.setConKokunaiKashoKbn("conKokunaiKashoKbn1");
        form.setConYunyuKashoCd("conYunyuKashoCd1");
        form.setConYunyuKokyakuCd("conYunyuKokyakuCd1");
        form.setConHambaiKeitaiKbn("conHambaiKeitaiKbn1");
        form.setConSakujonomiKensaku(new String[]{"conSakujonomiKensaku1"});
        target.setMst481Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst481Form();

        // 実行時に渡すパラメータの検証
        assertEquals(conKokyakuCd,  paramsCaptor_1.getValue().get("conKokyakuCd"));
        assertEquals("conKokunaiKashoKbn1", paramsCaptor_1.getValue().get("conKokunaiKashoKbn"));
        assertEquals("conYunyuKashoCd1", paramsCaptor_1.getValue().get("conYunyuKashoCd"));
        assertEquals("conYunyuKokyakuCd1", paramsCaptor_1.getValue().get("conYunyuKokyakuCd"));
        assertEquals("conHambaiKeitaiKbn1", paramsCaptor_1.getValue().get("conHambaiKeitaiKbn"));
        assertEquals("mst481-get-king-code-detail", functionCodeCaptor_2.getValue());
        //想定通りにKINGコード変換マスタ一覧を表示されること
        assertForRecList_2_1(form);
    }

    // search_正常_検索処理_2-2
    //
    // -------------------テスト条件--------------------------
    // K-INGコード検索結果一覧取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_2() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // K-INGコード検索結果一覧取得 取得件数 = 2
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // テスト実行
        Mst481Form form = new Mst481Form();
        target.setMst481Form(form);
        target.search();

        // 実施結果Outを取得
        form = target.getMst481Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null, paramsCaptor_1.getValue().get("conKokyakuCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conKokunaiKashoKbn"));
        assertEquals(null, paramsCaptor_1.getValue().get("conYunyuKashoCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conYunyuKokyakuCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conHambaiKeitaiKbn"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSakujonomiKensaku"));
        assertEquals("mst481-get-king-code-detail", functionCodeCaptor_2.getValue());
        //想定通りに K-INGコード変換マスタ一覧を表示されること
        assertForRecList_2_2(form);
    }

    // search_異常_検索処理_2-3
    //
    // -------------------テスト条件--------------------------
    //  K-INGコード検索結果一覧取得 取得件数 = 0
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_3() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // K-INGコード検索結果一覧取得 取得件数 = 0
        List<Map<String, String>> result = new ArrayList<>();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst481Form form = new Mst481Form();
        target.setMst481Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst481Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null, paramsCaptor_1.getValue().get("conKokyakuCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conKokunaiKashoKbn"));
        assertEquals(null, paramsCaptor_1.getValue().get("conYunyuKashoCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conYunyuKokyakuCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conHambaiKeitaiKbn"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSakujonomiKensaku"));
        assertEquals("mst481-get-king-code-detail", functionCodeCaptor_2.getValue());
        //想定通りに・一覧は表示しない（ヘッダーのみ） 
        //想定通りに ・ファンクションボタンは表示（検索前と同じ） 
        assertForRecList_2_3(form);
    }

    // getRecordCount_正常_件数取得処理_2-4
    //
    // -------------------テスト条件--------------------------
    //  K-INGコード検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_4() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // K-INGコード検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst481Form form = new Mst481Form();
        target.setMst481Form(form);
        target.getRecordCount();

        //実施結果Outを取得
        form = target.getMst481Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null, paramsCaptor_1.getValue().get("conKokyakuCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conKokunaiKashoKbn"));
        assertEquals(null, paramsCaptor_1.getValue().get("conYunyuKashoCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conYunyuKokyakuCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conHambaiKeitaiKbn"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSakujonomiKensaku"));
        assertEquals("mst481-get-king-code-kensu", functionCodeCaptor_2.getValue());
        //想定通りに正常にCountを実施されること
        assertEquals(null, form.getConKokyakuCd());
    }

    // getRecordCount_正常_件数取得処理_2-4-1
    //
    // -------------------テスト条件--------------------------
    //  K-INGコード検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_4_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // K-INGコード検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst481Form form = new Mst481Form();
        form.setConYunyuKashoCd("conYunyuKashoCd1");

        target.setMst481Form(form);
        target.getRecordCount();

        //実施結果Outを取得
        form = target.getMst481Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null, paramsCaptor_1.getValue().get("conKokyakuCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conKokunaiKashoKbn"));
        assertEquals("conYunyuKashoCd1", paramsCaptor_1.getValue().get("conYunyuKashoCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conYunyuKokyakuCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conHambaiKeitaiKbn"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSakujonomiKensaku"));
        assertEquals("mst481-get-king-code-kensu", functionCodeCaptor_2.getValue());
        //想定通りに正常にCountを実施されること
        assertEquals(null, form.getConKokyakuCd());
    }

    // getRecordCount_正常_件数取得処理_2-4-2
    //
    // -------------------テスト条件--------------------------
    //  K-INGコード検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_4_2() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // K-INGコード検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst481Form form = new Mst481Form();
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("conKokyakuCd");
        conKokyakuCd.setLabel("conKokyakuMei");
        form.setConKokyakuCd(conKokyakuCd);
        target.setMst481Form(form);
        target.getRecordCount();

        //実施結果Outを取得
        form = target.getMst481Form();

        // 実行時に渡すパラメータの検証
        AutoCompOptionBean hehe = (AutoCompOptionBean) paramsCaptor_1.getValue().get("conKokyakuCd");
        assertEquals("conKokyakuCd", hehe.getValue());
        assertEquals("conKokyakuMei", hehe.getLabel());
        assertEquals(null, paramsCaptor_1.getValue().get("conKokunaiKashoKbn"));
        assertEquals(null, paramsCaptor_1.getValue().get("conYunyuKashoCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conYunyuKokyakuCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conHambaiKeitaiKbn"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSakujonomiKensaku"));
        assertEquals("mst481-get-king-code-kensu", functionCodeCaptor_2.getValue());
    }

    // getRecordCount_正常_件数取得処理_2-4-3
    //
    // -------------------テスト条件--------------------------
    //  K-INGコード検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_4_3() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // K-INGコード検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst481Form form = new Mst481Form();
        form.setConHambaiKeitaiKbn("conHambaiKeitaiKbn1");
        target.setMst481Form(form);
        target.getRecordCount();

        //実施結果Outを取得
        form = target.getMst481Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null, paramsCaptor_1.getValue().get("conKokyakuCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conKokunaiKashoKbn"));
        assertEquals(null, paramsCaptor_1.getValue().get("conYunyuKashoCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conYunyuKokyakuCd"));
        assertEquals("conHambaiKeitaiKbn1", paramsCaptor_1.getValue().get("conHambaiKeitaiKbn"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSakujonomiKensaku"));
        assertEquals("mst481-get-king-code-kensu", functionCodeCaptor_2.getValue());
        //想定通りに正常にCountを実施されること
        assertEquals(null, form.getConKokyakuCd());
    }

    // getRecordCount_正常_件数取得処理_2-4-4
    //
    // -------------------テスト条件--------------------------
    //  K-INGコード検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_4_4() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // K-INGコード検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst481Form form = new Mst481Form();
        form.setConSakujonomiKensaku(new String[]{"conSakujonomiKensaku1"});
        target.setMst481Form(form);
        target.getRecordCount();

        //実施結果Outを取得
        form = target.getMst481Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null, paramsCaptor_1.getValue().get("conKokyakuCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conKokunaiKashoKbn"));
        assertEquals(null, paramsCaptor_1.getValue().get("conYunyuKashoCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conYunyuKokyakuCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conHambaiKeitaiKbn"));
        String[] conSakujonomiKensaku1 = (String[]) paramsCaptor_1.getValue().get("conSakujonomiKensaku");
        assertEquals("conSakujonomiKensaku1", conSakujonomiKensaku1[0]);
        assertEquals("mst481-get-king-code-kensu", functionCodeCaptor_2.getValue());
        //想定通りに正常にCountを実施されること
        assertEquals(null, form.getConKokyakuCd());
    }

    // clear_正常_クリア処理_3-1
    //
    // -------------------テスト条件--------------------------
    // 検索条件と検索結果がある
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_1() throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst481Form form = new Mst481Form();
        // 検索条件と検索結果がある
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("000001");
        conKokyakuCd.setLabel("顧客000001");
        form.setConKokyakuCd(conKokyakuCd);
        form.setConKokunaiKashoKbn("FUK");
        form.setConYunyuKashoCd("UB11");
        form.setConYunyuKokyakuCd("APPLIMATTPE");
        form.setConHambaiKeitaiKbn("2");
        form.setConSakujonomiKensaku(new String[]{"01"});

        target.setMst481Form(form);
        target.clear();

        //実施結果Outを取得
        form = target.getMst481Form();

        //想定通りに正常にClearを実施されること
        assertEquals(null, form.getConKokyakuCd());
        assertEquals(null, form.getConKokunaiKashoKbn());
        assertEquals(null, form.getConYunyuKashoCd());
        assertEquals(null, form.getConYunyuKokyakuCd());
        assertEquals(null, form.getConHambaiKeitaiKbn());
        assertEquals(null, form.getConSakujonomiKensaku());
    }

    // clear_正常_クリア処理_3-2
    //
    // -------------------テスト条件--------------------------
    // 検索条件がある、検索結果がない
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_2() throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst481Form form = new Mst481Form();
        target.setMst481Form(form);
        target.clear();

        //実施結果Outを取得
        form = target.getMst481Form();

        //想定通りに正常にClearを実施されること
        assertEquals(null, form.getConKokyakuCd());
        assertEquals(null, form.getConKokunaiKashoKbn());
        assertEquals(null, form.getConYunyuKashoCd());
        assertEquals(null, form.getConYunyuKokyakuCd());
        assertEquals(null, form.getConHambaiKeitaiKbn());
        assertEquals(null, form.getConSakujonomiKensaku());
    }

    // getHeader_正常_ダウンロード_4-1
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void getHeader_正常_ダウンロード_4_1() throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst481Form form = new Mst481Form();
        target.setMst481Form(form);
        List<CSVDto> dto = target.getHeader();

        //実施結果Outを取得
        form = target.getMst481Form();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にCVSのHeaderを設定されること
        assertEquals(null, form.getConKokyakuCd());
        assertEquals(null, form.getConKokunaiKashoKbn());
        assertEquals("国内箇所区分", dto.get(0).getTitle());
        assertEquals("listKokunaiKashoKbn", dto.get(0).getName());
        assertEquals("輸入箇所コード", dto.get(1).getTitle());
        assertEquals("listYunyuKashoCd", dto.get(1).getName());
        assertEquals("輸入顧客コード", dto.get(2).getTitle());
    }

    // beforeDown_正常_ダウンロード_4-2
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=2件
    // -----------------------------------------------------
    @Test
    public void beforeDown_正常_ダウンロード_4_2() throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst481Form form = new Mst481Form();
        target.setMst481Form(form);
        try {
            target.beforeDown("testComment");
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(Mst481BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        //実施結果Outを取得
        form = target.getMst481Form();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にダウンロード理由を記録すること
        assertEquals(null, form.getConKokyakuCd());
    }

    // upload_正常_アップロード_4_3
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void upload_正常_アップロード_4_3() throws IllegalAccessException, InvocationTargetException {
        //テスト実行
        Mst481Form form = new Mst481Form();
        Flash flash = new FlashKls();
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        when(flashUtil.getPageParam()).thenReturn(flash);
        target.upload();
    }

    // update_異常_更新処理_新規登録_11-1
    //
    // -------------------テスト条件--------------------------
    // 国内箇所区分,輸入箇所コード,輸入顧客コード,販売形態区分存在しています[MSTE0085]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_新規登録_11_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 国内箇所区分,輸入箇所コード,輸入顧客コード,販売形態区分存在しています[MSTE0086]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0086",
                "listTodofukenCdlistShimukeChiMeiCd");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5
                .capture(), tableNameCaptor_6.capture());

        //テスト実行
        Mst481Form form = new Mst481Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst481Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst481Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listKokunaiKashoKbn0", paramsCaptor_1_Param.get("listKokunaiKashoKbn"));
        assertEquals("listYunyuKashoCd0", paramsCaptor_1_Param.get("listYunyuKashoCd"));
        assertEquals("listYunyuKokyakuCd0", paramsCaptor_1_Param.get("listYunyuKokyakuCd"));
        assertEquals("listHambaiKetaiKbn0", paramsCaptor_1_Param.get("listHambaiKetaiKbn"));
        assertEquals("listKokyakuCd0", paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listYobi1", paramsCaptor_1_Param.get("listYobi1"));
        assertEquals("listYobi2", paramsCaptor_1_Param.get("listYobi2"));
        assertEquals("listYobi3", paramsCaptor_1_Param.get("listYobi3"));
        assertEquals("listYobi4", paramsCaptor_1_Param.get("listYobi4"));
        assertEquals("listYobi5", paramsCaptor_1_Param.get("listYobi5"));
        assertEquals("listYobi6", paramsCaptor_1_Param.get("listYobi6"));
        assertEquals("listYobi7", paramsCaptor_1_Param.get("listYobi7"));
        assertEquals("listYobi8", paramsCaptor_1_Param.get("listYobi8"));
        assertEquals("listYobi9", paramsCaptor_1_Param.get("listYobi9"));
        assertEquals("listYobi10", paramsCaptor_1_Param.get("listYobi10"));
        assertEquals("listDataVersion0", paramsCaptor_1_Param.get("listDataVersion"));
        assertEquals("mst481-insert-update-check", functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：MSTE0086）
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("MSTE0086", summaryCaptor_4.getValue());
    }

    // update_正常_更新処理_新規登録_11-2
    //
    // -------------------テスト条件--------------------------
    // 国内箇所区分,輸入箇所コード,輸入顧客コード,販売形態区分に存在していない
    // -----------------------------------------------------
    @Test
    public void update_正常_更新処理_新規登録_11_2() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 国内箇所区分,輸入箇所コード,輸入顧客コード,販売形態区分に存在していない
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //KINGコード変換マスタ検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture());

        //テスト実行
        Mst481Form form = new Mst481Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst481Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst481Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listKokunaiKashoKbn0", paramsCaptor_1_Param.get("listKokunaiKashoKbn"));
        assertEquals("listYunyuKashoCd0", paramsCaptor_1_Param.get("listYunyuKashoCd"));
        assertEquals("listYunyuKokyakuCd0", paramsCaptor_1_Param.get("listYunyuKokyakuCd"));
        assertEquals("listHambaiKetaiKbn0", paramsCaptor_1_Param.get("listHambaiKetaiKbn"));
        assertEquals("listKokyakuCd0", paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listYobi1", paramsCaptor_1_Param.get("listYobi1"));
        assertEquals("listYobi2", paramsCaptor_1_Param.get("listYobi2"));
        assertEquals("listYobi3", paramsCaptor_1_Param.get("listYobi3"));
        assertEquals("listYobi4", paramsCaptor_1_Param.get("listYobi4"));
        assertEquals("listYobi5", paramsCaptor_1_Param.get("listYobi5"));
        assertEquals("listYobi6", paramsCaptor_1_Param.get("listYobi6"));
        assertEquals("listYobi7", paramsCaptor_1_Param.get("listYobi7"));
        assertEquals("listYobi8", paramsCaptor_1_Param.get("listYobi8"));
        assertEquals("listYobi9", paramsCaptor_1_Param.get("listYobi9"));
        assertEquals("listYobi10", paramsCaptor_1_Param.get("listYobi10"));
        assertEquals("listDataVersion0", paramsCaptor_1_Param.get("listDataVersion"));
        assertEquals("mst481-insert-king-code", functionCodeCaptor_2.getValue());
        //想定通りに正常終了メッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("INFO", levelCaptor_3.getValue());
        assertEquals("COMI0011", summaryCaptor_4.getValue());
        assertEquals("更新", detailCaptor_5.getValue());
    }

    @Test
    public void update_異常_更新処理_新規登録_11_3() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //KINGコード変換マスタに存在しない[MSTE0086]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0086",
                "listTodofukenCdlistShimukeChiMeiCd");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture(), tableNameCaptor_6
                        .capture());

        //テスト実行
        Mst481Form form = new Mst481Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst481Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst481Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listKokunaiKashoKbn0", paramsCaptor_1_Param.get("listKokunaiKashoKbn"));
        assertEquals("listYunyuKashoCd0", paramsCaptor_1_Param.get("listYunyuKashoCd"));
        assertEquals("listYunyuKokyakuCd0", paramsCaptor_1_Param.get("listYunyuKokyakuCd"));
        assertEquals("listHambaiKetaiKbn0", paramsCaptor_1_Param.get("listHambaiKetaiKbn"));
        assertEquals("listKokyakuCd0", paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listYobi1", paramsCaptor_1_Param.get("listYobi1"));
        assertEquals("listYobi2", paramsCaptor_1_Param.get("listYobi2"));
        assertEquals("listYobi3", paramsCaptor_1_Param.get("listYobi3"));
        assertEquals("listYobi4", paramsCaptor_1_Param.get("listYobi4"));
        assertEquals("listYobi5", paramsCaptor_1_Param.get("listYobi5"));
        assertEquals("listYobi6", paramsCaptor_1_Param.get("listYobi6"));
        assertEquals("listYobi7", paramsCaptor_1_Param.get("listYobi7"));
        assertEquals("listYobi8", paramsCaptor_1_Param.get("listYobi8"));
        assertEquals("listYobi9", paramsCaptor_1_Param.get("listYobi9"));
        assertEquals("listYobi10", paramsCaptor_1_Param.get("listYobi10"));
        assertEquals("listDataVersion0", paramsCaptor_1_Param.get("listDataVersion"));
        assertEquals("mst481-insert-update-check", functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0006）
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("MSTE0086", summaryCaptor_4.getValue());
    }

    // update_異常_更新処理_更新登録_11-4
    //
    // -------------------テスト条件--------------------------
    // 国内箇所区分,輸入箇所コード,輸入顧客コード,販売形態区分に存在しない[MSTE0086]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_11_4() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        ////国内箇所区分,輸入箇所コード,輸入顧客コード,販売形態区分に存在しない[MSTE0085]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0086",
                "listKokunaiKashoKbn");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5
                .capture(), tableNameCaptor_6.capture());

        //テスト実行
        Mst481Form form = new Mst481Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst481Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst481Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listKokunaiKashoKbn0", paramsCaptor_1_Param.get("listKokunaiKashoKbn"));
        assertEquals("listYunyuKashoCd0", paramsCaptor_1_Param.get("listYunyuKashoCd"));
        assertEquals("listYunyuKokyakuCd0", paramsCaptor_1_Param.get("listYunyuKokyakuCd"));
        assertEquals("listHambaiKetaiKbn0", paramsCaptor_1_Param.get("listHambaiKetaiKbn"));
        assertEquals("listKokyakuCd0", paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listYobi1", paramsCaptor_1_Param.get("listYobi1"));
        assertEquals("listYobi2", paramsCaptor_1_Param.get("listYobi2"));
        assertEquals("listYobi3", paramsCaptor_1_Param.get("listYobi3"));
        assertEquals("listYobi4", paramsCaptor_1_Param.get("listYobi4"));
        assertEquals("listYobi5", paramsCaptor_1_Param.get("listYobi5"));
        assertEquals("listYobi6", paramsCaptor_1_Param.get("listYobi6"));
        assertEquals("listYobi7", paramsCaptor_1_Param.get("listYobi7"));
        assertEquals("listYobi8", paramsCaptor_1_Param.get("listYobi8"));
        assertEquals("listYobi9", paramsCaptor_1_Param.get("listYobi9"));
        assertEquals("listYobi10", paramsCaptor_1_Param.get("listYobi10"));
        assertEquals("listDataVersion0", paramsCaptor_1_Param.get("listDataVersion"));
        assertEquals("mst481-insert-update-check", functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：MSTE0086）
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("MSTE0086", summaryCaptor_4.getValue());
    }

    // update_正常_更新処理_更新登録_11-5
    //
    // -------------------テスト条件--------------------------
    // 国内箇所区分,輸入箇所コード,輸入顧客コード,販売形態区分に存在しています
    // -----------------------------------------------------
    @Test
    public void update_正常_更新処理_更新登録_11_5() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 国内箇所区分,輸入箇所コード,輸入顧客コード,販売形態区分に存在しています
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4
                .capture(), detailCaptor_5.capture());

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);

        //テスト実行
        Mst481Form form = new Mst481Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst481Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst481Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listKokunaiKashoKbn0", paramsCaptor_1_Param.get("listKokunaiKashoKbn"));
        assertEquals("listYunyuKashoCd0", paramsCaptor_1_Param.get("listYunyuKashoCd"));
        assertEquals("listYunyuKokyakuCd0", paramsCaptor_1_Param.get("listYunyuKokyakuCd"));
        assertEquals("listHambaiKetaiKbn0", paramsCaptor_1_Param.get("listHambaiKetaiKbn"));
        assertEquals("listKokyakuCd0", paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listYobi1", paramsCaptor_1_Param.get("listYobi1"));
        assertEquals("listYobi2", paramsCaptor_1_Param.get("listYobi2"));
        assertEquals("listYobi3", paramsCaptor_1_Param.get("listYobi3"));
        assertEquals("listYobi4", paramsCaptor_1_Param.get("listYobi4"));
        assertEquals("listYobi5", paramsCaptor_1_Param.get("listYobi5"));
        assertEquals("listYobi6", paramsCaptor_1_Param.get("listYobi6"));
        assertEquals("listYobi7", paramsCaptor_1_Param.get("listYobi7"));
        assertEquals("listYobi8", paramsCaptor_1_Param.get("listYobi8"));
        assertEquals("listYobi9", paramsCaptor_1_Param.get("listYobi9"));
        assertEquals("listYobi10", paramsCaptor_1_Param.get("listYobi10"));
        assertEquals("listDataVersion0", paramsCaptor_1_Param.get("listDataVersion"));
        //想定通りに正常終了メッセージ（メッセージID：COMI0007）を表示されること
        assertEquals("INFO", levelCaptor_3.getValue());
        assertEquals("COMI0011", summaryCaptor_4.getValue());
        assertEquals("更新", detailCaptor_5.getValue());

    }

    // update_異常_更新処理_更新登録_11-7
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_11_7() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(), summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        //テスト実行
        Mst481Form form = new Mst481Form();
        //行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        form.setSelectedSearchResult(result);
        target.setMst481Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst481Form();

        //想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("ERROR", levelCaptor_1.getValue());
        assertEquals("COME0029", summaryCaptor_2.getValue());
    }

    // update_異常_更新処理_更新登録_11-7_1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_11_7_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(), summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        //テスト実行
        Mst481Form form = new Mst481Form();
        target.setMst481Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst481Form();

        //想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("ERROR", levelCaptor_1.getValue());
        assertEquals("COME0029", summaryCaptor_2.getValue());
    }

    // update_異常_更新処理_更新登録_11-8
    //
    // -------------------テスト条件--------------------------
    // 仕向地名コード = ああああ
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_11_8() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Boolean> datasCaptor_3 = ArgumentCaptor.forClass(Boolean.class);
        ArgumentCaptor<List> checksCaptor_4 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<List> checksCaptor_5 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean2 = new MessageModuleBean();
        List<MessageModuleBean> msgList = new ArrayList<>();
        msgList.add(messageModuleBean2);

        when(listCheckBean.check(checksCaptor_4.capture(), checksCaptor_5.capture(), datasCaptor_3.capture()))
                .thenReturn(msgList);

        //テスト実行
        Mst481Form form = new Mst481Form();
        //行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
	form.setSelectedSearchResult(result);
        form.setSelectedSearchResult(result);
        target.setMst481Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst481Form();

    }

    // delRows_正常_K-INGコード変換マスタ削除処理_12-1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 1
    //  国内箇所区分,輸入箇所コード,輸入顧客コード,販売形態区分に存在している
    // -----------------------------------------------------
    @Test
    public void delRows_正常_KINGコード変換マスタ削除処理_12_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5
                .capture());
        //テスト実行
        Mst481Form form = new Mst481Form();
        //行選択チェック選択 = 1
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
	form.setSelectedSearchResult(result);
        form.setSearchResult(result);
        target.setMst481Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst481Form();

        //想定通りに正常終了メッセージ（メッセージID：COMI0011）を表示されることK-INGコード変換マスタ削除処理を行う。
        assertEquals("INFO", levelCaptor_3.getValue());
        assertEquals("COMI0011", summaryCaptor_4.getValue());
        assertEquals("削除", detailCaptor_5.getValue());
    }

    // delRows_正常_K-INGコード変換マスタ削除処理_12-2
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 2
    // 国内箇所区分,輸入箇所コード,輸入顧客コード,販売形態区分に存在している
    // -----------------------------------------------------
    @Test
    public void delRows_正常_KINGコード変換マスタ削除処理_12_2() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5
                .capture());
        //テスト実行
        Mst481Form form = new Mst481Form();
        //行選択チェック選択 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            result.add(createRecMapFor_11_1(i));
        }
	form.setSelectedSearchResult(result);
        form.setSearchResult(result);
        target.setMst481Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst481Form();

        //想定通りに正常終了メッセージ（メッセージID：COMI0011）を表示されることK-INGコード変換マスタ削除処理を行う。
        assertEquals("INFO", levelCaptor_3.getValue());
        assertEquals("COMI0011", summaryCaptor_4.getValue());
        assertEquals("削除", detailCaptor_5.getValue());
    }

    // delRows_正常_K-INGコード変換マスタ削除処理_12-2_1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 2
    // 国内箇所区分,輸入箇所コード,輸入顧客コード,販売形態区分に存在している
    // -----------------------------------------------------
    @Test
    public void delRows_正常_KINGコード変換マスタ削除処理_12_2_1() throws IllegalAccessException,
            InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        serviceInterfaceBean2.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean,serviceInterfaceBean2);
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5
                .capture());
        //テスト実行
        Mst481Form form = new Mst481Form();
        //行選択チェック選択 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst481Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst481Form();
        Date tekiyoBi = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        try {
            tekiyoBi = format.parse("2019/01/01");
        } catch (ParseException ex) {
            Logger.getLogger(Mst481BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listHambaiKeitaiKbn0", paramsCaptor_1_Param.get("listHambaiKeitaiKbn"));
        assertEquals("listKokyakuCd0", paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listHambaiKetaiKbn0", paramsCaptor_1_Param.get("listHambaiKetaiKbn"));
        assertEquals("listYunyuKokyakuCd0", paramsCaptor_1_Param.get("listYunyuKokyakuCd"));
        assertEquals("mst481-delete-row-detail", functionCodeCaptor_2.getValue());
    }
    
    // delRows_異常_K-INGコード変換マスタ削除処理_12-3
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // 国内箇所区分,輸入箇所コード,輸入顧客コード,販売形態区分に存在している
    // -----------------------------------------------------
    @Test
    public void delRows_異常_KINGコード変換マスタ削除処理_12_3() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(), summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        //テスト実行
        Mst481Form form = new Mst481Form();
        //行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        form.setSelectedSearchResult(result);
        target.setMst481Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst481Form();

        //想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("ERROR", levelCaptor_1.getValue());
        assertEquals("COME0013", summaryCaptor_2.getValue());
    }

    // delRows_異常_K-INGコード変換マスタ削除処理_12-4
    //
    // -------------------テスト条件--------------------------
    // 国内箇所区分,輸入箇所コード,輸入顧客コード,販売形態区分に存在しない
    // -----------------------------------------------------
    @Test
    public void delRows_異常_KINGコード変換マスタ削除処理_12_4() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // KINGコード変換マスタに存在しない[COME0006]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0086",
                "KokunaiKashoKbn");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(), summaryCaptor_2
                .capture(), summaryCaptor_3.capture(), summaryCaptor_4.capture())).thenReturn(messageModuleBean);

        //テスト実行
        Mst481Form form = new Mst481Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        form.setSearchResult(result);
        target.setMst481Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst481Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listKokunaiKashoKbn0", paramsCaptor_1_Param.get("listKokunaiKashoKbn"));
        assertEquals("listYunyuKashoCd0", paramsCaptor_1_Param.get("listYunyuKashoCd"));
        assertEquals("listYunyuKokyakuCd0", paramsCaptor_1_Param.get("listYunyuKokyakuCd"));
        assertEquals("listHambaiKetaiKbn0", paramsCaptor_1_Param.get("listHambaiKetaiKbn"));
        assertEquals("listKokyakuCd0", paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listYobi1", paramsCaptor_1_Param.get("listYobi1"));
        assertEquals("listYobi2", paramsCaptor_1_Param.get("listYobi2"));
        assertEquals("listYobi3", paramsCaptor_1_Param.get("listYobi3"));
        assertEquals("listYobi4", paramsCaptor_1_Param.get("listYobi4"));
        assertEquals("listYobi5", paramsCaptor_1_Param.get("listYobi5"));
        assertEquals("listYobi6", paramsCaptor_1_Param.get("listYobi6"));
        assertEquals("listYobi7", paramsCaptor_1_Param.get("listYobi7"));
        assertEquals("listYobi8", paramsCaptor_1_Param.get("listYobi8"));
        assertEquals("listYobi9", paramsCaptor_1_Param.get("listYobi9"));
        assertEquals("listYobi10", paramsCaptor_1_Param.get("listYobi10"));
        assertEquals("listDataVersion0", paramsCaptor_1_Param.get("listDataVersion"));
        assertEquals("mst481-delete-exist", functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：MSTE0086）
        assertEquals("ERROR", levelCaptor_1.getValue());
        assertEquals("MSTE0086", summaryCaptor_2.getValue());
    }

    // rirekiIchiran_正常_更新履歴コンテキストメニュー_13-1
    //
    // -------------------テスト条件--------------------------
    // 正常に取得された場合
    // -----------------------------------------------------
    @Test
    public void rirekiIchiran_正常_更新履歴コンテキストメニュー_13_1() throws IllegalAccessException,
            InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> titleFlgCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> searchKeyCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(rirekiSyosaiBean).searchList(titleFlgCaptor_1.capture(), functionCodeCaptor_2.capture(),
                searchKeyCaptor_3.capture());
        //テスト実行
        Mst481Form form = new Mst481Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst481Form(form);
        target.rirekiIchiran();

        //実施結果Outを取得
        form = target.getMst481Form();

        //想定通りに履歴を表示する。
        assertEquals("2", titleFlgCaptor_1.getValue());
        assertEquals("MST481_SEARCH_RIREKI", functionCodeCaptor_2.getValue());
        assertEquals("listKokunaiKashoKbn0", searchKeyCaptor_3.getValue().get("listKokunaiKashoKbn"));
        assertEquals("listYunyuKashoCd0", searchKeyCaptor_3.getValue().get("listYunyuKashoCd"));
        assertEquals("listYunyuKokyakuCd0", searchKeyCaptor_3.getValue().get("listYunyuKokyakuCd"));
        assertEquals("listHambaiKeitaiKbn0", searchKeyCaptor_3.getValue().get("listHambaiKeitaiKbn"));
    }

    // searchChange_正常_補充ケース_14-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void searchChange_正常_補充ケース_14_1() throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst481Form form = new Mst481Form();
        target.setMst481Form(form);
        target.searchChange();

        //実施結果Outを取得
        form = target.getMst481Form();

    }

    // menuClick_正常_補充ケース_14-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_14_2() throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst481Form form = new Mst481Form();
        target.setMst481Form(form);
        target.menuClick("", "");

        //実施結果Outを取得
        form = target.getMst481Form();

    }

    // menuClick_正常_補充ケース_14-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_14_2_1() throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(1);

        //テスト実行
        Mst481Form form = new Mst481Form();
        target.setMst481Form(form);
        target.menuClick("", "");

        //実施結果Outを取得
        form = target.getMst481Form();

    }

    // breadClumClick_正常_補充ケース_14-3
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_14_3() throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst481Form form = new Mst481Form();
        target.setMst481Form(form);
        target.breadClumClick("", 0);

        //実施結果Outを取得
        form = target.getMst481Form();

    }

    // breadClumClick_正常_補充ケース_14-3_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_14_3_1() throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(0);

        //テスト実行
        Mst481Form form = new Mst481Form();
        target.setMst481Form(form);
        target.breadClumClick("", 0);

        //実施結果Outを取得
        form = target.getMst481Form();

    }

    // logoutClick_正常_補充ケース_14-4
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void logoutClick_正常_補充ケース_14_4() throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst481Form form = new Mst481Form();
        target.setMst481Form(form);
        target.logoutClick();

        //実施結果Outを取得
        form = target.getMst481Form();

    }

    // delRowsFunc_正常_補充ケース_14-5
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void delRowsFunc_正常_補充ケース_14_5() throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst481Form form = new Mst481Form();
        target.setMst481Form(form);
        target.delRowsFunc();

        //実施結果Outを取得
        form = target.getMst481Form();

    }

    //顧客取得Autocomplete一覧を取得する処理
    //
    //
    //
    @Test
    public void getAutoComp_顧客取得処理_15() throws IllegalAccessException, InvocationTargetException {
        //テスト実行
        Mst481Form form = new Mst481Form();
        target.setMst481Form(form);
        target.getAutoCompForKokyakuCdList("conKokyakuCd1");

        //実施結果Outを取得
        form = target.getMst481Form();
    }

    //ダウンロード販売形態区分名を取得する処理
    //
    @Test
    public void getHambai_販売形態区分処理_16() throws IllegalAccessException, InvocationTargetException {
        //テスト実行
        Mst481Form form = new Mst481Form();
        List<Map<String, Object>> result = new ArrayList<>();
	for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
	ReportListDataModel searchResultSelectable = new ReportListDataModel(result);
	form.setSearchResultSelectable(searchResultSelectable);
        target.setMst481Form(form);
        target.hambaiKeitaiKbnSet("1", 0);

        //実施結果Outを取得
        form = target.getMst481Form();
    }

    //ダウンロード販売形態区分名を取得する処理
    //
    @Test
    public void getHambai_販売形態区分処理_16_1() throws IllegalAccessException, InvocationTargetException {
        //テスト実行
        Mst481Form form = new Mst481Form();
	List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
	ReportListDataModel searchResultSelectable = new ReportListDataModel(result);
	form.setSearchResultSelectable(searchResultSelectable);
        target.setMst481Form(form);
        target.hambaiKeitaiKbnSet("2", 0);
         
        //実施結果Outを取得
        form = target.getMst481Form();
	
    }

    //ダウンロード販売形態区分名を取得する処理
    //
    @Test
    public void getHambai_販売形態区分処理_16_2() throws IllegalAccessException, InvocationTargetException {
        //テスト実行
        Mst481Form form = new Mst481Form();
	List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_11_1(i));
        }
	ReportListDataModel searchResultSelectable = new ReportListDataModel(result);
	form.setSearchResultSelectable(searchResultSelectable);
        target.setMst481Form(form);
        target.hambaiKeitaiKbnSet("10086", 0);

        //実施結果Outを取得
        form = target.getMst481Form();
    }

    private Map<String, String> createRecMapFor_1_1(int i) {
        Map recMap = new HashMap();
        recMap.put("listHambaiKeitaiKbn", "listHambaiKeitaiKbn" + i);
        recMap.put("listKokyakuCd", "listKokyakuCd" + i);
        recMap.put("listHambaiKetaiKbn", "listHambaiKetaiKbn" + i);
        recMap.put("listYunyuKokyakuCd", "listYunyuKokyakuCd" + i);
        recMap.put("listYunyuKashoCd", "listYunyuKashoCd" + i);
        recMap.put("listKokunaiKashoKbn", "listKokunaiKashoKbn" + i);
        recMap.put("listYobi1", "listYobi1"+ i);
        recMap.put("listYobi2", "listYobi2"+ i);
        recMap.put("listYobi3", "listYobi3"+ i);
        recMap.put("listYobi4", "listYobi4"+ i);
        recMap.put("listYobi5", "listYobi5"+ i);
        recMap.put("listYobi6", "listYobi6"+ i);
        recMap.put("listYobi7", "listYobi7"+ i);
        recMap.put("listYobi8", "listYobi8"+ i);
        recMap.put("listYobi9", "listYobi9"+ i);
        recMap.put("listYobi10", "listYobi10"+ i);
        recMap.put("listDataVersion", "listDataVersion" + i);

        return recMap;
    }

    private Map<String, Object> createRecMapFor_11_1(int i) {
        Map recMap = new HashMap();
        recMap.put("listHambaiKeitaiKbn", "listHambaiKeitaiKbn" + i);
        recMap.put("listKokyakuCd", "listKokyakuCd" + i);
        recMap.put("listHambaiKetaiKbn", "listHambaiKetaiKbn" + i);
        recMap.put("listYunyuKokyakuCd", "listYunyuKokyakuCd" + i);
        recMap.put("listYunyuKashoCd", "listYunyuKashoCd" + i);
        recMap.put("listKokunaiKashoKbn", "listKokunaiKashoKbn" + i);
        recMap.put("listYobi1", "listYobi1");
        recMap.put("listYobi2", "listYobi2");
        recMap.put("listYobi3", "listYobi3");
        recMap.put("listYobi4", "listYobi4");
        recMap.put("listYobi5", "listYobi5");
        recMap.put("listYobi6", "listYobi6");
        recMap.put("listYobi7", "listYobi7");
        recMap.put("listYobi8", "listYobi8");
        recMap.put("listYobi9", "listYobi9");
        recMap.put("listYobi10", "listYobi10");
        recMap.put("listDataVersion", "listDataVersion" + i);
        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }

    private void assertForRecList_2_1(Mst481Form form) {
        int i = 0;
        assertEquals(1, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listHambaiKeitaiKbn" + i, rec.get("listHambaiKeitaiKbn"));
            assertEquals("listKokyakuCd" + i, rec.get("listKokyakuCd"));
            assertEquals("listHambaiKetaiKbn" + i, rec.get("listHambaiKetaiKbn"));
            assertEquals("listYunyuKokyakuCd" + i, rec.get("listYunyuKokyakuCd"));
            assertEquals("listKokunaiKashoKbn" + i, rec.get("listKokunaiKashoKbn"));
	    assertEquals("listYobi1" + i, rec.get("listYobi1"));
            assertEquals("listYobi2" + i, rec.get("listYobi2"));
            assertEquals("listYobi3" + i, rec.get("listYobi3"));
	    assertEquals("listYobi5" + i, rec.get("listYobi5"));
            assertEquals("listYobi6" + i, rec.get("listYobi6"));
            assertEquals("listYobi7" + i, rec.get("listYobi7"));
	    assertEquals("listYobi8" + i, rec.get("listYobi8"));
            assertEquals("listYobi9" + i, rec.get("listYobi9"));
            assertEquals("listYobi4" + i, rec.get("listYobi4"));
	    assertEquals("listYobi10" + i, rec.get("listYobi10"));
            assertEquals("listDataVersion" + i, rec.get("listDataVersion"));
            i++;
        }
    }

    private void assertForRecList_2_2(Mst481Form form) {
        int i = 0;
        assertEquals(2, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listHambaiKeitaiKbn" + i, rec.get("listHambaiKeitaiKbn"));
            assertEquals("listKokyakuCd" + i, rec.get("listKokyakuCd"));
            assertEquals("listHambaiKetaiKbn" + i, rec.get("listHambaiKetaiKbn"));
            assertEquals("listYunyuKokyakuCd" + i, rec.get("listYunyuKokyakuCd"));
            assertEquals("listKokunaiKashoKbn" + i, rec.get("listKokunaiKashoKbn"));
	    assertEquals("listYobi1" + i, rec.get("listYobi1"));
            assertEquals("listYobi2" + i, rec.get("listYobi2"));
            assertEquals("listYobi3" + i, rec.get("listYobi3"));
	    assertEquals("listYobi5" + i, rec.get("listYobi5"));
            assertEquals("listYobi6" + i, rec.get("listYobi6"));
            assertEquals("listYobi7" + i, rec.get("listYobi7"));
	    assertEquals("listYobi8" + i, rec.get("listYobi8"));
            assertEquals("listYobi9" + i, rec.get("listYobi9"));
            assertEquals("listYobi4" + i, rec.get("listYobi4"));
	    assertEquals("listYobi10" + i, rec.get("listYobi10"));
            assertEquals("listDataVersion" + i, rec.get("listDataVersion"));
            i++;
        }
    }

    private void assertForRecList_2_3(Mst481Form form) {
        int i = 0;
        assertEquals(0, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listHambaiKeitaiKbn" + i, rec.get("listHambaiKeitaiKbn"));
            assertEquals("listKokyakuCd" + i, rec.get("listKokyakuCd"));
            assertEquals("listHambaiKetaiKbn" + i, rec.get("listHambaiKetaiKbn"));
            assertEquals("listYunyuKokyakuCd" + i, rec.get("listYunyuKokyakuCd"));
            assertEquals("listKokunaiKashoKbn" + i, rec.get("listKokunaiKashoKbn"));
	    assertEquals("listYobi1" + i, rec.get("listYobi1"));
            assertEquals("listYobi2" + i, rec.get("listYobi2"));
            assertEquals("listYobi3" + i, rec.get("listYobi3"));
	    assertEquals("listYobi5" + i, rec.get("listYobi5"));
            assertEquals("listYobi6" + i, rec.get("listYobi6"));
            assertEquals("listYobi7" + i, rec.get("listYobi7"));
	    assertEquals("listYobi8" + i, rec.get("listYobi8"));
            assertEquals("listYobi9" + i, rec.get("listYobi9"));
            assertEquals("listYobi4" + i, rec.get("listYobi4"));
	    assertEquals("listYobi10" + i, rec.get("listYobi10"));
            assertEquals("listDataVersion" + i, rec.get("listDataVersion"));
            i++;
        }
    }

    @Test
    public void test_getSetUrl() throws IllegalAccessException, InvocationTargetException {
        String url = target.getUrl();
        target.setUrl(url);

        String title = target.getTITLE();

        assertEquals(url, target.getUrl());
    }

}
