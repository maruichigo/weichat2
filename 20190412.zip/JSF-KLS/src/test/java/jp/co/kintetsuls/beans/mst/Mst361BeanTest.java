/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.mst;

import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst361Form;
import jp.co.kintetsuls.utils.FlashUtil;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import org.junit.After;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import org.mockito.MockitoAnnotations;

/**
 * 月額自動請求マスタ(輸送売上)画面
 *
 * @author 邱志遠
 * @version 2019/03/22 新規作成
 */
public class Mst361BeanTest {
    
    // テストTarget
    @InjectMocks
    private Mst361Bean target;
    
    // Mockitoオブジェクト
    @Mock
    private FileBean fileBean;
    @Mock
    private AutoCompleteViewBean autoCompleteViewBean;
    @Mock
    private MasterInfoBean masterInfo;
    @Mock
    private MessagePropertyBean messageProperty;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosai;
    @Mock
    private SearchHelpBean searchHelpBean;
    @Mock
    private AuthorityConfBean authConfBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosaiBean;
    @Mock
    private ListCheckBean listCheckBean;
    @Mock
    private FlashUtil flashUtil;
    
    public Mst361BeanTest() {
    }

    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() {
    }
    
    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[not null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1 () throws IllegalAccessException, InvocationTargetException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst361Form mst361Form = new Mst361Form();
        
        // 前画面情報[not null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst361Form);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        // テスト実行
        Mst361Form form = new Mst361Form();
        target.setMst361Form(form);
        // 戻ってきた場合、再検索を実施する。
        target.init("","MST031_SCREEN",true);
        
        //実施結果Outを取得
        form = target.getMst361Form();
        String title = target.getTitleName();
        String url = target.getUrl();
        AuthorityConfBean authorityConfBean  = target.getAuthConfBean();
        Map<String, Object> rirekiSearchKey = target.getRirekiSearchKey();
        List<MessageModuleBean> msgList = target.getMsgList();
        target.setUrl(url);
        target.setBreadBean(breadBean);
        target.setAutoCompleteViewBean(autoCompleteViewBean);
        target.setAuthConfBean(authorityConfBean);
        target.setFileBean(fileBean);
        target.setMessageProperty(messageProperty);
        target.setPageCommonBean(pageCommonBean);
        target.setSearchHelpBean(searchHelpBean);
        target.setRirekiSyosaiBean(rirekiSyosaiBean);
        target.setListCheckBean(listCheckBean);
        target.setRirekiSearchKey(rirekiSearchKey);
        target.setMsgList(msgList);
        
        // 実行時に渡すパラメータの検証
        assertEquals("mst361Form",keyCaptor_1.getValue());
        //想定通りに再検索を実施する。
        assertEquals("search_mst361",keyCaptor_2.getValue());
    }
    
    // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[営業所コード = 111,顧客 = 000002,,料金項目 = 02,適用名 = ppp,世代検索条件 = {"01", "02"},適用日指定 = null,申請状況 = {"01", "02", "03", "04", "05"},削除済のみ検索 = null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2() throws IllegalAccessException, InvocationTargetException,
            InstantiationException {

        // Mockitoオブジェクトの予想return値設定
        Mst361Form mst361Form = new Mst361Form();
        //前回検索パラメータ[営業所コード = 111,顧客 = 000002,,料金項目 = 02,適用名 = ppp,世代検索条件 = {"01", "02"},適用日指定 = null,申請状況 = {"01", "02", "03", "04", "05"},削除済のみ検索 = null]
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("111");
        mst361Form.setConEigyoshoCd(conEigyoshoCd);

        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("000002");
        mst361Form.setConKokyakuCd(conKokyakuCd);
        
        AutoCompOptionBean conRyokinKomoku = new AutoCompOptionBean();
        conRyokinKomoku.setValue("02");
        mst361Form.setConRyokinKomoku(conRyokinKomoku);
        
        mst361Form.setConTekiyoMei("ppp");
                
        mst361Form.setConSedaiKensakuJoken(new String[]{"01", "02"});
        
        mst361Form.setConTekiyoBi(null);
       
        mst361Form.setConSakujonomiKensaku(null);
        
        mst361Form.setConShinseiJokyo(new String[]{"01", "02", "03", "04", "05"});
        
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        //前画面パラメータ[営業所コード = 111,顧客 = 000002,,料金項目 = 02,適用名 = ppp,世代検索条件 = {"01", "02"},適用日指定 = null,申請状況 = {"01", "02", "03", "04", "05"},削除済のみ検索 = null]
        flash.put("mst361Form", mst361Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);        

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst361Form form = new Mst361Form();
        target.setMst361Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst361Form();

        //想定通りに再検索を実施する。
        assertEquals("search_mst361", keyCaptor_2.getValue());
        assertEquals("111", form.getConEigyoshoCd().getValue());
        assertEquals("000002", form.getConKokyakuCd().getValue());
        assertEquals("02", form.getConRyokinKomoku().getValue());
        assertEquals("ppp", form.getConTekiyoMei());
        assertEquals("01", form.getConSedaiKensakuJoken()[0]);
        assertEquals("02", form.getConSedaiKensakuJoken()[1]);
        assertEquals(null, form.getConTekiyoBi());
        assertEquals(null, form.getConSakujonomiKensaku());
        assertEquals("01", form.getConShinseiJokyo()[0]);
        assertEquals("02", form.getConShinseiJokyo()[1]);
        assertEquals("03", form.getConShinseiJokyo()[2]);
        assertEquals("04", form.getConShinseiJokyo()[3]);
        assertEquals("05", form.getConShinseiJokyo()[4]);
    }
    
    // init_正常_初期処理_1_3
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[営業所コード = 111,顧客 = 000002,料金項目 = 02,適用名 = ppp,世代検索条件 = {"01", "02"},適用日指定 = null,申請状況 = {"01"},削除済のみ検索 = null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3() throws IllegalAccessException, InvocationTargetException,
            InstantiationException {

        // Mockitoオブジェクトの予想return値設定
        Mst361Form mst361Form = new Mst361Form();
        //前回検索パラメータ[営業所コード = 111,顧客 = 000002,料金項目 = 02,適用名 = ppp,世代検索条件 = {"01", "02"},適用日指定 = null,申請状況 = {"01"},削除済のみ検索 = null]
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("111");
        mst361Form.setConEigyoshoCd(conEigyoshoCd);

        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("000002");
        mst361Form.setConKokyakuCd(conKokyakuCd);
        
        AutoCompOptionBean conRyokinKomoku = new AutoCompOptionBean();
        conRyokinKomoku.setValue("02");
        mst361Form.setConRyokinKomoku(conRyokinKomoku);
        
        mst361Form.setConTekiyoMei("ppp");
                
        mst361Form.setConSedaiKensakuJoken(new String[]{"01", "02"});
        
        mst361Form.setConTekiyoBi(null);
       
        mst361Form.setConSakujonomiKensaku(null);
        
        mst361Form.setConShinseiJokyo(new String[]{"01"});
        
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        //前画面パラメータ[営業所コード = 111,顧客 = 000002,料金項目 = 02,適用名 = ppp,世代検索条件 = {"01", "02"},適用日指定 = null,申請状況 = {"01"},削除済のみ検索 = null]
        flash.put("mst361Form", null);
        when(pageCommonBean.getPageParam()).thenReturn(flash);        

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst361Form form = new Mst361Form();
        target.setMst361Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst361Form();

        //想定通りに再検索を実施する。
        assertEquals(null,form.getConSakujonomiKensaku());
    } 
    
    // init_正常_初期処理_1_4
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        //前画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(null);

        //テスト実行
        Mst361Form form = new Mst361Form();
        target.setMst361Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst361Form",keyCaptor_1.getValue());
        //想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null,form.getSearchResult());
    }

    // init_正常_初期処理_1_5
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_5 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        //前画面情報[null]
        doThrow(IllegalAccessException.class).when(pageCommonBean).getPageInfo(keyCaptor_1.capture());

        //テスト実行
        Mst361Form form = new Mst361Form();
        target.setMst361Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst361Form",keyCaptor_1.getValue());
        //想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null,form.getSearchResult());
    }
    // search_正常_検索処理_2-1
    //
    // -------------------テスト条件--------------------------
    // 検索結果一覧取得
    // 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 0; i++){
            result.add(createRecMapFor_2_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst361Form form = new Mst361Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("111");
        form.setConEigyoshoCd(conEigyoshoCd);

        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("000002");
        form.setConKokyakuCd(conKokyakuCd);
        
        AutoCompOptionBean conRyokinKomoku = new AutoCompOptionBean();
        conRyokinKomoku.setValue("02");
        form.setConRyokinKomoku(conRyokinKomoku);
        
        form.setConTekiyoMei("ppp");
                
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        
        form.setConTekiyoBi(null);
       
        form.setConSakujonomiKensaku(null);
        
        form.setConShinseiJokyo(new String[]{"01"});
        target.setMst361Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        assertEquals("111", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("000002", paramsCaptor_1.getValue().get("conKokyakuCd"));
        String[] conSedaiKensakuJoken =  (String[]) paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals("1", conSedaiKensakuJoken[0]);
        assertEquals("1", conSedaiKensakuJoken[1]);
        assertEquals("02", paramsCaptor_1.getValue().get("conRyokinKomoku"));
        assertEquals("ppp", paramsCaptor_1.getValue().get("conTekiyoMei"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSakujoNomiKensaku"));
        String[] conShinseiJokyo =  (String[]) paramsCaptor_1.getValue().get("conShinseiJokyo");
        assertEquals("01", conShinseiJokyo[0]);
        assertEquals("mst361_search",functionCodeCaptor_2.getValue());
        //想定通りに一覧を表示されること
        assertForRecList_2_1(form);
    }
    
    // search_正常_検索処理_2-2
    //
    // -------------------テスト条件--------------------------
    // 検索結果一覧取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 1; i++){
            result.add(createRecMapFor_2_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst361Form form = new Mst361Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("111");
        form.setConEigyoshoCd(conEigyoshoCd);

        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("000002");
        form.setConKokyakuCd(conKokyakuCd);
        
        AutoCompOptionBean conRyokinKomoku = new AutoCompOptionBean();
        conRyokinKomoku.setValue("02");
        form.setConRyokinKomoku(conRyokinKomoku);
        
        form.setConTekiyoMei("ppp");
                
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        
        form.setConTekiyoBi(null);
       
        form.setConSakujonomiKensaku(null);
        
        form.setConShinseiJokyo(new String[]{"01"});
        target.setMst361Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        assertEquals("111", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("000002", paramsCaptor_1.getValue().get("conKokyakuCd"));
        String[] conSedaiKensakuJoken =  (String[]) paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals("1", conSedaiKensakuJoken[0]);
        assertEquals("1", conSedaiKensakuJoken[1]);
        assertEquals("02", paramsCaptor_1.getValue().get("conRyokinKomoku"));
        assertEquals("ppp", paramsCaptor_1.getValue().get("conTekiyoMei"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSakujoNomiKensaku"));
        String[] conShinseiJokyo =  (String[]) paramsCaptor_1.getValue().get("conShinseiJokyo");
        assertEquals("01", conShinseiJokyo[0]);
        assertEquals("mst361_search",functionCodeCaptor_2.getValue());
        //想定通りに一覧を表示されること
        assertForRecList_2_2(form);
    }
    
    // search_異常_検索処理_2-3
    //
    // -------------------テスト条件--------------------------
    // 検索結果一覧取得 取得件数 = 0
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索結果一覧取得 取得件数 = 0
        List<Map<String, String>> result = new ArrayList<>();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // テスト実行
        Mst361Form form = new Mst361Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("全て");
        form.setConEigyoshoCd(conEigyoshoCd);

        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("000002");
        form.setConKokyakuCd(conKokyakuCd);
        
        AutoCompOptionBean conRyokinKomoku = new AutoCompOptionBean();
        conRyokinKomoku.setValue("02");
        form.setConRyokinKomoku(conRyokinKomoku);
        
        form.setConTekiyoMei("ppp");
                
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        
        form.setConTekiyoBi(null);
       
        form.setConSakujonomiKensaku(null);
        
        form.setConShinseiJokyo(new String[]{"01"});
        target.setMst361Form(form);
        target.search();

        // 実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        assertEquals("全て", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("000002", paramsCaptor_1.getValue().get("conKokyakuCd"));
        String[] conSedaiKensakuJoken =  (String[]) paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals("1", conSedaiKensakuJoken[0]);
        assertEquals("1", conSedaiKensakuJoken[1]);
        assertEquals("02", paramsCaptor_1.getValue().get("conRyokinKomoku"));
        assertEquals("ppp", paramsCaptor_1.getValue().get("conTekiyoMei"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSakujoNomiKensaku"));
        String[] conShinseiJokyo =  (String[]) paramsCaptor_1.getValue().get("conShinseiJokyo");
        assertEquals("01", conShinseiJokyo[0]);
        assertEquals("mst361_search",functionCodeCaptor_2.getValue());
        //想定通りに・一覧は表示しない（ヘッダーのみ） 
        //想定通りに ・ファンクションボタンは表示（検索前と同じ） 
        assertForRecList_2_3(form);
    }
    
    // getRecordCount_正常_件数取得処理_2-4
    //
    // -------------------テスト条件--------------------------
    // 検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst361Form form = new Mst361Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("111");
        form.setConEigyoshoCd(conEigyoshoCd);

        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("000002");
        form.setConKokyakuCd(conKokyakuCd);
        
        AutoCompOptionBean conRyokinKomoku = new AutoCompOptionBean();
        conRyokinKomoku.setValue("02");
        form.setConRyokinKomoku(conRyokinKomoku);
        
        form.setConTekiyoMei("ppp");
                
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        
        form.setConTekiyoBi(null);
       
        form.setConSakujonomiKensaku(null);
        
        form.setConShinseiJokyo(new String[]{"01"});
        target.setMst361Form(form);
        target.getRecordCount(false);

        //実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        assertEquals("111", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("000002", paramsCaptor_1.getValue().get("conKokyakuCd"));
        String[] conSedaiKensakuJoken =  (String[]) paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals("1", conSedaiKensakuJoken[0]);
        assertEquals("1", conSedaiKensakuJoken[1]);
        assertEquals("02", paramsCaptor_1.getValue().get("conRyokinKomoku"));
        assertEquals("ppp", paramsCaptor_1.getValue().get("conTekiyoMei"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSakujoNomiKensaku"));
        String[] conShinseiJokyo =  (String[]) paramsCaptor_1.getValue().get("conShinseiJokyo");
        assertEquals("01", conShinseiJokyo[0]);
        assertEquals("mst361_kensu",functionCodeCaptor_2.getValue());
    }
    
    // clear_正常_クリア処理_3-1
    //
    // -------------------テスト条件--------------------------
    // 検索条件と検索結果がある
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_1 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst361Form form = new Mst361Form();
        // 検索条件と検索結果がある
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("111");
        form.setConEigyoshoCd(conEigyoshoCd);

        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("000002");
        form.setConKokyakuCd(conKokyakuCd);
        
        AutoCompOptionBean conRyokinKomoku = new AutoCompOptionBean();
        conRyokinKomoku.setValue("02");
        form.setConRyokinKomoku(conRyokinKomoku);
        
        form.setConTekiyoMei("ppp");
                
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        
        form.setConTekiyoBi(null);
       
        form.setConSakujonomiKensaku(null);
        
        form.setConShinseiJokyo(new String[]{"01"});

        target.setMst361Form(form);
        target.clear();

        // 実施結果Outを取得
        form = target.getMst361Form();

        //想定通りに正常にClearを実施されること
        assertEquals(null,form.getConEigyoshoCd());
        assertEquals(null,form.getConKokyakuCd());
        assertEquals(null,form.getConRyokinKomoku());
        assertEquals(null,form.getConTekiyoMei());
        assertEquals("01",form.getConSedaiKensakuJoken()[0]);
        assertEquals("02",form.getConSedaiKensakuJoken()[1]);
        assertEquals(null,form.getConTekiyoBi());
        assertEquals(null,form.getConSakujonomiKensaku());
        assertEquals("01",form.getConShinseiJokyo()[0]);
        assertEquals("02",form.getConShinseiJokyo()[1]);
        assertEquals("03",form.getConShinseiJokyo()[2]);
        assertEquals("04",form.getConShinseiJokyo()[3]);
        assertEquals("05",form.getConShinseiJokyo()[4]);
    }

    // clear_正常_クリア処理_3-2
    //
    // -------------------テスト条件--------------------------
    // 検索条件がある、検索結果がない
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_2 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst361Form form = new Mst361Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("111");
        form.setConEigyoshoCd(conEigyoshoCd);

        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("000002");
        form.setConKokyakuCd(conKokyakuCd);
        
        AutoCompOptionBean conRyokinKomoku = new AutoCompOptionBean();
        conRyokinKomoku.setValue("02");
        form.setConRyokinKomoku(conRyokinKomoku);
        
        form.setConTekiyoMei("ppp");
                
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        
        form.setConTekiyoBi(null);
       
        form.setConSakujonomiKensaku(null);
        
        form.setConShinseiJokyo(new String[]{"01"});
        target.setMst361Form(form);
        target.clear();

        // 実施結果Outを取得
        form = target.getMst361Form();

        // 想定通りに正常にClearを実施されること
        assertEquals(null,form.getConEigyoshoCd());
        assertEquals(null,form.getConKokyakuCd());
        assertEquals(null,form.getConRyokinKomoku());
        assertEquals(null,form.getConTekiyoMei());
        assertEquals("01",form.getConSedaiKensakuJoken()[0]);
        assertEquals("02",form.getConSedaiKensakuJoken()[1]);
        assertEquals(null,form.getConTekiyoBi());
        assertEquals(null,form.getConSakujonomiKensaku());
        assertEquals("01",form.getConShinseiJokyo()[0]);
        assertEquals("02",form.getConShinseiJokyo()[1]);
        assertEquals("03",form.getConShinseiJokyo()[2]);
        assertEquals("04",form.getConShinseiJokyo()[3]);
        assertEquals("05",form.getConShinseiJokyo()[4]);
    }
    
    // getHeader_正常_ダウンロード_4-1
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
     @Test
    public void getHeader_正常_ダウンロード_4_1 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst361Form form = new Mst361Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("111");
        form.setConEigyoshoCd(conEigyoshoCd);

        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("000002");
        form.setConKokyakuCd(conKokyakuCd);
        
        AutoCompOptionBean conRyokinKomoku = new AutoCompOptionBean();
        conRyokinKomoku.setValue("02");
        form.setConRyokinKomoku(conRyokinKomoku);
        
        form.setConTekiyoMei("ppp");
                
        form.setConSedaiKensakuJoken(new String[]{"01","02"});
        
        form.setConTekiyoBi(null);
       
        form.setConSakujonomiKensaku(null);
        
        form.setConShinseiJokyo(new String[]{"01"});
        target.setMst361Form(form);
        List<CSVDto> dto = target.getHeader();

        //実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にCVSのHeaderを設定されること
        assertEquals("111",form.getConEigyoshoCd().getValue());
        assertEquals("000002",form.getConKokyakuCd().getValue());
        assertEquals("02",form.getConRyokinKomoku().getValue());
        assertEquals("ppp",form.getConTekiyoMei());
        assertEquals("01",form.getConSedaiKensakuJoken()[0]);
        assertEquals("02",form.getConSedaiKensakuJoken()[1]);
        assertEquals(null,form.getConTekiyoBi());
        assertEquals(null,form.getConSakujonomiKensaku());
        assertEquals("01",form.getConShinseiJokyo()[0]);
        assertEquals("顧客コード",dto.get(0).getTitle());
        assertEquals("listKokyakuCd",dto.get(0).getName());
        assertEquals("顧客名",dto.get(1).getTitle());
        assertEquals("listKokyakuMei",dto.get(1).getName());
        assertEquals("料金項目",dto.get(2).getTitle());
        assertEquals("listRyokinKomoku",dto.get(2).getName());
        assertEquals("料金項目名",dto.get(3).getTitle());
        assertEquals("listRyokinKomokuMeisho",dto.get(3).getName());
        assertEquals("適用開始日",dto.get(4).getTitle());
        assertEquals("listTekiyoKaishibi",dto.get(4).getName());
        assertEquals("単価",dto.get(5).getTitle());
        assertEquals("listTanka",dto.get(5).getName());
        assertEquals("単位",dto.get(6).getTitle());
        assertEquals("listTani",dto.get(6).getName());
        assertEquals("数量",dto.get(7).getTitle());
        assertEquals("listSuryo",dto.get(7).getName());
        assertEquals("売上入力の個数を使用",dto.get(8).getTitle());
        assertEquals("listUriageKosuShiyoFlg",dto.get(8).getName());
        assertEquals("金額",dto.get(9).getTitle());
        assertEquals("listKingaku",dto.get(9).getName());
        assertEquals("適用名",dto.get(10).getTitle());
        assertEquals("listTekiyoMei",dto.get(10).getName());
        assertEquals("適用終了日",dto.get(11).getTitle());
        assertEquals("listTekiyoShuryobi",dto.get(11).getName());
        assertEquals("申請状況",dto.get(12).getTitle());
        assertEquals("listShinseiJokyo",dto.get(12).getName());
    }  
    // beforeDown_正常_ダウンロード_4-2
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=2件
    // -----------------------------------------------------
    @Test
    public void beforeDown_正常_ダウンロード_4_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst361Form form = new Mst361Form();
        target.setMst361Form(form);
        try {
            target.beforeDown("testComment");
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(Mst361BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        //実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にダウンロード理由を記録すること
        assertEquals(null,form.getConKokyakuCd());
    }
    
    // rirekiIchiran_正常_更新履歴コンテキストメニュー_14-1
    //
    // -------------------テスト条件--------------------------
    // 正常に取得された場合
    // -----------------------------------------------------
    @Test
    public void rirekiIchiran_正常_更新履歴コンテキストメニュー_14_1 () throws IllegalAccessException, 
            InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> titleFlgCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> searchKeyCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(rirekiSyosaiBean).searchList(titleFlgCaptor_1.capture(),functionCodeCaptor_2.capture()
                ,searchKeyCaptor_3.capture());
        // テスト実行
        Mst361Form form = new Mst361Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++){
            result.add(createRecMapFor_14_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst361Form(form);
        target.rirekiIchiran();

        //実施結果Outを取得
        form = target.getMst361Form();

        //想定通りに履歴を表示する。
        assertEquals("2",titleFlgCaptor_1.getValue());
        assertEquals("MST361_SEARCH_RIREKI",functionCodeCaptor_2.getValue());
        assertEquals("listKokyakuCd0",searchKeyCaptor_3.getValue().get("listKokyakuCd"));
        assertEquals("listRyokinKomoku0",searchKeyCaptor_3.getValue().get("listRyokinKomoku"));
        assertEquals("listTekiyoKaishibi0",searchKeyCaptor_3.getValue().get("listTekiyoKaishibi"));
    }   
    
    // update_異常_登録申請ボタン_登録申請_15_1
    //
    // -------------------テスト条件--------------------------
    // 新規行 かつ 入力された顧客コード/料金項目コード/適用開始日と同一データが自動請求項目マスタ(輸送売上)に存在する。[MSTE0053]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_登録申請ボタン_登録申請_15_1 () throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 新規行 かつ 入力された顧客コード/料金項目コード/適用開始日と同一データが自動請求項目マスタ(輸送売上)に存在する。[MSTE0053]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0053",
                "listKokyakuCdlistRyokinKomokulistTekiyoKaishibi");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        // テスト実行
        Mst361Form form = new Mst361Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++){
            result.add(createRecMapFor_15_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst361Form(form);
        target.update();

        // 実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Wed Jan 02 16:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("1",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("1",paramsCaptor_1_Param.get("listTani"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("listUriageKosuShiyoFlg0",paramsCaptor_1_Param.get("listUriageKosuShiyoFlg"));
        assertEquals("listKingaku0",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listShinseiStatus0",paramsCaptor_1_Param.get("listShinseiStatus"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("listHJidoSeikyuDataVersion0",paramsCaptor_1_Param.get("listHJidoSeikyuDataVersion"));
        assertEquals("listTekyoFlg0",paramsCaptor_1_Param.get("listTekyoFlg"));
        assertEquals("listSakujonomiKensaku0",paramsCaptor_1_Param.get("listSakujonomiKensaku"));
        assertEquals("koushinCounter0",paramsCaptor_1_Param.get("koushinCounter"));
        assertEquals("koushinUserCd0",paramsCaptor_1_Param.get("koushinUserCd"));
        assertEquals("mst361_update_check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：MSTE0053）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("MSTE0053",summaryCaptor_4.getValue());
    }
    
    // update_正常_登録申請ボタン_登録申請_15_2
    //
    // -------------------テスト条件--------------------------
    // 新規行 かつ 入力された顧客コード/料金項目1コード/料金項目2コード/入力日付/適用開始日と同一データが自動請求項目マスタ(輸送売上)に存在していない
    // -----------------------------------------------------
    @Test
    public void update_正常_登録申請ボタン_登録申請_15_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 新規行 かつ 入力された顧客コード/料金項目1コード/料金項目2コード/入力日付/適用開始日と同一データが自動請求項目マスタ(輸送売上)に存在していない
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        // 検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_2_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        // テスト実行
        Mst361Form form = new Mst361Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++){
            result.add(createRecMapFor_15_1(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst361Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Wed Jan 02 16:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("1",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("1",paramsCaptor_1_Param.get("listTani"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("listUriageKosuShiyoFlg0",paramsCaptor_1_Param.get("listUriageKosuShiyoFlg"));
        assertEquals("listKingaku0",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listShinseiStatus0",paramsCaptor_1_Param.get("listShinseiStatus"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("listHJidoSeikyuDataVersion0",paramsCaptor_1_Param.get("listHJidoSeikyuDataVersion"));
        assertEquals("listTekyoFlg0",paramsCaptor_1_Param.get("listTekyoFlg"));
        assertEquals("listSakujonomiKensaku0",paramsCaptor_1_Param.get("listSakujonomiKensaku"));
        assertEquals("koushinCounter0",paramsCaptor_1_Param.get("koushinCounter"));
        assertEquals("koushinUserCd0",paramsCaptor_1_Param.get("koushinUserCd"));
        assertEquals("mst361_update",functionCodeCaptor_2.getValue());
    }  
    
    // update_異常_登録申請ボタン_登録申請_15_3
    //
    // -------------------テスト条件--------------------------
    // 入力された顧客コードが顧客マスタに存在しない。[COME0051]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_登録申請ボタン_登録申請_15_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力された顧客コードが顧客マスタに存在しない。[COME0051]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0051",
                "listKokyakuCd");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst361Form form = new Mst361Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++){
            result.add(createRecMapFor_15_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst361Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Wed Jan 02 16:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("1",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("1",paramsCaptor_1_Param.get("listTani"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("listUriageKosuShiyoFlg0",paramsCaptor_1_Param.get("listUriageKosuShiyoFlg"));
        assertEquals("listKingaku0",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listShinseiStatus0",paramsCaptor_1_Param.get("listShinseiStatus"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("listHJidoSeikyuDataVersion0",paramsCaptor_1_Param.get("listHJidoSeikyuDataVersion"));
        assertEquals("listTekyoFlg0",paramsCaptor_1_Param.get("listTekyoFlg"));
        assertEquals("listSakujonomiKensaku0",paramsCaptor_1_Param.get("listSakujonomiKensaku"));
        assertEquals("koushinCounter0",paramsCaptor_1_Param.get("koushinCounter"));
        assertEquals("koushinUserCd0",paramsCaptor_1_Param.get("koushinUserCd"));
        assertEquals("mst361_update_check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0051）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0051",summaryCaptor_4.getValue());
    }
    
    // update_正常_登録申請ボタン_登録申請_15_4
    //
    // -------------------テスト条件--------------------------
    // 入力された顧客コードが顧客マスタに存在
    // -----------------------------------------------------
    @Test
    public void update_正常_登録申請ボタン_登録申請_15_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力された顧客コードが顧客マスタに存在
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        // 検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_2_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        //テスト実行
        Mst361Form form = new Mst361Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++){
            result.add(createRecMapFor_15_1(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst361Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
       assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Wed Jan 02 16:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("1",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("1",paramsCaptor_1_Param.get("listTani"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("listUriageKosuShiyoFlg0",paramsCaptor_1_Param.get("listUriageKosuShiyoFlg"));
        assertEquals("listKingaku0",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listShinseiStatus0",paramsCaptor_1_Param.get("listShinseiStatus"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("listHJidoSeikyuDataVersion0",paramsCaptor_1_Param.get("listHJidoSeikyuDataVersion"));
        assertEquals("listTekyoFlg0",paramsCaptor_1_Param.get("listTekyoFlg"));
        assertEquals("listSakujonomiKensaku0",paramsCaptor_1_Param.get("listSakujonomiKensaku"));
        assertEquals("koushinCounter0",paramsCaptor_1_Param.get("koushinCounter"));
        assertEquals("koushinUserCd0",paramsCaptor_1_Param.get("koushinUserCd"));
        assertEquals("mst361_update",functionCodeCaptor_2.getValue());
    } 
    
    // update_異常_登録申請ボタン_登録申請_15_5
    //
    // -------------------テスト条件--------------------------
    // 入力された料金項目コードが付帯料金項目マスタに存在しない。[COME0051]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_登録申請ボタン_登録申請_15_5 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力された料金項目コードが付帯料金項目マスタに存在しない。[COME0051]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0051",
                "listRyokinKomoku");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst361Form form = new Mst361Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++){
            result.add(createRecMapFor_15_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst361Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Wed Jan 02 16:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("1",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("1",paramsCaptor_1_Param.get("listTani"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("listUriageKosuShiyoFlg0",paramsCaptor_1_Param.get("listUriageKosuShiyoFlg"));
        assertEquals("listKingaku0",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listShinseiStatus0",paramsCaptor_1_Param.get("listShinseiStatus"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("listHJidoSeikyuDataVersion0",paramsCaptor_1_Param.get("listHJidoSeikyuDataVersion"));
        assertEquals("listTekyoFlg0",paramsCaptor_1_Param.get("listTekyoFlg"));
        assertEquals("listSakujonomiKensaku0",paramsCaptor_1_Param.get("listSakujonomiKensaku"));
        assertEquals("koushinCounter0",paramsCaptor_1_Param.get("koushinCounter"));
        assertEquals("koushinUserCd0",paramsCaptor_1_Param.get("koushinUserCd"));
        assertEquals("mst361_update_check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0051）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0051",summaryCaptor_4.getValue());
    }
    
    // update_正常_登録申請ボタン_登録申請_15_6
    //
    // -------------------テスト条件--------------------------
    // 入力された料金項目コードが付帯料金項目マスタに存在
    // -----------------------------------------------------
    @Test
    public void update_正常_登録申請ボタン_登録申請_15_6 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力された料金項目コードが付帯料金項目マスタに存在
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        // 検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_2_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        //テスト実行
        Mst361Form form = new Mst361Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++){
            result.add(createRecMapFor_15_1(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst361Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Wed Jan 02 16:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("1",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("1",paramsCaptor_1_Param.get("listTani"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("listUriageKosuShiyoFlg0",paramsCaptor_1_Param.get("listUriageKosuShiyoFlg"));
        assertEquals("listKingaku0",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listShinseiStatus0",paramsCaptor_1_Param.get("listShinseiStatus"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("listHJidoSeikyuDataVersion0",paramsCaptor_1_Param.get("listHJidoSeikyuDataVersion"));
        assertEquals("listTekyoFlg0",paramsCaptor_1_Param.get("listTekyoFlg"));
        assertEquals("listSakujonomiKensaku0",paramsCaptor_1_Param.get("listSakujonomiKensaku"));
        assertEquals("koushinCounter0",paramsCaptor_1_Param.get("koushinCounter"));
        assertEquals("koushinUserCd0",paramsCaptor_1_Param.get("koushinUserCd"));
        assertEquals("mst361_update",functionCodeCaptor_2.getValue());
    } 
    
    // update_異常_登録申請ボタン_登録申請_15_7
    //
    // -------------------テスト条件--------------------------
    // 単位・単価が付帯料金表と不一致。[COME0052]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_登録申請ボタン_登録申請_15_7 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 単位・単価が付帯料金表と不一致。[COME0052]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0052",
                "listTanilistTanka");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mst361Form form = new Mst361Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++){
            result.add(createRecMapFor_15_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst361Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Wed Jan 02 16:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("1",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("1",paramsCaptor_1_Param.get("listTani"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("listUriageKosuShiyoFlg0",paramsCaptor_1_Param.get("listUriageKosuShiyoFlg"));
        assertEquals("listKingaku0",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listShinseiStatus0",paramsCaptor_1_Param.get("listShinseiStatus"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("listHJidoSeikyuDataVersion0",paramsCaptor_1_Param.get("listHJidoSeikyuDataVersion"));
        assertEquals("listTekyoFlg0",paramsCaptor_1_Param.get("listTekyoFlg"));
        assertEquals("listSakujonomiKensaku0",paramsCaptor_1_Param.get("listSakujonomiKensaku"));
        assertEquals("koushinCounter0",paramsCaptor_1_Param.get("koushinCounter"));
        assertEquals("koushinUserCd0",paramsCaptor_1_Param.get("koushinUserCd"));
        assertEquals("mst361_update_check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0052）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0052",summaryCaptor_4.getValue());
    }
    
    // update_正常_登録申請ボタン_登録申請_15_8
    //
    // -------------------テスト条件--------------------------
    // 単位・単価が付帯料金表と一致。
    // -----------------------------------------------------
    @Test
    public void update_正常_登録申請ボタン_登録申請_15_8 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 単位・単価が付帯料金表と一致。
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        // 検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_2_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        //テスト実行
        Mst361Form form = new Mst361Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++){
            result.add(createRecMapFor_15_1(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst361Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Wed Jan 02 16:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("1",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("1",paramsCaptor_1_Param.get("listTani"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("listUriageKosuShiyoFlg0",paramsCaptor_1_Param.get("listUriageKosuShiyoFlg"));
        assertEquals("listKingaku0",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listShinseiStatus0",paramsCaptor_1_Param.get("listShinseiStatus"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("listHJidoSeikyuDataVersion0",paramsCaptor_1_Param.get("listHJidoSeikyuDataVersion"));
        assertEquals("listTekyoFlg0",paramsCaptor_1_Param.get("listTekyoFlg"));
        assertEquals("listSakujonomiKensaku0",paramsCaptor_1_Param.get("listSakujonomiKensaku"));
        assertEquals("koushinCounter0",paramsCaptor_1_Param.get("koushinCounter"));
        assertEquals("koushinUserCd0",paramsCaptor_1_Param.get("koushinUserCd"));
        assertEquals("mst361_update",functionCodeCaptor_2.getValue());
    } 
    
    // update_異常_登録申請ボタン_更新申請_15_9
    //
    // -------------------テスト条件--------------------------
    // 新規行 かつ 入力された顧客コード/料金項目コード/適用開始日と同一データが自動請求項目マスタ(輸送売上)に存在する。[MSTE0053]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_登録申請ボタン_更新申請_15_9 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 新規行 かつ 入力された顧客コード/料金項目コード/適用開始日と同一データが自動請求項目マスタ(輸送売上)に存在する。[MSTE0053]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0053",
                "listKokyakuCdlistRyokinKomokulistTekiyoKaishibi");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        // テスト実行
        Mst361Form form = new Mst361Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++){
            result.add(createRecMapFor_15_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst361Form(form);
        target.update();

        // 実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Wed Jan 02 16:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("1",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("1",paramsCaptor_1_Param.get("listTani"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("listUriageKosuShiyoFlg0",paramsCaptor_1_Param.get("listUriageKosuShiyoFlg"));
        assertEquals("listKingaku0",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listShinseiStatus0",paramsCaptor_1_Param.get("listShinseiStatus"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("listHJidoSeikyuDataVersion0",paramsCaptor_1_Param.get("listHJidoSeikyuDataVersion"));
        assertEquals("listTekyoFlg0",paramsCaptor_1_Param.get("listTekyoFlg"));
        assertEquals("listSakujonomiKensaku0",paramsCaptor_1_Param.get("listSakujonomiKensaku"));
        assertEquals("koushinCounter0",paramsCaptor_1_Param.get("koushinCounter"));
        assertEquals("koushinUserCd0",paramsCaptor_1_Param.get("koushinUserCd"));
        assertEquals("mst361_update_check",functionCodeCaptor_2.getValue());
        // 想定通りにエラーが発生。（メッセージID：MSTE0053）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("MSTE0053",summaryCaptor_4.getValue());
    }
    
    // update_正常_登録申請ボタン_更新申請_15_10
    //
    // -------------------テスト条件--------------------------
    // 新規行 かつ 入力された顧客コード/料金項目コード/適用開始日と同一データが自動請求項目マスタ(輸送売上)に存在していない
    // -----------------------------------------------------
    @Test
    public void update_正常_登録申請ボタン_更新申請_15_10 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 新規行 かつ 入力された顧客コード/料金項目コード/適用開始日と同一データが自動請求項目マスタ(輸送売上)に存在していない
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        // 検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_2_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        // テスト実行
        Mst361Form form = new Mst361Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++){
            result.add(createRecMapFor_15_1(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst361Form(form);
        target.update();
        // 実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Wed Jan 02 16:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("1",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("1",paramsCaptor_1_Param.get("listTani"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("listUriageKosuShiyoFlg0",paramsCaptor_1_Param.get("listUriageKosuShiyoFlg"));
        assertEquals("listKingaku0",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listShinseiStatus0",paramsCaptor_1_Param.get("listShinseiStatus"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("listHJidoSeikyuDataVersion0",paramsCaptor_1_Param.get("listHJidoSeikyuDataVersion"));
        assertEquals("listTekyoFlg0",paramsCaptor_1_Param.get("listTekyoFlg"));
        assertEquals("listSakujonomiKensaku0",paramsCaptor_1_Param.get("listSakujonomiKensaku"));
        assertEquals("koushinCounter0",paramsCaptor_1_Param.get("koushinCounter"));
        assertEquals("koushinUserCd0",paramsCaptor_1_Param.get("koushinUserCd"));
        assertEquals("mst361_update",functionCodeCaptor_2.getValue());
    }  
    
    // update_異常_登録申請ボタン_更新申請_15_11
    //
    // -------------------テスト条件--------------------------
    // 入力された顧客コードが顧客マスタに存在しない。[COME0051]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_登録申請ボタン_更新申請_15_11 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力された顧客コードが顧客マスタに存在しない。[COME0051]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0051",
                "listKokyakuCd");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        // テスト実行
        Mst361Form form = new Mst361Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++){
            result.add(createRecMapFor_15_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst361Form(form);
        target.update();

        // 実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Wed Jan 02 16:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("1",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("1",paramsCaptor_1_Param.get("listTani"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("listUriageKosuShiyoFlg0",paramsCaptor_1_Param.get("listUriageKosuShiyoFlg"));
        assertEquals("listKingaku0",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listShinseiStatus0",paramsCaptor_1_Param.get("listShinseiStatus"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("listHJidoSeikyuDataVersion0",paramsCaptor_1_Param.get("listHJidoSeikyuDataVersion"));
        assertEquals("listTekyoFlg0",paramsCaptor_1_Param.get("listTekyoFlg"));
        assertEquals("listSakujonomiKensaku0",paramsCaptor_1_Param.get("listSakujonomiKensaku"));
        assertEquals("koushinCounter0",paramsCaptor_1_Param.get("koushinCounter"));
        assertEquals("koushinUserCd0",paramsCaptor_1_Param.get("koushinUserCd"));
        assertEquals("mst361_update_check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0051）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0051",summaryCaptor_4.getValue());
    }
    
    // update_正常_登録申請ボタン_更新申請_15_12
    //
    // -------------------テスト条件--------------------------
    // 入力された顧客コードが顧客マスタに存在
    // -----------------------------------------------------
    @Test
    public void update_正常_登録申請ボタン_更新申請_15_12 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力された顧客コードが顧客マスタに存在
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        // 検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_2_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        // テスト実行
        Mst361Form form = new Mst361Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++){
            result.add(createRecMapFor_15_1(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst361Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Wed Jan 02 16:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("1",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("1",paramsCaptor_1_Param.get("listTani"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("listUriageKosuShiyoFlg0",paramsCaptor_1_Param.get("listUriageKosuShiyoFlg"));
        assertEquals("listKingaku0",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listShinseiStatus0",paramsCaptor_1_Param.get("listShinseiStatus"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("listHJidoSeikyuDataVersion0",paramsCaptor_1_Param.get("listHJidoSeikyuDataVersion"));
        assertEquals("listTekyoFlg0",paramsCaptor_1_Param.get("listTekyoFlg"));
        assertEquals("listSakujonomiKensaku0",paramsCaptor_1_Param.get("listSakujonomiKensaku"));
        assertEquals("koushinCounter0",paramsCaptor_1_Param.get("koushinCounter"));
        assertEquals("koushinUserCd0",paramsCaptor_1_Param.get("koushinUserCd"));
        assertEquals("mst361_update",functionCodeCaptor_2.getValue());
    } 
    
    // update_異常_登録申請ボタン_更新申請_15_13
    //
    // -------------------テスト条件--------------------------
    // 入力された料金項目コードが付帯料金項目マスタに存在しない。[COME0051]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_登録申請ボタン_更新申請_15_13 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力された料金項目コードが付帯料金項目マスタに存在しない。[COME0051]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0051",
                "listRyokinKomoku1listRyokinKomoku2");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        // テスト実行
        Mst361Form form = new Mst361Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++){
            result.add(createRecMapFor_15_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst361Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Wed Jan 02 16:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("1",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("1",paramsCaptor_1_Param.get("listTani"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("listUriageKosuShiyoFlg0",paramsCaptor_1_Param.get("listUriageKosuShiyoFlg"));
        assertEquals("listKingaku0",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listShinseiStatus0",paramsCaptor_1_Param.get("listShinseiStatus"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("listHJidoSeikyuDataVersion0",paramsCaptor_1_Param.get("listHJidoSeikyuDataVersion"));
        assertEquals("listTekyoFlg0",paramsCaptor_1_Param.get("listTekyoFlg"));
        assertEquals("listSakujonomiKensaku0",paramsCaptor_1_Param.get("listSakujonomiKensaku"));
        assertEquals("koushinCounter0",paramsCaptor_1_Param.get("koushinCounter"));
        assertEquals("koushinUserCd0",paramsCaptor_1_Param.get("koushinUserCd"));
        assertEquals("mst361_update_check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0051）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0051",summaryCaptor_4.getValue());
    }
    
    // update_正常_登録申請ボタン_更新申請_15_14
    //
    // -------------------テスト条件--------------------------
    // 入力された料金項目コードが付帯料金項目マスタに存在
    // -----------------------------------------------------
    @Test
    public void update_正常_登録申請ボタン_更新申請_15_14 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力された料金項目コードが付帯料金項目マスタに存在
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        // 検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_2_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        // テスト実行
        Mst361Form form = new Mst361Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++){
            result.add(createRecMapFor_15_1(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst361Form(form);
        target.update();
        // 実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Wed Jan 02 16:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("1",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("1",paramsCaptor_1_Param.get("listTani"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("listUriageKosuShiyoFlg0",paramsCaptor_1_Param.get("listUriageKosuShiyoFlg"));
        assertEquals("listKingaku0",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listShinseiStatus0",paramsCaptor_1_Param.get("listShinseiStatus"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("listHJidoSeikyuDataVersion0",paramsCaptor_1_Param.get("listHJidoSeikyuDataVersion"));
        assertEquals("listTekyoFlg0",paramsCaptor_1_Param.get("listTekyoFlg"));
        assertEquals("listSakujonomiKensaku0",paramsCaptor_1_Param.get("listSakujonomiKensaku"));
        assertEquals("koushinCounter0",paramsCaptor_1_Param.get("koushinCounter"));
        assertEquals("koushinUserCd0",paramsCaptor_1_Param.get("koushinUserCd"));
        assertEquals("mst361_update",functionCodeCaptor_2.getValue());
    } 
    
    // update_異常_登録申請ボタン_更新申請_15_15
    //
    // -------------------テスト条件--------------------------
    // 単位・単価が付帯料金表と不一致。[COME0052]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_登録申請ボタン_更新申請_15_15 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 単位・単価が付帯料金表と不一致。[COME0052]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0052",
                "listTanilistTanka");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        // テスト実行
        Mst361Form form = new Mst361Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++){
            result.add(createRecMapFor_15_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst361Form(form);
        target.update();

        // 実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Wed Jan 02 16:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("1",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("1",paramsCaptor_1_Param.get("listTani"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("listUriageKosuShiyoFlg0",paramsCaptor_1_Param.get("listUriageKosuShiyoFlg"));
        assertEquals("listKingaku0",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listShinseiStatus0",paramsCaptor_1_Param.get("listShinseiStatus"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("listHJidoSeikyuDataVersion0",paramsCaptor_1_Param.get("listHJidoSeikyuDataVersion"));
        assertEquals("listTekyoFlg0",paramsCaptor_1_Param.get("listTekyoFlg"));
        assertEquals("listSakujonomiKensaku0",paramsCaptor_1_Param.get("listSakujonomiKensaku"));
        assertEquals("koushinCounter0",paramsCaptor_1_Param.get("koushinCounter"));
        assertEquals("koushinUserCd0",paramsCaptor_1_Param.get("koushinUserCd"));
        assertEquals("mst361_update_check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0052）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("COME0052",summaryCaptor_4.getValue());
    }
    
    // update_正常_登録申請ボタン_更新申請_15_16
    //
    // -------------------テスト条件--------------------------
    // 単位・単価が付帯料金表と一致。
    // -----------------------------------------------------
    @Test
    public void update_正常_登録申請ボタン_更新申請_15_16 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 単位・単価が付帯料金表と一致。
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        // 検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_2_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty)
                .message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());

        // テスト実行
        Mst361Form form = new Mst361Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++){
            result.add(createRecMapFor_15_1(i));
        }        
        form.setSelectedSearchResult(result);
        target.setMst361Form(form);
        target.update();
        // 実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Wed Jan 02 16:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("1",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("1",paramsCaptor_1_Param.get("listTani"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("listUriageKosuShiyoFlg0",paramsCaptor_1_Param.get("listUriageKosuShiyoFlg"));
        assertEquals("listKingaku0",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listShinseiStatus0",paramsCaptor_1_Param.get("listShinseiStatus"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("listHJidoSeikyuDataVersion0",paramsCaptor_1_Param.get("listHJidoSeikyuDataVersion"));
        assertEquals("listTekyoFlg0",paramsCaptor_1_Param.get("listTekyoFlg"));
        assertEquals("listSakujonomiKensaku0",paramsCaptor_1_Param.get("listSakujonomiKensaku"));
        assertEquals("koushinCounter0",paramsCaptor_1_Param.get("koushinCounter"));
        assertEquals("koushinUserCd0",paramsCaptor_1_Param.get("koushinUserCd"));
        assertEquals("mst361_update",functionCodeCaptor_2.getValue());
    } 
    
    // delRows_正常_削除申請ボタン_16_1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 1
    // 適用終了日が適用開始日より過去日付の場合ではありません。
    // -----------------------------------------------------
    @Test
    public void delRows_正常_削除申請ボタン_16_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture());
        // テスト実行
        Mst361Form form = new Mst361Form();
        // 行選択チェック選択 = 1
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_15_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst361Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Wed Jan 02 16:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("1",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("1",paramsCaptor_1_Param.get("listTani"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("listUriageKosuShiyoFlg0",paramsCaptor_1_Param.get("listUriageKosuShiyoFlg"));
        assertEquals("listKingaku0",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listShinseiStatus0",paramsCaptor_1_Param.get("listShinseiStatus"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("listHJidoSeikyuDataVersion0",paramsCaptor_1_Param.get("listHJidoSeikyuDataVersion"));
        assertEquals("listTekyoFlg0",paramsCaptor_1_Param.get("listTekyoFlg"));
        assertEquals("listSakujonomiKensaku0",paramsCaptor_1_Param.get("listSakujonomiKensaku"));
        assertEquals("koushinCounter0",paramsCaptor_1_Param.get("koushinCounter"));
        assertEquals("koushinUserCd0",paramsCaptor_1_Param.get("koushinUserCd"));
        assertEquals("mst361_delete",functionCodeCaptor_2.getValue());
    }  
    
    // delRows_正常_削除申請ボタン_16_2
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 2
    // 適用終了日が適用開始日より過去日付の場合ではありません。
    // -----------------------------------------------------
    @Test
    public void delRows_正常_削除申請ボタン_16_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture());
        // テスト実行
        Mst361Form form = new Mst361Form();
        // 行選択チェック選択 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            result.add(createRecMapFor_15_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst361Form(form);
        target.delRows(result);

        // 実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Wed Jan 02 16:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("1",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("1",paramsCaptor_1_Param.get("listTani"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("listUriageKosuShiyoFlg0",paramsCaptor_1_Param.get("listUriageKosuShiyoFlg"));
        assertEquals("listKingaku0",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listShinseiStatus0",paramsCaptor_1_Param.get("listShinseiStatus"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("listHJidoSeikyuDataVersion0",paramsCaptor_1_Param.get("listHJidoSeikyuDataVersion"));
        assertEquals("listTekyoFlg0",paramsCaptor_1_Param.get("listTekyoFlg"));
        assertEquals("listSakujonomiKensaku0",paramsCaptor_1_Param.get("listSakujonomiKensaku"));
        assertEquals("koushinCounter0",paramsCaptor_1_Param.get("koushinCounter"));
        assertEquals("koushinUserCd0",paramsCaptor_1_Param.get("koushinUserCd"));
        assertEquals("mst361_delete",functionCodeCaptor_2.getValue());
    }   
    
    // delRows_正常_削除申請ボタン_16_3
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 2
    // 適用終了日が適用開始日より過去日付の場合ではありません。
    // -----------------------------------------------------
    @Test
    public void delRows_正常_削除申請ボタン_16_3 () throws IllegalAccessException, 
            InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        serviceInterfaceBean2.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean,serviceInterfaceBean2);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture());
        // テスト実行
        Mst361Form form = new Mst361Form();
        // 行選択チェック選択 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            result.add(createRecMapFor_15_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst361Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Wed Jan 02 16:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("1",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("1",paramsCaptor_1_Param.get("listTani"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("listUriageKosuShiyoFlg0",paramsCaptor_1_Param.get("listUriageKosuShiyoFlg"));
        assertEquals("listKingaku0",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listShinseiStatus0",paramsCaptor_1_Param.get("listShinseiStatus"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("listHJidoSeikyuDataVersion0",paramsCaptor_1_Param.get("listHJidoSeikyuDataVersion"));
        assertEquals("listTekyoFlg0",paramsCaptor_1_Param.get("listTekyoFlg"));
        assertEquals("listSakujonomiKensaku0",paramsCaptor_1_Param.get("listSakujonomiKensaku"));
        assertEquals("koushinCounter0",paramsCaptor_1_Param.get("koushinCounter"));
        assertEquals("koushinUserCd0",paramsCaptor_1_Param.get("koushinUserCd"));
        assertEquals("mst361_delete",functionCodeCaptor_2.getValue());
    }
    
    // delRows_異常_削除申請ボタン_16_4
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // -----------------------------------------------------
    @Test
    public void delRows_異常_削除申請ボタン_16_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> objCaptor_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messageProperty).message(levelCaptor_1.capture(), summaryCaptor_2.capture(),objCaptor_3
                .capture());
        // テスト実行
        Mst361Form form = new Mst361Form();
        // 行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        form.setSelectedSearchResult(result);
        target.setMst361Form(form);
        target.delRowsFunc();

        // 実施結果Outを取得
        form = target.getMst361Form();

        // 想定通りにエラーが発生。（メッセージID：COME0011）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0011",summaryCaptor_2.getValue());
        assertEquals("選択",objCaptor_3.getValue());
    }  
    
    // delRows_異常_削除申請ボタン_16_5
    //
    // -------------------テスト条件--------------------------
    // 適用終了日が適用開始日より過去日付の場合。[COME0053]が返却
    // -----------------------------------------------------
    @Test
    public void delRows_異常_削除申請ボタン_16_5 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 適用終了日が適用開始日より過去日付の場合。[COME0053]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0053",
                "listTekiyoShuryobilistTekiyoKaishibi");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messageProperty.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2
                .capture(),summaryCaptor_3.capture(),summaryCaptor_4.capture())).thenReturn(messageModuleBean);

        // テスト実行
        Mst361Form form = new Mst361Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++){
            result.add(createRecMapFor_15_1(i));
        }
        form.setSelectedSearchResult(result);
        form.setSearchResult(result);
        target.setMst361Form(form);
        target.delRows(result);

        // 実施結果Outを取得
        form = target.getMst361Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listKokyakuCd0",paramsCaptor_1_Param.get("listKokyakuCd"));
        assertEquals("listKokyakuMei0",paramsCaptor_1_Param.get("listKokyakuMei"));
        assertEquals("listRyokinKomoku0",paramsCaptor_1_Param.get("listRyokinKomoku"));
        assertEquals("listRyokinKomokuMeisho0",paramsCaptor_1_Param.get("listRyokinKomokuMeisho"));
        assertEquals("Wed Jan 02 16:00:00 JST 2019",paramsCaptor_1_Param.get("listTekiyoKaishibi").toString());
        assertEquals("1",paramsCaptor_1_Param.get("listTanka"));
        assertEquals("1",paramsCaptor_1_Param.get("listTani"));
        assertEquals("1",paramsCaptor_1_Param.get("listSuryo"));
        assertEquals("listUriageKosuShiyoFlg0",paramsCaptor_1_Param.get("listUriageKosuShiyoFlg"));
        assertEquals("listKingaku0",paramsCaptor_1_Param.get("listKingaku"));
        assertEquals("listTekiyoMei0",paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listTekiyoShuryobi0",paramsCaptor_1_Param.get("listTekiyoShuryobi"));
        assertEquals("listShinseiStatus0",paramsCaptor_1_Param.get("listShinseiStatus"));
        assertEquals("listShinseiJokyo0",paramsCaptor_1_Param.get("listShinseiJokyo"));
        assertEquals("listHJidoSeikyuDataVersion0",paramsCaptor_1_Param.get("listHJidoSeikyuDataVersion"));
        assertEquals("listTekyoFlg0",paramsCaptor_1_Param.get("listTekyoFlg"));
        assertEquals("listSakujonomiKensaku0",paramsCaptor_1_Param.get("listSakujonomiKensaku"));
        assertEquals("koushinCounter0",paramsCaptor_1_Param.get("koushinCounter"));
        assertEquals("koushinUserCd0",paramsCaptor_1_Param.get("koushinUserCd"));
        assertEquals("mst361_delete_check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0053）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0053",summaryCaptor_2.getValue());
    }  
    
    private Map<String, String> createRecMapFor_2_1(int i) {
        Map recMap = new HashMap();
        recMap.put("listKokyakuCd", "listKokyakuCd" + i);
        recMap.put("listKokyakuMei", "listKokyakuMei" + i);
        recMap.put("listRyokinKomoku", "listRyokinKomoku" + i);
        recMap.put("listRyokinKomokuMeisho", "listRyokinKomokuMeisho" + i);
        recMap.put("listTekiyoKaishibi", "listTekiyoKaishibi" + i);
        recMap.put("listTanka", "listTanka" + i);
        recMap.put("listTani", "listTani" + i);
        recMap.put("listSuryo", "listSuryo" + i);
        recMap.put("listUriageKosuShiyoFlg", "listUriageKosuShiyoFlg" + i);
        recMap.put("listKingaku", "listKingaku" + i);
        recMap.put("listTekiyoMei", "listTekiyoMei" + i);
        recMap.put("listTekiyoShuryobi", "listTekiyoShuryobi" + i);
        recMap.put("listShinseiStatus", "listShinseiStatus" + i);
        recMap.put("listShinseiJokyo", "listShinseiJokyo" + i);
        recMap.put("listHJidoSeikyuDataVersion", "listHJidoSeikyuDataVersion" + i);
        recMap.put("listTekyoFlg", "listTekyoFlg" + i);
        recMap.put("listSakujonomiKensaku", "listSakujonomiKensaku" + i);
        recMap.put("koushinCounter", "koushinCounter" + i);
        recMap.put("koushinUserCd", "koushinUserCd" + i);
        return recMap;
    }
    
    private Map<String, Object> createRecMapFor_14_1(int i) {
        Map recMap = new HashMap();
        recMap.put("listKokyakuCd", "listKokyakuCd" + i);
        recMap.put("listKokyakuMei", "listKokyakuMei" + i);
        recMap.put("listRyokinKomoku", "listRyokinKomoku" + i);
        recMap.put("listRyokinKomokuMeisho", "listRyokinKomokuMeisho" + i);
        recMap.put("listTekiyoKaishibi", "listTekiyoKaishibi" + i);
        recMap.put("listTanka", "listTanka" + i);
        recMap.put("listTani", "listTani" + i);
        recMap.put("listSuryo", "listSuryo" + i);
        recMap.put("listUriageKosuShiyoFlg", "listUriageKosuShiyoFlg" + i);
        recMap.put("listKingaku", "listKingaku" + i);
        recMap.put("listTekiyoMei", "listTekiyoMei" + i);
        recMap.put("listTekiyoShuryobi", "listTekiyoShuryobi" + i);
        recMap.put("listShinseiStatus", "listShinseiStatus" + i);
        recMap.put("listShinseiJokyo", "listShinseiJokyo" + i);
        recMap.put("listHJidoSeikyuDataVersion", "listHJidoSeikyuDataVersion" + i);
        recMap.put("listTekyoFlg", "listTekyoFlg" + i);
        recMap.put("listSakujonomiKensaku", "listSakujonomiKensaku" + i);
        recMap.put("koushinCounter", "koushinCounter" + i);
        recMap.put("koushinUserCd", "koushinUserCd" + i);
        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }
    
    private Map<String, Object> createRecMapFor_15_1(int i) {
        Map recMap = new HashMap();
        recMap.put("listKokyakuCd", "listKokyakuCd" + i);
        recMap.put("listKokyakuMei", "listKokyakuMei" + i);
        recMap.put("listRyokinKomoku", "listRyokinKomoku" + i);
        recMap.put("listRyokinKomokuMeisho", "listRyokinKomokuMeisho" + i);
        recMap.put("listTekiyoKaishibi", "Wed Jan 02 16:00:00 JST 2019");
        recMap.put("listTanka", "1");
        recMap.put("listTani", "1");
        recMap.put("listSuryo", "1");
        recMap.put("listUriageKosuShiyoFlg", "listUriageKosuShiyoFlg" + i);
        recMap.put("listKingaku", "listKingaku" + i);
        recMap.put("listTekiyoMei", "listTekiyoMei" + i);
        recMap.put("listTekiyoShuryobi", "listTekiyoShuryobi" + i);
        recMap.put("listShinseiStatus", "listShinseiStatus" + i);
        recMap.put("listShinseiJokyo", "listShinseiJokyo" + i);
        recMap.put("listHJidoSeikyuDataVersion", "listHJidoSeikyuDataVersion" + i);
        recMap.put("listTekyoFlg", "listTekyoFlg" + i);
        recMap.put("listSakujonomiKensaku", "listSakujonomiKensaku" + i);
        recMap.put("koushinCounter", "koushinCounter" + i);
        recMap.put("koushinUserCd", "koushinUserCd" + i);
        recMap.put("listShuryoFlg", Boolean.FALSE);
        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }
    
    private void assertForRecList_2_1(Mst361Form form) {
        int i = 0;
        assertEquals(1, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listKokyakuCd" + i, rec.get("listKokyakuCd"));
            assertEquals("listKokyakuMei" + i, rec.get("listKokyakuMei"));
            assertEquals("listRyokinKomoku" + i, rec.get("listRyokinKomoku"));
            assertEquals("listRyokinKomokuMeisho" + i, rec.get("listRyokinKomokuMeisho"));
            assertEquals("listTekiyoKaishibi" + i, rec.get("listTekiyoKaishibi"));
            assertEquals("listTanka" + i, rec.get("listTanka"));
            assertEquals("listTani" + i, rec.get("listTani"));
            assertEquals("listSuryo" + i, rec.get("listSuryo"));
            assertEquals("listUriageKosuShiyoFlg" + i, rec.get("listUriageKosuShiyoFlg"));
            assertEquals("listKingaku" + i, rec.get("listKingaku"));
            assertEquals("listTekiyoMei" + i, rec.get("listTekiyoMei"));
            assertEquals("listTekiyoShuryobi" + i, rec.get("listTekiyoShuryobi"));
            assertEquals("listShinseiStatus" + i, rec.get("listShinseiStatus"));
            assertEquals("listShinseiJokyo" + i, rec.get("listShinseiJokyo"));
            assertEquals("listHJidoSeikyuDataVersion" + i, rec.get("listHJidoSeikyuDataVersion"));
            assertEquals("listTekyoFlg" + i, rec.get("listTekyoFlg"));
            assertEquals("listSakujonomiKensaku" + i, rec.get("listSakujonomiKensaku"));
            assertEquals("koushinCounter" + i, rec.get("koushinCounter"));
            assertEquals("koushinUserCd" + i, rec.get("koushinUserCd"));
            i++;
        }
    } 
    
    private void assertForRecList_2_2(Mst361Form form) {
        int i = 0;
        assertEquals(2, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listKokyakuCd" + i, rec.get("listKokyakuCd"));
            assertEquals("listKokyakuMei" + i, rec.get("listKokyakuMei"));
            assertEquals("listRyokinKomoku" + i, rec.get("listRyokinKomoku"));
            assertEquals("listRyokinKomokuMeisho" + i, rec.get("listRyokinKomokuMeisho"));
            assertEquals("listTekiyoKaishibi" + i, rec.get("listTekiyoKaishibi"));
            assertEquals("listTanka" + i, rec.get("listTanka"));
            assertEquals("listTani" + i, rec.get("listTani"));
            assertEquals("listSuryo" + i, rec.get("listSuryo"));
            assertEquals("listUriageKosuShiyoFlg" + i, rec.get("listUriageKosuShiyoFlg"));
            assertEquals("listKingaku" + i, rec.get("listKingaku"));
            assertEquals("listTekiyoMei" + i, rec.get("listTekiyoMei"));
            assertEquals("listTekiyoShuryobi" + i, rec.get("listTekiyoShuryobi"));
            assertEquals("listShinseiStatus" + i, rec.get("listShinseiStatus"));
            assertEquals("listShinseiJokyo" + i, rec.get("listShinseiJokyo"));
            assertEquals("listHJidoSeikyuDataVersion" + i, rec.get("listHJidoSeikyuDataVersion"));
            assertEquals("listTekyoFlg" + i, rec.get("listTekyoFlg"));
            assertEquals("listSakujonomiKensaku" + i, rec.get("listSakujonomiKensaku"));
            assertEquals("koushinCounter" + i, rec.get("koushinCounter"));
            assertEquals("koushinUserCd" + i, rec.get("koushinUserCd"));
            i++;
        }
    }   
    
    private void assertForRecList_2_3(Mst361Form form) {
        int i = 0;
        assertEquals(0, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listKokyakuCd" + i, rec.get("listKokyakuCd"));
            assertEquals("listKokyakuMei" + i, rec.get("listKokyakuMei"));
            assertEquals("listRyokinKomoku" + i, rec.get("listRyokinKomoku"));
            assertEquals("listRyokinKomokuMeisho" + i, rec.get("listRyokinKomokuMeisho"));
            assertEquals("listTekiyoKaishibi" + i, rec.get("listTekiyoKaishibi"));
            assertEquals("listTanka" + i, rec.get("listTanka"));
            assertEquals("listTani" + i, rec.get("listTani"));
            assertEquals("listSuryo" + i, rec.get("listSuryo"));
            assertEquals("listUriageKosuShiyoFlg" + i, rec.get("listUriageKosuShiyoFlg"));
            assertEquals("listKingaku" + i, rec.get("listKingaku"));
            assertEquals("listTekiyoMei" + i, rec.get("listTekiyoMei"));
            assertEquals("listTekiyoShuryobi" + i, rec.get("listTekiyoShuryobi"));
            assertEquals("listShinseiStatus" + i, rec.get("listShinseiStatus"));
            assertEquals("listShinseiJokyo" + i, rec.get("listShinseiJokyo"));
            assertEquals("listHJidoSeikyuDataVersion" + i, rec.get("listHJidoSeikyuDataVersion"));
            assertEquals("listTekyoFlg" + i, rec.get("listTekyoFlg"));
            assertEquals("listSakujonomiKensaku" + i, rec.get("listSakujonomiKensaku"));
            assertEquals("koushinCounter" + i, rec.get("koushinCounter"));
            assertEquals("koushinUserCd" + i, rec.get("koushinUserCd"));
            i++;
        }
    }
}
