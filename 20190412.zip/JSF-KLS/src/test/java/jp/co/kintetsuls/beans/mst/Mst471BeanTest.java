package jp.co.kintetsuls.beans.mst;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import jp.co.kintetsuls.beans.common.AddrAutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.KbnBean;
import jp.co.kintetsuls.beans.common.LabelValueBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst471Form;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doThrow;

/**
 * K-INGコード変換マスタ画面
 *
 * @author 雷新然 (MBP)
 * @version 2019/2/18 新規作成
 */
public class Mst471BeanTest {

    // テストTarget
    @InjectMocks
    private Mst471Bean target;

    // Mockitoオブジェクト
    @Mock
    private FileBean fileBean;
    @Mock
    private AutoCompleteViewBean autoCompleteViewBean;
    @Mock
    private AddrAutoCompleteViewBean addrAutoCompleteViewBean;
    @Mock
    private KbnBean kbnBean;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private SearchHelpBean searchHelpBean;
    @Mock
    private AuthorityConfBean authConfBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private MessagePropertyBean messagePropertyBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosaiBean;
    @Mock
    private LabelValueBean labelValueBean;
    @Mock
    private ListCheckBean listCheckBean;

    public Mst471BeanTest() {
    }

    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() {
    }

    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[not null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst471Form mst471Form = new Mst471Form();
        target.setAuthConfBean(authConfBean);
        target.setAutoCompleteViewBean(autoCompleteViewBean);
        target.setFileBean(fileBean);
        target.setMessagePropertyBean(messagePropertyBean);
        target.setPageCommonBean(pageCommonBean);
        target.setSearchHelpBean(searchHelpBean);
        target.setLabelValueBean(labelValueBean);
        target.setRirekiSyosaiBean(rirekiSyosaiBean);
        target.setBreadBean(breadBean);
        target.setAddrAutoCompleteViewBean(addrAutoCompleteViewBean);
        target.setKbnBean(kbnBean);
        target.setRirekiSearchKey(new HashMap<>());
        target.setMsgList(new ArrayList<>());

        //前画面情報[not null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst471Form);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());

        //テスト実行
        Mst471Form form = new Mst471Form();
        target.setMst471Form(form);
        
        AuthorityConfBean authorityConfBean1 = target.getAuthConfBean();
        AutoCompleteViewBean autoCompleteViewBean1 = target.getAutoCompleteViewBean();
        FileBean fileBean1 = target.getFileBean();
        MessagePropertyBean messagePropertyBean1 = target.getMessagePropertyBean();
        PageCommonBean pageCommonBean1 = target.getPageCommonBean();
        SearchHelpBean searchHelpBean1 = target.getSearchHelpBean();
        LabelValueBean labelValueBean1 = target.getLabelValueBean();
        RirekiSyosaiBean rirekiSyosaiBean1 = target.getRirekiSyosaiBean();
        BreadCrumbBean breadBean1 = target.getBreadBean();
        AddrAutoCompleteViewBean addrAutoCompleteViewBean1 = target.getAddrAutoCompleteViewBean();
        KbnBean kbnBean1 = target.getKbnBean();
        
        target.init("", "MST471_SCREEN", true);

        //実施結果Outを取得
        form = target.getMst471Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst471Form", keyCaptor_1.getValue());
        //想定通りに再検索を実施する。
        assertEquals("search_mst471", keyCaptor_2.getValue());
        assertEquals(authConfBean, authorityConfBean1);
        assertEquals(autoCompleteViewBean, autoCompleteViewBean1);
        assertEquals(fileBean, fileBean1);
        assertEquals(messagePropertyBean, messagePropertyBean1);
        assertEquals(pageCommonBean, pageCommonBean1);
        assertEquals(searchHelpBean, searchHelpBean1);
        assertEquals(labelValueBean, labelValueBean1);
        assertEquals(breadBean, breadBean1);
        assertEquals(rirekiSyosaiBean, rirekiSyosaiBean1);
        assertEquals(addrAutoCompleteViewBean, addrAutoCompleteViewBean1);
        assertEquals(kbnBean, kbnBean1);
    }

    // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // //前画面パラメータ[営業所コード = conKokyakuCd,号車コード = conGoshaCd,号車名 = "conGoshaMei",車両名 = "conSharyoMei",ドライバーコード = "conDriverCd",世代検索条件 = {01},適用日=null,削除のみ検索 = null,適用名=conTekiyoMei]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2() throws IllegalAccessException, InvocationTargetException,
            InstantiationException {

        // Mockitoオブジェクトの予想return値設定
        Mst471Form mst471Form = new Mst471Form();
        //営業所コード
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("conKokyakuCd");
        mst471Form.setConEigyoshoCd(conKokyakuCd);
        //号車コード
        mst471Form.setConGoshaCd("conGoshaCd");
        //号車名
        mst471Form.setConGoshaMei("conGoshaMei");
        //車両名
        mst471Form.setConSharyoMei("conSharyoMei");
        //車両No
        AutoCompOptionBean conSharyoNo = new AutoCompOptionBean();
        conSharyoNo.setValue("ConSharyoNo911");
        mst471Form.setConSharyoNo(conSharyoNo);
        //ドライバーコード
        AutoCompOptionBean conDriverCd = new AutoCompOptionBean();
        conDriverCd.setValue("conDriverCd911");
        mst471Form.setConDriverCd(conDriverCd);
        //世代検索条件
        mst471Form.setConSedaiKensakuJoken(new String[]{"01"});
        //適用日
        mst471Form.setConTekiyoBi(null);
        //削除のみ検索
        mst471Form.setConSakujoNomiKensaku(null);
        //適用名
        mst471Form.setConTekiyoMei("conTekiyoMei");
        
        // Mockitoオブジェクトの予想return値設定
        Flash flash = new FlashKls();
        //前画面パラメータ[営業所コード = conKokyakuCd,号車コード = conGoshaCd,号車名 = "conGoshaMei",車両名 = "conSharyoMei",ドライバーコード = "conDriverCd",世代検索条件 = {01},適用日=null,削除のみ検索 = null,適用名=conTekiyoMei]
        flash.put("mst471Form", mst471Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());

        //テスト実行
        Mst471Form form = new Mst471Form();
        target.setMst471Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID", "", false);

        //実施結果Outを取得
        form = target.getMst471Form();

        //想定通りに再検索を実施する。
        assertEquals("search_mst471", keyCaptor_2.getValue());
        assertEquals("conKokyakuCd", form.getConEigyoshoCd().getValue());
        assertEquals("conGoshaCd", form.getConGoshaCd());
        assertEquals("conGoshaMei", form.getConGoshaMei());
        assertEquals("conSharyoMei", form.getConSharyoMei());
        assertEquals("conDriverCd911", form.getConDriverCd().getValue());
        assertEquals("ConSharyoNo911", form.getConSharyoNo().getValue());
        assertEquals(null, form.getConTekiyoBi());
        assertEquals("conTekiyoMei", form.getConTekiyoMei());
    }
    
    // init_正常_初期処理_1_3
    //
    // -------------------テスト条件--------------------------
    // //前画面パラメータ[営業所コード = conKokyakuCd,号車コード = conGoshaCd,号車名 = "conGoshaMei",車両名 = "conSharyoMei",ドライバーコード = "conDriverCd",世代検索条件 = {01},適用日=null,削除のみ検索 = null,適用名=conTekiyoMei]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3() throws IllegalAccessException, InvocationTargetException,
            InstantiationException {

        // Mockitoオブジェクトの予想return値設定
        Mst471Form mst471Form = new Mst471Form();
        //営業所コード
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("conKokyakuCd");
        mst471Form.setConEigyoshoCd(conKokyakuCd);
        //号車コード
        mst471Form.setConGoshaCd("conGoshaCd");
        //号車名
        mst471Form.setConGoshaMei("conGoshaMei");
        //車両名
        mst471Form.setConSharyoMei("conSharyoMei");
        //車両No
        AutoCompOptionBean conSharyoNo = new AutoCompOptionBean();
        conSharyoNo.setValue("ConSharyoNo911");
        mst471Form.setConSharyoNo(conSharyoNo);
        //ドライバーコード
        AutoCompOptionBean conDriverCd = new AutoCompOptionBean();
        conDriverCd.setValue("conDriverCd911");
        mst471Form.setConDriverCd(conDriverCd);
        //世代検索条件
        mst471Form.setConSedaiKensakuJoken(new String[]{"01"});
        //適用日
        mst471Form.setConTekiyoBi(null);
        //削除のみ検索
        mst471Form.setConSakujoNomiKensaku(null);
        //適用名
        mst471Form.setConTekiyoMei("conTekiyoMei");
        
        // Mockitoオブジェクトの予想return値設定
        Flash flash = new FlashKls();
        //前画面パラメータ null
        flash.put("mst471Form", null);
        when(pageCommonBean.getPageParam()).thenReturn(flash);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());

        //テスト実行
        Mst471Form form = new Mst471Form();
        target.setMst471Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID", "", false);

        //実施結果Outを取得
        form = target.getMst471Form();

        //想定通りに再検索を実施する。
        assertEquals(null, form.getConTekiyoMei());
    }

    // init_正常_初期処理_1_4
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_4() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        //前画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(null);

        //テスト実行
        Mst471Form form = new Mst471Form();
        target.setMst471Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID", "", false);

        //実施結果Outを取得
        form = target.getMst471Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst471Form", keyCaptor_1.getValue());
        //想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null, form.getSearchResult());
    }
    
    // init_正常_初期処理_1_5
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_5() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        //前画面情報[null]
        doThrow(IllegalAccessException.class).when(pageCommonBean).getPageInfo(keyCaptor_1.capture());

        //テスト実行
        Mst471Form form = new Mst471Form();
        target.setMst471Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID", "", false);

        //実施結果Outを取得
        form = target.getMst471Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst471Form", keyCaptor_1.getValue());
        //想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null, form.getSearchResult());
    }

    // search_正常_検索処理_2-1
    //
    // -------------------テスト条件--------------------------
    // K-INGコード検索結果一覧取得
    // 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //K-INGコード検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 0; i++) {
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst471Form form = new Mst471Form();
        //営業所コード
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("conKokyakuCd911");
        form.setConEigyoshoCd(conKokyakuCd);
        //号車コード
        form.setConGoshaCd("conGoshaCd911");
        //号車名
        form.setConGoshaMei("conGoshaMei911");
        //車両名
        form.setConSharyoMei("conSharyoMei911");
        //車両No
        AutoCompOptionBean conSharyoNo = new AutoCompOptionBean();
        conSharyoNo.setValue("ConSharyoNo911");
        form.setConSharyoNo(conSharyoNo);
        //ドライバーコード
        AutoCompOptionBean conDriverCd = new AutoCompOptionBean();
        conDriverCd.setValue("conDriverCd911");
        form.setConDriverCd(conDriverCd);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01"});
        //適用日
        form.setConTekiyoBi(null);
        //削除のみ検索
        form.setConSakujoNomiKensaku(null);
        //適用名
        form.setConTekiyoMei("conTekiyoMei911");
        
        target.setMst471Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst471Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conKokyakuCd911",  paramsCaptor_1.getAllValues().get(0).get("conEigyoshoCd"));
        assertEquals("conGoshaCd911", paramsCaptor_1.getAllValues().get(0).get("conGoshaCd"));
        assertEquals("ConSharyoNo911", paramsCaptor_1.getAllValues().get(0).get("conSharyoNo"));
        assertEquals("conDriverCd911", paramsCaptor_1.getAllValues().get(0).get("conDriverCd"));
        assertEquals("1", ((String[])paramsCaptor_1.getAllValues().get(0).get("conSedaiKensakuJoken"))[0]);
        assertEquals(null, paramsCaptor_1.getAllValues().get(0).get("conTekiyoBi"));
        assertEquals(null, paramsCaptor_1.getAllValues().get(0).get("conSakujoNomiKensaku"));
        assertEquals("conTekiyoMei911", paramsCaptor_1.getAllValues().get(0).get("conTekiyoMei"));
        assertEquals("mst471-get-gosha-detail", functionCodeCaptor_2.getAllValues().get(0));
        //想定通りにKINGコード変換マスタ一覧を表示されること
        assertForRecList_2_1(form);
    }

    // search_正常_検索処理_2-2
    //
    // -------------------テスト条件--------------------------
    // K-INGコード検索結果一覧取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_2() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // K-INGコード検索結果一覧取得 取得件数 = 2
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        
        // テスト実行
        Mst471Form form = new Mst471Form();
        //営業所コード
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("conKokyakuCd911");
        form.setConEigyoshoCd(conKokyakuCd);
        //号車コード
        form.setConGoshaCd("conGoshaCd911");
        //号車名
        form.setConGoshaMei("conGoshaMei911");
        //車両名
        form.setConSharyoMei("conSharyoMei911");
        //車両No
        AutoCompOptionBean conSharyoNo = new AutoCompOptionBean();
        conSharyoNo.setValue("ConSharyoNo911");
        form.setConSharyoNo(conSharyoNo);
        //ドライバーコード
        AutoCompOptionBean conDriverCd = new AutoCompOptionBean();
        conDriverCd.setValue("conDriverCd911");
        form.setConDriverCd(conDriverCd);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01"});
        //適用日
        form.setConTekiyoBi(null);
        //削除のみ検索
        form.setConSakujoNomiKensaku(null);
        //適用名
        form.setConTekiyoMei("conTekiyoMei911");
        
        target.setMst471Form(form);
        target.search();

        // 実施結果Outを取得
        form = target.getMst471Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conKokyakuCd911",  paramsCaptor_1.getAllValues().get(0).get("conEigyoshoCd"));
        assertEquals("conGoshaCd911", paramsCaptor_1.getAllValues().get(0).get("conGoshaCd"));
        assertEquals("ConSharyoNo911", paramsCaptor_1.getAllValues().get(0).get("conSharyoNo"));
        assertEquals("conDriverCd911", paramsCaptor_1.getAllValues().get(0).get("conDriverCd"));
        assertEquals("1", ((String[])paramsCaptor_1.getAllValues().get(0).get("conSedaiKensakuJoken"))[0]);
        assertEquals(null, paramsCaptor_1.getAllValues().get(0).get("conTekiyoBi"));
        assertEquals(null, paramsCaptor_1.getAllValues().get(0).get("conSakujoNomiKensaku"));
        assertEquals("conTekiyoMei911", paramsCaptor_1.getAllValues().get(0).get("conTekiyoMei"));
        assertEquals("mst471-get-gosha-detail", functionCodeCaptor_2.getAllValues().get(0));
        //想定通りに K-INGコード変換マスタ一覧を表示されること
        assertForRecList_2_2(form);
    }

    // search_異常_検索処理_2-3
    //
    // -------------------テスト条件--------------------------
    //  K-INGコード検索結果一覧取得 取得件数 = 0
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_3() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // K-INGコード検索結果一覧取得 取得件数 = 0
        List<Map<String, String>> result = new ArrayList<>();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst471Form form = new Mst471Form();
        //営業所コード
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("conKokyakuCd911");
        form.setConEigyoshoCd(conKokyakuCd);
        //号車コード
        form.setConGoshaCd("conGoshaCd911");
        //号車名
        form.setConGoshaMei("conGoshaMei911");
        //車両名
        form.setConSharyoMei("conSharyoMei911");
        //車両No
        AutoCompOptionBean conSharyoNo = new AutoCompOptionBean();
        conSharyoNo.setValue("ConSharyoNo911");
        form.setConSharyoNo(conSharyoNo);
        //ドライバーコード
        AutoCompOptionBean conDriverCd = new AutoCompOptionBean();
        conDriverCd.setValue("conDriverCd911");
        form.setConDriverCd(conDriverCd);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01"});
        //適用日
        form.setConTekiyoBi(null);
        //削除のみ検索
        form.setConSakujoNomiKensaku(null);
        //適用名
        form.setConTekiyoMei("conTekiyoMei911");
        
        target.setMst471Form(form);
        target.search();

        //実施結果Outを取得
        form = target.getMst471Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conKokyakuCd911",  paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("conGoshaCd911", paramsCaptor_1.getValue().get("conGoshaCd"));
        assertEquals("ConSharyoNo911", paramsCaptor_1.getValue().get("conSharyoNo"));
        assertEquals("conDriverCd911", paramsCaptor_1.getValue().get("conDriverCd"));
        assertEquals("1", ((String[])paramsCaptor_1.getValue().get("conSedaiKensakuJoken"))[0]);
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSakujoNomiKensaku"));
        assertEquals("conTekiyoMei911", paramsCaptor_1.getValue().get("conTekiyoMei"));
        assertEquals("mst471-get-gosha-detail", functionCodeCaptor_2.getValue());
        //想定通りに ・ファンクションボタンは表示（検索前と同じ） 
        assertForRecList_2_3(form);
    }

    // getRecordCount_正常_件数取得処理_2-4
    //
    // -------------------テスト条件--------------------------
    //  K-INGコード検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_4() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // K-INGコード検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst471Form form = new Mst471Form();
        //営業所コード
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("conKokyakuCd911");
        form.setConEigyoshoCd(conKokyakuCd);
        //号車コード
        form.setConGoshaCd("conGoshaCd911");
        //号車名
        form.setConGoshaMei("conGoshaMei911");
        //車両名
        form.setConSharyoMei("conSharyoMei911");
        //車両No
        AutoCompOptionBean conSharyoNo = new AutoCompOptionBean();
        conSharyoNo.setValue("ConSharyoNo911");
        form.setConSharyoNo(conSharyoNo);
        //ドライバーコード
        AutoCompOptionBean conDriverCd = new AutoCompOptionBean();
        conDriverCd.setValue("conDriverCd911");
        form.setConDriverCd(conDriverCd);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01"});
        //適用日
        form.setConTekiyoBi(null);
        //削除のみ検索
        form.setConSakujoNomiKensaku(null);
        //適用名
        form.setConTekiyoMei("conTekiyoMei911");
        
        target.setMst471Form(form);
        target.getRecordCount(false);

        //実施結果Outを取得
        form = target.getMst471Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conKokyakuCd911",  paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("conGoshaCd911", paramsCaptor_1.getValue().get("conGoshaCd"));
        assertEquals("ConSharyoNo911", paramsCaptor_1.getValue().get("conSharyoNo"));
        assertEquals("conDriverCd911", paramsCaptor_1.getValue().get("conDriverCd"));
        assertEquals("1", ((String[])paramsCaptor_1.getValue().get("conSedaiKensakuJoken"))[0]);
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals(null, paramsCaptor_1.getValue().get("conSakujoNomiKensaku"));
        assertEquals("conTekiyoMei911", paramsCaptor_1.getValue().get("conTekiyoMei"));
        assertEquals("mst471-get-gosha-kensu", functionCodeCaptor_2.getValue());
    }

    // clear_正常_クリア処理_3-1
    //
    // -------------------テスト条件--------------------------
    // 検索条件と検索結果がある
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_1() throws IllegalAccessException, InvocationTargetException {
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // K-INGコード検索結果一覧取得 取得件数 = 2
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        
        //テスト実行
        Mst471Form form = new Mst471Form();
        //営業所コード
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("conKokyakuCd911");
        form.setConEigyoshoCd(conKokyakuCd);
        //号車コード
        form.setConGoshaCd("conGoshaCd911");
        //号車名
        form.setConGoshaMei("conGoshaMei911");
        //車両名
        form.setConSharyoMei("conSharyoMei911");
        //車両No
        AutoCompOptionBean conSharyoNo = new AutoCompOptionBean();
        conSharyoNo.setValue("ConSharyoNo911");
        form.setConSharyoNo(conSharyoNo);
        //ドライバーコード
        AutoCompOptionBean conDriverCd = new AutoCompOptionBean();
        conDriverCd.setValue("conDriverCd911");
        form.setConDriverCd(conDriverCd);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01"});
        //適用日
        form.setConTekiyoBi(null);
        //削除のみ検索
        form.setConSakujoNomiKensaku(null);
        //適用名
        form.setConTekiyoMei("conTekiyoMei911");

        target.setMst471Form(form);
        target.clear();

        //実施結果Outを取得
        form = target.getMst471Form();

        //想定通りに正常にClearを実施されること
        assertEquals(null, form.getConEigyoshoCd());
        assertEquals(null, form.getConGoshaCd());
        assertEquals(null, form.getConGoshaMei());
        assertEquals(null, form.getConSharyoMei());
        assertEquals(null, form.getConDriverCd());
        //世代検索条件  現在適用：チェックあり
        assertEquals(null,  form.getConSedaiKensakuJoken()[0]);
        assertEquals(null,  form.getConSedaiKensakuJoken()[1]);
        assertEquals(null, form.getConTekiyoBi());
        assertEquals(null, form.getConSakujoNomiKensaku());
        assertEquals(null, form.getConTekiyoMei());
        //検索結果がない
        assertEquals(null,form.getSearchResult());
        assertEquals(null,form.getSearchResultSelectable());
        assertEquals(null,form.getSelectedSearchResult());
    }

    // clear_正常_クリア処理_3-2
    //
    // -------------------テスト条件--------------------------
    // 検索条件がある、検索結果がない
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_2() throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst471Form form = new Mst471Form();
        //営業所コード
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("conKokyakuCd911");
        form.setConEigyoshoCd(conKokyakuCd);
        //号車コード
        form.setConGoshaCd("conGoshaCd911");
        //号車名
        form.setConGoshaMei("conGoshaMei911");
        //車両名
        form.setConSharyoMei("conSharyoMei911");
        ///車両No
        AutoCompOptionBean conSharyoNo = new AutoCompOptionBean();
        conSharyoNo.setValue("ConSharyoNo911");
        form.setConSharyoNo(conSharyoNo);
        //ドライバーコード
        AutoCompOptionBean conDriverCd = new AutoCompOptionBean();
        conDriverCd.setValue("conDriverCd911");
        form.setConDriverCd(conDriverCd);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01"});
        //適用日
        form.setConTekiyoBi(null);
        //削除のみ検索
        form.setConSakujoNomiKensaku(null);
        //適用名
        form.setConTekiyoMei("conTekiyoMei911");
        
        target.setMst471Form(form);
        target.clear();

        //実施結果Outを取得
        form = target.getMst471Form();

        //想定通りに正常にClearを実施されること
        assertEquals(null, form.getConEigyoshoCd());
        assertEquals(null, form.getConGoshaCd());
        assertEquals(null, form.getConGoshaMei());
        assertEquals(null, form.getConSharyoMei());
        assertEquals(null, form.getConDriverCd());
        //世代検索条件  現在適用：チェックあり
        //assertEquals("1",  form.getConSedaiKensakuJoken()[0]);
        assertEquals(null,  form.getConSedaiKensakuJoken()[0]);
        assertEquals(null,  form.getConSedaiKensakuJoken()[1]);
        assertEquals(null, form.getConTekiyoBi());
        assertEquals(null, form.getConSakujoNomiKensaku());
        assertEquals(null, form.getConTekiyoMei());
        //検索結果がない
        assertEquals(null,form.getSearchResult());
        assertEquals(null,form.getSearchResultSelectable());
        assertEquals(null,form.getSelectedSearchResult());
    }

    // getHeader_正常_ダウンロード_4-1
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void getHeader_正常_ダウンロード_4_1() throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst471Form form = new Mst471Form();
        //営業所コード
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("conKokyakuCd911");
        form.setConEigyoshoCd(conKokyakuCd);
        //号車コード
        form.setConGoshaCd("conGoshaCd911");
        //号車名
        form.setConGoshaMei("conGoshaMei911");
        //車両名
        form.setConSharyoMei("conSharyoMei911");
        //車両No
        AutoCompOptionBean conSharyoNo = new AutoCompOptionBean();
        conSharyoNo.setValue("ConSharyoNo911");
        form.setConSharyoNo(conSharyoNo);
        //ドライバーコード
        AutoCompOptionBean conDriverCd = new AutoCompOptionBean();
        conDriverCd.setValue("conDriverCd911");
        form.setConDriverCd(conDriverCd);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01"});
        //適用日
        form.setConTekiyoBi(null);
        //削除のみ検索
        form.setConSakujoNomiKensaku(null);
        //適用名
        form.setConTekiyoMei("conTekiyoMei911");
        target.setMst471Form(form);
        List<CSVDto> dto = target.getHeader();

        //実施結果Outを取得
        form = target.getMst471Form();

        // 実行時に渡すパラメータの検証
        assertEquals("conKokyakuCd911", form.getConEigyoshoCd().getValue());
        assertEquals("conGoshaCd911", form.getConGoshaCd());
        assertEquals("ConSharyoNo911", form.getConSharyoNo().getValue());
        assertEquals("conDriverCd911", form.getConDriverCd().getValue());
        //世代検索条件  現在適用：チェックあり
        assertEquals("01",  form.getConSedaiKensakuJoken()[0]);
        assertEquals(null, form.getConTekiyoBi());
        assertEquals(null, form.getConSakujoNomiKensaku());
        assertEquals("conTekiyoMei911", form.getConTekiyoMei());
        //想定通りに正常にCVSのHeaderを設定されること
        assertEquals("号車コード", dto.get(0).getTitle());
        assertEquals("listGoshaCd", dto.get(0).getName());
        assertEquals("号車名", dto.get(1).getTitle());
        assertEquals("listGoshaMei", dto.get(1).getName());
        assertEquals("適用開始日", dto.get(2).getTitle());
        assertEquals("listTekiyoKaishiBi", dto.get(2).getName());
        assertEquals("適用終了日", dto.get(3).getTitle());
        assertEquals("listTekiyoShuryoBiText", dto.get(3).getName());
        assertEquals("車両No", dto.get(4).getTitle());
        assertEquals("listSharyoNo", dto.get(4).getName());
        assertEquals("車両名", dto.get(5).getTitle());
        assertEquals("listSharyoMei", dto.get(5).getName());
        assertEquals("ドライバーコード", dto.get(6).getTitle());
        assertEquals("listDriverCd", dto.get(6).getName());
        assertEquals("ドライバー名", dto.get(7).getTitle());
        assertEquals("listDriverMei", dto.get(7).getName());
        assertEquals("開始住所JISコード", dto.get(8).getTitle());
        assertEquals("listKaishiJisCd", dto.get(8).getName());
        assertEquals("開始住所", dto.get(9).getTitle());
        assertEquals("listKaishiJisJusho", dto.get(9).getName());
        assertEquals("終了住所JISコード", dto.get(10).getTitle());
        assertEquals("listShuryoJisCd", dto.get(10).getName());
        assertEquals("終了住所", dto.get(11).getTitle());
        assertEquals("listShuryoJisJusho", dto.get(11).getName());
        assertEquals("ハンディ持参区分", dto.get(12).getTitle());
        assertEquals("listHandyJisanKbn", dto.get(12).getName());
        assertEquals("仕向地設定", dto.get(13).getTitle());
        assertEquals("listShimukechiSettei", dto.get(13).getName());
        assertEquals("適用名", dto.get(14).getTitle());
        assertEquals("listTekiyoMei", dto.get(14).getName());
    }

    // beforeDown_正常_ダウンロード_4-2
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=2件
    // -----------------------------------------------------
    @Test
    public void beforeDown_正常_ダウンロード_4_2() throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst471Form form = new Mst471Form();
        target.setMst471Form(form);
        try {
            target.beforeDown("testComment");
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(Mst471BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        //実施結果Outを取得
        form = target.getMst471Form();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にダウンロード理由を記録すること
        assertEquals(null,form.getConGoshaCd());
    }

    // searchGoshaShimukechi_正常_設定ボタンをクリック_20_1
    //
    // -------------------テスト条件--------------------------
    // 正常に取得された場合
    // -----------------------------------------------------
    @Test
    public void searchGoshaShimukechi_正常_設定ボタンをクリック_20_1() throws IllegalAccessException,
            InvocationTargetException {

       // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // K-INGコード検索結果一覧取得 取得件数 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        //テスト実行
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_24_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        Mst471Form form = new Mst471Form();
        form.setSelectedSearchResult(result);
        //営業所コード
        AutoCompOptionBean listEigyoshoCd = new AutoCompOptionBean();
        listEigyoshoCd.setValue("conKokyakuCd911");
        
        target.setMst471Form(form);
        target.searchGoshaShimukechi(listEigyoshoCd, "listGoshaCd", "2019/01/02");

        //実施結果Outを取得
        form = target.getMst471Form();

        //想定通りに履歴を表示する。
        assertEquals("mst471-get-goshashimuke-detail", functionCodeCaptor_2.getValue());
        assertEquals("listGoshaCd", paramsCaptor_1.getValue().get("listGoshaCd"));
        assertEquals("conKokyakuCd911", paramsCaptor_1.getValue().get("listEigyoshoCd"));
        assertEquals("2019/01/02", paramsCaptor_1.getValue().get("listTekiyoKaishiBi"));
        createRecMapFor_24_2(form);
    }
    
    // rirekiIchiran_正常_更新履歴コンテキストメニュー_24-1
    //
    // -------------------テスト条件--------------------------
    // 正常に取得された場合
    // -----------------------------------------------------
    @Test
    public void rirekiIchiran_正常_更新履歴コンテキストメニュー_24_1() throws IllegalAccessException,
            InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> titleFlgCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> searchKeyCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(rirekiSyosaiBean).searchList(titleFlgCaptor_1.capture(), functionCodeCaptor_2.capture(),
                searchKeyCaptor_3.capture());
        //テスト実行
        Mst471Form form = new Mst471Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_24_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst471Form(form);
        target.rirekiIchiran();

        //実施結果Outを取得
        form = target.getMst471Form();

        //想定通りに履歴を表示する。
        assertEquals("2", titleFlgCaptor_1.getValue());
        assertEquals("MST471_SEARCH_RIREKI", functionCodeCaptor_2.getValue());
        assertEquals("listGoshaCd0", searchKeyCaptor_3.getValue().get("listGoshaCd"));
        assertEquals("listEigyoshoCd0", searchKeyCaptor_3.getValue().get("listEigyoshoCd"));
        assertEquals("2019/01/02", searchKeyCaptor_3.getValue().get("listTekiyoKaishiBi"));
    }
    
    // update_異常_更新ボタン_新規登録_29_1
    //
    // -------------------テスト条件--------------------------
    // 入力した営業所コード・号車コード・適用開始日がDBに存在する [COME0018]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_新規登録_29_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 終了チェック 適用終了日が入力済みの場合 [COME0018]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0018", "listEigyoshoCdlistGoshaCdlistTekiyoKaishiBi");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5
                .capture(), tableNameCaptor_6.capture());

        //テスト実行
        Mst471Form form = new Mst471Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
             result.add(createRecMapFor_29_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst471Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst471Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listGoshaCd0", paramsCaptor_1_Param.get("listGoshaCd"));
        assertEquals("listGoshaMei0", paramsCaptor_1_Param.get("listGoshaMei"));
        assertEquals("2019/01/01", paramsCaptor_1_Param.get("listTekiyoKaishiBi"));
        assertEquals("true", paramsCaptor_1_Param.get("listTekiyoShuryoBiChk"));
        assertEquals("Wed Jan 02 00:00:00 CST 2019", paramsCaptor_1_Param.get("listTekiyoShuryoBiText"));
        assertEquals("listSharyoNo0", paramsCaptor_1_Param.get("listSharyoNo"));
        assertEquals("listSharyoMei0", paramsCaptor_1_Param.get("listSharyoMei"));
        assertEquals("listDriverCd0", paramsCaptor_1_Param.get("listDriverCd"));
        assertEquals("listDriverMei0", paramsCaptor_1_Param.get("listDriverMei"));
        assertEquals("listKaishiJisCd0", paramsCaptor_1_Param.get("listKaishiJisCd"));
        assertEquals("listHandyJisanKbn0", paramsCaptor_1_Param.get("listHandyJisanKbn"));
        assertEquals("listGoshaCd0", paramsCaptor_1_Param.get("listGoshaCd"));
        assertEquals("listTekiyoMei0", paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listEigyoshoCd0", paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("mst471-insert-duplicated-kensu", functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0018）
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0018", summaryCaptor_4.getValue());
    }

    // update_正常_更新ボタン_新規登録_29_2
    //
    // -------------------テスト条件--------------------------
    // 入力した営業所コード・号車コード・適用開始日がDBに存在しない
    // -----------------------------------------------------
    @Test
    public void update_正常_更新ボタン_新規登録_29_2() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 入力した営業所コード・号車コード・適用開始日がDBに存在しない
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //号車マスタ検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture());

        //テスト実行
        Mst471Form form = new Mst471Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_29_1(i));
        }
        form.setSelectedSearchResult(result);
        //営業所コード
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("conKokyakuCd911");
        form.setConEigyoshoCd(conKokyakuCd);
        //号車コード
        form.setConGoshaCd("conGoshaCd911");
        //号車名
        form.setConGoshaMei("conGoshaMei911");
        //車両名
        form.setConSharyoMei("conSharyoMei911");
        //車両No
        AutoCompOptionBean conSharyoNo = new AutoCompOptionBean();
        conSharyoNo.setValue("ConSharyoNo911");
        form.setConSharyoNo(conSharyoNo);
        //ドライバーコード
        AutoCompOptionBean conDriverCd = new AutoCompOptionBean();
        conDriverCd.setValue("conDriverCd911");
        form.setConDriverCd(conDriverCd);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01"});
        //適用日
        form.setConTekiyoBi(null);
        //削除のみ検索
        form.setConSakujoNomiKensaku(null);
        //適用名
        form.setConTekiyoMei("conTekiyoMei911");
        target.setMst471Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst471Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listGoshaCd0", paramsCaptor_1_Param.get("listGoshaCd"));
        assertEquals("listGoshaMei0", paramsCaptor_1_Param.get("listGoshaMei"));
        assertEquals("2019/01/01", paramsCaptor_1_Param.get("listTekiyoKaishiBi"));
        assertEquals("true", paramsCaptor_1_Param.get("listTekiyoShuryoBiChk"));
        assertEquals("Wed Jan 02 00:00:00 CST 2019", paramsCaptor_1_Param.get("listTekiyoShuryoBiText"));
        assertEquals("listSharyoNo0", paramsCaptor_1_Param.get("listSharyoNo"));
        assertEquals("listSharyoMei0", paramsCaptor_1_Param.get("listSharyoMei"));
        assertEquals("listDriverCd0", paramsCaptor_1_Param.get("listDriverCd"));
        assertEquals("listDriverMei0", paramsCaptor_1_Param.get("listDriverMei"));
        assertEquals("listKaishiJisCd0", paramsCaptor_1_Param.get("listKaishiJisCd"));
        assertEquals("listHandyJisanKbn0", paramsCaptor_1_Param.get("listHandyJisanKbn"));
        assertEquals("listGoshaCd0", paramsCaptor_1_Param.get("listGoshaCd"));
        assertEquals("listTekiyoMei0", paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listEigyoshoCd0", paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("mst471-insertupdate-gosha", functionCodeCaptor_2.getValue());
        //想定通りに正常終了メッセージ（メッセージID：COMI0007）を表示されること
        assertEquals("INFO", levelCaptor_3.getValue());
        assertEquals("COMI0007", summaryCaptor_4.getValue());
        assertEquals("更新", detailCaptor_5.getValue());
    }

    // update_異常_更新ボタン_新規登録_29_3
    //
    // -------------------テスト条件--------------------------
    // 同じ営業所コード・号車コードで未削除 かつ 適用終了日が設定されているデータが号車マスタに存在した  [MSTE110]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_新規登録_29_3() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //号車マスタに存在しない[MSTE110]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE110", "listEigyoshoCdlistGoshaCdlistTekiyoKaishiBi");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture(), tableNameCaptor_6
                        .capture());

        //テスト実行
        Mst471Form form = new Mst471Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            result.add(createRecMapFor_29_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst471Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst471Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listGoshaCd0", paramsCaptor_1_Param.get("listGoshaCd"));
        assertEquals("listGoshaMei0", paramsCaptor_1_Param.get("listGoshaMei"));
        assertEquals("2019/01/01", paramsCaptor_1_Param.get("listTekiyoKaishiBi"));
        assertEquals("true", paramsCaptor_1_Param.get("listTekiyoShuryoBiChk"));
        assertEquals("Wed Jan 02 00:00:00 CST 2019", paramsCaptor_1_Param.get("listTekiyoShuryoBiText"));
        assertEquals("listSharyoNo0", paramsCaptor_1_Param.get("listSharyoNo"));
        assertEquals("listSharyoMei0", paramsCaptor_1_Param.get("listSharyoMei"));
        assertEquals("listDriverCd0", paramsCaptor_1_Param.get("listDriverCd"));
        assertEquals("listDriverMei0", paramsCaptor_1_Param.get("listDriverMei"));
        assertEquals("listKaishiJisCd0", paramsCaptor_1_Param.get("listKaishiJisCd"));
        assertEquals("listHandyJisanKbn0", paramsCaptor_1_Param.get("listHandyJisanKbn"));
        assertEquals("listGoshaCd0", paramsCaptor_1_Param.get("listGoshaCd"));
        assertEquals("listTekiyoMei0", paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listEigyoshoCd0", paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("mst471-insert-duplicated-kensu", functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：MSTE110）
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("MSTE110", summaryCaptor_4.getValue());
    }

    // update_正常_更新ボタン_新規登録_29_4
    //
    // -------------------テスト条件--------------------------
    // 同じ営業所コード・号車コードで未削除 かつ 適用終了日が設定されているデータが号車マスタに存在しない
    // -----------------------------------------------------
    @Test
    public void update_正常_更新ボタン_新規登録_29_4() throws IllegalAccessException, InvocationTargetException {
        
        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 同じ営業所コード・号車コードで未削除 かつ 適用終了日が設定されているデータが号車マスタに存在しない
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //号車マスタ検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture());

        //テスト実行
        Mst471Form form = new Mst471Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_29_1(i));
        }
        form.setSelectedSearchResult(result);
        //営業所コード
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("conKokyakuCd911");
        form.setConEigyoshoCd(conKokyakuCd);
        //号車コード
        form.setConGoshaCd("conGoshaCd911");
        //号車名
        form.setConGoshaMei("conGoshaMei911");
        //車両名
        form.setConSharyoMei("conSharyoMei911");
        //車両No
        AutoCompOptionBean conSharyoNo = new AutoCompOptionBean();
        conSharyoNo.setValue("ConSharyoNo911");
        form.setConSharyoNo(conSharyoNo);
        //ドライバーコード
        AutoCompOptionBean conDriverCd = new AutoCompOptionBean();
        conDriverCd.setValue("conDriverCd911");
        form.setConDriverCd(conDriverCd);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01"});
        //適用日
        form.setConTekiyoBi(null);
        //削除のみ検索
        form.setConSakujoNomiKensaku(null);
        //適用名
        form.setConTekiyoMei("conTekiyoMei911");
        target.setMst471Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst471Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listGoshaCd0", paramsCaptor_1_Param.get("listGoshaCd"));
        assertEquals("listGoshaMei0", paramsCaptor_1_Param.get("listGoshaMei"));
        assertEquals("2019/01/01", paramsCaptor_1_Param.get("listTekiyoKaishiBi"));
        assertEquals("true", paramsCaptor_1_Param.get("listTekiyoShuryoBiChk"));
        assertEquals("Wed Jan 02 00:00:00 CST 2019", paramsCaptor_1_Param.get("listTekiyoShuryoBiText"));
        assertEquals("listSharyoNo0", paramsCaptor_1_Param.get("listSharyoNo"));
        assertEquals("listSharyoMei0", paramsCaptor_1_Param.get("listSharyoMei"));
        assertEquals("listDriverCd0", paramsCaptor_1_Param.get("listDriverCd"));
        assertEquals("listDriverMei0", paramsCaptor_1_Param.get("listDriverMei"));
        assertEquals("listKaishiJisCd0", paramsCaptor_1_Param.get("listKaishiJisCd"));
        assertEquals("listHandyJisanKbn0", paramsCaptor_1_Param.get("listHandyJisanKbn"));
        assertEquals("listGoshaCd0", paramsCaptor_1_Param.get("listGoshaCd"));
        assertEquals("listTekiyoMei0", paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listEigyoshoCd0", paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("mst471-insertupdate-gosha", functionCodeCaptor_2.getValue());
        //想定通りに正常終了メッセージ（メッセージID：COMI0007）を表示されること
        assertEquals("INFO", levelCaptor_3.getValue());
        assertEquals("COMI0007", summaryCaptor_4.getValue());
        assertEquals("更新", detailCaptor_5.getValue());
    }
    
    // update_異常_更新ボタン_更新登録_29_5
    //
    // -------------------テスト条件--------------------------
    // 営業所コード・号車コード・適用開始日の組み合わせが号車マスタに存在しない [MSTE0109]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_更新登録_29_5() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 営業所コード・号車コード・適用開始日の組み合わせが号車マスタに存在しない [MSTE0109]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0109", "listEigyoshoCdlistGoshaCdlistTekiyoKaishiBi");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5
                .capture(), tableNameCaptor_6.capture());

        //テスト実行
        Mst471Form form = new Mst471Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
             result.add(createRecMapFor_29_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst471Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst471Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listGoshaCd0", paramsCaptor_1_Param.get("listGoshaCd"));
        assertEquals("listGoshaMei0", paramsCaptor_1_Param.get("listGoshaMei"));
        assertEquals("2019/01/01", paramsCaptor_1_Param.get("listTekiyoKaishiBi"));
        assertEquals("true", paramsCaptor_1_Param.get("listTekiyoShuryoBiChk"));
        assertEquals("Wed Jan 02 00:00:00 CST 2019", paramsCaptor_1_Param.get("listTekiyoShuryoBiText"));
        assertEquals("listSharyoNo0", paramsCaptor_1_Param.get("listSharyoNo"));
        assertEquals("listSharyoMei0", paramsCaptor_1_Param.get("listSharyoMei"));
        assertEquals("listDriverCd0", paramsCaptor_1_Param.get("listDriverCd"));
        assertEquals("listDriverMei0", paramsCaptor_1_Param.get("listDriverMei"));
        assertEquals("listKaishiJisCd0", paramsCaptor_1_Param.get("listKaishiJisCd"));
        assertEquals("listHandyJisanKbn0", paramsCaptor_1_Param.get("listHandyJisanKbn"));
        assertEquals("listGoshaCd0", paramsCaptor_1_Param.get("listGoshaCd"));
        assertEquals("listTekiyoMei0", paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listEigyoshoCd0", paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("mst471-insert-duplicated-kensu", functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：MSTE0109）
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("MSTE0109", summaryCaptor_4.getValue());
    }

    // update_正常_更新ボタン_更新登録_29_6
    //
    // -------------------テスト条件--------------------------
    // 営業所コード・号車コード・適用開始日の組み合わせが号車マスタに存在しています
    // -----------------------------------------------------
    @Test
    public void update_正常_更新ボタン_更新登録_29_6() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 営業所コード・号車コード・適用開始日の組み合わせが号車マスタに存在しています
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //号車マスタ検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture());

        //テスト実行
        Mst471Form form = new Mst471Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_29_1(i));
        }
        form.setSelectedSearchResult(result);
        //営業所コード
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("conKokyakuCd911");
        form.setConEigyoshoCd(conKokyakuCd);
        //号車コード
        form.setConGoshaCd("conGoshaCd911");
        //号車名
        form.setConGoshaMei("conGoshaMei911");
        //車両名
        form.setConSharyoMei("conSharyoMei911");
        //車両No
        AutoCompOptionBean conSharyoNo = new AutoCompOptionBean();
        conSharyoNo.setValue("ConSharyoNo911");
        form.setConSharyoNo(conSharyoNo);
        //ドライバーコード
        AutoCompOptionBean conDriverCd = new AutoCompOptionBean();
        conDriverCd.setValue("conDriverCd911");
        form.setConDriverCd(conDriverCd);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01"});
        //適用日
        form.setConTekiyoBi(null);
        //削除のみ検索
        form.setConSakujoNomiKensaku(null);
        //適用名
        form.setConTekiyoMei("conTekiyoMei911");
        target.setMst471Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst471Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listGoshaCd0", paramsCaptor_1_Param.get("listGoshaCd"));
        assertEquals("listGoshaMei0", paramsCaptor_1_Param.get("listGoshaMei"));
        assertEquals("2019/01/01", paramsCaptor_1_Param.get("listTekiyoKaishiBi"));
        assertEquals("true", paramsCaptor_1_Param.get("listTekiyoShuryoBiChk"));
        assertEquals("Wed Jan 02 00:00:00 CST 2019", paramsCaptor_1_Param.get("listTekiyoShuryoBiText"));
        assertEquals("listSharyoNo0", paramsCaptor_1_Param.get("listSharyoNo"));
        assertEquals("listSharyoMei0", paramsCaptor_1_Param.get("listSharyoMei"));
        assertEquals("listDriverCd0", paramsCaptor_1_Param.get("listDriverCd"));
        assertEquals("listDriverMei0", paramsCaptor_1_Param.get("listDriverMei"));
        assertEquals("listKaishiJisCd0", paramsCaptor_1_Param.get("listKaishiJisCd"));
        assertEquals("listHandyJisanKbn0", paramsCaptor_1_Param.get("listHandyJisanKbn"));
        assertEquals("listGoshaCd0", paramsCaptor_1_Param.get("listGoshaCd"));
        assertEquals("listTekiyoMei0", paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listEigyoshoCd0", paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("mst471-insertupdate-gosha", functionCodeCaptor_2.getValue());
        //想定通りに正常終了メッセージ（メッセージID：COMI0007）を表示されること
        assertEquals("INFO", levelCaptor_3.getValue());
        assertEquals("COMI0007", summaryCaptor_4.getValue());
        assertEquals("更新", detailCaptor_5.getValue());
    }

    // update_異常_更新ボタン_更新登録_29_7
    //
    // -------------------テスト条件--------------------------
    // 同じ営業所コード・号車コードで削除済ではない かつ 適用終了日が設定されているデータが号車マスタに存在した場合 [MSTE110]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_更新登録_29_7() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //同じ営業所コード・号車コードで削除済ではない かつ 適用終了日が設定されているデータが号車マスタに存在した場合 [MSTE110]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE110", "listEigyoshoCdlistGoshaCdlistTekiyoKaishiBi");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture(), tableNameCaptor_6
                        .capture());

        //テスト実行
        Mst471Form form = new Mst471Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            result.add(createRecMapFor_29_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst471Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst471Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listGoshaCd0", paramsCaptor_1_Param.get("listGoshaCd"));
        assertEquals("listGoshaMei0", paramsCaptor_1_Param.get("listGoshaMei"));
        assertEquals("2019/01/01", paramsCaptor_1_Param.get("listTekiyoKaishiBi"));
        assertEquals("true", paramsCaptor_1_Param.get("listTekiyoShuryoBiChk"));
        assertEquals("Wed Jan 02 00:00:00 CST 2019", paramsCaptor_1_Param.get("listTekiyoShuryoBiText"));
        assertEquals("listSharyoNo0", paramsCaptor_1_Param.get("listSharyoNo"));
        assertEquals("listSharyoMei0", paramsCaptor_1_Param.get("listSharyoMei"));
        assertEquals("listDriverCd0", paramsCaptor_1_Param.get("listDriverCd"));
        assertEquals("listDriverMei0", paramsCaptor_1_Param.get("listDriverMei"));
        assertEquals("listKaishiJisCd0", paramsCaptor_1_Param.get("listKaishiJisCd"));
        assertEquals("listHandyJisanKbn0", paramsCaptor_1_Param.get("listHandyJisanKbn"));
        assertEquals("listGoshaCd0", paramsCaptor_1_Param.get("listGoshaCd"));
        assertEquals("listTekiyoMei0", paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listEigyoshoCd0", paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("mst471-insert-duplicated-kensu", functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：MSTE110）
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("MSTE110", summaryCaptor_4.getValue());
    }

    // update_正常_更新ボタン_更新登録_29_8
    //
    // -------------------テスト条件--------------------------
    // 同じ営業所コード・号車コードで削除済ではない かつ 適用終了日が設定されているデータが号車マスタに存在しない
    // -----------------------------------------------------
    @Test
    public void update_正常_更新ボタン_更新登録_29_8() throws IllegalAccessException, InvocationTargetException {
        
        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 同じ営業所コード・号車コードで削除済ではない かつ 適用終了日が設定されているデータが号車マスタに存在しない
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //号車マスタ検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean)
                .message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture());

        //テスト実行
        Mst471Form form = new Mst471Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_29_1(i));
        }
        form.setSelectedSearchResult(result);
        //営業所コード
        AutoCompOptionBean conKokyakuCd = new AutoCompOptionBean();
        conKokyakuCd.setValue("conKokyakuCd911");
        form.setConEigyoshoCd(conKokyakuCd);
        //号車コード
        form.setConGoshaCd("conGoshaCd911");
        //号車名
        form.setConGoshaMei("conGoshaMei911");
        //車両名
        form.setConSharyoMei("conSharyoMei911");
        //車両No
        AutoCompOptionBean conSharyoNo = new AutoCompOptionBean();
        conSharyoNo.setValue("ConSharyoNo911");
        form.setConSharyoNo(conSharyoNo);
        //ドライバーコード
        AutoCompOptionBean conDriverCd = new AutoCompOptionBean();
        conDriverCd.setValue("conDriverCd911");
        form.setConDriverCd(conDriverCd);
        //世代検索条件
        form.setConSedaiKensakuJoken(new String[]{"01"});
        //適用日
        form.setConTekiyoBi(null);
        //削除のみ検索
        form.setConSakujoNomiKensaku(null);
        //適用名
        form.setConTekiyoMei("conTekiyoMei911");
        target.setMst471Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMst471Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listGoshaCd0", paramsCaptor_1_Param.get("listGoshaCd"));
        assertEquals("listGoshaMei0", paramsCaptor_1_Param.get("listGoshaMei"));
        assertEquals("2019/01/01", paramsCaptor_1_Param.get("listTekiyoKaishiBi"));
        assertEquals("true", paramsCaptor_1_Param.get("listTekiyoShuryoBiChk"));
        assertEquals("Wed Jan 02 00:00:00 CST 2019", paramsCaptor_1_Param.get("listTekiyoShuryoBiText"));
        assertEquals("listSharyoNo0", paramsCaptor_1_Param.get("listSharyoNo"));
        assertEquals("listSharyoMei0", paramsCaptor_1_Param.get("listSharyoMei"));
        assertEquals("listDriverCd0", paramsCaptor_1_Param.get("listDriverCd"));
        assertEquals("listDriverMei0", paramsCaptor_1_Param.get("listDriverMei"));
        assertEquals("listKaishiJisCd0", paramsCaptor_1_Param.get("listKaishiJisCd"));
        assertEquals("listHandyJisanKbn0", paramsCaptor_1_Param.get("listHandyJisanKbn"));
        assertEquals("listGoshaCd0", paramsCaptor_1_Param.get("listGoshaCd"));
        assertEquals("listTekiyoMei0", paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listEigyoshoCd0", paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("mst471-insertupdate-gosha", functionCodeCaptor_2.getValue());
        //想定通りに正常終了メッセージ（メッセージID：COMI0007）を表示されること
        assertEquals("INFO", levelCaptor_3.getValue());
        assertEquals("COMI0007", summaryCaptor_4.getValue());
        assertEquals("更新", detailCaptor_5.getValue());
    }

    // delRows_正常_号車マスタ削除処理_30_1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 1
    // 営業所コード・号車コード・適用開始日の組み合わせが号車マスタに存在している
    // -----------------------------------------------------
    @Test
    public void delRows_正常_号車マスタ削除処理_30_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5
                .capture());
        //テスト実行
        Mst471Form form = new Mst471Form();
        //行選択チェック選択 = 1
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_30_1(i));
        }
	form.setSelectedSearchResult(result);
        form.setSearchResult(result);
        target.setMst471Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst471Form();

        //想定通りに正常終了メッセージ（メッセージID：COMI0004）削除処理を行う。
        assertEquals("mst471-delete-row-detail", functionCodeCaptor_2.getValue());
        assertEquals("INFO", levelCaptor_3.getValue());
        assertEquals("COMI0011", summaryCaptor_4.getValue());
        assertEquals("削除", detailCaptor_5.getValue());
    }

    // delRows_正常_号車マスタ削除処理_30_2
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 2
    // 営業所コード・号車コード・適用開始日の組み合わせが号車マスタに存在している
    // -----------------------------------------------------
    @Test
    public void delRows_正常_号車マスタ削除処理_30_2() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5
                .capture());
        //テスト実行
        Mst471Form form = new Mst471Form();
        //行選択チェック選択 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            result.add(createRecMapFor_30_1(i));
        }
	form.setSelectedSearchResult(result);
        form.setSearchResult(result);
        target.setMst471Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst471Form();

        //想定通りに正常終了メッセージ（メッセージID：COMI0004）削除処理を行う。
        assertEquals("mst471-delete-row-detail", functionCodeCaptor_2.getValue());
        assertEquals("INFO", levelCaptor_3.getValue());
        assertEquals("COMI0011", summaryCaptor_4.getValue());
        assertEquals("削除", detailCaptor_5.getValue());
    }

    
    // delRowsFunc_異常_号車マスタ削除処理_30_3
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // 営業所コード・号車コード・適用開始日の組み合わせが号車マスタに存在している
    // -----------------------------------------------------
    @Test
    public void delRowsFunc_異常_号車マスタ削除処理_30_3() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(), summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        //テスト実行
        Mst471Form form = new Mst471Form();
        //行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        form.setSelectedSearchResult(result);
        target.setMst471Form(form);
        target.delRowsFunc();

        //実施結果Outを取得
        form = target.getMst471Form(); 

        //想定通りにエラーが発生。（メッセージID：COME0013）
        assertEquals("ERROR", levelCaptor_1.getValue());
        assertEquals("COME0013", summaryCaptor_2.getValue());
    }
    
    // delRows_異常_号車マスタ削除処理_30_4
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 1
    // 営業所コード・号車コード・適用開始日の組み合わせが号車マスタに存在しない  [MSTE0109]が返却
    // -----------------------------------------------------
    @Test
    public void delRows_異常_号車マスタ削除処理_30_4() throws IllegalAccessException,
            InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MSTE0109", "listEigyoshoCdlistGoshaCdlistTekiyoKaishiBi");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(), summaryCaptor_2.capture(), summaryCaptor_3.capture()))
                .thenReturn(messageModuleBean);
        //テスト実行
        Mst471Form form = new Mst471Form();
        //行選択チェック選択 = 1
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            result.add(createRecMapFor_30_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMst471Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst471Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listGoshaCd0", paramsCaptor_1_Param.get("listGoshaCd"));
        assertEquals("listGoshaMei0", paramsCaptor_1_Param.get("listGoshaMei"));
        assertEquals("2019-01-01 00:00:00.0", paramsCaptor_1_Param.get("listTekiyoKaishiBi"));
        assertEquals("Wed Jan 02 00:00:00 CST 2019", paramsCaptor_1_Param.get("listTekiyoShuryoBiText"));
        assertEquals("listSharyoNo0", paramsCaptor_1_Param.get("listSharyoNo"));
        assertEquals("listSharyoMei0", paramsCaptor_1_Param.get("listSharyoMei"));
        assertEquals("listDriverCd0", paramsCaptor_1_Param.get("listDriverCd"));
        assertEquals("listDriverMei0", paramsCaptor_1_Param.get("listDriverMei"));
        assertEquals("listKaishiJisCd0", paramsCaptor_1_Param.get("listKaishiJisCd"));
        assertEquals("listHandyJisanKbn0", paramsCaptor_1_Param.get("listHandyJisanKbn"));
        assertEquals("listGoshaCd0", paramsCaptor_1_Param.get("listGoshaCd"));
        assertEquals("listTekiyoMei0", paramsCaptor_1_Param.get("listTekiyoMei"));
        assertEquals("listEigyoshoCd0", paramsCaptor_1_Param.get("listEigyoshoCd"));
        assertEquals("mst471-delete-exist", functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：MSTE0109）
        assertEquals("ERROR", levelCaptor_1.getValue());
        assertEquals("MSTE0109", summaryCaptor_2.getValue());
        assertEquals("号車マスタ", summaryCaptor_3.getValue());
    }
    
    // delRows_異常_号車マスタ削除処理_30_5
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 1
    // 営業所コード・号車コード・適用開始日の組み合わせが号車マスタに存在している  [MSTE0109]が返却
    // -----------------------------------------------------
    @Test
    public void delRows_異常_号車マスタ削除処理_30_5() throws IllegalAccessException,
            InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5
                .capture());
        //テスト実行
        Mst471Form form = new Mst471Form();
        //行選択チェック選択 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            result.add(createRecMapFor_30_1(i));
        }
	form.setSelectedSearchResult(result);
        form.setSearchResult(result);
        target.setMst471Form(form);
        target.delRows(result);

        //実施結果Outを取得
        form = target.getMst471Form();

        //想定通りに正常終了メッセージ（メッセージID：COMI0004）削除処理を行う。
        assertEquals("mst471-delete-row-detail", functionCodeCaptor_2.getValue());
        assertEquals("INFO", levelCaptor_3.getValue());
        assertEquals("COMI0011", summaryCaptor_4.getValue());
        assertEquals("削除", detailCaptor_5.getValue());
    }

    private Map<String, String> createRecMapFor_1_1(int i) {
        Map recMap = new HashMap();
        //号車コード
        recMap.put("listGoshaCd", "listGoshaCd" + i);
        //号車名
        recMap.put("listGoshaMei", "listGoshaMei" + i);
        //適用開始日
        recMap.put("listTekiyoKaishiBi", "listTekiyoKaishiBi" + i);
        //適用終了日
        recMap.put("listTekiyoShuryoBiChk", "listTekiyoShuryoBiChk" + i);
        //車両No
        recMap.put("listSharyoNo", "listSharyoNo" + i);
        //車両名
        recMap.put("listSharyoMei", "listSharyoMei" + i);
        //ドライバーコード
        recMap.put("listDriverCd", "listDriverCd"+ i);
        //ドライバー名
        recMap.put("listDriverMei", "listDriverMei"+ i);
        //開始住所JISコード
        recMap.put("listKaishiJisCd", "listKaishiJisCd"+ i);
        //ハンディ持参区分
        recMap.put("listHandyJisanKbn", "listHandyJisanKbn"+ i);
        //仕向地設定
        recMap.put("listGoshaCd", "listGoshaCd"+ i);
        recMap.put("listTekiyoKaishiBi", "listTekiyoKaishiBi"+ i);
        //適用名
        recMap.put("listTekiyoMei", "listTekiyoMei"+ i);
        //営業所コード
        recMap.put("listEigyoshoCd", "listEigyoshoCd"+ i);
        return recMap;
    }

    private void assertForRecList_2_1(Mst471Form form) {
        int i = 0;
        assertEquals(1, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            //号車コード
            assertEquals("listGoshaCd" + i, rec.get("listGoshaCd"));
            //号車名
            assertEquals("listGoshaMei" + i, rec.get("listGoshaMei"));
            //適用開始日
            assertEquals("listTekiyoKaishiBi" + i, rec.get("listTekiyoKaishiBi"));
            //適用終了日
            assertEquals("listTekiyoShuryoBiChk" + i, rec.get("listTekiyoShuryoBiChk"));
            //車両No
            assertEquals("listSharyoNo" + i, rec.get("listSharyoNo"));
            //車両名
            assertEquals("listSharyoMei" + i, rec.get("listSharyoMei"));
            //ドライバーコード
            assertEquals("listDriverCd" + i, rec.get("listDriverCd"));
            //ドライバー名
            assertEquals("listDriverMei" + i, rec.get("listDriverMei"));
            //開始住所JISコード
            assertEquals("listKaishiJisCd" + i, rec.get("listKaishiJisCd"));
            //ハンディ持参区分
            assertEquals("listHandyJisanKbn" + i, rec.get("listHandyJisanKbn"));
            //仕向地設定
            assertEquals("listGoshaCd" + i, rec.get("listGoshaCd"));
            //適用名
            assertEquals("listTekiyoMei" + i, rec.get("listTekiyoMei"));
            //営業所コード
            assertEquals("listEigyoshoCd" + i, rec.get("listEigyoshoCd"));
            i++;
        }
    }

    private void assertForRecList_2_2(Mst471Form form) {
        int i = 0;
        assertEquals(2, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            //号車コード
            assertEquals("listGoshaCd" + i, rec.get("listGoshaCd"));
            //号車名
            assertEquals("listGoshaMei" + i, rec.get("listGoshaMei"));
            //適用開始日
            assertEquals("listTekiyoKaishiBi" + i, rec.get("listTekiyoKaishiBi"));
            //適用終了日
            assertEquals("listTekiyoShuryoBiChk" + i, rec.get("listTekiyoShuryoBiChk"));
            //車両No
            assertEquals("listSharyoNo" + i, rec.get("listSharyoNo"));
            //車両名
            assertEquals("listSharyoMei" + i, rec.get("listSharyoMei"));
            //ドライバーコード
            assertEquals("listDriverCd" + i, rec.get("listDriverCd"));
            //ドライバー名
            assertEquals("listDriverMei" + i, rec.get("listDriverMei"));
            //開始住所JISコード
            assertEquals("listKaishiJisCd" + i, rec.get("listKaishiJisCd"));
            //ハンディ持参区分
            assertEquals("listHandyJisanKbn" + i, rec.get("listHandyJisanKbn"));
            //仕向地設定
            assertEquals("listGoshaCd" + i, rec.get("listGoshaCd"));
            //適用名
            assertEquals("listTekiyoMei" + i, rec.get("listTekiyoMei"));
            //営業所コード
            assertEquals("listEigyoshoCd" + i, rec.get("listEigyoshoCd"));
            i++;
        }
    }
    

    private void assertForRecList_2_3(Mst471Form form) {
        int i = 0;
        assertEquals(0, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            //号車コード
            assertEquals("listGoshaCd" + i, rec.get("listGoshaCd"));
            //号車名
            assertEquals("listGoshaMei" + i, rec.get("listGoshaMei"));
            //適用開始日
            assertEquals("listTekiyoKaishiBi" + i, rec.get("listTekiyoKaishiBi"));
            //適用終了日
            assertEquals("listTekiyoShuryoBiChk" + i, rec.get("listTekiyoShuryoBiChk"));
            //車両No
            assertEquals("listSharyoNo" + i, rec.get("listSharyoNo"));
            //車両名
            assertEquals("listSharyoMei" + i, rec.get("listSharyoMei"));
            //ドライバーコード
            assertEquals("listDriverCd" + i, rec.get("listDriverCd"));
            //ドライバー名
            assertEquals("listDriverMei" + i, rec.get("listDriverMei"));
            //開始住所JISコード
            assertEquals("listKaishiJisCd" + i, rec.get("listKaishiJisCd"));
            //ハンディ持参区分
            assertEquals("listHandyJisanKbn" + i, rec.get("listHandyJisanKbn"));
            //仕向地設定
            assertEquals("listGoshaCd" + i, rec.get("listGoshaCd"));
            //適用名
            assertEquals("listTekiyoMei" + i, rec.get("listTekiyoMei"));
            //営業所コード
            assertEquals("listEigyoshoCd" + i, rec.get("listEigyoshoCd"));
            i++;
        }
    }
    private Map<String, Object> createRecMapFor_24_1(int i) {
        Map recMap = new HashMap();
        //号車コード
        recMap.put("listGoshaCd", "listGoshaCd" + i);
        //号車名
        recMap.put("listGoshaMei", "listGoshaMei" + i);
        //適用開始日
        recMap.put("listTekiyoKaishiBi", "2019/01/02");
        //適用終了日
        recMap.put("listTekiyoShuryoBiTextTab", "listTekiyoShuryoBiTextTab" + i);
        //車両No
        recMap.put("listSharyoNo", "listSharyoNo" + i);
        //車両名
        recMap.put("listSharyoMei", "listSharyoMei" + i);
        //ドライバーコード
        recMap.put("listDriverCd", "listDriverCd"+ i);
        //ドライバー名
        recMap.put("listDriverMei", "listDriverMei"+ i);
        //開始住所JISコード
        recMap.put("listKaishiJushoJisCd1", "listKaishiJushoJisCd1"+ i);
        //開始住所
        recMap.put("listKaishiJusho", "listKaishiJusho"+ i);
        //終了住所JISコード
        recMap.put("listShuryoJushoJisCd1", "listShuryoJushoJisCd1"+ i);
        //終了住所
        recMap.put("listShuryoJusho", "listShuryoJusho"+ i);
        //ハンディ持参区分
        recMap.put("listHandyJisanKbn", "listHandyJisanKbn"+ i);
        //仕向地設定
        recMap.put("listShimukechiSetteiKensu", "listShimukechiSetteiKensu"+ i);
        //適用名
        recMap.put("listTekiyoMei", "listTekiyoMei"+ i);
        //営業所コード
        recMap.put("listEigyoshoCd", "listEigyoshoCd"+ i);
        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }
    
    private void createRecMapFor_24_2(Mst471Form form) {
        int i = 0;
        assertEquals(1, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            //号車コード
            assertEquals("listGoshaCd" + i, rec.get("listGoshaCd"));
            //号車名
            assertEquals("listGoshaMei" + i, rec.get("listGoshaMei"));
            //適用開始日
            assertEquals("2019/01/02", rec.get("listTekiyoKaishiBi"));
            //適用終了日
            assertEquals("listTekiyoShuryoBiTextTab" + i, rec.get("listTekiyoShuryoBiTextTab"));
            //車両No
            assertEquals("listSharyoNo" + i, rec.get("listSharyoNo"));
            //車両名
            assertEquals("listSharyoMei" + i, rec.get("listSharyoMei" ));
            //ドライバーコード
            assertEquals("listDriverCd" + i, rec.get("listDriverCd"));
            //ドライバー名
            assertEquals("listDriverMei" + i, rec.get("listDriverMei"));
            //開始住所JISコード
            assertEquals("listKaishiJushoJisCd1" + i, rec.get("listKaishiJushoJisCd1"));
            //開始住所
            assertEquals("listKaishiJusho" + i, rec.get("listKaishiJusho"));
            //終了住所JISコード
            assertEquals("listShuryoJushoJisCd1" + i, rec.get("listShuryoJushoJisCd1"));
            //終了住所
            assertEquals("listShuryoJusho" + i, rec.get("listShuryoJusho"));
            //ハンディ持参区分
            assertEquals("listHandyJisanKbn" + i, rec.get("listHandyJisanKbn"));
            //仕向地設定
            assertEquals("listShimukechiSetteiKensu" + i, rec.get("listShimukechiSetteiKensu"));
            //適用名
            assertEquals("listTekiyoMei" + i, rec.get("listTekiyoMei"));
            //営業所コード
            assertEquals("listEigyoshoCd" + i, rec.get("listEigyoshoCd"));
            i++;
        }
    }
    
    private Map<String, Object> createRecMapFor_29_1(int i) {
        Map recMap = new HashMap();
        //号車コード
        recMap.put("listGoshaCd", "listGoshaCd" + i);
        //号車名
        recMap.put("listGoshaMei", "listGoshaMei" + i);
        //適用開始日
        recMap.put("listTekiyoKaishiBi", "2019/01/01");
        //適用終了日
        recMap.put("listTekiyoShuryoBiChk", "true");
        //適用終了日
        recMap.put("listTekiyoShuryoBiText", "Wed Jan 02 00:00:00 CST 2019");
        //車両No
        recMap.put("listSharyoNo", "listSharyoNo" + i);
        //車両名
        recMap.put("listSharyoMei", "listSharyoMei" + i);
        //ドライバーコード
        recMap.put("listDriverCd", "listDriverCd"+ i);
        //ドライバー名
        recMap.put("listDriverMei", "listDriverMei"+ i);
        //開始住所JISコード
        recMap.put("listKaishiJisCd", "listKaishiJisCd"+ i);
        //ハンディ持参区分
        recMap.put("listHandyJisanKbn", "listHandyJisanKbn"+ i);
        //仕向地設定
        recMap.put("listGoshaCd", "listGoshaCd"+ i);
        //適用名
        recMap.put("listTekiyoMei", "listTekiyoMei"+ i);
        //営業所コード
        recMap.put("listEigyoshoCd", "listEigyoshoCd"+ i);
        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }
    
    private Map<String, Object> createRecMapFor_30_1(int i) {
        Map recMap = new HashMap();
        //号車コード
        recMap.put("listGoshaCd", "listGoshaCd" + i);
        //号車名
        recMap.put("listGoshaMei", "listGoshaMei" + i);
        //適用開始日
        recMap.put("listTekiyoKaishiBi", "2019-01-01 00:00:00.0");
        //適用終了日
        recMap.put("listTekiyoShuryoBiChk", "Wed Jan 02 00:00:00 CST 2019");
        //適用終了日
        recMap.put("listTekiyoShuryoBiText", "Wed Jan 02 00:00:00 CST 2019");
        //車両No
        recMap.put("listSharyoNo", "listSharyoNo" + i);
        //車両名
        recMap.put("listSharyoMei", "listSharyoMei" + i);
        //ドライバーコード
        recMap.put("listDriverCd", "listDriverCd"+ i);
        //ドライバー名
        recMap.put("listDriverMei", "listDriverMei"+ i);
        //開始住所JISコード
        recMap.put("listKaishiJisCd", "listKaishiJisCd"+ i);
        //ハンディ持参区分
        recMap.put("listHandyJisanKbn", "listHandyJisanKbn"+ i);
        //仕向地設定
        recMap.put("listGoshaCd", "listGoshaCd"+ i);
        //適用名
        recMap.put("listTekiyoMei", "listTekiyoMei"+ i);
        //営業所コード
        recMap.put("listEigyoshoCd", "listEigyoshoCd"+ i);
        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }
    
    //@Test
    public void test_getSetUrl() throws IllegalAccessException, InvocationTargetException {
        String url = target.getUrl();
        target.setUrl(url);

        //String title = target.getTITLE();

        assertEquals(url, target.getUrl());
    }

}
