package jp.co.kintetsuls.beans.mst;

import java.io.IOException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.forms.mst.Mst092Form;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.utils.FlashUtil;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * 仕入予定詳細画面
 *
 * @author 廖鈺 (MBP)
 * @version 2019/3/29 新規作成
 */
public class Mst092BeanTest {

    // テストTarget
    @InjectMocks
    private Mst092Bean target;

    // Mockitoオブジェクト
    @Mock
    private AutoCompleteViewBean autoCompleteViewBean;
    @Mock
    private MasterInfoBean masterInfo;
    @Mock
    private MessagePropertyBean messageProperty;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosai;
    @Mock
    private AuthorityConfBean authConfBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private MessagePropertyBean messagePropertyBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosaiBean;
    @Mock
    private FlashUtil flashUtil;
    @Mock
    private BaseBean baseBean;

    public Mst092BeanTest() {
    }

    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() {
    }

    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[not null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst092Form mst092Form = new Mst092Form();

        //前画面情報[not null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst092Form);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());

        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索結果一覧取得 件数 = 1
        Map<String, String> result = new HashMap();
        result = createRecMapFor_1(0);
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        // テスト実行
        Mst092Form form = new Mst092Form();
        target.setMst092Form(form);
        // 戻ってきた場合、再検索を実施する。
        target.init("", "MST031_SCREEN", true);

        // 実施結果Outを取得
        form = target.getMst092Form();
        String title = target.getTITLE();
        String url = target.getUrl();
        BreadCrumbBean breadBean = target.getBreadBean();
        AutoCompleteViewBean autoCompleteViewBean = target.getAutoCompleteViewBean();
        RirekiSyosaiBean rirekiSyosai = target.getRirekiSyosai();
        AuthorityConfBean authorityConfBean = target.getAuthorityConfBean();
        MessagePropertyBean messagePropertyBean = target.getMessagePropertyBean();
        PageCommonBean pageCommonBean = target.getPageCommonBean();
        List<MessageModuleBean> msgList = target.getMsgList();
        target.setUrl(url);
        target.setBreadBean(breadBean);
        target.setAutoCompleteViewBean(autoCompleteViewBean);
        target.setAuthorityConfBean(authorityConfBean);
        target.setMessagePropertyBean(messagePropertyBean);
        target.setPageCommonBean(pageCommonBean);
        target.setMsgList(msgList);

        // 実行時に渡すパラメータの検証
        assertEquals("mst092Form", keyCaptor_1.getValue());
        // 想定通りに再検索を実施する。
        assertEquals("search_mst092", keyCaptor_2.getValue());
    }

    // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[ 営業所コード = "001"仕入先コード = "FC008"
    // 仕入区分 = "輸送機材" 適用開始日 = "2019/01/01"  
    // 適用名 = "適用名 1" 適用終了 =  null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2() throws IllegalAccessException, InvocationTargetException,
            InstantiationException, ParseException {
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 0; i++) {
            result.add(createRecMapFor_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // Mockitoオブジェクトの予想return値設定
        Mst092Form mst092Form = new Mst092Form();

        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        mst092Form.setConEigyoshoCd(conEigyoshoCd);
        mst092Form.setConShiireKbn(conShiireKbn);
        mst092Form.setConShiiresakiCd(conShiiresakiCd);
        mst092Form.setConTekiyoKaishibi(conTekiyoKaishibi);
        mst092Form.setConTekiyoMei("適用名1");
        mst092Form.setConTekiyoShuryo(null);
        // Mockitoオブジェクトの予想return値設定
        Flash flash = new FlashKls();

        flash.put("mst092Form", mst092Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());

        // テスト実行
        Mst092Form form = new Mst092Form();
        target.setMst092Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID", "", false);

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 想定通りに再検索を実施する。
        assertEquals("search_mst092", keyCaptor_2.getValue());
        assertEquals("001", form.getConEigyoshoCd().getValue());
        assertEquals("FC008", form.getConShiiresakiCd().getValue());
        assertEquals("1002", form.getConShiireKbn().getValue());
        assertEquals("適用名1", form.getConTekiyoMei());
        assertEquals("2019-01-01", form.getConTekiyoKaishibi());
        assertEquals(null, form.getConTekiyoShuryo());
    }

    // init_正常_初期処理_1-2_1
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2_1() throws IllegalAccessException, InvocationTargetException,
            InstantiationException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        doThrow(IOException.class).when(pageCommonBean).getDBInfo(paramsCaptor_1.capture(),
                functionCodeCaptor_2.capture());
        // Mockitoオブジェクトの予想return値設定
        Mst092Form mst092Form = new Mst092Form();

        // 前回検索パラメータ
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        mst092Form.setConEigyoshoCd(conEigyoshoCd);
        mst092Form.setConShiireKbn(conShiireKbn);
        mst092Form.setConShiiresakiCd(conShiiresakiCd);
        mst092Form.setConTekiyoKaishibi(conTekiyoKaishibi);
        mst092Form.setConTekiyoMei("適用名1");
        mst092Form.setConTekiyoShuryo(null);

        Flash flash = new FlashKls();
        // 前画面パラメータ
        flash.put("mst501Form", null);
        when(pageCommonBean.getPageParam()).thenReturn(flash);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());

        // テスト実行
        Mst092Form form = new Mst092Form();
        target.setMst092Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID", "", false);

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 想定通りに再検索を実施する。
        assertEquals(null, form.getConTekiyoShuryo());
    }

    // init_正常_初期処理_1-3
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        // 前画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(null);

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 0; i++) {
            result.add(createRecMapFor_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        // テスト実行
        Mst092Form form = new Mst092Form();
        target.setMst092Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID", "", false);

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst092Form", keyCaptor_1.getValue());
        // 想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null, form.getSearchResult());
    }

    // init_正常_初期処理_1-3_1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 0; i++) {
            result.add(createRecMapFor_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        // 前画面情報[null]
        doThrow(IllegalAccessException.class).when(pageCommonBean).getPageInfo(keyCaptor_1.capture());

        // テスト実行
        Mst092Form form = new Mst092Form();
        target.setMst092Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID", "", false);

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst092Form", keyCaptor_1.getValue());
        // 想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null, form.getSearchResult());
    }

    // search_正常_検索処理_2-1
    //
    // -------------------テスト条件--------------------------
    // 仕入予定検索結果一覧取得 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_1() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 0; i++) {
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        // テスト実行
        Mst092Form form = new Mst092Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        target.setMst092Form(form);
        target.search();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 実行時に渡すパラメータの検証
        assertEquals("001", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("1002", paramsCaptor_1.getValue().get("conShiireKbn"));
        assertEquals("FC008", paramsCaptor_1.getValue().get("conShiiresakiCd"));
        assertEquals("2019-01-01", paramsCaptor_1.getValue().get("conTekiyoKaishibi"));
        assertEquals("適用名1", paramsCaptor_1.getValue().get("conTekiyoMei"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoShuryo"));
        assertEquals("mst092_search_shiire_yotei_meisai", functionCodeCaptor_2.getValue());
    }

    // search_異常_検索処理_2-2
    //
    // -------------------テスト条件--------------------------
    // 仕入予定検索結果一覧取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_2() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索結果一覧取得 取得件数 = 2
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            result.add(createRecMapFor_1_2(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mst092Form form = new Mst092Form();
        form.setSearchResult(result);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        target.setMst092Form(form);

        target.search();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 想定通りに一覧を表示されること
        assertForRecList_2_2(form);
    }

    // search_正常_検索処理_2-3
    //
    // -------------------テスト条件--------------------------
    // 仕入予定検索結果一覧取得 取得件数 = 0
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_3() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得 取得件数 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mst092Form form = new Mst092Form();
        form.setSearchResult(result);
        target.setMst092Form(form);
        target.search();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 想定通りに ・ファンクションボタンは表示（検索前と同じ） 
        assertForRecList_2_3(form);
    }

    // search_異常_検索処理_2_3_2
    //
    // -------------------テスト条件--------------------------
    // 仕入予定検索結果一覧取得
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_3_1() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        doThrow(IOException.class).when(pageCommonBean).getDBInfo(paramsCaptor_1.capture(),
                functionCodeCaptor_2.capture());
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mst092Form form = new Mst092Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        target.setMst092Form(form);
        target.search();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 実行時に渡すパラメータの検証
        assertEquals("001", paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals("1002", paramsCaptor_1.getValue().get("conShiireKbn"));
        assertEquals("FC008", paramsCaptor_1.getValue().get("conShiiresakiCd"));
        assertEquals("2019-01-01", paramsCaptor_1.getValue().get("conTekiyoKaishibi"));
        assertEquals("適用名1", paramsCaptor_1.getValue().get("conTekiyoMei"));
        assertEquals(null, paramsCaptor_1.getValue().get("ConTekiyoShuryo1"));
        assertEquals("mst092_search_shiire_yotei_meisai", functionCodeCaptor_2.getValue());
    }

    // getTekiyoKaishibi_正常_適用開始日ENTERキー押下_12_1
    //
    // -------------------テスト条件--------------------------
    //  特になし
    // -----------------------------------------------------
    @Test
    public void getTekiyoKaishibi_正常_適用開始日ENTERキー押下_12_1() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得 取得件数 = 0
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 0; i++) {
            result.add(createRecMapFor_13_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // テスト実行
        Mst092Form form = new Mst092Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(null);
        target.setMst092Form(form);
        target.getTekiyoKaishibi();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 実行時に渡すパラメータの検証
        assertEquals("001", form.getConEigyoshoCd().getValue());
        assertEquals("1002", form.getConShiireKbn().getValue());
        assertEquals("FC008", form.getConShiiresakiCd().getValue());
        assertEquals("2019/01/01", form.getConTekiyoKaishibi());
    }
    
    // getTekiyoKaishibi_正常_適用開始日ENTERキー押下_12_1_1
    //
    // -------------------テスト条件--------------------------
    //  特になし
    // -----------------------------------------------------
    @Test
    public void getTekiyoKaishibi_正常_適用開始日ENTERキー押下_12_1_1() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得 取得件数 = 0
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 0; i++) {
            result.add(createRecMapFor_13_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // テスト実行
        Mst092Form form = new Mst092Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi("2019/01/01");
        target.setMst092Form(form);
        target.getTekiyoKaishibi();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 実行時に渡すパラメータの検証
        assertEquals("001", form.getConEigyoshoCd().getValue());
        assertEquals("1002", form.getConShiireKbn().getValue());
        assertEquals("FC008", form.getConShiiresakiCd().getValue());
        assertEquals("2019/01/01", form.getConTekiyoKaishibi());
    }

    // getTekiyoKaishibi_正常_適用開始日ENTERキー押下_12_1_2
    //
    // -------------------テスト条件--------------------------
    //  特になし
    // -----------------------------------------------------
    @Test
    public void getTekiyoKaishibi_異常_適用開始日ENTERキー押下_12_1_2() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();

        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 0; i++) {
            result.add(createRecMapFor_13_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));

        doThrow(IOException.class).when(pageCommonBean).getDBInfo(paramsCaptor_1.capture(),
                functionCodeCaptor_2.capture());

        // テスト実行
        Mst092Form form = new Mst092Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        target.setMst092Form(form);
        target.getTekiyoKaishibi();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 実行時に渡すパラメータの検証
        assertEquals("001", form.getConEigyoshoCd().getValue());
        assertEquals("1002", form.getConShiireKbn().getValue());
        assertEquals("FC008", form.getConShiiresakiCd().getValue());
    }

    // taniChange_正常_件数取得処理_13_1
    //
    // -------------------テスト条件--------------------------
    //  単位変更月
    // -----------------------------------------------------
    @Test
    public void taniChange_正常_単位変更_13_1() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);

        // テスト実行
        Mst092Form form = new Mst092Form();
        form.setConTani("1");
        target.setMst092Form(form);
        target.taniChange();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 実行時に渡すパラメータの検証
        assertEquals(true, form.getShiireYoteiMeisaiRendered());
        assertEquals(false, form.getShiireYoteiRendered());
        assertEquals("1", form.getConTani());
    }

    // taniChange_正常_単位変更_13_1_1
    //
    // -------------------テスト条件--------------------------
    //  単位変更月
    // -----------------------------------------------------
    @Test
    public void taniChange_正常_単位変更_13_1_1() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);

        // テスト実行
        Mst092Form form = new Mst092Form();
        form.setConTani("3");
        target.setMst092Form(form);
        target.taniChange();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 実行時に渡すパラメータの検証
        assertEquals(true, form.getShiireYoteiMeisaiRendered());
        assertEquals(false, form.getShiireYoteiRendered());
        assertEquals("3", form.getConTani());
    }

    // taniChange_正常_単位変更_14_1_1
    //
    // -------------------テスト条件--------------------------
    //  単位変更日(曜日)
    // -----------------------------------------------------
    @Test
    public void taniChange_正常_単位変更_13_2() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);

        // テスト実行
        Mst092Form form = new Mst092Form();
        form.setConTani("2");
        target.setMst092Form(form);
        target.taniChange();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 実行時に渡すパラメータの検証
        assertEquals(false, form.getShiireYoteiMeisaiRendered());
        assertEquals(true, form.getShiireYoteiRendered());
        assertEquals("2", form.getConTani());
    }

    // taniChange_正常_単位変更_14_3
    //
    // -------------------テスト条件--------------------------
    //  単位変更未選択
    // -----------------------------------------------------
    @Test
    public void taniChange_正常_単位変更_13_3() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);

        // テスト実行
        Mst092Form form = new Mst092Form();
        target.setMst092Form(form);
        target.taniChange();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 実行時に渡すパラメータの検証
        assertEquals(false, form.getShiireYoteiMeisaiRendered());
        assertEquals(false, form.getShiireYoteiRendered());
        assertEquals(null, form.getConTani());
    }

    // calBtnClick_正常_金額計算処理_14_1
    //
    // -------------------テスト条件--------------------------
    //  特になし
    // -----------------------------------------------------
    @Test
    public void calBtnClick_正常_金額計算処理_14_1() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);

        List<Map<String, Object>> result = new ArrayList<>();
        Map<String, String> calResult = new HashMap();
        for (int i = 0; i <= 0; i++) {
            result.add(createRecMapFor_14_1(i));
        }
        calResult = createRecMapFor_14_1_1(0);
        // テスト実行
        Mst092Form form = new Mst092Form();
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(result));
        form.setCalSearchResult(calResult);
        form.setZeiRitsuResult(createRecMapFor_14_1_2());
                form.getSearchResultMsShiireYotelMeisai().setPageSize(2);
        form.getSearchResultMsShiireYotelMeisai().setRowIndex(0);
        form.getSearchResultMsShiireYotelMeisai().setRowCount(1);
        target.setMst092Form(form);
        target.calBtnClick();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 実行時に渡すパラメータの検証
        assertEquals(false, form.getShiireYoteiMeisaiRendered());
        assertEquals(false, form.getShiireYoteiRendered());
        assertEquals(null, form.getConTani());
    }

    // calBtnClick_正常_金額計算処理_14_2
    //
    // -------------------テスト条件--------------------------
    //  特になし
    // -----------------------------------------------------
    @Test
    public void calBtnClick_正常_金額計算処理_14_2() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);

        List<Map<String, Object>> result = new ArrayList<>();
        Map<String, String> calResult = new HashMap();
        for (int i = 0; i <= 0; i++) {
            result.add(createRecMapFor_14_2(i));
        }
        calResult = createRecMapFor_14_1_3(0);
        // テスト実行
        Mst092Form form = new Mst092Form();
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(result));
        form.setCalSearchResult(calResult);
        form.setZeiRitsuResult(createRecMapFor_14_1_2());
        form.getSearchResultMsShiireYotelMeisai().setPageSize(2);
        form.getSearchResultMsShiireYotelMeisai().setRowIndex(0);
        form.getSearchResultMsShiireYotelMeisai().setRowCount(2);
        form.getSearchResultMsShiireYotelMeisai().setDatasource(result);
        target.setMst092Form(form);
        target.calBtnClick();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 実行時に渡すパラメータの検証
        assertEquals(false, form.getShiireYoteiMeisaiRendered());
        assertEquals(false, form.getShiireYoteiRendered());
        assertEquals(null, form.getConTani());
    }
    
    // calBtnClick_正常_金額計算処理_14_2_1
    //
    // -------------------テスト条件--------------------------
    //  特になし
    // -----------------------------------------------------
    @Test
    public void calBtnClick_正常_金額計算処理_14_2_1() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);

        List<Map<String, Object>> result = new ArrayList<>();
        Map<String, String> calResult = new HashMap();
        for (int i = 0; i <= 0; i++) {
            result.add(createRecMapFor_14_2(i));
        }
        calResult = createRecMapFor_14_1_4();
        // テスト実行
        Mst092Form form = new Mst092Form();
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(result));
        form.setCalSearchResult(calResult);
        form.setZeiRitsuResult(createRecMapFor_14_1_2());
        form.getSearchResultMsShiireYotelMeisai().setPageSize(2);
        form.getSearchResultMsShiireYotelMeisai().setRowIndex(0);
        form.getSearchResultMsShiireYotelMeisai().setRowCount(2);
        form.getSearchResultMsShiireYotelMeisai().setDatasource(result);
        target.setMst092Form(form);
        target.calBtnClick();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 実行時に渡すパラメータの検証
        assertEquals(false, form.getShiireYoteiMeisaiRendered());
        assertEquals(false, form.getShiireYoteiRendered());
        assertEquals(null, form.getConTani());
    }
    
    // calBtnClick_正常_金額計算処理_14_2
    //
    // -------------------テスト条件--------------------------
    //  特になし
    // -----------------------------------------------------
    @Test
    public void calBtnClick_正常_金額計算処理_14_2_2() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);

        List<Map<String, Object>> result = new ArrayList<>();
        Map<String, String> calResult = new HashMap();
        for (int i = 0; i <= 0; i++) {
            result.add(createRecMapFor_14_2(i));
        }
        calResult = createRecMapFor_14_1_5();
        // テスト実行
        Mst092Form form = new Mst092Form();
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(result));
        form.setCalSearchResult(calResult);
        form.setZeiRitsuResult(createRecMapFor_14_1_2());
        form.getSearchResultMsShiireYotelMeisai().setPageSize(2);
        form.getSearchResultMsShiireYotelMeisai().setRowIndex(0);
        form.getSearchResultMsShiireYotelMeisai().setRowCount(2);
        form.getSearchResultMsShiireYotelMeisai().setDatasource(result);
        target.setMst092Form(form);
        target.calBtnClick();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 実行時に渡すパラメータの検証
        assertEquals(false, form.getShiireYoteiMeisaiRendered());
        assertEquals(false, form.getShiireYoteiRendered());
        assertEquals(null, form.getConTani());
    }
    
        // calBtnClick_正常_金額計算処理_14_2
    //
    // -------------------テスト条件--------------------------
    //  特になし
    // -----------------------------------------------------
    @Test
    public void calBtnClick_正常_金額計算処理_14_2_3() throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);

        List<Map<String, Object>> result = new ArrayList<>();
        Map<String, String> calResult = new HashMap();
        for (int i = 0; i <= 0; i++) {
            result.add(createRecMapFor_14_2(i));
        }
        calResult = createRecMapFor_14_1_1(0);
        // テスト実行
        Mst092Form form = new Mst092Form();
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(result));
        form.setCalSearchResult(calResult);
        form.setZeiRitsuResult(createRecMapFor_14_1_6());
        form.getSearchResultMsShiireYotelMeisai().setPageSize(2);
        form.getSearchResultMsShiireYotelMeisai().setRowIndex(0);
        form.getSearchResultMsShiireYotelMeisai().setRowCount(2);
        form.getSearchResultMsShiireYotelMeisai().setDatasource(result);
        target.setMst092Form(form);
        target.calBtnClick();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 実行時に渡すパラメータの検証
        assertEquals(false, form.getShiireYoteiMeisaiRendered());
        assertEquals(false, form.getShiireYoteiRendered());
        assertEquals(null, form.getConTani());
    }

    // insertOrUpdate_正常_更新処理_15_1
    //
    // -------------------テスト条件--------------------------
    // 登録処理を行う
    // -----------------------------------------------------
    @Test
    public void insertOrUpdate_正常_更新処理_15_1() throws IllegalAccessException,
            InvocationTargetException, ParseException {

              // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture());
        // テスト実行
        Mst092Form form = new Mst092Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        form.setConTani("1");
        form.setConTanka("1000000");
        form.setListYobibetuShiiregakuGetuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKayo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuSuiyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuMokuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKinyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuDoyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuNichiSuku(new BigDecimal("100"));

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
        target.setMst092Form(form);
        target.insertOrUpdate();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること削除処理を行う。
        assertEquals("INFO", levelCaptor_3.getValue());
        assertEquals("COMI0011", summaryCaptor_4.getValue());
        assertEquals("登録", detailCaptor_5.getValue());

    }
    
    // insertOrUpdate_異常_更新処理_15_1_1
    //
    // -------------------テスト条件--------------------------
    // 登録処理を行う
    // -----------------------------------------------------
    @Test
    public void insertOrUpdate_異常_更新処理_15_1_1() throws IllegalAccessException,
            InvocationTargetException, ParseException {

         // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0043",
                "仕入予定データ");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture());
        // テスト実行
        Mst092Form form = new Mst092Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        form.setConTani("1");
        form.setConTanka("1000000");
        form.setListYobibetuShiiregakuGetuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKayo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuSuiyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuMokuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKinyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuDoyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuNichiSuku(new BigDecimal("100"));

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
        target.setMst092Form(form);
        target.insertOrUpdate();

        // 実施結果Outを取得
        form = target.getMst092Form();

    }
    
    // insertOrUpdate_異常_更新処理_15_1_2
    //
    // -------------------テスト条件--------------------------
    // 登録処理を行う
    // -----------------------------------------------------
    @Test
    public void insertOrUpdate_異常_更新処理_15_1_2() throws IllegalAccessException,
            InvocationTargetException, ParseException {

         // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
       ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        serviceInterfaceBean2.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean, serviceInterfaceBean2);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture());
        // テスト実行
        Mst092Form form = new Mst092Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        form.setConTani("1");
        form.setConTanka("1000000");
        form.setListYobibetuShiiregakuGetuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKayo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuSuiyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuMokuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKinyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuDoyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuNichiSuku(new BigDecimal("100"));

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
        target.setMst092Form(form);
        target.insertOrUpdate();

        // 実施結果Outを取得
        form = target.getMst092Form();

    }

    // insertOrUpdate_正常_更新処理_15_2
    //
    // -------------------テスト条件--------------------------
    // 登録処理を行う
    // -----------------------------------------------------
    @Test
    public void insertOrUpdate_正常_更新処理_15_2() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture());
        // テスト実行
        Mst092Form form = new Mst092Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        form.setConTani("1");
        form.setConTanka("1000000");
        form.setListTekiyoShuryobi(conTekiyoKaishibi);
        form.setListYobibetuShiiregakuGetuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKayo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuSuiyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuMokuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKinyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuDoyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuNichiSuku(new BigDecimal("100"));

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
        target.setMst092Form(form);
        target.insertOrUpdate();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること削除処理を行う。
        assertEquals("INFO", levelCaptor_3.getValue());
        assertEquals("COMI0011", summaryCaptor_4.getValue());
        assertEquals("更新", detailCaptor_5.getValue());
    }
    
    // insertOrUpdate_異常_更新処理_15_2_1
    //
    // -------------------テスト条件--------------------------
    // 登録処理を行う
    // -----------------------------------------------------
    @Test
    public void insertOrUpdate_異常_更新処理_15_2_1() throws IllegalAccessException,
            InvocationTargetException, ParseException {

         // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0043",
                "仕入予定データ");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture());
        // テスト実行
        Mst092Form form = new Mst092Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        form.setConTani("1");
        form.setConTanka("1000000");
        form.setListYobibetuShiiregakuGetuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKayo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuSuiyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuMokuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKinyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuDoyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuNichiSuku(new BigDecimal("100"));

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
        target.setMst092Form(form);
        target.insertOrUpdate();

        // 実施結果Outを取得
        form = target.getMst092Form();

    }
    
    // insertOrUpdate_異常_更新処理_15_2_2
    //
    // -------------------テスト条件--------------------------
    // 登録処理を行う
    // -----------------------------------------------------
    @Test
    public void insertOrUpdate_異常_更新処理_15_2_2() throws IllegalAccessException,
            InvocationTargetException, ParseException {

         // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
       ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        serviceInterfaceBean2.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0014",
                "仕入予定データ");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean, serviceInterfaceBean2);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture());
        // テスト実行
        Mst092Form form = new Mst092Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        form.setConTani("1");
        form.setConTanka("1000000");
        form.setListYobibetuShiiregakuGetuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKayo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuSuiyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuMokuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKinyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuDoyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuNichiSuku(new BigDecimal("100"));

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
        target.setMst092Form(form);
        target.insertOrUpdate();

        // 実施結果Outを取得
        form = target.getMst092Form();

    }
    
    // insertOrUpdate_正常_更新処理_15_2
    //
    // -------------------テスト条件--------------------------
    // 登録処理を行う
    // -----------------------------------------------------
    @Test
    public void insertOrUpdate_正常_更新処理_15_2_3() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture());
        // テスト実行
        Mst092Form form = new Mst092Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        form.setConTani("1");
        form.setConTanka("1000000");

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1_1(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        target.setMst092Form(form);
        target.insertOrUpdate();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 想定通り
        assertEquals("001", form.getConEigyoshoCd().getValue());
        assertEquals("1002", form.getConShiireKbn().getValue());
        assertEquals("FC008", form.getConShiiresakiCd().getValue());
        assertEquals("1", form.getConTani());

    }
    
    // insertOrUpdate_異常_更新処理_15_3
    //
    // -------------------テスト条件--------------------------
    // 登録処理を行う
    // -----------------------------------------------------
    @Test
    public void insertOrUpdate_異常_更新処理_15_3() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture());
        // テスト実行
        Mst092Form form = new Mst092Form();

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
        
        target.setMst092Form(form);
        target.insertOrUpdate();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること削除処理を行う。
        assertEquals(null, form.getConEigyoshoCd());
        assertEquals(null, form.getConShiireKbn());
        assertEquals(null, form.getConShiiresakiCd());
        assertEquals(null, form.getConTani());
    }
    
    // insertOrUpdate_異常_更新処理_15_4
    //
    // -------------------テスト条件--------------------------
    // 登録処理を行う
    // -----------------------------------------------------
    @Test
    public void insertOrUpdate_異常_更新処理_15_4() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // テスト実行
        Mst092Form form = new Mst092Form();

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
                AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        form.setConTani("1");
        form.setConTanka("1000000");
        form.setListYobibetuShiiregakuGetuyo(null);
        target.setMst092Form(form);
        target.insertOrUpdate();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 想定通り
        assertEquals("001", form.getConEigyoshoCd().getValue());
        assertEquals("1002", form.getConShiireKbn().getValue());
        assertEquals("FC008", form.getConShiiresakiCd().getValue());
        assertEquals("1", form.getConTani());
    }
    
        // insertOrUpdate_異常_更新処理_15_4
    //
    // -------------------テスト条件--------------------------
    // 登録処理を行う
    // -----------------------------------------------------
    @Test
    public void insertOrUpdate_異常_更新処理_15_4_1() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // テスト実行
        Mst092Form form = new Mst092Form();

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
                AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        form.setConTani("1");
        form.setConTanka("1000000");
        form.setListYobibetuShiiregakuGetuyo(new BigDecimal("-10"));
        target.setMst092Form(form);
        target.insertOrUpdate();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること削除処理を行う。
        assertEquals("001", form.getConEigyoshoCd().getValue());
        assertEquals("1002", form.getConShiireKbn().getValue());
        assertEquals("FC008", form.getConShiiresakiCd().getValue());
        assertEquals("1", form.getConTani());
    }
    
        // insertOrUpdate_異常_更新処理_15_4
    //
    // -------------------テスト条件--------------------------
    // 登録処理を行う
    // -----------------------------------------------------
    @Test
    public void insertOrUpdate_異常_更新処理_15_4_2() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // テスト実行
        Mst092Form form = new Mst092Form();

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
                AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        form.setConTani("1");
        form.setConTanka("1000000");
        form.setListYobibetuShiiregakuGetuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKayo(null);
        target.setMst092Form(form);
        target.insertOrUpdate();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること削除処理を行う。
        assertEquals("001", form.getConEigyoshoCd().getValue());
        assertEquals("1002", form.getConShiireKbn().getValue());
        assertEquals("FC008", form.getConShiiresakiCd().getValue());
        assertEquals("1", form.getConTani());
    }
    
        // insertOrUpdate_異常_更新処理_15_4
    //
    // -------------------テスト条件--------------------------
    // 登録処理を行う
    // -----------------------------------------------------
    @Test
    public void insertOrUpdate_異常_更新処理_15_4_3() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // テスト実行
        Mst092Form form = new Mst092Form();

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
                AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        form.setConTani("1");
        form.setConTanka("1000000");
        form.setListYobibetuShiiregakuGetuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKayo(new BigDecimal("-10"));
        target.setMst092Form(form);
        target.insertOrUpdate();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること削除処理を行う。
        assertEquals("001", form.getConEigyoshoCd().getValue());
        assertEquals("1002", form.getConShiireKbn().getValue());
        assertEquals("FC008", form.getConShiiresakiCd().getValue());
        assertEquals("1", form.getConTani());
    }
    
        // insertOrUpdate_異常_更新処理_15_4
    //
    // -------------------テスト条件--------------------------
    // 登録処理を行う
    // -----------------------------------------------------
    @Test
    public void insertOrUpdate_異常_更新処理_15_4_4() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // テスト実行
        Mst092Form form = new Mst092Form();

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
                AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        form.setConTani("1");
        form.setConTanka("1000000");
        form.setListYobibetuShiiregakuGetuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKayo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuSuiyo(null);
        target.setMst092Form(form);
        target.insertOrUpdate();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること削除処理を行う。
        assertEquals("001", form.getConEigyoshoCd().getValue());
        assertEquals("1002", form.getConShiireKbn().getValue());
        assertEquals("FC008", form.getConShiiresakiCd().getValue());
        assertEquals("1", form.getConTani());
    }
    
    
        // insertOrUpdate_異常_更新処理_15_4
    //
    // -------------------テスト条件--------------------------
    // 登録処理を行う
    // -----------------------------------------------------
    @Test
    public void insertOrUpdate_異常_更新処理_15_4_5() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // テスト実行
        Mst092Form form = new Mst092Form();

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
                AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        form.setConTani("1");
        form.setConTanka("1000000");
        form.setListYobibetuShiiregakuGetuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKayo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuSuiyo(new BigDecimal("-10"));
        target.setMst092Form(form);
        target.insertOrUpdate();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること削除処理を行う。
        assertEquals("001", form.getConEigyoshoCd().getValue());
        assertEquals("1002", form.getConShiireKbn().getValue());
        assertEquals("FC008", form.getConShiiresakiCd().getValue());
        assertEquals("1", form.getConTani());
    }
    
        // insertOrUpdate_異常_更新処理_15_4
    //
    // -------------------テスト条件--------------------------
    // 登録処理を行う
    // -----------------------------------------------------
    @Test
    public void insertOrUpdate_異常_更新処理_15_4_6() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // テスト実行
        Mst092Form form = new Mst092Form();

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
                AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        form.setConTani("1");
        form.setConTanka("1000000");
        form.setListYobibetuShiiregakuGetuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKayo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuSuiyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuMokuyo(null);
        target.setMst092Form(form);
        target.insertOrUpdate();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること削除処理を行う。
        assertEquals("001", form.getConEigyoshoCd().getValue());
        assertEquals("1002", form.getConShiireKbn().getValue());
        assertEquals("FC008", form.getConShiiresakiCd().getValue());
        assertEquals("1", form.getConTani());
    }
    
        // insertOrUpdate_異常_更新処理_15_4
    //
    // -------------------テスト条件--------------------------
    // 登録処理を行う
    // -----------------------------------------------------
    @Test
    public void insertOrUpdate_異常_更新処理_15_4_7() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // テスト実行
        Mst092Form form = new Mst092Form();

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
                AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        form.setConTani("1");
        form.setConTanka("1000000");
        form.setListYobibetuShiiregakuGetuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKayo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuSuiyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuMokuyo(new BigDecimal("-10"));
        target.setMst092Form(form);
        target.insertOrUpdate();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること削除処理を行う。
        assertEquals("001", form.getConEigyoshoCd().getValue());
        assertEquals("1002", form.getConShiireKbn().getValue());
        assertEquals("FC008", form.getConShiiresakiCd().getValue());
        assertEquals("1", form.getConTani());
    }
    
        // insertOrUpdate_異常_更新処理_15_4
    //
    // -------------------テスト条件--------------------------
    // 登録処理を行う
    // -----------------------------------------------------
    @Test
    public void insertOrUpdate_異常_更新処理_15_4_8() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // テスト実行
        Mst092Form form = new Mst092Form();

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
                AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        form.setConTani("1");
        form.setConTanka("1000000");
        form.setListYobibetuShiiregakuGetuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKayo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuSuiyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuMokuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKinyo(null);
        target.setMst092Form(form);
        target.insertOrUpdate();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること削除処理を行う。
        assertEquals("001", form.getConEigyoshoCd().getValue());
        assertEquals("1002", form.getConShiireKbn().getValue());
        assertEquals("FC008", form.getConShiiresakiCd().getValue());
        assertEquals("1", form.getConTani());
    }
    
    // insertOrUpdate_異常_更新処理_15_4
    //
    // -------------------テスト条件--------------------------
    // 登録処理を行う
    // -----------------------------------------------------
    @Test
    public void insertOrUpdate_異常_更新処理_15_4_9() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // テスト実行
        Mst092Form form = new Mst092Form();

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
                AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        form.setConTani("1");
        form.setConTanka("1000000");
        form.setListYobibetuShiiregakuGetuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKayo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuSuiyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuMokuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKinyo(new BigDecimal("-10"));
        target.setMst092Form(form);
        target.insertOrUpdate();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること削除処理を行う。
        assertEquals("001", form.getConEigyoshoCd().getValue());
        assertEquals("1002", form.getConShiireKbn().getValue());
        assertEquals("FC008", form.getConShiiresakiCd().getValue());
        assertEquals("1", form.getConTani());
    }
    
    // insertOrUpdate_異常_更新処理_15_4
    //
    // -------------------テスト条件--------------------------
    // 登録処理を行う
    // -----------------------------------------------------
    @Test
    public void insertOrUpdate_異常_更新処理_15_4_10() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // テスト実行
        Mst092Form form = new Mst092Form();

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
                AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        form.setConTani("1");
        form.setConTanka("1000000");
        form.setListYobibetuShiiregakuGetuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKayo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuSuiyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuMokuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKinyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuDoyo(null);
        target.setMst092Form(form);
        target.insertOrUpdate();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること削除処理を行う。
        assertEquals("001", form.getConEigyoshoCd().getValue());
        assertEquals("1002", form.getConShiireKbn().getValue());
        assertEquals("FC008", form.getConShiiresakiCd().getValue());
        assertEquals("1", form.getConTani());
    }
    
    // insertOrUpdate_異常_更新処理_15_4
    //
    // -------------------テスト条件--------------------------
    // 登録処理を行う
    // -----------------------------------------------------
    @Test
    public void insertOrUpdate_異常_更新処理_15_4_11() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // テスト実行
        Mst092Form form = new Mst092Form();

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
                AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        form.setConTani("1");
        form.setConTanka("1000000");
        form.setListYobibetuShiiregakuGetuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKayo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuSuiyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuMokuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKinyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuDoyo(new BigDecimal("-10"));
        target.setMst092Form(form);
        target.insertOrUpdate();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること削除処理を行う。
        assertEquals("001", form.getConEigyoshoCd().getValue());
        assertEquals("1002", form.getConShiireKbn().getValue());
        assertEquals("FC008", form.getConShiiresakiCd().getValue());
        assertEquals("1", form.getConTani());
    }
    
    // insertOrUpdate_異常_更新処理_15_4
    //
    // -------------------テスト条件--------------------------
    // 登録処理を行う
    // -----------------------------------------------------
    @Test
    public void insertOrUpdate_異常_更新処理_15_4_12() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // テスト実行
        Mst092Form form = new Mst092Form();

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
                AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        form.setConTani("1");
        form.setConTanka("1000000");
        form.setListYobibetuShiiregakuGetuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKayo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuSuiyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuMokuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKinyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuDoyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuNichiSuku(null);
        target.setMst092Form(form);
        target.insertOrUpdate();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること削除処理を行う。
        assertEquals("001", form.getConEigyoshoCd().getValue());
        assertEquals("1002", form.getConShiireKbn().getValue());
        assertEquals("FC008", form.getConShiiresakiCd().getValue());
        assertEquals("1", form.getConTani());
    }
    
    // insertOrUpdate_異常_更新処理_15_4
    //
    // -------------------テスト条件--------------------------
    // 登録処理を行う
    // -----------------------------------------------------
    @Test
    public void insertOrUpdate_異常_更新処理_15_4_13() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // テスト実行
        Mst092Form form = new Mst092Form();

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
                AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        form.setConTani("1");
        form.setConTanka("1000000");
        form.setListYobibetuShiiregakuGetuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKayo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuSuiyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuMokuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKinyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuDoyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuNichiSuku(new BigDecimal("-10"));
        target.setMst092Form(form);
        target.insertOrUpdate();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること削除処理を行う。
        assertEquals("001", form.getConEigyoshoCd().getValue());
        assertEquals("1002", form.getConShiireKbn().getValue());
        assertEquals("FC008", form.getConShiiresakiCd().getValue());
        assertEquals("1", form.getConTani());
    }
    
        // insertOrUpdate_異常_更新処理_15_4
    //
    // -------------------テスト条件--------------------------
    // 登録処理を行う
    // -----------------------------------------------------
    @Test
    public void insertOrUpdate_異常_更新処理_15_4_14() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // テスト実行
        Mst092Form form = new Mst092Form();

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2_1(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
                AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        form.setConTani("1");
        form.setConTanka("1000000");
        form.setListYobibetuShiiregakuGetuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKayo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuSuiyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuMokuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKinyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuDoyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuNichiSuku(new BigDecimal("100"));
        target.setMst092Form(form);
        target.insertOrUpdate();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること削除処理を行う。
        assertEquals("001", form.getConEigyoshoCd().getValue());
        assertEquals("1002", form.getConShiireKbn().getValue());
        assertEquals("FC008", form.getConShiiresakiCd().getValue());
        assertEquals("1", form.getConTani());
    }
    
        // insertOrUpdate_異常_更新処理_15_4_15
    //
    // -------------------テスト条件--------------------------
    // 登録処理を行う
    // -----------------------------------------------------
    @Test
    public void insertOrUpdate_異常_更新処理_15_4_15() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // テスト実行
        Mst092Form form = new Mst092Form();

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2_2(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
                AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        form.setConTani("1");
        form.setConTanka("1000000");
        form.setListYobibetuShiiregakuGetuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKayo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuSuiyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuMokuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKinyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuDoyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuNichiSuku(new BigDecimal("100"));
        target.setMst092Form(form);
        target.insertOrUpdate();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること削除処理を行う。
        assertEquals("001", form.getConEigyoshoCd().getValue());
        assertEquals("1002", form.getConShiireKbn().getValue());
        assertEquals("FC008", form.getConShiiresakiCd().getValue());
        assertEquals("1", form.getConTani());
    }
    
        // insertOrUpdate_異常_更新処理_15_4_16
    //
    // -------------------テスト条件--------------------------
    // 登録処理を行う
    // -----------------------------------------------------
    @Test
    public void insertOrUpdate_異常_更新処理_15_4_16() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // テスト実行
        Mst092Form form = new Mst092Form();

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2_3(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
                AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        form.setConTani("1");
        form.setConTanka("1000000");
        form.setListYobibetuShiiregakuGetuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKayo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuSuiyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuMokuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKinyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuDoyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuNichiSuku(new BigDecimal("100"));
        target.setMst092Form(form);
        target.insertOrUpdate();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること削除処理を行う。
        assertEquals("001", form.getConEigyoshoCd().getValue());
        assertEquals("1002", form.getConShiireKbn().getValue());
        assertEquals("FC008", form.getConShiiresakiCd().getValue());
        assertEquals("1", form.getConTani());
    }
    
        // insertOrUpdate_異常_更新処理_15_4_17
    //
    // -------------------テスト条件--------------------------
    // 登録処理を行う
    // -----------------------------------------------------
    @Test
    public void insertOrUpdate_異常_更新処理_15_4_17() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // テスト実行
        Mst092Form form = new Mst092Form();

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2_4(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
                AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        form.setConTani("1");
        form.setConTanka("1000000");
        form.setListYobibetuShiiregakuGetuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKayo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuSuiyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuMokuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKinyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuDoyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuNichiSuku(new BigDecimal("100"));
        target.setMst092Form(form);
        target.insertOrUpdate();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること削除処理を行う。
        assertEquals("001", form.getConEigyoshoCd().getValue());
        assertEquals("1002", form.getConShiireKbn().getValue());
        assertEquals("FC008", form.getConShiiresakiCd().getValue());
        assertEquals("1", form.getConTani());
    }
    
        // insertOrUpdate_異常_更新処理_15_4_18
    //
    // -------------------テスト条件--------------------------
    // 登録処理を行う
    // -----------------------------------------------------
    @Test
    public void insertOrUpdate_異常_更新処理_15_4_18() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // テスト実行
        Mst092Form form = new Mst092Form();

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2_5(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
                AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});
        form.setConTani("1");
        form.setConTanka("1000000");
        form.setListYobibetuShiiregakuGetuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKayo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuSuiyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuMokuyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuKinyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuDoyo(new BigDecimal("100"));
        form.setListYobibetuShiiregakuNichiSuku(new BigDecimal("100"));
        target.setMst092Form(form);
        target.insertOrUpdate();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること削除処理を行う。
        assertEquals("001", form.getConEigyoshoCd().getValue());
        assertEquals("1002", form.getConShiireKbn().getValue());
        assertEquals("FC008", form.getConShiiresakiCd().getValue());
        assertEquals("1", form.getConTani());
    }

    // ronriDelRows_正常_論理削除処理_16_1
    //
    // -------------------テスト条件--------------------------
    // 業務論理削除処理
    // -----------------------------------------------------
    @Test
    public void ronriDelRows_正常_論理削除処理_16_1() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture());
        // テスト実行
        Mst092Form form = new Mst092Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
        target.setMst092Form(form);
        target.ronriDelRows();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null, form.getConTani());
        assertEquals(null, form.getConTanka());
        assertEquals("mst092_ronri_delete", functionCodeCaptor_2.getValue());
        // 想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること削除処理を行う。
        assertEquals("INFO", levelCaptor_3.getValue());
        assertEquals("COMI0011", summaryCaptor_4.getValue());
        assertEquals("論理削除", detailCaptor_5.getValue());

    }
    
    // ronriDelRows_正常_論理削除処理_16_2
    //
    // -------------------テスト条件--------------------------
    // 業務論理削除処理
    // -----------------------------------------------------
    @Test
    public void ronriDelRows_異常_論理削除処理_16_2() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
       // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕入予定マスタに存在しない[COME0006]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0043",
                "仕入予定データ");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), 
                functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture(),
                summaryCaptor_3.capture(),summaryCaptor_4.capture())).thenReturn(messageModuleBean);
        // テスト実行
        Mst092Form form = new Mst092Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
        target.setMst092Form(form);
        target.ronriDelRows();

        // 実施結果Outを取得
        form = target.getMst092Form();

    }
    
    // ronriDelRows_正常_論理削除処理_16_3
    //
    // -------------------テスト条件--------------------------
    // 業務論理削除処理
    // -----------------------------------------------------
    @Test
    public void ronriDelRows_異常_論理削除処理_16_3() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        serviceInterfaceBean2.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean, serviceInterfaceBean2);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());
        // テスト実行
        Mst092Form form = new Mst092Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
        target.setMst092Form(form);
        target.ronriDelRows();

        // 実施結果Outを取得
        form = target.getMst092Form();

    }

    // delRows_正常_削除処理_17_1
    //
    // -------------------テスト条件--------------------------
    // 削除処理
    // -----------------------------------------------------
    @Test
    public void delRows_正常_削除処理_17_1() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture());
        // テスト実行
        Mst092Form form = new Mst092Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        target.setMst092Form(form);
        target.delRows();

        // 実施結果Outを取得
        form = target.getMst092Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null, form.getConTani());
        assertEquals(null, form.getConTanka());
        assertEquals("mst092_delete", functionCodeCaptor_2.getValue());
        // 想定通りに正常終了メッセージ（メッセージID：COMI0004）を表示されること削除処理を行う。
        assertEquals("INFO", levelCaptor_3.getValue());
        assertEquals("COMI0011", summaryCaptor_4.getValue());
        assertEquals("削除", detailCaptor_5.getValue());

    }
    
    // ronriDelRows_正常_論理削除処理_16_2
    //
    // -------------------テスト条件--------------------------
    // 削除処理
    // -----------------------------------------------------
    @Test
    public void delRows_異常_削除処理_17_2() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
       // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕入予定マスタに存在しない[COME0006]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "COME0043",
                "仕入予定データ");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), 
                functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture(),
                summaryCaptor_3.capture(),summaryCaptor_4.capture())).thenReturn(messageModuleBean);
        // テスト実行
        Mst092Form form = new Mst092Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
        target.setMst092Form(form);
        target.delRows();

        // 実施結果Outを取得
        form = target.getMst092Form();

    }
    
    // ronriDelRows_正常_論理削除処理_16_3
    //
    // -------------------テスト条件--------------------------
    // 削除処理
    // -----------------------------------------------------
    @Test
    public void delRows_異常_論理削除処理_17_3() throws IllegalAccessException,
            InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        serviceInterfaceBean2.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean, serviceInterfaceBean2);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(
                levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5.capture());
        // テスト実行
        Mst092Form form = new Mst092Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean conShiiresakiCd = new AutoCompOptionBean();
        conShiiresakiCd.setValue("FC008");
        AutoCompOptionBean conShiireKbn = new AutoCompOptionBean();
        conShiireKbn.setValue("1002");
        String conTekiyoKaishibi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        form.setConEigyoshoCd(conEigyoshoCd);
        form.setConShiireKbn(conShiireKbn);
        form.setConShiiresakiCd(conShiiresakiCd);
        form.setConTekiyoKaishibi(conTekiyoKaishibi);
        form.setConTekiyoMei("適用名1");
        form.setConTekiyoShuryo(new String[]{"ConTekiyoShuryo1"});

        List<Map<String, Object>> resultShiireYotel = new ArrayList<>();
        List<Map<String, Object>> resultShiireYotelMeisai = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            resultShiireYotel.add(createRecMapFor_11_1(i));
            resultShiireYotelMeisai.add(createRecMapFor_14_2(i));
        }
        form.setSearchResultMsShiireYotel(new ReportListDataModel(resultShiireYotel));
        form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(resultShiireYotelMeisai));
        target.setMst092Form(form);
        target.delRows();

        // 実施結果Outを取得
        form = target.getMst092Form();

    }

    // menuClick_正常_補充ケース_18-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_18_2() throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst092Form form = new Mst092Form();
        target.setMst092Form(form);
        target.menuClick("", "");

        // 実施結果Outを取得
        form = target.getMst092Form();

    }

    // menuClick_正常_補充ケース_18-2-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_18_2_1() throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(1);

        // テスト実行
        Mst092Form form = new Mst092Form();
        target.setMst092Form(form);
        target.menuClick("", "");

        // 実施結果Outを取得
        form = target.getMst092Form();

    }

    // breadClumClick_正常_補充ケース_18-3
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_18_3() throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst092Form form = new Mst092Form();
        target.setMst092Form(form);
        target.breadClumClick("", 0);

        // 実施結果Outを取得
        form = target.getMst092Form();

    }

    // breadClumClick_正常_補充ケース_18-3-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_18_3_1() throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(0);
        // テスト実行
        Mst092Form form = new Mst092Form();
        target.setMst092Form(form);
        target.breadClumClick("", 0);

        // 実施結果Outを取得
        form = target.getMst092Form();

    }

    // logoutClick_正常_補充ケース_18-4
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void logoutClick_正常_補充ケース_18_4() throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst092Form form = new Mst092Form();
        target.setMst092Form(form);
        target.logoutClick();

        // 実施結果Outを取得
        form = target.getMst092Form();

    }

    // addRow_正常_補充ケース_18_5
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void addRow_正常_補充ケース_18_5() throws IllegalAccessException, InvocationTargetException {

        
        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> result = new ArrayList<>();
        
        resMap.put("tablesorter_mst092", result);
        
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);

        // パラメータキャプチャー
        doNothing().when(pageCommonBean).addRow("tablesorter_mst092", true);
        // テスト実行
        Mst092Form form = new Mst092Form();
        target.setMst092Form(form);
        target.addRow("tablesorter_mst092", true);

        // 実施結果Outを取得
        form = target.getMst092Form();

    }

    private Map<String, String> createRecMapFor_1_1(int i) {
        Map recMap = new HashMap();
        BigDecimal money = new BigDecimal(1111111111);
        String conTekiyobi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        recMap.put("listShiireYoteiDataVersion", "listShiireYoteiDataVersion" + i);
        recMap.put("conTani", "listTani" + i);
        recMap.put("conTanka", "listTanka" + i);
        recMap.put("listTekiyoShuryobi", "listTekiyoShuryobi" + i);
        recMap.put("listYobibetuShiiregakuGetuyo", money);
        recMap.put("listYobibetuShiiregakuKayo", money);
        recMap.put("listYobibetuShiiregakuSuiyo", money);
        recMap.put("listYobibetuShiiregakuMokuyo", money);
        recMap.put("listYobibetuShiiregakuKinyo", money);
        recMap.put("listYobibetuShiiregakuDoyo", money);
        recMap.put("listYobibetuShiiregakuNichiSuku", money);
        recMap.put("listEigyoshoMei", "listEigyoshoMei" + i);
        return recMap;
    }

    private Map<String, String> createRecMapFor_13_1(int i) {
        Map recMap = new HashMap();
        recMap.put("LISTTEKIYOKAISHIBI", "1546272000000");
        return recMap;
    }

    private Map<String, Object> createRecMapFor_14_1(int i) {
        Map recMap = new HashMap();
        BigDecimal money = new BigDecimal(1111111111);
        recMap.put("listhMeisaiNo", "listhMeisaiNo" + i);
        recMap.put("listKanriNo", "123456789");
        recMap.put("listKeihiHutangaku", " ");
        recMap.put("listUchiHikazeigaku", money);
        recMap.put("listShohizei", null);
        recMap.put("listShiiregaku", money);
        recMap.put("listMemo", "listMemo" + i);
        recMap.put("listUchiHikazeigaku", money);
        return recMap;
    }
    
    private Map<String, String> createRecMapFor_14_1_1(int i) {
        Map recMap = new HashMap();
        BigDecimal money = new BigDecimal(1111111111);
        recMap.put("listhMeisaiNo", "listhMeisaiNo" + i);
        recMap.put("listKanriNo", "123456789");
        recMap.put("listUchiHikazeigaku", money);
        recMap.put("listKeihiHutangaku", "");
        recMap.put("listShiiregaku", money);
        recMap.put("ZEI_RITSU", new BigDecimal("40"));
        return recMap;
    }
    
    private Map<String, String> createRecMapFor_14_1_2() {
        Map recMap = new HashMap();
        recMap.put("ZEI_RITSU", new BigDecimal("40"));
        return recMap;
    }
    
    private Map<String, String> createRecMapFor_14_1_3(int i) {
        Map recMap = new HashMap();
        BigDecimal money = new BigDecimal(1111111111);
        recMap.put("listUchiHikazeigaku", money);
        recMap.put("listShiiregaku", money);
        return recMap;
    }
    
    private Map<String, String> createRecMapFor_14_1_4() {
        Map recMap = new HashMap();
        BigDecimal money = new BigDecimal(1111111111);
        recMap.put("listShiiregaku", "");

        return recMap;
    }

    private Map<String, String> createRecMapFor_14_1_5() {
        Map recMap = new HashMap();
        BigDecimal money = new BigDecimal(1111111111);
        recMap.put("listUchiHikazeigaku", "");
        recMap.put("listShiiregaku", money);

        return recMap;
    }

    private Map<String, String> createRecMapFor_14_1_6() {
        Map recMap = new HashMap();
        recMap.put("ZEI_RITSU", "");
        return recMap;
    }

    private Map<String, Object> createRecMapFor_14_2(int i) {
        Map recMap = new HashMap();
        BigDecimal money = new BigDecimal(1111111111);
        recMap.put("listhMeisaiNo", "listhMeisaiNo" + i);
        recMap.put("listKanriNo", "123456789");
        recMap.put("listKeihiHutangaku", null);
        recMap.put("listUchiHikazeigaku", money);
        recMap.put("listShohizei", null);
        recMap.put("listShiiregaku", money);
        recMap.put("listMemo", "listMemo" + i);
        recMap.put("listUchiHikazeigaku", money);
        return recMap;
    }
    
    private Map<String, Object> createRecMapFor_14_2_1(int i) {
        Map recMap = new HashMap();
        BigDecimal money = new BigDecimal(1111111111);
        recMap.put("listhMeisaiNo", "listhMeisaiNo" + i);
        recMap.put("listKanriNo", "listKanriNo" + i);
        recMap.put("listKeihiHutangaku", null);
        recMap.put("listUchiHikazeigaku", money);
        recMap.put("listShohizei", null);
        recMap.put("listShiiregaku", money);
        recMap.put("listMemo", "listMemo" + i);
        recMap.put("listUchiHikazeigaku", money);
        return recMap;
    }
    
    private Map<String, Object> createRecMapFor_14_2_2(int i) {
        Map recMap = new HashMap();
        recMap.put("listKanriNo", "123456789");
        return recMap;
    }
        
    private Map<String, Object> createRecMapFor_14_2_3(int i) {
        Map recMap = new HashMap();
        BigDecimal money = new BigDecimal(1111111111);
        recMap.put("listKanriNo", "123456789" + i);
        recMap.put("listUchiHikazeigaku", new BigDecimal("-10"));
        return recMap;
    }
            
    private Map<String, Object> createRecMapFor_14_2_4(int i) {
        Map recMap = new HashMap();
        BigDecimal money = new BigDecimal(1111111111);
        recMap.put("listKanriNo", "123456789" + i);
        recMap.put("listUchiHikazeigaku", money);
        recMap.put("listShiiregaku", null);
        return recMap;
    }
    private Map<String, Object> createRecMapFor_14_2_5(int i) {
        Map recMap = new HashMap();
        BigDecimal money = new BigDecimal(1111111111);
        recMap.put("listKanriNo", "123456789" + i);
        recMap.put("listUchiHikazeigaku", money);
        recMap.put("listShiiregaku", new BigDecimal("-10"));
        return recMap;
    }

    private Map<String, String> createRecMapFor_1(int i) {
        Map recMap = new HashMap();
        recMap.put("ZEI_RITSU ", "ZEI_RITSU " + i);
        return recMap;
    }

    private Map<String, Object> createRecMapFor_1_2(int i) {
        Map recMap = new HashMap();
        recMap.put("listShiireKbnCd", "listShiireKbnCd" + i);
        recMap.put("listShiireKbn", "listShiireKbn" + i);
        recMap.put("listShiiresakiCd", "listShiiresakiCd" + i);
        recMap.put("listEigyoshoCd", "listEigyoshoCd" + i);
        String conTekiyobi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        recMap.put("listTekiyoKaisibi", Long.valueOf("1546272000000"));
        recMap.put("listShiiresakiMei", "listShiiresakiMei" + i);
        recMap.put("listTani", "listTani" + i);
        recMap.put("listTanka", "listTanka" + i);
        recMap.put("listYobibetuShiiregakuGetuyo", "listYobibetuShiiregakuGetuyo" + i);
        recMap.put("listYobibetuShiiregakuKayo", "listYobibetuShiiregakuKayo" + i);
        recMap.put("listYobibetuShiiregakuSuiyo", "listYobibetuShiiregakuSuiyo" + i);
        recMap.put("listYobibetuShiiregakuMokuyo", "listYobibetuShiiregakuMokuyo" + i);
        recMap.put("listYobibetuShiiregakuKinyo", "listYobibetuShiiregakuKinyo" + i);
        recMap.put("listYobibetuShiiregakuDoyo", "listYobibetuShiiregakuDoyo" + i);
        recMap.put("listYobibetuShiiregakuNitiShuku", "listYobibetuShiiregakuNitiShuku" + i);
        recMap.put("listShiireYoteiMeisaiGokeiKingaku", "listShiireYoteiMeisaiGokeiKingaku" + i);
        recMap.put("listTekiyoShuryobi", "listTekiyoShuryobi" + i);
        recMap.put("listEigyoshoMei", "listEigyoshoMei" + i);
        recMap.put("listShuryoFlg", "listShuryoFlg" + i);
        recMap.put("listhMeisaiNo", "listhMeisaiNo" + i);
        recMap.put("listKanriNo", "listKanriNo" + i);
        recMap.put("listKeihiHutangaku", "listKeihiHutangaku" + i);
        recMap.put("listUchiHikazeigaku", "listUchiHikazeigaku" + i);
        recMap.put("listShohizei", "listShohizei" + i);
        recMap.put("listShiiregaku", "listShiiregaku" + i);
        recMap.put("listMemo", "listMemo" + i);
        recMap.put("listUchiHikazeigaku", "listUchiHikazeigaku" + i);
        recMap.put("listSakujoFlg", "listSakujoFlg" + i);

        return recMap;
    }

    private Map<String, Object> createRecMapFor_11_1(int i) {
        Map recMap = new HashMap();
        recMap.put("listYobibetuShiiregakuGetuyo", "listYobibetuShiiregakuGetuyo" + i);
        recMap.put("listYobibetuShiiregakuKayo", "listYobibetuShiiregakuKayo" + i);
        recMap.put("listYobibetuShiiregakuSuiyo", "listYobibetuShiiregakuSuiyo" + i);
        recMap.put("listYobibetuShiiregakuMokuyo", "listYobibetuShiiregakuMokuyo" + i);
        recMap.put("listYobibetuShiiregakuKinyo", "listYobibetuShiiregakuKinyo" + i);
        recMap.put("listYobibetuShiiregakuDoyo", "listYobibetuShiiregakuDoyo" + i);
        recMap.put("listYobibetuShiiregakuNitiShuku", "listYobibetuShiiregakuNitiShuku" + i);
        recMap.put("listShiireYoteiMeisaiGokeiKingaku", "listShiireYoteiMeisaiGokeiKingaku" + i);
        recMap.put("listEigyoshoMei", "listEigyoshoMei" + i);
        recMap.put("listShuryoFlg", "listShuryoFlg" + i);
        return recMap;
    }
    
        private Map<String, Object> createRecMapFor_11_1_1(int i) {
        Map recMap = new HashMap();
        recMap.put("listYobibetuShiiregakuGetuyo", "listYobibetuShiiregakuGetuyo" + i);
        recMap.put("listYobibetuShiiregakuKayo", "listYobibetuShiiregakuKayo" + i);
        recMap.put("listYobibetuShiiregakuSuiyo", "listYobibetuShiiregakuSuiyo" + i);
        recMap.put("listYobibetuShiiregakuMokuyo", "listYobibetuShiiregakuMokuyo" + i);
        recMap.put("listYobibetuShiiregakuKinyo", "listYobibetuShiiregakuKinyo" + i);
        recMap.put("listYobibetuShiiregakuDoyo", "listYobibetuShiiregakuDoyo" + i);
        recMap.put("listYobibetuShiiregakuNitiShuku", "listYobibetuShiiregakuNitiShuku" + i);
        recMap.put("listShiireYoteiMeisaiGokeiKingaku", "listShiireYoteiMeisaiGokeiKingaku" + i);
        recMap.put("listEigyoshoMei", "listEigyoshoMei" + i);
        recMap.put("listSearchFlg", "true");
        return recMap;
    }

    private Map<String, Object> createRecMapFor_11_2(int i) {
        Map recMap = new HashMap();
        recMap.put("listDataVersion", "listDataVersion" + i);
        recMap.put("listShiireKbnCd", "listShiireKbnCd" + i);
        recMap.put("listShiiresakiCd", "listShiiresakiCd" + i);
        recMap.put("listEigyoshoCd", "listEigyoshoCd" + i);
        String conTekiyobi = "2019-01-01";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        recMap.put("listTekiyoKaisibi", Long.valueOf("1546272000000"));
        recMap.put("listShiiresakiMei", "listShiiresakiMei" + i);
        recMap.put("listTani", "listTani" + i);
        recMap.put("listTanka", "listTanka" + i);
        recMap.put("listYobibetuShiiregakuGetuyo", "listYobibetuShiiregakuGetuyo" + i);
        recMap.put("listYobibetuShiiregakuKayo", "listYobibetuShiiregakuKayo" + i);
        recMap.put("listYobibetuShiiregakuSuiyo", "listYobibetuShiiregakuSuiyo" + i);
        recMap.put("listYobibetuShiiregakuMokuyo", "listYobibetuShiiregakuMokuyo" + i);
        recMap.put("listYobibetuShiiregakuKinyo", "listYobibetuShiiregakuKinyo" + i);
        recMap.put("listYobibetuShiiregakuDoyo", "listYobibetuShiiregakuDoyo" + i);
        recMap.put("listYobibetuShiiregakuNitiShuku", "listYobibetuShiiregakuNitiShuku" + i);
        recMap.put("listShiireYoteiMeisaiGokeiKingaku", "listShiireYoteiMeisaiGokeiKingaku" + i);
        recMap.put("listEigyoshoMei", "listEigyoshoMei" + i);
        recMap.put("listShuryoFlg", "listShuryoFlg" + i);
        return recMap;
    }

    private void assertForRecList_2_1(Mst092Form form) {
        int i = 0;
        assertEquals(1, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listShiireKbnCd" + i, rec.get("listShiireKbnCd"));
            assertEquals("listShiiresakiCd" + i, rec.get("listShiiresakiCd"));
            assertEquals("listEigyoshoCd" + i, rec.get("listEigyoshoCd"));
            assertEquals("2019/01/01", rec.get("listTekiyoKaisibi"));
            assertEquals("listShiiresakiMei" + i, rec.get("listShiiresakiMei"));
            assertEquals("listTani" + i, rec.get("listTani"));
            assertEquals("1,111,111,111", rec.get("listTanka"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuGetuyo"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuKayo"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuSuiyo"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuMokuyo"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuKinyo"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuDoyo"));
            assertEquals("1,111,111,111", rec.get("listYobibetuShiiregakuNitiShuku"));
            assertEquals("1,111,111,111", rec.get("listShiireYoteiMeisaiGokeiKingaku"));
            assertEquals("listEigyoshoMei" + i, rec.get("listEigyoshoMei"));
            assertEquals("listShuryoFlg" + i, rec.get("listShuryoFlg"));
            i++;
        }
    }

    private void assertForRecList_2_2(Mst092Form form) {
        int i = 0;
        assertEquals(2, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listShiireKbnCd" + i, rec.get("listShiireKbnCd"));
            assertEquals("listShiiresakiCd" + i, rec.get("listShiiresakiCd"));
            assertEquals("listEigyoshoCd" + i, rec.get("listEigyoshoCd"));
            assertEquals(Long.valueOf("1546272000000"), rec.get("listTekiyoKaisibi"));
            assertEquals("listShiiresakiMei" + i, rec.get("listShiiresakiMei"));
            assertEquals("listTani" + i, rec.get("listTani"));
            assertEquals("listTanka" + i, rec.get("listTanka"));
            assertEquals("listYobibetuShiiregakuGetuyo" + i, rec.get("listYobibetuShiiregakuGetuyo"));
            assertEquals("listYobibetuShiiregakuKayo" + i, rec.get("listYobibetuShiiregakuKayo"));
            assertEquals("listYobibetuShiiregakuSuiyo" + i, rec.get("listYobibetuShiiregakuSuiyo"));
            assertEquals("listYobibetuShiiregakuMokuyo" + i, rec.get("listYobibetuShiiregakuMokuyo"));
            assertEquals("listYobibetuShiiregakuKinyo" + i, rec.get("listYobibetuShiiregakuKinyo"));
            assertEquals("listYobibetuShiiregakuDoyo" + i, rec.get("listYobibetuShiiregakuDoyo"));
            assertEquals("listYobibetuShiiregakuNitiShuku" + i, rec.get("listYobibetuShiiregakuNitiShuku"));
            assertEquals("listShiireYoteiMeisaiGokeiKingaku" + i, rec.get("listShiireYoteiMeisaiGokeiKingaku"));
            assertEquals("listEigyoshoMei" + i, rec.get("listEigyoshoMei"));
            assertEquals("listShuryoFlg" + i, rec.get("listShuryoFlg"));
            i++;
        }
    }

    private void assertForRecList_2_3(Mst092Form form) {
        int i = 0;
        assertEquals(0, form.getSearchResult().size());
    }

}
