/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.lgn;

import java.io.IOException;
import static org.junit.Assert.assertEquals;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import javax.naming.AuthenticationException;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import jp.co.kintetsuls.beans.common.DirContextBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.SystemMasterBean;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.forms.lgn.Lgn011Form;
import jp.co.kintetsuls.service.LoginService;
import jp.co.kintetsuls.service.common.AuthorityService;
import jp.co.kintetsuls.service.common.MenuService;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.kintetsuls.utils.FlashUtil;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import jp.co.sharedsys.beans.session.MenuBean;
import org.mockito.Mockito;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * ログイン画面
 *
 * @author 曾鳳(MBP)
 * @version 2019/4/1 新規作成
 */
public class Lgn011BeanTest {

    // テストTarget
    @InjectMocks
    private Lgn011Bean target;

    // Mockitoオブジェクト
    @Mock
    private MessagePropertyBean messagePropertyBean;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private SystemMasterBean systemMasterBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private AuthorityConfBean authConfBean;
    @Mock
    private MenuBean menuBean;
    @Mock
    private DirContextBean dirContextBean;
    @Mock
    LoginService loginService;
    @Mock
    AuthorityService authService;
    @Mock
    MenuService menuService;
    @Mock
    FlashUtil flashUtil;
    
    public Lgn011BeanTest() {
    }

    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() {
    }

    // init_正常_初期処理_1-1
    @Test
    public void init_正常_初期処理_1_1() {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String[]> keyCaptor_2 = ArgumentCaptor.forClass(String[].class);
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        // ログインフォーム
        Lgn011Form lgn011Form = new Lgn011Form();
        // パスワード誤入力最大回数
        String passwordGoNyuryokuSaidaiKaisu = "5";
        // 各プロジェクトのRestFullサービスの受け渡しクラス
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // お知らせ検索結果一覧取得 件数 = 1
        List<Map<String, Object>> result = new ArrayList<>();
        Map<String, Object> map = new HashMap();
        map.put("osrDtlListKinkyudo", "3");
        map.put("osrDtlListNichiji", "2019/04/01");
        map.put("osrDtlListUserMei", "test001");
        map.put("osrDtlListMessage", "message");
        result.add(map);
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        
        // パスワード誤入力最大回数取得
        when(systemMasterBean.getSysValByCdAndKanriGroup(keyCaptor_1.capture(), keyCaptor_2.capture()
                )).thenReturn(passwordGoNyuryokuSaidaiKaisu);

        // お知らせ取得
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        
        //テスト実行
        target.setLgn011Form(lgn011Form);
        target.init("", "", false);
        
        // 実行時に渡すパラメータの検証
        assertEquals("password_error_max_kaisu", keyCaptor_1.getValue());
        assertEquals("lgn011", keyCaptor_2.getAllValues().get(0));
        assertEquals("system", keyCaptor_2.getAllValues().get(1));
        assertEquals("lgn011-get-inform-detail", functionCodeCaptor_2.getValue());
        assertEquals("5", lgn011Form.getHyoDtlPasswordGoNyuryokuSaidaiKaisu().toString());
        assertEquals("3", lgn011Form.getInformResultList().get(0).get("osrDtlListKinkyudo"));
        assertEquals("2019/04/01", lgn011Form.getInformResultList().get(0).get("osrDtlListNichiji"));
        assertEquals("test001", lgn011Form.getInformResultList().get(0).get("osrDtlListUserMei"));
        assertEquals("message", lgn011Form.getInformResultList().get(0).get("osrDtlListMessage"));
    }
    
    // init_異常_初期処理_1-2
    @Test
    public void init_異常_初期処理_1_2() {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String[]> keyCaptor_2 = ArgumentCaptor.forClass(String[].class);
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        // ログインフォーム
        Lgn011Form lgn011Form = new Lgn011Form();
        // パスワード誤入力最大回数
        String passwordGoNyuryokuSaidaiKaisu = "5";
        
        // パスワード誤入力最大回数取得
        when(systemMasterBean.getSysValByCdAndKanriGroup(keyCaptor_1.capture(), keyCaptor_2.capture()
                )).thenReturn(passwordGoNyuryokuSaidaiKaisu);

        // お知らせ取得異常
        doThrow(IOException.class).when(pageCommonBean).getDBInfo(paramsCaptor_1.capture(), 
                functionCodeCaptor_2.capture());
        
        //テスト実行
        target.setLgn011Form(lgn011Form);
        target.init("", "", false);
        
        // 実行時に渡すパラメータの検証
        assertEquals("password_error_max_kaisu", keyCaptor_1.getValue());
        assertEquals("lgn011", keyCaptor_2.getAllValues().get(0));
        assertEquals("system", keyCaptor_2.getAllValues().get(1));
        assertEquals("lgn011-get-inform-detail", functionCodeCaptor_2.getValue());
    }
    
    // login_異常_ログイン処理_2-1
    //
    // -------------------テスト条件--------------------------
    // ユーザーが存在しない
    // -----------------------------------------------------
    @Test
    public void login_異常_ログイン処理_2_1() {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> compCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Object[]> argsCaptor_4 = ArgumentCaptor.forClass(Object[].class);
        
        // Mockitoオブジェクトの予想return値設定
        // ログインフォーム
        Lgn011Form lgn011Form = new Lgn011Form();
        lgn011Form.setHyoDtlUserCd("test001");
        // 各プロジェクトのRestFullサービスの受け渡しクラス
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // ユーザー件数 = 0
        int kensu = 0;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(kensu));
        
        // ユーザ情報取得
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        doNothing().when(messagePropertyBean).messageToArea(levelCaptor_1.capture(),summaryCaptor_2.capture(),
                compCaptor_3.capture(), argsCaptor_4.capture());
        
        //テスト実行
        target.setLgn011Form(lgn011Form);
        target.login();
        
        // 実行時に渡すパラメータの検証
        assertEquals("test001", paramsCaptor_1.getValue().get("hyoDtlUserCd"));
        assertEquals("lgn011-check-usercd", functionCodeCaptor_2.getValue());
        assertEquals("ERROR", levelCaptor_1.getValue());
        assertEquals("COME0006", summaryCaptor_2.getValue());
        assertEquals("loginForm:hyoDtlErrorMessage", compCaptor_3.getValue());
        assertEquals("ユーザーコード", argsCaptor_4.getAllValues().get(0));
        assertEquals("ユーザーマスタ", argsCaptor_4.getAllValues().get(1));
    }

    // login_異常_ログイン処理_2-2
    //
    // -------------------テスト条件--------------------------
    // ユーザーが存在、パスワードが入力誤り、パスワード誤入力回数 + 1 < パスワード誤入力最大回数 の場合
    // -----------------------------------------------------
    @Test
    public void login_異常_ログイン処理_2_2() throws NamingException {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> compCaptor_3 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        // ログインフォーム
        Lgn011Form lgn011Form = new Lgn011Form();
        lgn011Form.setHyoDtlUserCd("test001");
        lgn011Form.setHyoDtlPassword("001");
        // パスワード誤入力最大回数 = 5
        lgn011Form.setHyoDtlPasswordGoNyuryokuSaidaiKaisu(5);
        // 各プロジェクトのRestFullサービスの受け渡しクラス
        // ユーザー件数 = 1
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        int kensu = 1;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(kensu));

        // パスワード誤入力回数 = 1
        ServiceInterfaceBean errServiceInterfaceBean = new ServiceInterfaceBean();
        int errorKaisu = 1;
        errServiceInterfaceBean.setJson(JSONUtil.makeJSONString(errorKaisu));
        
        // ユーザ情報取得
        Map<String, Object> params = new HashMap<>();
        params.put("hyoDtlUserCd", lgn011Form.getHyoDtlUserCd());
        when(pageCommonBean.getDBInfo(params, "lgn011-check-usercd")).thenReturn(serviceInterfaceBean);
        
        // パスワード誤入力回数を更新する
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_1.capture()))
                .thenReturn(errServiceInterfaceBean);
        
        doNothing().when(messagePropertyBean).messageToArea(levelCaptor_1.capture(),summaryCaptor_2.capture(),
                compCaptor_3.capture());
        
        // ADサーバログイン処理
        doThrow(AuthenticationException.class).when(dirContextBean)
                .initialDirContext(lgn011Form.getHyoDtlUserCd(), lgn011Form.getHyoDtlPassword());
        
        //テスト実行
        target.setLgn011Form(lgn011Form);
        target.login();
        
        // 実行時に渡すパラメータの検証
        assertEquals("test001", paramsCaptor_1.getValue().get("userCd"));
        assertEquals("lgn011-update-pwdkaisu", functionCodeCaptor_1.getValue());
        assertEquals("ERROR", levelCaptor_1.getValue());
        assertEquals("LGNE0009", summaryCaptor_2.getValue());
        assertEquals("loginForm:hyoDtlErrorMessage", compCaptor_3.getValue());
    }

    // login_異常_ログイン処理_2-3
    //
    // -------------------テスト条件--------------------------
    // ユーザーが存在、パスワードが入力誤り、パスワード誤入力回数 + 1 = パスワード誤入力最大回数 の場合
    // -----------------------------------------------------
    @Test
    public void login_異常_ログイン処理_2_3() throws NamingException {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> compCaptor_3 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        // ログインフォーム
        Lgn011Form lgn011Form = new Lgn011Form();
        lgn011Form.setHyoDtlUserCd("test001");
        lgn011Form.setHyoDtlPassword("001");
        // パスワード誤入力最大回数 = 5
        lgn011Form.setHyoDtlPasswordGoNyuryokuSaidaiKaisu(5);
        // 各プロジェクトのRestFullサービスの受け渡しクラス
        // ユーザー件数 = 1
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        int kensu = 1;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(kensu));

        // パスワード誤入力回数 = 4
        ServiceInterfaceBean errServiceInterfaceBean = new ServiceInterfaceBean();
        int errorKaisu = 4;
        errServiceInterfaceBean.setJson(JSONUtil.makeJSONString(errorKaisu));
        
        // ユーザ情報取得
        Map<String, Object> params = new HashMap<>();
        params.put("hyoDtlUserCd", lgn011Form.getHyoDtlUserCd());
        when(pageCommonBean.getDBInfo(params, "lgn011-check-usercd")).thenReturn(serviceInterfaceBean);
        
        // パスワード誤入力回数を更新する
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_1.capture()))
                .thenReturn(errServiceInterfaceBean);
        
        doNothing().when(messagePropertyBean).messageToArea(levelCaptor_1.capture(),summaryCaptor_2.capture(),
                compCaptor_3.capture());
        
        // ADサーバログイン処理
        doThrow(AuthenticationException.class).when(dirContextBean)
                .initialDirContext(lgn011Form.getHyoDtlUserCd(), lgn011Form.getHyoDtlPassword());
        
        //テスト実行
        target.setLgn011Form(lgn011Form);
        target.login();
        
        // 実行時に渡すパラメータの検証
        assertEquals("test001", paramsCaptor_1.getValue().get("userCd"));
        assertEquals("lgn011-update-pwdkaisu", functionCodeCaptor_1.getValue());
        assertEquals("ERROR", levelCaptor_1.getValue());
        assertEquals("LGNE0009", summaryCaptor_2.getValue());
        assertEquals("loginForm:hyoDtlErrorMessage", compCaptor_3.getValue());
    }

    // login_異常_ログイン処理_2-4
    //
    // -------------------テスト条件--------------------------
    // ユーザーが存在、パスワードが入力誤り、パスワード誤入力回数 + 1 > パスワード誤入力最大回数 の場合
    // -----------------------------------------------------
    @Test
    public void login_異常_ログイン処理_2_4() throws NamingException {
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> compCaptor_3 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        // ログインフォーム
        Lgn011Form lgn011Form = new Lgn011Form();
        lgn011Form.setHyoDtlUserCd("test001");
        lgn011Form.setHyoDtlPassword("001");
        // パスワード誤入力最大回数 = 5
        lgn011Form.setHyoDtlPasswordGoNyuryokuSaidaiKaisu(5);
        // 各プロジェクトのRestFullサービスの受け渡しクラス
        // ユーザー件数 = 1
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        int kensu = 1;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(kensu));

        // パスワード誤入力回数 = 5
        ServiceInterfaceBean errServiceInterfaceBean = new ServiceInterfaceBean();
        int errorKaisu = 5;
        errServiceInterfaceBean.setJson(JSONUtil.makeJSONString(errorKaisu));
        
        // ユーザ情報取得
        Map<String, Object> params = new HashMap<>();
        params.put("hyoDtlUserCd", lgn011Form.getHyoDtlUserCd());
        when(pageCommonBean.getDBInfo(params, "lgn011-check-usercd")).thenReturn(serviceInterfaceBean);
        
        // パスワード誤入力回数を更新する
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_1.capture()))
                .thenReturn(errServiceInterfaceBean);
        
        doNothing().when(messagePropertyBean).messageToArea(levelCaptor_1.capture(),summaryCaptor_2.capture(),
                compCaptor_3.capture());
        
        // ADサーバログイン処理
        doThrow(AuthenticationException.class).when(dirContextBean)
                .initialDirContext(lgn011Form.getHyoDtlUserCd(), lgn011Form.getHyoDtlPassword());
        
        //テスト実行
        target.setLgn011Form(lgn011Form);
        target.login();
        
        // 実行時に渡すパラメータの検証
        assertEquals("test001", paramsCaptor_1.getValue().get("userCd"));
        assertEquals("lgn011-update-pwdkaisu", functionCodeCaptor_1.getValue());
        assertEquals("ERROR", levelCaptor_1.getValue());
        assertEquals("LGNE0003", summaryCaptor_2.getValue());
        assertEquals("loginForm:hyoDtlErrorMessage", compCaptor_3.getValue());
    }

    // login_異常_ログイン処理_2-5
    //
    // -------------------テスト条件--------------------------
    // ユーザーが存在、パスワードが入力正しい、システムエラーが発生した場合(AuthenticationException以外のException発生時)
    // -----------------------------------------------------
    @Test
    public void login_異常_ログイン処理_2_5() throws NamingException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> compCaptor_3 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        // ログインフォーム
        Lgn011Form lgn011Form = new Lgn011Form();
        lgn011Form.setHyoDtlUserCd("test001");
        lgn011Form.setHyoDtlPassword("TEST001");
        // パスワード誤入力最大回数 = 5
        lgn011Form.setHyoDtlPasswordGoNyuryokuSaidaiKaisu(5);
        // 各プロジェクトのRestFullサービスの受け渡しクラス
        // ユーザー件数 = 1
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        int kensu = 1;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(kensu));
        
        // ユーザ情報取得
        Map<String, Object> params = new HashMap<>();
        params.put("hyoDtlUserCd", lgn011Form.getHyoDtlUserCd());
        when(pageCommonBean.getDBInfo(params, "lgn011-check-usercd")).thenReturn(serviceInterfaceBean);
        
        doNothing().when(messagePropertyBean).messageToArea(levelCaptor_1.capture(),summaryCaptor_2.capture(),
                compCaptor_3.capture());
        
        // ADサーバログイン処理
        doThrow(NamingException.class).when(dirContextBean)
                .initialDirContext(lgn011Form.getHyoDtlUserCd(), lgn011Form.getHyoDtlPassword());
        
        //テスト実行
        target.setLgn011Form(lgn011Form);
        target.login();
        
        // 実行時に渡すパラメータの検証
        assertEquals("ERROR", levelCaptor_1.getValue());
        assertEquals("COMF0002", summaryCaptor_2.getValue());
        assertEquals("loginForm:hyoDtlErrorMessage", compCaptor_3.getValue());
    }

    // login_正常_ログイン処理_2-6
    //
    // -------------------テスト条件--------------------------
    // ユーザーが存在、パスワードが入力正しい、ADサーバ接続成功、ワンタイムパスワードフラグ = 1
    // -----------------------------------------------------
    @Test
    public void login_正常_ログイン処理_2_6() throws NamingException, SystemException, IOException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> userCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> psswCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        // ログインフォーム
        Lgn011Form lgn011Form = new Lgn011Form();
        lgn011Form.setHyoDtlUserCd("test001");
        lgn011Form.setHyoDtlPassword("TEST001");
        // パスワード誤入力最大回数 = 5
        lgn011Form.setHyoDtlPasswordGoNyuryokuSaidaiKaisu(5);
        // 各プロジェクトのRestFullサービスの受け渡しクラス
        // ユーザー件数 = 1
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        int kensu = 1;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(kensu));
        
        // ユーザ情報取得
        Map<String, Object> params = new HashMap<>();
        params.put("hyoDtlUserCd", lgn011Form.getHyoDtlUserCd());
        when(pageCommonBean.getDBInfo(params, "lgn011-check-usercd")).thenReturn(serviceInterfaceBean);
        
        // ADサーバログイン処理
        InitialDirContext ctx = Mockito.mock(InitialDirContext.class);
        when(dirContextBean
                .initialDirContext(lgn011Form.getHyoDtlUserCd(), lgn011Form.getHyoDtlPassword())).thenReturn(ctx);
        
        // パスワード誤入力回数を初期化する
        Map<String, Object> params2 = new HashMap<>();
        params2.put("userCd", lgn011Form.getHyoDtlUserCd());
        when(pageCommonBean.getDBInfo(params2, "lgn011-init-pwdkaisu")).thenReturn(serviceInterfaceBean);
        
        // ユーザのADサーバ情報を取得する
        NamingEnumeration ctxr = Mockito.mock(NamingEnumeration.class);
        when(dirContextBean.initialDirContext(userCaptor_1.capture(), psswCaptor_2.capture())).thenReturn(ctx);
        ArgumentCaptor<String> ctxCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> ctxCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<SearchControls> ctxCaptor_3 = ArgumentCaptor.forClass(SearchControls.class);
        when(ctxr.hasMore()).thenReturn(true, false);
        Attributes attr = new BasicAttributes();
        // ワンタイムパスワードフラグ = 1
        attr.put("userCertificate", "1");
        SearchResult sr = new SearchResult("", "", attr);
        when(ctxr.next()).thenReturn(sr);
        when(ctx.search(ctxCaptor_1.capture(), ctxCaptor_2.capture(), ctxCaptor_3.capture())).thenReturn(ctxr);

        ServiceInterfaceBean sib = new ServiceInterfaceBean();
        sib.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        RestfullService rest = null;

        // ログイン情報取得を呼ぶ
        when(loginService.getLoginInfo(
                authConfBean, rest, lgn011Form.getHyoDtlUserCd(), lgn011Form.getHyoDtlPassword())).thenReturn(sib);
        
        // 権限取得を呼ぶ
        when(authService.getAuthority(lgn011Form.getHyoDtlUserCd(), rest, authConfBean)).thenReturn(sib);
        
        // Menu取得を呼ぶ
        when(menuService.getMenu(lgn011Form.getHyoDtlUserCd(), rest, menuBean)).thenReturn(sib);
        
        // flash
        Flash flash =  new FlashKls();
        flash.put("onetimePassLogin", "1");
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        when(flashUtil.getPageParam()).thenReturn(flash);
        
        //テスト実行
        target.setLgn011Form(lgn011Form);
        target.login();
        
        // 実行結果の検証
        assertEquals("/contents/lgn/lgn021.xhtml?faces-redirect=true", target.getUrl());
    }

    // login_正常_ログイン処理_2-7
    //
    // -------------------テスト条件--------------------------
    // ユーザーが存在、パスワードが入力正しい、ADサーバ接続成功、ワンタイムパスワードフラグ = 0
    // -----------------------------------------------------
    @Test
    public void login_正常_ログイン処理_2_7() throws NamingException, SystemException, IOException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> userCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> psswCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        // ログインフォーム
        Lgn011Form lgn011Form = new Lgn011Form();
        lgn011Form.setHyoDtlUserCd("test001");
        lgn011Form.setHyoDtlPassword("TEST001");
        // パスワード誤入力最大回数 = 5
        lgn011Form.setHyoDtlPasswordGoNyuryokuSaidaiKaisu(5);
        // 各プロジェクトのRestFullサービスの受け渡しクラス
        // ユーザー件数 = 1
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        int kensu = 1;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(kensu));
        
        // ユーザ情報取得
        Map<String, Object> params = new HashMap<>();
        params.put("hyoDtlUserCd", lgn011Form.getHyoDtlUserCd());
        when(pageCommonBean.getDBInfo(params, "lgn011-check-usercd")).thenReturn(serviceInterfaceBean);
        
        // ADサーバログイン処理
        InitialDirContext ctx = Mockito.mock(InitialDirContext.class);
        when(dirContextBean
                .initialDirContext(lgn011Form.getHyoDtlUserCd(), lgn011Form.getHyoDtlPassword())).thenReturn(ctx);
        
        // パスワード誤入力回数を初期化する
        Map<String, Object> params2 = new HashMap<>();
        params2.put("userCd", lgn011Form.getHyoDtlUserCd());
        when(pageCommonBean.getDBInfo(params2, "lgn011-init-pwdkaisu")).thenReturn(serviceInterfaceBean);
        
        // ユーザのADサーバ情報を取得する
        NamingEnumeration ctxr = Mockito.mock(NamingEnumeration.class);
        when(dirContextBean.initialDirContext(userCaptor_1.capture(), psswCaptor_2.capture())).thenReturn(ctx);
        ArgumentCaptor<String> ctxCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> ctxCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<SearchControls> ctxCaptor_3 = ArgumentCaptor.forClass(SearchControls.class);
        when(ctxr.hasMore()).thenReturn(true, false);
        Attributes attr = new BasicAttributes();
        // ワンタイムパスワードフラグ = 0
        attr.put("userCertificate", "0");
        SearchResult sr = new SearchResult("", "", attr);
        when(ctxr.next()).thenReturn(sr);
        when(ctx.search(ctxCaptor_1.capture(), ctxCaptor_2.capture(), ctxCaptor_3.capture())).thenReturn(ctxr);

        ServiceInterfaceBean sib = new ServiceInterfaceBean();
        sib.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        RestfullService rest = null;

        // ログイン情報取得を呼ぶ
        when(loginService.getLoginInfo(
                authConfBean, rest, lgn011Form.getHyoDtlUserCd(), lgn011Form.getHyoDtlPassword())).thenReturn(sib);
        
        // 権限取得を呼ぶ
        when(authService.getAuthority(lgn011Form.getHyoDtlUserCd(), rest, authConfBean)).thenReturn(sib);
        
        // Menu取得を呼ぶ
        when(menuService.getMenu(lgn011Form.getHyoDtlUserCd(), rest, menuBean)).thenReturn(sib);
        
        // flash
        Flash flash =  new FlashKls();
        flash.put("onetimePassLogin", "1");
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        when(flashUtil.getPageParam()).thenReturn(flash);
        
        //テスト実行
        target.setLgn011Form(lgn011Form);
        target.login();
        
        // 実行結果の検証
        assertEquals("/contents/top/top011.xhtml?faces-redirect=true", target.getUrl());
    }

    // login_正常_ログイン処理_2-8
    //
    // -------------------テスト条件--------------------------
    // ユーザーが存在、パスワードが入力正しい、ADサーバ接続成功、パスワード有効期限 < SYSDATE
    // -----------------------------------------------------
    @Test
    public void login_正常_ログイン処理_2_8() throws NamingException, SystemException, IOException {
        
        // パラメータキャプチャー
        ArgumentCaptor<String> userCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> psswCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        // ログインフォーム
        Lgn011Form lgn011Form = new Lgn011Form();
        lgn011Form.setHyoDtlUserCd("test001");
        lgn011Form.setHyoDtlPassword("TEST001");
        // パスワード誤入力最大回数 = 5
        lgn011Form.setHyoDtlPasswordGoNyuryokuSaidaiKaisu(5);
        // 各プロジェクトのRestFullサービスの受け渡しクラス
        // ユーザー件数 = 1
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        int kensu = 1;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(kensu));
        
        // ユーザ情報取得
        Map<String, Object> params = new HashMap<>();
        params.put("hyoDtlUserCd", lgn011Form.getHyoDtlUserCd());
        when(pageCommonBean.getDBInfo(params, "lgn011-check-usercd")).thenReturn(serviceInterfaceBean);
        
        // ADサーバログイン処理
        InitialDirContext ctx = Mockito.mock(InitialDirContext.class);
        when(dirContextBean
                .initialDirContext(lgn011Form.getHyoDtlUserCd(), lgn011Form.getHyoDtlPassword())).thenReturn(ctx);
        
        // パスワード誤入力回数を初期化する
        Map<String, Object> params2 = new HashMap<>();
        params2.put("userCd", lgn011Form.getHyoDtlUserCd());
        when(pageCommonBean.getDBInfo(params2, "lgn011-init-pwdkaisu")).thenReturn(serviceInterfaceBean);
        
        // ユーザのADサーバ情報を取得する
        NamingEnumeration ctxr = Mockito.mock(NamingEnumeration.class);
        when(dirContextBean.initialDirContext(userCaptor_1.capture(), psswCaptor_2.capture())).thenReturn(ctx);
        ArgumentCaptor<String> ctxCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> ctxCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<SearchControls> ctxCaptor_3 = ArgumentCaptor.forClass(SearchControls.class);
        when(ctxr.hasMore()).thenReturn(true, false);
        Attributes attr = new BasicAttributes();
        // パスワード有効期限 < SYSDATE
        attr.put("userCert", "2019/03/01");
        SearchResult sr = new SearchResult("", "", attr);
        when(ctxr.next()).thenReturn(sr);
        when(ctx.search(ctxCaptor_1.capture(), ctxCaptor_2.capture(), ctxCaptor_3.capture())).thenReturn(ctxr);

        ServiceInterfaceBean sib = new ServiceInterfaceBean();
        sib.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        RestfullService rest = null;

        // ログイン情報取得を呼ぶ
        when(loginService.getLoginInfo(
                authConfBean, rest, lgn011Form.getHyoDtlUserCd(), lgn011Form.getHyoDtlPassword())).thenReturn(sib);
        
        // 権限取得を呼ぶ
        when(authService.getAuthority(lgn011Form.getHyoDtlUserCd(), rest, authConfBean)).thenReturn(sib);
        
        // Menu取得を呼ぶ
        when(menuService.getMenu(lgn011Form.getHyoDtlUserCd(), rest, menuBean)).thenReturn(sib);
        
        // flash
        Flash flash =  new FlashKls();
        flash.put("onetimePassLogin", "1");
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        when(flashUtil.getPageParam()).thenReturn(flash);
        
        //テスト実行
        target.setLgn011Form(lgn011Form);
        target.login();
        
        // 実行結果の検証
        assertEquals("/contents/lgn/lgn021.xhtml?faces-redirect=true", target.getUrl());
    }

    // pwdInitLink_正常_パスワード初期化ページへ遷移処理_3-1
    @Test
    public void pwdInitLink_正常_パスワード初期化ページへ遷移処理_3_1() {
        
        Flash flash =  new FlashKls();
        flash.put("onetimePassLogin", "0");
        when(flashUtil.getPageParam()).thenReturn(flash);
        
        //テスト実行
        target.pwdInitLink();
        
        // 実行結果の検証
        assertEquals("/contents/lgn/lgn031.xhtml?faces-redirect=true", target.getUrl());
    }
    
    // menuClick_正常_メニュークリック処_4-1
    @Test
    public void menuClick_正常_メニュークリック処理_4_1() {
        //テスト実行
        target.menuClick("", "");
        
        // 実行結果の検証
        assertEquals(null, target.getUrl());
    }
    
    // breadClumClick_正常_パンくずクリック処理_5-1
    @Test
    public void breadClumClick_正常_パンくずクリック処理_5_1() {
        //テスト実行
        target.breadClumClick("", 0);
        
        // 実行結果の検証
        assertEquals(null, target.getUrl());
    }
    
    // logoutClick_正常_ログアウトクリック処理_6-1
    @Test
    public void logoutClick_正常_ログアウトクリック処理_6_1() {
        //テスト実行
        target.logoutClick();
        
        // 実行結果の検証
        assertEquals(null, target.getUrl());
    }
    
    // initSetting_正常_初期設定ボタンクリック処理_7-1
    @Test
    public void initSetting_正常_初期設定ボタンクリック処理_7_1() {
        
        Flash flash =  new FlashKls();
        when(flashUtil.getPageParam()).thenReturn(flash);
        
        //テスト実行
        target.initSetting();
        
        // 実行結果の検証
        assertEquals("/contents/top/top011.xhtml?faces-redirect=true", target.getUrl());
    }
    
    // netFramework_正常_.NET Frameworkボタンクリック処理_8-1
    @Test
    public void netFramework_正常_Frameworkボタンクリック処理_8_1() {
        
        Flash flash =  new FlashKls();
        when(flashUtil.getPageParam()).thenReturn(flash);
        
        //テスト実行
        target.netFramework();
        
        // 実行結果の検証
        assertEquals("/contents/top/top011.xhtml?faces-redirect=true", target.getUrl());
    }
    
}
