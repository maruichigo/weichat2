package jp.co.kintetsuls.beans.mst;

import java.io.IOException;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.doThrow;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.KbnBean;
import jp.co.kintetsuls.beans.common.KbnModuleBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.forms.mst.Mst131Form;
import jp.co.kintetsuls.utils.DateUtils;
import jp.co.kintetsuls.utils.FlashUtil;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import static org.mockito.Mockito.when;

/**
 * 仕向地名マスタ画面
 *
 * @author 馬雷 (MBP)
 * @version 2019/1/24 新規作成
 */
public class Mst131BeanTest {

    // テストTarget
    @InjectMocks
    private Mst131Bean target;

    // Mockitoオブジェクト
    @Mock
    private FileBean fileBean;
    @Mock
    private AutoCompleteViewBean autoCompleteViewBean;
    @Mock
    private MasterInfoBean masterInfo;
    @Mock
    private MessagePropertyBean messageProperty;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosai;
    @Mock
    private SearchHelpBean searchHelpBean;
    @Mock
    private AuthorityConfBean authConfBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private KbnBean kbnBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosaiBean;
    @Mock
    private ListCheckBean listCheckBean;
    @Mock
    private  FlashUtil flashUtil;
    public Mst131BeanTest() {
    }

    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() {
    }

    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[not null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst131Form mst131Form = new Mst131Form();
        
        //前画面情報[not null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst131Form);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst131Form form = new Mst131Form();
        target.setForm(form);
        // 戻ってきた場合、再検索を実施する。
        target.init("","MST132_SCREEN",true);

        //実施結果Outを取得
        form = target.getForm();
        String title = target.getTITLE();
        String url = target.getUrl();
        BreadCrumbBean breadBean = target.getBreadBean();
        AutoCompleteViewBean autoCompleteViewBean = target.getAutoCompleteViewBean();
        AuthorityConfBean authorityConfBean  = target.getAuthConfBean();
        FileBean fileBean = target.getFileBean();
        MessagePropertyBean messagePropertyBean = target.getMessageProperty();
        PageCommonBean pageCommonBean = target.getPageCommon();
        SearchHelpBean searchHelpBean = target.getSearchHelpBean();
        RirekiSyosaiBean rirekiSyosaiBean = target.getRirekiSyosaiBean();
//        ListCheckBean listCheckBean = target.getListCheckBean();
        Map<String, Object> rirekiSearchKey = target.getRirekiSearchKey();
        List<MessageModuleBean> msgList = target.getMsgList();
        target.setUrl(url);
        target.setBreadBean(breadBean);
        target.setAutoCompleteViewBean(autoCompleteViewBean);
        target.setAuthConfBean(authorityConfBean);
        target.setFileBean(fileBean);
        target.setMessageProperty(messagePropertyBean);
        target.setPageCommon(pageCommonBean);
        target.setSearchHelpBean(searchHelpBean);
        target.setRirekiSyosaiBean(rirekiSyosaiBean);
//        target.setListCheckBean(listCheckBean);
        target.setRirekiSearchKey(rirekiSearchKey);
        target.setMsgList(msgList);
        
        // 実行時に渡すパラメータの検証
        assertEquals("mst131Form",keyCaptor_1.getValue());
        //想定通りに再検索を実施する。
        assertEquals("search_mst131",keyCaptor_2.getValue());
    }

    // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[都道府県 = 01,仕向地名 = 地名23,削除済のみ検索 = null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2() throws IllegalAccessException, InvocationTargetException,
            InstantiationException, SystemException {

        // Mockitoオブジェクトの予想return値設定
        Mst131Form mst131Form = new Mst131Form();
        //前回検索パラメータ
        AutoCompOptionBean conTodofuken = new AutoCompOptionBean();
        AutoCompOptionBean conKankantsuEigyosho = new AutoCompOptionBean();
        conTodofuken.setValue("01");
        conKankantsuEigyosho.setValue("001");
        mst131Form.setConTodofuken(conTodofuken);
        List<String> kankatsuKbn = new ArrayList<>();
        kankatsuKbn.add("01");
        // 管轄区分
        mst131Form.setConKankatsuKbn(kankatsuKbn);
        // 削除済のみ
        mst131Form.setConSakujoSumiNomi(null);
        // 管轄営業所コード
        mst131Form.setKankatsuEigyosho(conKankantsuEigyosho);
        // SS仕入先コード
        mst131Form.setConSsShiiresakiCd("SS001");
        // 仕入先コード
        mst131Form.setConShiiresakiCd("1001");
        // 会社名
        mst131Form.setConKaishaMei("KM_会社");
        // 支店/営業所名
        mst131Form.setConShitenEigyoshoMei("大阪支店");
        // 仕入先名
        mst131Form.setConShiiresakiMei("仕入先");
        // 使用区分
        List<String> shiyouKbn = new ArrayList<>();
        shiyouKbn.add("1");
        mst131Form.setConShiyoKbn(shiyouKbn);
        // 世代検索条件
        List<String> seidaiKensakuJyoken = new ArrayList<>();
        seidaiKensakuJyoken.add("05");
        mst131Form.setConSedaiKensakuJoken(seidaiKensakuJyoken);
        // 適用日
        mst131Form.setConTekiyoBi("2019/03/01");
        // カナ名称
        mst131Form.setConKanaMeisho("会社カナ");
        // 申請状況
        List<String> shinseiJyouKyo = new ArrayList<>();
        shinseiJyouKyo.add("02");
        mst131Form.setConShinseiJokyo(shinseiJyouKyo);
        // 住所
        mst131Form.setConJusho("東京");
        // 未使用期間（年）
        mst131Form.setConMishiyoKikanNen(1);
        // 未使用期間（月）
        mst131Form.setConMishiyoKikanTsuki(2);
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        //前画面パラメータ[都道府県 = 01,仕向地名 = 地名23,削除済のみ検索 = null]
        flash.put("mst131Form", mst131Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);        

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        //テスト実行
        Mst131Form form = new Mst131Form();
        target.setForm(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getForm();

        //想定通りに再検索を実施する。
        assertEquals("search_mst131",keyCaptor_2.getValue());
        assertEquals("01",form.getConTodofuken().getValue());
        assertEquals("001", form.getKankatsuEigyosho().getValue());
        assertEquals(kankatsuKbn, form.getConKankatsuKbn());
        assertEquals(conKankantsuEigyosho.getValue(), conKankantsuEigyosho.getValue());
        assertEquals("SS001", form.getConSsShiiresakiCd());
        assertEquals("1001", form.getConShiiresakiCd());
        assertEquals("1", form.getConShiyoKbn().get(0));
        assertEquals(shiyouKbn, form.getConShiyoKbn());
        assertEquals(seidaiKensakuJyoken, form.getConSedaiKensakuJoken());
        assertEquals("2019/03/01", form.getConTekiyoBi());
        assertEquals(shinseiJyouKyo, form.getConShinseiJokyo());
        assertEquals(null,form.getConSakujoSumiNomi());
    }

    // init_正常_初期処理_1-2_1
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2_1() throws IllegalAccessException, InvocationTargetException,
            InstantiationException, SystemException {

        // Mockitoオブジェクトの予想return値設定
        Mst131Form mst131Form = new Mst131Form();
        //前回検索パラメータ[都道府県 = 01,仕向地名 = 地名23,削除済のみ検索 = null]
        AutoCompOptionBean conTodofuken = new AutoCompOptionBean();
        conTodofuken.setValue("01");
        mst131Form.setConTodofuken(conTodofuken);
        AutoCompOptionBean conKankantsuEigyosho = new AutoCompOptionBean();
        conKankantsuEigyosho.setValue("001");
        // 管轄営業所
        mst131Form.setKankatsuEigyosho(conKankantsuEigyosho);
        // 使用区分
        List<String> shiyouKbn = new ArrayList<>();
        shiyouKbn.add("1");
        mst131Form.setConShiyoKbn(shiyouKbn);
        // 世代検索条件
        List<String> seidaiKensakuJyoken = new ArrayList<>();
        seidaiKensakuJyoken.add("05");
        mst131Form.setConSedaiKensakuJoken(seidaiKensakuJyoken);
        // 適用日
        mst131Form.setConTekiyoBi("2019/03/01");
        mst131Form.setConSakujoSumiNomi(null);
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        //前画面パラメータ[都道府県 = 01,仕向地名 = 地名23,削除済のみ検索 = null]
        flash.put("mst131Form", null);
        when(pageCommonBean.getPageParam()).thenReturn(flash);        

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());

        //テスト実行
        Mst131Form form = new Mst131Form();
        target.setForm(mst131Form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getForm();

        //想定通りに再検索を実施する。
        assertEquals(null,form.getConSakujoSumiNomi());
        assertEquals(conKankantsuEigyosho, form.getKankatsuEigyosho());
        assertEquals(null, form.getConShiyoKbn());
        List<String> sedaiJyoken = new ArrayList<>();
        sedaiJyoken.add(null);
        sedaiJyoken.add(null);
        assertEquals(sedaiJyoken, form.getConSedaiKensakuJoken());
        assertEquals(null, form.getConTekiyoBi());
        
    }    
    
    // init_正常_初期処理_1-3
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        //前画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(null);

        //テスト実行
        Mst131Form form = new Mst131Form();
        target.setForm(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getForm();

        // 実行時に渡すパラメータの検証
        assertEquals("mst131Form",keyCaptor_1.getValue());
        //想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null,form.getSearchResult());
    }

    // init_正常_初期処理_1-3_1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        //前画面情報[null]
        doThrow(IllegalAccessException.class).when(pageCommonBean).getPageInfo(keyCaptor_1.capture());

        //テスト実行
        Mst131Form form = new Mst131Form();
        target.setForm(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getForm();

        // 実行時に渡すパラメータの検証
        assertEquals("mst131Form",keyCaptor_1.getValue());
        //想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null,form.getSearchResult());
    }

   // search_正常_検索処理_2-1
    //
    // -------------------テスト条件--------------------------
    // 仕向地検索結果一覧取得
    // 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_1 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=0;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

         KbnModuleBean kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnMei("削除");
        KbnModuleBean kbnModuleBean1 = new KbnModuleBean();
        kbnModuleBean1.setKbnMei("適用終了");
        
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_SAKUJO")).thenReturn(kbnModuleBean);
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_TEKIYO_SHURYO")).thenReturn(kbnModuleBean1);
        //テスト実行
        Mst131Form mst131Form = new Mst131Form();
        AutoCompOptionBean conTodofuken = new AutoCompOptionBean();
        AutoCompOptionBean conKankantsuEigyosho = new AutoCompOptionBean();
        conTodofuken.setValue("01");
        conKankantsuEigyosho.setValue("001");
        mst131Form.setConTodofuken(conTodofuken);
        List<String> kankatsuKbn = new ArrayList<>();
        kankatsuKbn.add("01");
        // 管轄区分
        mst131Form.setConKankatsuKbn(kankatsuKbn);
        // 削除済のみ
        mst131Form.setConSakujoSumiNomi(null);
        // 管轄営業所コード
        mst131Form.setKankatsuEigyosho(conKankantsuEigyosho);
        // SS仕入先コード
        mst131Form.setConSsShiiresakiCd("SS001");
        // 仕入先コード
        mst131Form.setConShiiresakiCd("1001");
        // 会社名
        mst131Form.setConKaishaMei("KM_会社");
        // 支店/営業所名
        mst131Form.setConShitenEigyoshoMei("大阪支店");
        // 仕入先名
        mst131Form.setConShiiresakiMei("仕入先");
        // 使用区分
        List<String> shiyouKbn = new ArrayList<>();
        shiyouKbn.add("1");
        mst131Form.setConShiyoKbn(shiyouKbn);
        // 世代検索条件
        List<String> seidaiKensakuJyoken = new ArrayList<>();
        seidaiKensakuJyoken.add("05");
        mst131Form.setConSedaiKensakuJoken(seidaiKensakuJyoken);
        // 適用日
        mst131Form.setConTekiyoBi("2019/03/01");
        // カナ名称
        mst131Form.setConKanaMeisho("会社カナ");
        // 申請状況
        List<String> shinseiJyouKyo = new ArrayList<>();
        shinseiJyouKyo.add("02");
        mst131Form.setConShinseiJokyo(shinseiJyouKyo);
        // 住所
        mst131Form.setConJusho("東京");
        // 未使用期間（年）
        mst131Form.setConMishiyoKikanNen(1);
        // 未使用期間（月）
        mst131Form.setConMishiyoKikanTsuki(2);
        target.setForm(mst131Form);
        target.search();
        //実施結果Outを取得
        mst131Form = target.getForm();
        // 実行時に渡すパラメータの検証
        assertEquals(conTodofuken, mst131Form.getConTodofuken());
        List<String> kankatsuKbnParam = (List<String>) paramsCaptor_1.getValue().get("conKankatsuKbn");
        assertEquals(kankatsuKbn, kankatsuKbnParam);
        assertEquals("", paramsCaptor_1.getValue().get("conSakujoSumiNomi"));
        assertEquals(conKankantsuEigyosho, mst131Form.getKankatsuEigyosho());

        assertEquals("SS001", paramsCaptor_1.getValue().get("conSsShiiresakiCd"));
        assertEquals("1001", paramsCaptor_1.getValue().get("conShiiresakiCd"));
        assertEquals("KM_会社", paramsCaptor_1.getValue().get("conKaishaMei"));
        assertEquals("大阪支店", paramsCaptor_1.getValue().get("conShitenEigyoshoMei"));
        assertEquals("仕入先", paramsCaptor_1.getValue().get("conShiiresakiMei"));
        List<String> shiyouKbnParams = (List<String>) paramsCaptor_1.getValue().get("conShiyoKbn");
        assertEquals(shiyouKbn, shiyouKbnParams);
        List<String> seidaiKensakuJokenParams = (List<String>) paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals(seidaiKensakuJyoken, seidaiKensakuJokenParams);
        assertEquals("2019/03/01", paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals("会社カナ", paramsCaptor_1.getValue().get("conKanaMeisho"));
        List<String> shinseiJokyoParam = (List<String>) paramsCaptor_1.getValue().get("conShinseiJokyo");
        assertEquals(shinseiJyouKyo, shinseiJokyoParam);
        assertEquals("東京", paramsCaptor_1.getValue().get("conJusho"));
        assertEquals(1, paramsCaptor_1.getValue().get("conMishiyoKikanNen"));
        assertEquals(2, paramsCaptor_1.getValue().get("conMishiyoKikanTsuki"));
        
        assertEquals("mst131-get-detail", functionCodeCaptor_2.getValue());

    }

   // search_正常_検索処理_2-2
    //
    // -------------------テスト条件--------------------------
    // 仕向地検索結果一覧取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        KbnModuleBean kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnMei("削除");
        KbnModuleBean kbnModuleBean1 = new KbnModuleBean();
        kbnModuleBean1.setKbnMei("適用終了");
        
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_SAKUJO")).thenReturn(kbnModuleBean);
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_TEKIYO_SHURYO")).thenReturn(kbnModuleBean1);
        //仕向地検索結果一覧取得 取得件数 = 2
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=1;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst131Form form = new Mst131Form();
        target.setForm(form);
        target.search();

        //実施結果Outを取得
        form = target.getForm();

        // 実行時に渡すパラメータの検証
         List<String> kankatsuKbnParam = (List<String>) paramsCaptor_1.getValue().get("conKankatsuKbn");
        assertEquals(null, kankatsuKbnParam);
        assertEquals("", paramsCaptor_1.getValue().get("conSakujoSumiNomi"));
        assertEquals(null, form.getKankatsuEigyosho());

        assertEquals(null, paramsCaptor_1.getValue().get("conSsShiiresakiCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conShiiresakiCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conKaishaMei"));
        assertEquals(null, paramsCaptor_1.getValue().get("conShitenEigyoshoMei"));
        assertEquals(null, paramsCaptor_1.getValue().get("conShiiresakiMei"));
        List<String> shiyouKbnParams = (List<String>) paramsCaptor_1.getValue().get("conShiyoKbn");
        assertEquals(null, shiyouKbnParams);
        List<String> seidaiKensakuJokenParams = (List<String>) paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals(null, seidaiKensakuJokenParams);
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals(null, paramsCaptor_1.getValue().get("conKanaMeisho"));
        List<String> shinseiJokyoParam = (List<String>) paramsCaptor_1.getValue().get("conShinseiJokyo");
        assertEquals(null, shinseiJokyoParam);
        assertEquals(null, paramsCaptor_1.getValue().get("conJusho"));
        assertEquals(0, paramsCaptor_1.getValue().get("conMishiyoKikanNen"));
        assertEquals(0, paramsCaptor_1.getValue().get("conMishiyoKikanTsuki"));

        assertEquals("mst131-get-detail",functionCodeCaptor_2.getValue());
    }

    // search_異常_検索処理_2-3
    //
    // -------------------テスト条件--------------------------
    // 仕向地検索結果一覧取得 取得件数 = 0
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得 取得件数 = 0
        List<Map<String, String>> result = new ArrayList<>();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        KbnModuleBean kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnMei("削除");
        KbnModuleBean kbnModuleBean1 = new KbnModuleBean();
        kbnModuleBean1.setKbnMei("適用終了");
        
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_SAKUJO")).thenReturn(kbnModuleBean);
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_TEKIYO_SHURYO")).thenReturn(kbnModuleBean1);
        //テスト実行
        Mst131Form form = new Mst131Form();
         List<String> kankatsuKbn = new ArrayList<>();
        kankatsuKbn.add("01");
        // 管轄区分
        form.setConKankatsuKbn(kankatsuKbn);
        // 削除済のみ
        form.setConSakujoSumiNomi(null);
        // 使用区分
        List<String> shiyouKbn = new ArrayList<>();
        shiyouKbn.add("1");
        form.setConShiyoKbn(shiyouKbn);
        // 世代検索条件
        List<String> seidaiKensakuJyoken = new ArrayList<>();
        seidaiKensakuJyoken.add("05");
        form.setConSedaiKensakuJoken(seidaiKensakuJyoken);
        target.setForm(form);
        target.search();

        //実施結果Outを取得
        form = target.getForm();

        // 実行時に渡すパラメータの検証
        assertEquals(null, form.getConSakujoSumiNomi());
        List<String> kankatsuKbnParam = (List<String>) paramsCaptor_1.getValue().get("conKankatsuKbn");
        assertEquals(kankatsuKbn, kankatsuKbnParam);
        assertEquals(shiyouKbn, form.getConShiyoKbn());
        List<String> seidaiKensakuJyokenParam = (List<String>) paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals(seidaiKensakuJyoken, seidaiKensakuJyokenParam);
        assertEquals("mst131-get-detail",functionCodeCaptor_2.getValue());
        //想定通りに・一覧は表示しない（ヘッダーのみ） 
        //想定通りに ・ファンクションボタンは表示（検索前と同じ） 
        assertForRecList_2_3(form);
    }

    // getRecordCount_正常_件数取得処理_2-4
    //
    // -------------------テスト条件--------------------------
    // 仕入先検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        KbnModuleBean kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnMei("削除");
        KbnModuleBean kbnModuleBean1 = new KbnModuleBean();
        kbnModuleBean1.setKbnMei("適用終了");
        
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_SAKUJO")).thenReturn(kbnModuleBean);
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_TEKIYO_SHURYO")).thenReturn(kbnModuleBean1);
        //テスト実行
        Mst131Form form = new Mst131Form();
        target.setForm(form);
        target.count(false);

        //実施結果Outを取得
        form = target.getForm();

        // 実行時に渡すパラメータの検証
        assertEquals(null, form.getConSakujoSumiNomi());
        List<String> kankatsuKbnParam = (List<String>) paramsCaptor_1.getValue().get("conKankatsuKbn");
        assertEquals(null, kankatsuKbnParam);
         List<String> shiyouKbnParam = (List<String>) paramsCaptor_1.getValue().get("ConShiyoKbn");
        assertEquals(null, shiyouKbnParam);
        List<String> seidaiKensakuJyokenParam = (List<String>) paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
        assertEquals(null, seidaiKensakuJyokenParam);
        //想定通りに正常にCountを実施されること
        assertEquals(null,form.getConTodofuken());
        assertEquals("mst131-get-count",functionCodeCaptor_2.getValue());
    }

    // getRecordCount_正常_件数取得処理_2-4_1
    //
    // -------------------テスト条件--------------------------
    // 仕向地検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_4_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        KbnModuleBean kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnMei("削除");
        KbnModuleBean kbnModuleBean1 = new KbnModuleBean();
        kbnModuleBean1.setKbnMei("適用終了");
        
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_SAKUJO")).thenReturn(kbnModuleBean);
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_TEKIYO_SHURYO")).thenReturn(kbnModuleBean1);

        //テスト実行
        Mst131Form form = new Mst131Form();
        AutoCompOptionBean conTodofuken = new AutoCompOptionBean();
        conTodofuken.setValue("conTodofuken1");
        form.setConTodofuken(conTodofuken);
         List<String> kankatsuKbn = new ArrayList<>();
        kankatsuKbn.add("01");
        // 管轄区分
        form.setConKankatsuKbn(kankatsuKbn);
        // 削除済のみ
        form.setConSakujoSumiNomi(null);
        // 使用区分
        List<String> shiyouKbn = new ArrayList<>();
        shiyouKbn.add("1");
        form.setConShiyoKbn(shiyouKbn);
        // 世代検索条件
        List<String> seidaiKensakuJyoken = new ArrayList<>();
        seidaiKensakuJyoken.add("05");
        form.setConSedaiKensakuJoken(seidaiKensakuJyoken);
        target.setForm(form);
        target.count(false);

        //実施結果Outを取得
        form = target.getForm();

        // 実行時に渡すパラメータの検証
        assertEquals(kankatsuKbn, (List<String>)paramsCaptor_1.getValue().get("conKankatsuKbn"));
        assertEquals("mst131-get-count",functionCodeCaptor_2.getValue());
        //想定通りに正常にCountを実施されること
        assertEquals("conTodofuken1",form.getConTodofuken().getValue());
        assertEquals("", paramsCaptor_1.getValue().get("conSakujoSumiNomi"));
        assertEquals(shiyouKbn, (List<String>) paramsCaptor_1.getValue().get("conShiyoKbn"));
        assertEquals(seidaiKensakuJyoken, (List<String>) paramsCaptor_1.getValue().get("conSedaiKensakuJoken"));
    }    

    // getRecordCount_正常_件数取得処理_2-4_2
    //
    // -------------------テスト条件--------------------------
    // 仕向地検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_4_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), 
                functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        KbnModuleBean kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnMei("削除");
        KbnModuleBean kbnModuleBean1 = new KbnModuleBean();
        kbnModuleBean1.setKbnMei("適用終了");
        
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_SAKUJO")).thenReturn(kbnModuleBean);
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_TEKIYO_SHURYO")).thenReturn(kbnModuleBean1);
        
        //テスト実行
        Mst131Form form = new Mst131Form();
        AutoCompOptionBean conTodofuken = new AutoCompOptionBean();
        conTodofuken.setValue("conTodofuken1");
        form.setConTodofuken(conTodofuken);
        form.setConShiiresakiCd("conShiiresakiCd1");
        form.setConSakujoSumiNomi(null);
        
        // 使用区分
        List<String> shiyouKbn = new ArrayList<>();
        shiyouKbn.add("1");
        form.setConShiyoKbn(shiyouKbn);
        // 世代検索条件
        List<String> seidaiKensakuJyoken = new ArrayList<>();
        seidaiKensakuJyoken.add("05");
        form.setConSedaiKensakuJoken(seidaiKensakuJyoken);
        
        //申請状況
        List<String> shinSeiJyoukyo = new ArrayList<>();
        shinSeiJyoukyo.add("02");
        form.setConShinseiJokyo(shinSeiJyoukyo);
        target.setForm(form);
        target.count(false);

        //実施結果Outを取得
        form = target.getForm();

        // 実行時に渡すパラメータの検証
        assertEquals("conShiiresakiCd1",paramsCaptor_1.getValue().get("conShiiresakiCd"));
        assertEquals("mst131-get-count",functionCodeCaptor_2.getValue());
        //想定通りに正常にCountを実施されること
        assertEquals("conTodofuken1",form.getConTodofuken().getValue());
        assertEquals("", paramsCaptor_1.getValue().get("conSakujoSumiNomi"));
        assertEquals(shiyouKbn, (List<String>) paramsCaptor_1.getValue().get("conShiyoKbn"));
        assertEquals(seidaiKensakuJyoken, (List<String>) paramsCaptor_1.getValue().get("conSedaiKensakuJoken"));
        assertEquals(shinSeiJyoukyo, (List<String>) paramsCaptor_1.getValue().get("conShinseiJokyo"));
    } 
    
    @Test
    public void getRecordCount_正常_ドンロド_2_4_3() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), 
                functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        KbnModuleBean kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnMei("削除");
        KbnModuleBean kbnModuleBean1 = new KbnModuleBean();
        kbnModuleBean1.setKbnMei("適用終了");
        
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_SAKUJO")).thenReturn(kbnModuleBean);
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_TEKIYO_SHURYO")).thenReturn(kbnModuleBean1);
        
        //テスト実行
        Mst131Form form = new Mst131Form();
        AutoCompOptionBean conTodofuken = new AutoCompOptionBean();
        conTodofuken.setValue("conTodofuken1");
        form.setConTodofuken(conTodofuken);
        form.setConShiiresakiCd("conShiiresakiCd1");
        form.setConSakujoSumiNomi(null);
        
        // 使用区分
        List<String> shiyouKbn = new ArrayList<>();
        shiyouKbn.add("1");
        form.setConShiyoKbn(shiyouKbn);
        // 世代検索条件
        List<String> seidaiKensakuJyoken = new ArrayList<>();
        seidaiKensakuJyoken.add("05");
        form.setConSedaiKensakuJoken(seidaiKensakuJyoken);
        
        //申請状況
        List<String> shinSeiJyoukyo = new ArrayList<>();
        shinSeiJyoukyo.add("02");
        form.setConShinseiJokyo(shinSeiJyoukyo);
        target.setForm(form);
        pageCommonBean.savePageInfo("mst131Form", form);
        when(pageCommonBean.getPageInfo("mst131Form")).thenReturn(form);
        target.setPageCommon(pageCommonBean);
        target.count(true);
    } 
    
    
    
    // clear_正常_クリア処理_3-1
    //
    // -------------------テスト条件--------------------------
    // 検索条件と検索結果がある
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst131Form form = new Mst131Form();
        // 検索条件と検索結果がある
        AutoCompOptionBean conTodofuken = new AutoCompOptionBean();
        conTodofuken.setValue("01");
        conTodofuken.setLabel("東京");
        form.setConTodofuken(conTodofuken);
        form.setConShiiresakiCd("仕入先テスト");
        List<String> sakuJyousumiNomi = new ArrayList<>();
        sakuJyousumiNomi.add("01");
        form.setConSakujoSumiNomi(sakuJyousumiNomi);
        // 使用区分
        List<String> shiyouKbn = new ArrayList<>();
        shiyouKbn.add("1");
        form.setConShiyoKbn(shiyouKbn);
        // 世代検索条件
        List<String> seidaiKensakuJyoken = new ArrayList<>();
        seidaiKensakuJyoken.add("05");
        form.setConSedaiKensakuJoken(seidaiKensakuJyoken);

        //申請状況
        List<String> shinSeiJyoukyo = new ArrayList<>();
        shinSeiJyoukyo.add("02");
        form.setConShinseiJokyo(shinSeiJyoukyo);
        target.setForm(form);
        target.clear();

        //実施結果Outを取得
        form = target.getForm();

        //想定通りに正常にClearを実施されること
        assertEquals(null, form.getConTodofuken());
        assertEquals(null, form.getConShiiresakiCd());
        assertEquals(null, form.getConSakujoSumiNomi());
        assertEquals(null, form.getConShiyoKbn());
        List<String> sedai = new ArrayList<String>();
        sedai.add(null);
        sedai.add(null);
        assertEquals(sedai, form.getConSedaiKensakuJoken());
        List<String> shinseiJyokyo = new ArrayList<String>();
//        shinseiJyokyo.add("");
        assertEquals(shinseiJyokyo, form.getConShinseiJokyo());
    }

    // clear_正常_クリア処理_3-2
    //
    // -------------------テスト条件--------------------------
    // 検索条件がある、検索結果がない
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst131Form form = new Mst131Form();
        target.setForm(form);
        target.clear();

        //実施結果Outを取得
        form = target.getForm();

        //想定通りに正常にClearを実施されること
        assertEquals(null, form.getConTodofuken());
        assertEquals(null, form.getConShiiresakiCd());
        assertEquals(null, form.getConSakujoSumiNomi());
    }

    // getHeader_正常_ダウンロード_4-1
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void getHeader_正常_ダウンロード_4_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst131Form form = new Mst131Form();
        target.setForm(form);
        List<CSVDto> dto = target.getHeader();

        //実施結果Outを取得
        form = target.getForm();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にCVSのHeaderを設定されること
        assertEquals(null, form.getConTodofuken());
        assertEquals(null, form.getConShiiresakiCd());
        assertEquals("管轄区分",dto.get(0).getTitle());
        assertEquals("listKankatsuKbn",dto.get(0).getName());
        assertEquals("営業所名称",dto.get(1).getTitle());
        assertEquals("listEigyoshoMei",dto.get(1).getName());
        assertEquals("仕入先コード",dto.get(2).getTitle());
        assertEquals("listShiiresakiCd",dto.get(2).getName());
        assertEquals("仕入先名称",dto.get(3).getTitle());
        assertEquals("listShiiresakiMeisho",dto.get(3).getName());
        assertEquals("適用開始日",dto.get(4).getTitle());
        assertEquals("listTekiyoKaishibi",dto.get(4).getName());
        assertEquals("仕入先住所",dto.get(5).getTitle());
        assertEquals("listShiiresakiJusho",dto.get(5).getName());
    }

    // beforeDown_正常_ダウンロード_4-2
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=2件
    // -----------------------------------------------------
    @Test
    public void beforeDown_正常_ダウンロード_4_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst131Form form = new Mst131Form();
        target.setForm(form);
        try {
            target.beforeDown("testComment");
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(Mst131BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        //実施結果Outを取得
        form = target.getForm();

        // 実行時に渡すパラメータの検証
        //想定通りに正常にダウンロード理由を記録すること
        assertEquals(null,form.getConTodofuken());
    }    


        // checkParamas_正常_検索パラメータチェック_6-1
    //
    // -------------------テスト条件--------------------------
    // 世代検索条件=null
    // -----------------------------------------------------
    @Test
    public void checkParamas_正常_検索パラメータチェック_6_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst131Form form = new Mst131Form();
        form.setConSedaiKensakuJoken(null);
        target.setForm(form);
        String ret = target.searchCheck();

        //実施結果検証
        assertEquals("TRUE",ret);
    }

    // checkParamas_正常_検索パラメータチェック_6-2
    //
    // -------------------テスト条件--------------------------
    // 世代検索条件件数=0
    // -----------------------------------------------------
    @Test
    public void checkParamas_正常_検索パラメータチェック_6_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst131Form form = new Mst131Form();
        form.setConSedaiKensakuJoken(new ArrayList<>());
        target.setForm(form);
        String ret = target.searchCheck();

        //実施結果検証
        assertEquals("TRUE",ret);
    }

    // checkParamas_正常_検索パラメータチェック_6-3
    //
    // -------------------テスト条件--------------------------
    // 適用日指定が選択されていない場合
    // -----------------------------------------------------
    @Test
    public void checkParamas_正常_検索パラメータチェック_6_3 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst131Form form = new Mst131Form();
        List<String> seidai = new ArrayList<>();
        seidai.add("01");
        form.setConSedaiKensakuJoken(seidai);
        target.setForm(form);
        when(kbnBean.getKbnCdOfKeyCd(MsCnst.SEDAI_KENSAKU_JOKEN_TEKIYO_HI_SHITEI)).thenReturn("05");
        String ret = target.searchCheck();

        //実施結果検証
        assertEquals("TRUE",ret);
    }

    // checkParamas_正常_検索パラメータチェック_6-4
    //
    // -------------------テスト条件--------------------------
    // 適用日指定が選択されている、適用日が入力されていない場合
    // -----------------------------------------------------
    @Test
    public void checkParamas_正常_検索パラメータチェック_6_4 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst131Form form = new Mst131Form();
        List<String> seidai = new ArrayList<>();
        seidai.add("05");
        form.setConSedaiKensakuJoken(seidai);
        form.setConTekiyoBi(null);
        target.setForm(form);
        when(kbnBean.getKbnCdOfKeyCd(MsCnst.SEDAI_KENSAKU_JOKEN_TEKIYO_HI_SHITEI)).thenReturn("05");
        String ret = target.searchCheck();

        //実施結果検証
        assertEquals("FALSE",ret);
    }

    // checkParamas_正常_検索パラメータチェック_6-5
    //
    // -------------------テスト条件--------------------------
    // 適用日指定が選択されている、適用日が入力されている場合
    // -----------------------------------------------------
    @Test
    public void checkParamas_正常_検索パラメータチェック_6_5 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst131Form form = new Mst131Form();
        List<String> seidai = new ArrayList<>();
        seidai.add("05");
        form.setConSedaiKensakuJoken(seidai);
        form.setConTekiyoBi("2019/03/22");
        target.setForm(form);
        when(kbnBean.getKbnCdOfKeyCd(MsCnst.SEDAI_KENSAKU_JOKEN_TEKIYO_HI_SHITEI)).thenReturn("05");
        String ret = target.searchCheck();

        //実施結果検証
        assertEquals("TRUE",ret);
    }
    
    // update_異常_更新処理_更新登録_11-7_1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_11_7_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messageProperty.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        List<Map<String, Object>> selectedResult = new ArrayList<>();
        
        //テスト実行
        Mst131Form form = new Mst131Form();
        form.setSelectedSearchResult(selectedResult);
        target.setForm(form);
        target.kouShin();

        //実施結果Outを取得
        form = target.getForm();

        //想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0029",summaryCaptor_2.getValue());
    }    

    // update_異常_更新処理_更新登録_11-8
    //
    // -------------------テスト条件--------------------------
    // 仕向地名コード = ああああ
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_11_8 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Boolean> datasCaptor_3 = ArgumentCaptor.forClass(Boolean.class);
        ArgumentCaptor<List> checksCaptor_4 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<List> checksCaptor_5 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean2 = new MessageModuleBean();
        List<MessageModuleBean> msgList = new ArrayList<>();
        msgList.add(messageModuleBean2);

        when(listCheckBean.check(checksCaptor_4.capture(), checksCaptor_5.capture(), datasCaptor_3.capture()))
                .thenReturn(msgList); 

        //テスト実行
        Mst131Form form = new Mst131Form();
        //行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setForm(form);
        target.kouShin();

        //実施結果Outを取得
        form = target.getForm();

}    
   

    // rirekiIchiran_正常_更新履歴コンテキストメニュー_13-1
    //
    // -------------------テスト条件--------------------------
    // 正常に取得された場合
    // -----------------------------------------------------
    @Test
    public void rirekiIchiran_正常_更新履歴コンテキストメニュー_13_1 () throws IllegalAccessException, 
            InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> titleFlgCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> searchKeyCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(rirekiSyosaiBean).searchList(titleFlgCaptor_1.capture(),functionCodeCaptor_2.capture()
                ,searchKeyCaptor_3.capture());
        //テスト実行
        Mst131Form form = new Mst131Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setForm(form);
        target.rirekiIchiran();

        //実施結果Outを取得
        form = target.getForm();

        //想定通りに履歴を表示する。
        assertEquals("2",titleFlgCaptor_1.getValue());
        assertEquals("MST131_SEARCH_RIREKI",functionCodeCaptor_2.getValue());
        assertEquals("listShiiresakiCd0", searchKeyCaptor_3.getValue().get("conShiiresakiCd"));
        assertEquals("listTekiyoKaishibi0", searchKeyCaptor_3.getValue().get("conTekiyoBi"));
    }    

    // searchChange_正常_補充ケース_14-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void searchChange_正常_補充ケース_14_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst131Form form = new Mst131Form();
        target.setForm(form);
        target.searchChange();

        //実施結果Outを取得
        form = target.getForm();

    }

    // menuClick_正常_補充ケース_14-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_14_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst131Form form = new Mst131Form();
        target.setForm(form);
        target.menuClick("","");

        //実施結果Outを取得
        form = target.getForm();

    }

    // menuClick_正常_補充ケース_14-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_14_2_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(1);

        //テスト実行
        Mst131Form form = new Mst131Form();
        target.setForm(form);
        target.menuClick("","");

        //実施結果Outを取得
        form = target.getForm();

    }    
    
    // breadClumClick_正常_補充ケース_14-3
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_14_3 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst131Form form = new Mst131Form();
        target.setForm(form);
        target.breadClumClick("",0);

        //実施結果Outを取得
        form = target.getForm();

    }

    // breadClumClick_正常_補充ケース_14-3_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_14_3_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(0);        
        
        //テスト実行
        Mst131Form form = new Mst131Form();
        target.setForm(form);
        target.breadClumClick("",0);

        //実施結果Outを取得
        form = target.getForm();

    }    
    
    // logoutClick_正常_補充ケース_14-4
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void logoutClick_正常_補充ケース_14_4 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst131Form form = new Mst131Form();
        target.setForm(form);
        target.logoutClick();

        //実施結果Outを取得
        form = target.getForm();

    }

    /**
     * 正常に画面
     */
    @Test
    public void detailClick_case_11_1() throws IllegalAccessException, InvocationTargetException, SystemException {
        Flash flash = new FlashKls();
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        when(flashUtil.getPageParam()).thenReturn(flash);
        boolean btnFlg = true;
        Mst131Form form = new Mst131Form();
        List<Map<String, Object>> searchResult = new ArrayList<>();
        target.setPageCommon(pageCommonBean);
        Map<String, Object> map = new HashMap<>();
        map.put("conShiiresakiCd", "000123");
        searchResult.add(map);
        form.setSelectedSearchResult(searchResult);
        target.setForm(form);
        target.detailClick(btnFlg);

}
    
    @Test
    public void detailClick_選択しない_11_2() throws IllegalAccessException, InvocationTargetException, SystemException {
        Flash flash = new FlashKls();
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        when(flashUtil.getPageParam()).thenReturn(flash);
        boolean btnFlg = true;
        Mst131Form form = new Mst131Form();
        form.setSelectedSearchResult(null);
        target.setForm(form);
        String url = target.detailClick(btnFlg);

}
   /**
    *申請処理
    */ 
    @Test
    public void shinsei_case_12_1(){
        Mst131Form form = new Mst131Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setForm(form);
        target.shinsei();
    }

    @Test
    public void buttonClick_case_13_1() throws IllegalAccessException, InvocationTargetException, SystemException{
        Flash flash = new FlashKls();
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        when(flashUtil.getPageParam()).thenReturn(flash);
        target.setPageCommon(pageCommonBean);
        String url= target.buttonClick();

    }


    @Test
    public void linkClick_case_14_1() throws SystemException{
        Flash flash = new FlashKls();
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        when(flashUtil.getPageParam()).thenReturn(flash);
        target.setPageCommon(pageCommonBean);
        String url = target.linkClick("01", "TT1", "営業所", "01", "000123", "2019/03/01", "管轄会社", "2019/03/01");

   
    }
 
    @Test
    public void deleteShimukeList_NotNull_15_1(){
        Mst131Form form = new Mst131Form();
        List<Map<String, Object>> searchResult = new ArrayList<>();
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=0;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        target.setPageCommon(pageCommonBean);
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
            .thenReturn(serviceInterfaceBean);

        Map<String, Object> map = new HashMap<>();
        map.put("conShiiresakiCd", "000123");
        searchResult.add(map);
        form.setSelectedSearchResult(searchResult);
        target.setForm(form);
        KbnModuleBean kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnMei("削除");
        KbnModuleBean kbnModuleBean1 = new KbnModuleBean();
        kbnModuleBean1.setKbnMei("適用終了");
        
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_SAKUJO")).thenReturn(kbnModuleBean);
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_TEKIYO_SHURYO")).thenReturn(kbnModuleBean1);
        when(pageCommonBean.accsessDBWithList(form.getSelectedSearchResult(),
                "deleterow")).thenReturn(serviceInterfaceBean);
        serviceInterfaceBean.addMessage(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COME0029, "01");
        target.deleteShimukeList();
    }
    
    @Test
    public void deleteShimukeList_IsNull_15_2(){
        Mst131Form form = new Mst131Form();
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=0;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        target.setPageCommon(pageCommonBean);
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
            .thenReturn(serviceInterfaceBean);
        
        List<Map<String, Object>> searchResult = new ArrayList<>();
        KbnModuleBean kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnMei("削除");
        KbnModuleBean kbnModuleBean1 = new KbnModuleBean();
        kbnModuleBean1.setKbnMei("適用終了");
        
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_SAKUJO")).thenReturn(kbnModuleBean);
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_TEKIYO_SHURYO")).thenReturn(kbnModuleBean1);
        target.setPageCommon(pageCommonBean);
        Map<String, Object> map = new HashMap<>();
        map.put("conShiiresakiCd", "000123");
        searchResult.add(map);
        form.setSelectedSearchResult(searchResult);
        target.setForm(form);
        when(pageCommonBean.accsessDBWithList(form.getSelectedSearchResult(),
                "deleterow")).thenReturn(serviceInterfaceBean);
        serviceInterfaceBean = null;
        target.deleteShimukeList();
    }
    

    @Test     
    public void subSearchConHad_カナ名称_16_1(){
         // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        KbnModuleBean kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnMei("削除");
        KbnModuleBean kbnModuleBean1 = new KbnModuleBean();
        kbnModuleBean1.setKbnMei("適用終了");
        
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_SAKUJO")).thenReturn(kbnModuleBean);
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_TEKIYO_SHURYO")).thenReturn(kbnModuleBean1);

        //テスト実行
        Mst131Form form = new Mst131Form();
        AutoCompOptionBean conTodofuken = new AutoCompOptionBean();
        conTodofuken.setValue("conTodofuken1");
        form.setConTodofuken(conTodofuken);
         List<String> kankatsuKbn = new ArrayList<>();
        kankatsuKbn.add("01");
        // カナ名
        form.setConKanaMeisho("カナ");
        // 管轄区分
        form.setConKankatsuKbn(kankatsuKbn);
        // 削除済のみ
        form.setConSakujoSumiNomi(null);
        // 使用区分
        List<String> shiyouKbn = new ArrayList<>();
        shiyouKbn.add("1");
        form.setConShiyoKbn(shiyouKbn);
        // 世代検索条件
        List<String> seidaiKensakuJyoken = new ArrayList<>();
        seidaiKensakuJyoken.add("05");
        form.setConSedaiKensakuJoken(seidaiKensakuJyoken);
        target.setForm(form);
        target.count(false);
        form = target.getForm();
        assertEquals("カナ", form.getConKanaMeisho());
    }
    
    @Test
    public void subSearchConHad_適用日_16_2(){
         // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        KbnModuleBean kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnMei("削除");
        KbnModuleBean kbnModuleBean1 = new KbnModuleBean();
        kbnModuleBean1.setKbnMei("適用終了");
        
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_SAKUJO")).thenReturn(kbnModuleBean);
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_TEKIYO_SHURYO")).thenReturn(kbnModuleBean1);

        //テスト実行
        Mst131Form form = new Mst131Form();
        AutoCompOptionBean conTodofuken = new AutoCompOptionBean();
        conTodofuken.setValue("conTodofuken1");
        form.setConTodofuken(conTodofuken);
         List<String> kankatsuKbn = new ArrayList<>();
        kankatsuKbn.add("01");

        // 適用日
        form.setConTekiyoBi("2019/03/01");
        // 管轄区分
        form.setConKankatsuKbn(kankatsuKbn);
        // 削除済のみ
        form.setConSakujoSumiNomi(null);
        // 使用区分
        List<String> shiyouKbn = new ArrayList<>();
        shiyouKbn.add("1");
        form.setConShiyoKbn(shiyouKbn);

        target.setForm(form);
        target.count(false);
        form = target.getForm();
        assertEquals("2019/03/01", form.getConTekiyoBi());
    }
  
    @Test
    public void subSearchConHad_削除のみ_16_3(){
         // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        KbnModuleBean kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnMei("削除");
        KbnModuleBean kbnModuleBean1 = new KbnModuleBean();
        kbnModuleBean1.setKbnMei("適用終了");
        
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_SAKUJO")).thenReturn(kbnModuleBean);
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_TEKIYO_SHURYO")).thenReturn(kbnModuleBean1);

        //テスト実行
        Mst131Form form = new Mst131Form();
        AutoCompOptionBean conTodofuken = new AutoCompOptionBean();
        conTodofuken.setValue("conTodofuken1");
        form.setConTodofuken(conTodofuken);
         List<String> kankatsuKbn = new ArrayList<>();
        kankatsuKbn.add("01");
        // 削除のみ
        List<String> sakujyo = new ArrayList<>();
        sakujyo.add("1");
        form.setConSakujoSumiNomi(sakujyo);
        // 管轄区分
        form.setConKankatsuKbn(kankatsuKbn);

        // 使用区分
        List<String> shiyouKbn = new ArrayList<>();
        shiyouKbn.add("1");
        form.setConShiyoKbn(shiyouKbn);

        target.setForm(form);
        target.count(false);
        form = target.getForm();
        assertEquals(null, form.getConTekiyoBi());
    }
    
    @Test
    public void subSearchConHad_申請状況_16_4(){
         // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        KbnModuleBean kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnMei("削除");
        KbnModuleBean kbnModuleBean1 = new KbnModuleBean();
        kbnModuleBean1.setKbnMei("適用終了");
        
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_SAKUJO")).thenReturn(kbnModuleBean);
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_TEKIYO_SHURYO")).thenReturn(kbnModuleBean1);

        //テスト実行
        Mst131Form form = new Mst131Form();
        AutoCompOptionBean conTodofuken = new AutoCompOptionBean();
        conTodofuken.setValue("conTodofuken1");
        form.setConTodofuken(conTodofuken);
         List<String> kankatsuKbn = new ArrayList<>();
        kankatsuKbn.add("01");

        // 申請状況
        List<String> shinseiJyokyo = new ArrayList<>();
        shinseiJyokyo.add("02");
        shinseiJyokyo.add("03");
        form.setConShinseiJokyo(shinseiJyokyo);
        // 使用区分
        List<String> shiyouKbn = new ArrayList<>();
        shiyouKbn.add("1");
        form.setConShiyoKbn(shiyouKbn);

        target.setForm(form);
        target.count(false);
        form = target.getForm();
        assertEquals(null, form.getConTekiyoBi());
    }

    @Test
    public void subSearchConHad_都道府県_16_5(){
         // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        KbnModuleBean kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnMei("削除");
        KbnModuleBean kbnModuleBean1 = new KbnModuleBean();
        kbnModuleBean1.setKbnMei("適用終了");
        
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_SAKUJO")).thenReturn(kbnModuleBean);
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_TEKIYO_SHURYO")).thenReturn(kbnModuleBean1);

        //テスト実行
        Mst131Form form = new Mst131Form();
        AutoCompOptionBean conTodofuken = new AutoCompOptionBean();
        conTodofuken.setValue("conTodofuken1");
        form.setConTodofuken(conTodofuken);

        target.setForm(form);
        target.count(false);
        form = target.getForm();
        assertEquals(conTodofuken, form.getConTodofuken());
    }

    @Test
    public void subSearchConHad_住所_16_6(){
         // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        KbnModuleBean kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnMei("削除");
        KbnModuleBean kbnModuleBean1 = new KbnModuleBean();
        kbnModuleBean1.setKbnMei("適用終了");
        
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_SAKUJO")).thenReturn(kbnModuleBean);
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_TEKIYO_SHURYO")).thenReturn(kbnModuleBean1);

        //テスト実行
        Mst131Form form = new Mst131Form();
        form.setConJusho("東京");
        target.setForm(form);
        target.count(false);
        form = target.getForm();
        assertEquals("東京", form.getConJusho());
    }

    @Test
    public void 未使用期間_年_16_7(){
         // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        KbnModuleBean kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnMei("削除");
        KbnModuleBean kbnModuleBean1 = new KbnModuleBean();
        kbnModuleBean1.setKbnMei("適用終了");
        
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_SAKUJO")).thenReturn(kbnModuleBean);
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_TEKIYO_SHURYO")).thenReturn(kbnModuleBean1);

        //テスト実行
        Mst131Form form = new Mst131Form();
        form.setConMishiyoKikanNen(1);
        target.setForm(form);
        target.count(false);
        form = target.getForm();
        assertEquals(1, form.getConMishiyoKikanNen());
    }

    @Test
    public void 未使用期間_月_16_7(){
         // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        KbnModuleBean kbnModuleBean = new KbnModuleBean();
        kbnModuleBean.setKbnMei("削除");
        KbnModuleBean kbnModuleBean1 = new KbnModuleBean();
        kbnModuleBean1.setKbnMei("適用終了");
        
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_SAKUJO")).thenReturn(kbnModuleBean);
        when(kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_TEKIYO_SHURYO")).thenReturn(kbnModuleBean1);

        //テスト実行
        Mst131Form form = new Mst131Form();
        form.setConMishiyoKikanTsuki(1);
        target.setForm(form);
        target.count(false);
        form = target.getForm();
        assertEquals(1, form.getConMishiyoKikanTsuki());
    }


    private Map<String, String> createRecMapFor_1_1(int i) {
        Map recMap = new HashMap();
        recMap.put("listKankatsuKbn", "listKankatsuKbn" + i);
        recMap.put("listEigyoshoMei", "listEigyoshoMei" + i);
        recMap.put("listShiiresakiCd", "listShiiresakiCd" + i);
        recMap.put("listTekiyoKaishibi", "1553011200");
        recMap.put("listShiiresakiJusho", "listShiiresakiJusho" + i);
        recMap.put("listSsShiiresakiCd", "listSsShiiresakiCd" + i);
        recMap.put("listKokuGaishaFlg", "listKokuGaishaFlg" + i);
        recMap.put("listDairitenFlg", "listDairitenFlg" + i);
        recMap.put("listKansenGyoshaFlg", "listKansenGyoshaFlg" + i);
        recMap.put("listChukeiGyoshaFlg", "listChukeiGyoshaFlg" + i);
        recMap.put("listCharterGyoshaFlg", "listCharterGyoshaFlg" + i);
        recMap.put("listSonotaFlg", "listSonotaFlg" + i);
        recMap.put("listSaishuShiyobi", "1553011200");
        recMap.put("listShinseiStatus", "listShinseiStatus" + i);
        return recMap;
    }


    private Map<String, Object> createRecMapFor_11_1(int i) {
        Map recMap = new HashMap();
        recMap.put("listKankatsuKbn", "listKankatsuKbn" + i);
        recMap.put("listEigyoshoMei", "listEigyoshoMei" + i);
        recMap.put("listShiiresakiCd", "listShiiresakiCd" + i);
        recMap.put("listTekiyoKaishibi", "listTekiyoKaishibi" + i);
        recMap.put("listShiiresakiJusho", "listShiiresakiJusho" + i);
        recMap.put("listSsShiiresakiCd", "listSsShiiresakiCd" + i);
        recMap.put("listKokuGaishaFlg", "listKokuGaishaFlg" + i);
        recMap.put("listDairitenFlg", "listDairitenFlg" + i);
        recMap.put("listKansenGyoshaFlg", "listKansenGyoshaFlg" + i);
        recMap.put("listChukeiGyoshaFlg", "listChukeiGyoshaFlg" + i);
        recMap.put("listCharterGyoshaFlg", "listCharterGyoshaFlg" + i);
        recMap.put("listSonotaFlg", "listSonotaFlg" + i);
        recMap.put("listSaishuShiyobi", "listSaishuShiyobi" + i);
        recMap.put("listShinseiStatus", "listShinseiStatus" + i);
        if (i == 0) {
            recMap.put("addFlg", true);
        }
        return recMap;
    }
    
    private void assertForRecList_2_1(Mst131Form form) {
        int i = 0;
        assertEquals(1, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listKankatsuKbn" + i, rec.get("listKankatsuKbn"));
            assertEquals("listEigyoshoMei" + i, rec.get("listEigyoshoMei"));
            assertEquals("listShiiresakiCd" + i, rec.get("listShiiresakiCd"));
            assertEquals("listTekiyoKaishibi" + i, rec.get("listTekiyoKaishibi"));
            assertEquals("listShiiresakiJusho" + i, rec.get("listShiiresakiJusho"));
            assertEquals("listSsShiiresakiCd" + i, rec.get("listSsShiiresakiCd"));
            assertEquals("listKokuGaishaFlg" + i, rec.get("listKokuGaishaFlg"));
            assertEquals("listDairitenFlg" + i, rec.get("listDairitenFlg"));
            assertEquals("listKansenGyoshaFlg" + i, rec.get("listKansenGyoshaFlg"));
            assertEquals("listChukeiGyoshaFlg" + i, rec.get("listChukeiGyoshaFlg"));
            assertEquals("listCharterGyoshaFlg" + i, rec.get("listCharterGyoshaFlg"));
            assertEquals("listSonotaFlg" + i, rec.get("listSonotaFlg"));
            assertEquals("listSaishuShiyobi" + i, rec.get("listSaishuShiyobi"));
            assertEquals("listShinseiStatus" + i, rec.get("listShinseiStatus"));
            i++;
        }
    }    

    private void assertForRecList_2_2(Mst131Form form) {
        int i = 0;
        assertEquals(2, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listKankatsuKbn" + i, rec.get("listKankatsuKbn"));
            assertEquals("listEigyoshoMei" + i, rec.get("listEigyoshoMei"));
            assertEquals("listShiiresakiCd" + i, rec.get("listShiiresakiCd"));
            assertEquals("listTekiyoKaishibi" + i, rec.get("listTekiyoKaishibi"));
            assertEquals("listShiiresakiJusho" + i, rec.get("listShiiresakiJusho"));
            assertEquals("listSsShiiresakiCd" + i, rec.get("listSsShiiresakiCd"));
            assertEquals("listKokuGaishaFlg" + i, rec.get("listKokuGaishaFlg"));
            assertEquals("listDairitenFlg" + i, rec.get("listDairitenFlg"));
            assertEquals("listKansenGyoshaFlg" + i, rec.get("listKansenGyoshaFlg"));
            assertEquals("listChukeiGyoshaFlg" + i, rec.get("listChukeiGyoshaFlg"));
            assertEquals("listCharterGyoshaFlg" + i, rec.get("listCharterGyoshaFlg"));
            assertEquals("listSonotaFlg" + i, rec.get("listSonotaFlg"));
            assertEquals("listSaishuShiyobi" + i, rec.get("listSaishuShiyobi"));
            assertEquals("listShinseiStatus" + i, rec.get("listShinseiStatus"));
            i++;
        }
    }      

    private void assertForRecList_2_3(Mst131Form form) {
        int i = 0;
        assertEquals(0, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listKankatsuKbn" + i, rec.get("listKankatsuKbn"));
            assertEquals("listEigyoshoMei" + i, rec.get("listEigyoshoMei"));
            assertEquals("listShiiresakiCd" + i, rec.get("listShiiresakiCd"));
            assertEquals("listTekiyoKaishibi" + i, rec.get("listTekiyoKaishibi"));
            assertEquals("listShiiresakiJusho" + i, rec.get("listShiiresakiJusho"));
            assertEquals("listSsShiiresakiCd" + i, rec.get("listSsShiiresakiCd"));
            assertEquals("listKokuGaishaFlg" + i, rec.get("listKokuGaishaFlg"));
            assertEquals("listDairitenFlg" + i, rec.get("listDairitenFlg"));
            assertEquals("listKansenGyoshaFlg" + i, rec.get("listKansenGyoshaFlg"));
            assertEquals("listChukeiGyoshaFlg" + i, rec.get("listChukeiGyoshaFlg"));
            assertEquals("listCharterGyoshaFlg" + i, rec.get("listCharterGyoshaFlg"));
            assertEquals("listSonotaFlg" + i, rec.get("listSonotaFlg"));
            assertEquals("listSaishuShiyobi" + i, rec.get("listSaishuShiyobi"));
            assertEquals("listShinseiStatus" + i, rec.get("listShinseiStatus"));
            i++;
        }
    }
    
}
