/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import jp.co.kintetsuls.common.json.JSONUtil;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.beans.common.SearchHelpNoDownloadBean;
import jp.co.kintetsuls.beans.common.SystemMasterBean;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.forms.mst.Mst042Form;
import jp.co.kintetsuls.utils.FlashUtil;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import org.mockito.Mockito;
import static org.mockito.Mockito.doThrow;

/**
 * 営業所マスタ詳細画面
 *
 * @author 雷珍 (MBP)
 * @version 2019/04/08 新規作成
 */
public class Mst042BeanTest {

    // テストTarget
    @InjectMocks
    private Mst042Bean target;

    // Mockitoオブジェクト
    @Mock
    private AutoCompleteViewBean autoCompleteViewBean;
    @Mock
    private MessageModuleBean message;
    @Mock
    private MessagePropertyBean messagePropertyBean;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private AuthorityConfBean authConfBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosaiBean;
    @Mock
    private FlashUtil flashUtil;
    @Mock
    private BaseBean baseBean;
    @Mock
    private SearchHelpNoDownloadBean searchHelpNoDownloadBean;
    @Mock
    private SystemMasterBean systemMasterBean;
    @Mock
    private SearchHelpBean searchHelpBean;
    
    public Mst042BeanTest() {
    }

    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() {
    }
    
    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[not null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst042Form mst042Form = new Mst042Form();
        
        //前画面情報[not null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst042Form);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());

        //テスト実行
        Mst042Form form = new Mst042Form();
        target.setMst042Form(form);
        target.init("","MST042_SCREEN",false);

        //実施結果Outを取得
        form = target.getMst042Form();
        String title = target.getTITLE();
        String url = target.getUrl();
        BreadCrumbBean breadBean = target.getBreadBean();
	SystemMasterBean systemMasterBean = target.getSystemMasterBean();
        AutoCompleteViewBean autoCompleteViewBean = target.getAutoCompleteViewBean();
	AuthorityConfBean authConfBean = target.getAuthorityConfBean();
	MessagePropertyBean messagePropertyBean = target.getMessagePropertyBean();
	PageCommonBean pageCommonBean = target.getPageCommonBean();
	SearchHelpBean searchHelpBean = target.getSearchHelp();
	List<String> subSoshikiMeiList = target.getSubSoshikiMeiList();
        List<String> subSoshikiList = target.getSubSoshikiList();
	String subSoshikiMeiWk = target.getSubSoshikiMeiWk();
        String subSoshikiWk = target.getSubSoshikiWk();
	int maxSeqNo = target.getMaxSeqNo();
	List<Map<String, Object>> eigyoshoOroshiTankaDeleteIchiranList = target.getEigyoshoOroshiTankaDeleteIchiranList();
	List<Map<String, Object>> eigyoshoGroupDeleteIchiranList = target.getEigyoshoGroupDeleteIchiranList();
        Boolean initFlg = target.getInitFlg();
        target.setUrl(url);
        target.setBreadBean(breadBean);
        target.setAutoCompleteViewBean(autoCompleteViewBean);
        target.setAuthorityConfBean(authConfBean);
        target.setSystemMasterBean(systemMasterBean);;
	target.setMessagePropertyBean(messagePropertyBean);
	target.setPageCommonBean(pageCommonBean);
	target.setSearchHelp(searchHelpBean);
        target.setSubSoshikiList(subSoshikiList);
	target.setSubSoshikiMeiList(subSoshikiMeiList);
	target.setSubSoshikiMeiWk(subSoshikiMeiWk);
        target.setSubSoshikiWk(subSoshikiWk);
	target.setEigyoshoOroshiTankaDeleteIchiranList(eigyoshoOroshiTankaDeleteIchiranList);
	target.setEigyoshoGroupDeleteIchiranList(eigyoshoGroupDeleteIchiranList);
	target.setInitFlg(initFlg);
        target.setMaxSeqNo(maxSeqNo);
    }
    
    // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 前回画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst042Form mst042Form = new Mst042Form();
        //前回画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst042Form);
	
	// パラメータキャプチャー
        // Mockitoオブジェクトの予想return値設定
        Flash flash = new FlashKls();
        // 前画面パラメータ
        flash.put("mst042Form", mst042Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);
	
	// パラメータキャプチャー
	ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
	doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());

        //テスト実行
        Mst042Form form = new Mst042Form();
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 適用名
	form.setConTekiyoMei("適用名1");
	// 適用終了
	form.setConTekiyoShuryo(new String[]{});
        target.setMst042Form(form);
        target.init("","",true);

        //実施結果Outを取得
        form = target.getMst042Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst042Form", keyCaptor_1.getValue());
        //想定通りに再検索されること
	assertEquals("search_mst042", keyCaptor_2.getValue());

    }
    
    // init_正常_初期処理_1_3_1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst042Form mst042Form = new Mst042Form();
        
        //前回画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst042Form);
	
	Flash flash = new FlashKls();
        // 前画面パラメータ
        flash.put("mst042Form", mst042Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);
	// パラメータキャプチャー
	ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
	doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        // テスト実行
        Mst042Form form = new Mst042Form();
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	// 営業所コード
	conEigyoshoCd.setValue("001");
	form.setConEigyoshoCd(conEigyoshoCd);
	
        target.setMst042Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        // 実施結果Outを取得
        form = target.getMst042Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst042Form",keyCaptor_1.getValue());
    }
   
    // init_正常_初期処理_1_3_2
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst042Form mst042Form = new Mst042Form();
	
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	mst042Form.setConEigyoshoCd(conEigyoshoCd);
        //前回画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst042Form);
	
	Flash flash = new FlashKls();
        // 前画面パラメータ
        flash.put("mst042Form", mst042Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);
	// パラメータキャプチャー
	ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
	doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        // テスト実行
        Mst042Form form = new Mst042Form();
	
        target.setMst042Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        // 実施結果Outを取得
        form = target.getMst042Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst042Form",keyCaptor_1.getValue());

    }
    
    // init_正常_初期処理_1_3_3
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst042Form mst042Form = new Mst042Form();
	
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	mst042Form.setConEigyoshoCd(conEigyoshoCd);
	// 複写フラグ
	mst042Form.setFukushaFlg("1");
	
        //前回画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst042Form);
	
	Flash flash = new FlashKls();
        // 前画面パラメータ
        flash.put("mst042Form", mst042Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);
	// パラメータキャプチャー
	ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
	doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        // テスト実行
        Mst042Form form = new Mst042Form();
	
        target.setMst042Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        // 実施結果Outを取得
        form = target.getMst042Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst042Form",keyCaptor_1.getValue());

    }
    
    // iinit_正常_初期処理_1_3_4
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        //前画面情報[null]
        doThrow(IllegalAccessException.class).when(pageCommonBean).getPageInfo(keyCaptor_1.capture());

        //テスト実行
        Mst042Form form = new Mst042Form();
        target.setMst042Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        //実施結果Outを取得
        form = target.getMst042Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst042Form",keyCaptor_1.getValue());

    }
    
    // search_正常_検索処理_2_1
    //
    // -------------------テスト条件--------------------------
    // 営業所検索結果一覧取得
    // 適用開始日 = "2018/06/05"
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_1 () throws IllegalAccessException, InvocationTargetException, SystemException {
    
	// テスト実行
	Mst042Form form = new Mst042Form();
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	target.setMst042Form(form);
	target.searchEigyoshoInfo();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }
    
    // search_正常_検索処理_2_2
    //
    // -------------------テスト条件--------------------------
    // 営業所検索結果一覧取得
    // 営業所コード = "null"
    // 適用開始日 = ""
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_2() throws IllegalAccessException, InvocationTargetException, SystemException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// サブ組織名リスト
	AutoCompOptionBean subsoshiMeiBean = new AutoCompOptionBean();
	subsoshiMeiBean.setValue("subsoshiMeiBean");
	List<AutoCompOptionBean> subsoshiMeiBeanList = new ArrayList();
	subsoshiMeiBeanList.add(subsoshiMeiBean);
  
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue(null);
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("");
	target.setMst042Form(form);
	target.searchEigyoshoInfo();
	
	// 実施結果Outを取得
	form = target.getMst042Form();

    }  
    
    // search_異常_検索処理_2_3
    //
    // -------------------テスト条件--------------------------
    // 営業所検索結果一覧取得 
    // 営業所コード = "001"
    // 適用開始日 = "2018/06/05"
    // 適用名 = "適用名1"
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_3() throws IllegalAccessException, InvocationTargetException, SystemException {

	
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
      
        // 営業所検索結果一覧取得 件数 = 1
	List<Map<String, Object>> result= new ArrayList();
	
	serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),
                functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setMaxRows("10");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
	// テスト実行
	Mst042Form form = new Mst042Form();
  
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 適用名
	form.setConTekiyoMei("適用名1");
	
	target.setMst042Form(form);
	target.searchEigyoshoInfo();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
	
	//想定通りに仕向地名マスタ一覧を表示されること
	assertForRecList_2_2(form);
    }  

    // searchJusho_正常_検索処理_2-4
    //
    // -------------------テスト条件--------------------------
    // 営業所検索結果一覧取得
    // 営業所コード = "001"
    // 適用開始日 = "2018/06/05"
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_4 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

	// Mockitoオブジェクトの予想return値設定
	ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
	// 営業所検索結果一覧取得 取得件数 = 1
	Map<String, Object> result = new HashMap<>();
	List<String> result1= new ArrayList<>();
	result1.add("123");
	Map<String, Object> resultEigyosho = new HashMap<>();
	// 使用区分
	resultEigyosho.put("knrDtlShiyoKbn", result1);
	// 送り状発行営業所コード
	resultEigyosho.put("knrDtlOkurijoHakkoEigyoshoCd", "123");
	// 送り状発行営業所名
	resultEigyosho.put("knrDtlOkurijoHakkoEigyoshoMei", "123");
	// 経理変換先コード
	resultEigyosho.put("knrDtlKeirisakiHenkanCd", "123");
	// 営業所種別コード
	resultEigyosho.put("knrDtlHEigyoshoShubetsuCd", "123");
	// 承認営業所区分コード
	resultEigyosho.put("knrDtlHShoninEigyoshoKbnCd", "123");
	// 承認区分
	resultEigyosho.put("knrDtlShoninKbn", "1");
	// 郵便番号
	resultEigyosho.put("khnDtlYubinBango", "1234");
	
        result.put("resultEigyosho", resultEigyosho);
	
	serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
		.thenReturn(serviceInterfaceBean);

	// テスト実行
	Mst042Form form = new Mst042Form();
	
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");

	target.setMst042Form(form);
	target.searchEigyoshoInfo();

	// 実施結果Outを取得
	form = target.getMst042Form();
    }
    
    // searchJusho_異常_検索処理_2-5
    //
    // -------------------テスト条件--------------------------
    // 営業所検索結果一覧取得
    // 営業所コード = "001"
    // 適用開始日 = "2018/06/05"
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_5 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

	// Mockitoオブジェクトの予想return値設定
	ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
	// 営業所検索結果一覧取得 取得件数 = 1
	List<Map<String, Object>> resultShoninsha = new ArrayList();
	Map<String, Object> result = new HashMap<>();
	List<String> result1= new ArrayList<>();
	result1.add("123");
	Map<String, Object> resultEigyosho = new HashMap<>();
	Map<String, Object> result3 = new HashMap<>();
	result3.put("resultShoninsha", "resultShoninsha");
	resultShoninsha.add(result3);
	// 使用区分
	resultEigyosho.put("knrDtlShiyoKbn", result1);
	// 送り状発行営業所コード
	resultEigyosho.put("knrDtlOkurijoHakkoEigyoshoCd", null);
	// 送り状発行営業所名
	resultEigyosho.put("knrDtlOkurijoHakkoEigyoshoMei", "123");
	// 経理変換先コード
	resultEigyosho.put("knrDtlKeirisakiHenkanCd", "123");
	// 営業所種別コード
	resultEigyosho.put("knrDtlHEigyoshoShubetsuCd", "123");
	// 承認営業所区分コード
	resultEigyosho.put("knrDtlHShoninEigyoshoKbnCd", "123");
	// 承認区分
	resultEigyosho.put("knrDtlShoninKbn", "1");
	// 郵便番号
	resultEigyosho.put("khnDtlYubinBango", "1234");
	resultEigyosho.put("khnDtlJisCd", "1234");
	// 空港コード	
	resultEigyosho.put("khnDtlKukoCd", "123");
	// 仕向地
	resultEigyosho.put("khnDtlShimukeChi", "123");
	// 銀行口座コード
	resultEigyosho.put("kzaDtlGinkoKozaCd", "1234");
	// 仕立営業所コード
	resultEigyosho.put("orsDtlShitateEigyoshoCd", "1234");
        result.put("resultEigyosho", resultEigyosho);
	result.put("resultShoninsha", resultShoninsha);
	
	serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
		.thenReturn(serviceInterfaceBean);

	// テスト実行
	Mst042Form form = new Mst042Form();
	
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");

	target.setMst042Form(form);
	target.searchEigyoshoInfo();

	// 実施結果Outを取得
	form = target.getMst042Form();
    }
 
    // searchJusho_異常_検索処理_2-6
    //
    // -------------------テスト条件--------------------------
    // 営業所検索結果一覧取得
    // 営業所コード = "001"
    // 適用開始日 = "2018/06/05"
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_6 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

	// Mockitoオブジェクトの予想return値設定
	ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
	// 営業所検索結果一覧取得 取得件数 = 1
	List<Map<String, Object>> resultShoninsha = new ArrayList();
	Map<String, Object> result3 = new HashMap<>();
	result3.put("resultShoninsha", "resultShoninsha");
	resultShoninsha.add(result3);
	Map<String, Object> result = new HashMap<>();
	List<String> result1= new ArrayList<>();
	result1.add("123");
	Map<String, Object> resultEigyosho = new HashMap<>();
	// 使用区分
	resultEigyosho.put("knrDtlShiyoKbn", result1);
	// 送り状発行営業所コード
	resultEigyosho.put("knrDtlOkurijoHakkoEigyoshoCd", null);

	// 仕立営業所コード
	resultEigyosho.put("orsDtlShitateEigyoshoCd", "1234");
	// 一見顧客登録フラグ
	resultEigyosho.put("dtlHIchigenKokyakuTorokuFlg", "0");
	// 社内便登録フラグ
	resultEigyosho.put("dtlHShanaiBinTorokuFlg", "0");	
	// 着払代引登録フラグ
	resultEigyosho.put("dtlHChakubaraiDaibikiTorokuFlg", "0");
	
        result.put("resultEigyosho", resultEigyosho);
	// 承認者情報リスト
	result.put("resultShoninsha", resultShoninsha);
	// 営業所グループ情報リスト
	result.put("resultGroup", resultShoninsha);
	// 卸単価情報リスト
	result.put("resultOroshiTanka", resultShoninsha);
        
	serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
		.thenReturn(serviceInterfaceBean);

	// テスト実行
	Mst042Form form = new Mst042Form();
	
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 起動モード区分
        form.setModeKbn("1");
	
	target.setMst042Form(form);
	target.setInitFlg(false);
	target.searchEigyoshoInfo();

	// 実施結果Outを取得
	form = target.getMst042Form();
    }
    
    // searchJusho_異常_検索処理_2-7
    //
    // -------------------テスト条件--------------------------
    // 営業所検索結果一覧取得
    // 営業所コード = "001"
    // 適用開始日 = "2018/06/05"
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_7 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

	// Mockitoオブジェクトの予想return値設定
	ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
	// 営業所検索結果一覧取得 取得件数 = 1
	List<Map<String, Object>> resultShoninsha = new ArrayList();
	Map<String, Object> result3 = new HashMap<>();
	result3.put("resultShoninsha", "resultShoninsha");
	resultShoninsha.add(result3);
	Map<String, Object> result = new HashMap<>();
	List<String> result1= new ArrayList<>();
	result1.add("123");
	Map<String, Object> resultEigyosho = new HashMap<>();
	// 使用区分
	resultEigyosho.put("knrDtlShiyoKbn", result1);
	// 送り状発行営業所コード
	resultEigyosho.put("knrDtlOkurijoHakkoEigyoshoCd", null);

	// 仕立営業所コード
	resultEigyosho.put("orsDtlShitateEigyoshoCd", "1234");
	// 一見顧客登録フラグ
	resultEigyosho.put("dtlHIchigenKokyakuTorokuFlg", "1");
	// 社内便登録フラグ
	resultEigyosho.put("dtlHShanaiBinTorokuFlg", "0");	
	// 着払代引登録フラグ
	resultEigyosho.put("dtlHChakubaraiDaibikiTorokuFlg", "0");
	resultEigyosho.put("maxSeqNo", "123");
	
        result.put("resultEigyosho", resultEigyosho);
	// 承認者情報リスト
	result.put("resultShoninsha", resultShoninsha);
	// 営業所グループ情報リスト
	result.put("resultGroup", resultShoninsha);
	// 卸単価情報リスト
	result.put("resultOroshiTanka", resultShoninsha);
        
	serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
		.thenReturn(serviceInterfaceBean);

	// テスト実行
	Mst042Form form = new Mst042Form();
	
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 起動モード区分
        form.setModeKbn("2");
	
	//適用終了日を表示する
	form.setTekiyoShuryobi("2018/06/09");
	target.setMst042Form(form);
	target.setInitFlg(false);
	target.searchEigyoshoInfo();

	// 実施結果Outを取得
	form = target.getMst042Form();
    }
    
    // searchJusho_異常_検索処理_2-8
    //
    // -------------------テスト条件--------------------------
    // 営業所検索結果一覧取得
    // 営業所コード = "001"
    // 適用開始日 = "2018/06/05"
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_8 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

	// Mockitoオブジェクトの予想return値設定
	ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
	// 営業所検索結果一覧取得 取得件数 = 1
	List<Map<String, Object>> resultShoninsha = new ArrayList();
	Map<String, Object> result3 = new HashMap<>();
	result3.put("resultShoninsha", "resultShoninsha");
	resultShoninsha.add(result3);
	Map<String, Object> result = new HashMap<>();
	List<String> result1= new ArrayList<>();
	result1.add("123");
	Map<String, Object> resultEigyosho = new HashMap<>();
	// 使用区分
	resultEigyosho.put("knrDtlShiyoKbn", result1);
	// 送り状発行営業所コード
	resultEigyosho.put("knrDtlOkurijoHakkoEigyoshoCd", null);
	//適用終了日を表示する
	resultEigyosho.put("tekiyoShuryobi", "2018/06/09");

	// 仕立営業所コード
	resultEigyosho.put("orsDtlShitateEigyoshoCd", "1234");
	// 一見顧客登録フラグ
	resultEigyosho.put("dtlHIchigenKokyakuTorokuFlg", "1");
	// 社内便登録フラグ
	resultEigyosho.put("dtlHShanaiBinTorokuFlg", "1");	
	// 着払代引登録フラグ
	resultEigyosho.put("dtlHChakubaraiDaibikiTorokuFlg", "0");
	resultEigyosho.put("maxSeqNo", "123");
	
        result.put("resultEigyosho", resultEigyosho);
	// 承認者情報リスト
	result.put("resultShoninsha", resultShoninsha);
	// 営業所グループ情報リスト
	result.put("resultGroup", resultShoninsha);
	// 卸単価情報リスト
	result.put("resultOroshiTanka", resultShoninsha);
        
	serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
		.thenReturn(serviceInterfaceBean);

	// テスト実行
	Mst042Form form = new Mst042Form();
	
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 起動モード区分
        form.setModeKbn("2");
	
	//適用終了日を表示する
	form.setTekiyoShuryobi("2018/06/09");
	target.setMst042Form(form);
	target.setInitFlg(false);
	target.searchEigyoshoInfo();

	// 実施結果Outを取得
	form = target.getMst042Form();
    }
    
    // searchJusho_異常_検索処理_2-9
    //
    // -------------------テスト条件--------------------------
    // 営業所検索結果一覧取得
    // 営業所コード = "001"
    // 適用開始日 = "2018/06/05"
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_9 () throws IllegalAccessException, InvocationTargetException, SystemException {
	
	// パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_2 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
	
	AutoCompOptionBean subsoshiMeiBean = new AutoCompOptionBean();
	subsoshiMeiBean.setValue("subsoshiMeiBean");
	subsoshiMeiBean.setLabel("subsoshiMeiBean");
	List<AutoCompOptionBean> subsoshiMeiBeanList = new ArrayList();
	subsoshiMeiBeanList.add(subsoshiMeiBean);
	when(autoCompleteViewBean.getValueLabelFromDB(functionCodeCaptor_3.capture(), 
		paramsCaptor_2.capture())).thenReturn(subsoshiMeiBeanList);


        // パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

	// Mockitoオブジェクトの予想return値設定
	ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
	// 営業所検索結果一覧取得 取得件数 = 1
	List<Map<String, Object>> resultShoninsha = new ArrayList();
	Map<String, Object> result3 = new HashMap<>();
	result3.put("resultShoninsha", "resultShoninsha");
	resultShoninsha.add(result3);
	Map<String, Object> result = new HashMap<>();
	List<String> result1= new ArrayList<>();
	result1.add("123");
	Map<String, Object> resultEigyosho = new HashMap<>();
	// 使用区分
	resultEigyosho.put("knrDtlShiyoKbn", result1);
	// 送り状発行営業所コード
	resultEigyosho.put("knrDtlOkurijoHakkoEigyoshoCd", null);
	//適用終了日を表示する
	resultEigyosho.put("tekiyoShuryobi", "2018/06/09");
	// 仕立営業所コード
	resultEigyosho.put("orsDtlShitateEigyoshoCd", "1234");
	// 一見顧客登録フラグ
	resultEigyosho.put("dtlHIchigenKokyakuTorokuFlg", "1");
	// 社内便登録フラグ
	resultEigyosho.put("dtlHShanaiBinTorokuFlg", "1");	
	// 着払代引登録フラグ
	resultEigyosho.put("dtlHChakubaraiDaibikiTorokuFlg", "0");
	resultEigyosho.put("maxSeqNo", "123");
	
        result.put("resultEigyosho", resultEigyosho);
	// 承認者情報リスト
	result.put("resultShoninsha", resultShoninsha);
	// 営業所グループ情報リスト
	result.put("resultGroup", resultShoninsha);
	
        
	serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
		.thenReturn(serviceInterfaceBean);

	// テスト実行
	Mst042Form form = new Mst042Form();
	
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 起動モード区分
        form.setModeKbn("2");
	
	//適用終了日を表示する
	form.setTekiyoShuryobi("2018/06/09");
	target.setMst042Form(form);
	target.setInitFlg(false);
	target.searchEigyoshoInfo();

	// 実施結果Outを取得
	form = target.getMst042Form();
    }
    
    // sakujo_正常_論理削除処理_19_1
    //
    // -------------------テスト条件--------------------------
    // 営業所コード = "001" 
    // 適用開始日 = "2018/06/05"
    // 適用名 = "適用名1"
    // -----------------------------------------------------
    @Test
    public void sakujo_正常_論理削除処理_19_1() throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
	// テスト実行
	Mst042Form form = new Mst042Form();
  
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 適用名
	form.setConTekiyoMei("適用名1");
      
	target.setMst042Form(form);
	target.btnSakujo();
	
	// 実施結果Outを取得
	form = target.getMst042Form();

    }  

    // 正常_削除処理_20_1
    //
    // -------------------テスト条件--------------------------
    // 営業所コード = "001" 
    // 適用開始日 = "2018/06/05"
    // 適用名 = "適用名1"
    // -----------------------------------------------------
    @Test
    public void ronriSakujo_正常_削除処理_20_1() throws IllegalAccessException, InvocationTargetException, SystemException {
	
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
	// テスト実行
	Mst042Form form = new Mst042Form();
  
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 適用名
	form.setConTekiyoMei("適用名1");
      
	target.setMst042Form(form);
	target.btnRonriSakujo();
	
	// 実施結果Outを取得
	form = target.getMst042Form();

    }  
    
    // getTekiyoKaishibi_正常_適用開始日ENTERキー押下_11_1
    //
    // -------------------テスト条件--------------------------
    // 営業所コード = "001" 
    // 適用開始日 = "null"
    // 適用名 = "適用名1"
    // -----------------------------------------------------
    @Test
    public void getTekiyoKaishibi_正常_適用開始日ENTERキー押下_11_1() throws IllegalAccessException, InvocationTargetException, ParseException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 営業所検索結果一覧取得 取得件数 = 0
        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 0; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // テスト実行
        Mst042Form form = new Mst042Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
	// 営業所コード
        form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi(null);
	// 適用名
	form.setConTekiyoMei("適用名1");

        target.setMst042Form(form);
        target.getTekiyoKaishibi();

        // 実施結果Outを取得
        form = target.getMst042Form();

        // 実行時に渡すパラメータの検証
        assertEquals("001", form.getConEigyoshoCd().getValue());
        assertEquals("適用名1", form.getConTekiyoMei());
    }
    
    // getTekiyoKaishibi_正常_適用開始日ENTERキー押下_11_2
    //
    // -------------------テスト条件--------------------------
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "適用名1"
    // -----------------------------------------------------
    @Test
    public void getTekiyoKaishibi_正常_適用開始日ENTERキー押下_11_2() throws IllegalAccessException, InvocationTargetException, ParseException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();

        Map<String, String> result = new HashMap<>();
        result.put("conEigyoshoCd", "001");
	result.put("tekiyoKaishibi", "2019/01/01");
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // テスト実行
        Mst042Form form = new Mst042Form();
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
	// 営業所コード
        form.setConEigyoshoCd(conEigyoshoCd);
	// 適用名
	form.setConTekiyoMei("適用名1");
   
        target.setMst042Form(form);
        target.getTekiyoKaishibi();

        // 実施結果Outを取得
        form = target.getMst042Form();
	
    }
    
    // gbtnBtnDairiShoninUserClick_正常_代理承認者設定ボタン_14_1
    //
    // -------------------テスト条件--------------------------
    // 営業所コード = "001" 
    // 適用開始日 = "null"
    // 適用名 = "適用名1"
    // -----------------------------------------------------
    @Test
    public void gbtnBtnDairiShoninUserClick_正常_代理承認者設定ボタン_14_1() throws IllegalAccessException, InvocationTargetException, ParseException, SystemException {
   
	// パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst042Form mst042Form = new Mst042Form();
	//前回画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst042Form);
	
	// パラメータキャプチャー
        // Mockitoオブジェクトの予想return値設定
        Flash flash = new FlashKls();
        // 前画面パラメータ[都道府県 = 01,仕向地名 = 地名23,削除済のみ検索 = null]
        flash.put("mst042Form", mst042Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        // テスト実行
        Mst042Form form = new Mst042Form();
	// 営業所コード
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用名
	form.setConTekiyoMei("適用名1");
   
        form.setConTekiyoKaishibi(null);
	when(flashUtil.getPageParam()).thenReturn(flash);
	when(pageCommonBean.getPageParam()).thenReturn(flash);
        target.setMst042Form(form);
        target.btnBtnDairiShoninUserClick();

        // 実施結果Outを取得
        form = target.getMst042Form();

        // 実行時に渡すパラメータの検証
        assertEquals("001", form.getConEigyoshoCd().getValue());
        assertEquals("適用名1", form.getConTekiyoMei());
	
    }
    
    // gbtnBtnDairiShoninUserClick_正常_代理承認者設定ボタン_14_2
    //
    // -------------------テスト条件--------------------------
    //  特になし
    // -----------------------------------------------------
    @Test
    public void gbtnBtnDairiShoninUserClick_正常_代理承認者設定ボタン_14_2() throws IllegalAccessException, InvocationTargetException, ParseException, SystemException {
   
        // テスト実行
	Mst042Form form = new Mst042Form();
	target.setMst042Form(form);
	Flash flash = new FlashKls();
	flash.put("mst042form", form);
	when(flashUtil.getPageParam()).thenReturn(flash);
	when(pageCommonBean.getPageParam()).thenReturn(flash);
	target.btnBtnDairiShoninUserClick();

	// 実施結果Outを取得
	form = target.getMst042Form();

    }
    
    // getSubSoshikiMeisho_正常_サブ組織名ENTERキー押下_17_1
    //
    // -------------------テスト条件--------------------------
    // 営業所コード = "001" 
    // 適用名 = "適用名1"
    // -----------------------------------------------------
    @Test
    public void getSubSoshikiMeisho_正常_サブ組織名ENTERキー押下_17_1() throws IllegalAccessException, InvocationTargetException, ParseException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();

        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 0; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));

        doThrow(IOException.class).when(pageCommonBean).getDBInfo(paramsCaptor_1.capture(),
                functionCodeCaptor_2.capture());

        // テスト実行
        Mst042Form form = new Mst042Form();
	// 営業所コード
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
	
	// 適用名
	form.setConTekiyoMei("適用名1");
   
        form.setConTekiyoKaishibi(null);
        target.setMst042Form(form);
        target.getSubSoshikiMeisho(1, conEigyoshoCd, null, "1", "1", "1");

        // 実施結果Outを取得
        form = target.getMst042Form();

    }
    
    // getSubSoshikiMeisho_異常_サブ組織名ENTERキー押下_17_2
    //
    // -------------------テスト条件--------------------------
    // 営業所コード = "001" 
    // 適用名 = "適用名1"
    // -----------------------------------------------------
    @Test
    public void getSubSoshikiMeisho_異常_サブ組織名ENTERキー押下_17_2 () throws IllegalAccessException, InvocationTargetException, ParseException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();

        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 0; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));

        doThrow(IOException.class).when(pageCommonBean).getDBInfo(paramsCaptor_1.capture(),
                functionCodeCaptor_2.capture());

        // テスト実行
        Mst042Form form = new Mst042Form();
	// 営業所コード
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
	
	// 適用名
	form.setConTekiyoMei("適用名1");
   
        form.setConTekiyoKaishibi(null);
        target.setMst042Form(form);
        target.getSubSoshikiMeisho(1, conEigyoshoCd, null, "1", "1", "true");

        // 実施結果Outを取得
        form = target.getMst042Form();

    }
    
    // getSubSoshikiMeisho_異常_サブ組織名ENTERキー押下_17_2
    //
    // -------------------テスト条件--------------------------
    //「はい」ボタンを押下した場合
    // -----------------------------------------------------
    @Test
    public void getSubSoshikiMeisho_異常_サブ組織名ENTERキー押下_17_3() throws IllegalAccessException, InvocationTargetException, ParseException, SystemException {

        // テスト実行
        Mst042Form form = new Mst042Form();
        // サブ組織名リスト
        List<String> subSoshikiMeiList = new ArrayList<>();
        // サブ組織リスト
        List<String> subSoshikiList = new ArrayList<>();
        target.setMst042Form(form);
        target.subSoshikiMeishoCallBack();

        // 実施結果Outを取得
        form = target.getMst042Form();
    }
   
    // getSubSoshikiMeisho_異常_サブ組織名ENTERキー押下_17_4
    //
    // -------------------テスト条件--------------------------
    // 営業所コード = "001"
    // -----------------------------------------------------
    @Test
    public void getSubSoshikiMeisho_異常_サブ組織名ENTERキー押下_17_4 () throws IllegalAccessException, InvocationTargetException, ParseException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();

        List<Map<String, String>> result = new ArrayList<>();
        for (int i = 0; i <= 0; i++) {
            result.add(createRecMapFor_11_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));

        doThrow(IOException.class).when(pageCommonBean).getDBInfo(paramsCaptor_1.capture(),
                functionCodeCaptor_2.capture());

        // テスト実行
        Mst042Form form = new Mst042Form();
	// 営業所コード
        AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
        conEigyoshoCd.setValue("001");
        AutoCompOptionBean option = new AutoCompOptionBean();
	option.setLabel("option");
	option.setValue("option");

        form.setConTekiyoKaishibi(null);
        target.setMst042Form(form);
        target.getSubSoshikiMeisho(1, conEigyoshoCd, option, "1", "1", "true");

        // 実施結果Outを取得
        form = target.getMst042Form();

    }
    
    // koshin_正常_更新処理_18_1
    //
    // -------------------テスト条件--------------------------
    // 更新処理を行う
    // 営業所コード = "001" 
    // 適用開始日 = "2018/06/05"
    // 適用名 = "適用名1"
    // -----------------------------------------------------
    @Test
    public void koshin_正常_更新処理_18_1() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {
	
	// テスト実行
	Mst042Form form = new Mst042Form();
  
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 適用名
	form.setConTekiyoMei("適用名1");

	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();

    }  
    
    // koshin_正常_更新処理_18_2
    //
    // -------------------テスト条件--------------------------
    // 編集ボタン押下処理
    // 営業所コード = "001" 
    // 適用開始日 = "2018/06/05"
    // 適用名 = "適用名1"
    // -----------------------------------------------------
    @Test
    public void koshin_正常_更新処理_18_2() throws IllegalAccessException, InvocationTargetException, SystemException {

	// テスト実行
	Mst042Form form = new Mst042Form();
  
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 適用名
	form.setConTekiyoMei("適用名1");
      
	target.setMst042Form(form);
	target.btnEdit();
	
	// 実施結果Outを取得
	form = target.getMst042Form();

    }  
    
    // koshin_正常_更新処理_18_3
    //
    // -------------------テスト条件--------------------------
    // 新規登録ボタン押下処理
    // 営業所コード = "001" 
    // 適用開始日 = "2018/06/05"
    // 適用名 = "適用名1"
    // -----------------------------------------------------
    @Test
    public void koshin_正常_更新処理_18_3() throws IllegalAccessException, InvocationTargetException, SystemException {

	// テスト実行
	Mst042Form form = new Mst042Form();
  
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 適用名
	form.setConTekiyoMei("適用名1");
      
	target.setMst042Form(form);
	target.btnToroku();
	
	// 実施結果Outを取得
	form = target.getMst042Form();

    }  
    
    // koshin_正常_更新処理_18_4
    //
    // -------------------テスト条件--------------------------
    // 複写登録ボタン押下処理
    // 営業所コード = "001" 
    // 適用開始日 = "2018/06/05"
    // 適用名 = "適用名1"
    // -----------------------------------------------------
    @Test
    public void koshin_正常_更新処理_18_4() throws IllegalAccessException, InvocationTargetException, SystemException {
	
	// テスト実行
	Mst042Form form = new Mst042Form();
  
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 適用名
	form.setConTekiyoMei("適用名1");
	// 適用終了
	form.setConTekiyoShuryo(new String[]{});
      
	target.setMst042Form(form);
	target.btnFukushaToroku();
	
	// 実施結果Outを取得
	form = target.getMst042Form();

    }  
    
    // koshin_正常_更新処理_18_5
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 営業所コード = "001" 
    // 適用開始日 = "2018/06/05"
    // 適用名 = "適用名1"
    // 削除区分 ="1"
    // 適用終了日 = "2019/06/06"
    // -----------------------------------------------------
    @Test
    public void koshin_正常_更新処理_18_5() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
	serviceInterfaceBean.addMessage("111", "111", "111");
	serviceInterfaceBean.setTableName("111");
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), 
                keyCaptor_2.capture())).thenReturn(serviceInterfaceBean);

	// テスト実行
	Mst042Form form = new Mst042Form();
  
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("適用名1");
	// 適用終了日
	form.setConTekiyoKaishibi("2019/06/06");
	// 削除区分
	form.setDeleteKbn("1");
      
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();

    }  
    
    // koshin_正常_更新処理_18_6
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 営業所コード = "001" 
    // 適用開始日 = "2018/06/05"
    // 適用名 = "適用名1"
    // 削除区分 ="1"
    // 適用終了日 = "2019/06/06"
    // -----------------------------------------------------
    @Test
    public void koshin_正常_更新処理_18_6() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

        // パラメータキャプチャー
	ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
	when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),
		functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
	// テスト実行
	Mst042Form form = new Mst042Form();
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 適用名
	form.setConTekiyoMei("適用名1");
	// 削除区分
	form.setDeleteKbn("1");
	// 一見顧客登録フラグ
	form.setDtlHIchigenKokyakuTorokuFlg("1");
	// 社内便登録フラグ
	form.setDtlHShanaiBinTorokuFlg("1");
	// 着払代引登録フラグ
	form.setDtlHChakubaraiDaibikiTorokuFlg("1");
	form.setDeleteKbn("RonriSakujo");
	Map<String, Object> resultEigyoshoInfo = new HashMap();
	resultEigyoshoInfo.put("conEigyoshoCd", conEigyoshoCd);
	resultEigyoshoInfo.put("conTekiyoKaishibi", "2018/06/05");
	resultEigyoshoInfo.put("conTekiyoShuryobi", "2038/12/19 23:59:59");
	resultEigyoshoInfo.put("dtlSakujoFlg", "1");
	resultEigyoshoInfo.put("dtlEigyoshoDataVersion", "1");
	form.setResultEigyoshoInfo(resultEigyoshoInfo);
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_正常_更新処理_18_32
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 営業所コード = "001" 
    // 適用開始日 = "2018/06/05"
    // 適用名 = "適用名1"
    // 削除区分 ="1"
    // 適用終了日 = "2019/06/06"
    // 一見顧客登録フラグ = "1"
    // 社内便登録フラグ = "1"
    // 着払代引登録フラグ = "1"
    // -----------------------------------------------------
    @Test
    public void koshin_正常_更新処理_18_32() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {
	// パラメータキャプチャー
	ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
	when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),
		functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
	// テスト実行
	Mst042Form form = new Mst042Form();
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 適用名
	form.setConTekiyoMei("適用名1");
	// 削除区分
	form.setDeleteKbn("1");
	// 一見顧客登録フラグ
	form.setDtlHIchigenKokyakuTorokuFlg("1");
	// 社内便登録フラグ
	form.setDtlHShanaiBinTorokuFlg("1");
	// 着払代引登録フラグ
	form.setDtlHChakubaraiDaibikiTorokuFlg("1");
	
	Map<String, Object> resultEigyoshoInfo = new HashMap();
	resultEigyoshoInfo.put("conEigyoshoCd", conEigyoshoCd);
	resultEigyoshoInfo.put("conTekiyoKaishibi", "2018/06/05");
	resultEigyoshoInfo.put("conTekiyoShuryobi", "2038/12/19 23:59:59");
	resultEigyoshoInfo.put("dtlSakujoFlg", "1");
	resultEigyoshoInfo.put("dtlEigyoshoDataVersion", "1");
	form.setResultEigyoshoInfo(resultEigyoshoInfo);
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
	
    }  
    
    // koshin_異常_更新処理_18_7
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "null" 
    // 適用開始日 = "null"
    // 適用名 = "12345678901234567890123456789012345678901"
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_7() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue(null);
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi(null);
	// 適用名
	form.setConTekiyoMei("12345678901234567890123456789012345678901");
			
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();

    }  
    
    // koshin_異常_更新処理_18_8
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "null" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345678901234567890123456789012345678901"
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_8() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue(null);
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345678901234567890123456789012345678901");
	
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();

    }  
    
    // insertOrUpdate_異常_更新処理_18_9
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_9() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("123456789012345678901234567890123456789012");
	
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_異常_更新処理_18_10
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_10() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789012345678901234567890123456789012");
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_異常_更新処理_18_11
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_11() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("123456789012345678901234567890123456789012");
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_異常_更新処理_18_12
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_12() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123456789012345678901234567890123456789012");
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_異常_更新処理_18_13
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = ""
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_13() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("");
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_異常_更新処理_18_14
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "null"
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_14() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd(null);
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_異常_更新処理_18_15
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "001"
    // 承認区分 = "null"
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_15() throws IllegalAccessException, InvocationTargetException, SystemException ,UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("001");
	// 承認区分
	form.setKnrDtlHShoninEigyoshoKbnCd(null);
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_異常_更新処理_18_16
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "001"
    // 承認区分 = ""
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_16() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("001");
	// 承認区分
	form.setKnrDtlHShoninEigyoshoKbnCd("");
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_異常_更新処理_18_17
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "001"
    // 承認区分 = "002"
    // JISコード = "null"
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_17() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("001");
	// 承認区分
	form.setKnrDtlHShoninEigyoshoKbnCd("002");
	// JISコード
	AutoCompOptionBean khnDtlJisCd = new AutoCompOptionBean();
	khnDtlJisCd.setValue(null);
	form.setKhnDtlJisCd(khnDtlJisCd);
	
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_異常_更新処理_18_18
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "001"
    // 承認区分 = "002"
    // JISコード = "123"
    // 郵便番号 = "12345678"
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_18() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("001");
	// 承認区分
	form.setKnrDtlHShoninEigyoshoKbnCd("002");
	// JISコード
	AutoCompOptionBean khnDtlJisCd = new AutoCompOptionBean();
	khnDtlJisCd.setValue("123");
	form.setKhnDtlJisCd(khnDtlJisCd);
	// 郵便番号
	form.setKhnDtlYubinBango("12345678");
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_異常_更新処理_18_19
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "001"
    // 承認区分 = "002"
    // JISコード = "123"
    // 郵便番号 = "12345678"
    // 住所1 = "null"
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_19() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("001");
	// 承認区分
	form.setKnrDtlHShoninEigyoshoKbnCd("002");
	// JISコード
	AutoCompOptionBean khnDtlJisCd = new AutoCompOptionBean();
	khnDtlJisCd.setValue("123");
	form.setKhnDtlJisCd(khnDtlJisCd);
	// 郵便番号
	form.setKhnDtlYubinBango("1234567");
	// 住所1
	form.setKhnDtlJusho1(null);
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_異常_更新処理_18_20
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "001"
    // 承認区分 = "002"
    // JISコード = "123"
    // 郵便番号 = "12345678"
    // 住所1 = ""
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_20() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("001");
	// 承認区分
	form.setKnrDtlHShoninEigyoshoKbnCd("002");
	// JISコード
	AutoCompOptionBean khnDtlJisCd = new AutoCompOptionBean();
	khnDtlJisCd.setValue("123");
	form.setKhnDtlJisCd(khnDtlJisCd);
	// 郵便番号
	form.setKhnDtlYubinBango("1234567");
	// 住所1
	form.setKhnDtlJusho1("");
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_異常_更新処理_18_21
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "001"
    // 承認区分 = "002"
    // JISコード = "123"
    // 郵便番号 = "12345678"
    // 住所1 = "123456789012345678901234567890123456789012"
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_21() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("001");
	// 承認区分
	form.setKnrDtlHShoninEigyoshoKbnCd("002");
	// JISコード
	AutoCompOptionBean khnDtlJisCd = new AutoCompOptionBean();
	khnDtlJisCd.setValue("123");
	form.setKhnDtlJisCd(khnDtlJisCd);
	// 郵便番号
	form.setKhnDtlYubinBango("1234567");
	// 住所1
	form.setKhnDtlJusho1("123456789012345678901234567890123456789012");
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_正常_更新処理_18_22
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "001"
    // 承認区分 = "002"
    // JISコード = "123"
    // 郵便番号 = "12345678"
    // 住所1 = "123456789012345689012"
    // -----------------------------------------------------
    @Test
    public void koshin_正常_更新処理_18_22() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("001");
	// 承認区分
	form.setKnrDtlHShoninEigyoshoKbnCd("002");
	// JISコード
	AutoCompOptionBean khnDtlJisCd = new AutoCompOptionBean();
	khnDtlJisCd.setValue("123");
	form.setKhnDtlJisCd(khnDtlJisCd);
	// 郵便番号
	form.setKhnDtlYubinBango("1234567");
	// 住所1
	form.setKhnDtlJusho1("123456789012345689012");
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_異常_更新処理_18_23
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "001"
    // 承認区分 = "002"
    // JISコード = "123"
    // 郵便番号 = "12345678"
    // 住所1 = "123456789012345689012"
    // 住所2 ="123456789012345678901234567890123456789012"
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_23() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("001");
	// 承認区分
	form.setKnrDtlHShoninEigyoshoKbnCd("002");
	// JISコード
	AutoCompOptionBean khnDtlJisCd = new AutoCompOptionBean();
	khnDtlJisCd.setValue("123");
	form.setKhnDtlJisCd(khnDtlJisCd);
	// 郵便番号
	form.setKhnDtlYubinBango("1234567");
	// 住所1
	form.setKhnDtlJusho1("123456789012345689012");
	// 住所2
	form.setKhnDtlJusho2("123456789012345678901234567890123456789012");
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_異常_更新処理_18_24
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "001"
    // 承認区分 = "002"
    // JISコード = "123"
    // 郵便番号 = "12345678"
    // 住所1 = "123456789012345689012"
    // 住所2 ="1234567890123456789012"
    // 住所3 = "123456789012345678901234567890123456789012"
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_24() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("001");
	// 承認区分
	form.setKnrDtlHShoninEigyoshoKbnCd("002");
	// JISコード
	AutoCompOptionBean khnDtlJisCd = new AutoCompOptionBean();
	khnDtlJisCd.setValue("123");
	form.setKhnDtlJisCd(khnDtlJisCd);
	// 郵便番号
	form.setKhnDtlYubinBango("1234567");
	// 住所1
	form.setKhnDtlJusho1("123456789012345689012");
	// 住所2
	form.setKhnDtlJusho2("1234567890123456789012");
	// 住所3
	form.setKhnDtlJusho3("123456789012345678901234567890123456789012");
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_異常_更新処理_18_25
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "001"
    // 承認区分 = "002"
    // JISコード = "123"
    // 郵便番号 = "12345678"
    // 住所1 = "123456789012345689012"
    // 住所2 ="1234567890123456789012"
    // 住所3 = "123456780123456789012"
    // 住所4 = "123456789012345678901234567890123456789012"
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_25() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("001");
	// 承認区分
	form.setKnrDtlHShoninEigyoshoKbnCd("002");
	// JISコード
	AutoCompOptionBean khnDtlJisCd = new AutoCompOptionBean();
	khnDtlJisCd.setValue("123");
	form.setKhnDtlJisCd(khnDtlJisCd);
	// 郵便番号
	form.setKhnDtlYubinBango("1234567");
	// 住所1
	form.setKhnDtlJusho1("123456789012345689012");
	// 住所2
	form.setKhnDtlJusho2("1234567890123456789012");
	// 住所3
	form.setKhnDtlJusho3("123456780123456789012");
	// 住所4
	form.setKhnDtlJusho4("123456789012345678901234567890123456789012");
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_異常_更新処理_18_26
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "001"
    // 承認区分 = "002"
    // JISコード = "123"
    // 郵便番号 = "12345678"
    // 住所1 = "123456789012345689012"
    // 住所2 ="1234567890123456789012"
    // 住所3 = "123456780123456789012"
    // 住所4 = "12345678901789012"
    // 空港コード = "null"
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_26() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("001");
	// 承認区分
	form.setKnrDtlHShoninEigyoshoKbnCd("002");
	// JISコード
	AutoCompOptionBean khnDtlJisCd = new AutoCompOptionBean();
	khnDtlJisCd.setValue("123");
	form.setKhnDtlJisCd(khnDtlJisCd);
	// 郵便番号
	form.setKhnDtlYubinBango("1234567");
	// 住所1
	form.setKhnDtlJusho1("123456789012345689012");
	// 住所2
	form.setKhnDtlJusho2("1234567890123456789012");
	// 住所3
	form.setKhnDtlJusho3("123456780123456789012");
	// 住所4
	form.setKhnDtlJusho4("12345678901789012");
	// 空港コード
	AutoCompOptionBean khnDtlKukoCd = new AutoCompOptionBean();
	khnDtlKukoCd.setValue(null);
	form.setKhnDtlKukoCd(khnDtlKukoCd);
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_異常_更新処理_18_27
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "001"
    // 承認区分 = "002"
    // JISコード = "123"
    // 郵便番号 = "12345678"
    // 住所1 = "123456789012345689012"
    // 住所2 ="1234567890123456789012"
    // 住所3 = "123456780123456789012"
    // 住所4 = "12345678901789012"
    // 空港コード = "123"
    // 仕向地 = "null"
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_27() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("001");
	// 承認区分
	form.setKnrDtlHShoninEigyoshoKbnCd("002");
	// JISコード
	AutoCompOptionBean khnDtlJisCd = new AutoCompOptionBean();
	khnDtlJisCd.setValue("123");
	form.setKhnDtlJisCd(khnDtlJisCd);
	// 郵便番号
	form.setKhnDtlYubinBango("1234567");
	// 住所1
	form.setKhnDtlJusho1("123456789012345689012");
	// 住所2
	form.setKhnDtlJusho2("1234567890123456789012");
	// 住所3
	form.setKhnDtlJusho3("123456780123456789012");
	// 住所4
	form.setKhnDtlJusho4("12345678901789012");
	// 空港コード
	AutoCompOptionBean khnDtlKukoCd = new AutoCompOptionBean();
	khnDtlKukoCd.setValue("123");
	form.setKhnDtlKukoCd(khnDtlKukoCd);
	// 仕向地
	AutoCompOptionBean khnDtlShimukeChi = new AutoCompOptionBean();
	khnDtlShimukeChi.setValue(null);
	form.setKhnDtlShimukeChi(khnDtlShimukeChi);
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_異常_更新処理_18_28
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "001"
    // 承認区分 = "002"
    // JISコード = "123"
    // 郵便番号 = "12345678"
    // 住所1 = "123456789012345689012"
    // 住所2 ="1234567890123456789012"
    // 住所3 = "123456780123456789012"
    // 住所4 = "12345678901789012"
    // 空港コード = "123"
    // 仕向地 = "123"
    // 集配地区コード ="null"
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_28() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("001");
	// 承認区分
	form.setKnrDtlHShoninEigyoshoKbnCd("002");
	// JISコード
	AutoCompOptionBean khnDtlJisCd = new AutoCompOptionBean();
	khnDtlJisCd.setValue("123");
	form.setKhnDtlJisCd(khnDtlJisCd);
	// 郵便番号
	form.setKhnDtlYubinBango("1234567");
	// 住所1
	form.setKhnDtlJusho1("123456789012345689012");
	// 住所2
	form.setKhnDtlJusho2("1234567890123456789012");
	// 住所3
	form.setKhnDtlJusho3("123456780123456789012");
	// 住所4
	form.setKhnDtlJusho4("12345678901789012");
	// 空港コード
	AutoCompOptionBean khnDtlKukoCd = new AutoCompOptionBean();
	khnDtlKukoCd.setValue("123");
	form.setKhnDtlKukoCd(khnDtlKukoCd);
	// 仕向地
	AutoCompOptionBean khnDtlShimukeChi = new AutoCompOptionBean();
	khnDtlShimukeChi.setValue("123");
	form.setKhnDtlShimukeChi(khnDtlShimukeChi);
	// 集配地区コード
	form.setKhnDtlShuhaiChikuCd(null);
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_異常_更新処理_18_29
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "001"
    // 承認区分 = "002"
    // JISコード = "123"
    // 郵便番号 = "12345678"
    // 住所1 = "123456789012345689012"
    // 住所2 ="1234567890123456789012"
    // 住所3 = "123456780123456789012"
    // 住所4 = "12345678901789012"
    // 空港コード = "123"
    // 仕向地 = "123"
    // 集配地区コード =""
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_29() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("001");
	// 承認区分
	form.setKnrDtlHShoninEigyoshoKbnCd("002");
	// JISコード
	AutoCompOptionBean khnDtlJisCd = new AutoCompOptionBean();
	khnDtlJisCd.setValue("123");
	form.setKhnDtlJisCd(khnDtlJisCd);
	// 郵便番号
	form.setKhnDtlYubinBango("1234567");
	// 住所1
	form.setKhnDtlJusho1("123456789012345689012");
	// 住所2
	form.setKhnDtlJusho2("1234567890123456789012");
	// 住所3
	form.setKhnDtlJusho3("123456780123456789012");
	// 住所4
	form.setKhnDtlJusho4("12345678901789012");
	// 空港コード
	AutoCompOptionBean khnDtlKukoCd = new AutoCompOptionBean();
	khnDtlKukoCd.setValue("123");
	form.setKhnDtlKukoCd(khnDtlKukoCd);
	// 仕向地
	AutoCompOptionBean khnDtlShimukeChi = new AutoCompOptionBean();
	khnDtlShimukeChi.setValue("123");
	form.setKhnDtlShimukeChi(khnDtlShimukeChi);
	// 集配地区コード
	form.setKhnDtlShuhaiChikuCd("");
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_正常_更新処理_18_30
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "001"
    // 承認区分 = "002"
    // JISコード = "123"
    // 郵便番号 = "12345678"
    // 住所1 = "123456789012345689012"
    // 住所2 ="1234567890123456789012"
    // 住所3 = "123456780123456789012"
    // 住所4 = "12345678901789012"
    // 空港コード = "123"
    // 仕向地 = "123"
    // 集配地区コード ="123"
    // 伝票種別 = "123"
    // 卸単価情報 = "orsDtlListHDempyoShubetsuCd"
    // -----------------------------------------------------
    @Test
    public void koshin_正常_更新処理_18_30() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("001");
	// 承認区分
	form.setKnrDtlHShoninEigyoshoKbnCd("002");
	// JISコード
	AutoCompOptionBean khnDtlJisCd = new AutoCompOptionBean();
	khnDtlJisCd.setValue("123");
	form.setKhnDtlJisCd(khnDtlJisCd);
	// 郵便番号
	form.setKhnDtlYubinBango("1234567");
	// 住所1
	form.setKhnDtlJusho1("123456789012345689012");
	// 住所2
	form.setKhnDtlJusho2("1234567890123456789012");
	// 住所3
	form.setKhnDtlJusho3("123456780123456789012");
	// 住所4
	form.setKhnDtlJusho4("12345678901789012");
	// 空港コード
	AutoCompOptionBean khnDtlKukoCd = new AutoCompOptionBean();
	khnDtlKukoCd.setValue("123");
	form.setKhnDtlKukoCd(khnDtlKukoCd);
	// 仕向地
	AutoCompOptionBean khnDtlShimukeChi = new AutoCompOptionBean();
	khnDtlShimukeChi.setValue("123");
	form.setKhnDtlShimukeChi(khnDtlShimukeChi);
	// 集配地区コード
	form.setKhnDtlShuhaiChikuCd("123");
	// 伝票種別リスト
        List<String> dempyoShubetsuList = new ArrayList<>();
        dempyoShubetsuList.add("123");
	// 卸単価情報リスト
	Map<String, Object> data = new HashMap<>();
	data.put("orsDtlListHDempyoShubetsuCd", "orsInfo1");
	List<Map<String, Object>> datasource = new ArrayList();
	datasource.add(data);
	form.setListOrsDtlSelectable(new ReportListDataModel(datasource));
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }   
    
    // koshin_異常_更新処理_18_31
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "001"
    // 承認区分 = "002"
    // JISコード = "123"
    // 郵便番号 = "12345678"
    // 住所1 = "123456789012345689012"
    // 住所2 ="1234567890123456789012"
    // 住所3 = "123456780123456789012"
    // 住所4 = "12345678901789012"
    // 空港コード = "123"
    // 仕向地 = "123"
    // 集配地区コード ="123"
    // 伝票種別 = "123"
    // 卸単価情報 = "orsDtlListHDempyoShubetsuCd"
    // 新JISコード = "001"
    // 旧住所フラグ = "1"
    // 使用不可フラグ ="0"
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_31() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("001");
	// 承認区分
	form.setKnrDtlHShoninEigyoshoKbnCd("002");
	// JISコード
	AutoCompOptionBean khnDtlJisCd = new AutoCompOptionBean();
	khnDtlJisCd.setValue("123");
	form.setKhnDtlJisCd(khnDtlJisCd);
	// 郵便番号
	form.setKhnDtlYubinBango("1234567");
	// 住所1
	form.setKhnDtlJusho1("123456789012345689012");
	// 住所2
	form.setKhnDtlJusho2("1234567890123456789012");
	// 住所3
	form.setKhnDtlJusho3("123456780123456789012");
	// 住所4
	form.setKhnDtlJusho4("12345678901789012");
	// 空港コード
	AutoCompOptionBean khnDtlKukoCd = new AutoCompOptionBean();
	khnDtlKukoCd.setValue("123");
	form.setKhnDtlKukoCd(khnDtlKukoCd);
	// 仕向地
	AutoCompOptionBean khnDtlShimukeChi = new AutoCompOptionBean();
	khnDtlShimukeChi.setValue("123");
	form.setKhnDtlShimukeChi(khnDtlShimukeChi);
	// 集配地区コード
	form.setKhnDtlShuhaiChikuCd("123");
	// 伝票種別リスト
        List<String> dempyoShubetsuList = new ArrayList<>();
        dempyoShubetsuList.add("123");
	// 卸単価情報リスト
	Map<String, Object> data = new HashMap<>();
	data.put("orsDtlListHDempyoShubeuCd", "orsInfo1");
	List<Map<String, Object>> datasource = new ArrayList();
	datasource.add(data);
	form.setListOrsDtlSelectable(new ReportListDataModel(datasource));
	
	// 営業所グループ情報リスト
	Map<String, Object> egrpDtlListJoiEigyoshoCd = new HashMap<>();
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "orsInfo1");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListMainSoshiki", "true");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", "0001");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", "");
	
	List<Map<String, Object>> data1 = new ArrayList();
	data1.add(egrpDtlListJoiEigyoshoCd);
	form.setListEgrpDtlSelectable(new ReportListDataModel(data1));
	// 上位営業所リスト
	List<String> eigyoshoCdList = new ArrayList<>();
	eigyoshoCdList.add("111");
	eigyoshoCdList.add("161");
	// メイン組織チェックボックスリスト
	List<String> mainSoshikiList = new ArrayList<>();
	mainSoshikiList.add("123");
	mainSoshikiList.add("111");
	mainSoshikiList.add("611");
	// 新JISコード
	form.setDtlHShinJisCd("001");
	// 旧住所フラグ
	form.setDtlHKyuJushoFlg("1");
	// 使用不可フラグ
	form.setDtlHShiyoFukaFlg("0");

	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();

    }  
    
    // koshin_異常_更新処理_18_32
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = "null"
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_32() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);	
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
  
    // koshin_異常_更新処理_18_33
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "001"
    // 承認区分 = "002"
    // JISコード = "123"
    // 郵便番号 = "12345678"
    // 住所1 = "123456789012345689012"
    // 住所2 ="1234567890123456789012"
    // 住所3 = "123456780123456789012"
    // 住所4 = "12345678901789012"
    // 空港コード = "123"
    // 仕向地 = "123"
    // 集配地区コード ="123"
    // 伝票種別 = "123"
    // 卸単価情報 = "orsDtlListHDempyoShubetsuCd"
    // 新JISコード = "001"
    // 旧住所フラグ = "1"
    // 使用不可フラグ ="0"
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_33() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("001");
	// 承認区分
	form.setKnrDtlHShoninEigyoshoKbnCd("002");
	// JISコード
	AutoCompOptionBean khnDtlJisCd = new AutoCompOptionBean();
	khnDtlJisCd.setValue("123");
	form.setKhnDtlJisCd(khnDtlJisCd);
	// 郵便番号
	form.setKhnDtlYubinBango("1234567");
	// 住所1
	form.setKhnDtlJusho1("123456789012345689012");
	// 住所2
	form.setKhnDtlJusho2("1234567890123456789012");
	// 住所3
	form.setKhnDtlJusho3("123456780123456789012");
	// 住所4
	form.setKhnDtlJusho4("12345678901789012");
	// 空港コード
	AutoCompOptionBean khnDtlKukoCd = new AutoCompOptionBean();
	khnDtlKukoCd.setValue("123");
	form.setKhnDtlKukoCd(khnDtlKukoCd);
	// 仕向地
	AutoCompOptionBean khnDtlShimukeChi = new AutoCompOptionBean();
	khnDtlShimukeChi.setValue("123");
	form.setKhnDtlShimukeChi(khnDtlShimukeChi);
	// 集配地区コード
	form.setKhnDtlShuhaiChikuCd("123");
	// 伝票種別リスト
        List<String> dempyoShubetsuList = new ArrayList<>();
        dempyoShubetsuList.add("123");
	// 卸単価情報リスト
	Map<String, Object> data = new HashMap<>();
	data.put("orsDtlListHDempyoShubeuCd", "orsInfo1");
	
	List<Map<String, Object>> datasource = new ArrayList();
	datasource.add(data);
	form.setListOrsDtlSelectable(new ReportListDataModel(datasource));
	
	// 営業所グループ情報リスト
	Map<String, Object> egrpDtlListJoiEigyoshoCd = new HashMap<>();
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "orsInfo1");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListMainSoshiki", "true");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", "0001");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", "");
	
	List<Map<String, Object>> data1 = new ArrayList();
	data1.add(egrpDtlListJoiEigyoshoCd);
	form.setListEgrpDtlSelectable(new ReportListDataModel(data1));
	// 上位営業所リスト
	List<String> eigyoshoCdList = new ArrayList<>();
	eigyoshoCdList.add("111");
	eigyoshoCdList.add("161");
	// メイン組織チェックボックスリスト
	List<String> mainSoshikiList = new ArrayList<>();
	mainSoshikiList.add("123");
	mainSoshikiList.add("111");
	mainSoshikiList.add("611");
	// 新JISコード
	form.setDtlHShinJisCd("001");
	// 旧住所フラグ
	form.setDtlHKyuJushoFlg("1");
	// 使用不可フラグ
	form.setDtlHShiyoFukaFlg("1");

	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();

    }  
    
    // koshin_異常_更新処理_18_34
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "001"
    // 承認区分 = "002"
    // JISコード = "123"
    // 郵便番号 = "12345678"
    // 住所1 = "123456789012345689012"
    // 住所2 ="1234567890123456789012"
    // 住所3 = "123456780123456789012"
    // 住所4 = "12345678901789012"
    // 空港コード = "123"
    // 仕向地 = "123"
    // 集配地区コード ="123"
    // 伝票種別 = "123"
    // 卸単価情報 = "orsDtlListHDempyoShubetsuCd"
    // 新JISコード = "001"
    // 旧住所フラグ = "1"
    // 使用不可フラグ ="0"
    // 登録/更新対象区分 = "0"
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_34() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

	// Mockitoオブジェクトの予想return値設定
	ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
	ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
	// 営業所検索結果一覧取得 取得件数 = 1
	Map<String, Object> result = new HashMap<>();
	List<String> result1= new ArrayList<>();
	result1.add("123");
	Map<String, Object> resultEigyosho = new HashMap<>();
	// 使用区分
	resultEigyosho.put("knrDtlShiyoKbn", result1);
	// 送り状発行営業所コード
	resultEigyosho.put("knrDtlOkurijoHakkoEigyoshoCd", "123");
	// 送り状発行営業所名
	resultEigyosho.put("knrDtlOkurijoHakkoEigyoshoMei", "123");
	// 経理変換先コード
	resultEigyosho.put("knrDtlKeirisakiHenkanCd", "123");
	// 営業所種別コード
	resultEigyosho.put("knrDtlHEigyoshoShubetsuCd", "123");
	// 承認営業所区分コード
	resultEigyosho.put("knrDtlHShoninEigyoshoKbnCd", "123");
	// 承認区分
	resultEigyosho.put("knrDtlShoninKbn", "1");
	// 郵便番号
	resultEigyosho.put("khnDtlYubinBango", "1234");
	
        result.put("resultEigyosho", resultEigyosho);
	result.put("resultShoninsha", "resultShoninsha1");
	result.put("resultGroup", "resultGroup1");
	result.put("resultOroshiTanka", "resultOroshiTanka");
	
	serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
		.thenReturn(serviceInterfaceBean, serviceInterfaceBean2);
	
	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("001");
	// 承認区分
	form.setKnrDtlHShoninEigyoshoKbnCd("002");
	// JISコード
	AutoCompOptionBean khnDtlJisCd = new AutoCompOptionBean();
	khnDtlJisCd.setValue("123");
	form.setKhnDtlJisCd(khnDtlJisCd);
	// 郵便番号
	form.setKhnDtlYubinBango("1234567");
	// 住所1
	form.setKhnDtlJusho1("123456789012345689012");
	// 住所2
	form.setKhnDtlJusho2("1234567890123456789012");
	// 住所3
	form.setKhnDtlJusho3("123456780123456789012");
	// 住所4
	form.setKhnDtlJusho4("12345678901789012");
	// 空港コード
	AutoCompOptionBean khnDtlKukoCd = new AutoCompOptionBean();
	khnDtlKukoCd.setValue("123");
	form.setKhnDtlKukoCd(khnDtlKukoCd);
	// 仕向地
	AutoCompOptionBean khnDtlShimukeChi = new AutoCompOptionBean();
	khnDtlShimukeChi.setValue("123");
	form.setKhnDtlShimukeChi(khnDtlShimukeChi);
	// 集配地区コード
	form.setKhnDtlShuhaiChikuCd("123");
	// 伝票種別リスト
        List<String> dempyoShubetsuList = new ArrayList<>();
        dempyoShubetsuList.add("123");
	// 卸単価情報リスト
	Map<String, Object> data = new HashMap<>();
	data.put("orsDtlListHDempyoShubeuCd", "orsInfo1");
	List<Map<String, Object>> datasource = new ArrayList();
	datasource.add(data);
	form.setListOrsDtlSelectable(new ReportListDataModel(datasource));
	
	// 営業所グループ情報リスト
	Map<String, Object> egrpDtlListJoiEigyoshoCd = new HashMap<>();
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "orsInfo1");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListMainSoshiki", "true");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", "0001");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", "");
	
	List<Map<String, Object>> data1 = new ArrayList();
	data1.add(egrpDtlListJoiEigyoshoCd);
	form.setListEgrpDtlSelectable(new ReportListDataModel(data1));
	// 上位営業所リスト
	List<String> eigyoshoCdList = new ArrayList<>();
	eigyoshoCdList.add("111");
	eigyoshoCdList.add("161");
	// メイン組織チェックボックスリスト
	List<String> mainSoshikiList = new ArrayList<>();
	mainSoshikiList.add("123");
	mainSoshikiList.add("111");
	mainSoshikiList.add("611");
	// 新JISコード
	form.setDtlHShinJisCd("001");
	// 旧住所フラグ
	form.setDtlHKyuJushoFlg("1");
	// 登録/更新対象区分
	form.setEditKbn("0");
	Map<String, Object> data2 = new HashMap<>();
	data.put("orsDtlListHDempyoShubetsuCd", "orsI");
	List<Map<String, Object>> datasource2 = new ArrayList();
	datasource2.add(data2);
	form.setListOrsDtlSelectable(new ReportListDataModel(datasource2));

	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_異常_更新処理_18_35
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "001"
    // 承認区分 = "002"
    // JISコード = "123"
    // 郵便番号 = "12345678"
    // 住所1 = "123456789012345689012"
    // 住所2 ="1234567890123456789012"
    // 住所3 = "123456780123456789012"
    // 住所4 = "12345678901789012"
    // 空港コード = "123"
    // 仕向地 = "123"
    // 集配地区コード ="123"
    // 伝票種別 = "123"
    // 卸単価情報 = "orsDtlListHDempyoShubetsuCd"
    // 新JISコード = "001"
    // 旧住所フラグ = "1"
    // 使用不可フラグ ="0"
    // 登録/更新対象区分 = "1"
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_35() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

	// Mockitoオブジェクトの予想return値設定
	ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
	ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
	// 営業所検索結果一覧取得 取得件数 = 1
	Map<String, Object> result = new HashMap<>();
	List<String> result1= new ArrayList<>();
	result1.add("123");
	Map<String, Object> resultEigyosho = new HashMap<>();
	// 使用区分
	resultEigyosho.put("knrDtlShiyoKbn", result1);
	// 送り状発行営業所コード
	resultEigyosho.put("knrDtlOkurijoHakkoEigyoshoCd", "123");
	// 送り状発行営業所名
	resultEigyosho.put("knrDtlOkurijoHakkoEigyoshoMei", "123");
	// 経理変換先コード
	resultEigyosho.put("knrDtlKeirisakiHenkanCd", "123");
	// 営業所種別コード
	resultEigyosho.put("knrDtlHEigyoshoShubetsuCd", "123");
	// 承認営業所区分コード
	resultEigyosho.put("knrDtlHShoninEigyoshoKbnCd", "123");
	// 承認区分
	resultEigyosho.put("knrDtlShoninKbn", "1");
	// 郵便番号
	resultEigyosho.put("khnDtlYubinBango", "1234");
	
        result.put("resultEigyosho", resultEigyosho);
	result.put("resultShoninsha", "resultShoninsha1");
	result.put("resultGroup", "resultGroup1");
	result.put("resultOroshiTanka", "resultOroshiTanka");
	
	serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
		.thenReturn(serviceInterfaceBean, serviceInterfaceBean2);
	
	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("001");
	// 承認区分
	form.setKnrDtlHShoninEigyoshoKbnCd("002");
	// JISコード
	AutoCompOptionBean khnDtlJisCd = new AutoCompOptionBean();
	khnDtlJisCd.setValue("123");
	form.setKhnDtlJisCd(khnDtlJisCd);
	// 郵便番号
	form.setKhnDtlYubinBango("1234567");
	// 住所1
	form.setKhnDtlJusho1("123456789012345689012");
	// 住所2
	form.setKhnDtlJusho2("1234567890123456789012");
	// 住所3
	form.setKhnDtlJusho3("123456780123456789012");
	// 住所4
	form.setKhnDtlJusho4("12345678901789012");
	// 空港コード
	AutoCompOptionBean khnDtlKukoCd = new AutoCompOptionBean();
	khnDtlKukoCd.setValue("123");
	form.setKhnDtlKukoCd(khnDtlKukoCd);
	// 仕向地
	AutoCompOptionBean khnDtlShimukeChi = new AutoCompOptionBean();
	khnDtlShimukeChi.setValue("123");
	form.setKhnDtlShimukeChi(khnDtlShimukeChi);
	// 集配地区コード
	form.setKhnDtlShuhaiChikuCd("123");
	// 伝票種別リスト
        List<String> dempyoShubetsuList = new ArrayList<>();
        dempyoShubetsuList.add("123");
	// 卸単価情報リスト
	Map<String, Object> data = new HashMap<>();
	data.put("orsDtlListHDempyoShubeuCd", "orsInfo1");
	List<Map<String, Object>> datasource = new ArrayList();
	datasource.add(data);
	form.setListOrsDtlSelectable(new ReportListDataModel(datasource));
	
	// 営業所グループ情報リスト
	Map<String, Object> egrpDtlListJoiEigyoshoCd = new HashMap<>();
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "orsInfo1");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListMainSoshiki", "true");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", "0001");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", "");
	
	List<Map<String, Object>> data1 = new ArrayList();
	data1.add(egrpDtlListJoiEigyoshoCd);
	form.setListEgrpDtlSelectable(new ReportListDataModel(data1));
	// 上位営業所リスト
	List<String> eigyoshoCdList = new ArrayList<>();
	eigyoshoCdList.add("111");
	eigyoshoCdList.add("161");
	// メイン組織チェックボックスリスト
	List<String> mainSoshikiList = new ArrayList<>();
	mainSoshikiList.add("123");
	mainSoshikiList.add("111");
	mainSoshikiList.add("611");
	// 新JISコード
	form.setDtlHShinJisCd("001");
	// 旧住所フラグ
	form.setDtlHKyuJushoFlg("1");
	// 登録/更新対象区分
	form.setEditKbn("1");
	
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_異常_更新処理_18_36
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "001"
    // 承認区分 = "002"
    // JISコード = "123"
    // 郵便番号 = "12345678"
    // 住所1 = "123456789012345689012"
    // 住所2 ="1234567890123456789012"
    // 住所3 = "123456780123456789012"
    // 住所4 = "12345678901789012"
    // 空港コード = "123"
    // 仕向地 = "123"
    // 集配地区コード ="123"
    // 伝票種別 = "123"
    // 卸単価情報 = "orsDtlListHDempyoShubetsuCd"
    // 新JISコード = "001"
    // 旧住所フラグ = "1"
    // 使用不可フラグ ="0"
    // 起動モード区分 = "0"
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_36() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

	// Mockitoオブジェクトの予想return値設定
	ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
	ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
	// 営業所検索結果一覧取得 取得件数 = 1
	Map<String, Object> result = new HashMap<>();
	List<String> result1= new ArrayList<>();
	result1.add("123");
	Map<String, Object> resultEigyosho = new HashMap<>();
	// 使用区分
	resultEigyosho.put("knrDtlShiyoKbn", result1);
	// 送り状発行営業所コード
	resultEigyosho.put("knrDtlOkurijoHakkoEigyoshoCd", "123");
	// 送り状発行営業所名
	resultEigyosho.put("knrDtlOkurijoHakkoEigyoshoMei", "123");
	// 経理変換先コード
	resultEigyosho.put("knrDtlKeirisakiHenkanCd", "123");
	// 営業所種別コード
	resultEigyosho.put("knrDtlHEigyoshoShubetsuCd", "123");
	// 承認営業所区分コード
	resultEigyosho.put("knrDtlHShoninEigyoshoKbnCd", "123");
	// 承認区分
	resultEigyosho.put("knrDtlShoninKbn", "1");
	// 郵便番号
	resultEigyosho.put("khnDtlYubinBango", "1234");
	
        result.put("resultEigyosho", resultEigyosho);
	result.put("resultShoninsha", "resultShoninsha1");
	result.put("resultGroup", "resultGroup1");
	result.put("resultOroshiTanka", "resultOroshiTanka");
	
	serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
		.thenReturn(serviceInterfaceBean, serviceInterfaceBean2);
	
	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("001");
	// 承認区分
	form.setKnrDtlHShoninEigyoshoKbnCd("002");
	// JISコード
	AutoCompOptionBean khnDtlJisCd = new AutoCompOptionBean();
	khnDtlJisCd.setValue("123");
	form.setKhnDtlJisCd(khnDtlJisCd);
	// 郵便番号
	form.setKhnDtlYubinBango("1234567");
	// 住所1
	form.setKhnDtlJusho1("123456789012345689012");
	// 住所2
	form.setKhnDtlJusho2("1234567890123456789012");
	// 住所3
	form.setKhnDtlJusho3("123456780123456789012");
	// 住所4
	form.setKhnDtlJusho4("12345678901789012");
	// 空港コード
	AutoCompOptionBean khnDtlKukoCd = new AutoCompOptionBean();
	khnDtlKukoCd.setValue("123");
	form.setKhnDtlKukoCd(khnDtlKukoCd);
	// 仕向地
	AutoCompOptionBean khnDtlShimukeChi = new AutoCompOptionBean();
	khnDtlShimukeChi.setValue("123");
	form.setKhnDtlShimukeChi(khnDtlShimukeChi);
	// 集配地区コード
	form.setKhnDtlShuhaiChikuCd("123");
	// 伝票種別リスト
        List<String> dempyoShubetsuList = new ArrayList<>();
        dempyoShubetsuList.add("123");
	// 卸単価情報リスト
	Map<String, Object> data = new HashMap<>();
	data.put("orsDtlListHDempyoShubeuCd", "orsInfo1");
	List<Map<String, Object>> datasource = new ArrayList();
	datasource.add(data);
	form.setListOrsDtlSelectable(new ReportListDataModel(datasource));
	
	// 営業所グループ情報リスト
	Map<String, Object> egrpDtlListJoiEigyoshoCd = new HashMap<>();
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "orsInfo1");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListMainSoshiki", "true");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", "0001");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", "");
	
	List<Map<String, Object>> data1 = new ArrayList();
	data1.add(egrpDtlListJoiEigyoshoCd);
	form.setListEgrpDtlSelectable(new ReportListDataModel(data1));
	// 上位営業所リスト
	List<String> eigyoshoCdList = new ArrayList<>();
	eigyoshoCdList.add("111");
	eigyoshoCdList.add("161");
	// メイン組織チェックボックスリスト
	List<String> mainSoshikiList = new ArrayList<>();
	mainSoshikiList.add("123");
	mainSoshikiList.add("111");
	mainSoshikiList.add("611");
	// 新JISコード
	form.setDtlHShinJisCd("001");
	// 旧住所フラグ
	form.setDtlHKyuJushoFlg("1");
        // 営業所グループ情報_登録一覧リスト
        List<Map<String, Object>> eigyoshoGroupTorokuIchiranList = new ArrayList();
        // 営業所グループ情報_更新一覧リスト
        List<Map<String, Object>> eigyoshoGroupKoshinIchiranList = new ArrayList();
	// 起動モード区分
	form.setModeKbn("0");

	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_異常_更新処理_18_37
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "001"
    // 承認区分 = "002"
    // JISコード = "123"
    // 郵便番号 = "12345678"
    // 住所1 = "123456789012345689012"
    // 住所2 ="1234567890123456789012"
    // 住所3 = "123456780123456789012"
    // 住所4 = "12345678901789012"
    // 空港コード = "123"
    // 仕向地 = "123"
    // 集配地区コード ="123"
    // 伝票種別 = "123"
    // 卸単価情報 = "orsDtlListHDempyoShubetsuCd"
    // 新JISコード = "001"
    // 旧住所フラグ = "1"
    // 使用不可フラグ ="0"
    // 起動モード区分 = "1"
    // 一見顧客登録フラグ = "0"
    // 社内便登録フラグ = "0"
    // 着払代引登録フラグ = "0"
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_37() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);

	// Mockitoオブジェクトの予想return値設定
	ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
	ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
	// 営業所検索結果一覧取得 取得件数 = 1
	Map<String, Object> result = new HashMap<>();
	List<String> result1= new ArrayList<>();
	result1.add("123");
	Map<String, Object> resultEigyosho = new HashMap<>();
	// 使用区分
	resultEigyosho.put("knrDtlShiyoKbn", result1);
	// 送り状発行営業所コード
	resultEigyosho.put("knrDtlOkurijoHakkoEigyoshoCd", "123");
	// 送り状発行営業所名
	resultEigyosho.put("knrDtlOkurijoHakkoEigyoshoMei", "123");
	// 経理変換先コード
	resultEigyosho.put("knrDtlKeirisakiHenkanCd", "123");
	// 営業所種別コード
	resultEigyosho.put("knrDtlHEigyoshoShubetsuCd", "123");
	// 承認営業所区分コード
	resultEigyosho.put("knrDtlHShoninEigyoshoKbnCd", "123");
	// 承認区分
	resultEigyosho.put("knrDtlShoninKbn", "1");
	// 郵便番号
	resultEigyosho.put("khnDtlYubinBango", "1234");
	
        result.put("resultEigyosho", resultEigyosho);
	result.put("resultShoninsha", "resultShoninsha1");
	result.put("resultGroup", "resultGroup1");
	result.put("resultOroshiTanka", "resultOroshiTanka");
	
	serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
		.thenReturn(serviceInterfaceBean, serviceInterfaceBean2);
	
	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("001");
	// 承認区分
	form.setKnrDtlHShoninEigyoshoKbnCd("002");
	// JISコード
	AutoCompOptionBean khnDtlJisCd = new AutoCompOptionBean();
	khnDtlJisCd.setValue("123");
	form.setKhnDtlJisCd(khnDtlJisCd);
	// 郵便番号
	form.setKhnDtlYubinBango("1234567");
	// 住所1
	form.setKhnDtlJusho1("123456789012345689012");
	// 住所2
	form.setKhnDtlJusho2("1234567890123456789012");
	// 住所3
	form.setKhnDtlJusho3("123456780123456789012");
	// 住所4
	form.setKhnDtlJusho4("12345678901789012");
	// 空港コード
	AutoCompOptionBean khnDtlKukoCd = new AutoCompOptionBean();
	khnDtlKukoCd.setValue("123");
	form.setKhnDtlKukoCd(khnDtlKukoCd);
	// 仕向地
	AutoCompOptionBean khnDtlShimukeChi = new AutoCompOptionBean();
	khnDtlShimukeChi.setValue("123");
	form.setKhnDtlShimukeChi(khnDtlShimukeChi);
	// 集配地区コード
	form.setKhnDtlShuhaiChikuCd("123");
	// 伝票種別リスト
        List<String> dempyoShubetsuList = new ArrayList<>();
        dempyoShubetsuList.add("123");
	// 卸単価情報リスト
	Map<String, Object> data = new HashMap<>();
	data.put("orsDtlListHDempyoShubeuCd", "orsInfo1");
	List<Map<String, Object>> datasource = new ArrayList();
	datasource.add(data);
	form.setListOrsDtlSelectable(new ReportListDataModel(datasource));
	
	// 営業所グループ情報リスト
	Map<String, Object> egrpDtlListJoiEigyoshoCd = new HashMap<>();
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "orsInfo1");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListMainSoshiki", "true");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", "0001");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", "");
	
	List<Map<String, Object>> data1 = new ArrayList();
	data1.add(egrpDtlListJoiEigyoshoCd);
	form.setListEgrpDtlSelectable(new ReportListDataModel(data1));
	// 上位営業所リスト
	List<String> eigyoshoCdList = new ArrayList<>();
	eigyoshoCdList.add("111");
	eigyoshoCdList.add("161");
	// メイン組織チェックボックスリスト
	List<String> mainSoshikiList = new ArrayList<>();
	mainSoshikiList.add("123");
	mainSoshikiList.add("111");
	mainSoshikiList.add("611");
	// 新JISコード
	form.setDtlHShinJisCd("001");
	// 旧住所フラグ
	form.setDtlHKyuJushoFlg("1");
        // 営業所グループ情報_登録一覧リスト
        List<Map<String, Object>> eigyoshoGroupTorokuIchiranList = new ArrayList();
        // 営業所グループ情報_更新一覧リスト
        List<Map<String, Object>> eigyoshoGroupKoshinIchiranList = new ArrayList();
	// 起動モード区分
	form.setModeKbn("1");
	// 一見顧客登録フラグ
	form.setDtlHIchigenKokyakuTorokuFlg("0");
	// 社内便登録フラグ
	form.setDtlHShanaiBinTorokuFlg("0");
	// 着払代引登録フラグ
	form.setDtlHChakubaraiDaibikiTorokuFlg("0");
	// 住所情報
	Map<String, Object> resultJusho = new HashMap<>();
	resultJusho.put("resultEigyosho", "resultEigyosho1");

	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_正常_更新処理_18_38
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 営業所コード = "001" 
    // 適用開始日 = "2018/06/05"
    // 適用名 = "適用名1"
    // 削除区分 ="1"
    // 適用終了日 = "2019/06/06"
    // 一見顧客登録フラグ = "0"
    // 社内便登録フラグ = "1"
    // 着払代引登録フラグ = "0"
    // -----------------------------------------------------
    @Test
    public void koshin_正常_更新処理_18_38() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {
	// パラメータキャプチャー
	ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
	when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),
		functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
	// テスト実行
	Mst042Form form = new Mst042Form();
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 適用終了日
	form.setTekiyoShuryobi("2038/12/19");
	// 適用名
	form.setConTekiyoMei("適用名1");
	// 削除区分
	form.setDeleteKbn("1");
	// 一見顧客登録フラグ
	form.setDtlHIchigenKokyakuTorokuFlg("0");
	// 社内便登録フラグ
	form.setDtlHShanaiBinTorokuFlg("1");
	// 着払代引登録フラグ
	form.setDtlHChakubaraiDaibikiTorokuFlg("0");
	
	Map<String, Object> resultEigyoshoInfo = new HashMap();
	resultEigyoshoInfo.put("conEigyoshoCd", conEigyoshoCd);
	resultEigyoshoInfo.put("conTekiyoKaishibi", "2018/06/05");
	resultEigyoshoInfo.put("conTekiyoShuryobi", "2038/12/19 23:59:59");
	resultEigyoshoInfo.put("dtlSakujoFlg", "1");
	resultEigyoshoInfo.put("dtlEigyoshoDataVersion", "1");
	form.setResultEigyoshoInfo(resultEigyoshoInfo);
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
	
    }  
    
    // koshin_正常_更新処理_18_39
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 営業所コード = "001" 
    // 適用開始日 = "2018/06/05"
    // 適用名 = "適用名1"
    // 削除区分 ="1"
    // 適用終了日 = "2019/06/06"
    // 一見顧客登録フラグ = "0"
    // 社内便登録フラグ = "0"
    // 着払代引登録フラグ = "1"
    // -----------------------------------------------------
    @Test
    public void koshin_正常_更新処理_18_39() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {
	
	// パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),
		functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        
	// テスト実行
	Mst042Form form = new Mst042Form();
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 適用終了日
	form.setTekiyoShuryobi("2038/12/19");
	// 適用名
	form.setConTekiyoMei("適用名1");
	// 削除区分
	form.setDeleteKbn("1");
	// 一見顧客登録フラグ
	form.setDtlHIchigenKokyakuTorokuFlg("0");
	// 社内便登録フラグ
	form.setDtlHShanaiBinTorokuFlg("0");
	// 着払代引登録フラグ
	form.setDtlHChakubaraiDaibikiTorokuFlg("1");
	
	Map<String, Object> resultEigyoshoInfo = new HashMap();
	resultEigyoshoInfo.put("conEigyoshoCd", conEigyoshoCd);
	resultEigyoshoInfo.put("conTekiyoKaishibi", "2018/06/05");
	resultEigyoshoInfo.put("conTekiyoShuryobi", "2038/12/19 23:59:59");
	resultEigyoshoInfo.put("dtlSakujoFlg", "1");
	resultEigyoshoInfo.put("dtlEigyoshoDataVersion", "1");
	form.setResultEigyoshoInfo(resultEigyoshoInfo);
	
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
	
    }  
    
    // koshin_正常_更新処理_18_40
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "001"
    // 承認区分 = "002"
    // JISコード = "123"
    // 郵便番号 = "12345678"
    // 住所1 = "123456789012345689012"
    // 住所2 ="1234567890123456789012"
    // 住所3 = "123456780123456789012"
    // 住所4 = "12345678901789012"
    // 空港コード = "123"
    // 仕向地 = "123"
    // 集配地区コード ="123"
    // -----------------------------------------------------
    @Test
    public void koshin_正常_更新処理_18_40() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

        // パラメータキャプチャー
	ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
	when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),
		functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
		AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("001");
	// 承認区分
	form.setKnrDtlHShoninEigyoshoKbnCd("002");
	// JISコード
	AutoCompOptionBean khnDtlJisCd = new AutoCompOptionBean();
	khnDtlJisCd.setValue("123");
	form.setKhnDtlJisCd(khnDtlJisCd);
	// 郵便番号
	form.setKhnDtlYubinBango("1234567");
	// 住所1
	form.setKhnDtlJusho1("123456789012345689012");
	// 住所2
	form.setKhnDtlJusho2("1234567890123456789012");
	// 住所3
	form.setKhnDtlJusho3("123456780123456789012");
	// 住所4
	form.setKhnDtlJusho4("12345678901789012");
	// 空港コード
	AutoCompOptionBean khnDtlKukoCd = new AutoCompOptionBean();
	khnDtlKukoCd.setValue("123");
	form.setKhnDtlKukoCd(khnDtlKukoCd);
	// 仕向地
	AutoCompOptionBean khnDtlShimukeChi = new AutoCompOptionBean();
	khnDtlShimukeChi.setValue("123");
	form.setKhnDtlShimukeChi(khnDtlShimukeChi);
	// 集配地区コード
	form.setKhnDtlShuhaiChikuCd("123");
	// 伝票種別リスト
        List<String> dempyoShubetsuList = new ArrayList<>();
        dempyoShubetsuList.add("123");
	// 卸単価情報リスト
	Map<String, Object> data = new HashMap<>();
	data.put("orsDtlListHDempyoShubeuCd", "orsInfo1");
	data.put("orsDtlListHDempyoShubetsuCd", "123");
	data.put("orsDtlListShukaOroshiTanka", "123");
	data.put("orsDtlListHDempyoShubetsuCd", "12563");
	
	List<Map<String, Object>> datasource = new ArrayList();
	datasource.add(data);
	form.setListOrsDtlSelectable(new ReportListDataModel(datasource));
	
	// 営業所グループ情報リスト
	Map<String, Object> egrpDtlListJoiEigyoshoCd = new HashMap<>();
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "orsInfo1");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListMainSoshiki", "true");
	AutoCompOptionBean egrpDtlListSubSoshikiCdAut = new AutoCompOptionBean();
	egrpDtlListSubSoshikiCdAut.setValue("123");
	egrpDtlListSubSoshikiCdAut.setLabel("123");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", egrpDtlListSubSoshikiCdAut);
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "123");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListMainSoshiki", "egrpDtlListMainSoshiki");
	
	List<Map<String, Object>> data1 = new ArrayList();
	data1.add(egrpDtlListJoiEigyoshoCd);
	form.setListEgrpDtlSelectable(new ReportListDataModel(data1));
	
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_正常_更新処理_18_41
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "001"
    // 承認区分 = "002"
    // JISコード = "123"
    // 郵便番号 = "12345678"
    // 住所1 = "123456789012345689012"
    // 住所2 ="1234567890123456789012"
    // 住所3 = "123456780123456789012"
    // 住所4 = "12345678901789012"
    // 空港コード = "123"
    // 仕向地 = "123"
    // 集配地区コード ="123"
    // -----------------------------------------------------
    @Test
    public void koshin_正常_更新処理_18_41() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

        // パラメータキャプチャー
	ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
	when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),
		functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
		AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("001");
	// 承認区分
	form.setKnrDtlHShoninEigyoshoKbnCd("002");
	// JISコード
	AutoCompOptionBean khnDtlJisCd = new AutoCompOptionBean();
	khnDtlJisCd.setValue("123");
	form.setKhnDtlJisCd(khnDtlJisCd);
	// 郵便番号
	form.setKhnDtlYubinBango("1234567");
	// 住所1
	form.setKhnDtlJusho1("123456789012345689012");
	// 住所2
	form.setKhnDtlJusho2("1234567890123456789012");
	// 住所3
	form.setKhnDtlJusho3("123456780123456789012");
	// 住所4
	form.setKhnDtlJusho4("12345678901789012");
	// 空港コード
	AutoCompOptionBean khnDtlKukoCd = new AutoCompOptionBean();
	khnDtlKukoCd.setValue("123");
	form.setKhnDtlKukoCd(khnDtlKukoCd);
	// 仕向地
	AutoCompOptionBean khnDtlShimukeChi = new AutoCompOptionBean();
	khnDtlShimukeChi.setValue("123");
	form.setKhnDtlShimukeChi(khnDtlShimukeChi);
	// 集配地区コード
	form.setKhnDtlShuhaiChikuCd("123");
	// 伝票種別リスト
        List<String> dempyoShubetsuList = new ArrayList<>();
        dempyoShubetsuList.add("123");
	// 卸単価情報リスト
	Map<String, Object> data = new HashMap<>();
	data.put("orsDtlListHDempyoShubeuCd", "orsInfo1");
	data.put("orsDtlListHDempyoShubetsuCd", "123");
	data.put("orsDtlListShukaOroshiTanka", "123");
	data.put("orsDtlListHDempyoShubetsuCd", "12563");
	
	List<Map<String, Object>> datasource = new ArrayList();
	datasource.add(data);
	datasource.add(data);
	form.setListOrsDtlSelectable(new ReportListDataModel(datasource));
	
	// 営業所グループ情報リスト
	Map<String, Object> egrpDtlListJoiEigyoshoCd = new HashMap<>();
	AutoCompOptionBean egrpDtlListSubSoshikiCdAut = new AutoCompOptionBean();
	egrpDtlListSubSoshikiCdAut.setValue("123");
	egrpDtlListSubSoshikiCdAut.setLabel("123");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "orsInfo1");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListMainSoshiki", "true");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", egrpDtlListSubSoshikiCdAut);
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "123");
	
	List<Map<String, Object>> data1 = new ArrayList();
	data1.add(egrpDtlListJoiEigyoshoCd);
	form.setListEgrpDtlSelectable(new ReportListDataModel(data1));
	
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_正常_更新処理_18_42
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "001"
    // 承認区分 = "002"
    // JISコード = "123"
    // 郵便番号 = "12345678"
    // 住所1 = "123456789012345689012"
    // 住所2 ="1234567890123456789012"
    // 住所3 = "123456780123456789012"
    // 住所4 = "12345678901789012"
    // 空港コード = "123"
    // 仕向地 = "123"
    // 集配地区コード ="123"
    // -----------------------------------------------------
    @Test
    public void koshin_正常_更新処理_18_42() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

        // パラメータキャプチャー
	ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
	when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(),
		functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
		AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("001");
	// 承認区分
	form.setKnrDtlHShoninEigyoshoKbnCd("002");
	// JISコード
	AutoCompOptionBean khnDtlJisCd = new AutoCompOptionBean();
	khnDtlJisCd.setValue("123");
	form.setKhnDtlJisCd(khnDtlJisCd);
	// 郵便番号
	form.setKhnDtlYubinBango("1234567");
	// 住所1
	form.setKhnDtlJusho1("123456789012345689012");
	// 住所2
	form.setKhnDtlJusho2("1234567890123456789012");
	// 住所3
	form.setKhnDtlJusho3("123456780123456789012");
	// 住所4
	form.setKhnDtlJusho4("12345678901789012");
	// 空港コード
	AutoCompOptionBean khnDtlKukoCd = new AutoCompOptionBean();
	khnDtlKukoCd.setValue("123");
	form.setKhnDtlKukoCd(khnDtlKukoCd);
	// 仕向地
	AutoCompOptionBean khnDtlShimukeChi = new AutoCompOptionBean();
	khnDtlShimukeChi.setValue("123");
	form.setKhnDtlShimukeChi(khnDtlShimukeChi);
	// 集配地区コード
	form.setKhnDtlShuhaiChikuCd("123");
	// 伝票種別リスト
        List<String> dempyoShubetsuList = new ArrayList<>();
        dempyoShubetsuList.add("123");
	// 卸単価情報リスト
	Map<String, Object> data = new HashMap<>();
	data.put("orsDtlListHDempyoShubeuCd", "orsInfo1");
	data.put("orsDtlListHDempyoShubetsuCd", "123");
	data.put("orsDtlListShukaOroshiTanka", "123");
	data.put("orsDtlListHDempyoShubetsuCd", "12563");
	
	List<Map<String, Object>> datasource = new ArrayList();
	datasource.add(data);
	form.setListOrsDtlSelectable(new ReportListDataModel(datasource));
	
	// 営業所グループ情報リスト
	Map<String, Object> egrpDtlListJoiEigyoshoCd = new HashMap<>();
	AutoCompOptionBean egrpDtlListSubSoshikiCdAut = new AutoCompOptionBean();
	egrpDtlListSubSoshikiCdAut.setValue("123");
	egrpDtlListSubSoshikiCdAut.setLabel("123");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "orsInfo1");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListMainSoshiki", "true");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", egrpDtlListSubSoshikiCdAut);
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "123");
	
	List<Map<String, Object>> data1 = new ArrayList();
	data1.add(egrpDtlListJoiEigyoshoCd);
	data1.add(egrpDtlListJoiEigyoshoCd);
	form.setListEgrpDtlSelectable(new ReportListDataModel(data1));
	
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
    }  
    
    // koshin_異常_更新処理_18_43
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "001"
    // 承認区分 = "002"
    // JISコード = "123"
    // 郵便番号 = "12345678"
    // 住所1 = "123456789012345689012"
    // 住所2 ="1234567890123456789012"
    // 住所3 = "123456780123456789012"
    // 住所4 = "12345678901789012"
    // 空港コード = "123"
    // 仕向地 = "123"
    // 集配地区コード ="123"
    // -----------------------------------------------------
    @Test
    public void koshin_異常_更新処理_18_43() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

        // パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
	serviceInterfaceBean.addMessage("ERROR", "MSTE0009", "JISコード");
	serviceInterfaceBean.setTableName("営業所マスタ");
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),
		functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
	
	// パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<String> detailCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), 
		summaryCaptor_4.capture(), detailCaptor_5.capture(), detailCaptor_6.capture());
	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
		AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("001");
	// 承認区分
	form.setKnrDtlHShoninEigyoshoKbnCd("002");
	// JISコード
	AutoCompOptionBean khnDtlJisCd = new AutoCompOptionBean();
	khnDtlJisCd.setValue("123");
	form.setKhnDtlJisCd(khnDtlJisCd);
	// 郵便番号
	form.setKhnDtlYubinBango("1234567");
	// 住所1
	form.setKhnDtlJusho1("123456789012345689012");
	// 住所2
	form.setKhnDtlJusho2("1234567890123456789012");
	// 住所3
	form.setKhnDtlJusho3("123456780123456789012");
	// 住所4
	form.setKhnDtlJusho4("12345678901789012");
	// 空港コード
	AutoCompOptionBean khnDtlKukoCd = new AutoCompOptionBean();
	khnDtlKukoCd.setValue("123");
	form.setKhnDtlKukoCd(khnDtlKukoCd);
	// 仕向地
	AutoCompOptionBean khnDtlShimukeChi = new AutoCompOptionBean();
	khnDtlShimukeChi.setValue("123");
	form.setKhnDtlShimukeChi(khnDtlShimukeChi);
	// 集配地区コード
	form.setKhnDtlShuhaiChikuCd("123");
	// 伝票種別リスト
        List<String> dempyoShubetsuList = new ArrayList<>();
        dempyoShubetsuList.add("123");
	// 卸単価情報リスト
	Map<String, Object> data = new HashMap<>();
	data.put("orsDtlListHDempyoShubeuCd", "orsInfo1");
	data.put("orsDtlListHDempyoShubetsuCd", "123");
	data.put("orsDtlListShukaOroshiTanka", "123");
	data.put("orsDtlListHDempyoShubetsuCd", "12563");
	
	List<Map<String, Object>> datasource = new ArrayList();
	datasource.add(data);
	form.setListOrsDtlSelectable(new ReportListDataModel(datasource));
	
	// 営業所グループ情報リスト
	Map<String, Object> egrpDtlListJoiEigyoshoCd = new HashMap<>();
	AutoCompOptionBean egrpDtlListSubSoshikiCdAut = new AutoCompOptionBean();
	egrpDtlListSubSoshikiCdAut.setValue("123");
	egrpDtlListSubSoshikiCdAut.setLabel("123");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "orsInfo1");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListMainSoshiki", "true");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", egrpDtlListSubSoshikiCdAut);
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "123");
	
	List<Map<String, Object>> data1 = new ArrayList();
	data1.add(egrpDtlListJoiEigyoshoCd);
	form.setListEgrpDtlSelectable(new ReportListDataModel(data1));
	// 送り状発行営業所存在チェック
	AutoCompOptionBean knrDtlOkurijoHakkoEigyoshoCd = new AutoCompOptionBean();
	knrDtlOkurijoHakkoEigyoshoCd.setValue("123");
	form.setKnrDtlOkurijoHakkoEigyoshoCd(knrDtlOkurijoHakkoEigyoshoCd);
	// 銀行口座存在チェック
	form.setKzaDtlGinkoKozaCd(knrDtlOkurijoHakkoEigyoshoCd);
	// 仕立営業所コード存在チェック
	form.setOrsDtlShitateEigyoshoCd(knrDtlOkurijoHakkoEigyoshoCd);
	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
	assertEquals("ERROR", levelCaptor_3.getValue());
	assertEquals("MSTE0009", summaryCaptor_4.getValue());
    }  
    
    // koshin_正常_更新処理_18_44
    //
    // -------------------テスト条件--------------------------
    // 更新ボタン押下処理
    // 削除区分 = null
    // 営業所コード = "001" 
    // 適用開始日 = "2019/01/01"
    // 適用名 = "12345"
    // 営業所名 = "12345678989012"
    // 営業所カナ名 = "123456789017890123456789012"
    // 営業所略称 = "12345678567890129012"
    // 英語表記 = "12345678567890129012"
    // 営業所種別 = "001"
    // 承認区分 = "002"
    // JISコード = "123"
    // 郵便番号 = "12345678"
    // 住所1 = "123456789012345689012"
    // 住所2 ="1234567890123456789012"
    // 住所3 = "123456780123456789012"
    // 住所4 = "12345678901789012"
    // 空港コード = "123"
    // 仕向地 = "123"
    // 集配地区コード ="123"
    // -----------------------------------------------------
    @Test
    public void koshin_正常_更新処理_18_44() throws IllegalAccessException, InvocationTargetException, SystemException, UnsupportedEncodingException {

	// テスト実行
	Mst042Form form = new Mst042Form();
	// 削除区分
	form.setDeleteKbn(null);
		AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// 適用名
	form.setConTekiyoMei("12345");
	// 営業所名
	form.setKnrDtlEigyoshoMei("12345678989012");
	// 営業所カナ名
	form.setKnrDtlEigyoshoKanaMei("123456789017890123456789012");
	// 営業所略称
	form.setKnrDtlEigyoshoRyakusho("12345678567890129012");
	// 英語表記
	form.setKnrDtlEigoHyoki("123567890123456789012");
	// 営業所種別
	form.setKnrDtlHEigyoshoShubetsuCd("001");
	// 承認区分
	form.setKnrDtlHShoninEigyoshoKbnCd("002");
	// JISコード
	AutoCompOptionBean khnDtlJisCd = new AutoCompOptionBean();
	khnDtlJisCd.setValue("123");
	form.setKhnDtlJisCd(khnDtlJisCd);
	// 郵便番号
	form.setKhnDtlYubinBango("1234567");
	// 住所1
	form.setKhnDtlJusho1("123456789012345689012");
	// 住所2
	form.setKhnDtlJusho2("1234567890123456789012");
	// 住所3
	form.setKhnDtlJusho3("123456780123456789012");
	// 住所4
	form.setKhnDtlJusho4("12345678901789012");
	// 空港コード
	AutoCompOptionBean khnDtlKukoCd = new AutoCompOptionBean();
	khnDtlKukoCd.setValue("123");
	form.setKhnDtlKukoCd(khnDtlKukoCd);
	// 仕向地
	AutoCompOptionBean khnDtlShimukeChi = new AutoCompOptionBean();
	khnDtlShimukeChi.setValue("123");
	form.setKhnDtlShimukeChi(khnDtlShimukeChi);
	// 集配地区コード
	form.setKhnDtlShuhaiChikuCd("123");
	// 伝票種別リスト
        List<String> dempyoShubetsuList = new ArrayList<>();
        dempyoShubetsuList.add("123");
	// 卸単価情報リスト
	Map<String, Object> data = new HashMap<>();
	data.put("orsDtlListHDempyoShubeuCd", "123");
	data.put("orsDtlListHDempyoShubetsuCd", null);
	data.put("orsDtlListShukaOroshiTanka", "123");

	
	List<Map<String, Object>> datasource = new ArrayList();
	datasource.add(data);
	form.setListOrsDtlSelectable(new ReportListDataModel(datasource));
	
	// 営業所グループ情報リスト
	Map<String, Object> egrpDtlListJoiEigyoshoCd = new HashMap<>();
	AutoCompOptionBean egrpDtlListSubSoshikiCdAut = new AutoCompOptionBean();
	egrpDtlListSubSoshikiCdAut.setValue("123");
	egrpDtlListSubSoshikiCdAut.setLabel("123");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "orsInfo1");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListMainSoshiki", "true");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", egrpDtlListSubSoshikiCdAut);
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "123");
	
	List<Map<String, Object>> data1 = new ArrayList();
	data1.add(egrpDtlListJoiEigyoshoCd);
	form.setListEgrpDtlSelectable(new ReportListDataModel(data1));

	target.setMst042Form(form);
	target.btnKoshin();
	
	// 実施結果Outを取得
	form = target.getMst042Form();

    }  

    // addRow_正常_補充ケース_25_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void addRow_正常_補充ケース_25_1() throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
	
	AutoCompOptionBean subsoshiMeiBean = new AutoCompOptionBean();
	subsoshiMeiBean.setValue("subsoshiMeiBean");
	subsoshiMeiBean.setLabel("subsoshiMeiBean");
	List<AutoCompOptionBean> subsoshiMeiBeanList = new ArrayList();
	subsoshiMeiBeanList.add(subsoshiMeiBean);
	when(autoCompleteViewBean.getValueLabelFromDB(functionCodeCaptor_2.capture(), 
		paramsCaptor_1.capture())).thenReturn(subsoshiMeiBeanList);
	
        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> result = new ArrayList<>();
        
        resMap.put("tablesorter_mst042", result);
        
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);

        // パラメータキャプチャー
        doNothing().when(pageCommonBean).addRow("tablesorter_mst042", true);
        // テスト実行
        Mst042Form form = new Mst042Form();
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// サブ組織名リスト
	List<String> subSoshikiMei = new ArrayList();
	form.setSubSoshikiMeiList(subSoshikiMei);
	
        target.setMst042Form(form);
        target.addRow("tablesorter_mst042", true);

        // 実施結果Outを取得
        form = target.getMst042Form();

    }
    
    // addRow_異常_補充ケース_25_2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void addRow_異常_補充ケース_25_2() throws IllegalAccessException, InvocationTargetException {
   
        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> result = new ArrayList<>();
        
        resMap.put("tablesorter_mst042", result);
        
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);
	// パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture());
        // テスト実行
        Mst042Form form = new Mst042Form();
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
        target.setMst042Form(form);
        target.addRow("tablesorter_mst042", true);

        // 実施結果Outを取得
        form = target.getMst042Form();
	
	// 想定通りにエラーが発生。（メッセージID：COME0003）
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0003", summaryCaptor_4.getValue());
        assertEquals("適用開始日", detailCaptor_5.getValue());

    }
    
    // addRow_異常_補充ケース_25_3
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void addRow_異常_補充ケース_25_3() throws IllegalAccessException, InvocationTargetException {
   
        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> result = new ArrayList<>();
        
        resMap.put("tablesorter_mst042", result);
        
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);
	// パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture());
        // テスト実行
        Mst042Form form = new Mst042Form();
	// 営業所コード
	form.setConEigyoshoCd(null);
        target.setMst042Form(form);
        target.addRow("tablesorter_mst042", true);

        // 実施結果Outを取得
        form = target.getMst042Form();
	
	// 想定通りにエラーが発生。（メッセージID：COME0003）
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0003", summaryCaptor_4.getValue());
        assertEquals("営業所コード", detailCaptor_5.getValue());

    }
    
    // addRow_正常_補充ケース_25_4
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void addRow_正常_補充ケース_25_4() throws IllegalAccessException, InvocationTargetException {
  
        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> result = new ArrayList<>();
        
        resMap.put("tablesorter_mst042", result);
        
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);

        // パラメータキャプチャー
        doNothing().when(pageCommonBean).addRow("tablesorter_mst042", true);
        // テスト実行
        Mst042Form form = new Mst042Form();
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2019/01/01");
	// サブ組織名リスト
	List<String> subSoshikiMei = new ArrayList();
	form.setSubSoshikiMeiList(subSoshikiMei);
	List<AutoCompOptionBean> subsoshiMeiBeanList = new ArrayList<>();
	subsoshiMeiBeanList.add(conEigyoshoCd);
        target.setMst042Form(form);
        target.addRow("tablesorter_mst042", true);

        // 実施結果Outを取得
        form = target.getMst042Form();

    }
    
    // setListCodeName_正常_補充ケース_26_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void setListCodeName_正常_補充ケース_26_1() throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst042Form form = new Mst042Form();
	// 選択されたAUTOCOMPLETEデータ
	AutoCompOptionBean option = new AutoCompOptionBean();
	option.setValue("001");
	// 営業所グループ情報
	Map<String, Object> egrpDtlListJoiEigyoshoCd = new HashMap<>();
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "orsInfo1");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyosho", "orsInfo");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoi", "info");
	List<Map<String, Object>> data1 = new ArrayList();
	data1.add(egrpDtlListJoiEigyoshoCd);
	form.setListEgrpDtlSelectable(new ReportListDataModel(data1));
	form.getListEgrpDtlSelectable().setPageSize(1);
	form.getListEgrpDtlSelectable().setRowIndex(0);
	form.getListEgrpDtlSelectable().setRowCount(1);
        target.setMst042Form(form);
        target.setListCodeName(0, option, "22", "22", "Egrp");

        // 実施結果Outを取得
        form = target.getMst042Form();
    }
    
    // setListCodeName_正常_補充ケース_26_2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void setListCodeName_正常_補充ケース_26_2() throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst042Form form = new Mst042Form();
	// 選択されたAUTOCOMPLETEデータ
	AutoCompOptionBean option = new AutoCompOptionBean();
	option.setValue("001");
	// 営業所グループ情報
	Map<String, Object> orsDtlSelectable = new HashMap<>();
	orsDtlSelectable.put("egrpDtlListJoiEigyoshoCd", "orsInfo1");
	orsDtlSelectable.put("egrpDtlListJoiEigyosho", "orsInfo");
	orsDtlSelectable.put("egrpDtlListJoi", "info");
	List<Map<String, Object>> data1 = new ArrayList();
	data1.add(orsDtlSelectable);
	form.setListOrsDtlSelectable(new ReportListDataModel(data1));
	form.getListOrsDtlSelectable().setPageSize(1);
	form.getListOrsDtlSelectable().setRowIndex(0);
	form.getListOrsDtlSelectable().setRowCount(1);
        target.setMst042Form(form);
        target.setListCodeName(0, option, "22", "22", "Ors");

        // 実施結果Outを取得
        form = target.getMst042Form();
    }
 
    // setListCodeName_正常_補充ケース_26_3
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void setListCodeName_正常_補充ケース_26_3() throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst042Form form = new Mst042Form();
	// 営業所グループ情報
	Map<String, Object> egrpDtlListJoiEigyoshoCd = new HashMap<>();
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "orsInfo1");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyosho", "orsInfo");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoi", "info");
	List<Map<String, Object>> data1 = new ArrayList();
	data1.add(egrpDtlListJoiEigyoshoCd);
	form.setListEgrpDtlSelectable(new ReportListDataModel(data1));
	form.getListEgrpDtlSelectable().setPageSize(1);
	form.getListEgrpDtlSelectable().setRowIndex(0);
	form.getListEgrpDtlSelectable().setRowCount(1);
        target.setMst042Form(form);
        target.setListCodeName(0, null, "22", "22", "Egrp");

        // 実施結果Outを取得
        form = target.getMst042Form();
    }
    
    // setListCodeName_正常_補充ケース_26_4
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void setListCodeName_正常_補充ケース_26_4() throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst042Form form = new Mst042Form();
	// 営業所グループ情報
	Map<String, Object> orsDtlSelectable = new HashMap<>();
	orsDtlSelectable.put("egrpDtlListJoiEigyoshoCd", "orsInfo1");
	orsDtlSelectable.put("egrpDtlListJoiEigyosho", "orsInfo");
	orsDtlSelectable.put("egrpDtlListJoi", "info");
	List<Map<String, Object>> data1 = new ArrayList();
	data1.add(orsDtlSelectable);
	form.setListOrsDtlSelectable(new ReportListDataModel(data1));
	form.getListOrsDtlSelectable().setPageSize(1);
	form.getListOrsDtlSelectable().setRowIndex(0);
	form.getListOrsDtlSelectable().setRowCount(1);
        target.setMst042Form(form);
        target.setListCodeName(0, null, "22", "22", "Ors");

        // 実施結果Outを取得
        form = target.getMst042Form();
    }
    
    //　サンプルデータをテストフォ2-2
    private void assertForRecList_2_2(Mst042Form form) {
	int i = 0;
	for (Map<String, Object> rec : form.getListOrsDtlSelectable()) {
	      
	    // 営業所コード
	    assertEquals("conEigyoshoCd" + i, rec.get("conEigyoshoCd"));
	    // 適用開始日
	    assertEquals("conTekiyoKaishibi" + i, rec.get("conTekiyoKaishibi"));
	    // 適用名
	    assertEquals("conTekiyoMei" + i, rec.get("conTekiyoMei"));
	    // 適用終了
	    assertEquals("conTekiyoShuryo" + i, rec.get("conTekiyoShuryo"));
	    // 営業所名
	    assertEquals("knrDtlEigyoshoMei" + i, rec.get("knrDtlEigyoshoMei"));
	    // 営業所カナ名
	    assertEquals("knrDtlEigyoshoKanaMei" + i, rec.get("knrDtlEigyoshoKanaMei"));
	    // 営業所略称
	    assertEquals("knrDtlEigyoshoRyakusho" + i, rec.get("knrDtlEigyoshoRyakusho"));
	    // 英語表記
	    assertEquals("knrDtlEigoHyoki" + i, rec.get("knrDtlEigoHyoki"));
	    // 使用区分.集荷営業所
	    assertEquals("knrDtlShiyoShukaKbn" + i, rec.get("knrDtlShiyoShukaKbn"));
	    // 使用区分.配達営業所
	    assertEquals("knrDtlShiyoHaitatsuKbn" + i, rec.get("knrDtlShiyoHaitatsuKbn"));
	    // 使用区分.チャーター起点
	    assertEquals("knrDtlShiyoKitenKbn" + i, rec.get("knrDtlShiyoKitenKbn"));
	    // 使用区分.売上
	    assertEquals("knrDtlShiyoUriageKbn" + i, rec.get("knrDtlShiyoUriageKbn"));
	    // 使用区分.発券営業所
	    assertEquals("knrDtlShiyoHakkenKbn" + i, rec.get("knrDtlShiyoHakkenKbn"));
	    // 使用区分.車両管理
	    assertEquals("knrDtlShiyoSharyoKbn" + i, rec.get("knrDtlShiyoSharyoKbn"));
	    // 使用区分.配達伝票出力営業所
	    assertEquals("knrDtlShiyoHaidenKbn" + i, rec.get("knrDtlShiyoHaidenKbn"));
	    // 送り状発行営業所コード
	    assertEquals("knrDtlOkurijoHakkoEigyoshoCd" + i, rec.get("knrDtlOkurijoHakkoEigyoshoCd"));
	    // 送り状発行営業所名
	    assertEquals("knrDtlOkurijoHakkoEigyoshoMei" + i, rec.get("knrDtlOkurijoHakkoEigyoshoMei"));
	    // 経理変換先コード
	    assertEquals("knrDtlKeirisakiHenkanCd" + i, rec.get("knrDtlKeirisakiHenkanCd"));
	    // 営業所種別コード
	    assertEquals("knrDtlHEigyoshoShubetsuCd" + i, rec.get("knrDtlHEigyoshoShubetsuCd"));
	    // 営業所種別
	    assertEquals("knrDtlEigyoshoShubetsu" + i, rec.get("knrDtlEigyoshoShubetsu"));
	    // 承認営業所区分コード
	    assertEquals("knrDtlHShoninEigyoshoKbnCd" + i, rec.get("knrDtlHShoninEigyoshoKbnCd"));
	    // 承認区分
	    assertEquals("knrDtlShoninKbn" + i, rec.get("knrDtlShoninKbn"));
	    // 郵便番号
	    assertEquals("khnDtlYubinBango" + i, rec.get("khnDtlYubinBango"));
	    // JISコード
	    assertEquals("khnDtlJisCd" + i, rec.get("khnDtlJisCd"));
	    // 住所1
	    assertEquals("khnDtlJusho1" + i, rec.get("khnDtlJusho1"));
	    // 住所2
	    assertEquals("khnDtlJusho2" + i, rec.get("khnDtlJusho2"));
	    // 住所3
	    assertEquals("khnDtlJusho3" + i, rec.get("khnDtlJusho3"));
	    // 住所4
	    assertEquals("khnDtlJusho4" + i, rec.get("khnDtlJusho4"));
	    // 空港コード
	    assertEquals("khnDtlKukoCd" + i, rec.get("khnDtlKukoCd"));
	    // 空港名
	    assertEquals("khnDtlKukoMei" + i, rec.get("khnDtlKukoMei"));
	    // 仕向地
	    assertEquals("khnDtlShimukeChi" + i, rec.get("khnDtlShimukeChi"));
	    // 仕向地名
	    assertEquals("khnDtlShimukeChiMei" + i, rec.get("khnDtlShimukeChiMei"));
	    // 集配地区コード
	    assertEquals("khnDtlShuhaiChikuCd" + i, rec.get("khnDtlShuhaiChikuCd"));
	    // 電話番号1
	    assertEquals("khnDtlTelBango1" + i, rec.get("khnDtlTelBango1"));
	    // 電話番号2
	    assertEquals("khnDtlTelBango2" + i, rec.get("khnDtlTelBango2"));
	    // 社内電話番号
	    assertEquals("khnDtlShanaiTelBango" + i, rec.get("khnDtlShanaiTelBango"));
	    // FAX番号
	    assertEquals("khnDtlFaxBango" + i, rec.get("khnDtlFaxBango"));
	    // 銀行口座コード
	    assertEquals("kzaDtlGinkoKozaCd" + i, rec.get("kzaDtlGinkoKozaCd"));
	    // 銀行口座名
	    assertEquals("kzaDtlGinkoKozaMei" + i, rec.get("kzaDtlGinkoKozaMei"));
	    // 金融機関コード
	    assertEquals("kzaDtlKinyuKikanCd" + i, rec.get("kzaDtlKinyuKikanCd"));
	    // 金融機関名
	    assertEquals("kzaDtlKinyuKikanMei" + i, rec.get("kzaDtlKinyuKikanMei"));
	    // 支店コード
	    assertEquals("kzaDtlShitenCd" + i, rec.get("kzaDtlShitenCd"));
	    // 支店名
	    assertEquals("kzaDtlShitenMei" + i, rec.get("kzaDtlShitenMei"));
	    // 口座種別コード
	    assertEquals("kzaDtlKozaShubetsuCd" + i, rec.get("kzaDtlKozaShubetsuCd"));
	    // 口座種別名
	    assertEquals("kzaDtlKozaShubetsuMei" + i, rec.get("kzaDtlKozaShubetsuMei"));
	    // 口座番号
	    assertEquals("kzaDtlKozaBango" + i, rec.get("kzaDtlKozaBango"));
	    // 名義人名
	    assertEquals("kzaDtlMeigininMei" + i, rec.get("kzaDtlMeigininMei"));
	    // 仕立営業所コード
	    assertEquals("orsDtlShitateEigyoshoCd" + i, rec.get("orsDtlShitateEigyoshoCd"));
	    // 仕立営業所名
	    assertEquals("orsDtlShitateEigyoshoMei" + i, rec.get("orsDtlShitateEigyoshoMei"));
	    // 他社中継卸値率
	    assertEquals("orsDtlTashaChukeiOroshineritsu" + i, rec.get("orsDtlTashaChukeiOroshineritsu"));
	    // 更新ユーザ
	    assertEquals("kshnDtlUser" + i, rec.get("kshnDtlUser"));
	    // 更新日時
	    assertEquals("kshnDtlKoshinNichiji" + i, rec.get("kshnDtlKoshinNichiji"));
	    // 最終使用日(売上管理)
	    assertEquals("kshnDtlSaishuShiyoHiUriageKanri" + i, rec.get("kshnDtlSaishuShiyoHiUriageKanri"));
	    // 最終使用日(卸計算)
	    assertEquals("kshnDtlSaishuShiyoHiOroshiKanri" + i, rec.get("kshnDtlSaishuShiyoHiOroshiKanri"));
	    // 最終使用日(仕入管理)
	    assertEquals("kshnDtlSaishuShiyoHiShiireKanri" + i, rec.get("kshnDtlSaishuShiyoHiShiireKanri"));
	    // 一見顧客登録フラグ
	    assertEquals("dtlHIchigenKokyakuTorokuFlg" + i, rec.get("dtlHIchigenKokyakuTorokuFlg"));
	    // 社内便登録フラグ
	    assertEquals("dtlHShanaiBinTorokuFlg" + i, rec.get("dtlHShanaiBinTorokuFlg"));
	    // 着払代引登録フラグ
	    assertEquals("dtlHChakubaraiDaibikiTorokuFlg" + i, rec.get("dtlHChakubaraiDaibikiTorokuFlg"));
	    // 旧住所フラグ
	    assertEquals("dtlHKyuJushoFlg" + i, rec.get("dtlHKyuJushoFlg"));
	    // 使用不可フラグ
	    assertEquals("dtlHShiyoFukaFlg" + i, rec.get("dtlHShiyoFukaFlg"));
	    // 新JISコード
	    assertEquals("dtlHShinJisCd" + i, rec.get("dtlHShinJisCd"));
	    // 営業所データバージョン
	    assertEquals("dtlEigyoshoDataVersion" + i, rec.get("dtlEigyoshoDataVersion"));
	    // 更新カウンタ
	    assertEquals("dtlKoshinCounter" + i, rec.get("dtlKoshinCounter"));
	    // 削除フラグ
	    assertEquals("dtlHSakujoFlg" + i, rec.get("dtlHSakujoFlg"));
	    // 適用終了日
	    assertEquals("tekiyoShuryobi" + i, rec.get("tekiyoShuryobi"));
	   
	    i++;
	}
    }
    
    // サンプルデータを作成フォ2-
    private Map<String, String> createRecMapFor_2_2(int i) {
	Map<String, String> rec = new HashMap();
	
	// 営業所コード
	rec.put("conEigyoshoCd", "conEigyoshoCd" + i);
	// 適用開始日
	rec.put("conTekiyoKaishibi", "conTekiyoKaishibi" + i);
	// 適用名
	rec.put("conTekiyoMei", "conTekiyoMei" + i);
	// 適用終了
	rec.put("conTekiyoShuryo", "conTekiyoShuryo" + i);
	// 営業所名
	rec.put("knrDtlEigyoshoMei", "knrDtlEigyoshoMei" + i);
	// 営業所カナ名
	rec.put("knrDtlEigyoshoKanaMei", "knrDtlEigyoshoKanaMei" + i);
	// 営業所略称
	rec.put("knrDtlEigyoshoRyakusho", "knrDtlEigyoshoRyakusho" + i);
	// 英語表記
	rec.put("knrDtlEigoHyoki", "knrDtlEigoHyoki" + i);
	// 使用区分.集荷営業所
	rec.put("knrDtlShiyoShukaKbn", "knrDtlShiyoShukaKbn" + i);
	// 使用区分.配達営業所
	rec.put("knrDtlShiyoHaitatsuKbn", "knrDtlShiyoHaitatsuKbn" + i);
	// 使用区分.チャーター起点
	rec.put("knrDtlShiyoKitenKbn", "knrDtlShiyoKitenKbn" + i);
	// 使用区分.売上
	rec.put("knrDtlShiyoUriageKbn", "knrDtlShiyoUriageKbn" + i);
	// 使用区分.発券営業所
	rec.put("knrDtlShiyoHakkenKbn", "knrDtlShiyoHakkenKbn" + i);
	// 使用区分.車両管理
	rec.put("knrDtlShiyoSharyoKbn", "conTekiyoKaishibi" + i);
	// 使用区分.配達伝票出力営業所
	rec.put("knrDtlShiyoHaidenKbn", "knrDtlShiyoHaidenKbn" + i);
	// 送り状発行営業所コード
	rec.put("knrDtlOkurijoHakkoEigyoshoCd", "knrDtlOkurijoHakkoEigyoshoCd" + i);
	// 送り状発行営業所名
	rec.put("knrDtlOkurijoHakkoEigyoshoMei", "knrDtlOkurijoHakkoEigyoshoMei" + i);
	// 経理変換先コード
	rec.put("knrDtlKeirisakiHenkanCd", "knrDtlKeirisakiHenkanCd" + i);
	// 営業所種別コード
	rec.put("knrDtlHEigyoshoShubetsuCd", "knrDtlHEigyoshoShubetsuCd" + i);
	// 営業所種別
	rec.put("knrDtlEigyoshoShubetsu", "knrDtlEigyoshoShubetsu" + i);
	// 承認営業所区分コード
	rec.put("knrDtlHShoninEigyoshoKbnCd", "knrDtlHShoninEigyoshoKbnCd" + i);
	// 承認区分
	rec.put("knrDtlShoninKbn", "knrDtlShoninKbn" + i);
	// 郵便番号
	rec.put("khnDtlYubinBango", "khnDtlYubinBango" + i);
	// JISコード
	rec.put("khnDtlJisCd", "khnDtlJisCd" + i);
	// 住所1
	rec.put("khnDtlJusho1", "khnDtlJusho1" + i);
	// 住所2
	rec.put("khnDtlJusho2", "khnDtlJusho2" + i);
	// 住所3
	rec.put("khnDtlJusho3", "khnDtlJusho3" + i);
	// 住所4
	rec.put("khnDtlJusho4", "khnDtlJusho4" + i);
	// 空港コード
	rec.put("khnDtlKukoCd", "khnDtlKukoCd" + i);
	// 空港名
	rec.put("khnDtlKukoMei", "khnDtlKukoMei" + i);
	// 仕向地
	rec.put("khnDtlShimukeChi", "khnDtlShimukeChi" + i);
	// 仕向地名
	rec.put("khnDtlShimukeChiMei", "khnDtlShimukeChiMei" + i);
	// 集配地区コード
	rec.put("khnDtlShuhaiChikuCd", "khnDtlShuhaiChikuCd" + i);
	// 電話番号1
	rec.put("khnDtlTelBango1", "khnDtlTelBango1" + i);
	// 電話番号2
	rec.put("khnDtlTelBango2", "khnDtlTelBango2" + i);
	// 社内電話番号
	rec.put("khnDtlShanaiTelBango", "khnDtlShanaiTelBango" + i);
	// FAX番号
	rec.put("khnDtlFaxBango", "khnDtlFaxBango" + i);
	// 銀行口座コード
	rec.put("kzaDtlGinkoKozaCd", "kzaDtlGinkoKozaCd" + i);
	// 銀行口座名
	rec.put("kzaDtlGinkoKozaMei", "kzaDtlGinkoKozaMei" + i);
	// 金融機関コード
	rec.put("kzaDtlKinyuKikanCd", "kzaDtlKinyuKikanCd" + i);
	// 金融機関名
	rec.put("kzaDtlKinyuKikanMei", "kzaDtlKinyuKikanMei" + i);
	// 支店コード
	rec.put("kzaDtlShitenCd", "kzaDtlShitenCd" + i);
	// 支店名
	rec.put("kzaDtlShitenMei", "kzaDtlShitenMei" + i);
	// 口座種別コード
	rec.put("kzaDtlKozaShubetsuCd", "kzaDtlKozaShubetsuCd" + i);
	// 口座種別名
	rec.put("kzaDtlKozaShubetsuMei", "kzaDtlKozaShubetsuMei" + i);
	// 口座番号
	rec.put("kzaDtlKozaBango", "kzaDtlKozaBango" + i);
	// 名義人名
	rec.put("kzaDtlMeigininMei", "kzaDtlMeigininMei" + i);
	// 仕立営業所コード
	rec.put("orsDtlShitateEigyoshoCd", "orsDtlShitateEigyoshoCd" + i);
	// 仕立営業所名
	rec.put("orsDtlShitateEigyoshoMei", "orsDtlShitateEigyoshoMei" + i);
	// 他社中継卸値率
	rec.put("orsDtlTashaChukeiOroshineritsu", "orsDtlTashaChukeiOroshineritsu" + i);
	// 更新ユーザ
	rec.put("kshnDtlUser", "kshnDtlUser" + i);
	// 更新日時
	rec.put("kshnDtlKoshinNichiji", "kshnDtlKoshinNichiji" + i);
	// 最終使用日(売上管理)
	rec.put("kshnDtlSaishuShiyoHiUriageKanri", "kshnDtlSaishuShiyoHiUriageKanri" + i);
	// 最終使用日(卸計算)
	rec.put("kshnDtlSaishuShiyoHiOroshiKanri", "kshnDtlSaishuShiyoHiOroshiKanri" + i);
	// 最終使用日(仕入管理)
	rec.put("kshnDtlSaishuShiyoHiShiireKanri", "kshnDtlSaishuShiyoHiShiireKanri" + i);
	// 一見顧客登録フラグ
	rec.put("dtlHIchigenKokyakuTorokuFlg", "dtlHIchigenKokyakuTorokuFlg" + i);
	// 社内便登録フラグ
	rec.put("dtlHShanaiBinTorokuFlg", "dtlHShanaiBinTorokuFlg" + i);
	// 着払代引登録フラグ
	rec.put("dtlHChakubaraiDaibikiTorokuFlg", "dtlHChakubaraiDaibikiTorokuFlg" + i);
	// 旧住所フラグ
	rec.put("dtlHKyuJushoFlg", "dtlHKyuJushoFlg" + i);
	// 使用不可フラグ
	rec.put("dtlHShiyoFukaFlg", "dtlHShiyoFukaFlg" + i);
	// 新JISコード
	rec.put("dtlHShinJisCd", "dtlHShinJisCd" + i);
	// 営業所データバージョン
	rec.put("dtlEigyoshoDataVersion", "dtlEigyoshoDataVersion" + i);
	// 更新カウンタ
	rec.put("dtlKoshinCounter", "dtlKoshinCounter" + i);
	// 削除フラグ
	rec.put("dtlHSakujoFlg", "dtlHSakujoFlg" + i);
	// 適用終了日
	rec.put("tekiyoShuryobi", "tekiyoShuryobi" + i);
        return rec;     
    }
  
    private Map<String, String> createRecMapFor_11_1(int i) {
        Map recMap = new HashMap();
        recMap.put("LISTTEKIYOKAISHIBI", "1546272000000");
        return recMap;
    }
    
    // menuClick_正常_補充ケース_29_2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_29_2 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst042Form form = new Mst042Form();
        target.setMst042Form(form);
        target.menuClick("","");

        // 実施結果Outを取得
        form = target.getMst042Form();

    }
    
    // menuClick_正常_補充ケース_29_2_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_29_2_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(1);
       
        // テスト実行
        Mst042Form form = new Mst042Form();
        target.setMst042Form(form);
        target.menuClick("","");

        // 実施結果Outを取得
        form = target.getMst042Form();

    }

    // breadClumClick_正常_補充ケース_29_3
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_29_3 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst042Form form = new Mst042Form();
        target.setMst042Form(form);
        target.breadClumClick("",0);

        // 実施結果Outを取得
        form = target.getMst042Form();

    }
    
    // breadClumClick_正常_補充ケース_29_3_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_29_3_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(0); 
        // テスト実行
        Mst042Form form = new Mst042Form();
        target.setMst042Form(form);
        target.breadClumClick("",0);

        // 実施結果Outを取得
        form = target.getMst042Form();

    }

    // logoutClick_正常_補充ケース_29_4
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void logoutClick_正常_補充ケース_29_4 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mst042Form form = new Mst042Form();
        target.setMst042Form(form);
        target.logoutClick();

        // 実施結果Outを取得
        form = target.getMst042Form();

    }
    
    // insertUpdateEigyoshoInfo_正常_補充ケース_29_5
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void insertUpdateEigyoshoInfo_正常_補充ケース_29_5 () throws IllegalAccessException, InvocationTargetException, SystemException {

	// パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
	serviceInterfaceBean.addMessage("ERROR", "COME0002", "");
	serviceInterfaceBean.setTableName("TABLE_NAME");
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),
		functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
	
	// パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<String> detailCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), 
		summaryCaptor_4.capture(), detailCaptor_5.capture(), detailCaptor_6.capture());
	// テスト実行
	Mst042Form form = new Mst042Form();
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 卸単価情報リスト
	Map<String, Object> data = new HashMap<>();
	data.put("orsDtlListHDempyoShubetsuCd", "orsInfo1");
	List<Map<String, Object>> datasource = new ArrayList();
	datasource.add(data);
	form.setListOrsDtlSelectable(new ReportListDataModel(datasource));
	
	// 営業所グループ情報リスト
	Map<String, Object> egrpDtlListJoiEigyoshoCd = new HashMap<>();
	AutoCompOptionBean egrpDtlListSubSoshikiCdAut = new AutoCompOptionBean();
	egrpDtlListSubSoshikiCdAut.setValue("0001");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "orsInfo1");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListMainSoshiki", "true");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", egrpDtlListSubSoshikiCdAut);
	egrpDtlListJoiEigyoshoCd.put("hideFlg", "");
	egrpDtlListJoiEigyoshoCd.put("addFlg", "true");
	
	List<Map<String, Object>> data1 = new ArrayList();
	data1.add(egrpDtlListJoiEigyoshoCd);
	form.setListEgrpDtlSelectable(new ReportListDataModel(data1));
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 適用名
	form.setConTekiyoMei("適用名1");
	// 削除区分
	form.setDeleteKbn("1");
	form.setEditKbn("1");
	// 一見顧客登録フラグ
	form.setDtlHIchigenKokyakuTorokuFlg("1");
	// 社内便登録フラグ
	form.setDtlHShanaiBinTorokuFlg("1");
	// 着払代引登録フラグ
	form.setDtlHChakubaraiDaibikiTorokuFlg("1");
	
	Map<String, Object> resultEigyoshoInfo = new HashMap();
	resultEigyoshoInfo.put("conEigyoshoCd", conEigyoshoCd);
	resultEigyoshoInfo.put("conTekiyoKaishibi", "2018/06/05");
	resultEigyoshoInfo.put("conTekiyoShuryobi", "2038/12/19 23:59:59");
	resultEigyoshoInfo.put("dtlSakujoFlg", "1");
	resultEigyoshoInfo.put("dtlEigyoshoDataVersion", "1");
	form.setResultEigyoshoInfo(resultEigyoshoInfo);
	target.setMst042Form(form);
        target.insertUpdateEigyoshoInfo();

        // 実施結果Outを取得
        form = target.getMst042Form();
	
	assertEquals("ERROR", levelCaptor_3.getValue());
	assertEquals("COME0002", summaryCaptor_4.getValue());

    }
    
    // insertUpdateEigyoshoInfo_正常_補充ケース_29_6
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void insertUpdateEigyoshoInfo_正常_補充ケース_29_6 () throws IllegalAccessException, InvocationTargetException, SystemException {

	// パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
	serviceInterfaceBean.addMessage("ERROR", "COME0002", "");
	serviceInterfaceBean.setTableName("TABLE_NAME");
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),
		functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
	
	// パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<String> detailCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), 
		summaryCaptor_4.capture(), detailCaptor_5.capture(), detailCaptor_6.capture());
	// テスト実行
	Mst042Form form = new Mst042Form();
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 卸単価情報リスト
	Map<String, Object> data = new HashMap<>();
	data.put("orsDtlListHDempyoShubetsuCd", "orsInfo1");
	data.put("addFlg", "true");
	List<Map<String, Object>> datasource = new ArrayList();
	datasource.add(data);
	form.setListOrsDtlSelectable(new ReportListDataModel(datasource));
	
	// 営業所グループ情報リスト
	Map<String, Object> egrpDtlListJoiEigyoshoCd = new HashMap<>();
	AutoCompOptionBean egrpDtlListSubSoshikiCdAut = new AutoCompOptionBean();
	egrpDtlListSubSoshikiCdAut.setValue("0001");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "orsInfo1");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListMainSoshiki", "true");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", egrpDtlListSubSoshikiCdAut);
	egrpDtlListJoiEigyoshoCd.put("hideFlg", "");
	egrpDtlListJoiEigyoshoCd.put("addFlg", "true");
	
	List<Map<String, Object>> data1 = new ArrayList();
	data1.add(egrpDtlListJoiEigyoshoCd);
	form.setListEgrpDtlSelectable(new ReportListDataModel(data1));
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 適用名
	form.setConTekiyoMei("適用名1");
	// 削除区分
	form.setDeleteKbn("1");
	form.setEditKbn("1");
	// 一見顧客登録フラグ
	form.setDtlHIchigenKokyakuTorokuFlg("1");
	// 社内便登録フラグ
	form.setDtlHShanaiBinTorokuFlg("1");
	// 着払代引登録フラグ
	form.setDtlHChakubaraiDaibikiTorokuFlg("1");
	
	Map<String, Object> resultEigyoshoInfo = new HashMap();
	resultEigyoshoInfo.put("conEigyoshoCd", conEigyoshoCd);
	resultEigyoshoInfo.put("conTekiyoKaishibi", "2018/06/05");
	resultEigyoshoInfo.put("conTekiyoShuryobi", "2038/12/19 23:59:59");
	resultEigyoshoInfo.put("dtlSakujoFlg", "1");
	resultEigyoshoInfo.put("dtlEigyoshoDataVersion", "1");
	form.setResultEigyoshoInfo(resultEigyoshoInfo);
	target.setMst042Form(form);
        target.insertUpdateEigyoshoInfo();

        // 実施結果Outを取得
        form = target.getMst042Form();
	
	assertEquals("ERROR", levelCaptor_3.getValue());
	assertEquals("COME0002", summaryCaptor_4.getValue());

    }
    
    // insertUpdateEigyoshoInfo_正常_補充ケース_29_7
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void insertUpdateEigyoshoInfo_正常_補充ケース_29_7 () throws IllegalAccessException, InvocationTargetException, SystemException {

	// パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
	serviceInterfaceBean.addMessage("ERROR", "COME0002", "");
	serviceInterfaceBean.setTableName("TABLE_NAME");
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),
		functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
	
	// パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<String> detailCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), 
		summaryCaptor_4.capture(), detailCaptor_5.capture(), detailCaptor_6.capture());
	// テスト実行
	Mst042Form form = new Mst042Form();
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 卸単価情報リスト
	Map<String, Object> data = new HashMap<>();
	data.put("orsDtlListHDempyoShubetsuCd", "orsInfo1");
	List<Map<String, Object>> datasource = new ArrayList();
	datasource.add(data);
	form.setListOrsDtlSelectable(new ReportListDataModel(datasource));
	
	// 営業所グループ情報リスト
	Map<String, Object> egrpDtlListJoiEigyoshoCd = new HashMap<>();
	AutoCompOptionBean egrpDtlListSubSoshikiCdAut = new AutoCompOptionBean();
	egrpDtlListSubSoshikiCdAut.setValue("0001");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "orsInfo1");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListMainSoshiki", "true");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", egrpDtlListSubSoshikiCdAut);
	egrpDtlListJoiEigyoshoCd.put("hideFlg", "");
	egrpDtlListJoiEigyoshoCd.put("addFlg", "true");
	
	List<Map<String, Object>> data1 = new ArrayList();
	data1.add(egrpDtlListJoiEigyoshoCd);
	form.setListEgrpDtlSelectable(new ReportListDataModel(data1));
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 適用名
	form.setConTekiyoMei("適用名1");
	// 削除区分
	form.setDeleteKbn("1");
	form.setEditKbn("0");
	// 一見顧客登録フラグ
	form.setDtlHIchigenKokyakuTorokuFlg("1");
	// 社内便登録フラグ
	form.setDtlHShanaiBinTorokuFlg("1");
	// 着払代引登録フラグ
	form.setDtlHChakubaraiDaibikiTorokuFlg("1");
	
	Map<String, Object> resultEigyoshoInfo = new HashMap();
	resultEigyoshoInfo.put("conEigyoshoCd", conEigyoshoCd);
	resultEigyoshoInfo.put("conTekiyoKaishibi", "2018/06/05");
	resultEigyoshoInfo.put("conTekiyoShuryobi", "2038/12/19 23:59:59");
	resultEigyoshoInfo.put("dtlSakujoFlg", "1");
	resultEigyoshoInfo.put("dtlEigyoshoDataVersion", "1");
	form.setResultEigyoshoInfo(resultEigyoshoInfo);
	target.setMst042Form(form);
        target.insertUpdateEigyoshoInfo();

        // 実施結果Outを取得
        form = target.getMst042Form();
	
	assertEquals("ERROR", levelCaptor_3.getValue());
	assertEquals("COME0002", summaryCaptor_4.getValue());

    }
    
    // insertUpdateEigyoshoInfo_正常_補充ケース_29_8
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void insertUpdateEigyoshoInfo_正常_補充ケース_29_8 () throws IllegalAccessException, InvocationTargetException, SystemException {

	// パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
	serviceInterfaceBean.addMessage("ERROR", "COME0002", "");
	serviceInterfaceBean.setTableName("TABLE_NAME");
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),
		functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
	
	// パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<String> detailCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), 
		summaryCaptor_4.capture(), detailCaptor_5.capture(), detailCaptor_6.capture());
	// テスト実行
	Mst042Form form = new Mst042Form();
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 卸単価情報リスト
	Map<String, Object> data = new HashMap<>();
	data.put("orsDtlListHDempyoShubetsuCd", "orsInfo1");
	data.put("addFlg", "true");
	List<Map<String, Object>> datasource = new ArrayList();
	datasource.add(data);
	form.setListOrsDtlSelectable(new ReportListDataModel(datasource));
	
	// 営業所グループ情報リスト
	Map<String, Object> egrpDtlListJoiEigyoshoCd = new HashMap<>();
	AutoCompOptionBean egrpDtlListSubSoshikiCdAut = new AutoCompOptionBean();
	egrpDtlListSubSoshikiCdAut.setValue("0001");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "orsInfo1");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListMainSoshiki", "true");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", egrpDtlListSubSoshikiCdAut);
	egrpDtlListJoiEigyoshoCd.put("hideFlg", "");
	egrpDtlListJoiEigyoshoCd.put("addFlg", "true");
	
	List<Map<String, Object>> data1 = new ArrayList();
	data1.add(egrpDtlListJoiEigyoshoCd);
	form.setListEgrpDtlSelectable(new ReportListDataModel(data1));
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 適用名
	form.setConTekiyoMei("適用名1");
	// 削除区分
	form.setDeleteKbn("1");
	form.setEditKbn("0");
	// 一見顧客登録フラグ
	form.setDtlHIchigenKokyakuTorokuFlg("1");
	// 社内便登録フラグ
	form.setDtlHShanaiBinTorokuFlg("1");
	// 着払代引登録フラグ
	form.setDtlHChakubaraiDaibikiTorokuFlg("1");
	
	Map<String, Object> resultEigyoshoInfo = new HashMap();
	resultEigyoshoInfo.put("conEigyoshoCd", conEigyoshoCd);
	resultEigyoshoInfo.put("conTekiyoKaishibi", "2018/06/05");
	resultEigyoshoInfo.put("conTekiyoShuryobi", "2038/12/19 23:59:59");
	resultEigyoshoInfo.put("dtlSakujoFlg", "1");
	resultEigyoshoInfo.put("dtlEigyoshoDataVersion", "1");
	form.setResultEigyoshoInfo(resultEigyoshoInfo);
	target.setMst042Form(form);
        target.insertUpdateEigyoshoInfo();

        // 実施結果Outを取得
        form = target.getMst042Form();
	
	assertEquals("ERROR", levelCaptor_3.getValue());
	assertEquals("COME0002", summaryCaptor_4.getValue());
    }
    
    // insertUpdateEigyoshoInfo_正常_補充ケース_29_9
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void insertUpdateEigyoshoInfo_正常_補充ケース_29_9 () throws IllegalAccessException, InvocationTargetException, SystemException {

	// パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
	serviceInterfaceBean.addMessage("ERROR", "COME0002", "");
	serviceInterfaceBean.setTableName("TABLE_NAME");
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),
		functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
	
	// パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<String> detailCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), 
		summaryCaptor_4.capture(), detailCaptor_5.capture(), detailCaptor_6.capture());
	// テスト実行
	Mst042Form form = new Mst042Form();
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 卸単価情報リスト
	Map<String, Object> data = new HashMap<>();
	data.put("orsDtlListHDempyoShubetsuCd", "orsInfo1");
	data.put("addFlg", "true");
	List<Map<String, Object>> datasource = new ArrayList();
	datasource.add(data);
	form.setListOrsDtlSelectable(new ReportListDataModel(datasource));
	
	// 営業所グループ情報リスト
	Map<String, Object> egrpDtlListJoiEigyoshoCd = new HashMap<>();
	AutoCompOptionBean egrpDtlListSubSoshikiCdAut = new AutoCompOptionBean();
	egrpDtlListSubSoshikiCdAut.setValue("0001");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "orsInfo1");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListMainSoshiki", "true");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", egrpDtlListSubSoshikiCdAut);
	egrpDtlListJoiEigyoshoCd.put("hideFlg", "");
	egrpDtlListJoiEigyoshoCd.put("addFlg", "true");
	
	List<Map<String, Object>> data1 = new ArrayList();
	data1.add(egrpDtlListJoiEigyoshoCd);
	form.setListEgrpDtlSelectable(new ReportListDataModel(data1));
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 適用名
	form.setConTekiyoMei("適用名1");
	// 削除区分
	form.setDeleteKbn("1");
	form.setEditKbn("0");
	// 一見顧客登録フラグ
	form.setDtlHIchigenKokyakuTorokuFlg("1");
	// 社内便登録フラグ
	form.setDtlHShanaiBinTorokuFlg("1");
	// 着払代引登録フラグ
	form.setDtlHChakubaraiDaibikiTorokuFlg("1");
	
	Map<String, Object> resultEigyoshoInfo = new HashMap();
	resultEigyoshoInfo.put("conEigyoshoCd", conEigyoshoCd);
	resultEigyoshoInfo.put("conTekiyoKaishibi", "2018/06/05");
	resultEigyoshoInfo.put("conTekiyoShuryobi", "2038/12/19 23:59:59");
	resultEigyoshoInfo.put("dtlSakujoFlg", "1");
	resultEigyoshoInfo.put("dtlEigyoshoDataVersion", "1");
	form.setResultEigyoshoInfo(resultEigyoshoInfo);
	String[] Kbn =new String[]{"1"};
	form.setKnrDtlShiyoKbn(Kbn);
	// 送り状発行営業所コード
	AutoCompOptionBean knrDtlOkurijoHakkoEigyoshoCd = new AutoCompOptionBean();
	knrDtlOkurijoHakkoEigyoshoCd.setValue("0001");
	form.setKnrDtlOkurijoHakkoEigyoshoCd(knrDtlOkurijoHakkoEigyoshoCd);
	// 銀行口座コード
	form.setKzaDtlGinkoKozaCd(knrDtlOkurijoHakkoEigyoshoCd);
	// 仕立営業所コード
	form.setOrsDtlShitateEigyoshoCd(knrDtlOkurijoHakkoEigyoshoCd);
	
	target.setMst042Form(form);
        target.insertUpdateEigyoshoInfo();

        // 実施結果Outを取得
        form = target.getMst042Form();
	
	assertEquals("ERROR", levelCaptor_3.getValue());
	assertEquals("COME0002", summaryCaptor_4.getValue());

    }
    
    // delRows_正常_補充ケース_29_10
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void delRows_正常_補充ケース_29_10 () throws IllegalAccessException, InvocationTargetException, SystemException {
	
        Map<String, List<Map<String, Object>>> resMap1 = new HashMap();
        List<Map<String, Object>> resultList = Mockito.mock(List.class);
        Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 新JISコード
        recMap.put("tableEgrp_mst042", "tableEgrp_mst042");
        recMap.put("addFlg", null);
        when(resultList.size()).thenReturn(2);
        when(resultList.get(1)).thenReturn(recMap);
	when(resultList.get(2)).thenReturn(recMap);
	resultList.add(recMap);
	
        resMap1.put("tableEgrp_mst042", resultList);
        foucesDataList.put("tableEgrp_mst042", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap1);

        // テスト実行
        Mst042Form form = new Mst042Form();
	Map<String, Object> egrpDtlSelectedResult = new HashMap<>();
	egrpDtlSelectedResult.put("123", "123");
	List<Map<String, Object>> listEgrpDtlSelectedResult = new ArrayList();
	listEgrpDtlSelectedResult.add(egrpDtlSelectedResult);
	
	form.setListEgrpDtlSelectedResult(listEgrpDtlSelectedResult);
        target.setMst042Form(form);
        target.delRows("tableEgrp_mst042",resultList);

        // 実施結果Outを取得
        form = target.getMst042Form();
    
    }
    
    // delRows_正常_補充ケース_29_18
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void delRows_正常_補充ケース_29_18 () throws IllegalAccessException, InvocationTargetException, SystemException {
	
        Map<String, List<Map<String, Object>>> resMap1 = new HashMap();
        List<Map<String, Object>> resultList = Mockito.mock(List.class);
        Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 新JISコード
        recMap.put("tableOrs_mst042", "tableOrs_mst042");
        recMap.put("addFlg", null);
        when(resultList.size()).thenReturn(2);
        when(resultList.get(1)).thenReturn(recMap);
	when(resultList.get(2)).thenReturn(recMap);
	resultList.add(recMap);
	
        resMap1.put("tableOrs_mst042", resultList);
        foucesDataList.put("tableOrs_mst042", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap1);

        // テスト実行
        Mst042Form form = new Mst042Form();
	Map<String, Object> egrpDtlSelectedResult = new HashMap<>();
	egrpDtlSelectedResult.put("123", "123");
	List<Map<String, Object>> listEgrpDtlSelectedResult = new ArrayList();
	listEgrpDtlSelectedResult.add(egrpDtlSelectedResult);
	
	form.setListOrsDtlSelectedResult(listEgrpDtlSelectedResult);
        target.setMst042Form(form);
        target.delRows("tableOrs_mst042",resultList);

        // 実施結果Outを取得
        form = target.getMst042Form();
    
    }
   
    // insertUpdateEigyoshoInfo_正常_補充ケース_29_11
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void insertUpdateEigyoshoInfo_正常_補充ケース_29_11 () throws IllegalAccessException, InvocationTargetException, SystemException {

	// パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
	serviceInterfaceBean.addMessage("ERROR", "COME0002", "");
	serviceInterfaceBean.setTableName("TABLE_NAME");
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),
		functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
	
	// パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<String> detailCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), 
		summaryCaptor_4.capture(), detailCaptor_5.capture(), detailCaptor_6.capture());
	// テスト実行
	Mst042Form form = new Mst042Form();
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 卸単価情報リスト
	Map<String, Object> data = new HashMap<>();
	data.put("orsDtlListHDempyoShubetsuCd", "orsInfo1");
	data.put("addFlg", "true");
	List<Map<String, Object>> datasource = new ArrayList();
	datasource.add(data);
	form.setListOrsDtlSelectable(new ReportListDataModel(datasource));
	
	// 営業所グループ情報リスト
	Map<String, Object> egrpDtlListJoiEigyoshoCd = new HashMap<>();
	AutoCompOptionBean egrpDtlListSubSoshikiCdAut = new AutoCompOptionBean();
	egrpDtlListSubSoshikiCdAut.setValue("0001");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "orsInfo1");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListMainSoshiki", "true");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", egrpDtlListSubSoshikiCdAut);
	egrpDtlListJoiEigyoshoCd.put("hideFlg", "");
	egrpDtlListJoiEigyoshoCd.put("addFlg", "true");
	
	List<Map<String, Object>> data1 = new ArrayList();
	data1.add(egrpDtlListJoiEigyoshoCd);
	form.setListEgrpDtlSelectable(new ReportListDataModel(data1));
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 適用名
	form.setConTekiyoMei("適用名1");
	// 削除区分
	form.setDeleteKbn("1");
	form.setEditKbn("0");
	// 一見顧客登録フラグ
	form.setDtlHIchigenKokyakuTorokuFlg("1");
	// 社内便登録フラグ
	form.setDtlHShanaiBinTorokuFlg("1");
	// 着払代引登録フラグ
	form.setDtlHChakubaraiDaibikiTorokuFlg("1");
	
	Map<String, Object> resultEigyoshoInfo = new HashMap();
	resultEigyoshoInfo.put("conEigyoshoCd", conEigyoshoCd);
	resultEigyoshoInfo.put("conTekiyoKaishibi", "2018/06/05");
	resultEigyoshoInfo.put("conTekiyoShuryobi", "2038/12/19 23:59:59");
	resultEigyoshoInfo.put("dtlSakujoFlg", "1");
	resultEigyoshoInfo.put("dtlEigyoshoDataVersion", "1");
	form.setResultEigyoshoInfo(resultEigyoshoInfo);
	String[] Kbn =new String[]{"2"};
	form.setKnrDtlShiyoKbn(Kbn);
	// 送り状発行営業所コード
	AutoCompOptionBean knrDtlOkurijoHakkoEigyoshoCd = new AutoCompOptionBean();
	knrDtlOkurijoHakkoEigyoshoCd.setValue("0001");
	form.setKnrDtlOkurijoHakkoEigyoshoCd(knrDtlOkurijoHakkoEigyoshoCd);
	// 銀行口座コード
	form.setKzaDtlGinkoKozaCd(knrDtlOkurijoHakkoEigyoshoCd);
	// 仕立営業所コード
	form.setOrsDtlShitateEigyoshoCd(knrDtlOkurijoHakkoEigyoshoCd);
	
	target.setMst042Form(form);
        target.insertUpdateEigyoshoInfo();

        // 実施結果Outを取得
        form = target.getMst042Form();
	
	assertEquals("ERROR", levelCaptor_3.getValue());
	assertEquals("COME0002", summaryCaptor_4.getValue());

    }
    
    // insertUpdateEigyoshoInfo_正常_補充ケース_29_12
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void insertUpdateEigyoshoInfo_正常_補充ケース_29_12 () throws IllegalAccessException, InvocationTargetException, SystemException {

	// パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
	serviceInterfaceBean.addMessage("ERROR", "COME0002", "");
	serviceInterfaceBean.setTableName("TABLE_NAME");
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),
		functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
	
	// パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<String> detailCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), 
		summaryCaptor_4.capture(), detailCaptor_5.capture(), detailCaptor_6.capture());
	// テスト実行
	Mst042Form form = new Mst042Form();
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 卸単価情報リスト
	Map<String, Object> data = new HashMap<>();
	data.put("orsDtlListHDempyoShubetsuCd", "orsInfo1");
	data.put("addFlg", "true");
	List<Map<String, Object>> datasource = new ArrayList();
	datasource.add(data);
	form.setListOrsDtlSelectable(new ReportListDataModel(datasource));
	
	// 営業所グループ情報リスト
	Map<String, Object> egrpDtlListJoiEigyoshoCd = new HashMap<>();
	AutoCompOptionBean egrpDtlListSubSoshikiCdAut = new AutoCompOptionBean();
	egrpDtlListSubSoshikiCdAut.setValue("0001");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "orsInfo1");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListMainSoshiki", "true");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", egrpDtlListSubSoshikiCdAut);
	egrpDtlListJoiEigyoshoCd.put("hideFlg", "");
	egrpDtlListJoiEigyoshoCd.put("addFlg", "true");
	
	List<Map<String, Object>> data1 = new ArrayList();
	data1.add(egrpDtlListJoiEigyoshoCd);
	form.setListEgrpDtlSelectable(new ReportListDataModel(data1));
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 適用名
	form.setConTekiyoMei("適用名1");
	// 削除区分
	form.setDeleteKbn("1");
	form.setEditKbn("0");
	// 一見顧客登録フラグ
	form.setDtlHIchigenKokyakuTorokuFlg("1");
	// 社内便登録フラグ
	form.setDtlHShanaiBinTorokuFlg("1");
	// 着払代引登録フラグ
	form.setDtlHChakubaraiDaibikiTorokuFlg("1");
	
	Map<String, Object> resultEigyoshoInfo = new HashMap();
	resultEigyoshoInfo.put("conEigyoshoCd", conEigyoshoCd);
	resultEigyoshoInfo.put("conTekiyoKaishibi", "2018/06/05");
	resultEigyoshoInfo.put("conTekiyoShuryobi", "2038/12/19 23:59:59");
	resultEigyoshoInfo.put("dtlSakujoFlg", "1");
	resultEigyoshoInfo.put("dtlEigyoshoDataVersion", "1");
	form.setResultEigyoshoInfo(resultEigyoshoInfo);
	String[] Kbn =new String[]{"3"};
	form.setKnrDtlShiyoKbn(Kbn);
	// 送り状発行営業所コード
	AutoCompOptionBean knrDtlOkurijoHakkoEigyoshoCd = new AutoCompOptionBean();
	knrDtlOkurijoHakkoEigyoshoCd.setValue("0001");
	form.setKnrDtlOkurijoHakkoEigyoshoCd(knrDtlOkurijoHakkoEigyoshoCd);
	// 銀行口座コード
	form.setKzaDtlGinkoKozaCd(knrDtlOkurijoHakkoEigyoshoCd);
	// 仕立営業所コード
	form.setOrsDtlShitateEigyoshoCd(knrDtlOkurijoHakkoEigyoshoCd);
	
	target.setMst042Form(form);
        target.insertUpdateEigyoshoInfo();

        // 実施結果Outを取得
        form = target.getMst042Form();
	
	assertEquals("ERROR", levelCaptor_3.getValue());
	assertEquals("COME0002", summaryCaptor_4.getValue());

    }
    
    // insertUpdateEigyoshoInfo_正常_補充ケース_29_13
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void insertUpdateEigyoshoInfo_正常_補充ケース_29_13 () throws IllegalAccessException, InvocationTargetException, SystemException {

	// パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
	serviceInterfaceBean.addMessage("ERROR", "COME0002", "");
	serviceInterfaceBean.setTableName("TABLE_NAME");
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),
		functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
	
	// パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<String> detailCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), 
		summaryCaptor_4.capture(), detailCaptor_5.capture(), detailCaptor_6.capture());
	// テスト実行
	Mst042Form form = new Mst042Form();
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 卸単価情報リスト
	Map<String, Object> data = new HashMap<>();
	data.put("orsDtlListHDempyoShubetsuCd", "orsInfo1");
	data.put("addFlg", "true");
	List<Map<String, Object>> datasource = new ArrayList();
	datasource.add(data);
	form.setListOrsDtlSelectable(new ReportListDataModel(datasource));
	
	// 営業所グループ情報リスト
	Map<String, Object> egrpDtlListJoiEigyoshoCd = new HashMap<>();
	AutoCompOptionBean egrpDtlListSubSoshikiCdAut = new AutoCompOptionBean();
	egrpDtlListSubSoshikiCdAut.setValue("0001");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "orsInfo1");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListMainSoshiki", "true");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", egrpDtlListSubSoshikiCdAut);
	egrpDtlListJoiEigyoshoCd.put("hideFlg", "");
	egrpDtlListJoiEigyoshoCd.put("addFlg", "true");
	
	List<Map<String, Object>> data1 = new ArrayList();
	data1.add(egrpDtlListJoiEigyoshoCd);
	form.setListEgrpDtlSelectable(new ReportListDataModel(data1));
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 適用名
	form.setConTekiyoMei("適用名1");
	// 削除区分
	form.setDeleteKbn("1");
	form.setEditKbn("0");
	// 一見顧客登録フラグ
	form.setDtlHIchigenKokyakuTorokuFlg("1");
	// 社内便登録フラグ
	form.setDtlHShanaiBinTorokuFlg("1");
	// 着払代引登録フラグ
	form.setDtlHChakubaraiDaibikiTorokuFlg("1");
	
	Map<String, Object> resultEigyoshoInfo = new HashMap();
	resultEigyoshoInfo.put("conEigyoshoCd", conEigyoshoCd);
	resultEigyoshoInfo.put("conTekiyoKaishibi", "2018/06/05");
	resultEigyoshoInfo.put("conTekiyoShuryobi", "2038/12/19 23:59:59");
	resultEigyoshoInfo.put("dtlSakujoFlg", "1");
	resultEigyoshoInfo.put("dtlEigyoshoDataVersion", "1");
	form.setResultEigyoshoInfo(resultEigyoshoInfo);
	String[] Kbn =new String[]{"4"};
	form.setKnrDtlShiyoKbn(Kbn);
	// 送り状発行営業所コード
	AutoCompOptionBean knrDtlOkurijoHakkoEigyoshoCd = new AutoCompOptionBean();
	knrDtlOkurijoHakkoEigyoshoCd.setValue("0001");
	form.setKnrDtlOkurijoHakkoEigyoshoCd(knrDtlOkurijoHakkoEigyoshoCd);
	// 銀行口座コード
	form.setKzaDtlGinkoKozaCd(knrDtlOkurijoHakkoEigyoshoCd);
	// 仕立営業所コード
	form.setOrsDtlShitateEigyoshoCd(knrDtlOkurijoHakkoEigyoshoCd);
	
	target.setMst042Form(form);
        target.insertUpdateEigyoshoInfo();

        // 実施結果Outを取得
        form = target.getMst042Form();
	
	assertEquals("ERROR", levelCaptor_3.getValue());
	assertEquals("COME0002", summaryCaptor_4.getValue());

    }
    
    // insertUpdateEigyoshoInfo_正常_補充ケース_29_14
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void insertUpdateEigyoshoInfo_正常_補充ケース_29_14 () throws IllegalAccessException, InvocationTargetException, SystemException {

	// パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
	serviceInterfaceBean.addMessage("ERROR", "COME0002", "");
	serviceInterfaceBean.setTableName("TABLE_NAME");
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),
		functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
	
	// パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<String> detailCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), 
		summaryCaptor_4.capture(), detailCaptor_5.capture(), detailCaptor_6.capture());
	// テスト実行
	Mst042Form form = new Mst042Form();
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 卸単価情報リスト
	Map<String, Object> data = new HashMap<>();
	data.put("orsDtlListHDempyoShubetsuCd", "orsInfo1");
	data.put("addFlg", "true");
	List<Map<String, Object>> datasource = new ArrayList();
	datasource.add(data);
	form.setListOrsDtlSelectable(new ReportListDataModel(datasource));
	
	// 営業所グループ情報リスト
	Map<String, Object> egrpDtlListJoiEigyoshoCd = new HashMap<>();
	AutoCompOptionBean egrpDtlListSubSoshikiCdAut = new AutoCompOptionBean();
	egrpDtlListSubSoshikiCdAut.setValue("0001");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "orsInfo1");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListMainSoshiki", "true");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", egrpDtlListSubSoshikiCdAut);
	egrpDtlListJoiEigyoshoCd.put("hideFlg", "");
	egrpDtlListJoiEigyoshoCd.put("addFlg", "true");
	
	List<Map<String, Object>> data1 = new ArrayList();
	data1.add(egrpDtlListJoiEigyoshoCd);
	form.setListEgrpDtlSelectable(new ReportListDataModel(data1));
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 適用名
	form.setConTekiyoMei("適用名1");
	// 削除区分
	form.setDeleteKbn("1");
	form.setEditKbn("0");
	// 一見顧客登録フラグ
	form.setDtlHIchigenKokyakuTorokuFlg("1");
	// 社内便登録フラグ
	form.setDtlHShanaiBinTorokuFlg("1");
	// 着払代引登録フラグ
	form.setDtlHChakubaraiDaibikiTorokuFlg("1");
	
	Map<String, Object> resultEigyoshoInfo = new HashMap();
	resultEigyoshoInfo.put("conEigyoshoCd", conEigyoshoCd);
	resultEigyoshoInfo.put("conTekiyoKaishibi", "2018/06/05");
	resultEigyoshoInfo.put("conTekiyoShuryobi", "2038/12/19 23:59:59");
	resultEigyoshoInfo.put("dtlSakujoFlg", "1");
	resultEigyoshoInfo.put("dtlEigyoshoDataVersion", "1");
	form.setResultEigyoshoInfo(resultEigyoshoInfo);
	String[] Kbn =new String[]{"5"};
	form.setKnrDtlShiyoKbn(Kbn);
	// 送り状発行営業所コード
	AutoCompOptionBean knrDtlOkurijoHakkoEigyoshoCd = new AutoCompOptionBean();
	knrDtlOkurijoHakkoEigyoshoCd.setValue("0001");
	form.setKnrDtlOkurijoHakkoEigyoshoCd(knrDtlOkurijoHakkoEigyoshoCd);
	// 銀行口座コード
	form.setKzaDtlGinkoKozaCd(knrDtlOkurijoHakkoEigyoshoCd);
	// 仕立営業所コード
	form.setOrsDtlShitateEigyoshoCd(knrDtlOkurijoHakkoEigyoshoCd);
	
	target.setMst042Form(form);
        target.insertUpdateEigyoshoInfo();

        // 実施結果Outを取得
        form = target.getMst042Form();
	
	assertEquals("ERROR", levelCaptor_3.getValue());
	assertEquals("COME0002", summaryCaptor_4.getValue());

    }
    
    // insertUpdateEigyoshoInfo_正常_補充ケース_29_15
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void insertUpdateEigyoshoInfo_正常_補充ケース_29_15 () throws IllegalAccessException, InvocationTargetException, SystemException {

	// パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
	serviceInterfaceBean.addMessage("ERROR", "COME0002", "");
	serviceInterfaceBean.setTableName("TABLE_NAME");
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),
		functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
	
	// パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<String> detailCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), 
		summaryCaptor_4.capture(), detailCaptor_5.capture(), detailCaptor_6.capture());
	// テスト実行
	Mst042Form form = new Mst042Form();
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 卸単価情報リスト
	Map<String, Object> data = new HashMap<>();
	data.put("orsDtlListHDempyoShubetsuCd", "orsInfo1");
	data.put("addFlg", "true");
	List<Map<String, Object>> datasource = new ArrayList();
	datasource.add(data);
	form.setListOrsDtlSelectable(new ReportListDataModel(datasource));
	
	// 営業所グループ情報リスト
	Map<String, Object> egrpDtlListJoiEigyoshoCd = new HashMap<>();
	AutoCompOptionBean egrpDtlListSubSoshikiCdAut = new AutoCompOptionBean();
	egrpDtlListSubSoshikiCdAut.setValue("0001");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "orsInfo1");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListMainSoshiki", "true");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", egrpDtlListSubSoshikiCdAut);
	egrpDtlListJoiEigyoshoCd.put("hideFlg", "");
	egrpDtlListJoiEigyoshoCd.put("addFlg", "true");
	
	List<Map<String, Object>> data1 = new ArrayList();
	data1.add(egrpDtlListJoiEigyoshoCd);
	form.setListEgrpDtlSelectable(new ReportListDataModel(data1));
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 適用名
	form.setConTekiyoMei("適用名1");
	// 削除区分
	form.setDeleteKbn("1");
	form.setEditKbn("0");
	// 一見顧客登録フラグ
	form.setDtlHIchigenKokyakuTorokuFlg("1");
	// 社内便登録フラグ
	form.setDtlHShanaiBinTorokuFlg("1");
	// 着払代引登録フラグ
	form.setDtlHChakubaraiDaibikiTorokuFlg("1");
	
	Map<String, Object> resultEigyoshoInfo = new HashMap();
	resultEigyoshoInfo.put("conEigyoshoCd", conEigyoshoCd);
	resultEigyoshoInfo.put("conTekiyoKaishibi", "2018/06/05");
	resultEigyoshoInfo.put("conTekiyoShuryobi", "2038/12/19 23:59:59");
	resultEigyoshoInfo.put("dtlSakujoFlg", "1");
	resultEigyoshoInfo.put("dtlEigyoshoDataVersion", "1");
	form.setResultEigyoshoInfo(resultEigyoshoInfo);
	String[] Kbn =new String[]{"6"};
	form.setKnrDtlShiyoKbn(Kbn);
	// 送り状発行営業所コード
	AutoCompOptionBean knrDtlOkurijoHakkoEigyoshoCd = new AutoCompOptionBean();
	knrDtlOkurijoHakkoEigyoshoCd.setValue("0001");
	form.setKnrDtlOkurijoHakkoEigyoshoCd(knrDtlOkurijoHakkoEigyoshoCd);
	// 銀行口座コード
	form.setKzaDtlGinkoKozaCd(knrDtlOkurijoHakkoEigyoshoCd);
	// 仕立営業所コード
	form.setOrsDtlShitateEigyoshoCd(knrDtlOkurijoHakkoEigyoshoCd);
	
	target.setMst042Form(form);
        target.insertUpdateEigyoshoInfo();

        // 実施結果Outを取得
        form = target.getMst042Form();
	
	assertEquals("ERROR", levelCaptor_3.getValue());
	assertEquals("COME0002", summaryCaptor_4.getValue());

    }
    
    // insertUpdateEigyoshoInfo_正常_補充ケース_29_16
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void insertUpdateEigyoshoInfo_正常_補充ケース_29_16 () throws IllegalAccessException, InvocationTargetException, SystemException {

	// パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
	serviceInterfaceBean.addMessage("ERROR", "COME0002", "");
	serviceInterfaceBean.setTableName("TABLE_NAME");
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),
		functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
	
	// パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<String> detailCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), 
		summaryCaptor_4.capture(), detailCaptor_5.capture(), detailCaptor_6.capture());
	// テスト実行
	Mst042Form form = new Mst042Form();
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 卸単価情報リスト
	Map<String, Object> data = new HashMap<>();
	data.put("orsDtlListHDempyoShubetsuCd", "orsInfo1");
	data.put("addFlg", "true");
	List<Map<String, Object>> datasource = new ArrayList();
	datasource.add(data);
	form.setListOrsDtlSelectable(new ReportListDataModel(datasource));
	
	// 営業所グループ情報リスト
	Map<String, Object> egrpDtlListJoiEigyoshoCd = new HashMap<>();
	AutoCompOptionBean egrpDtlListSubSoshikiCdAut = new AutoCompOptionBean();
	egrpDtlListSubSoshikiCdAut.setValue("0001");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListJoiEigyoshoCd", "orsInfo1");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListMainSoshiki", "true");
	egrpDtlListJoiEigyoshoCd.put("egrpDtlListSubSoshikiCdAut", egrpDtlListSubSoshikiCdAut);
	egrpDtlListJoiEigyoshoCd.put("hideFlg", "");
	egrpDtlListJoiEigyoshoCd.put("addFlg", "true");
	
	List<Map<String, Object>> data1 = new ArrayList();
	data1.add(egrpDtlListJoiEigyoshoCd);
	form.setListEgrpDtlSelectable(new ReportListDataModel(data1));
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 適用名
	form.setConTekiyoMei("適用名1");
	// 削除区分
	form.setDeleteKbn("1");
	form.setEditKbn("0");
	// 一見顧客登録フラグ
	form.setDtlHIchigenKokyakuTorokuFlg("1");
	// 社内便登録フラグ
	form.setDtlHShanaiBinTorokuFlg("1");
	// 着払代引登録フラグ
	form.setDtlHChakubaraiDaibikiTorokuFlg("1");
	
	Map<String, Object> resultEigyoshoInfo = new HashMap();
	resultEigyoshoInfo.put("conEigyoshoCd", conEigyoshoCd);
	resultEigyoshoInfo.put("conTekiyoKaishibi", "2018/06/05");
	resultEigyoshoInfo.put("conTekiyoShuryobi", "2038/12/19 23:59:59");
	resultEigyoshoInfo.put("dtlSakujoFlg", "1");
	resultEigyoshoInfo.put("dtlEigyoshoDataVersion", "1");
	form.setResultEigyoshoInfo(resultEigyoshoInfo);
	String[] Kbn =new String[]{"7"};
	form.setKnrDtlShiyoKbn(Kbn);
	// 送り状発行営業所コード
	AutoCompOptionBean knrDtlOkurijoHakkoEigyoshoCd = new AutoCompOptionBean();
	knrDtlOkurijoHakkoEigyoshoCd.setValue("0001");
	form.setKnrDtlOkurijoHakkoEigyoshoCd(knrDtlOkurijoHakkoEigyoshoCd);
	// 銀行口座コード
	form.setKzaDtlGinkoKozaCd(knrDtlOkurijoHakkoEigyoshoCd);
	// 仕立営業所コード
	form.setOrsDtlShitateEigyoshoCd(knrDtlOkurijoHakkoEigyoshoCd);
	
	target.setMst042Form(form);
        target.insertUpdateEigyoshoInfo();

        // 実施結果Outを取得
        form = target.getMst042Form();
	
	assertEquals("ERROR", levelCaptor_3.getValue());
	assertEquals("COME0002", summaryCaptor_4.getValue());

    }
    
    // delRows_正常_補充ケース_29_17
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void deleteList_正常_補充ケース_29_17 () throws IllegalAccessException, InvocationTargetException, SystemException {

	// パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_2 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
	
	// Mockitoオブジェクトの予想return値設定
	ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
	serviceInterfaceBean.addMessage("ERROR", "MSTE0009", "該当のデータ");
	serviceInterfaceBean.setTableName("営業所マスタ");
	when(pageCommonBean.getDBInfo(paramsCaptor_2.capture(),
		functionCodeCaptor_3.capture())).thenReturn(serviceInterfaceBean);
	
	// パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<String> detailCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), 
		summaryCaptor_4.capture(), detailCaptor_5.capture(), detailCaptor_6.capture());
        
	// テスト実行
	Mst042Form form = new Mst042Form();
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("001");
	// 営業所コード
	form.setConEigyoshoCd(conEigyoshoCd);
	// 適用開始日
	form.setConTekiyoKaishibi("2018/06/05");
	// 適用終了日
	form.setTekiyoShuryobi("2038/12/19");
	// 適用名
	form.setConTekiyoMei("適用名1");
	// 削除区分
	form.setDeleteKbn("1");
	// 一見顧客登録フラグ
	form.setDtlHIchigenKokyakuTorokuFlg("0");
	// 社内便登録フラグ
	form.setDtlHShanaiBinTorokuFlg("0");
	// 着払代引登録フラグ
	form.setDtlHChakubaraiDaibikiTorokuFlg("1");
	
	Map<String, Object> resultEigyoshoInfo = new HashMap();
	resultEigyoshoInfo.put("conEigyoshoCd", conEigyoshoCd);
	resultEigyoshoInfo.put("conTekiyoKaishibi", "2018/06/05");
	resultEigyoshoInfo.put("conTekiyoShuryobi", "2038/12/19 23:59:59");
	resultEigyoshoInfo.put("dtlSakujoFlg", "1");
	resultEigyoshoInfo.put("dtlEigyoshoDataVersion", "1");
	form.setResultEigyoshoInfo(resultEigyoshoInfo);
	
	target.setMst042Form(form);
	target.deleteList();
	
	// 実施結果Outを取得
	form = target.getMst042Form();
	
	assertEquals("ERROR", levelCaptor_3.getValue());
	assertEquals("MSTE0009", summaryCaptor_4.getValue());
    
    }
      
}
