package jp.co.kintetsuls.beans.mst;

import java.io.IOException;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.LabelValueBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.forms.mst.Mst041Form;
import jp.co.kintetsuls.utils.FlashUtil;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

/**
 * @author 雷新然 (MBP)
 * @version 2019/3/12 新規作成
 */
public class Mst041BeanTest {

    @InjectMocks
    private Mst041Bean target;

    // Mockitoオブジェクト
    @Mock
    private FileBean fileBean;
    @Mock
    private AutoCompleteViewBean autoCompleteViewBean;
    @Mock
    private MasterInfoBean masterInfo;
    @Mock
    private MessagePropertyBean messageProperty;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosai;
    @Mock
    private SearchHelpBean searchHelpBean;
    @Mock
    private AuthorityConfBean authConfBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private FlashUtil flashUtil;

    public Mst041BeanTest() {
    }

    @Before
    public void setUp() {
	// Mockitoオブジェクト初期化
	MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() {
    }

    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[not null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1() throws IllegalAccessException, InvocationTargetException {

	// パラメータキャプチャー
	ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
	// Mockitoオブジェクトの予想return値設定
	Mst041Form mst041Form = new Mst041Form();

	// 前画面情報[not null]
	when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst041Form);

	// パラメータキャプチャー
	ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
	doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());

	// テスト実行
	Mst041Form form = new Mst041Form();
	target.setMst041Form(form);
	// 戻ってきた場合、再検索を実施する。
	target.init("", "MST031_SCREEN", true);

	// 実施結果Outを取得
	form = target.getMst041Form();

	String tilte = target.getTITLE();
	String url = target.getUrl();
	BreadCrumbBean breadBean = target.getBreadBean();
	AutoCompleteViewBean autoCompleteViewBean = target.getAutoCompleteViewBean();
	AuthorityConfBean authorityConfBean = target.getAuthorityConfBean();
	FileBean fileBean = target.getFileBean();
	MessagePropertyBean messagePropertyBean = target.getMessagePropertyBean();
	PageCommonBean pageCommonBean = target.getPageCommonBean();
	SearchHelpBean searchHelpBean = target.getSearchHelpBean();
	LabelValueBean labelValueBean = target.getLabelValueBean();
	RirekiSyosaiBean rirekiSyosaiBean = target.getRirekiSyosaiBean();
	Map<String, Object> rirekiSearchKey = target.getRirekiSearchKey();
	List<MessageModuleBean> msgList = target.getMsgList();

	target.setUrl(url);
	target.setBreadBean(breadBean);
	target.setAutoCompleteViewBean(autoCompleteViewBean);
	target.setAuthorityConfBean(authorityConfBean);
	target.setFileBean(fileBean);
	target.setMessagePropertyBean(messagePropertyBean);
	target.setPageCommonBean(pageCommonBean);
	target.setSearchHelpBean(searchHelpBean);
	target.setRirekiSyosaiBean(rirekiSyosaiBean);
	target.setRirekiSearchKey(rirekiSearchKey);
	target.setMsgList(msgList);

	// 実行時に渡すパラメータの検証
	assertEquals("mst041Form", keyCaptor_1.getValue());
	// 想定通りに再検索を実施する。
	assertEquals("search_mst041", keyCaptor_2.getValue());
    }

    // init_正常_初期処理_1_2_1
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[営業所コード = 006,営業所名 = 営業所6, 削除済のみ検索 = null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2_1() throws IllegalAccessException, InvocationTargetException,
	    InstantiationException {

	// Mockitoオブジェクトの予想return値設定
	Mst041Form mst041Form = new Mst041Form();
	// 前回検索パラメータ[営業所コード = 006, 営業所名 = 営業所6, 削除済のみ検索 = null]
	AutoCompOptionBean eigyoshoCd = new AutoCompOptionBean();
	eigyoshoCd.setValue("006");
	mst041Form.setConEigyoshoCd(eigyoshoCd);
	mst041Form.setConEigyoshoMei("営業所6");

	// ["01", "02", "03", "04", "05", "06"]
	mst041Form.setConSedaiKensakuJoken(null);
	mst041Form.setConSakujoSumiNomi(null);
	mst041Form.setConShiyoKbn(null);
	// Mockitoオブジェクトの予想return値設定
	Flash flash = new FlashKls();
	// 前画面パラメータ[営業所cd = 006,営業所名 = 営業所6, 削除済のみ検索 = null]
	flash.put("mst041Form", mst041Form);
	when(pageCommonBean.getPageParam()).thenReturn(flash);

	// パラメータキャプチャー
	ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
	doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());

	// テスト実行
	Mst041Form form = new Mst041Form();
	target.setMst041Form(form);
	// メニューをクリックする(false)
	target.init("testMenuID", "", false);

	// 実施結果Outを取得
	form = target.getMst041Form();

	// 想定通りに再検索を実施する。
	assertEquals("search_mst041", keyCaptor_2.getValue());
	assertEquals("006", form.getConEigyoshoCd().getValue());
	assertEquals(null, form.getConSakujoSumiNomi());
    }

    // init_正常_初期処理_1_2_2
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[営業所コード = 006, 営業所名 = 営業所6, 住所 = null, 仕向地名 = null, 削除済のみ検索 = null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2_2() throws IllegalAccessException, InvocationTargetException,
	    InstantiationException {

	// Mockitoオブジェクトの予想return値設定
	Mst041Form mst041Form = new Mst041Form();
	// 前回検索パラメータ[営業所コード = 006, 営業所名 = 営業所6, 住所 = null, 仕向地名 = null, 削除済のみ検索 = null]
	AutoCompOptionBean eigyoshoCd = new AutoCompOptionBean();
	eigyoshoCd.setValue("006");
	mst041Form.setConEigyoshoCd(eigyoshoCd);
	mst041Form.setConEigyoshoMei("営業所6");
	mst041Form.setConJusho(null);
	mst041Form.setConShimukeChiMei(null);
	// Mockitoオブジェクトの予想return値設定
	Flash flash = new FlashKls();
	// 前画面パラメータ[営業所コード = 006, 営業所名 = 営業所6, 住所 = null, 仕向地名 = null, 削除済のみ検索 = null]
	flash.put("mst041Form", mst041Form);
	when(pageCommonBean.getPageParam()).thenReturn(flash);

	// パラメータキャプチャー
	ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
	doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());

	// テスト実行
	Mst041Form form = new Mst041Form();
	target.setMst041Form(form);
	// メニューをクリックする(false)
	target.init("testMenuID", "", false);

	// 実施結果Outを取得
	form = target.getMst041Form();

	// 想定通りに再検索を実施する。
	assertEquals("search_mst041", keyCaptor_2.getValue());
	assertEquals(null, form.getConJusho());
	assertEquals(null, form.getConShimukeChiMei());
    }

    // init_正常_初期処理_1_3_1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3_1() throws IllegalAccessException, InvocationTargetException {

	// パラメータキャプチャー
	ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
	// Mockitoオブジェクトの予想return値設定
	// 前画面情報[null]
	when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(null);

	// テスト実行
	Mst041Form form = new Mst041Form();
	target.setMst041Form(form);
	// メニューをクリックする(false)
	target.init("testMenuID", "", false);

	// 実施結果Outを取得
	form = target.getMst041Form();

	// 実行時に渡すパラメータの検証
	assertEquals("mst041Form", keyCaptor_1.getValue());
	// 想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
	assertEquals(null, form.getSearchResult());
    }

    // init_正常_初期処理_1_3_2
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3_2() throws IllegalAccessException, InvocationTargetException {

	// パラメータキャプチャー
	ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
	// Mockitoオブジェクトの予想return値設定
	// 前画面情報[null]
	doThrow(IllegalAccessException.class).when(pageCommonBean).getPageInfo(keyCaptor_1.capture());

	// テスト実行
	Mst041Form form = new Mst041Form();
	target.setMst041Form(form);
	// メニューをクリックする(false)
	target.init("testMenuID", "", false);

	//実施結果Outを取得
	form = target.getMst041Form();

	// 実行時に渡すパラメータの検証
	assertEquals("mst041Form", keyCaptor_1.getValue());
	// 想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
	assertEquals(null, form.getSearchResult());
    }

    // search_正常_検索処理_2_1_1
    //
    // -------------------テスト条件--------------------------
    // 営業所検索結果一覧取得
    // 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_1_1() throws IllegalAccessException, InvocationTargetException {

	// パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
	// Mockitoオブジェクトの予想return値設定
	ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
	// 営業所検索結果一覧取得 件数 = 1
	List<Map<String, Object>> result = new ArrayList<>();
	for (int i = 0; i < 1; i++) {
	    result.add(createRecMapFor_2_1(i));
	}
	serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

	// テスト実行
	MasterInfoBean masterInfoBean = new MasterInfoBean();
	masterInfoBean.setAllEigyoshoSearch("0");
	when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
	Mst041Form form = new Mst041Form();
	AutoCompOptionBean eigyoshoCd = new AutoCompOptionBean();
	eigyoshoCd.setValue("conEigyoshoCd1");
	form.setConEigyoshoCd(eigyoshoCd);
	form.setConSedaiKensakuJoken(new String[]{"conSedaiKensakuJoken1"});
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd");
	form.setConTekiyoBi("2019/01/01");
	List<String> sakujo = new ArrayList<>();
	sakujo.add("01");
	form.setConSakujoSumiNomi(sakujo);
	form.setConShiyoKbn(new String[]{"conShiyoKbn1"});
	AutoCompOptionBean conShimukeChiCd = new AutoCompOptionBean();
	conShimukeChiCd.setLabel("conShimukeChi1");
	conShimukeChiCd.setValue("conShimukeChiCd1");
	form.setConShimukeChiCd(conShimukeChiCd);
	form.setConTekiyoMei("conTekiyoMei1");
	form.setConJusho("conJusho1");

	target.setMst041Form(form);
	target.search();

	// 実施結果Outを取得
	form = target.getMst041Form();

	// 実行時に渡すパラメータの検証
	assertEquals("conEigyoshoCd1", paramsCaptor_1.getValue().get("conEigyoshoCd"));
	String[] conSedaiKensakuJokenParam = (String[]) paramsCaptor_1.getValue().get("conSedaiKensakuJoken");
	assertEquals("conSedaiKensakuJoken1", conSedaiKensakuJokenParam[0]);
	String[] conShiyoKbnParam = (String[]) paramsCaptor_1.getValue().get("conShiyoKbn");
	assertEquals("conShiyoKbn1", conShiyoKbnParam[0]);
	assertEquals("conTekiyoMei1", paramsCaptor_1.getValue().get("conTekiyoMei"));
	assertEquals("conJusho1", paramsCaptor_1.getValue().get("conJusho"));
	// 想定通りに仕向地名マスタ一覧を表示されること
	assertForRecList_2_1(form);
    }

    // search_正常_検索処理_2_1_2
    //
    // -------------------テスト条件--------------------------
    // 営業所検索結果一覧取得
    // 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_検索処理_2_1_2() throws IllegalAccessException, InvocationTargetException {

	// パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
	// Mockitoオブジェクトの予想return値設定
	ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
	// 営業所検索結果一覧取得 件数 = 1
	int result = 1;
	serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

	// テスト実行
	MasterInfoBean masterInfoBean = new MasterInfoBean();
	masterInfoBean.setAllEigyoshoSearch("0");
	when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
	Mst041Form form = new Mst041Form();
	AutoCompOptionBean eigyoshoCd = new AutoCompOptionBean();
	eigyoshoCd.setValue("conEigyoshoCd1");
	form.setConEigyoshoCd(eigyoshoCd);
	form.setConSedaiKensakuJoken(new String[]{"conSedaiKensakuJoken1"});
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd");
	form.setConTekiyoBi("2019/01/01");
	List<String> sakujo = new ArrayList<>();
	sakujo.add("01");
	form.setConSakujoSumiNomi(sakujo);
	AutoCompOptionBean conShimukeChiCd = new AutoCompOptionBean("conShimukeChi1", "conShimukeChiCd1");

	form.setConShimukeChiCd(conShimukeChiCd);
	form.setConTekiyoMei("conTekiyoMei1");
	form.setConJusho("conJusho1");

	target.setMst041Form(form);
	target.getRecordCount(false);

	//実施結果Outを取得
	form = target.getMst041Form();
    }

    // search_正常_検索処理_2_1_3
    //
    // -------------------テスト条件--------------------------
    // 営業所検索結果一覧取得
    // 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_検索処理_2_1_3() throws IllegalAccessException, InvocationTargetException {

	// パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
	// Mockitoオブジェクトの予想return値設定
	ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
	// 営業所検索結果一覧取得 件数 = 1
	int result = 1;
	serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

	// テスト実行
	MasterInfoBean masterInfoBean = new MasterInfoBean();
	masterInfoBean.setAllEigyoshoSearch("0");
	when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
	Mst041Form form = new Mst041Form();
	AutoCompOptionBean eigyoshoCd = new AutoCompOptionBean();
	eigyoshoCd.setValue("conEigyoshoCd1");
	form.setConEigyoshoCd(eigyoshoCd);
	form.setConSedaiKensakuJoken(new String[]{"conSedaiKensakuJoken1"});
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd");
	form.setConTekiyoBi("2019/01/01");
	List<String> sakujo = new ArrayList<>();
	sakujo.add("01");
	form.setConSakujoSumiNomi(sakujo);
	form.setConTekiyoMei("conTekiyoMei1");
	form.setConJusho("conJusho1");

	target.setMst041Form(form);
	target.getRecordCount(false);

	// 実施結果Outを取得
	form = target.getMst041Form();
    }

    // search_正常_検索処理_2_1_4
    //
    // -------------------テスト条件--------------------------
    // 営業所検索結果一覧取得
    // 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_検索処理_2_1_4() throws IllegalAccessException, InvocationTargetException {

	// パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
	// Mockitoオブジェクトの予想return値設定
	ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
	// 営業所検索結果一覧取得 件数 = 1
	int result = 1;
	serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

	// テスト実行
	MasterInfoBean masterInfoBean = new MasterInfoBean();
	masterInfoBean.setAllEigyoshoSearch("0");
	when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
	Mst041Form form = new Mst041Form();
	AutoCompOptionBean eigyoshoCd = new AutoCompOptionBean();
	eigyoshoCd.setValue("conEigyoshoCd1");
	form.setConEigyoshoCd(eigyoshoCd);
	form.setConSedaiKensakuJoken(new String[]{"conSedaiKensakuJoken1"});
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd");
	form.setConTekiyoBi("2019/01/01");
	List<String> sakujo = new ArrayList<>();
	sakujo.add("01");
	form.setConSakujoSumiNomi(sakujo);
	form.setConJusho("conJusho1");

	target.setMst041Form(form);
	target.getRecordCount(false);

	//実施結果Outを取得
	form = target.getMst041Form();
    }

    // search_正常_検索処理_2_2_1
    //
    // -------------------テスト条件--------------------------
    // 営業所検索結果一覧取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_2_1() throws IllegalAccessException, InvocationTargetException {
	// パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
	// Mockitoオブジェクトの予想return値設定
	ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
	// 営業所検索結果一覧取得 取得件数 = 2
	List<Map<String, String>> result = new ArrayList<>();
	for (int i = 0; i <= 1; i++) {
	    result.add(createRecMapFor_2_2(i));
	}
	serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
		.thenReturn(serviceInterfaceBean);

	// テスト実行
	MasterInfoBean masterInfoBean = new MasterInfoBean();
	masterInfoBean.setAllEigyoshoSearch("0");
	when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
	Mst041Form form = new Mst041Form();
	AutoCompOptionBean eigyoshoCd = new AutoCompOptionBean();
	eigyoshoCd.setValue("conEigyoshoCd1");
	form.setConEigyoshoCd(eigyoshoCd);
	form.setConSedaiKensakuJoken(new String[]{"conSedaiKensakuJoken1"});
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd");
	form.setConTekiyoBi("2019/01/01");
	List<String> sakujo = new ArrayList<>();
	form.setConShiyoKbn(null);
	AutoCompOptionBean conShimukeChiCd = new AutoCompOptionBean();
	conShimukeChiCd.setLabel("conShimukeChi1");
	conShimukeChiCd.setValue("conShimukeChiCd1");
	form.setConShimukeChiCd(conShimukeChiCd);
	form.setConTekiyoMei("conTekiyoMei1");
	form.setConJusho("conJusho1");
	target.setMst041Form(form);
	target.search();

	// 実施結果Outを取得
	form = target.getMst041Form();

	// 想定通りに仕向地名マスタ一覧を表示されること
	assertForRecList_2_2(form);
    }

    // search_正常_検索処理_2_2_2
    //
    // -------------------テスト条件--------------------------
    // 営業所検索結果一覧取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_2_2() throws IllegalAccessException, InvocationTargetException {
	// パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
	// Mockitoオブジェクトの予想return値設定
	ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
	// 営業所検索結果一覧取得 取得件数 = 2
	List<Map<String, String>> result = new ArrayList<>();
	for (int i = 0; i <= 1; i++) {
	    result.add(createRecMapFor_2_2(i));
	}
	serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
		.thenReturn(serviceInterfaceBean);

	// テスト実行
	MasterInfoBean masterInfoBean = new MasterInfoBean();
	masterInfoBean.setAllEigyoshoSearch("0");
	when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
	Mst041Form form = new Mst041Form();
	AutoCompOptionBean eigyoshoCd = new AutoCompOptionBean();
	eigyoshoCd.setValue("conEigyoshoCd1");
	form.setConEigyoshoCd(eigyoshoCd);
	form.setConSedaiKensakuJoken(new String[]{"conSedaiKensakuJoken1"});
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd");
	form.setConTekiyoBi("2019/01/01");
	AutoCompOptionBean conShimukeChiCd = new AutoCompOptionBean();
	conShimukeChiCd.setLabel("conShimukeChi1");
	conShimukeChiCd.setValue("conShimukeChiCd1");
	form.setConShimukeChiCd(conShimukeChiCd);
	form.setConTekiyoMei("conTekiyoMei1");
	form.setConJusho("conJusho1");
	List<String> sakujo = new ArrayList<>();
	sakujo.add("01");
	form.setConSakujoSumiNomi(sakujo);
	target.setMst041Form(form);
	target.search();

	// 実施結果Outを取得
	form = target.getMst041Form();

	// 想定通りに仕向地名マスタ一覧を表示されること
	assertForRecList_2_2(form);
    }

    // search_異常_検索処理_2_3_1
    //
    // -------------------テスト条件--------------------------
    // 営業所検索結果一覧取得 取得件数 = 0
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_3_1() throws IllegalAccessException, InvocationTargetException {

	// パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
	// Mockitoオブジェクトの予想return値設定
	ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
	// 営業所検索結果一覧取得 取得件数 = 0
	Map<String, String> result = new HashMap<>();
	serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
	doThrow(IOException.class).when(pageCommonBean).getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture());

	MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
	List<Map<String, Object>> resultList = new ArrayList<>();
	// テスト実行
	Mst041Form form = new Mst041Form();
	
	form.setSearchResult(resultList);
        target.setMst041Form(form);
	target.search();
	
	// 実施結果Outを取得
        form = target.getMst041Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null, paramsCaptor_1.getValue().get("conEigyoshoCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoBi"));
        assertEquals(null, paramsCaptor_1.getValue().get("conShimukeChiCd"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyoMei"));
        assertEquals(null,(String[]) paramsCaptor_1.getValue().get("conSedaiKensakuJoken"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTekiyobi"));
        assertEquals("mst041-get-eigyosho-detail",functionCodeCaptor_2.getValue());
        // 想定通りに・一覧は表示しない（ヘッダーのみ） 
        // 想定通りに ・ファンクションボタンは表示（検索前と同じ） 
        assertForRecList_2_3(form);
	
    }

    // getEigyoshoListCount_正常_件数取得処理_2_4_1
    //
    // -------------------テスト条件--------------------------
    // 営業所検索件数取得 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void getEigyoshoListCount_正常_件数取得処理_2_4_1() throws IllegalAccessException, InvocationTargetException {

	// パラメータキャプチャー
	ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
	// Mockitoオブジェクトの予想return値設定
	ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
	// 営業所検索件数取得 取得件数 = 1
	int result = 1;
	serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
	when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
		.thenReturn(serviceInterfaceBean);

	// テスト実行
	Mst041Form form = new Mst041Form();
	MasterInfoBean masterInfoBean = new MasterInfoBean();
	masterInfoBean.setAllEigyoshoSearch("0");
	when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
	AutoCompOptionBean eigyoshoCd = new AutoCompOptionBean();
	eigyoshoCd.setValue("conEigyoshoCd1");
	form.setConEigyoshoCd(eigyoshoCd);
	form.setConSedaiKensakuJoken(new String[]{"conSedaiKensakuJoken1"});
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd");
	form.setConTekiyoBi("2019/01/01");
	List<String> sakujo = new ArrayList<>();
	sakujo.add("01");
	form.setConSakujoSumiNomi(sakujo);
	form.setConShiyoKbn(new String[]{"conShiyoKbn1"});
	AutoCompOptionBean conShimukeChiCd = new AutoCompOptionBean();
	conShimukeChiCd.setValue("conShimukeChi1");
	conShimukeChiCd.setLabel("conTekiyoMei1");
	form.setConShimukeChiCd(conShimukeChiCd);
	form.setConTekiyoMei("conTekiyoMei1");
	form.setConJusho("conJusho1");

	target.setMst041Form(form);
	target.getRecordCount(false);

	// 実施結果Outを取得
	form = target.getMst041Form();
    }

    // search_異常_検索処理_2-4_2
    //
    // -------------------テスト条件--------------------------
    // 営業所検索結果一覧取得 取得件数 = 0
    // -----------------------------------------------------
    @Test
    public void getSearchResult_正常_2_4_2() throws IllegalAccessException, InvocationTargetException {
	Mst041Form form = new Mst041Form();
	List<Map<String, Object>> searchList = new ArrayList<>();
	Map<String, Object> result = new HashMap<>();
	result.put("test", "test");
	searchList.add(result);
	form.setSearchResult(searchList);
	target.setMst041Form(form);
	target.getSearchResult();
    }

    // clear_正常_クリア処理_3-1
    //
    // -------------------テスト条件--------------------------
    // 検索条件と検索結果がある
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_1() throws IllegalAccessException, InvocationTargetException {

	// テスト実行
	Mst041Form form = new Mst041Form();
	// 検索条件と検索結果がある
	AutoCompOptionBean conEigyoshoCd = new AutoCompOptionBean();
	conEigyoshoCd.setValue("006");
	form.setConEigyoshoMei("営業所6");
	form.setConSedaiKensakuJoken(new String[]{"01"});
	List<String> sakujo = new ArrayList<>();
	sakujo.add("01");
	form.setConSakujoSumiNomi(sakujo);

	target.setMst041Form(form);
	target.clear();

	// 実施結果Outを取得
	form = target.getMst041Form();

	// 想定通りに正常にClearを実施されること
	// 営業所コード
	assertEquals(null, form.getConEigyoshoCd());
	// 営業所名
	assertEquals(null, form.getConEigyoshoMei());
	// 世代検索条件初期化、初期値 = { "01", "02" }
	assertEquals("01", form.getConSedaiKensakuJoken()[0]);
	assertEquals("02", form.getConSedaiKensakuJoken()[1]);
	// 適用日
	assertEquals(null, form.getConTekiyoBi());
	// 削除済のみ
	assertEquals(null, form.getConSakujoSumiNomi());
	// 使用区分
	assertEquals(null, form.getConShiyoKbn());
	// 仕向地コード
	assertEquals(null, form.getConShimukeChiCd());
	// 仕向地名
	assertEquals(null, form.getConShimukeChiMei());
	// 適用名
	assertEquals(null, form.getConTekiyoMei());
	// 住所w
	assertEquals(null, form.getConJusho());
    }

    // clear_正常_クリア処理_3-2
    //
    // -------------------テスト条件--------------------------
    // 検索条件がある、検索結果がない
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_2() throws IllegalAccessException, InvocationTargetException {

	// テスト実行
	Mst041Form form = new Mst041Form();
	target.setMst041Form(form);
	target.clear();

	// 実施結果Outを取得
	form = target.getMst041Form();

	// 想定通りに正常にClearを実施されること
	// 営業所コード
	assertEquals(null, form.getConEigyoshoCd());
	// 営業所名
	assertEquals(null, form.getConEigyoshoMei());
	// 世代検索条件初期化、初期値 = { "01", "02" }
	assertEquals("01", form.getConSedaiKensakuJoken()[0]);
	assertEquals("02", form.getConSedaiKensakuJoken()[1]);
	// 適用日
	assertEquals(null, form.getConTekiyoBi());
	// 削除済のみ
	assertEquals(null, form.getConSakujoSumiNomi());
	// 使用区分
	assertEquals(null, form.getConShiyoKbn());
	// 仕向地コード
	assertEquals(null, form.getConShimukeChiCd());
	// 仕向地名
	assertEquals(null, form.getConShimukeChiMei());
	// 適用名
	assertEquals(null, form.getConTekiyoMei());
	// 住所w
	assertEquals(null, form.getConJusho());
    }

    // getHeader_正常_ダウンロード_4-1
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void getHeader_正常_ダウンロード_4_1() throws IllegalAccessException, InvocationTargetException {

	// テスト実行
	Mst041Form form = new Mst041Form();
	target.setMst041Form(form);
	List<CSVDto> dto = target.getHeader();

	// 実施結果Outを取得
	form = target.getMst041Form();

	// 実行時に渡すパラメータの検証
	// 想定通りに正常にCVSのHeaderを設定されること
	assertEquals(null, form.getConEigyoshoCd());
	assertEquals(null, form.getConEigyoshoMei());
	assertEquals(null, form.getConShimukeChiCd());
	assertEquals(null, form.getConShimukeChiMei());
	assertEquals("営業所コード", dto.get(0).getTitle());
	assertEquals("listEigyoshoCd", dto.get(0).getName());
	assertEquals("営業所名", dto.get(1).getTitle());
	assertEquals("listEigyoshoMei", dto.get(1).getName());
    }

    // beforeDown_正常_ダウンロード処理_4_2
    //
    // -------------------テスト条件--------------------------
    // 警告条件を行う場合
    // -----------------------------------------------------
    @Test
    public void beforeDown_正常_ダウンロード処理_4_2() throws IllegalAccessException, InvocationTargetException {

	// テスト実行
	Mst041Form form = new Mst041Form();
	target.setMst041Form(form);

	try {
	    target.beforeDown("testComment");
	} catch (Exception ex) {
	    java.util.logging.Logger.getLogger(Mst041BeanTest.class.getName()).log(Level.SEVERE, null, ex);
	}

	// 実施結果Outを取得
	form = target.getMst041Form();

	// 実行時に渡すパラメータの検証
	// 想定通りに正常にダウンロード理由を記録すること
	assertEquals(null, form.getConEigyoshoMei());
    }

    // beforeDown_正常_ダウンロード処理_4_3
    //
    // -------------------テスト条件--------------------------
    // 警告条件を行う場合
    // -----------------------------------------------------
    @Test
    public void beforeDown_正常_ダウンロード処理_4_3() throws IllegalAccessException, InvocationTargetException {

	// テスト実行
	Mst041Form form = new Mst041Form();
	target.setMst041Form(form);

	try {
	    target.beforeDown("testComment");
	} catch (Exception ex) {
	    java.util.logging.Logger.getLogger(Mst041BeanTest.class.getName()).log(Level.SEVERE, null, ex);
	}

	// 実施結果Outを取得
	form = target.getMst041Form();

	// 実行時に渡すパラメータの検証
	// 想定通りに正常にダウンロード理由を記録すること
	assertEquals(null, form.getConEigyoshoMei());
    }

    // link_正常_営業所コードリンク_12_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void link_正常_営業所コードリンク_12_1() throws IllegalAccessException, InvocationTargetException, ParseException {

	// パラメータキャプチャー
	ArgumentCaptor<String> titleFlgCaptor_1 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<Map> searchKeyCaptor_3 = ArgumentCaptor.forClass(Map.class);
	// Mockitoオブジェクトの予想return値設定
	rirekiSyosai.searchList(titleFlgCaptor_1.capture(), functionCodeCaptor_2.capture(),
		searchKeyCaptor_3.capture());
	// テスト実行
	Mst041Form form = new Mst041Form();
	List<Map<String, Object>> result = new ArrayList<>();
	for (int i = 0; i < 1; i++) {
	    result.add(createRecMapFor_12_1(i));
	}
	form.setLinkSearchResult(createRecMapFor_12_1(1));
	target.setMst041Form(form);
	Flash flash = new FlashKls();
	flash.put("mst041form", null);
	when(pageCommonBean.getPageParam()).thenReturn(flash);

	when(flashUtil.getPageParam()).thenReturn(flash);

	AutoCompOptionBean eigyoshoCd = new AutoCompOptionBean();
	eigyoshoCd.setValue("conEigyoshoCd1");
	form.setConEigyoshoCd(eigyoshoCd);
	target.btnEigyoshoLinkClick();

	// 実施結果Outを取得
	form = target.getMst041Form();
    }

    // link_異常_営業所コードリンク_12
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void btnEigyoshoLinkClick_異常_営業所コードリンク_12_2() throws IllegalAccessException, InvocationTargetException, ParseException {

	// パラメータキャプチャー
	ArgumentCaptor<String> titleFlgCaptor_1 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<Map> searchKeyCaptor_3 = ArgumentCaptor.forClass(Map.class);
	// Mockitoオブジェクトの予想return値設定
	rirekiSyosai.searchList(titleFlgCaptor_1.capture(), functionCodeCaptor_2.capture(),
		searchKeyCaptor_3.capture());
	// テスト実行
	Mst041Form form = new Mst041Form();
	List<Map<String, Object>> result = new ArrayList<>();
	for (int i = 0; i < 1; i++) {
	    result.add(createRecMapFor_12_1(i));
	}
	form.setLinkSearchResult(createRecMapFor_12_1(1));
	target.setMst041Form(form);
	Flash flash = new FlashKls();
	flash.put("mst041form", null);
	when(pageCommonBean.getPageParam()).thenReturn(flash);

	when(flashUtil.getPageParam()).thenReturn(flash);

	AutoCompOptionBean eigyoshoCd = new AutoCompOptionBean();
	eigyoshoCd.setValue("conEigyoshoCd1");
	form.setConEigyoshoCd(eigyoshoCd);
	target.btnEigyoshoLinkClick();

	// 実施結果Outを取得
	form = target.getMst041Form();

    }

    // breadClumClick_異常_営業所コードリンク_12_3
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void convertShimukeChiCd_異常_営業所コードリンク_12_3() throws IllegalAccessException, InvocationTargetException {

	// パラメータキャプチャー
	ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
	// Mockitoオブジェクトの予想return値設定
	ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
	serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
	when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
		.thenReturn(serviceInterfaceBean);

	// パラメータキャプチャー
	ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
	// Mockitoオブジェクトの予想return値設定
	doNothing().when(messageProperty).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5
		.capture());

	// テスト実行
	Mst041Form form = new Mst041Form();
	AutoCompOptionBean conShimukeChiCd = new AutoCompOptionBean("test", "59988989");
	form.setConShimukeChiCd(conShimukeChiCd);
	target.setMst041Form(form);
	target.convertShimukeChiCd();

    }

    // detail_正常_詳細ボタン_14_1
    //
    // -------------------テスト条件--------------------------
    // 詳細ボタンクリック場合、一つを選択の場合
    // -----------------------------------------------------
    @Test
    public void detail_正常_詳細ボタン_14_1() throws IllegalAccessException, InvocationTargetException, ParseException {
	// パラメータキャプチャー
	ArgumentCaptor<String> titleFlgCaptor_1 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<Map> searchKeyCaptor_3 = ArgumentCaptor.forClass(Map.class);
	// テスト実行
	Mst041Form form = new Mst041Form();
	List<Map<String, Object>> result = new ArrayList<>();
	for (int i = 0; i < 1; i++) {
	    result.add(createRecMapFor_14(i));
	}
	form.setSelectedSearchResult(result);
	target.setMst041Form(form);
	Flash flash = new FlashKls();
	flash.put("mst041form", null);
	when(pageCommonBean.getPageParam()).thenReturn(flash);

	when(flashUtil.getPageParam()).thenReturn(flash);
	target.btnShousaiClick();

	// 実施結果Outを取得
	form = target.getMst041Form();
    }

    // detail_異常_詳細ボタン_14_2
    //
    // -------------------テスト条件--------------------------
    // 詳細ボタンクリック場合、何も選択してない場合
    // -----------------------------------------------------
    @Test
    public void detail_異常_詳細ボタン_14_2() throws IllegalAccessException, InvocationTargetException, ParseException {
	// パラメータキャプチャー
	ArgumentCaptor<String> titleFlgCaptor_1 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<Map> searchKeyCaptor_3 = ArgumentCaptor.forClass(Map.class);
	// Mockitoオブジェクトの予想return値設定
	// テスト実行
	Mst041Form form = new Mst041Form();
	List<Map<String, Object>> result = new ArrayList<>();
	for (int i = 0; i < 0; i++) {
	    result.add(createRecMapFor_14(i));
	}
	form.setSelectedSearchResult(result);
	target.setMst041Form(form);
	target.btnShousaiClick();

	// 実施結果Outを取得
	form = target.getMst041Form();
    }

    // detail_異常_詳細ボタン_14_3
    //
    // -------------------テスト条件--------------------------
    // 詳細ボタンクリック場合、複数を選択の場合
    // -----------------------------------------------------
    @Test
    public void detail_異常_詳細ボタン_14_3() throws IllegalAccessException, InvocationTargetException, ParseException {
	// テスト実行
	Mst041Form form = new Mst041Form();
	List<Map<String, Object>> result = new ArrayList<>();
	for (int i = 0; i < 2; i++) {
	    result.add(createRecMapFor_14(i));
	}
	form.setSelectedSearchResult(result);
	target.setMst041Form(form);
	target.btnShousaiClick();

	// 実施結果Outを取得
	form = target.getMst041Form();

    }

    // btnFukushaTorokuClick_正常_複写登録_15_1
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 1
    // -----------------------------------------------------
    @Test
    public void btnFukushaTorokuClick_正常_複写登録_15_1() throws IllegalAccessException, InvocationTargetException, ParseException {
	// パラメータキャプチャー
	ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
	// Mockitoオブジェクトの予想return値設定
	ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
	serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
	when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

	// パラメータキャプチャー
	ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
	// Mockitoオブジェクトの予想return値設定
	doNothing().when(messageProperty).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), detailCaptor_5.capture());
	// テスト実行
	Mst041Form form = new Mst041Form();
	// 行選択チェック選択 = 1
	List<Map<String, Object>> result = new ArrayList<>();
	for (int i = 0; i < 1; i++) {
	    result.add(createRecMapFor_15_1(i));
	}
	form.setSelectedSearchResult(result);
	target.setMst041Form(form);
	Flash flash = new FlashKls();
	flash.put("mst031form", null);
	when(pageCommonBean.getPageParam()).thenReturn(flash);

	when(flashUtil.getPageParam()).thenReturn(flash);
	target.btnFukushaTorokuClick();

	// 実施結果Outを取得
	form = target.getMst041Form();
    }

    // btnCopyTorokuClick_異常_複写登録_15_2
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // -----------------------------------------------------
    @Test
    public void btnCopyTorokuClick_異常_複写登録_15_2() throws IllegalAccessException, InvocationTargetException, ParseException {

	// パラメータキャプチャー
	ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
	// Mockitoオブジェクトの予想return値設定
	MessageModuleBean messageModuleBean = new MessageModuleBean();
	when(messageProperty.createMessageModule(levelCaptor_1.capture(), summaryCaptor_2.capture())).thenReturn(messageModuleBean);
	// テスト実行
	Mst041Form form = new Mst041Form();
	// 行選択チェック選択 = 0
	List<Map<String, Object>> result = new ArrayList<>();
	// 検索結果を設置する
	form.setSelectedSearchResult(result);

	target.setMst041Form(form);
	target.btnFukushaTorokuClick();

	// 実施結果Outを取得
	form = target.getMst041Form();
    }

    // btnCopyTorokuClick_異常_複写登録_15_3
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 2
    // -----------------------------------------------------
    @Test
    public void btnCopyTorokuClick_異常_複写登録_15_3() throws IllegalAccessException, InvocationTargetException, ParseException {

	// パラメータキャプチャー
	ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
	// Mockitoオブジェクトの予想return値設定
	MessageModuleBean messageModuleBean = new MessageModuleBean();
	when(messageProperty.createMessageModule(
		levelCaptor_1.capture(), summaryCaptor_2.capture())).thenReturn(messageModuleBean);
	// テスト実行
	Mst041Form form = new Mst041Form();
	// 行選択チェック選択 = 2
	List<Map<String, Object>> result = new ArrayList<>();
	for (int i = 0; i < 2; i++) {
	    result.add(createRecMapFor_15_1(i));
	}
	form.setSelectedSearchResult(result);
	target.setMst041Form(form);
	target.btnFukushaTorokuClick();

	// 実施結果Outを取得
	form = target.getMst041Form();
    }

    // detail_正常_更新履歴コンテキストメニュー_16_1
    //
    // -------------------テスト条件--------------------------
    // 詳細ボタンクリック場合、一つ目を選択した場合
    // -----------------------------------------------------
    @Test
    public void detail_正常_更新履歴コンテキストメニュー_16_1() throws IllegalAccessException, InvocationTargetException {
	// パラメータキャプチャー
	ArgumentCaptor<String> titleFlgCaptor_1 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
	ArgumentCaptor<Map> searchKeyCaptor_3 = ArgumentCaptor.forClass(Map.class);
	// Mockitoオブジェクトの予想return値設定
	doNothing().when(rirekiSyosai).searchList(titleFlgCaptor_1.capture(), functionCodeCaptor_2.capture(),
		searchKeyCaptor_3.capture());
	// テスト実行
	Mst041Form form = new Mst041Form();
	List<Map<String, Object>> result = new ArrayList<>();
	for (int i = 0; i < 1; i++) {
	    result.add(createRecMapFor_16(i));
	}
	form.setSelectedSearchResult(result);
	target.setMst041Form(form);
	target.rirekiIchiran();

	// 実施結果Outを取得
	form = target.getMst041Form();

	//想定通りに履歴を表示する。
	assertEquals("2", titleFlgCaptor_1.getValue());
	assertEquals("MST041_SEARCH_RIREKI", functionCodeCaptor_2.getValue());
	assertEquals("listEigyoshoCd0", searchKeyCaptor_3.getValue().get("listEigyoshoCd"));
	assertEquals("listTekiyoKaishibi0", searchKeyCaptor_3.getValue().get("listTekiyoKaishibi"));
    }

    // btnShinkiTorokuClick_正常_新規登録_18_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void btnShinkiTorokuClick_正常_新規登録_18_1() throws IllegalAccessException, InvocationTargetException {

	// テスト実行
	Mst041Form form = new Mst041Form();
	target.setMst041Form(form);
	Flash flash = new FlashKls();
	flash.put("mst041form", form);
	when(flashUtil.getPageParam()).thenReturn(flash);
	when(pageCommonBean.getPageParam()).thenReturn(flash);
	target.btnShinkiTorokuClick();

	// 実施結果Outを取得
	form = target.getMst041Form();
    }

    // searchChange_正常_補充ケース_20-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void searchChange_正常_補充ケース_20_1() throws IllegalAccessException, InvocationTargetException {
	// テスト実行
	Mst041Form form = new Mst041Form();
	target.setMst041Form(form);
	target.searchChange();

	// 実施結果Outを取得
	form = target.getMst041Form();

    }

    // menuClick_正常_補充ケース_20-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_20_2() throws IllegalAccessException, InvocationTargetException {
	// テスト実行
	Mst041Form form = new Mst041Form();
	target.setMst041Form(form);
	target.menuClick("", "");

	// 実施結果Outを取得
	form = target.getMst041Form();
    }

    // menuClick_正常_補充ケース_20-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_20_2_1() throws IllegalAccessException, InvocationTargetException {

	doThrow(IllegalAccessException.class).when(breadBean).pop(1);

	// テスト実行
	Mst041Form form = new Mst041Form();
	target.setMst041Form(form);
	target.menuClick("", "");

	// 実施結果Outを取得
	form = target.getMst041Form();

    }

    // breadClumClick_正常_補充ケース_20-3
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_20_3() throws IllegalAccessException, InvocationTargetException {

	// テスト実行
	Mst041Form form = new Mst041Form();
	target.setMst041Form(form);
	target.breadClumClick("", 0);

	// 実施結果Outを取得
	form = target.getMst041Form();

    }

    // breadClumClick_正常_補充ケース_20-3_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_20_3_1() throws IllegalAccessException, InvocationTargetException {

	doThrow(IllegalAccessException.class).when(breadBean).pop(0);

	// テスト実行
	Mst041Form form = new Mst041Form();
	target.setMst041Form(form);
	target.breadClumClick("", 0);

	// 実施結果Outを取得
	form = target.getMst041Form();

    }

    // logoutClick_正常_補充ケース_20-4
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void logoutClick_正常_補充ケース_20_4() throws IllegalAccessException, InvocationTargetException {

	// テスト実行
	Mst041Form form = new Mst041Form();
	target.setMst041Form(form);
	target.logoutClick();

	// 実施結果Outを取得
	form = target.getMst041Form();

    }

    // サンプルデータを作成フォ2-1
    private Map<String, Object> createRecMapFor_2_1(int i) {
	Map<String, Object> recMap = new HashMap();
	recMap.put("listEigyoshoCd", "listEigyoshoCd" + i);
	recMap.put("listEigyoshoMei", "listEigyoshoMei" + i);
	recMap.put("listSeidaiKensakuJoken", "listSeidaiKensakuJoken" + i);
	recMap.put("listTekiyoKaishibi", new Date());
	recMap.put("listSakujoSuminomi", "listSakujoSuminomi" + i);
	recMap.put("listShiyoKbn", "listShiyoKbn" + i);
	recMap.put("listShimukeChiCd", "listShimukeChiCd" + i);
	recMap.put("listTekiyoMei", "listTekiyoMei" + i);
	recMap.put("listJusho", "listJusho" + i);

	return recMap;
    }

    // サンプルデータを作成フォ2-2
    private Map<String, String> createRecMapFor_2_2(int i) {
	Map<String, String> recMap = new HashMap();
	recMap.put("listEigyoshoCd", "listEigyoshoCd" + i);
	recMap.put("listEigyoshoMei", "listEigyoshoMei" + i);
	recMap.put("listTekiyoBi", "listTekiyoBi" + i);
	recMap.put("listJusho", "listJusho" + i);
	recMap.put("listSaishuShiyoHiduke", "1553413109");
	recMap.put("listShimukeChiCd", "listShimukeChiCd" + i);
	recMap.put("listShimukeChiMei", "listShimukeChiMei" + i);

	return recMap;
    }

    private Map<String, Object> createRecMapFor_2_4(int i) {
	Map recMap = new HashMap();
	recMap.put("listEigyoshoCd", "listEigyoshoCd" + i);
	recMap.put("listEigyoshoMei", "listEigyoshoMei" + i);
	recMap.put("listSeidaiKensakuJoken", "listSeidaiKensakuJoken" + i);
	recMap.put("listTekiyoKaishibi", "listTekiyoKaishibi" + i);
	recMap.put("listSakujoSuminomi", "listSakujoSuminomi" + i);
	recMap.put("listShiyoKbn", "listShiyoKbn" + i);
	recMap.put("listShimukeChiCd", "listShimukeChiCd" + i);
	recMap.put("listTekiyoMei", "listTekiyoMei" + i);
	recMap.put("listJusho", "listJusho" + i);

	return recMap;
    }

    private Map<String, Object> createRecMapFor_12(int i) {
	Map recMap = new HashMap();

	recMap.put("listEigyoshoCd", "listEigyoshoCd" + i);
	recMap.put("listEigyoshoMei", "listEigyoshoMei" + i);
	recMap.put("listTekiyoKaishibi", Long.MAX_VALUE);
	recMap.put("listTekiyoMei", "listTekiyoMei" + i);
	recMap.put("listTekiyoShuryo", "listTekiyoShuryo" + i);

	return recMap;
    }

    private Map<String, Object> createRecMapFor_12_1(int i) {
	Map recMap = new HashMap();

	recMap.put("listEigyoshoCd", "listEigyoshoCd" + i);
	recMap.put("listEigyoshoMei", "listEigyoshoMei" + i);
	recMap.put("listTekiyoKaishibi", "2019/12/05");
	recMap.put("listTekiyoMei", "listTekiyoMei" + i);
	recMap.put("listTekiyoShuryo", "listTekiyoShuryo" + i);

	return recMap;
    }

    // サンプルデータを作成フォ14
    private Map<String, Object> createRecMapFor_14(int i) {
	Map recMap = new HashMap();

	recMap.put("listEigyoshoCd", "listEigyoshoCd" + i);
	recMap.put("listEigyoshoMei", "listEigyoshoMei" + i);
	recMap.put("listSeidaiKensakuJoken", "listSeidaiKensakuJoken" + i);
	recMap.put("listTekiyoKaishibi", "2018/12/25");
	recMap.put("listSakujoSuminomi", "listSakujoSuminomi" + i);
	recMap.put("listShiyoKbn", "listShiyoKbn" + i);
	recMap.put("listShimukeChiCd", "listShimukeChiCd" + i);
	recMap.put("listTekiyoMei", "listTekiyoMei" + i);
	recMap.put("listJusho", "listJusho" + i);
	if (i == 0) {
	    recMap.put("addFlg", true);
	}
	return recMap;
    }

    // サンプルデータを作成フォ15_1
    private Map<String, Object> createRecMapFor_15_1(int i) {
	Map recMap = new HashMap();
	recMap.put("listEigyoshoCd", "listEigyoshoCd" + i);
	recMap.put("listEigyoshoMei", "listEigyoshoMei" + i);
	recMap.put("listTekiyoKaishibi", "2019/12/25");
	recMap.put("listTekiyoMei", "listTekiyoMei" + i);
	recMap.put("listTekiyoShuryo", "listTekiyoShuryo" + i);

	return recMap;
    }

    // サンプルデータを作成フォ16
    private Map<String, Object> createRecMapFor_16(int i) {
	Map recMap = new HashMap();
	recMap.put("listEigyoshoCd", "listEigyoshoCd" + i);
	recMap.put("listEigyoshoMei", "listEigyoshoMei" + i);
	recMap.put("listSeidaiKensakuJoken", "listSeidaiKensakuJoken" + i);
	recMap.put("listTekiyoKaishibi", "listTekiyoKaishibi" + i);
	recMap.put("listSakujoSuminomi", "listSakujoSuminomi" + i);
	recMap.put("listShiyoKbn", "listShiyoKbn" + i);
	recMap.put("listShimukeChiCd", "listShimukeChiCd" + i);
	recMap.put("listTekiyoMei", "listTekiyoMei" + i);
	recMap.put("listJusho", "listJusho" + i);
	if (i == 0) {
	    recMap.put("fukushaFlg", 0);
	}
	return recMap;
    }

    //　サンプルデータをテストフォ2-1
    private void assertForRecList_2_1(Mst041Form form) {
	int i = 0;
	assertEquals(1, form.getSearchResult().size());
	for (Map<String, Object> rec : form.getSearchResult()) {
	    assertEquals("listEigyoshoCd" + i, rec.get("listEigyoshoCd"));
	    assertEquals("listEigyoshoMei" + i, rec.get("listEigyoshoMei"));
	    assertEquals("listSeidaiKensakuJoken" + i, rec.get("listSeidaiKensakuJoken"));
	    assertEquals("listSakujoSuminomi" + i, rec.get("listSakujoSuminomi"));
	    assertEquals("listShiyoKbn" + i, rec.get("listShiyoKbn"));
	    assertEquals("listTekiyoMei" + i, rec.get("listTekiyoMei"));
	    assertEquals("listJusho" + i, rec.get("listJusho"));
	    i++;
	}

    }

    //　サンプルデータをテストフォ2-2
    private void assertForRecList_2_2(Mst041Form form) {
	int i = 0;
	for (Map<String, Object> rec : form.getSearchResult()) {
	    assertEquals("listEigyoshoCd" + i, rec.get("listEigyoshoCd"));
	    assertEquals("listEigyoshoMei" + i, rec.get("listEigyoshoMei"));
	    assertEquals("listJusho" + i, rec.get("listJusho"));
	    assertEquals("listShimukeChiMei" + i, rec.get("listShimukeChiMei"));
	    i++;
	}
    }

    //　サンプルデータをテストフォ2-3
    private void assertForRecList_2_3(Mst041Form form) {
	int i = 0;
	assertEquals(0, form.getSearchResult().size());
	for (Map<String, Object> rec : form.getSearchResult()) {
	    assertEquals("listEigyoshoCd" + i, rec.get("listEigyoshoCd"));
	    assertEquals("listEigyoshoMei" + i, rec.get("listEigyoshoMei"));
	    assertEquals("listTekiyoBi" + i, rec.get("listTekiyoBi"));
	    assertEquals("listJusho" + i, rec.get("listJusho"));
	    assertEquals("listShimukeChiCd" + i, rec.get("listShimukeChiCd"));
	    assertEquals("listShimukeChiMei" + i, rec.get("listShimukeChiMei"));
	    i++;
	}
    }

}
