package jp.co.kintetsuls.beans.mwb;

import java.io.IOException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mwb.Mwb041Form;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.utils.FlashUtil;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * 仕向地名マスタ画面
 *
 * @author 廖鈺 (MBP)
 * @version 2019/3/08 新規作成
 */
public class Mwb041BeanTest {

    // テストTarget
    @InjectMocks
    private Mwb041Bean target;

    // Mockitoオブジェクト
    @Mock
    private FileBean fileBean;
    @Mock
    private AutoCompleteViewBean autoCompleteViewBean;
    @Mock
    private MasterInfoBean masterInfo;
    @Mock
    private MessagePropertyBean messageProperty;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosai;
    @Mock
    private SearchHelpBean searchHelpBean;
    @Mock
    private AuthorityConfBean authConfBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private MessagePropertyBean messagePropertyBean;
    @Mock
    private RirekiSyosaiBean rirekiSyosaiBean;
    @Mock
    private FlashUtil flashUtil;
    @Mock
    private BaseBean baseBean;
    @Mock
    private ListCheckBean listCheckBean;
    
    public Mwb041BeanTest() {
    }

    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() {
    }

    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[not null]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mwb041Form mwb041Form = new Mwb041Form();
        
        //前画面情報[not null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mwb041Form);

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        // テスト実行
        Mwb041Form form = new Mwb041Form();
        target.setMwb041Form(form);
        // 戻ってきた場合、再検索を実施する。
        target.init("","MWB031_SCREEN",true);

        // 実施結果Outを取得
        form = target.getMwb041Form();
        String title = target.getTITLE_NAME();
        String url = target.getUrl();
        BreadCrumbBean breadBean = target.getBreadBean();
        AutoCompleteViewBean autoCompleteViewBean = target.getAutoCompleteViewBean();
        AuthorityConfBean authorityConfBean  = target.getAuthorityConfBean();
        FileBean fileBean = target.getFileBean();
        MessagePropertyBean messagePropertyBean = target.getMessagePropertyBean();
        PageCommonBean pageCommonBean = target.getPageCommonBean();
        SearchHelpBean searchHelpBean = target.getSearchHelpBean();
        RirekiSyosaiBean rirekiSyosaiBean = target.getRirekiSyosaiBean();
        ListCheckBean listCheckBean = target.getListCheckBean();
        Map<String, Object> rirekiSearchKey = target.getRirekiSearchKey();
        List<MessageModuleBean> msgList = target.getMsgList();
        target.setUrl(url);
        target.setBreadBean(breadBean);
        target.setAutoCompleteViewBean(autoCompleteViewBean);
        target.setAuthorityConfBean(authorityConfBean);
        target.setFileBean(fileBean);
        target.setMessagePropertyBean(messagePropertyBean);
        target.setPageCommonBean(pageCommonBean);
        target.setSearchHelpBean(searchHelpBean);
        target.setRirekiSyosaiBean(rirekiSyosaiBean);
        target.setListCheckBean(listCheckBean);
        
        target.setRirekiSearchKey(rirekiSearchKey);
        target.setMsgList(msgList);

        // 実行時に渡すパラメータの検証
        assertEquals("mwb041Form",keyCaptor_1.getValue());
        // 想定通りに再検索を実施する。
        assertEquals("search_mwb041",keyCaptor_2.getValue());
    }

   // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ[ 発券営業所コード = "132"配布先営業所コード = "131"
    // 航空会社 = "ANA" MAWB番号 = "70000011" 
    // 搭載日付FROM = "2019/01/01" 搭載日付TO =  "2019/01/02" 表示条件選択="使用済"]
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2() throws IllegalAccessException, InvocationTargetException,
            InstantiationException, ParseException {

        // Mockitoオブジェクトの予想return値設定
        Mwb041Form mwb041Form = new Mwb041Form();
        
        AutoCompOptionBean conHakkenEigyoshoCd = new AutoCompOptionBean();
        conHakkenEigyoshoCd.setValue("132");
        AutoCompOptionBean conHaifusakiEigyoshoCd = new AutoCompOptionBean();
        conHaifusakiEigyoshoCd.setValue("131");
        String[] conHyojiJyokenSentaku = {"1"};
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        mwb041Form.setConHakkenEigyoshoCd(conHakkenEigyoshoCd);
        mwb041Form.setConHaifusakiEigyoshoCd(conHaifusakiEigyoshoCd);
        mwb041Form.setConKokuGaisha("ANA");
        mwb041Form.setConMawbBango("70000011");
        mwb041Form.setConTosaiHizukeFrom("2019/01/01");
        mwb041Form.setConTosaiHizukeTo("2019/01/02");
        mwb041Form.setConHyojiJyokenSentaku(conHyojiJyokenSentaku);
        
        // Mockitoオブジェクトの予想return値設定
        Flash flash =  new FlashKls();
        
        flash.put("mwb041Form", mwb041Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);        

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        // テスト実行
        Mwb041Form form = new Mwb041Form();
        target.setMwb041Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        // 実施結果Outを取得
        form = target.getMwb041Form();

        // 想定通りに再検索を実施する。
        assertEquals("search_mwb041",keyCaptor_2.getValue());
        assertEquals("132",form.getConHakkenEigyoshoCd().getValue());
        assertEquals("131",form.getConHaifusakiEigyoshoCd().getValue());
        assertEquals("ANA",form.getConKokuGaisha());
        assertEquals("2019/01/01",form.getConTosaiHizukeFrom());
        assertEquals("2019/01/02",form.getConTosaiHizukeTo());
        assertEquals(1,form.getConHyojiJyokenSentaku().length);
    }
    
    // init_正常_初期処理_1_2_1
    //
    // -------------------テスト条件--------------------------
    // 前回検索パラメータ
    // DBデータ戻り値
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2_1() throws IllegalAccessException, InvocationTargetException,
            InstantiationException, ParseException {

        // Mockitoオブジェクトの予想return値設定
        Mwb041Form mwb041Form = new Mwb041Form();
        
        // 前回検索パラメータ
        AutoCompOptionBean conHakkenEigyoshoCd = new AutoCompOptionBean();
        conHakkenEigyoshoCd.setValue("132");
        AutoCompOptionBean conHaifusakiEigyoshoCd = new AutoCompOptionBean();
        conHaifusakiEigyoshoCd.setValue("131");
        String[] conHyojiJyokenSentaku = {"1"};
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        mwb041Form.setConHakkenEigyoshoCd(conHakkenEigyoshoCd);
        mwb041Form.setConHaifusakiEigyoshoCd(conHaifusakiEigyoshoCd);
        mwb041Form.setConKokuGaisha("ANA");
        mwb041Form.setConMawbBango("70000011");
        mwb041Form.setConTosaiHizukeFrom("2019/01/01");
        mwb041Form.setConTosaiHizukeTo("2019/01/02");
        mwb041Form.setConHyojiJyokenSentaku(conHyojiJyokenSentaku);
        
        
        Flash flash =  new FlashKls();
        // 前画面パラメータ
        flash.put("mwb041Form", null);
        when(pageCommonBean.getPageParam()).thenReturn(flash);        

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_2 = ArgumentCaptor.forClass(String.class);
        doNothing().when(pageCommonBean).searchAgain(keyCaptor_2.capture());
        
        // テスト実行
        Mwb041Form form = new Mwb041Form();
        target.setMwb041Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        // 実施結果Outを取得
        form = target.getMwb041Form();

        // 想定通りに再検索を実施する。
        assertEquals(null,form.getConHyojiJyokenSentaku());
    } 

    // init_正常_初期処理_1-3
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        // 前画面情報[null]
        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(null);

        // テスト実行
        Mwb041Form form = new Mwb041Form();
        target.setMwb041Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        // 実施結果Outを取得
        form = target.getMwb041Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mwb041Form",keyCaptor_1.getValue());
        // 想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null,form.getSearchResult());
    }
    
    // init_正常_初期処理_1-3_1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        // 前画面情報[null]
        doThrow(IllegalAccessException.class).when(pageCommonBean).getPageInfo(keyCaptor_1.capture());

        // テスト実行
        Mwb041Form form = new Mwb041Form();
        target.setMwb041Form(form);
        // メニューをクリックする(false)
        target.init("testMenuID","",false);

        // 実施結果Outを取得
        form = target.getMwb041Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mwb041Form",keyCaptor_1.getValue());
        // 想定通りに検索しない、何もしない、各項目の初期状態は、詳細設計書の「画面項目定義」を参照。
        assertEquals(null,form.getSearchResult());
    }

    // search_正常_検索処理_2-1
    //
    // -------------------テスト条件--------------------------
    // 仕入予定検索結果一覧取得 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_1 () throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=0;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mwb041Form form = new Mwb041Form();
        AutoCompOptionBean conHakkenEigyoshoCd = new AutoCompOptionBean();
        conHakkenEigyoshoCd.setValue("132");
        AutoCompOptionBean conHaifusakiEigyoshoCd = new AutoCompOptionBean();
        conHaifusakiEigyoshoCd.setValue("131");
        String[] conHyojiJyokenSentaku = {"1"};
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        form.setConHakkenEigyoshoCd(conHakkenEigyoshoCd);
        form.setConHaifusakiEigyoshoCd(conHaifusakiEigyoshoCd);
        form.setConKokuGaisha("ANA");
        form.setConMawbBango("70000011");
        form.setConTosaiHizukeFrom("2019/01/01");
        form.setConTosaiHizukeTo("2019/01/02");
        form.setConHyojiJyokenSentaku(conHyojiJyokenSentaku);
        target.setMwb041Form(form);
        target.search();

        // 実施結果Outを取得
        form = target.getMwb041Form();

        // 実行時に渡すパラメータの検証
        assertEquals("132", paramsCaptor_1.getValue().get("conHakkenEigyoshoCd"));
        assertEquals("131", paramsCaptor_1.getValue().get("conHaifusakiEigyoshoCd"));
        assertEquals(new String[]{"1"},
                (String[]) paramsCaptor_1.getValue().get("conHyojiJyokenSentaku"));
        assertEquals("ANA", paramsCaptor_1.getValue().get("conKokuGaisha"));
        assertEquals("70000011", paramsCaptor_1.getValue().get("conMawbBango"));
        assertEquals("2019/01/01",paramsCaptor_1.getValue().get("conTosaiHizukeFrom"));
        assertEquals("2019/01/02", paramsCaptor_1.getValue().get("conTosaiHizukeTo"));
        assertEquals("mwb041_search", functionCodeCaptor_2.getValue());
        // 想定通りに一覧を表示されること
        assertForRecList_2_1(form);
    }    
    
        // search_異常_検索処理_2_1_1
    //
    // -------------------テスト条件--------------------------
    // 仕入予定検索結果一覧取得 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_1_1 () throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=0;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mwb041Form form = new Mwb041Form();
        AutoCompOptionBean conHakkenEigyoshoCd = new AutoCompOptionBean();
        conHakkenEigyoshoCd.setValue("132");
        AutoCompOptionBean conHaifusakiEigyoshoCd = new AutoCompOptionBean();
        conHaifusakiEigyoshoCd.setValue("131");
        String[] conHyojiJyokenSentaku = {"1"};
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        form.setConHakkenEigyoshoCd(conHakkenEigyoshoCd);
        form.setConHaifusakiEigyoshoCd(conHaifusakiEigyoshoCd);
        form.setConKokuGaisha("ANA");
        form.setConMawbBango("aaaaaaaa");
        form.setConTosaiHizukeFrom("2019/01/01");
        form.setConTosaiHizukeTo("2019/01/02");
        form.setConHyojiJyokenSentaku(conHyojiJyokenSentaku);
        target.setMwb041Form(form);
        target.searchCheck();

        // 実施結果Outを取得
        form = target.getMwb041Form();

    }
    
    // search_異常_検索処理_2_1_2
    //
    // -------------------テスト条件--------------------------
    // 仕入予定検索結果一覧取得 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_1_2 () throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=0;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mwb041Form form = new Mwb041Form();
        AutoCompOptionBean conHakkenEigyoshoCd = new AutoCompOptionBean();
        conHakkenEigyoshoCd.setValue("132");
        AutoCompOptionBean conHaifusakiEigyoshoCd = new AutoCompOptionBean();
        conHaifusakiEigyoshoCd.setValue("131");
        String[] conHyojiJyokenSentaku = {"1"};
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        form.setConHakkenEigyoshoCd(conHakkenEigyoshoCd);
        form.setConHaifusakiEigyoshoCd(conHaifusakiEigyoshoCd);
        form.setConKokuGaisha("ANA");
        form.setConMawbBango("70000011");
        form.setConTosaiHizukeFrom("2019/01/02");
        form.setConTosaiHizukeTo("2019/01/01");
        form.setConHyojiJyokenSentaku(conHyojiJyokenSentaku);
        target.setMwb041Form(form);
        target.searchCheck();

        // 実施結果Outを取得
        form = target.getMwb041Form();

    }

    // search_正常_検索処理_2_1_2
    //
    // -------------------テスト条件--------------------------
    // 仕入予定検索結果一覧取得 取得件数 = 1
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_1_3 () throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索結果一覧取得 件数 = 1
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=0;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(
                paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mwb041Form form = new Mwb041Form();
        AutoCompOptionBean conHakkenEigyoshoCd = new AutoCompOptionBean();
        conHakkenEigyoshoCd.setValue("132");
        AutoCompOptionBean conHaifusakiEigyoshoCd = new AutoCompOptionBean();
        conHaifusakiEigyoshoCd.setValue("131");
        String[] conHyojiJyokenSentaku = {"1"};
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        form.setConHakkenEigyoshoCd(conHakkenEigyoshoCd);
        form.setConHaifusakiEigyoshoCd(conHaifusakiEigyoshoCd);
        form.setConKokuGaisha("ANA");
        form.setConMawbBango("70000011");
        form.setConTosaiHizukeFrom("2019/01/01");
        form.setConTosaiHizukeTo("2019/01/02");
        form.setConHyojiJyokenSentaku(conHyojiJyokenSentaku);
        target.setMwb041Form(form);
        target.searchCheck();

        // 実施結果Outを取得
        form = target.getMwb041Form();

    }
    
   // search_異常_検索処理_2-2
    //
    // -------------------テスト条件--------------------------
    // 仕入予定検索結果一覧取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void search_正常_検索処理_2_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索結果一覧取得 取得件数 = 2
        List<Map<String, String>> result = new ArrayList<>();
        for (int i=0;i<=1;i++){
            result.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mwb041Form form = new Mwb041Form();
        AutoCompOptionBean conHakkenEigyoshoCd = new AutoCompOptionBean();
        conHakkenEigyoshoCd.setValue("132");
        AutoCompOptionBean conHaifusakiEigyoshoCd = new AutoCompOptionBean();
        conHaifusakiEigyoshoCd.setValue("131");
        String[] conHyojiJyokenSentaku = {"1"};
        form.setConHakkenEigyoshoCd(conHakkenEigyoshoCd);
        form.setConHaifusakiEigyoshoCd(conHaifusakiEigyoshoCd);
        form.setConKokuGaisha("ANA");
        form.setConHyojiJyokenSentaku(conHyojiJyokenSentaku);
        target.setMwb041Form(form);
        target.search();

        // 実施結果Outを取得
        form = target.getMwb041Form();

        // 実行時に渡すパラメータの検証
        assertEquals("132", paramsCaptor_1.getValue().get("conHakkenEigyoshoCd"));
        assertEquals("131", paramsCaptor_1.getValue().get("conHaifusakiEigyoshoCd"));
        assertEquals(new String[]{"1"},
                (String[]) paramsCaptor_1.getValue().get("conHyojiJyokenSentaku"));
        assertEquals("ANA", paramsCaptor_1.getValue().get("conKokuGaisha"));
        assertEquals(null, paramsCaptor_1.getValue().get("conMawbBango"));
        assertEquals(null,paramsCaptor_1.getValue().get("conTosaiHizukeFrom"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTosaiHizukeTo"));
        assertEquals("mwb041_search", functionCodeCaptor_2.getValue());
        // 想定通りに一覧を表示されること
        assertForRecList_2_2(form);
    }

    // search_正常_検索処理_2-3
    //
    // -------------------テスト条件--------------------------
    // 仕入予定検索結果一覧取得 取得件数 = 0
    // -----------------------------------------------------
    @Test
    public void search_異常_検索処理_2_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得 取得件数 = 0
        List<Map<String, String>> result = new ArrayList<>();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mwb041Form form = new Mwb041Form();
        AutoCompOptionBean conHakkenEigyoshoCd = new AutoCompOptionBean();
        conHakkenEigyoshoCd.setValue("132");
        AutoCompOptionBean conHaifusakiEigyoshoCd = new AutoCompOptionBean();
        conHaifusakiEigyoshoCd.setValue("123");
        String[] conHyojiJyokenSentaku = {"1"};
        form.setConHakkenEigyoshoCd(conHakkenEigyoshoCd);
        form.setConHaifusakiEigyoshoCd(conHaifusakiEigyoshoCd);
        form.setConKokuGaisha("ANA");
        form.setConHyojiJyokenSentaku(conHyojiJyokenSentaku);
        target.setMwb041Form(form);
        target.search();

        // 実施結果Outを取得
        form = target.getMwb041Form();

        // 実行時に渡すパラメータの検証
        assertEquals("132", paramsCaptor_1.getValue().get("conHakkenEigyoshoCd"));
        assertEquals("123", paramsCaptor_1.getValue().get("conHaifusakiEigyoshoCd"));
        assertEquals(new String[]{"1"},
                (String[]) paramsCaptor_1.getValue().get("conHyojiJyokenSentaku"));
        assertEquals("ANA", paramsCaptor_1.getValue().get("conKokuGaisha"));
        assertEquals(null, paramsCaptor_1.getValue().get("conMawbBango"));
        assertEquals(null,paramsCaptor_1.getValue().get("conTosaiHizukeFrom"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTosaiHizukeTo"));
        assertEquals("mwb041_search", functionCodeCaptor_2.getValue());
        // 想定通りに・一覧は表示しない（ヘッダーのみ） 
        // 想定通りに ・ファンクションボタンは表示（検索前と同じ） 
        assertForRecList_2_3(form);
    }
    
    // search_異常_件数取得処理_2-4_2
    //
    // -------------------テスト条件--------------------------
    // 仕入予定検索結果一覧取得
    // -----------------------------------------------------
    @Test
    public void search_異常_件数取得処理_2_3_1 () throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        doThrow(IOException.class).when(pageCommonBean).getDBInfo(paramsCaptor_1.capture(), 
                functionCodeCaptor_2.capture());
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mwb041Form form = new Mwb041Form();
        AutoCompOptionBean conHakkenEigyoshoCd = new AutoCompOptionBean();
        conHakkenEigyoshoCd.setValue("132");
        AutoCompOptionBean conHaifusakiEigyoshoCd = new AutoCompOptionBean();
        conHaifusakiEigyoshoCd.setValue("131");
        String[] conHyojiJyokenSentaku = {"1"};
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        form.setConHakkenEigyoshoCd(conHakkenEigyoshoCd);
        form.setConHaifusakiEigyoshoCd(conHaifusakiEigyoshoCd);
        form.setConKokuGaisha("ANA");
        form.setConMawbBango("70000011");
        form.setConTosaiHizukeFrom("2019/01/01");
        form.setConTosaiHizukeTo("2019/01/02");
        form.setConHyojiJyokenSentaku(conHyojiJyokenSentaku);
        target.setMwb041Form(form);
        target.search();

        // 実施結果Outを取得
        form = target.getMwb041Form();

        // 実行時に渡すパラメータの検証
        assertEquals("132", paramsCaptor_1.getValue().get("conHakkenEigyoshoCd"));
        assertEquals("131", paramsCaptor_1.getValue().get("conHaifusakiEigyoshoCd"));
        assertEquals(new String[]{"1"},
                (String[]) paramsCaptor_1.getValue().get("conHyojiJyokenSentaku"));
        assertEquals("ANA", paramsCaptor_1.getValue().get("conKokuGaisha"));
        assertEquals("70000011", paramsCaptor_1.getValue().get("conMawbBango"));
        assertEquals("2019/01/01",paramsCaptor_1.getValue().get("conTosaiHizukeFrom"));
        assertEquals("2019/01/02", paramsCaptor_1.getValue().get("conTosaiHizukeTo"));
        assertEquals("mwb041_search", functionCodeCaptor_2.getValue());
    } 

    // getRecordCount_正常_件数取得処理_2-4
    //
    // -------------------テスト条件--------------------------
    // 仕入予定検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_4 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 仕向地検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), 
                functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        // テスト実行
        Mwb041Form form = new Mwb041Form();
        AutoCompOptionBean conHakkenEigyoshoCd = new AutoCompOptionBean();
        conHakkenEigyoshoCd.setValue("132");
        AutoCompOptionBean conHaifusakiEigyoshoCd = new AutoCompOptionBean();
        conHaifusakiEigyoshoCd.setValue("123");
        String[] conHyojiJyokenSentaku = {"1"};
        form.setConHakkenEigyoshoCd(conHakkenEigyoshoCd);
        form.setConHaifusakiEigyoshoCd(conHaifusakiEigyoshoCd);
        form.setConKokuGaisha("ANA");
        form.setConHyojiJyokenSentaku(conHyojiJyokenSentaku);
        when(pageCommonBean.getPageInfo("mwb041Form")).thenReturn(form);
        target.setMwb041Form(form);
        target.getRecordCount(true);

        // 実施結果Outを取得
        form = target.getMwb041Form();

        // 実行時に渡すパラメータの検証
        assertEquals("132", paramsCaptor_1.getValue().get("conHakkenEigyoshoCd"));
        assertEquals("123", paramsCaptor_1.getValue().get("conHaifusakiEigyoshoCd"));
        assertEquals(new String[]{"1"},
                (String[]) paramsCaptor_1.getValue().get("conHyojiJyokenSentaku"));
        assertEquals("ANA", paramsCaptor_1.getValue().get("conKokuGaisha"));
        assertEquals(null, paramsCaptor_1.getValue().get("conMawbBango"));
        assertEquals(null,paramsCaptor_1.getValue().get("conTosaiHizukeFrom"));
        assertEquals(null, paramsCaptor_1.getValue().get("conTosaiHizukeTo"));
        assertEquals("mwb041_count",functionCodeCaptor_2.getValue());
        // 想定通りに正常にCountを実施されること
//        assertEquals(null,form.getConEigyoshoCd());
    }
    
    // getRecordCount_正常_件数取得処理_2-4_1
    //
    // -------------------テスト条件--------------------------
    // 仕入予定検索件数取得 取得件数 = 2
    // -----------------------------------------------------
    @Test
    public void getRecordCount_正常_件数取得処理_2_4_1 () throws IllegalAccessException, InvocationTargetException, ParseException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        // 検索件数取得 取得件数 = 2
        int result = 2;
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        

        // テスト実行
        Mwb041Form form = new Mwb041Form();
        AutoCompOptionBean conHakkenEigyoshoCd = new AutoCompOptionBean();
        conHakkenEigyoshoCd.setValue("132");
        AutoCompOptionBean conHaifusakiEigyoshoCd = new AutoCompOptionBean();
        conHaifusakiEigyoshoCd.setValue("131");
        String[] conHyojiJyokenSentaku = {"1"};
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        form.setConHakkenEigyoshoCd(conHakkenEigyoshoCd);
        form.setConHaifusakiEigyoshoCd(conHaifusakiEigyoshoCd);
        form.setConKokuGaisha("ANA");
        form.setConMawbBango("70000011");
        form.setConTosaiHizukeFrom("2019/01/01");
        form.setConTosaiHizukeTo("2019/01/02");
        form.setConHyojiJyokenSentaku(conHyojiJyokenSentaku);
        target.setMwb041Form(form);
        target.getRecordCount(false);

        // 実施結果Outを取得
        form = target.getMwb041Form();

        // 実行時に渡すパラメータの検証
        assertEquals("132", paramsCaptor_1.getValue().get("conHakkenEigyoshoCd"));
        assertEquals("131", paramsCaptor_1.getValue().get("conHaifusakiEigyoshoCd"));
        assertEquals(new String[]{"1"},
                (String[]) paramsCaptor_1.getValue().get("conHyojiJyokenSentaku"));
        assertEquals("ANA", paramsCaptor_1.getValue().get("conKokuGaisha"));
        assertEquals("70000011", paramsCaptor_1.getValue().get("conMawbBango"));
        assertEquals("2019/01/01",paramsCaptor_1.getValue().get("conTosaiHizukeFrom"));
        assertEquals("2019/01/02", paramsCaptor_1.getValue().get("conTosaiHizukeTo"));
        assertEquals("mwb041_count",functionCodeCaptor_2.getValue());
        //想定通りに正常にCountを実施されること
    }

    // clear_正常_クリア処理_3-1
    //
    // -------------------テスト条件--------------------------
    // 仕入予定検索条件と検索結果がある
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_1 () throws IllegalAccessException, InvocationTargetException, ParseException {

        // テスト実行
        Mwb041Form form = new Mwb041Form();
        // 検索条件と検索結果がある
        AutoCompOptionBean conHakkenEigyoshoCd = new AutoCompOptionBean();
        conHakkenEigyoshoCd.setValue("132");
        AutoCompOptionBean conHaifusakiEigyoshoCd = new AutoCompOptionBean();
        conHaifusakiEigyoshoCd.setValue("131");
        String[] conHyojiJyokenSentaku = {"1"};
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        form.setConHakkenEigyoshoCd(conHakkenEigyoshoCd);
        form.setConHaifusakiEigyoshoCd(conHaifusakiEigyoshoCd);
        form.setConKokuGaisha("ANA");
        form.setConMawbBango("70000011");
        form.setConTosaiHizukeFrom("2019/01/01");
        form.setConTosaiHizukeTo("2019/01/02");
        form.setConHyojiJyokenSentaku(conHyojiJyokenSentaku);

        target.setMwb041Form(form);
        target.clear();

        // 実施結果Outを取得
        form = target.getMwb041Form();

        // 想定通りに正常にClearを実施されること
        assertEquals(null,form.getConHakkenEigyoshoCd());
        assertEquals(null,form.getConHaifusakiEigyoshoCd());
        assertEquals(null,form.getConKokuGaisha());
        assertEquals(null,form.getConMawbBango());
        assertEquals(null,form.getConHyojiJyokenSentaku());
        assertEquals(null,form.getConTosaiHizukeFrom());
        assertEquals(null, form.getConTosaiHizukeTo());
    }

    // clear_正常_クリア処理_3-2
    //
    // -------------------テスト条件--------------------------
    // 検索条件がある、検索結果がない
    // -----------------------------------------------------
    @Test
    public void clear_正常_クリア処理_3_2 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mwb041Form form = new Mwb041Form();
        target.setMwb041Form(form);
        target.clear();

        // 実施結果Outを取得
        form = target.getMwb041Form();

        // 想定通りに正常にClearを実施されること
        assertEquals(null,form.getConHakkenEigyoshoCd());
        assertEquals(null,form.getConHaifusakiEigyoshoCd());
        assertEquals(null,form.getConKokuGaisha());
        assertEquals(null,form.getConMawbBango());
        assertEquals(null,form.getConHyojiJyokenSentaku());
        assertEquals(null,form.getConTosaiHizukeFrom());
        assertEquals(null, form.getConTosaiHizukeTo());
    }

    // getHeader_正常_ダウンロード_4-1
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void getHeader_正常_ダウンロード_4_1 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mwb041Form form = new Mwb041Form();
        AutoCompOptionBean conHakkenEigyoshoCd = new AutoCompOptionBean();
        conHakkenEigyoshoCd.setValue("132");
        AutoCompOptionBean conHaifusakiEigyoshoCd = new AutoCompOptionBean();
        conHaifusakiEigyoshoCd.setValue("131");
        String[] conHyojiJyokenSentaku = {"1"};
        form.setConHakkenEigyoshoCd(conHakkenEigyoshoCd);
        form.setConHaifusakiEigyoshoCd(conHaifusakiEigyoshoCd);
        form.setConKokuGaisha("ANA");
        form.setConHyojiJyokenSentaku(conHyojiJyokenSentaku);
        target.setMwb041Form(form);
        List<CSVDto> dto = target.getHeader();

        // 実施結果Outを取得
        form = target.getMwb041Form();

        // 実行時に渡すパラメータの検証
        assertEquals("132",form.getConHakkenEigyoshoCd().getValue());
        assertEquals("131",form.getConHaifusakiEigyoshoCd().getValue());
        assertEquals("ANA",form.getConKokuGaisha());
        assertEquals(null,form.getConMawbBango());
        assertEquals(1,form.getConHyojiJyokenSentaku().length);
        assertEquals(null,form.getConTosaiHizukeFrom());
        assertEquals(null, form.getConTosaiHizukeTo());
        
        // 想定通りに正常にCVSのHeaderを設定されること
        assertEquals("航空会社",dto.get(0).getTitle());
        assertEquals("listKokuGaishaCd",dto.get(0).getName());
        assertEquals("MAWB番号",dto.get(1).getTitle());
        assertEquals("listMawbBango",dto.get(1).getName());
    }

    // beforeDown_正常_ダウンロード_4-2
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=2件
    // -----------------------------------------------------
    @Test
    public void beforeDown_正常_ダウンロード_4_2 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mwb041Form form = new Mwb041Form();
        AutoCompOptionBean conHakkenEigyoshoCd = new AutoCompOptionBean();
        conHakkenEigyoshoCd.setValue("132");
        AutoCompOptionBean conHaifusakiEigyoshoCd = new AutoCompOptionBean();
        conHaifusakiEigyoshoCd.setValue("131");
        String[] conHyojiJyokenSentaku = {"1"};
        form.setConHakkenEigyoshoCd(conHakkenEigyoshoCd);
        form.setConHaifusakiEigyoshoCd(conHaifusakiEigyoshoCd);
        form.setConKokuGaisha("ANA");
        form.setConHyojiJyokenSentaku(conHyojiJyokenSentaku);
        target.setMwb041Form(form);
        try {
            target.beforeDown("testComment");
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(Mwb041BeanTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        // 実施結果Outを取得
        form = target.getMwb041Form();

        // 実行時に渡すパラメータの検証
        // 想定通りに正常にダウンロード理由を記録すること
        assertEquals("132",form.getConHakkenEigyoshoCd().getValue());
        assertEquals("131",form.getConHaifusakiEigyoshoCd().getValue());
        assertEquals("ANA",form.getConKokuGaisha());
        assertEquals(null,form.getConMawbBango());
        assertEquals(1,form.getConHyojiJyokenSentaku().length);
        assertEquals(null,form.getConTosaiHizukeFrom());
        assertEquals(null, form.getConTosaiHizukeTo());
    }    
    
    // getSearchResult_正常_ダウンロード_4-2
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=2件
    // -----------------------------------------------------
    @Test
    public void getSearchResult_正常_ダウンロード_4_3 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mwb041Form form = new Mwb041Form();
        AutoCompOptionBean conHakkenEigyoshoCd = new AutoCompOptionBean();
        conHakkenEigyoshoCd.setValue("132");
        AutoCompOptionBean conHaifusakiEigyoshoCd = new AutoCompOptionBean();
        conHaifusakiEigyoshoCd.setValue("131");
        String[] conHyojiJyokenSentaku = {"1"};
        form.setConHakkenEigyoshoCd(conHakkenEigyoshoCd);
        form.setConHaifusakiEigyoshoCd(conHaifusakiEigyoshoCd);
        form.setConKokuGaisha("ANA");
        form.setConHyojiJyokenSentaku(conHyojiJyokenSentaku);
        target.setMwb041Form(form);
        target.getSearchResult();

        // 実施結果Outを取得
        form = target.getMwb041Form();

        // 実行時に渡すパラメータの検証
        // 想定通りに正常にダウンロード理由を記録すること
        assertEquals("132",form.getConHakkenEigyoshoCd().getValue());
        assertEquals("131",form.getConHaifusakiEigyoshoCd().getValue());
        assertEquals("ANA",form.getConKokuGaisha());
        assertEquals(null,form.getConMawbBango());
        assertEquals(1,form.getConHyojiJyokenSentaku().length);
        assertEquals(null,form.getConTosaiHizukeFrom());
        assertEquals(null, form.getConTosaiHizukeTo());
    }
    
    // upload_正常_アップロード_4_3
    //
    // -------------------テスト条件--------------------------
    // 検索結果件数=1件
    // -----------------------------------------------------
    @Test
    public void upload_正常_アップロード_4_3() throws IllegalAccessException, InvocationTargetException {
        //テスト実行
        Mwb041Form form = new Mwb041Form();
        Flash flash = new FlashKls();
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        when(flashUtil.getPageParam()).thenReturn(flash);
        target.upload();
    }

    // rirekiIchiran_正常_更新履歴コンテキストメニュー_13-1
    //
    // -------------------テスト条件--------------------------
    // 正常に取得された場合
    // -----------------------------------------------------
    @Test
    public void rirekiIchiran_正常_更新履歴コンテキストメニュー_13_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> titleFlgCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Map> searchKeyCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(rirekiSyosaiBean).searchList(titleFlgCaptor_1.capture(),
                functionCodeCaptor_2.capture(),searchKeyCaptor_3.capture());
        // テスト実行
        Mwb041Form form = new Mwb041Form();
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_2(i));
        }
        form.setSelectedSearchResult(result);
        target.setMwb041Form(form);
        target.rirekiIchiran();

        // 実施結果Outを取得
        form = target.getMwb041Form();

        // 想定通りに履歴を表示する。
        assertEquals("2",titleFlgCaptor_1.getValue());
        assertEquals("MWB041_SEARCH_RIREKI",functionCodeCaptor_2.getValue());
        assertEquals("listKokuGaishaCd0",searchKeyCaptor_3.getValue().get("listKokuGaishaCd"));
        assertEquals("listKokuGaisha0",searchKeyCaptor_3.getValue().get("listKokuGaisha"));
        assertEquals("listMawbBango0",searchKeyCaptor_3.getValue().get("listMawbBango"));
    }   

    // update_正常_更新処理_更新登録_14-1
    //
    // -------------------テスト条件--------------------------
    // 都道府県コード、仕向地名コードの組み合わせが、仕向地名マスタに存在しています
    // -----------------------------------------------------
    @Test
    public void update_正常_更新処理_更新登録_14_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //都道府県コード、仕向地名コードの組み合わせが、仕向地名マスタに存在しています
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_SUCCESS);
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4
                .capture(),detailCaptor_5.capture());        
       
        ArgumentCaptor<Map> paramsCaptor_3 = ArgumentCaptor.forClass(Map.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        //仕向地検索結果一覧取得 件数 = 1
        List<Map<String, String>> resultS = new ArrayList<>();
        ArgumentCaptor<String> functionCodeCaptor_3 = ArgumentCaptor.forClass(String.class);
        for (int i = 0; i <= 0; i++) {
            resultS.add(createRecMapFor_1_1(i));
        }
        serviceInterfaceBean2.setJson(JSONUtil.makeJSONString(resultS));
        when(pageCommonBean.getDBInfo(paramsCaptor_3.capture(), functionCodeCaptor_3.capture()))
                .thenReturn(serviceInterfaceBean2);
        
        MasterInfoBean masterInfoBean = new MasterInfoBean();
        masterInfoBean.setAllEigyoshoSearch("0");
        when(pageCommonBean.getMasterInfo()).thenReturn(masterInfoBean);
        //テスト実行
        Map<String, String> searchMotoList = new HashMap<>();
        searchMotoList.put("listMawbBango0", "listMawbBango0");
        Mwb041Form form = new Mwb041Form();
        AutoCompOptionBean conHakkenEigyoshoCd = new AutoCompOptionBean();
        conHakkenEigyoshoCd.setValue("132");
        AutoCompOptionBean conHaifusakiEigyoshoCd = new AutoCompOptionBean();
        conHaifusakiEigyoshoCd.setValue("123");
        String[] conHyojiJyokenSentaku = {"1"};
        form.setConHakkenEigyoshoCd(conHakkenEigyoshoCd);
        form.setConHaifusakiEigyoshoCd(conHaifusakiEigyoshoCd);
        form.setConKokuGaisha("ANA");
        form.setConHyojiJyokenSentaku(conHyojiJyokenSentaku);
        form.setSearchMotoList(searchMotoList);
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }        
        form.setSelectedSearchResult(result);
        form.setSearchResultSelectable(new ReportListDataModel(result));
        target.setMwb041Form(form);
        target.update();
        //実施結果Outを取得
        form = target.getMwb041Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listKokuGaishaCd0",paramsCaptor_1_Param.get("listKokuGaishaCd"));
        assertEquals("listKokuGaisha0",paramsCaptor_1_Param.get("listKokuGaisha"));
        assertEquals("listMawbBango0",paramsCaptor_1_Param.get("listMawbBango"));
        assertEquals(Long.valueOf("1546272000000"),paramsCaptor_1_Param.get("listTosaiHizuke"));
        assertEquals("listTosaiBinMei0",paramsCaptor_1_Param.get("listTosaiBinMei"));
        assertEquals(Long.valueOf("1546272000000"),paramsCaptor_1_Param.get("listShisakuTekiyoHizuke"));
        assertEquals("mwb041_update",functionCodeCaptor_2.getValue());

    }    

    // update_異常_更新処理_更新登録_14-2
    //
    // -------------------テスト条件--------------------------
    // 実績MAWB番号に存在する[MWBE0002]が返却
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_14_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<List> paramsCaptor_1 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //都道府県コードが都道府県マスタに存在する[COME0006]が返却
        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean.addMessage("ERROR", "MWBE0002",
                "listMawbBango");
        when(pageCommonBean.accsessDBWithList(paramsCaptor_1.capture(), functionCodeCaptor_2.capture()))
                .thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> detailCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> tableNameCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),detailCaptor_5
                .capture(),tableNameCaptor_6.capture());

        //テスト実行
        Mwb041Form form = new Mwb041Form();

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
         form.setSelectedSearchResult(result);
        Map<String, String> searchMotoList = new HashMap<>();
        searchMotoList.put("listMawbBango0", "listMawbBango0");
        form.setSearchMotoList(searchMotoList);
        form.setSearchResultSelectable(new ReportListDataModel(result));
        target.setMwb041Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMwb041Form();

        // 実行時に渡すパラメータの検証
        Map<String, Object> paramsCaptor_1_Param = (Map<String, Object>) paramsCaptor_1.getValue().get(0);
        assertEquals("listKokuGaishaCd0",paramsCaptor_1_Param.get("listKokuGaishaCd"));
        assertEquals("listKokuGaisha0",paramsCaptor_1_Param.get("listKokuGaisha"));
        assertEquals("listMawbBango0",paramsCaptor_1_Param.get("listMawbBango"));
        assertEquals(Long.valueOf("1546272000000"),paramsCaptor_1_Param.get("listTosaiHizuke"));
        assertEquals("listTosaiBinMei0",paramsCaptor_1_Param.get("listTosaiBinMei"));
        assertEquals(Long.valueOf("1546272000000"),paramsCaptor_1_Param.get("listShisakuTekiyoHizuke"));
        assertEquals("mwb041_update_check",functionCodeCaptor_2.getValue());
        //想定通りにエラーが発生。（メッセージID：COME0006）
        assertEquals("ERROR",levelCaptor_3.getValue());
        assertEquals("MWBE0002",summaryCaptor_4.getValue());
    }    

    // update_異常_更新処理_更新登録_14-7
    //
    // -------------------テスト条件--------------------------
    // 行選択チェック選択 = 0
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_14_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        //テスト実行
        Mwb041Form form = new Mwb041Form();
        //行選択チェック選択 = 0
        List<Map<String, Object>> result = new ArrayList<>();
        form.setSelectedSearchResult(result);
        Map<String, String> searchMotoList = new HashMap<>();
        searchMotoList.put("listMawbBango", "listMawbBango0");
        form.setSearchMotoList(searchMotoList);
        form.setSearchResultSelectable(new ReportListDataModel(result));
        target.setMwb041Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMwb041Form();

        //想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("MWBE0011",summaryCaptor_2.getValue());
    }

    // update_異常_更新処理_更新登録_14-7_1
    //
    // -------------------テスト条件--------------------------
    // 変更された行が1行以なし
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_14_3_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        //テスト実行
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        Mwb041Form form = new Mwb041Form();
        Map<String, String> searchMotoList = new HashMap<>();
        searchMotoList.put("listMawbBango0", "listMawbBango0listKoguchiOkurijoNo0");
        form.setSearchMotoList(searchMotoList);
        form.setSelectedSearchResult(result);
        form.setSearchResultSelectable(new ReportListDataModel(result));
        target.setMwb041Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMwb041Form();

        //想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("MWBE0011",summaryCaptor_2.getValue());
    }    
    
    // update_異常_更新処理_更新登録_14_3_2
    //
    // -------------------テスト条件--------------------------
    // 小口送り状NO = null
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_14_3_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        when(messagePropertyBean.createMessageModule(levelCaptor_1.capture(),summaryCaptor_2.capture()))
                .thenReturn(messageModuleBean);
        //テスト実行
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1_1(i));
        }
        Mwb041Form form = new Mwb041Form();
        Map<String, String> searchMotoList = new HashMap<>();
        searchMotoList.put("listMawbBango0", "listMawbBango0");
        form.setSearchMotoList(searchMotoList);
        form.setSelectedSearchResult(result);
        form.setSearchResultSelectable(new ReportListDataModel(result));
        target.setMwb041Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMwb041Form();

        //想定通りにエラーが発生。（メッセージID：COME0029）
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("MWBE0011",summaryCaptor_2.getValue());
    }

    // update_異常_更新処理_更新登録_14-8
    //
    // -------------------テスト条件--------------------------
    // 一覧の単項目チェックメッセージリスト　= 0
    // -----------------------------------------------------
    @Test
    public void update_異常_更新処理_更新登録_14_3_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Boolean> datasCaptor_3 = ArgumentCaptor.forClass(Boolean.class);
        ArgumentCaptor<List> checksCaptor_4 = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<List> checksCaptor_5 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean2 = new MessageModuleBean();
        List<MessageModuleBean> msgList = new ArrayList<>();
        msgList.add(messageModuleBean2);

        when(listCheckBean.check(checksCaptor_4.capture(), checksCaptor_5.capture(), datasCaptor_3.capture()))
                .thenReturn(msgList); 

        //テスト実行
        Mwb041Form form = new Mwb041Form();
        //行選択チェック選択 = 1
        List<Map<String, Object>> result = new ArrayList<>();
        for (int i=0;i<1;i++){
            result.add(createRecMapFor_11_1(i));
        }
        form.setSelectedSearchResult(result);
        target.setMwb041Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMwb041Form();

}    
    
    // searchChange_正常_補充ケース_15-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void searchChange_正常_補充ケース_15_1 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mwb041Form form = new Mwb041Form();
        target.setMwb041Form(form);
        target.searchChange();

        // 実施結果Outを取得
        form = target.getMwb041Form();

    }

    // menuClick_正常_補充ケース_15-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_15_2 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mwb041Form form = new Mwb041Form();
        target.setMwb041Form(form);
        target.menuClick("","");

        // 実施結果Outを取得
        form = target.getMwb041Form();

    }
    
    // menuClick_正常_補充ケース_15-2-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_15_2_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(1);
       
        // テスト実行
        Mwb041Form form = new Mwb041Form();
        target.setMwb041Form(form);
        target.menuClick("","");

        // 実施結果Outを取得
        form = target.getMwb041Form();

    }

    // breadClumClick_正常_補充ケース_15-3
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_15_3 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mwb041Form form = new Mwb041Form();
        target.setMwb041Form(form);
        target.breadClumClick("",0);

        // 実施結果Outを取得
        form = target.getMwb041Form();

    }
    
    // breadClumClick_正常_補充ケース_15-3-1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_15_3_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(0); 
        // テスト実行
        Mwb041Form form = new Mwb041Form();
        target.setMwb041Form(form);
        target.breadClumClick("",0);

        // 実施結果Outを取得
        form = target.getMwb041Form();

    }

    // logoutClick_正常_補充ケース_15-4
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void logoutClick_正常_補充ケース_15_4 () throws IllegalAccessException, InvocationTargetException {

        // テスト実行
        Mwb041Form form = new Mwb041Form();
        target.setMwb041Form(form);
        target.logoutClick();

        // 実施結果Outを取得
        form = target.getMwb041Form();

    }
    
    private Map<String, String> createRecMapFor_1_1(int i) {
        Map recMap = new HashMap();
        recMap.put("listKokuGaishaCd", "listKokuGaishaCd" + i);
        // 航空会社名
        recMap.put("listKokuGaisha", "listKokuGaisha" + i);
        // MAWB番号	
        recMap.put("listMawbBango", "listMawbBango" + i);
        // 搭載日付
        recMap.put("listTosaiHizuke", Long.valueOf("1546272000000")); 
        // 搭載便名
        recMap.put("listTosaiBinMei", "listTosaiBinMei" + i);
        // 施策適用日付
        recMap.put("listShisakuTekiyoHizuke",Long.valueOf("1546272000000"));
        // 施策適用便名
        recMap.put("listShisakuTekiyoBinMei", "listShisakuTekiyoBinMei" + i);
        // 出発地空港コード
        recMap.put("listShuppatsuchiKukoCd", "listShuppatsuchiKukoCd" + i);
        // 出発地空港
        recMap.put("listShuppatsuchiKukoMei", "listShuppatsuchiKukoMei" + i);
        // 到着地空港コード
        recMap.put("listTochakuchiKukoCd", "listTochakuchiKukoCd" + i);
        // 到着地空港
        recMap.put("listTochakuchiKukoMei", "listTochakuchiKukoMei" + i);
        // 搭載重量(Kg)
        recMap.put("listTosaiJuryo", "listTosaiJuryo" + i);
        // 適用重量(Kg)
        recMap.put("listTekiyoJuryo", "listTekiyoJuryo" + i);
        // 最低搭載重量(Kg)
        recMap.put("listSaiteTosaiJuryo", "listSaiteTosaiJuryo" + i);
        // 一般運賃
        recMap.put("listIppanUnchin", "listIppanUnchin" + i);
        // 適用運賃
        recMap.put("listTekiyoUnchin", "listTekiyoUnchin" + i);
        // 代理店手数料
        recMap.put("listDairitenTesuryo", "listDairitenTesuryo" + i);
        // 支払金額
        recMap.put("listShiharaiKingakuZeikomi", "listShiharaiKingakuZeikomi" + i);
        // 小口送り状No
        recMap.put("listKoguchiOkurijoNo", "listKoguchiOkurijoNo" + i);
        // 品目明細コード
        recMap.put("listHimmokuMeisaiCd", "listHimmokuMeisaiCd" + i);
        // 運賃種別
        recMap.put("listUnchinShubetsu", "listUnchinShubetsu" + i);
        // 施策番号
        recMap.put("listShisakuBango", "listShisakuBango" + i);
        // 施策適用基準
        recMap.put("listShisakuTekiyoKijyun", "listShisakuTekiyoKijyun" + i);
        // 施策レート
        recMap.put("listShisakuRate", "listShisakuRate" + i);
        // 発券営業所コード
        recMap.put("listHakkenEigyoshoCd", "listHakkenEigyoshoCd" + i);
        // 発券営業所
        recMap.put("listHakkenEigyosho", "listHakkenEigyosho" + i);
        // 配布先営業所コード
        recMap.put("listHaifusakiEigyoshoCd", "listHaifusakiEigyoshoCd" + i);
        // 配布先営業所
        recMap.put("listHaifusakiEigyosho", "listHaifusakiEigyosho" + i);
        // 修正区分
        recMap.put("listShuseiKubun", "listShuseiKubun" + i);
        // 使用区分
        recMap.put("listShiyoKubun", "listShiyoKubun" + i);
        // MAWB登録ID
        recMap.put("listMawbTorokuId", "listMawbTorokuId" + i);
        // MAWB配布ID
        recMap.put("listMawbHaifuId", "listMawbHaifuId" + i);
        // 開始MAWB番号
        recMap.put("listKaishiMawbBango", "listKaishiMawbBango" + i);
        // 終了MAWB番号
        recMap.put("listShuryoMawbBango", "listShuryoMawbBango" + i);
        // 開始MAWB配布番号
        recMap.put("listKaishiHaifuMawbBango", "listKaishiHaifuMawbBango" + i);
        // 終了MAWB配布番号
        recMap.put("listShuryoHaifuMawbBango", "listShuryoHaifuMawbBango" + i);
        // 修正日付
        recMap.put("listSaishuOperationKoshinNichiji", "listSaishuOperationKoshinNichiji" + i);
        // MAWBデータバージョン
        recMap.put("listMawbDataVersion", "listMawbDataVersion" + i);
        return recMap;
    }

    private Map<String, Object> createRecMapFor_11_1(int i) {
        Map recMap = new HashMap();
                // 航空会社コード
        recMap.put("listKokuGaishaCd", "listKokuGaishaCd" + i);
        // 航空会社名
        recMap.put("listKokuGaisha", "listKokuGaisha" + i);
        // MAWB番号	
        recMap.put("listMawbBango", "listMawbBango" + i);
        // 搭載日付
        recMap.put("listTosaiHizuke", Long.valueOf("1546272000000")); 
        // 搭載便名
        recMap.put("listTosaiBinMei", "listTosaiBinMei" + i);
        // 施策適用日付
        recMap.put("listShisakuTekiyoHizuke",Long.valueOf("1546272000000"));
        // 施策適用便名
        recMap.put("listShisakuTekiyoBinMei", "listShisakuTekiyoBinMei" + i);
        // 出発地空港コード
        recMap.put("listShuppatsuchiKukoCd", "listShuppatsuchiKukoCd" + i);
        // 出発地空港
        recMap.put("listShuppatsuchiKukoMei", "listShuppatsuchiKukoMei" + i);
        // 到着地空港コード
        recMap.put("listTochakuchiKukoCd", "listTochakuchiKukoCd" + i);
        // 到着地空港
        recMap.put("listTochakuchiKukoMei", "listTochakuchiKukoMei" + i);
        // 搭載重量(Kg)
        recMap.put("listTosaiJuryo", "listTosaiJuryo" + i);
        // 適用重量(Kg)
        recMap.put("listTekiyoJuryo", "listTekiyoJuryo" + i);
        // 最低搭載重量(Kg)
        recMap.put("listSaiteTosaiJuryo", "listSaiteTosaiJuryo" + i);
        // 一般運賃
        recMap.put("listIppanUnchin", "listIppanUnchin" + i);
        // 適用運賃
        recMap.put("listTekiyoUnchin", "listTekiyoUnchin" + i);
        // 代理店手数料
        recMap.put("listDairitenTesuryo", "listDairitenTesuryo" + i);
        // 支払金額
        recMap.put("listShiharaiKingakuZeikomi", "listShiharaiKingakuZeikomi" + i);
        // 小口送り状No
        recMap.put("listKoguchiOkurijoNo", "listKoguchiOkurijoNo" + i);
        // 品目明細コード
        recMap.put("listHimmokuMeisaiCd", "listHimmokuMeisaiCd" + i);
        // 運賃種別
        recMap.put("listUnchinShubetsu", "listUnchinShubetsu" + i);
        // 施策番号
        recMap.put("listShisakuBango", "listShisakuBango" + i);
        // 施策適用基準
        recMap.put("listShisakuTekiyoKijyun", "listShisakuTekiyoKijyun" + i);
        // 施策レート
        recMap.put("listShisakuRate", "listShisakuRate" + i);
        // 発券営業所コード
        recMap.put("listHakkenEigyoshoCd", "listHakkenEigyoshoCd" + i);
        // 発券営業所
        recMap.put("listHakkenEigyosho", "listHakkenEigyosho" + i);
        // 配布先営業所コード
        recMap.put("listHaifusakiEigyoshoCd", "listHaifusakiEigyoshoCd" + i);
        // 配布先営業所
        recMap.put("listHaifusakiEigyosho", "listHaifusakiEigyosho" + i);
        // 修正区分
        recMap.put("listShuseiKubun", "listShuseiKubun" + i);
        // 使用区分
        recMap.put("listShiyoKubun", "listShiyoKubun" + i);
        // MAWB登録ID
        recMap.put("listMawbTorokuId", "listMawbTorokuId" + i);
        // MAWB配布ID
        recMap.put("listMawbHaifuId", "listMawbHaifuId" + i);
        // 開始MAWB番号
        recMap.put("listKaishiMawbBango", "listKaishiMawbBango" + i);
        // 終了MAWB番号
        recMap.put("listShuryoMawbBango", "listShuryoMawbBango" + i);
        // 開始MAWB配布番号
        recMap.put("listKaishiHaifuMawbBango", "listKaishiHaifuMawbBango" + i);
        // 終了MAWB配布番号
        recMap.put("listShuryoHaifuMawbBango", "listShuryoHaifuMawbBango" + i);
        // 修正日付
        recMap.put("listSaishuOperationKoshinNichiji", "listSaishuOperationKoshinNichiji" + i);
        // MAWBデータバージョン
        recMap.put("listMawbDataVersion", "listMawbDataVersion" + i);
        return recMap;
    }
    
        private Map<String, Object> createRecMapFor_11_1_1(int i) {
        Map recMap = new HashMap();
        // 航空会社コード
        recMap.put("listKokuGaishaCd", "listKokuGaishaCd" + i);
        // 航空会社名
        recMap.put("listKokuGaisha", "listKokuGaisha" + i);
        // MAWB番号	
        recMap.put("listMawbBango", "listMawbBango" + i);
        // 搭載日付
        recMap.put("listTosaiHizuke", Long.valueOf("1546272000000")); 
        // 搭載便名
        recMap.put("listTosaiBinMei", "listTosaiBinMei" + i);
        // 施策適用日付
        recMap.put("listShisakuTekiyoHizuke",Long.valueOf("1546272000000"));
        // 施策適用便名
        recMap.put("listShisakuTekiyoBinMei", "listShisakuTekiyoBinMei" + i);
        // 出発地空港コード
        recMap.put("listShuppatsuchiKukoCd", "listShuppatsuchiKukoCd" + i);
        // 出発地空港
        recMap.put("listShuppatsuchiKukoMei", "listShuppatsuchiKukoMei" + i);
        // 到着地空港コード
        recMap.put("listTochakuchiKukoCd", "listTochakuchiKukoCd" + i);
        // 到着地空港
        recMap.put("listTochakuchiKukoMei", "listTochakuchiKukoMei" + i);
        // 搭載重量(Kg)
        recMap.put("listTosaiJuryo", "listTosaiJuryo" + i);
        // 適用重量(Kg)
        recMap.put("listTekiyoJuryo", "listTekiyoJuryo" + i);
        // 最低搭載重量(Kg)
        recMap.put("listSaiteTosaiJuryo", "listSaiteTosaiJuryo" + i);
        // 一般運賃
        recMap.put("listIppanUnchin", "listIppanUnchin" + i);
        // 適用運賃
        recMap.put("listTekiyoUnchin", "listTekiyoUnchin" + i);
        // 代理店手数料
        recMap.put("listDairitenTesuryo", "listDairitenTesuryo" + i);
        // 支払金額
        recMap.put("listShiharaiKingakuZeikomi", "listShiharaiKingakuZeikomi" + i);
        // 小口送り状No
        recMap.put("listKoguchiOkurijoNo", null);
        // 品目明細コード
        recMap.put("listHimmokuMeisaiCd", "listHimmokuMeisaiCd" + i);
        // 運賃種別
        recMap.put("listUnchinShubetsu", "listUnchinShubetsu" + i);
        // 施策番号
        recMap.put("listShisakuBango", "listShisakuBango" + i);
        // 施策適用基準
        recMap.put("listShisakuTekiyoKijyun", "listShisakuTekiyoKijyun" + i);
        // 施策レート
        recMap.put("listShisakuRate", "listShisakuRate" + i);
        // 発券営業所コード
        recMap.put("listHakkenEigyoshoCd", "listHakkenEigyoshoCd" + i);
        // 発券営業所
        recMap.put("listHakkenEigyosho", "listHakkenEigyosho" + i);
        // 配布先営業所コード
        recMap.put("listHaifusakiEigyoshoCd", "listHaifusakiEigyoshoCd" + i);
        // 配布先営業所
        recMap.put("listHaifusakiEigyosho", "listHaifusakiEigyosho" + i);
        // 修正区分
        recMap.put("listShuseiKubun", "listShuseiKubun" + i);
        // 使用区分
        recMap.put("listShiyoKubun", "listShiyoKubun" + i);
        // MAWB登録ID
        recMap.put("listMawbTorokuId", "listMawbTorokuId" + i);
        // MAWB配布ID
        recMap.put("listMawbHaifuId", "listMawbHaifuId" + i);
        // 開始MAWB番号
        recMap.put("listKaishiMawbBango", "listKaishiMawbBango" + i);
        // 終了MAWB番号
        recMap.put("listShuryoMawbBango", "listShuryoMawbBango" + i);
        // 開始MAWB配布番号
        recMap.put("listKaishiHaifuMawbBango", "listKaishiHaifuMawbBango" + i);
        // 終了MAWB配布番号
        recMap.put("listShuryoHaifuMawbBango", "listShuryoHaifuMawbBango" + i);
        // 修正日付
        recMap.put("listSaishuOperationKoshinNichiji", "listSaishuOperationKoshinNichiji" + i);
        // MAWBデータバージョン
        recMap.put("listMawbDataVersion", "listMawbDataVersion" + i);
        return recMap;
    }
    
        private Map<String, Object> createRecMapFor_11_2(int i) {
        Map recMap = new HashMap();
        recMap.put("listKokuGaishaCd", "listKokuGaishaCd" + i);
        // 航空会社名
        recMap.put("listKokuGaisha", "listKokuGaisha" + i);
        // MAWB番号	
        recMap.put("listMawbBango", "listMawbBango" + i);
        // 搭載日付
        recMap.put("listTosaiHizuke", Long.valueOf("1546272000000")); 
        // 搭載便名
        recMap.put("listTosaiBinMei", "listTosaiBinMei" + i);
        // 施策適用日付
        recMap.put("listShisakuTekiyoHizuke",Long.valueOf("1546272000000"));
        // 施策適用便名
        recMap.put("listShisakuTekiyoBinMei", "listShisakuTekiyoBinMei" + i);
        // 出発地空港コード
        recMap.put("listShuppatsuchiKukoCd", "listShuppatsuchiKukoCd" + i);
        // 出発地空港
        recMap.put("listShuppatsuchiKukoMei", "listShuppatsuchiKukoMei" + i);
        // 到着地空港コード
        recMap.put("listTochakuchiKukoCd", "listTochakuchiKukoCd" + i);
        // 到着地空港
        recMap.put("listTochakuchiKukoMei", "listTochakuchiKukoMei" + i);
        // 搭載重量(Kg)
        recMap.put("listTosaiJuryo", "listTosaiJuryo" + i);
        // 適用重量(Kg)
        recMap.put("listTekiyoJuryo", "listTekiyoJuryo" + i);
        // 最低搭載重量(Kg)
        recMap.put("listSaiteTosaiJuryo", "listSaiteTosaiJuryo" + i);
        // 一般運賃
        recMap.put("listIppanUnchin", "listIppanUnchin" + i);
        // 適用運賃
        recMap.put("listTekiyoUnchin", "listTekiyoUnchin" + i);
        // 代理店手数料
        recMap.put("listDairitenTesuryo", "listDairitenTesuryo" + i);
        // 支払金額
        recMap.put("listShiharaiKingakuZeikomi", "listShiharaiKingakuZeikomi" + i);
        // 小口送り状No
        recMap.put("listKoguchiOkurijoNo", "listKoguchiOkurijoNo" + i);
        // 品目明細コード
        recMap.put("listHimmokuMeisaiCd", "listHimmokuMeisaiCd" + i);
        // 運賃種別
        recMap.put("listUnchinShubetsu", "listUnchinShubetsu" + i);
        // 施策番号
        recMap.put("listShisakuBango", "listShisakuBango" + i);
        // 施策適用基準
        recMap.put("listShisakuTekiyoKijyun", "listShisakuTekiyoKijyun" + i);
        // 施策レート
        recMap.put("listShisakuRate", "listShisakuRate" + i);
        // 発券営業所コード
        recMap.put("listHakkenEigyoshoCd", "listHakkenEigyoshoCd" + i);
        // 発券営業所
        recMap.put("listHakkenEigyosho", "listHakkenEigyosho" + i);
        // 配布先営業所コード
        recMap.put("listHaifusakiEigyoshoCd", "listHaifusakiEigyoshoCd" + i);
        // 配布先営業所
        recMap.put("listHaifusakiEigyosho", "listHaifusakiEigyosho" + i);
        // 修正区分
        recMap.put("listShuseiKubun", "listShuseiKubun" + i);
        // 使用区分
        recMap.put("listShiyoKubun", "listShiyoKubun" + i);
        // MAWB登録ID
        recMap.put("listMawbTorokuId", "listMawbTorokuId" + i);
        // MAWB配布ID
        recMap.put("listMawbHaifuId", "listMawbHaifuId" + i);
        // 開始MAWB番号
        recMap.put("listKaishiMawbBango", "listKaishiMawbBango" + i);
        // 終了MAWB番号
        recMap.put("listShuryoMawbBango", "listShuryoMawbBango" + i);
        // 開始MAWB配布番号
        recMap.put("listKaishiHaifuMawbBango", "listKaishiHaifuMawbBango" + i);
        // 終了MAWB配布番号
        recMap.put("listShuryoHaifuMawbBango", "listShuryoHaifuMawbBango" + i);
        // 修正日付
        recMap.put("listSaishuOperationKoshinNichiji", "listSaishuOperationKoshinNichiji" + i);
        // MAWBデータバージョン
        recMap.put("listMawbDataVersion", "listMawbDataVersion" + i);
        return recMap;
    }
    
    private void assertForRecList_2_1(Mwb041Form form) {
        int i = 0;
        assertEquals(1, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listKokuGaisha" + i, rec.get("listKokuGaisha"));
            assertEquals("listMawbBango" + i, rec.get("listMawbBango"));
            assertEquals("2019/01/01", rec.get("listTosaiHizuke"));
            assertEquals("listTosaiBinMei" + i, rec.get("listTosaiBinMei"));
            assertEquals("2019/01/01", rec.get("listShisakuTekiyoHizuke"));
            assertEquals("listShisakuTekiyoBinMei" + i, rec.get("listShisakuTekiyoBinMei"));
            assertEquals("listShuppatsuchiKukoCd" + i, rec.get("listShuppatsuchiKukoCd"));
            assertEquals("listShuppatsuchiKukoMei" + i, rec.get("listShuppatsuchiKukoMei"));
            assertEquals("listTochakuchiKukoCd" + i, rec.get("listTochakuchiKukoCd"));
            assertEquals("listTochakuchiKukoMei" + i, rec.get("listTochakuchiKukoMei"));
            assertEquals("listTosaiJuryo" + i, rec.get("listTosaiJuryo"));
            assertEquals("listTekiyoJuryo" + i, rec.get("listTekiyoJuryo"));
            assertEquals("listSaiteTosaiJuryo" + i, rec.get("listSaiteTosaiJuryo"));
            assertEquals("listIppanUnchin" + i, rec.get("listIppanUnchin"));
            assertEquals("listTekiyoUnchin" + i, rec.get("listTekiyoUnchin"));
            assertEquals("listDairitenTesuryo" + i, rec.get("listDairitenTesuryo"));
            assertEquals("listShiharaiKingakuZeikomi" + i, rec.get("listShiharaiKingakuZeikomi"));
            assertEquals("listKoguchiOkurijoNo" + i, rec.get("listKoguchiOkurijoNo"));
            assertEquals("listHimmokuMeisaiCd" + i, rec.get("listHimmokuMeisaiCd"));
            assertEquals("listUnchinShubetsu" + i, rec.get("listUnchinShubetsu"));
            assertEquals("listShisakuBango" + i, rec.get("listShisakuBango"));
            assertEquals("listTochakuchiKukoMei" + i, rec.get("listTochakuchiKukoMei"));
            assertEquals("listShisakuTekiyoKijyun" + i, rec.get("listShisakuTekiyoKijyun"));
            assertEquals("listShisakuRate" + i, rec.get("listShisakuRate"));
            assertEquals("listSaiteTosaiJuryo" + i, rec.get("listSaiteTosaiJuryo"));
            assertEquals("listHakkenEigyoshoCd" + i, rec.get("listHakkenEigyoshoCd"));
            assertEquals("listHakkenEigyosho" + i, rec.get("listHakkenEigyosho"));
            assertEquals("listHaifusakiEigyoshoCd" + i, rec.get("listHaifusakiEigyoshoCd"));
            assertEquals("listHaifusakiEigyosho" + i, rec.get("listHaifusakiEigyosho"));
            assertEquals("listShuseiKubun" + i, rec.get("listShuseiKubun"));
            assertEquals("listShiyoKubun" + i, rec.get("listShiyoKubun"));
            assertEquals("listMawbTorokuId" + i, rec.get("listMawbTorokuId"));
            assertEquals("listMawbHaifuId" + i, rec.get("listMawbHaifuId"));
            assertEquals("listKaishiMawbBango" + i, rec.get("listKaishiMawbBango"));
            assertEquals("listShuryoMawbBango" + i, rec.get("listShuryoMawbBango"));
            assertEquals("listKaishiHaifuMawbBango" + i, rec.get("listKaishiHaifuMawbBango"));
            assertEquals("listShuryoHaifuMawbBango" + i, rec.get("listShuryoHaifuMawbBango"));
            // 修正日付
            assertEquals("listSaishuOperationKoshinNichiji" + i, rec.get("listSaishuOperationKoshinNichiji"));
            // MAWBデータバージョン
            assertEquals("listMawbDataVersion" + i, rec.get("listMawbDataVersion"));
            i++;
        }
    }    

    private void assertForRecList_2_2(Mwb041Form form) {
        int i = 0;
        assertEquals(2, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listKokuGaisha" + i, rec.get("listKokuGaisha"));
            assertEquals("listMawbBango" + i, rec.get("listMawbBango"));
            assertEquals("2019/01/01", rec.get("listTosaiHizuke"));
            assertEquals("listTosaiBinMei" + i, rec.get("listTosaiBinMei"));
            assertEquals("2019/01/01", rec.get("listShisakuTekiyoHizuke"));
            assertEquals("listShisakuTekiyoBinMei" + i, rec.get("listShisakuTekiyoBinMei"));
            assertEquals("listShuppatsuchiKukoCd" + i, rec.get("listShuppatsuchiKukoCd"));
            assertEquals("listShuppatsuchiKukoMei" + i, rec.get("listShuppatsuchiKukoMei"));
            assertEquals("listTochakuchiKukoCd" + i, rec.get("listTochakuchiKukoCd"));
            assertEquals("listTochakuchiKukoMei" + i, rec.get("listTochakuchiKukoMei"));
            assertEquals("listTosaiJuryo" + i, rec.get("listTosaiJuryo"));
            assertEquals("listTekiyoJuryo" + i, rec.get("listTekiyoJuryo"));
            assertEquals("listSaiteTosaiJuryo" + i, rec.get("listSaiteTosaiJuryo"));
            assertEquals("listIppanUnchin" + i, rec.get("listIppanUnchin"));
            assertEquals("listTekiyoUnchin" + i, rec.get("listTekiyoUnchin"));
            assertEquals("listDairitenTesuryo" + i, rec.get("listDairitenTesuryo"));
            assertEquals("listShiharaiKingakuZeikomi" + i, rec.get("listShiharaiKingakuZeikomi"));
            assertEquals("listKoguchiOkurijoNo" + i, rec.get("listKoguchiOkurijoNo"));
            assertEquals("listHimmokuMeisaiCd" + i, rec.get("listHimmokuMeisaiCd"));
            assertEquals("listUnchinShubetsu" + i, rec.get("listUnchinShubetsu"));
            assertEquals("listShisakuBango" + i, rec.get("listShisakuBango"));
            assertEquals("listTochakuchiKukoMei" + i, rec.get("listTochakuchiKukoMei"));
            assertEquals("listShisakuTekiyoKijyun" + i, rec.get("listShisakuTekiyoKijyun"));
            assertEquals("listShisakuRate" + i, rec.get("listShisakuRate"));
            assertEquals("listSaiteTosaiJuryo" + i, rec.get("listSaiteTosaiJuryo"));
            assertEquals("listHakkenEigyoshoCd" + i, rec.get("listHakkenEigyoshoCd"));
            assertEquals("listHakkenEigyosho" + i, rec.get("listHakkenEigyosho"));
            assertEquals("listHaifusakiEigyoshoCd" + i, rec.get("listHaifusakiEigyoshoCd"));
            assertEquals("listHaifusakiEigyosho" + i, rec.get("listHaifusakiEigyosho"));
            assertEquals("listShuseiKubun" + i, rec.get("listShuseiKubun"));
            assertEquals("listShiyoKubun" + i, rec.get("listShiyoKubun"));
            assertEquals("listMawbTorokuId" + i, rec.get("listMawbTorokuId"));
            assertEquals("listMawbHaifuId" + i, rec.get("listMawbHaifuId"));
            assertEquals("listKaishiMawbBango" + i, rec.get("listKaishiMawbBango"));
            assertEquals("listShuryoMawbBango" + i, rec.get("listShuryoMawbBango"));
            assertEquals("listKaishiHaifuMawbBango" + i, rec.get("listKaishiHaifuMawbBango"));
            assertEquals("listShuryoHaifuMawbBango" + i, rec.get("listShuryoHaifuMawbBango"));
            assertEquals("listSaishuOperationKoshinNichiji" + i, rec.get("listSaishuOperationKoshinNichiji"));
            assertEquals("listMawbDataVersion" + i, rec.get("listMawbDataVersion"));
            i++;
        }
    }      

    private void assertForRecList_2_3(Mwb041Form form) {
        int i = 0;
        assertEquals(0, form.getSearchResult().size());
        for (Map<String, Object> rec : form.getSearchResult()) {
            assertEquals("listKokuGaisha" + i, rec.get("listKokuGaisha"));
            assertEquals("listMawbBango" + i, rec.get("listMawbBango"));
            assertEquals("2019/01/01", rec.get("listTosaiHizuke"));
            assertEquals("listTosaiBinMei" + i, rec.get("listTosaiBinMei"));
            assertEquals("2019/01/01", rec.get("listShisakuTekiyoHizuke"));
            assertEquals("listShisakuTekiyoBinMei" + i, rec.get("listShisakuTekiyoBinMei"));
            assertEquals("listShuppatsuchiKukoCd" + i, rec.get("listShuppatsuchiKukoCd"));
            assertEquals("listShuppatsuchiKukoMei" + i, rec.get("listShuppatsuchiKukoMei"));
            assertEquals("listTochakuchiKukoCd" + i, rec.get("listTochakuchiKukoCd"));
            assertEquals("listTochakuchiKukoMei" + i, rec.get("listTochakuchiKukoMei"));
            assertEquals("listTosaiJuryo" + i, rec.get("listTosaiJuryo"));
            assertEquals("listTekiyoJuryo" + i, rec.get("listTekiyoJuryo"));
            assertEquals("listSaiteTosaiJuryo" + i, rec.get("listSaiteTosaiJuryo"));
            assertEquals("listIppanUnchin" + i, rec.get("listIppanUnchin"));
            assertEquals("listTekiyoUnchin" + i, rec.get("listTekiyoUnchin"));
            assertEquals("listDairitenTesuryo" + i, rec.get("listDairitenTesuryo"));
            assertEquals("listShiharaiKingakuZeikomi" + i, rec.get("listShiharaiKingakuZeikomi"));
            assertEquals("listKoguchiOkurijoNo" + i, rec.get("listKoguchiOkurijoNo"));
            assertEquals("listHimmokuMeisaiCd" + i, rec.get("listHimmokuMeisaiCd"));
            assertEquals("listUnchinShubetsu" + i, rec.get("listUnchinShubetsu"));
            assertEquals("listShisakuBango" + i, rec.get("listShisakuBango"));
            assertEquals("listTochakuchiKukoMei" + i, rec.get("listTochakuchiKukoMei"));
            assertEquals("listShisakuTekiyoKijyun" + i, rec.get("listShisakuTekiyoKijyun"));
            assertEquals("listShisakuRate" + i, rec.get("listShisakuRate"));
            assertEquals("listSaiteTosaiJuryo" + i, rec.get("listSaiteTosaiJuryo"));
            assertEquals("listHakkenEigyoshoCd" + i, rec.get("listHakkenEigyoshoCd"));
            assertEquals("listHakkenEigyosho" + i, rec.get("listHakkenEigyosho"));
            assertEquals("listHaifusakiEigyoshoCd" + i, rec.get("listHaifusakiEigyoshoCd"));
            assertEquals("listHaifusakiEigyosho" + i, rec.get("listHaifusakiEigyosho"));
            assertEquals("listShuseiKubun" + i, rec.get("listShuseiKubun"));
            assertEquals("listShiyoKubun" + i, rec.get("listShiyoKubun"));
            assertEquals("listMawbTorokuId" + i, rec.get("listMawbTorokuId"));
            assertEquals("listMawbHaifuId" + i, rec.get("listMawbHaifuId"));
            assertEquals("listKaishiMawbBango" + i, rec.get("listKaishiMawbBango"));
            assertEquals("listShuryoMawbBango" + i, rec.get("listShuryoMawbBango"));
            assertEquals("listKaishiHaifuMawbBango" + i, rec.get("listKaishiHaifuMawbBango"));
            assertEquals("listShuryoHaifuMawbBango" + i, rec.get("listShuryoHaifuMawbBango"));
            assertEquals("listSaishuOperationKoshinNichiji" + i, rec.get("listSaishuOperationKoshinNichiji"));
            assertEquals("listMawbDataVersion" + i, rec.get("listMawbDataVersion"));
            i++;
        }
    }
    
}
