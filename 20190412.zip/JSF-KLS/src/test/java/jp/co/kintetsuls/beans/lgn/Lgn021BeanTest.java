/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.lgn;

import java.lang.reflect.InvocationTargetException;
import static org.junit.Assert.assertEquals;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.util.HashMap;
import java.util.Map;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import javax.naming.AuthenticationException;
import javax.naming.NamingException;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.ModificationItem;
import jp.co.kintetsuls.beans.common.DirContextBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.SystemMasterBean;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.forms.lgn.Lgn021Form;
import jp.co.kintetsuls.service.LoginService;
import jp.co.kintetsuls.service.common.AuthorityService;
import jp.co.kintetsuls.service.common.MenuService;
import jp.co.kintetsuls.utils.FlashUtil;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import jp.co.sharedsys.beans.session.MenuBean;
import org.mockito.Mockito;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * パスワード変更画面
 *
 * @author 曾鳳(MBP)
 * @version 2019/4/2 新規作成
 */
public class Lgn021BeanTest {

    // テストTarget
    @InjectMocks
    private Lgn021Bean target;

    // Mockitoオブジェクト
    @Mock
    private MessagePropertyBean messagePropertyBean;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private SystemMasterBean systemMasterBean;
    @Mock
    private BreadCrumbBean breadBean;
    @Mock
    private AuthorityConfBean authConfBean;
    @Mock
    private MenuBean menuBean;
    @Mock
    private DirContextBean dirContextBean;
    @Mock
    LoginService loginService;
    @Mock
    AuthorityService authService;
    @Mock
    MenuService menuService;
    @Mock
    FlashUtil flashUtil;
    @Mock
    MasterInfoBean masterInfo;
    
    public Lgn021BeanTest() {
    }

    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() {
    }

    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // メニューからの遷移の場合
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1() {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String[]> keyCaptor_2 = ArgumentCaptor.forClass(String[].class);
        
        // Mockitoオブジェクトの予想return値設定
        // パスワード変更ォーム
        Lgn021Form lgn021Form = new Lgn021Form();
        // パスワード誤入力最大回数
        String passwordGoNyuryokuSaidaiKaisu = "5";
        // ログイン情報.ユーザーコード
        String userCd = "test001";
        when(authConfBean.getUserCd()).thenReturn(userCd);
        
        // パスワード誤入力最大回数取得
        when(systemMasterBean.getSysValByCdAndKanriGroup(keyCaptor_1.capture(), keyCaptor_2.capture()
                )).thenReturn(passwordGoNyuryokuSaidaiKaisu);
        
        //テスト実行
        target.setLgn021Form(lgn021Form);
        // メニューからの遷移
        target.init("menuIdLgn021", "", false);
        
        // 実行時に渡すパラメータの検証
        assertEquals("password_error_max_kaisu", keyCaptor_1.getValue());
        assertEquals("lgn021", keyCaptor_2.getAllValues().get(0));
        assertEquals("system", keyCaptor_2.getAllValues().get(1));
        
        // 実行結果の検証
        // ユーザーコード
        assertEquals("test001", lgn021Form.getHyoDtlUserCd());
        // 現在のパスワードを表示する
        assertEquals(true, lgn021Form.getHyoDtlGenzaiPasswordVisabled());
        // 現在のパスワード = 空白
        assertEquals(null, lgn021Form.getHyoDtlGenzaiPassword());
        // 新しいパスワード = 空白
        assertEquals(null, lgn021Form.getHyoDtlNewPassword());
            // 新しいパスワード(確認) = 空白
        assertEquals(null, lgn021Form.getHyoDtlNewPasswordKakunin());
    }
    
    // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // TOP画面からの遷移の場合
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2() {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String[]> keyCaptor_2 = ArgumentCaptor.forClass(String[].class);
        
        // Mockitoオブジェクトの予想return値設定
        // パスワード変更ォーム
        Lgn021Form lgn021Form = new Lgn021Form();
        // パスワード誤入力最大回数
        String passwordGoNyuryokuSaidaiKaisu = "5";
        // ログイン情報.ユーザーコード
        String userCd = "test001";
        when(authConfBean.getUserCd()).thenReturn(userCd);
        
        // パスワード誤入力最大回数取得
        when(systemMasterBean.getSysValByCdAndKanriGroup(keyCaptor_1.capture(), keyCaptor_2.capture()
                )).thenReturn(passwordGoNyuryokuSaidaiKaisu);
        
        //テスト実行
        target.setLgn021Form(lgn021Form);
        // TOP画面からの遷移
        target.init("", "TOP011_SCREEN", false);
        
        // 実行時に渡すパラメータの検証
        assertEquals("password_error_max_kaisu", keyCaptor_1.getValue());
        assertEquals("lgn021", keyCaptor_2.getAllValues().get(0));
        assertEquals("system", keyCaptor_2.getAllValues().get(1));
        
        // 実行結果の検証
        // ユーザーコード
        assertEquals("test001", lgn021Form.getHyoDtlUserCd());
        // 現在のパスワードを表示する
        assertEquals(true, lgn021Form.getHyoDtlGenzaiPasswordVisabled());
        // 現在のパスワード = 空白
        assertEquals(null, lgn021Form.getHyoDtlGenzaiPassword());
        // 新しいパスワード = 空白
        assertEquals(null, lgn021Form.getHyoDtlNewPassword());
            // 新しいパスワード(確認) = 空白
        assertEquals(null, lgn021Form.getHyoDtlNewPasswordKakunin());
    }
    
    // init_正常_初期処理_1-3
    //
    // -------------------テスト条件--------------------------
    // ログイン画面からの遷移の場合、ワンタイムパスワード未使用時の場合
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_3() {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String[]> keyCaptor_2 = ArgumentCaptor.forClass(String[].class);
        
        // Mockitoオブジェクトの予想return値設定
        // パスワード変更ォーム
        Lgn021Form lgn021Form = new Lgn021Form();
        // パスワード誤入力最大回数
        String passwordGoNyuryokuSaidaiKaisu = "5";
        // ログイン情報.ユーザーコード
        String userCd = "test001";
        when(authConfBean.getUserCd()).thenReturn(userCd);
        
        // パスワード誤入力最大回数取得
        when(systemMasterBean.getSysValByCdAndKanriGroup(keyCaptor_1.capture(), keyCaptor_2.capture()
                )).thenReturn(passwordGoNyuryokuSaidaiKaisu);
        
        // flash
        Flash flash =  new FlashKls();
        // ワンタイムパスワード未使用時の場合
        flash.put("onetimePassLogin", "0");
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        
        //テスト実行
        target.setLgn021Form(lgn021Form);
        // ログイン画面からの遷移
        target.init("", "LGN011_SCREEN", false);
        
        // 実行時に渡すパラメータの検証
        assertEquals("password_error_max_kaisu", keyCaptor_1.getValue());
        assertEquals("lgn021", keyCaptor_2.getAllValues().get(0));
        assertEquals("system", keyCaptor_2.getAllValues().get(1));
        
        // 実行結果の検証
        // ユーザーコード
        assertEquals("test001", lgn021Form.getHyoDtlUserCd());
        // 現在のパスワードを表示する
        assertEquals(true, lgn021Form.getHyoDtlGenzaiPasswordVisabled());
        // 現在のパスワード = 空白
        assertEquals(null, lgn021Form.getHyoDtlGenzaiPassword());
        // 新しいパスワード = 空白
        assertEquals(null, lgn021Form.getHyoDtlNewPassword());
            // 新しいパスワード(確認) = 空白
        assertEquals(null, lgn021Form.getHyoDtlNewPasswordKakunin());
    }
    
    // init_正常_初期処理_1-4
    //
    // -------------------テスト条件--------------------------
    // ログイン画面からの遷移の場合、ワンタイムパスワード使用時の場合
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_4() {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String[]> keyCaptor_2 = ArgumentCaptor.forClass(String[].class);
        
        // Mockitoオブジェクトの予想return値設定
        // パスワード変更ォーム
        Lgn021Form lgn021Form = new Lgn021Form();
        // パスワード誤入力最大回数
        String passwordGoNyuryokuSaidaiKaisu = "5";
        // ログイン情報.ユーザーコード
        String userCd = "test001";
        when(authConfBean.getUserCd()).thenReturn(userCd);
        
        // パスワード誤入力最大回数取得
        when(systemMasterBean.getSysValByCdAndKanriGroup(keyCaptor_1.capture(), keyCaptor_2.capture()
                )).thenReturn(passwordGoNyuryokuSaidaiKaisu);
        
        // flash
        Flash flash =  new FlashKls();
        // ワンタイムパスワード使用時の場合
        flash.put("onetimePassLogin", "1");
        when(pageCommonBean.getPageParam()).thenReturn(flash);
        
        //テスト実行
        target.setLgn021Form(lgn021Form);
        // ログイン画面からの遷移
        target.init("", "LGN011_SCREEN", false);
        
        // 実行時に渡すパラメータの検証
        assertEquals("password_error_max_kaisu", keyCaptor_1.getValue());
        assertEquals("lgn021", keyCaptor_2.getAllValues().get(0));
        assertEquals("system", keyCaptor_2.getAllValues().get(1));
        
        // 実行結果の検証
        // ユーザーコード
        assertEquals("test001", lgn021Form.getHyoDtlUserCd());
        // 現在のパスワードを表示しない
        assertEquals(false, lgn021Form.getHyoDtlGenzaiPasswordVisabled());
        // 現在のパスワード = 空白
        assertEquals(null, lgn021Form.getHyoDtlGenzaiPassword());
        // 新しいパスワード = 空白
        assertEquals(null, lgn021Form.getHyoDtlNewPassword());
            // 新しいパスワード(確認) = 空白
        assertEquals(null, lgn021Form.getHyoDtlNewPasswordKakunin());
    }
    
    // init_異常_初期処理_1-5
    //
    // -------------------テスト条件--------------------------
    // パンくず追加時異常が発生しました
    // -----------------------------------------------------
    @Test
    public void init_異常_初期処理_1_5() throws IllegalAccessException, InvocationTargetException {

        // パンくず追加時異常が発生しました
        doThrow(IllegalAccessException.class).when(breadBean)
                .push("パスワード変更", Cnst.SCREEN.LGN021_SCREEN.name(), target);
        
        //テスト実行
        target.init("", "LGN011_SCREEN", false);
    }
    
    // update_異常_変更処理_2-1
    //
    // -------------------テスト条件--------------------------
    // モード = 1(変更モード)の場合、現在のパスワード未入力の場合、
    // -----------------------------------------------------
    @Test
    public void update_異常_変更処理_2_1() {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> compCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Object[]> argsCaptor_4 = ArgumentCaptor.forClass(Object[].class);
        
        // Mockitoオブジェクトの予想return値設定
        // パスワード変更ォーム
        Lgn021Form lgn021Form = new Lgn021Form();
        // 変更モード
        lgn021Form.setMode("1");
        // 現在のパスワード:未入力
        lgn021Form.setHyoDtlGenzaiPassword("");
        // 新しいパスワード
        lgn021Form.setHyoDtlNewPassword("1");
        // 新しいパスワード(確認)
        lgn021Form.setHyoDtlNewPasswordKakunin("1");
        
        doNothing().when(messagePropertyBean).messageToArea(levelCaptor_1.capture(),summaryCaptor_2.capture(),
                compCaptor_3.capture(), argsCaptor_4.capture());
        
        //テスト実行
        target.setLgn021Form(lgn021Form);
        target.update();
        
        // 実行結果の検証
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0003",summaryCaptor_2.getValue());
        assertEquals("lgn021Form:genzaiPassw:hyoDtlGenzaiPassword",compCaptor_3.getValue());
        assertEquals("現在のパスワード",argsCaptor_4.getAllValues().get(0));
        assertEquals(null,target.getUrl());
    }
    
    // update_異常_変更処理_2-2
    //
    // -------------------テスト条件--------------------------
    // モード = 1(変更モード)の場合、新しいパスワード未入力の場合、
    // -----------------------------------------------------
    @Test
    public void update_異常_変更処理_2_2() {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> compCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Object[]> argsCaptor_4 = ArgumentCaptor.forClass(Object[].class);
        
        // Mockitoオブジェクトの予想return値設定
        // パスワード変更ォーム
        Lgn021Form lgn021Form = new Lgn021Form();
        // 変更モード
        lgn021Form.setMode("1");
        // 現在のパスワード
        lgn021Form.setHyoDtlGenzaiPassword("a");
        // 新しいパスワード:未入力
        lgn021Form.setHyoDtlNewPassword("");
        // 新しいパスワード(確認)
        lgn021Form.setHyoDtlNewPasswordKakunin("1");
        
        doNothing().when(messagePropertyBean).messageToArea(levelCaptor_1.capture(),summaryCaptor_2.capture(),
                compCaptor_3.capture(), argsCaptor_4.capture());
        
        //テスト実行
        target.setLgn021Form(lgn021Form);
        target.update();
        
        // 実行結果の検証
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0003",summaryCaptor_2.getValue());
        assertEquals("lgn021Form:newPassw:hyoDtlNewPassword",compCaptor_3.getValue());
        assertEquals("新しいパスワード",argsCaptor_4.getAllValues().get(0));
        assertEquals(null,target.getUrl());
    }
    
    // update_異常_変更処理_2-3
    //
    // -------------------テスト条件--------------------------
    // モード = 1(変更モード)の場合、新しいパスワード(確認)未入力の場合、
    // -----------------------------------------------------
    @Test
    public void update_異常_変更処理_2_3() {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> compCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Object[]> argsCaptor_4 = ArgumentCaptor.forClass(Object[].class);
        
        // Mockitoオブジェクトの予想return値設定
        // パスワード変更ォーム
        Lgn021Form lgn021Form = new Lgn021Form();
        // 変更モード
        lgn021Form.setMode("1");
        // 現在のパスワード
        lgn021Form.setHyoDtlGenzaiPassword("a");
        // 新しいパスワード
        lgn021Form.setHyoDtlNewPassword("1");
        // 新しいパスワード(確認):未入力
        lgn021Form.setHyoDtlNewPasswordKakunin("");
        
        doNothing().when(messagePropertyBean).messageToArea(levelCaptor_1.capture(),summaryCaptor_2.capture(),
                compCaptor_3.capture(), argsCaptor_4.capture());
        
        //テスト実行
        target.setLgn021Form(lgn021Form);
        target.update();
        
        // 実行結果の検証
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0003",summaryCaptor_2.getValue());
        assertEquals("lgn021Form:newPasswKakunin:hyoDtlNewPasswordKakunin",compCaptor_3.getValue());
        assertEquals("新しいパスワード(確認)",argsCaptor_4.getAllValues().get(0));
        assertEquals(null,target.getUrl());
    }
    
    // update_異常_変更処理_2-4
    //
    // -------------------テスト条件--------------------------
    // モード = 1(変更モード)の場合、新しいパスワード≠新しいパスワード(確認)の場合、
    // -----------------------------------------------------
    @Test
    public void update_異常_変更処理_2_4() {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> compCaptor_3 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        // パスワード変更ォーム
        Lgn021Form lgn021Form = new Lgn021Form();
        // 変更モード
        lgn021Form.setMode("1");
        // 現在のパスワード
        lgn021Form.setHyoDtlGenzaiPassword("a");
        // 新しいパスワード
        lgn021Form.setHyoDtlNewPassword("1");
        // 新しいパスワード(確認):未入力
        lgn021Form.setHyoDtlNewPasswordKakunin("2");
        
        doNothing().when(messagePropertyBean).messageToArea(levelCaptor_1.capture(),summaryCaptor_2.capture(),
                compCaptor_3.capture());
        
        //テスト実行
        target.setLgn021Form(lgn021Form);
        target.update();
        
        // 実行結果の検証
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("LGNE0001",summaryCaptor_2.getValue());
        assertEquals("lgn021Form:newPasswKakunin:hyoDtlNewPasswordKakunin",compCaptor_3.getValue());
        assertEquals(null,target.getUrl());
    }
    
    // update_異常_変更処理_2-5
    //
    // -------------------テスト条件--------------------------
    // モード = 1(変更モード)の場合、ADサーバ接続に失敗した場合(AuthenticationException発生時)、
    // 取得結果.件数 + 1 < ワーク.パスワード誤入力最大回数 の場合
    // -----------------------------------------------------
    @Test
    public void update_異常_変更処理_2_5() throws NamingException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> compCaptor_3 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        // パスワード変更ォーム
        Lgn021Form lgn021Form = new Lgn021Form();
        // パスワード誤入力最大回数 = 5
        lgn021Form.setPassErrorMaxKaisu(5);
        // 変更モード
        lgn021Form.setMode("1");
        // ユーザコード
        lgn021Form.setHyoDtlUserCd("test001");
        // 現在のパスワード
        lgn021Form.setHyoDtlGenzaiPassword("a");
        // 新しいパスワード
        lgn021Form.setHyoDtlNewPassword("1");
        // 新しいパスワード(確認):未入力
        lgn021Form.setHyoDtlNewPasswordKakunin("1");
        
        // ADサーバログイン処理
        doThrow(AuthenticationException.class).when(dirContextBean)
                .initialDirContext(lgn021Form.getHyoDtlUserCd(), lgn021Form.getHyoDtlGenzaiPassword());
        
        // パスワード誤入力回数 = 1
        ServiceInterfaceBean errServiceInterfaceBean = new ServiceInterfaceBean();
        int errorKaisu = 1;
        errServiceInterfaceBean.setJson(JSONUtil.makeJSONString(errorKaisu));
        
        // パスワード誤入力回数を更新する
        Map<String, Object> params = new HashMap<>();
        params.put("userCd", lgn021Form.getHyoDtlUserCd());
        params.put("mode", "1");
        when(pageCommonBean.getDBInfo(params, "lgn021-update")).thenReturn(errServiceInterfaceBean);
        
        doNothing().when(messagePropertyBean).messageToArea(levelCaptor_1.capture(),summaryCaptor_2.capture(),
                compCaptor_3.capture());
        
        //テスト実行
        target.setLgn021Form(lgn021Form);
        target.update();
        
        // 実行結果の検証
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("LGNE0002",summaryCaptor_2.getValue());
        assertEquals("lgn021Form:hyoDtlErrorMessage",compCaptor_3.getValue());
        assertEquals(null,target.getUrl());
    }
    
    // update_異常_変更処理_2-6
    //
    // -------------------テスト条件--------------------------
    // モード = 1(変更モード)の場合、ADサーバ接続に失敗した場合(AuthenticationException発生時)、
    // 取得結果.件数 + 1 = ワーク.パスワード誤入力最大回数 の場合
    // -----------------------------------------------------
    @Test
    public void update_異常_変更処理_2_6() throws NamingException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> compCaptor_3 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        // パスワード変更ォーム
        Lgn021Form lgn021Form = new Lgn021Form();
        // パスワード誤入力最大回数 = 5
        lgn021Form.setPassErrorMaxKaisu(5);
        // 変更モード
        lgn021Form.setMode("1");
        // ユーザコード
        lgn021Form.setHyoDtlUserCd("test001");
        // 現在のパスワード
        lgn021Form.setHyoDtlGenzaiPassword("a");
        // 新しいパスワード
        lgn021Form.setHyoDtlNewPassword("1");
        // 新しいパスワード(確認):未入力
        lgn021Form.setHyoDtlNewPasswordKakunin("1");
        
        // ADサーバログイン処理
        doThrow(AuthenticationException.class).when(dirContextBean)
                .initialDirContext(lgn021Form.getHyoDtlUserCd(), lgn021Form.getHyoDtlGenzaiPassword());
        
        // パスワード誤入力回数 = 4
        ServiceInterfaceBean errServiceInterfaceBean = new ServiceInterfaceBean();
        int errorKaisu = 4;
        errServiceInterfaceBean.setJson(JSONUtil.makeJSONString(errorKaisu));
        
        // パスワード誤入力回数を更新する
        Map<String, Object> params = new HashMap<>();
        params.put("userCd", lgn021Form.getHyoDtlUserCd());
        params.put("mode", "1");
        when(pageCommonBean.getDBInfo(params, "lgn021-update")).thenReturn(errServiceInterfaceBean);
        
        doNothing().when(messagePropertyBean).messageToArea(levelCaptor_1.capture(),summaryCaptor_2.capture(),
                compCaptor_3.capture());
        
        //テスト実行
        target.setLgn021Form(lgn021Form);
        target.update();
        
        // 実行結果の検証
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("LGNE0002",summaryCaptor_2.getValue());
        assertEquals("lgn021Form:hyoDtlErrorMessage",compCaptor_3.getValue());
        assertEquals(null,target.getUrl());
    }
    
    // update_異常_変更処理_2-7
    //
    // -------------------テスト条件--------------------------
    // モード = 1(変更モード)の場合、ADサーバ接続に失敗した場合(AuthenticationException発生時)、
    // 取得結果.件数 + 1 > ワーク.パスワード誤入力最大回数 の場合
    // -----------------------------------------------------
    @Test
    public void update_異常_変更処理_2_7() throws NamingException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> compCaptor_3 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        // パスワード変更ォーム
        Lgn021Form lgn021Form = new Lgn021Form();
        // パスワード誤入力最大回数 = 5
        lgn021Form.setPassErrorMaxKaisu(5);
        // 変更モード
        lgn021Form.setMode("1");
        // ユーザコード
        lgn021Form.setHyoDtlUserCd("test001");
        // 現在のパスワード
        lgn021Form.setHyoDtlGenzaiPassword("a");
        // 新しいパスワード
        lgn021Form.setHyoDtlNewPassword("1");
        // 新しいパスワード(確認):未入力
        lgn021Form.setHyoDtlNewPasswordKakunin("1");
        
        // ADサーバログイン処理
        doThrow(AuthenticationException.class).when(dirContextBean)
                .initialDirContext(lgn021Form.getHyoDtlUserCd(), lgn021Form.getHyoDtlGenzaiPassword());
        
        // パスワード誤入力回数 = 5
        ServiceInterfaceBean errServiceInterfaceBean = new ServiceInterfaceBean();
        int errorKaisu = 5;
        errServiceInterfaceBean.setJson(JSONUtil.makeJSONString(errorKaisu));
        
        // パスワード誤入力回数を更新する
        Map<String, Object> params = new HashMap<>();
        params.put("userCd", lgn021Form.getHyoDtlUserCd());
        params.put("mode", "1");
        when(pageCommonBean.getDBInfo(params, "lgn021-update")).thenReturn(errServiceInterfaceBean);
        
        doNothing().when(messagePropertyBean).messageToArea(levelCaptor_1.capture(),summaryCaptor_2.capture(),
                compCaptor_3.capture());
        
        doNothing().when(pageCommonBean).executeScript("km.showConfirmDialog('lgne0003Dialog')");
        
        //テスト実行
        target.setLgn021Form(lgn021Form);
        target.update();
        
        // 実行結果の検証
        assertEquals(null,target.getUrl());
    }
    
    // update_異常_変更処理_2-8
    //
    // -------------------テスト条件--------------------------
    // モード = 1(変更モード)の場合、システムエラーが発生した場合(AuthenticationException以外のException発生時)
    // -----------------------------------------------------
    @Test
    public void update_異常_変更処理_2_8() throws NamingException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> compCaptor_3 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        // パスワード変更ォーム
        Lgn021Form lgn021Form = new Lgn021Form();
        // パスワード誤入力最大回数 = 5
        lgn021Form.setPassErrorMaxKaisu(5);
        // 変更モード
        lgn021Form.setMode("1");
        // ユーザコード
        lgn021Form.setHyoDtlUserCd("test001");
        // 現在のパスワード
        lgn021Form.setHyoDtlGenzaiPassword("a");
        // 新しいパスワード
        lgn021Form.setHyoDtlNewPassword("1");
        // 新しいパスワード(確認):未入力
        lgn021Form.setHyoDtlNewPasswordKakunin("1");
        
        // ADサーバログイン処理
        doThrow(NamingException.class).when(dirContextBean)
                .initialDirContext(lgn021Form.getHyoDtlUserCd(), lgn021Form.getHyoDtlGenzaiPassword());
        
        doNothing().when(messagePropertyBean).messageToArea(levelCaptor_1.capture(),summaryCaptor_2.capture(),
                compCaptor_3.capture());
        
        //テスト実行
        target.setLgn021Form(lgn021Form);
        target.update();
        
        // 実行結果の検証
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COMF0002",summaryCaptor_2.getValue());
        assertEquals("lgn021Form:hyoDtlErrorMessage",compCaptor_3.getValue());
        assertEquals(null,target.getUrl());
    }
    
    // update_異常_変更処理_2-9
    //
    // -------------------テスト条件--------------------------
    // モード = 2(初期化モード)の場合、新しいパスワード未入力の場合、
    // -----------------------------------------------------
    @Test
    public void update_異常_変更処理_2_9() {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> compCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Object[]> argsCaptor_4 = ArgumentCaptor.forClass(Object[].class);
        
        // Mockitoオブジェクトの予想return値設定
        // パスワード変更ォーム
        Lgn021Form lgn021Form = new Lgn021Form();
        // 初期化モード
        lgn021Form.setMode("2");
        // ユーザコード
        lgn021Form.setHyoDtlUserCd("test001");
        // 新しいパスワード:未入力
        lgn021Form.setHyoDtlNewPassword("");
        // 新しいパスワード(確認)
        lgn021Form.setHyoDtlNewPasswordKakunin("1");
        
        doNothing().when(messagePropertyBean).messageToArea(levelCaptor_1.capture(),summaryCaptor_2.capture(),
                compCaptor_3.capture(), argsCaptor_4.capture());
        
        //テスト実行
        target.setLgn021Form(lgn021Form);
        target.update();
        
        // 実行結果の検証
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0003",summaryCaptor_2.getValue());
        assertEquals("lgn021Form:newPassw:hyoDtlNewPassword",compCaptor_3.getValue());
        assertEquals("新しいパスワード",argsCaptor_4.getAllValues().get(0));
        assertEquals(null,target.getUrl());
    }
    
    // update_異常_変更処理_2-10
    //
    // -------------------テスト条件--------------------------
    // モード = 2(初期化モード)の場合、新しいパスワード(確認)未入力の場合、
    // -----------------------------------------------------
    @Test
    public void update_異常_変更処理_2_10() {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> compCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Object[]> argsCaptor_4 = ArgumentCaptor.forClass(Object[].class);
        
        // Mockitoオブジェクトの予想return値設定
        // パスワード変更ォーム
        Lgn021Form lgn021Form = new Lgn021Form();
        // 初期化モード
        lgn021Form.setMode("2");
        // ユーザコード
        lgn021Form.setHyoDtlUserCd("test001");
        // 新しいパスワード
        lgn021Form.setHyoDtlNewPassword("1");
        // 新しいパスワード(確認):未入力
        lgn021Form.setHyoDtlNewPasswordKakunin("");
        
        doNothing().when(messagePropertyBean).messageToArea(levelCaptor_1.capture(),summaryCaptor_2.capture(),
                compCaptor_3.capture(), argsCaptor_4.capture());
        
        //テスト実行
        target.setLgn021Form(lgn021Form);
        target.update();
        
        // 実行結果の検証
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("COME0003",summaryCaptor_2.getValue());
        assertEquals("lgn021Form:newPasswKakunin:hyoDtlNewPasswordKakunin",compCaptor_3.getValue());
        assertEquals("新しいパスワード(確認)",argsCaptor_4.getAllValues().get(0));
        assertEquals(null,target.getUrl());
    }
    
    // update_異常_変更処理_2-11
    //
    // -------------------テスト条件--------------------------
    // モード = 2(初期化モード)の場合、新しいパスワード≠新しいパスワード(確認)の場合、
    // -----------------------------------------------------
    @Test
    public void update_異常_変更処理_2_11() {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> compCaptor_3 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        // パスワード変更ォーム
        Lgn021Form lgn021Form = new Lgn021Form();
        // 初期化モード
        lgn021Form.setMode("2");
        // ユーザコード
        lgn021Form.setHyoDtlUserCd("test001");
        // 新しいパスワード
        lgn021Form.setHyoDtlNewPassword("1");
        // 新しいパスワード(確認):未入力
        lgn021Form.setHyoDtlNewPasswordKakunin("2");
        
        doNothing().when(messagePropertyBean).messageToArea(levelCaptor_1.capture(),summaryCaptor_2.capture(),
                compCaptor_3.capture());
        
        //テスト実行
        target.setLgn021Form(lgn021Form);
        target.update();
        
        // 実行結果の検証
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("LGNE0001",summaryCaptor_2.getValue());
        assertEquals("lgn021Form:newPasswKakunin:hyoDtlNewPasswordKakunin",compCaptor_3.getValue());
        assertEquals(null,target.getUrl());
    }
    
    // update_正常_変更処理_2-12
    //
    // -------------------テスト条件--------------------------
    // モード = 1(変更モード)の場合
    // -----------------------------------------------------
    @Test
    public void update_正常_変更処理_2_12() throws NamingException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> targetCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<ModificationItem[]> modCaptor_1 = ArgumentCaptor.forClass(ModificationItem[].class);
        
        // Mockitoオブジェクトの予想return値設定
        // パスワード変更ォーム
        Lgn021Form lgn021Form = new Lgn021Form();
        // 変更モード
        lgn021Form.setMode("1");
        // ユーザコード
        lgn021Form.setHyoDtlUserCd("test001");
        // 現在のパスワード
        lgn021Form.setHyoDtlGenzaiPassword("a");
        // 新しいパスワード
        lgn021Form.setHyoDtlNewPassword("1");
        // 新しいパスワード(確認):未入力
        lgn021Form.setHyoDtlNewPasswordKakunin("1");

        // バインドユーザ
        String bindUser = "bindUser";
        // バインドユーザのパスワード
        String bindUserPassword = "bindUserPassword";
        // ユーザーコード に対応したdn
        String dn = "dn";
        when(messagePropertyBean.getProperties(keyCaptor_1.capture())).thenReturn(bindUser, bindUserPassword, dn);
        
        // ADサーバログイン処理
        InitialDirContext ctx = Mockito.mock(InitialDirContext.class);
        when(dirContextBean.initialDirContext(lgn021Form.getHyoDtlUserCd(),
                lgn021Form.getHyoDtlGenzaiPassword())).thenReturn(ctx);
        // ADサーバのパスワード更新処理
        when(dirContextBean.initialDirContext(bindUser, bindUserPassword)).thenReturn(ctx);
        doNothing().when(ctx).modifyAttributes(targetCaptor_1.capture(), modCaptor_1.capture());
        
        // flash
        Flash flash =  new FlashKls();
        when(flashUtil.getPageParam()).thenReturn(flash);
        
        //テスト実行
        target.setLgn021Form(lgn021Form);
        target.update();
        
        // 実行結果の検証
        assertEquals("/contents/top/top011.xhtml?faces-redirect=true", target.getUrl());
    }
    
    // update_正常_変更処理_2-13
    //
    // -------------------テスト条件--------------------------
    // モード = 2(初期化モード)の場合
    // -----------------------------------------------------
    @Test
    public void update_正常_変更処理_2_13() throws NamingException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> targetCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<ModificationItem[]> modCaptor_1 = ArgumentCaptor.forClass(ModificationItem[].class);
        
        // Mockitoオブジェクトの予想return値設定
        // パスワード変更ォーム
        Lgn021Form lgn021Form = new Lgn021Form();
        // 初期化モード
        lgn021Form.setMode("2");
        // ユーザコード
        lgn021Form.setHyoDtlUserCd("test001");
        // 新しいパスワード
        lgn021Form.setHyoDtlNewPassword("1");
        // 新しいパスワード(確認):未入力
        lgn021Form.setHyoDtlNewPasswordKakunin("1");

        // バインドユーザ
        String bindUser = "bindUser";
        // バインドユーザのパスワード
        String bindUserPassword = "bindUserPassword";
        // ユーザーコード に対応したdn
        String dn = "dn";
        when(messagePropertyBean.getProperties(keyCaptor_1.capture())).thenReturn(bindUser, bindUserPassword, dn);
        
        // ADサーバログイン処理
        InitialDirContext ctx = Mockito.mock(InitialDirContext.class);
        when(dirContextBean.initialDirContext(lgn021Form.getHyoDtlUserCd(),
                lgn021Form.getHyoDtlGenzaiPassword())).thenReturn(ctx);
        // ADサーバのパスワード更新処理
        when(dirContextBean.initialDirContext(bindUser, bindUserPassword)).thenReturn(ctx);
        doNothing().when(ctx).modifyAttributes(targetCaptor_1.capture(), modCaptor_1.capture());
        
        // flash
        Flash flash =  new FlashKls();
        when(flashUtil.getPageParam()).thenReturn(flash);
        
        //テスト実行
        target.setLgn021Form(lgn021Form);
        target.update();
    }
    
    // update_異常_変更処理_2-14
    //
    // -------------------テスト条件--------------------------
    // LDAPパスワード更新異常
    // -----------------------------------------------------
    @Test
    public void update_異常_変更処理_2_14() throws NamingException {

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> compCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> targetCaptor_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<ModificationItem[]> modCaptor_1 = ArgumentCaptor.forClass(ModificationItem[].class);
        
        // Mockitoオブジェクトの予想return値設定
        // パスワード変更ォーム
        Lgn021Form lgn021Form = new Lgn021Form();
        // 初期化モード
        lgn021Form.setMode("2");
        // ユーザコード
        lgn021Form.setHyoDtlUserCd("test001");
        // 現在のパスワード
        lgn021Form.setHyoDtlGenzaiPassword("a");
        // 新しいパスワード
        lgn021Form.setHyoDtlNewPassword("1");
        // 新しいパスワード(確認):未入力
        lgn021Form.setHyoDtlNewPasswordKakunin("1");

        // バインドユーザ
        String bindUser = "bindUser";
        // バインドユーザのパスワード
        String bindUserPassword = "bindUserPassword";
        // ユーザーコード に対応したdn
        String dn = "dn";
        when(messagePropertyBean.getProperties(keyCaptor_1.capture())).thenReturn(bindUser, bindUserPassword, dn);
        
        // ADサーバログイン処理
        InitialDirContext ctx = Mockito.mock(InitialDirContext.class);
        when(dirContextBean.initialDirContext(lgn021Form.getHyoDtlUserCd(),
                lgn021Form.getHyoDtlGenzaiPassword())).thenReturn(ctx);
        // ADサーバのパスワード更新処理
        when(dirContextBean.initialDirContext(bindUser, bindUserPassword)).thenReturn(ctx);
        doThrow(NamingException.class).when(ctx).modifyAttributes(targetCaptor_1.capture(), modCaptor_1.capture());
        
        doNothing().when(messagePropertyBean).messageToArea(levelCaptor_1.capture(),summaryCaptor_2.capture(),
                compCaptor_3.capture());
        
        //テスト実行
        target.setLgn021Form(lgn021Form);
        target.update();
        
        // 実行結果の検証
        assertEquals("ERROR",levelCaptor_1.getValue());
        assertEquals("LGNE0004",summaryCaptor_2.getValue());
        assertEquals("lgn021Form:hyoDtlErrorMessage",compCaptor_3.getValue());
        assertEquals(null,target.getUrl());
    }
    
    // gotoLgn011_正常_ログイン(Lgn011)への遷移処理_3-1
    @Test
    public void gotoLgn011_正常_ログインへの遷移処理_3_1() {
        
        Flash flash =  new FlashKls();
        when(flashUtil.getPageParam()).thenReturn(flash);
        
        //テスト実行
        target.gotoLgn011();
        
        // 実行結果の検証
        assertEquals("/contents/lgn/lgn011.xhtml?faces-redirect=true", target.getUrl());
    }
    
    // menuClick_正常_メニュークリック処理_4-1
    @Test
    public void menuClick_正常_メニュークリック処理_4_1() {
        
        Flash flash =  new FlashKls();
        when(flashUtil.getPageParam()).thenReturn(flash);
        
        //テスト実行
        target.menuClick("", "TOP011_SCREEN");
        
        // 実行結果の検証
        assertEquals("/contents/top/top011.xhtml?faces-redirect=true", target.getUrl());
    }

    // menuClick_異常_メニュークリック処理_4-2
    @Test
    public void menuClick_異常_メニュークリック処理_4_2() throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(1);

        //テスト実行
        target.menuClick("", "");
        
        // 実行結果の検証
        assertEquals("", target.getUrl());
    }    
    
    // breadClumClick_正常_パンくずクリック処理_5-1
    @Test
    public void breadClumClick_正常_パンくずクリック処理_5_1() {
        
        Flash flash =  new FlashKls();
        when(flashUtil.getPageParam()).thenReturn(flash);
        
        //テスト実行
        target.breadClumClick("TOP011_SCREEN", 0);
        
        // 実行結果の検証
        assertEquals("/contents/top/top011.xhtml?faces-redirect=true", target.getUrl());
    }

    // breadClumClick_異常_パンくずクリック処理_5-2
    @Test
    public void breadClumClick_異常_パンくずクリック処理_5_2()
            throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(1);

        //テスト実行
        target.breadClumClick("", 1);
        
        // 実行結果の検証
        assertEquals("", target.getUrl());
    }    
    
    // logoutClick_正常_ログアウトクリック_6-1
    @Test
    public void logoutClick_正常_ログアウトクリック_6_1() {
        
        //テスト実行
        target.logoutClick();
    }

}
