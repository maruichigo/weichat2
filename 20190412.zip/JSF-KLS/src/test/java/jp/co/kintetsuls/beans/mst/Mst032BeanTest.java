package jp.co.kintetsuls.beans.mst;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.doThrow;
import org.mockito.MockitoAnnotations;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import javax.faces.context.FlashKls;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.forms.mst.Mst032Form;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.mockito.Mockito;
import static org.mockito.Mockito.spy;
import org.primefaces.PrimeFaces;

/**
 * 住所マスタ詳細画面
 *
 * @author 張誠 (MBP)
 * @version 2019/1/28 新規作成
 */
public class Mst032BeanTest {

    // テストTarget
    @InjectMocks
    private Mst032Bean target;

    // Mockitoオブジェクト
    @Mock
    private AutoCompleteViewBean autoCompleteViewBean;
    @Mock
    private MessageModuleBean message;
    @Mock
    private MessagePropertyBean messagePropertyBean;
    @Mock
    private PageCommonBean pageCommonBean;
    @Mock
    private AuthorityConfBean authConfBean;
    @Mock
    private BreadCrumbBean breadBean;

    public Mst032BeanTest() {
    }

    @Before
    public void setUp() {
        // Mockitoオブジェクト初期化
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void tearDown() {
    }

    // init_正常_初期処理_1-1
    //
    // -------------------テスト条件--------------------------
    // 前画面情報[not null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        // Mockitoオブジェクトの予想return値設定
        Mst032Form flashForm = new Mst032Form();
        Flash flash = new FlashKls();
        //前画面情報[not null]
        flash.put("mst032Form", flashForm);
        when(pageCommonBean.getPageParam()).thenReturn(flash);

        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.init("","",false);

        //実施結果Outを取得
        form = target.getMst032Form();
        String title = target.getTITLE();
        String url = target.getUrl();
        BreadCrumbBean breadBean = target.getBreadBean();
        AutoCompleteViewBean autoCompleteViewBean = target.getAutoCompleteViewBean();
        AuthorityConfBean authorityConfBean = target.getAuthConfBean();
        MessagePropertyBean messagePropertyBean = target.getMessagePropertyBean();
        PageCommonBean pageCommonBean = target.getPageCommonBean();
        Map henkanJohoListMap = target.getHenkanJohoListMap();
        String henkanFlg = target.getHenkanFlg();
        Map shisetsuJohoListMap = target.getShisetsuJohoListMap();
        String shisetsuFlg = target.getShisetsuFlg();
        target.setUrl(url);
        target.setBreadBean(breadBean);
        target.setAutoCompleteViewBean(autoCompleteViewBean);
        target.setAuthConfBean(authorityConfBean);
        target.setMessagePropertyBean(messagePropertyBean);
        target.setPageCommonBean(pageCommonBean);
        target.setHenkanJohoListMap(henkanJohoListMap);
        target.setHenkanFlg(henkanFlg);
        target.setShisetsuJohoListMap(shisetsuJohoListMap);
        target.setShisetsuFlg(shisetsuFlg);

        //想定通りに別紙 「共通マスタ取得」 内 『仕向地取得』 を参照
        assertEquals(null,form.getConJisCd());
        assertEquals("",form.getConJisCdTaihi());
    }

    // init_正常_初期処理_1-2
    //
    // -------------------テスト条件--------------------------
    // 前回画面情報[null]
    // 前画面パラメータ[都道府県 = 01,仕向地名 = 地名23,削除済のみ検索 = null]
    // -----------------------------------------------------
    @Test
    public void init_正常_初期処理_1_2 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<String> keyCaptor_1 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Mst032Form mst032Form = new Mst032Form();
        //前回画面情報[null]

        when(pageCommonBean.getPageInfo(keyCaptor_1.capture())).thenReturn(mst032Form);

        // パラメータキャプチャー
        // Mockitoオブジェクトの予想return値設定
        Flash flash = new FlashKls();
        //前画面パラメータ[都道府県 = 01,仕向地名 = 地名23,削除済のみ検索 = null]
        flash.put("mst032Form", mst032Form);
        when(pageCommonBean.getPageParam()).thenReturn(flash);

        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.init("","",true);

        //実施結果Outを取得
        form = target.getMst032Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst032Form",keyCaptor_1.getValue());
        //想定通りに再検索されること
        assertEquals(null,form.getConJisCd());
        assertEquals(null,form.getConJisCdTaihi());
    }

    // searchJusho_正常_検索処理_2-1
    //
    // -------------------テスト条件--------------------------
    // 住所マスタ情報 = 取得正常(データあり)
    // 住所情報詳細一覧  件数 = 2
    // 住所離島一覧  件数 = 2
    // 住所離島一覧  件数 = 2
    // 住所館内配送一覧  件数 = 2
    // JISコード設定処理 = null
    // 旧住所コメント制御 = 1
    // -----------------------------------------------------
    @Test
    public void searchJusho_正常_検索処理_2_1 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //住所マスタ情報 = 取得正常(データあり)
        Map<String, Object> searchResult = new HashMap();
        Map<String, Object> resultJusho = new HashMap();
        // チェック実行日時
        resultJusho.put("jisChkDtlCheckJikkoHizuke", "jisChkDtlCheckJikkoHizuke");
        // チェック結果
        resultJusho.put("jisChkDtlCheckKekka", "jisChkDtlCheckKekka");
        // ステータス変更日時
        resultJusho.put("jisChkDtlStatusHenkoHizuke", "jisChkDtlStatusHenkoHizuke");
        // 漢字住所（都道府県） 
        resultJusho.put("jshDtlKanjiJushoTodofukenMei", "jshDtlKanjiJushoTodofukenMei");
        // 漢字住所（市区町村）
        resultJusho.put("jshDtlKanjiJushoShikuchosonMei", "jshDtlKanjiJushoShikuchosonMei");
        // 変更漢字住所（都道府県）
        resultJusho.put("jshDtlHenkoKanjiJushoTodofukenMei", "jshDtlHenkoKanjiJushoTodofukenMei");
        // 変更漢字住所（市区町村）
        resultJusho.put("jshDtlHenkoKanjiJushoShikuchosonMei", "jshDtlHenkoKanjiJushoShikuchosonMei");
        // カナ住所（都道府県）
        resultJusho.put("jshDtlKanaJushoTodofukenMei", "jshDtlKanaJushoTodofukenMei");
        // カナ住所（市区町村）
        resultJusho.put("jshDtlKanaJushoShikuchosonMei", "jshDtlKanaJushoShikuchosonMei");
        // 変更カナ住所（都道府県）
        resultJusho.put("jshDtlHenkoKanaJushoTodofukenMei", "jshDtlHenkoKanaJushoTodofukenMei");
        // 変更カナ住所（市区町村）
        resultJusho.put("jshDtlHenkoKanaJushoShikuchosonMei", "jshDtlHenkoKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        resultJusho.put("jshDtlEigoJushoTodofukenMei", "jshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        resultJusho.put("jshDtlEigoJushoShikuchosonMei", "jshDtlEigoJushoShikuchosonMei");
        // 離島有無
        resultJusho.put("jshDtlRitoUmuFlg", "jshDtlRitoUmuFlg");
        // 離島件数
        resultJusho.put("jshDtlRitoKensu", "jshDtlRitoKensu");
        // 館内配送件数
        resultJusho.put("jshDtlKannaiHaisoKensu", "jshDtlKannaiHaisoKensu");
        // HTコメント(100バイト)
        resultJusho.put("jshDtlHtComment1", "jshDtlHtComment1");
        // HTコメント(200バイト)
        resultJusho.put("jshDtlHtComment2", null);
        // 旧住所区分
        resultJusho.put("kyuJushoFlg", "1");
        resultJusho.put("shiyoFukaFlg", "2");
        // JISコード設定処理
        resultJusho.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        // 旧住所コメント
        resultJusho.put("kyjshDtlKyuJushoComment", "kyjshDtlKyuJushoComment");
        // 更新日時
        resultJusho.put("kshnDtlkoshinNichiji", "kshnDtlkoshinNichiji");
        // 更新者
        resultJusho.put("kshnDtlUser", "kshnDtlUser");
        searchResult.put("resultJusho", resultJusho);

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst032Form form = new Mst032Form();

        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        
        target.setMst032Form(form);
        target.searchJusho();

        //実施結果Outを取得
        form = target.getMst032Form();

    }

    // searchJusho_正常_検索処理_2-2
    //
    // -------------------テスト条件--------------------------
    // 住所マスタ情報 = 取得正常(データあり)
    // 住所情報詳細一覧  件数 = 2
    // 住所離島一覧  件数 = 2
    // 住所離島一覧  件数 = 2
    // 住所館内配送一覧  件数 = 2
    // JISコード設定処理 ≠ null
    // 住所館内配送一覧  件数 = 1 2以外
    // -----------------------------------------------------
    @Test
    public void searchJusho_正常_検索処理_2_2 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //住所マスタ情報 = 取得正常(データあり)
        Map<String, Object> searchResult = new HashMap();
        Map<String, Object> resultJusho = new HashMap();
        // チェック実行日時
        resultJusho.put("jisChkDtlCheckJikkoHizuke", "jisChkDtlCheckJikkoHizuke");
        // チェック結果
        resultJusho.put("jisChkDtlCheckKekka", "jisChkDtlCheckKekka");
        // ステータス変更日時
        resultJusho.put("jisChkDtlStatusHenkoHizuke", "jisChkDtlStatusHenkoHizuke");
        // 漢字住所（都道府県） 
        resultJusho.put("jshDtlKanjiJushoTodofukenMei", "jshDtlKanjiJushoTodofukenMei");
        // 漢字住所（市区町村）
        resultJusho.put("jshDtlKanjiJushoShikuchosonMei", "jshDtlKanjiJushoShikuchosonMei");
        // 変更漢字住所（都道府県）
        resultJusho.put("jshDtlHenkoKanjiJushoTodofukenMei", "jshDtlHenkoKanjiJushoTodofukenMei");
        // 変更漢字住所（市区町村）
        resultJusho.put("jshDtlHenkoKanjiJushoShikuchosonMei", "jshDtlHenkoKanjiJushoShikuchosonMei");
        // カナ住所（都道府県）
        resultJusho.put("jshDtlKanaJushoTodofukenMei", "jshDtlKanaJushoTodofukenMei");
        // カナ住所（市区町村）
        resultJusho.put("jshDtlKanaJushoShikuchosonMei", "jshDtlKanaJushoShikuchosonMei");
        // 変更カナ住所（都道府県）
        resultJusho.put("jshDtlHenkoKanaJushoTodofukenMei", "jshDtlHenkoKanaJushoTodofukenMei");
        // 変更カナ住所（市区町村）
        resultJusho.put("jshDtlHenkoKanaJushoShikuchosonMei", "jshDtlHenkoKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        resultJusho.put("jshDtlEigoJushoTodofukenMei", "jshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        resultJusho.put("jshDtlEigoJushoShikuchosonMei", "jshDtlEigoJushoShikuchosonMei");
        // 離島有無
        resultJusho.put("jshDtlRitoUmuFlg", "jshDtlRitoUmuFlg");
        // 離島件数
        resultJusho.put("jshDtlRitoKensu", "jshDtlRitoKensu");
        // 館内配送件数
        resultJusho.put("jshDtlKannaiHaisoKensu", "jshDtlKannaiHaisoKensu");
        // HTコメント(100バイト)
        resultJusho.put("jshDtlHtComment1", "jshDtlHtComment1");
        // HTコメント(200バイト)
        resultJusho.put("jshDtlHtComment2", "jshDtlHtComment2");
        // 旧住所区分
        resultJusho.put("kyuJushoFlg", "kyuJushoFlg");
        resultJusho.put("shiyoFukaFlg", "shiyoFukaFlg");
        // JISコード設定処理
        resultJusho.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        // 旧住所コメント
        resultJusho.put("kyjshDtlKyuJushoComment", "kyjshDtlKyuJushoComment");
        // 更新日時
        resultJusho.put("kshnDtlkoshinNichiji", "kshnDtlkoshinNichiji");
        // 更新者
        resultJusho.put("kshnDtlUser", "kshnDtlUser");
        searchResult.put("resultJusho", resultJusho);

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> nameCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> valueCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        AutoCompOptionBean autoCompOptionBean = new AutoCompOptionBean();
        autoCompOptionBean.setValue("01");
        when(autoCompleteViewBean.initAddr(nameCaptor_3.capture(),valueCaptor_4.capture())).thenReturn(autoCompOptionBean);

        //テスト実行
        Mst032Form form = new Mst032Form();

        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        
        target.setMst032Form(form);
        target.searchJusho();

        //実施結果Outを取得
        form = target.getMst032Form();

    }
    
    // searchJusho_正常_検索処理_2-3
    //
    // -------------------テスト条件--------------------------
    // 住所マスタ情報 = 取得正常(データなし)
    // 住所情報詳細一覧  件数 = 2
    // 住所離島一覧  件数 = 2
    // 住所離島一覧  件数 = 2
    // 住所館内配送一覧  件数 = 1 2以外
    // 新JISコード ≠ null
    // -----------------------------------------------------
    @Test
    public void searchJusho_正常_検索処理_2_3 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> nameCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> valueCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        AutoCompOptionBean autoCompOptionBean = new AutoCompOptionBean();
        autoCompOptionBean.setValue("01");
        when(autoCompleteViewBean.initAddr(nameCaptor_5.capture(),valueCaptor_6.capture())).thenReturn(autoCompOptionBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        
        target.setMst032Form(form);
        target.searchJusho();

        //実施結果Outを取得
        form = target.getMst032Form();
        
        // 実行時に渡すパラメータの検証
        assertEquals("02", paramsCaptor_1.getValue().get("conJisCd"));
        assertEquals("mst032-search", functionCodeCaptor_2.getValue());
        assertEquals("WARN", levelCaptor_3.getValue());
        assertEquals("COMW0011", summaryCaptor_4.getValue());
        assertEquals("JIS_CD_NEW", nameCaptor_5.getValue());
        assertEquals(null, valueCaptor_6.getValue());
        //想定通りにワーク.一覧に内容で設定する。メッセージ（メッセージID：COMW0011）を表示されること
        assertEquals("WARN",levelCaptor_3.getValue());
        assertEquals("COMW0011",summaryCaptor_4.getValue());
        
    }
    // searchJusho_正常_検索処理_2-4
    //
    // -------------------テスト条件--------------------------
    // 住所マスタ情報 = 取得正常(データなし)
    // 住所情報詳細一覧  件数 = 2
    // 住所離島一覧  件数 = 2
    // 住所離島一覧  件数 = 2
    // 住所館内配送一覧  件数 = 1 2以外
    // 新JISコード = null
    // -----------------------------------------------------
    @Test
    public void searchJusho_正常_検索処理_2_4 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> nameCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> valueCaptor_6 = ArgumentCaptor.forClass(String.class);
        // 新JISコード = null
        // Mockitoオブジェクトの予想return値設定
        when(autoCompleteViewBean.initAddr(nameCaptor_5.capture(),valueCaptor_6.capture())).thenReturn(null);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        
        target.setMst032Form(form);
        target.searchJusho();

        //実施結果Outを取得
        form = target.getMst032Form();
        
        // 実行時に渡すパラメータの検証
        assertEquals("02", paramsCaptor_1.getValue().get("conJisCd"));
        assertEquals("mst032-search", functionCodeCaptor_2.getValue());
        assertEquals("WARN", levelCaptor_3.getValue());
        assertEquals("COMW0011", summaryCaptor_4.getValue());
        assertEquals("JIS_CD_NEW", nameCaptor_5.getValue());
        assertEquals(null, valueCaptor_6.getValue());
        //想定通りにワーク.一覧に内容で設定する。メッセージ（メッセージID：COMW0011）を表示されること
        assertEquals("WARN",levelCaptor_3.getValue());
        assertEquals("COMW0011",summaryCaptor_4.getValue());

    }

    // update_正常_更新ボタン_24-1
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 各項目は入力チェック正常
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // DB更新正常
    // -----------------------------------------------------
    @Test
    public void update_正常_更新ボタン_24_1 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_24_1(i));
        }
        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        // 実行時に渡すパラメータの検証
        assertEquals("02", paramsCaptor_1.getValue().get("conJisCd"));
        assertEquals("mst032-search", functionCodeCaptor_2.getValue());
        //想定通りにメッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("WARN", levelCaptor_3.getValue());
        assertEquals("COMW0011", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-2
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 各項目は入力チェック正常
    // 関連チェック異常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_2 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        serviceInterfaceBean2.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean2.addMessage("WARN", "警告", "情報が取得できませんでした。");
        serviceInterfaceBean2.setTableName("住所マスタ");
        
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean2,serviceInterfaceBean);
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_24_1(i));
        }
        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");

            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null, paramsCaptor_1.getValue().get("conJisCd"));
        assertEquals("mst032-insert-update-check", functionCodeCaptor_2.getValue());
    }

    // update_異常_更新ボタン_24-3
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 各項目は入力チェック正常
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // DB更新異常
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_3 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        
        ServiceInterfaceBean serviceInterfaceBean2 = new ServiceInterfaceBean();
        serviceInterfaceBean2.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        serviceInterfaceBean2.addMessage("ERROR", "エラー", "該当データは存在しません。");
        serviceInterfaceBean2.setTableName("住所マスタ");
        
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean,serviceInterfaceBean2);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_24_1(i));
        }
        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        // 実行時に渡すパラメータの検証
        assertEquals(null, paramsCaptor_1.getValue().get("conJisCd"));
        assertEquals("mst032-insert-update", functionCodeCaptor_2.getValue());
    }    
    
    // update_異常_更新ボタン_24-4
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 各項目は入力チェック正常
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = false
    // 新EDI住所 = false
    // DB更新正常
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_4 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_24_4(i));
        }
        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();
    }

    // update_異常_更新ボタン_24-5
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 各項目は入力チェック正常
    // 関連チェック正常
    // 住所JISマスタ変更判定は異常_新JISコード
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // DB更新異常
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_5 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_24_1(i));
        }
        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "KyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        // 実行時に渡すパラメータの検証
        assertEquals("02", paramsCaptor_1.getValue().get("conJisCd"));
        assertEquals("mst032-search", functionCodeCaptor_2.getValue());
        //想定通りにメッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("WARN", levelCaptor_3.getValue());
        assertEquals("COMW0011", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-6
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 各項目は入力チェック正常
    // 関連チェック正常
    // 住所JISマスタ変更判定は異常_旧住所区分
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // DB更新異常
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_6 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_24_1(i));
        }
        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "kyuJushoFlg");
        recMap.put("shiyoFukaFlg", "shiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        // 実行時に渡すパラメータの検証
        assertEquals("02", paramsCaptor_1.getValue().get("conJisCd"));
        assertEquals("mst032-search", functionCodeCaptor_2.getValue());
        //想定通りにメッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("WARN", levelCaptor_3.getValue());
        assertEquals("COMW0011", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-7
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 各項目は入力チェック正常
    // 関連チェック正常
    // 住所JISマスタ変更判定は異常_HTコメント(200バイト)
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // DB更新異常
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_7 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_24_1(i));
        }
        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "jshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        // 実行時に渡すパラメータの検証
        assertEquals("02", paramsCaptor_1.getValue().get("conJisCd"));
        assertEquals("mst032-search", functionCodeCaptor_2.getValue());
        //想定通りにメッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("WARN", levelCaptor_3.getValue());
        assertEquals("COMW0011", summaryCaptor_4.getValue());
    }
    
    // update_異常_更新ボタン_24-8
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 各項目は入力チェック正常
    // 関連チェック正常
    // 住所JISマスタ変更判定は異常_HTコメント(100バイト)
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // DB更新異常
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_8 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_24_1(i));
        }
        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "jshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        // 実行時に渡すパラメータの検証
        assertEquals("02", paramsCaptor_1.getValue().get("conJisCd"));
        assertEquals("mst032-search", functionCodeCaptor_2.getValue());
        //想定通りにメッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("WARN", levelCaptor_3.getValue());
        assertEquals("COMW0011", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-9
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 各項目は入力チェック正常
    // 関連チェック正常
    // 住所JISマスタ変更判定は異常_離島有無
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // DB更新異常
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_9 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_24_1(i));
        }
        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "jshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        // 実行時に渡すパラメータの検証
        assertEquals("02", paramsCaptor_1.getValue().get("conJisCd"));
        assertEquals("mst032-search", functionCodeCaptor_2.getValue());
        //想定通りにメッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("WARN", levelCaptor_3.getValue());
        assertEquals("COMW0011", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-10
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 各項目は入力チェック正常
    // 関連チェック正常
    // 住所JISマスタ変更判定は異常_英語住所市区町村
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // DB更新異常
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_10 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_24_1(i));
        }
        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "jshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        // 実行時に渡すパラメータの検証
        assertEquals("02", paramsCaptor_1.getValue().get("conJisCd"));
        assertEquals("mst032-search", functionCodeCaptor_2.getValue());
        //想定通りにメッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("WARN", levelCaptor_3.getValue());
        assertEquals("COMW0011", summaryCaptor_4.getValue());
    }
    
    // update_異常_更新ボタン_24-11
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 各項目は入力チェック正常
    // 関連チェック正常
    // 住所JISマスタ変更判定は異常_英語住所都道府県
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // DB更新異常
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_11 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_24_1(i));
        }
        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "jshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        // 実行時に渡すパラメータの検証
        assertEquals("02", paramsCaptor_1.getValue().get("conJisCd"));
        assertEquals("mst032-search", functionCodeCaptor_2.getValue());
        //想定通りにメッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("WARN", levelCaptor_3.getValue());
        assertEquals("COMW0011", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-12
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 各項目は入力チェック正常
    // 関連チェック正常
    // 住所JISマスタ変更判定は異常_カナ住所市区町村
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // DB更新異常
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_12 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_24_1(i));
        }
        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "jshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        // 実行時に渡すパラメータの検証
        assertEquals("02", paramsCaptor_1.getValue().get("conJisCd"));
        assertEquals("mst032-search", functionCodeCaptor_2.getValue());
        //想定通りにメッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("WARN", levelCaptor_3.getValue());
        assertEquals("COMW0011", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-13
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 各項目は入力チェック正常
    // 関連チェック正常
    // 住所JISマスタ変更判定は異常_漢字住所市区町村
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // DB更新異常
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_13 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_24_1(i));
        }
        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "jshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        // 実行時に渡すパラメータの検証
        assertEquals("02", paramsCaptor_1.getValue().get("conJisCd"));
        assertEquals("mst032-search", functionCodeCaptor_2.getValue());
        //想定通りにメッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("WARN", levelCaptor_3.getValue());
        assertEquals("COMW0011", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-14
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 各項目は入力チェック正常
    // 関連チェック正常
    // 住所JISマスタ変更判定は異常_適用名
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // DB更新異常
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_14 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_24_1(i));
        }
        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 適用名
        form.setConTekiyoMeiTaihi("ConTekiyoMeiTaihi");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        // 実行時に渡すパラメータの検証
        assertEquals("02", paramsCaptor_1.getValue().get("conJisCd"));
        assertEquals("mst032-search", functionCodeCaptor_2.getValue());
        //想定通りにメッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("WARN", levelCaptor_3.getValue());
        assertEquals("COMW0011", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-15
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 各項目は入力チェック正常
    // 関連チェック正常
    // 住所JISマスタ変更判定は異常_ 住所JISマスタの更新カントー
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // DB更新異常
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_15 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_24_1(i));
        }
        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        // 実行時に渡すパラメータの検証
        assertEquals("02", paramsCaptor_1.getValue().get("conJisCd"));
        assertEquals("mst032-search", functionCodeCaptor_2.getValue());
        //想定通りにメッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("WARN", levelCaptor_3.getValue());
        assertEquals("COMW0011", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-16
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 各項目は入力チェック異常(Max超過)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_16 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture(), paramCaptor_6.capture());

        
        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param2Captor_8_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常

        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture(),param2Captor_8_4.capture())).thenReturn(messageModuleBean);

        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi("40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        form.setJshDtlKanjiJushoTodofukenMei("40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        form.setJshDtlKanjiJushoShikuchosonMei("40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        form.setJshDtlKanaJushoTodofukenMei("40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        form.setJshDtlKanaJushoShikuchosonMei("");
        form.setJshDtlEigoJushoTodofukenMei("40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        form.setJshDtlEigoJushoShikuchosonMei("40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        form.setJshDtlHtComment1("100xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        form.setJshDtlHtComment2("200xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        form.setKyjshDtlKyuJushoComment("40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_24_1(i));
        }
        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0002", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-17
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 各項目は入力チェック異常(空白)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_17 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture(), paramCaptor_6.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param2Captor_8_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture(),param2Captor_8_4.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi("40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        form.setJshDtlKanjiJushoTodofukenMei("");
        form.setJshDtlKanjiJushoShikuchosonMei("");
        form.setJshDtlKanaJushoTodofukenMei("");
        form.setJshDtlKanaJushoShikuchosonMei("");
        form.setJshDtlEigoJushoTodofukenMei("");
        form.setJshDtlEigoJushoShikuchosonMei("");
        form.setJshDtlHtComment1("100xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        form.setJshDtlHtComment2("200xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        form.setKyjshDtlKyuJushoComment("40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_24_1(i));
        }
        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0002", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-18
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 住所詳細一覧の入力チェック異常(空白)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_18 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 3; i++) {
            listJushoSelectedResult.add(createJushoMapFor_24_18(i));
        }
        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0003", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-19
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 住所詳細一覧の入力チェック異常(99)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_19 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 3; i++) {
            listJushoSelectedResult.add(createJushoMapFor_24_19(i));
        }
        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("MSTE0110", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-20
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 住所詳細一覧の入力チェック異常(2桁超過)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_20 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture(), paramCaptor_6.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 3; i++) {
            listJushoSelectedResult.add(createJushoMapFor_24_20(i));
        }
        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0002", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-21
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 住所詳細一覧の入力チェック異常(仕向地コード重複)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_21 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture());
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_24_21(i));
        }
        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();
    }
    
    // update_異常_更新ボタン_24-22
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 住所離島一覧の入力チェック異常(40桁超過)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_22 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture(), paramCaptor_6.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_24_1(i));
        }
        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
            // 住所
            recMap.put("rtDtlListJusho", "40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
            // 備考
            recMap.put("rtDtlListBiko", "40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0002", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-23
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 館内配送一覧の入力チェック異常(40桁超過)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_23 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture(), paramCaptor_6.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_24_1(i));
        }
        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
            // 住所
            recMap.put("khDtlListJusho", "40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
            // 備考
            recMap.put("khDtlListBiko", "40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0002", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-24
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 館内配送一覧の備考入力チェック異常(40桁超過)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_24 ()  throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture(), paramCaptor_6.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_24_1(i));
        }
        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0002", summaryCaptor_4.getValue());
    }
    
    // update_異常_更新ボタン_24-25
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 館内配送一覧の住所入力チェック異常(40桁超過)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_25 ()  throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture(), paramCaptor_6.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_24_1(i));
        }
        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0002", summaryCaptor_4.getValue());
    }


    // update_異常_更新ボタン_24-26
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 住所離島一覧の備考入力チェック異常(40桁超過)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_26 ()  throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture(), paramCaptor_6.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_24_1(i));
        }
        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0002", summaryCaptor_4.getValue());
    }
    
    // update_異常_更新ボタン_24-27
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 住所離島一覧の住所入力チェック異常(40桁超過)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_27 ()  throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture(), paramCaptor_6.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_24_1(i));
        }
        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COMI0011）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0002", summaryCaptor_4.getValue());
    }
    
    // update_異常_更新ボタン_24-28
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 住所詳細一覧の管轄営業所コード入力チェック異常(空)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_28 ()  throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture());

        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        Map map = new HashMap();
        // 仕向地コード(下2桁)
        map.put("jshDtlListShimukeChiCd", "00");
        // 町字
        map.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字
        map.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        map.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 町字
        map.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        map.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        map.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        map.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        map.put("jshDtlListEigyoshoCd", "");

        map.put("jshDtlListKyuEdiJushoFlg", "true");

        map.put("jshDtlListShinEdiJushoFlg", "true");

        map.put(StndConsIF.CONST_ADD_ROW_KEY, "true");

        map.put("jshDtlListHShimukeChiCd", "00");

        map.put("jshDtlListHShimukeChiCd", "02");
        listJushoSelectedResult.add(map);

        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COME0003）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0003", summaryCaptor_4.getValue());
    }
    
    // update_異常_更新ボタン_24-29
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    //  住所詳細一覧の集配地区コード入力チェック異常(空)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_29 ()  throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture());

        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        Map map = new HashMap();
        // 仕向地コード(下2桁)
        map.put("jshDtlListShimukeChiCd", "00");
        // 町字
        map.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字
        map.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        map.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 町字
        map.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        map.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        map.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        map.put("jshDtlListShuhaiChikuCd", "");
        // 管轄営業所コード
        map.put("jshDtlListEigyoshoCd", "");

        map.put("jshDtlListKyuEdiJushoFlg", "true");

        map.put("jshDtlListShinEdiJushoFlg", "true");

        map.put(StndConsIF.CONST_ADD_ROW_KEY, "true");

        map.put("jshDtlListHShimukeChiCd", "00");

        map.put("jshDtlListHShimukeChiCd", "02");
        listJushoSelectedResult.add(map);

        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COME0003）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0003", summaryCaptor_4.getValue());
    }
    
    // update_異常_更新ボタン_24-30
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    //  住所詳細一覧の空港コード入力チェック異常(空)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_30 ()  throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture());

        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        Map map = new HashMap();
        // 仕向地コード(下2桁)
        map.put("jshDtlListShimukeChiCd", "00");
        // 町字
        map.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字
        map.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        map.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 町字
        map.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        map.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        map.put("jshDtlListKukoCd", "");
        // 集配地区コード
        map.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        map.put("jshDtlListEigyoshoCd", "");

        map.put("jshDtlListKyuEdiJushoFlg", "true");

        map.put("jshDtlListShinEdiJushoFlg", "true");

        map.put(StndConsIF.CONST_ADD_ROW_KEY, "true");

        map.put("jshDtlListHShimukeChiCd", "00");

        map.put("jshDtlListHShimukeChiCd", "02");
        listJushoSelectedResult.add(map);

        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COME0003）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0003", summaryCaptor_4.getValue());
    }
    
    // update_異常_更新ボタン_24-31
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    //  住所詳細一覧の仕向地名入力チェック異常(空)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_31 ()  throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture());

        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        Map map = new HashMap();
        // 仕向地コード(下2桁)
        map.put("jshDtlListShimukeChiCd", "00");
        // 町字
        map.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字
        map.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        map.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 町字
        map.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        map.put("jshDtlListShimukeChiMeiCd", "");
        // 空港コード
        map.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        map.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        map.put("jshDtlListEigyoshoCd", "");

        map.put("jshDtlListKyuEdiJushoFlg", "true");

        map.put("jshDtlListShinEdiJushoFlg", "true");

        map.put(StndConsIF.CONST_ADD_ROW_KEY, "true");

        map.put("jshDtlListHShimukeChiCd", "00");

        map.put("jshDtlListHShimukeChiCd", "02");
        listJushoSelectedResult.add(map);

        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COME0003）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0003", summaryCaptor_4.getValue());
    }
    
    // update_異常_更新ボタン_24-32
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 住所詳細一覧の町字カナ入力チェック異常(空)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_32 ()  throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture());

        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        Map map = new HashMap();
        // 仕向地コード(下2桁)
        map.put("jshDtlListShimukeChiCd", "00");
        // 町字
        map.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字
        map.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        map.put("jshDtlListChoazaKana", "");
        // 仕向地名
        map.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        map.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        map.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        map.put("jshDtlListEigyoshoCd", "");

        map.put("jshDtlListKyuEdiJushoFlg", "true");

        map.put("jshDtlListShinEdiJushoFlg", "true");

        map.put(StndConsIF.CONST_ADD_ROW_KEY, "true");

        map.put("jshDtlListHShimukeChiCd", "00");

        map.put("jshDtlListHShimukeChiCd", "02");
        listJushoSelectedResult.add(map);

        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COME0003）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0003", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-33
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 住所詳細一覧の町字カナ入力チェック異常(40桁超過)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_33 ()  throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture());

        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        Map map = new HashMap();
        // 仕向地コード(下2桁)
        map.put("jshDtlListShimukeChiCd", "00");
        // 町字
        map.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字
        map.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        map.put("jshDtlListChoazaKana", "40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        // 仕向地名
        map.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        map.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        map.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        map.put("jshDtlListEigyoshoCd", "");

        map.put("jshDtlListKyuEdiJushoFlg", "true");

        map.put("jshDtlListShinEdiJushoFlg", "true");

        map.put(StndConsIF.CONST_ADD_ROW_KEY, "true");

        map.put("jshDtlListHShimukeChiCd", "00");

        map.put("jshDtlListHShimukeChiCd", "02");
        listJushoSelectedResult.add(map);

        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COME0002）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0002", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-34
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 住所詳細一覧の町字入力チェック異常(空)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_34 ()  throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture());

        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        Map map = new HashMap();
        // 仕向地コード(下2桁)
        map.put("jshDtlListShimukeChiCd", "00");
        // 町字
        map.put("jshDtlListChoaza", "");
        // 町字カナ
        map.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        map.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        map.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        map.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        map.put("jshDtlListEigyoshoCd", "");

        map.put("jshDtlListKyuEdiJushoFlg", "true");

        map.put("jshDtlListShinEdiJushoFlg", "true");

        map.put(StndConsIF.CONST_ADD_ROW_KEY, "true");

        map.put("jshDtlListHShimukeChiCd", "00");

        map.put("jshDtlListHShimukeChiCd", "02");
        listJushoSelectedResult.add(map);

        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COME0003）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0003", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-35
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 住所詳細一覧の町字入力チェック異常(40桁超過)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_35 ()  throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture());

        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        Map map = new HashMap();
        // 仕向地コード(下2桁)
        map.put("jshDtlListShimukeChiCd", "00");
        // 町字
        map.put("jshDtlListChoaza", "40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        // 町字カナ
        map.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        map.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        map.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        map.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        map.put("jshDtlListEigyoshoCd", "");

        map.put("jshDtlListKyuEdiJushoFlg", "true");

        map.put("jshDtlListShinEdiJushoFlg", "true");

        map.put(StndConsIF.CONST_ADD_ROW_KEY, "true");

        map.put("jshDtlListHShimukeChiCd", "00");

        map.put("jshDtlListHShimukeChiCd", "02");
        listJushoSelectedResult.add(map);

        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COME0003）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0002", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-36
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 住所詳細一覧の旧住所コメント入力チェック異常(40桁超過)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_36 ()  throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture());

        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        Map map = new HashMap();
        // 仕向地コード(下2桁)
        map.put("jshDtlListShimukeChiCd", "00");
        // 町字
        map.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        map.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        map.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        map.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        map.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        map.put("jshDtlListEigyoshoCd", "");

        map.put("jshDtlListKyuEdiJushoFlg", "true");

        map.put("jshDtlListShinEdiJushoFlg", "true");

        map.put(StndConsIF.CONST_ADD_ROW_KEY, "true");

        map.put("jshDtlListHShimukeChiCd", "00");

        map.put("jshDtlListHShimukeChiCd", "02");
        listJushoSelectedResult.add(map);

        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlRitoUmuFlg(new String[]{"JshDtlRitoUmuFlg"});
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COME0002）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0002", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-37
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 住所詳細一覧のHTコメント(200バイト)入力チェック異常(200桁超過)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_37 ()  throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture());

        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("200xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        Map map = new HashMap();
        // 仕向地コード(下2桁)
        map.put("jshDtlListShimukeChiCd", "00");
        // 町字
        map.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        map.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        map.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        map.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        map.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        map.put("jshDtlListEigyoshoCd", "");

        map.put("jshDtlListKyuEdiJushoFlg", "true");

        map.put("jshDtlListShinEdiJushoFlg", "true");

        map.put(StndConsIF.CONST_ADD_ROW_KEY, "true");

        map.put("jshDtlListHShimukeChiCd", "00");

        map.put("jshDtlListHShimukeChiCd", "02");
        listJushoSelectedResult.add(map);

        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COME0002）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0002", summaryCaptor_4.getValue());
    }
    
    // update_異常_更新ボタン_24-38
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 住所詳細一覧のHTコメント(100バイト)入力チェック異常(100桁超過)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_38 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture());

        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlEigoJushoShikuchosonMei("JshDtlEigoJushoShikuchosonMei");
        form.setJshDtlHtComment1("100xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        Map map = new HashMap();
        // 仕向地コード(下2桁)
        map.put("jshDtlListShimukeChiCd", "00");
        // 町字
        map.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        map.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        map.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        map.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        map.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        map.put("jshDtlListEigyoshoCd", "");

        map.put("jshDtlListKyuEdiJushoFlg", "true");

        map.put("jshDtlListShinEdiJushoFlg", "true");

        map.put(StndConsIF.CONST_ADD_ROW_KEY, "true");

        map.put("jshDtlListHShimukeChiCd", "00");

        map.put("jshDtlListHShimukeChiCd", "02");
        listJushoSelectedResult.add(map);

        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COME0002）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0002", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-39
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 住所詳細一覧の英語住所（市区町村）入力チェック異常(空)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_39 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture());

        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        Map map = new HashMap();
        // 仕向地コード(下2桁)
        map.put("jshDtlListShimukeChiCd", "00");
        // 町字
        map.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        map.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        map.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        map.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        map.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        map.put("jshDtlListEigyoshoCd", "");

        map.put("jshDtlListKyuEdiJushoFlg", "true");

        map.put("jshDtlListShinEdiJushoFlg", "true");

        map.put(StndConsIF.CONST_ADD_ROW_KEY, "true");

        map.put("jshDtlListHShimukeChiCd", "00");

        map.put("jshDtlListHShimukeChiCd", "02");
        listJushoSelectedResult.add(map);

        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COME0003）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0003", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-40
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 住所詳細一覧の英語住所（市区町村）入力チェック異常(40桁超過)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_40 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture());

        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        Map map = new HashMap();
        // 仕向地コード(下2桁)
        map.put("jshDtlListShimukeChiCd", "00");
        // 町字
        map.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        map.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        map.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        map.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        map.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        map.put("jshDtlListEigyoshoCd", "");

        map.put("jshDtlListKyuEdiJushoFlg", "true");

        map.put("jshDtlListShinEdiJushoFlg", "true");

        map.put(StndConsIF.CONST_ADD_ROW_KEY, "true");

        map.put("jshDtlListHShimukeChiCd", "00");

        map.put("jshDtlListHShimukeChiCd", "02");
        listJushoSelectedResult.add(map);

        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COME0002）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0002", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-41
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 住所詳細一覧の英語住所（都道府県）入力チェック異常(空)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_41 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture());

        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("");
        form.setJshDtlEigoJushoShikuchosonMei("");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        Map map = new HashMap();
        // 仕向地コード(下2桁)
        map.put("jshDtlListShimukeChiCd", "00");
        // 町字
        map.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        map.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        map.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        map.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        map.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        map.put("jshDtlListEigyoshoCd", "");

        map.put("jshDtlListKyuEdiJushoFlg", "true");

        map.put("jshDtlListShinEdiJushoFlg", "true");

        map.put(StndConsIF.CONST_ADD_ROW_KEY, "true");

        map.put("jshDtlListHShimukeChiCd", "00");

        map.put("jshDtlListHShimukeChiCd", "02");
        listJushoSelectedResult.add(map);

        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COME0003）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0003", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-42
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 住所詳細一覧の英語住所（都道府県）入力チェック異常(40桁超過)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_42 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture());

        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        form.setJshDtlEigoJushoShikuchosonMei("");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        Map map = new HashMap();
        // 仕向地コード(下2桁)
        map.put("jshDtlListShimukeChiCd", "00");
        // 町字
        map.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        map.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        map.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        map.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        map.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        map.put("jshDtlListEigyoshoCd", "");

        map.put("jshDtlListKyuEdiJushoFlg", "true");

        map.put("jshDtlListShinEdiJushoFlg", "true");

        map.put(StndConsIF.CONST_ADD_ROW_KEY, "true");

        map.put("jshDtlListHShimukeChiCd", "00");

        map.put("jshDtlListHShimukeChiCd", "02");
        listJushoSelectedResult.add(map);

        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COME0002）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0002", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-43
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 住所詳細一覧のカナ住所（市区町村）入力チェック異常(空)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_43 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture());

        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        Map map = new HashMap();
        // 仕向地コード(下2桁)
        map.put("jshDtlListShimukeChiCd", "00");
        // 町字
        map.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        map.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        map.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        map.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        map.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        map.put("jshDtlListEigyoshoCd", "");

        map.put("jshDtlListKyuEdiJushoFlg", "true");

        map.put("jshDtlListShinEdiJushoFlg", "true");

        map.put(StndConsIF.CONST_ADD_ROW_KEY, "true");

        map.put("jshDtlListHShimukeChiCd", "00");

        map.put("jshDtlListHShimukeChiCd", "02");
        listJushoSelectedResult.add(map);

        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COME0003）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0003", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-44
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 住所詳細一覧のカナ住所（都道府県）入力チェック異常(空)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_44 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture());

        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        Map map = new HashMap();
        // 仕向地コード(下2桁)
        map.put("jshDtlListShimukeChiCd", "00");
        // 町字
        map.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        map.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        map.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        map.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        map.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        map.put("jshDtlListEigyoshoCd", "");

        map.put("jshDtlListKyuEdiJushoFlg", "true");

        map.put("jshDtlListShinEdiJushoFlg", "true");

        map.put(StndConsIF.CONST_ADD_ROW_KEY, "true");

        map.put("jshDtlListHShimukeChiCd", "00");

        map.put("jshDtlListHShimukeChiCd", "02");
        listJushoSelectedResult.add(map);

        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COME0003）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0003", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-45
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 住所詳細一覧のカナ住所（都道府県）入力チェック異常(40桁超過)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_45 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture());

        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        Map map = new HashMap();
        // 仕向地コード(下2桁)
        map.put("jshDtlListShimukeChiCd", "00");
        // 町字
        map.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        map.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        map.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        map.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        map.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        map.put("jshDtlListEigyoshoCd", "");

        map.put("jshDtlListKyuEdiJushoFlg", "true");

        map.put("jshDtlListShinEdiJushoFlg", "true");

        map.put(StndConsIF.CONST_ADD_ROW_KEY, "true");

        map.put("jshDtlListHShimukeChiCd", "00");

        map.put("jshDtlListHShimukeChiCd", "02");
        listJushoSelectedResult.add(map);

        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COME0002）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0002", summaryCaptor_4.getValue());
    }
    
    // update_異常_更新ボタン_24-46
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 住所詳細一覧の漢字住所（市区町村）入力チェック異常(空)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_46 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture());

        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        Map map = new HashMap();
        // 仕向地コード(下2桁)
        map.put("jshDtlListShimukeChiCd", "00");
        // 町字
        map.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        map.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        map.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        map.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        map.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        map.put("jshDtlListEigyoshoCd", "");

        map.put("jshDtlListKyuEdiJushoFlg", "true");

        map.put("jshDtlListShinEdiJushoFlg", "true");

        map.put(StndConsIF.CONST_ADD_ROW_KEY, "true");

        map.put("jshDtlListHShimukeChiCd", "00");

        map.put("jshDtlListHShimukeChiCd", "02");
        listJushoSelectedResult.add(map);

        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COME0003）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0003", summaryCaptor_4.getValue());
    }
    
    // henkanJohoPopShow_正常_変換件数リンク_18-1
    //
    // -------------------テスト条件--------------------------
    // 適用開始日（退避用） ≠ null 変換キーはマッチしない
    // -----------------------------------------------------
    @Test
    public void henkanJohoPopShow_正常_変換件数リンク_18_1 () throws IllegalAccessException, InvocationTargetException {
        
        // 館内配送詳細リスト
        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = new ArrayList<>();
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        resultList.add(recMap);
        
        resMap.put("tablesorter_mst032", resultList);
        foucesDataList.put("tablesorter_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);
        when(pageCommonBean.getFoucesDataList()).thenReturn(foucesDataList);

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        resultListKannai.add(recMap);

        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultListKannai));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoKaishibiTaihi(new Date());
        target.setHenkanJohoListMap(new HashMap());

        target.setMst032Form(form);
        target.henkanJohoPopShow("tablesorter_mst032");

        //実施結果Outを取得
        form = target.getMst032Form();

        // 実行時に渡すパラメータの検証
        //想定通りにメッセージ（メッセージID：COME0002）を表示されること
        assertEquals("jshDtlListJisJusho",paramsCaptor_1.getValue().get("hnknDtlJisJusho"));
    }

    // update_異常_更新ボタン_24-47
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 住所詳細一覧の漢字住所（市区町村）入力チェック異常(40桁超過)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_47 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture());

        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("JshDtlKanjiJushoTodofukenMei");
        form.setJshDtlKanjiJushoShikuchosonMei("40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        Map map = new HashMap();
        // 仕向地コード(下2桁)
        map.put("jshDtlListShimukeChiCd", "00");
        // 町字
        map.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        map.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        map.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        map.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        map.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        map.put("jshDtlListEigyoshoCd", "");

        map.put("jshDtlListKyuEdiJushoFlg", "true");

        map.put("jshDtlListShinEdiJushoFlg", "true");

        map.put(StndConsIF.CONST_ADD_ROW_KEY, "true");

        map.put("jshDtlListHShimukeChiCd", "00");

        map.put("jshDtlListHShimukeChiCd", "02");
        listJushoSelectedResult.add(map);

        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COME0002）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0002", summaryCaptor_4.getValue());
    }
    
    // update_異常_更新ボタン_24-48
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 住所詳細一覧の漢字住所（都道府県）入力チェック異常(空)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_48 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture());

        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        Map map = new HashMap();
        // 仕向地コード(下2桁)
        map.put("jshDtlListShimukeChiCd", "00");
        // 町字
        map.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        map.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        map.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        map.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        map.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        map.put("jshDtlListEigyoshoCd", "");

        map.put("jshDtlListKyuEdiJushoFlg", "true");

        map.put("jshDtlListShinEdiJushoFlg", "true");

        map.put(StndConsIF.CONST_ADD_ROW_KEY, "true");

        map.put("jshDtlListHShimukeChiCd", "00");

        map.put("jshDtlListHShimukeChiCd", "02");
        listJushoSelectedResult.add(map);

        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COME0003）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0003", summaryCaptor_4.getValue());
    }

    // update_異常_更新ボタン_24-49
    //
    // -------------------テスト条件--------------------------
    // 適用名（退避用） = null
    // 住所詳細一覧の漢字住所（都道府県）入力チェック異常(40桁超過)
    // 関連チェック正常
    // 住所JISマスタ変更判定は正常
    // チェック結果 = OK
    // 旧EDI住所 = true
    // 新EDI住所 = true
    // -----------------------------------------------------
    @Test
    public void update_異常_更新ボタン_24_49 () throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        //仕向地検索件数取得 取得件数 = 2
        //住所マスタ情報 = 取得正常(データなし)
        Map<String, Object> searchResult = new HashMap();
        searchResult.put("resultJusho", "");

        // 住所詳細情報リスト
        List<Map<String, String>> resultListJusho = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListJusho.add(createJushoMapFor_2_1(i));
        }
        searchResult.put("resultListJusho", resultListJusho);
        
        // 離島詳細リスト
        List<Map<String, String>> resultListRito = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListRito.add(createRitoMapFor_2_1(i));
        }
        searchResult.put("resultListRito", resultListRito);
        
        // 館内配送詳細リスト  
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            resultListKannai.add(createKannaiMapFor_2_1(i));
        }
        searchResult.put("resultListKannai", resultListKannai);
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(searchResult));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture());

        // パラメータキャプチャー
        ArgumentCaptor<List> messageCaptor_3 = ArgumentCaptor.forClass(List.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).messageList(messageCaptor_3.capture());
        
        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_5_1 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_6_2 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> param1Captor_7_3 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        MessageModuleBean messageModuleBean = new MessageModuleBean();
        //関連チェック正常
        when(messagePropertyBean.createMessageModule(levelCaptor_5_1.capture(),summaryCaptor_6_2.capture(),param1Captor_7_3.capture())).thenReturn(messageModuleBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoMeiTaihi(null);
        form.setJshDtlKanjiJushoTodofukenMei("40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        form.setJshDtlKanjiJushoShikuchosonMei("JshDtlKanjiJushoShikuchosonMei");
        form.setJshDtlKanaJushoTodofukenMei("JshDtlKanaJushoTodofukenMei");
        form.setJshDtlKanaJushoShikuchosonMei("JshDtlKanaJushoShikuchosonMei");
        form.setJshDtlEigoJushoTodofukenMei("JshDtlEigoJushoTodofukenMei");
        form.setJshDtlEigoJushoShikuchosonMei("");
        form.setJshDtlHtComment1("JshDtlHtComment1");
        form.setJshDtlHtComment2("JshDtlHtComment2");
        form.setKyjshDtlKyuJushoComment("KyjshDtlKyuJushoComment");

        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        Map map = new HashMap();
        // 仕向地コード(下2桁)
        map.put("jshDtlListShimukeChiCd", "00");
        // 町字
        map.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        map.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        map.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        map.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        map.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        map.put("jshDtlListEigyoshoCd", "");

        map.put("jshDtlListKyuEdiJushoFlg", "true");

        map.put("jshDtlListShinEdiJushoFlg", "true");

        map.put(StndConsIF.CONST_ADD_ROW_KEY, "true");

        map.put("jshDtlListHShimukeChiCd", "00");

        map.put("jshDtlListHShimukeChiCd", "02");
        listJushoSelectedResult.add(map);

        form.setListJushoSelectedResult(listJushoSelectedResult);

        List<Map<String, Object>> listRitoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 島名
            recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
            // 住所
            recMap.put("rtDtlListJusho", "rtDtlListJusho");
            // 備考
            recMap.put("rtDtlListBiko", "rtDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listRitoSelectedResult.add(recMap);
        }
        form.setListRitoSelectedResult(listRitoSelectedResult);
        
        List<Map<String, Object>> listKannaiSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Map recMap = new HashMap();
            // 施設名
            recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
            // 住所
            recMap.put("khDtlListJusho", "khDtlListJusho");
            // 備考
            recMap.put("khDtlListBiko", "khDtlListBiko");
        if (i == 0) {
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
            listKannaiSelectedResult.add(recMap);
        }
        form.setListKannaiSelectedResult(listKannaiSelectedResult);
        
        // 住所JISマスタ変更判定
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        form.setResultJusho(recMap);

        form.setKyjshDtlKyuJushoKubun(new String[]{"KyuJushoFlg","ShiyoFukaFlg"});
        AutoCompOptionBean kyjshDtlShinJisCd = new AutoCompOptionBean();
        kyjshDtlShinJisCd.setValue("kyjshDtlShinJisCd");
        form.setKyjshDtlShinJisCd(kyjshDtlShinJisCd);
        form.setConTekiyoKaishibi("2019/03/02");
        AutoCompOptionBean conJisCd = new AutoCompOptionBean();
        conJisCd.setValue("02");
        form.setConJisCd(conJisCd);
        
        form.setJisChkDtlCheckKekka("OK");
        
        target.setMst032Form(form);
        target.update();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにメッセージ（メッセージID：COME0002）を表示されること
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0002", summaryCaptor_4.getValue());
    }
    
    // henkanJohoPopShow_正常_変換件数リンク_18-2
    //
    // -------------------テスト条件--------------------------
    // 適用開始日（退避用） = null 変換キーはマッチしない
    // -----------------------------------------------------
    @Test
    public void henkanJohoPopShow_正常_変換件数リンク_18_2 () throws IllegalAccessException, InvocationTargetException {
        
        // 館内配送詳細リスト
        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = new ArrayList<>();
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        resultList.add(recMap);
        
        resMap.put("tablesorter_mst032", resultList);
        foucesDataList.put("tablesorter_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);
        when(pageCommonBean.getFoucesDataList()).thenReturn(foucesDataList);

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        resultListKannai.add(recMap);

        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultListKannai));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoKaishibiTaihi(null);
        target.setHenkanJohoListMap(new HashMap());

        target.setMst032Form(form);
        target.henkanJohoPopShow("tablesorter_mst032");

        //実施結果Outを取得
        form = target.getMst032Form();

    }

    // henkanJohoPopShow_正常_変換件数リンク_18-3
    //
    // -------------------テスト条件--------------------------
    // 適用開始日（退避用） ≠ null 変換キーはマッチする
    // -----------------------------------------------------
    @Test
    public void henkanJohoPopShow_正常_変換件数リンク_18_3 () throws IllegalAccessException, InvocationTargetException {
        
        // 館内配送詳細リスト
        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = new ArrayList<>();
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        resultList.add(recMap);
        
        resMap.put("tablesorter_mst032", resultList);
        foucesDataList.put("tablesorter_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);
        when(pageCommonBean.getFoucesDataList()).thenReturn(foucesDataList);

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        // Mockitoオブジェクトの予想return値設定
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        List<Map<String, String>> resultListKannai = new ArrayList<>();
        resultListKannai.add(recMap);

        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultListKannai));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();

        form.setConTekiyoKaishibiTaihi(new Date());
        Map henkanJohoListMap = new HashMap();
        henkanJohoListMap.put("jshDtlListJisCdjshDtlListHShimukeChiCd", resultListKannai);
        target.setHenkanJohoListMap(henkanJohoListMap);

        target.setMst032Form(form);
        target.henkanJohoPopShow("tablesorter_mst032");

        //実施結果Outを取得
        form = target.getMst032Form();

    }

    // setHenkanJoho_正常_設定ボタン（変換情報ポップアップ）_27-1
    //
    // -------------------テスト条件--------------------------
    // 変換情報検索処理：
    // 仕向地フラグ　≠ ""
    // 変換住所チェック正常
    // 住所重複チェック正常
    // 取得件数 = 0の場合
    // -----------------------------------------------------
    @Test
    public void setHenkanJoho_正常_設定ボタン変換情報ポップアップ_27_1 () throws IllegalAccessException, InvocationTargetException {

        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        List<Map<String, Object>> res = new ArrayList();
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(res));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();
        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_27_2(i));
        }
        ReportListDataModel dm = new ReportListDataModel(listJushoSelectedResult);
        form.setListJushoSelectable(dm);
        Map<String, Object> henkanJoho = new HashMap();
        henkanJoho.put("hnknDtlShimukeChiCd", "hnknDtlShimukeChiCd");
        henkanJoho.put("key", "key");
        form.setHenkanJoho(henkanJoho);
        form.setListHenkanSelectable(dm);
        target.setHenkanJohoListMap(new HashMap());
        target.setMst032Form(form);
        target.setHenkanJoho();

        //実施結果Outを取得
        form = target.getMst032Form();

        // 実行時に渡すパラメータの検証
    }
    
    // setHenkanJoho_異常_設定ボタン（変換情報ポップアップ）_27-2
    //
    // -------------------テスト条件--------------------------
    // 変換情報検索処理：
    // 仕向地フラグ　≠ ""
    // 変換住所チェック正常
    // 住所重複チェック正常
    // 取得件数 > 0の場合
    // -----------------------------------------------------
    @Test
    public void setHenkanJoho_異常_設定ボタン変換情報ポップアップ_27_2 () throws IllegalAccessException, InvocationTargetException {

        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        List<Map<String, Object>> res = new ArrayList();
        res.add(recMap);
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(res));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();
        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_27_2(i));
        }
        ReportListDataModel dm = new ReportListDataModel(listJushoSelectedResult);
        form.setListJushoSelectable(dm);
        Map<String, Object> henkanJoho = new HashMap();
        henkanJoho.put("hnknDtlShimukeChiCd", "hnknDtlShimukeChiCd");
        form.setHenkanJoho(henkanJoho);
        form.setListHenkanSelectable(dm);
        target.setMst032Form(form);
        target.setHenkanJoho();

        //実施結果Outを取得
        form = target.getMst032Form();

        // 実行時に渡すパラメータの検証
    }

    // setHenkanJoho_異常_設定ボタン（変換情報ポップアップ）_27-3
    //
    // -------------------テスト条件--------------------------
    // 変換情報検索処理：
    // 仕向地フラグ　≠ ""
    // 変換住所チェック正常
    // 住所重複チェック異常
    // 
    // -----------------------------------------------------
    @Test
    public void setHenkanJoho_正常_設定ボタン変換情報ポップアップ_27_3 () throws IllegalAccessException, InvocationTargetException {

        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        List<Map<String, Object>> res = new ArrayList();
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(res));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();
        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_27_3(i));
        }
        ReportListDataModel dm = new ReportListDataModel(listJushoSelectedResult);
        form.setListJushoSelectable(dm);
        Map<String, Object> henkanJoho = new HashMap();
        henkanJoho.put("hnknDtlShimukeChiCd", "hnknDtlShimukeChiCd");
        henkanJoho.put("key", "key");
        form.setHenkanJoho(henkanJoho);
        form.setListHenkanSelectable(dm);
        target.setHenkanJohoListMap(new HashMap());
        target.setMst032Form(form);
        target.setHenkanJoho();

        //実施結果Outを取得
        form = target.getMst032Form();

        // 実行時に渡すパラメータの検証
    }

    // setHenkanJoho_異常_設定ボタン（変換情報ポップアップ）_27-4
    //
    // -------------------テスト条件--------------------------
    // 変換情報検索処理：
    // 仕向地フラグ　≠ ""
    // 変換住所チェック > 40 桁
    // 
    // 
    // -----------------------------------------------------
    @Test
    public void setHenkanJoho_正常_設定ボタン変換情報ポップアップ_27_4 () throws IllegalAccessException, InvocationTargetException {

        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        List<Map<String, Object>> res = new ArrayList();
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(res));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();
        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_27_4(i));
        }
        ReportListDataModel dm = new ReportListDataModel(listJushoSelectedResult);
        form.setListJushoSelectable(dm);
        Map<String, Object> henkanJoho = new HashMap();
        henkanJoho.put("hnknDtlShimukeChiCd", "hnknDtlShimukeChiCd");
        henkanJoho.put("key", "key");
        form.setHenkanJoho(henkanJoho);
        form.setListHenkanSelectable(dm);
        target.setHenkanJohoListMap(new HashMap());
        target.setMst032Form(form);
        target.setHenkanJoho();

        //実施結果Outを取得
        form = target.getMst032Form();

        // 実行時に渡すパラメータの検証
    }
    
    // setHenkanJoho_異常_設定ボタン（変換情報ポップアップ）_27-5
    //
    // -------------------テスト条件--------------------------
    // 変換情報検索処理：
    // 仕向地フラグ　= ""
    // 
    // 
    // -----------------------------------------------------
    @Test
    public void setHenkanJoho_正常_設定ボタン変換情報ポップアップ_27_5 () throws IllegalAccessException, InvocationTargetException {

        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        List<Map<String, Object>> res = new ArrayList();
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(res));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();
        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_27_2(i));
        }
        ReportListDataModel dm = new ReportListDataModel(listJushoSelectedResult);
        form.setListJushoSelectable(dm);
        Map<String, Object> henkanJoho = new HashMap();
        henkanJoho.put("hnknDtlShimukeChiCd", "xhnknDtlShimukeChiCdx");
        henkanJoho.put("key", "key");
        form.setHenkanJoho(henkanJoho);
        form.setListHenkanSelectable(dm);
        target.setHenkanJohoListMap(new HashMap());
        target.setMst032Form(form);
        target.setHenkanJoho();

        //実施結果Outを取得
        form = target.getMst032Form();
    }
    
    // shisetsuJohoPopShow_正常_初期処理（施設名表記情報ポップアップ）_29-1
    //
    // -------------------テスト条件--------------------------
    // 施設表示名情報リスト　= null
    // 配送シーケンス　≠ null
    // -----------------------------------------------------
    @Test
    public void shisetsuJohoPopShow_正常_初期処理施設名表記情報ポップアップ_29_1 () throws IllegalAccessException, InvocationTargetException {

        // 館内配送詳細リスト
        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = new ArrayList<>();
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");

        recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
        recMap.put("khDtlListHJushoKannaihaisoSeq", "khDtlListHJushoKannaihaisoSeq");
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        resultList.add(recMap);
        
        resMap.put("tablesorter_mst032", resultList);
        foucesDataList.put("tablesorter_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);
        when(pageCommonBean.getFoucesDataList()).thenReturn(foucesDataList);
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        List<Map<String, Object>> res = new ArrayList();
        res.add(recMap);
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(res));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.setShisetsuJohoListMap(new HashMap());
        target.shisetsuJohoPopShow("tablesorter_mst032");

        //実施結果Outを取得
        form = target.getMst032Form();
    }

    // shisetsuJohoPopShow_正常_初期処理（施設名表記情報ポップアップ）_29-2
    //
    // -------------------テスト条件--------------------------
    // 施設表示名情報リスト　≠ null
    // 配送シーケンス　≠ null
    // -----------------------------------------------------
    @Test
    public void shisetsuJohoPopShow_正常_初期処理施設名表記情報ポップアップ_29_2 () throws IllegalAccessException, InvocationTargetException {

        // 館内配送詳細リスト
        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = new ArrayList<>();
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");

        recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
        recMap.put("khDtlListHJushoKannaihaisoSeq", "khDtlListHJushoKannaihaisoSeq");
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        resultList.add(recMap);
        
        resMap.put("tablesorter_mst032", resultList);
        foucesDataList.put("tablesorter_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);
        when(pageCommonBean.getFoucesDataList()).thenReturn(foucesDataList);
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        List<Map<String, Object>> res = new ArrayList();
        res.add(recMap);
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(res));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        Map shisetsuJohoListMap = new HashMap();
        shisetsuJohoListMap.put("khDtlListHJushoKannaihaisoSeq", res);
        target.setShisetsuJohoListMap(shisetsuJohoListMap);
        target.shisetsuJohoPopShow("tablesorter_mst032");

        //実施結果Outを取得
        form = target.getMst032Form();
    }

    // shisetsuJohoPopShow_異常_初期処理（施設名表記情報ポップアップ）_29-3
    //
    // -------------------テスト条件--------------------------
    // 施設表示名情報リスト　≠ null
    // 配送シーケンス　= null
    // -----------------------------------------------------
    @Test
    public void shisetsuJohoPopShow_正常_初期処理施設名表記情報ポップアップ_29_3 () throws IllegalAccessException, InvocationTargetException {

        // 館内配送詳細リスト
        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = new ArrayList<>();
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");

        recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
        recMap.put("khDtlListHJushoKannaihaisoSeq", null);
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        resultList.add(recMap);
        
        resMap.put("tablesorter_mst032", resultList);
        foucesDataList.put("tablesorter_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);
        when(pageCommonBean.getFoucesDataList()).thenReturn(foucesDataList);
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        List<Map<String, Object>> res = new ArrayList();
        res.add(recMap);
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(res));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        Map shisetsuJohoListMap = new HashMap();
        shisetsuJohoListMap.put("khDtlListHJushoKannaihaisoSeq", res);
        target.setShisetsuJohoListMap(shisetsuJohoListMap);
        target.shisetsuJohoPopShow("tablesorter_mst032");

        //実施結果Outを取得
        form = target.getMst032Form();
    }

    // setShisetsuJoho_異常_.設定ボタン（施設名表記情報ポップアップ）_31-1
    //
    // -------------------テスト条件--------------------------
    // 施設表示名重複チェック正常
    // 取得件数 > 0
    // -----------------------------------------------------
    @Test
    public void setShisetsuJoho_正常_設定ボタン施設名表記情報ポップアップ_31_1 () throws IllegalAccessException, InvocationTargetException {

        // 館内配送詳細リスト
        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = new ArrayList<>();
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");

        recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
        recMap.put("khDtlListHJushoKannaihaisoSeq", null);
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        resultList.add(recMap);
        
        resMap.put("tablesorter_mst032", resultList);
        foucesDataList.put("tablesorter_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);
        when(pageCommonBean.getFoucesDataList()).thenReturn(foucesDataList);
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        List<Map<String, Object>> res = new ArrayList();
        res.add(recMap);
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(res));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> messageCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(),summaryCaptor_4.capture(),messageCaptor_5.capture());
        
        //テスト実行
        Mst032Form form = new Mst032Form();
        
        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_31_1(i));
        }
        ReportListDataModel dm = new ReportListDataModel(listJushoSelectedResult);
        form.setListShisetsuSelectable(dm);
        
        Map shisetsuJoho = new HashMap();
        shisetsuJoho.put("khDtlListHJisCd", "khDtlListHJisCd");
        shisetsuJoho.put("khDtlListHTekiyoKaishibi", "khDtlListHTekiyoKaishibi");
        form.setShisetsuJoho(shisetsuJoho);
        
        target.setMst032Form(form);
        target.setShisetsuJoho();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りにワーク.メッセージリストにメッセージID‘MSTE0051’の追加を行う。     ‘表示名’
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("MSTE0051", summaryCaptor_4.getValue());
    }
    
    // setShisetsuJoho_正常_.設定ボタン（施設名表記情報ポップアップ）_31-2
    //
    // -------------------テスト条件--------------------------
    // 施設表示名重複チェック正常
    // 取得件数 = 0
    // -----------------------------------------------------
    @Test
    public void setShisetsuJoho_正常_設定ボタン施設名表記情報ポップアップ_31_2 () throws IllegalAccessException, InvocationTargetException {

        // 館内配送詳細リスト
        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = new ArrayList<>();
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");

        recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
        recMap.put("khDtlListHJushoKannaihaisoSeq", null);
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        resultList.add(recMap);
        
        resMap.put("tablesorter_mst032", resultList);
        foucesDataList.put("tablesorter_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);
        when(pageCommonBean.getFoucesDataList()).thenReturn(foucesDataList);
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        List<Map<String, Object>> res = new ArrayList();

        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(res));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture());
        
        //テスト実行
        Mst032Form form = new Mst032Form();
        
        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_31_1(i));
        }
        ReportListDataModel dm = new ReportListDataModel(listJushoSelectedResult);
        form.setListShisetsuSelectable(dm);
        
        Map shisetsuJoho = new HashMap();
        shisetsuJoho.put("khDtlListHJisCd", "khDtlListHJisCd");
        shisetsuJoho.put("khDtlListHTekiyoKaishibi", "khDtlListHTekiyoKaishibi");
        shisetsuJoho.put("key", "UNIQUE_KEY");
        shisetsuJoho.put("khDtlListHJushoKannaihaisoSeq", "khDtlListHJushoKannaihaisoSeq");
        form.setShisetsuJoho(shisetsuJoho);

        form.setListKannaiSelectable(dm);

        target.setShisetsuJohoListMap(new HashMap());
        target.setMst032Form(form);
        target.setShisetsuJoho();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りに.メッセージリストにメッセージID‘MSTI0001’の追加を行う。
        assertEquals("INFO", levelCaptor_3.getValue());
        assertEquals("MSTI0001", summaryCaptor_4.getValue());
    }

    // setShisetsuJoho_異常_設定ボタン（施設名表記情報ポップアップ）_31-3
    //
    // -------------------テスト条件--------------------------
    // 施設表示名重複チェック異常
    // -----------------------------------------------------
    @Test
    public void setShisetsuJoho_正常_設定ボタン施設名表記情報ポップアップ_31_3 () throws IllegalAccessException, InvocationTargetException {

        // 館内配送詳細リスト
        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = new ArrayList<>();
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");

        recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
        recMap.put("khDtlListHJushoKannaihaisoSeq", null);
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        resultList.add(recMap);
        
        resMap.put("tablesorter_mst032", resultList);
        foucesDataList.put("tablesorter_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);
        when(pageCommonBean.getFoucesDataList()).thenReturn(foucesDataList);
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        List<Map<String, Object>> res = new ArrayList();

        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(res));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture());
        
        //テスト実行
        Mst032Form form = new Mst032Form();
        
        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_31_3(i));
        }
        ReportListDataModel dm = new ReportListDataModel(listJushoSelectedResult);
        form.setListShisetsuSelectable(dm);
        
        Map shisetsuJoho = new HashMap();
        shisetsuJoho.put("khDtlListHJisCd", "khDtlListHJisCd");
        shisetsuJoho.put("khDtlListHTekiyoKaishibi", "khDtlListHTekiyoKaishibi");
        shisetsuJoho.put("key", "UNIQUE_KEY");
        shisetsuJoho.put("khDtlListHJushoKannaihaisoSeq", "khDtlListHJushoKannaihaisoSeq");
        form.setShisetsuJoho(shisetsuJoho);

        form.setListKannaiSelectable(dm);

        target.setShisetsuJohoListMap(new HashMap());
        target.setMst032Form(form);
        target.setShisetsuJoho();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りに.メッセージリストにメッセージID‘MSTE0052’の追加を行う。
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("MSTE0052", summaryCaptor_4.getValue());
    }

    // setShisetsuJoho_異常_設定ボタン（施設名表記情報ポップアップ）_31-4
    //
    // -------------------テスト条件--------------------------
    // 施設表示名_変換住所異常
    // -----------------------------------------------------
    @Test
    public void setShisetsuJoho_正常_設定ボタン施設名表記情報ポップアップ_31_4 () throws IllegalAccessException, InvocationTargetException {

        // 館内配送詳細リスト
        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = new ArrayList<>();
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");

        recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
        recMap.put("khDtlListHJushoKannaihaisoSeq", null);
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        resultList.add(recMap);
        
        resMap.put("tablesorter_mst032", resultList);
        foucesDataList.put("tablesorter_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);
        when(pageCommonBean.getFoucesDataList()).thenReturn(foucesDataList);
        
        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        
        List<Map<String, Object>> res = new ArrayList();

        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(res));
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(), functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        // パラメータキャプチャー
        ArgumentCaptor<String> levelCaptor_3 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> summaryCaptor_4 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_5 = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> paramCaptor_6 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        doNothing().when(messagePropertyBean).message(levelCaptor_3.capture(), summaryCaptor_4.capture(), paramCaptor_5.capture(), paramCaptor_6.capture());
        
        //テスト実行
        Mst032Form form = new Mst032Form();
        
        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_31_4(i));
        }
        ReportListDataModel dm = new ReportListDataModel(listJushoSelectedResult);
        form.setListShisetsuSelectable(dm);
        
        Map shisetsuJoho = new HashMap();
        shisetsuJoho.put("khDtlListHJisCd", "khDtlListHJisCd");
        shisetsuJoho.put("khDtlListHTekiyoKaishibi", "khDtlListHTekiyoKaishibi");
        shisetsuJoho.put("key", "UNIQUE_KEY");
        shisetsuJoho.put("khDtlListHJushoKannaihaisoSeq", "khDtlListHJushoKannaihaisoSeq");
        form.setShisetsuJoho(shisetsuJoho);

        form.setListKannaiSelectable(dm);

        target.setShisetsuJohoListMap(new HashMap());
        target.setMst032Form(form);
        target.setShisetsuJoho();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りに.メッセージリストにメッセージID‘MSTI0001’の追加を行う。
        assertEquals("ERROR", levelCaptor_3.getValue());
        assertEquals("COME0002", summaryCaptor_4.getValue());
    }

    // henkoJohoSet_正常_変更情報反映_10-1
    //
    // -------------------テスト条件--------------------------
    // 変更情報反映正常
    // -----------------------------------------------------
    @Test
    public void henkoJohoSet_正常_変更情報反映_10_1 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        Map<String, Object> rec = new HashMap();
        // 変更漢字住所（都道府県）
        rec.put("henkoTodofukenMeiKanji", "henkoTodofukenMeiKanji");
        // 変更カナ住所（市区町村）
        rec.put("henkoShikuchosonMeiKanji", "henkoShikuchosonMeiKanji");
        // 変更カナ住所（都道府県）
        rec.put("henkoTodofukenMeiKana", "henkoTodofukenMeiKana");
        //  変更カナ住所（市区町村）
        rec.put("henkoShikuchosonMeiKana", "henkoShikuchosonMeiKana");

        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(rec));
        //変更情報反映正常

        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);

        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.henkoJohoSet();

        //実施結果Outを取得
        form = target.getMst032Form();

        // 実行時に渡すパラメータの検証
        assertEquals("mst032-search",functionCodeCaptor_2.getValue());
        //想定通りに変更情報反映
        assertEquals("henkoShikuchosonMeiKanji",form.getJshDtlHenkoKanjiJushoShikuchosonMei());
    }

    // kyuJushoControl_正常_旧住所フラグ選択_13-1
    //
    // -------------------テスト条件--------------------------
    // 旧住所区分 size > 0
    // -----------------------------------------------------
    @Test
    public void kyuJushoControl_正常_旧住所フラグ選択_13_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst032Form form = new Mst032Form();
        form.setKyjshDtlKyuJushoKubun(new String[]{"01"});
        target.setMst032Form(form);
        target.kyuJushoControl();

        //実施結果Outを取得
        form = target.getMst032Form();


        //想定通りに旧住所フラグ選択反映
        assertEquals(null,form.getKyjshDtlShinJisCd());
    }

    // kyuJushoControl_正常_旧住所フラグ選択_13-2
    //
    // -------------------テスト条件--------------------------
    // 旧住所区分 size = 0
    // -----------------------------------------------------
    @Test
    public void kyuJushoControl_正常_旧住所フラグ選択_13_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst032Form form = new Mst032Form();
        form.setKyjshDtlKyuJushoKubun(new String[]{});
        target.setMst032Form(form);
        target.kyuJushoControl();

        //実施結果Outを取得
        form = target.getMst032Form();


        //想定通りに旧住所フラグ選択反映
        assertEquals(null,form.getKyjshDtlShinJisCd());
    }

    // addRowEnterKey_正常_最終行入力エンターキーダウン_21-1
    //
    // -------------------テスト条件--------------------------
    // -----------------------------------------------------
    @Test
    public void addRowEnterKey_正常_最終行入力エンターキーダウン_21_1 () throws IllegalAccessException, InvocationTargetException {

        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = Mockito.mock(List.class);
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        when(resultList.size()).thenReturn(2);
        when(resultList.get(1)).thenReturn(recMap);
        when(resultList.get(2)).thenReturn(recMap);

        resMap.put("tableJusho_mst032", resultList);
        foucesDataList.put("tableJusho_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);
        
        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.addRowEnterKey("tableJusho_mst032",1);

        //実施結果Outを取得
        form = target.getMst032Form();
    }

    // addRowEnterKey_正常_最終行入力エンターキーダウン_21-2
    //
    // -------------------テスト条件--------------------------
    // id = tableRito_mst032
    // 選択リスト ≠ null
    // -----------------------------------------------------
    @Test
    public void addRowEnterKey_正常_最終行入力エンターキーダウン_21_2 () throws IllegalAccessException, InvocationTargetException {

        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = Mockito.mock(List.class);
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        when(resultList.size()).thenReturn(2);
        when(resultList.get(1)).thenReturn(recMap);
        when(resultList.get(2)).thenReturn(recMap);

        resMap.put("tableRito_mst032", resultList);
        foucesDataList.put("tableRito_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);

        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.addRowEnterKey("tableRito_mst032",1);

        //実施結果Outを取得
        form = target.getMst032Form();
    }

    // addRowEnterKey_正常_最終行入力エンターキーダウン_21-3
    //
    // -------------------テスト条件--------------------------
    // id = tableKannai_mst032
    // 選択リスト ≠ null
    // -----------------------------------------------------
    @Test
    public void addRowEnterKey_正常_最終行入力エンターキーダウン_21_3 () throws IllegalAccessException, InvocationTargetException {

        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = Mockito.mock(List.class);
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        when(resultList.size()).thenReturn(2);
        when(resultList.get(1)).thenReturn(recMap);
        when(resultList.get(2)).thenReturn(recMap);

        resMap.put("tableKannai_mst032", resultList);
        foucesDataList.put("tableKannai_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);

        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.addRowEnterKey("tableKannai_mst032",1);

        //実施結果Outを取得
        form = target.getMst032Form();
    }

    // addRowEnterKey_正常_最終行入力エンターキーダウン_21-4
    //
    // -------------------テスト条件--------------------------
    // id = tableJusho_mst032
    // 選択リスト = null
    // -----------------------------------------------------
    @Test
    public void addRowEnterKey_正常_最終行入力エンターキーダウン_21_4 ()  throws IllegalAccessException, InvocationTargetException {

        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = Mockito.mock(List.class);
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();

        
        when(resultList.size()).thenReturn(2);
        when(resultList.get(1)).thenReturn(recMap);
        when(resultList.get(2)).thenReturn(recMap);
        when(resultList.isEmpty()).thenReturn(true);

        resMap.put("tableJusho_mst032", resultList);
        foucesDataList.put("tableJusho_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);
        
        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.addRowEnterKey("tableJusho_mst032",1);

        //実施結果Outを取得
        form = target.getMst032Form();
    }

    // addRowEnterKey_正常_最終行入力エンターキーダウン_21-5
    //
    // -------------------テスト条件--------------------------
    // indexRow = 0
    // -----------------------------------------------------
    @Test
    public void addRowEnterKey_正常_最終行入力エンターキーダウン_21_5 ()  throws IllegalAccessException, InvocationTargetException {

        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = Mockito.mock(List.class);
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();

        
        when(resultList.size()).thenReturn(2);
        when(resultList.get(1)).thenReturn(recMap);
        when(resultList.isEmpty()).thenReturn(true);

        resMap.put("tableJusho_mst032", resultList);
        foucesDataList.put("tableJusho_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);
        
        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.addRowEnterKey("tableJusho_mst032",0);

        //実施結果Outを取得
        form = target.getMst032Form();
    }
    
    // henkanGamenHiden_正常_閉じるボタン変換情報ポップアップ_26-1
    //
    // -------------------テスト条件--------------------------
    // 画面項目修正判定 = 1
    // -----------------------------------------------------
    @Test
    public void henkanGamenHiden_正常_閉じるボタン変換情報ポップアップ_26_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setHenkanFlg("1");
        target.setMst032Form(form);
        target.henkanGamenHiden();

        //実施結果Outを取得
        form = target.getMst032Form();
    }

    // henkanGamenHiden_正常_閉じるボタン変換情報ポップアップ_26-2
    //
    // -------------------テスト条件--------------------------
    // 画面項目修正判定 = 2
    // -----------------------------------------------------
    @Test
    public void henkanGamenHiden_正常_閉じるボタン変換情報ポップアップ_26_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setHenkanFlg("2");
        target.setMst032Form(form);
        target.henkanGamenHiden();

        //実施結果Outを取得
        form = target.getMst032Form();
    }

    // henkanDataFukugen_正常_変換情報閉じる場合、データ復元_26-3
    //
    // -------------------テスト条件--------------------------
    // 変換情報閉じる
    // -----------------------------------------------------
    @Test
    public void henkanDataFukugen_正常_変換情報閉じる場合データ復元_26_3 () throws IllegalAccessException, InvocationTargetException {

        // パラメータキャプチャー
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);
        // Mockitoオブジェクトの予想return値設定
        List<Map<String, Object>> res = new ArrayList();
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(res));
        //変換情報閉じる
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();
        
        Map<String, Object> henkanJoho = new HashMap();
        Map<String, Object> henkanJohoListMap = new HashMap();
        henkanJoho.put("hnknDtlShimukeChiCd", "hnknDtlShimukeChiCd");
        henkanJoho.put("key", "key");
        form.setHenkanJoho(henkanJoho);
        List<Map<String, Object>> resultListKannai = new ArrayList<>();
        henkanJoho.put("jshDtlListJisCdjshDtlListHShimukeChiCd", resultListKannai);
        henkanJohoListMap.put("hnknDtlShimukeChiCd", resultListKannai);
        target.setHenkanJohoListMap(henkanJohoListMap);
        target.setMst032Form(form);
        target.henkanDataFukugen();

        //実施結果Outを取得
        form = target.getMst032Form();
    }
    
   // shisetsuGamenHiden_正常_閉じるボタン_30-1
    //
    // -------------------テスト条件--------------------------
    // 画面項目修正判定 = 1
    // -----------------------------------------------------
    @Test
    public void shisetsuGamenHiden_正常_閉じるボタン_30_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setShisetsuFlg("1");
        target.setMst032Form(form);
        target.shisetsuGamenHiden();

        //実施結果Outを取得
        form = target.getMst032Form();
    }

    // shisetsuGamenHiden_正常_閉じるボタン_30-2
    //
    // -------------------テスト条件--------------------------
    // 画面項目修正判定 = 2
    // -----------------------------------------------------
    @Test
    public void shisetsuGamenHiden_正常_閉じるボタン_30_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setShisetsuFlg("2");
        target.setMst032Form(form);
        target.shisetsuGamenHiden();

        //実施結果Outを取得
        form = target.getMst032Form();

    }
    
    // shisetsuDataFukugen_正常_施設名表記情報閉じる場合_30-3
    //
    // -------------------テスト条件--------------------------
    // 施設名表記情報閉じる正常
    // -----------------------------------------------------
    @Test
    public void shisetsuDataFukugen_正常_施設名表記情報閉じる場合_30_3 ()  throws IllegalAccessException, InvocationTargetException {
        
        //テスト実行
        Mst032Form form = new Mst032Form();
        
        Map<String, Object> henkanJoho = new HashMap();
        Map<String, Object> henkanJohoListMap = new HashMap();
        henkanJoho.put("khDtlListHJushoKannaihaisoSeq", "khDtlListHJushoKannaihaisoSeq");
        henkanJoho.put("key", "key");
        form.setShisetsuJoho(henkanJoho);
        List<Map<String, Object>> resultListKannai = new ArrayList<>();
        henkanJohoListMap.put("khDtlListHJushoKannaihaisoSeq", resultListKannai);
        target.setShisetsuJohoListMap(henkanJohoListMap);
        target.setMst032Form(form);
        target.shisetsuDataFukugen();

        //実施結果Outを取得
        form = target.getMst032Form();
    }

    // menuClick_正常_補充ケース_14-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_14_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.menuClick("","");

        //実施結果Outを取得
        form = target.getMst032Form();

    }

    // menuClick_正常_補充ケース_14-2
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void menuClick_正常_補充ケース_14_2_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(1);

        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.menuClick("","");

        //実施結果Outを取得
        form = target.getMst032Form();

    }    
    
    // breadClumClick_正常_補充ケース_14-3
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_14_3 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.breadClumClick("",0);

        //実施結果Outを取得
        form = target.getMst032Form();

    }

    // breadClumClick_正常_補充ケース_14-3_1
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void breadClumClick_正常_補充ケース_14_3_1 () throws IllegalAccessException, InvocationTargetException {

        doThrow(IllegalAccessException.class).when(breadBean).pop(0);        
        
        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.breadClumClick("",0);

        //実施結果Outを取得
        form = target.getMst032Form();

    }    
    
    // logoutClick_正常_補充ケース_14-4
    //
    // -------------------テスト条件--------------------------
    // 特になし
    // -----------------------------------------------------
    @Test
    public void logoutClick_正常_補充ケース_14_4 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.logoutClick();

        //実施結果Outを取得
        form = target.getMst032Form();
    }

    // addRow_正常_行追加_22-1
    //
    // -------------------テスト条件--------------------------
    // id = tableJusho_mst032
    // 選択リスト ≠ null
    // -----------------------------------------------------
    @Test
    public void addRow_正常_行追加_22_1 () throws IllegalAccessException, InvocationTargetException {

        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = Mockito.mock(List.class);
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        when(resultList.size()).thenReturn(2);
        when(resultList.get(1)).thenReturn(recMap);
        when(resultList.get(2)).thenReturn(recMap);

        resMap.put("tableJusho_mst032", resultList);
        foucesDataList.put("tableJusho_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);
        
        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.addRow("tableJusho_mst032",true);

        //実施結果Outを取得
        form = target.getMst032Form();
    }

    // addRow_正常_行追加_22-2
    //
    // -------------------テスト条件--------------------------
    // id = tableRito_mst032
    // 選択リスト ≠ null
    // -----------------------------------------------------
    @Test
    public void addRow_正常_行追加_22_2 () throws IllegalAccessException, InvocationTargetException {

        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = Mockito.mock(List.class);
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        when(resultList.size()).thenReturn(2);
        when(resultList.get(1)).thenReturn(recMap);
        when(resultList.get(2)).thenReturn(recMap);

        resMap.put("tableRito_mst032", resultList);
        foucesDataList.put("tableRito_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);

        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.addRow("tableRito_mst032",true);

        //実施結果Outを取得
        form = target.getMst032Form();
    }

    // addRow_正常_行追加_22-3
    //
    // -------------------テスト条件--------------------------
    // id = tableKannai_mst032
    // 選択リスト ≠ null
    // -----------------------------------------------------
    @Test
    public void addRow_正常_行追加_22_3 () throws IllegalAccessException, InvocationTargetException {

        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = Mockito.mock(List.class);
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        when(resultList.size()).thenReturn(2);
        when(resultList.get(1)).thenReturn(recMap);
        when(resultList.get(2)).thenReturn(recMap);

        resMap.put("tableKannai_mst032", resultList);
        foucesDataList.put("tableKannai_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);

        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.addRow("tableKannai_mst032",true);

        //実施結果Outを取得
        form = target.getMst032Form();
    }

    // addRow_正常_行追加_22-4
    //
    // -------------------テスト条件--------------------------
    // id = tableJusho_mst032
    // 選択リスト = null
    // -----------------------------------------------------
    @Test
    public void addRow_正常_行追加_22_4 ()  throws IllegalAccessException, InvocationTargetException {

        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = Mockito.mock(List.class);
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();

        
        when(resultList.size()).thenReturn(2);
        when(resultList.get(1)).thenReturn(recMap);
        when(resultList.get(2)).thenReturn(recMap);
        when(resultList.isEmpty()).thenReturn(true);

        resMap.put("tableJusho_mst032", resultList);
        foucesDataList.put("tableJusho_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);
        
        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.addRow("tableJusho_mst032",false);

        //実施結果Outを取得
        form = target.getMst032Form();
    }

    // addRow_正常_行追加_22-5
    //
    // -------------------テスト条件--------------------------
    // indexRow = 0
    // -----------------------------------------------------
    @Test
    public void addRow_正常_行追加_22_5 ()  throws IllegalAccessException, InvocationTargetException {

        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = Mockito.mock(List.class);
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();

        
        when(resultList.size()).thenReturn(2);
        when(resultList.get(1)).thenReturn(recMap);
        when(resultList.get(0)).thenReturn(recMap);
        when(resultList.isEmpty()).thenReturn(false);

        resMap.put("tableJusho_mst032", resultList);
        foucesDataList.put("tableJusho_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);
        
        //テスト実行
        Mst032Form form = new Mst032Form();
        form.setConJisCdTaihi("");
        target.setMst032Form(form);
        target.addRow("tableJusho_mst032",false);

        //実施結果Outを取得
        form = target.getMst032Form();
    }

    // addRowPop_正常_ポップアップ画面行追加_33-1
    //
    // -------------------テスト条件--------------------------
    // id = tableHenkan_mst032
    // -----------------------------------------------------
    @Test
    public void addRowPop_正常_ポップアップ画面行追加_33_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.addRowPop("tableHenkan_mst032",true);

        //実施結果Outを取得
        form = target.getMst032Form();

    }
    
    // addRowPop_正常_ポップアップ画面行追加_33-2
    //
    // -------------------テスト条件--------------------------
    // id = tableHenkan_mst033
    // -----------------------------------------------------
    @Test
    public void addRowPop_正常_ポップアップ画面行追加_33_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.addRowPop("tableHenkan_mst033",true);

        //実施結果Outを取得
        form = target.getMst032Form();

    }

    // copyRows_正常_テーブルにデータをコピー_34-1
    //
    // -------------------テスト条件--------------------------
    // id = tableJusho_mst032
    // 選択リスト ≠ null
    // -----------------------------------------------------
    @Test
    public void copyRows_正常_テーブルにデータをコピー_34_1 () throws IllegalAccessException, InvocationTargetException {

        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = Mockito.mock(List.class);
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        when(resultList.size()).thenReturn(2);
        when(resultList.get(1)).thenReturn(recMap);
        when(resultList.get(2)).thenReturn(recMap);

        resMap.put("tableJusho_mst032", resultList);
        foucesDataList.put("tableJusho_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);
        
        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.copyRows("tableJusho_mst032");

        //実施結果Outを取得
        form = target.getMst032Form();
    }

    // copyRows_正常_テーブルにデータをコピー_34-2
    //
    // -------------------テスト条件--------------------------
    // id = tableRito_mst032
    // 選択リスト ≠ null
    // -----------------------------------------------------
    @Test
    public void copyRows_正常_テーブルにデータをコピー_34_2 () throws IllegalAccessException, InvocationTargetException {

        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = Mockito.mock(List.class);
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        when(resultList.size()).thenReturn(2);
        when(resultList.get(1)).thenReturn(recMap);
        when(resultList.get(2)).thenReturn(recMap);

        resMap.put("tableRito_mst032", resultList);
        foucesDataList.put("tableRito_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);

        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.copyRows("tableRito_mst032");

        //実施結果Outを取得
        form = target.getMst032Form();
    }

    // copyRows_正常_テーブルにデータをコピー_34-3
    //
    // -------------------テスト条件--------------------------
    // id = tableKannai_mst032
    // 選択リスト ≠ null
    // -----------------------------------------------------
    @Test
    public void copyRows_正常_テーブルにデータをコピー_34_3 () throws IllegalAccessException, InvocationTargetException {

        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = Mockito.mock(List.class);
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        when(resultList.size()).thenReturn(2);
        when(resultList.get(1)).thenReturn(recMap);
        when(resultList.get(2)).thenReturn(recMap);

        resMap.put("tableKannai_mst032", resultList);
        foucesDataList.put("tableKannai_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);

        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.copyRows("tableKannai_mst032");

        //実施結果Outを取得
        form = target.getMst032Form();
    }

    // copyRows_正常_テーブルにデータをコピー_34-4
    //
    // -------------------テスト条件--------------------------
    // id = tableHenkan_mst032
    // 選択リスト ≠ null
    // -----------------------------------------------------
    @Test
    public void copyRows_正常_テーブルにデータをコピー_34_4 () throws IllegalAccessException, InvocationTargetException {

        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = Mockito.mock(List.class);
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        when(resultList.size()).thenReturn(2);
        when(resultList.get(1)).thenReturn(recMap);
        when(resultList.get(2)).thenReturn(recMap);

        resMap.put("tableHenkan_mst032", resultList);
        foucesDataList.put("tableHenkan_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);
        
        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.copyRows("tableHenkan_mst032");

        //実施結果Outを取得
        form = target.getMst032Form();
    }

    // copyRows_正常_テーブルにデータをコピー_34-5
    //
    // -------------------テスト条件--------------------------
    // id = tableshisetsu_mst032
    // 選択リスト ≠ null
    // -----------------------------------------------------
    @Test
    public void copyRows_正常_テーブルにデータをコピー_34_5 () throws IllegalAccessException, InvocationTargetException {

        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = Mockito.mock(List.class);
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        when(resultList.size()).thenReturn(2);
        when(resultList.get(1)).thenReturn(recMap);
        when(resultList.get(2)).thenReturn(recMap);

        resMap.put("tableshisetsu_mst032", resultList);
        foucesDataList.put("tableshisetsu_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);
        
        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.copyRows("tableshisetsu_mst032");

        //実施結果Outを取得
        form = target.getMst032Form();
    }
    
    // delRows_正常_業務削除処理_35-1
    //
    // -------------------テスト条件--------------------------
    // id = tableJusho_mst032
    // 選択リスト ≠ null
    // -----------------------------------------------------
    @Test
    public void delRows_正常_業務削除処理_35_1 () throws IllegalAccessException, InvocationTargetException {

        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = Mockito.mock(List.class);
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        when(resultList.size()).thenReturn(2);
        when(resultList.get(1)).thenReturn(recMap);
        when(resultList.get(2)).thenReturn(recMap);

        resMap.put("tableJusho_mst032", resultList);
        foucesDataList.put("tableJusho_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);
        
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);        
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(0);
        //変換情報閉じる
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        
        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.delRows("tableJusho_mst032",resultList);

        //実施結果Outを取得
        form = target.getMst032Form();
    }

    // delRows_正常_業務削除処理_35-2
    //
    // -------------------テスト条件--------------------------
    // id = tableRito_mst032
    // 選択リスト ≠ null
    // -----------------------------------------------------
    @Test
    public void delRows_正常_業務削除処理_35_2 () throws IllegalAccessException, InvocationTargetException {

        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = Mockito.mock(List.class);
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        when(resultList.size()).thenReturn(2);
        when(resultList.get(1)).thenReturn(recMap);
        when(resultList.get(2)).thenReturn(recMap);

        resMap.put("tableRito_mst032", resultList);
        foucesDataList.put("tableRito_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);        
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(0);
        //変換情報閉じる
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.delRows("tableRito_mst032",resultList);

        //実施結果Outを取得
        form = target.getMst032Form();
    }

    // delRows_正常_業務削除処理_35-3
    //
    // -------------------テスト条件--------------------------
    // id = tableKannai_mst032
    // 選択リスト ≠ null
    // -----------------------------------------------------
    @Test
    public void delRows_正常_業務削除処理_35_3 ()throws IllegalAccessException, InvocationTargetException {

        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = Mockito.mock(List.class);
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        when(resultList.size()).thenReturn(2);
        when(resultList.get(1)).thenReturn(recMap);
        when(resultList.get(2)).thenReturn(recMap);

        resMap.put("tableKannai_mst032", resultList);
        foucesDataList.put("tableKannai_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);        
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(0);
        //変換情報閉じる
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        //テスト実行
        Mst032Form form = new Mst032Form();
        target.setMst032Form(form);
        target.delRows("tableKannai_mst032",resultList);

        //実施結果Outを取得
        form = target.getMst032Form();
    }

    // delRows_正常_業務削除処理_35-4
    //
    // -------------------テスト条件--------------------------
    // id = tableHenkan_mst032
    // 選択リスト ≠ null
    // -----------------------------------------------------
    @Test
    public void delRows_正常_業務削除処理_35_4 () throws IllegalAccessException, InvocationTargetException {

        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = new ArrayList();
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        resultList.add(recMap);

        resMap.put("tableHenkan_mst032", resultList);
        foucesDataList.put("tableHenkan_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);        
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(0);
        //変換情報閉じる
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        //テスト実行
        Mst032Form form = new Mst032Form();
        
        Map map = new HashMap();
        map.put("jshDtlListHShimukeChiCd", "00");
        map.put("hnknDtlShimukeChiCd", "hnknDtlShimukeChiCd");
        map.put("key", "key");
        map.put("UNIQUE_KEY", "key");
        form.setHenkanJoho(map);
        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_27_2(i));
        }
        ReportListDataModel dm = new ReportListDataModel(listJushoSelectedResult);
        form.setListJushoSelectable(dm);
        target.setHenkanJohoListMap(new HashMap());
        target.setMst032Form(form);
        target.delRows("tableHenkan_mst032",resultList);

        //実施結果Outを取得
        form = target.getMst032Form();
    }

    // delRows_正常_業務削除処理_35-5
    //
    // -------------------テスト条件--------------------------
    // id = tableshisetsu_mst032
    // 選択リスト ≠ null
    // -----------------------------------------------------
    @Test
    public void delRows_正常_業務削除処理_35_5 () throws IllegalAccessException, InvocationTargetException {

        Map<String, List<Map<String, Object>>> resMap = new HashMap();
        List<Map<String, Object>> resultList = new ArrayList();
         Map<String, Object> foucesDataList = new HashMap();
        Map recMap = new HashMap();
        // 住所JISマスタの更新カントーより、新規更新処理判定
        recMap.put("kshnDtlJisJushoCounter", "kshnDtlJisJushoCounter");
        // 漢字住所（市区町村）
        recMap.put("khDtlListBiko", "khDtlListBiko");
        recMap.put("jshDtlKanjiJushoShikuchosonMei", "JshDtlKanjiJushoShikuchosonMei");
        // カナ住所（市区町村）
        recMap.put("jshDtlKanaJushoShikuchosonMei", "JshDtlKanaJushoShikuchosonMei");
        // 英語住所（都道府県）
        recMap.put("jshDtlEigoJushoTodofukenMei", "JshDtlEigoJushoTodofukenMei");
        // 英語住所（市区町村）
        recMap.put("jshDtlEigoJushoShikuchosonMei", "JshDtlEigoJushoShikuchosonMei");
        // 離島有無
        recMap.put("jshDtlRitoUmuFlg", "JshDtlRitoUmuFlg");
        // HTコメント(100バイト)
        recMap.put("jshDtlHtComment1", "JshDtlHtComment1");
        // HTコメント(200バイト)
        recMap.put("jshDtlHtComment2", "JshDtlHtComment2");
        // 旧住所区分
        recMap.put("kyuJushoFlg", "KyuJushoFlg");
        recMap.put("shiyoFukaFlg", "ShiyoFukaFlg");
        // 新JISコード
        recMap.put("kyjshDtlShinJisCd", "kyjshDtlShinJisCd");
        
        recMap.put("jshDtlListJisCd", "jshDtlListJisCd");
        recMap.put("jshDtlListHShimukeChiCd", "jshDtlListHShimukeChiCd");
        recMap.put("jshDtlListJisJusho", "jshDtlListJisJusho");
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        
        resultList.add(recMap);

        resMap.put("tableshisetsu_mst032", resultList);
        foucesDataList.put("tableshisetsu_mst032", recMap);
        when(pageCommonBean.getDatasLists()).thenReturn(resMap);
        ArgumentCaptor<Map> paramsCaptor_1 = ArgumentCaptor.forClass(Map.class);
        ArgumentCaptor<String> functionCodeCaptor_2 = ArgumentCaptor.forClass(String.class);        
        ServiceInterfaceBean serviceInterfaceBean = new ServiceInterfaceBean();
        serviceInterfaceBean.setStatusCode(0);
        //変換情報閉じる
        when(pageCommonBean.getDBInfo(paramsCaptor_1.capture(),functionCodeCaptor_2.capture())).thenReturn(serviceInterfaceBean);
        //テスト実行
        Mst032Form form = new Mst032Form();
        
        Map map = new HashMap();
        map.put("jshDtlListHShimukeChiCd", "00");
        map.put("khDtlListHJushoKannaihaisoSeq", "khDtlListHJushoKannaihaisoSeq");
        map.put("key", "key");
        map.put("UNIQUE_KEY", "key");
        form.setShisetsuJoho(map);
        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_27_2(i));
        }
        ReportListDataModel dm = new ReportListDataModel(listJushoSelectedResult);
        form.setListKannaiSelectable(dm);
        target.setShisetsuJohoListMap(new HashMap());
        
        target.setMst032Form(form);
        target.delRows("tableshisetsu_mst032",resultList);

        //実施結果Outを取得
        form = target.getMst032Form();
    }

    // setHenkoFlg_正常_POP情報変更フラグ_36-1
    //
    // -------------------テスト条件--------------------------
    // flg = 1
    // -----------------------------------------------------
    @Test
    public void setHenkoFlg_正常_POP情報変更フラグ_36_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst032Form form = new Mst032Form();
        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_27_2(i));
        }
        ReportListDataModel dm = new ReportListDataModel(listJushoSelectedResult);
        form.setListShisetsuSelectable(dm);
        target.setMst032Form(form);
        target.setHenkoFlg("1","1",1);

        
        //実施結果Outを取得
        form = target.getMst032Form();

    }

    // setHenkoFlg_正常_POP情報変更フラグ_36-2
    //
    // -------------------テスト条件--------------------------
    // flg = 0
    // -----------------------------------------------------
    @Test
    public void setHenkoFlg_正常_POP情報変更フラグ_36_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst032Form form = new Mst032Form();
        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_27_2(i));
        }
        ReportListDataModel dm = new ReportListDataModel(listJushoSelectedResult);
        form.setListHenkanSelectable(dm);
        target.setMst032Form(form);
        target.setHenkoFlg("0","0",1);
        
        //実施結果Outを取得
        form = target.getMst032Form();

    }

    // setListCodeName_正常_AUTOCOMPLETE選択時コードと名称の設定処理_37-1
    //
    // -------------------テスト条件--------------------------
    // option = null
    // -----------------------------------------------------
    @Test
    public void setListCodeName_正常_AUTOCOMPLETE選択時コードと名称の設定処理_37_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst032Form form = new Mst032Form();
        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_27_2(i));
        }
        ReportListDataModel dm = new ReportListDataModel(listJushoSelectedResult);
        form.setListJushoSelectable(dm);
        target.setMst032Form(form);
        target.setListCodeName(0,null,"123","456");

        //実施結果Outを取得
        form = target.getMst032Form();

    }

    // setListCodeName_正常_AUTOCOMPLETE選択時コードと名称の設定処理_37-2
    //
    // -------------------テスト条件--------------------------
    // option not null
    // -----------------------------------------------------
    @Test
    public void setListCodeName_正常_AUTOCOMPLETE選択時コードと名称の設定処理_37_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst032Form form = new Mst032Form();
        List<Map<String, Object>> listJushoSelectedResult = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            listJushoSelectedResult.add(createJushoMapFor_27_2(i));
        }
        ReportListDataModel dm = new ReportListDataModel(listJushoSelectedResult);
        form.setListJushoSelectable(dm);
        target.setMst032Form(form);
        target.setListCodeName(0,new  AutoCompOptionBean(),"234","678");

        //実施結果Outを取得
        form = target.getMst032Form();

    }

    // tekiyoMeiSet_正常_適用名退避_38-1
    //
    // -------------------テスト条件--------------------------
    // ConTekiyoMei not null
    // -----------------------------------------------------
    @Test
    public void tekiyoMeiSet_正常_適用名退避_38_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst032Form form = new Mst032Form();
        form.setConTekiyoMei("345");
        target.setMst032Form(form);
        target.tekiyoMeiSet();

        //実施結果Outを取得
        form = target.getMst032Form();

        //想定通りに退避
        assertEquals("345",form.getConTekiyoMeiTaihi());
    }

    // tekiyoShuryoSet_正常_適用終了退避_39-1
    //
    // -------------------テスト条件--------------------------
    // ConTekiyoShuryo = null
    // -----------------------------------------------------
    @Test
    public void tekiyoShuryoSet_正常_適用終了退避_39_1 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst032Form form = new Mst032Form();
        form.setConTekiyoShuryo(new String[]{"345"});
        target.setMst032Form(form);
        target.tekiyoShuryoSet();

        //実施結果Outを取得
        form = target.getMst032Form();

    }

    // tekiyoShuryoSet_正常_適用終了退避_39-2
    //
    // -------------------テスト条件--------------------------
    // ConTekiyoShuryo not null
    // -----------------------------------------------------
    @Test
    public void tekiyoShuryoSet_正常_適用終了退避_39_2 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst032Form form = new Mst032Form();
        form.setConTekiyoShuryo(null);
        target.setMst032Form(form);
        target.tekiyoShuryoSet();

        //実施結果Outを取得
        form = target.getMst032Form();

    }
    
    // tekiyoShuryoSet_正常_適用終了退避_39-3
    //
    // -------------------テスト条件--------------------------
    // ConTekiyoShuryo not null
    // -----------------------------------------------------
    @Test
    public void tekiyoShuryoSet_正常_適用終了退避_39_3 () throws IllegalAccessException, InvocationTargetException {

        //テスト実行
        Mst032Form form = new Mst032Form();
        form.setConTekiyoShuryo(new String[]{});
        target.setMst032Form(form);
        target.tekiyoShuryoSet();

        //実施結果Outを取得
        form = target.getMst032Form();

    }
    
    private Map<String, String> createJushoMapFor_2_1(int i) {
        Map recMap = new HashMap();
        // 仕向地名コード
        recMap.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        recMap.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 管轄営業所コード
        recMap.put("jshDtlListEigyoshoCd", "jshDtlListEigyoshoCd");
        return recMap;
    }
    
    private Map<String, String> createRitoMapFor_2_1(int i) {
        Map recMap = new HashMap();
        recMap.put("rtDtlListShimaMei", "rtDtlListShimaMei");
        recMap.put("rtDtlListJisJusho", "rtDtlListJisJusho");
        return recMap;
    }
    
    private Map<String, String> createKannaiMapFor_2_1(int i) {
        Map recMap = new HashMap();
        recMap.put("khDtlListShisetsuMei", "khDtlListShisetsuMei");
        recMap.put("khDtlListJisJusho", "khDtlListJisJusho");
        return recMap;
    }
    
    private Map<String, Object> createJushoMapFor_24_1(int i) {
        Map recMap = new HashMap();
        // 仕向地コード(下2桁)
        recMap.put("jshDtlListShimukeChiCd", "0" + i );
        // 町字
        recMap.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字
        recMap.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        recMap.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 町字
        recMap.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        recMap.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        recMap.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        recMap.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        recMap.put("jshDtlListEigyoshoCd", "jshDtlListEigyoshoCd");
        
        if (i == 0) {
            recMap.put("jshDtlListKyuEdiJushoFlg", "true");
            recMap.put("jshDtlListShinEdiJushoFlg", "true");
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
            recMap.put("jshDtlListHShimukeChiCd", "00");
        }
            recMap.put("jshDtlListHShimukeChiCd", "02");
        return recMap;
    }

    private Map<String, Object> createJushoMapFor_24_4(int i) {
        Map recMap = new HashMap();
        // 仕向地コード(下2桁)
        recMap.put("jshDtlListShimukeChiCd", "0" + i );
        // 町字
        recMap.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字
        recMap.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        recMap.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 町字
        recMap.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        recMap.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        recMap.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        recMap.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        recMap.put("jshDtlListEigyoshoCd", "jshDtlListEigyoshoCd");
        
        if (i == 0) {
            recMap.put("jshDtlListKyuEdiJushoFlg", "false");
            recMap.put("jshDtlListShinEdiJushoFlg", "false");
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
            recMap.put("jshDtlListHShimukeChiCd", "00");
        }
            recMap.put("jshDtlListHShimukeChiCd", "02");
        return recMap;
    }

    private Map<String, Object> createJushoMapFor_24_18(int i) {
        Map recMap = new HashMap();
        if (i == 0) {
            // 仕向地コード(下2桁)
            recMap.put("jshDtlListShimukeChiCd", "");
            // 町字
            recMap.put("jshDtlListChoaza", "");
            // 町字カナ
            recMap.put("jshDtlListChoazaKana", "");
            // 仕向地名
            recMap.put("jshDtlListShimukeChiMeiCd", "");
            // 空港コード
            recMap.put("jshDtlListKukoCd", "");
            // 集配地区コード
            recMap.put("jshDtlListShuhaiChikuCd", "");
            // 管轄営業所コード
            recMap.put("jshDtlListEigyoshoCd", "");
        } else if (i == 1) {
            // 仕向地コード(下2桁)
            recMap.put("jshDtlListShimukeChiCd", "99");
            // 町字
            recMap.put("jshDtlListChoaza", "40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
            // 町字カナ
            recMap.put("jshDtlListChoazaKana", "40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
            // 仕向地名
            recMap.put("jshDtlListShimukeChiMeiCd", "");
            // 空港コード
            recMap.put("jshDtlListKukoCd", "");
            // 集配地区コード
            recMap.put("jshDtlListShuhaiChikuCd", "");
            // 管轄営業所コード
            recMap.put("jshDtlListEigyoshoCd", "");
        } else if (i == 2){
            // 仕向地コード(下2桁)
            recMap.put("jshDtlListShimukeChiCd", "3xxx");
            // 町字
            recMap.put("jshDtlListChoaza", "");
            // 町字カナ
            recMap.put("jshDtlListChoazaKana", "");
            // 仕向地名
            recMap.put("jshDtlListShimukeChiMeiCd", "");
            // 空港コード
            recMap.put("jshDtlListKukoCd", "");
            // 集配地区コード
            recMap.put("jshDtlListShuhaiChikuCd", "");
            // 管轄営業所コード
            recMap.put("jshDtlListEigyoshoCd", "");
        } else {
            // 仕向地コード(下2桁)
            recMap.put("jshDtlListShimukeChiCd", "3xxx");
            // 町字
            recMap.put("jshDtlListChoaza", "");
            // 町字カナ
            recMap.put("jshDtlListChoazaKana", "");
            // 仕向地名
            recMap.put("jshDtlListShimukeChiMeiCd", "");
            // 空港コード
            recMap.put("jshDtlListKukoCd", "");
            // 集配地区コード
            recMap.put("jshDtlListShuhaiChikuCd", "");
            // 管轄営業所コード
            recMap.put("jshDtlListEigyoshoCd", "");
        }

        
        if (i == 0) {
            recMap.put("jshDtlListKyuEdiJushoFlg", "true");
            recMap.put("jshDtlListShinEdiJushoFlg", "true");
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
            recMap.put("jshDtlListHShimukeChiCd", "00");
        }
            recMap.put("jshDtlListHShimukeChiCd", "02");
        return recMap;
    }

    private Map<String, Object> createJushoMapFor_24_19(int i) {
        Map recMap = new HashMap();
        if (i == 0) {
            // 仕向地コード(下2桁)
            recMap.put("jshDtlListShimukeChiCd", "99");
            // 町字
            recMap.put("jshDtlListChoaza", "40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
            // 町字カナ
            recMap.put("jshDtlListChoazaKana", "40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
            // 仕向地名
            recMap.put("jshDtlListShimukeChiMeiCd", "");
            // 空港コード
            recMap.put("jshDtlListKukoCd", "");
            // 集配地区コード
            recMap.put("jshDtlListShuhaiChikuCd", "");
            // 管轄営業所コード
            recMap.put("jshDtlListEigyoshoCd", "");
        }

        if (i == 0) {
            recMap.put("jshDtlListKyuEdiJushoFlg", "true");
            recMap.put("jshDtlListShinEdiJushoFlg", "true");
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
            recMap.put("jshDtlListHShimukeChiCd", "00");
        }
            recMap.put("jshDtlListHShimukeChiCd", "02");
        return recMap;
    }

    private Map<String, Object> createJushoMapFor_24_20(int i) {
        Map recMap = new HashMap();
        if (i == 0){
            // 仕向地コード(下2桁)
            recMap.put("jshDtlListShimukeChiCd", "3xxx");
            // 町字
            recMap.put("jshDtlListChoaza", "");
            // 町字カナ
            recMap.put("jshDtlListChoazaKana", "");
            // 仕向地名
            recMap.put("jshDtlListShimukeChiMeiCd", "");
            // 空港コード
            recMap.put("jshDtlListKukoCd", "");
            // 集配地区コード
            recMap.put("jshDtlListShuhaiChikuCd", "");
            // 管轄営業所コード
            recMap.put("jshDtlListEigyoshoCd", "");
        } else {
            // 仕向地コード(下2桁)
            recMap.put("jshDtlListShimukeChiCd", "3xxx");
            // 町字
            recMap.put("jshDtlListChoaza", "");
            // 町字カナ
            recMap.put("jshDtlListChoazaKana", "");
            // 仕向地名
            recMap.put("jshDtlListShimukeChiMeiCd", "");
            // 空港コード
            recMap.put("jshDtlListKukoCd", "");
            // 集配地区コード
            recMap.put("jshDtlListShuhaiChikuCd", "");
            // 管轄営業所コード
            recMap.put("jshDtlListEigyoshoCd", "");
        }

        if (i == 0) {
            recMap.put("jshDtlListKyuEdiJushoFlg", "true");
            recMap.put("jshDtlListShinEdiJushoFlg", "true");
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
            recMap.put("jshDtlListHShimukeChiCd", "00");
        }
            recMap.put("jshDtlListHShimukeChiCd", "02");
        return recMap;
    }

    private Map<String, Object> createJushoMapFor_24_21(int i) {
        Map recMap = new HashMap();
        // 仕向地コード(下2桁)
        recMap.put("jshDtlListShimukeChiCd", "00");
        // 町字
        recMap.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字
        recMap.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        recMap.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 町字
        recMap.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        recMap.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        recMap.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        recMap.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        recMap.put("jshDtlListEigyoshoCd", "jshDtlListEigyoshoCd");
        
        if (i == 0) {
            recMap.put("jshDtlListKyuEdiJushoFlg", "true");
            recMap.put("jshDtlListShinEdiJushoFlg", "true");
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
            recMap.put("jshDtlListHShimukeChiCd", "00");
        }
            recMap.put("jshDtlListHShimukeChiCd", "02");
        return recMap;
    }
    
    private Map<String, Object> createJushoMapFor_27_2(int i) {
        Map recMap = new HashMap();
        // 仕向地コード(下2桁)
        recMap.put("jshDtlListShimukeChiCd", "0" + i );
        // 町字
        recMap.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字
        recMap.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        recMap.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 町字
        recMap.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        recMap.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        recMap.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        recMap.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        recMap.put("jshDtlListEigyoshoCd", "jshDtlListEigyoshoCd");

        recMap.put("jshDtlListJisCd", "hnknDtlShimukeChiCd");
        recMap.put("jshDtlListHShimukeChiCd", "");
        
        recMap.put("hnknDtlListHenkanJohoJusho", "hnknDtlListHenkanJohoJusho" + i);
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        recMap.put("jshDtlListHenkanKensu", "jshDtlListHenkanKensu");
        if (i == 0) {
            recMap.put("jshDtlListKyuEdiJushoFlg", "true");
            recMap.put("jshDtlListShinEdiJushoFlg", "true");
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
        return recMap;
    }

    private Map<String, Object> createJushoMapFor_27_3(int i) {
        Map recMap = new HashMap();
        // 仕向地コード(下2桁)
        recMap.put("jshDtlListShimukeChiCd", "0" + i );
        // 町字
        recMap.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字
        recMap.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        recMap.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 町字
        recMap.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        recMap.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        recMap.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        recMap.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        recMap.put("jshDtlListEigyoshoCd", "jshDtlListEigyoshoCd");

        recMap.put("jshDtlListJisCd", "hnknDtlShimukeChiCd");
        recMap.put("jshDtlListHShimukeChiCd", "");
        
        recMap.put("hnknDtlListHenkanJohoJusho", "hnknDtlListHenkanJohoJusho");
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        recMap.put("jshDtlListHenkanKensu", "jshDtlListHenkanKensu");
        if (i == 0) {
            recMap.put("jshDtlListKyuEdiJushoFlg", "true");
            recMap.put("jshDtlListShinEdiJushoFlg", "true");
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
        return recMap;
    }

    private Map<String, Object> createJushoMapFor_27_4(int i) {
        Map recMap = new HashMap();
        // 仕向地コード(下2桁)
        recMap.put("jshDtlListShimukeChiCd", "0" + i );
        // 町字
        recMap.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字
        recMap.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        recMap.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 町字
        recMap.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        recMap.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        recMap.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        recMap.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        recMap.put("jshDtlListEigyoshoCd", "jshDtlListEigyoshoCd");

        recMap.put("jshDtlListJisCd", "hnknDtlShimukeChiCd");
        recMap.put("jshDtlListHShimukeChiCd", "");
        
        recMap.put("hnknDtlListHenkanJohoJusho", "40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" + i);
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        recMap.put("jshDtlListHenkanKensu", "jshDtlListHenkanKensu");
        if (i == 0) {
            recMap.put("jshDtlListKyuEdiJushoFlg", "true");
            recMap.put("jshDtlListShinEdiJushoFlg", "true");
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
        return recMap;
    }

    private Map<String, Object> createJushoMapFor_31_1(int i) {
        Map recMap = new HashMap();
        // 仕向地コード(下2桁)
        recMap.put("jshDtlListShimukeChiCd", "0" + i );
        // 町字
        recMap.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字
        recMap.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        recMap.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 町字
        recMap.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        recMap.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        recMap.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        recMap.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        recMap.put("jshDtlListEigyoshoCd", "jshDtlListEigyoshoCd");

        recMap.put("jshDtlListJisCd", "hnknDtlShimukeChiCd");
        recMap.put("jshDtlListHShimukeChiCd", "");
        
        recMap.put("hnknDtlListHenkanJohoJusho", "hnknDtlListHenkanJohoJusho" + i);
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        recMap.put("jshDtlListHenkanKensu", "jshDtlListHenkanKensu");

        recMap.put("shstDtlListHyojiMei", "shstDtlListHyojiMei" + i);
        recMap.put("hnknDtlListHenkanJohoJusho", "hnknDtlListHenkanJohoJusho");
        
        if (i == 0) {
            recMap.put("jshDtlListKyuEdiJushoFlg", "true");
            recMap.put("jshDtlListShinEdiJushoFlg", "true");
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
        return recMap;
    }

    private Map<String, Object> createJushoMapFor_31_3(int i) {
        Map recMap = new HashMap();
        // 仕向地コード(下2桁)
        recMap.put("jshDtlListShimukeChiCd", "0" + i );
        // 町字
        recMap.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字
        recMap.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        recMap.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 町字
        recMap.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        recMap.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        recMap.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        recMap.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        recMap.put("jshDtlListEigyoshoCd", "jshDtlListEigyoshoCd");

        recMap.put("jshDtlListJisCd", "hnknDtlShimukeChiCd");
        recMap.put("jshDtlListHShimukeChiCd", "");
        
        recMap.put("hnknDtlListHenkanJohoJusho", "hnknDtlListHenkanJohoJusho" + i);
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        recMap.put("jshDtlListHenkanKensu", "jshDtlListHenkanKensu");

        recMap.put("shstDtlListHyojiMei", "shstDtlListHyojiMei");
        recMap.put("hnknDtlListHenkanJohoJusho", "hnknDtlListHenkanJohoJusho");
        
        if (i == 0) {
            recMap.put("jshDtlListKyuEdiJushoFlg", "true");
            recMap.put("jshDtlListShinEdiJushoFlg", "true");
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
        return recMap;
    }

    private Map<String, Object> createJushoMapFor_31_4(int i) {
        Map recMap = new HashMap();
        // 仕向地コード(下2桁)
        recMap.put("jshDtlListShimukeChiCd", "0" + i );
        // 町字
        recMap.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字
        recMap.put("jshDtlListChoaza", "jshDtlListChoaza");
        // 町字カナ
        recMap.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 町字
        recMap.put("jshDtlListChoazaKana", "jshDtlListChoazaKana");
        // 仕向地名
        recMap.put("jshDtlListShimukeChiMeiCd", "jshDtlListShimukeChiMeiCd");
        // 空港コード
        recMap.put("jshDtlListKukoCd", "jshDtlListKukoCd");
        // 集配地区コード
        recMap.put("jshDtlListShuhaiChikuCd", "jshDtlListShuhaiChikuCd");
        // 管轄営業所コード
        recMap.put("jshDtlListEigyoshoCd", "jshDtlListEigyoshoCd");

        recMap.put("jshDtlListJisCd", "hnknDtlShimukeChiCd");
        recMap.put("jshDtlListHShimukeChiCd", "");
        
        recMap.put("hnknDtlListHenkanJohoJusho", "hnknDtlListHenkanJohoJusho40xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" + i);
        recMap.put("UNIQUE_KEY", "UNIQUE_KEY");
        recMap.put("jshDtlListHenkanKensu", "jshDtlListHenkanKensu");

        recMap.put("shstDtlListHyojiMei", "shstDtlListHyojiMei" + i);
        
        if (i == 0) {
            recMap.put("jshDtlListKyuEdiJushoFlg", "true");
            recMap.put("jshDtlListShinEdiJushoFlg", "true");
            recMap.put(StndConsIF.CONST_ADD_ROW_KEY, "true");
        }
        return recMap;
    }
    
}
