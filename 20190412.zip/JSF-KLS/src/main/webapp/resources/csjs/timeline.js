/*
 
 Licensed under the Apache License, Version 2.0 (the "License"); you may not
 use this file except in compliance with the License. You may obtain a copy
 of the License at
 
 http://www.apache.org/licenses/LICENSE-2.0
 
 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 License for the specific language governing permissions and limitations under
 the License.
 
 Copyright (c) 2011-2015 Almende B.V.
 
 @author  Jos de Jong, <jos@almende.org>
 @date    2015-03-04
 @version 2.9.1
 */
"undefined" === typeof links && (links = {});
"undefined" === typeof google && (google = void 0);
Array.prototype.indexOf || (Array.prototype.indexOf = function (a) {
    for (var b = 0; b < this.length; b++)
        if (this[b] == a)
            return b;
    return-1
});
Array.prototype.forEach || (Array.prototype.forEach = function (a, b) {
    for (var c = 0, d = this.length; c < d; ++c)
        a.call(b || this, this[c], c, this)
});
links.Timeline = function (a, b) {
    if (a) {
        this.dom = {};
        this.conversion = {};
        this.eventParams = {};
        this.groups = [];
        this.groupIndexes = {};
        this.items = [];
        this.renderQueue = {show: [], hide: [], update: []};
        this.renderedItems = [];
        this.clusterGenerator = new links.Timeline.ClusterGenerator(this);
        this.currentClusters = [];
        this.selection = void 0;
        this.listeners = {};
        this.size = {actualHeight: 0, axis: {characterMajorHeight: 0, characterMajorWidth: 0, characterMinorHeight: 0, characterMinorWidth: 0, height: 0, labelMajorTop: 0, labelMinorTop: 0, line: 0,
                lineMajorWidth: 0, lineMinorHeight: 0, lineMinorTop: 0, lineMinorWidth: 0, top: 0}, contentHeight: 0, contentLeft: 0, contentWidth: 0, frameHeight: 0, frameWidth: 0, groupsLeft: 0, groupsWidth: 0, items: {top: 0}};
        this.dom.container = a;
        this.options = {width: "100%", height: "auto", minHeight: 0, groupMinHeight: 0, autoHeight: !0, eventMargin: 10, eventMarginAxis: 20, dragAreaWidth: 10, min: void 0, max: void 0, zoomMin: 10, zoomMax: 31536E10, moveable: !0, zoomable: !0, selectable: !0, unselectable: !0, editable: !1, snapEvents: !0, groupsChangeable: !0, timeChangeable: !0,
            showCurrentTime: !0, showCustomTime: !1, showMajorLabels: !0, showMinorLabels: !0, showNavigation: !1, showButtonNew: !1, groupsOnRight: !1, groupsOrder: !0, axisOnTop: !1, stackEvents: !0, animate: !0, animateZoom: !0, cluster: !1, clusterMaxItems: 5, style: "box", customStackOrder: !1, locale: "en", MONTHS: "January February March April May June July August September October November December".split(" "), MONTHS_SHORT: "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split(" "), DAYS: "Sunday Monday Tuesday Wednesday Thursday Friday Saturday".split(" "),
            DAYS_SHORT: "Sun Mon Tue Wed Thu Fri Sat".split(" "), ZOOM_IN: "Zoom in", ZOOM_OUT: "Zoom out", MOVE_LEFT: "Move left", MOVE_RIGHT: "Move right", NEW: "New", CREATE_NEW_EVENT: "Create new event"};
        this.setOptions(b);
        this.clientTimeOffset = 0;
        for (var c = this.dom; c.container.hasChildNodes(); )
            c.container.removeChild(c.container.firstChild);
        this.step = new links.Timeline.StepDate;
        this.itemTypes = {box: links.Timeline.ItemBox, range: links.Timeline.ItemRange, floatingRange: links.Timeline.ItemFloatingRange, dot: links.Timeline.ItemDot};
        this.data = [];
        this.firstDraw = !0;
        this.setVisibleChartRange(void 0, void 0, !1);
        this.render();
        var d = this;
        setTimeout(function () {
            d.trigger("ready")
        }, 0)
    }
};
links.Timeline.prototype.draw = function (a, b) {
    b && (console.log("WARNING: Passing options in draw() is deprecated. Pass options to the constructur or use setOptions() instead!"), this.setOptions(b));
    this.options.selectable && links.Timeline.addClassName(this.dom.frame, "timeline-selectable");
    this.setData(a);
    this.firstDraw && this.setVisibleChartRangeAuto();
    this.firstDraw = !1
};
links.Timeline.prototype.setOptions = function (a) {
    if (a) {
        for (var b in a)
            a.hasOwnProperty(b) && (this.options[b] = a[b]);
        if ("undefined" !== typeof links.locales && "en" !== this.options.locale && (b = links.locales[this.options.locale]))
            for (var c in b)
                b.hasOwnProperty(c) && (this.options[c] = b[c]);
        void 0 != a.showButtonAdd && (this.options.showButtonNew = a.showButtonAdd, console.log("WARNING: Option showButtonAdd is deprecated. Use showButtonNew instead"));
        void 0 != a.intervalMin && (this.options.zoomMin = a.intervalMin, console.log("WARNING: Option intervalMin is deprecated. Use zoomMin instead"));
        void 0 != a.intervalMax && (this.options.zoomMax = a.intervalMax, console.log("WARNING: Option intervalMax is deprecated. Use zoomMax instead"));
        a.scale && a.step && this.step.setScale(a.scale, a.step)
    }
    this.options.autoHeight = "auto" === this.options.height
};
links.Timeline.prototype.getOptions = function () {
    return this.options
};
links.Timeline.prototype.addItemType = function (a, b) {
    this.itemTypes[a] = b
};
links.Timeline.mapColumnIds = function (a) {
    for (var b = {}, c = a.getNumberOfColumns(), d = !0, e = 0; e < c; e++) {
        var f = a.getColumnId(e) || a.getColumnLabel(e);
        b[f] = e;
        if ("start" == f || "end" == f || "content" == f || "group" == f || "className" == f || "editable" == f || "type" == f)
            d = !1
    }
    d && (b.start = 0, b.end = 1, b.content = 2, 3 < c && (b.group = 3), 4 < c && (b.className = 4), 5 < c && (b.editable = 5), 6 < c && (b.type = 6));
    return b
};
links.Timeline.prototype.setData = function (a) {
    this.unselectItem();
    a || (a = []);
    this.stackCancelAnimation();
    this.clearItems();
    this.data = a;
    var b = this.items;
    this.deleteGroups();
    if (google && google.visualization && a instanceof google.visualization.DataTable)
        for (var c = links.Timeline.mapColumnIds(a), d = 0, e = a.getNumberOfRows(); d < e; d++)
            b.push(this.createItem({start: void 0 != c.start ? a.getValue(d, c.start) : void 0, end: void 0 != c.end ? a.getValue(d, c.end) : void 0, content: void 0 != c.content ? a.getValue(d, c.content) : void 0, group: void 0 !=
                        c.group ? a.getValue(d, c.group) : void 0, className: void 0 != c.className ? a.getValue(d, c.className) : void 0, editable: void 0 != c.editable ? a.getValue(d, c.editable) : void 0, type: void 0 != c.type ? a.getValue(d, c.type) : void 0}));
    else if (links.Timeline.isArray(a))
        for (d = 0, e = a.length; d < e; d++)
            c = this.createItem(a[d]), b.push(c);
    else
        throw"Unknown data type. DataTable or Array expected.";
    this.options.cluster && this.clusterGenerator.setData(this.items);
    this.render({animate: !1})
};
links.Timeline.prototype.getData = function () {
    return this.data
};
links.Timeline.prototype.updateData = function (a, b) {
    var c = this.data, d;
    if (google && google.visualization && c instanceof google.visualization.DataTable) {
        var e = a + 1 - c.getNumberOfRows();
        0 < e && c.addRows(e);
        e = links.Timeline.mapColumnIds(c);
        for (d in b)
            if (b.hasOwnProperty(d)) {
                var f = e[d];
                if (void 0 == f) {
                    var f = b[d], g = "string";
                    "number" == typeof f ? g = "number" : "boolean" == typeof f ? g = "boolean" : f instanceof Date && (g = "datetime");
                    f = c.addColumn(g, d)
                }
                c.setValue(a, f, b[d])
            }
    } else if (links.Timeline.isArray(c))
        for (d in e = c[a], void 0 ==
                e && (e = {}, c[a] = e), b)
            b.hasOwnProperty(d) && (e[d] = b[d]);
    else
        throw"Cannot update data, unknown type of data";
};
links.Timeline.prototype.getItemIndex = function (a) {
    for (var b = this.dom.items.frame, c = this.items, d = void 0; a.parentNode && a.parentNode !== b; )
        a = a.parentNode;
    if (a.parentNode === b)
        for (var b = 0, e = c.length; b < e; b++)
            if (c[b].dom === a) {
                d = b;
                break
            }
    return d
};
links.Timeline.prototype.getClusterIndex = function (a) {
    var b = this.dom.items.frame, c = this.clusters, d = void 0;
    if (this.clusters) {
        for (; a.parentNode && a.parentNode !== b; )
            a = a.parentNode;
        if (a.parentNode === b)
            for (var b = 0, e = c.length; b < e; b++)
                if (c[b].dom === a) {
                    d = b;
                    break
                }
    }
    return d
};
links.Timeline.prototype.getVisibleItems = function (a, b) {
    var c = this.items, d = [];
    if (c)
        for (var e = 0, f = c.length; e < f; e++) {
            var g = c[e];
            g.end ? a <= g.start && g.end <= b && d.push({row: e}) : a <= g.start && g.start <= b && d.push({row: e})
        }
    return d
};
links.Timeline.prototype.setSize = function (a, b) {
    a && (this.options.width = a, this.dom.frame.style.width = a);
    b && (this.options.height = b, this.options.autoHeight = "auto" === this.options.height, "auto" !== b && (this.dom.frame.style.height = b));
    this.render({animate: !1})
};
links.Timeline.prototype.setVisibleChartRange = function (a, b, c) {
    var d = {};
    a && b || (d = this.getDataRange(!0));
    a || (b ? d.min && d.min.valueOf() < b.valueOf() ? a = d.min : (a = new Date(b.valueOf()), a.setDate(a.getDate() - 7)) : (a = new Date, a.setDate(a.getDate() - 3)));
    b || (d.max ? b = d.max : (b = new Date(a.valueOf()), b.setDate(b.getDate() + 7)));
    b <= a && (b = new Date(a.valueOf()), b.setDate(b.getDate() + 7));
    d = this.options.min ? this.options.min : void 0;
    void 0 != d && a.valueOf() < d.valueOf() && (a = new Date(d.valueOf()));
    d = this.options.max ? this.options.max :
            void 0;
    void 0 != d && b.valueOf() > d.valueOf() && (b = new Date(d.valueOf()));
    this.applyRange(a, b);
    void 0 == c || 1 == c ? this.render({animate: !1}) : this.recalcConversion()
};
links.Timeline.prototype.setVisibleChartRangeAuto = function () {
    if (this.options && (this.options.start || this.options.end))
        this.setVisibleChartRange(this.options.start, this.options.end);
    else {
        var a = this.getDataRange(!0);
        this.setVisibleChartRange(a.min, a.max)
    }
};
links.Timeline.prototype.setVisibleChartRangeNow = function () {
    var a = this.end.valueOf() - this.start.valueOf(), b = new Date((new Date).valueOf() - a / 2);
    this.setVisibleChartRange(b, new Date(b.valueOf() + a))
};
links.Timeline.prototype.getVisibleChartRange = function () {
    return{start: new Date(this.start.valueOf()), end: new Date(this.end.valueOf())}
};
links.Timeline.prototype.getDataRange = function (a) {
    var b = this.items, c = void 0, d = void 0;
    if (b)
        for (var e = 0, f = b.length; e < f; e++) {
            var g = b[e], h = void 0 != g.start ? g.start.valueOf() : void 0, g = void 0 != g.end ? g.end.valueOf() : h;
            void 0 != h && (c = void 0 != c ? Math.min(c.valueOf(), h.valueOf()) : h);
            void 0 != g && (d = void 0 != d ? Math.max(d.valueOf(), g.valueOf()) : g)
        }
    c && d && a && (a = d - c, c -= .05 * a, d += .05 * a);
    return{min: void 0 != c ? new Date(c) : void 0, max: void 0 != d ? new Date(d) : void 0}
};
links.Timeline.prototype.render = function (a) {
    this.reflowFrame();
    this.reflowAxis();
    this.reflowGroups();
    this.reflowItems();
    var b = this.options.animate;
    a && void 0 != a.animate && (b = a.animate);
    this.recalcConversion();
    this.clusterItems();
    this.filterItems();
    this.stackItems(b);
    this.recalcItems();
    this.repaint() && (b = a ? a.renderTimesLeft : void 0, void 0 == b && (b = 5), 0 < b && this.render({animate: a ? a.animate : void 0, renderTimesLeft: b - 1}))
};
links.Timeline.prototype.repaint = function () {
    var a = this.repaintFrame(), b = this.repaintAxis(), c = this.repaintGroups(), d = this.repaintItems();
    this.repaintCurrentTime();
    this.repaintCustomTime();
    return a || b || c || d
};
links.Timeline.prototype.reflowFrame = function () {
    var a = this.dom, b = this.size, c = a.frame ? a.frame.offsetWidth : 0, d = a.frame ? a.frame.clientHeight : 0, a = (a = b.frameWidth !== c) || b.frameHeight !== d;
    b.frameWidth = c;
    b.frameHeight = d;
    return a
};
links.Timeline.prototype.repaintFrame = function () {
    var a = !1, b = this.dom, c = this.options, d = this.size;
    b.frame || (b.frame = document.createElement("DIV"), b.frame.className = "timeline-frame ui-widget ui-widget-content ui-corner-all", b.container.appendChild(b.frame), a = !0);
    var e = c.autoHeight ? d.actualHeight + "px" : c.height || "100%", c = c.width || "100%", a = (a = a || b.frame.style.height != e) || b.frame.style.width != c;
    b.frame.style.height = e;
    b.frame.style.width = c;
    if (!b.content) {
        b.content = document.createElement("DIV");
        b.content.className =
                "timeline-content";
        b.frame.appendChild(b.content);
        a = document.createElement("DIV");
        a.style.position = "absolute";
        a.style.left = "0px";
        a.style.top = "0px";
        a.style.height = "100%";
        a.style.width = "0px";
        b.content.appendChild(a);
        b.contentTimelines = a;
        var a = this.eventParams, f = this;
        a.onMouseDown || (a.onMouseDown = function (a) {
            f.onMouseDown(a)
        }, links.Timeline.addEventListener(b.content, "mousedown", a.onMouseDown));
        a.onTouchStart || (a.onTouchStart = function (a) {
            f.onTouchStart(a)
        }, links.Timeline.addEventListener(b.content, "touchstart",
                a.onTouchStart));
        a.onMouseWheel || (a.onMouseWheel = function (a) {
            f.onMouseWheel(a)
        }, links.Timeline.addEventListener(b.content, "mousewheel", a.onMouseWheel));
        a.onDblClick || (a.onDblClick = function (a) {
            f.onDblClick(a)
        }, links.Timeline.addEventListener(b.content, "dblclick", a.onDblClick));
        a = !0
    }
    b.content.style.left = d.contentLeft + "px";
    b.content.style.top = "0px";
    b.content.style.width = d.contentWidth + "px";
    b.content.style.height = d.frameHeight + "px";
    this.repaintNavigation();
    return a
};
links.Timeline.prototype.reflowAxis = function () {
    var a, b = this.options, c = this.size, d = this.dom.axis, e = d && d.characterMinor ? d.characterMinor.clientWidth : 0, f = d && d.characterMinor ? d.characterMinor.clientHeight : 0, g = d && d.characterMajor ? d.characterMajor.clientWidth : 0, h = d && d.characterMajor ? d.characterMajor.clientHeight : 0, k = (b.showMinorLabels ? f : 0) + (b.showMajorLabels ? h : 0), l = b.axisOnTop ? 0 : c.frameHeight - k, n = b.axisOnTop ? k : l;
    a = (a = (a = c.axis.top !== l) || c.axis.line !== n) || c.axis.height !== k;
    c.axis.top = l;
    c.axis.line = n;
    c.axis.height =
            k;
    c.axis.labelMajorTop = b.axisOnTop ? 0 : n + (b.showMinorLabels ? f : 0);
    c.axis.labelMinorTop = b.axisOnTop ? b.showMajorLabels ? h : 0 : n;
    c.axis.lineMinorTop = b.axisOnTop ? c.axis.labelMinorTop : 0;
    c.axis.lineMinorHeight = b.showMajorLabels ? c.frameHeight - h : c.frameHeight;
    c.axis.lineMinorWidth = d && d.minorLines && d.minorLines.length ? d.minorLines[0].offsetWidth : 1;
    c.axis.lineMajorWidth = d && d.majorLines && d.majorLines.length ? d.majorLines[0].offsetWidth : 1;
    a = (a = (a = (a = a || c.axis.characterMinorWidth !== e) || c.axis.characterMinorHeight !==
            f) || c.axis.characterMajorWidth !== g) || c.axis.characterMajorHeight !== h;
    c.axis.characterMinorWidth = e;
    c.axis.characterMinorHeight = f;
    c.axis.characterMajorWidth = g;
    c.axis.characterMajorHeight = h;
    d = Math.max(c.frameHeight - k, 0);
    c.contentLeft = b.groupsOnRight ? 0 : c.groupsWidth;
    c.contentWidth = Math.max(c.frameWidth - c.groupsWidth, 0);
    c.contentHeight = d;
    return a
};
links.Timeline.prototype.repaintAxis = function () {
    var a = !1, b = this.dom, c = this.options, d = this.size, e = this.step, f = b.axis;
    f || (f = {}, b.axis = f);
    d.axis.properties || (d.axis.properties = {});
    f.minorTexts || (f.minorTexts = []);
    f.minorLines || (f.minorLines = []);
    f.majorTexts || (f.majorTexts = []);
    f.majorLines || (f.majorLines = []);
    f.frame || (f.frame = document.createElement("DIV"), f.frame.style.position = "absolute", f.frame.style.left = "0px", f.frame.style.top = "0px", b.content.appendChild(f.frame));
    b.content.removeChild(f.frame);
    f.frame.style.width =
            d.contentWidth + "px";
    f.frame.style.height = d.axis.height + "px";
    var g = this.screenToTime(0), h = this.screenToTime(d.contentWidth);
    d.axis.characterMinorWidth && (this.minimumStep = this.screenToTime(6 * d.axis.characterMinorWidth) - this.screenToTime(0), e.setRange(g, h, this.minimumStep));
    g = this.repaintAxisCharacters();
    a = a || g;
    this.repaintAxisStartOverwriting();
    e.start();
    g = void 0;
    for (h = 0; !e.end() && 1E3 > h; ) {
        h++;
        var k = e.getCurrent(), k = this.timeToScreen(k), l = e.isMajor();
        c.showMinorLabels && this.repaintAxisMinorText(k, e.getLabelMinor(c));
        l && c.showMajorLabels ? (0 < k && (void 0 == g && (g = k), this.repaintAxisMajorText(k, e.getLabelMajor(c))), this.repaintAxisMajorLine(k)) : this.repaintAxisMinorLine(k);
        e.next()
    }
    c.showMajorLabels && (e = this.screenToTime(0), c = this.step.getLabelMajor(c, e), d = c.length * d.axis.characterMajorWidth + 10, (void 0 == g || d < g) && this.repaintAxisMajorText(0, c, e));
    this.repaintAxisEndOverwriting();
    this.repaintAxisHorizontal();
    b.content.insertBefore(f.frame, b.content.firstChild);
    return a
};
links.Timeline.prototype.repaintAxisCharacters = function () {
    var a = !1, b = this.dom.axis;
    if (!b.characterMinor) {
        var a = document.createTextNode("0"), c = document.createElement("DIV");
        c.className = "timeline-axis-text timeline-axis-text-minor";
        c.appendChild(a);
        c.style.position = "absolute";
        c.style.visibility = "hidden";
        c.style.paddingLeft = "0px";
        c.style.paddingRight = "0px";
        b.frame.appendChild(c);
        b.characterMinor = c;
        a = !0
    }
    b.characterMajor || (a = document.createTextNode("0"), c = document.createElement("DIV"), c.className = "timeline-axis-text timeline-axis-text-major",
            c.appendChild(a), c.style.position = "absolute", c.style.visibility = "hidden", c.style.paddingLeft = "0px", c.style.paddingRight = "0px", b.frame.appendChild(c), b.characterMajor = c, a = !0);
    return a
};
links.Timeline.prototype.repaintAxisStartOverwriting = function () {
    var a = this.size.axis.properties;
    a.minorTextNum = 0;
    a.minorLineNum = 0;
    a.majorTextNum = 0;
    a.majorLineNum = 0
};
links.Timeline.prototype.repaintAxisEndOverwriting = function () {
    var a = this.dom, b = this.size.axis.properties, c = this.dom.axis.frame, d, e = a.axis.minorTexts;
    for (d = b.minorTextNum; e.length > d; )
        c.removeChild(e[d]), e.splice(d, 1);
    e = a.axis.minorLines;
    for (d = b.minorLineNum; e.length > d; )
        c.removeChild(e[d]), e.splice(d, 1);
    e = a.axis.majorTexts;
    for (d = b.majorTextNum; e.length > d; )
        c.removeChild(e[d]), e.splice(d, 1);
    a = a.axis.majorLines;
    for (d = b.majorLineNum; a.length > d; )
        c.removeChild(a[d]), a.splice(d, 1)
};
links.Timeline.prototype.repaintAxisHorizontal = function () {
    var a = this.dom.axis, b = this.size, c = this.options;
    if (c = c.showMinorLabels || c.showMajorLabels) {
        if (!a.backgroundLine) {
            var d = document.createElement("DIV");
            d.className = "timeline-axis";
            d.style.position = "absolute";
            d.style.left = "0px";
            d.style.width = "100%";
            d.style.border = "none";
            a.frame.insertBefore(d, a.frame.firstChild);
            a.backgroundLine = d
        }
        a.backgroundLine && (a.backgroundLine.style.top = b.axis.top + "px", a.backgroundLine.style.height = b.axis.height + "px")
    } else
        a.backgroundLine &&
                (a.frame.removeChild(a.backgroundLine), delete a.backgroundLine);
    c ? (a.line ? (c = a.frame.removeChild(a.line), a.frame.appendChild(c)) : (c = document.createElement("DIV"), c.className = "timeline-axis", c.style.position = "absolute", c.style.left = "0px", c.style.width = "100%", c.style.height = "0px", a.frame.appendChild(c), a.line = c), a.line.style.top = b.axis.line + "px") : a.line && a.line.parentElement && (a.frame.removeChild(a.line), delete a.line)
};
links.Timeline.prototype.repaintAxisMinorText = function (a, b) {
    var c = this.size, d = this.dom, e = c.axis.properties, f = d.axis.frame, d = d.axis.minorTexts, g = e.minorTextNum;
    if (g < d.length)
        g = d[g];
    else {
        var h = document.createTextNode(""), g = document.createElement("DIV");
        g.appendChild(h);
        g.className = "timeline-axis-text timeline-axis-text-minor";
        g.style.position = "absolute";
        f.appendChild(g);
        d.push(g)
    }
    g.childNodes[0].nodeValue = b;
    g.style.left = a + "px";
    g.style.top = c.axis.labelMinorTop + "px";
    e.minorTextNum++
};
links.Timeline.prototype.repaintAxisMinorLine = function (a) {
    var b = this.size.axis, c = this.dom, d = b.properties, e = c.axis.frame, c = c.axis.minorLines, f = d.minorLineNum;
    f < c.length ? f = c[f] : (f = document.createElement("DIV"), f.className = "timeline-axis-grid timeline-axis-grid-minor", f.style.position = "absolute", f.style.width = "0px", e.appendChild(f), c.push(f));
    f.style.top = b.lineMinorTop + "px";
    f.style.height = b.lineMinorHeight + "px";
    f.style.left = a - b.lineMinorWidth / 2 + "px";
    d.minorLineNum++
};
links.Timeline.prototype.repaintAxisMajorText = function (a, b) {
    var c = this.size, d = c.axis.properties, e = this.dom.axis.frame, f = this.dom.axis.majorTexts, g = d.majorTextNum;
    if (g < f.length)
        g = f[g];
    else {
        var h = document.createTextNode(b), g = document.createElement("DIV");
        g.className = "timeline-axis-text timeline-axis-text-major";
        g.appendChild(h);
        g.style.position = "absolute";
        g.style.top = "0px";
        e.appendChild(g);
        f.push(g)
    }
    g.childNodes[0].nodeValue = b;
    g.style.top = c.axis.labelMajorTop + "px";
    g.style.left = a + "px";
    d.majorTextNum++
};
links.Timeline.prototype.repaintAxisMajorLine = function (a) {
    var b = this.size, c = b.axis.properties, d = this.size.axis, e = this.dom.axis.frame, f = this.dom.axis.majorLines, g = c.majorLineNum;
    g < f.length ? g = f[g] : (g = document.createElement("DIV"), g.className = "timeline-axis-grid timeline-axis-grid-major", g.style.position = "absolute", g.style.top = "0px", g.style.width = "0px", e.appendChild(g), f.push(g));
    g.style.left = a - d.lineMajorWidth / 2 + "px";
    g.style.height = b.frameHeight + "px";
    c.majorLineNum++
};
links.Timeline.prototype.reflowItems = function () {
    var a = !1, b, c, d;
    b = this.groups;
    var e = this.renderedItems;
    b && b.forEach(function (a) {
        a.itemsHeight = a.labelHeight || 0
    });
    b = 0;
    for (c = e.length; b < c; b++) {
        var f = e[b], g = f.dom;
        d = f.group;
        if (g) {
            var h = g ? g.clientWidth : 0, g = g ? g.clientHeight : 0, a = (a = a || f.width != h) || f.height != g;
            f.width = h;
            f.height = g;
            f.reflow()
        }
        d && (d.itemsHeight = Math.max(this.options.groupMinHeight, d.itemsHeight ? Math.max(d.itemsHeight, f.height) : f.height))
    }
    return a
};
links.Timeline.prototype.recalcItems = function () {
    var a = !1, b, c, d, e, f;
    d = this.groups;
    var g = this.size, h = this.options;
    f = this.renderedItems;
    var k = 0;
    if (0 == d.length) {
        if (h.autoHeight || h.cluster) {
            var l = k = 0;
            if (this.stack && this.stack.finalItems)
                for (d = this.stack.finalItems, (e = d[0]) && e.top && (k = e.top, l = e.top + e.height), b = 1, c = d.length; b < c; b++)
                    e = d[b], k = Math.min(k, e.top), l = Math.max(l, e.top + e.height);
            else
                for ((d = f[0]) && d.top && (k = d.top, l = d.top + d.height), b = 1, c = f.length; b < c; b++)
                    d = f[b], d.top && (k = Math.min(k, d.top), l = Math.max(l,
                            d.top + d.height));
            k = l - k + 2 * h.eventMarginAxis + g.axis.height;
            k < h.minHeight && (k = h.minHeight);
            if (g.actualHeight != k && h.autoHeight && !h.axisOnTop)
                if (l = k - g.actualHeight, this.stack && this.stack.finalItems)
                    for (d = this.stack.finalItems, b = 0, c = d.length; b < c; b++)
                        d[b].top += l, d[b].item.top += l;
                else
                    for (b = 0, c = f.length; b < c; b++)
                        f[b].top += l
        }
    } else {
        k = g.axis.height + 2 * h.eventMarginAxis;
        b = 0;
        for (c = d.length; b < c; b++)
            f = d[b], l = f.itemsHeight, a = a || l != f.height, f.height = Math.max(l, h.groupMinHeight), k += d[b].height + h.eventMargin;
        a = h.eventMargin;
        l = h.axisOnTop ? h.eventMarginAxis + a / 2 : g.contentHeight - h.eventMarginAxis + a / 2;
        e = g.axis.height;
        b = 0;
        for (c = d.length; b < c; b++)
            f = d[b], h.axisOnTop ? (f.top = l + e, f.labelTop = l + e + (f.height - f.labelHeight) / 2, f.lineTop = l + e + f.height + a / 2, l += f.height + a) : (l -= f.height + a, f.top = l, f.labelTop = l + (f.height - f.labelHeight) / 2, f.lineTop = l - a / 2);
        a = !0
    }
    k < h.minHeight && (k = h.minHeight);
    a = a || k != g.actualHeight;
    g.actualHeight = k;
    return a
};
links.Timeline.prototype.clearItems = function () {
    var a = this.renderQueue.hide;
    this.renderedItems.forEach(function (b) {
        a.push(b)
    });
    this.clusterGenerator.clear();
    this.items = []
};
links.Timeline.prototype.repaintItems = function () {
    var a, b, c = !1, d = this.dom;
    a = this.size;
    var e = this, f = this.renderedItems;
    d.items || (d.items = {});
    var g = d.items.frame;
    g || (g = document.createElement("DIV"), g.style.position = "relative", d.content.appendChild(g), d.items.frame = g);
    g.style.left = "0px";
    g.style.top = a.items.top + "px";
    g.style.height = "0px";
    d.content.removeChild(g);
    for (var h = this.renderQueue, k = [], c = c || 0 < h.show.length || 0 < h.update.length || 0 < h.hide.length; a = h.show.shift(); )
        a.showDOM(g), a.getImageUrls(k), f.push(a);
    for (; a = h.update.shift(); )
        a.updateDOM(g), a.getImageUrls(k), b = this.renderedItems.indexOf(a), -1 == b && f.push(a);
    for (; a = h.hide.shift(); )
        a.hideDOM(g), b = this.renderedItems.indexOf(a), -1 != b && f.splice(b, 1);
    f.forEach(function (a) {
        a.updatePosition(e)
    });
    this.repaintDeleteButton();
    this.repaintDragAreas();
    d.content.appendChild(g);
    k.length && links.imageloader.loadAll(k, function () {
        e.render()
    }, !1);
    return c
};
links.Timeline.prototype.reflowGroups = function () {
    for (var a = !1, b = this.options, c = this.size, d = this.dom, e = 0, f = this.groups, g = this.dom.groups ? this.dom.groups.labels : [], h = 0, k = f.length; h < k; h++) {
        var l = f[h], n = g[h];
        l.labelWidth = n ? n.clientWidth : 0;
        l.labelHeight = n ? n.clientHeight : 0;
        l.width = l.labelWidth;
        e = Math.max(e, l.width)
    }
    void 0 !== b.groupsWidth && (e = d.groups && d.groups.frame ? d.groups.frame.clientWidth : 0);
    e += 1;
    b = b.groupsOnRight ? c.frameWidth - e : 0;
    a = (a = a || c.groupsWidth !== e) || c.groupsLeft !== b;
    c.groupsWidth = e;
    c.groupsLeft =
            b;
    return a
};
links.Timeline.prototype.repaintGroups = function () {
    var a = this.dom, b = this, c = this.options, d = this.size, e = this.groups;
    void 0 === a.groups && (a.groups = {});
    var f = a.groups.labels;
    f || (f = [], a.groups.labels = f);
    var g = a.groups.labelLines;
    g || (g = [], a.groups.labelLines = g);
    var h = a.groups.itemLines;
    h || (h = [], a.groups.itemLines = h);
    var k = a.groups.frame;
    k || (k = document.createElement("DIV"), k.className = "timeline-groups-axis", k.style.position = "absolute", k.style.overflow = "hidden", k.style.top = "0px", k.style.height = "100%", a.frame.appendChild(k),
            a.groups.frame = k);
    k.style.left = d.groupsLeft + "px";
    k.style.width = void 0 !== c.groupsWidth ? c.groupsWidth : d.groupsWidth + "px";
    k.style.display = 0 == e.length ? "none" : "";
    for (var l = f.length, n = e.length, m = 0, v = Math.min(l, n); m < v; m++) {
        var t = e[m], q = f[m];
        q.innerHTML = this.getGroupName(t);
        q.style.display = ""
    }
    for (m = l; m < n; m++) {
        t = e[m];
        q = document.createElement("DIV");
        q.className = "timeline-groups-text";
        q.style.position = "absolute";
        void 0 === c.groupsWidth && (q.style.whiteSpace = "nowrap");
        q.innerHTML = this.getGroupName(t);
        k.appendChild(q);
        f[m] = q;
        var r = document.createElement("DIV");
        r.className = "timeline-axis-grid timeline-axis-grid-minor";
        r.style.position = "absolute";
        r.style.left = "0px";
        r.style.width = "100%";
        r.style.height = "0px";
        r.style.borderTopStyle = "solid";
        k.appendChild(r);
        g[m] = r;
        var p = document.createElement("DIV");
        p.className = "timeline-axis-grid timeline-axis-grid-minor";
        p.style.position = "absolute";
        p.style.left = "0px";
        p.style.width = "100%";
        p.style.height = "0px";
        p.style.borderTopStyle = "solid";
        a.content.insertBefore(p, a.content.firstChild);
        h[m] = p
    }
    for (m = n; m < l; m++)
        q = f[m], r = g[m], p = h[m], k.removeChild(q), k.removeChild(r), a.content.removeChild(p);
    f.splice(n, l - n);
    g.splice(n, l - n);
    h.splice(n, l - n);
    links.Timeline.addClassName(k, c.groupsOnRight ? "timeline-groups-axis-onright" : "timeline-groups-axis-onleft");
    m = 0;
    for (v = e.length; m < v; m++)
        t = e[m], q = f[m], r = g[m], p = h[m], q.style.top = t.labelTop + "px", r.style.top = t.lineTop + "px", p.style.top = t.lineTop + "px", p.style.width = d.contentWidth + "px";
    a.groups.background || (c = document.createElement("DIV"), c.className = "timeline-axis",
            c.style.position = "absolute", c.style.left = "0px", c.style.width = "100%", c.style.border = "none", k.appendChild(c), a.groups.background = c);
    a.groups.background.style.top = d.axis.top + "px";
    a.groups.background.style.height = d.axis.height + "px";
    a.groups.line || (c = document.createElement("DIV"), c.className = "timeline-axis", c.style.position = "absolute", c.style.left = "0px", c.style.width = "100%", c.style.height = "0px", k.appendChild(c), a.groups.line = c);
    a.groups.line.style.top = d.axis.line + "px";
    a.groups.frame && e.length && (d = [], links.imageloader.filterImageUrls(a.groups.frame,
            d), d.length && links.imageloader.loadAll(d, function () {
        b.render()
    }, !1))
};
links.Timeline.prototype.repaintCurrentTime = function () {
    var a = this.dom, b = this.size;
    if (this.options.showCurrentTime) {
        if (!a.currentTime) {
            var c = document.createElement("DIV");
            c.className = "timeline-currenttime";
            c.style.position = "absolute";
            c.style.top = "0px";
            c.style.height = "100%";
            a.contentTimelines.appendChild(c);
            a.currentTime = c
        }
        var c = new Date((new Date).valueOf() + this.clientTimeOffset), d = this.timeToScreen(c);
        a.currentTime.style.display = d > -b.contentWidth && d < 2 * b.contentWidth ? "" : "none";
        a.currentTime.style.left =
                d + "px";
        a.currentTime.title = "Current time: " + c;
        void 0 != this.currentTimeTimer && (clearTimeout(this.currentTimeTimer), delete this.currentTimeTimer);
        var e = this, a = 1 / this.conversion.factor / 2;
        30 > a && (a = 30);
        this.currentTimeTimer = setTimeout(function () {
            e.repaintCurrentTime()
        }, a)
    } else
        a.currentTime && (a.contentTimelines.removeChild(a.currentTime), delete a.currentTime)
};
links.Timeline.prototype.repaintCustomTime = function () {
    var a = this.dom, b = this.size;
    if (this.options.showCustomTime) {
        if (!a.customTime) {
            var c = document.createElement("DIV");
            c.className = "timeline-customtime";
            c.style.position = "absolute";
            c.style.top = "0px";
            c.style.height = "100%";
            var d = document.createElement("DIV");
            d.style.position = "relative";
            d.style.top = "0px";
            d.style.left = "-10px";
            d.style.height = "100%";
            d.style.width = "20px";
            c.appendChild(d);
            a.contentTimelines.appendChild(c);
            a.customTime = c;
            this.customTime = new Date
        }
        c =
                this.timeToScreen(this.customTime);
        a.customTime.style.display = c > -b.contentWidth && c < 2 * b.contentWidth ? "" : "none";
        a.customTime.style.left = c + "px";
        a.customTime.title = "Time: " + this.customTime
    } else
        a.customTime && (a.contentTimelines.removeChild(a.customTime), delete a.customTime)
};
links.Timeline.prototype.repaintDeleteButton = function () {
    var a = this.dom, b = a.items.frame, c = a.items.deleteButton;
    c || (c = document.createElement("DIV"), c.className = "timeline-navigation-delete", c.style.position = "absolute", b.appendChild(c), a.items.deleteButton = c);
    var a = this.selection && void 0 !== this.selection.index ? this.selection.index : -1, d = this.selection && void 0 !== this.selection.index ? this.items[a] : void 0;
    d && d.rendered && this.isEditable(d) ? (a = d.getRight(this), d = d.top, c.style.left = a + "px", c.style.top = d + "px",
            c.style.display = "", b.removeChild(c), b.appendChild(c)) : c.style.display = "none"
};
links.Timeline.prototype.repaintDragAreas = function () {
    var a = this.options, b = this.dom, c = this.dom.items.frame, d = b.items.dragLeft;
    d || (d = document.createElement("DIV"), d.className = "timeline-event-range-drag-left", d.style.position = "absolute", c.appendChild(d), b.items.dragLeft = d);
    var e = b.items.dragRight;
    e || (e = document.createElement("DIV"), e.className = "timeline-event-range-drag-right", e.style.position = "absolute", c.appendChild(e), b.items.dragRight = e);
    var b = this.selection && void 0 !== this.selection.index ? this.selection.index :
            -1, f = this.selection && void 0 !== this.selection.index ? this.items[b] : void 0;
    if (f && f.rendered && this.isEditable(f) && (f instanceof links.Timeline.ItemRange || f instanceof links.Timeline.ItemFloatingRange)) {
        var b = f.getLeft(this), g = f.getRight(this), h = f.top, f = f.height;
        d.style.left = b + "px";
        d.style.top = h + "px";
        d.style.width = a.dragAreaWidth + "px";
        d.style.height = f + "px";
        d.style.display = "";
        c.removeChild(d);
        c.appendChild(d);
        e.style.left = g - a.dragAreaWidth + "px";
        e.style.top = h + "px";
        e.style.width = a.dragAreaWidth + "px";
        e.style.height =
                f + "px";
        e.style.display = "";
        c.removeChild(e);
        c.appendChild(e)
    } else
        d.style.display = "none", e.style.display = "none"
};
links.Timeline.prototype.repaintNavigation = function () {
    var a = this, b = this.options, c = this.dom, d = c.frame, e = c.navBar;
    if (!e) {
        var f = b.showButtonNew && b.editable, g = b.showNavigation && (b.zoomable || b.moveable);
        if (g || f)
            e = document.createElement("DIV"), e.style.position = "absolute", e.className = "timeline-navigation ui-widget ui-state-highlight ui-corner-all", b.groupsOnRight ? e.style.left = "10px" : e.style.right = "10px", b.axisOnTop ? e.style.bottom = "10px" : e.style.top = "10px", c.navBar = e, d.appendChild(e);
        f && (e.addButton = document.createElement("DIV"),
                e.addButton.className = "timeline-navigation-new", e.addButton.title = b.CREATE_NEW_EVENT, c = document.createElement("SPAN"), c.className = "ui-icon ui-icon-circle-plus", e.addButton.appendChild(c), links.Timeline.addEventListener(e.addButton, "mousedown", function (c) {
            links.Timeline.preventDefault(c);
            links.Timeline.stopPropagation(c);
            c = a.screenToTime(a.size.contentWidth / 2);
            b.snapEvents && a.step.snap(c);
            a.addItem({start: c, content: b.NEW, group: a.groups.length ? a.groups[0].content : void 0}, !0);
            c = a.items.length - 1;
            a.selectItem(c);
            a.applyAdd = !0;
            a.trigger("add");
            a.applyAdd ? (a.render({animate: !1}), a.selectItem(c)) : a.deleteItem(c)
        }), e.appendChild(e.addButton));
        f && g && links.Timeline.addClassName(e.addButton, "timeline-navigation-new-line");
        g && (b.zoomable && (e.zoomInButton = document.createElement("DIV"), e.zoomInButton.className = "timeline-navigation-zoom-in", e.zoomInButton.title = this.options.ZOOM_IN, f = document.createElement("SPAN"), f.className = "ui-icon ui-icon-circle-zoomin", e.zoomInButton.appendChild(f), links.Timeline.addEventListener(e.zoomInButton,
                "mousedown", function (b) {
                    links.Timeline.preventDefault(b);
                    links.Timeline.stopPropagation(b);
                    a.zoom(.4);
                    a.trigger("rangechange");
                    a.trigger("rangechanged")
                }), e.appendChild(e.zoomInButton), e.zoomOutButton = document.createElement("DIV"), e.zoomOutButton.className = "timeline-navigation-zoom-out", e.zoomOutButton.title = this.options.ZOOM_OUT, f = document.createElement("SPAN"), f.className = "ui-icon ui-icon-circle-zoomout", e.zoomOutButton.appendChild(f), links.Timeline.addEventListener(e.zoomOutButton, "mousedown",
                function (b) {
                    links.Timeline.preventDefault(b);
                    links.Timeline.stopPropagation(b);
                    a.zoom(-.4);
                    a.trigger("rangechange");
                    a.trigger("rangechanged")
                }), e.appendChild(e.zoomOutButton)), b.moveable && (e.moveLeftButton = document.createElement("DIV"), e.moveLeftButton.className = "timeline-navigation-move-left", e.moveLeftButton.title = this.options.MOVE_LEFT, f = document.createElement("SPAN"), f.className = "ui-icon ui-icon-circle-arrow-w", e.moveLeftButton.appendChild(f), links.Timeline.addEventListener(e.moveLeftButton, "mousedown",
                function (b) {
                    links.Timeline.preventDefault(b);
                    links.Timeline.stopPropagation(b);
                    a.move(-.2);
                    a.trigger("rangechange");
                    a.trigger("rangechanged")
                }), e.appendChild(e.moveLeftButton), e.moveRightButton = document.createElement("DIV"), e.moveRightButton.className = "timeline-navigation-move-right", e.moveRightButton.title = this.options.MOVE_RIGHT, f = document.createElement("SPAN"), f.className = "ui-icon ui-icon-circle-arrow-e", e.moveRightButton.appendChild(f), links.Timeline.addEventListener(e.moveRightButton, "mousedown",
                function (b) {
                    links.Timeline.preventDefault(b);
                    links.Timeline.stopPropagation(b);
                    a.move(.2);
                    a.trigger("rangechange");
                    a.trigger("rangechanged")
                }), e.appendChild(e.moveRightButton)))
    }
};
links.Timeline.prototype.setCurrentTime = function (a) {
    this.clientTimeOffset = a.valueOf() - (new Date).valueOf();
    this.repaintCurrentTime()
};
links.Timeline.prototype.getCurrentTime = function () {
    return new Date((new Date).valueOf() + this.clientTimeOffset)
};
links.Timeline.prototype.setCustomTime = function (a) {
    this.customTime = new Date(a.valueOf());
    this.repaintCustomTime()
};
links.Timeline.prototype.getCustomTime = function () {
    return new Date(this.customTime.valueOf())
};
links.Timeline.prototype.setScale = function (a, b) {
    this.step.setScale(a, b);
    this.render()
};
links.Timeline.prototype.setAutoScale = function (a) {
    this.step.setAutoScale(a);
    this.render()
};
links.Timeline.prototype.redraw = function () {
    this.setData(this.data)
};
links.Timeline.prototype.checkResize = function () {
    this.render()
};
links.Timeline.prototype.isEditable = function (a) {
    return a ? void 0 != a.editable ? a.editable : this.options.editable : !1
};
links.Timeline.prototype.recalcConversion = function () {
    this.conversion.offset = this.start.valueOf();
    this.conversion.factor = this.size.contentWidth / (this.end.valueOf() - this.start.valueOf())
};
links.Timeline.prototype.screenToTime = function (a) {
    var b = this.conversion;
    return new Date(a / b.factor + b.offset)
};
links.Timeline.prototype.timeToScreen = function (a) {
    var b = this.conversion;
    return(a.valueOf() - b.offset) * b.factor
};
links.Timeline.prototype.onTouchStart = function (a) {
    var b = this.eventParams, c = this;
    if (!b.touchDown) {
        b.touchDown = !0;
        b.zoomed = !1;
        this.onMouseDown(a);
        b.onTouchMove || (b.onTouchMove = function (a) {
            c.onTouchMove(a)
        }, links.Timeline.addEventListener(document, "touchmove", b.onTouchMove));
        b.onTouchEnd || (b.onTouchEnd = function (a) {
            c.onTouchEnd(a)
        }, links.Timeline.addEventListener(document, "touchend", b.onTouchEnd));
        var d = links.Timeline.getTarget(a), d = this.getItemIndex(d);
        b.doubleTapStartPrev = b.doubleTapStart;
        b.doubleTapStart =
                (new Date).valueOf();
        b.doubleTapItemPrev = b.doubleTapItem;
        b.doubleTapItem = d;
        links.Timeline.preventDefault(a)
    }
};
links.Timeline.prototype.onTouchMove = function (a) {
    var b = this.eventParams;
    a.scale && 1 !== a.scale && (b.zoomed = !0);
    if (!b.zoomed)
        this.onMouseMove(a);
    else if (this.options.zoomable) {
        b.zoomed = !0;
        var c = b.end.valueOf() - b.start.valueOf(), d = c / a.scale - c, c = new Date(parseInt(b.start.valueOf() - d / 2)), b = new Date(parseInt(b.end.valueOf() + d / 2));
        this.setVisibleChartRange(c, b);
        this.trigger("rangechange")
    }
    links.Timeline.preventDefault(a)
};
links.Timeline.prototype.onTouchEnd = function (a) {
    var b = this.eventParams;
    b.touchDown = !1;
    b.zoomed && this.trigger("rangechanged");
    b.onTouchMove && (links.Timeline.removeEventListener(document, "touchmove", b.onTouchMove), delete b.onTouchMove);
    b.onTouchEnd && (links.Timeline.removeEventListener(document, "touchend", b.onTouchEnd), delete b.onTouchEnd);
    this.onMouseUp(a);
    var c = (new Date).valueOf(), d = links.Timeline.getTarget(a);
    this.getItemIndex(d);
    b.doubleTapStartPrev && 500 > c - b.doubleTapStartPrev && b.doubleTapItem ==
            b.doubleTapItemPrev && (b.touchDown = !0, this.onDblClick(a), b.touchDown = !1);
    links.Timeline.preventDefault(a)
};
links.Timeline.prototype.onMouseDown = function (a) {
    a = a || window.event;
    var b = this.eventParams, c = this.options, d = this.dom;
    if ((a.which ? 1 == a.which : 1 == a.button) || b.touchDown) {
        b.mouseX = links.Timeline.getPageX(a);
        b.mouseY = links.Timeline.getPageY(a);
        b.frameLeft = links.Timeline.getAbsoluteLeft(this.dom.content);
        b.frameTop = links.Timeline.getAbsoluteTop(this.dom.content);
        b.previousLeft = 0;
        b.previousOffset = 0;
        b.moved = !1;
        b.start = new Date(this.start.valueOf());
        b.end = new Date(this.end.valueOf());
        b.target = links.Timeline.getTarget(a);
        var e = d.items && d.items.dragRight ? d.items.dragRight : void 0;
        b.itemDragLeft = b.target === (d.items && d.items.dragLeft ? d.items.dragLeft : void 0);
        b.itemDragRight = b.target === e;
        b.itemDragLeft || b.itemDragRight ? (b.itemIndex = this.selection && void 0 !== this.selection.index ? this.selection.index : void 0, delete b.clusterIndex) : (b.itemIndex = this.getItemIndex(b.target), b.clusterIndex = this.getClusterIndex(b.target));
        b.customTime = b.target === d.customTime || b.target.parentNode === d.customTime ? this.customTime : void 0;
        b.addItem =
                c.editable && a.ctrlKey;
        if (b.addItem) {
            var f = b.mouseY - b.frameTop, d = this.screenToTime(b.mouseX - b.frameLeft);
            c.snapEvents && this.step.snap(d);
            e = new Date(d.valueOf());
            c = c.NEW;
            f = this.getGroupFromHeight(f);
            this.addItem({start: d, end: e, content: c, group: this.getGroupName(f)});
            b.itemIndex = this.items.length - 1;
            delete b.clusterIndex;
            this.selectItem(b.itemIndex);
            b.itemDragRight = !0
        }
        c = this.items[b.itemIndex];
        d = this.isSelected(b.itemIndex);
        b.editItem = d && this.isEditable(c);
        b.editItem ? (b.itemStart = c.start, b.itemEnd = c.end,
                b.itemGroup = c.group, b.itemLeft = c.getLeft(this), b.itemRight = c.getRight(this)) : this.dom.frame.style.cursor = "move";
        if (!b.touchDown) {
            var g = this;
            b.onMouseMove || (b.onMouseMove = function (a) {
                g.onMouseMove(a)
            }, links.Timeline.addEventListener(document, "mousemove", b.onMouseMove));
            b.onMouseUp || (b.onMouseUp = function (a) {
                g.onMouseUp(a)
            }, links.Timeline.addEventListener(document, "mouseup", b.onMouseUp));
            links.Timeline.preventDefault(a)
        }
    }
};
links.Timeline.prototype.onMouseMove = function (a) {
    a = a || window.event;
    var b = this.eventParams, c = this.size, d = this.dom, e = this.options, f = links.Timeline.getPageX(a), g = links.Timeline.getPageY(a);
    void 0 == b.mouseX && (b.mouseX = f);
    void 0 == b.mouseY && (b.mouseY = g);
    f -= b.mouseX;
    1 <= Math.abs(f) && (b.moved = !0);
    if (b.customTime)
        b = this.timeToScreen(b.customTime) + f, this.customTime = this.screenToTime(b), this.repaintCustomTime(), this.trigger("timechange");
    else if (b.editItem) {
        var d = this.items[b.itemIndex], h, k;
        b.itemDragLeft && e.timeChangeable ?
                (h = b.itemLeft + f, k = b.itemRight, d.start = this.screenToTime(h), e.snapEvents && (this.step.snap(d.start), h = this.timeToScreen(d.start)), h > k && (h = k, d.start = this.screenToTime(h)), this.trigger("change")) : b.itemDragRight && e.timeChangeable ? (h = b.itemLeft, k = b.itemRight + f, d.end = this.screenToTime(k), e.snapEvents && (this.step.snap(d.end), k = this.timeToScreen(d.end)), k < h && (k = h, d.end = this.screenToTime(k)), this.trigger("change")) : e.timeChangeable && (h = b.itemLeft + f, d.start = this.screenToTime(h), e.snapEvents && (this.step.snap(d.start),
                h = this.timeToScreen(d.start)), d.end && (k = h + (b.itemRight - b.itemLeft), d.end = this.screenToTime(k)), this.trigger("change"));
        d.setPosition(h, k);
        c = b.itemDragLeft || b.itemDragRight;
        this.groups.length && !c ? (b = this.getGroupFromHeight(g - b.frameTop), e.groupsChangeable && d.group !== b ? (d = this.items.indexOf(d), this.changeItem(d, {group: this.getGroupName(b)})) : (this.repaintDeleteButton(), this.repaintDragAreas())) : this.render()
    } else
        e.moveable && (e = b.end.valueOf() - b.start.valueOf(), g = Math.round(-f / c.contentWidth * e), f = new Date(b.start.valueOf() +
                g), this.applyRange(f, new Date(b.end.valueOf() + g)), (f = this.start.valueOf() - f.valueOf()) && (g += f), this.recalcConversion(), f = b.previousLeft || 0, h = parseFloat(d.items.frame.style.left) || 0, f = (b.previousOffset || 0) + (h - f), c = -g / e * c.contentWidth + f, d.items.frame.style.left = c + "px", b.previousOffset = f, b.previousLeft = parseFloat(d.items.frame.style.left) || c, this.repaintCurrentTime(), this.repaintCustomTime(), this.repaintAxis(), this.trigger("rangechange"));
    links.Timeline.preventDefault(a)
};
links.Timeline.prototype.onMouseUp = function (a) {
    a = this.eventParams;
    var b = this.options;
    this.dom.frame.style.cursor = "auto";
    a.onMouseMove && (links.Timeline.removeEventListener(document, "mousemove", a.onMouseMove), delete a.onMouseMove);
    a.onMouseUp && (links.Timeline.removeEventListener(document, "mouseup", a.onMouseUp), delete a.onMouseUp);
    if (a.customTime)
        this.trigger("timechanged");
    else if (a.editItem) {
        if (b = this.items[a.itemIndex], a.moved || a.addItem)
            this.applyAdd = this.applyChange = !0, this.updateData(a.itemIndex,
                    {start: b.start, end: b.end}), this.trigger(a.addItem ? "add" : "changed"), b = this.items[a.itemIndex], a.addItem ? this.applyAdd ? this.updateData(a.itemIndex, {start: b.start, end: b.end, content: b.content, group: this.getGroupName(b.group)}) : this.deleteItem(a.itemIndex) : this.applyChange ? this.updateData(a.itemIndex, {start: b.start, end: b.end}) : (delete this.applyChange, delete this.applyAdd, b = this.items[a.itemIndex], b.start = a.itemStart, b.end = a.itemEnd, b.group = a.itemGroup, b.setPosition(a.itemLeft, a.itemRight), this.updateData(a.itemIndex,
                    {start: a.itemStart, end: a.itemEnd})), this.options.cluster && this.clusterGenerator.updateData(), this.render()
    } else
        a.moved || a.zoomed ? (this.render(), (a.moved && b.moveable || a.zoomed && b.zoomable) && this.trigger("rangechanged")) : a.target === this.dom.items.deleteButton ? this.selection && void 0 !== this.selection.index && this.confirmDeleteItem(this.selection.index) : b.selectable && (void 0 != a.itemIndex ? this.isSelected(a.itemIndex) || (this.selectItem(a.itemIndex), this.trigger("select")) : void 0 != a.clusterIndex ? (this.selectCluster(a.clusterIndex),
                this.trigger("select")) : b.unselectable && (this.unselectItem(), this.trigger("select")))
};
links.Timeline.prototype.onDblClick = function (a) {
    var b = this.eventParams, c = this.options, d = this.dom;
    a = a || window.event;
    if (void 0 != b.itemIndex)
        (b = this.items[b.itemIndex]) && this.isEditable(b) && this.trigger("edit");
    else if (c.editable) {
        b.mouseX = links.Timeline.getPageX(a);
        b.mouseY = links.Timeline.getPageY(a);
        var e = b.mouseX - links.Timeline.getAbsoluteLeft(d.content), d = b.mouseY - links.Timeline.getAbsoluteTop(d.content), e = this.screenToTime(e);
        c.snapEvents && this.step.snap(e);
        c = c.NEW;
        d = this.getGroupFromHeight(d);
        this.addItem({start: e, content: c, group: this.getGroupName(d)}, !0);
        b.itemIndex = this.items.length - 1;
        this.selectItem(b.itemIndex);
        this.applyAdd = !0;
        this.trigger("add");
        this.applyAdd ? (this.render({animate: !1}), this.selectItem(b.itemIndex)) : this.deleteItem(b.itemIndex)
    }
    links.Timeline.preventDefault(a)
};
links.Timeline.prototype.onMouseWheel = function (a) {
    if (this.options.zoomable) {
        a || (a = window.event);
        var b = 0;
        a.wheelDelta ? b = a.wheelDelta / 120 : a.detail && (b = -a.detail / 3);
        if (b) {
            if (a.shiftKey)
                this.move(-.2 * b);
            else {
                var b = b / 5, c = links.Timeline.getAbsoluteLeft(this.dom.content), d = links.Timeline.getPageX(a), c = void 0 != d && void 0 != c ? this.screenToTime(d - c) : void 0;
                this.zoom(b, c)
            }
            this.trigger("rangechange");
            this.trigger("rangechanged")
        }
        links.Timeline.preventDefault(a)
    }
};
links.Timeline.prototype.zoom = function (a, b) {
    void 0 == b && (b = new Date((this.start.valueOf() + this.end.valueOf()) / 2));
    1 <= a && (a = .9);
    -1 >= a && (a = -.9);
    0 > a && (a /= 1 + a);
    var c = new Date(this.start.valueOf() - (this.start.valueOf() - b) * a), d = new Date(this.end.valueOf() - (this.end.valueOf() - b) * a), e = d.valueOf() - c.valueOf(), f = Number(this.options.zoomMin) || 10;
    10 > f && (f = 10);
    e >= f && (this.applyRange(c, d, b), this.render({animate: this.options.animate && this.options.animateZoom}))
};
links.Timeline.prototype.move = function (a) {
    var b = this.end.valueOf() - this.start.valueOf();
    this.applyRange(new Date(this.start.valueOf() + b * a), new Date(this.end.valueOf() + b * a));
    this.render()
};
links.Timeline.prototype.applyRange = function (a, b, c) {
    a = a.valueOf();
    b = b.valueOf();
    var d = b - a, e = this.options, f = Number(e.zoomMin) || 10;
    10 > f && (f = 10);
    var g = Number(e.zoomMax) || 31536E10;
    31536E10 < g && (g = 31536E10);
    g < f && (g = f);
    var h = e.min ? e.min.valueOf() : void 0, e = e.max ? e.max.valueOf() : void 0;
    void 0 != h && void 0 != e && (h >= e && (e = h + 864E5), g > e - h && (g = e - h), f > e - h && (f = e - h));
    a >= b && (b += 864E5);
    if (d < f) {
        var f = f - d, k = c ? (c.valueOf() - a) / d : .5;
        a -= Math.round(f * k);
        b += Math.round(f * (1 - k))
    }
    d > g && (f = d - g, k = c ? (c.valueOf() - a) / d : .5, a += Math.round(f *
            k), b -= Math.round(f * (1 - k)));
    void 0 != h && (f = a - h, 0 > f && (a -= f, b -= f));
    void 0 != e && (f = e - b, 0 > f && (a += f, b += f));
    this.start = new Date(a);
    this.end = new Date(b)
};
links.Timeline.prototype.confirmDeleteItem = function (a) {
    this.applyDelete = !0;
    this.isSelected(a) || this.selectItem(a);
    this.trigger("delete");
    this.applyDelete && this.deleteItem(a);
    delete this.applyDelete
};
links.Timeline.prototype.deleteItem = function (a, b) {
    if (a >= this.items.length)
        throw"Cannot delete row, index out of range";
    this.selection && void 0 !== this.selection.index && (this.selection.index == a ? this.unselectItem() : this.selection.index > a && this.selection.index--);
    var c = this.items.splice(a, 1)[0];
    this.renderQueue.hide.push(c);
    if (this.data)
        if (google && google.visualization && this.data instanceof google.visualization.DataTable)
            this.data.removeRow(a);
        else if (links.Timeline.isArray(this.data))
            this.data.splice(a,
                    1);
        else
            throw"Cannot delete row from data, unknown data type";
    this.options.cluster && this.clusterGenerator.updateData();
    b || this.render()
};
links.Timeline.prototype.deleteAllItems = function () {
    this.unselectItem();
    this.clearItems();
    this.deleteGroups();
    if (this.data)
        if (google && google.visualization && this.data instanceof google.visualization.DataTable)
            this.data.removeRows(0, this.data.getNumberOfRows());
        else if (links.Timeline.isArray(this.data))
            this.data.splice(0, this.data.length);
        else
            throw"Cannot delete row from data, unknown data type";
    this.options.cluster && this.clusterGenerator.updateData();
    this.render()
};
links.Timeline.prototype.getGroupFromHeight = function (a) {
    var b, c, d = this.groups;
    if (d.length) {
        if (this.options.axisOnTop)
            for (b = d.length - 1; 0 <= b && !(c = d[b], a > c.top); b--)
                ;
        else
            for (b = 0; b < d.length && !(c = d[b], a > c.top); b++)
                ;
        return c
    }
};
links.Timeline.Item = function (a, b) {
    a && (this.start = a.start, this.end = a.end, this.content = a.content, this.className = a.className, this.editable = a.editable, this.group = a.group, this.type = a.type);
    this.dotHeight = this.dotWidth = this.lineWidth = this.height = this.width = this.left = this.top = 0;
    this.rendered = !1;
    if (b)
        for (var c in b)
            b.hasOwnProperty(c) && (this[c] = b[c])
};
links.Timeline.Item.prototype.reflow = function () {
    return!1
};
links.Timeline.Item.prototype.getImageUrls = function (a) {
    this.dom && links.imageloader.filterImageUrls(this.dom, a)
};
links.Timeline.Item.prototype.select = function () {
};
links.Timeline.Item.prototype.unselect = function () {
};
links.Timeline.Item.prototype.createDOM = function () {
};
links.Timeline.Item.prototype.showDOM = function (a) {
};
links.Timeline.Item.prototype.hideDOM = function (a) {
};
links.Timeline.Item.prototype.updateDOM = function () {
};
links.Timeline.Item.prototype.updatePosition = function (a) {
};
links.Timeline.Item.prototype.isRendered = function () {
    return this.rendered
};
links.Timeline.Item.prototype.isVisible = function (a, b) {
    return!1
};
links.Timeline.Item.prototype.setPosition = function (a, b) {
};
links.Timeline.Item.prototype.getLeft = function (a) {
    return 0
};
links.Timeline.Item.prototype.getRight = function (a) {
    return 0
};
links.Timeline.Item.prototype.getWidth = function (a) {
    return this.width || 0
};
links.Timeline.ItemBox = function (a, b) {
    links.Timeline.Item.call(this, a, b)
};
links.Timeline.ItemBox.prototype = new links.Timeline.Item;
links.Timeline.ItemBox.prototype.reflow = function () {
    var a = this.dom, b = a.dot.offsetHeight, c = a.dot.offsetWidth, a = a.line.offsetWidth, d = this.dotHeight != b || this.dotWidth != c || this.lineWidth != a;
    this.dotHeight = b;
    this.dotWidth = c;
    this.lineWidth = a;
    return d
};
links.Timeline.ItemBox.prototype.select = function () {
    var a = this.dom;
    links.Timeline.addClassName(a, "timeline-event-selected ui-state-active");
    links.Timeline.addClassName(a.line, "timeline-event-selected ui-state-active");
    links.Timeline.addClassName(a.dot, "timeline-event-selected ui-state-active")
};
links.Timeline.ItemBox.prototype.unselect = function () {
    var a = this.dom;
    links.Timeline.removeClassName(a, "timeline-event-selected ui-state-active");
    links.Timeline.removeClassName(a.line, "timeline-event-selected ui-state-active");
    links.Timeline.removeClassName(a.dot, "timeline-event-selected ui-state-active")
};
links.Timeline.ItemBox.prototype.createDOM = function () {
    var a = document.createElement("DIV");
    a.style.position = "absolute";
    a.style.left = this.left + "px";
    a.style.top = this.top + "px";
    var b = document.createElement("DIV");
    b.className = "timeline-event-content";
    b.innerHTML = this.content;
    a.appendChild(b);
    b = document.createElement("DIV");
    b.style.position = "absolute";
    b.style.width = "0px";
    a.line = b;
    b = document.createElement("DIV");
    b.style.position = "absolute";
    b.style.width = "0px";
    b.style.height = "0px";
    a.dot = b;
    this.dom = a;
    this.updateDOM();
    return a
};
links.Timeline.ItemBox.prototype.showDOM = function (a) {
    var b = this.dom;
    b || (b = this.createDOM());
    b.parentNode != a && (b.parentNode && this.hideDOM(), a.appendChild(b), a.insertBefore(b.line, a.firstChild), a.appendChild(b.dot), this.rendered = !0)
};
links.Timeline.ItemBox.prototype.hideDOM = function () {
    var a = this.dom;
    a && (a.parentNode && a.parentNode.removeChild(a), a.line && a.line.parentNode && a.line.parentNode.removeChild(a.line), a.dot && a.dot.parentNode && a.dot.parentNode.removeChild(a.dot), this.rendered = !1)
};
links.Timeline.ItemBox.prototype.updateDOM = function () {
    var a = this.dom;
    if (a) {
        var b = a.line, c = a.dot;
        a.firstChild.innerHTML = this.content;
        a.className = "timeline-event timeline-event-box ui-widget ui-state-default";
        b.className = "timeline-event timeline-event-line ui-widget ui-state-default";
        c.className = "timeline-event timeline-event-dot ui-widget ui-state-default";
        this.isCluster && (links.Timeline.addClassName(a, "timeline-event-cluster ui-widget-header"), links.Timeline.addClassName(b, "timeline-event-cluster ui-widget-header"),
                links.Timeline.addClassName(c, "timeline-event-cluster ui-widget-header"));
        this.className && (links.Timeline.addClassName(a, this.className), links.Timeline.addClassName(b, this.className), links.Timeline.addClassName(c, this.className))
    }
};
links.Timeline.ItemBox.prototype.updatePosition = function (a) {
    var b = this.dom;
    if (b) {
        var c = a.timeToScreen(this.start), d = a.options.axisOnTop, e = a.size.axis.top, f = a.size.axis.height;
        a = a.options.box && a.options.box.align ? a.options.box.align : void 0;
        b.style.top = this.top + "px";
        b.style.left = "right" == a ? c - this.width + "px" : "left" == a ? c + "px" : c - this.width / 2 + "px";
        a = b.line;
        b = b.dot;
        a.style.left = c - this.lineWidth / 2 + "px";
        b.style.left = c - this.dotWidth / 2 + "px";
        d ? (a.style.top = f + "px", a.style.height = Math.max(this.top - f, 0) + "px", b.style.top =
                f - this.dotHeight / 2 + "px") : (a.style.top = this.top + this.height + "px", a.style.height = Math.max(e - this.top - this.height, 0) + "px", b.style.top = e - this.dotHeight / 2 + "px")
    }
};
links.Timeline.ItemBox.prototype.isVisible = function (a, b) {
    return this.cluster ? !1 : this.start > a && this.start < b
};
links.Timeline.ItemBox.prototype.setPosition = function (a, b) {
    var c = this.dom;
    c.style.left = a - this.width / 2 + "px";
    c.line.style.left = a - this.lineWidth / 2 + "px";
    c.dot.style.left = a - this.dotWidth / 2 + "px";
    this.group && (this.top = this.group.top, c.style.top = this.top + "px")
};
links.Timeline.ItemBox.prototype.getLeft = function (a) {
    var b = a.options.box && a.options.box.align ? a.options.box.align : void 0;
    a = a.timeToScreen(this.start);
    return a = "right" == b ? a - width : a - this.width / 2
};
links.Timeline.ItemBox.prototype.getRight = function (a) {
    var b = a.options.box && a.options.box.align ? a.options.box.align : void 0;
    a = a.timeToScreen(this.start);
    return"right" == b ? a : "left" == b ? a + this.width : a + this.width / 2
};
links.Timeline.ItemRange = function (a, b) {
    links.Timeline.Item.call(this, a, b)
};
links.Timeline.ItemRange.prototype = new links.Timeline.Item;
links.Timeline.ItemRange.prototype.select = function () {
    links.Timeline.addClassName(this.dom, "timeline-event-selected ui-state-active")
};
links.Timeline.ItemRange.prototype.unselect = function () {
    links.Timeline.removeClassName(this.dom, "timeline-event-selected ui-state-active")
};
links.Timeline.ItemRange.prototype.createDOM = function () {
    var a = document.createElement("DIV");
    a.style.position = "absolute";
    var b = document.createElement("DIV");
    b.className = "timeline-event-content";
    a.appendChild(b);
    this.dom = a;
    this.updateDOM();
    return a
};
links.Timeline.ItemRange.prototype.showDOM = function (a) {
    var b = this.dom;
    b || (b = this.createDOM());
    b.parentNode != a && (b.parentNode && this.hideDOM(), a.appendChild(b), this.rendered = !0)
};
links.Timeline.ItemRange.prototype.hideDOM = function () {
    var a = this.dom;
    a && (a.parentNode && a.parentNode.removeChild(a), this.rendered = !1)
};
links.Timeline.ItemRange.prototype.updateDOM = function () {
    var a = this.dom;
    a && (a.firstChild.innerHTML = this.content, a.className = "timeline-event timeline-event-range ui-widget ui-state-default", this.isCluster && links.Timeline.addClassName(a, "timeline-event-cluster ui-widget-header"), this.className && links.Timeline.addClassName(a, this.className))
};
links.Timeline.ItemRange.prototype.updatePosition = function (a) {
    var b = this.dom;
    if (b) {
        var c = a.size.contentWidth, d = a.timeToScreen(this.start);
        a = a.timeToScreen(this.end);
        d < -c && (d = -c);
        a > 2 * c && (a = 2 * c);
        b.style.top = this.top + "px";
        b.style.left = d + "px";
        b.style.width = Math.max(a - d, 1) + "px"
    }
};
links.Timeline.ItemRange.prototype.isVisible = function (a, b) {
    return this.cluster ? !1 : this.end > a && this.start < b
};
links.Timeline.ItemRange.prototype.setPosition = function (a, b) {
    var c = this.dom;
    c.style.left = a + "px";
    c.style.width = b - a + "px";
    this.group && (this.top = this.group.top, c.style.top = this.top + "px")
};
links.Timeline.ItemRange.prototype.getLeft = function (a) {
    return a.timeToScreen(this.start)
};
links.Timeline.ItemRange.prototype.getRight = function (a) {
    return a.timeToScreen(this.end)
};
links.Timeline.ItemRange.prototype.getWidth = function (a) {
    return a.timeToScreen(this.end) - a.timeToScreen(this.start)
};
links.Timeline.ItemFloatingRange = function (a, b) {
    links.Timeline.Item.call(this, a, b)
};
links.Timeline.ItemFloatingRange.prototype = new links.Timeline.Item;
links.Timeline.ItemFloatingRange.prototype.select = function () {
    links.Timeline.addClassName(this.dom, "timeline-event-selected ui-state-active")
};
links.Timeline.ItemFloatingRange.prototype.unselect = function () {
    links.Timeline.removeClassName(this.dom, "timeline-event-selected ui-state-active")
};
links.Timeline.ItemFloatingRange.prototype.createDOM = function () {
    var a = document.createElement("DIV");
    a.style.position = "absolute";
    var b = document.createElement("DIV");
    b.className = "timeline-event-content";
    a.appendChild(b);
    this.dom = a;
    this.updateDOM();
    return a
};
links.Timeline.ItemFloatingRange.prototype.showDOM = function (a) {
    var b = this.dom;
    b || (b = this.createDOM());
    b.parentNode != a && (b.parentNode && this.hideDOM(), a.appendChild(b), this.rendered = !0)
};
links.Timeline.ItemFloatingRange.prototype.hideDOM = function () {
    var a = this.dom;
    a && (a.parentNode && a.parentNode.removeChild(a), this.rendered = !1)
};
links.Timeline.ItemFloatingRange.prototype.updateDOM = function () {
    var a = this.dom;
    a && (a.firstChild.innerHTML = this.content, a.className = "timeline-event timeline-event-range ui-widget ui-state-default", this.isCluster && links.Timeline.addClassName(a, "timeline-event-cluster ui-widget-header"), this.className && links.Timeline.addClassName(a, this.className))
};
links.Timeline.ItemFloatingRange.prototype.updatePosition = function (a) {
    var b = this.dom;
    if (b) {
        var c = a.size.contentWidth, d = this.getLeft(a);
        a = this.getRight(a);
        d < -c && (d = -c);
        a > 2 * c && (a = 2 * c);
        b.style.top = this.top + "px";
        b.style.left = d + "px";
        b.style.width = Math.max(a - d, 1) + "px"
    }
};
links.Timeline.ItemFloatingRange.prototype.isVisible = function (a, b) {
    return this.cluster ? !1 : this.end && this.start ? this.end > a && this.start < b : this.start ? this.start < b : this.end ? this.end > a : !0
};
links.Timeline.ItemFloatingRange.prototype.setPosition = function (a, b) {
    var c = this.dom;
    c.style.left = a + "px";
    c.style.width = b - a + "px";
    this.group && (this.top = this.group.top, c.style.top = this.top + "px")
};
links.Timeline.ItemFloatingRange.prototype.getLeft = function (a) {
    return this.start ? a.timeToScreen(this.start) : 0
};
links.Timeline.ItemFloatingRange.prototype.getRight = function (a) {
    return this.end ? a.timeToScreen(this.end) : a.size.contentWidth
};
links.Timeline.ItemFloatingRange.prototype.getWidth = function (a) {
    return this.getRight(a) - this.getLeft(a)
};
links.Timeline.ItemDot = function (a, b) {
    links.Timeline.Item.call(this, a, b)
};
links.Timeline.ItemDot.prototype = new links.Timeline.Item;
links.Timeline.ItemDot.prototype.reflow = function () {
    var a = this.dom, b = a.dot.offsetHeight, c = a.dot.offsetWidth, a = a.content.offsetHeight, d = this.dotHeight != b || this.dotWidth != c || this.contentHeight != a;
    this.dotHeight = b;
    this.dotWidth = c;
    this.contentHeight = a;
    return d
};
links.Timeline.ItemDot.prototype.select = function () {
    links.Timeline.addClassName(this.dom, "timeline-event-selected ui-state-active")
};
links.Timeline.ItemDot.prototype.unselect = function () {
    links.Timeline.removeClassName(this.dom, "timeline-event-selected ui-state-active")
};
links.Timeline.ItemDot.prototype.createDOM = function () {
    var a = document.createElement("DIV");
    a.style.position = "absolute";
    var b = document.createElement("DIV");
    b.className = "timeline-event-content";
    a.appendChild(b);
    var c = document.createElement("DIV");
    c.style.position = "absolute";
    c.style.width = "0px";
    c.style.height = "0px";
    a.appendChild(c);
    a.content = b;
    a.dot = c;
    this.dom = a;
    this.updateDOM();
    return a
};
links.Timeline.ItemDot.prototype.showDOM = function (a) {
    var b = this.dom;
    b || (b = this.createDOM());
    b.parentNode != a && (b.parentNode && this.hideDOM(), a.appendChild(b), this.rendered = !0)
};
links.Timeline.ItemDot.prototype.hideDOM = function () {
    var a = this.dom;
    a && (a.parentNode && a.parentNode.removeChild(a), this.rendered = !1)
};
links.Timeline.ItemDot.prototype.updateDOM = function () {
    if (this.dom) {
        var a = this.dom, b = a.dot;
        a.firstChild.innerHTML = this.content;
        a.className = "timeline-event-dot-container";
        b.className = "timeline-event timeline-event-dot ui-widget ui-state-default";
        this.isCluster && (links.Timeline.addClassName(a, "timeline-event-cluster ui-widget-header"), links.Timeline.addClassName(b, "timeline-event-cluster ui-widget-header"));
        this.className && (links.Timeline.addClassName(a, this.className), links.Timeline.addClassName(b,
                this.className))
    }
};
links.Timeline.ItemDot.prototype.updatePosition = function (a) {
    var b = this.dom;
    b && (a = a.timeToScreen(this.start), b.style.top = this.top + "px", b.style.left = a - this.dotWidth / 2 + "px", b.content.style.marginLeft = 1.5 * this.dotWidth + "px", b.dot.style.top = (this.height - this.dotHeight) / 2 + "px")
};
links.Timeline.ItemDot.prototype.isVisible = function (a, b) {
    return this.cluster ? !1 : this.start > a && this.start < b
};
links.Timeline.ItemDot.prototype.setPosition = function (a, b) {
    var c = this.dom;
    c.style.left = a - this.dotWidth / 2 + "px";
    this.group && (this.top = this.group.top, c.style.top = this.top + "px")
};
links.Timeline.ItemDot.prototype.getLeft = function (a) {
    return a.timeToScreen(this.start)
};
links.Timeline.ItemDot.prototype.getRight = function (a) {
    return a.timeToScreen(this.start) + this.width
};
links.Timeline.prototype.getItem = function (a) {
    if (a >= this.items.length)
        throw"Cannot get item, index out of range";
    var b = this.data;
    if (google && google.visualization && b instanceof google.visualization.DataTable) {
        var c = links.Timeline.mapColumnIds(b), b = {}, d;
        for (d in c)
            c.hasOwnProperty(d) && (b[d] = this.data.getValue(a, c[d]))
    } else if (links.Timeline.isArray(this.data))
        b = links.Timeline.clone(this.data[a]);
    else
        throw"Unknown data type. DataTable or Array expected.";
    a = this.items[a];
    b.start = new Date(a.start.valueOf());
    a.end && (b.end = new Date(a.end.valueOf()));
    b.content = a.content;
    a.group && (b.group = this.getGroupName(a.group));
    a.className && (b.className = a.className);
    "undefined" !== typeof a.editable && (b.editable = a.editable);
    a.type && (b.type = a.type);
    return b
};
links.Timeline.prototype.getCluster = function (a) {
    if (a >= this.clusters.length)
        throw"Cannot get cluster, index out of range";
    var b = {}, c = this.clusters[a];
    a = c.items;
    b.start = new Date(c.start.valueOf());
    c.type && (b.type = c.type);
    b.items = [];
    for (c = 0; c < a.length; c++)
        for (var d = 0; d < this.items.length; d++)
            if (this.items[d] == a[c]) {
                b.items.push(this.getItem(d));
                break
            }
    return b
};
links.Timeline.prototype.addItem = function (a, b) {
    this.addItems([a], b)
};
links.Timeline.prototype.addItems = function (a, b) {
    var c = this, d = this.items;
    a.forEach(function (a) {
        var b = d.length;
        d.push(c.createItem(a));
        c.updateData(b, a)
    });
    this.options.cluster && this.clusterGenerator.updateData();
    b || this.render({animate: !1})
};
links.Timeline.prototype.createItem = function (a) {
    var b = a.type || (a.end ? "range" : this.options.style), c = links.Timeline.clone(a);
    c.type = b;
    c.group = this.getGroup(a.group);
    a = this.options;
    a = a.axisOnTop ? this.size.axis.height + a.eventMarginAxis + a.eventMargin / 2 : this.size.contentHeight - a.eventMarginAxis - a.eventMargin / 2;
    if (b in this.itemTypes)
        return new this.itemTypes[b](c, {top: a});
    console.log('ERROR: Unknown event type "' + b + '"');
    return new links.Timeline.Item(c, {top: a})
};
links.Timeline.prototype.changeItem = function (a, b, c) {
    var d = this.items[a];
    if (!d)
        throw"Cannot change item, index out of range";
    var e = this.createItem({start: b.hasOwnProperty("start") ? b.start : d.start, end: b.hasOwnProperty("end") ? b.end : d.end, content: b.hasOwnProperty("content") ? b.content : d.content, group: b.hasOwnProperty("group") ? b.group : this.getGroupName(d.group), className: b.hasOwnProperty("className") ? b.className : d.className, editable: b.hasOwnProperty("editable") ? b.editable : d.editable, type: b.hasOwnProperty("type") ?
                b.type : b.end ? "range" : "box"});
    this.items[a] = e;
    this.renderQueue.hide.push(d);
    this.renderQueue.show.push(e);
    this.updateData(a, b);
    this.options.cluster && this.clusterGenerator.updateData();
    c || (this.render({animate: !1}), this.selection && this.selection.index == a && e.select())
};
links.Timeline.prototype.deleteGroups = function () {
    this.groups = [];
    this.groupIndexes = {}
};
links.Timeline.prototype.getGroup = function (a) {
    var b = this.groups, c = this.groupIndexes, d = void 0, d = c[a];
    if (void 0 == d && void 0 != a) {
        d = {content: a, labelTop: 0, lineTop: 0};
        b.push(d);
        1 == this.options.groupsOrder ? b = b.sort(function (a, b) {
            return a.content > b.content ? 1 : a.content < b.content ? -1 : 0
        }) : "function" == typeof this.options.groupsOrder && (b = b.sort(this.options.groupsOrder));
        a = 0;
        for (var e = b.length; a < e; a++)
            c[b[a].content] = a
    } else
        d = b[d];
    return d
};
links.Timeline.prototype.getGroupName = function (a) {
    return a ? a.content : void 0
};
links.Timeline.prototype.cancelChange = function () {
    this.applyChange = !1
};
links.Timeline.prototype.cancelDelete = function () {
    this.applyDelete = !1
};
links.Timeline.prototype.cancelAdd = function () {
    this.applyAdd = !1
};
links.Timeline.prototype.setSelection = function (a) {
    if (void 0 != a && 0 < a.length) {
        if (void 0 != a[0].row) {
            var b = a[0].row;
            if (this.items[b])
                return a = this.items[b], this.selectItem(b), b = a.start, a = a.end, a = void 0 != a ? (a.valueOf() + b.valueOf()) / 2 : b.valueOf(), b = this.end.valueOf() - this.start.valueOf(), this.setVisibleChartRange(new Date(a - b / 2), new Date(a + b / 2)), !0
        }
    } else
        this.unselectItem();
    return!1
};
links.Timeline.prototype.getSelection = function () {
    var a = [];
    this.selection && (void 0 !== this.selection.index ? a.push({row: this.selection.index}) : a.push({cluster: this.selection.cluster}));
    return a
};
links.Timeline.prototype.selectItem = function (a) {
    this.unselectItem();
    this.selection = void 0;
    if (void 0 != this.items[a]) {
        var b = this.items[a];
        this.selection = {index: a};
        b && b.dom && (this.isEditable(b) && (b.dom.style.cursor = "move"), b.select());
        this.repaintDeleteButton();
        this.repaintDragAreas()
    }
};
links.Timeline.prototype.selectCluster = function (a) {
    this.unselectItem();
    this.selection = void 0;
    void 0 != this.clusters[a] && (this.selection = {cluster: a}, this.repaintDeleteButton(), this.repaintDragAreas())
};
links.Timeline.prototype.isSelected = function (a) {
    return this.selection && this.selection.index == a
};
links.Timeline.prototype.unselectItem = function () {
    if (this.selection && void 0 !== this.selection.index) {
        var a = this.items[this.selection.index];
        a && a.dom && (a.dom.style.cursor = "", a.unselect());
        this.selection = void 0;
        this.repaintDeleteButton();
        this.repaintDragAreas()
    }
};
links.Timeline.prototype.stackItems = function (a) {
    void 0 == a && (a = !1);
    var b = this.stack;
    b || (this.stack = b = {});
    b.sortedItems = this.stackOrder(this.renderedItems);
    b.finalItems = this.stackCalculateFinal(b.sortedItems);
    if (a || b.timer) {
        var c = this, d = function () {
            var a = c.stackMoveOneStep(b.sortedItems, b.finalItems);
            c.repaint();
            a ? delete b.timer : b.timer = setTimeout(d, 30)
        };
        b.timer || (b.timer = setTimeout(d, 30))
    } else
        this.stackMoveToFinal(b.sortedItems, b.finalItems)
};
links.Timeline.prototype.stackCancelAnimation = function () {
    this.stack && this.stack.timer && (clearTimeout(this.stack.timer), delete this.stack.timer)
};
links.Timeline.prototype.getItemsByGroup = function (a) {
    for (var b = {}, c = 0; c < a.length; ++c) {
        var d = a[c], e = "undefined";
        d.group && (e = d.group.content ? d.group.content : d.group);
        b[e] || (b[e] = []);
        b[e].push(d)
    }
    return b
};
links.Timeline.prototype.stackOrder = function (a) {
    a = a.concat([]);
    a.sort(this.options.customStackOrder && "function" === typeof this.options.customStackOrder ? this.options.customStackOrder : function (a, c) {
        return!(a instanceof links.Timeline.ItemRange || a instanceof links.Timeline.ItemFloatingRange) || c instanceof links.Timeline.ItemRange || c instanceof links.Timeline.ItemFloatingRange ? a instanceof links.Timeline.ItemRange || a instanceof links.Timeline.ItemFloatingRange || !(c instanceof links.Timeline.ItemRange ||
                c instanceof links.Timeline.ItemFloatingRange) ? a.left - c.left : 1 : -1
    });
    return a
};
links.Timeline.prototype.stackCalculateFinal = function (a) {
    var b = this.size, c = this.options, d = c.axisOnTop, e = c.eventMargin, f = c.eventMarginAxis, b = d ? b.axis.height + f + e / 2 : b.contentHeight - f - e / 2, g = [];
    a = this.getItemsByGroup(a);
    for (j = 0; j < this.groups.length; ++j) {
        var h = this.groups[j];
        a[h.content] ? (f = this.finalItemsPosition(a[h.content], b, h), f.forEach(function (a) {
            g.push(a)
        }), b = d ? b + (h.itemsHeight + e) : b - (h.itemsHeight + e)) : b = d ? b + (c.groupMinHeight + e) : b - (c.groupMinHeight + e)
    }
    a.undefined && (f = this.finalItemsPosition(a.undefined,
            b), f.forEach(function (a) {
        g.push(a)
    }));
    return g
};
links.Timeline.prototype.finalItemsPosition = function (a, b, c) {
    var d, e = this.options, f = e.axisOnTop, e = e.eventMargin, g;
    g = this.initialItemsPosition(a, b);
    a = 0;
    for (d = g.length; a < d; a++) {
        var h = g[a], k = null;
        if (this.options.stackEvents) {
            do
                k = this.stackItemsCheckOverlap(g, a, 0, a - 1), null != k && (h.top = f ? k.top + k.height + e : k.top - h.height - e, h.bottom = h.top + h.height);
            while (k)
        }
        c && (c.itemsHeight = f ? c.itemsHeight ? Math.max(c.itemsHeight, h.bottom - b) : h.height + e : c.itemsHeight ? Math.max(c.itemsHeight, b - h.top) : h.height + e)
    }
    return g
};
links.Timeline.prototype.initialItemsPosition = function (a, b) {
    for (var c = this.options.axisOnTop, d = [], e = 0, f = a.length; e < f; ++e) {
        var g = a[e], h, k = g.height;
        h = g.getWidth(this);
        var l = g.getRight(this), n = l - h;
        h = c ? b : b - k;
        d.push({left: n, top: h, right: l, bottom: h + k, height: k, item: g})
    }
    return d
};
links.Timeline.prototype.stackMoveOneStep = function (a, b) {
    for (var c = !0, d = 0, e = b.length; d < e; d++) {
        var f = b[d], g = f.item, h = parseInt(g.top), k = parseInt(f.top), l = k - h;
        if (l) {
            var n = k == h ? 0 : k > h ? 1 : -1;
            4 < Math.abs(l) && (n = l / 4);
            h = parseInt(h + n);
            h != k && (c = !1);
            g.top = h;
            g.bottom = g.top + g.height
        } else
            g.top = f.top, g.bottom = f.bottom;
        g.left = f.left;
        g.right = f.right
    }
    return c
};
links.Timeline.prototype.stackMoveToFinal = function (a, b) {
    for (var c = 0, d = b.length; c < d; c++) {
        var e = b[c], f = e.item;
        f.left = e.left;
        f.top = e.top;
        f.right = e.right;
        f.bottom = e.bottom
    }
};
links.Timeline.prototype.stackItemsCheckOverlap = function (a, b, c, d) {
    for (var e = this.options.eventMargin, f = this.collision, g = a[b]; d >= c; d--) {
        var h = a[d];
        if (f(g, h, e) && d != b)
            return h
    }
};
links.Timeline.prototype.collision = function (a, b, c) {
    void 0 == c && (c = 0);
    return a.left - c < b.right && a.right + c > b.left && a.top - c < b.bottom && a.bottom + c > b.top
};
links.Timeline.prototype.trigger = function (a) {
    var b = null;
    switch (a) {
        case "rangechange":
        case "rangechanged":
            b = {start: new Date(this.start.valueOf()), end: new Date(this.end.valueOf())};
            break;
        case "timechange":
        case "timechanged":
            b = {time: new Date(this.customTime.valueOf())}
    }
    links.events.trigger(this, a, b);
    google && google.visualization && google.visualization.events.trigger(this, a, b)
};
links.Timeline.prototype.clusterItems = function () {
    if (this.options.cluster) {
        var a = this.clusterGenerator.getClusters(this.conversion.factor, this.options.clusterMaxItems);
        if (this.clusters != a) {
            var b = this.renderQueue;
            this.clusters && this.clusters.forEach(function (a) {
                b.hide.push(a);
                a.items.forEach(function (a) {
                    a.cluster = void 0
                })
            });
            a.forEach(function (a) {
                a.items.forEach(function (b) {
                    b.cluster = a
                })
            });
            this.clusters = a
        }
    }
};
links.Timeline.prototype.filterItems = function () {
    function a(a) {
        a.forEach(function (a) {
            var c = a.rendered, f = a.isVisible(d, e);
            c != f && (c && b.hide.push(a), f && -1 == b.show.indexOf(a) && b.show.push(a))
        })
    }
    var b = this.renderQueue, c = this.end - this.start, d = new Date(this.start.valueOf() - c), e = new Date(this.end.valueOf() + c);
    a(this.items);
    this.clusters && a(this.clusters)
};
links.Timeline.ClusterGenerator = function (a) {
    this.timeline = a;
    this.clear()
};
links.Timeline.ClusterGenerator.prototype.clear = function () {
    this.items = [];
    this.groups = {};
    this.clearCache()
};
links.Timeline.ClusterGenerator.prototype.clearCache = function () {
    this.cache = {};
    this.cacheLevel = -1;
    this.cache[this.cacheLevel] = []
};
links.Timeline.ClusterGenerator.prototype.setData = function (a, b) {
    this.items = a || [];
    this.applyOnChangedLevel = this.dataChanged = !0;
    b && b.applyOnChangedLevel && (this.applyOnChangedLevel = b.applyOnChangedLevel)
};
links.Timeline.ClusterGenerator.prototype.updateData = function () {
    this.dataChanged = !0;
    this.applyOnChangedLevel = !1
};
links.Timeline.ClusterGenerator.prototype.filterData = function () {
    var a = this.items || [], b = {};
    this.groups = b;
    a.forEach(function (a) {
        var c = a.group ? a.group.content : "", f = b[c];
        f || (f = [], b[c] = f);
        f.push(a);
        a.start && (a.center = a.end ? (a.start.valueOf() + a.end.valueOf()) / 2 : a.start.valueOf())
    });
    for (var c in b)
        b.hasOwnProperty(c) && b[c].sort(function (a, b) {
            return a.center - b.center
        });
    this.dataChanged = !1
};
links.Timeline.ClusterGenerator.prototype.getClusters = function (a, b) {
    var c = -1, d = 0;
    0 < a && (c = Math.round(Math.log(100 / a) / Math.log(2)), d = Math.pow(2, c));
    if (this.dataChanged) {
        var e = c != this.cacheLevel;
        if (this.applyOnChangedLevel ? e : 1)
            this.clearCache(), this.filterData()
    }
    this.cacheLevel = c;
    e = this.cache[c];
    if (!e) {
        var e = [], f;
        for (f in this.groups)
            if (this.groups.hasOwnProperty(f))
                for (var g = this.groups[f], h = g.length, k = 0; k < h; ) {
                    for (var l = g[k], n = 1, m = k - 1; 0 <= m && l.center - g[m].center < d / 2; )
                        g[m].cluster || n++, m--;
                    for (m = k + 1; m <
                            g.length && g[m].center - l.center < d / 2; )
                        n++, m++;
                    for (m = e.length - 1; 0 <= m && l.center - e[m].center < d / 2; )
                        l.group == e[m].group && n++, m--;
                    if (n > b) {
                        for (var n = n - b + 1, m = [], v = void 0, t = void 0, q = void 0, r = !1, p = 0, x = k; m.length < n && x < g.length; ) {
                            var u = g[x], y = u.start.valueOf(), z = u.end ? u.end.valueOf() : u.start.valueOf();
                            m.push(u);
                            v = p ? p / (p + 1) * v + 1 / (p + 1) * u.center : u.center;
                            t = void 0 != t ? Math.min(t, y) : y;
                            q = void 0 != q ? Math.max(q, z) : z;
                            r = r || u instanceof links.Timeline.ItemRange || u instanceof links.Timeline.ItemFloatingRange;
                            p++;
                            x++
                        }
                        var w, p =
                                '\x3cdiv title\x3d"' + ("Cluster containing " + p + " events. Zoom in to see the individual events.") + '"\x3e' + p + " events\x3c/div\x3e", l = l.group ? l.group.content : void 0;
                        w = r ? this.timeline.createItem({start: new Date(t), end: new Date(q), content: p, group: l}) : this.timeline.createItem({start: new Date(v), content: p, group: l});
                        w.isCluster = !0;
                        w.items = m;
                        w.items.forEach(function (a) {
                            a.cluster = w
                        });
                        e.push(w);
                        k += n
                    } else
                        delete l.cluster, k += 1
                }
        this.cache[c] = e
    }
    return e
};
links.events = links.events || {listeners: [], indexOf: function (a) {
        for (var b = this.listeners, c = 0, d = this.listeners.length; c < d; c++) {
            var e = b[c];
            if (e && e.object == a)
                return c
        }
        return-1
    }, addListener: function (a, b, c) {
        var d = this.indexOf(a), d = this.listeners[d];
        d || (d = {object: a, events: {}}, this.listeners.push(d));
        a = d.events[b];
        a || (a = [], d.events[b] = a);
        -1 == a.indexOf(c) && a.push(c)
    }, removeListener: function (a, b, c) {
        a = this.indexOf(a);
        var d = this.listeners[a];
        if (d) {
            var e = d.events[b];
            e && (a = e.indexOf(c), -1 != a && e.splice(a, 1), 0 == e.length &&
                    delete d.events[b]);
            b = 0;
            c = d.events;
            for (var f in c)
                c.hasOwnProperty(f) && b++;
            0 == b && delete this.listeners[a]
        }
    }, removeAllListeners: function () {
        this.listeners = []
    }, trigger: function (a, b, c) {
        a = this.indexOf(a);
        if (a = this.listeners[a])
            if (b = a.events[b]) {
                a = 0;
                for (var d = b.length; a < d; a++)
                    b[a](c)
            }
    }};
links.Timeline.StepDate = function (a, b, c) {
    this.current = new Date;
    this._start = new Date;
    this._end = new Date;
    this.autoScale = !0;
    this.scale = links.Timeline.StepDate.SCALE.DAY;
    this.step = 1;
    this.setRange(a, b, c)
};
links.Timeline.StepDate.SCALE = {MILLISECOND: 1, SECOND: 2, MINUTE: 3, HOUR: 4, DAY: 5, WEEKDAY: 6, MONTH: 7, YEAR: 8};
links.Timeline.StepDate.prototype.setRange = function (a, b, c) {
    a instanceof Date && b instanceof Date && (this._start = void 0 != a ? new Date(a.valueOf()) : new Date, this._end = void 0 != b ? new Date(b.valueOf()) : new Date, this.autoScale && this.setMinimumStep(c))
};
links.Timeline.StepDate.prototype.start = function () {
    this.current = new Date(this._start.valueOf());
    this.roundToMinor()
};
links.Timeline.StepDate.prototype.roundToMinor = function () {
    switch (this.scale) {
        case links.Timeline.StepDate.SCALE.YEAR:
            this.current.setFullYear(this.step * Math.floor(this.current.getFullYear() / this.step)), this.current.setMonth(0);
        case links.Timeline.StepDate.SCALE.MONTH:
            this.current.setDate(1);
        case links.Timeline.StepDate.SCALE.DAY:
        case links.Timeline.StepDate.SCALE.WEEKDAY:
            this.current.setHours(0);
        case links.Timeline.StepDate.SCALE.HOUR:
            this.current.setMinutes(0);
        case links.Timeline.StepDate.SCALE.MINUTE:
            this.current.setSeconds(0);
        case links.Timeline.StepDate.SCALE.SECOND:
            this.current.setMilliseconds(0)
    }
    if (1 != this.step)
        switch (this.scale) {
            case links.Timeline.StepDate.SCALE.MILLISECOND:
                this.current.setMilliseconds(this.current.getMilliseconds() - this.current.getMilliseconds() % this.step);
                break;
            case links.Timeline.StepDate.SCALE.SECOND:
                this.current.setSeconds(this.current.getSeconds() - this.current.getSeconds() % this.step);
                break;
            case links.Timeline.StepDate.SCALE.MINUTE:
                this.current.setMinutes(this.current.getMinutes() - this.current.getMinutes() %
                        this.step);
                break;
            case links.Timeline.StepDate.SCALE.HOUR:
                this.current.setHours(this.current.getHours() - this.current.getHours() % this.step);
                break;
            case links.Timeline.StepDate.SCALE.WEEKDAY:
            case links.Timeline.StepDate.SCALE.DAY:
                this.current.setDate(this.current.getDate() - 1 - (this.current.getDate() - 1) % this.step + 1);
                break;
            case links.Timeline.StepDate.SCALE.MONTH:
                this.current.setMonth(this.current.getMonth() - this.current.getMonth() % this.step);
                break;
            case links.Timeline.StepDate.SCALE.YEAR:
                this.current.setFullYear(this.current.getFullYear() -
                        this.current.getFullYear() % this.step)
            }
};
links.Timeline.StepDate.prototype.end = function () {
    return this.current.valueOf() > this._end.valueOf()
};
links.Timeline.StepDate.prototype.next = function () {
    var a = this.current.valueOf();
    if (6 > this.current.getMonth())
        switch (this.scale) {
            case links.Timeline.StepDate.SCALE.MILLISECOND:
                this.current = new Date(this.current.valueOf() + this.step);
                break;
            case links.Timeline.StepDate.SCALE.SECOND:
                this.current = new Date(this.current.valueOf() + 1E3 * this.step);
                break;
            case links.Timeline.StepDate.SCALE.MINUTE:
                this.current = new Date(this.current.valueOf() + 6E4 * this.step);
                break;
            case links.Timeline.StepDate.SCALE.HOUR:
                this.current =
                        new Date(this.current.valueOf() + 36E5 * this.step);
                var b = this.current.getHours();
                this.current.setHours(b - b % this.step);
                break;
            case links.Timeline.StepDate.SCALE.WEEKDAY:
            case links.Timeline.StepDate.SCALE.DAY:
                this.current.setDate(this.current.getDate() + this.step);
                break;
            case links.Timeline.StepDate.SCALE.MONTH:
                this.current.setMonth(this.current.getMonth() + this.step);
                break;
            case links.Timeline.StepDate.SCALE.YEAR:
                this.current.setFullYear(this.current.getFullYear() + this.step)
        }
    else
        switch (this.scale) {
            case links.Timeline.StepDate.SCALE.MILLISECOND:
                this.current =
                        new Date(this.current.valueOf() + this.step);
                break;
            case links.Timeline.StepDate.SCALE.SECOND:
                this.current.setSeconds(this.current.getSeconds() + this.step);
                break;
            case links.Timeline.StepDate.SCALE.MINUTE:
                this.current.setMinutes(this.current.getMinutes() + this.step);
                break;
            case links.Timeline.StepDate.SCALE.HOUR:
                this.current.setHours(this.current.getHours() + this.step);
                break;
            case links.Timeline.StepDate.SCALE.WEEKDAY:
            case links.Timeline.StepDate.SCALE.DAY:
                this.current.setDate(this.current.getDate() + this.step);
                break;
            case links.Timeline.StepDate.SCALE.MONTH:
                this.current.setMonth(this.current.getMonth() + this.step);
                break;
            case links.Timeline.StepDate.SCALE.YEAR:
                this.current.setFullYear(this.current.getFullYear() + this.step)
        }
    if (1 != this.step)
        switch (this.scale) {
            case links.Timeline.StepDate.SCALE.MILLISECOND:
                this.current.getMilliseconds() < this.step && this.current.setMilliseconds(0);
                break;
            case links.Timeline.StepDate.SCALE.SECOND:
                this.current.getSeconds() < this.step && this.current.setSeconds(0);
                break;
            case links.Timeline.StepDate.SCALE.MINUTE:
                this.current.getMinutes() <
                        this.step && this.current.setMinutes(0);
                break;
            case links.Timeline.StepDate.SCALE.HOUR:
                this.current.getHours() < this.step && this.current.setHours(0);
                break;
            case links.Timeline.StepDate.SCALE.WEEKDAY:
            case links.Timeline.StepDate.SCALE.DAY:
                this.current.getDate() < this.step + 1 && this.current.setDate(1);
                break;
            case links.Timeline.StepDate.SCALE.MONTH:
                this.current.getMonth() < this.step && this.current.setMonth(0)
        }
    this.current.valueOf() == a && (this.current = new Date(this._end.valueOf()))
};
links.Timeline.StepDate.prototype.getCurrent = function () {
    return this.current
};
links.Timeline.StepDate.prototype.setScale = function (a, b) {
    this.scale = a;
    0 < b && (this.step = b);
    this.autoScale = !1
};
links.Timeline.StepDate.prototype.setAutoScale = function (a) {
    this.autoScale = a
};
links.Timeline.StepDate.prototype.setMinimumStep = function (a) {
    void 0 != a && (31104E9 > a && (this.scale = links.Timeline.StepDate.SCALE.YEAR, this.step = 1E3), 15552E9 > a && (this.scale = links.Timeline.StepDate.SCALE.YEAR, this.step = 500), 31104E8 > a && (this.scale = links.Timeline.StepDate.SCALE.YEAR, this.step = 100), 15552E8 > a && (this.scale = links.Timeline.StepDate.SCALE.YEAR, this.step = 50), 31104E7 > a && (this.scale = links.Timeline.StepDate.SCALE.YEAR, this.step = 10), 15552E7 > a && (this.scale = links.Timeline.StepDate.SCALE.YEAR, this.step =
            5), 31104E6 > a && (this.scale = links.Timeline.StepDate.SCALE.YEAR, this.step = 1), 7776E6 > a && (this.scale = links.Timeline.StepDate.SCALE.MONTH, this.step = 3), 2592E6 > a && (this.scale = links.Timeline.StepDate.SCALE.MONTH, this.step = 1), 432E6 > a && (this.scale = links.Timeline.StepDate.SCALE.DAY, this.step = 5), 1728E5 > a && (this.scale = links.Timeline.StepDate.SCALE.DAY, this.step = 2), 864E5 > a && (this.scale = links.Timeline.StepDate.SCALE.DAY, this.step = 1), 432E5 > a && (this.scale = links.Timeline.StepDate.SCALE.WEEKDAY, this.step = 1), 144E5 > a &&
            (this.scale = links.Timeline.StepDate.SCALE.HOUR, this.step = 4), 36E5 > a && (this.scale = links.Timeline.StepDate.SCALE.HOUR, this.step = 1), 9E5 > a && (this.scale = links.Timeline.StepDate.SCALE.MINUTE, this.step = 15), 6E5 > a && (this.scale = links.Timeline.StepDate.SCALE.MINUTE, this.step = 10), 3E5 > a && (this.scale = links.Timeline.StepDate.SCALE.MINUTE, this.step = 5), 6E4 > a && (this.scale = links.Timeline.StepDate.SCALE.MINUTE, this.step = 1), 15E3 > a && (this.scale = links.Timeline.StepDate.SCALE.SECOND, this.step = 15), 1E4 > a && (this.scale = links.Timeline.StepDate.SCALE.SECOND,
            this.step = 10), 5E3 > a && (this.scale = links.Timeline.StepDate.SCALE.SECOND, this.step = 5), 1E3 > a && (this.scale = links.Timeline.StepDate.SCALE.SECOND, this.step = 1), 200 > a && (this.scale = links.Timeline.StepDate.SCALE.MILLISECOND, this.step = 200), 100 > a && (this.scale = links.Timeline.StepDate.SCALE.MILLISECOND, this.step = 100), 50 > a && (this.scale = links.Timeline.StepDate.SCALE.MILLISECOND, this.step = 50), 10 > a && (this.scale = links.Timeline.StepDate.SCALE.MILLISECOND, this.step = 10), 5 > a && (this.scale = links.Timeline.StepDate.SCALE.MILLISECOND,
            this.step = 5), 1 > a && (this.scale = links.Timeline.StepDate.SCALE.MILLISECOND, this.step = 1))
};
links.Timeline.StepDate.prototype.snap = function (a) {
    if (this.scale == links.Timeline.StepDate.SCALE.YEAR) {
        var b = a.getFullYear() + Math.round(a.getMonth() / 12);
        a.setFullYear(Math.round(b / this.step) * this.step);
        a.setMonth(0);
        a.setDate(0);
        a.setHours(0);
        a.setMinutes(0);
        a.setSeconds(0);
        a.setMilliseconds(0)
    } else if (this.scale == links.Timeline.StepDate.SCALE.MONTH)
        15 < a.getDate() ? (a.setDate(1), a.setMonth(a.getMonth() + 1)) : a.setDate(1), a.setHours(0), a.setMinutes(0), a.setSeconds(0), a.setMilliseconds(0);
    else if (this.scale ==
            links.Timeline.StepDate.SCALE.DAY || this.scale == links.Timeline.StepDate.SCALE.WEEKDAY) {
        switch (this.step) {
            case 5:
            case 2:
                a.setHours(24 * Math.round(a.getHours() / 24));
                break;
            default:
                a.setHours(12 * Math.round(a.getHours() / 12))
        }
        a.setMinutes(0);
        a.setSeconds(0);
        a.setMilliseconds(0)
    } else if (this.scale == links.Timeline.StepDate.SCALE.HOUR) {
        switch (this.step) {
            case 4:
                a.setMinutes(60 * Math.round(a.getMinutes() / 60));
                break;
            default:
                a.setMinutes(30 * Math.round(a.getMinutes() / 30))
        }
        a.setSeconds(0);
        a.setMilliseconds(0)
    } else if (this.scale ==
            links.Timeline.StepDate.SCALE.MINUTE) {
        switch (this.step) {
            case 15:
            case 10:
                a.setMinutes(5 * Math.round(a.getMinutes() / 5));
                a.setSeconds(0);
                break;
            case 5:
                a.setSeconds(60 * Math.round(a.getSeconds() / 60));
                break;
            default:
                a.setSeconds(30 * Math.round(a.getSeconds() / 30))
        }
        a.setMilliseconds(0)
    } else if (this.scale == links.Timeline.StepDate.SCALE.SECOND)
        switch (this.step) {
            case 15:
            case 10:
                a.setSeconds(5 * Math.round(a.getSeconds() / 5));
                a.setMilliseconds(0);
                break;
            case 5:
                a.setMilliseconds(1E3 * Math.round(a.getMilliseconds() / 1E3));
                break;
            default:
                a.setMilliseconds(500 * Math.round(a.getMilliseconds() / 500))
        }
    else
        this.scale == links.Timeline.StepDate.SCALE.MILLISECOND && (b = 5 < this.step ? this.step / 2 : 1, a.setMilliseconds(Math.round(a.getMilliseconds() / b) * b))
};
links.Timeline.StepDate.prototype.isMajor = function () {
    switch (this.scale) {
        case links.Timeline.StepDate.SCALE.MILLISECOND:
            return 0 == this.current.getMilliseconds();
        case links.Timeline.StepDate.SCALE.SECOND:
            return 0 == this.current.getSeconds();
        case links.Timeline.StepDate.SCALE.MINUTE:
            return 0 == this.current.getHours() && 0 == this.current.getMinutes();
        case links.Timeline.StepDate.SCALE.HOUR:
            return 0 == this.current.getHours();
        case links.Timeline.StepDate.SCALE.WEEKDAY:
        case links.Timeline.StepDate.SCALE.DAY:
            return 1 ==
                    this.current.getDate();
        case links.Timeline.StepDate.SCALE.MONTH:
            return 0 == this.current.getMonth();
        case links.Timeline.StepDate.SCALE.YEAR:
            return!1;
        default:
            return!1
        }
};
links.Timeline.StepDate.prototype.getLabelMinor = function (a, b) {
    void 0 == b && (b = this.current);
    switch (this.scale) {
        case links.Timeline.StepDate.SCALE.MILLISECOND:
            return String(b.getMilliseconds());
        case links.Timeline.StepDate.SCALE.SECOND:
            return String(b.getSeconds());
        case links.Timeline.StepDate.SCALE.MINUTE:
            return this.addZeros(b.getHours(), 2) + ":" + this.addZeros(b.getMinutes(), 2);
        case links.Timeline.StepDate.SCALE.HOUR:
            return this.addZeros(b.getHours(), 2) + ":" + this.addZeros(b.getMinutes(), 2);
        case links.Timeline.StepDate.SCALE.WEEKDAY:
            return a.DAYS_SHORT[b.getDay()] +
                    " " + b.getDate();
        case links.Timeline.StepDate.SCALE.DAY:
            return String(b.getDate());
        case links.Timeline.StepDate.SCALE.MONTH:
            return a.MONTHS_SHORT[b.getMonth()];
        case links.Timeline.StepDate.SCALE.YEAR:
            return String(b.getFullYear());
        default:
            return""
        }
};
links.Timeline.StepDate.prototype.getLabelMajor = function (a, b) {
    void 0 == b && (b = this.current);
    switch (this.scale) {
        case links.Timeline.StepDate.SCALE.MILLISECOND:
            return this.addZeros(b.getHours(), 2) + ":" + this.addZeros(b.getMinutes(), 2) + ":" + this.addZeros(b.getSeconds(), 2);
        case links.Timeline.StepDate.SCALE.SECOND:
            return b.getDate() + " " + a.MONTHS[b.getMonth()] + " " + this.addZeros(b.getHours(), 2) + ":" + this.addZeros(b.getMinutes(), 2);
        case links.Timeline.StepDate.SCALE.MINUTE:
            return a.DAYS[b.getDay()] + " " + b.getDate() +
                    " " + a.MONTHS[b.getMonth()] + " " + b.getFullYear();
        case links.Timeline.StepDate.SCALE.HOUR:
            return a.DAYS[b.getDay()] + " " + b.getDate() + " " + a.MONTHS[b.getMonth()] + " " + b.getFullYear();
        case links.Timeline.StepDate.SCALE.WEEKDAY:
        case links.Timeline.StepDate.SCALE.DAY:
            return a.MONTHS[b.getMonth()] + " " + b.getFullYear();
        case links.Timeline.StepDate.SCALE.MONTH:
            return String(b.getFullYear());
        default:
            return""
        }
};
links.Timeline.StepDate.prototype.addZeros = function (a, b) {
    for (var c = "" + a; c.length < b; )
        c = "0" + c;
    return c
};
links.imageloader = function () {
    function a(a) {
        if (1 == e[a])
            return!0;
        var b = new Image;
        b.src = a;
        return b.complete ? !0 : !1
    }
    function b(a) {
        return void 0 != f[a]
    }
    function c(c, d, k) {
        void 0 == k && (k = !0);
        if (a(c))
            k && d(c);
        else if (!b(c) || k) {
            var l = f[c];
            l || (k = new Image, k.src = c, l = [], f[c] = l, k.onload = function (a) {
                e[c] = !0;
                delete f[c];
                for (a = 0; a < l.length; a++)
                    l[a](c)
            });
            -1 == l.indexOf(d) && l.push(d)
        }
    }
    function d(a, b) {
        for (var c = a.firstChild; c; ) {
            if ("IMG" == c.tagName) {
                var e = c.src;
                -1 == b.indexOf(e) && b.push(e)
            }
            d(c, b);
            c = c.nextSibling
        }
    }
    var e = {},
            f = {};
    return{isLoaded: a, isLoading: b, load: c, loadAll: function (b, d, e) {
            var f = [];
            b.forEach(function (b) {
                a(b) || f.push(b)
            });
            if (f.length) {
                var n = f.length;
                f.forEach(function (a) {
                    c(a, function () {
                        n--;
                        0 == n && d()
                    }, e)
                })
            } else
                e && d()
        }, filterImageUrls: d}
}();
links.Timeline.addEventListener = function (a, b, c, d) {
    a.addEventListener ? (void 0 === d && (d = !1), "mousewheel" === b && 0 <= navigator.userAgent.indexOf("Firefox") && (b = "DOMMouseScroll"), a.addEventListener(b, c, d)) : a.attachEvent("on" + b, c)
};
links.Timeline.removeEventListener = function (a, b, c, d) {
    a.removeEventListener ? (void 0 === d && (d = !1), "mousewheel" === b && 0 <= navigator.userAgent.indexOf("Firefox") && (b = "DOMMouseScroll"), a.removeEventListener(b, c, d)) : a.detachEvent("on" + b, c)
};
links.Timeline.getTarget = function (a) {
    a || (a = window.event);
    var b;
    a.target ? b = a.target : a.srcElement && (b = a.srcElement);
    void 0 != b.nodeType && 3 == b.nodeType && (b = b.parentNode);
    return b
};
links.Timeline.stopPropagation = function (a) {
    a || (a = window.event);
    a.stopPropagation ? a.stopPropagation() : a.cancelBubble = !0
};
links.Timeline.preventDefault = function (a) {
    a || (a = window.event);
    a.preventDefault ? a.preventDefault() : a.returnValue = !1
};
links.Timeline.getAbsoluteLeft = function (a) {
    var b = document.documentElement, c = document.body, d = a.offsetLeft;
    for (a = a.offsetParent; null != a && a != c && a != b; )
        d += a.offsetLeft, d -= a.scrollLeft, a = a.offsetParent;
    return d
};
links.Timeline.getAbsoluteTop = function (a) {
    var b = document.documentElement, c = document.body, d = a.offsetTop;
    for (a = a.offsetParent; null != a && a != c && a != b; )
        d += a.offsetTop, d -= a.scrollTop, a = a.offsetParent;
    return d
};
links.Timeline.getPageY = function (a) {
    "targetTouches"in a && a.targetTouches.length && (a = a.targetTouches[0]);
    if ("pageY"in a)
        return a.pageY;
    var b = document.documentElement, c = document.body;
    return a.clientY + (b && b.scrollTop || c && c.scrollTop || 0) - (b && b.clientTop || c && c.clientTop || 0)
};
links.Timeline.getPageX = function (a) {
    "targetTouches"in a && a.targetTouches.length && (a = a.targetTouches[0]);
    if ("pageX"in a)
        return a.pageX;
    var b = document.documentElement, c = document.body;
    return a.clientX + (b && b.scrollLeft || c && c.scrollLeft || 0) - (b && b.clientLeft || c && c.clientLeft || 0)
};
links.Timeline.addClassName = function (a, b) {
    for (var c = a.className.split(" "), d = b.split(" "), e = !1, f = 0; f < d.length; f++)
        -1 == c.indexOf(d[f]) && (c.push(d[f]), e = !0);
    e && (a.className = c.join(" "))
};
links.Timeline.removeClassName = function (a, b) {
    for (var c = a.className.split(" "), d = b.split(" "), e = !1, f = 0; f < d.length; f++) {
        var g = c.indexOf(d[f]);
        -1 != g && (c.splice(g, 1), e = !0)
    }
    e && (a.className = c.join(" "))
};
links.Timeline.isArray = function (a) {
    return a instanceof Array ? !0 : "[object Array]" === Object.prototype.toString.call(a)
};
links.Timeline.clone = function (a) {
    var b = {}, c;
    for (c in a)
        a.hasOwnProperty(c) && (b[c] = a[c]);
    return b
};
links.Timeline.parseJSONDate = function (a) {
    if (void 0 != a) {
        if (a instanceof Date)
            return a;
        var b = a.match(/\/Date\((-?\d+)([-\+]?\d{2})?(\d{2})?\)\//i);
        return b ? (a = b[2] ? 36E5 * b[2] + 6E4 * b[3] * (b[2] / Math.abs(b[2])) : 0, new Date(1 * b[1] + a)) : Date.parse(a)
    }
};
PrimeFacesExt.widget.Timeline = PrimeFaces.widget.DeferredWidget.extend({init: function (a) {
        this._super(a);
        this.cfg = a;
        this.id = a.id;
        if (this.lazy = null != this.getBehavior("lazyload"))
            this.min = "undefined" !== typeof this.cfg.opts.min ? this.cfg.opts.min.getTime() : null, this.max = "undefined" !== typeof this.cfg.opts.max ? this.cfg.opts.max.getTime() : null, this.pFactor = this.cfg.opts.preloadFactor, this.rangeLoadedEvents = {start: null, end: null};
        this.renderDeferred()
    }, _render: function () {
        this.cfg.opts = PrimeFacesExt.configureLocale("Timeline",
                this.cfg.opts);
        var a = document.getElementById(this.id);
        this.instance = new links.Timeline(a, this.cfg.opts);
        this.instance.draw(this.cfg.data, null);
        this.cfg.opts.currentTime && this.instance.setCurrentTime(this.cfg.opts.currentTime);
        this.bindEvents(a)
    }, bindEvents: function (a) {
        if (this.cfg.opts.responsive) {
            var b = $(a).closest(".ui-layout-pane");
            if (0 < b.length)
                b.on("layoutpaneonresize", $.proxy(function () {
                    this.instance.checkResize()
                }, this));
            else
                b = "resize.timeline" + PrimeFaces.escapeClientId(this.id), $(window).off(b).on(b,
                        $.proxy(function () {
                            this.instance.checkResize()
                        }, this))
        }
        this.cfg.opts.selectable && this.getBehavior("select") && links.events.addListener(this.instance, "select", $.proxy(function () {
            var a = this.getSelectedIndex();
            0 > a || (a = {params: [{name: this.id + "_eventIdx", value: a}]}, this.getBehavior("select").call(this, a))
        }, this));
        this.cfg.opts.selectable && this.cfg.opts.editable && this.getBehavior("add") && links.events.addListener(this.instance, "add", $.proxy(function () {
            var a = this.getSelectedEvent();
            if (null != a) {
                var b = [];
                b.push({name: this.id +
                            "_startDate", value: a.start.getTime()});
                a.end && b.push({name: this.id + "_endDate", value: a.end.getTime()});
                a.group && b.push({name: this.id + "_group", value: a.group});
                this.getBehavior("add").call(this, {params: b})
            }
        }, this));
        this.cfg.opts.selectable && this.cfg.opts.editable && this.cfg.opts.timeChangeable && this.getBehavior("change") && links.events.addListener(this.instance, "change", $.proxy(function () {
            var a = this.getSelectedIndex();
            if (!(0 > a)) {
                var b = this.getEvent(a);
                if (null != b && this.instance.isEditable(b)) {
                    var e = [];
                    e.push({name: this.id + "_eventIdx", value: a});
                    e.push({name: this.id + "_startDate", value: b.start.getTime()});
                    b.end && e.push({name: this.id + "_endDate", value: b.end.getTime()});
                    b.group && e.push({name: this.id + "_group", value: b.group});
                    this.getBehavior("change").call(this, {params: e})
                }
            }
        }, this));
        this.cfg.opts.selectable && this.cfg.opts.editable && this.cfg.opts.timeChangeable && this.getBehavior("changed") && links.events.addListener(this.instance, "changed", $.proxy(function () {
            var a = this.getSelectedIndex();
            if (!(0 > a)) {
                var b =
                        this.getEvent(a);
                if (null != b && this.instance.isEditable(b)) {
                    var e = [];
                    e.push({name: this.id + "_eventIdx", value: a});
                    e.push({name: this.id + "_startDate", value: b.start.getTime()});
                    b.end && e.push({name: this.id + "_endDate", value: b.end.getTime()});
                    b.group && e.push({name: this.id + "_group", value: b.group});
                    this.getBehavior("changed").call(this, {params: e})
                }
            }
        }, this));
        this.cfg.opts.selectable && this.cfg.opts.editable && this.getBehavior("edit") && links.events.addListener(this.instance, "edit", $.proxy(function () {
            var a = this.getSelectedIndex();
            0 > a || !this.isEditable(a) || (a = {params: [{name: this.id + "_eventIdx", value: a}]}, this.getBehavior("edit").call(this, a))
        }, this));
        this.cfg.opts.selectable && this.cfg.opts.editable && this.getBehavior("delete") && links.events.addListener(this.instance, "delete", $.proxy(function () {
            var a = this.getSelectedIndex();
            0 > a || !this.isEditable(a) || (a = {params: [{name: this.id + "_eventIdx", value: a}]}, this.getBehavior("delete").call(this, a))
        }, this));
        (this.cfg.opts.zoomable || this.cfg.opts.moveable) && this.getBehavior("rangechange") &&
                links.events.addListener(this.instance, "rangechange", $.proxy(function () {
                    var a = this.instance.getVisibleChartRange(), a = {params: [{name: this.id + "_startDate", value: a.start.getTime()}, {name: this.id + "_endDate", value: a.end.getTime()}]};
                    this.getBehavior("rangechange").call(this, a)
                }, this));
        (this.cfg.opts.zoomable || this.cfg.opts.moveable) && this.getBehavior("rangechanged") && links.events.addListener(this.instance, "rangechanged", $.proxy(function () {
            var a = this.instance.getVisibleChartRange(), a = {params: [{name: this.id +
                                "_startDate", value: a.start.getTime()}, {name: this.id + "_endDate", value: a.end.getTime()}]};
            this.getBehavior("rangechanged").call(this, a)
        }, this));
        this.lazy && (this.fireLazyLoading(), links.events.addListener(this.instance, "rangechanged", $.proxy(function () {
            this.fireLazyLoading()
        }, this)));
        this.cfg.opts.selectable && this.cfg.opts.editable && this.getBehavior("drop") && (b = {tolerance: "pointer"}, this.cfg.opts.hoverClass && (b.hoverClass = this.cfg.opts.hoverClass), this.cfg.opts.activeClass && (b.activeClass = this.cfg.opts.activeClass),
                this.cfg.opts.accept && (b.accept = this.cfg.opts.accept), this.cfg.opts.scope && (b.scope = this.cfg.opts.scope), b.drop = $.proxy(function (a, b) {
            var e = this.getInstance(), f = a.pageX - links.Timeline.getAbsoluteLeft(e.dom.content), g = a.pageY - links.Timeline.getAbsoluteTop(e.dom.content), h = e.screenToTime(f), k = e.screenToTime(f + e.size.frameWidth / 10);
            this.cfg.opts.snapEvents && (e.step.snap(h), e.step.snap(k));
            f = [];
            f.push({name: this.id + "_startDate", value: h.getTime()});
            f.push({name: this.id + "_endDate", value: k.getTime()});
            (g =
                    e.getGroupFromHeight(g)) && f.push({name: this.id + "_group", value: e.getGroupName(g)});
            f.push({name: this.id + "_dragId", value: b.draggable.attr("id")});
            e = b.draggable.closest(".ui-datatable, .ui-datagrid, .ui-datalist, .ui-carousel");
            0 < e.length && f.push({name: this.id + "_uiDataId", value: e.attr("id")});
            this.getBehavior("drop").call(this, {params: f, event: a, ui: b})
        }, this), $(a).droppable(b))
    }, getData: function () {
        var a = $.map(this.instance.getData(), $.proxy(function (a) {
            var c = {};
            a.hasOwnProperty("content") && (c.data = a.content);
            a.hasOwnProperty("start") && (c.startDate = a.start.getTime());
            a.hasOwnProperty("end") && null != a.end ? c.endDate = a.end.getTime() : c.endDate = null;
            a.hasOwnProperty("editable") ? c.editable = a.editable : c.editable = null;
            a.hasOwnProperty("group") ? c.group = a.group : c.group = null;
            a.hasOwnProperty("className") ? c.styleClass = a.className : c.styleClass = null;
            return c
        }, this));
        return JSON.stringify(a)
    }, fireLazyLoading: function () {
        var a = this.getLazyLoadRange();
        if (null != a) {
            var b = {params: []};
            null != a.startFirst && null != a.endFirst && (b.params[0] =
                    {name: this.id + "_startDateFirst", value: a.startFirst}, b.params[1] = {name: this.id + "_endDateFirst", value: a.endFirst});
            null != a.startSecond && null != a.endSecond && (b.params[2] = {name: this.id + "_startDateSecond", value: a.startSecond}, b.params[3] = {name: this.id + "_endDateSecond", value: a.endSecond});
            this.getBehavior("lazyload").call(this, b)
        }
    }, getLazyLoadRange: function () {
        var a = this.instance.getVisibleChartRange();
        if (null == this.rangeLoadedEvents.start || null == this.rangeLoadedEvents.end) {
            var b = (a.end.getTime() - a.start.getTime()) *
                    this.pFactor;
            this.rangeLoadedEvents.start = Math.round(a.start.getTime() - b);
            this.rangeLoadedEvents.end = Math.round(a.end.getTime() + b);
            null != this.min && this.rangeLoadedEvents.start < this.min && (this.rangeLoadedEvents.start = this.min);
            null != this.max && this.rangeLoadedEvents.end > this.max && (this.rangeLoadedEvents.end = this.max);
            return{startFirst: this.rangeLoadedEvents.start, endFirst: this.rangeLoadedEvents.end, startSecond: null, endSecond: null}
        }
        if (a.end.getTime() > this.rangeLoadedEvents.end && a.start.getTime() >= this.rangeLoadedEvents.start)
            return b =
                    this.rangeLoadedEvents.end + 1, this.rangeLoadedEvents.end = Math.round(a.end.getTime() + (a.end.getTime() - a.start.getTime()) * this.pFactor), null != this.max && this.rangeLoadedEvents.end > this.max && (this.rangeLoadedEvents.end = this.max), {startFirst: b, endFirst: this.rangeLoadedEvents.end, startSecond: null, endSecond: null};
        if (a.start.getTime() < this.rangeLoadedEvents.start && a.end.getTime() <= this.rangeLoadedEvents.end)
            return b = this.rangeLoadedEvents.start - 1, this.rangeLoadedEvents.start = Math.round(a.start.getTime() - (a.end.getTime() -
                    a.start.getTime()) * this.pFactor), null != this.min && this.rangeLoadedEvents.start < this.min && (this.rangeLoadedEvents.start = this.min), {startFirst: this.rangeLoadedEvents.start, endFirst: b, startSecond: null, endSecond: null};
        if (a.start.getTime() < this.rangeLoadedEvents.start && a.end.getTime() > this.rangeLoadedEvents.end) {
            var b = (a.end.getTime() - a.start.getTime()) * this.pFactor, c = this.rangeLoadedEvents.start - 1, d = this.rangeLoadedEvents.end + 1;
            this.rangeLoadedEvents.start = Math.round(a.start.getTime() - b);
            this.rangeLoadedEvents.end =
                    Math.round(a.end.getTime() + b);
            null != this.min && this.rangeLoadedEvents.start < this.min && (this.rangeLoadedEvents.start = this.min);
            null != this.max && this.rangeLoadedEvents.end > this.max && (this.rangeLoadedEvents.end = this.max);
            return{startFirst: this.rangeLoadedEvents.start, endFirst: c, startSecond: d, endSecond: this.rangeLoadedEvents.end}
        }
        return null
    }, addEvent: function (a) {
        this.instance.addItem(a)
    }, changeEvent: function (a, b) {
        this.instance.changeItem(a, b)
    }, deleteEvent: function (a, b) {
        this.instance.deleteItem(a, b)
    }, deleteAllEvents: function () {
        this.instance.deleteAllItems()
    },
    cancelAdd: function () {
        this.instance.cancelAdd()
    }, cancelChange: function () {
        this.instance.cancelChange()
    }, cancelDelete: function () {
        this.instance.cancelDelete()
    }, getEvent: function (a) {
        return this.instance.getItem(a)
    }, isEditable: function (a) {
        return this.instance.isEditable(this.getEvent(a))
    }, getVisibleRange: function () {
        return this.instance.getVisibleChartRange()
    }, setVisibleRange: function (a, b) {
        return this.instance.setVisibleChartRange(a, b)
    }, move: function (a) {
        return this.instance.move(a)
    }, zoom: function (a, b) {
        return this.instance.zoom(a,
                b)
    }, checkResize: function () {
        this.instance.checkResize()
    }, getNumberOfEvents: function () {
        return this.instance.getData().length
    }, getBehavior: function (a) {
        return this.cfg.behaviors ? this.cfg.behaviors[a] : null
    }, getSelectedIndex: function () {
        var a = this.instance.getSelection();
        return a.length && void 0 != a[0].row ? a[0].row : -1
    }, getSelectedEvent: function () {
        var a = this.getSelectedIndex();
        return-1 != a ? this.instance.getItem(a) : null
    }, setSelection: function (a) {
        0 <= a ? this.instance.setSelection([{row: a}]) : this.instance.setSelection([])
    },
    getInstance: function () {
        return this.instance
    }});
//# sourceMappingURL=https://raw.githubusercontent.com/primefaces-extensions/core/master/src/sourcemap/4.0.0/timeline.js.map