/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function () {

    document.onkeydown = function (e) {
        //取消返回按钮
        var code;
        if (!e)
            var e = window.event;
        if (e.keyCode)
            code = e.keyCode;
        else if (e.which)
            code = e.which;
        debugger;
        if (((e.keyCode == 8) && //BackSpace   
                ((e.srcElement.type != "text" &&
                        e.srcElement.type != "textarea" &&
                        e.srcElement.type != "password") ||
                        e.srcElement.readOnly == true)) ||
                ((e.ctrlKey) && ((e.keyCode == 78) || (e.keyCode == 82))) || //CtrlN,CtrlR   
                (e.keyCode == 116)) {                                                   //F5   
            e.keyCode = 0;
            e.returnValue = false;
            return false;
        }
        //有对话框时取消回车按钮
        if ($(".ui-widget-overlay").length > 0) {
            if (e.keyCode === 13) {
                return false;
            }
        }

    }

//    if(window.links){
//     links.Timeline.prototype.setOptions(
////            timeLineOption
//             )
//    }
//初期话显示年和月的控件
//    initYearMonthCalendar();
//数字入力項目の異常処理 
    $(".pe-inputNumber").each(function () {
        this.onblur = function () {
            if (this.value == "") {
                $("[id*='" + $(this).attr("id").replace("_input", "_hinput") + "']").attr("value", "");
            }
        }
    });

    commonPageJS();

});

function commonPageJS() {
    $(".ui-my-select-many").find("[type='checkbox']").each(function () {
        selectManyCheckboxSet(this);
    });
}
function test() {
    debugger;

//    PF('searchResult').setupStickHeader();
}
//更改一览表示页
function changeDataTablePage(widgetVar, page) {
    debugger;
    clearDatatableSort(widgetVar);
//    if (PF(widgetVar).getPaginator().getCurrentPage() !== page) {
//        PF(widgetVar).getPaginator().setPage(page);
    PF(widgetVar).getPaginator().cfg.page = page;
    PF(widgetVar).getPaginator().updateUI();
//    }

//     PF(widgetVar).paginate(page);
}
//清空一览排序
function clearDatatableSort(id) {
    $("[id*='" + id + "'].ui-datatable").find('.ui-state-active').removeClass("ui-state-active");
    $("[id*='" + id + "'].ui-datatable").find('.ui-sortable-column-icon').removeClass('ui-icon-triangle-1-s ui-icon-triangle-1-n');
}
//确认ｄｉａｌｏｇ
function successDialog(xhr, status, args) {
    if ($("[class*=global-message-ready ]").length > 0) {
        PF('globalMessage').show();
        setTimeout("$('[hid=globalMessageBtn]').click()", 3000);
    }

}
//执行传入名称的方法
function excuteFunction(functionName) {
    if (functionName === null ||
            functionName === undefined || functionName === "") {
        return;
    }
    try
    {
        eval(functionName + "();");
    }
    catch (e)
    {
    }
}
//iframe  url 修改
function gotof(url) {
    $("#rightf").attr("src", getUrlbase(url));
    return false;
}
//url　生成
function getUrlbase(myUrl) {
    var urloreg = window.location.href;
    urloreg = urloreg.substr(0, urloreg.indexOf(window.location.pathname));
    var urls = urloreg +
            '/' +
            window.location.pathname.split('/')[1];
    return urls + myUrl;
}

function showDlgCom() {
    showDlg({}, function () {
        alert('1')
    }, function () {
        alert('2')
    });
}

function showDlg(option, onShow, onHidden) {
    window.parent.showDlg(option, onShow, onHidden);
}

//通过ｊａｖａ返回值判断是否关闭
function closeDlgA(xhr, status, args) {
//      RequestContext context = RequestContext.getCurrentInstance();
//    context.addCallbackParam("close", true);
    if (args.close) {
        closeDlg(true);
    }
}

function closeDlg()
{
    closeDlg(true);
}
function closeDlg(closeFlg) {
    if (closeFlg === "false" || closeFlg === false) {
        return;
    }
    window.parent.closeDlg();
}

function openPage(url) {
    window.open(getUrlbase(url), 'newwindow',
            'height=600,width=800,top=0,left=0,toolbar=no,menubar=no,scrollbars=no,resizable=no,location=no,status=no');
}
function openLink(url) {
    debugger;
    var reg = new RegExp("^http");
    if (!reg.test(url)) {
        url = "http://" + url;
    }
    window.open(url, 'newwindow',
            'height=600,width=800,top=0,left=0,toolbar=no,menubar=no,scrollbars=no,resizable=no,location=no,status=no');
}
//防止按钮事件重复提交
function btnBlocker(target)
{
    var _target = $(target);
    // ボタンを隠す
    _target.fadeOut(1500);
    _target.attr("disabled", "disabled");

    // FIXME 3秒後に再度押せるようにする
    _target.fadeIn(1500, function () {
        $(this).removeAttr("disabled");
    });
}
CWide = [];
CWideS = [];
//缓存一览的宽度
function saveCWide() {
    CWideS = [];
    $(".ui-resizable-column").each(function () {
        thisCWide = {};
        thisCWide.id = $(this).attr("id");
        thisCWide.style = $(this).attr("style");
        CWideS.push(thisCWide);
    });
}

//还原一览的宽度
function restoreCWide() {
    for (var i = 0; i < CWideS.length; i++)
    {
//        $("#" + CWide[i].id).attr("style", CWide[i].style);
        $(".ui-resizable-column").each(function () {
            if (CWideS[i].id === $(this).attr("id")) {
                $(this).attr("style", CWideS[i].style);
            }
        });
    }
}


//自动设置一览的宽度
function autoCWide() {
    $(".ui-datatable").each(function () {
        if ($(this).find(".ui-datatable-data").length > 0) {
            autoWideSub($(this));
        }
    });

}

function autoWideSub(a) {
    a.find(".ui-datatable-data").attr("style", "display:table");
    CWide = [];
    a.find(".ui-datatable-data").find("[data-ri='0']").find("[role='gridcell']").each(function () {

        thisCWide = {};
        thisCWide.width = $(this).width() + 22;
        if (thisCWide.width < 90) {
            thisCWide.width = 90;
        }
        CWide.push(thisCWide);

    });
    a.find(".ui-datatable-data").attr("style", "");
    var index = 0;
    a.find(".ui-datatable-scrollable-header-box").find("[role='columnheader']").each(function () {
        if (CWide[index] == undefined) {
            return;
        }
        $(this).attr("style", "width: " + CWide[index].width + "px;");
        index++;
    });
    index = 0;
    a.find(".ui-datatable-scrollable-theadclone").find(".ui-resizable-column").each(function () {
        if (CWide[index] == undefined) {
            return;
        }
        $(this).attr("style", "width: " + CWide[index].width + "px;");
        index++;
    });
    index = 0;
    a.find(".ui-datatable-tablewrapper").find(".ui-resizable-column").each(function () {
        if (CWide[index] == undefined) {
            return;
        }
        $(this).attr("style", "width: " + CWide[index].width + "px;");
        index++;
    });
}
function trythis(a) {
    $(".fc-mon").css("color", "red");
}




/**
 * 获取光标在短连接输入框中的位置
 * @param inputId 框Id
 * @return {*}
 */
function getCursorPos(inputId) {
    debugger;
    PF(inputId).jqInput.insertText('dsadad');
}


//Cookie 取得方法
function getCookie(name) {
    return  $.cookie(name);
}

//Cookie 设定方法
function setCookie(key, value) {
    var dt = new Date();
    //设定Cookie有效时间为30天
    dt.setDate(dt.getDate() + 30);
    $.cookie(key, value, {path: '/', expires: dt});
}

/** 
 * 定义验证各种格式类型的正则表达式对象 
 */
var Regexs = {
    email: (/^[0-9a-z][0-9a-z\-\_\.]+@([0-9a-z][0-9a-z\-]*\.)+[a-z]{2,}$/i), //邮箱  
    phone: (/^0[0-9]{2,3}[2-9][0-9]{6,7}$/), //座机手机号码  
    ydphpne: (/^((13[4-9])|(15[012789])|147|182|187|188)[0-9]{8}$/), //移动手机号码  
    allphpne: (/^((13[0-9])|(15[0-9])|(18[0-9]))[0-9]{8}$/), //所有手机号码  
    ltphpne: (/^((13[0-2])|(15[56])|(186)|(145))[0-9]{8}$/), //联通手机号码  
    dxphpne: (/^((133)|(153)|(180)|(189))[0-9]{8}$/), //电信手机号码  
    url: (/^http:\/\/([0-9a-z][0-9a-z\-]*\.)+[a-z]{2,}(:\d+)?\/[0-9a-z%\-_\/\.]+/i), //网址  
    num: (/[^0-9]/), //数字  
    cnum: (/[^0-9a-zA-Z_.-]/),
    photo: (/\.jpg$|\.jpeg$|\.gif$/i), //图片格式  
    dat: (/\.dat$/i), //dat格式  
    csv: (/\.csv$|\.txt/i), //txt格式  
    row: (/\n/ig)
};
/** 
 * @return 若符合对应的格式，返回true，否则返回false 
 */
function chkFormat(str, ftype) {
    var ftypeList = ftype.split(" ");
    for (i = 0; i < ftypeList.length; i++) {
        if (chkFormatBase(str, ftypeList[i])) {
            return true;
        }
    }
}
function chkFormatBase(str, ftype) {
    if (ftype == null || ftype == "") {
        return true; //输入为空，认为是验证通过  
    }
    var nReg = Regexs[ftype];
    if (str == null || str == "")
        return true; //输入为空，认为是验证通过  
    if (ftype == 'num') {
        if (!nReg.test(str) && !chkChinese(str)) {//10.23 tenfy 必须为数字且不能有中文  
            return false;
        } else {
            return true;
        }
    }
    str = str.toLowerCase();
    if (!nReg.test(str)) {
        return false;
    } else {
        return true;

    }
}
;
function chkChinese(s) {
    for (var i = 0; i < s.length; i++) {
        if (s.charCodeAt(i) > 255)
            return true;
    }
    return false;
}
function toggleOverlay(a) {
    PF(a).toggle();
}

function openSubMenu(header) {
    var headerJQ = $(header);

    if (this.activeSubSubMenu) {
        $(this.activeSubSubMenu).removeClass("openSubMenuLink");
        this.activeSubSubMenu = null;
    }

    if (this.activeMenu) {
        if (this.activeMenu === header) {
            headerJQ.removeClass('MenuSideMainLinkDark').next().slideUp(700, "easeInOutQuint");
            this.activeMenu = null;
            $.removeCookie('menustate', {path: '/'});
        }
        else {
            $(this.activeMenu).removeClass('MenuSideMainLinkDark').next().slideUp(700, "easeInOutQuint");
            headerJQ.addClass("MenuSideMainLinkDark").next().slideDown(700, "easeInOutQuint");
            this.activeMenu = header;
            $.cookie('menustate', headerJQ.attr('id'), {path: '/'});
        }
    }
    else {
        headerJQ.addClass("MenuSideMainLinkDark").next().slideDown(700, "easeInOutQuint");
        this.activeMenu = header;
        $.cookie('menustate', headerJQ.attr('id'), {path: '/'});
    }
}
//取消双击
function fade(a) {
    $(a).fadeOut(1500);
    $(a).fadeIn(1500);
}

function cleanTips() {
    $('.qtip').qtip('destroy', true);

}


function addDate(date, days) {
    var d = new Date(date);
    d.setDate(d.getDate() + days);
    var month = d.getMonth() + 1;
    var day = d.getDate();
    if (month < 10) {
        month = "0" + month;
    }
    if (day < 10) {
        day = "0" + day;
    }
    var val = d.getFullYear() + "" + month + "" + day;
    return val;
}