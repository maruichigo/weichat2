PrimeFaces.locales['ja_JP'] = {
    closeText: '閉じる',
    prevText: '先月',
    nextText: '翌月',
    currentText: '今日',
    monthNames: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
    monthNamesShort: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
    dayNames: ['日曜', '月曜', '火曜', '水曜', '木曜', '金曜', '土曜'],
    dayNamesShort: ['日', '月', '火', '水', '木', '金', '土'],
    dayNamesMin: ['日', '月', '火', '水', '木', '金', '土'],
    firstDay: 0,
    showMonthAfterYear: true,
    yearSuffix: '', // 年
    timeOnlyTitle: '時間のみ',
    timeText: '時間',
    hourText: '時',
    minuteText: '分',
    secondText: '秒',
    ampm: false,
    month: '月',
    week: '週',
    day: '日',
    allDayText: '全日',
    MONTHS: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
    MONTHS_SHORT: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
    DAYS: ['日曜', '月曜', '火曜', '水曜', '木曜', '金曜', '土曜'],
    DAYS_SHORT: ['日', '月', '火', '水', '木', '金', '土'],
    ZOOM_IN: "Zoom in",
    ZOOM_OUT: "Zoom out",
    MOVE_LEFT: "Move left",
    MOVE_RIGHT: "Move right",
    NEW: "New",
    CREATE_NEW_EVENT: "Create new event"
};
PrimeFacesExt.configureLocale = function (a, b) {
    if (a === "Timeline") {
        //拡張timeline
        extendTimeLine();
    }
    if (PrimeFacesExt.locales && PrimeFacesExt.locales[a]) {
        if (b.locale) {
            var d = PrimeFacesExt.locales[a][b.locale];
            if (d)
                for (var c in d)
                    d.hasOwnProperty(c) && (b[c] = d[c])
        } else {
            var d = PrimeFacesExt.locales[a]['en'];
            if (d)
                for (var c in d)
                    d.hasOwnProperty(c) && (b[c] = d[c])
        }
    }
    return b
}

//拡張timeline追加ラベル
function extendTimeLine() {
    var bE = PrimeFacesExt.widget.Timeline.prototype.bindEvents;
    PrimeFacesExt.widget.Timeline.prototype.bindEvents = function (a) {
        bE.call(this, a);
        eval('extendTimeLineMake()');
    };
}
function extendTimeLineMake(){
    
}
PrimeFaces.locales['de'] = {
    closeText: '关闭',
    prevText: '上个月',
    nextText: '下个月',
    currentText: '今天',
    monthNames: ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月'],
    monthNamesShort: ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月'],
    dayNames: ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'],
    dayNamesShort: ['日', '一', '二', '三', '四', '五', '六'],
    dayNamesMin: ['日', '一', '二', '三', '四', '五', '六'],
    weekHeader: '周',
    firstDay: 0,
    isRTL: false,
    showMonthAfterYear: true,
    yearSuffix: '', // 年
    timeOnlyTitle: '仅时间',
    timeText: '时间',
    hourText: '时',
    minuteText: '分',
    secondText: '秒',
    ampm: false,
    month: '月',
    week: '周',
    day: '日',
    allDayText: '全天',
    MONTHS: "January February March April May June July August September October November December".split(" "),
    MONTHS_SHORT: "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split(" "),
    DAYS: "Sunday Monday Tuesday Wednesday Thursday Friday Saturday".split(" "),
    DAYS_SHORT: "Sun Mon Tue Wed Thu Fri Sat".split(" "),
    ZOOM_IN: "Zoom in",
    ZOOM_OUT: "Zoom out",
    MOVE_LEFT: "Move left",
    MOVE_RIGHT: "Move right",
    NEW: "New",
    CREATE_NEW_EVENT: "Create new event"
};

(function (a) {
    alert(a);
})

function overLoadSchedule() {
    var update = this.update;
    this.update = function () {
        update;
        console.log("update");
//        alert('1');
    }
    var a = this.cfg.eventDrop;
    this.cfg.eventDrop = function (i, h, f, d, g, c) {
        a(i, h, f, d, g, c);
//        alert('1');
    }
    var eventMouseover = this.cfg.eventMouseover;
    this.cfg.eventMouseover = function (d, c, b) {
        if ($(this).attr("data-hasqtip") !== undefined) {
            return;
        }
        //eventMouseover(d, c, b);
        var tips = "";
        tips += "<div class=\"qtip-titlebar\"><div class=\"qtip-title\" aria-atomic=\"true\">说明：<b class=\"h4\" style=\"color:red\">" + JSON.stringify(d) + "</b></div></div>";

        tips += "<div class=\"qtip-content textlink\" aria-atomic=\"true\"><a href=\"";
        tips += "http://localhost:8080/bxdl-web/view/com/com00100.xhtml";
        tips += "\" style=\"color:red\">现在去处理</a></div>";

        addTip(this, tips);

    }
    function addTip(target, info) {
        $(target).qtip({
            content: info,
            position: {
                at: 'bottom right' // at the bottom right of...
//                target: $() // my target
            },
            hide: {
                fixed: true,
                delay: 300
            },
            show: {
                solo: true,
                ready: true
            },
            style: {
                tip: false

            }
        });
    }

}


function selectManyCheckboxClean(a) {
    var tagetName = $(a).attr("id").replace("g_clear_btn", "");
    $("[id*='" + tagetName + "']").each(
            function () {
                if (this.checked) {
                    this.checked = false;
                }
            });
    $("table[id*='" + tagetName + "']").find(".ui-icon-check").attr("class", "ui-chkbox-icon ui-icon ui-icon-blank");
    $("table[id*='" + tagetName + "']").find(".ui-state-active").removeClass("ui-state-active");
    $("[id*='" + tagetName + "'][id*='myInput']").attr("value", "");

    return false;
}



function selectManyCheckboxSet(a) {
    var tagetName = $(a).attr("name");

    var value = "";
    $("[id*='" + tagetName + "']").each(
            function () {
                if (this.checked) {
                    if (value !== "") {
                        value += ",";
                    }
                    value += $("label[for='" + $(this).attr("id") + "']").html();
                }
            });
    $("[id*='" + tagetName + "'][id*='myInput']").attr("value", value);

}
function selectIbtTypeManyCheckboxClean(a) {
    var tagetName = $(a).attr("id").replace("ibt_myInput_clean_btn", "");
    $("[id*='" + tagetName + "']").each(
            function () {
                if (this.checked) {
                    this.checked = false;
                }
            });
    $("table[id*='" + tagetName + "']").find(".ui-icon-check").attr("class", "ui-chkbox-icon ui-icon ui-icon-blank");
    $("table[id*='" + tagetName + "']").find(".ui-state-active").removeClass("ui-state-active");
    $("[id*='" + tagetName + "'][id*='ibt_myInput_input']").val("");
    return false;
}
function selectInsTypeManyCheckboxClean(a) {
    var tagetName = $(a).attr("id").replace("ins_myInput_clean_btn", "");
    $("[id*='" + tagetName + "']").each(
            function () {
                if (this.checked) {
                    this.checked = false;
                }
            });
    $("table[id*='" + tagetName + "']").find(".ui-icon-check").attr("class", "ui-chkbox-icon ui-icon ui-icon-blank");
    $("table[id*='" + tagetName + "']").find(".ui-state-active").removeClass("ui-state-active");
    $("[id*='" + tagetName + "'][id*='ins_myInput_input']").val("");
    return false;
}


function mSelectManyCheckboxSet(a) {
    var tagetName = $(a).attr("name");
    var tagetNameList = tagetName.split(":");
    var tagetNameMain = "";
    var length = tagetNameList.length - 3;

    for (var i = 0; i < length; i++)
    {
        tagetNameMain = tagetNameMain + tagetNameList[i] + ":";
    }
    var value = "";
    $("[id*='" + tagetNameMain + "']").each(
            function () {
                if (this.checked) {
                    if (value !== "") {
                        value += ",";
                    }
                    value += $("label[for='" + $(this).attr("id") + "']").html();
                }
            });
    $("input[id*='" + tagetNameMain + "'][id*='myInput']").val(value);
}
function mSelectManyCheckboxClean(a) {
    var tagetName = $(a).attr("id").replace("g_clear_btn", "");

    $("[id*='" + tagetName + "']").each(
            function () {
                if (this.checked) {
                    this.checked = false;
                }
            });
    $("table[id*='" + tagetName + "']").find(".ui-icon-check").attr("class", "ui-chkbox-icon ui-icon ui-icon-blank");
    $("table[id*='" + tagetName + "']").find(".ui-state-active").removeClass("ui-state-active");
    $("input[id*='" + tagetName + "'][id*='myInput']").val("");
    return false;
}

