
//覆盖时间控件的ｊｓ
PrimeFaces.widget.Calendar = PrimeFaces.widget.BaseWidget.extend({
    init: function (b) {
        this._super(b);
        this.input = $(this.jqId + "_input");
        this.jqEl = this.cfg.popup ? this.input : $(this.jqId + "_inline");
        var a = this;
        this.configureLocale();
        this.bindDateSelectListener();
        this.bindViewChangeListener();
        this.cfg.beforeShowDay = function (g) {
            if (a.cfg.preShowDay) {
                return a.cfg.preShowDay(g)
            } else {
                if (a.cfg.disabledWeekends) {
                    return $.datepicker.noWeekends(g)
                } else {
                    return [true, ""]
                }
            }
        };
        var e = this.hasTimePicker();
        if (e) {
            this.configureTimePicker()
        }
        if (this.cfg.popup) {
            PrimeFaces.skinInput(this.jqEl);
            if (this.cfg.behaviors) {
                PrimeFaces.attachBehaviors(this.jqEl, this.cfg.behaviors)
            }
            this.cfg.beforeShow = function (g, i) {
                setTimeout(function () {
                    $("#ui-datepicker-div").css("z-index", ++PrimeFaces.zindex)
                },
                        1);
                if (PrimeFaces.env.touch && !a.input.attr("readonly") && a.cfg.showOn && a.cfg.showOn === "button") {
                    $(this).prop("readonly", true)
                }
                var h = a.cfg.preShow;
                if (h) {
                    return a.cfg.preShow.call(a, g, i)
                }
            }
        }
        if (PrimeFaces.env.touch && !this.input.attr("readonly") && this.cfg.showOn && this.cfg.showOn === "button") {
            this.cfg.onClose = function (h, g) {
                $(this).attr("readonly", false)
            }
        }
        if (!this.cfg.disabled) {
            if (e) {
                if (this.cfg.timeOnly) {
                    this.jqEl.timepicker(this.cfg)
                } else {
                    this.jqEl.datetimepicker(this.cfg)
                }
            } else {
                this.jqEl.datepicker(this.cfg)
            }
        }
        if (this.cfg.popup && this.cfg.showOn) {
            var d = this.jqEl.siblings(".ui-datepicker-trigger:button");
            d.html("").addClass("ui-button ui-widget ui-state-default ui-corner-all ui-button-icon-only").append('<span class="ui-button-icon-left ui-icon ui-icon-calendar"></span><span class="ui-button-text">ui-button</span>');
            var f = this.jqEl.attr("title");
            if (f) {
                d.attr("title", f)
            }
            PrimeFaces.skinButton(d);
            $("#ui-datepicker-div").addClass("ui-shadow")
        }
        if (this.cfg.popup) {
            this.jq.data("primefaces-overlay-target", this.id).find("*").data("primefaces-overlay-target", this.id)
        }
        this.input.data(PrimeFaces.CLIENT_ID_DATA, this.id);
        if (this.cfg.mask) {
            var c = {
                placeholder: this.cfg.maskSlotChar || "_"
            };
            this.input.mask(this.cfg.mask, c)
        }
        initYearMonthCalendarSub(b.id);
    },
    refresh: function (a) {
        if (a.popup && $.datepicker._lastInput && (a.id + "_input") === $.datepicker._lastInput.id) {
            $.datepicker._hideDatepicker()
        }
        this.init(a)
    },
    configureLocale: function () {
        var a = PrimeFaces.locales[this.cfg.locale];
        if (a) {
            for (var b in a) {
                this.cfg[b] = a[b]
            }
        }
    },
    bindDateSelectListener: function () {
        var a = this;
        this.cfg.onSelect = function () {
            if (a.cfg.popup) {
                a.fireDateSelectEvent()
            } else {
                var b = $.datepicker.formatDate(a.cfg.dateFormat, a.getDate());
                a.input.val(b);
                a.fireDateSelectEvent()
            }
        }
    },
    fireDateSelectEvent: function () {
        if (this.cfg.behaviors) {
            var a = this.cfg.behaviors.dateSelect;
            if (a) {
                a.call(this)
            }
        }
    },
    bindViewChangeListener: function () {
        if (this.hasBehavior("viewChange")) {
            var a = this;
            this.cfg.onChangeMonthYear = function (b, c) {
                a.fireViewChangeEvent(b, c)
            }
        }
    },
    fireViewChangeEvent: function (b, c) {
        if (this.cfg.behaviors) {
            var d = this.cfg.behaviors.viewChange;
            if (d) {
                var a = {
                    params: [{
                            name: this.id + "_month",
                            value: c
                        },
                        {
                            name: this.id + "_year",
                            value: b
                        }]
                };
                d.call(this, a)
            }
        }
    },
    configureTimePicker: function () {
        var b = this.cfg.dateFormat,
                a = b.toLowerCase().indexOf("h");
        this.cfg.dateFormat = b.substring(0, a - 1);
        this.cfg.timeFormat = b.substring(a, b.length);
        if (this.cfg.timeFormat.indexOf("ss") != -1) {
            this.cfg.showSecond = true
        }
        if (this.cfg.timeFormat.indexOf("TT") != -1) {
            this.cfg.ampm = true
        }
        if (this.cfg.minDate) {
            this.cfg.minDate = $.datepicker.parseDateTime(this.cfg.dateFormat, this.cfg.timeFormat, this.cfg.minDate, {},
                    {})
        }
        if (this.cfg.maxDate) {
            this.cfg.maxDate = $.datepicker.parseDateTime(this.cfg.dateFormat, this.cfg.timeFormat, this.cfg.maxDate, {},
                    {})
        }
        if (!this.cfg.showButtonPanel) {
            this.cfg.showButtonPanel = false
        }
    },
    hasTimePicker: function () {
        return this.cfg.dateFormat.toLowerCase().indexOf("h") != -1
    },
    setDate: function (a) {
        this.jqEl.datetimepicker("setDate", a)
    },
    getDate: function () {
        return this.jqEl.datetimepicker("getDate")
    },
    enable: function () {
        this.jqEl.datetimepicker("enable")
    },
    disable: function () {
        this.jqEl.datetimepicker("disable")
    },
    hasBehavior: function (a) {
        if (this.cfg.behaviors) {
            return this.cfg.behaviors[a] !== undefined
        }
        return false
    }
});


function initYearMonthCalendarSub(target) {
    var com = $("[id='" + target + "']");
    if (com.attr("class").indexOf("my-year-month-calendar") < 0) {
        return;
    }

    var val = com.find("input");
//    com.find("a").each(function () {
//        var onclick_ = this.onclick;
//        this.onclick = function () {
////            alert($(this).attr('class'));
//            if (onclick_ !== null) {
//                onclick_();
//            }
//            setvalue();
//        };
//    });
    com.onchange = function () {
        alert(1);
    }
    com.find("select").each(function () {
        $(this).attr("onchange", "setvalueYearMonthCalendar('" + target + "')");
    });
    if (com.find("input").val() === "" || com.find("input").val() === undefined) {
        com.find('.ui-datepicker-year').val("");
        com.find('.ui-datepicker-month').val("");
    }
//    this.onclick = null;
//    this.onkeydown = null;
}
function clearYM(target) {
    var com = $(".my-year-month-calendar[id*='" + target.id.replace('g_clear_btn', '') + "']");
    com.find('.ui-datepicker-year').val("");
    com.find('.ui-datepicker-month').val("");
    com.find('input').val("");
}

function setvalueYearMonthCalendar(target) {
    var com = $("[id='" + target + "']");
    var year = com.find(".ui-datepicker-year").val();
    var month = com.find(".ui-datepicker-month").val();
    month = parseInt(month) + 1;
    if (month < 10) {
        month = "0" + month;
    }
    com.find("input").val(year + "-" + month + "-" + "01");
    eval(com.attr("ttdl")+"change()");
    com.find("select").each(function () {
        $(this).attr("onchange", "setvalueYearMonthCalendar('" + target + "')");
    });
}