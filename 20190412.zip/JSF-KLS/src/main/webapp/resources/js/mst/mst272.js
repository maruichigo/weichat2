jQuery(document).ready(function () {
    $("#listForm\\:tablesorter_mst272_4").children().css("height", $("#listForm\\:tablesorter_mst272_0").css("height"));
    $(".ui-picklist-buttons").hide();
    $("#listForm\\:tablesorter_mst272_5").find("ul").css("width", "150px");
    $("#listForm\\:tablesorter_mst272_5").find("ul").css("height", "240px");

    $("input[name='topForm\\:conGyoshaKbn']").click(function () {

        if ($(this).val() == '1') {

        }
        if ($(this).val() == '2') {

        }

    });

});

function remove(obj) {
    var reg = /:/g;
    var id = $(obj).parents("ul").next().attr("id").replace(reg, "\\:");
    var val = $(obj).parents("tr").children("td:eq(0)")[0].innerHTML;

    $(obj).parents("li").remove();
    $("#" + id + " option[value='" + val + "']").remove();

}

//列の移動は、ドラック＆ドロップ
function handleDrop(event, ui) {
    var html = ui.draggable[0].innerHTML;
    var val = ui.draggable[0].attributes[1].value;
    var label = $(ui.draggable[0]).find("td:eq(0)")[0].innerHTML;
    var text = $(event.target).find("li").text();
    
    console.log(ui);
    
    if (text.indexOf(html) === -1) {
        $(ui.draggable[0]).remove();
        $(event.target).find("ul").append("<li class=\"ui-orderlist-item ui-corner-all ui-sortable-handle\" data-item-value=\"" + val + "\">" + html + "</li>");
        $(event.target).find("select").append("<option selected=\"selected\" value=\"" + val + "\">" + label + "</li>");
    }
    $(ui.draggable[0]).removeClass("ui-state-highlight");
   

}
