var conInit;
$(document).ready(function () {
     conInit = $("#searchForm").html();
//    alert(conInit);
});
// functionボタン：前画面へボタン処理
function backforward() {
    var array = $(".ui-breadcrumb li[role] a");
    var i = $(".ui-breadcrumb li[role]").length - 2;
    $(array[i]).click();
    this.setScroll("top");
    return false;
}

// 管轄区分変更
function kankatsuKbnChange(searchForm, kankatsuKbnId, kankatsuEigyosho){

    var eigyosho = kankatsuEigyosho+"_"+"input";
    $("input[id$="+eigyosho+"]").attr("disabled", true)
    $("input[id$="+eigyosho+"]").next().next().attr("disabled", true)
    $("#"+searchForm+"\\:"+kankatsuKbnId+"\\:coms\\:0").change(function () {
                    if ($("#"+searchForm+"\\:"+kankatsuKbnId+"\\:coms\\:0").is(':checked') || $("#"+searchForm+"\\:"+kankatsuKbnId+"\\:coms\\:1").is(':checked')) {
                        $("input[id$="+eigyosho+"]").attr("disabled", false)
                        $("input[id$="+eigyosho+"]").next().next().attr("disabled", false) 
                }
                    else {
                        $("input[id$="+eigyosho+"]").attr("disabled", true)
                        $("input[id$="+eigyosho+"]").next().next().attr("disabled", true)
            }});
            $("#"+searchForm+"\\:"+kankatsuKbnId+"\\:coms\\:1").change(function () {
                    if ($("#"+searchForm+"\\:"+kankatsuKbnId+"\\:coms\\:0").is(':checked') || $("#"+searchForm+"\\:"+kankatsuKbnId+"\\:coms\\:1").is(':checked')) {
                        $("input[id$="+eigyosho+"]").attr("disabled", false)
                        $("input[id$="+eigyosho+"]").next().next().attr("disabled", false)
                }   
                    else {
                        $("input[id$="+eigyosho+"]").attr("disabled", true)
                        $("input[id$="+eigyosho+"]").next().next().attr("disabled", true) 
            }});
}

/* 行追加＆行複製時の画面スクロール（引数[top or bottom]) */
function setScroll(type) {
    var s = "";
    if (type == "top") {
        s = 0;
    } else {
        s = $('body').scrollHeight || document.documentElement.scrollHeight;
    }
    $(window).scrollTop(s);
}

// checkBoxで選択された行のデータを保持
var $checkList = "";
function handleComplete(args) {
    $checkList = args.checkParam;
}

// コンテキストメニュー：選択行コピー
function cprow() {

    var list = $("tr.ui-state-highlight");
    if (list.length != 0) {
        var str = "";
        var headList = $(list[0]).parent().prev().children().children();
        var numList = [];
        var num = 0;
        for (var j = 0; j < headList.length; j++) {
            if ($(headList[j]).is(':visible') && $(headList[j]).text() != '' && $(headList[j]).text() != 'No') {
                if (numList.length == 0) {
                    num = 0
                }
                if (str != '') {
                    str += ",";
                }
                str += '"' + $(headList[j]).find(".ui-column-title").text() + '"';
                numList.push(num);
            }
            num++;
        }
        for (var i = 0; i < list.length; i++) {
            var childListText = $(list[i]).find(".copyRowData").text();
            var childList = childListText.substring(1, childListText.length - 1).split(', ');
            str += "\r\n";
            for (var j = 0; j < numList.length; j++) {
                if (j != 0) {
                    str += ",";
                }
                var rowtext = childList[numList[j]].split('=');
                str += '"' + rowtext[1] + '"';
            }
        }
    }
    var input = document.createElement('textarea');
    input.setAttribute('id', 'copyinput');
    document.body.appendChild(input);
    input.value = str;
//    input.value = $checkList;
    input.select();
    document.execCommand('copy');
    document.body.removeChild(input);
}

// 配色定義処理
function initCustomColor() {
    var items = $("label:contains('_emp')");
    var len = items.length;
    var ids = [];
    for (var i = 0; i < len; i++) {
        var colors = $(items[i]).html();
        var color = colors.substring(colors.indexOf('_emp') - 1, colors.indexOf('_emp'));
//        ids.push(colors.substring(colors.indexOf('_emp') - 1, colors.indexOf('_emp')));
//        alert(color);
        switch (parseInt(color))
        {
            case 0:
                $(items[i]).parent().css("backgroundColor", "#fafafa");
                break;
            case 1:
                $(items[i]).parent().css("backgroundColor", "#c6c6c6");
                break;
            case 2:
                $(items[i]).parent().css("backgroundColor", "#ffffcc");
                break;
            case 3:
                $(items[i]).parent().css("backgroundColor", "#d8ffca");
                break;
            case 4:
                $(items[i]).parent().css("backgroundColor", "#ffdceb");
                break;
            case 5:
                $(items[i]).parent().css("backgroundColor", "#e64b4b");
                break;
            case 6:
                $(items[i]).parent().css("backgroundColor", "#D9F3FF");
                break;
            case 7:
                $(items[i]).parent().css("backgroundColor", "#F0FDCF");
                break;
            case 8:
                $(items[i]).parent().css("backgroundColor", "#186BA0");
                break;
            case 9:
                $(items[i]).parent().css("backgroundColor", "#EEEEEE");
                break;
            default:
                break;
        }
    }
}

// 編集項目の背景色変更
function changeColorOnListChange(key) {
    var item = $("label:contains('" + key + "')");
    var org = item.next().find('input').attr('value');
    var mid = item.next().find('input').val();
//    alert(org);
//    alert(mid);
    if (typeof (org) == 'undefined' && mid == '') {
        item.parent().removeAttr('style');
    } else if (org != mid) {
        item.parent().css('backgroundColor', '#FFBBFF');
    } else {
        item.parent().removeAttr('style');
    }
}

// 一覧内のAutoCompleteラベル反映対応
function changeValueOnListSelect(key) {
    var item = $("label:contains('" + key + "')");
    var mid = item.next().find('input').val();
    if (mid !== '') {
        var labelValue = item.parent().next().find("label:contains('" + mid + " ')").html();
        var label = labelValue.substring(labelValue.indexOf(' '));
        var target = item.parent().next().find("label").attr('id');
//    alert(target);
        document.getElementById(target).innerHTML = label;
    } else {
        var labelValue = item.parent().next().find("label:contains('" + mid + " ')").html();
        var label = labelValue.substring(labelValue.indexOf(' '));
        var target = item.parent().next().find("label").attr('id');
        document.getElementById(target).innerHTML = '';
    }
}

// 一覧内のAutoCompleteラベル反映対応（同一セル）
function changeValueOnListSelectOneCell(key) {
    var item = $("label:contains('" + key + "')");
    var mid = item.next().find('input').val();
    if (mid !== '') {
        var labelValue = item.parent().find("label:contains('" + mid + " ')").html();
        var label = labelValue.substring(labelValue.indexOf(' '));
        var target = item.next().next().attr('id');
        document.getElementById(target).innerHTML = label;
    } else {
         var labelValue = item.parent().find("label:contains('" + mid + " ')").html();
        var label = labelValue.substring(labelValue.indexOf(' '));
        var target = item.next().next().attr('id');
        document.getElementById(target).innerHTML = '';
    }
}

var checkStatus = 2;
// フィルタトグルボタン
function filterToggle(formID, tableID) {
//alert(PF('filterTgl'));
    var func = PF('filterTgl');
    if (func !== undefined) {
        if (PF('filterTgl').getJQ().find(':checked').val() === 'true') {
            $("#" + formID + "\\:" + tableID + " th select").show();
            $("#" + formID + "\\:" + tableID + " th input").show();
            checkStatus = 1;
        } else {
            $("#" + formID + "\\:" + tableID + " th select").hide();
            $("#" + formID + "\\:" + tableID + " th input").hide();
            checkStatus = 2;
        }
    }

}

// p:datatable stickyHeaderを使うとヘッダが壊れるため、jquery.floatTheadを使う
var tablecount = 0;
function tableFloatThead() {
    //件数が0件の場合は動作させない
    if (tablecount == 0) {
        return;
    }

    // floatThead-tableが存在する場合は、処理を終了する。
    if ($('.floatThead-table').length == 1) {
        return;
    }

    var $pftable = PF('wtableCus011').getThead().parent();
    $pftable.floatThead({
        position: 'absAndFixed',
        zIndex: 2,
    });
    tableReflow();
    colTogglerRefresh('wdToggler');
}

/**
 * ColumnTogglerのリフレッシュ
 * @param wdName ウィジェット名
 * @returns null
 */
function colTogglerRefresh(wdName) {
    var $chks = $('.ui-columntoggler-item > .ui-chkbox > .ui-chkbox-box');

    $chks.each(function (i, val) {
        var $val = $(val);
        if ($val.hasClass('ui-state-active')) {
            //PF(wdName).check($val);
        } else {
            PF(wdName).uncheck($val);
        }
    });

}

// 検索btn押下時のfilter制御
function filterLoad(formID, tableID) {

    if ($("input[id$='filterTgl:1']").html() !== undefined) {
        if ($("input[id$='filterTgl:1']").prop("checked")) {
            filterToggle(formID, tableID);
        } else {
            filterToggle(formID, tableID);
            $("input[id$='filterTgl:1']").attr('checked', true);
            $("input[id$='filterTgl:1']").parent().addClass("ui-state-active");
        }
    }
}

// filterのステータスを回復
function recoverFilter(formID, tableID) {

    if (checkStatus === 1) {
        $("input[id$='filterTgl:0']").parent().addClass("ui-state-active");
        $("#" + formID + "\\:" + tableID + " th select").show();
        $("#" + formID + "\\:" + tableID + " th input").show();
    } else if (checkStatus === 2) {
        $("input[id$='filterTgl:1']").attr('checked', true);
        $("input[id$='filterTgl:1']").parent().addClass("ui-state-active");
        $("#" + formID + "\\:" + tableID + " th select").hide();
        $("#" + formID + "\\:" + tableID + " th input").hide();
    }

}

// 再検索
function searchAgain(serchId) {
    $("button[id$='" + serchId + "']").click();
}

// 条件クリア用
function clearCondition(clearIds) {
    
    var ids = clearIds.split(":");
    
    for (i = 0; i < ids.length; i++)
    {
        var conInputs = $("input[id$='" + ids[i] + "']");
        conInputs.val("");
        var conLabels = $("label[id$='" + ids[i] + "_label']");
        conLabels.text("　");
        var checkBoxsDiv0 = $("input[id$='" + ids[i] + ":0']");
        var checkFlg = checkBoxsDiv0.parent().next().attr("class");
        if (typeof (checkFlg) != 'undefined' && checkFlg.indexOf('ui-state-active') > 0) {
            checkBoxsDiv0.click();
        }
    }

}

// 条件クリア用
function clearForCondition(cleanIgnore) {
    if (cleanIgnore === 'true') {
        return;
    } else {
        $("#searchForm").html(conInit);
    }
}

function replaceBlankCol() {
    var items = $("label:contains('blankCol;')");
    var len = items.length;
    for (var i = 0; i < len; i++) {
        var item = $(items[i]);
        if (item.html() === 'blankCol;') {
            item.html('&nbsp;');
        }
    }
}