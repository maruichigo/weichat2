/*
 * 個別JSファイル 
 * cus.js 
 * Copyright (c) Shared System Inc.
 */ 

var valflg=false;
jQuery(document).ready(function(){                
    
    //サブ検索条件の制御
    subToggler(0);  // 初期状態
    
    // パンくずからの遷移用
    tableFloatThead();
});

// サブ検索条件
function subToggler() {
    
    // サブ検索条件判定
    $("a[id$='searchForm:searchSub_toggler']").on("click", function(){
        var str =  $("a[id$='searchForm:searchSub_toggler']").html();
        if (str.indexOf('ui-icon-plusthick') != -1) {
           tglflg = 1;  // チェックあり
        } else {
           tglflg = 0;  // 初期状態    
        }
        subTogglerCtrl(tglflg);
    });  
}

// サブ検索条件の制御
function subTogglerCtrl(tglflg) {
    valflg=false;

    // 初期表示
    if ( tglflg == 0 ) {
        // 初期状態
       $('div[id$="searchForm:searchSub_header"] > span[class$="ui-panel-title"]').html('<span class="ui-panel-title" >サブ検索条件</span>');
       return;
    }
        
    // チェックするかの判定
    if ( tglflg == 2 ) {
        var str =  $("a[id$='searchForm:searchSub_toggler']").html();
        if (str.indexOf('ui-icon-plusthick') == -1) {
           return;
        }
    }

    // サブ検索条件が使用される場合に星マークを付与する処理判定開始
    // サブ検索条件項目のテキストボックスが使用されているか
    var inputText = $("div[id$='searchForm:searchSub_content']").find("input[type='text']").map(function (index, el) {
        return $(this).val();
    });    

    // サブ検索条件項目のチェックボックスが使用されているか
    var inputCheck = $("div[id$='searchForm:searchSub_content']").find("input[type='checkbox']:checked").map(function (index, el) {
        return $(this);
    });

    // サブ検索条件項目のセレクトボックスが使用されているか
    var selectCheck = $("div[id$='searchForm:searchSub_content']").find("option:selected").map(function (index, el) {
       return $(this).val(); 
    });

    for (i = 0; i < inputText.length; i++) {
        if ( inputText[i] != "" ) {
            valflg=true;
            break;
        }
    }

    for (i = 0; i < inputCheck.length; i++) {
        if ( inputCheck[i] ) {
            valflg=true;
            break;
        }
    }

    for (i = 0; i < selectCheck.length; i++) {
        if ( selectCheck[i] !== "" ) {
            valflg=true;
            break;
        }
    }  

    // 入力があればサブ検索の先頭に星マークを付与
    if ( valflg ){
        $('div[id$="searchForm:searchSub_header"] > span[class$="ui-panel-title"]').html('<span class="ui-panel-title subsearch-icon">&emsp;&emsp;サブ検索条件</span>');
    } else {
        $('div[id$="searchForm:searchSub_header"] > span[class$="ui-panel-title"]').html('<span class="ui-panel-title" >サブ検索条件</span>');                
    }  
}
