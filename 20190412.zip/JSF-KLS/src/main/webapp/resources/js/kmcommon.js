$(document).ready(function () {
    // AutoCompleteのスクロールのクリックバグ修正
    $('body').on('mousedown', '.ui-autocomplete-panel', function (event) {
        event.stopImmediatePropagation();
    });

    // Datatableの最終行のセルにタブ使用バグ対応
    PrimeFaces.widget.DataTable.prototype.showCurrentCell = function (cell) {
        var $this = this;
        if (this.currentCell) {
            if (this.cfg.saveOnCellBlur)
                this.saveCell(this.currentCell);
            else if (!this.currentCell.is(cell))
                this.doCellEditCancelRequest(this.currentCell);
        }
        if (cell && cell.length) {
            this.currentCell = cell;
            var cellEditor = cell.children('div.ui-cell-editor'), displayContainer = cellEditor.children('div.ui-cell-editor-output'), inputContainer = cellEditor.children('div.ui-cell-editor-input'), inputs = inputContainer.find(':input:enabled'), multi = inputs.length > 1;
            cell.addClass('ui-state-highlight ui-cell-editing');
            displayContainer.hide();
            inputContainer.show();
            inputs.eq(0).focus().select();
            if (multi) {
                var oldValues = [];
                for (var i = 0; i < inputs.length; i++) {
                    var input = inputs.eq(i);
                    if (input.is(':checkbox')) {
                        oldValues.push(input.val() + "_" + input.is(':checked'));
                    } else {
                        oldValues.push(input.val());
                    }
                }
                cell.data('multi-edit', true);
                cell.data('old-value', oldValues);
            } else {
                cell.data('multi-edit', false);
                cell.data('old-value', inputs.eq(0).val());
            }

            if (!cell.data('edit-events-bound')) {
                cell.data('edit-events-bound', true);
                inputs.on('keydown.datatable-cell', function (e) {
                    var keyCode = $.ui.keyCode, shiftKey = e.shiftKey, key = e.which, input = $(this);
                    if (key === keyCode.ENTER || key == keyCode.NUMPAD_ENTER) {
                        $this.saveCell(cell);
                        e.preventDefault();
                    } else if (key === keyCode.TAB) {
                        if (multi) {
                            var focusIndex = shiftKey ? input.index() - 1 : input.index() + 1;
                            if (focusIndex < 0 || (focusIndex === inputs.length) || input.parent().hasClass('ui-inputnumber') || input.parent().hasClass('ui-helper-hidden-accessible')) {
                                $this.tabCell(cell, !shiftKey);
                            } else {
                                inputs.eq(focusIndex).focus();
                            }
                        } else {
                            $this.tabCell(cell, !shiftKey);
                        }
                        e.preventDefault();
                    } else if (key === keyCode.ESCAPE) {
                        $this.doCellEditCancelRequest(cell);
                        e.preventDefault();
                    }
                }).on('focus.datatable-cell click.datatable-cell', function (e) {
                    $this.currentCell = cell;
                });
            }
        } else {
            this.currentCell = null;
        }
    }
});

var km = km || {
    //検索ダイアログを表示する。
    showSearchHelpDialog: function (vid, did, count) {
        km.searchId = vid;
        var spanId = "#"+did +"_"+ "search_count";
        $(spanId).html(count);
        PF(did).show();
    },
    
    // 確認ダイアログを表示する。
    showConfirmDialog: function () {
        // デフォルトdialog_id
        var tid = 'confirmDialog';
        
        // パラメータからdialog_id取得
        if (arguments.length === 1 ) {
            tid = arguments[0];
        }
        PF(tid).show();
        return false;
    },
    
    // ブラウザの新タブを開く
    showNewTab : function (url) {
        window.open(url)
    },
    
    // モーダルダイアログを表示する
    showModalDialog : function(url) {
        
    },

    searchId: undefined,

    //検索処理を行う。
    doSearch: function () {
        if (!km.searchId) {
            return;
        }
        PF("realSerchBtn" + km.searchId).jq.click();
    },
    
    //ダイアログを閉じる
    closeDlg: function (widgetId, closeFlg) {
        if (closeFlg === "false" || closeFlg === false) {
            return;
        }
        PF(widgetId).hide();
    },

    //エラー項目のエラー情報を表示する。
    showError: function () {
        km.cleanTips();
        var tips = [];
        $(".e-div .ui-message-error").each(function () {
            //メッセージ情報に更新がある場合は、エラー情報を初期表示
            var readyflg= true;
             if( $(this).hasClass("km-error-shown") ){
                  //メッセージ情報に更新がない場合は、エラー情報を初期表示しない
                readyflg = false;
             }
            var target = $("[id='" + this.id.replace("_msg", "") + "']");
          
            tips.push(km.qtipFuC(target.parent(), $(this).find("span").attr("title"),readyflg)) ;
            target.parent().addClass("km-error-field");
            $(this).addClass("km-error-shown");
        })
        $(".km-error-field").each(function () {
            var msg = $(this).parent().find(".ui-message-error");
            if (msg.length === 0) {
                $(this).qtip('destroy', true);
                $(this).removeClass("km-error-field");
            }
        });
        setTimeout(function () {
//             $( tips[0]).qtip("api").toggle(false);
           for(var i = 0;i<  tips.length;i++){ 
                $(tips[i]).qtip("api").toggle(false);
           };
        }, 1000);

    },
    
    //qtipを使用して、エラー情報を表示する。
    qtipFuC: function (target, contet,readyflg) {
        $(target).qtip('destroy', true);
      var tip =  $(target).qtip({
            content: {text: contet },
            show: {
               ready:readyflg
            },
            hide: {
//                event:false,
                delay: 500
            },
            position: {
                my: 'bottom left',
                at: 'top left',
                adjust: {
                    x: 20
                }
            },
            style: {
                classes: 'qtip-blue qtip-shadow'
            }
        });
        return tip;
    },
    
    //エラー情報をクリアする。
    cleanTips: function () {
        $('.qtip').qtip('destroy', true);
    }
};
  