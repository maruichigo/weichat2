/*
 * MenuModelBean.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.beans.session;

import java.io.Serializable;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import jp.co.kintetsuls.exception.SystemException;
import lombok.Getter;
import lombok.Setter;
import org.primefaces.event.MenuActionEvent;
import org.primefaces.model.menu.MenuModel;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * メニューBean
 * @author saihara
 */
@ManagedBean(name = "menuBean")
@SessionScoped
public class MenuBean implements Serializable {

    @Getter @Setter
    private MenuModel model;    // メニュー情報
   
    @ManagedProperty(value = "#{breadBean}")    // パンくずBean
    private BreadCrumbBean breadBean;
    
    private static final Logger logger = LogManager.getLogger(new Object(){}.getClass().getEnclosingClass().getName()); // ログ出力
 
    public MenuBean() {
    }
    
    public MenuBean(MenuModel model) {
        if (model != null) {
            this.model = model;
        }  
    }

    /**
     * メニュークリック（トリガー）
     * @param event     メニュークリック時のイベント
     * @return          遷移先の画面URL
     * @throws jp.co.kintetsuls.exception.SystemException 
     */    
    public String menuClick(MenuActionEvent event) throws SystemException {
        String menuId;
        String nextScreen;
        String url;
        
        try{
            // パラメータ取得
            menuId = event.getMenuItem().getParams().get("menuId").get(0);          //メニューID
            nextScreen = event.getMenuItem().getParams().get("screenId").get(0);    //遷移先画面
        }catch(Exception ex){
            logger.error(ex.getMessage(), ex);
            throw new SystemException(ex);
        }
        
        // メニュークリック実行
        url = breadBean.getCurr().menuClick(menuId, nextScreen);        
        return url;
    }

    /**
     * @return the breadBean
     */
    public BreadCrumbBean getBreadBean() {
        return breadBean;
    }

    /**
     * @param breadBean the breadBean to set
     */
    public void setBreadBean(BreadCrumbBean breadBean) {
        this.breadBean = breadBean;
    }
}