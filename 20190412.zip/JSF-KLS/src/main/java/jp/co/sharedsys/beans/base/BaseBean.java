/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.sharedsys.beans.base;

import java.io.Serializable;
import javax.annotation.PostConstruct;
import javax.faces.application.ConfigurableNavigationHandler;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import javax.servlet.http.HttpSession;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.utils.FlashUtil;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * ベースBean
 * @author Shared System Inc.
 */
public abstract class BaseBean implements Serializable  {   

    private static final Logger logger = LogManager.getLogger(new Object(){}.getClass().getEnclosingClass().getName()); // ログ出力

    private FlashUtil flashUtil = new FlashUtil();

    /**
     * コンストラクタ
     */
    public BaseBean() {
    }

    /**
     * 初期処理（トリガー）
     */
    @PostConstruct
    public void baseInit(){
        String prevScreen = "";     //遷移元画面
        String menuId = "";         //メニューID
        boolean backFlg = false;    //前画面フラグ

        try{
            if (FacesContext.getCurrentInstance().isPostback()) {
               return;
            }

            // パラメータ取得
            Flash flash = FacesContext.getCurrentInstance().getExternalContext().getFlash();
            if(flash.size() > 0) {  
                // 遷移元画面
                if(flash.get("prevScreen") != null){
                    prevScreen = flash.get( "prevScreen").toString();
                }

                // メニューID
                if(flash.get("menuId") != null){
                    menuId = flash.get( "menuId").toString();
                }

                // 前画面フラグ
                if(flash.get("backFlg") != null){
                    backFlg = Boolean.valueOf(flash.get("backFlg").toString());
                }

                // 初期処理実行
                init(menuId, prevScreen, backFlg);
            } else {
                FacesContext context = FacesContext.getCurrentInstance();
                if (!"/login.xhtml".equals(context.getViewRoot().getViewId())){
                    //ログイン画面以外の場合は認証Beanを取得してログアウト
                    ExternalContext extContext = context.getExternalContext();
                    HttpSession session = (HttpSession) extContext.getSession(false);
                    AuthorityConfBean authConf = (AuthorityConfBean)session.getAttribute("authConfBean");
                    if (null != authConf){
                        ConfigurableNavigationHandler handler = (ConfigurableNavigationHandler)context.getApplication().getNavigationHandler();
                        handler.performNavigation(authConf.logout());
                    } else {
                        //認証Beanが取得出来なければ、そのままログアウト。
                        ConfigurableNavigationHandler handler = (ConfigurableNavigationHandler)context.getApplication().getNavigationHandler();
                        handler.performNavigation(Cnst.SCREEN.LOGIN_SCREEN.getXhtml()+"?faces-redirect=true");
                    }
                }
            }

        }catch(NumberFormatException ex){
            logger.error(ex.getMessage(), ex);
        }
    }

    /**
     * 初期処理（処理）
     * @param menuId        クリックされたメニューID（メニューからの遷移以外はNULL）
     * @param prevScreen    遷移元の画面
     * @param backFlg       戻るフラグ（前画面へボタンからの遷移以外はFALSE）
     */
    public abstract void init(String menuId, String prevScreen, boolean backFlg);

    /**
     * メニュークリック（処理）
     * @param menuId        クリックされたメニューID（メニューからの遷移以外はNULL）
     * @param nextScreen    遷移先の画面
     * @return              遷移先の画面URL
     */
    public abstract String menuClick(String menuId, String nextScreen);

    /**
     * パンくずクリック（処理）
     * @param nextScreen    遷移先の画面
     * @param breadIndex    選択されたパンくずのIndex
     * @return              遷移先の画面URL 
     */
    public abstract String breadClumClick(String nextScreen, int breadIndex);
    
    /**
     * ログアウトクリック（処理）
     * @return              遷移先の画面URL 
     */
    public abstract String logoutClick();
    
    /**
     * 画面遷移処理
     * @param nextScreen    遷移先の画面
     * @param menuId        クリックされたメニューID（メニューからの遷移以外はNULL）
     * @param prevScreen    遷移元の画面
     * @param backFlg       戻るフラグ（前画面へボタンからの遷移以外はFALSE）
     * @return              遷移先の画面URL 
     */
    public String forward(String nextScreen, String menuId, String prevScreen, boolean backFlg){
        String url;             //URL
        
        // 遷移先画面を特定
        try{
            Cnst.SCREEN screen = Cnst.SCREEN.valueOf(nextScreen);
            url = screen.getXhtml() + "?faces-redirect=true";
        }catch(Exception ex){
            // 画面遷移しない
            logger.error(ex.getMessage(), ex);
            return "";
        }

        // パラメータ設定
        Flash flash = flashUtil.getPageParam();
        flash.put("nextScreen", nextScreen);
        flash.put( "prevScreen", prevScreen);
        flash.put( "menuId", menuId);
        flash.put("backFlg", String.valueOf(backFlg));
        
        // 画面遷移先のURLを返す
        return url;
        
    };
}
