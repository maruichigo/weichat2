/*
 * AuthorityConfBean.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.beans.session;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import jp.co.kintetsuls.service.common.ComponentBean;
import jp.co.kintetsuls.beans.logout.LogoutBean;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.service.common.AuthorityService;
import jp.co.kintetsuls.service.general.RestfullService;
import lombok.Data;

/**
 * ログインユーザー情報を格納するManagedBeanです。
 * ログイン成功時に生成され、セッションスコープで持ち回ります。
 * @author Shared System Inc.
 */
@ManagedBean(name = "authConfBean")
@SessionScoped
@Data
public class AuthorityConfBean implements Serializable {

    private static final long serialVersionUID = -8006365439680582676L;

    // ToDo:下記はログイン処理にてDBから取得するようにしてください。
    private String userName = "";
    private String userDepartment = "";

    /** login時に取得 */
    private String userCd = null;

    /**  コンポーネント権限リスト Map<screenCode, Map<component , 権限>  */
    private Map<String, Map<String, ComponentBean>> authComponentMap = new HashMap<>();
    
    /** 担当営業所一覧 List＜Map{{VALUE:営業所CD}, {LABEL_VALUE:営業所名}, {LABEL:営業所CD:営業所名}}＞ */
    private Map<String, String> availableEigyoshoMap;
    
    /**
     * ログインユーザー所属営業所
     */
    private List<String> loginUserShozokuEigyosho;

    /** デフォルト営業所 */
    private String defaultEigyosho;

    /**
     * デフォルト営業所より取得された本社フラグ
     */
    private Boolean honshaFlg = false;
    
    /** パンくず情報 */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * 本社判断
     * 
     * @return 本社フラグ
     */
    public Boolean isHonsha() {
        AuthorityService authService = new AuthorityService();
        ServiceInterfaceBean sib = authService.eigyoshoShubetsuCheck(defaultEigyosho);
        if("3".equals(String.valueOf(sib.getJson()))){
            return true;
        }
        return false;
    }
    
    /**
     * ログアウトクリック（各業務処理を呼び出す）
     * @return          遷移先の画面URL
     */       
    public String logoutClick() {
        String url;
        url = getBreadBean().getCurr().logoutClick();
        return url;
    }  

    /**
     * ログアウト実行
     * @return          遷移先の画面URL
     */      
    public String logout() {
        if (new LogoutBean().execute(this)){
            return "";//ログアウト中止
        }
        FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
        return Cnst.SCREEN.LOGIN_SCREEN.getXhtml()+"?faces-redirect=true";
    }
    
    
}
