/*
 * BreadCrumbBean.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.sharedsys.beans.session;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.sharedsys.beans.base.BaseBean;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.EnumUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.event.MenuActionEvent;
import org.primefaces.model.menu.DefaultMenuItem;
import org.primefaces.model.menu.DefaultMenuModel;
import org.primefaces.model.menu.DynamicMenuModel;
import org.primefaces.model.menu.MenuElement;
import org.primefaces.model.menu.MenuModel;

/**
 * パンくずリスト表示用Bean
 * @author s_furutani
 */
@ManagedBean(name = "breadBean")
@SessionScoped
public class BreadCrumbBean implements Serializable {
    
    private static final long serialVersionUID = -8006365439680582699L;

    @Getter @Setter
    private BaseBean curr;      // 現在表示している画面Bean
    
	@Getter @Setter
	private MenuModel model;    // パンくず情報

    @Getter @Setter
	private int menuindex = 0;  // パンくずIndex

    private static final Logger logger = LogManager.getLogger(new Object(){}.getClass().getEnclosingClass().getName()); //ログ出力
    
	public BreadCrumbBean() {
		init();
	}

	/**
	 * 初期化
	 */    
	public void init(){
		model = new DefaultMenuModel();
	}
    
	/**
	 * パンくずリスト追加
     * @param title         パンくずに追加する画面名
     * @param screenId      パンくずに追加する画面のID
     * @param bean          パンくずに追加する画面ののBean
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException 
	 */
	public void push(String title, String screenId, BaseBean bean) throws IllegalAccessException, InvocationTargetException {

        // パンくず表示更新
		for (MenuElement me : model.getElements()) {
            DefaultMenuItem item = (DefaultMenuItem)me;
			item.setDisabled(false);    // 押下可
			item.setStyleClass("");
		}
        
        // パンくず追加
        int index = model.getElements().size();
            if (index > 0) {
                DefaultMenuItem itemPre = (DefaultMenuItem) model.getElements().get(index - 1);
                if (!title.equals(itemPre.getValue())) {
                    DefaultMenuItem item = createMenuItem(title, screenId);
                    model.addElement(item);
                    model.generateUniqueIds();
                } else {
                    this.pop(1);
                    DefaultMenuItem item = createMenuItem(title, screenId);
                    model.addElement(item);
                    model.generateUniqueIds();
                }
            } else {
                DefaultMenuItem item = createMenuItem(title, screenId);
                model.addElement(item);
                model.generateUniqueIds();
            }

        // 現在の画面Beanを保持
        curr = bean;        
	}

	/**
	 * パンくずリスト削除
     * @param breadIndex    パンくずのIndex
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException 
	 */
	public void pop(int breadIndex) throws IllegalAccessException, InvocationTargetException {
        int i=0;
        menuindex = 0;
        
        // 遷移先の画面はpushで登録するので遷移先の画面まで削除する
		DynamicMenuModel tmpModel = new DynamicMenuModel();
		for (MenuElement me : model.getElements()) {
            DefaultMenuItem item = (DefaultMenuItem)me;
            if(breadIndex == 0) {
                break;
            }
            if(i < breadIndex) {
                tmpModel.addElement(item);
            }else if (i == breadIndex) {
                break;
            }
            menuindex++;
            i++;
		}
		// model入替え
		model = tmpModel;
    }

	/**
	 * ぱんくずリストに入れるアイテムの新規作成
	 * @param title パンくずに追加する画面名
	 * @return      パンくずの情報
	 */
	private DefaultMenuItem createMenuItem(String title, String screenId) {
        DefaultMenuItem item = new DefaultMenuItem(title);
		item.setValue(title);
		item.setUpdate(":main_section");
		item.setParam("index", Integer.toString(menuindex));
		item.setParam("screenId", screenId);
		item.setId(Integer.toString(menuindex));    //一意ユニークを与えないと仕様でエラーになります。
		item.setStyleClass("current-bread-crumb");

        item.setCommand("#{breadBean.breadClumClick}");
        item.setDisabled(true);
        
        //メニューのOnstart,OnCompleteが登録されていたら登録
        if(EnumUtils.isValidEnum(Cnst.SCREEN_ACT.class, "START_COMPLETE")) {
            Cnst.SCREEN_ACT act = Cnst.SCREEN_ACT.valueOf("START_COMPLETE");
            item.setOnstart(act.getOnStart());
            item.setOncomplete(act.getOnComplete());       
        }

		menuindex++;       
		return item;
	}

	/**
	 * ぱんくずクリック時のイベント
     * @param event     パンくずクリック時のイベント
     * @return          遷移先の画面URL
     * @throws jp.co.kintetsuls.exception.SystemException
	 */    
    public String breadClumClick(MenuActionEvent event) throws SystemException {
        String nextScreen;
        String url;
        int breadIndex;

        try{
            // パラメータ取得
            nextScreen = event.getMenuItem().getParams().get("screenId").get(0);                    //遷移先画面
            breadIndex = Integer.valueOf(event.getMenuItem().getParams().get("index").get(0));   //パンくずIndex
        }catch(NumberFormatException ex){
            logger.error(ex.getMessage(), ex);
            throw new SystemException(ex);
        }
        
        // パンくずイベント実行
        url = curr.breadClumClick(nextScreen, breadIndex);

        return url;
    }

    /**
     * ロゴ画像クリック時のイベント(TOPへ戻る)
     * @return 遷移先(TOP)の画面URL
     */
    public String logoClick(){
        return curr.breadClumClick(Cnst.SCREEN.TOP_SCREEN.name(), 0);
    }
    
}