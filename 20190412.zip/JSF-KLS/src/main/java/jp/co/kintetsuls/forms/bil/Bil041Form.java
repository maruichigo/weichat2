/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.forms.bil;

import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import lombok.Data;

/**
 *
 * @author wanglinjing
 */
@ManagedBean(name = "bil041Form")
@ViewScoped
@Data
public class Bil041Form {

    /**
     * 営業所コード
     */
    private AutoCompOptionBean conEigyoayoCd;
    /**
     * 営業所名
     */
    private String conEigyoayoMei;
    /**
     * 请求先名
     */
    private String conSeikyusakiMei;
    /**
     * 请求先コード
     */
    private AutoCompOptionBean conSeikyusakiCode;
    /**
     * mode
     */
    private String gamenMode;
    /**
     * 基準日
     */
    private Date conKijubi;
    /**
     * 要求締日
     */
    private Date conYochyuShimeibi;
    /**
     * 1.今すぐ発行 2.締予約
     */
    private String danxuan;
    /**
     * row
     */
    private String row;
    /**
     * 締予定範囲
     */
    private String yoteihani;
    /**
     * 締予定範囲Start
     */
    private Date yoteihaniStart;
    /**
     * 締予定範囲End
     */
    private Date yoteihaniEnd;
    /**
     * 締選択
     */
    private String shimeiShentaku;
    /**
     * 締内容
     */
    private String shimeiRaiyo;
    /**
     * 締要求内容
     */
    private String shimeiyochyuRaiyo;
    /**
     * listRow
     */
    private String listRow;
    /**
     * 営業所コード
     */
    private String listEigyosyoCode;
    /**
     * 営業所名
     */
    private String listEigyosyoMei;
    /**
     * 請求先コード
     */
    private String listSeikyusakiCode;
    /**
     * 請求先名
     */
    private String listSeikyusakiMei;
    /**
     * 予約済み締範囲
     */
    private String listYuteifanwei;
    /**
     * 予約済み締範囲start
     */
    private Date listYoteihaniStart;
    /**
     * 予約済み締範囲end
     */
    private Date listYoteihaniEnd;
    /**
     * 締設定
     */
    private String listShimeiSetei;
    /**
     * 締予約者
     */
    private String listShimeiYoteshya;
    /**
     * 締予約日時
     */
    private Date listShimeiyuteHitoki;
    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;

    /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;

    /**
     * 選択された結果
     */
    private List<Map<String, String>> selectedSearchResult;
    /**
     * システムdate
     */
    private Date sysDate;
    /**
     * 件数
     */
    private String kensu;
}
