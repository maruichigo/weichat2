/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.cnst.SysMsg;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.service.general.RestfullService;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.event.SelectEvent;
import java.util.Iterator;
import jp.co.kintetsuls.utils.CheckUtils;

/**
 * 住所マスタ詳細画面
 *
 * @author ZC (MBP)
 * @version 2019/1/28 新規作成
 */
@javax.faces.bean.ManagedBean(name = "rirekisyosai")
@ViewScoped
@Data
public class RirekiSyosaiBean implements Serializable {

    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messageProperty;

    private RestfullService rest;

    // ボタン名称
    private String rirekiButtonName = "履歴確認";
    // 履歴タイトル
    private String rirekiTitle;
    // 履歴データ
    private List<RirekiBean> listRireki;
    // 選択さてた履歴レコード
    private RirekiBean selectedRireki;
    // 最新レコード
    private RirekiBean lastRireki;
    //　カーラー
    private String backgroundStyle = "background-color: lightblue";
    // データエンプティメッセージ
    private String dataEmptyMessage;

    /**
     * 一覧履歴タイトル
     */
    private List<String> listColName;

    /**
     * 一覧履歴DB物理カラム
     */
    private List<String> listColValue;

    /**
     * 一覧履歴カラムカーラー（特殊処理）
     */
    private String listColColor = "0";

    /**
     * 一覧履歴DB物理カラム
     */
    private List<RirekiListCol> listCol;

    /**
     * 一覧履歴データ
     */
    private List<Map<String, Object>> rirekiResult;

    private static final Logger logger = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    public RirekiSyosaiBean() {

    }

    // 
//    public String getRirekiButtonName() {
//        return rirekiButtonName;
//    }
    /**
     * 履歴詳細情報を取得
     *
     * @param titleFlg
     * @param functionCode
     * @param mstName
     * @param searchKey
     */
    public void getRireki(String titleFlg, String functionCode, String mstName, Map<String, Object> searchKey) {
        // 履歴画面タイトル
        if ("1".equals(titleFlg)) {
            this.rirekiTitle = "適用開始日毎";
        } else {
            this.rirekiTitle = "全更新";
        }

        listRireki = new ArrayList<>();
        ServiceInterfaceBean req = new ServiceInterfaceBean();

        // 検索用関数
        req.setFunctionCode(functionCode);

        //parameter
        Map<String, Object> params = new HashMap<>();

        // 検索キーの値
        Set setKey = searchKey.entrySet();
        Iterator iteratorKey = setKey.iterator();
        int i = 1;
        while (iteratorKey.hasNext()) {
            Map.Entry mapentry = (Map.Entry) iteratorKey.next();
            params.put(mapentry.getKey().toString(), mapentry.getValue().toString());
            i++;
        }
        //　検索テーブル
        params.put("MstName", mstName);
        params.put("rirekiShowFlg", titleFlg);
        String request = JSONUtil.makeJSONString(params);
        req.setJson(request);

        //JAX-RS接続を実行(SQL側のチェック処理など未実装。)
        rest = RestfullService.getInstance();
        ServiceInterfaceBean res;
        try {
            res = rest.request(req);
        } catch (Exception ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
            return;
        }

        if (res == null || res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return;
        }

        try {
            ObjectMapper mapper = new ObjectMapper();
            List<Map<String, Object>> resultList = mapper.readValue(res.getJson(), List.class);
            if (resultList == null || resultList.isEmpty()) {
                return;
            }

            // 履歴データ設定
            List<String> tekiyoKaishibiList = new ArrayList<>();
            for (Map<String, Object> rirekiData : resultList) {
                RirekiBean rireki = new RirekiBean();
                Map<String, Object> primaryKey = new HashMap<>();
                // 履歴データキー設定 
                iteratorKey = setKey.iterator();
                while (iteratorKey.hasNext()) {
                    Map.Entry mapentry = (Map.Entry) iteratorKey.next();
                    primaryKey.put(mapentry.getKey().toString(), rirekiData.get(mapentry.getKey().toString()));
                }
                primaryKey.put("DATA_VERSION", rirekiData.get("DATA_VERSION"));
                rireki.setPrimaryKey(primaryKey);
                // 履歴データ 
                rireki.setDataMapper(rirekiData);
                //　履歴一覧項目設定
                rireki.setLastUpdateDate(String.valueOf(rirekiData.get("KOSHIN_NICHIJI")));
                rireki.setLastUpdateUser(String.valueOf(rirekiData.get("KOSHIN_USER")));
                rireki.setVersion("Ver" + String.valueOf(rirekiData.get("DATA_VERSION")));
                if(String.valueOf(rirekiData.get("TEKIYO_KAISHIBI")) != null) {
                    rireki.setTekiyoKaishibi(String.valueOf(rirekiData.get("TEKIYO_KAISHIBI")));
                }
                if ("1".equals(titleFlg)) {
                    if (!tekiyoKaishibiList.contains(String.valueOf(rirekiData.get("TEKIYO_KAISHIBI")))) {
                        listRireki.add(rireki);
                        tekiyoKaishibiList.add(String.valueOf(rirekiData.get("TEKIYO_KAISHIBI")));
                    }
                } else {
                    listRireki.add(rireki);
                }
            }

        } catch (IOException ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
        }
        // 戻りSIBのステータスチェック、エラー処理
        if (listRireki == null || listRireki.isEmpty()) {
            messageProperty.message(MessagePropertyBean.SEVERITY_ERROR, "履歴データがありません。");
        }
    }

    public void onRirekiSelect(SelectEvent event) {

        selectedRireki = (RirekiBean) event.getObject();

        int count = listRireki.size();
        for (int i = 0; i < count; i++) {
            RirekiBean tempRireki = listRireki.get(i);
            if (i < count - 1) {
                tempRireki.setNext(listRireki.get(i + 1));
            }
            if (i > 0) {
                tempRireki.setPrevious(listRireki.get(i - 1));
            }
        }
        rirekiButtonName = "履歴モード終了";

    }

    public void rirekiButtonClick() {
        if ("履歴モード終了".equals(rirekiButtonName)) {
            rirekiButtonName = "履歴確認";

            selectedRireki = null;
        }
    }

    public void preRirekiButtonClick() {
        selectedRireki = selectedRireki.getPrevious();
    }

    public void nextRirekiButtonClick() {
        selectedRireki = selectedRireki.getNext();
    }

    public void searchList(String titleFlg, String functionCode, Map<String, Object> searchKey) {
        // 履歴画面タイトル
        if (CheckUtils.isEmpty(rirekiTitle)) {
            if ("1".equals(titleFlg)) {
                this.rirekiTitle = "適用開始日毎";
            } else {
                this.rirekiTitle = "全更新";
            }
        }
        ServiceInterfaceBean req = new ServiceInterfaceBean();

        req.setFunctionCode(functionCode);

        String requestData = JSONUtil.makeJSONString(searchKey);
        req.setJson(requestData);

        //JAX-RS接続を実行(SQL側のチェック処理など未実装。)
        rest = RestfullService.getInstance();
        ServiceInterfaceBean res;
        try {
            res = rest.request(req);
        } catch (Exception ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
            return;
        }

        if (res == null || res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return;
        }

        try {
            ObjectMapper mapper = new ObjectMapper();
            if ("1".equals(titleFlg)) {
                rirekiResult = new ArrayList<>();
                List<Map<String, Object>> resultList = mapper.readValue(res.getJson(), List.class);
                if (resultList.size() > 0) {
                    List<String> tekiyoKaishibiList = new ArrayList<>();
                    resultList.forEach((rirekiData) -> {
                        String strTekiyoKaishibi = String.valueOf(rirekiData.get("TEKIYO_KAISHIBI"));
                        if (!tekiyoKaishibiList.contains(strTekiyoKaishibi)) {
                            tekiyoKaishibiList.add(strTekiyoKaishibi);
                            rirekiResult.add(rirekiData);
                        }
                    });
                }
            } else {
                rirekiResult = mapper.readValue(res.getJson(), List.class);
            }
        } catch (IOException ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
            return;
        }
        // 戻りSIBのステータスチェック、エラー処理
        if (rirekiResult == null || rirekiResult.isEmpty()) {
            setDataEmptyMessage("履歴データがありません。");
        }
    }
}
