/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mst;

import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.annotation.NotNull;
import lombok.Data;

/**
 * 集約コードマスタ フォーム
 * 
 * @author 许博 (MBP)
 * @version 2019/1/24 新規作成
 */
@ManagedBean(name = "mst071Form")
@ViewScoped
@Data
public class Mst071Form {

    /**
     * 集約区分
     */
    @NotNull(message = "{COME0003}", name = "集約区分")
    private String conShuyakuKbn;
    
    /**
     * 集約区分Disabled
     */
    private boolean conShuyakuKbnDisabled;
    
    /**
     * 本社
     */
    private boolean conHonsha;

    /**
     * 集約コード
     */
    private AutoCompOptionBean conShuyakuCd;
    
    /**
     * 集約コードDisabled
     */
    private boolean conShuyakuCdDisabled;

    /**
     * 集約コード名称
     */
    private String conShuyakuCdMei;
    
    /**
     * 集約コード名称Disabled
     */
    private boolean conShuyakuCdMeiDisabled;

    /**
     * 営業所コード
     */
    private AutoCompOptionBean conEigyoshoCd;
    
    /**
     * 営業所コードDisabled
     */
    private boolean conEigyoshoCdDisabled;

    /**
     * 削除のみ検索
     */
    private String[] conSakujoNomiKensaku;

    /**
     * 削除のみ検索Disabled
     */
    private boolean conSakujoNomiKensakuDisabled;
    
    /**
     * 検索条件保持用集約区分
     */
    private String hShuyakuKbnHid;

    /**
     * 検索条件保持用営業所コード
     */
    private String hEigyoushoCdHid;
    
    /**
     * 編集Disabled
     */
    private boolean btnEditeDisabled;

    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;

    /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;

    /**
     * 選択された結果
     */
    private List<Map<String, Object>> selectedSearchResult;
}
