/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.common;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.annotation.NotEmpty;
import lombok.Data;

/**
 * 共通アップロード フォーム
 *
 * @author 王永 (MBP)
 * @version 2019/03/11 新規作成
 */
@javax.faces.bean.ManagedBean(name = "uploadForm")
@ViewScoped
@Data
public class UploadForm  implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * データ選択.
     */
    private String dataSelect;

    /**
     * アップロードメソッド.
     */
    private String uploadMethed;

    /**
     * ヘッダ.
     */
    private List<String> headerSt;
    
    /**
     * アップロード結果一覧データ
     */
    private List<Map<String, Object>> uploadResult;

    /**
     * アップロード結果一覧選択できる
     */
    private ReportListDataModel uploadResultSelectable;

    /**
     * 選択された結果
     */
    private List<Map<String, Object>> selectedSearchResult;
    
    /**
     * チェックボタンDisabled
     */
    private boolean conCheckButtonDisabled;
    
    /**
     * 登録ボタンDisabled
     */
    private boolean conTourokuButtonDisabled;
    
}
