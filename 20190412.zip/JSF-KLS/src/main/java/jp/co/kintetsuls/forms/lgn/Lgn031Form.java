/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.lgn;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.annotation.NotNull;
import jp.co.kintetsuls.beans.common.annotation.SizeCheck;
import lombok.Data;

/**
 * パスワード初期化フォーム
 * 
 * @author 黄義輝 (MBP)
 * @version 2019/03/19 新規作成
 */
@javax.faces.bean.ManagedBean(name = "lgn031Form")
@ViewScoped
@Data
public class Lgn031Form implements Serializable {

    /* 画面モード */
    private String mode;

    /* 申請ステータス */
    private String hyoDtlShinseiStatus;

    /* ユーザーコード */
    @NotNull(name = "ユーザーコード")
    @SizeCheck(size = 7, name = "ユーザーコード")
    private String hyoDtlUserCd;

    /* ユーザー名 */
    private String hyoDtlUserMei;

    /* ユーザー適用開始日 */
    private String hyoDtlUserTekiyoKaishibi;

    /* 通知方法 */
    private String hyoDtlTsuchiHoho;

    /* 電話番号 */
    private String hyoDtlTelBango;

    /* 連絡先担当者名 */
    private String hyoDtlRenrakusakiTantoshaMei;

    /* メールアドレス */
    private String hyoDtlMailAddress;

    /* 申請理由 */
    @NotNull(name = "申請理由")
    private String hyoDtlShinseiRiyu;

    /* 所属営業所 */
    private String hyoDtlShozokuEigyosho;

    /* 権限ロール */
    private String hyoDtlKengenRole;

    /* 申請回数 */
    private String hyoDtlShinseiKaisuu;

    /* パスワード誤入力回数 */
    private String hyoDtlPasswordGoNyuryokuKaisuu;
    
    /* パスワード誤入力最大回数 */
    private Integer hyoDtlPasswordGoNyuryokuSaidaiKaisu;
    
    /* メールアドレス不一致最大回数 */
    private Integer mailAddressFuitchiKaisu;

    /* メール申請ロック期間 */
    private String mailShinseiLockKikan;

    /* ワンタイムパスワード */
    private String hyoDtlOnetimePassword;

    /* 再発行 */
    private String hyoDtlSaiHakko;

    /* 本人連絡 */
    private String hyoDtlHonninrenraku;

    /* パスワード変更 */
    private String hyoDtlPasswordHenko;

    /* 申請ID */
    private String hyoDtlShinseiId;

    /* 進行状況アイコン */
    private String shnDtlListShinkojokyoIcon;

    /* 種別 */
    private String shnDtlListShubetsu;

    /* 箇所 */
    private String shnDtlListKasho;

    /* ユーザーアイコン */
    private String shnDtlListUserIcon;

    /* 名前 */
    private String shnDtlListNamae;

    /* 結果 */
    private String shnDtlListKekka;

    /* コメント */
    private String shnDtlListComment;

    /* 日時 */
    private String shnDtlListNichiji;
    
    /* 申請情報 */
    private List<Map<String, String>> shinseiInfoList;

    /* 承認者情報 */
    private List<Map<String, Object>> shoninshaInfoList;

    // 承認状況取得
    private List<Map<String, String>> syouninJyoukyouList;

    // 送信データ取得
    private Map<String, String> submitDateMap;

    /* 検索結果一覧データ */
    private List<Map<String, Object>> searchResult;

}
