/*
 * AutoCompOptionConverter.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common;

import java.util.Iterator;
import java.util.List;
import javax.faces.bean.ViewScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import org.primefaces.component.autocomplete.AutoComplete;

/**
 * AutoComplete コンポーネントで使用するPOJOを変換するためのクラス
 * @author saihara
 */
@FacesConverter("optionConverter")
@ViewScoped
public class AutoCompOptionConverter implements Converter {
 
    /**
     * リストから選択された時に呼び出されるメソッド。
     * @param context facesContext
     * @param component AutoComplete
     * @param value 入力値
     * @return selected object
     */
    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        AutoComplete uiobj = (AutoComplete) component;
        List list = (List) uiobj.getCompleteMethod().invoke(FacesContext.getCurrentInstance().getELContext(), new String[]{value});
        if (list != null && !list.isEmpty()) {
            for (Iterator it = list.iterator(); it.hasNext();) {
                AutoCompOptionBean rec = (AutoCompOptionBean) it.next();
                if (value.equals(rec.getValue())) {
                    return rec;
                }
            }
            return null;
        } else {
            return new AutoCompOptionBean(value,value);
        }
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {
        if (value instanceof String) {
            return String.valueOf(value);
        }
        
        if (value != null) {
            return ((AutoCompOptionBean)value).getValue();
        } else {
            return null;
        }
    }
}
