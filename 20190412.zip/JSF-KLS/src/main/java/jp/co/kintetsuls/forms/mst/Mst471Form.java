/*
 * Mst471Form.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mst;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.annotation.MaxSizeCheck;
import jp.co.kintetsuls.beans.common.annotation.NotEmpty;
import jp.co.kintetsuls.beans.common.annotation.NotNull;
import lombok.Data;

/**
 * 号車マスタ画面 フォーム
 * 
 * @author 徐有川 (MBP)
 * @version 2019/1/22 新規作成
 */
@ManagedBean(name = "mst471Form")
@ViewScoped
@Data
public class Mst471Form implements Serializable {
    
    /**
     * 営業所コード
     */
    @NotNull(message = "{COME0003}", name = "営業所コード")
    private AutoCompOptionBean conEigyoshoCd;
    
     /**
     * 営業所名
     */
    private String conEigyoshoMei;
    
    /**
     * 号車コード
     */
    @MaxSizeCheck(maxSize = 5, name = "号車コード")
    private String conGoshaCd;
    
    /**
     * 号車名
     */
    @MaxSizeCheck(maxSize = 40, name = "号車名")
    private String conGoshaMei;

    /**
     * 車両No
     */
    private AutoCompOptionBean conSharyoNo;
    
    /**
     * 車両名
     */
    
    private String conSharyoMei;
    
    /**
     * ドライバーコード
     */
    private AutoCompOptionBean conDriverCd;
   
    /**
     * ドライバー名
     */
    private String conDriverMei;
    
    /**
     * 世代検索条件
     */
    @NotEmpty(message = "{COME0022}", name = "世代検索条件")
    private String[] conSedaiKensakuJoken;
    
    /**
     * 適用日
     */
    private String conTekiyoBi;
    
    /**
     * 削除のみ検索
     */
    private String[] conSakujoNomiKensaku;
    
    /**
     * 検索Visabled
     */
    private boolean btnSearchVisible;

    /**
     * 検索条件変更Visabled
     */
    private boolean btnSearchChangeVisible;
    
    /**
     * 適用名
     */
    @MaxSizeCheck(maxSize = 40, name = "適用名")
    private String conTekiyoMei;
    
    /**
     * 編集Disabled
     */
    private boolean btnEditeDisabled;

    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;

     /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable; 
    
    /**
     * 検索結果 仕向地名マスタ
     */
    private ReportListDataModel searchResultShimukechi; 

     /**
     * 号車マスタ 選択された結果
     */
    private List<Map<String, Object>> selectedSearchResult;
    
    /**
     * 号車仕向地マスタ 選択された結果
     */
    private List<Map<String, Object>> selectedShimuSearchResult;
    
    /**
     * JISコードNotEmpty
     */
    private AutoCompOptionBean jisCodeNotEmpty;
    
    /**
     * 仕向地コードNotEmpty
     */
    private AutoCompOptionBean shimukechiCodeNotEmpty;
    
    /**
     * 仕向地の適用開始日
     */
    private String conTekiyoBiShimukechiMaster;
    
    /**
     * 設定をクリックして、dialogの表示用
     */
    private String conSettiShow;
    
    /**
     * 営業所コード
     */
    private String gdconEigyoshoCd;
    
     /**
     * 営業所名
     */
    private String gdconEigyoshoMei;
    
    /**
     * 号車コード
     */
    @NotNull(message = "{COME0041}", name = "号車コード")
    private String listGoshaCd;
    
    /**
     * 号車名
     */
    @NotNull(message = "{COME0041}", name = "号車名")
    private String listGoshaMei;
    
    /**
     * 適用開始日
     */
    @NotNull(message = "{COME0041}", name = "適用開始日")
    private String listTekiyoKaishiBi;
    
    /**
     * 適用名
     */
    @NotNull(message = "{COME0041}", name = "適用名")
    private String listTekiyoMei;
    
    /**
     * 車両No
     */
    @NotNull(message = "{COME0041}", name = "車両No")
    private AutoCompOptionBean listSharyoNo;
    
    /**
     * 車両名
     */
    private String listSharyoMei;
    
    /**
     * 仕向地JISコード(都道府県) 先頭2桁
     */
    private String hListJisCdTodofuken;
    
    /**
     * 仕向地JISコード(市区町村) 末尾3桁
     */
    private String hListJisCdShikuchoson;
    
    /**
     * ドライバーコード
     */
    @NotNull(message = "{COME0041}", name = "ドライバーコード")
    private String listDriverCd;
    
    /**
     * ドライバー名
     */
    private String listDriverMei;
    
    /**
     * 仕向地コード
     */
    private String hListShimukechiCd;
    
    /**
     * 住所
     */
    private String hListJusho;
    
    /**
     * 仕向地名
     */
    private String hListShimukechiMei;
    
     /**
     * 仕向地設定
     */
    private int listShimukechiSettei;
    
    /**
     * 設定
     */
    private String listbtnSettei;
    
    /**
     * 開始住所JISコード
     */
    private AutoCompOptionBean listKaishiJisCd;

    /**
     * 開始住所JIS住所
     */
    private String listKaishiJisJusho;

     /**
     * 終了住所JISコード
     */
    private AutoCompOptionBean listShuryoJisCd;

    /**
     * 終了住所JIS住所
     */
    private String listShuryoJisJusho;
    
    /**
     * ハンディ持参区分
     */
    private String listHandyJisanKbn;
    
     /**
     * 検索件数
     */
    private String count;
    
	/**
     * 仕向地コード
     */
    private AutoCompOptionBean listShimukechiCd;

    /**
     *  号車仕向地 リスト
     */
    private List<Map<String, Object>> gdShimukechiList;
	
	/**
     * 仕向地住所
     */
    private String listShimukechiJusho;
    
    /**
     * 適用終了日(チェックボックス)
     */
    private boolean listTekiyoShuryoBiChk;
    /**
     * 適用終了日 Disabled
     */
    private boolean listTekiyoShuryoBiDisabled = false;
    
    /**
     * 仕向地用
     */
    private String simukechiEgyouCd;
    
    /**
     * 仕向地用
     */
    private String simukechiGoshaCd;
    
    /**
     * 仕向地用
     */
    private String simukechiGoshaMei;
    
    /**
     * 仕向地用
     */
    private String simukechiTeiKyouBi;
    
    /**
     * 検索Visible
     */
    private boolean conDisabled;
}
