package jp.co.kintetsuls.service.general.property;

public class ServiceCnst {
    public static final String CONF_HOME = "conf-directory";
    public static final String PROP_SERVICE = "exservice.properties";
    public static final String AD_SERVICE = "adserver.properties";
    
}
