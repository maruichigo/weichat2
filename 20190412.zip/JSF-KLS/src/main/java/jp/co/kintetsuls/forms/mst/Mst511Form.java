/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mst;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.annotation.SelectOne;
import lombok.Data;

/**
 * 代理承認者設定マスタフォーム
 *
 * @author LiXinZhi (MBP)
 * @version 2019/3/1 新規作成
 */
@ManagedBean(name = "mst511Form")
@ViewScoped
@Data
public class Mst511Form implements Serializable {
    
     private static final long serialVersionUID = 1L;
     
    /**
     * 営業所コードAutoComp
     */
    @SelectOne(name = "営業所コード", message = "{COME0003}")
    private AutoCompOptionBean eigyoshokodo;
    
    /**
     * 営業所コードDisabled
     */
    private boolean coneigyoshokodoDisabled;

    /**
     * 削除済のみ
     */
    private String[] conSakujoSumiNomi;

    /**
     * 削除済のみDisabled
     */
    private boolean conSakujoSumiNomiDisabled;
    
    /**
     * 所属終了を含む
     */
    private String[] conShozokuShuryoWoFukumu;

    /**
     * 所属終了を含むDisabled
     */
    private boolean conShozokuShuryoWoFukumuDisabled;
    
    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;

    /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;

    /**
     * 選択された結果
     */
    private List<Map<String, Object>> selectedSearchResult;
    
    /**
     * 編集Disabled
     */
    private boolean btnEditeDisabled;

}
