/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst181Form;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 記事マスタ画面
 *
 * @author 謝航宇 (MBP)
 * @version 2019/3/12 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst181")
@ViewScoped
@Data
public class Mst181Bean extends AbstractBean {
    
    /**
     * ダウンロードファイル名
     */
    private final static String Title = "記事マスタ一覧";

    /**
     * タイトル
     */
    private final String strTitle = "記事マスタ";
    
    /**
     * 画面URL
     */
    private String url;     // URL

    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

    /**
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messageProperty;
    
    /**
     * ファイルダウンロード
     */
    @ManagedProperty(value = "#{fileBean}")
    private FileBean fileBean;

    /**
     * 画面項目保持
     */
    @ManagedProperty(value = "#{mst181Form}")
    @Getter
    @Setter
    private Mst181Form mst181Form;

    /**
     * 共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommon;
    
    /**
     * 共通作業
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;
    
    /**
     * 履歴一覧処理共通
     */
    @ManagedProperty(value = "#{rirekisyosai}")
    private RirekiSyosaiBean rirekiSyosai;
    
    /**
     * 一覧単項目チェック共通
     */
    @ManagedProperty(value = "#{listCheckBean}")
    private ListCheckBean listCheckBean;

    /**
     * ログ出力
     */
    private static final Logger LOGG_LOGGER = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    /**
     * ScreenCode：MST181.
     */
    private static final String SC_CD_MST181 = "MST181_SCREEN";

    /**
     * 定数：検索FUNC_CODE.
     */
    private static final String SEARCH_FUNC_CODE = "MST181_SEARCH";

    /**
     * 定数：更新FUNC_CODE.
     */
    private static final String UPDATE_FUNC_CODE = "MST181_UPDATE";
    
    /**
     * 定数：削除FUNC_CODEチェック.
     */
    private static final String FUNC_CODE_DELETE_EXIST = "MST181_DELETE_EXIST";
    
    /**
     * 定数：削除FUNC_CODE.
     */
    private static final String DELETE_FUNC_CODE = "MST181_DELETE";
    
    /**
     * 定数：登録の重複.存在チェックFUNC_CODE.
     */
    private static final String FUNC_CODE_INSERT_UPDATE_DUPLICATED = "MST181_INSERT_UPDATE_EXIST";
    
    /**
     * 定数：一覧のDataTableのID.
     */
    private static final String DATA_TABLE_ID = "tablesorter_mst181";
    
    /**
     * 定数：画面項目保持key.
     */
    private static final String CONST_MST181_FORM = "mst181Form";
    
    /**
     * 定数：検索件数取得FUNC_CODE.
     */
    private static final String FUNC_CODE_SEARCH_KENSU = "MST181_KENSU";
    
    /**
     * 定数：MasterInfo取得key.
     */
    private static final String CONST_MST181_MASTER = "mst181";
    
    /**
     * 定数：再検索Button取得キー
     */
    private static final String CONST_MST181_SEARCH = "search_mst181";  
    
    /**
     * 履歴テーブル検索キー.
     */
    private Map<String, Object> rirekiSearchKey;
    
    /**
     * ワーク.メッセージリスト
     */
    List<MessageModuleBean> msgList = new ArrayList<>();

    /**
     * コンストラクタ
     */
    public Mst181Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId
     * @param prevScreen
     * @param backFlag
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            // パンくず追加
            breadBean.push(strTitle, SCREEN.MST181_SCREEN.name(), this);

            // マスタ内容取得
            pageCommon.getMasterInfo(CONST_MST181_MASTER);
            
            // 検索シーケンス処理ため初期化
            searchHelpBean.regSearchHelp(DATA_TABLE_ID, //
                s -> { return count(); },
                s -> { search(); return null; },
                null);
            searchHelpBean.getSettings().put(DATA_TABLE_ID, pageCommon);
            
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO, new AutoCompOptionBean("全て", "all"));
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_KOKYAKU);
            
            // 前回の記録をクリアする
            this.clear();
            mst181Form.setSearchResult(null);
            mst181Form.setSearchResultSelectable(null);
            mst181Form.setSelectedSearchResult(null);
            
            // 戻ってきた場合
            Mst181Form preForm = (Mst181Form) pageCommon.getPageInfo(CONST_MST181_FORM);
            if (backFlag  && preForm != null) {
                PageCommonBean.simpleCopy(preForm, mst181Form);
                // 再検索を実施する
                pageCommon.searchAgain(CONST_MST181_SEARCH);
            // 進んできた場合
            } else {
                Flash flash = pageCommon.getPageParam();
                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_MST181_FORM) != null) {                    
                    PageCommonBean.simpleCopy(flash.get(CONST_MST181_FORM), mst181Form);
                    // 再検索を実施する
                    pageCommon.searchAgain(CONST_MST181_SEARCH);
                }
            }
            // ダウンロードシーケンス初期化
            fileBean.setDataSize(DATA_TABLE_ID, (id -> {
                return count();
            }));
            fileBean.getSettings().put(DATA_TABLE_ID, pageCommon);
            
            fileBean.setSubFlg(false);
            
            fileBean.setTilte(Title);
            
            fileBean.regDownloadFucntion(DATA_TABLE_ID, getHeader() ,(id -> {
                return getKijiMasterList();
            }));
            fileBean.regBeforeDownFucntion(DATA_TABLE_ID, (comment -> {
                return beforeDown(comment);
            }));

            // 行更新また削除するために共通処理へ登録する
            pageCommon.regDelFucntion(DATA_TABLE_ID,
                    (dataList -> (this.delRows(dataList))));
            
            // component初期化とユーザ権限により制御設定
            pageCommon.setAuthControll(mst181Form, SC_CD_MST181, true);
            
            // 初期はデータを編集不可にする
            mst181Form.setBtnEditeDisabled(true);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGG_LOGGER.error(ex.getMessage(), ex);
        }
    }
    
    /**
     * カウント処理
     *
     * @return 取得件数
     */
    public Long count() {
        // 前回の記録をクリアする
        Map<String, Object> mapRec = new LinkedHashMap();
        mapRec.put(StndConsIF.CONST_ZERO_STRING, true);
        List<Map<String, Object>> mapList = new ArrayList();
        mapList.add(mapRec);
        mst181Form.setSearchResult(mapList);
        mst181Form.setSearchResultSelectable(new ReportListDataModel(mst181Form.getSearchResult()));
        mst181Form.setSelectedSearchResult(null);
        
        // 初期はデータを編集不可にする
        mst181Form.setBtnEditeDisabled(true);
        
        // ワーク.件数
        long kensu = getKijiMasterListKensu();
        // 検索部のステータスを変更する
        pageCommon.setSerchConDisabled(mst181Form);

        // 検索条件保存
        pageCommon.savePageInfo(CONST_MST181_FORM, mst181Form);
        return kensu;
    }
    
    /**
     * 検索処理
     *
     */
    public void search() {
        // 選択リストを初期化する
        mst181Form.setSelectedSearchResult(new ArrayList<>());
        mst181Form.setSearchResultSelectable(null);
        
        // 記事マスタ検索し、取得した値を画面項目にセット
        List<Map<String, Object>> res = getKijiMasterList();
        fileBean.setDataList(res);
        
        // 取得した値を画面項目にセットする
        pageCommon.setDatalist(DATA_TABLE_ID, res);
        mst181Form.setSearchResultSelectable(new ReportListDataModel(res));
        
        // 検索初期はデータを編集不可にする
        mst181Form.setBtnEditeDisabled(false);

        // 検索部のステータスを変更する
        pageCommon.setSerchConDisabled(mst181Form);
        // 検索条件を保存する
        pageCommon.savePageInfo(CONST_MST181_FORM, mst181Form);
        // 検索条件を無効化する
        pageCommon.setEditFlg(false);
    }
    
    /**
     * 検索条件を設定する
     * 
     * @return 検索条件
     */
    private Map<String, Object> setCondition() {
        // パラメータ
        Map<String, Object> params = new HashMap<>();
        // 営業所コード
        if (mst181Form.getConEigyoshoCd() != null) {
            params.put("conEigyoshoCd", mst181Form.getConEigyoshoCd().getValue());
        }
        // 顧客コード
        if (mst181Form.getConKokyakuCd() != null) {
            params.put("conKokyakuCd", mst181Form.getConKokyakuCd().getValue());
        }
        return params;
    }

    /**
     * 検索条件変更処理
     *
     */
    public void searchChange() {
        // 検索部のステータス変更
        pageCommon.setSerchConEnabled(mst181Form);
    }

    /**
     * クリア処理
     */
    public void clear() {
        // 検索部の条件クリア
        mst181Form.setConEigyoshoCd(null);
        mst181Form.setConKokyakuCd(null);
        // 検索部のステータス変更
        pageCommon.setSerchConEnabled(mst181Form);
        pageCommon.setBtnSearchChangeVisible(false);
        pageCommon.setBtnSearchVisible(Boolean.TRUE);
    }

    /**
     * 更新処理
     *
     */
    public void update() {
        // エラーメッセージを格納する変数の初期化を行う
        msgList = new ArrayList();
        
        // 行選択チェックを行う
        if (mst181Form.getSelectedSearchResult() == null || mst181Form.getSelectedSearchResult().isEmpty()) {
            MessageModuleBean message = messageProperty.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MSTE0093);
            msgList.add(message);

            messageProperty.messageList(msgList);
            return;
        }
        
        // 登録一覧リストの初期化を行う
        List<Map<String, Object>> torokuIchiranList = new ArrayList();

        // 更新一覧リストの初期化を行う
        List<Map<String, Object>> koshinIchiranList = new ArrayList();

        // 単項目チェック処理
        if (!checkJsfParamas(mst181Form.getSelectedSearchResult())) {
            return;
        }
        
        // 登録更新情報設定処理
        for (Map<String, Object> record : mst181Form.getSelectedSearchResult()) {
            // 仕向地名マスタ一覧.カレント行 = 登録対象の場合
            if (record.get(StndConsIF.CONST_ADD_ROW_KEY) != null) {
                // 登録データワークにデータを設定する
                torokuIchiranList.add(record);
                // 仕向地名マスタ一覧.カレント行 ≠ 登録対象の場合
            } else {
                // 更新データワークにデータを設定する
                koshinIchiranList.add(record);
            }
        }
        
        // 登録・更新処理を行う
        int status = insertUpdateKijiMasterList();

        // エラーの場合、処理終了
        if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            return;
        }
        // 登録の後に再度検索する
        this.search();
        // 一覧をDataVersionプラス1
        pageCommon.addIchiranDataVersion(mst181Form.getSelectedSearchResult());

        // メッセージを設定する
        messageProperty.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, "更新");
        
        // ログ出力を行う
        LOGG_LOGGER.info("更新 " + mst181Form.getSelectedSearchResult().size() + " 件");
    }
    
    /**
     * 一覧の単項目チェック処理
     * 
     * @param params 画面一覧パラメータ
     * @return チェックの結果
     */
    private boolean checkJsfParamas(List<Map<String, Object>> params) {

        // 単項目チェック
        List<ListCheckBean> checks = new ArrayList<>();
        // 営業所コード
        checks.add(new ListCheckBean("listEigyoshoCd", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "営業所コード"));
        // 顧客コード
        checks.add(new ListCheckBean("listKokyakuCd",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "顧客コード"));
        // 記事コード
        checks.add(new ListCheckBean("listKijiCd",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "記事コード"));
        
        checks.add(new ListCheckBean("listKijiCd",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "記事コード", "3"));
        // 記事内容
        checks.add(new ListCheckBean("listKijiNaiyo",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "記事内容", "40"));
        List<MessageModuleBean> msgList = listCheckBean.check(params, checks);

        // チェックの結果
        if (msgList != null && !msgList.isEmpty()) {
            return false;
        }
        return true;
    }
    
    /**
     * DBへ記事マスタを登録また更新する
     */
    private int insertUpdateKijiMasterList() {
        // 重複、存在チェック
        ServiceInterfaceBean res = pageCommon.accsessDBWithList(mst181Form.getSelectedSearchResult(), FUNC_CODE_INSERT_UPDATE_DUPLICATED);
        
        // エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            messageProperty.message(res.getMessages().get(0)[0],
                    res.getMessages().get(0)[1],
                    res.getMessages().get(0)[2],
                    res.getTableName());
            return res.getStatusCode();
        }
        
        // 登録一覧リストと更新一覧リストの内容処理する
        res = pageCommon.accsessDBWithList(mst181Form.getSelectedSearchResult(), UPDATE_FUNC_CODE);

        return res.getStatusCode();
        
    }
    
    /**
     * DBから記事マスタ検索件数を取得する
     */
    private Long getKijiMasterListKensu() {
        // パラメータ
        Map<String, Object> params = setCondition();
        // DBをアクセス
        ServiceInterfaceBean res = pageCommon.getDBInfo(params, FUNC_CODE_SEARCH_KENSU);

        return Long.valueOf(res.getJson());
    }

    /**
     * DBから記事マスタ情報を取得する
     */
    private List<Map<String, Object>> getKijiMasterList() {
        // パラメータ
        Map<String, Object> params = setCondition();
        // DBをアクセス
        ServiceInterfaceBean res = pageCommon.getDBInfo(params, SEARCH_FUNC_CODE);

        try {
            ObjectMapper mapper = new ObjectMapper();
            mst181Form.setSearchResult(mapper.readValue(res.getJson(), List.class));
        } catch (IOException ex) {
            LOGG_LOGGER.error(ex.getMessage(), ex);
            return null;
        }
        return mst181Form.getSearchResult();
    }
    
    /**
     * 業務削除処理ファンクション領域
     *
     */
    public void delRowsFunc() {
        pageCommon.getSelectedDatasList().put(DATA_TABLE_ID, mst181Form.getSelectedSearchResult());
        pageCommon.delRows(DATA_TABLE_ID);
    }
    
    /**
     * DBから記事マスタ情報を削除する
     * @param datas レコードリスト
     * @return 正常／異常
     */
    public Boolean delRows(List<Map<String, Object>> datas) {
        // エラーメッセージを格納する変数を初期化する
        msgList = new ArrayList<>();
        // 行選択チェック
        if (datas.isEmpty()) {
            MessageModuleBean message = messageProperty.createMessageModule(
                    messageProperty.SEVERITY_ERROR, MessageCnst.COME0029);
            msgList.add(message);
            return false;
        }

        // DBをチェック
        ServiceInterfaceBean res = pageCommon.accsessDBWithList(datas, FUNC_CODE_DELETE_EXIST);
        // エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            // 存在しない場合は画面から削除しない
            mst181Form.getSearchResult().addAll(datas);
            MessageModuleBean message = messageProperty.createMessageModule(
                    res.getMessages().get(0)[0],
                    res.getMessages().get(0)[1],
                    res.getMessages().get(0)[2],
                    "記事マスタ");
            msgList.add(message);
            messageProperty.messageList(msgList);
            return false;
        }
        
        // 削除処理を行う
        res = pageCommon.accsessDBWithList(datas, DELETE_FUNC_CODE);
        // エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            return false;
        }
        
        // メッセージを設定する
        messageProperty.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, "削除");
        
        // ログ出力
        LOGG_LOGGER.info("削除 " + datas.size() + " 件");
        return true;
    }
    
    /**
     * 更新履歴を表示処理
     *
     */
    public void rirekiIchiran() {

        // 履歴テーブル検索キー設定
        rirekiSearchKey = new HashMap();
        Map<String, Object> selectRec = mst181Form.getSelectedSearchResult().get(0);
        rirekiSearchKey.put("listEigyoshoCd", selectRec.get("listEigyoshoCd"));
        rirekiSearchKey.put("listKokyakuCd", selectRec.get("listKokyakuCd"));
        rirekiSearchKey.put("listKijiCd", selectRec.get("listKijiCd"));
        
        // 履歴タイトル設定
        rirekiSyosai.setListColName(new ArrayList<>(Arrays.asList("バージョン情報","記事コード", "記事内容", "営業所コード", "顧客コード")));

        // 履歴beanの項目物理名設定
        rirekiSyosai.setListColValue(new ArrayList<>(Arrays.asList("listKijiDataVersion","listKijiCd", "listKijiNaiyo", "listEigyoshoCd", "listKokyakuCd")));

        // 履歴テーブル検索する
        rirekiSyosai.searchList("2", "MST181_RIREKI", rirekiSearchKey);
    }
    

    /**
     * メニュークリック（処理）
     *
     * @param menuId
     * @param nextScreen
     * @return
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGG_LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック（処理）
     *
     * @return
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGG_LOGGER.error(ex.getMessage(), ex);
        }
        // 画面遷移を行う
        url = forward(nextScreen, null, null, true);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return
     */
    @Override
    public String logoutClick() {
        return authConfBean.logout();
    }

    /**
     * @return the strTitle
     */
    public String getStrTitle() {
        return strTitle;
    }
    
    /**
     * CSVファイルのタイトルを設定する処理
     * 
     * @return 画面タイトル
     */
    public List<CSVDto> getHeader() {
        // CSVファイルのタイトルを設定
        List<CSVDto> header = new ArrayList<>();
        // 営業所コード
        header.add(new CSVDto("営業所コード", "listEigyoshoCd"));
        // 顧客コード
        header.add(new CSVDto("顧客コード", "listKokyakuCd"));
        // 記事コード
        header.add(new CSVDto("記事コード", "listKijiCd"));
        // 記事内容
        header.add(new CSVDto("記事内容", "listKijiNaiyo"));
        return header;
    }

     /**
     * ダウンロード理由を記録する処理
     *
     * @param comment 理由コメント
     * @return 正常／異常
     * @throws Exception
     */
    public boolean beforeDown(String comment) throws Exception {
        // ダウンロード理由を記録する
        System.out.println(comment);
        return true;
    }
	
	/**
     * アップロード
     * 
     * @return 遷移先画面のURL
     */
    public String upload() {
        
        // flash初期化
        Flash flash = pageCommon.getPageParam();
        
        // flashにアップロード機能コードを設定する
        flash.put("uploadFunctionCd", strTitle);
        
        // アップロード画面へ遷移
        url = forward(SCREEN.UPLOAD_SCREEN.name(), null, SCREEN.MST181_SCREEN.name(), false);
        return url;
    }

}
