/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import jp.co.kintetsuls.beans.common.AutoCompleteBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.KbnBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiListCol;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.forms.mst.Mst511Form;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.kintetsuls.utils.DateUtils;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.PrimeFaces;

/**
 * 代理承認者設定マスタ画面BEAN 
 *
 * @author LiXinZhi (MBP)
 * @version 2019/2/27 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst511")
@ViewScoped
@Data
public class Mst511Bean extends BaseBean {

    /**
     * URL
     */
    private String URL;
    
    /**
     * KBNBEAN
     */
    @ManagedProperty(value = "#{kbnBean}")
    private KbnBean kbnBean;
    
    /**
     * 一覧のAutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoComplete}")
    private AutoCompleteBean autoCompleteBean;
    
    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(
            new Object() {}.getClass().getEnclosingClass().getName());
    
    /**
     * 一覧単項目チェック共通
     */
    @ManagedProperty(value = "#{listCheckBean}")
    private ListCheckBean listCheckBean;
    
    /**
     * ファイルダウンロード
     */
    @ManagedProperty(value = "#{fileBean}")
    private FileBean fileBean;
    
    /**
     * 画面フォーム
     */
    @ManagedProperty(value = "#{mst511Form}")
    private Mst511Form mst511Form;
    
    /**
     * マスタインフォ
     */
    @ManagedProperty(value = "#{masterInfo}")
    private MasterInfoBean masterInfo;
    
    /**
     * 定数：再検索Button取得キー
     */
    private static final String CONST_MST511_SEARCH = "search_mst511";
    
    /**
     * 画面共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;
    
    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;
    
    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;
    
    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

    /**
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authorityConfBean;
    
    /**
     * タイトル
     */
    private final String TITLENAME = "代理承認者設定マスタ";

    /**
     * 検索シーケンス処理共通
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;

    /**
     * 履歴一覧処理共通
     */
    @ManagedProperty(value = "#{rirekisyosai}")
    private RirekiSyosaiBean rirekiSyosai;

    /**
     * 定数：登録の重複チェックファンクションコード
     */
    private static final String FUNC_CODE_INSERT_UPDATE_CHECK = "mst511-insert-update-check";
    
    /**
     * 定数：代理承認者設定マスタ登録更新ファンクションコード
     */
    private static final String FUNC_CODE_INSERT_UPDATE = "mst511-insert-update-ichiran";
    
    /**
     * 定数：削除の存在チェックファンクションコード
     */
    private static final String FUNC_CODE_DELETE_EXIST = "mst511-delete-exist";
    
    /**
     * ScreenCode：MST511.
     */
    private static final String SC_CD_MST511 = "MST511_SCREEN";
    
    /**
     * 定数：検索FUNC_CODE.
     */
    private static final String FUNC_CODE_SEARCH = "mst511-get-eigyosho-detail";
    
    /**
     * 定数：検索FUNC_CODE.
     */
    private static final String FUNC_CODE_SEARCH_KENSU = "mst511-get-eigyosho-kensu";
    
    /**
     * 定数：行削除FUNC_CODE.
     */
    private static final String FUNC_CODE_DELETE_ROW = "mst511-delete-row-detail";

    /**
     * 定数：一覧のDataTableのID.
     */
    private static final String DATA_TABLE_ID = "tablesorter_mst511";

    /**
     * 定数：画面項目保持key.
     */
    private static final String CONST_MST511_FORM = "mst511Form";

    /**
     * 定数：MasterInfo取得key.
     */
    private static final String CONST_MST511_MASTER = "mst511";

    /**
     * 履歴テーブル検索キー.
     */
    private Map<String, Object> rirekiSearchKey;

    /**
     * ワーク.メッセージリスト
     */
    List<MessageModuleBean> msgList = new ArrayList<>();
    
    /**
     * コンストラクタ
     */
    public Mst511Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId　 メニューID
     * @param prevScreen  遷移元画面ID
     * @param backFlag  戻るフラグ
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
         try {
            // パンくずを追加する
            breadBean.push(TITLENAME, SCREEN.MST511_SCREEN.name(), this);

            // システムマスタ取得する
            pageCommonBean.getMasterInfo(CONST_MST511_MASTER);

            // 検索シーケンス処理を初期化する
            searchHelpBean.regSearchHelp(DATA_TABLE_ID,
                    s -> {return getRecordCount();},
                    s -> {search(); return null;},
                    null);
            searchHelpBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);
            //DOWNLOADボタン画面に存在しない場合
            searchHelpBean.setDownloadFlg(false);

            // 前回の記録をクリアする
            this.clear();
            mst511Form.setSearchResult(null);
            mst511Form.setSearchResultSelectable(null);
            mst511Form.setSelectedSearchResult(null);

            // DBからマスタの内容を取得
            // ワーク.営業所リスト
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO);
            // ワーク.ユーザーリスト
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_USER);

            // 戻ってきた場合
            Mst511Form preForm = (Mst511Form) pageCommonBean.getPageInfo(CONST_MST511_FORM);
            if (backFlag && preForm != null) {
                pageCommonBean.simpleCopy(preForm, mst511Form);
                // 再検索を実施する
                pageCommonBean.searchAgain(CONST_MST511_SEARCH);
                // 進んできた場合
            } else {
                Flash flash = pageCommonBean.getPageParam();
                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_MST511_FORM) != null) {
                    pageCommonBean.simpleCopy(flash.get(CONST_MST511_FORM), mst511Form);
                    // 再検索を実施する
                    pageCommonBean.searchAgain(CONST_MST511_SEARCH);
                }
            }

           // 行更新また削除するために共通処理へ登録する
            pageCommonBean.regDelFucntion(DATA_TABLE_ID,
                    (dataList -> (this.delRows(dataList))));

            // component初期化とユーザ権限により制御を設定する
            pageCommonBean.setAuthControll(mst511Form, SC_CD_MST511, true);

            // 初期はデータを編集不可にする
            mst511Form.setBtnEditeDisabled(true);

         } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * カウント処理
     *
     * @return 取得件数
     */
    public Long getRecordCount() {

        // 前回の記録をクリアする
        Map<String, Object> mapRec = new LinkedHashMap();
        mapRec.put("hideFlg", "hideRow");
        List<Map<String, Object>> mapList = new ArrayList();
        mapList.add(mapRec);
        mst511Form.setSearchResult(mapList);
        mst511Form.setSearchResultSelectable(new ReportListDataModel(mst511Form.getSearchResult()));
        mst511Form.setSelectedSearchResult(null);

        // 検索初期はデータを編集不可にする
        mst511Form.setBtnEditeDisabled(true);

        // レコード件数を取得する
        long recordCount = getDairiShoninListCount();

         // 検索部のステータスを変更する
        pageCommonBean.setSerchConDisabled(mst511Form);

        // 参照モードにする
        pageCommonBean.setEditFlg(false);

        // 検索条件保存
        pageCommonBean.savePageInfo(CONST_MST511_FORM, mst511Form);

        return recordCount;
    }
   
    /**
     * 検索処理
     */
    public void search() {

         // 選択リストを初期化する
        mst511Form.setSelectedSearchResult(new ArrayList<>());
        mst511Form.setSearchResultSelectable(null);
        
        // 営業所マスタ検索を行う
        List<Map<String, Object>> recordList = getDairiShoninList();

        // 取得した値を画面項目にセットする
        pageCommonBean.setDatalist(DATA_TABLE_ID, recordList);

        mst511Form.setSearchResultSelectable(new ReportListDataModel(recordList));
        
         fileBean.setDataList(recordList);
        
        // 検索部のステータスを変更する
        pageCommonBean.setSerchConDisabled(mst511Form);

        // 削除済のみのチェック状態より、明細データを編集可／不可にする
        if (mst511Form.getConSakujoSumiNomi() == null || mst511Form.getConSakujoSumiNomi().length == 0) {
            // 削除済みデータを編集可にする
            mst511Form.setBtnEditeDisabled(false);
        } else {
            // 削除済みデータを編集不可にする
            mst511Form.setBtnEditeDisabled(true);
        }
        
        // 検索条件を保存する
        pageCommonBean.savePageInfo(CONST_MST511_FORM, mst511Form);
        
        // 参照モードにする
        pageCommonBean.setEditFlg(false);
    }

    /**
     * クリア処理
     */
    public void clear() {

        // 検索部の条件クリア
        mst511Form.setEigyoshokodo(null);
        mst511Form.setConShozokuShuryoWoFukumu(null);
        mst511Form.setConSakujoSumiNomi(null);

        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mst511Form);
        pageCommonBean.setBtnSearchChangeVisible(false);
        pageCommonBean.setBtnSearchVisible(Boolean.TRUE);
    }
    
    /**
     * ユーザー取得Autocomplete一覧を取得する処理
     * 
     * @param key 検索キー
     * @return Autocompleteリスト
     */    
    public List<String> getAutoCompForKokyakuCdList(String key) {
        return autoCompleteBean.getStringListByKey(MsCnst.COM_GET_VW_USER, key);
    }
    
    /**
     * 営業所取得Autocomplete一覧を取得する処理
     * 
     * @param key 検索キー
     * @return Autocompleteリスト
     */    
    public List<String> getAutoCompForKokyakuCdList2(String key) {
        return autoCompleteBean.getStringListByKey(MsCnst.COM_GET_VW_EIGYOSHO, key);
    }
    
    /**
     * 更新処理
     */
    public void update() {

        // 行選択チェックを行う
        if (mst511Form.getSelectedSearchResult().isEmpty()) {

            MessageModuleBean message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MSTE0093);
            msgList.add(message);

            messagePropertyBean.messageList(msgList);
            return;
        }
        
        // 単項目チェック処理
        if (!checkJsfParamas(mst511Form.getSelectedSearchResult())) {
            return;
        } 
        
        // エラーメッセージを格納する変数の初期化を行う
        msgList = new ArrayList();
        
        //更新と登録リスト
        List<Map<String, Object>> allList = new ArrayList();
        
        // 登録更新情報設定処理
        if (mst511Form.getSelectedSearchResult() != null &&
                mst511Form.getSelectedSearchResult().size() > 0) {
            for (Map<String, Object> record : mst511Form.getSelectedSearchResult()) {
                         
                //営業所コードを取得する
                record.put("listEigyoshoCd", mst511Form.getEigyoshokodo().getValue());
                //更新と登録リスト
                allList.add(record);
            }
        }
        
        // 登録・更新データがある場合
        if (allList.size() > 0) {
            
            // 登録・更新処理を行う
            int status = insertUpdateDairishoninListCheck(allList);

            // エラーの場合、処理終了
            if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
                return;
            }
        }
        
        insertUpdateDairishoninList();
    }

    /**
     * DBへ代理承認マスタを登録また更新する処理
     */
    public void insertUpdateDairishoninList() {
        
        //更新と登録リスト
        List<Map<String, Object>> allList = new ArrayList();
        
        // 登録更新情報設定処理
        if (mst511Form.getSelectedSearchResult() != null &&
                mst511Form.getSelectedSearchResult().size() > 0) {
            for (Map<String, Object> record : mst511Form.getSelectedSearchResult()) {
                
                //営業所コードを取得する
                record.put("listEigyoshoCd", mst511Form.getEigyoshokodo().getValue());
                //更新と登録リスト
                allList.add(record);
            }
        }
        
        // 登録一覧リストと更新一覧リストの内容を処理する
        pageCommonBean.accsessDBWithList(allList, FUNC_CODE_INSERT_UPDATE);
        
        // 登録の後に再度検索する
        this.search();
        
        // 一覧の配色定義をなくす
        pageCommonBean.resetIchiranColColor(mst511Form.getSelectedSearchResult());
        
        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, "更新");

        // ログ出力を行う
        LOGGER.info("更新 " + mst511Form.getSelectedSearchResult().size() + " 件");
    }
    
    /**
     * 更新履歴を表示処理
     */
    public void rirekiIchiran() {

        //履歴テーブル検索キー設定
        rirekiSearchKey = new HashMap();

        // 選択されたレコードを取得する
        Map<String, Object> selectRec = mst511Form.getSelectedSearchResult().get(0);
        rirekiSearchKey.put("listEigyoshoCd", selectRec.get("listEigyoshoCd"));
        rirekiSearchKey.put("listUserCd", selectRec.get("listUserCd"));

        //履歴タイトル設定
        rirekiSyosai.setListColName(new ArrayList<>(Arrays.asList("バージョン情報","ユーザーコード","ユーザー名",
                "所属開始日","所属終了日","提案申請","料金登録申請","売上削除","その他請求売上削除","現金回収削除",
                "トレース削除","締め解除", "ロジデータ削除","集金解除","パスワード初期化","ユーザマスタ","顧客マスタ",
                "仕入先マスタ","施設マスタ","月額自動請求マスタ","営業日カレンダー","ロジ料金表","大量データDL")));

        //履歴beanの項目物理名設定
        List<String> colValue = new ArrayList<>(Arrays.asList("listDataVersion","listUserCd","listUserMei",
                "listShozokuKaishibi","listShozokuShuryobi","listTeianShinsei","listRyokinTorokuShinsei",
                "listUriageSakujo","listSonotaSeikyuUriageSakujo","listGenkinKaishuSakujo","listTraceSakujo",
                "listShimeKaijo","listLogiDataSakujo","listShukinKaijo","listPasswordShokika","listUserMaster",
                "listKokyakuMaster","listShiiresakiMaster","listShisetsuMaster","listGetsugakuJidoSeikyuMaster",
                "listEigyobiCalender","listLogiRyokinHyo","listTairyoDataDl"));
        // 表示位置設定
        List<String> colAlign = new ArrayList<>(Arrays.asList("left","left","left",
                "left", "left", "center", "center", 
                "center", "center", "center", "center", 
                "center", "center", "center", "center", 
                "center", "center", "center", "center", 
                "center", "center", "center", "center", 
                "center","center", "center"));
        // カラムタイプ設定
        List<String> colType = new ArrayList<>(Arrays.asList("","","",
                "", "", "chkb", "chkb", 
                "chkb", "chkb", "chkb", "chkb", 
                "chkb", "chkb", "chkb", "chkb", 
                "chkb", "chkb", "chkb", "chkb", 
                "chkb", "chkb", "chkb", "chkb", 
                "chkb","chkb", "chkb"));
        List<RirekiListCol> listCol = new ArrayList<>();
                for (int i = 0; i < colValue.size(); i++) {
                   RirekiListCol col = new RirekiListCol();
                   col.setColValue(colValue.get(i));
                   col.setColAlign(colAlign.get(i));
                   col.setColType(colType.get(i));
                   listCol.add(col);
        }
        rirekiSyosai.setListCol(listCol);
        
        //履歴テーブル検索する
        rirekiSyosai.searchList("2", "MST511_SEARCH_RIREKI", rirekiSearchKey);
    }

    /**
     * メニュークリック処理
     *
     * @param menuId メニューID
     * @param nextScreen 遷移先画面ID
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移
        URL = forward(nextScreen, menuId, null, true);
        return URL;
    }

    /**
     * パンくずクリック（処理）
     *
     * @param nextScreen  遷移先画面ID
     * @param breadIndex  パンくずのインデックス
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        URL = forward(nextScreen, null, null, true);
        return URL;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authorityConfBean.logout();
    }
   
    /**
     * 検索条件変更処理
     */
    public void searchChange() {

        // 検索部のステータスを変更する
        pageCommonBean.setSerchConEnabled(mst511Form);
    }

    /**
     * 業務削除処理
     *
     * @param recordList レコードリスト
     * @return 正常／異常
     */
    public Boolean delRows(List<Map<String, Object>> recordList) {

        // エラーメッセージを格納する変数の初期化
        msgList = new ArrayList<>();

        // 削除対象がない場合
        if (recordList.isEmpty()) {
            return true;
        }

        // 存在チェック
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(recordList, FUNC_CODE_DELETE_EXIST);

        // エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            MessageModuleBean message = messagePropertyBean.createMessageModule(
                    res.getMessages().get(0)[0], 
                    res.getMessages().get(0)[1]);
            msgList.add(message);
            messagePropertyBean.messageList(msgList);
            return false;
        }

        // 削除処理を行う
        int status = deleteDairishoninList(recordList);

        // エラーの場合、処理を終了
        if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            return false;
        }
        
        // 画面レコード削除
        mst511Form.getSearchResult().removeAll(recordList);
        
        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, "削除");

        // ログ出力
        LOGGER.info("削除 " + recordList.size() + " 件");

        return true;
    }
    
    /**
     * 業務削除処理ファンクション領域
     */
    public void delRowsFunc() {

        pageCommonBean.getSelectedDatasList().put(DATA_TABLE_ID, mst511Form.getSelectedSearchResult());
        
        pageCommonBean.delRowsWithMsg(DATA_TABLE_ID, MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MSTE0093);
    }
    
   /**
     * DBから代理承認者設定マスタ情報を取得する
     * 
     * @return 営業所マスタ情報
     */
    private List<Map<String, Object>> getDairiShoninList() {

        // パラメータ
        Map<String, Object> params = new HashMap<>();
        
        //ユーザーdefault營業所取得
        params.put("loginUserShozokuEigyosho", authorityConfBean.getLoginUserShozokuEigyosho());
        
        //全営業所取得
        params.put("allEigyoshoSearch", masterInfo.getAllEigyoshoSearch());
        
        //システムデイタ取得
        params.put("sysDate", DateUtils.format(DateUtils.getSysDateFromApServer(), StndConsIF.DF_YYYY_MM_DD));
        
        // 営業所コード
        if (mst511Form.getEigyoshokodo() != null) {
            params.put("conEigyoshoCd", mst511Form.getEigyoshokodo().getValue());
        }
        // 所属を含む
        params.put("conShozokuShuryoWoFukumu", mst511Form.getConShozokuShuryoWoFukumu());
        // 削除済のみ
        params.put("conSakujoSumiNomi", mst511Form.getConSakujoSumiNomi());

        try {
            // DBをアクセスする
            ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH);
            ObjectMapper mapper = new ObjectMapper();
            mst511Form.setSearchResult(mapper.readValue(serviceInterfaceBean.getJson(), List.class));
            
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
        //営業所マスタ情報を返却する
        return mst511Form.getSearchResult();
    }

    /**
     * DBから代理承認マスタ情報を削除する処理
     * 
     * @param recordList レコードリスト
     * @return ステータスコード
     */
    private int deleteDairishoninList(List<Map<String, Object>> recordList) {

        // DBをアクセス
        ServiceInterfaceBean serviceInterfaceBean =
                pageCommonBean.accsessDBWithList(recordList, FUNC_CODE_DELETE_ROW);

        // ステータスコードを返却する
        return serviceInterfaceBean.getStatusCode();
    }

    /**
     * DBから代理承認者設定マスタ検索件数を取得する処理
     * 
     * @return 検索件数
     */
    private long getDairiShoninListCount() {

        // パラメータ
        Map<String, Object> params = new HashMap<>();
        
        //システムデイタ取得
        params.put("sysDate", DateUtils.format(DateUtils.getSysDateFromApServer(), StndConsIF.DF_YYYY_MM_DD));
        
        //ユーザーdefault營業所取得
        params.put("loginUserShozokuEigyosho", authorityConfBean.getLoginUserShozokuEigyosho());
        
        //全営業所取得
        params.put("allEigyoshoSearch", masterInfo.getAllEigyoshoSearch());
        
        // 営業所コードが空白以外の場合
        if (mst511Form.getEigyoshokodo() != null) {
            params.put("conEigyoshoCd", mst511Form.getEigyoshokodo().getValue());
        }
        // 所属を含む
        params.put("conShozokuShuryoWoFukumu", mst511Form.getConShozokuShuryoWoFukumu());
        // 削除済のみ
        params.put("conSakujoSumiNomi", mst511Form.getConSakujoSumiNomi());
        
        // DBをアクセスする
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH_KENSU);

        // 検索件数を返却する
        return Long.valueOf(serviceInterfaceBean.getJson());
    }
    
    /**
     * 一覧の単項目チェック処理
     * 
     * @param params 画面一覧パラメータ
     * @return チェックの結果
     */
    private boolean checkJsfParamas(List<Map<String, Object>> params) {
        
        List<ListCheckBean> checks = new ArrayList<>();
        checks.add(new ListCheckBean("listUserCd", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "ユーザーコード"));
        List<MessageModuleBean> msgList = listCheckBean.check(params, checks,true);

        if (msgList != null && !msgList.isEmpty()) {
            return false;
        }
        return true;
    }
    
    /**
     * DBへ代理承認マスタを登録また更新する時のチェック処理
     * 
     * @return システム
     */
    private int insertUpdateDairishoninListCheck(List<Map<String, Object>> params) {

        // 重複、存在チェック
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.accsessDBWithList(
                params, FUNC_CODE_INSERT_UPDATE_CHECK);

        // エラーの場合、処理を終了
        if (serviceInterfaceBean.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            // 一覧表示ユーザの所属終了日がシステム日付より1か月以内となっている場合
            if (CheckUtils.isEqual(MessageCnst.MSTE0092, serviceInterfaceBean.getMessages().get(0)[1])) {
                PrimeFaces.current().executeScript("km.showConfirmDialog('mste0092Dialog')");
            } else {
                messagePropertyBean.message(serviceInterfaceBean.getMessages().get(0)[0],
                        serviceInterfaceBean.getMessages().get(0)[1]);
            }
        }
        return serviceInterfaceBean.getStatusCode();
    }
 
}