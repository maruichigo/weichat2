/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mst;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.annotation.MaxSizeCheck;
import lombok.Data;

/**
 * 仕向地名マスタフォーム
 *
 * @author 馬雷 (MBP)
 * @version 2019/1/24 新規作成
 */
@ManagedBean(name = "mst501Form")
@ViewScoped
@Data
public class Mst501Form implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 都道府県AutoCompelete
     */
    private AutoCompOptionBean conTodofuken;

    /**
     * 都道府県Label
     */
    private String conTodofukenLabel;
    
    /**
     * 都道府県Disabled
     */
    private boolean conTodofukenDisabled;

    /**
     * 都道府県Visabled
     */
    private boolean conTodofukenVisible;

    /**
     * 仕向地名
     */
    @MaxSizeCheck(maxSize = 8, name = "仕向地名")
    private String conShimukeChiMei;

    /**
     * 仕向地名Disabled
     */
    private boolean conShimukeChiMeiDisabled;

    /**
     * 仕向地名Visabled
     */
    private boolean conShimukeChiMeiVisible;

    /**
     * 削除済のみ
     */
    private String[] conSakujoSumiNomi;

    /**
     * 削除済のみDisabled
     */
    private boolean conSakujoSumiNomiDisabled;

    /**
     * 削除済のみVisabled
     */
    private boolean conSakujoSumiNomiVisible;

    /**
     * 編集Disabled
     */
    private boolean btnEditeDisabled;

    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;

    /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;

    /**
     * 選択された結果
     */
    private List<Map<String, Object>> selectedSearchResult;

}
