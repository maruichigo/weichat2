/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.forms.edi.edi011;

import jp.co.kintetsuls.forms.edi.edi011.Edi011Document;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import org.primefaces.model.CheckboxTreeNode;
import org.primefaces.model.TreeNode;

/**
 *
 * @author xubo
 */
@ManagedBean(name = "documentService")
@ApplicationScoped
public class Edi011DocumentService {

    public TreeNode createCheckboxDocuments() {
        TreeNode root = new CheckboxTreeNode(new Edi011Document("", "","","","-", "", "", "", "", "", "", "", "", "","", "", "", "", ""), null);

        TreeNode ABCkaisha = new CheckboxTreeNode(new Edi011Document("ABC株式会社","","","", "-", "", "", "", "", "", "", "111111", "品川営業所","", "", "", "", "", ""), root);
        TreeNode DEFkaisha = new CheckboxTreeNode(new Edi011Document("DEF株式会社","","","", "-", "", "", "", "", "", "", "222222", "新東京営業所","", "", "", "", "", ""), root);
        TreeNode XYZkaisha = new CheckboxTreeNode(new Edi011Document("XYZ株式会社","","","", "-", "", "", "", "", "", "", "333333", "品川営業所","", "", "", "", "", ""), root);

        //DEFkaisha
        TreeNode DEFkaisha1 = new CheckboxTreeNode(new Edi011Document("DEF株式会社(請求情報送信)","","","", "正常終了", "4", "15", "", "", "", "", "222222", "新東京営業所", "","", "09/04　11:00:00", "09/04　11:00:00", "", ""), DEFkaisha);
        TreeNode DEFkaisha2 = new CheckboxTreeNode(new Edi011Document("DEF株式会社(トレース送信_配完)", "","","","一部異常", "6", "22", "", "", "", "", "222222", "新東京営業所","", "", "09/04　11:00:00", "09/04　11:00:00", "", ""), DEFkaisha);

        //Pictures
        TreeNode def1 = new CheckboxTreeNode("def", new Edi011Document("ファイル４","","","","正常終了", "1", "5", "5", "0", "0", "0", "", "","", "無し", "09/03　10:00:00", "09/03　10:00:00", "example@mail.co.jp", "あり"), DEFkaisha2);
        TreeNode def2 = new CheckboxTreeNode("def", new Edi011Document("ファイル３","","","","正常終了", "2", "7", "6", "0", "1", "0", "", "","", "無し", "09/03　10:00:00", "09/03　10:00:00", "", "あり"), DEFkaisha2);
        TreeNode def3 = new CheckboxTreeNode("def", new Edi011Document("ファイル２","","","","一部異常", "2", "6", "6", "0", "0", "0", "", "","", "あり", "09/03　10:00:00", "09/03　10:00:00", "example@mail.co.jp", "あり"), DEFkaisha2);
        TreeNode def4 = new CheckboxTreeNode("def", new Edi011Document("ファイル１","","","","正常終了", "1", "4", "4", "0", "0", "0", "", "","", "無し", "09/03　10:00:00", "09/03　10:00:00", "example@mail.co.jp", "無し"), DEFkaisha2);

        return root;
    }
}
