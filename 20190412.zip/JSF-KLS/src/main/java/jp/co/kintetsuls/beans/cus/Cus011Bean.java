/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.cus;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.cnst.SysMsg;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.context.RequestContext;
import org.primefaces.event.CellEditEvent;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.data.PageEvent;
import org.primefaces.model.LazyDataModel;

/**
 *
 * @author y_kamata
 */
@javax.faces.bean.ManagedBean(name = "cus011")
@ViewScoped
@Data
public class Cus011Bean extends BaseBean {
    
    private final String strTitle = "顧客一覧画面";
    private String url;     // URL
    private RestfullService rest;
    private String backColor = "";
    
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;
     
    private static Logger logger = LogManager.getLogger(new Object(){}.getClass().getEnclosingClass().getName());

    private Map<String,String> kokyakuKbns = new HashMap<>();
    private String kokyakuKbn[];
    private String sakujoFlg;
    private String kokyakuCd;
    private Date tekiyoKaishibi;
    private String kokyakuMei = "　";
    private Map<String,String> shinseiStatusCds = new HashMap<>();
    private String shinseiStatusCd;
    private String seikyuEigyoshoCd;
    private String seikyuEigyoshoMei = "　";
    private String hojinGroupCd;
    private String hojinGroupMei = "　";
    private LazyDataModel<Cus011Def> lazyModel;
    private LazyCus011DataModel cus011LazyModel;
    private List<Cus011Def> selectedCus011Def;
    private int curPage;
    private int curPageRows;
    private Boolean searchedFlg;

    /**
     * コンストラクタ
     */
    public Cus011Bean() {

    }
    
    /**
     * 初期処理（処理）
     * @param menuId
     * @param prevScreen
     * @param backFlag
     */      
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag){
        int i;
        
        try {
            
            // 画面項目初期値設定
            // パンくず追加
            breadBean.push("顧客一覧画面", SCREEN.CUS011_SCREEN.name(), this);

            // 顧客区分
            kokyakuKbns = new HashMap<>();
            kokyakuKbn = new String[3];
            for(i=0; i<CusCnst.KOKYAKU_KBN_VALUE.length; i++) {
                kokyakuKbns.put(CusCnst.KOKYAKU_KBN_MEI[i], CusCnst.KOKYAKU_KBN_VALUE[i]);
                kokyakuKbn[i] = CusCnst.KOKYAKU_KBN_VALUE[i];
            }

            // 申請ステータス
            setShinseiStatusCds(new HashMap<>());
            for(i=0; i<CusCnst.SHINSEI_STATUS_VALUE.length; i++) {
                shinseiStatusCds.put(CusCnst.SHINSEI_STATUS_MEI[i], CusCnst.SHINSEI_STATUS_VALUE[i]);
            }

            // １ページ内で表示する行数の初期値
            curPageRows = 20;
            
            // 検索条件入力値の初期化
            clear();       
            // 検索済みフラグクリア
            searchedFlg = false;        
            
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }
    }
    
    /**
     * メニュークリック（処理）
     * @param menuId
     * @param nextScreen
     * @return 
     */    
    @Override
    public String menuClick(String menuId, String nextScreen){
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }

        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
    }
    
    /**
     * パンくずクリック（処理）
     * @return 
     */   
    @Override
    public String breadClumClick(String nextScreen, int breadIndex){
        
        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }        
        url = forward(nextScreen, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     * @return 
     */   
    @Override
    public String logoutClick(){
        return authConfBean.logout();
    }
    
    /**
     * 画面遷移処理（顧客マスタメンテナンス画面へ）
     * @return 
     * @throws java.lang.IllegalAccessException 
     * @throws java.lang.reflect.InvocationTargetException 
     */     
    public String buttonClick() throws IllegalAccessException, InvocationTargetException {
        
        // 画面遷移
        url = forward(SCREEN.CUS012_SCREEN.name(), null, SCREEN.CUS011_SCREEN.name(), false);
        return url;
    }   
    
    /**
     * 検索条件クリア
     */
    public void clear(){
        backColor = "";
        shinseiStatusCd = "";
        sakujoFlg = "0";
        kokyakuCd = "";
        tekiyoKaishibi = null;
        kokyakuMei = "　";
        seikyuEigyoshoCd = "";
        seikyuEigyoshoMei = "　";
        hojinGroupCd = "";
        hojinGroupMei = "　";
        
        kokyakuKbn = new String[3];
        for(int i=0; i<kokyakuKbns.size(); i++) {
            kokyakuKbn[i] = CusCnst.KOKYAKU_KBN_VALUE[i];
        }
        
        // 検索済みフラグをクリア
        searchedFlg = false;
    }
    
    /**
     * 検索ボタン押下イベント
     */
    public void search(){
        
        backColor = "";
        RequestContext context = RequestContext.getCurrentInstance();
        context.addCallbackParam("setFlg", "true");
            
        // 種別チェック
        if(kokyakuKbn.length == 0) {
            FacesContext.getCurrentInstance().addMessage("message" , new FacesMessage(FacesMessage.SEVERITY_WARN, "警告", "種別を選択してください。"));
            backColor = CusCnst.ERR_BACK_COLOR;
            context.addCallbackParam("setFlg", "false");
            return;
        }
        
        // 顧客マスタ検索し、取得した値を画面項目にセット
        ServiceInterfaceBean res = getKokyakuList();        

        // 戻りSIBのステータスチェック、エラー処理
        if (res != null && res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR){
            // ToDo:各画面の仕様に従いメッセージ表示などのエラー処理を追加してください
            MsgExec.message(res.getMessages());
            context.addCallbackParam("setFlg", "false");
            return;
        }

        if(res != null) {
            MsgExec.message(res.getMessages());   
        }
        // 検索済みフラグを立てる
        searchedFlg = true;       
        
    }

    /**
     * DBから顧客情報を取得する
     */    
    private ServiceInterfaceBean getKokyakuList(){
        ServiceInterfaceBean req = new ServiceInterfaceBean();
        req.setFunctionCode("CUS011_GET_KOKYAKU_LIST");

        //parameter
        Map<String, Object> params = new HashMap<>();
        params.put("kokyakuCd", kokyakuCd);
        params.put("tekiyoKaishibi", FormatUtil.dateToJsonString(tekiyoKaishibi));
        params.put("shinseiStatusCd", shinseiStatusCd);
        params.put("seikyuEigyoshoCd", seikyuEigyoshoCd);
        params.put("hojinGroupCd", hojinGroupCd);
        params.put("kokyakuKbn", kokyakuKbn);
        params.put("sakujoFlg", sakujoFlg);
        
        String requestData = JSONUtil.makeJSONString(params);
        req.setJson(requestData);

        //JAX-RS接続を実行(SQL側のチェック処理など未実装。)
        setRest(RestfullService.getInstance());
        ServiceInterfaceBean res = null;
        List<Cus011Def> result = new ArrayList<>();
        
        try {
            res = getRest().request(req);
            
            if (res == null){
                throw new Exception();
            }
            if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR){
                return res;
            }
            
            ObjectMapper mapper = new ObjectMapper();
            result = mapper.readValue(res.getJson(), new TypeReference<List<Cus011Def>>(){});

            if(result.isEmpty()){
                lazyModel = null;
                res.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                res.addMessage("WARN", "警告", "該当データはありません。");
            }else{
                // 取得した内容を一覧に展開
                selectedCus011Def = null;
                setLazyModel(new LazyCus011DataModel(result));
            }
        } catch (Exception ex) {
            if(res == null){
                res.addMessage("WARN", "警告", SysMsg.ERRRTN);
                res.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            }
            logger.error(ex.getMessage(), ex);
            return res;
        }
        return res;
    }

    /**
     * 更新ボタン
     */
    public void update() {
        List<Cus011Def> insCus011 = new ArrayList<>();
        List<Cus011Def> updCus011 = new ArrayList<>();
        cus011LazyModel = (LazyCus011DataModel)lazyModel;
        int startPos = curPage * curPageRows;
        
        // 現在表示しているページで編集されている行を格納
        for(int i=startPos; i<startPos+curPageRows; i++) {
            Cus011Def cus011 = cus011LazyModel.getDatasource().get(i);

            //顧客コードが空ならエラー
            if("".equals(cus011.getKokyakuCd())) {
                FacesContext.getCurrentInstance().addMessage("message" , new FacesMessage(FacesMessage.SEVERITY_WARN, "警告", "顧客コードが入力されてません。"));
                return;     
            }
            
            if("1".equals(cus011.getActionFlg())){
                // 登録時
                insCus011.add(cus011);
            }else if("2".equals(cus011.getActionFlg())) {
                // 更新時
                updCus011.add(cus011);
            }
            
        }

        // 更新対象確認
        if (insCus011.isEmpty() && updCus011.isEmpty()){
            FacesContext.getCurrentInstance().addMessage("message" , new FacesMessage(FacesMessage.SEVERITY_WARN, "警告", "更新対象がありません"));
            return; 
        }
        
        // 顧客マスタを更新し、更新した内容を画面項目にセット
        ServiceInterfaceBean res = updateKokyakuList(insCus011, updCus011);        

        // ToDo:各画面や共通メッセージ仕様に従い、メッセージ表示などのエラー処理を追加してください
        // 以下メッセージ表示サンプル
        MsgExec.message(res.getMessages());
        
    }
        
    /**
     * DBの顧客情報を更新する
     */    
    private ServiceInterfaceBean updateKokyakuList(List<Cus011Def> insCus011, List<Cus011Def> updCus011){        
        ServiceInterfaceBean req = new ServiceInterfaceBean();
        req.setFunctionCode("CUS011_UPDATE_KOKYAKU_LIST");
        Map<String, Object> params = new HashMap<>();

        // 送信パラメータに更新データを設定
        params.put("INSERT", insCus011);        
        params.put("UPDATE", updCus011);

        // 送信パラメータに検索条件を設定
        Map<String, Object> selCol = new HashMap<>();
        selCol.put("kokyakuCd", kokyakuCd);
        selCol.put("tekiyoKaishibi", FormatUtil.dateToJsonString(tekiyoKaishibi));
        selCol.put("shinseiStatusCd", shinseiStatusCd);
        selCol.put("seikyuEigyoshoCd", seikyuEigyoshoCd);
        selCol.put("hojinGroupCd", hojinGroupCd);
        selCol.put("kokyakuKbn", kokyakuKbn);
        selCol.put("sakujoFlg", sakujoFlg);
        selCol.put("userCd", authConfBean.getUserCd());
        params.put("SEARCH", selCol);

        String requestData = JSONUtil.makeJSONString(params);
        req.setJson(requestData);
        
        //JAX-RS接続を実行(SQL側のチェック処理など未実装。)
        setRest(RestfullService.getInstance());
        ServiceInterfaceBean res = null;
        List<Cus011Def> result;
        
        try {
            res = getRest().request(req);
            
            if (res == null){
                throw new Exception();
            }
            if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR){
                return res;
            }
            
            // 最新の情報で一覧を更新
            ObjectMapper mapper = new ObjectMapper();
            result = mapper.readValue(res.getJson(), new TypeReference<List<Cus011Def>>(){});
            if(result.isEmpty()){
                lazyModel = null;
                FacesContext.getCurrentInstance().addMessage("message" , new FacesMessage(FacesMessage.SEVERITY_WARN, "警告", "該当データはありません。"));
            }else{
                selectedCus011Def = null;
                setLazyModel(new LazyCus011DataModel(result));
            }
            
        } catch (Exception ex) {
            if(res == null){
                res.addMessage("WARN", "警告", SysMsg.ERRRTN);
                res.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            }
            logger.error(ex.getMessage(), ex);
            return res;
        }
        return res;
    }

    /**
     * 削除ボタン
     */
    public void delete() {
        List<Cus011Def> listCus011 = new ArrayList<>();
        cus011LazyModel = (LazyCus011DataModel)lazyModel;
        int startPos = curPage * curPageRows;

        // 現在表示しているページでチェックされている行を論理削除
        for(int i=startPos; i<startPos+curPageRows; i++) {
            Cus011Def cus011 = cus011LazyModel.getDatasource().get(i);
            
            //顧客コードが空ならエラー
            if("".equals(cus011.getKokyakuCd())) {
                FacesContext.getCurrentInstance().addMessage("message" , new FacesMessage(FacesMessage.SEVERITY_WARN, "警告", "顧客コードが入力されてません。"));
                return;     
            }          
            
            // チェックありの行を保持
            if("1".equals(cus011.getCheckFlg())){
                listCus011.add(cus011);
            }  
        }
        
        // 削除対象確認
        if (listCus011.isEmpty()){
            FacesContext.getCurrentInstance().addMessage("message" , new FacesMessage(FacesMessage.SEVERITY_WARN, "警告", "削除対象がありません"));
            return; 
        }  
        
        // 顧客マスタを論理削除し、削除した内容を画面項目にセット
        ServiceInterfaceBean res = deleteKokyakuList(listCus011);           

        // ToDo:各画面や共通メッセージ仕様に従い、メッセージ表示などのエラー処理を追加してください
        // 以下メッセージ表示サンプル
        MsgExec.message(res.getMessages());
    }
        
   /**
     * DBの顧客情報を論理削除する
     */    
    private ServiceInterfaceBean deleteKokyakuList(List<Cus011Def> listCus011){         
        ServiceInterfaceBean req = new ServiceInterfaceBean();
        req.setFunctionCode("CUS011_DELETE_KOKYAKU_LIST");
        Map<String, Object> params = new HashMap<>();

        // 送信パラメータに削除対象データを設定
        params.put("DELETE", listCus011);

        // 送信パラメータに検索条件を設定
        Map<String, Object> selCol = new HashMap<>();
        selCol.put("kokyakuCd", kokyakuCd);
        selCol.put("tekiyoKaishibi", FormatUtil.dateToJsonString(tekiyoKaishibi));
        selCol.put("shinseiStatusCd", shinseiStatusCd);
        selCol.put("seikyuEigyoshoCd", seikyuEigyoshoCd);
        selCol.put("hojinGroupCd", hojinGroupCd);
        selCol.put("kokyakuKbn", kokyakuKbn);
        selCol.put("sakujoFlg", sakujoFlg);
        selCol.put("userCd", authConfBean.getUserCd());
        params.put("SEARCH", selCol);

        String requestData = JSONUtil.makeJSONString(params);
        req.setJson(requestData);
        
        //JAX-RS接続を実行(SQL側のチェック処理など未実装。)
        setRest(RestfullService.getInstance());
        ServiceInterfaceBean res = null;
        List<Cus011Def> result;
        
        try {
            res = getRest().request(req);
            
            if (res == null){
                throw new Exception();
            }
            
            // 最新の情報で一覧を更新            
            ObjectMapper mapper = new ObjectMapper();
            result = mapper.readValue(res.getJson(), new TypeReference<List<Cus011Def>>(){});
            if(result.isEmpty()){
                lazyModel = null;
                FacesContext.getCurrentInstance().addMessage("message" , new FacesMessage(FacesMessage.SEVERITY_WARN, "警告", "該当データはありません。"));
            }else{
                selectedCus011Def = null;
                setLazyModel(new LazyCus011DataModel(result));
            }
        } catch (Exception ex) {
            if(res == null){
                res.addMessage("WARN", "警告", SysMsg.ERRRTN);
                res.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            }
            logger.error(ex.getMessage(), ex);
            return res;
        }
        return res;
    }
    
    /**
     * 一覧のセルの編集情報を取得する
     * @param event
     */        
    public void cellEdit(CellEditEvent event){
        String oldValue = (String)event.getOldValue();
        String newValue = (String)event.getNewValue();

        // ヘッダ情報取得
        String columnHeader = event.getColumn().getHeaderText();
 
        // 変更なしなら終了
        if(oldValue == null ? newValue == null : oldValue.equals(newValue)) {
            return;
        }
        cus011LazyModel = (LazyCus011DataModel)lazyModel;
        // 新規登録以外は更新する
        if("kokyakuCd".equals(columnHeader) && !(oldValue.equals(newValue))) {
            cus011LazyModel.getDatasource().get(event.getRowIndex()).setActionFlg("1");     // 新規登録  
        }else if(!"1".equals(cus011LazyModel.getDatasource().get(event.getRowIndex()).getActionFlg())) {
            cus011LazyModel.getDatasource().get(event.getRowIndex()).setActionFlg("2");     // 更新  
        }   
    }

    /**
     * チェックした行の情報を取得する
     * @param event
     */        
    public void rowSelectCheckbox(SelectEvent event){
        Cus011Def cus011 = (Cus011Def)event.getObject();
        cus011LazyModel = (LazyCus011DataModel)lazyModel;
        // チェック有効
        cus011LazyModel.getDatasource().get(Integer.valueOf(cus011.getId())).setCheckFlg("1");
  
    }

    /**
     * チェックを外した行の情報を取得する
     * @param event
     */        
    public void rowUnselectCheckbox(SelectEvent event){
        Cus011Def cus011 = (Cus011Def)event.getObject();
        cus011LazyModel = (LazyCus011DataModel)lazyModel;
        // チェック無効
        cus011LazyModel.getDatasource().get(Integer.valueOf(cus011.getId())).setCheckFlg("0");
  
    }

    /**
     * 行チェックボックス以外の一覧のチェックボックスのイベント
     * @param event
     */        
    public void clickCheckBox(AjaxBehaviorEvent event) {
        String checkId = (String)event.getComponent().getAttributes().get("checkId");
        cus011LazyModel = (LazyCus011DataModel)lazyModel;
        
        if(!"1".equals(cus011LazyModel.getDatasource().get(Integer.valueOf(checkId)).getActionFlg())) {
            cus011LazyModel.getDatasource().get(Integer.valueOf(checkId)).setActionFlg("2");     // 更新  
        }   
    }

    /**
     * 表示されている現在のページを0始まりで取得する
     * @param event
     */ 
    public void page(PageEvent event) {
        curPage = event.getPage();
    }

    /**
     * 検索条件をもとに戻す
     */ 
    public void changeConditions(){
        searchedFlg = false;
    }
    
    /**
     * @return the breadBean
     */
    public BreadCrumbBean getBreadBean() {
        return breadBean;
    }

    /**
     * @param breadBean the breadBean to set
     */
    public void setBreadBean(BreadCrumbBean breadBean) {
        this.breadBean = breadBean;
    }

    /**
     * @return the authConfBean
     */
    public AuthorityConfBean getAuthConfBean() {
        return authConfBean;
    }

    /**
     * @param authConfBean the authConfBean to set
     */
    public void setAuthConfBean(AuthorityConfBean authConfBean) {
        this.authConfBean = authConfBean;
    }

    
    
}
