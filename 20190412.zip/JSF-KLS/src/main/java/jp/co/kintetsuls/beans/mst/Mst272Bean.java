/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteBean;
import jp.co.kintetsuls.beans.common.LabelValueBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.cnst.SysMsg;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.forms.mst.Mst272Form;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.event.DragDropEvent;
import org.primefaces.model.DualListModel;

/**
 * 代理店・中継配達料金表詳細
 *
 * @author shx (MBP)
 * @version 2019/1/30 新規作成
 */
@ManagedBean(name = "mst272")
@ViewScoped
@Data
public class Mst272Bean extends AbstractBean {

    private final String strTitle = "代理店・中継配達料金表詳細";
    private String url;     // URL

    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    @ManagedProperty(value = "#{autoComplete}")
    private AutoCompleteBean autoCompleteBean;

    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    @ManagedProperty(value = "#{labelValueBean}")
    private LabelValueBean labelValueBean;

    @ManagedProperty(value = "#{mst272Form}")
    private Mst272Form form;

    private static final Logger logger = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    private RestfullService rest;

    private List<Map<String, String>> searchResult;

    private Map<String, String> selectSearchResult;

    /**
     * 都道府県
     */
    private String conTodofuken;
    /**
     * 仕向地名
     */
    private String conShimukeChiMei;
    /**
     * 削除済のみ
     */
    private String conSakujoSumiNomi[];

    /**
     * 業者区分
     */
    private String conGyoshaKbn;
    /**
     * 業者区分List
     */
    private List<Map<String, String>> gyoshaKbnList;
    /**
     * 世代検索List
     */
    private List<Map<String, String>> sedaiList;

    private DualListModel<String> cities;

    /**
     * コンストラクタ
     */
    public Mst272Bean() {
        setConGyoshaKbn("1");

    }

    public List<AutoCompOptionBean> getSelect(String query) {
        List<AutoCompOptionBean> comList = new ArrayList<>();
        AutoCompOptionBean acob = new AutoCompOptionBean();
        acob.setLabel("個建て");
        acob.setValue("1");
        AutoCompOptionBean acob1 = new AutoCompOptionBean();
        acob1.setLabel("総重量建て");
        acob1.setValue("2");
        comList.add(acob);
        comList.add(acob1);
        return comList;
    }

    /**
     * 初期処理（処理）
     *
     * @param menuId
     * @param prevScreen
     * @param backFlag
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            if (breadBean.getMenuindex() == 1) {
                // パンくず追加
                breadBean.push("代理店・中継配達料金表詳細", SCREEN.MST272_SCREEN.name(), this);
            }
            // AutoCompleteを初期化する
            Map params = new HashMap();
            autoCompleteBean.initAutoComplete("COM_GET_VW_DAIRITEN", params);
            initData();
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }
    }

    public void initData() {
        List<Map<String, Object>> searchList = new ArrayList<>();
        for (int i = 1; i < 17; i++) {
            Map map = new HashMap();
            if (i < 10) {
                map.put("listTodofukenCd", "0" + i + "  都道府" + (int) (Math.random() * 900 + 100));
            } else {
                map.put("listTodofukenCd", i + "  都道府" + (int) (Math.random() * 900 + 100));
            }
            if (i == 6) {
                map.put("listRank", "3");
                map.put("listSyousai", "○");
            } else {
                map.put("listRank", "");
                map.put("listSyousai", "");
            }
            searchList.add(map);
        }
        form.setSearchResultSelectable1(new ReportListDataModel(searchList));
        searchList = new ArrayList<>();
        for (int i = 17; i < 33; i++) {
            Map map = new HashMap();
            map.put("listTodofukenCd", i + "  都道府" + (int) (Math.random() * 900 + 100));

            map.put("listRank", "");
            map.put("listSyousai", "");

            searchList.add(map);
        }
        form.setSearchResultSelectable2(new ReportListDataModel(searchList));
        searchList = new ArrayList<>();
        for (int i = 33; i < 49; i++) {
            Map map = new HashMap();

            if (i == 48) {
                map.put("listTodofukenCd", "");
                map.put("listRank", "");
                map.put("listSyousai", "");
            } else {
                map.put("listTodofukenCd", i + "  都道府" + (int) (Math.random() * 900 + 100));
                map.put("listRank", "");
                map.put("listSyousai", "");
            }
            searchList.add(map);
        }
        form.setSearchResultSelectable3(new ReportListDataModel(searchList));
        searchList = new ArrayList<>();
        for (int i = 201; i < 217; i++) {
            Map map = new HashMap();

            if (i == 204) {
                map.put("listTodofukenCd", i + "  " + (int) (Math.random() * 900 + 100) + "市");
                map.put("listRank", "4");
                map.put("listArea", "J");
                map.put("listBikou", "");
            } else if (i == 205) {
                map.put("listTodofukenCd", i + "  " + (int) (Math.random() * 900 + 100) + "市");
                map.put("listRank", "4");
                map.put("listArea", "D");
                map.put("listBikou", "");
            } else {
                map.put("listTodofukenCd", i + "  " + (int) (Math.random() * 900 + 100) + "市");
                map.put("listRank", "");
                map.put("listArea", "A");
                map.put("listBikou", "");
            }
            searchList.add(map);
        }
        form.setSearchResultSelectable4(new ReportListDataModel(searchList));
        List<String> citiesSource = new ArrayList<String>();
        List<String> citiesTarget = new ArrayList<String>();

        List cars = new ArrayList<>();
        Map map = new HashMap();
        map.put("key0", "着地");
        List<Map<String, Object>> todofuList = new ArrayList<>();

        Map map1 = new HashMap();
        map1.put("label", "北海道");
        map1.put("key", "01");
        todofuList.add(map1);

        map.put("key1", todofuList);
        List<Map<String, Object>> todofuList1 = new ArrayList<>();

        Map map2 = new HashMap();
        map2.put("label", "青森県");
        todofuList1.add(map2);
        Map map3 = new HashMap();
        map3.put("label", "岩手県");
        todofuList1.add(map3);
        Map map4 = new HashMap();
        map4.put("label", "宮城県");
        todofuList1.add(map4);
        map.put("key2", todofuList1);
        List<Map<String, Object>> todofuList2 = new ArrayList<>();

        Map map5 = new HashMap();
        map5.put("label", "茨城県");
        todofuList2.add(map5);
        Map map6 = new HashMap();
        map6.put("label", "栃木県");
        todofuList2.add(map6);
        Map map7 = new HashMap();
        map7.put("label", "群馬県");
        todofuList2.add(map7);

        map.put("key3", todofuList2);
        List<Map<String, Object>> todofuList3 = new ArrayList<>();

        Map map8 = new HashMap();
        map8.put("label", "新潟県");
        todofuList3.add(map8);
        map.put("key4", todofuList3);
        List<Map<String, Object>> todofuList4 = new ArrayList<>();

        Map map9 = new HashMap();
        map9.put("label", "岐阜県");
        todofuList4.add(map9);
        map.put("key5", todofuList4);
        List<Map<String, Object>> todofuList5 = new ArrayList<>();

        Map map10 = new HashMap();
        map10.put("label", "京都府");
        todofuList5.add(map10);
        map.put("key6", todofuList5);
        List<Map<String, Object>> todofuList6 = new ArrayList<>();

        Map map11 = new HashMap();
        map11.put("label", "鳥取県");
        todofuList6.add(map11);
        map.put("key7", todofuList6);
        List<Map<String, Object>> todofuList7 = new ArrayList<>();

        Map map12 = new HashMap();
        map12.put("label", "徳島県");
        todofuList7.add(map12);
        map.put("key8", todofuList7);
        List<Map<String, Object>> todofuList8 = new ArrayList<>();

        Map map13 = new HashMap();
        map13.put("label", "福岡県");
        todofuList8.add(map13);
        map.put("key9", todofuList8);
        List<Map<String, Object>> todofuList9 = new ArrayList<>();

        map.put("key10", todofuList9);
        List<Map<String, Object>> subList = new ArrayList<>();
        Map map14 = new HashMap();
        map14.put("zhonglianglabel", "~");
        map14.put("zhongliang", "2");
        map14.put("geshulabel", "~");
        map14.put("geshu", "");
        map14.put("key1", "756");
        map14.put("space", "");
        subList.add(map14);
        form.setSearchResultSelectable6(new ReportListDataModel(subList));
        cars.add(map);
        form.setSearchResultSelectable5(new ReportListDataModel(cars));

    }

    public void onCarDrop(DragDropEvent ddEvent) {
        Object obj = ddEvent.getData();
        System.out.println(1111);
    }

    /**
     * 検索処理
     *
     */
    public void search() {
        // 入力チェック
        if (conShimukeChiMei.isEmpty()) {

        }

    }

    /**
     * メニュークリック（処理）
     *
     * @param menuId
     * @param nextScreen
     * @return
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }

        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック（処理）
     *
     * @return
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }
        url = forward(nextScreen, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return
     */
    @Override
    public String logoutClick() {
        return authConfBean.logout();
    }

    /**
     * 画面遷移処理（顧客マスタメンテナンス画面へ）
     *
     * @return
     * @throws java.lang.IllegalAccessException
     * @throws java.lang.reflect.InvocationTargetException
     */
    public String buttonClick() throws IllegalAccessException, InvocationTargetException {

        // 画面遷移
        url = forward(SCREEN.CUS012_SCREEN.name(), null, SCREEN.CUS011_SCREEN.name(), false);
        return url;
    }

    /**
     * @return the strTitle
     */
    public String getStrTitle() {
        return strTitle;
    }

    public List<String> completeKaisha(String query) {
        List<String> kaishaList = null;
        Map<String, Object> params = new HashMap<>();
        //params.put("conKaishaMei", query);
        ServiceInterfaceBean req = new ServiceInterfaceBean();

        req.setFunctionCode("MST271_GET_KAISHA");
        String requestData = JSONUtil.makeJSONString(params);
        req.setJson(requestData);

        //JAX-RS接続を実行(SQL側のチェック処理など未実装。)
        rest = RestfullService.getInstance();
        ServiceInterfaceBean res = null;
        try {
            res = rest.request(req);
        } catch (Exception ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
            return null;
        }

        if (res == null || res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return null;
        }

        try {
            ObjectMapper mapper = new ObjectMapper();
            kaishaList = mapper.readValue(res.getJson(), List.class);

        } catch (IOException ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
            return null;
        }

        // 戻りSIBのステータスチェック、エラー処理
        if (res == null || res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {

            // ToDo:各画面の仕様に従いメッセージ表示などのエラー処理を追加してください
        }

        //kaishaList = exec.execute(this, "MST271_GET_KAISHA", params);
        if (kaishaList == null) {
            kaishaList = new ArrayList<>();
        }

        return kaishaList;
    }

    public List<String> completeEigyosho(String query) {
        List<String> eigyoshoList = null;
        Map<String, Object> params = new HashMap<>();
        //params.put("eigyoshoMei", query);

        ServiceInterfaceBean req = new ServiceInterfaceBean();
        req.setFunctionCode("MST271_GET_SHITEN_EIGYOSHO");

        String requestData = JSONUtil.makeJSONString(params);
        req.setJson(requestData);

        //JAX-RS接続を実行(SQL側のチェック処理など未実装。)
        rest = RestfullService.getInstance();
        ServiceInterfaceBean res = null;
        try {
            res = rest.request(req);
        } catch (Exception ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
            return null;
        }

        if (res == null || res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return null;
        }

        try {
            ObjectMapper mapper = new ObjectMapper();
            eigyoshoList = mapper.readValue(res.getJson(), List.class);

        } catch (IOException ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
            return null;
        }

        // 戻りSIBのステータスチェック、エラー処理
        if (res == null || res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {

            // ToDo:各画面の仕様に従いメッセージ表示などのエラー処理を追加してください
        }
        if (eigyoshoList == null) {
            eigyoshoList = new ArrayList<>();
        }

        return eigyoshoList;
    }
}
