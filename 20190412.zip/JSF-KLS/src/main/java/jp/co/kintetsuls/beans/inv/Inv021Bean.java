/*
 * Copyright (c) Shared System Inc.
 */

package jp.co.kintetsuls.beans.inv;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.LabelValueBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.forms.inv.Inv021Form;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Getter;
import lombok.Setter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 送り状発行詳細画面
 *
 * @author 作成者 (MBP)
 * @version 2019/2/2 新規作成
 */
@javax.faces.bean.ManagedBean(name = "inv021")
@ViewScoped
public class Inv021Bean extends BaseBean {

    private final String strTitle = "送り状発行詳細";
    private String url;

    @ManagedProperty(value = "#{breadBean}")
    @Getter
    @Setter
    private BreadCrumbBean breadBean;

    @ManagedProperty(value = "#{authConfBean}")
    @Getter
    @Setter
    private AuthorityConfBean authConfBean;

    @ManagedProperty(value = "#{labelValueBean}")
    @Getter
    @Setter
    private LabelValueBean labelValueBean;

    private static final Logger logger = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    @ManagedProperty(value = "#{inv021Form}")
    @Getter
    @Setter
    private Inv021Form inv021Form;

    /**
     * コンストラクタ
     */
    public Inv021Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId クリックされたメニューID（メニューからの遷移以外はNULL）
     * @param prevScreen 遷移元の画面
     * @param backFlag 戻るフラグ（前画面へボタンからの遷移以外はFALSE）
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            // パンくず追加
            breadBean.push("送り状発行詳細", SCREEN.INV021_SCREEN.name(), this);
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }

        // TODO CHECKBOXリストを取得する
        //inv021Form.setXXXLabelValueList(labelValueBean.getStringList("Function code", "サービスパラメーター"));

    }

    /**
     * 検索処理
     */
    public void search() {

        List<Map<String, Object>> datas = new ArrayList<>();
        Map<String, Object> data = new HashMap<>();
        data.put("k11", "操作区分001");
        data.put("k12", "送り状NO001");
        data.put("k13", "引取フラグ001");
        data.put("k14", "顧客コード001");
        data.put("k15", "顧客名称001");
        data.put("k16", "担当営業所コード001");
        data.put("k17", "担当営業所名称001");
        data.put("k18", "発行パターン選択001");
        data.put("k19", "選択001");
        data.put("k20", "パターン登録001");
        data.put("k21", "集荷日001");
        data.put("k22", "伝票種別コード001");
        data.put("k23", "伝票種別名称001");
        data.put("k24", "輸送方法コード001");
        data.put("k25", "輸送方法名称001");
        data.put("k26", "発行枚数001");
        data.put("k27", "発行枚数単位ラベル001");
        data.put("k28", "荷受人数・総枚数001");
        data.put("k29", "発行営業所コード001");
        data.put("k30", "発行営業所名称001");
        data.put("k31", "荷札発行有無001");
        datas.add(data);
        //inv021Form.setSearchResultSelectable(new ReportListDataModel(datas));
    }
    /**
     * メニュークリック（処理）
     *
     * @param menuId クリックされたメニューID（メニューからの遷移以外はNULL）
     * @param nextScreen 遷移先の画面
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }

        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
   }

    /**
     * パンくずクリック（処理）
     *
     * @param nextScreen 遷移先の画面
     * @param breadIndex 選択されたパンくずのIndex
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }
        url = forward(nextScreen, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authConfBean.logout();
    }

    /**
     * 画面遷移処理
     *
     * @return 遷移先の画面URL
     * @throws java.lang.IllegalAccessException
     * @throws java.lang.reflect.InvocationTargetException
     */
    public String buttonClick() throws IllegalAccessException, InvocationTargetException {

        // 画面遷移 TODO
        url = forward(SCREEN.CUS012_SCREEN.name(), null, SCREEN.CUS011_SCREEN.name(), false);
        return url;
    }

    public String getStrTitle() {
        return strTitle;
    }

}

