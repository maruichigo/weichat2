/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mst;

import java.util.List;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.annotation.MaxSizeCheck;
import jp.co.kintetsuls.beans.common.annotation.NotEmpty;
import jp.co.kintetsuls.beans.common.annotation.NotNull;
import lombok.Data;

/**
 * 月額自動請求マスタ(輸送売上)フォーム
 * 
 * @author Song Yuyang
 * @version 2019/1/28 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst361Form")
@ViewScoped
@Data
public class Mst361Form {
    
    /**
     * 営業所オプション
     */
    @NotNull(message = "{COME0003}", name = "営業所コード")
    private AutoCompOptionBean conEigyoshoCd;
    
    /**
     * 顧客オプション
     */
    private AutoCompOptionBean conKokyakuCd;
    
    /**
     * 料金項目オプション
     */
    private AutoCompOptionBean conRyokinKomoku;
    
    /**
     * 適用名 
     */
    @MaxSizeCheck(maxSize = 40, name = "適用名")
    private String conTekiyoMei;
    
    /**
     * 世代検索条件
     */
    @NotEmpty(message = "{COME0003}", name = "世代検索条件")
    private String[] conSedaiKensakuJoken;
    
    /**
     * 申請状況
     */
    private String[] conShinseiJokyo;
    
    /**
     * 適用日
     */
    private String conTekiyoBi;
    
    /**
     * 削除済のみ
     */
    private String[] conSakujonomiKensaku;
    
    /**
     * 検索Visabled
     */
    private boolean btnSearchVisible;

    /**
     * 検索条件変更Visabled
     */
    private boolean btnSearchChangeVisible;
    
    /**
     * 検索条件Disabled
     */
    private boolean conSearchJokenDisabled;
    
    /**
     * 編集Disabled
     */
    private boolean btnEditeDisabled;

    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;

    /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;

    /**
     * 選択された結果
     */
    private List<Map<String, Object>> selectedSearchResult;
}
