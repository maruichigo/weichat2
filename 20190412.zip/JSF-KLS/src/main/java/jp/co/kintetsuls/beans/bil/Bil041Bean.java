/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.bil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.forms.bil.Bil041Form;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 *
 * @author wanglinjing
 */
@javax.faces.bean.ManagedBean(name = "bil041")
@ViewScoped
@Data
public class Bil041Bean extends BaseBean {

    private final String strTitle = "特別締め画面";
    private String url;

    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    private static final Logger logger = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    @ManagedProperty(value = "#{bil041Form}")
    private Bil041Form bil041Form;

    @ManagedProperty(value = "#{fileBean}")
    private FileBean fileBean;

    public Bil041Bean() {
    }

    @Override
    public void init(String menuId, String prevScreen, boolean backFlg) {
        try {
            // パンくず追加

            breadBean.push("特別締め画面", Cnst.SCREEN.BIL041_SCREEN.name(), this);
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }
    }

    @Override
    public String menuClick(String menuId, String nextScreen) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String logoutClick() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * @return the strTitle
     */
    public String getStrTitle() {
        return strTitle;
    }

    public void search() {
        List<Map<String, Object>> result = getResult();

        bil041Form.setSearchResultSelectable(new ReportListDataModel(result));
    }

    private List<Map<String, Object>> getResult() {
        Map<String, Object> params = new HashMap<>();
        params.put("kensu", "3");
        params.put("row", "1");
        params.put("yoteihaniStart", "2017/06/21");
        params.put("yoteihaniEnd", "2017/07/20");
        params.put("sysDate", "2017/09/20");
        params.put("shimeiShentaku", "締める");
        params.put("shimeiRaiyo", "締実施者　締実施日時");
        params.put("shimeiyochyuRaiyo", "締要求内容");
        params.put("listEigyosyoCode", "001");
        params.put("listEigyosyoMei", "品川営業所");
        params.put("listRow", "1");
        params.put("listSeikyusakiCode", "012345");
        params.put("listSeikyusakiMei", "請求先１");
        params.put("listYoteihaniStart", "2017/06/21");
        params.put("listYoteihaniEnd", " 2017/09/25");
        params.put("listShimeiSetei", "締める");
        params.put("listShimeiYoteshya", "山田太郎");
        params.put("listShimeiyuteHitoki", "2017/09/ 10:00:00");
        List<Map<String, Object>> result = new ArrayList<>();
        result.add(params);
        params = new HashMap<>();
        params.put("row", "2");
        params.put("yoteihaniStart", "2017/07/21");
        params.put("yoteihaniEnd", "2017/09/25");
        params.put("sysDate", "2017/09/20");
        params.put("shimeiShentaku", "締める");
        params.put("shimeiRaiyo", "締実施者　締実施日時");
        params.put("shimeiyochyuRaiyo", "締要求内容");
        params.put("listEigyosyoCode", "002");
        params.put("listEigyosyoMei", "四川営業所");
        params.put("listRow", "2");
        params.put("listSeikyusakiCode", "012345");
        params.put("listSeikyusakiMei", "請求先2");
        params.put("listYoteihaniStart", "2017/07/21");
        params.put("listYoteihaniEnd", " 2017/09/25");
        params.put("listShimeiSetei", "締める");
        params.put("listShimeiYoteshya", "西瓜太郎");
        params.put("listShimeiyuteHitoki", "2017/09/25 10:00:00");
        result.add(params);
        params = new HashMap<>();
        params.put("row", "3");
        params.put("yoteihaniStart", "2017/09/26");
        params.put("yoteihaniEnd", "2017/10/20");
        params.put("sysDate", "2017/09/20");
        params.put("shimeiShentaku", "締めない");
        params.put("shimeiRaiyo", "締実施者　締実施日時");
        params.put("shimeiyochyuRaiyo", "締要求内容");
        params.put("listEigyosyoCode", "003");
        params.put("listEigyosyoMei", "沐川営業所");
        params.put("listRow", "2");
        params.put("listSeikyusakiCode", "012345");
        params.put("listSeikyusakiMei", "請求先3");
        params.put("listYoteihaniStart", "2017/09/25");
        params.put("listYoteihaniEnd", " 2017/10/20");
        params.put("listShimeiSetei", "締める");
        params.put("listShimeiYoteshya", "西瓜太郎");
        params.put("listShimeiyuteHitoki", "2017/10/20 10:00:00");
        result.add(params);
        return result;
    }
}
