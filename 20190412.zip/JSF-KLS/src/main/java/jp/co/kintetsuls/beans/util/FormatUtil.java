/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * フォーマット変換ユーティリティのクラス
 * @author Yuka Kobayashi
 */
public class FormatUtil {
    
    public static String dateToJsonString(java.util.Date date){
        if(date == null ){
            return "";
        }
        java.sql.Date sqlDate = new java.sql.Date(date.getTime());
        
        return sqlDate.toString();
    }
    
    public static java.util.Date jsonStringToDate(String str){
        if(str == null || str.isEmpty()){
            return null;
        }
        
        str = str.substring(0, 10);
        DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date date = null;
        try {
            date = format.parse(str);
        } catch (ParseException ex) {
            Logger.getLogger(FormatUtil.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        return date;
        
    }
    
}
