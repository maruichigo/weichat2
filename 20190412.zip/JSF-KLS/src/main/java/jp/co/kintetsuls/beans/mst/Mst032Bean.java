/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.forms.mst.Mst032Form;
import jp.co.kintetsuls.utils.DateUtils;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 住所マスタ詳細画面
 *
 * @author 張誠 (MBP)
 * @version 2019/1/28 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst032")
@ViewScoped
@Data
public class Mst032Bean extends BaseBean {

    /**
     * タイトル
     */
    private final String TITLE = "住所マスタ詳細";

    /**
     * 画面URL
     */
    private String url;

    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;

    /**
     * 画面共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * 画面フォーム
     */
    @ManagedProperty(value = "#{mst032Form}")
    private Mst032Form mst032Form;

    /**
     * 変換情報リスト
     */
    private Map<String, Object> henkanJohoListMap;

    /**
     * 変換情報変更フラグ
     */
    private String henkanFlg;

    /**
     * 施設表示名情報リスト
     */
    private Map<String, Object> shisetsuJohoListMap;

    /**
     * 施設表示名情報変更フラグ
     */
    private String shisetsuFlg;

    /**
     * 定数：MasterInfo取得キー
     */
    private static final String CONST_MST032_MASTER = "mst032";

    /**
     * 定数：住所情報詳細
     */
    private static final String DATA_JUSHOTABLE_ID = "tableJusho_mst032";

    /**
     * 定数：離島情報
     */
    private static final String DATA_RITOTABLE_ID = "tableRito_mst032";

    /**
     * 定数：館内配送情報
     */
    private static final String DATA_KANNAITABLE_ID = "tableKannai_mst032";

    /**
     * 定数：変換情報
     */
    private static final String DATA_HENKANTABLE_ID = "tableHenkan_mst032";

    /**
     * 定数：施設表示名情報
     */
    private static final String DATA_SHISETSUTABLE_ID = "tableshisetsu_mst032";

    /**
     * 定数：住所情報検索FUNC_CODE
     */
    private static final String SEARCH_FUNC_CODE = "mst032-search";

    /**
     * 定数：行削除FUNC_CODE
     */
    private static final String DELETE_FUNC_CODE = "mst032-delete";

    /**
     * 定数：登録のチェックファンクションコード
     */
    private static final String FUNC_CODE_INSERT_UPDATE_CHECK = "mst032-insert-update-check";

    /**
     * 定数：更新FUNC_CODE
     */
    private static final String UPDATE_FUNC_CODE = "mst032-insert-update";

    /**
     * 定数：画面項目保持key
     */
    private static final String CONST_MST032_FORM = "mst032Form";

    /**
     * 定数：再検索Button取得キー
     */
    private static final String CONST_MST032_SEARCH = "search_mst032";

    /**
     * 定数：パラメータ（住所情報）
     */
    private static final String CONST_JUSHO = "jusho";

    /**
     * 定数：パラメータ（離島情報）
     */
    private static final String CONST_RITO = "rito";
    /**
     * 定数：パラメータ（館内配送情報）
     */
    private static final String CONST_KANNAI = "kannai";

    /**
     * 定数：パラメータ（JIS変換情報と仕向地変換情報）
     */
    private static final String CONST_HENKAN = "henkan";

    /**
     * 定数：パラメータ（施設表示名情報）
     */
    private static final String CONST_SHISETSU = "shisetsu";

    /**
     * 定数：パラメータ（変更情報反映）
     */
    private static final String CONST_HENKO = "henko";

    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(
            new Object() {}.getClass().getEnclosingClass().getName());

    /**
     * コンストラクタ
     */
    public Mst032Bean() {
    }

    /**
     * 1.初期処理
     *
     * @param menuId メニューID
     * @param prevScreen 遷移元画面ID
     * @param backFlag 戻るフラグ
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            // パンくず追加
            breadBean.push(TITLE, SCREEN.MST032_SCREEN.name(), this);

            // システムマスタ取得する
            pageCommonBean.getMasterInfo(CONST_MST032_MASTER);

            // JISコード
            autoCompleteViewBean.initAddr("JIS_CD", null);

            // システム日付
            mst032Form.setTekiyoKaishibiSysDate(new Date());

            // 戻ってきた場合
            Mst032Form preForm = (Mst032Form) pageCommonBean.getPageInfo(CONST_MST032_FORM);
            if (backFlag && preForm != null) {
                PageCommonBean.simpleCopy(preForm, mst032Form);
                // 再検索を実施する
                pageCommonBean.searchAgain(CONST_MST032_SEARCH);
                // 進んできた場合
            } else {
                Flash flash = pageCommonBean.getPageParam();
                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_MST032_FORM) != null) {
                    PageCommonBean.simpleCopy(flash.get(CONST_MST032_FORM), mst032Form);
                    // JISコード
                    mst032Form.setConJisCd(autoCompleteViewBean.initAddr("JIS_CD", mst032Form.getConJisCdTaihi()));
                    mst032Form.setConJisCdTaihi("");
                    // 再検索を実施する
                    pageCommonBean.searchAgain(CONST_MST032_SEARCH);
                }
            }

            // 行削除するため登録
            // 住所情報
            pageCommonBean.regDelFucntion(DATA_JUSHOTABLE_ID,
                    (dataList -> (this.delRows(DATA_JUSHOTABLE_ID, dataList))));
            // 離島情報
            pageCommonBean.regDelFucntion(DATA_RITOTABLE_ID,
                    (dataList -> (this.delRows(DATA_RITOTABLE_ID, dataList))));
            // 館内配送情報
            pageCommonBean.regDelFucntion(DATA_KANNAITABLE_ID,
                    (dataList -> (this.delRows(DATA_KANNAITABLE_ID, dataList))));
            // 変換情報
            pageCommonBean.regDelFucntion(DATA_HENKANTABLE_ID,
                    (dataList -> (this.delRows(DATA_HENKANTABLE_ID, dataList))));
            // 施設表示名情報
            pageCommonBean.regDelFucntion(DATA_SHISETSUTABLE_ID,
                    (dataList -> (this.delRows(DATA_SHISETSUTABLE_ID, dataList))));

            // 仕向地名
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_SHIMUKE_CHI_MEI);
            // 空港
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_MS_KUKO);
            // 集配地区
            autoCompleteViewBean.getMsKbnMei(MsCnst.SHUHAI_CHIKU);
            // 管轄営業所
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO);

            // 施設表示名情報リスト初期化
            shisetsuJohoListMap = new HashMap<>();
            // 変換情報リスト初期化
            henkanJohoListMap = new HashMap<>();
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * 2.検索処理
     *
     * @throws SystemException
     */
    public void searchJusho() throws SystemException {

        // 画面用変数初期化        
        // 住所基本情報
        mst032Form.setResultJusho(new HashMap<>());
        // 画面用項目設定（住所基本情報）
        setGamenJushoKihonJoho(null);
        // 住所詳細情報リスト  
        mst032Form.setListJushoSelectable(null);
        mst032Form.setListJushoSelectedResult(new ArrayList<>());
        // 離島詳細リスト
        mst032Form.setListRitoSelectable(null);
        mst032Form.setListRitoSelectedResult(new ArrayList<>());
        // 館内配送詳細リスト 
        mst032Form.setListKannaiSelectable(null);
        mst032Form.setListKannaiSelectedResult(new ArrayList<>());
        // 変換情報リスト 
        mst032Form.setListHenkanSelectable(null);
        mst032Form.setListHenkanSelectedResult(new ArrayList<>());
        // 施設表示名情報リスト 
        mst032Form.setListShisetsuSelectable(null);
        mst032Form.setListShisetsuSelectedResult(new ArrayList<>());

        // 変換情報初期化
        mst032Form.setHenkanJoho(new HashMap<>());
        // 変換情報MAP初期化
        henkanJohoListMap = new HashMap<>();
        // 施設名表記情報初期化
        mst032Form.setShisetsuJoho(new HashMap<>());
        // 施設表示名情報MAP初期化
        shisetsuJohoListMap = new HashMap<>();

        // システム日付
        mst032Form.setTekiyoKaishibiSysDate(new Date());

        Date tekiyoKaishibi = DateUtils.parseFmtYMD(mst032Form.getConTekiyoKaishibi());

        // 住所基本情報を検索し、取得した値を画面項目にセット
        Map<String, Object> searchResult = getJushoDetail(tekiyoKaishibi);
        if ("".equals(searchResult.get("resultJusho"))) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_WARN, MessageCnst.COMW0011);
            // 住所基本情報退避
            setMapJushoKihonJoho();
        } else {
            Map<String, Object> resultJusho = (Map<String, Object>) searchResult.get("resultJusho");
            // 画面用項目設定（住所基本情報）
            setGamenJushoKihonJoho(resultJusho);
            // 住所基本情報退避
            mst032Form.setResultJusho(resultJusho);
        }

        // リストワーク変数
        List<Map<String, Object>> res;

        // 住所詳細情報リスト           
        res = (List<Map<String, Object>>) searchResult.get("resultListJusho");
        // AUTOCOMPLETE項目再設定
        AutocompleteSet(res);
        mst032Form.setListJushoSelectable(new ReportListDataModel(res));
        pageCommonBean.setDatalist(DATA_JUSHOTABLE_ID, res);

        // 離島詳細リスト            
        res = (List<Map<String, Object>>) searchResult.get("resultListRito");
        mst032Form.setListRitoSelectable(new ReportListDataModel(res));
        pageCommonBean.setDatalist(DATA_RITOTABLE_ID, res);

        // 館内配送詳細リスト            
        res = (List<Map<String, Object>>) searchResult.get("resultListKannai");
        mst032Form.setListKannaiSelectable(new ReportListDataModel(res));
        pageCommonBean.setDatalist(DATA_KANNAITABLE_ID, res);

        // JISコード（退避用）
        mst032Form.setConJisCdTaihi(mst032Form.getConJisCd().getValue());
        // 適用開始日（退避用）
        mst032Form.setConTekiyoKaishibiTaihi(tekiyoKaishibi);

        // 検索条件保存
        pageCommonBean.savePageInfo(CONST_MST032_FORM, mst032Form);

    }

    /**
     * 10.変更情報反映
     *
     */
    public void henkoJohoSet() {
        // パラメータ設定
        Map<String, Object> params = new HashMap<>();

        // 変更情報反映検索フラグ
        params.put("mstFlg", CONST_HENKO);
        // JISコード
        params.put("conJisCd", mst032Form.getConJisCdTaihi());
        // 適用開始日
        params.put("conTekiyoKaishibi", mst032Form.getConTekiyoKaishibiTaihi());

        Map<String, Object> searchResult = null;
        // DBをアクセス        
        ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, SEARCH_FUNC_CODE);
        try {
            ObjectMapper mapper = new ObjectMapper();
            searchResult = mapper.readValue(res.getJson(), Map.class);
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        if (searchResult != null) {
            // 変更漢字住所（都道府県）
            mst032Form.setJshDtlHenkoKanjiJushoTodofukenMei(
                    searchResult.get("henkoTodofukenMeiKanji").toString());
            // 変更カナ住所（市区町村）
            mst032Form.setJshDtlHenkoKanjiJushoShikuchosonMei(
                    searchResult.get("henkoShikuchosonMeiKanji").toString());
            // 変更カナ住所（都道府県）
            mst032Form.setJshDtlHenkoKanaJushoTodofukenMei(
                    searchResult.get("henkoTodofukenMeiKana").toString());
            //  変更カナ住所（市区町村）
            mst032Form.setJshDtlHenkoKanaJushoShikuchosonMei(
                    searchResult.get("henkoShikuchosonMeiKana").toString());
        }
    }

    /**
     * 13.旧住所フラグ選択 14.使用不可フラグ選択
     *
     */
    public void kyuJushoControl() {
        String[] kyuJushoKbn = mst032Form.getKyjshDtlKyuJushoKubun();
        if (kyuJushoKbn.length > 0) {
            mst032Form.setKyjshDtlKyuJushoCommentEditFlg(false);
        } else {
            mst032Form.setKyjshDtlKyuJushoCommentEditFlg(true);
        }
    }

    /**
     * 18.変換件数リンク
     *
     * @param id 画面のリストID
     */
    public void henkanJohoPopShow(String id) {
        // 画面の住所情報一覧を取得
        List<Map<String, Object>> body = pageCommonBean.getDatasLists().get(id);
        if (body != null && body.size() > 0) {
            // 選択されたデータを取得
            Map<String, Object> seletedRow = (HashMap<String, Object>) pageCommonBean.getFoucesDataList().get(id);
            if (!seletedRow.isEmpty()) {
                String jisCd = "";
                String shimukeChiCd = "";
                String jisJusho = "";
                String key = "";
                // 仕向地コード(JIS)
                if (seletedRow.get("jshDtlListJisCd") != null) {
                    jisCd = seletedRow.get("jshDtlListJisCd").toString();
                }
                // 仕向地コード(下2桁)
                if (seletedRow.get("jshDtlListHShimukeChiCd") != null) {
                    shimukeChiCd = seletedRow.get("jshDtlListHShimukeChiCd").toString();
                }

                // JIS住所
                if (seletedRow.get("jshDtlListJisJusho") != null) {
                    jisJusho = seletedRow.get("jshDtlListJisJusho").toString();
                }
                // 選択されたデータのキー
                if (seletedRow.get("UNIQUE_KEY") != null) {
                    key = seletedRow.get("UNIQUE_KEY").toString();
                }
                henkanJohoShow(jisCd, shimukeChiCd, jisJusho, key);
            }
        }
    }

    /**
     * 19.変換情報コンテキストメニュー
     *
     * 25.初期処理（変換情報ポップアップ）
     *
     * @param jisCd JISコード
     * @param shimukeChiCd 仕向地コード
     * @param jisJusho JIS住所
     * @param key 選択されたデータのキー
     */
    public void henkanJohoShow(String jisCd, String shimukeChiCd, String jisJusho, String key) {
        // パラメータ判定
        if (mst032Form.getConTekiyoKaishibiTaihi() == null
                || jisCd.isEmpty()
                || shimukeChiCd.isEmpty()) {
            return;
        }
        Map<String, Object> params = new HashMap<>();
        // 変換情報検索フラグ
        params.put("mstFlg", CONST_HENKAN);
        // 検索条件の適用開始日
        params.put("conTekiyoKaishibi", mst032Form.getConTekiyoKaishibiTaihi());
        // JISコード
        params.put("hnknDtlJisCd", jisCd);
        // 仕向地コード
        params.put("hnknDtlShimukeChiCd", jisCd + shimukeChiCd);
        // 仕向地コード(下2桁)
        params.put("jshDtlListHShimukeChiCd", shimukeChiCd);
        // JIS住所
        params.put("hnknDtlJisJusho", jisJusho);
        // 選択されたデータのキー
        params.put("key", key);
        // リストMapのキーを設定
        String henkanKey = jisCd + shimukeChiCd;
        if (henkanJohoListMap.isEmpty() || !henkanJohoListMap.containsKey(henkanKey)) {
            // 変換情報マスタ検索し、取得した値を画面項目にセット
            List<Map<String, Object>> res = getHenkanJohoList(params);
            // 共通ワーク退避
            pageCommonBean.setDatalist(DATA_HENKANTABLE_ID, res);
            mst032Form.setListHenkanSelectable(new ReportListDataModel(res));
            // 変換情報検索結果を退避
            List<Map<String, Object>> result = new ArrayList<>();
            if (res.size() > 0) {
                result = listTaihi(res);
            }
            // 変換情報リスト設定
            henkanJohoListMap.put(henkanKey, result);
        } else {
            List<Map<String, Object>> datas = listTaihi((List<Map<String, Object>>) henkanJohoListMap.get(henkanKey));
            pageCommonBean.setDatalist(DATA_HENKANTABLE_ID, datas);
            mst032Form.setListHenkanSelectable(new ReportListDataModel(datas));
        }
        mst032Form.setListHenkanSelectedResult(null);
        // 変換情報検索条件を退避
        mst032Form.setHenkanJoho(params);
        // 変換情報変更フラグ初期化
        henkanFlg = "0";
        // 変換情報画面表示
        pageCommonBean.executeScript("PF('widHenKanJoho').show();");
    }

    /**
     * 表記情報件数リンク（仕様書ない、変換件数リンクと同じよう実装、暫定保留）
     *
     * @param id 画面のリストID
     */
    public void shisetsuJohoPopShow(String id) {
        // 画面の館内配送情報一覧を取得
        List<Map<String, Object>> body = pageCommonBean.getDatasLists().get(id);
        if (body != null && body.size() > 0) {
            // 選択されたデータを取得
            Map<String, Object> seletedRow = (HashMap<String, Object>) pageCommonBean.getFoucesDataList().get(id);
            if (!seletedRow.isEmpty()) {
                String shisetsuMei = "";
                String haisoSeq = "";
                String key = "";
                // 施設名
                if (seletedRow.get("khDtlListShisetsuMei") != null) {
                    shisetsuMei = seletedRow.get("khDtlListShisetsuMei").toString();
                }
                // 住所館内配送シーケンス
                if (seletedRow.get("khDtlListHJushoKannaihaisoSeq") != null) {
                    haisoSeq = seletedRow.get("khDtlListHJushoKannaihaisoSeq").toString();
                }
                // 選択されたデータのキー
                if (seletedRow.get("UNIQUE_KEY") != null) {
                    key = seletedRow.get("UNIQUE_KEY").toString();
                }
                shisetsuJohoShow(shisetsuMei, haisoSeq, key);
            }
        }
    }

    /**
     * 20.施設名表記情報コンテキストメニュー
     *
     * 29.初期処理（施設名表記情報ポップアップ）
     *
     * @param shisetsuMei 施設表示名
     * @param haisoSeq 住所館内配送シーケンス
     * @param key 選択されたデータのキー
     */
    public void shisetsuJohoShow(String shisetsuMei, String haisoSeq, String key) {
        // パラメータ判定
        if (shisetsuMei.isEmpty() || haisoSeq.isEmpty()) {
            return;
        }

        Map<String, Object> params = new HashMap<>();
        // 変換情報検索フラグ
        params.put("mstFlg", CONST_SHISETSU);
        // JISコード
        params.put("khDtlListHJisCd", mst032Form.getConJisCdTaihi());
        // 適用開始日   
        params.put("khDtlListHTekiyoKaishibi", mst032Form.getConTekiyoKaishibiTaihi());
        // 住所館内配送シーケンス
        params.put("khDtlListHJushoKannaihaisoSeq", haisoSeq);
        // 施設表示名
        params.put("shstDtlShisetsuMei", shisetsuMei);
        // 選択されたデータのキー
        params.put("key", key);
        if (shisetsuJohoListMap.isEmpty() || !shisetsuJohoListMap.containsKey(haisoSeq)) {
            // 施設表示名情報マスタ検索し、取得した値を画面項目にセット
            List<Map<String, Object>> res = getShisetsuJohoList(params);
            pageCommonBean.setDatalist(DATA_SHISETSUTABLE_ID, res);
            mst032Form.setListShisetsuSelectable(new ReportListDataModel(res));
            List<Map<String, Object>> result = new ArrayList<>();
            // 施設表示名情報検索結果を退避
            if (res.size() > 0) {
                result = listTaihi(res);
            }
            // 施設表示名情報リスト設定
            shisetsuJohoListMap.put(haisoSeq, result);
        } else {
            // 既存データ設定
            List<Map<String, Object>> datas = listTaihi((List<Map<String, Object>>) shisetsuJohoListMap.get(haisoSeq));
            pageCommonBean.setDatalist(DATA_SHISETSUTABLE_ID, datas);
            mst032Form.setListShisetsuSelectable(new ReportListDataModel(datas));
        }
        mst032Form.setListShisetsuSelectedResult(null);
        // 施設表示名情報検索条件を退避
        mst032Form.setShisetsuJoho(params);
        // 施設表示名情報変更フラグ初期化
        shisetsuFlg = "0";
        // 施設表示名情報画面表示
        pageCommonBean.executeScript("PF('widShisetsuJoho').show();");
    }

    /**
     * 21.最終行入力エンターキーダウン（住所情報詳細表）
     *
     * 22.最終行入力エンターキーダウン（離島情報表）
     *
     * 23.最終行入力エンターキーダウン（館内配送情報表 ）
     *
     * 28.最終行入力エンターキーダウン（変換情報ポップアップ）
     *
     * 32.最終行入力エンターキーダウン（施設名表記情報ポップアップ
     *
     * @param id 画面リストID
     * @param indexRow 選択された行
     */
    public void addRowEnterKey(String id, int indexRow) {
        // 最終行入力チェック
        List<Map<String, Object>> selectList = pageCommonBean.getDatasLists().get(id);
        if (indexRow != selectList.size() - 1) {
            return;
        }
        boolean chkFlg = false;
        if (!selectList.isEmpty()) {
            Map<String, Object> endData = selectList.get(selectList.size() - 1);
            Set setKey = endData.entrySet();
            Iterator iteratorKey = setKey.iterator();
            String tmpData;
            while (iteratorKey.hasNext()) {
                Map.Entry mapentry = (Map.Entry) iteratorKey.next();
                String chkCol = mapentry.getKey().toString();
                if (!"UNIQUE_KEY".equals(chkCol) && !"addFlg".equals(chkCol) && endData.get(chkCol) != null) {
                    if ((DATA_JUSHOTABLE_ID.equals(id) && !"jshDtlListJisCd".equals(chkCol)
                            && !"jshDtlListJisJusho".equals(chkCol))
                            || (DATA_RITOTABLE_ID.equals(id) && !"rtDtlListJisJusho".equals(chkCol))
                            || (DATA_KANNAITABLE_ID.equals(id) && !"khDtlListJisJusho".equals(chkCol))
                            || DATA_HENKANTABLE_ID.equals(id)
                            || DATA_SHISETSUTABLE_ID.equals(id)) {
                        tmpData = endData.get(chkCol).toString();
                        if ((!tmpData.isEmpty()) && (!"false".equals(tmpData))) {
                            chkFlg = true;
                            break;
                        }
                    }
                }
            }
        } else {
            chkFlg = true;
        }
        if (chkFlg) {
            pageCommonBean.addRow(id, true);
            // 固定データ設定
            // 漢字住所（都道府県）+ 漢字住所（市区町村）
            String jisJusho = mst032Form.getJshDtlKanjiJushoTodofukenMei()
                    + mst032Form.getJshDtlKanjiJushoShikuchosonMei();
            if (DATA_JUSHOTABLE_ID.equals(id)) {
                // 住所情報詳細
                // 仕向地コード(JIS)
                selectList.get(indexRow + 1).put("jshDtlListJisCd", mst032Form.getConJisCdTaihi());
                // JIS住所
                selectList.get(indexRow + 1).put("jshDtlListJisJusho", jisJusho);
            } else if (DATA_RITOTABLE_ID.equals(id)) {
                // 離島情報
                // JIS住所
                selectList.get(indexRow + 1).put("rtDtlListJisJusho", jisJusho);
            } else if (DATA_KANNAITABLE_ID.equals(id)) {
                // 館内配送情報
                // JIS住所
                selectList.get(indexRow + 1).put("khDtlListJisJusho", jisJusho);
            }
        }
    }

    /**
     * 24.更新ボタン
     *
     * @throws SystemException
     */
    public void update() throws SystemException {

        // 入力内容チェック処理
        int status;
        // チェック仕様5-1
        status = inputChcek();
        if (status != 1) {
            // エラーの場合
            return;
        }

        // チェック仕様5-2
        status = ediJushoCheck();
        if (status != 1) {
            // エラーの場合
            return;
        }
        // DB更新処理
        dbUpdate();

    }

    /**
     * 更新処理サーバ側
     *
     * @throws SystemException
     */
    public int dbUpdate() throws SystemException {

        // 登録更新住所情報パラメータ
        Map<String, Object> params = new HashMap<>();

        // 住所JISマスタ更新判定
        // updFlg "":更新なし,"0":新規,"1":更新あり
        String updFlg = jushoJisHenkoHantei();
        // 住所基本情報修正フラグ
        params.put("updFlg", updFlg);

        // 存在チェック、登録更新チェック
        int status = kanrenChcek(params.get("updFlg").toString());
        if (status != 1) {
            // エラーの場合
            return -1;
        }

        // 検索条件設定
        // JISコード
        params.put("conJisCd", mst032Form.getConJisCdTaihi());
        // 適用開始日
        params.put("conTekiyoKaishibi", mst032Form.getConTekiyoKaishibiTaihi());
        // 適用名
        params.put("conTekiyoMei", mst032Form.getConTekiyoMeiTaihi());
        // 適用終了
        params.put("conTekiyoShuryo", mst032Form.getConTekiyoShuryoTaihi());
        // 更新ユーザー
        params.put("userCd", authConfBean.getUserCd());

        // 住所基本情報
        setMapJushoKihonJoho();
        params.put("jushoJoho", mst032Form.getResultJusho());

        // 登録一覧リストの初期化を行う
        List<Map<String, Object>> torokuJushoList = new ArrayList();
        // 更新一覧リストの初期化を行う
        List<Map<String, Object>> koshinJushoList = new ArrayList();
        // 仕向地コード(下2桁)変更リストの初期化を行う
        List<Map<String, Object>> henkoJushoList = new ArrayList();

        // 登録更新情報設定処理（住所情報詳細_一覧）
        // 登録一覧リスト（住所詳細）
        params.put("jushoAddList", torokuJushoList);
        // 更新一覧リスト（住所詳細）
        params.put("jushoUpdList", koshinJushoList);
        // 仕向地コード変更一覧リスト（住所詳細）
        params.put("jushoHenkoList", henkoJushoList);
        for (Map<String, Object> rec : mst032Form.getListJushoSelectedResult()) {
            // 住所情報詳細.カレント行
            if (rec.get(StndConsIF.CONST_ADD_ROW_KEY) != null) {
                // 登録対象
                torokuJushoList.add(rec);
            } else {
                if (!rec.get("jshDtlListShimukeChiCd").equals(rec.get("jshDtlListHShimukeChiCd"))) {
                    // 主キー変更対象
                    henkoJushoList.add(rec);
                } else {
                    // 更新対象
                    koshinJushoList.add(rec);
                }
            }
        }

        // 登録更新情報設定処理（離島情報_一覧）
        // 登録一覧リストの初期化を行う
        List<Map<String, Object>> torokuRitoList = new ArrayList();
        // 更新一覧リストの初期化を行う
        List<Map<String, Object>> koshinRitoList = new ArrayList();
        for (Map<String, Object> rec : mst032Form.getListRitoSelectedResult()) {
            // 住所情報詳細.カレント行 = 登録対象
            if (rec.get(StndConsIF.CONST_ADD_ROW_KEY) != null) {
                torokuRitoList.add(rec);
            } else {
                koshinRitoList.add(rec);
            }
        }
        // 登録一覧リスト（離島情報）
        params.put("ritoAddList", torokuRitoList);
        // 更新一覧リスト（離島情報）
        params.put("ritoUpdList", koshinRitoList);

        // 登録更新情報設定処理（館内配送情報_一覧）
        // 登録一覧リストの初期化を行う
        List<Map<String, Object>> torokuKannaiList = new ArrayList();
        // 更新一覧リストの初期化を行う
        List<Map<String, Object>> koshinKannaiList = new ArrayList();
        for (Map<String, Object> rec : mst032Form.getListKannaiSelectedResult()) {
            // 住所情報詳細.カレント行 = 登録対象
            if (rec.get(StndConsIF.CONST_ADD_ROW_KEY) != null) {
                torokuKannaiList.add(rec);
            } else {
                koshinKannaiList.add(rec);
            }
        }
        // 登録一覧リスト（館内配送情報）
        params.put("kannaiAddList", torokuKannaiList);
        // 更新一覧リスト（館内配送情報）
        params.put("kannaiUpdList", koshinKannaiList);

        // 登録更新情報設定処理（変換情報_一覧）        
        // 変換情報リスト
        params.put("henkanJohoListMap", henkanJohoListMap);

        // 登録更新情報設定処理（施設名表記情報_一覧）       
        // 施設名表記情報リスト
        params.put("shisetsuJohoListMap", shisetsuJohoListMap);

        // 登録更新チェック
        // DBをアクセス
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, UPDATE_FUNC_CODE);
        // エラーの場合、処理終了
        if (serviceInterfaceBean != null && serviceInterfaceBean.getStatusCode()
                == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            String[] tableNames = serviceInterfaceBean.getTableName().split(",");
            messagePropertyBean.message(serviceInterfaceBean.getMessages().get(0)[0],
                    serviceInterfaceBean.getMessages().get(0)[1],
                    serviceInterfaceBean.getMessages().get(0)[2],
                    tableNames[0]);
            return serviceInterfaceBean.getStatusCode();
        }
        // 画面情報再取得
        this.searchJusho();
        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, "更新");
        return 0;
    }

    /**
     * EDI住所チェック処理
     *
     */
    private int ediJushoCheck() {
        // 一覧の入力チェック処理	
        mst032Form.setEdiJushoMsg("");
        for (Map<String, Object> rec : mst032Form.getListJushoSelectedResult()) {
            String chkKekka = mst032Form.getJisChkDtlCheckKekka();
            if (("OK".equals(chkKekka) || "新規".equals(chkKekka) || "差異あり".equals(chkKekka))
                    && "00".equals(rec.get("jshDtlListShimukeChiCd").toString())) {
                if (Boolean.valueOf(rec.get("jshDtlListKyuEdiJushoFlg").toString()) == false) {
                    mst032Form.setEdiJushoMsg("JIS住所（仕向地コード下2桁が00）の"
                            + "旧EDI住所が外れています。このまま登録してよろしいですか。");
                }
                if (Boolean.valueOf(rec.get("jshDtlListShinEdiJushoFlg").toString()) == false) {
                    mst032Form.setEdiJushoMsg("JIS住所（仕向地コード下2桁が00）の"
                            + "新EDI住所が外れています。このまま登録してよろしいですか。");
                }
                if (Boolean.valueOf(rec.get("jshDtlListKyuEdiJushoFlg").toString()) == false
                        && Boolean.valueOf(rec.get("jshDtlListShinEdiJushoFlg").toString()) == false) {
                    mst032Form.setEdiJushoMsg("JIS住所（仕向地コード下2桁が00）の"
                            + "旧EDI住所、新EDI住所が外れています。このまま登録してよろしいですか。");
                }
                // エラーの場合
                if (!"".equals(mst032Form.getEdiJushoMsg())) {
                    pageCommonBean.executeScript("km.showConfirmDialog('mst032DialogCheck')");
                    return -1;
                }
            }
        }
        return 1;
    }

    /**
     * 26.閉じるボタン（変換情報ポップアップ）
     *
     */
    public void henkanGamenHiden() {

        // 画面項目修正判定。
        if ("1".equals(henkanFlg)) {
            pageCommonBean.executeScript("km.showConfirmDialog('mst032DialogHenkan')");
        } else {
            // 変換情報画面閉じる
            pageCommonBean.executeScript("PF('widHenKanJoho').hide();");
        }
    }

    /**
     * 変換情報閉じる場合、データ復元
     *
     */
    public void henkanDataFukugen() {
        // リストMapのキーを設定
        String henkanKey = mst032Form.getHenkanJoho().get("hnknDtlShimukeChiCd").toString();
        // 画面入力内容を破棄し、入力前の値に戻す
        List<Map<String, Object>> res = listTaihi((List<Map<String, Object>>) henkanJohoListMap.get(henkanKey));
        pageCommonBean.setDatalist(DATA_HENKANTABLE_ID, res);
        mst032Form.setListHenkanSelectable(new ReportListDataModel(res));
        // 変換情報画面閉じる
        pageCommonBean.executeScript("PF('widHenKanJoho').hide();");
    }

    /**
     * 27.設定ボタン（変換情報ポップアップ）
     *
     */
    public void setHenkanJoho() {
        List<Map<String, Object>> datas;
        Iterator<Map<String, Object>> ite;

        // 仕向地コード相関チェック
        datas = mst032Form.getListJushoSelectable().getDatasource();
        // 仕向地コード
        String shimukeChiCd = mst032Form.getHenkanJoho().get("hnknDtlShimukeChiCd").toString();
        // チェックフラグ
        String shimukeChiCdFlg = "";
        if (datas.size() > 0) {
            // 仕向地コードチェック
            ite = datas.iterator();
            while (ite.hasNext()) {
                Map<String, Object> i = ite.next();
                if (shimukeChiCd.equals(i.get("jshDtlListJisCd").toString()
                        + i.get("jshDtlListHShimukeChiCd").toString())) {
                    shimukeChiCdFlg = "1";
                    break;
                }
            }
        }
        // エラーの場合        
        if ("".equals(shimukeChiCdFlg)) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MSTE0052, "仕向地コード");
            return;
        }
        // 住所相関チェック
        datas = mst032Form.getListHenkanSelectable().getDatasource();
        if (datas.size() > 0) {
            List<String> jushoMeiList = new ArrayList<>();
            ite = datas.iterator();
            while (ite.hasNext()) {
                Map<String, Object> i = ite.next();
                jushoMeiList.add(i.get("hnknDtlListHenkanJohoJusho").toString());
                // 最大桁数チェック
                // 変換住所
                if (!maxSizeCheck(i.get("hnknDtlListHenkanJohoJusho").toString(), 40)) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0002, "変換住所", "40");
                    return;
                }
            }
            ite = datas.iterator();
            while (ite.hasNext()) {
                Map<String, Object> i = ite.next();
                List<String> filterList = jushoMeiList.stream()
                        .filter((String sub) -> i.get("hnknDtlListHenkanJohoJusho").toString().equals(sub))
                        .collect(Collectors.toList());
                if (filterList.size() > 1) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MSTE0052, "住所");
                    return;
                }
            }
            // 変換情報重複チェック
            Map<String, Object> params = new HashMap<>();
            // チェックフラグ            
            params.put("mstFlg", "hkChk");
            // 検索条件の適用開始日
            params.put("conTekiyoKaishibi", mst032Form.getHenkanJoho().get("conTekiyoKaishibi"));
            // JISコード
            params.put("hnknDtlJisCd", mst032Form.getHenkanJoho().get("hnknDtlJisCd"));
            // 仕向地コード
            params.put("hnknDtlShimukeChiCd", mst032Form.getHenkanJoho().get("hnknDtlShimukeChiCd"));
            // 仕向地コード(下2桁)
            params.put("jshDtlListHShimukeChiCd", mst032Form.getHenkanJoho().get("jshDtlListHShimukeChiCd"));
            // 選択されたデータ
            params.put("dataList", datas);
            // 検索処理
            List<Map<String, Object>> res = getHenkanJohoList(params);
            if (res != null && res.size() > 0) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MSTE0050,
                        mst032Form.getHenkanJoho().get("hnknDtlShimukeChiCd"), res.get(0).get("henkanJohoJusho"));
                return;
            }
        }
        // 変換件数設定
        henkanKensuSet(datas.size());
        // 変換フラグ設定
        henkanFlg = "0";
        // 施設表示名情報リスト設定
        String henkanKey = mst032Form.getHenkanJoho().get("hnknDtlShimukeChiCd").toString();
        henkanJohoListMap.put(henkanKey, listTaihi(datas));
        // 設定完了
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.MSTI0001);
    }

    /**
     * 30.閉じるボタン（施設名表記情報ポップアップ）
     *
     */
    public void shisetsuGamenHiden() {
        // 画面項目修正判定。
        if ("1".equals(shisetsuFlg)) {
            pageCommonBean.executeScript("km.showConfirmDialog('mst032DialogShisetsu')");

        } else {
            // 施設表示名情報画面閉じる
            pageCommonBean.executeScript("PF('widShisetsuJoho').hide();");
        }
    }

    /**
     * 施設名表記情報閉じる場合、データ復元
     *
     */
    public void shisetsuDataFukugen() {
        // 画面入力内容を破棄し、入力前の値に戻す
        // リストMapのキーを設定
        String shisetsuKey = mst032Form.getShisetsuJoho().get("khDtlListHJushoKannaihaisoSeq").toString();
        List<Map<String, Object>> res = listTaihi((List<Map<String, Object>>) shisetsuJohoListMap.get(shisetsuKey));
        pageCommonBean.setDatalist(DATA_SHISETSUTABLE_ID, res);
        mst032Form.setListShisetsuSelectable(new ReportListDataModel(res));
        // 施設表示名情報画面閉じる
        pageCommonBean.executeScript("PF('widShisetsuJoho').hide();");
    }

    /**
     * 31.設定ボタン（施設名表記情報ポップアップ）
     *
     */
    public void setShisetsuJoho() {
        MessageModuleBean message;
        List<Map<String, Object>> datas = mst032Form.getListShisetsuSelectable().getDatasource();
        if (datas.size() > 0) {
            // 施設表示名相関チェック
            List<String> hyojiMeiList = new ArrayList<>();
            Iterator<Map<String, Object>> ite = datas.iterator();
            while (ite.hasNext()) {
                Map<String, Object> i = ite.next();
                hyojiMeiList.add(i.get("shstDtlListHyojiMei").toString());
                // 施設名
                if (!maxSizeCheck(i.get("hnknDtlListHenkanJohoJusho").toString(), 40)) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0002, "変換住所", "40");
                    return;
                }
            }
            ite = datas.iterator();
            while (ite.hasNext()) {
                Map<String, Object> i = ite.next();
                List<String> filterList = hyojiMeiList.stream()
                        .filter((String sub) -> i.get("shstDtlListHyojiMei").toString().equals(sub))
                        .collect(Collectors.toList());
                if (filterList.size() > 1) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MSTE0052, "施設");
                    return;
                }
            }
            // 施設名表記情報重複チェック
            Map<String, Object> params = new HashMap<>();
            // 検索フラグ
            params.put("mstFlg", "shChk");
            // JISコード   
            params.put("khDtlListHJisCd", mst032Form.getShisetsuJoho().get("khDtlListHJisCd"));
            // 適用開始日
            params.put("khDtlListHTekiyoKaishibi", mst032Form.getShisetsuJoho().get("khDtlListHTekiyoKaishibi"));
            // 住所館内配送シーケンス
            params.put("khDtlListHJushoKannaihaisoSeq",
                    mst032Form.getShisetsuJoho().get("khDtlListHJushoKannaihaisoSeq"));
            // 選択されたデータ
            params.put("dataList", datas);
            // 検索処理
            List<Map<String, Object>> res = getShisetsuJohoList(params);
            if (res != null && res.size() > 0) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MSTE0051, res.get(0).get("hyojiMei"));
                return;
            }
        }
        // 表記情報件数設定
        hyokiJohoKensuSet(datas.size());
        // 変更フラグ設定
        shisetsuFlg = "0";

        // 施設表示名情報リスト設定
        // リストMapのキーを設定
        String shisetsuKey = mst032Form.getShisetsuJoho().get("khDtlListHJushoKannaihaisoSeq").toString();
        // 施設表示名情報リスト設定
        shisetsuJohoListMap.put(shisetsuKey, listTaihi(datas));

        // 設定完了
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.MSTI0001);
    }

    /**
     * メニュークリック（処理）
     *
     * @param menuId メニューID
     * @param nextScreen 遷移先画面ID
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック（処理）
     *
     * @param nextScreen 遷移先画面ID
     * @param breadIndex パンくずのインデックス
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        url = forward(nextScreen, null, null, true);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authConfBean.logout();
    }

    /**
     * 住所情報取得する
     *
     * @param tekiyoKaishibi 適用開始日
     * @return 検索結果
     */
    private Map<String, Object> getJushoDetail(Date tekiyoKaishibi) {

        // パラメータ設定
        Map<String, Object> params = new HashMap<>();

        // 住所情報検索フラグ
        params.put("mstFlg", CONST_JUSHO);
        // JISコード
        params.put("conJisCd", mst032Form.getConJisCd().getValue());
        // 適用開始日
        params.put("conTekiyoKaishibi", tekiyoKaishibi);

        // DBをアクセス
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, SEARCH_FUNC_CODE);
        try {
            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> searchResult = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
            return searchResult;
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
    }

    /**
     * 画面用項目設定（住所基本情報）
     *
     * @param res 住所基本情報
     */
    private void setGamenJushoKihonJoho(Map<String, Object> res) {
        if (res != null && res.size() > 0) {
            // チェック実行日時
            mst032Form.setJisChkDtlCheckJikkoHizuke(res.get("jisChkDtlCheckJikkoHizuke").toString());
            // チェック結果
            mst032Form.setJisChkDtlCheckKekka(res.get("jisChkDtlCheckKekka").toString());
            // ステータス変更日時
            mst032Form.setJisChkDtlStatusHenkoHizuke(res.get("jisChkDtlStatusHenkoHizuke").toString());
            // 漢字住所（都道府県） 
            mst032Form.setJshDtlKanjiJushoTodofukenMei(res.get("jshDtlKanjiJushoTodofukenMei").toString());
            // 漢字住所（市区町村）
            mst032Form.setJshDtlKanjiJushoShikuchosonMei(res.get("jshDtlKanjiJushoShikuchosonMei").toString());
            // 変更漢字住所（都道府県）
            mst032Form.setJshDtlHenkoKanjiJushoTodofukenMei(res.get("jshDtlHenkoKanjiJushoTodofukenMei").toString());
            // 変更漢字住所（市区町村）
            mst032Form.setJshDtlHenkoKanjiJushoShikuchosonMei(
                    res.get("jshDtlHenkoKanjiJushoShikuchosonMei").toString());
            // カナ住所（都道府県）
            mst032Form.setJshDtlKanaJushoTodofukenMei(res.get("jshDtlKanaJushoTodofukenMei").toString());
            // カナ住所（市区町村）
            mst032Form.setJshDtlKanaJushoShikuchosonMei(res.get("jshDtlKanaJushoShikuchosonMei").toString());
            // 変更カナ住所（都道府県）
            mst032Form.setJshDtlHenkoKanaJushoTodofukenMei(res.get("jshDtlHenkoKanaJushoTodofukenMei").toString());
            // 変更カナ住所（市区町村）
            mst032Form.setJshDtlHenkoKanaJushoShikuchosonMei(res.get("jshDtlHenkoKanaJushoShikuchosonMei").toString());
            // 英語住所（都道府県）
            mst032Form.setJshDtlEigoJushoTodofukenMei(res.get("jshDtlEigoJushoTodofukenMei").toString());
            // 英語住所（市区町村）
            mst032Form.setJshDtlEigoJushoShikuchosonMei(res.get("jshDtlEigoJushoShikuchosonMei").toString());
            // 離島有無
            String[] umuFlg = {res.get("jshDtlRitoUmuFlg").toString()};
            mst032Form.setJshDtlRitoUmuFlg(umuFlg);
            // 離島件数
            mst032Form.setJshDtlRitoKensu(res.get("jshDtlRitoKensu").toString());
            // 館内配送件数
            mst032Form.setJshDtlKannaiHaisoKensu(res.get("jshDtlKannaiHaisoKensu").toString());
            // HTコメント(100バイト)
            mst032Form.setJshDtlHtComment1(res.get("jshDtlHtComment1").toString());
            // HTコメント(200バイト)
            mst032Form.setJshDtlHtComment2(res.get("jshDtlHtComment2").toString());
            // 旧住所区分
            String[] kyuJushoKubun = {res.get("kyuJushoFlg").toString(), res.get("shiyoFukaFlg").toString()};
            mst032Form.setKyjshDtlKyuJushoKubun(kyuJushoKubun);
            // JISコード設定処理
            if (res.get("jshDtlHtComment2").toString().isEmpty()) {
                mst032Form.setKyjshDtlShinJisCd(autoCompleteViewBean.initAddr("JIS_CD_NEW", null));
            } else {
                mst032Form.setKyjshDtlShinJisCd(autoCompleteViewBean.initAddr("JIS_CD_NEW",
                        res.get("kyjshDtlShinJisCd").toString()));
            }
            // 旧住所コメント
            mst032Form.setKyjshDtlKyuJushoComment(res.get("kyjshDtlKyuJushoComment").toString());
            // 旧住所コメント制御
            if ("1".equals(kyuJushoKubun[0]) || "2".equals(kyuJushoKubun[1])) {
                mst032Form.setKyjshDtlKyuJushoCommentEditFlg(false);
            } else {
                mst032Form.setKyjshDtlKyuJushoCommentEditFlg(true);
            }
            // 更新日時
            mst032Form.setKshnDtlkoshinNichiji(res.get("kshnDtlkoshinNichiji").toString());
            // 更新者
            mst032Form.setKshnDtlUser(res.get("kshnDtlUser").toString());
        } else {
            // チェック実行日時
            mst032Form.setJisChkDtlCheckJikkoHizuke("");
            // チェック結果
            mst032Form.setJisChkDtlCheckKekka("");
            // ステータス変更日時
            mst032Form.setJisChkDtlStatusHenkoHizuke("");
            // 漢字住所（都道府県） 
            mst032Form.setJshDtlKanjiJushoTodofukenMei("");
            // 漢字住所（市区町村）
            mst032Form.setJshDtlKanjiJushoShikuchosonMei("");
            // 変更漢字住所（都道府県）
            mst032Form.setJshDtlHenkoKanjiJushoTodofukenMei("");
            // 変更漢字住所（市区町村）
            mst032Form.setJshDtlHenkoKanjiJushoShikuchosonMei("");
            // カナ住所（都道府県）
            mst032Form.setJshDtlKanaJushoTodofukenMei("");
            // カナ住所（市区町村）
            mst032Form.setJshDtlKanaJushoShikuchosonMei("");
            // 変更カナ住所（都道府県）
            mst032Form.setJshDtlHenkoKanaJushoTodofukenMei("");
            // 変更カナ住所（市区町村）
            mst032Form.setJshDtlHenkoKanaJushoShikuchosonMei("");
            // 英語住所（都道府県）
            mst032Form.setJshDtlEigoJushoTodofukenMei("");
            // 英語住所（市区町村）
            mst032Form.setJshDtlEigoJushoShikuchosonMei("");
            // 離島有無
            String[] umuFlg = {"0"};
            mst032Form.setJshDtlRitoUmuFlg(umuFlg);
            // 離島件数
            mst032Form.setJshDtlRitoKensu("");
            // 館内配送件数
            mst032Form.setJshDtlKannaiHaisoKensu("");
            // HTコメント(100バイト)
            mst032Form.setJshDtlHtComment1("");
            // HTコメント(200バイト)
            mst032Form.setJshDtlHtComment2("");
            // 旧住所区分
            String[] kyuJushoKubun = {"0", "0"};
            mst032Form.setKyjshDtlKyuJushoKubun(kyuJushoKubun);
            // JISコード設定処理
            mst032Form.setKyjshDtlShinJisCd(autoCompleteViewBean.initAddr("JIS_CD_NEW", null));
            // 旧住所コメント
            mst032Form.setKyjshDtlKyuJushoComment("");
            // 旧住所コメント制御
            mst032Form.setKyjshDtlKyuJushoCommentEditFlg(true);
            // 更新日時
            mst032Form.setKshnDtlkoshinNichiji("");
            // 更新者
            mst032Form.setKshnDtlUser("");
        }
    }

    /**
     * 更新用項目設定（住所基本情報）
     *
     */
    private void setMapJushoKihonJoho() {
        // チェック実行日時
        mst032Form.getResultJusho().put("jisChkDtlCheckJikkoHizuke",
                mst032Form.getJisChkDtlCheckJikkoHizuke());
        // チェック結果
        mst032Form.getResultJusho().put("jisChkDtlCheckKekka",
                mst032Form.getJisChkDtlCheckKekka());
        // ステータス変更日時
        mst032Form.getResultJusho().put("jisChkDtlStatusHenkoHizuke",
                mst032Form.getJisChkDtlStatusHenkoHizuke());
        // 漢字住所（都道府県）
        mst032Form.getResultJusho().put("jshDtlKanjiJushoTodofukenMei",
                mst032Form.getJshDtlKanjiJushoTodofukenMei());
        // 漢字住所（市区町村）
        mst032Form.getResultJusho().put("jshDtlKanjiJushoShikuchosonMei",
                mst032Form.getJshDtlKanjiJushoShikuchosonMei());
        // 変更漢字住所（都道府県）
        mst032Form.getResultJusho().put("jshDtlHenkoKanjiJushoTodofukenMei",
                mst032Form.getJshDtlHenkoKanjiJushoTodofukenMei());
        // 変更漢字住所（市区町村）
        mst032Form.getResultJusho().put("jshDtlHenkoKanjiJushoShikuchosonMei",
                mst032Form.getJshDtlHenkoKanjiJushoShikuchosonMei());
        // カナ住所（都道府県）
        mst032Form.getResultJusho().put("jshDtlKanaJushoTodofukenMei",
                mst032Form.getJshDtlKanaJushoTodofukenMei());
        // カナ住所（市区町村）
        mst032Form.getResultJusho().put("jshDtlKanaJushoShikuchosonMei",
                mst032Form.getJshDtlKanaJushoShikuchosonMei());
        // 変更カナ住所（都道府県）
        mst032Form.getResultJusho().put("jshDtlHenkoKanaJushoTodofukenMei",
                mst032Form.getJshDtlHenkoKanaJushoTodofukenMei());
        // 変更カナ住所（市区町村）
        mst032Form.getResultJusho().put("jshDtlHenkoKanaJushoShikuchosonMei",
                mst032Form.getJshDtlHenkoKanaJushoShikuchosonMei());
        // 英語住所（都道府県）
        mst032Form.getResultJusho().put("jshDtlEigoJushoTodofukenMei",
                mst032Form.getJshDtlEigoJushoTodofukenMei());
        // 英語住所（市区町村）
        mst032Form.getResultJusho().put("jshDtlEigoJushoShikuchosonMei",
                mst032Form.getJshDtlEigoJushoShikuchosonMei());
        // 離島有無
        String umuFlg = "0";
        if (mst032Form.getJshDtlRitoUmuFlg().length > 0) {
            umuFlg = mst032Form.getJshDtlRitoUmuFlg()[0];
        }
        mst032Form.getResultJusho().put("jshDtlRitoUmuFlg", umuFlg);
        // HTコメント(100バイト)
        mst032Form.getResultJusho().put("jshDtlHtComment1", mst032Form.getJshDtlHtComment1());
        // HTコメント(200バイト)
        mst032Form.getResultJusho().put("jshDtlHtComment2", mst032Form.getJshDtlHtComment2());
        // 旧住所区分
        String kyuJushoFlg = "0";
        String shiyoFukaFlg = "0";
        if (mst032Form.getKyjshDtlKyuJushoKubun().length > 0) {
            if (mst032Form.getKyjshDtlKyuJushoKubun().length == 2) {
                kyuJushoFlg = mst032Form.getKyjshDtlKyuJushoKubun()[0];
                shiyoFukaFlg = mst032Form.getKyjshDtlKyuJushoKubun()[1];
            } else if ("1".equals(mst032Form.getKyjshDtlKyuJushoKubun()[0])) {
                kyuJushoFlg = "1";
            } else {
                shiyoFukaFlg = "2";
            }
        }
        mst032Form.getResultJusho().put("kyuJushoFlg", kyuJushoFlg);
        // 使用不可区分
        mst032Form.getResultJusho().put("shiyoFukaFlg", shiyoFukaFlg);
        // 旧住所コメント
        mst032Form.getResultJusho().put("kyjshDtlKyuJushoComment",
                mst032Form.getKyjshDtlKyuJushoComment());
        // 新JISコード
        if (mst032Form.getKyjshDtlShinJisCd() != null) {
            mst032Form.getResultJusho().put("kyjshDtlShinJisCd",
                    mst032Form.getKyjshDtlShinJisCd().getValue());
        } else {
            mst032Form.getResultJusho().put("kyjshDtlShinJisCd", "");
        }
        // 更新日時
        mst032Form.getResultJusho().put("kshnDtlkoshinNichiji",
                mst032Form.getKshnDtlkoshinNichiji());
        // 更新者
        mst032Form.getResultJusho().put("kshnDtlUser",
                mst032Form.getKshnDtlUser());
    }

    /**
     * 住所JISマスタ変更判定
     *
     * @return 新規更新の判定結果
     */
    private String jushoJisHenkoHantei() {

        // 住所JISマスタの更新カントーより、新規更新処理判定
        Object jisJushoCounter = mst032Form.getResultJusho().get("kshnDtlJisJushoCounter");
        if (jisJushoCounter == null || "".equals(jisJushoCounter.toString())) {
            // 新規の場合
            return "0";
        }

        // 適用名
        if (!(mst032Form.getConTekiyoMeiTaihi() == null || "".equals(mst032Form.getConTekiyoMeiTaihi().trim()))) {
            return "1";
        }

        // 漢字住所（市区町村）
        if (!mst032Form.getJshDtlKanjiJushoShikuchosonMei().equals(
                mst032Form.getResultJusho().get("jshDtlKanjiJushoShikuchosonMei").toString())) {
            return "1";
        }
        // カナ住所（市区町村）
        if (!mst032Form.getJshDtlKanaJushoShikuchosonMei().equals(
                mst032Form.getResultJusho().get("jshDtlKanaJushoShikuchosonMei").toString())) {
            return "1";
        }
        // 英語住所（都道府県）
        if (!mst032Form.getJshDtlEigoJushoTodofukenMei().equals(
                mst032Form.getResultJusho().get("jshDtlEigoJushoTodofukenMei").toString())) {
            return "1";
        }
        // 英語住所（市区町村）
        if (!mst032Form.getJshDtlEigoJushoShikuchosonMei().equals(
                mst032Form.getResultJusho().get("jshDtlEigoJushoShikuchosonMei").toString())) {
            return "1";
        }
        // 離島有無
        String umuFlg1 = "0";
        if (mst032Form.getJshDtlRitoUmuFlg().length > 0) {
            umuFlg1 = mst032Form.getJshDtlRitoUmuFlg()[0];
        }
        String umuFlg2 = mst032Form.getResultJusho().get("jshDtlRitoUmuFlg").toString().replace("0", "");
        if (!umuFlg1.equals(umuFlg2)) {
            return "1";
        }
        // HTコメント(100バイト)
        if (!mst032Form.getJshDtlHtComment1().equals(
                mst032Form.getResultJusho().get("jshDtlHtComment1").toString())) {
            return "1";
        }
        // HTコメント(200バイト)
        if (!mst032Form.getJshDtlHtComment2().equals(
                mst032Form.getResultJusho().get("jshDtlHtComment2").toString())) {
            return "1";
        }
        // 旧住所区分
        String kbn1 = StringUtils.join(mst032Form.getKyjshDtlKyuJushoKubun());
        String kbn2 = (mst032Form.getResultJusho().get("kyuJushoFlg").toString()
                + mst032Form.getResultJusho().get("shiyoFukaFlg").toString()).replace("0", "");
        if (!kbn1.equals(kbn2)) {
            return "1";
        }
        // 新JISコード
        if (!mst032Form.getKyjshDtlShinJisCd().getValue().equals(
                mst032Form.getResultJusho().get("kyjshDtlShinJisCd").toString())) {
            return "1";
        }
        return "";
    }

    /**
     * 入力内容チェック処理
     *
     * @return 処理結果
     */
    private int inputChcek() {

        int result = -1;
        // 適用名最大桁数チェック
        if (!maxSizeCheck(mst032Form.getConTekiyoMeiTaihi(), 40)) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0002, "適用名", "40");
            return result;
        }
        // 詳細の入力チェック処理	
        // 漢字住所（都道府県）
        if ("".equals(mst032Form.getJshDtlKanjiJushoTodofukenMei().trim())) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "漢字住所（都道府県）");
            return result;
        } else {
            if (!maxSizeCheck(mst032Form.getJshDtlKanjiJushoTodofukenMei(), 40)) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0002, "漢字住所（都道府県）", "40");
                return result;
            }
        }
        // 漢字住所（市区町村）   
        if ("".equals(mst032Form.getJshDtlKanjiJushoShikuchosonMei().trim())) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "漢字住所（市区町村）");
            return result;

        } else {
            if (!maxSizeCheck(mst032Form.getJshDtlKanjiJushoShikuchosonMei(), 40)) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0002, "漢字住所（市区町村）", "40");
                return result;

            }
        }

        // カナ住所（都道府県）  
        if ("".equals(mst032Form.getJshDtlKanaJushoTodofukenMei().trim())) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "カナ住所（都道府県）");
            return result;

        } else {
            if (!maxSizeCheck(mst032Form.getJshDtlKanaJushoTodofukenMei(), 40)) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0002, "カナ住所（都道府県）", "40");
                return result;
            }
        }

        // カナ住所（市区町村）
        if ("".equals(mst032Form.getJshDtlKanaJushoShikuchosonMei().trim())) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "カナ住所（市区町村）");
            return result;
        }

        // 英語住所（都道府県）
        if ("".equals(mst032Form.getJshDtlEigoJushoTodofukenMei().trim())) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "英語住所（都道府県）");
            return result;
        } else {
            if (!maxSizeCheck(mst032Form.getJshDtlEigoJushoTodofukenMei(), 40)) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0002, "英語住所（都道府県）", "40");
                return result;
            }
        }

        // 英語住所（市区町村）
        if ("".equals(mst032Form.getJshDtlEigoJushoShikuchosonMei().trim())) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "英語住所（市区町村）");
            return result;
        } else {
            if (!maxSizeCheck(mst032Form.getJshDtlEigoJushoShikuchosonMei(), 40)) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0002, "英語住所（市区町村）", "40");
                return result;
            }
        }

        // HTコメント(100バイト)
        if (!maxSizeCheck(mst032Form.getJshDtlHtComment1(), 100)) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0002, "HTコメント(100バイト)", "100");
            return result;
        }

        // HTコメント(200バイト)
        if (!maxSizeCheck(mst032Form.getJshDtlHtComment2(), 200)) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0002, "HTコメント(200バイト)", "200");
            return result;
        }

        // 旧住所コメント
        if (!maxSizeCheck(mst032Form.getKyjshDtlKyuJushoComment(), 40)) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0002, "旧住所コメント", "40");
            return result;
        }

        // 住所詳細一覧の入力チェック処理	
        for (Map<String, Object> rec : mst032Form.getListJushoSelectedResult()) {
            // 仕向地コード(下2桁)
            if ("".equals(rec.get("jshDtlListShimukeChiCd").toString().trim())) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "仕向地コード(下2桁)");
                return result;
            } else {
                if ("99".equals(rec.get("jshDtlListShimukeChiCd").toString().trim())) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MSTE0110, "仕向地コード(下2桁)");
                    return result;
                }
                // 仕向地コード(下2桁)
                if (!maxSizeCheck(rec.get("jshDtlListShimukeChiCd").toString(), 2)) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0002, "仕向地コード(下2桁)", "2");
                    return result;
                }
            }
            // 町字
            if ("".equals(rec.get("jshDtlListChoaza").toString().trim())) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "町字");
                return result;
            } else {
                // 町字
                if (!maxSizeCheck(rec.get("jshDtlListChoaza").toString(), 40)) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0002, "町字", "40");
                    return result;
                }
            }
            // 町字カナ
            if ("".equals(rec.get("jshDtlListChoazaKana").toString().trim())) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "町字カナ");
                return result;
            } else {
                // 町字
                if (!maxSizeCheck(rec.get("jshDtlListChoazaKana").toString(), 40)) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0002, "町字カナ", "40");
                    return result;
                }
            }
            // 仕向地名
            if (rec.get("jshDtlListShimukeChiMeiCd") == null
                    || "".equals(rec.get("jshDtlListShimukeChiMeiCd").toString().trim())) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "仕向地名");
                return result;
            }
            // 空港コード
            if (rec.get("jshDtlListKukoCd") == null || "".equals(rec.get("jshDtlListKukoCd").toString().trim())) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "空港コード");
                return result;
            }
            // 集配地区コード
            if (rec.get("jshDtlListShuhaiChikuCd") == null
                    || "".equals(rec.get("jshDtlListShuhaiChikuCd").toString().trim())) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "集配地区コード");
                return result;
            }
            // 管轄営業所コード
            if (rec.get("jshDtlListEigyoshoCd") == null
                    || "".equals(rec.get("jshDtlListEigyoshoCd").toString().trim())) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "管轄営業所コード");
                return result;
            }
        }

        // 仕向地コード重複チェック
        List<String> shimukeChiCdList = new ArrayList<>();
        Iterator<Map<String, Object>> ite = mst032Form.getListJushoSelectedResult().iterator();

        while (ite.hasNext()) {
            Map<String, Object> i = ite.next();
            shimukeChiCdList.add(i.get("jshDtlListShimukeChiCd").toString());
        }
        ite = mst032Form.getListJushoSelectedResult().iterator();

        while (ite.hasNext()) {
            Map<String, Object> i = ite.next();
            List<String> filterList = shimukeChiCdList.stream()
                    .filter((String sub) -> i.get("jshDtlListShimukeChiCd").toString().equals(sub))
                    .collect(Collectors.toList());
            if (filterList.size() > 1) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MSTE0036);
                return result;
            }
        }

        // 住所離島一覧の入力チェック処理	
        for (Map<String, Object> rec : mst032Form.getListRitoSelectedResult()) {
            // 島名
            if (!maxSizeCheck(rec.get("rtDtlListShimaMei").toString(), 40)) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0002, "離島情報島名", "40");
                return result;
            }
            // 住所
            if (!maxSizeCheck(rec.get("rtDtlListJusho").toString(), 40)) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0002, "離島情報住所", "40");
                return result;
            }
            // 備考
            if (!maxSizeCheck(rec.get("rtDtlListBiko").toString(), 40)) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0002, "離島情報備考", "40");
                return result;
            }
        }

        // 館内配送一覧の入力チェック処理	
        for (Map<String, Object> rec : mst032Form.getListKannaiSelectedResult()) {
            // 施設名
            if (!maxSizeCheck(rec.get("khDtlListShisetsuMei").toString(), 40)) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0002, "館内配送情報施設名", "40");
                return result;
            }
            // 住所
            if (!maxSizeCheck(rec.get("khDtlListJusho").toString(), 40)) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0002, "館内配送情報住所", "40");
                return result;
            }
            // 備考
            if (!maxSizeCheck(rec.get("khDtlListBiko").toString(), 40)) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0002, "館内配送情報備考", "40");
                return result;
            }
        }

        return 1;
    }

    /**
     * 関連チェック
     *
     * @param updFlg チェック対象フラグ
     * @return チェック処理結果
     */
    private int kanrenChcek(String updFlg) {
        // 重複、存在チェック
        Map<String, Object> params = new HashMap<>();
        params.put("updFlg", updFlg);
        // JISコード
        params.put("conJisCd", mst032Form.getConJisCdTaihi());
        // 適用開始日
        params.put("conTekiyoKaishibi", mst032Form.getConTekiyoKaishibiTaihi());
        // チェック対象リスト
        params.put("jushoList", mst032Form.getListJushoSelectedResult());
        // DBをアクセス
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, FUNC_CODE_INSERT_UPDATE_CHECK);
        // エラーの場合、処理を終了
        if (serviceInterfaceBean != null && serviceInterfaceBean.getStatusCode()
                == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            String[] tableNames = serviceInterfaceBean.getTableName().split(",");
            messagePropertyBean.message(serviceInterfaceBean.getMessages().get(0)[0],
                    serviceInterfaceBean.getMessages().get(0)[1],
                    serviceInterfaceBean.getMessages().get(0)[2],
                    tableNames[0]);
            return serviceInterfaceBean.getStatusCode();
        }
        return ServiceInterfaceBean.PROCESS_STATUS_SUCCESS;
    }

    /**
     * 変換情報取得する
     *
     * @param params 検索用パラメータ
     * @return 変換情報の検索結果
     */
    private List<Map<String, Object>> getHenkanJohoList(Map<String, Object> params) {
        // DBをアクセス        
        ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, SEARCH_FUNC_CODE);
        try {
            ObjectMapper mapper = new ObjectMapper();
            List<Map<String, Object>> searchResult = mapper.readValue(res.getJson(), List.class
            );
            return searchResult;
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
    }

    /**
     * 変換件数設定
     *
     * @param kensu 変更情報データの件数
     */
    public void henkanKensuSet(int kensu) {
        List<Map<String, Object>> jushoList = mst032Form.getListJushoSelectable().getDatasource();
        Iterator<Map<String, Object>> ite = jushoList.iterator();
        while (ite.hasNext()) {
            Map<String, Object> i = ite.next();
            if (mst032Form.getHenkanJoho().get("key").equals(i.get("UNIQUE_KEY"))) {
                i.put("jshDtlListHenkanKensu", kensu);
            }
        }
    }

    /**
     * 施設表示名情報取得する
     *
     * @param params 検索用パラメータ
     * @return 施設表示名情報の検索結果
     */
    private List<Map<String, Object>> getShisetsuJohoList(Map<String, Object> params) {
        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, SEARCH_FUNC_CODE);
        try {
            ObjectMapper mapper = new ObjectMapper();
            List<Map<String, Object>> searchResult = mapper.readValue(res.getJson(), List.class
            );
            return searchResult;
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
    }

    /**
     * 表記情報件数設定
     *
     * @param kensu 表記情報件数
     */
    public void hyokiJohoKensuSet(int kensu) {
        List<Map<String, Object>> kannaiList = mst032Form.getListKannaiSelectable().getDatasource();
        Iterator<Map<String, Object>> ite = kannaiList.iterator();
        while (ite.hasNext()) {
            Map<String, Object> i = ite.next();
            if (mst032Form.getShisetsuJoho().get("key").equals(i.get("UNIQUE_KEY"))) {
                i.put("khDtlListHyokiJohoKensu", kensu);
            }
        }
    }

    /**
     * 行追加（住所情報詳細、離島情報、館内配送情報用）
     *
     * @param id 画面リストID
     * @param toLast listの下に追加するフラグ
     */
    public void addRow(String id, Boolean toLast) {

        // 対象リスト取得
        List<Map<String, Object>> selectList = pageCommonBean.getDatasLists().get(id);
        if (selectList.isEmpty()) {
            toLast = true;
        }
        int indexRow;
        // 追加された行取得
        if (toLast) {
            indexRow = selectList.size();
        } else {
            indexRow = selectList.indexOf(pageCommonBean.getFoucesDataList().get(id));
        }
        pageCommonBean.addRow(id, toLast);

        // 固定データ設定
        // 漢字住所（都道府県）+ 漢字住所（市区町村）
        String jisJusho = mst032Form.getJshDtlKanjiJushoTodofukenMei() + mst032Form.getJshDtlKanjiJushoShikuchosonMei();
        if (DATA_JUSHOTABLE_ID.equals(id)) {
            // 住所情報詳細
            // 仕向地コード(JIS)
            selectList.get(indexRow).put("jshDtlListJisCd", mst032Form.getConJisCdTaihi());
            // JIS住所
            selectList.get(indexRow).put("jshDtlListJisJusho", jisJusho);
        } else if (DATA_RITOTABLE_ID.equals(id)) {
            // 離島情報
            // JIS住所
            selectList.get(indexRow).put("rtDtlListJisJusho", jisJusho);
        } else if (DATA_KANNAITABLE_ID.equals(id)) {
            // 館内配送情報
            // JIS住所
            selectList.get(indexRow).put("khDtlListJisJusho", jisJusho);
        }
    }

    /**
     * ポップアップ画面行追加
     *
     * @param id 画面リストID
     * @param toLast listの下に追加するフラグ
     */
    public void addRowPop(String id, Boolean toLast) {
        // 変更フラグ設定
        if (id.equals(DATA_HENKANTABLE_ID)) {
            henkanFlg = "1";
        } else {
            shisetsuFlg = "1";
        }
        pageCommonBean.addRow(id, toLast);
    }

    /**
     * テーブルにデータをコピー
     *
     * @param id テーブルリストID
     */
    public void copyRows(String id) {

        // 対象リスト取得
        List<Map<String, Object>> selectList = pageCommonBean.getDatasLists().get(id);
        if (selectList.isEmpty()) {
            return;
        }
        int indexRow = selectList.indexOf(pageCommonBean.getFoucesDataList().get(id)) + 1;
        // 共通用データコピー
        pageCommonBean.copyRows(id, false);
        // 非表示項目設定
        if (DATA_JUSHOTABLE_ID.equals(id)) {
            // 住所情報詳細
            // ダミーJISフラグ
            selectList.get(indexRow).put("jshDtlListHDummyJisFlg", "");
            // 仕向地コード(下2桁)
            selectList.get(indexRow).put("jshDtlListHShimukeChiCd", "");
            // 変換件数
            selectList.get(indexRow).put("jshDtlListHenkanKensu", null);
        } else if (DATA_HENKANTABLE_ID.equals(id)) {
            // 変換情報
            // 変換情報シーケンス
            selectList.get(indexRow).put("hnknDtlListHHenkanJohoSeq", "");
            // 削除フラグ
            selectList.get(indexRow).put("hnknDtlListHSakujoFlg", "");
        } else if (DATA_RITOTABLE_ID.equals(id)) {
            // 離島情報
            // 住所離島シーケンス
            selectList.get(indexRow).put("rtDtlListHJushoRitoSeq", "");
        } else if (DATA_KANNAITABLE_ID.equals(id)) {
            // 館内配送情報
            // JISコード
            selectList.get(indexRow).put("khDtlListHJisCd", "");
            // 住所館内配送シーケンス
            selectList.get(indexRow).put("khDtlListHJushoKannaihaisoSeq", "");
            // 表記情報件数
            selectList.get(indexRow).put("khDtlListHyokiJohoKensu", null);
        } else if (DATA_SHISETSUTABLE_ID.equals(id)) {
            // 施設名表記情報           
            // 施設表示名シーケンス
            selectList.get(indexRow).put("shstDtlListHShisetsuHyojiMeiSeq", "");
            // 削除フラグ
            selectList.get(indexRow).put("shstDtlListHSakujoFlg", "");
        }
    }

    /**
     * 業務削除処理
     *
     * @param id 削除対象リストフラグ
     * @param datas 削除対象リスト
     * @return 処理結果
     */
    public Boolean delRows(String id, List<Map<String, Object>> datas) {
        // 削除実施
        int status = deleteList(id, datas);
        // エラーの場合、処理を終了
        if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            return false;
        }
        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0004,"削除");

        return true;
    }

    /**
     * DBから情報を削除する
     *
     * @param mstFlg 削除対象リストフラグ
     * @param datas 削除対象リスト
     * @return 処理結果
     */
    private int deleteList(String id, List<Map<String, Object>> datas) {
        //　更新マスタ対象設定
        String mstFlg = "";
        if (id.equals(DATA_JUSHOTABLE_ID)) {
            mstFlg = CONST_JUSHO;
        } else if (id.equals(DATA_RITOTABLE_ID)) {
            mstFlg = CONST_RITO;
        } else if (id.equals(DATA_KANNAITABLE_ID)) {
            mstFlg = CONST_KANNAI;
        } else if (id.equals(DATA_HENKANTABLE_ID)) {
            mstFlg = CONST_HENKAN;
        } else if (id.equals(DATA_SHISETSUTABLE_ID)) {
            mstFlg = CONST_SHISETSU;
        }
        // 
        String mstFlgOld = mstFlg;
        // パラメータ
        Map<String, Object> params = new HashMap<>();
        // 変換情報の場合、マスタフラグを再設定
        if (CONST_HENKAN.equals(mstFlg)) {
            if ("00".equals(mst032Form.getHenkanJoho().get("jshDtlListHShimukeChiCd"))) {
                // JISの場合
                mstFlg = "jis";
            } else {
                // 仕向地の場合  
                mstFlg = "shimuke";
            }
            params = mst032Form.getHenkanJoho();
        } else if (CONST_SHISETSU.equals(mstFlg)) {
            // 施設表示名情報
            params = mst032Form.getShisetsuJoho();
        }
        // 検索マスタフラグ
        params.put("mstFlg", mstFlg);
        // JISコード
        params.put("conJisCd", mst032Form.getConJisCdTaihi());
        // 適用開始日
        params.put("conTekiyoKaishibi", mst032Form.getConTekiyoKaishibiTaihi());
        // 更新ユーザー
        params.put("userCd", authConfBean.getUserCd());
        // 削除リストパラメータを設定
        params.put("dataList", datas);
        // DBをアクセス
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, DELETE_FUNC_CODE);
        if (serviceInterfaceBean != null && serviceInterfaceBean.getStatusCode()
                == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            String[] tableNames = serviceInterfaceBean.getTableName().split(",");
            messagePropertyBean.message(serviceInterfaceBean.getMessages().get(0)[0],
                    serviceInterfaceBean.getMessages().get(0)[1],
                    serviceInterfaceBean.getMessages().get(0)[2],
                    tableNames[0]);
            return serviceInterfaceBean.getStatusCode();
        }
        // 画面レコード削除
        pageCommonBean.getDatasLists().get(id).removeAll(datas);
        // 変換情報と施設表示名情報を再退避
        List<Map<String, Object>> dataTaihi;
        if (CONST_HENKAN.equals(mstFlgOld)) {
            dataTaihi = listTaihi(pageCommonBean.getDatasLists().get(id));
            String key = params.get("hnknDtlShimukeChiCd").toString();
            henkanJohoListMap.put(key, dataTaihi);
            mst032Form.setListHenkanSelectedResult(null);
            henkanFlg = "0";
            // 変換情報件数設定
            henkanKensuSet(dataTaihi.size());
        } else if (CONST_SHISETSU.equals(mstFlgOld)) {
            dataTaihi = listTaihi(pageCommonBean.getDatasLists().get(id));
            // リストMapのキーを設定
            String key = params.get("khDtlListHJushoKannaihaisoSeq").toString();
            shisetsuJohoListMap.put(key, dataTaihi);
            mst032Form.setListShisetsuSelectedResult(null);
            shisetsuFlg = "0";
            // 表記情報件数設定
            hyokiJohoKensuSet(dataTaihi.size());
        }
        // ステータスコードを返却する
        return serviceInterfaceBean.getStatusCode();

    }

    /**
     * 画面リスト退避
     *
     * @param res 処理対象リスト
     * @return 処理結果リスト
     */
    private List<Map<String, Object>> listTaihi(List<Map<String, Object>> res) {
        List<Map<String, Object>> result = new ArrayList<>();
        int i = 0;
        for (Map<String, Object> data : res) {
            Map<String, Object> primaryKey = new HashMap<>();
            // データキー設定 
            Set setKey = res.get(i).entrySet();
            Iterator iteratorKey = setKey.iterator();
            while (iteratorKey.hasNext()) {
                Map.Entry mapentry = (Map.Entry) iteratorKey.next();
                primaryKey.put(mapentry.getKey().toString(), data.get(mapentry.getKey().toString()));
            }
            i++;
            result.add(primaryKey);
        }
        return result;
    }

    /**
     * POP情報変更フラグ設定
     *
     * @param flg 0:変換情報 1:施設表示名情報
     * @param status 変更状態
     * @param rowIndex 選択された行
     */
    public void setHenkoFlg(String flg, String status, int rowIndex) {
        if ("0".equals(flg)) {
            // 変換情報
            henkanFlg = status;
            // 修正フラグ設定
            mst032Form.getListHenkanSelectable().getDatasource().get(rowIndex).put("setFlg", "UPD");
        } else {
            // 施設表示名情報
            shisetsuFlg = status;
            // 修正フラグ設定
            mst032Form.getListShisetsuSelectable().getDatasource().get(rowIndex).put("setFlg", "UPD");
        }
    }

    /**
     * AUTOCOMPLETE項目再設定
     *
     * @param resList 設定対象リスト
     */
    public void AutocompleteSet(List<Map<String, Object>> resList) {
        if (resList.size() > 0) {
            for (Map<String, Object> record : resList) {
                // 仕向地名コード
                String shimukeChiMeiCd = record.get("jshDtlListShimukeChiMeiCd").toString();
                record.put("jshDtlListShimukeChiMeiCdAut",
                        autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_SHIMUKE_CHI_MEI, shimukeChiMeiCd));
                // 空港コード
                String kukoCd = record.get("jshDtlListKukoCd").toString();
                record.put("jshDtlListKukoCdAut",
                        autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_MS_KUKO, kukoCd));
                // 管轄営業所コード
                String eigyoshoCd = record.get("jshDtlListEigyoshoCd").toString();
                record.put("jshDtlListEigyoshoCdAut",
                        autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO, eigyoshoCd));
            }
        }
    }

    /**
     * AUTOCOMPLETE選択時コードと名称の設定処理
     *
     * @param row 明細行番号
     * @param option 選択されたAUTOCOMPLETEデータ
     * @param colCodeName 設定先コード
     * @param colNameName 設定先名称
     */
    public void setListCodeName(int row, AutoCompOptionBean option, String colCodeName, String colNameName) {

        if (option == null) {
            mst032Form.getListJushoSelectable().getDatasource().get(row).put(colCodeName, "");
            mst032Form.getListJushoSelectable().getDatasource().get(row).put(colNameName, "");
        } else {
            mst032Form.getListJushoSelectable().getDatasource().get(row).put(colCodeName, option.getValue());
            mst032Form.getListJushoSelectable().getDatasource().get(row).put(colNameName, option.getLabel());
        }
    }

    /**
     * 適用名退避
     *
     */
    public void tekiyoMeiSet() {
        if (mst032Form.getConTekiyoMei() != null) {
            mst032Form.setConTekiyoMeiTaihi(mst032Form.getConTekiyoMei());
        }

    }

    /**
     * 適用終了退避
     *
     */
    public void tekiyoShuryoSet() {
        if (mst032Form.getConTekiyoShuryo() != null) {
            String[] tekiyoShuryoKbn = (String[]) mst032Form.getConTekiyoShuryo();
            if (tekiyoShuryoKbn.length > 0) {
                mst032Form.setConTekiyoShuryoTaihi("1");
            } else {
                mst032Form.setConTekiyoShuryoTaihi("0");
            }
        }
    }

    /**
     * 最大桁数チェック
     *
     * @param value チェック対象
     * @param maxLength 最大入力桁数
     * @return チェック結果
     */
    private boolean maxSizeCheck(String value, int maxLength) {

        try {
            return !(value != null && value.getBytes("UTF-8").length > maxLength);
        } catch (UnsupportedEncodingException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return true;
        }
    }

}
