/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.inv;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteBean;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 送り状発行荷受人選択
 *
 * @author xupenggeyang
 */
@ManagedBean(name = "inv022")
@ViewScoped
@Data
public class Inv022Bean extends BaseBean {

    //TITLE
    String TITLE = "送り状発行荷受人選択";

    private String url;

    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;
    
    @ManagedProperty(value = "#{autoComplete}")
    private AutoCompleteBean autoCompleteBean;

    private RestfullService rest;

    private static final Logger logger = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    private String kokyakuCd = "77884";

    private String kokyakuNm = "name";

    private AutoCompOptionBean receiverCd;

    private String receiverKana = "テスト";

    private String receiverName = "test";

    private String receiverPlace = "Osaka";

    private String phoneNum = "7777-777-777";
    
    private String receiverShortName = "tes";
    
    private String searchKey = "tes";

    private Boolean sakujoFlg = false;

    private int count = 0;
    
    private static final String COM_GET_VW_KOKYAKU = "COM_GET_VW_KOKYAKU";

    public Inv022Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId
     * @param prevScreen
     * @param backFlag
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            //AutoComplete初期化
            Map params = new HashMap();
            
            autoCompleteBean.initAutoComplete(COM_GET_VW_KOKYAKU, params);
            
            
            // パンくず追加
            breadBean.push("送り状発行荷受人選択", Cnst.SCREEN.INV022_SCREEN.name(), this);
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }
    }

    @Override
    public String menuClick(String menuId, String nextScreen) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String logoutClick() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public void search(){
        
    }
    
    
//    /************模擬データ*************/
//    private List<Car> cars;
//
//    private Car selectedCar;
//
//    @ManagedProperty("#{carService}")
//    private CarService service;
//
//    @PostConstruct
//    public void init() {
//        cars = service.createCars(10);
//    }
//
//    public List<Car> getCars() {
//        return cars;
//    }
//
//    public Car getSelectedCar() {
//        return selectedCar;
//    }
//
//    public void setSelectedCar(Car selectedCar) {
//        this.selectedCar = selectedCar;
//    }
//
//    public void setService(CarService service) {
//        this.service = service;
//    }
//
//    public void deleteCar() {
//        cars.remove(selectedCar);
//        selectedCar = null;
//    }
}
