/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mwb;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.annotation.DateCheck;
import jp.co.kintetsuls.beans.common.annotation.HalfNumber;
import jp.co.kintetsuls.beans.common.annotation.MaxSizeCheck;
import jp.co.kintetsuls.beans.common.annotation.NotNull;
import lombok.Data;

/**
 * MAWB一覧 編集用リストの内容
 *
 * @author 尹明龍(MBP)
 * @version 2019/2/12 新規作成
 */
@Data
public class Mwb011MawbBangoBean implements Serializable {

    /**
     * 定数：発券営業所コード
     */
    private static final String CONST_HAKKEN_EIGYOSHO_CD = "HAKKEN_EIGYOSHO_CD";
    /**
     * 定数：発券営業所名
     */
    private static final String CONST_HAKKEN_EIGYOSHO_MEI = "HAKKEN_EIGYOSHO_MEI";
    /**
     * 定数：航空会社コード
     */
    private static final String CONST_KOKU_GAISHA_CD = "KOKU_GAISHA_CD";
    /**
     * 定数：MAWB登録ID
     */
    private static final String CONST_MAWB_TOROKU_ID = "MAWB_TOROKU_ID";
    /**
     * 定数：配布先営業所コード
     */
    private static final String CONST_HAIFUSAKI_EIGYOSHO_CD = "HAIFUSAKI_EIGYOSHO_CD";
    /**
     * 定数：配布先営業所名
     */
    private static final String CONST_HAIFUSAKI_EIGYOSHO_MEI = "HAIFUSAKI_EIGYOSHO_MEI";
    /**
     * 定数：MAWB配布ID
     */
    private static final String CONST_MAWB_HAIFU_ID = "MAWB_HAIFU_ID";
    /**
     * 定数：MAWB番号
     */
    private static final String CONST_TOROKU_MAWB_BANGO = "TOROKU_MAWB_BANGO";
    /**
     * 定数：受入日付
     */
    private static final String CONST_UKEIRE_HIZUKE = "UKEIRE_HIZUKE";
    /**
     * 定数：受入枚数
     */
    private static final String CONST_UKEIRE_MAISU = "UKEIRE_MAISU";
    /**
     * 定数：受入日付
     */
    private static final String CONST_HAIFU_HIZUKE = "HAIFU_HIZUKE";
    /**
     * 定数：配布MAWB番号
     */
    private static final String CONST_HAIFU_MAWB_BANGO = "HAIFU_MAWB_BANGO";
    /**
     * 定数：配布枚数
     */
    private static final String CONST_HAIFU_MAISU = "HAIFU_MAISU";
    /**
     * 定数：使用枚数
     */
    private static final String CONST_SHIYO_MAISU = "SHIYO_MAISU";
    /**
     * 定数：VOID枚数
     */
    private static final String CONST_VOID_MAISU = "VOID_MAISU";

    /**
     * 定数：開始MAWB番号
     */
    private static final String CONST_KAISHI_MAWB_BANGO = "KAISHI_MAWB_BANGO";
    /**
     * 定数：終了MAWB番号
     */
    private static final String CONST_SHURYO_MAWB_BANGO = "SHURYO_MAWB_BANGO";
    /**
     * 定数：開始MAWB配布番号
     */
    private static final String CONST_KAISHI_MAWB_HAIFU_BANGO = "KAISHI_MAWB_HAIFU_BANGO";
    /**
     * 定数：終了MAWB配布番号
     */
    private static final String CONST_SHURYO_MAWB_HAIFU_BANGO = "SHURYO_MAWB_HAIFU_BANGO";
    /**
     * 航空会社コード
     */
    private String kokuGaishaCd;

    /**
     * 発券営業所コード
     */
    private String hakkenEigyoshoCd;

    /**
     * 発券営業所名
     */
    private String hakkenEigyoshoMei;

    /**
     * MAWB登録ID
     */
    private Integer mawbTorokuId;

    /**
     * 配布先営業所コード
     */
    private String haifusakiEigyoshoCd;
    /**
     * 配布先営業所
     */
    private String haifusakiEigyoshoMei;

    /**
     * MAWB配布ID
     */
    private Integer mawbHaifuId;

    /**
     * 発券営業所・航空会社・登録MAWB番号
     */
    private String dispMawbBango;
    /**
     * 登録MAWB番号
     */
    private String torokuMawbBango;
    /**
     * 受入日付
     */
    private Date ukeireHizuke;
    /**
     * 受入日付
     */
    private String strUkeireHizuke;
    /**
     * 受入枚数
     */
    private Integer ukeireMaisu;
    /**
     * 配布日付
     */
    private Date haifuHizuke;
    /**
     * 配布日付
     */
    private String strHaifuHizuke;
    /**
     * 配布MAWB番号
     */
    private String haifuMawbBango;

    /**
     * 配布枚数
     */
    private Integer haifuMaisu;

    /**
     * 使用枚数
     */
    private Integer shiyoMaisu;

    /**
     * VOID枚数
     */
    private Integer voidMaisu;

    /**
     * 未使用枚数
     */
    private Integer mishiyoMaisu;

    /**
     * 登録MAWB番号From
     */
    private String torokuMawbBangoFrom;

    /**
     * 登録MAWB番号To
     */
    private String torokuMawbBangoTo;

    /**
     * 再設定受入日付
     */
    @NotNull(name = "受入日付")
    @DateCheck(name = "受入日付")
    private String saiUkeireHizuke;
    /**
     * 再設定登録MAWB番号From
     */
    @MaxSizeCheck(name = "登録MAWB番号", maxSize = 8)
    @HalfNumber(name = "登録MAWB番号")
    private String saiTorokuMawbBangoFrom;

    /**
     * 再設定登録MAWB番号To
     */
    @MaxSizeCheck(name = "登録MAWB番号", maxSize = 8)
    @HalfNumber(name = "登録MAWB番号")
    private String saiTorokuMawbBangoTo;
    /**
     * 再設定受入枚数
     */
    private Integer saiUkeireMaisu;
    /**
     * 配布MAWB番号From
     */
    @MaxSizeCheck(name = "MAWB番号", maxSize = 8)
    @HalfNumber(name = "MAWB番号")
    private String haifuMawbBangoFrom;

    /**
     * 配布MAWB番号To
     */
    @MaxSizeCheck(name = "MAWB番号", maxSize = 8)
    @HalfNumber(name = "MAWB番号")
    private String haifuMawbBangoTo;

    /**
     * 再配布日付
     */    
    @DateCheck(name = "配布日付")
    private String saiHaifuHizuke;
    
    /**
     * 再配布先営業所
     */
    private AutoCompOptionBean saiHaifusakiEigyosho;
    /**
     * 再配布形式
     */
    private int saiHaifuType;
    /**
     * 再配布MAWB番号From
     */
    @MaxSizeCheck(name = "再配布MAWB番号", maxSize = 8)
    @HalfNumber(name = "再配布MAWB番号")
    private String saiHaifuMawbBangoFrom;
    /**
     * 再配布MAWB番号To
     */
    @MaxSizeCheck(name = "再配布MAWB番号", maxSize = 8)
    @HalfNumber(name = "再配布MAWB番号")
    private String saiHaifuMawbBangoTo;
    /**
     * 再配布枚数
     */
    private int saiHaifuMeisu;
    /**
     * 再配布MAWB番号
     */
    private List<String> selectedMawbBangoList;

    /**
     * 0:root 1:発券営業所 2:航空会社 3:登録MAWB番号 4:配布MAWB番号
     */
    private int level;
    /**
     * 子ノード
     */
    private List<Mwb011MawbBangoBean> childNodes;
    /**
     * 配布MAWB番号の開始から終了までの値
     */
    private List<String> selectMawbBangoList;

    public Mwb011MawbBangoBean(int level) {
        this.level = level;
        this.childNodes = new ArrayList<>();
    }

    public Mwb011MawbBangoBean(int level, Map<String, Object> dataMapper) {
        this.level = level;
        // 発券営業所コード
        this.hakkenEigyoshoCd = getStringValue(dataMapper.get(CONST_HAKKEN_EIGYOSHO_CD));
        // 発券営業所名
        this.hakkenEigyoshoMei = getStringValue(dataMapper.get(CONST_HAKKEN_EIGYOSHO_MEI));
        // 航空会社コード
        this.kokuGaishaCd = getStringValue(dataMapper.get(CONST_KOKU_GAISHA_CD));
        // MAWB登録ID
        this.mawbTorokuId = getIntValue(dataMapper.get(CONST_MAWB_TOROKU_ID));
        // 配布先営業所コード
        this.haifusakiEigyoshoCd = getStringValue(dataMapper.get(CONST_HAIFUSAKI_EIGYOSHO_CD));
        // 配布先営業所名
        this.haifusakiEigyoshoMei = getStringValue(dataMapper.get(CONST_HAIFUSAKI_EIGYOSHO_MEI));
        // MAWB配布ID
        this.mawbHaifuId = getIntValue(dataMapper.get(CONST_MAWB_HAIFU_ID));
        // MAWB番号
        this.torokuMawbBango = getStringValue(dataMapper.get(CONST_TOROKU_MAWB_BANGO));
        // 受入日付
        this.ukeireHizuke = getDateValue(dataMapper.get(CONST_UKEIRE_HIZUKE));
        this.strUkeireHizuke = getDateStringValue(this.ukeireHizuke);
        // 受入枚数
        this.ukeireMaisu = getIntValue(dataMapper.get(CONST_UKEIRE_MAISU));
        // 配布日付
        this.haifuHizuke = getDateValue(dataMapper.get(CONST_HAIFU_HIZUKE));
        this.strHaifuHizuke = getDateStringValue(this.haifuHizuke);
        // 配布MAWB番号
        this.haifuMawbBango = getStringValue(dataMapper.get(CONST_HAIFU_MAWB_BANGO));
        // 配布枚数
        this.haifuMaisu = getIntValue(dataMapper.get(CONST_HAIFU_MAISU));
        // 使用枚数
        this.shiyoMaisu = getIntValue(dataMapper.get(CONST_SHIYO_MAISU));
        // VOID枚数
        this.voidMaisu = getIntValue(dataMapper.get(CONST_VOID_MAISU));
        // 開始MAWB番号
        this.torokuMawbBangoFrom = getStringValue(dataMapper.get(CONST_KAISHI_MAWB_BANGO));
        // 終了MAWB番号
        this.torokuMawbBangoTo = getStringValue(dataMapper.get(CONST_SHURYO_MAWB_BANGO));
        // 再配布MAWB番号From
        this.haifuMawbBangoFrom = getStringValue(dataMapper.get(CONST_KAISHI_MAWB_HAIFU_BANGO));
        // 再配布MAWB番号To
        this.haifuMawbBangoTo = getStringValue(dataMapper.get(CONST_SHURYO_MAWB_HAIFU_BANGO));
    }

    private String getStringValue(Object obj) {
        if (obj == null) {
            return "";
        } else {
            return String.valueOf(obj);
        }
    }

    private int getIntValue(Object obj) {
        if (obj == null) {
            return 0;
        } else {
            return (int) obj;
        }
    }

    public String getDateStringValue(Object obj) {
        if (obj == null || "".equals(obj.toString())) {
            return "";
        }

        DateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
        return formatter.format(obj);
    }

    private Date getDateValue(Object obj) {
        if (obj == null || "".equals(obj.toString())) {
            return null;
        }
        if (obj instanceof Long) {
            return new Date((Long) obj);
        }

        return (Date) obj;
    }
}
