/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.stc;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import lombok.Data;

/**
 * 仕向地名マスタフォーム
 *
 * @author MaLei (MBP)
 * @version 2019/1/24 新規作成
 */
@ManagedBean(name = "stc031Form")
@ViewScoped
@Data
public class Stc031Form implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 都道府県Value
     */
    private AutoCompOptionBean conTodofuken;

    /**
     * 仕向地名
     */
    private String conShimukeChiMei;

    /**
     * 削除済のみ
     */
    private String[] conSakujoSumiNomi;

    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;

    /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;

    /**
     * 選択された結果
     */
    private List<Map<String, String>> selectedSearchResult;

}
