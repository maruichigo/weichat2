/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common.annotation.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.annotation.SizeCheck;

/**
 * 桁数チェック
 * 
 * @author zf(MBP)
 * @version 2019/3/11 新規作成
 */
public class SizeCheckValidator implements ConstraintValidator<SizeCheck, Object> {

    private int size;

    @Override
    public void initialize(SizeCheck constraintAnnotation) {
        this.size = constraintAnnotation.size();
    }

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext context) {
       if (value == null) {
            return true;
        }
        String valStr = null;
         if (value.getClass().getTypeName().equals("java.lang.String")) {
            valStr = value.toString();
        } else if (value.getClass().getTypeName().equals("jp.co.kintetsuls.beans.common.AutoCompOptionBean")) {
            valStr = ((AutoCompOptionBean)value).getValue();
        }
        return !(valStr != null && !"".equals(valStr) && valStr.getBytes().length != size);
    }
}
