/*
 * SvfDataModel.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common;

import java.io.InputStream;

/**
 * ファイルアップロードで使用する情報のModelクラスです。
 *
 * @author sharedSystem
 */
public class UpLoadFileDataModel {
    
    private String filePath;             // ファイルパス
    private InputStream fileStream;      // ファイルStream    

    /**
     * @return the filePath
     */
    public String getFilePath() {
        return filePath;
    }

    /**
     * @param filePath the filePath to set
     */
    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    /**
     * @return the fileStream
     */
    public InputStream getFileStream() {
        return fileStream;
    }

    /**
     * @param fileStream the fileStream to set
     */
    public void setFileStream(InputStream fileStream) {
        this.fileStream = fileStream;
    }

}
