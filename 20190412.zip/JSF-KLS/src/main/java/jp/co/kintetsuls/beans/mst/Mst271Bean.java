/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Level;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst271Form;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 代理店・中継配達料金表一覧 Bean
 *
 * @author 強 超 (MBP)
 * @version 2019/1/28 新規作成
 */
@ManagedBean(name = "mst271")
@ViewScoped
@Data
public class Mst271Bean extends AbstractBean {

    /**
     * タイトル
     */
    private final String strTitle = "代理店・中継配達料金表一覧";
    
    /**
     * タイトル
     */
    private final String titleName = "代理店・中継配達料金表詳細一覧";
    
    /**
     * 画面URL
     */
    private String url;     // URL

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messageProperty;
    
    /**
     * 画面共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;
    
    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     *
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;
    
    /**
     * 一覧単項目チェック共通
     */
    @ManagedProperty(value = "#{listCheckBean}")
    private ListCheckBean listCheckBean;
    
    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

     /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(
            new Object() {}.getClass().getEnclosingClass().getName());
    
     /**
     * 画面フォーム
     */
    @ManagedProperty(value = "#{mst271Form}")
    @Getter
    @Setter
    private Mst271Form mst271Form;

     /**
     * 検索シーケンス処理共通
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;
    
     /**
     * ファイルダウンロード
     */
    @ManagedProperty(value = "#{fileBean}")
    private FileBean fileBean;
    
     /**
     * 履歴一覧処理共通
     */
    @ManagedProperty(value = "#{rirekisyosai}")
    private RirekiSyosaiBean rirekiSyosai;   
    
    /**
     * ScreenCode：MST271.
     */
    private static final String SC_CD_MST271 = "MST271_SCREEN";
    
     /**
     * 定数：一覧のDataTableのID.
     */
    private static final String DATA_TABLE_ID = "tablesorter_mst271";
    
     /**
     * 定数：検索ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH = "mst271_search";
    
     /**
     * 定数：検索件数取得ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH_KENSU = "mst271_kensu";
    
    /**
     * 定数：画面項目保持key.
     */
    private static final String CONST_MST271_FORM = "mst271Form";
    
    /**
     * 定数：MasterInfo取得key.
     */
    private static final String CONST_MST271_MASTER = "mst271";
    /**
     * 定数：再検索Button取得キー
     */
    private static final String CONST_MST271_SEARCH = "search_mst271";
    
      /**
     * 履歴テーブル検索キー.
     */
    private Map<String, Object> rirekiSearchKey;
    
    /**
     * ワーク.メッセージリスト
     */
    List<MessageModuleBean> msgList = new ArrayList<>();
    private Object CheckUtils;
    
    /**
     * コンストラクタ
     */
    public Mst271Bean() {
        
    }
    
   private String[] checkedItems = {"1", "2"};

    /**
     * 初期処理（処理）
     *
     * @param menuId
     * @param prevScreen
     * @param backFlag
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            // パンくず追加
            breadBean.push(strTitle, SCREEN.MST271_SCREEN.name(), this);
            
            //業者区分
            mst271Form.setConGyoshaKbn("1");
            
            // マスタ内容取得
            pageCommonBean.getMasterInfo(CONST_MST271_MASTER);
            
            // 検索シーケンス処理ため初期化
            searchHelpBean.regSearchHelp(DATA_TABLE_ID,
                    s -> {return getRecordCount();},
                    s -> {search(); return null;},
                    null);
            searchHelpBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);
            
            //下記はDBからマスタを取得
            /*代理店取得*/
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_DAIRITEN);
            /*営業所取得*/
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_ALL_VW_EIGYOSHO);
            /*仕入先*/
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_SHIIRESAKI);
            /*会社名*/
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_KAISHA_MEI);
            /*支店営業所*/
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_SHITEN_MEI);
            /*伝票種別*/
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_MS_DEMPYO_SHUBETSU);
            
            // 前回の記録をクリアする
            this.clear();
            mst271Form.setSearchResult(null);
            mst271Form.setSearchResultSelectable(null);
            mst271Form.setSelectedSearchResult(null);
            
            // 戻ってきた場合
            Mst271Form preForm = (Mst271Form) pageCommonBean.getPageInfo(CONST_MST271_FORM);
            if (backFlag && preForm != null) {
                    PageCommonBean.simpleCopy(preForm, mst271Form);
                    // 再検索を実施する
                    pageCommonBean.searchAgain(CONST_MST271_SEARCH);
            } else {
                Flash flash = pageCommonBean.getPageParam();
                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_MST271_FORM) != null) {
                    PageCommonBean.simpleCopy(flash.get(CONST_MST271_FORM), mst271Form);
                    // 再検索を実施する
                    pageCommonBean.searchAgain(CONST_MST271_SEARCH);
                }
            }
            
            // ダウンロードシーケンスを初期化する
            fileBean.setDataSize(DATA_TABLE_ID, (id -> {return getRecordCount();}));

            fileBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);

            fileBean.setSubFlg(false);

            fileBean.setTilte(titleName);

            fileBean.regDownloadFucntion(DATA_TABLE_ID, getHeader() ,
                    (id -> {return getShimukeList();}));
            
            fileBean.regBeforeDownFucntion(DATA_TABLE_ID,
                    (comment -> {return beforeDown(comment);}));
            fileBean.setSearchResult(DATA_TABLE_ID, (id -> {return getSearchResult();})); 
            
            // component初期化とユーザ権限により制御設定
            pageCommonBean.setAuthControll(mst271Form, SC_CD_MST271, true);
            
            //管轄営業所
            mst271Form.setConKankatsuEigyoshoDisabled(true);
            //代理店を表示する
            mst271Form.setCheckConDairitenDisplay("block");
            //中継業者を表示しない
            mst271Form.setCheckConKankatsuEigyoshoDisplay("none");
            // 世代検索条件を初期化する
            mst271Form.setConSedaiKensakuJoken(new String[]{"01","02"});
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * カウント処理
     *
     * @return 取得件数
     */
    public Long getRecordCount() {
        
         // 前回の記録をクリアする
        Map<String, Object> mapRec = new LinkedHashMap();
        mapRec.put(StndConsIF.CONST_ZERO_STRING, true);
        List<Map<String, Object>> mapList = new ArrayList();
        mapList.add(mapRec);
        mst271Form.setSearchResult(mapList);
        mst271Form.setSearchResult(new ArrayList<>());
        mst271Form.setSearchResultSelectable(new ReportListDataModel(mst271Form.getSearchResult()));
        mst271Form.setSelectedSearchResult(null);
        
        // レコード件数を取得する
        long recordCount = getShimukeListCount();
        // 検索部のステータスを変更する
        pageCommonBean.setSerchConDisabled(mst271Form);
        // 参照モードにする
        pageCommonBean.setEditFlg(true);
        // 検索条件保存
        pageCommonBean.savePageInfo(CONST_MST271_FORM, mst271Form);

        return recordCount;
    }
    
    /**
     * クリア処理
     *
     */
    public void clear() {

        // 検索部の条件クリア
        //代理店
        mst271Form.setConDairiten(null);
        //管轄営業所
        mst271Form.setConKankatsuEigyosho(null);
        //仕入先
        mst271Form.setConSiiresaki(null);
        //適用日
        mst271Form.setConTekiyoHi(null);
        // 世代検索条件を初期化する
        mst271Form.setConSedaiKensakuJoken(new String[]{"01","02"});
        //削除のみ
        mst271Form.setConSakujoSumiNomi(null);
        //料金表設定
        mst271Form.setConRyokinhyoSettei(null);
        //会社名
        mst271Form.setConKaishaMei(null);
        //支店/営業所
        mst271Form.setConSitenEigyosho(null);
        //伝票
        mst271Form.setConDempyoShubetu(null);
        //伝票
        mst271Form.setConDempyoShubetu1(null);
        //仕入先名称
        mst271Form.setConSiiresakiMeisho(null);
        //仕入先略称
        mst271Form.setConSiiresakiRyakusho(null);
        //仕入先名称
        mst271Form.setConSiiresakiMeisho1(null);
        //仕入先略称
        mst271Form.setConSiiresakiRyakusho1(null);
        //デフォルトのみ
        mst271Form.setConDefaultNomi(null);
        
        String kbn = mst271Form.getConGyoshaKbn();
        //代理店
        if ("1".equals(kbn)) {
           //代理店を表示する
            mst271Form.setCheckConDairitenDisplay("block");
            //中継業者を表示しない
            mst271Form.setCheckConKankatsuEigyoshoDisplay("none");
            //代理店
            mst271Form.setConDairitenDisabled(false);
            //管轄営業所
            mst271Form.setConKankatsuEigyoshoDisabled(true);
        //中継業者
        } else if("2".equals(kbn)) {
            //代理店を表示しない
            mst271Form.setCheckConDairitenDisplay("none");
            //中継業者を表示する
            mst271Form.setCheckConKankatsuEigyoshoDisplay("block");
            //代理店
            mst271Form.setConDairitenDisabled(true);
            //管轄営業所
            mst271Form.setConKankatsuEigyoshoDisabled(false);
        }
        mst271Form.setConTodofukenDisabled(false);
        mst271Form.setSearchResult(null);
        mst271Form.setSearchResultSelectable(null);
        mst271Form.setSelectedSearchResult(null);
        // 検索部のステータス変更
        pageCommonBean.setBtnSearchChangeVisible(false);
        pageCommonBean.setBtnSearchVisible(Boolean.TRUE);
    }
    /**
     * 業者区分の変更処理
     */
    public void change(){
        //業者区分を取得
        String kbn = mst271Form.getConGyoshaKbn();
        // 検索部のステータス変更
        mst271Form.setBtnSearchVisible(true);
        mst271Form.setConTodofukenDisabled(false);
        
        mst271Form.setSearchResult(null);
        mst271Form.setSearchResultSelectable(null);
        mst271Form.setSelectedSearchResult(null);
        clear();
        //代理店
        if ("1".equals(kbn)){
            //代理店
            mst271Form.setConDairitenDisabled(false);
            //管轄営業所
            mst271Form.setConKankatsuEigyoshoDisabled(true);
            //代理店を表示する
            mst271Form.setCheckConDairitenDisplay("block");
            //中継業者を表示しない
            mst271Form.setCheckConKankatsuEigyoshoDisplay("none");
        } else if ("2".equals(kbn)) {
            //代理店
            mst271Form.setConDairitenDisabled(true);
            //管轄営業所
            mst271Form.setConKankatsuEigyoshoDisabled(false);
            //代理店を表示しない
            mst271Form.setCheckConDairitenDisplay("none");
            //中継業者を表示する
            mst271Form.setCheckConKankatsuEigyoshoDisplay("block");
        }
        // ダウンロードシーケンスを初期化する
        fileBean.setDataSize(DATA_TABLE_ID, (id -> {return getRecordCount();}));

        fileBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);

        fileBean.setSubFlg(false);

        fileBean.setTilte(titleName);

        fileBean.regDownloadFucntion(DATA_TABLE_ID, getHeader() ,
                (id -> {return getShimukeList();}));

        fileBean.regBeforeDownFucntion(DATA_TABLE_ID,
                (comment -> {return beforeDown(comment);}));
        
        fileBean.setSplitButtonSta(true);
        
        // 参照モードにする
        pageCommonBean.setEditFlg(false);
        // 検索部のステータス変更
        pageCommonBean.setBtnSearchChangeVisible(false);
        pageCommonBean.setBtnSearchVisible(Boolean.TRUE);
        
    }
    
     /**
     * 検索条件変更処理
     *
     */
    public void searchChange() {
        // 検索部のステータスを変更する
        pageCommonBean.setSerchConEnabled(mst271Form);
        
        //業者区分を取得
        String kbn = mst271Form.getConGyoshaKbn();
        //中継業者
        if ("1".equals(kbn)) {
            //代理店
            mst271Form.setConDairitenDisabled(false);
            //管轄営業所
            mst271Form.setConKankatsuEigyoshoDisabled(true);
        } else if("2".equals(kbn)) {
            //代理店
            mst271Form.setConDairitenDisabled(true);
            //管轄営業所
            mst271Form.setConKankatsuEigyoshoDisabled(false);
        }
    }
    
    /**
     * 検索処理
     *
     */
    public void search() {
        // 選択リストを初期化する
        mst271Form.setSelectedSearchResult(new ArrayList<>());
        mst271Form.setSearchResultSelectable(null);
       
        // 代理店・中継マスタ検索を行う
        List<Map<String, Object>> res = getShimukeList();
        // 検索部のステータス変更
        mst271Form.setBtnSearchVisible(true);
        mst271Form.setBtnSearchChangeVisible(true);
        
        fileBean.setDataList(res);
        // 取得した値を画面項目にセットする
        pageCommonBean.setDatalist(DATA_TABLE_ID, res);
        mst271Form.setSearchResultSelectable(new ReportListDataModel(res));
        // 検索部のステータス変更
        mst271Form.setConTodofukenDisabled(true);
        //代理店
        mst271Form.setConDairitenDisabled(true);
        //管轄営業所
        mst271Form.setConKankatsuEigyoshoDisabled(true);
        
        // 検索部のステータスを変更する
        pageCommonBean.setSerchConDisabled(mst271Form);
        // 検索条件を保存する
        pageCommonBean.savePageInfo(CONST_MST271_FORM, mst271Form);
        
        // 参照モードにする
        pageCommonBean.setEditFlg(true);
    }

    /**
     * DBから代理店・中継配達料金表一覧情報を取得する
     */
    private List<Map<String, Object>> getShimukeList() {
        
        //パラメータ
        Map<String, Object> params = new HashMap<>();
       
        //ワーク.業者区分
        params.put("conGyoshaKbn", mst271Form.getConGyoshaKbn());
        //ワーク.代理店コード
        params.put("conDairiten", mst271Form.getConDairiten() == null ?  "" :  mst271Form.getConDairiten().getValue());
        //ワーク.管轄営業所コード
        params.put("conKankatsuEigyosho", mst271Form.getConKankatsuEigyosho() == null ?  "" :  mst271Form.getConKankatsuEigyosho().getValue());
        //ワーク.仕入先
        params.put("conSiiresaki", mst271Form.getConSiiresaki() == null ?  "" :  mst271Form.getConSiiresaki().getValue());
        //ワーク.世代検索条件
        String[] conSedaiKensakuJoken = new String[5];
        List conSedaiKensakuJokenList = Arrays.asList(mst271Form.getConSedaiKensakuJoken());
        for (int i = 1; i < 6; i++) {
            if (conSedaiKensakuJokenList.isEmpty()) {
                conSedaiKensakuJoken[i - 1] = "0";
            } else {
                //循环リスト 比較値して値をつける
                for (Object object : conSedaiKensakuJokenList) {
                    if (i == Integer.valueOf(String.valueOf(object))) {
                        conSedaiKensakuJoken[i - 1] = "1";
                        break;
                    } else {
                        conSedaiKensakuJoken[i - 1] = "0";
                    }
                }
            }
        }
        params.put("conSedaiKensakuJoken", conSedaiKensakuJoken);
        //ワーク.適用日指定
        params.put("conTekiyoHi", mst271Form.getConTekiyoHi());
        //ワーク.削除済のみ
       params.put("conSakujoSumiNomi", mst271Form.getConSakujoSumiNomi().isEmpty() ?  "1" :  "0");
       
        //ワーク.料金表設定
       params.put("conRyokinhyoSettei", mst271Form.getConRyokinhyoSettei().isEmpty() ?  "0" :  "1");

       //params.put("conRyokinhyoSettei", mst271Form.getConRyokinhyoSettei());
       //ワーク.会社名
       params.put("conKaishaMei", mst271Form.getConKaishaMei() == null ?  "" :  mst271Form.getConKaishaMei().getLabel());

        //ワーク.支店/営業所
        params.put("conSitenEigyosho", mst271Form.getConSitenEigyosho() == null ?  "" :  mst271Form.getConSitenEigyosho().getLabel());
        if ("1".equals(mst271Form.getConGyoshaKbn())) {
            
            //ワーク.伝票種別コード
            params.put("conDempyoShubetu", mst271Form.getConDempyoShubetu1() == null ?  "" :  mst271Form.getConDempyoShubetu1().getValue());

            //ワーク.仕入先名称
            params.put("conSiiresakiMeisho", mst271Form.getConSiiresakiMeisho1() == null ?  "" :  mst271Form.getConSiiresakiMeisho1());

            //ワーク.仕入先略称
            params.put("conSiiresakiRyakusho", mst271Form.getConSiiresakiRyakusho1() == null ?  "" :  mst271Form.getConSiiresakiRyakusho1());
        } else {
            //ワーク.伝票種別コード
            params.put("conDempyoShubetu", mst271Form.getConDempyoShubetu() == null ?  "" :  mst271Form.getConDempyoShubetu().getValue());

            //ワーク.仕入先名称
            params.put("conSiiresakiMeisho", mst271Form.getConSiiresakiMeisho() == null ?  "" :  mst271Form.getConSiiresakiMeisho());

            //ワーク.仕入先略称
            params.put("conSiiresakiRyakusho", mst271Form.getConSiiresakiRyakusho() == null ?  "" :  mst271Form.getConSiiresakiRyakusho());
        }
        
        //ワーク.デフォルトのみ
        params.put("conDefaultNomi", mst271Form.getConDefaultNomi().isEmpty() ?   "0" :   "1");
        // DBをアクセスする
        try {
            ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH);
            ObjectMapper mapper = new ObjectMapper();
            mst271Form.setSearchResult(mapper.readValue(serviceInterfaceBean.getJson(), List.class));

        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
        
        return mst271Form.getSearchResult();
    }
    
    /**
     * DBから代理店・中継配達料金表一覧検索件数を取得する処理
     */
    private Long getShimukeListCount() {
       
        //パラメータ
        Map<String, Object> params = new HashMap<>();
       // 世代検索条件で(適用日指定)が選択されている場合 (共通check没法实现联动check)
        if (Arrays.asList(mst271Form.getConSedaiKensakuJoken()).contains("05")) {
            // 適用日の入力が行われているかチェックを行う。
            if (mst271Form.getConTekiyoHi() == null) {
                MessageModuleBean message  =  messageProperty.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0028,"適用日指定","適用日");
                msgList.add(message);
                return null;
            }
        }
        //ワーク.業者区分
        params.put("conGyoshaKbn", mst271Form.getConGyoshaKbn());
        //ワーク.代理店コード
        params.put("conDairiten", mst271Form.getConDairiten() == null ?  "" :  mst271Form.getConDairiten().getValue());
        //ワーク.管轄営業所コード
        params.put("conKankatsuEigyosho", mst271Form.getConKankatsuEigyosho() == null ?  "" :  mst271Form.getConKankatsuEigyosho().getValue());
        //ワーク.仕入先
        params.put("conSiiresaki", mst271Form.getConSiiresaki() == null ?  "" :  mst271Form.getConSiiresaki().getValue());
        //ワーク.世代検索条件
        String[] conSedaiKensakuJoken = new String[5];
        List conSedaiKensakuJokenList = Arrays.asList(mst271Form.getConSedaiKensakuJoken());
        for (int i = 1; i < 6; i++) {
            if (conSedaiKensakuJokenList.isEmpty()) {
                conSedaiKensakuJoken[i - 1] = "0";
            } else {
                //循环リスト 比較値して値をつける
                for (Object object : conSedaiKensakuJokenList) {
                    if (i == Integer.valueOf(String.valueOf(object))) {
                        conSedaiKensakuJoken[i - 1] = "1";
                        break;
                    } else {
                        conSedaiKensakuJoken[i - 1] = "0";
                    }
                }
            }
        }
        params.put("conSedaiKensakuJoken", conSedaiKensakuJoken);
        //ワーク.適用日指定
        params.put("conTekiyoHi", mst271Form.getConTekiyoHi());
        //ワーク.削除済のみ
       params.put("conSakujoSumiNomi", mst271Form.getConSakujoSumiNomi().isEmpty() ?  "1" :  "0");
       
        //ワーク.料金表設定
       params.put("conRyokinhyoSettei", mst271Form.getConRyokinhyoSettei().isEmpty() ?  "0" :  "1");

       //params.put("conRyokinhyoSettei", mst271Form.getConRyokinhyoSettei());
       //ワーク.会社名
       params.put("conKaishaMei", mst271Form.getConKaishaMei() == null ?  "" :  mst271Form.getConKaishaMei().getLabel());

        //ワーク.支店/営業所
        params.put("conSitenEigyosho", mst271Form.getConSitenEigyosho() == null ?  "" :  mst271Form.getConSitenEigyosho().getLabel());
        
        if ("1".equals(mst271Form.getConGyoshaKbn())) {
            
            //ワーク.伝票種別コード
            params.put("conDempyoShubetu", mst271Form.getConDempyoShubetu1() == null ?  "" :  mst271Form.getConDempyoShubetu1().getValue());

            //ワーク.仕入先名称
            params.put("conSiiresakiMeisho", mst271Form.getConSiiresakiMeisho1() == null ?  "" :  mst271Form.getConSiiresakiMeisho1());

            //ワーク.仕入先略称
            params.put("conSiiresakiRyakusho", mst271Form.getConSiiresakiRyakusho1() == null ?  "" :  mst271Form.getConSiiresakiRyakusho1());
        } else {
            //ワーク.伝票種別コード
            params.put("conDempyoShubetu", mst271Form.getConDempyoShubetu() == null ?  "" :  mst271Form.getConDempyoShubetu().getValue());

            //ワーク.仕入先名称
            params.put("conSiiresakiMeisho", mst271Form.getConSiiresakiMeisho() == null ?  "" :  mst271Form.getConSiiresakiMeisho());

            //ワーク.仕入先略称
            params.put("conSiiresakiRyakusho", mst271Form.getConSiiresakiRyakusho() == null ?  "" :  mst271Form.getConSiiresakiRyakusho());
        }
        //ワーク.デフォルトのみ
        params.put("conDefaultNomi", mst271Form.getConDefaultNomi().isEmpty() ?   "0" :   "1");
        
        
        // DBをアクセスする
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH_KENSU);

        // 検索件数を返却する
        return Long.valueOf(serviceInterfaceBean.getJson());
    }
    
    
    /**
     * メニュークリック（処理）
     *
     * @param menuId
     * @param nextScreen
     * @return
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック（処理）
     *
     * @return
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        url = forward(nextScreen, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return
     */
    @Override
    public String logoutClick() {
        return authConfBean.logout();
    }

    /**
     * 画面遷移処理（顧客マスタメンテナンス画面へ）
     *
     * @return
     * @throws java.lang.IllegalAccessException
     * @throws java.lang.reflect.InvocationTargetException
     */
    public String buttonClick() throws IllegalAccessException, InvocationTargetException {

        // 画面遷移
        url = forward(SCREEN.CUS012_SCREEN.name(), null, SCREEN.CUS011_SCREEN.name(), false);
        return url;
    }

    /**
     * @return the strTitle
     */
    public String getStrTitle() {
        return strTitle;
    }
    /**
     * ダウンロードダイアログ
     *
     * @param comment
     * @return boolean
     * @throws java.lang.Exception
     */
    public boolean beforeDown(String comment) throws Exception {
        System.out.println(comment);
        return true;
    }
    
    
    /**
     * CSVファイルのタイトルを設定する処理
     * 
     * @return 画面タイトル
     */
     public List<CSVDto> getHeader() {
        // CSVファイルのタイトルを設定
        List<CSVDto> header = new ArrayList<>();
        String kbn = mst271Form.getConGyoshaKbn();
        String codeStrField = "listDairitenCd";
        String conKankatsuEigyoshoMeiStrField = "listDairitenMei";
        String conKankatsuEigyoshoMeiStrName = "代理店";
        if ("2".equals(kbn)) {
            codeStrField = "listEigyoshoCd";
            conKankatsuEigyoshoMeiStrField = "listEigyoshoMei";
            conKankatsuEigyoshoMeiStrName="営業所";
        }
        header.add(new CSVDto("区分", "listKbnMei"));
        header.add(new CSVDto("コード", codeStrField));
        header.add(new CSVDto(conKankatsuEigyoshoMeiStrName, conKankatsuEigyoshoMeiStrField));
        header.add(new CSVDto("仕入先コード", "listShiiresakiCd"));
        header.add(new CSVDto("会社名", "listKaishaMei"));
        header.add(new CSVDto("支店/営業所", "listShitenEigyoshoMei"));
        header.add(new CSVDto("デフォルト", "listDefaultFlg"));
        header.add(new CSVDto("伝票種別", "listDempyoShubetsuCd"));
        header.add(new CSVDto("ステータス", "listStatus"));
        header.add(new CSVDto("適用開始日", "listTekiyoKaishibi"));
        header.add(new CSVDto("適用名", "listTekiyoMei"));
        header.add(new CSVDto("代理店中継配達料金表データバージョン", "listDairitenChukeiHaitatsuRyokinhyoDataVersion"));
        return header;
    }
      /**
     * 詳細へ遷移
     *
     * @return 
     */
    public String create() {
        return forward(SCREEN.MST272_SCREEN.name(), null, SCREEN.MST271_SCREEN.name(), false);
    }
       /**
     * 詳細へ遷移 複製登録ボタン
     *
     * @return 
     */
    public String copy() {
        //選択必須チェック
        if (mst271Form.getSelectedSearchResult() == null || mst271Form.getSelectedSearchResult().isEmpty()) {
            messageProperty.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0022);
            return null;
        } 
        //2行以上選択されていないかチェックを行う。
        if (mst271Form.getSelectedSearchResult().size() >= 2 ) {
            messageProperty.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0020);
            return null;
        } else {
            //料金設定のないコードを表示している場合、その行を選択して
            if (mst271Form.getConRyokinhyoSettei() == null || mst271Form.getConRyokinhyoSettei().isEmpty() || mst271Form.getConRyokinhyoSettei().get(0).equals("0")) {
                messageProperty.message(MessagePropertyBean.SEVERITY_WARN, MessageCnst.MSTW0002);
             }
            return forward(SCREEN.MST272_SCREEN.name(), null, SCREEN.MST271_SCREEN.name(), false);
        }      
    }
    
       /**
     * 詳細へ遷移
     *
     * @return 
     */
    public String details() {
        //選択必須チェック
        if (mst271Form.getSelectedSearchResult() == null || mst271Form.getSelectedSearchResult().isEmpty()) {
            messageProperty.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0013);
            return null;
        } 
        //2行以上選択されていないかチェックを行う。
        if (mst271Form.getSelectedSearchResult().size() >= 2 ) {
            messageProperty.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0020);
            return null;
        } else {
            //料金設定のないコードを表示している場合、その行を選択して
            if (mst271Form.getConRyokinhyoSettei() == null ||  mst271Form.getConRyokinhyoSettei().isEmpty() || mst271Form.getConRyokinhyoSettei().get(0).equals("0")) {
                messageProperty.message(MessagePropertyBean.SEVERITY_WARN, MessageCnst.MSTW0002);
            }
            return forward(SCREEN.MST272_SCREEN.name(), null, SCREEN.MST271_SCREEN.name(), false);
        }  
    }
     
    
     /**
     * 更新履歴を表示処理
     *
     */
    public void rirekiIchiran() {

        //履歴テーブル検索キー設定
        rirekiSearchKey = new HashMap();
        Map<String, String> selectRec = mst271Form.getSelectedSearchResult().get(0);
        
        //仕入先コード
        rirekiSearchKey.put("conSiiresakiCd", selectRec.get("listShiiresakiCd"));
        //世代検索
        String[] conSedaiKensakuJoken = new String[5];
        List conSedaiKensakuJokenList = Arrays.asList(mst271Form.getConSedaiKensakuJoken());
        for (int i = 1; i < 6; i++) {
            if (conSedaiKensakuJokenList.isEmpty()) {
                conSedaiKensakuJoken[i - 1] = "0";
            } else {
                //循环リスト 比較値して値をつける
                for (Object object : conSedaiKensakuJokenList) {
                    if (i == Integer.valueOf(String.valueOf(object))) {
                        conSedaiKensakuJoken[i - 1] = "1";
                        break;
                    } else {
                        conSedaiKensakuJoken[i - 1] = "0";
                    }
                }
            }
        }
        rirekiSearchKey.put("conSedaiKensakuJoken", conSedaiKensakuJoken);
        
         //ワーク.適用日指定
        if (selectRec.get("listTekiyoKaishibi") != null) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", Locale.US);
                rirekiSearchKey.put("conTekiyoHi", sdf.parse(selectRec.get("listTekiyoKaishibi")));
            } catch (ParseException ex) {
                java.util.logging.Logger.getLogger(Mst271Bean.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        //仕入先名称
         rirekiSearchKey.put("conSiiresakiMeisho", mst271Form.getConSiiresakiMeisho());
        //仕入先略称
         rirekiSearchKey.put("conSiiresakiRyakusho", mst271Form.getConSiiresakiRyakusho());
         String listDempyoShubetsuCd = selectRec.get("listDempyoShubetsuCd");
        //伝票種別
        rirekiSearchKey.put("conDempyoShubetuCd", listDempyoShubetsuCd.split(" ")[0]);
         //ワーク.削除済のみ
        rirekiSearchKey.put("conSakujoZumiNomiKensaku", mst271Form.getConSakujoSumiNomi().isEmpty() ?   "1" :   "0");
         //ワーク.デフォルトのみ
        rirekiSearchKey.put("conDefaultNomi", mst271Form.getConDefaultNomi().isEmpty() ?   "0" :   "1");
        //業者区分
        String kbn = mst271Form.getConGyoshaKbn();
        rirekiSearchKey.put("listKbnCd", kbn);
        String conKankatsuEigyoshoMeiStrName = "代理店";
        String codeStrField = "listDairitenCd";
        String conKankatsuEigyoshoMeiStrField = "listDairitenMei";
        //代理店コード
        rirekiSearchKey.put("conKankatsuEigyoshoCd", selectRec.get("listDairitenCd"));
        if ("2".equals(kbn)) {
            conKankatsuEigyoshoMeiStrName="営業所";
            codeStrField = "listEigyoshoCd";
            conKankatsuEigyoshoMeiStrField = "listEigyoshoMei";
            //管轄営業所コード
            rirekiSearchKey.put("conKankatsuEigyoshoCd", selectRec.get("listEigyoshoCd"));
        }
        //履歴タイトル設定
        rirekiSyosai.setListColName(
                new ArrayList<>(Arrays.asList(
                        "区分", "コード", conKankatsuEigyoshoMeiStrName,  "仕入先コード","会社名", "支店/営業所",
                        "デフォルト", "伝票種別", "ステータス", "適用開始日", "適用名", "代理店中継配達料金表データバージョン", "更新カウンタ")));

        //履歴テーブル物理カラム設定
        rirekiSyosai.setListColValue(new ArrayList<>(
                Arrays.asList(
                        "listKbnMei", codeStrField, conKankatsuEigyoshoMeiStrField, "listShiiresakiCd", "listKaishaMei",
                        "listShitenEigyoshoMei","listDefaultFlg","listDempyoShubetsuCd","listStatus","listTekiyoKaishibi","listTekiyoMei",
                        "listDairitenChukeiHaitatsuRyokinhyoDataVersion","listKoshinCounter")));
        //履歴テーブル検索する
        rirekiSyosai.searchList("2", "MST271_SEARCH_RIREKI", rirekiSearchKey);

    }
    
   /**
     * 検索結果を取得する
     * 
     * @return 検索結果
     */
    private List<Map<String, Object>> getSearchResult() {
        return mst271Form.getSearchResult();
    }
}