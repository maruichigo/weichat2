/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common.annotation.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.utils.DateUtils;
import jp.co.kintetsuls.beans.common.annotation.DateCheck;

/**
 * 日付チェック
 * 
 * @author zf (MBP)
 * @version 2019/3/7 新規作成
 */
public class DateCheckValidator implements ConstraintValidator<DateCheck, String> { 

    private String pattern;

    @Override
    public void initialize(DateCheck constraintAnnotation) {
        this.pattern = constraintAnnotation.pattern();
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (value != null && !"".equals(value)) {
            try {
                DateUtils.parse(value, pattern);
            } catch (SystemException e) {
                return false;
            }
        }
        return true;
    }
    
}
