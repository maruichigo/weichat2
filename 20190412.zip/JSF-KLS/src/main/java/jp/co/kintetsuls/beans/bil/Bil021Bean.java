/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.bil;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import jp.co.kintetsuls.beans.cus.*;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Level;
import java.util.stream.Collectors;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import jp.co.kintetsuls.beans.common.AutoCompleteBean;
import jp.co.kintetsuls.beans.common.LabelValueBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.cnst.SysMsg;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.forms.common.LabelValueForm;
import jp.co.kintetsuls.forms.bil.Bil021Form;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.kintetsuls.service.general.property.ExternalServiceProperty;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.event.SelectEvent;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author y_kamata
 */
@Data
@javax.faces.bean.ManagedBean(name = "bil021")
@ViewScoped
public class Bil021Bean extends BaseBean {

    private final String strTitle = "月額自動請求マスタ(輸送売上)画面";
    private String url; // URL

    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    @ManagedProperty(value = "#{autoComplete}")
    private AutoCompleteBean autoCompleteBean;

    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messageProperty;

    @ManagedProperty(value = "#{labelValueBean}")
    private LabelValueBean labelValueBean;

    @ManagedProperty(value = "#{bil021Form}")
    private Bil021Form form;

    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommon;

    private static final Logger logger = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    private RestfullService rest;

    /**
     * メッセージID：COME0003.
     */
    private static final String MSG_ID_COME0003 = "COME0003";

    /**
     * 定数：0文字列.
     */
    private static final String CONST_ZERO_STRING = "0";

    /**
     * 定数：COM_GET_VW_EIGYOSHO.
     */
    private static final String COM_GET_VW_EIGYOSHO = "COM_GET_VW_EIGYOSHO";

    /**
     * 定数：COM_GET_VW_KOKYAKU.
     */
    private static final String COM_GET_VW_KOKYAKU = "COM_GET_VW_KOKYAKU";

    /**
     * 定数：COM_GET_VW_FUTAI_RYOKIN_KOMOKU2.
     */
    private static final String COM_GET_VW_FUTAI_RYOKIN_KOMOKU2 = "COM_GET_VW_FUTAI_RYOKIN_KOMOKU2";

    /**
     * 定数：検索FUNC_CODE.
     */
    private static final String SEARCH_FUNC_CODE = "BIL021_GET_DETAIL";

    /**
     * 定数：CHECKED.
     */
    private static final Integer CHECKED = 1;

    /**
     * コンストラクタ
     */
    public Bil021Bean() {
    }

    /**
     * 初期処理（処理）
     *
     * @param menuId
     * @param prevScreen
     * @param backFlag
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            // AutoCompleteを初期化する
            Map params = new HashMap();
            autoCompleteBean.initAutoComplete(COM_GET_VW_EIGYOSHO, params);
            autoCompleteBean.initAutoComplete(COM_GET_VW_KOKYAKU, params);
            autoCompleteBean.initAutoComplete(COM_GET_VW_FUTAI_RYOKIN_KOMOKU2, params);
            // パンくず追加
            breadBean.push("請求書の詳細画面", SCREEN.BIL021_SCREEN.name(), this);
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }

        /* 検索条件初期化 */
        clearConditions();

    }

    /**
     * メニュークリック（処理）
     *
     * @param menuId
     * @param nextScreen
     * @return
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }

        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック（処理）
     *
     * @return
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }
        url = forward(nextScreen, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return
     */
    @Override
    public String logoutClick() {
        return authConfBean.logout();
    }

    /**
     * 画面遷移処理
     *
     * @return
     */
    public String buttonClick() {
        url = forward(SCREEN.CUS012_SCREEN.name(), null, SCREEN.CUS012_SCREEN.name(), false);
        return url;
    }

    /**
     * @return the strTitle
     */
    public String getStrTitle() {
        return strTitle;
    }

    /**
     * @return the breadBean
     */
    public BreadCrumbBean getBreadBean() {
        return breadBean;
    }

    /**
     * @param breadBean the breadBean to set
     */
    public void setBreadBean(BreadCrumbBean breadBean) {
        this.breadBean = breadBean;
    }

    /// authConf Baseではやらない？
    public AuthorityConfBean getAuthConfBean() {
        return authConfBean;
    }

    public void setAuthConfBean(AuthorityConfBean authConfBean) {
        this.authConfBean = authConfBean;
    }

    /**
     * 検索処理
     *
     */
    public void search() {
        logger.debug("test", "search()");
        List<Map<String, Object>> res = searchForList();
        if (res != null) {
            for (Map<String, Object> re : res) {
                if (re.get("listTekiyoKaishibi") != null) {
                    re.put("listTekiyoKaishibi", new Date((long) re.get("listTekiyoKaishibi")));
                }
                if (re.get("listTekiyoShuryobi") != null) {
                    re.put("listTekiyoShuryobi", new Date((long) re.get("listTekiyoShuryobi")));
                }
                re.put("listUriageKosuShiyoFlg", CHECKED.equals(re.get("listUriageKosuShiyoFlg")));
                re.put("listShuryoCheck", CHECKED.equals(re.get("listShuryoCheck")));
            }
            pageCommon.getDatasLists().put("tablesorter_bil021", res);
            form.setSearchResultSelectable(new ReportListDataModel(res));
        }
    }

    /**
     * 検索条件クリア
     */
    public void clearConditions() {
    }

    private List<Map<String, Object>> searchForList() {
        ServiceInterfaceBean req = new ServiceInterfaceBean();

        req.setFunctionCode(SEARCH_FUNC_CODE);

        //parameter
        Map<String, Object> params = new HashMap<>();
        // 営業所コード
        if (form.getConEigyoshoCd() != null) {
            params.put("conEigyoshoCd", form.getConEigyoshoCd().getValue());
        } else {
            req.addMessage("WARN", "警告", messageProperty.getProperty(MSG_ID_COME0003, "営業所コード"));
        }
        if (form.getConKokyakuCd() != null) {
            params.put("conKokyakuCd", form.getConKokyakuCd().getValue());
        } else {
            params.put("conKokyakuCd", "");
        }
        if (form.getConRyokinKomokuCd() != null) {
            params.put("conRyokinKomokuCd", form.getConRyokinKomokuCd().getValue());
        } else {
            params.put("conRyokinKomokuCd", "");
        }
        // 適用名
        params.put("conTekiyoMei", form.getConTekiyoMei());
        // 世代検索
        List<String> jokens = form.getConSedaiKensakuJoken();

        // 締日
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy",Locale.US);
            params.put("conShimeBi", sdf.parse(String.valueOf(form.getConTekiyoBi())));
        } catch (ParseException ex) {
            java.util.logging.Logger.getLogger(Bil021Bean.class.getName()).log(Level.SEVERE, null, ex);
        }
        String requestData = JSONUtil.makeJSONString(params);
        req.setJson(requestData);
        if (req.getMessages().size() > 0) {
            return null;
        }

        //JAX-RS接続を実行(SQL側のチェック処理など未実装。)
        rest = RestfullService.getInstance();
        ServiceInterfaceBean res = null;
        try {
            res = rest.request(req);
        } catch (Exception ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
            return null;
        }

        if (res == null || res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return null;
        }

        try {
            ObjectMapper mapper = new ObjectMapper();
            form.setSearchResult(mapper.readValue(res.getJson(), List.class));

        } catch (IOException ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
            return null;
        }

        // 戻りSIBのステータスチェック、エラー処理
        if (res == null || res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {

            // ToDo:各画面の仕様に従いメッセージ表示などのエラー処理を追加してください
        }
        return form.getSearchResult();
    }

}
