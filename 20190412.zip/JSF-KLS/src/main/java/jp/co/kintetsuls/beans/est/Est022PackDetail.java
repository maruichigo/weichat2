/*
 * EstimatePackDetailBean.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.est;

import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.FacesEvent;
import javax.faces.model.SelectItem;
import jp.co.kintetsuls.exception.LogicException;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.forms.est.Est022PackForm;
import lombok.Data;
import org.primefaces.component.api.DynamicColumn;
import org.primefaces.component.api.UIColumn;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.event.CellEditEvent;
import org.primefaces.event.SelectEvent;

/**
 *
 * @MBP
 */
@javax.faces.bean.ManagedBean(name = "est022PackDetail")
@ViewScoped
@Data
public class Est022PackDetail {

    // 見積りパック料金
    @ManagedProperty(value = "#{est022PackForm}")
    private Est022PackForm packForm;

//=============================================================================
//【Pack料金一覧部
//-----------------------------------------------------------------------------
    //ランクボラタンコンポーネントIDX
    private final int RANK_BUTTON_IDX = 1;

    //料金表テーブルコンポーネントID
    private final String PACK_UNCHIN_DT_ID = "estimationForm:estimationTab:unchin";

    //料金表テーブル・ヘッダ部 コンポーネントKEY
    private final String PACK_UNCHIN_HEADER_KEY = "header";

    //運賃テーブルカラム関連
    private final int UNCHIN_COL_WIDTH = 148;
    private final int UNCHIN_COL_MAX = 10;
    private final int UNCHIN_COL_SIDE = 190;

    //地図初期背景色
    private final String MAP_DEF_COLOR = "#cfcfcf";

//-----------------------------------------------------------------------------
    //ランク別設定
    private List<EstimatePackRank> ranks;

    //動的な列生成用
    private List<EstimateColumnModel> columns;

    //建値設定設定
//    private List<EstimatePackPricePattern> pricePatterns;
    //料金設定
    private List<List<BigDecimal>> prices;

    //都道府県リスト１
    private List<EstimatePackCityPrefectures> prefectures1;

    //都道府県リスト２
    private List<EstimatePackCityPrefectures> prefectures2;

    //都道府県リスト３
    private List<EstimatePackCityPrefectures> prefectures3;

    //市区町村リスト
    private List<EstimatePackCityMunicipality> municipalities;

    //運賃テーブル幅
    private int unchinWidth;

    //料金表ドラッグ＆ドロップモード
    private boolean draggableColumns;

    //マップリスト
    private Map<String, String> colorList;

    public Est022PackDetail() {
    }

    public void addCol(int idx) throws LogicException, SystemException, InvocationTargetException {
    }

    public void dummyw(int index) throws LogicException, SystemException, InvocationTargetException {
    }

    /**
     * 料金表の明細行を追加する
     *
     * @param event
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    public void addRow(FacesEvent event) throws LogicException, SystemException {

        getPackInfo();
        // 運賃テーブル取得
        FacesContext ctx = FacesContext.getCurrentInstance();
        DataTable table = (DataTable) ctx.getViewRoot().findComponent(PACK_UNCHIN_DT_ID);
        List<UIColumn> cols = table.getColumns();

        //料金行追加
        List row = new ArrayList();
        for (int i = 0; cols.size() > i; i++) {
            BigDecimal price = new BigDecimal("0");
            row.add(price);
        }
        List<List<BigDecimal>> priceList = this.prices;
        priceList.add(row);

        //建値行追加
    }

    /**
     * 画面で選択された発着地名を取得するメソッド
     *
     * @param event
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    public void selectedRegion(SelectEvent event) throws LogicException, SystemException {
//        selectedRegion = (String)event.getObject();
    }

    /**
     * 発着地名を印刷用発着地名に転記するメソッド
     *
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    public void setPrintRegion() throws LogicException, SystemException {

        //未選択の場合は以降SKIP
//        if(selectedRegion==null) return;
        //rankを逆引きする
/*        EstimatePackRank rank = getSelectedCityRank(selectedRegion);
        if(rank==null) return;

        if(rank.getPrintRegion1()==null || rank.getPrintRegion1().equals("")) {
            rank.setPrintRegion1(selectedRegion);
        } else if (rank.getPrintRegion2()==null || rank.getPrintRegion2().equals("")) {
            rank.setPrintRegion2(selectedRegion);
        } else if (rank.getPrintRegion3()==null || rank.getPrintRegion3().equals("")) {
            rank.setPrintRegion3(selectedRegion);
        } else if (rank.getPrintRegion4()==null || rank.getPrintRegion4().equals("")) {
            rank.setPrintRegion4(selectedRegion);
        } else if (rank.getPrintRegion5()==null || rank.getPrintRegion5().equals("")) {
            rank.setPrintRegion5(selectedRegion);
        } else if (rank.getPrintRegion6()==null || rank.getPrintRegion6().equals("")) {
            rank.setPrintRegion6(selectedRegion);
        } else if (rank.getPrintRegion7()==null || rank.getPrintRegion7().equals("")) {
            rank.setPrintRegion7(selectedRegion);
        } else if (rank.getPrintRegion8()==null || rank.getPrintRegion8().equals("")) {
            rank.setPrintRegion8(selectedRegion);
        }
         */
    }

    /**
     * RegionからRankを逆引きするメソッド
     *
     * @param region
     * @return rank object
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    private EstimatePackRank getSelectedCityRank(String region) throws LogicException, SystemException {

        EstimatePackRank result = null;
        /*
        looptop:
        for(EstimatePackRank rank : ranks) {
            for(String city : rank.getCities()) {
                if (city.equals(region)) {
                    result = rank;
                    break looptop;
                }
            }
        }
         */
        return result;
    }

    /**
     * 都道府県一覧で選択されたランクを一括更新する
     *
     * @param event
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    public void setRankSelectPrefectures(FacesEvent event) throws LogicException, SystemException {

        getPackInfo();

        //パラメータ取得
        Map<String, String> param = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
        int mode = Integer.parseInt(param.get("mode"));

        String inputRank = "01";

        //都道府県一覧selection1
        List<EstimatePackCityPrefectures> selectedPrefectures = this.prefectures1;
        for (EstimatePackCityPrefectures city : selectedPrefectures) {
            //ランク設定済の場合は解除する
            if (city.getRank() != null && !city.getRank().equals("")) {
                deleteCityList(city.getRank(), city.getJisCode(), 1);
            }
            //ランク設定
            if (mode == 1) {
                setRankPrefectures(inputRank, city);
            }
        }

        //都道府県一覧selection2
        selectedPrefectures = this.prefectures2;
        for (EstimatePackCityPrefectures city : selectedPrefectures) {
            //ランク設定済の場合は解除する
            if (city.getRank() != null && !city.getRank().equals("")) {
                deleteCityList(city.getRank(), city.getJisCode(), 2);
            }
            //ランク設定
            if (mode == 1) {
                setRankPrefectures(inputRank, city);
            }
        }

        //都道府県一覧selection3
        selectedPrefectures = this.prefectures3;
        for (EstimatePackCityPrefectures city : selectedPrefectures) {
            //ランク設定済の場合は解除する
            if (city.getRank() != null && !city.getRank().equals("")) {
                deleteCityList(city.getRank(), city.getJisCode(), 3);
            }
            //ランク設定
            if (mode == 1) {
                setRankPrefectures(inputRank, city);
            }
        }

    }

    /**
     * 都道府県をランクに反映する
     *
     * @param ranknum
     * @param city
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    private void setRankPrefectures(String ranknum, EstimatePackCityPrefectures city) throws LogicException, SystemException {

        //入力されたランクの有無をチェックして要素取得
        EstimatePackRank inpRank = getInputRank(ranknum);

        //都道府県地図／一覧の要素取得
        if (inpRank != null) {
            String name = city.getCityName();
            String code = city.getJisCode();
            List<String> cities = inpRank.getCities();
            cities.add(code + ":" + name + ":" + "P");
            city.setColor(inpRank.getRankColor());
            city.setRank(ranknum);
        }
    }

    /**
     * ランクColumnを追加するメソッド
     *
     * @param bean
     * @param event
     * @param md
     * @param flg
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    public void addColumn2(FacesEvent event) throws LogicException, SystemException {

        getPackInfo();

        //fixme debug 
        long start = System.nanoTime();

        //Column数
        int count = columns.size();

        for (int j = 0; count > j; j++) {

            //カラム生成
            columns.add(new EstimateColumnModel("Dummy", "Dummy"));
            int colindex = columns.size() - 1;

            //ヘッダ生成
            EstimatePackRank rank = new EstimatePackRank();
            rank.setRankColor(EstimateRankColor.getColor(colindex + 1));
            ranks.add(rank);

            //料金に新規Columnを追加
            BigDecimal price;
            for (int i = 0; prices.size() > i; i++) {
                List row = prices.get(i);
                price = new BigDecimal("0");
                row.add(price);
            }
        }

        int size = columns.size();
        //テーブル幅算出
        if (size < UNCHIN_COL_MAX) {
            unchinWidth = UNCHIN_COL_SIDE + UNCHIN_COL_WIDTH * (size);
        } else {
            unchinWidth = UNCHIN_COL_SIDE + UNCHIN_COL_WIDTH * UNCHIN_COL_MAX;
        }
        this.packForm.setUnchinWidth(unchinWidth);

        //fixme debug 
        long end = System.nanoTime();
        System.out.println("PackDetail::::: " + (end - start) + "ns");

    }

    /**
     * 日本地図の背景色を返却するメソッド
     *
     * @param values
     * @param obj
     * @param md
     * @param code
     * @param tabindex
     * @param regindex
     * @return color
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    public String getMapColor(String code)
            throws LogicException, SystemException {
        // 背景色を取得（ランクの色と同じなので、一覧から取得とします）
        if (!colorList.isEmpty() && colorList.containsKey(code)) {
            return colorList.get(code);
        }
        return MAP_DEF_COLOR;
    }

    /*----------------------------------------------------------------------------------------------------------------------------------*/
    /**
     * 都道府県一覧でランクの更新・削除を映するメソッド
     *
     * @param bean
     * @param event
     * @param md
     * @param flg
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    public void changeRowPrefecturesRank(FacesEvent event)
            throws LogicException, SystemException {

        //fixme debug 
        long start = System.nanoTime();

        getPackInfo();

        //パラメータ取得
        Map<String, String> param = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
        int listnum = Integer.parseInt(param.get("listnum"));

        //ObjectValues取得
        String code = null;
        switch (listnum) {
            case 1:
                code = prefectures1.get(((CellEditEvent) event).getRowIndex()).getJisCode();
                break;
            case 2:
                code = prefectures2.get(((CellEditEvent) event).getRowIndex()).getJisCode();
                break;
            case 3:
                code = prefectures3.get(((CellEditEvent) event).getRowIndex()).getJisCode();
                break;
            default:
                break;
        }

        String newRank = (String) ((CellEditEvent) event).getNewValue();
        String oldRank = (String) ((CellEditEvent) event).getOldValue();
        if (newRank == null || newRank.equals("")) {
            deleteCityList(oldRank, code, listnum);
        } else {
            setPrefecturesList(newRank, code, listnum);
        }

        //fixme debug 
        long end = System.nanoTime();
        System.out.println("PackDetail::::: " + (end - start) + "ns");

    }

    /**
     * 都道府県一覧・市区町村一覧でランクが削除された場合の処理
     *
     * @param ranknum
     * @param code
     * @param listnum
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    private void deleteCityList(String ranknum, String code, int listnum) throws LogicException, SystemException {

        //削除される前のランクの有無をチェックして要素取得
        EstimatePackRank inpRank = getInputRank(ranknum);

        //都道府県・市区町村の削除
        if (inpRank != null) {
            for (String targetCity : inpRank.getCities()) {
                String[] cityProperty = targetCity.split(":");
                if (cityProperty[0].equals(code)) {
                    inpRank.getCities().remove(targetCity);
                    if (cityProperty[2].equals("P")) {
                        releasePrefectures(code, listnum);
                    } else {
                        //fixme
                    }
                    break;
                }
            }
        }
    }

    /**
     * 都道府県一覧・市区町村一覧でランクが更新された場合の処理
     *
     * @param ranknum
     * @param code
     * @param listnum
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    public void setPrefecturesList(String ranknum, String code, int listnum) throws LogicException, SystemException {

        //入力されたランクの有無をチェックして要素取得
        EstimatePackRank inpRank = getInputRank(ranknum);

        //都道府県地図／一覧の要素取得
        if (inpRank != null) {
            EstimatePackCityPrefectures city = getPrefectures(code, listnum);
            if (city != null) {
                //ランクに当道府県を追加
                String name = city.getCityName();
                List<String> cities = inpRank.getCities();
                cities.add(code + ":" + name + ":" + "P");
                city.setColor(inpRank.getRankColor());
            }
        }
    }

    /**
     * 都道府県一覧で入力されたランク返却するメソッド
     *
     * @param listnum
     * @return rank object
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    private EstimatePackRank getInputRank(String ranknum) throws LogicException, SystemException {

        getPackInfo();
        EstimatePackRank result = null;
        for (EstimatePackRank rank : ranks) {
            if (rank.getRank().equals(ranknum)) {
                result = rank;
                break;
            }
        }
        return result;
    }

    /**
     * ランクColumnを追加するメソッド
     *
     * @param bean
     * @param event
     * @param md
     * @param flg
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    public void addColumn(FacesEvent event)
            throws LogicException, SystemException {

        //fixme debug 
        long start = System.nanoTime();

        getPackInfo();

        //パラメータ取得
        Map<String, String> param = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
        int colindex = Integer.parseInt(param.get("colIndex"));

        //最終列以外 or 列ドラッグ＆ドロップ可のときは生成しない
        if (ranks.size() - 1 != colindex || draggableColumns) {
            return;
        }

        //カラム生成
        columns.add(new EstimateColumnModel("Dummy", "Dummy"));

        //ヘッダ生成
        EstimatePackRank rank = new EstimatePackRank();
        rank.setRankColor(EstimateRankColor.getColor(colindex + 1));
        ranks.add(rank);

        //料金に新規Columnを追加
        BigDecimal price;
        for (int i = 0; prices.size() > i; i++) {
            List row = prices.get(i);
            price = new BigDecimal("0");
            row.add(price);
        }

        //テーブル幅算出
        if (colindex < UNCHIN_COL_MAX - 1) {
            unchinWidth = UNCHIN_COL_SIDE + UNCHIN_COL_WIDTH * (colindex + 2);
        } else {
            unchinWidth = UNCHIN_COL_SIDE + UNCHIN_COL_WIDTH * UNCHIN_COL_MAX;
        }
        this.packForm.setUnchinWidth(unchinWidth);

        //fixme debug 
        long end = System.nanoTime();
        System.out.println("PackDetail::::: " + (end - start) + "ns");

    }

    /**
     * ランク設定ボタンを選択／未選択状態にするメソッド
     *
     * @param bean
     * @param event
     * @param md
     * @param flg
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    public void selectRank(FacesEvent event)
            throws LogicException, SystemException {

        getPackInfo();

        //パラメータ取得
        Map<String, String> param = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
        // 現在選択列
        int colindex = Integer.parseInt(param.get("colIndex"));
        // 設定中のフラグ
        boolean selectFlag = Boolean.parseBoolean(param.get("selectFlag"));

        if (selectFlag) {
            for (int i = 0; i < ranks.size(); i++) {
                if (colindex == i) {
                    (ranks.get(i)).setSelected(true);
                } else {
                    (ranks.get(i)).setSelected(false);
                }
            }
        } else {
            ranks.get(colindex).setSelected(false);
        }
    }

    /**
     * 地図で選択した都道府県を料金表の発着地域に反映するメソッド
     *
     * @param bean
     * @param event
     * @param md
     * @param flg
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    public void setPrefectures(FacesEvent event)
            throws LogicException, SystemException {

        //パラメータ取得
        Map<String, String> param = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
        String code = param.get("pcode");

        //ObjectValues取得
        getPackInfo();

        //都道府県一覧の要素取得
        EstimatePackCityPrefectures city = getPrefectures(code, 0);

        //都道府県地図の要素取得
        EstimatePackRank selRank = getSelectRank();
        if (selRank == null) {
            return;
        }
        boolean exist = false;
        List<String> cities = selRank.getCities();
        // 着地リストに存在かどうか
        for (String targetCity : cities) {
            String[] cityProperty = targetCity.split(":");
            if (cityProperty[0].equals(code)) {
                exist = true;
                // 存在の場合は地図から削除し、背景色も解除
                cities.remove(targetCity);
                // 一覧から削除し、背景色も解除
                city.setRank(null);
                city.setColor(null);
                break;
            }
        }
        // 存在しない場合は、着地リストに追加し、地図/一覧の背景色を設定
        if (!exist) {
            String name = city.getCityName();
            cities.add(code + ":" + name + ":" + "P");
            city.setRank(selRank.getRank());
            city.setColor(selRank.getRankColor());
        }

        // 背景色更新
        colorList.put(code, city.getColor());

        // 他のリストから削除
        // deleteUnSelect(code);
    }

    /**
     * 都道府県・市区町村を料金表の発着地域から削除するメソッド
     *
     * @param bean
     * @param event
     * @param md
     * @param flg
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    public void deleteCity(FacesEvent event)
            throws LogicException, SystemException {

        //パラメータ取得
        Map<String, String> param = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
        String city = param.get("cityCode");
        int colindex = Integer.parseInt(param.get("colIndex"));

        //ObjectValues取得
        getPackInfo();

        //料金表のランクから削除する
        List<String> cities = (ranks.get(colindex)).getCities();
        for (String targetCity : cities) {
            String[] cityProperty = targetCity.split(":");
            if (cityProperty[0].equals(city)) {
                cities.remove(targetCity);
                //地図・一覧の情報を初期化する
                if (cityProperty[2].equals("P")) {
                    releasePrefectures(city, 0);
                } else {
                    //fixme
                }
                break;
            }
        }
    }

    /**
     * ランクColumnの並び順を保存するメソッド
     *
     * @param bean
     * @param event
     * @param md
     * @param flg
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    public void onColumnReorder(FacesEvent event)
            throws LogicException, SystemException {

        //ObjectValues取得
        getPackInfo();

        //UIColumn取得
        FacesContext ctx = FacesContext.getCurrentInstance();
        DataTable table = (DataTable) ctx.getViewRoot().findComponent(PACK_UNCHIN_DT_ID);
        List<UIColumn> cols = table.getColumns();

        int cnt = 0;
        for (UIColumn col : cols) {
            DynamicColumn dc = (DynamicColumn) col;
            ranks.get(dc.getIndex()).setColOrder(++cnt);
        }
    }

    /**
     * 地図/一覧で選択された都道府県を解除するメソッド
     *
     * @param code
     * @param listnum
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    public void releasePrefectures(String code, int listnum) throws LogicException, SystemException {

        //都道府県地図／一覧の要素取得
        EstimatePackCityPrefectures city = getPrefectures(code, listnum);

        //都道府県要素初期化
        if (city != null) {
            city.setRank(null);
            city.setColor(null);
        }
    }

    /**
     * 「設定中」のランク返却するメソッド
     *
     * @param listnum
     * @return rank object
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    public EstimatePackRank getSelectRank() throws LogicException, SystemException {

        EstimatePackRank result = null;
        for (EstimatePackRank rank : ranks) {
            if (rank.getSelected()) {
                result = rank;
                break;
            }
        }
        return result;
    }

    /**
     * 「設定中」以外のリストから、クリックする県を削除
     *
     * @param listnum
     * @return rank object
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    public void deleteUnSelect(String code) throws LogicException, SystemException {

        // 地図クリックの時は、設定中以外の着地リストから削除する
        for (EstimatePackRank rank : ranks) {
            if (!rank.getSelected()) {
                List<String> cities = rank.getCities();
                // 着地リストから削除
                for (String targetCity : cities) {
                    String[] cityProperty = targetCity.split(":");
                    if (cityProperty[0].equals(code)) {
                        cities.remove(targetCity);
                    }
                }
            }
        }
    }

    /**
     * 指定された都道府県を返却するメソッド
     *
     * @param code
     * @param listnum
     * @return prefectures info
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    private EstimatePackCityPrefectures getPrefectures(String code, int listnum) throws LogicException, SystemException {

        EstimatePackCityPrefectures result = null;
        getPackInfo();

        if ((listnum == 0 && result == null) || listnum == 1) {
            for (EstimatePackCityPrefectures city : prefectures1) {
                if (city.getJisCode().equals(code)) {
                    result = city;
                    break;
                }
            }
        }
        if ((listnum == 0 && result == null) || listnum == 2) {
            for (EstimatePackCityPrefectures city : prefectures2) {
                if (city.getJisCode().equals(code)) {
                    result = city;
                    break;
                }
            }
        }
        if ((listnum == 0 && result == null) || listnum == 3) {
            for (EstimatePackCityPrefectures city : prefectures3) {
                if (city.getJisCode().equals(code)) {
                    result = city;
                    break;
                }
            }
        }
        return result;
    }

    /**
     * 都道府県リストに初期値をセットするメソッド
     *
     * @param list1
     * @param list2
     * @param list3
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    public void initPackPrefectures()
            throws LogicException, SystemException {

        List<EstimatePackCityPrefectures> list1 = new ArrayList<>();
        list1.add(new EstimatePackCityPrefectures("01", "北海道", null, null, false));
        list1.add(new EstimatePackCityPrefectures("02", "青森県", null, null, false));
        list1.add(new EstimatePackCityPrefectures("03", "岩手県", null, null, false));
        list1.add(new EstimatePackCityPrefectures("04", "宮城県", null, null, false));
        list1.add(new EstimatePackCityPrefectures("05", "秋田県", null, null, false));
        list1.add(new EstimatePackCityPrefectures("06", "山形県", null, null, false));
        list1.add(new EstimatePackCityPrefectures("07", "福島県", null, null, false));
        list1.add(new EstimatePackCityPrefectures("08", "茨城県", null, null, false));
        list1.add(new EstimatePackCityPrefectures("09", "栃木県", null, null, false));
        list1.add(new EstimatePackCityPrefectures("10", "群馬県", null, null, false));
        list1.add(new EstimatePackCityPrefectures("11", "埼玉県", null, null, false));
        list1.add(new EstimatePackCityPrefectures("12", "千葉県", null, null, false));
        list1.add(new EstimatePackCityPrefectures("13", "東京都", null, null, false));
        list1.add(new EstimatePackCityPrefectures("14", "神奈川県", null, null, false));
        list1.add(new EstimatePackCityPrefectures("15", "新潟県", null, null, false));
        list1.add(new EstimatePackCityPrefectures("16", "富山県", null, null, false));

        List<EstimatePackCityPrefectures> list2 = new ArrayList<>();
        list2.add(new EstimatePackCityPrefectures("17", "石川県", null, null, false));
        list2.add(new EstimatePackCityPrefectures("18", "福井県", null, null, false));
        list2.add(new EstimatePackCityPrefectures("19", "山梨県", null, null, false));
        list2.add(new EstimatePackCityPrefectures("20", "長野県", null, null, false));
        list2.add(new EstimatePackCityPrefectures("21", "岐阜県", null, null, false));
        list2.add(new EstimatePackCityPrefectures("22", "静岡県", null, null, false));
        list2.add(new EstimatePackCityPrefectures("23", "愛知県", null, null, false));
        list2.add(new EstimatePackCityPrefectures("24", "三重県", null, null, false));
        list2.add(new EstimatePackCityPrefectures("25", "滋賀県", null, null, false));
        list2.add(new EstimatePackCityPrefectures("26", "京都府", null, null, false));
        list2.add(new EstimatePackCityPrefectures("27", "大阪府", null, null, false));
        list2.add(new EstimatePackCityPrefectures("28", "兵庫県", null, null, false));
        list2.add(new EstimatePackCityPrefectures("29", "奈良県", null, null, false));
        list2.add(new EstimatePackCityPrefectures("30", "和歌山県", null, null, false));
        list2.add(new EstimatePackCityPrefectures("31", "鳥取県", null, null, false));
        list2.add(new EstimatePackCityPrefectures("32", "島根県", null, null, false));

        List<EstimatePackCityPrefectures> list3 = new ArrayList<>();
        list3.add(new EstimatePackCityPrefectures("33", "岡山県", null, null, false));
        list3.add(new EstimatePackCityPrefectures("34", "広島県", null, null, false));
        list3.add(new EstimatePackCityPrefectures("35", "山口県", null, null, false));
        list3.add(new EstimatePackCityPrefectures("36", "徳島県", null, null, false));
        list3.add(new EstimatePackCityPrefectures("37", "香川県", null, null, false));
        list3.add(new EstimatePackCityPrefectures("38", "愛媛県", null, null, false));
        list3.add(new EstimatePackCityPrefectures("39", "高知県", null, null, false));
        list3.add(new EstimatePackCityPrefectures("40", "福岡県", null, null, false));
        list3.add(new EstimatePackCityPrefectures("41", "佐賀県", null, null, false));
        list3.add(new EstimatePackCityPrefectures("42", "長崎県", null, null, false));
        list3.add(new EstimatePackCityPrefectures("43", "熊本県", null, null, false));
        list3.add(new EstimatePackCityPrefectures("44", "大分県", null, null, false));
        list3.add(new EstimatePackCityPrefectures("45", "宮崎県", null, null, false));
        list3.add(new EstimatePackCityPrefectures("46", "鹿児島県", null, null, false));
        list3.add(new EstimatePackCityPrefectures("47", "沖縄県", null, null, false));

        // 画面に設定する
        this.packForm.setPrefectures1(list1);
        this.packForm.setPrefectures2(list2);
        this.packForm.setPrefectures3(list3);
    }

    /**
     * 市区町村リストに初期値をセットるメソッド
     *
     * @param list
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    public void initPackMunicipalities()
            throws LogicException, SystemException {
        List<EstimatePackCityMunicipality> list = new ArrayList<>();
        list.add(new EstimatePackCityMunicipality("201", "山形市", "A", null, null, "備考メモ"));
        list.add(new EstimatePackCityMunicipality("202", "米沢市", "G", null, null, null));
        list.add(new EstimatePackCityMunicipality("203", "鶴岡市", "I", null, null, "備考メモ"));
        list.add(new EstimatePackCityMunicipality("204", "酒田市", "J", null, null, null));
        list.add(new EstimatePackCityMunicipality("205", "新庄市", "D", null, null, "備考メモ"));
        this.packForm.setMunicipalities(list);
    }

    /**
     * ランク別設定情報に初期値をセットするメソッド
     *
     * @param ranks
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    public void initPackRanks()
            throws LogicException, SystemException {
        List<EstimatePackRank> ranksLst = new ArrayList();
        //ランク別情報初期化
        EstimatePackRank rank = new EstimatePackRank();
        rank.setRankColor(EstimateRankColor.getColor(64));
        rank.setRank("1");
        rank.setSelected(false);
        rank.setRegion("北海道");
        ranksLst.add(rank);
        EstimatePackRank rank1 = new EstimatePackRank();
        rank1.setRank("2");
        rank1.setRankColor(EstimateRankColor.getColor(59));
        rank1.setSelected(true);
        rank1.setRegion("東北");
        ranksLst.add(rank1);
        EstimatePackRank rank2 = new EstimatePackRank();
        rank2.setRank("3");
        rank2.setRankColor(EstimateRankColor.getColor(42));
        rank2.setSelected(false);
        rank2.setRegion("関東");
        ranksLst.add(rank2);
        EstimatePackRank rank3 = new EstimatePackRank();
        rank3.setRank("4");
        rank3.setRankColor(EstimateRankColor.getColor(67));
        rank3.setSelected(false);
        rank3.setRegion("四国");
        ranksLst.add(rank3);
        EstimatePackRank rank4 = new EstimatePackRank();
        rank4.setRank("5");
        rank4.setRankColor(EstimateRankColor.getColor(61));
        rank4.setSelected(false);
        rank4.setRegion("九州");
        ranksLst.add(rank4);
        this.packForm.setRanks(ranksLst);
    }

    /**
     * 料金表に初期値をセットするメソッド
     *
     * @param prices
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    public void initPackPrices()
            throws LogicException, SystemException {

        //料金初期化
        List<List<BigDecimal>> pricesLst = new ArrayList<>();
        List<BigDecimal> rowItem = new ArrayList<>();
        BigDecimal price = new BigDecimal("0");
        rowItem.add(price);
        pricesLst.add(rowItem);
        this.packForm.setPrices(pricesLst);

        //建値初期化 fixme
    }

    /**
     * その他項目設定
     *
     * @param prices
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    public void initpackCommom()
            throws LogicException, SystemException {
        // 地図／一覧
        this.packForm.setPackMapOrList("01");

        // 元払／着払／引取
        this.packForm.setPackMotoChakuHikitoriKbn("元  払");

        // 運賃計算パターン
        this.packForm.setSelectKeisanPtn("01");
        List<SelectItem> patn = new ArrayList();
        patn.add(new SelectItem("01", "パターン１"));
        patn.add(new SelectItem("02", "パターン２"));
        this.packForm.setPackUnchinKeisanPtn(patn);

        // 発着地域リストセット
        this.packForm.setSelectChakuchiiki("01");
        List<SelectItem> ckc = new ArrayList();
        ckc.add(new SelectItem("01", "着地１"));
        ckc.add(new SelectItem("02", "着地２"));
        this.packForm.setPackHattiOrChakuchiiki(ckc);

        // 発着同じ住所
        this.packForm.setPackHatsuChakuDoJusho(false);

        // 往復同一料金
        this.packForm.setPackOfukuDoRyokin(false);

        // 料金表ドラッグ＆ドロップモード
        this.packForm.setDraggableColumns(false);

        // 運賃グリッド列
        List<EstimateColumnModel> collist = new ArrayList<>();
        collist.add(new EstimateColumnModel("dumy", "dumy"));
        collist.add(new EstimateColumnModel("dumy2", "dumy2"));
        collist.add(new EstimateColumnModel("dumy3", "dumy3"));
        collist.add(new EstimateColumnModel("dumy4", "dumy4"));
        collist.add(new EstimateColumnModel("dumy5", "dumy5"));
        this.packForm.setColumns(collist);

        //運賃表示長さ
        this.packForm.setUnchinWidth(1000);

        this.colorList = new HashMap<>();
    }

    /**
     * パック情報をObjectValuesから取得するメソッド(SSNavi乗せ換え対応のため)
     *
     * @param obj
     * @param tabindex
     * @param regindex
     * @return pack
     * @throws jp.co.sharedsys.wbb.jsf.exception.LogicException logic
     * @throws jp.co.sharedsys.wbb.jsf.exception.SystemException system
     */
    private void getPackInfo() throws LogicException, SystemException {

        //ランク別設定
        ranks = this.packForm.getRanks();
        //動的な列生成用
        columns = this.packForm.getColumns();
        //建値設定設定
//      pricePatterns = (List<EstimatePackPricePattern>) pack.get("pricePatterns");
        //料金設定
        prices = this.packForm.getPrices();
        //都道府県リスト１
        prefectures1 = this.packForm.getPrefectures1();
        //都道府県リスト２
        prefectures2 = this.packForm.getPrefectures2();
        //都道府県リスト３
        prefectures3 = this.packForm.getPrefectures3();
        //市区町村リスト
        municipalities = this.packForm.getMunicipalities();
        //運賃テーブル幅
        unchinWidth = this.packForm.getUnchinWidth();
        //料金表ドラッグ＆ドロップモード
        draggableColumns = this.packForm.isDraggableColumns();

    }

}
