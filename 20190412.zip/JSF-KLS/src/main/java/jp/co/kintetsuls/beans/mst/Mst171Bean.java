/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.KbnBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiListCol;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst171Form;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 荷受人/荷送人マスタ画面
 *
 * @author 張誠(MBP)
 * @version 2019/3/18 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst171")
@ViewScoped
@Data
public class Mst171Bean extends AbstractBean {

    /**
     * 荷受人タイトル
     */
    private final String TITLE1 = "荷受人マスタ";

    /**
     * 荷送人タイトル
     */
    private final String TITLE2 = "荷送人マスタ";

    /**
     * 荷受人ダウンロードファイル名
     */
    private final String FILE_NAME1 = "荷受人マスタ一覧";

    /**
     * 荷送人ダウンロードファイル名
     */
    private final String FILE_NAME2 = "荷送人マスタ一覧";

    /**
     * 画面URL
     */
    private String url;

    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * ログインユーザー情報
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

    /**
     * 共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * 検索シーケンス処理共通
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;

    /**
     * 履歴一覧処理共通
     */
    @ManagedProperty(value = "#{rirekisyosai}")
    private RirekiSyosaiBean rirekiSyosaiBean;

    /**
     * E2コード定義取得Bean
     */
    @ManagedProperty(value = "#{kbnBean}")
    private KbnBean kbnBean;

    /**
     * ファイルダウンロード
     */
    @ManagedProperty(value = "#{fileBean}")
    private FileBean fileBean;

    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(
    new Object() {}.getClass().getEnclosingClass().getName());

    /**
     * 住所マスタ フォーム
     */
    @ManagedProperty(value = "#{mst171Form}")
    private Mst171Form mst171Form;

    /**
     * 定数：一覧のデータテーブルID
     */
    private static final String DATA_TABLE_ID = "tablesorter_mst171";

    /**
     * スクリーンコード：MST031
     */
    private static final String SC_CD_MST171 = "MST171_SCREEN";

    /**
     * 定数：画面項目保持キー
     */
    private static final String CONST_MST171_FORM = "mst171Form";

    /**
     * 定数：再検索Button取得キー
     */
    private static final String CONST_MST171_SEARCH = "search_mst171";

    /**
     * 定数：検索件数取得ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH_KENSU = "mst171-get-kensu";

    /**
     * 定数：検索ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH = "mst171-get-detail";

    /**
     * 定数：削除ファンクションコード
     */
    private static final String FUNC_CODE_DELETE = "mst171_delete";

    /**
     * 定数：複写ファンクションコード
     */
    private static final String FUNC_CODE_FUKUSHA = "mst171_fukusha";

    /**
     * 定数：複写ファンクションコード
     */
    private static final String FUNC_CODE_IKKATUTOROKU = "mst171_ikkatutoroku";

    /**
     * コンストラクタ
     */
    public Mst171Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId クリックされたメニューID（メニューからの遷移以外はNULL）
     * @param prevScreen 遷移元の画面
     * @param backFlag 戻るフラグ（前画面へボタンからの遷移以外はFALSE）
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            // タイトル設定
            if ("1".equals(mst171Form.getConNiukeNiokurininMode())) {
                // パンくず追加
                breadBean.push(TITLE1, SCREEN.MST171_SCREEN.name(), this);
            } else {
                // パンくず追加
                breadBean.push(TITLE2, SCREEN.MST171_SCREEN.name(), this);
            }

            // 1)システムマスタ取得
            pageCommonBean.getMasterInfo(MsCnst.SYS_CDGROUP_MST171);

            // 検索シーケンス処理を初期化する
            searchHelpBean.regSearchHelp(DATA_TABLE_ID,
                    s -> {return count(false);},
                    s -> { search(); return null;},
                    s -> {if (!searchCheck()) {
                            return "FALSE";
                         } else {
                            return "TRUE";
                        }
                    });
            searchHelpBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);

            // DBからマスタの内容を取得
            // ワーク.営業所リスト
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO, new AutoCompOptionBean("全て", "all"));
            // ワーク.顧客リスト
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_KOKYAKU);

            // 並び順初期値を設定する
            mst171Form.setConSortJun(kbnBean.getKbnCdOfKeyCd(MsCnst.NIUKENIN_MST_KENSAKUJOKEN_NARABIJUN_CODEJUN));

            // 前回の記録をクリアする
            this.clear();
            mst171Form.setSearchResult(null);
            mst171Form.setSearchResultSelectable(null);
            mst171Form.setSelectedSearchResult(null);

            Mst171Form preForm = (Mst171Form) pageCommonBean.getPageInfo("mst171Form");
            // 戻ってきた場合
            if (backFlag && preForm != null) {
                PageCommonBean.simpleCopy(preForm, mst171Form);
                // 再検索を実施する
                pageCommonBean.searchAgain(CONST_MST171_SEARCH);
            } else {
                // 進んできた場合
                Flash flash = pageCommonBean.getPageParam();
                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_MST171_FORM) != null) {
                    PageCommonBean.simpleCopy(flash.get(CONST_MST171_FORM), mst171Form);
                    // 再検索を実施する
                    pageCommonBean.searchAgain(CONST_MST171_SEARCH);
                }
            }

            // ダウンロードシーケンスを初期化する
            fileBean.setDataSize(DATA_TABLE_ID, (id -> {return count(true);}));
            fileBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);
            if ("1".equals(mst171Form.getConNiukeNiokurininMode())) {
                fileBean.setTilte(FILE_NAME1);
            } else {
                fileBean.setTilte(FILE_NAME2);
            }

            fileBean.regDownloadFucntion(DATA_TABLE_ID, getHeader(), (id -> {return getList(true);}));
            fileBean.regBeforeDownFucntion(DATA_TABLE_ID, (comment -> {return beforeDown(comment);}));
            fileBean.setSearchResult(DATA_TABLE_ID, (id -> {return getSearchResult();}));

            // component初期化とユーザ権限により制御を設定する
            pageCommonBean.setAuthControll(mst171Form, SC_CD_MST171, true);
            // ボタン制御
            bottonControl(false);

        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * 複写有無チェック
     *
     * @return 正常／異常
     */
    public boolean searchCheck() {

        // 営業所コード退避
        mst171Form.setConEigyoshoCdTaihi(mst171Form.getConEigyoshoCd().getValue());
        // 顧客コード退避
        mst171Form.setConKokyakuCdTaihi(mst171Form.getConKokyakuCd().getValue());
        // 未使用期間（月）退避
        mst171Form.setConMishiyoKikanTsukiTaihi(mst171Form.getConMishiyoKikanTsuki());

        if (mst171Form.getConHKokyakuCdTaihi() != null && !"".equals(mst171Form.getConHKokyakuCdTaihi().trim())) {
            // 確認ダイアログを表示する      
            pageCommonBean.executeScript("km.showConfirmDialog('mst171DialogSearch')");
            return false;

        }
        return true;
    }

    /**
     * カウント処理
     *
     * @param downloadFlg ダウンロードフラグ
     * @return 件数
     */
    public long count(boolean downloadFlg) {

        // 前回の記録をクリアする
        Map<String, Object> mapRec = new LinkedHashMap();
        mapRec.put("hideFlg", "hideRow");
        List<Map<String, Object>> mapList = new ArrayList();
        mapList.add(mapRec);
        mst171Form.setSearchResult(mapList);
        mst171Form.setSearchResultSelectable(new ReportListDataModel(mst171Form.getSearchResult()));
        mst171Form.setSelectedSearchResult(null);

        // 件数取得処理
        long kensu = getKensu(downloadFlg);

        // サブ検索条件フラグ設定
        fileBean.setSubFlg(subSearchConHad());

        if (!downloadFlg) {

            // 検索部のステータスを変更する
            pageCommonBean.setSerchConDisabled(mst171Form);

            // 検索条件保存
            pageCommonBean.savePageInfo(CONST_MST171_FORM, mst171Form);
        }

        return kensu;
    }

    /**
     * 複写後の再検索
     *
     */
    public void fukushaAtoSearch() {
        // 顧客コードクリア(Hidden)
        mst171Form.setConHKokyakuCdTaihi("");
        // 再検索を実施する
        pageCommonBean.searchAgain(CONST_MST171_SEARCH);
    }

    /**
     * 検索処理
     *
     */
    public void search() {

        // 選択リストを初期化する
        mst171Form.setSelectedSearchResult(new ArrayList<>());

        // 一覧情報を検索する
        List<Map<String, Object>> recordList = getList(false);
        if (recordList == null) {
            return;
        }
        
        // 配色定義を設定する
        setIchiranColor(recordList);
        
        fileBean.setDataList(recordList);

        // 取得した値を画面項目にセットする
        pageCommonBean.setDatalist(DATA_TABLE_ID, recordList);
        mst171Form.setSearchResultSelectable(new ReportListDataModel(recordList));

        // 検索部のステータス変更
        pageCommonBean.setSerchConDisabled(mst171Form);

        // ボタン制御
        bottonControl(false);
    }

    /**
     * 検索条件変更処理
     *
     */
    public void searchChange() {

        // 検索部のステータスを変更する
        pageCommonBean.setSerchConEnabled(mst171Form);
    }

    /**
     * クリア処理
     *
     */
    public void clear() {

        // 検索部の条件をクリア
        mst171Form.setConEigyoshoCd(null);
        mst171Form.setConKokyakuCd(null);
        // 荷受人/荷送人モード判定
        if ("1".equals(mst171Form.getConNiukeNiokurininMode())) {
            mst171Form.setConNiukeninHakkoCd(null);
            mst171Form.setConNiukeninMei(null);
            mst171Form.setConNiukeninKanaMei(null);
            mst171Form.setConNiukeninJusho(null);
            mst171Form.setConNiukeninTel(null);
            mst171Form.setConNiukeninKey(null);
        } else {
            mst171Form.setConNiokurininHakkoCd(null);
            mst171Form.setConNiokurininMei(null);
            mst171Form.setConNiokurininKanaMei(null);
            mst171Form.setConNiokurininJusho(null);
            mst171Form.setConNiokurininTel(null);
            mst171Form.setConNiokurininKey(null);
        }
        mst171Form.setConSortJun(null);
        mst171Form.setConYoshuseiNomi(null);
        mst171Form.setConKyuJushoHyoji(null);
        mst171Form.setConMishiyoKikanNen(null);
        mst171Form.setConMishiyoKikanTsuki(null);
        mst171Form.setConSakujozumiFukumu(null);

        // 並び順初期値を設定する
        mst171Form.setConSortJun(kbnBean.getKbnCdOfKeyCd(MsCnst.NIUKENIN_MST_KENSAKUJOKEN_NARABIJUN_CODEJUN));

        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mst171Form);
        pageCommonBean.setBtnSearchChangeVisible(false);
        pageCommonBean.setBtnSearchVisible(true);
    }

    /**
     * 画面遷移処理 (新規追加）
     *
     * @return 遷移先の画面URL
     */
    public String shinkiToroku() {

        // 遷移画面パラメータ設定
        Flash flash = pageCommonBean.getPageParam();

        // 荷受人/荷送人モード
        flash.put("conNiukeNiokurininMode", mst171Form.getConNiukeNiokurininMode());
        // 参照/編集/新規モード
        flash.put("conSanshoHenshuShinkiMode", "2");
        // 検索条件顧客コード
        if (mst171Form.getConKokyakuCd() != null) {
            flash.put("kokyakuCd", mst171Form.getConKokyakuCd().getValue());
        }

        // 仕入予定詳細画面に遷移する
        url = forward(SCREEN.MST172_SCREEN.name(), null, SCREEN.MST171_SCREEN.name(), false);
        return url;
    }

    /**
     * 画面遷移処理 (複写登録)
     *
     * @return 遷移先の画面URL
     */
    public String copyToroku() {

        // 行選択データ
        List<Map<String, Object>> selectedRecordList = mst171Form.getSelectedSearchResult();
        // 行選択チェック
        if (selectedRecordList == null || selectedRecordList.isEmpty()) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0022);
            return null;
        }
        // 複数選択チェック
        if (selectedRecordList.size() > 1) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0020);
            return null;
        }

        //遷移画面パラメータ設定
        Flash flash = pageCommonBean.getPageParam();

        // 荷受人/荷送人モード
        flash.put("conNiukeNiokurininMode", mst171Form.getConNiukeNiokurininMode());
        // 参照/編集/新規モード
        flash.put("conSanshoHenshuShinkiMode", "2");
        // 荷受人発行コード / 荷送人発行コード
        if ("1".equals(mst171Form.getConNiukeNiokurininMode())) {
            flash.put("dtlNiukeninHakkoCd", selectedRecordList.get(0).get("listNiukeninHakkoCd").toString());
        } else {
            flash.put("dtlNiokurininHakkoCd", selectedRecordList.get(0).get("listNiokurininHakkoCd").toString());
        }
        // 検索条件顧客コード
        if (mst171Form.getConKokyakuCd() != null) {
            flash.put("kokyakuCd", mst171Form.getConKokyakuCd().getValue());
        }
        // 顧客コード
        flash.put("dtlKokyakuCd", selectedRecordList.get(0).get("listKokyakuCd").toString());

        // 仕入予定詳細画面に遷移する
        url = forward(SCREEN.MST172_SCREEN.name(), null, SCREEN.MST171_SCREEN.name(), false);
        return url;
    }

    /**
     * 削除コンテキストメニュー／削除ボタンクリック処理
     *
     * @param buttonFlg 詳細ボタンクリックフラグ(true:削除ボタンクリック)
     */
    public void deleteRecord(boolean buttonFlg) {

        // 行選択データ
        List<Map<String, Object>> selectedRecordList = mst171Form.getSelectedSearchResult();
        // 詳細ボタンクリックの場合、チェックを行う
        if (buttonFlg) {
            // 行選択チェック
            if (selectedRecordList == null || selectedRecordList.isEmpty()) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0013);
                return;
            }
        }

        pageCommonBean.executeScript("km.showConfirmDialog('mst171DialogDelRows')");
    }

    /**
     * DBから一覧情報を削除する
     *
     */
    public void deleteRows() {

        // 行選択データ
        List<Map<String, Object>> recordList = mst171Form.getSelectedSearchResult();

        // パラメータ
        Map<String, Object> params = new HashMap<>();
        // 荷受人/荷送人モード
        params.put("conNiukeNiokurininMode", mst171Form.getConNiukeNiokurininMode());
        // 選択データ
        params.put("recordList", recordList);
        // DBをアクセス
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, FUNC_CODE_DELETE);

        // エラーの場合、処理を終了
        if (serviceInterfaceBean.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            // 排他エラー            
            messagePropertyBean.message(serviceInterfaceBean.getMessages().get(0)[0],
                    serviceInterfaceBean.getMessages().get(0)[1],
                    serviceInterfaceBean.getMessages().get(0)[2],
                    serviceInterfaceBean.getTableName());
            return;
        }

        // 再検索を実施する
        pageCommonBean.searchAgain(CONST_MST171_SEARCH);
        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, "更新");

    }

    /**
     * 他顧客コードからの一括複写
     *
     */
    public void takokyakuCdKaraIkkatsuFukusha() {

        // 営業所コード
        if (mst171Form.getConEigyoshoCdTaihi() == null || "".equals(mst171Form.getConEigyoshoCdTaihi())) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "営業所コード");
            return;
        }
        // 顧客コード
        if (mst171Form.getConKokyakuCdTaihi() == null || "".equals(mst171Form.getConKokyakuCdTaihi())) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "顧客コード");
            return;
        }
        // 複写元選択ダイアログ画面初期化
        // 顧客コード
        mst171Form.setConHKokyakuCd("");
        mst171Form.setConHKokyakuCdTaihi("");
        // 顧客名称 
        mst171Form.setListKokyakuMei("");

        // 複写元選択ダイアログ画面表示
        pageCommonBean.executeScript("PF('widFukusha').show();");
    }

    /**
     * 閉じるボタンを押す
     *
     */
    public void gamenHidenKakunin() {
        // 確認ダイアログを表示する      
        pageCommonBean.executeScript("km.showConfirmDialog('mst171DialogClose')");
    }

    /**
     * 複写元選択ダイアログ画面閉じる
     *
     */
    public void gamenHiden() {
        // 顧客コードクリア(Hidden)
        mst171Form.setConHKokyakuCdTaihi("");
        // 顧客コードクリア
        mst171Form.setConHKokyakuCd("");
        // 確認ダイアログを表示する      
        pageCommonBean.executeScript("PF('widFukusha').hide();");
    }

    /**
     * 複写を押す
     *
     */
    public void fukusha() {
        if (mst171Form.getConHKokyakuCd() == null || "".equals(mst171Form.getConHKokyakuCd())) {
            return;
        }
        // 入力項目チェック
        if (mst171Form.getConHKokyakuCd().equals(mst171Form.getConKokyakuCdTaihi())) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MSTE0002, "顧客コード");
            return;
        }
        // パラメータ
        Map<String, Object> params = new HashMap<>();
        // 荷受人/荷送人モード
        params.put("conNiukeNiokurininMode", mst171Form.getConNiukeNiokurininMode());
        // 顧客コード
        params.put("conHKokyakuCd", mst171Form.getConHKokyakuCd());
        // ログインユーザー所属営業所
        params.put("shozokuEigyoshoCd", authConfBean.getLoginUserShozokuEigyosho());
        List<Map<String, Object>> recordList = null;
        try {
            // DBをアクセス
            ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_FUKUSHA);

            // エラーの場合、処理を終了
            if (res.getStatusCode() == res.PROCESS_STATUS_ERROR) {
                messagePropertyBean.message(res.getMessages().get(0)[0],
                        res.getMessages().get(0)[1],
                        res.getMessages().get(0)[2],
                        res.getTableName());
                return;
            }
            ObjectMapper mapper = new ObjectMapper();
            recordList = mapper.readValue(res.getJson(), List.class);
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return;
        }
        mst171Form.setSearchResult(recordList);
        // 取得した値を画面項目にセットする
        pageCommonBean.setDatalist(DATA_TABLE_ID, recordList);
        mst171Form.setSelectedSearchResult(null);
        mst171Form.setSearchResultSelectable(new ReportListDataModel(recordList));
        bottonControl(true);
    }

    /**
     * ボタン制御
     *
     * @param disabled
     */
    public void bottonControl(boolean disabled) {
        // 新規登録ボタン非活性   
        mst171Form.setBtnShinkiTorokuDisabled(disabled);
        // 複写登録ボタン非活性   
        mst171Form.setBtnFukushaTorokuDisabled(disabled);
        // 詳細ボタン非活性   
        mst171Form.setBtnShosaiDisabled(disabled);
        // 削除ボタン非活性   
        mst171Form.setBtnSakujoDisabled(disabled);
        // ダウンロードボタン非活性   
        //mst171Form.setBtnDownloadDisabled(disabled);
        // アップロードボタン非活性   
        mst171Form.setBtnUploadDisabled(disabled);
        // 他顧客コードからの一括複写ボタン非活性   
        mst171Form.setBtnTakokyakuCdKaraIkkatsuFukushaDisabled(disabled);
        // 一括登録ボタン活性   
        mst171Form.setBtnIkkatsuTorokuDisabled(!disabled);
        // 取消ボタン活性   
        mst171Form.setBtnTorikeshiDisabled(!disabled);

    }

    /**
     * 一括登録
     *
     */
    public void ikkatsuToroku() {
        // 営業所コード
        if (mst171Form.getConEigyoshoCdTaihi() == null || "".equals(mst171Form.getConEigyoshoCdTaihi())) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "営業所コード");
            return;
        }
        // 顧客コード
        if (mst171Form.getConKokyakuCdTaihi() == null || "".equals(mst171Form.getConKokyakuCdTaihi())) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "顧客コード");
            return;
        }
        // 未使用期間（月）
        if (!(mst171Form.getConMishiyoKikanTsukiTaihi() == null || "".equals(mst171Form.getConMishiyoKikanTsukiTaihi()))) {
            if (Integer.valueOf(mst171Form.getConMishiyoKikanTsukiTaihi()) > 11
                    || Integer.valueOf(mst171Form.getConMishiyoKikanTsukiTaihi()) < 1) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0026, "1", "11");
                return;
            }
        }
        // パラメータ
        Map<String, Object> params = new HashMap<>();
        // 荷受人/荷送人モード
        params.put("conNiukeNiokurininMode", mst171Form.getConNiukeNiokurininMode());
        // 複写元顧客コード
        params.put("conHKokyakuCd", mst171Form.getConHKokyakuCd());
        // 顧客コード
        params.put("conKokyakuCd", mst171Form.getConKokyakuCdTaihi());
        // 営業所コード
        params.put("conEigyoshoCd", mst171Form.getConEigyoshoCdTaihi());
        // 全営業所検索
        params.put("allEigyoshoSearch", pageCommonBean.getMasterInfo().getAllEigyoshoSearch());
        // ログインユーザー所属営業所
        params.put("shozokuEigyoshoCd", authConfBean.getLoginUserShozokuEigyosho());
        // DBをアクセス
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, FUNC_CODE_IKKATUTOROKU);

        // エラーの場合、処理を終了
        if (serviceInterfaceBean.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            messagePropertyBean.message(serviceInterfaceBean.getMessages().get(0)[0],
                    serviceInterfaceBean.getMessages().get(0)[1],
                    serviceInterfaceBean.getMessages().get(0)[2]);
            return;
        }
        // 顧客コード（Hidden）
        mst171Form.setConHKokyakuCdTaihi("");
        // ボタン制御
        bottonControl(false);
        pageCommonBean.searchAgain(CONST_MST171_SEARCH);
        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, "登録");
    }

    /**
     * 取消ボタンを押す確認
     *
     */
    public void torikeshiKakunin() {
        // 確認ダイアログを表示する      
        pageCommonBean.executeScript("km.showConfirmDialog('mst171DialogTorikeshi')");
    }

    /**
     * 取消処理
     *
     */
    public void torikeshi() {
        // 顧客コードクリア(Hidden)
        mst171Form.setConHKokyakuCdTaihi("");
        bottonControl(false);
        // 一覧情報を検索する
        pageCommonBean.searchAgain(CONST_MST171_SEARCH);
    }

    /**
     * アップロード
     *
     * @return 遷移先画面のURL
     */
    public String upload() {

        // flash初期化
        Flash flash = pageCommonBean.getPageParam();

        // flashにアップロード機能コードを設定する
        if ("1".equals(mst171Form.getConNiukeNiokurininMode())) {
            flash.put("uploadFunctionCd", TITLE1);
        } else {
            flash.put("uploadFunctionCd", TITLE2);
        }

        // アップロード画面へ遷移
        url = forward(SCREEN.UPLOAD_SCREEN.name(), null, SCREEN.MST171_SCREEN.name(), false);
        return url;
    }

    /**
     * メニュークリック（処理）
     *
     * @param menuId クリックされたメニューID（メニューからの遷移以外はNULL）
     * @param nextScreen 遷移先の画面
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック（処理）
     *
     * @param nextScreen 遷移先の画面
     * @param breadIndex 選択されたパンくずのIndex
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        url = forward(nextScreen, null, null, true);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authConfBean.logout();
    }

    /**
     * 詳細コンテキストメニュー／詳細ボタンクリック処理
     *
     * @param buttonFlg 詳細ボタンクリックフラグ(true:詳細ボタンクリック)
     * @return 遷移先の画面URL
     */
    public String detailClick(boolean buttonFlg) {

        // 行選択データ
        List<Map<String, Object>> selectedRecordList = mst171Form.getSelectedSearchResult();
        // 詳細ボタンクリックの場合、チェックを行う
        if (buttonFlg) {

            // 行選択チェック
            if (selectedRecordList == null || selectedRecordList.isEmpty()) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0022);
                return null;
            }
            // 複数選択チェック
            if (selectedRecordList.size() > 1) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0020);
                return null;
            }
        }

        // 選択されたレコードを取得する
        Map<String, Object> selectedRecord = selectedRecordList.get(0);

        // パラメータを設定する
        String hakkoCd = "";
        // 荷受人発行コード / 荷送人発行コード
        if ("1".equals(mst171Form.getConNiukeNiokurininMode())) {
            hakkoCd = selectedRecord.get("listNiukeninHakkoCd").toString();
        } else {
            hakkoCd = selectedRecord.get("listNiokurininHakkoCd").toString();
        }

        setMst172Param(mst171Form.getConNiukeNiokurininMode(), selectedRecord.get("listJieigyoshoFlg").toString(),
                hakkoCd, selectedRecord.get("listKokyakuCd").toString());

        // 画面遷移
        url = forward(SCREEN.MST172_SCREEN.name(), null, SCREEN.MST171_SCREEN.name(), false);
        return url;
    }

    /**
     * 発行コードリンククリック処理
     *
     * @param hakkoCd 荷受人発行コード/荷送人発行コード
     * @param kokyakuCd 顧客コード
     * @param jieigyoshoFlg 自営業所フラグ
     * @return 遷移先の画面URL
     */
    public String linkClick(String hakkoCd, String kokyakuCd, String jieigyoshoFlg) {

        // パラメータを設定する
        setMst172Param(mst171Form.getConNiukeNiokurininMode(), jieigyoshoFlg, hakkoCd, kokyakuCd);

        // 画面遷移
        url = forward(SCREEN.MST172_SCREEN.name(), null, SCREEN.MST171_SCREEN.name(), false);
        return url;
    }

    /**
     * 住所マスタ履歴を表示処理
     *
     */
    public void rirekiIchiran() {

        // 履歴テーブル検索キーを設定する
        Map<String, Object> rirekiSearchKey = new HashMap();

        // 選択されたレコードを取得する
        Map<String, Object> selectedRecord = mst171Form.getSelectedSearchResult().get(0);

        // 荷受人/荷送人モード
        rirekiSearchKey.put("conNiukeNiokurininMode", mst171Form.getConNiukeNiokurininMode());
        // 営業所コード
        rirekiSearchKey.put("conEigyoshoCd", mst171Form.getConEigyoshoCdTaihi());
        // 顧客コード
        rirekiSearchKey.put("conKokyakuCd", mst171Form.getConKokyakuCdTaihi());
        // 複写元顧客コード
        rirekiSearchKey.put("conHKokyakuCd", mst171Form.getConHKokyakuCd());
        // 全営業所検索
        rirekiSearchKey.put("allEigyoshoSearch", pageCommonBean.getMasterInfo().getAllEigyoshoSearch());
        // ログインユーザー所属営業所
        rirekiSearchKey.put("shozokuEigyoshoCd", authConfBean.getLoginUserShozokuEigyosho());
        // 荷受人発行コード / 荷送人発行コード
        String hakkoCd = "";
        String hakkoCdName = "";
        String hakkoCdValue = "";
        String hakkoCdNameValue = "";
        if ("1".equals(mst171Form.getConNiukeNiokurininMode())) {
            hakkoCd = "荷受人発行コード";
            hakkoCdName = "荷受人名称";
            hakkoCdValue = "listNiukeninHakkoCd";
            hakkoCdNameValue = "listNiukeninMei";
            // 荷受人発行コード
            rirekiSearchKey.put("listNiukeninHakkoCd", selectedRecord.get("listNiukeninHakkoCd"));
        } else {
            hakkoCd = "荷受人発行コード";
            hakkoCdName = "荷送人名称";
            hakkoCdValue = "listNiokurininHakkoCd";
            hakkoCdNameValue = "listNiokurininMei";
            // 荷受人発行コード
            rirekiSearchKey.put("listNiokurininHakkoCd", selectedRecord.get("listNiokurininHakkoCd"));
        }

        // 履歴タイトルを設定する
        rirekiSyosaiBean.setListColName(new ArrayList<>(Arrays.asList(
                "バージョン情報",
                hakkoCd,
                hakkoCdName,
                "カナ名称",
                "住所",
                "旧住所",
                "電話番号",
                "検索キー",
                "記事有無",
                "最終使用日",
                "エラー内容")));
        // 履歴beanの項目物理名を設定する
        List<String> colValue = new ArrayList<>(Arrays.asList(
                "listDataVersion",
                hakkoCdValue,
                hakkoCdNameValue,
                "listKanaMei",
                "listJusho",
                "listKyuJusho",
                "listTel",
                "listKensakuKey",
                "listKijiUmu",
                "listSaishuShiyobi",
                "listErrorNaiyo"));
        List<String> colAlign = new ArrayList<>(Arrays.asList(
                "left",
                "center",
                "left",
                "left",
                "left",
                "center",
                "center",
                "left",
                "center",
                "center",
                "center"));
        List<RirekiListCol> listCol = new ArrayList<>();
        for (int i = 0; i < colValue.size(); i++) {
            RirekiListCol col = new RirekiListCol();
            col.setColValue(colValue.get(i));
            col.setColAlign(colAlign.get(i));
            listCol.add(col);
        }
        rirekiSyosaiBean.setListCol(listCol);

        // 履歴テーブルを検索する
        rirekiSyosaiBean.searchList("2", "MST171_SEARCH_RIREKI", rirekiSearchKey);
    }

    /**
     * CSVファイルのタイトルを設定する処理
     *
     * @return 画面タイトル
     */
    public List<CSVDto> getHeader() {

        // CSVファイルのタイトルを設定する
        List<CSVDto> header = new ArrayList<>();
        // 荷受人発行コード / 荷送人発行コード
        if ("1".equals(mst171Form.getConNiukeNiokurininMode())) {
            header.add(new CSVDto("荷受人発行コード", "listNiukeninHakkoCd"));
            header.add(new CSVDto("荷受人名称", "listNiukeninMei"));
        } else {
            header.add(new CSVDto("荷送人発行コード", "listNiokurininHakkoCd"));
            header.add(new CSVDto("荷送人名称", "listNiokurininMei"));
        }

        header.add(new CSVDto("カナ名称", "listKanaMei"));
        header.add(new CSVDto("住所", "listJusho"));
        header.add(new CSVDto("旧住所", "listKyuJusho"));
        header.add(new CSVDto("電話番号", "listTel"));
        header.add(new CSVDto("検索キー", "listKensakuKey"));
        header.add(new CSVDto("最終使用日", "listSaishuShiyobi"));
        header.add(new CSVDto("記事有無", "listErrorNaiyo"));

        // 取得値を返却する
        return header;
    }

    /**
     * ダウンロード理由を記録する処理
     *
     * @param comment 理由コメント
     * @return 正常／異常
     * @throws Exception
     */
    public boolean beforeDown(String comment) throws Exception {

        // ダウンロード理由を記録する
        System.out.println(comment);

        return true;
    }

    /**
     * 荷受人マスタ詳細画面へパラメータを設定する
     *
     * @param niukeNiokurininMode 荷受人/荷送人モード(1:荷受人モード/2:荷送人モード)
     * @param sanshoHenshuShinkiMode 参照/編集/新規モード(0:参照/1:編集/2:新規モード)
     * @param hakkoCd 荷受人発行コード/荷送人発行コード
     * @param kokyakuCd 顧客コード
     */
    private void setMst172Param(String niukeNiokurininMode, String sanshoHenshuShinkiMode,
            String hakkoCd, String kokyakuCd) {
        Flash flash = pageCommonBean.getPageParam();
        // 荷受人/荷送人モード
        flash.put("conNiukeNiokurininMode", niukeNiokurininMode);

        // 参照/編集/新規モード
        flash.put("conSanshoHenshuShinkiMode", sanshoHenshuShinkiMode);
        // 荷受人発行コード/荷送人発行コード
        if ("1".equals(niukeNiokurininMode)) {
            flash.put("dtlNiukeninHakkoCd", hakkoCd);
        } else {
            flash.put("dtlNiokurininHakkoCd", hakkoCd);
        }
        // 顧客コード
        flash.put("dtlKokyakuCd", kokyakuCd);
        // 検索条件顧客コード
        if (mst171Form.getConKokyakuCd() != null) {
            flash.put("kokyakuCd", mst171Form.getConKokyakuCd().getValue());
        }
    }

    /**
     * 検索条件を設定する
     *
     * @param downloadFlg ダウンロードフラグ
     * @return 検索条件
     */
    private Map<String, Object> setCondition(boolean downloadFlg) {

        Map<String, Object> params = new HashMap<>();

        Mst171Form tempForm = mst171Form;
        if (downloadFlg) {
            tempForm = (Mst171Form) pageCommonBean.getPageInfo(CONST_MST171_FORM);
        }

        // 荷受人/荷送人モード
        params.put("conNiukeNiokurininMode", tempForm.getConNiukeNiokurininMode());

        // 営業所コード
        params.put("conEigyoshoCd", tempForm.getConEigyoshoCd().getValue());
        // 顧客コード
        params.put("conKokyakuCd", tempForm.getConKokyakuCd().getValue());

        // 荷受人の場合/荷送人の場合
        if ("1".equals(tempForm.getConNiukeNiokurininMode())) {
            // 荷受人発行コード
            params.put("conNiukeninHakkoCd", tempForm.getConNiukeninHakkoCd());
            // 荷受人名称
            params.put("conNiukeninMei", tempForm.getConNiukeninMei());
            // 荷受人カナ名称
            params.put("conNiukeninKanaMei", tempForm.getConNiukeninKanaMei());
            // 荷受人住所
            params.put("conNiukeninJusho", tempForm.getConNiukeninJusho());
            // 荷受人電話番号
            params.put("conNiukeninTel", tempForm.getConNiukeninTel());
            // 荷受人検索キー
            params.put("conNiukeninKey", tempForm.getConNiukeninKey());
        } else {
            // 荷送人発行コード
            params.put("conNiokurininHakkoCd", tempForm.getConNiokurininHakkoCd());
            // 荷送人名称
            params.put("conNiokurininMei", tempForm.getConNiokurininMei());
            // 荷送人カナ名称
            params.put("conNiokurininKanaMei", tempForm.getConNiokurininKanaMei());
            // 荷送人住所
            params.put("conNiokurininJusho", tempForm.getConNiokurininJusho());
            // 荷送人電話番号
            params.put("conNiokurininTel", tempForm.getConNiokurininTel());
            // 荷送人検索キー
            params.put("conNiokurininKey", tempForm.getConNiokurininKey());

        }

        // 並び順
        params.put("conSortJun", tempForm.getConSortJun());
        // 要修正分のみ
        if (tempForm.getConYoshuseiNomi() != null && tempForm.getConYoshuseiNomi().length > 0) {
            params.put("conYoshuseiNomi", tempForm.getConYoshuseiNomi()[0]);
        } else {
            params.put("conYoshuseiNomi", "0");
        }
        // 旧住所警告分も表示する 
        if (tempForm.getConKyuJushoHyoji() != null && tempForm.getConKyuJushoHyoji().length > 0) {
            params.put("conKyuJushoHyoji", tempForm.getConKyuJushoHyoji()[0]);
        } else {
            params.put("conKyuJushoHyoji", "0");
        }
        // 未使用期間（年）
        params.put("conMishiyoKikanNen", tempForm.getConMishiyoKikanNen());
        // 未使用期間（年）
        params.put("conMishiyoKikanTsuki", tempForm.getConMishiyoKikanTsuki());
        // 削除済みを含む
        if (tempForm.getConSakujozumiFukumu() != null && tempForm.getConSakujozumiFukumu().length > 0) {
            params.put("conSakujozumiFukumu", tempForm.getConSakujozumiFukumu()[0]);
        } else {
            params.put("conSakujozumiFukumu", "0");
        }

        // 全営業所検索
        params.put("allEigyoshoSearch", pageCommonBean.getMasterInfo().getAllEigyoshoSearch());
        // ログインユーザー所属営業所
        params.put("shozokuEigyoshoCd", authConfBean.getLoginUserShozokuEigyosho());

        return params;
    }

    /**
     * 検索条件に一致するデータ件数の取得を行う
     *
     * @param downloadFlg ダウンロードフラグ
     */
    private long getKensu(boolean downloadFlg) {

        // パラメータ
        Map<String, Object> params = setCondition(downloadFlg);
        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH_KENSU);

        return Long.valueOf(res.getJson());
    }

    /**
     * 検索条件に一致するデータの取得を行う
     *
     * @param downloadFlg ダウンロードフラグ
     */
    private List<Map<String, Object>> getList(boolean downloadFlg) {

        // パラメータ
        Map<String, Object> params = setCondition(downloadFlg);

        try {
            // DBをアクセス
            ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH);
            ObjectMapper mapper = new ObjectMapper();
            mst171Form.setSearchResult(mapper.readValue(res.getJson(), List.class));
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
        return mst171Form.getSearchResult();
    }

    /**
     * サブ検索条件入力判断
     *
     * @return true:入力あり/false:入力しない
     */
    public boolean subSearchConHad() {

        // 未使用期間（年）
        if (mst171Form.getConMishiyoKikanNen() != null && !"".equals(mst171Form.getConMishiyoKikanNen().trim())) {
            return true;
        }
        // 未使用期間（年）
        if (mst171Form.getConMishiyoKikanTsuki() != null && !"".equals(mst171Form.getConMishiyoKikanTsuki().trim())) {
            return true;
        }
        // 削除済みを含む
        if (mst171Form.getConSakujozumiFukumu() != null && mst171Form.getConSakujozumiFukumu().length > 0) {
            return true;
        }

        return false;
    }

    /**
     * 検索結果を取得する
     *
     * @return 検索結果
     */
    public List<Map<String, Object>> getSearchResult() {
        return mst171Form.getSearchResult();
    }
    
    /**
     * 配色定義を設定する処理
     *
     * @param recordList レコードリスト
     */
    private void setIchiranColor(List<Map<String, Object>> recordList) {
        // 配色定義の判定を行う
        if (recordList != null && recordList.size() > 0) {
            for (Map<String, Object> record : recordList) {
                if ("使用不可住所".equals(record.get("listErrorNaiyo"))) {
                    pageCommonBean.setIchiranRowColor(record, "5");
                }
            }
        }
    }

    /**
     * 複写顧客コードを取得する
     *
     */
    public void getKokyakuCdList() {
        // Cus014_顧客（法人番号）検索ポップアップ（未実装）
       
    }
}
