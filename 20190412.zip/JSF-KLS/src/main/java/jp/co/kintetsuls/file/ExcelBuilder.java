package jp.co.kintetsuls.file;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.utils.BeanUtils;
import jp.co.kintetsuls.utils.DateUtils;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.utils.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.WorkbookUtil;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * Excel ファイルを作成
 *
 * @author
 */
public class ExcelBuilder {

    public static final String CSV_ENCODE = StndConsIF.KYOTU_ENCODE_UTF8;
    public static final String FILE_STORE_FOLDER_TEMP = "\\temp";

    /**
     *
     * csvファイル保存
     */
    public static String saveExcelInfoMap(List<CSVDto> header, List<Map<String, Object>> body) throws Exception {

        XSSFWorkbook wb = new XSSFWorkbook();

        CellStyle titleStyle = wb.createCellStyle();

        final String safeName = WorkbookUtil.createSafeSheetName("data");
        final Sheet sheet = wb.createSheet(safeName);

        CSVTokenizer csv = CSVTokenizer.getInstance();

        final Row titleRow = sheet.createRow(sheet.getLastRowNum());
        for (CSVDto d : header) {
            final int cellIndex = titleRow.getLastCellNum() == -1 ? 0 : titleRow.getLastCellNum();
            final Cell cell = titleRow.createCell(cellIndex);
            cell.setCellValue(new XSSFRichTextString(d.getTitle()));
            final Font titleFont = wb.createFont();
            titleFont.setBold(true);
            titleStyle.setFont(titleFont);
            cell.setCellStyle(titleStyle);
        }

        Row dataRow = sheet.createRow(sheet.getLastRowNum() + 1);
        for (Map o : body) {
            for (CSVDto d : header) {
                final int cellIndex = dataRow.getLastCellNum() == -1 ? 0 : dataRow.getLastCellNum();
                final Cell cell = dataRow.createCell(cellIndex);
                cell.setCellValue(new XSSFRichTextString(BeanUtils.objectToString(o.get(d.getName()))));

            }
            dataRow = sheet.createRow(sheet.getLastRowNum() + 1);
        }

        String filename = DateUtils.format(DateUtils.getSysDate(), StndConsIF.DF_YYYYMMDDHHMMSS);
        String filepath = FileUtils.getAbsolutePath(FILE_STORE_FOLDER_TEMP);

        OutputStream os = new FileOutputStream(filepath + StndConsIF.FS + filename + ".xlsx", false);
        try {
            wb.write(os);

        } catch (IOException e) {

        } finally {
            os.close();
        }
        return filename + ".xlsx";
    }
}
