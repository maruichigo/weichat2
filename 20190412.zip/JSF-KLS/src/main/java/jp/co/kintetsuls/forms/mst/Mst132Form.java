/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mst;

import java.util.List;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.annotation.MaxSizeCheck;
import jp.co.kintetsuls.beans.common.annotation.NotNull;
import jp.co.kintetsuls.beans.common.annotation.ZipCode;
import lombok.Data;

/**
 * 仕入先マスタ詳細 フォーム
 *
 * @author 劉成江 (MBP)
 * @version 2019/1/29 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst132Form")
@ViewScoped
@Data
public class Mst132Form {

    /**
     * 仕入先コード適用開始日検索用
     */
    private String shiiresakiCdBtn;

    /**
     * 適用フラグ
     */
    private String tekiyouFlg;
    
    /**
     * データバジョン
     */
    private String dtlShiiresakiDataVersion;
    
    /**
     * 更新カウンタ
     */
    private String koushinCounter;
    
    /**
     * 参照/編集/新規モード(0:参照/1:編集/2:新規モード)
     */
    private String mode;

    /**
     * 管轄区分
     */
    @NotNull(name = "管轄区分")
    private String conKankatsuKbn;

    /**
     * 管轄営業所
     */
    private AutoCompOptionBean conKankatsuEigyosho;

    /**
     * 承認ステータス
     */
    private String conShinseiStatus;

    /**
     * 仕入先コード
     */
    private String conShiiresakiCdStr;

    /**
     * 仕入先
     */
    @NotNull(name = "仕入先コード")
    private AutoCompOptionBean conShiiresakiCd;

    /**
     * 適用開始日
     */
    @NotNull(name = "適用開始日")
    private String conTekiyoKaishibi;

    /**
     * 適用名
     */
    @NotNull(name = "適用名")
    @MaxSizeCheck(name = "適用名", maxSize = 40)
    private String conTekiyoMei;

    /**
     * 適用終了
     */
    private List<String> conTekiyoShuryobi;

    /**
     * 仕入先名
     */
    @NotNull(name = "仕入先名")
    @MaxSizeCheck(name = "仕入先名", maxSize = 40)
    private String knrDtlShiiresakiMei;

    /**
     * 仕入先カナ名
     */
    @MaxSizeCheck(name = "仕入先カナ名", maxSize = 40)
    private String knrDtlShiiresakiMeikana;

    /**
     * 仕入先名備考
     */
    private String knrDtlShiiresakiMeiBiko;

    /**
     * 法人番号
     */
    @NotNull(name = "法人番号コード")
    private AutoCompOptionBean knrDtlHojinBango;

    /**
     * 使用区分
     */
    private List<String> knrDtlShiyokbn;

    /**
     * SS仕入先
     */
    @NotNull(name = "SS仕入先コード")
    private AutoCompOptionBean knrDtlSsShiiresaki;

    /**
     * SS企業コード
     */
    @NotNull(name = "SS企業コード")
    @MaxSizeCheck(name = "SS企業コード", maxSize = 8)
    private String knrDtlSskigyoCd;

    /**
     * その他使用営業所
     */
    private AutoCompOptionBean knrDtlSonotaShiyoEigyosho;

    /**
     * その他使用営業所
     */
    private String knrDtlSonotaShiyoEigyoshoMei;

    /**
     * その他使用営業所備考
     */
    private String knrDtlSonotaShiyoEigyoshoBiko;

    /**
     * 仕入先データバージョン
     */
    private String knrDtlHShiiresakiDataVersion;

    /**
     * 適用フラグ
     */
    private String knrDtlHTekiyoFlg;

    /**
     * 会社名
     */
    @NotNull(name = "会社名")
    @MaxSizeCheck(name = "会社名", maxSize = 40)
    private String khnDtlKaishaMei;

    /**
     * 会社カナ名
     */
    @MaxSizeCheck(name = "会社カナ名", maxSize = 40)
    private String khnDtlKaishaMeiKana;

    /**
     * 支店/営業所名
     */
    @NotNull(name = "支店/営業所名")
    @MaxSizeCheck(name = "支店/営業所名", maxSize = 40)
    private String khnDtlShitenEigyoshoMei;

    /**
     * 支店/営業所カナ名
     */
    @MaxSizeCheck(name = "支店/営業所カナ名", maxSize = 40)
    private String khnDtlShitenEigyoshoMeiKana;

    /**
     * 部署/担当者１
     */
    @MaxSizeCheck(name = "部署/担当者１", maxSize = 40)
    private String khnDtlBushoTantosha1;

    /**
     * 部署/担当者２
     */
    @MaxSizeCheck(name = "部署/担当者2", maxSize = 40)
    private String khnDtlBushoTantosha2;

    /**
     * 旧住所
     */
    private String khnDtlKyuJusho;

    /**
     * 使用不可
     */
    private String khnDtlShiyoFuka;

    /**
     * 新住所反映
     */
    private String khnDtlSinJushoHanei;

    /**
     * 郵便番号
     */
    @NotNull(name = "郵便番号")
    @ZipCode(name = "郵便番号")
    private String khnDtlYubinBango;

    /**
     * JISコード編集不可
     */
    private String khnDtlJisCd;

    /**
     * JISコード編集可
     */
    @NotNull(name = "JISコード")
    private AutoCompOptionBean khnDtlJisCdEdit;
    
    /**
     * JISコードリスト
     */
    private AutoCompOptionBean khnDtlJisCdAutoCompOption;

    /**
     * 住所1
     */
    @MaxSizeCheck(name = "住所1", maxSize = 40)
    private String khnDtlJusho1;

    /**
     * 住所2
     */
    @MaxSizeCheck(name = "住所2", maxSize = 40)
    private String khnDtlJusho2;

    /**
     * 住所3
     */
    @MaxSizeCheck(name = "住所3", maxSize = 40)
    private String khnDtlJusho3;

    /**
     * 住所4
     */
    @MaxSizeCheck(name = "住所4", maxSize = 40)
    private String khnDtlJusho4;

    /**
     * 空港
     */
    @NotNull(name = "空港コード")
    private AutoCompOptionBean khnDtlKuko;

    /**
     * 仕向地
     */
    @NotNull(name = "仕向地コード")
    private AutoCompOptionBean khnDtlShimukeChi;

    /**
     * 仕向地Str
     */
    private String khnDtlShimukeChiStr;
    
    /**
     * 集配地区コード
     */
    private String khnDtlShuhaiChikuCd;

    /**
     * 集配地区コードリスト
     */
    @NotNull(name = "集配地区")
    private AutoCompOptionBean khnDtlShuhaiChikuCdLabelValueListt;

    /**
     * 電話番号１
     */
    @MaxSizeCheck(name = "電話番号１", maxSize = 19)
    private String khnDtlTelBango1;

    /**
     * 電話番号２
     */
    @MaxSizeCheck(name = "電話番号2", maxSize = 19)
    private String khnDtlTelBango2;

    /**
     * FAX番号
     */
    @MaxSizeCheck(name = "FAX番号", maxSize = 19)
    private String khnDtlFaxBango;

    /**
     * 金融機関名
     */
    @NotNull(name = "金融機関名")
    @MaxSizeCheck(name = "金融機関名", maxSize = 60)
    private String trhkDtlKinyuKikanMei;

    /**
     * 支店名
     */
    @NotNull(name = "支店名")
    @MaxSizeCheck(name = "支店名", maxSize = 40)
    private String trhkDtlShitenMei;

    /**
     * 口座種別
     */
    private AutoCompOptionBean trhkDtlKozaShubetsu;

    /**
     * 口座番号
     */
    @NotNull(name = "口座番号")
    @MaxSizeCheck(name = "口座番号", maxSize = 7)
    private String trhkDtlKozaBango;

    /**
     * 名義人名
     */
    @NotNull(name = "名義人名")
    @MaxSizeCheck(name = "名義人名", maxSize = 40)
    private String trhkDtlMeigininMei;

    /**
     * 手数料負担
     */
    private String trhkDtlTesuryoFutan;

    /**
     * 支払条件
     */
    private String trhkDtlShiharaiJoken;

    /**
     * 買掛金コード
     */
    private String trhkDtlKaikakekinCd;

    /**
     * メモ
     */
    @NotNull(name = "メモ")
    @MaxSizeCheck(name = "メモ", maxSize = 100)
    private String sntDtlMemo;

    /**
     * 更新日時
     */
    private String lastDtlKoshinNichiji;

    /**
     * 更新者
     */
    private String lastDtlKoshinSha;

    /**
     * 最終使用日(代理店マスタ)
     */
    private String lastDtlShiyoHizukeMsDairiten;

    /**
     * 最終使用日(仕入管理)
     */
    private String lastDtlShiyoHizukeTrShiireKanri;

    /**
     * 検索結果
     */
    private List<Map<String, Object>> searchResult;

    /**
     * 履歴検索パラメータ
     */
    private Map<String, Object> rirekiSearchKey;

    /**
     * 画面モード
     *
     */
    private String Mode;

    /**
     * 履歴確認ボタンDisabled
     */
    private boolean rirekiDisabled;
}
