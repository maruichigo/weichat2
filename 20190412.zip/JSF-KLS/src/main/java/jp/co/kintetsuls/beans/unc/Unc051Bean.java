    /*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.unc;

import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Getter;
import lombok.Setter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 仕入先マスタ一覧
 *
 * @author MBP劉 (MBP)
 * @version 2019/1/24 新規作成
 */
@javax.faces.bean.ManagedBean(name = "unc051")
@ViewScoped
public class Unc051Bean extends BaseBean {

    private final String strTitle = "残高問合せ画面";
    private String url;     // URL

    @ManagedProperty(value = "#{breadBean}")
    @Getter
    @Setter
    private BreadCrumbBean breadBean;

    @ManagedProperty(value = "#{authConfBean}")
    @Getter
    @Setter
    private AuthorityConfBean authConfBean;

    private static final Logger logger = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    private RestfullService rest;

    @Getter
    @Setter
    private List<Unc051Model> searchResult;

    @Getter
    @Setter
    private Unc051Model selectSearchResult;

    /**
     * 都道府県
     */
    @Getter
    @Setter
    private String conTodofuken;
    /**
     * 仕向地名
     */
    @Getter
    @Setter
    private String conShimukeChiMei;
    /**
     * 削除済のみ
     */
    @Getter
    @Setter
    private String conSakujoSumiNomi[];

    /**
     * コンストラクタ
     */
    public Unc051Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId
     * @param prevScreen
     * @param backFlag
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            // パンくず追加
            breadBean.push("残高問合せ画面", SCREEN.MST501_SCREEN.name(), this);
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }
    }

    /**
     * 検索処理
     *
     */
    public void search() {

        // 入力チェック
//        if (conShimukeChiMei.isEmpty()) {
//
//        }


        // 仕向地名マスタ検索し、取得した値を画面項目にセット
        List<Unc051Model> res = getShimukeList();

    }

    /**
     * DBから仕向地名マスタ情報を取得する
     */
    private List<Unc051Model> getShimukeList() {
         List<Unc051Model> list = new ArrayList<>();
         Unc051Model model1 = new Unc051Model();
         SimpleDateFormat smf = new SimpleDateFormat("YYYY/MM/DD");
         model1.setEigyoshoCd("000001");
         model1.setEigyoshoName("東京営業所");
         model1.setSeikyusakiCd("00001");
         model1.setSeikyusakiName("請求先名A");
         model1.setSeikyushoNo("100003-001");
         model1.setShiDate("2017/09/30");
         model1.setSeikyuKin(new BigDecimal("100000"));
         model1.setNyuKin(BigDecimal.ZERO);
         model1.setZankoukuKin(new BigDecimal("100000"));
         model1.setNyuKinDate("2017/10/05");
         model1.setNyuKinhou("集金");
         model1.setJyoukenGai("0");
         model1.setLastAuther("山田 太郎");
         list.add(model1);
         
         Unc051Model model2 = new Unc051Model();
         model2.setEigyoshoCd("000001");
         model2.setEigyoshoName("東京営業所");
         model2.setSeikyusakiCd("00001");
         model2.setSeikyusakiName("請求先名A");
         model2.setSeikyushoNo("100002-001");
         model2.setShiDate("2017/08/31");
         model2.setSeikyuKin(new BigDecimal("200000"));
         model2.setNyuKin(new BigDecimal("200000"));
         model2.setZankoukuKin(BigDecimal.ZERO);
         model2.setNyuKinDate("2017/09/05");
         model2.setNyuKinhou("集金");
         model2.setJyoukenGai("0");
         model2.setLastAuther("山田 太郎");
         list.add(model2);
         
         Unc051Model model3 = new Unc051Model();
         model3.setEigyoshoCd("000001");
         model3.setEigyoshoName("東京営業所");
         model3.setSeikyusakiCd("00001");
         model3.setSeikyusakiName("請求先名A");
         model3.setSeikyushoNo("100001-001");
         model3.setShiDate("2017/07/31");
         model3.setSeikyuKin(new BigDecimal("300000"));
         model3.setNyuKin(new BigDecimal("300000"));
         model3.setZankoukuKin(BigDecimal.ZERO);
         model3.setNyuKinDate("2017/08/05");
         model3.setNyuKinhou("集金");
         model3.setJyoukenGai("0");
         model3.setLastAuther("山田 太郎");
         list.add(model3);
         
         Unc051Model model4 = new Unc051Model();
         model4.setEigyoshoCd("000001");
         model4.setEigyoshoName("東京営業所");
         model4.setSeikyusakiCd("00004");
         model4.setSeikyusakiName("請求先名D");
         model4.setSeikyushoNo("100004-001");
         model4.setShiDate("2017/09/31");
         model4.setSeikyuKin(new BigDecimal("400000"));
         model4.setNyuKin(new BigDecimal("400000"));
         model4.setZankoukuKin(BigDecimal.ZERO);
         model4.setNyuKinDate("2017/08/05");
         model4.setNyuKinhou("集金");
         model4.setJyoukenGai("0");
         model4.setLastAuther("山田 太郎");
         list.add(model4);
         
         Unc051Model model5 = new Unc051Model();
         model5.setEigyoshoCd("000001");
         model5.setEigyoshoName("東京営業所");
         model5.setSeikyusakiCd("00005");
         model5.setSeikyusakiName("請求先名E");
         model5.setSeikyushoNo("100005-001");
         model5.setShiDate("2017/09/20");
         model5.setSeikyuKin(new BigDecimal("500000"));
         model5.setNyuKin(new BigDecimal("500000"));
         model5.setZankoukuKin(BigDecimal.ZERO);
         model5.setNyuKinDate("2017/08/05");
         model5.setNyuKinhou("振込");
         model5.setJyoukenGai("1");
         model5.setLastAuther("山田 太郎");
         list.add(model5);
         
         Unc051Model model6 = new Unc051Model();
         model6.setEigyoshoCd("000001");
         model6.setEigyoshoName("東京営業所");
         model6.setSeikyusakiCd("00006");
         model6.setSeikyusakiName("請求先名F");
         model6.setSeikyushoNo("100006-001");
         model6.setShiDate("2017/09/20");
         model6.setSeikyuKin(new BigDecimal("500000"));
         model6.setNyuKin(new BigDecimal("500000"));
         model6.setZankoukuKin(BigDecimal.ZERO);
         model6.setNyuKinDate("2017/08/05");
         model6.setNyuKinhou("振込");
         model6.setJyoukenGai("1");
         model6.setLastAuther("山田 太郎");
         list.add(model6);
         this.searchResult = list;
         return this.searchResult;

    }

    /**
     * メニュークリック（処理）
     *
     * @param menuId
     * @param nextScreen
     * @return
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }

        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック（処理）
     *
     * @return
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }
        url = forward(nextScreen, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return
     */
    @Override
    public String logoutClick() {
        return authConfBean.logout();
    }

    /**
     * 画面遷移処理（顧客マスタメンテナンス画面へ）
     *
     * @return
     * @throws java.lang.IllegalAccessException
     * @throws java.lang.reflect.InvocationTargetException
     */
    public String buttonClick() throws IllegalAccessException, InvocationTargetException {

        // 画面遷移
        url = forward(SCREEN.CUS012_SCREEN.name(), null, SCREEN.CUS011_SCREEN.name(), false);
        return url;
    }

    /**
     * @return the strTitle
     */
    public String getStrTitle() {
        return strTitle;
    }

    public List<String> completeText(String query) {
        List<String> tantoEigyosho = new ArrayList();

        tantoEigyosho.add("営業所００１");
        tantoEigyosho.add("営業所００２");
        tantoEigyosho.add("営業所００３");
        tantoEigyosho.add("営業所００４");
        tantoEigyosho.add("営業所００５");

        return tantoEigyosho;
    }
}
