/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.inv;

import java.util.List;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.forms.common.LabelValueForm;
import lombok.Data;

/**
 * 送り状発行詳細 フォーム
 *
 * @author 作成者 (MBP)
 * @version 2019/2/2 新規作成
 */
@javax.faces.bean.ManagedBean(name = "inv021Form")
@ViewScoped
@Data
public class Inv021Form {

    /**
     * 操作区分
     */
    private String k11;

    /**
     * 送り状NO
     */
    private String k12;

    /**
     * 引取フラグ
     */
    private String[] k13;

    /**
     * 引取フラグリスト
     */
    private List<LabelValueForm> k13LabelValueList;

    /**
     * 顧客コード
     */
    private String k14;

    /**
     * 顧客名称
     */
    private String k15;

    /**
     * 担当営業所コード
     */
    private String k16;

    /**
     * 担当営業所名称
     */
    private String k17;

    /**
     * 発行パターン選択
     */
    private String k18;

    /**
     * 集荷日
     */
    private String k21;

    /**
     * 伝票種別コード
     */
    private String k22;

    /**
     * 伝票種別名称
     */
    private String k23;

    /**
     * 輸送方法コード
     */
    private String k24;

    /**
     * 輸送方法名称
     */
    private String k25;

    /**
     * 発行枚数
     */
    private String k26;

    /**
     * 発行枚数単位ラベル
     */
    private String k27;

    /**
     * 荷受人数・総枚数
     */
    private String k28;

    /**
     * 発行営業所コード
     */
    private String k29;

    /**
     * 発行営業所名称
     */
    private String k30;

    /**
     * 荷札発行有無
     */
    private String k31;

    /**
     * 荷受人発行コード
     */
    private String k33;

    /**
     * 電話番号
     */
    private String k36;

    /**
     * 旧住所ラベル
     */
    private String k39;

    /**
     * 使用不可ラベル
     */
    private String k40;

    /**
     * 郵便番号
     */
    private String k42;

    /**
     * JISコード
     */
    private String k43;

    /**
     * 住所1
     */
    private String k44;

    /**
     * 住所2
     */
    private String k45;

    /**
     * 住所3
     */
    private String k46;

    /**
     * 住所4
     */
    private String k47;

    /**
     * 名称1
     */
    private String k48;

    /**
     * 名称2
     */
    private String k49;

    /**
     * 名称3
     */
    private String k50;

    /**
     * 名称4
     */
    private String k51;

    /**
     * 仕向地コード
     */
    private String k52;

    /**
     * 仕向地名称
     */
    private String k53;

    /**
     * 配達営業所コード
     */
    private String k54;

    /**
     * 配達営業所名称
     */
    private String k55;

    /**
     * 荷送人発行コード
     */
    private String k57;

    /**
     * 電話番号
     */
    private String k60;

    /**
     * 旧住所ラベル
     */
    private String k63;

    /**
     * 使用不可ラベル
     */
    private String k64;

    /**
     * 郵便番号
     */
    private String k66;

    /**
     * JISコード
     */
    private String k67;

    /**
     * 住所1
     */
    private String k68;

    /**
     * 住所2
     */
    private String k69;

    /**
     * 住所3
     */
    private String k70;

    /**
     * 住所4
     */
    private String k71;

    /**
     * 名称1
     */
    private String k72;

    /**
     * 名称2
     */
    private String k73;

    /**
     * 名称3
     */
    private String k74;

    /**
     * 名称4
     */
    private String k75;

    /**
     * 集荷営業所コード
     */
    private String k76;

    /**
     * 集荷営業所名称
     */
    private String k77;

    /**
     * 集荷営業所電話番号
     */
    private String k78;

    /**
     * 品名コード
     */
    private String k80;

    /**
     * 品名内容
     */
    private String k81;

    /**
     * 特記事項コード
     */
    private String k82;

    /**
     * 特記事項内容
     */
    private String k83;

    /**
     * 記事欄1コード
     */
    private String k84;

    /**
     * 記事欄1内容
     */
    private String k85;

    /**
     * 記事欄2コード
     */
    private String k86;

    /**
     * 記事欄2内容
     */
    private String k87;

    /**
     * 記事欄3コード
     */
    private String k88;

    /**
     * 記事欄3内容
     */
    private String k89;

    /**
     * 記事欄4コード
     */
    private String k90;

    /**
     * 記事欄4内容
     */
    private String k91;

    /**
     * 記事欄5選択
     */
    private String k92;

    /**
     * 記事欄5内容
     */
    private String k93;

    /**
     * 配送指示
     */
    private String k95;

    /**
     * 配達指定日
     */
    private String k96;

    /**
     * 配達指定時刻
     */
    private String k97;

    /**
     * 配達指定時刻選択
     */
    private String k98;

    /**
     * 個数未確定
     */
    private String[] k99;

    /**
     * 個数未確定リスト
     */
    private List<LabelValueForm> k99LabelValueList;

    /**
     * 個数
     */
    private String k100;

    /**
     * 個数単位ラベル
     */
    private String k101;

    /**
     * 個数未確定注意事項
     */
    private String k102;

    /**
     * 重量
     */
    private String k103;

    /**
     * 重量単位ラベル
     */
    private String k104;

    /**
     * 容積重量
     */
    private String k105;

    /**
     * 容積重量単位ラベル
     */
    private String k106;

    /**
     * お客様管理NO
     */
    private String k107;

    /**
     * 送り状レイアウト
     */
    private String k108;

    /**
     * 荷札レイアウト
     */
    private String k109;

    /**
     * 発行区分
     */
    private String k111;

    /**
     * 発行日時
     */
    private String k112;

    /**
     * 発行者
     */
    private String k113;

    /**
     * 発行端末
     */
    private String k114;

    /**
     * 再発行日時
     */
    private String k115;

    /**
     * 再発行者
     */
    private String k116;

    /**
     * 発行区分
     */
    private String k118;

    /**
     * 発行枚数
     */
    private String k119;

    /**
     * 発行枚数単位ラベル
     */
    private String k120;

    /**
     * 発行営業所コード
     */
    private String k121;

    /**
     * 発行営業所名称
     */
    private String k122;

    /**
     * 発行日時
     */
    private String k123;

    /**
     * 発行者
     */
    private String k124;

    /**
     * 発行端末
     */
    private String k125;

    /**
     * 再発行日時
     */
    private String k126;

    /**
     * 再発行者
     */
    private String k127;

    /**
     * 登録区分
     */
    private String k129;

    /**
     * 発行要求営業所コード
     */
    private String k130;

    /**
     * 発行要求営業所名称
     */
    private String k131;

    /**
     * 要求日時
     */
    private String k132;

    /**
     * 更新者
     */
    private String k133;

    /**
     * 出力対象
     */
    private String[] k138;

    /**
     * 出力対象リスト
     */
    private List<LabelValueForm> k138LabelValueList;

    /**
     * 送り状NO FROM
     */
    private String k139;

    /**
     * 送り状NO TO
     */
    private String k140;

    /**
     * 説明ラベル
     */
    private String k147;

    /**
     * パターン名称
     */
    private String k148;

    /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;
}
