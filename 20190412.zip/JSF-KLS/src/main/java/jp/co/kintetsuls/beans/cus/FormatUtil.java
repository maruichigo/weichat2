/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.cus;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * フォーマット変換サンプル
 * @author Yuka Kobayashi
 */
public class FormatUtil {
    
    private static final Logger logger = LogManager.getLogger(new Object(){}.getClass().getEnclosingClass().getName());

    public static String dateToJsonString(java.util.Date date){
        if(date == null ){
            return "";
        }
        java.sql.Date sqlDate = new java.sql.Date(date.getTime());
        
        return sqlDate.toString();
    }
    
    public static java.util.Date jsonStringToDate(String str){
        if(str == null || str.isEmpty()){
            return null;
        }
        
        str = str.substring(0, 10);
        DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date date = null;
        try {
            date = format.parse(str);
        } catch (ParseException ex) {
            logger.error(ex.getMessage(), ex);
            return null;
        }
        return date;
        
    }
    
}
