package jp.co.kintetsuls.beans.logout;

import javax.faces.bean.ManagedProperty;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.sharedsys.beans.session.AuthorityConfBean;

@javax.faces.bean.ManagedBean(name = "logoutBean")
@javax.faces.bean.RequestScoped
@lombok.Data
public class LogoutBean {

    /**
     * ログアウト拡張処理
     * 
     * @return ProcessStop:true/ProcessContinue:false;
     */
    public boolean execute(AuthorityConfBean authConf){
        boolean stopflg = false;

        return stopflg;
    }
}
