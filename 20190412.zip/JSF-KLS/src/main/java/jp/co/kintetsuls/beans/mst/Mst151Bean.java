/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiListCol;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst151Form;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 品名マスタ画面
 *
 * @author 许博 (MBP)
 * @version 2019/1/28 新規作成
 */
@ManagedBean(name = "mst151")
@ViewScoped
@Data
public class Mst151Bean extends AbstractBean {

    /**
     * タイトル
     */
    private final String TITLE = "品名マスタ";

    /**
     * ダウンロードファイル名
     */
    private final static String FILE_NAME = "品名マスタ一覧";

    /**
     * 画面URL
     */
    private String url;

    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

    /**
     * 画面フォーム
     */
    @ManagedProperty(value = "#{mst151Form}")
    private Mst151Form mst151Form;

    /**
     * 画面共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * 検索シーケンス処理共通
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;

    /**
     * ファイルダウンロード
     */
    @ManagedProperty(value = "#{fileBean}")
    private FileBean fileBean;

    /**
     * 履歴一覧処理共通
     */
    @ManagedProperty(value = "#{rirekisyosai}")
    private RirekiSyosaiBean rirekiSyosai;

    /**
     * 一覧単項目チェック共通
     */
    @ManagedProperty(value = "#{listCheckBean}")
    private ListCheckBean listCheckBean;

    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    /**
     * スクリーンコード：MST151
     */
    private static final String SC_CD_MST151 = "MST151_SCREEN";

    /**
     * 定数：一覧のデータテーブルID
     */
    private static final String DATA_TABLE_ID = "tablesorter_mst151";

    /**
     * 定数：検索件数取得ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH_KENSU = "mst151-get-himmei-kensu";

    /**
     * 定数：検索ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH = "mst151-get-himmei-detail";

    /**
     * 定数：登録の重複チェックと更新の存在チェックファンクションコード
     */
    private static final String FUNC_CODE_INSERT_UPDATE_CHECK = "mst151-insert-update-check";

    /**
     * 定数：削除の存在チェックファンクションコード
     */
    private static final String FUNC_CODE_DELETE_EXIST = "mst151-delete-exist";

    /**
     * 定数：品名マスタ登録更新ファンクションコード
     */
    private static final String FUNC_CODE_INSERT_UPDATE = "mst151-insert-update";

    /**
     * 定数：行削除ファンクションコード
     */
    private static final String FUNC_CODE_DELETE_ROW = "mst151-delete-row-detail";

    /**
     * 定数：画面項目保持キー
     */
    private static final String CONST_MST151_FORM = "mst151Form";

    /**
     * 定数：MasterInfo取得キー
     */
    private static final String CONST_MST151_MASTER = "mst151";

    /**
     * 定数：再検索Button取得キー
     */
    private static final String CONST_MST151_SEARCH = "search_mst151";

    /**
     * 履歴テーブル検索キー
     */
    private Map<String, Object> rirekiSearchKey;

    /**
     * ワーク.メッセージリスト
     */
    List<MessageModuleBean> msgList = new ArrayList<>();

    /**
     * コンストラクタ
     */
    public Mst151Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId メニューID
     * @param prevScreen 遷移元画面ID
     * @param backFlag 戻るフラグ
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {

            // パンくずを追加する
            breadBean.push(TITLE, SCREEN.MST151_SCREEN.name(), this);

            // システムマスタ取得する
            pageCommonBean.getMasterInfo(CONST_MST151_MASTER);

            // 検索シーケンス処理ため初期化する
            searchHelpBean.regSearchHelp(DATA_TABLE_ID,
                    s -> {
                        return getRecordCount();
                    },
                    s -> {
                        search();
                        return null;
                    },
                    null);
            searchHelpBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);

            // AutoCompleteを初期化する
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO, new AutoCompOptionBean("全て", "all"));
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_KOKYAKU);

            // 前回の記録をクリアする
            this.clear();
            mst151Form.setSearchResult(null);
            mst151Form.setSearchResultSelectable(null);
            mst151Form.setSelectedSearchResult(null);

            // 戻ってきた場合
            Mst151Form preForm = (Mst151Form) pageCommonBean.getPageInfo(CONST_MST151_FORM);
            if (backFlag && preForm != null) {
                PageCommonBean.simpleCopy(preForm, mst151Form);
                // 再検索を実施する
                pageCommonBean.searchAgain(CONST_MST151_SEARCH);
                // 進んできた場合
            } else {
                Flash flash = pageCommonBean.getPageParam();
                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_MST151_FORM) != null) {
                    PageCommonBean.simpleCopy(flash.get(CONST_MST151_FORM), mst151Form);
                    // 再検索を実施する
                    pageCommonBean.searchAgain(CONST_MST151_SEARCH);
                }
            }

            // ダウンロードシーケンス初期化する
            fileBean.setDataSize(DATA_TABLE_ID,
                    (id -> {
                        return getRecordCount();
                    }));
            
            fileBean.setSearchResult(DATA_TABLE_ID, (id -> {return getSearchResult();}));

            fileBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);

            fileBean.setSubFlg(false);

            fileBean.setTilte(FILE_NAME);

            fileBean.regDownloadFucntion(DATA_TABLE_ID, getHeader(),
                    (id -> {
                        return getHimmeiCdList();
                    }));

            fileBean.regBeforeDownFucntion(DATA_TABLE_ID,
                    (comment -> {
                        return beforeDown(comment);
                    }));

            // 行更新また削除するために共通処理へ登録する
            pageCommonBean.regDelFucntion(DATA_TABLE_ID,
                    (dataList -> (this.delRows(dataList))));

            // component初期化とユーザ権限により制御を設定する
            pageCommonBean.setAuthControll(mst151Form, SC_CD_MST151, true);

            // 初期はデータを編集不可にする
            mst151Form.setBtnEditeDisabled(true);

        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * カウント処理
     *
     * @return 取得件数
     */
    public Long getRecordCount() {

        // 前回の記録をクリアする
        Map<String, Object> mapRec = new LinkedHashMap();
        mapRec.put("hideFlg", "hideRow");
        List<Map<String, Object>> mapList = new ArrayList();
        mapList.add(mapRec);
        mst151Form.setSearchResult(mapList);
        mst151Form.setSearchResultSelectable(new ReportListDataModel(mst151Form.getSearchResult()));
        mst151Form.setSelectedSearchResult(null);

        // 検索初期はデータを編集不可にする
        mst151Form.setBtnEditeDisabled(true);

        // レコード件数を取得する
        long recordCount = getHimmeiCdListCount();

        // 検索部のステータスを変更する
        pageCommonBean.setSerchConDisabled(mst151Form);

        // 参照モードにする
        pageCommonBean.setEditFlg(false);

        // 検索条件保存
        pageCommonBean.savePageInfo(CONST_MST151_FORM, mst151Form);

        return recordCount;
    }

    /**
     * 検索処理
     */
    public void search() {

        // 選択リストを初期化する
        mst151Form.setSelectedSearchResult(new ArrayList<>());
        mst151Form.setSearchResultSelectable(null);

        // 品名マスタ検索を行う
        List<Map<String, Object>> recordList = getHimmeiCdList();

        fileBean.setDataList(recordList);

        // 取得した値を画面項目にセットする
        pageCommonBean.setDatalist(DATA_TABLE_ID, recordList);
        mst151Form.setSearchResultSelectable(new ReportListDataModel(recordList));

        // 検索部のステータス変更する
        pageCommonBean.setSerchConDisabled(mst151Form);

        // 編集ボタンのステータス変更する
        mst151Form.setBtnEditeDisabled(false);

        // 検索条件を保存する
        pageCommonBean.savePageInfo(CONST_MST151_FORM, mst151Form);

        // 参照モードにする
        pageCommonBean.setEditFlg(false);
    }

    /**
     * 検索条件変更処理
     */
    public void searchChange() {

        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mst151Form);
    }

    /**
     * クリア処理
     */
    public void clear() {

        // 検索部の条件クリア
        mst151Form.setConEigyosho(null);
        mst151Form.setConKokyaku(null);
        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mst151Form);
        pageCommonBean.setBtnSearchChangeVisible(false);
        pageCommonBean.setBtnSearchVisible(Boolean.TRUE);
    }

    /**
     * 更新処理
     */
    public void update() {

        // エラーメッセージを格納する変数の初期化を行う
        msgList = new ArrayList();

        // 行選択チェックを行う
        if (mst151Form.getSelectedSearchResult().isEmpty()) {

            MessageModuleBean message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
            msgList.add(message);

            messagePropertyBean.messageList(msgList);
            return;
        }

        // 登録一覧リストの初期化を行う
        List<Map<String, Object>> torokuIchiranList = new ArrayList();

        // 更新一覧リストの初期化を行う
        List<Map<String, Object>> koshinIchiranList = new ArrayList();
        
        // 単項目チェック処理
        if (!checkJsfParamas(mst151Form.getSelectedSearchResult())) {
            return;
        }
        
        // 登録更新情報設定処理
        for (Map<String, Object> record : mst151Form.getSelectedSearchResult()) {
            // 品名マスタ一覧.カレント行 = 登録対象
            if (record.get(StndConsIF.CONST_ADD_ROW_KEY) != null) {
                // 営業所コードを設定する
                record.put("listEigyoshoCd", mst151Form.getConEigyosho().getValue());
                // 顧客コードを設定する
                record.put("listKokyakuCd", mst151Form.getConKokyaku().getValue());
                torokuIchiranList.add(record);
            } else {
                koshinIchiranList.add(record);
            }
        }

        // 登録・更新処理を行う
        int status = insertUpdateHimmeiList();

        // エラーの場合、処理終了
        if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            return;
        }

        // 登録の後に再度検索する
        this.search();

        // 一覧の配色定義をなくす
        pageCommonBean.resetIchiranColColor(mst151Form.getSelectedSearchResult());

        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0007, "更新");

        // ログ出力を行う
        LOGGER.info("更新 " + mst151Form.getSelectedSearchResult().size() + " 件");
    }

    /**
     * 業務削除処理ファンクション領域
     *
     */
    public void delRowsFunc() {

        pageCommonBean.getSelectedDatasList().put(DATA_TABLE_ID, mst151Form.getSelectedSearchResult());
        pageCommonBean.delRows(DATA_TABLE_ID);
    }

    /**
     * 業務削除処理
     *
     * @param recordList レコードリスト
     * @return 正常／異常
     */
    public Boolean delRows(List<Map<String, Object>> recordList) {

        // エラーメッセージを格納する変数を初期化する
        msgList = new ArrayList<>();

        // 行選択チェックを行う
        if (recordList.isEmpty()) {
            MessageModuleBean message = messagePropertyBean.createMessageModule(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.MSTE0093);
            msgList.add(message);
            return false;
        }

        // 存在チェック
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(recordList, FUNC_CODE_DELETE_EXIST);

        // エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {

            MessageModuleBean message = messagePropertyBean.createMessageModule(res.getMessages().get(0)[0],
                    res.getMessages().get(0)[1]);
            msgList.add(message);
            return false;
        }

        // 削除処理を行う
        int status = deleteHimmeiList(recordList);

        // エラーの場合、処理を終了
        if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            return false;
        }

        // 画面レコード削除
        mst151Form.getSearchResult().removeAll(recordList);

        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0004, "削除");

        // ログ出力
        LOGGER.info("削除 " + recordList.size() + " 件");
        return true;
    }

    /**
     * 更新履歴を表示処理
     */
    public void rirekiIchiran() {

        // 履歴テーブル検索キーを設定する
        rirekiSearchKey = new HashMap();

        // 選択されたレコードを取得する
        Map<String, Object> selectRec = mst151Form.getSelectedSearchResult().get(0);
        rirekiSearchKey.put("listHimmeiCd", selectRec.get("listHimmeiCd"));
        rirekiSearchKey.put("listEigyoshoCd", selectRec.get("listEigyoshoCd"));
        rirekiSearchKey.put("listKokyakuCd", selectRec.get("listKokyakuCd"));

        // 履歴タイトルを設定する
        rirekiSyosai.setListColName(
            new ArrayList<>(Arrays.asList("バージョン情報", "品名コード", "品名", "営業所コード", "顧客コード")));

        // 履歴beanの項目物理名を設定する
        List<String> colValue = new ArrayList<>(Arrays.asList(
            "listDataVersion", "listHimmeiCd", "listHimmei", "listEigyoshoCd",
                        "listKokyakuCd"
        ));
        List<String> colAlign = new ArrayList<>(Arrays.asList(
            "center","left" ,"left" ,"left" ,"left" 
        ));
        List<RirekiListCol> listCol = new ArrayList<>();
        for (int i = 0; i < colValue.size(); i++){
            RirekiListCol col = new RirekiListCol();
            col.setColValue(colValue.get(i));
            col.setColAlign(colAlign.get(i));
            listCol.add(col);
        }
        rirekiSyosai.setListCol(listCol);

        // 履歴テーブルを検索する
        rirekiSyosai.searchList("2", "MST151_GET_HIMMEI_RIREKI", rirekiSearchKey);

    }

    /**
     * CSVファイルのタイトルを設定する処理
     *
     * @return 画面タイトル
     */
    public List<CSVDto> getHeader() {

        // CSVファイルのタイトルを設定
        List<CSVDto> header = new ArrayList<>();
        header.add(new CSVDto("品名コード", "listHimmeiCd"));
        header.add(new CSVDto("品名", "listHimmei"));

        // 取得値を返却する
        return header;
    }

    /**
     * ダウンロード理由を記録する処理
     *
     * @param comment 理由コメント
     * @return 正常／異常
     * @throws Exception
     */
    public boolean beforeDown(String comment) throws Exception {

        // ダウンロード理由を記録する
        System.out.println(comment);
        return true;
    }

    /**
     * メニュークリック処理
     *
     * @param menuId メニューID
     * @param nextScreenId 遷移先画面ID
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreenId) {
        try {
            // パンくずを削除する
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移を行う
        url = forward(nextScreenId, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック処理
     *
     * @param nextScreenId 遷移先画面ID
     * @param breadIndex パンくずのインデックス
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreenId, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移を行う
        url = forward(nextScreenId, null, null, true);
        return url;
    }

    /**
     * ログアウトクリック処理
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authConfBean.logout();
    }
    
    /**
     * アップロード
     * 
     * @return 遷移先画面のURL
     */
    public String upload() {
        
        // flash初期化
        Flash flash = pageCommonBean.getPageParam();
        
        // flashにアップロード機能コードを設定する
        flash.put("uploadFunctionCd", TITLE);
        
        // アップロードを画面へ遷移
        url = forward(Cnst.SCREEN.UPLOAD_SCREEN.name(), null, Cnst.SCREEN.UPLOAD_SCREEN.name(), false);
        return url;
    }
    
    /**
     * ダウンロード検査結果取得
     * 
     * @return 検索結果
     */
    public List<Map<String, Object>> getSearchResult() {
        return mst151Form.getSearchResult();
    }

    /**
     * 一覧の単項目チェック処理
     *
     * @param params 画面一覧パラメータ
     * @return チェックの結果
     */
    private boolean checkJsfParamas(List<Map<String, Object>> params) {

        List<ListCheckBean> checks = new ArrayList<>();
        checks.add(new ListCheckBean("listHimmeiCd",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "品名コード"));
        checks.add(new ListCheckBean("listHimmeiCd",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_SIZE, "品名コード", "3"));
        checks.add(new ListCheckBean("listHimmei",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "品名"));
        checks.add(new ListCheckBean("listHimmei",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "品名", "40"));
        List<MessageModuleBean> checkMsgList = listCheckBean.check(params, checks, true);

        if (!checkMsgList.isEmpty()) {
            return false;
        }
        return true;
    }

    /**
     * DBから品名マスタ情報を取得する
     */
    private List<Map<String, Object>> getHimmeiCdList() {

        // パラメータを設定する
        Map<String, Object> params = new HashMap<>();

        // ログインユーザー所属営業所を設定する
        params.put("loginUserShozokuEigyosho", authConfBean.getLoginUserShozokuEigyosho());
        
        // 全営業所検索
        params.put("allEigyoshoSearch", pageCommonBean.getMasterInfo().getAllEigyoshoSearch());
        
        // 営業所コードを設定する
        params.put("conEigyosho", mst151Form.getConEigyosho().getValue());

        // 顧客コードを設定する
        params.put("conKokyaku", mst151Form.getConKokyaku().getValue());
        try {
            // DBをアクセスする
            ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH);
            ObjectMapper mapper = new ObjectMapper();
            mst151Form.setSearchResult(mapper.readValue(res.getJson(), List.class));
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }

        // 品名マスタ情報を返却する
        return mst151Form.getSearchResult();
    }

    /**
     * DBから品名マスタ検索件数を取得する処理
     */
    private Long getHimmeiCdListCount() {

        // パラメータを設定する
        Map<String, Object> params = new HashMap<>();

        // ログインユーザー所属営業所を設定する
        params.put("loginUserShozokuEigyosho", (authConfBean.getLoginUserShozokuEigyosho()));
        // 全営業所検索
        params.put("allEigyoshoSearch", pageCommonBean.getMasterInfo().getAllEigyoshoSearch());
        // 営業所コードを設定する
        params.put("conEigyosho", mst151Form.getConEigyosho().getValue());
        // 顧客コードを設定する
        params.put("conKokyaku", mst151Form.getConKokyaku().getValue());

        // DBをアクセスする
        ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH_KENSU);

        // 検索件数を返却する
        return Long.valueOf(res.getJson());
    }

    /**
     * DBへ品名マスタを登録また更新する処理
     */
    private int insertUpdateHimmeiList() {

        // 相関、重複、存在チェック
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(mst151Form.getSelectedSearchResult(),
                FUNC_CODE_INSERT_UPDATE_CHECK);

        // エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            messagePropertyBean.message(res.getMessages().get(0)[0],
                    res.getMessages().get(0)[1]);
            return res.getStatusCode();
        }

        // 登録一覧リストと更新一覧リストの内容を処理する
        res = pageCommonBean.accsessDBWithList(mst151Form.getSelectedSearchResult(), FUNC_CODE_INSERT_UPDATE);

        return res.getStatusCode();
    }

    /**
     * DBから品名マスタ情報を削除する処理
     *
     * @param recordList レコードリスト
     * @return ステータスコード
     */
    private int deleteHimmeiList(List<Map<String, Object>> recordList) {

        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(recordList, FUNC_CODE_DELETE_ROW);

        // ステータスコードを返却する
        return res.getStatusCode();
    }
}
