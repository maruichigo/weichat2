/*
 * EstimatePackCityMunicipality.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.est;

import java.io.Serializable;

public class EstimatePackCityMunicipality implements Serializable {

    //JISコード
    public String jisCode;

    public String getJisCode() {
        return jisCode;
    }

    public void setJisCode(String value) {
        this.jisCode = value;
    }

    //市区町村名
    public String cityName;

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String value) {
        this.cityName = value;
    }

    //地区
    public String district;

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String value) {
        this.district = value;
    }

    //ランク
    public String rank;

    public String getRank() {
        return rank;
    }

    public void setRank(String value) {
        this.rank = value;
    }

    //ランクカラーコード
    public String color;

    public String getColor() {
        return color;
    }

    public void setColor(String value) {
        this.color = value;
    }

    //備考
    public String memo;

    public String getMemo() {
        return memo;
    }

    public void setMemo(String value) {
        this.memo = value;
    }

    public EstimatePackCityMunicipality(String jisCode, String cityName, String district, String rank, String color, String memo) {
        this.jisCode = jisCode;
        this.cityName = cityName;
        this.district = district;
        this.rank = rank;
        this.color = color;
        this.memo = memo;
    }

    public EstimatePackCityMunicipality() {
        this.jisCode = null;
        this.cityName = null;
        this.district = null;
        this.rank = null;
        this.color = null;
        this.memo = null;
    }
}