/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.common;

import java.io.Serializable;
import lombok.Data;

/**
 *
 * @author MaLei (MBP)
 */
@Data
public class MessageModuleBean implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * SEVERITY
     */
    private String severity;

    /**
     * メッセージID
     */
    private String messageId;

    /**
     * 置換文字
     */
    private String text;

    public MessageModuleBean() {
    }

}
