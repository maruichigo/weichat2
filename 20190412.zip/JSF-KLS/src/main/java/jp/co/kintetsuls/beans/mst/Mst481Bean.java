/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.AutoCompleteBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.LabelValueBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiListCol;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.forms.mst.Mst481Form;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.PrimeFaces;

/**
 * K-INGコード変換マスタ画面
 *
 * @author 雷新然 (MBP)
 * @version 2019/2/12 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst481")
@ViewScoped
@Data
public class Mst481Bean extends AbstractBean {

    /**
     * タイトル
     */
    private final String TITLE  = "K-INGコード変換マスタ";
    
    /**
     * ダウンロードファイル名
     */
    private final static String FILE_NAME  = "K-INGコード変換マスタ一覧"; 

    /**
     * 画面URL
     */
    private String url;

    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

    /**
     * 一覧のAutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoComplete}")
    private AutoCompleteBean autoCompleteBean;

    /**
     *
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authorityConfBean;

    /**
     * ファイルダウンロード
     */
    @ManagedProperty(value = "#{fileBean}")
    private FileBean fileBean;

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;

    /**
     * 画面フォーム
     */
    @ManagedProperty(value = "#{mst481Form}")
    private Mst481Form mst481Form;

    /**
     * 画面共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * 検索シーケンス処理共通
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;
    
    /**
     * 共通マスタ取得
     */
    @ManagedProperty(value = "#{labelValueBean}")
    private LabelValueBean labelValueBean;
    
    /**
     * 一覧単項目チェック共通
     */
    @ManagedProperty(value = "#{listCheckBean}")
    private ListCheckBean listCheckBean;

    /**
     * 履歴一覧処理共通
     */
    @ManagedProperty(value = "#{rirekisyosai}")
    private RirekiSyosaiBean rirekiSyosaiBean;

    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(
            new Object() {}.getClass().getEnclosingClass().getName());

    /**
     * スクリーンコード：MST481
     */
    private static final String SC_CD_MST481 = "MST481_SCREEN";

    /**
     * 定数：検索件数取得ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH_KENSU = "mst481-get-king-code-kensu";

    /**
     * 定数：検索ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH = "mst481-get-king-code-detail";

    /**
     * 定数：登録の重複チェックファンクションコード
     */
    private static final String FUNC_CODE_INSERT_UPDATE_CHECK = "mst481-insert-update-check";

    /**
     * 定数：削除の存在チェックファンクションコード
     */
    private static final String FUNC_CODE_DELETE_EXIST = "mst481-delete-exist";

    /**
     * 定数：K-INGコード変換マスタ登録更新ファンクションコード
     */
    private static final String FUNC_CODE_INSERT_UPDATE = "mst481-insert-king-code";

    /**
     * 定数：行削除ファンクションコード
     */
    private static final String FUNC_CODE_DELETE_ROW = "mst481-delete-row-detail";

    /**
     * 定数：一覧のデータテーブルID
     */
    private static final String DATA_TABLE_ID = "tablesorter_mst481";

    /**
     * 定数：画面項目保持キー
     */
    private static final String CONST_MST481_FORM = "mst481Form";

    /**
     * 定数：MasterInfo取得キー
     */
    private static final String CONST_MST481_MASTER = "mst481";
    
    /**
     * 定数：再検索Button取得キー
     */
    private static final String CONST_MST481_SEARCH = "search_mst481"; 

    /**
     * 履歴テーブル検索キー
     */
    private Map<String, Object> rirekiSearchKey;

    /**
     * ワーク.メッセージリスト
     */
    List<MessageModuleBean> msgList = new ArrayList<>();

    /**
     * コンストラクタ
     */
    public Mst481Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId メニューID
     * @param prevScreen 遷移元画面ID
     * @param backFlag 戻るフラグ
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {

            // パンくずを追加する
            breadBean.push(TITLE, SCREEN.MST481_SCREEN.name(), this);
	    
	    // システムマスタ取得する
            pageCommonBean.getMasterInfo(CONST_MST481_MASTER);

            // 検索シーケンス処理を初期化する
            searchHelpBean.regSearchHelp(DATA_TABLE_ID,
                    s -> {return getRecordCount();},
                    s -> {search(); return null;},
                    null);
            searchHelpBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);
	    
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(顧客コードリスト)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_KOKYAKU);
	    
	    // 前回の記録をクリアする
            this.clear();
            mst481Form.setSearchResult(null);
            mst481Form.setSearchResultSelectable(null);
            mst481Form.setSelectedSearchResult(null);

            // 戻ってきた場合
            Mst481Form preForm = (Mst481Form) pageCommonBean.getPageInfo(CONST_MST481_FORM);
            if (backFlag && preForm != null) {
                PageCommonBean.simpleCopy(preForm, mst481Form);
                // 再検索を実施する
                pageCommonBean.searchAgain(CONST_MST481_SEARCH);
            // 進んできた場合
            } else {
                Flash flash = pageCommonBean.getPageParam();
                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_MST481_FORM) != null) {
                    PageCommonBean.simpleCopy(flash.get(CONST_MST481_FORM), mst481Form);
                    // 再検索を実施する
                    pageCommonBean.searchAgain(CONST_MST481_SEARCH);
                }
            }

            // ダウンロードシーケンスを初期化する
            fileBean.setDataSize(DATA_TABLE_ID, (id -> {return getRecordCount();}));
            
            fileBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);
            
            fileBean.setSubFlg(true);
	    
	    fileBean.setTilte(FILE_NAME);
            
            fileBean.regDownloadFucntion(DATA_TABLE_ID, getHeader() ,
                    (id -> {return getKIngCodeList();}));
            
            fileBean.regBeforeDownFucntion(DATA_TABLE_ID,
                    (comment -> {return beforeDown(comment);}));
	    
	    fileBean.setSearchResult(DATA_TABLE_ID, (id -> {return getSearchResult();})); 

            // 行更新また削除するために共通処理へ登録す
            pageCommonBean.regDelFucntion(DATA_TABLE_ID, (dataList -> (this.delRows(dataList))));

            // component初期化とユーザ権限により制御を設定する
            pageCommonBean.setAuthControll(mst481Form, SC_CD_MST481, true);
	    
	    // 初期はデータを編集不可にする
            mst481Form.setBtnHenshuDisabled(true);

        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * カウント処理
     *
     * @return 取得件数
     */
    public Long getRecordCount() {
	
	// 前回の記録をクリアする
	Map<String, Object> mapRec = new LinkedHashMap();
        mapRec.put("hideFlg", "hideRow");
        List<Map<String, Object>> mapList = new ArrayList();
        mapList.add(mapRec);
        mst481Form.setSearchResult(mapList);
        mst481Form.setSearchResultSelectable(new ReportListDataModel(mst481Form.getSearchResult()));
        mst481Form.setSelectedSearchResult(null);
	
	// 検索初期はデータを編集不可にする
        mst481Form.setBtnHenshuDisabled(true);

        // レコード件数を取得する
        long recordCount = getKIngCodeListCount();
	
	// 検索部のステータスを変更する
        pageCommonBean.setSerchConDisabled(mst481Form);
	
	// 参照モードにする
        pageCommonBean.setEditFlg(false);
	
	// サブ検索条件フラグ設定
        fileBean.setSubFlg(subSearchConHad());

        // 検索条件保存
        pageCommonBean.savePageInfo(CONST_MST481_FORM, mst481Form);

        return recordCount;
    }

    /**
     * 検索処理
     *
     */
    public void search() {
	    
	// 選択リストを初期化する
	mst481Form.setSelectedSearchResult(new ArrayList<>());
        mst481Form.setSearchResultSelectable(null);
	// K-INGコード変換マスタ検索を行う
	List<Map<String, Object>> recordList = getKIngCodeList();

	fileBean.setDataList(recordList);

	// 取得した値を画面項目にセットする
	pageCommonBean.setDatalist(DATA_TABLE_ID, recordList);
	mst481Form.setSearchResultSelectable(new ReportListDataModel(recordList));

	// 検索部のステータスを変更する
	pageCommonBean.setSerchConDisabled(mst481Form);

	// 削除済のみのチェック状態より、明細データを編集可／不可にする
	if (mst481Form.getConSakujonomiKensaku() == null || mst481Form.getConSakujonomiKensaku().length == 0) {
	    // 有効データを編集可にする
	    mst481Form.setBtnHenshuDisabled(false);
	} else {
	    // 削除済みデータを編集不可にする
	    mst481Form.setBtnHenshuDisabled(true);
	}

	// 検索条件を保存する
	pageCommonBean.savePageInfo(CONST_MST481_FORM, mst481Form);

	// 参照モードにする
	pageCommonBean.setEditFlg(false);
    }
    
    /**
     * 検索条件変更処理
     *
     */
    public void searchChange() {

        // 検索部のステータスを変更する
        pageCommonBean.setSerchConEnabled(mst481Form);
    }

    /**
     * クリア処理
     *
     */
    public void clear() {

	// 顧客コード
        mst481Form.setConKokyakuCd(null);
	// 顧客名称
        mst481Form.setConKokyakuMei(null);
	// 国内箇所区分
        mst481Form.setConKokunaiKashoKbn(null);
	// 輸入箇所コード
        mst481Form.setConYunyuKashoCd(null);
	// 輸入顧客コード
        mst481Form.setConYunyuKokyakuCd(null);
	// 販売形態区分
        mst481Form.setConHambaiKeitaiKbn(null);
	// 削除のみ検索
        mst481Form.setConSakujonomiKensaku(null);
        
        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mst481Form);
        pageCommonBean.setBtnSearchChangeVisible(false);
        pageCommonBean.setBtnSearchVisible(Boolean.TRUE);
    }

    /**
     * 更新処理
     *
     */
    public void update() {
	
	// エラーメッセージを格納する変数の初期化を行う
        msgList = new ArrayList();

        // 行選択チェックを行う
        if (mst481Form.getSelectedSearchResult() == null || mst481Form.getSelectedSearchResult().isEmpty()) {

            MessageModuleBean message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
            msgList.add(message);

            messagePropertyBean.messageList(msgList);
            return;
        }

        // 登録一覧リストの初期化を行う
        List<Map<String, Object>> torokuIchiranList = new ArrayList();

        // 更新一覧リストの初期化を行う
        List<Map<String, Object>> koshinIchiranList = new ArrayList();
	
	// 単項目チェック処理
        if (!checkJsfParamas(mst481Form.getSelectedSearchResult())) {
            return;
        }

        // 登録更新情報設定処理
	for (Map<String, Object> record : mst481Form.getSelectedSearchResult()) {
	    // K-INGコード変換マスタ一覧.カレント行 = 登録対象の場合
	    if (record.get(StndConsIF.CONST_ADD_ROW_KEY) != null) {
		// 登録データワークにデータを設定する
		torokuIchiranList.add(record);
	    // K-INGコード変換マスタ一覧.カレント行 ≠ 登録対象の場合
	    } else {
		// 更新データワークにデータを設定する
		koshinIchiranList.add(record);
	    } 
        }

	// 登録・更新処理を行う
	int status = insertUpdateKIngCodeList();

	// エラーの場合、処理終了
	if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
	    return;
	}

	// 登録の後に再度検索する
	this.search();

        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, "更新");
        
        // ログ出力を行う
        LOGGER.info("更新 " + mst481Form.getSelectedSearchResult().size() + " 件");
    }

    /**
     * 更新履歴を表示処理
     *
     */
    public void rirekiIchiran() {

        // 履歴テーブル検索キーを設定する
        rirekiSearchKey = new HashMap();
        
        // 選択されたレコードを取得する
        Map<String, Object> selectedRecord = mst481Form.getSelectedSearchResult().get(0);
	// 国内箇所区分
	rirekiSearchKey.put("listKokunaiKashoKbn", selectedRecord.get("listKokunaiKashoKbn"));
	// 輸入箇所コード
        rirekiSearchKey.put("listYunyuKashoCd", selectedRecord.get("listYunyuKashoCd"));
	// 販売形態区分
        rirekiSearchKey.put("listHambaiKeitaiKbn", selectedRecord.get("listHambaiKeitaiKbn"));
	// 輸入顧客コード
        rirekiSearchKey.put("listYunyuKokyakuCd", selectedRecord.get("listYunyuKokyakuCd"));

        // 履歴タイトルを設定する
        rirekiSyosaiBean.setListColName(
                new ArrayList<>(Arrays.asList("バージョン情報", "国内箇所区分", "輸入箇所コード", "輸入顧客コード",
			"販売形態区分", "顧客コード", "顧客名", "予備１", "予備２", "予備３", "予備４",
			"予備５", "予備６", "予備７", "予備８", "予備９", "予備１０")));

        // 履歴beanの項目物理名を設定する
        List<String> colValue = new ArrayList<>(Arrays.asList(
		"listDataVersion", "listKokunaiKashoKbn", "listYunyuKashoCd", "listYunyuKokyakuCd",
		"listHambaiKeitaiKbn", "listKokyakuCd", "listKokyakuMei", "listYobi1", "listYobi2",
		"listYobi3", "listYobi4", "listYobi5", "listYobi6", "listYobi7", "listYobi8",
		"listYobi9", "listYobi10"));
	List<String> colAlign = new ArrayList<>(Arrays.asList("left", "left", "left", "left", "left", "left",
		"left", "left", "left", "left", "left", "left", "left", "left", "left", "left", "left"));
	
	List<RirekiListCol> listCol = new ArrayList<>();
        for (int i = 0; i < colValue.size(); i++) {
           RirekiListCol col = new RirekiListCol();
           col.setColValue(colValue.get(i));
           col.setColAlign(colAlign.get(i));
           listCol.add(col);
        }
	rirekiSyosaiBean.setListCol(listCol);
	
        // 履歴テーブルを検索する
        rirekiSyosaiBean.searchList("2", "MST481_SEARCH_RIREKI", rirekiSearchKey);
    }
    
    /**
     * 業務削除処理ファンクション領域
     *
     */
    public void delRowsFunc() {

        pageCommonBean.getSelectedDatasList().put(DATA_TABLE_ID, mst481Form.getSelectedSearchResult());
        pageCommonBean.delRowsWithMsg(DATA_TABLE_ID, MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0013);

    }
    
    /**
     * 業務削除処理
     *
     * @param recordList レコードリスト
     * @return 正常／異常
     */
    public Boolean delRows(List<Map<String, Object>> recordList) {

        // エラーメッセージを格納する変数を初期化する
        msgList = new ArrayList<>();

        // 行選択チェック
        if (recordList.isEmpty()) {
            MessageModuleBean message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0013);
            msgList.add(message);
            
            return false;
        }

        // 存在チェック
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(recordList, FUNC_CODE_DELETE_EXIST);
        
        // エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
	    
            MessageModuleBean message = messagePropertyBean.createMessageModule( 
                    res.getMessages().get(0)[0], 
                    res.getMessages().get(0)[1],
                    res.getMessages().get(0)[2],
                    "K-INGコード変換マスタ");
            msgList.add(message);
            messagePropertyBean.messageList(msgList);
            return false;
        }

        // 削除処理を行う
        int status = deleteKIngCodeList(recordList);
        
        // エラーの場合、処理を終了
        if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            return false;
        }
	
	// 画面レコード削除
        mst481Form.getSearchResult().removeAll(recordList);

        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, "削除");
        
        // ログ出力
        LOGGER.info("削除 " + recordList.size() + " 件");
        
        return true;
    }
    
    /**
     * メニュークリック処理
     *
     * @param menuId メニューID
     * @param nextScreenId 遷移先画面ID
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreenId) {
        try {
            // パンくずを削除する
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移を行う
        url = forward(nextScreenId, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック処理
     *
     * @param nextScreenId 遷移先画面ID
     * @param breadIndex パンくずのインデックス
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreenId, int breadIndex) {

        try {
            // パンくずを削除する
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        
        // 画面遷移を行う
        url = forward(nextScreenId, null, null, true);
        return url;
    }

    /**
     * ログアウトクリック処理
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authorityConfBean.logout();
    }

    /**
     * CSVファイルのタイトルを設定する処理
     * 
     * @return 画面タイトル
     */
    public List<CSVDto> getHeader() {
       
        // CSVファイルのタイトルを設定する
        List<CSVDto> header = new ArrayList<>();
	// 国内箇所区分
        header.add(new CSVDto("国内箇所区分", "listKokunaiKashoKbn"));
	// 輸入箇所コード
        header.add(new CSVDto("輸入箇所コード", "listYunyuKashoCd"));
	// 輸入顧客コード
        header.add(new CSVDto("輸入顧客コード", "listYunyuKokyakuCd"));
	// 販売形態区分
        header.add(new CSVDto("販売形態区分", "listHambaiKeitaiKbnName"));
	// 顧客コード
        header.add(new CSVDto("顧客コード", "listKokyakuCd"));
	// 顧客名
        header.add(new CSVDto("顧客名", "listKokyakuMei"));
	// 予備１
        header.add(new CSVDto("予備１", "listYobi1"));
	// 予備２
        header.add(new CSVDto("予備２", "listYobi2"));
	// 予備３
        header.add(new CSVDto("予備３", "listYobi3"));
	// 予備４
        header.add(new CSVDto("予備４", "listYobi4"));
	// 予備５
        header.add(new CSVDto("予備５", "listYobi5"));
	// 予備６
        header.add(new CSVDto("予備６", "listYobi6"));
	// 予備７
        header.add(new CSVDto("予備７", "listYobi7"));
	// 予備８
        header.add(new CSVDto("予備８", "listYobi8"));
	// 予備９
        header.add(new CSVDto("予備９", "listYobi9"));
	// 予備１０
        header.add(new CSVDto("予備１０", "listYobi10"));
        
        // 取得値を返却する
        return header;
    }
    
    /**
     * ダウンロード理由を記録する処理
     *
     * @param comment 理由コメント
     * @return 正常／異常
     * @throws Exception
     */
    public boolean beforeDown(String comment) throws Exception {
        
        // ダウンロード理由を記録する
        System.out.println(comment);
        
        return true;
    }
    
    /**
     * アップロード
     * 
     * @return 遷移先画面のURL
     */
    public String upload() {
        
        // flash初期化
        Flash flash = pageCommonBean.getPageParam();
        
        // flashにアップロード機能コードを設定する
        flash.put("uploadFunctionCd", TITLE);
        
        // アップロード画面へ遷移
        url = forward(Cnst.SCREEN.UPLOAD_SCREEN.name(), null, Cnst.SCREEN.UPLOAD_SCREEN.name(), false);
        return url;
    }
    
    /**
     * 顧客取得Autocomplete一覧を取得する処理
     * 
     * @param key 検索キー
     * @return Autocompleteリスト
     */    
    public List<String> getAutoCompForKokyakuCdList(String key) {
        return autoCompleteBean.getStringListByKey(MsCnst.COM_GET_VW_KOKYAKU, key);
    }
    
    /**
     * ダウンロード販売形態区分名を取得する処理
     * @param value
     * @param rowIndex
     */
    public void  hambaiKeitaiKbnSet(String value,int rowIndex){
	
	String kbnMei = "";
	if("1".equals(value)){
	   kbnMei=  "A";
	}else if("2".equals(value)){
	     kbnMei = "N";
	}
	mst481Form.getSearchResultSelectable().getDatasource().get(rowIndex).put("listHambaiKeitaiKbnName", kbnMei);
    }

    /**
     * DBからK-INGコード変換マスタ検索件数を取得する処理
     * 
     */
    private long getKIngCodeListCount() {

        // パラメータ
        Map<String, Object> params = new HashMap<>();
        
        // 顧客コード
        params.put("conKokyakuCd", mst481Form.getConKokyakuCd());
        // 顧客名称
        params.put("conKokyakuMei", mst481Form.getConKokyakuMei());
        // 国内箇所区分
        params.put("conKokunaiKashoKbn", mst481Form.getConKokunaiKashoKbn());
        // 輸入箇所コード
        params.put("conYunyuKashoCd", mst481Form.getConYunyuKashoCd());
        // 輸入顧客コード
        params.put("conYunyuKokyakuCd", mst481Form.getConYunyuKokyakuCd());
        // 販売形態区分
        params.put("conHambaiKeitaiKbn", mst481Form.getConHambaiKeitaiKbn());
        // 削除のみ検索
        params.put("conSakujonomiKensaku", mst481Form.getConSakujonomiKensaku());
        
        // DBをアクセスする
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH_KENSU);

        // 検索件数を返却する
        return Long.valueOf(serviceInterfaceBean.getJson());
    }
    
    /**
     * 一覧の単項目チェック処理
     * 
     * @param params 画面一覧パラメータ
     * @return チェックの結果
     */
    private boolean checkJsfParamas(List<Map<String, Object>> params) {

        List<ListCheckBean> checks = new ArrayList<>();
        checks.add(new ListCheckBean("listKokunaiKashoKbn", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "国内箇所区分"));
        checks.add(new ListCheckBean("listYunyuKashoCd",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "輸入箇所コード"));
	checks.add(new ListCheckBean("listYunyuKokyakuCd",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "輸入顧客コード"));
	checks.add(new ListCheckBean("listHambaiKeitaiKbn",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "販売形態区分"));
	checks.add(new ListCheckBean("listKokunaiKashoKbn",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "国内箇所区分","3"));
	checks.add(new ListCheckBean("listYunyuKashoCd",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "輸入箇所コード","15"));
	checks.add(new ListCheckBean("listYunyuKokyakuCd",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "輸入顧客コード","15"));
	checks.add(new ListCheckBean("listYobi1",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "予備１","3"));
	checks.add(new ListCheckBean("listYobi2",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "予備２","3"));
	checks.add(new ListCheckBean("listYobi3",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "予備３","3"));
	checks.add(new ListCheckBean("listYobi4",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "予備４","3"));
	checks.add(new ListCheckBean("listYobi5",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "予備５","3"));
	checks.add(new ListCheckBean("listYobi6",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "予備６","3"));
	checks.add(new ListCheckBean("listYobi7",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "予備７","3"));
	checks.add(new ListCheckBean("listYobi8",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "予備８","3"));
	checks.add(new ListCheckBean("listYobi9",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "予備９","3"));
	checks.add(new ListCheckBean("listYobi10",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "予備１０","3"));
	checks.add(new ListCheckBean("listKokunaiKashoKbn",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_IS_HALF, "国内箇所区分"));
	checks.add(new ListCheckBean("listYunyuKashoCd",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_IS_HALF, "輸入箇所コード"));
	checks.add(new ListCheckBean("listYunyuKokyakuCd",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_IS_HALF, "輸入顧客コード"));
	checks.add(new ListCheckBean("listKokyakuCd",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_IS_HALF, "顧客コード"));
	checks.add(new ListCheckBean("listYobi1",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_IS_HALF, "予備１"));
	checks.add(new ListCheckBean("listYobi2",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_IS_HALF, "予備２"));
	checks.add(new ListCheckBean("listYobi3",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_IS_HALF, "予備３"));
	checks.add(new ListCheckBean("listYobi4",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_IS_HALF, "予備４"));
	checks.add(new ListCheckBean("listYobi5",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_IS_HALF, "予備５"));
	checks.add(new ListCheckBean("listYobi6",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_IS_HALF, "予備６"));
	checks.add(new ListCheckBean("listYobi7",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_IS_HALF, "予備７"));
	checks.add(new ListCheckBean("listYobi8",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_IS_HALF, "予備８"));
	checks.add(new ListCheckBean("listYobi9",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_IS_HALF, "予備９"));
	checks.add(new ListCheckBean("listYobi10",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_IS_HALF, "予備１０"));
        List<MessageModuleBean> checkMsgList = listCheckBean.check(params, checks, true);

        if (!checkMsgList.isEmpty()) {
            return false;
        }
        return true;
    }

    /**
     * DBからK-INGコード変換マスタ情報を取得する処理
     * 
     */
    private List<Map<String, Object>> getKIngCodeList() {

        // パラメータ
        Map<String, Object> params = new HashMap<>();
        
        // 顧客コード
        params.put("conKokyakuCd", mst481Form.getConKokyakuCd());
        // 顧客名称
        params.put("conKokyakuMei", mst481Form.getConKokyakuMei());
        // 国内箇所区分
        params.put("conKokunaiKashoKbn", mst481Form.getConKokunaiKashoKbn());
        // 輸入箇所コード
        params.put("conYunyuKashoCd", mst481Form.getConYunyuKashoCd());
        // 輸入顧客コード
        params.put("conYunyuKokyakuCd", mst481Form.getConYunyuKokyakuCd());
        // 販売形態区分
        params.put("conHambaiKeitaiKbn", mst481Form.getConHambaiKeitaiKbn());
        // 削除のみ検索
        params.put("conSakujonomiKensaku", mst481Form.getConSakujonomiKensaku());

        // DBをアクセスする
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH);

        try {
            ObjectMapper mapper = new ObjectMapper();
            mst481Form.setSearchResult(mapper.readValue(serviceInterfaceBean.getJson(), List.class));

        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
        
        // K-INGコード変換マスタ情報を返却する
        return mst481Form.getSearchResult();
    }

    /**
     * DBへK-INGコード変換マスタを登録また更新する処理
     * 
     */
    private int insertUpdateKIngCodeList() {

        // 重複、存在チェック
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.accsessDBWithList(
                mst481Form.getSelectedSearchResult(), FUNC_CODE_INSERT_UPDATE_CHECK);
        
        // エラーの場合、処理を終了
        if (serviceInterfaceBean.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            messagePropertyBean.message(serviceInterfaceBean.getMessages().get(0)[0],
                    serviceInterfaceBean.getMessages().get(0)[1],
                    serviceInterfaceBean.getMessages().get(0)[2],
                    serviceInterfaceBean.getTableName());

            return serviceInterfaceBean.getStatusCode();
        }

        // 登録一覧リストと更新一覧リストの内容を処理する
        serviceInterfaceBean = pageCommonBean.accsessDBWithList(
                mst481Form.getSelectedSearchResult(), FUNC_CODE_INSERT_UPDATE);

        return serviceInterfaceBean.getStatusCode();
    }

    /**
     * DBからK-INGコード変換マスタ情報を削除する処理
     * 
     * @param recordList レコードリスト
     * @return ステータスコード
     */
    private int deleteKIngCodeList(List<Map<String, Object>> recordList) {

        // DBをアクセス
        ServiceInterfaceBean serviceInterfaceBean =
                pageCommonBean.accsessDBWithList(recordList, FUNC_CODE_DELETE_ROW);

        // ステータスコードを返却する
        return serviceInterfaceBean.getStatusCode();
    }
    
    /**
     * ダウンロード用検索結果取得
     * 
     * @return 検索結果
     */
    private List<Map<String, Object>> getSearchResult() {
        return mst481Form.getSearchResult();
    }
    
    /**
     * サブ検索条件入力判断
     * 
     * @return true:入力あり/false:入力しない
     */
    private boolean subSearchConHad() {
        
        // 輸入箇所コード
        if (!StringUtils.isEmpty(mst481Form.getConYunyuKashoCd())) {
            return true;
        }
        // 輸入顧客コード
        if (!StringUtils.isEmpty(mst481Form.getConYunyuKokyakuCd())) {
            return true;
        }
        // 販売形態区分
        if (!StringUtils.isEmpty(mst481Form.getConHambaiKeitaiKbn())) {
            return true;
        }
        // 削除のみ検索
        if (mst481Form.getConSakujonomiKensaku() != null && mst481Form.getConSakujonomiKensaku().length > 0) {
            return true;
        }

        return false;
    }
      
}
