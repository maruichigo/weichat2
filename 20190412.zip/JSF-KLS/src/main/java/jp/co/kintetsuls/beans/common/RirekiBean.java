/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.common;

import java.io.Serializable;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import lombok.Data;

/**
 *
 * @author YinMingLong (MBP)
 */
@javax.faces.bean.ManagedBean(name = "rirekiBean")
@ViewScoped
@Data
public class RirekiBean implements Serializable {

    private static final long serialVersionUID = 1L;
  
    // 主キー
    private Map<String, Object> primaryKey;

    // バージョン情報
    private String version;

    // 適用開始日
    private String tekiyoKaishibi;
    
    // 最終更新日
    private String lastUpdateDate;

    // 最終更新者
    private String lastUpdateUser;

    // 履歴内容
    private Map<String, Object> dataMapper;

    // 背景色
    private Map<String, Object> styleMapper;

    private RirekiBean next;

    private RirekiBean previous;

}
