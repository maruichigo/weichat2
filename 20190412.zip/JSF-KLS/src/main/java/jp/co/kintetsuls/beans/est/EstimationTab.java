/*
 * EstimationTab.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.est;

import java.io.Serializable;

    public class EstimationTab implements Serializable {

        private String title;
        private String url;
        private int index = -1;

        public EstimationTab(String title, String url, int index) {
            this.title = title;
            this.url = url;
            this.index = index;
        }

        public String getTitle() {
            return title;
        }

        public String getUrl() {
            return url;
        }

        public int getIndex() {
            return index;
        }

    }