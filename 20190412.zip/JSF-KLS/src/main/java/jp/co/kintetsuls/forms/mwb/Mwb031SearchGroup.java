/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.forms.mwb;

/**
 * 検索グループ
 * 
 * @author 許 彭戈ヤン (MBP)
 * @Version 2019/03/12 新規作成
 */
public interface Mwb031SearchGroup {
    
}
