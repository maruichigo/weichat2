/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.service.common;

import jp.co.kintetsuls.service.general.RestfullService;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import org.primefaces.model.menu.DefaultMenuColumn;
import org.primefaces.model.menu.DefaultMenuItem;
import org.primefaces.model.menu.DefaultMenuModel;
import org.primefaces.model.menu.DefaultSubMenu;
import org.primefaces.model.menu.MenuModel;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.sharedsys.beans.session.MenuBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import org.apache.commons.lang3.EnumUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.model.menu.DefaultSeparator;

public class MenuService {
    private static final Logger logger = LogManager.getLogger(new Object(){}.getClass().getEnclosingClass().getName());
    
    public ServiceInterfaceBean getMenu(String userCd, RestfullService rest, MenuBean menuBean)  throws SystemException, IOException {
        ServiceInterfaceBean req = new ServiceInterfaceBean();
        req.setFunctionCode("COMMON_GET_ALL_MENU");
        req.setUserCd(userCd);

        //parameter
        Map<String, Object> params = new HashMap<>();
        params.put("userCd", userCd);
        String requestData = JSONUtil.makeJSONString(params);
        req.setJson(requestData);

        //JAX-RS接続を実行
        rest = RestfullService.getInstance();
        ServiceInterfaceBean res = rest.request(req);
        List<Map<String, Object>> menuResult = rest.jsonResMapList(res);

        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR){
            String msg = "利用可能なメニューが取得できませんでした。";
            logger.error(msg);
            res.addMessage("ERROR", "エラー", msg);
            res.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return res;
        }

        MenuModel menumodel = buildDbMenuList(menuResult);
        if (null != menumodel ){
            menuBean.setModel(menumodel);
        }

        return res;
    }

    /** 
     * DBから取得したメニューをModelに成形して戻す
     * @param parentList
     * @return
     * @throws SystemException 
     */
    private MenuModel buildDbMenuList(List<Map<String, Object>> parentList) throws SystemException {

        MenuModel model = new DefaultMenuModel();
        
        for (Map parentMap : parentList){
            DefaultSubMenu parentMenu = new DefaultSubMenu((String)parentMap.get("parentGroupName"));
            List<Map<String, Object>> childList = (List<Map<String, Object>>) parentMap.get("childs");

            DefaultMenuColumn menuSection = new DefaultMenuColumn();

            for(Map childMap : childList) {

                DefaultSubMenu childMenu = new DefaultSubMenu((String)childMap.get("childGroupName"));
                List<Map<String, Object>> itemList = (List<Map<String, Object>>) childMap.get("items");
                
                for(Map item : itemList) {
                    DefaultMenuItem menuItem = new DefaultMenuItem((String)item.get("menuName"));

                    String menuId = (String)item.get("menuId");
                    String screenId = (String)item.get("screenId");
                    String bean = null;
                    try{
                        Cnst.SCREEN screen = Cnst.SCREEN.valueOf(screenId);
                        bean = screen.getAnno();
                    } catch (Exception e){
                        //TODO SCREENに登録後戻す
                        //throw new SystemException(e);
                    }
                    //メニュー押下時コマンド
                    if("LOGOUT".equals(screenId)){
                        //ログアウト
                        menuItem.setCommand("#{authConfBean.logoutClick}");
                    } else {
                        //メニュークリック
                        menuItem.setCommand("#{menuBean.menuClick}");
                    }

                    menuItem.setUpdate(":main_section");
                    menuItem.setParam("screenId", screenId);
                    menuItem.setParam("menuId", menuId);
                    //メニューのOnstart,OnCompleteが登録されていたら登録
                    if(EnumUtils.isValidEnum(Cnst.SCREEN_ACT.class, "START_COMPLETE")) {
                        Cnst.SCREEN_ACT act = Cnst.SCREEN_ACT.valueOf("START_COMPLETE");
                        menuItem.setOnstart(act.getOnStart());
                        menuItem.setOncomplete(act.getOnComplete());
                    }
                    menuItem.setStyleClass("ssnavi-itemlink");
//                    menuItem.setStyle("padding-left: 15px;background-image: url('../../resources/images/ico_search_btn.gif') !important;background-repeat: no-repeat;background-position: left;");
                    menuItem.setIcon("fa fa-car");
                    childMenu.addElement(menuItem);
                }
                menuSection.addElement(childMenu);
            }
            parentMenu.addElement(menuSection);
            model.addElement(parentMenu);
    
        }
        
        return model;
    }    
    
}
