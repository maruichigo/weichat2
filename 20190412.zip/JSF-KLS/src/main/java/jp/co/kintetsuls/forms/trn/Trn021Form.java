/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.trn;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.forms.common.LabelValueForm;
import lombok.Data;

/**
 * 貨物詳細 フォーム
 *
 * @author 作成者 (MBP)
 * @version 2019/1/31 新規作成
 */
@javax.faces.bean.ManagedBean(name = "trn021Form")
@ViewScoped
@Data
public class Trn021Form {

    /**
     * 送り状No
     */
    private String k12 = "123456-1234567";

    /**
     * お客様管理No
     */
    private String k13 = "12345678901234567890";

    /**
     * 集荷日
     */
    private String k15 = "2017/10/02";

    /**
     * 経理計上日
     */
    private String k16 = "2017/10/02";

    /**
     * 伝票種別
     */
    private String k17 = "01 一般貨物";

    /**
     * 輸送方法
     */
    private String k18 = "11 最終便";

    /**
     * 元着区分
     */
    private String k19 = "01 元払";

    /**
     * 支払方法
     */
    private String k20 = "01 後払";

    /**
     * 引取輸送
     */
    private String[] k21;

    /**
     * 引取輸送リスト
     */
    private List<LabelValueForm> k21LabelValueList;

    /**
     * 他社中継
     */
    private String[] k22;

    /**
     * 他社中継リスト
     */
    private List<LabelValueForm> k22LabelValueList;

    /**
     * 第三支払
     */
    private String[] k23;

    /**
     * 第三支払リスト
     */
    private List<LabelValueForm> k23LabelValueList;

    /**
     * 第三者払コード
     */
    private String k24 = "123456";

    /**
     * 第三者払会社
     */
    private String k25 = "〇〇株式会社";

    /**
     * 第三者払支店
     */
    private String k26 = "110 仙台営業所";

    /**
     * 請求先コード
     */
    private String k27 = "123456";

    /**
     * 請求先会社
     */
    private String k28 = "〇〇株式会社";

    /**
     * 請求先支店
     */
    private String k29 = "110 仙台営業所";

    /**
     * 契約先コード
     */
    private String k30 = "123456";

    /**
     * 契約先会社
     */
    private String k31 = "株式会社△△";

    /**
     * 契約先支店
     */
    private String k32 = "121 新東京営業所";

    /**
     * 着払請求先コード
     */
    private String k33 = "123456";

    /**
     * 着払請求先会社
     */
    private String k34 = "〇〇株式会社";

    /**
     * 着払請求先支店
     */
    private String k35 = "110 仙台営業所";

    /**
     * 個数
     */
    private String k36 = "999個";

    /**
     * 重量
     */
    private String k37 = "100Kg";

    /**
     * 容積重量
     */
    private String k38 = "100cm³";

    /**
     * 特記事項
     */
    private String k39 = "特記事項AAAAAA";

    /**
     * 備考欄
     */
    private String k40 = "備考BBBBB";

    /**
     * 請求金額
     */
    private String k41 = "25,000円";

    /**
     * トレース一覧情報
     */
    private List<Map<String, String>> b45List;

    /**
     * 発店控画像
     */
    private String k54 = "あり";

    /**
     * 受領書
     */
    private String k55 = "11";

    /**
     * 到着予定
     */
    private String k56 = "翌日 09時～13時";

    /**
     * 到着可否
     */
    private String k57 = "可";

    /**
     * 配達営業所
     */
    private String k59 = "121 新東京営業所";

    /**
     * 着空港
     */
    private String k60 = "999 〇〇空港";

    /**
     * 配達指示
     */
    private String k61 = "04 配達チャーター";

    /**
     * 配達指定日
     */
    private String k62 = "2017/10/03";

    /**
     * 経由空港
     */
    private String k63 = "001 羽田空港";

    /**
     * 集荷営業所
     */
    private String k64 = "101 △△営業所";

    /**
     * 発空港
     */
    private String k65 = "999 〇〇空港";

    /**
     * 集荷指示
     */
    private String k66 = "03 集荷チャーター";

    /**
     * 保険
     */
    private String k67 = "01 一般";

    /**
     * 保険金額
     */
    private String k68 = "10万円";

    /**
     * MAWB(小口）
     */
    private String[] k69;

    /**
     * MAWB(小口）リスト
     */
    private List<LabelValueForm> k69LabelValueList;

    /**
     * 航空会社コード
     */
    private String k70 = "AIR001";

    /**
     * 航空会社
     */
    private String k71 = "○〇航空";

    /**
     * MAWB番号
     */
    private String k72 = "12345678";

    /**
     * 代理店コード
     */
    private String k73 = "AB001";

    /**
     * 代理店
     */
    private String k74 = "〇〇運送会社";

    /**
     * 他社送り状
     */
    private String k75 = "123456789012";

    /**
     * 電話番号
     */
    private String k77 = "03-0000-0000";

    /**
     * 地区
     */
    private String k78 = "A";

    /**
     * 郵便番号
     */
    private String k79 = "000-1111";

    /**
     * JISコード
     */
    private String k80 = "13100";

    /**
     * 住所１
     */
    private String k81 = "東京都品川区〇〇";

    /**
     * 住所２
     */
    private String k82 = "３－１－１１";

    /**
     * 住所３
     */
    private String k83 = "東京ターミナル";

    /**
     * 住所４
     */
    private String k84 = "";

    /**
     * 名前１
     */
    private String k85 = "株式会社□□";

    /**
     * 名前２
     */
    private String k86 = "〇〇事業部";

    /**
     * 名前３
     */
    private String k87 = "";

    /**
     * 名前４
     */
    private String k88 = "";

    /**
     * 仕向地コード
     */
    private String k89 = "13109-00";

    /**
     * 仕向地
     */
    private String k90 = "品川";

    /**
     * 荷送人コード
     */
    private String k92 = "987654";

    /**
     * 電話番号
     */
    private String k93 = "098-999-8888";

    /**
     * 地区
     */
    private String k94 = "A";

    /**
     * 郵便番号
     */
    private String k95 = "222-1111";

    /**
     * JISコード
     */
    private String k96 = "13100";

    /**
     * 住所１
     */
    private String k97 = "沖縄県那覇市△△";

    /**
     * 住所２
     */
    private String k98 = "９－８－１";

    /**
     * 住所３
     */
    private String k99 = "〇〇マンション１１１";

    /**
     * 住所４
     */
    private String k100 = "";

    /**
     * 名前１
     */
    private String k101 = "□□株式会社";

    /**
     * 名前２
     */
    private String k102 = "〇〇部";

    /**
     * 名前３
     */
    private String k103 = "";

    /**
     * 名前４
     */
    private String k104 = "";

    /**
     * お客様管理No一覧
     */
    private List<Map<String, String>> b105List;

    /**
     * 品名
     */
    private String k110 = "食べ物";

    /**
     * 記事欄１
     */
    private String k111 = "記事１";

    /**
     * 記事欄２
     */
    private String k112 = "記事２";

    /**
     * 記事欄３
     */
    private String k113 = "記事３";

    /**
     * 記事欄４
     */
    private String k114 = "記事４";

    /**
     * 記事欄５
     */
    private String k115 = "記事５";

    /**
     * 関連ファイル
     */
    private ReportListDataModel b116List;

    /**
     * 関連ファイル選択された結果
     */
    private List<Map<String, String>> b116SelectedResult;

    /**
     * ステータス
     */
    private String k121 = "未請求";

    /**
     * エラー情報
     */
    private String k122 = "〇〇エラー";

    /**
     * 締日
     */
    private String k124 = "2017/10/02";

    /**
     * 請求書No
     */
    private String k125 = "-";

    /**
     * 請求書記載日
     */
    private String k126 = "2017/10/01";

    /**
     * 入力営業所
     */
    private String k128 = "〇〇営業所";

    /**
     * 入力担当者
     */
    private String k129 = "〇〇　〇〇";

    /**
     * 入力日時
     */
    private String k130 = "2018/01/11 10:11:22";

    /**
     * 更新営業所
     */
    private String k131 = "〇〇営業所";

    /**
     * 更新担当者
     */
    private String k132 = "〇〇　〇〇";

    /**
     * 更新日時
     */
    private String k133 = "2018/01/13 12:10:45";

    /**
     * 送り状選択ポップアップリスト
     */
    private List<Map<String, String>> b146List;

    /**
     * 送り状No
     */
    private String k158 = "123456-1234567";

    /**
     * 売上漏れ
     */
    private String k159 = "売上漏れ";

    /**
     * トレース
     */
    private String k160 = "配完";

    /**
     * ポイント
     */
    private String k161 = "品川営業所";

    /**
     * 日時
     */
    private String k162 = "2017/10/02  18:00";

    /**
     * 担当者
     */
    private String k163 = "〇〇　××";

    /**
     * 個数
     */
    private String k164 = "3";

    /**
     * 区分
     */
    private String k165 = "正常";

    /**
     * 関連会社
     */
    private String k166 = "1234 ××会社";

    /**
     * 項目
     */
    private String k167 = "車番";

    /**
     * 内容
     */
    private String k168 = "1111";

    /**
     * 項目2内容2List
     */
    private List<Map<String, String>> k169List;

    /**
     * サムネイル画像
     */
    private List<String> k171 = Arrays.asList("ajaxloadingbar.gif","axis-logo.png","axis-logout.png");

    /**
     * 画像コメント
     */
    private String k172 = "画像コメント";

    /**
     * 枝番一覧
     */
    private List<Map<String, String>> b173List;

    /**
     * 領収書発行
     */
    private List<Map<String, String>> b182List;

    /**
     * ユニットNo
     */
    private String k190 = "1234";

    /**
     * 送り状一覧
     */
    private List<Map<String, String>> b189List;

}
