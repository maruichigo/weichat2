/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mwb;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import lombok.Data;

/**
 * VOID入力フォーム
 *
 * @author 許 彭戈ヤン (MBP)
 * @version 2019/02/18 新規作成
 */
@ManagedBean(name = "mwb031Form")
@ViewScoped
@Data
public class Mwb031Form implements Serializable {

    private static final long serialVersionUID = 1L;
    
    /**
     * タイトル
     */
    private String jokenTitle;

    /**
     * 作業区分選択
     */
    private String conSelectSagyoKubun;

    /**
     * 発券営業所コード
     */
    private AutoCompOptionBean conSearchHakkenEigyoshoCd;

    /**
     * VOID年月
     */
    private String conSearchVoidNengetsu;

    /**
     * 航空会社レターコード
     */
    private AutoCompOptionBean conSearchKokuGaishaLetterCd;

    /**
     * 航空会社レターコード
     */
    private AutoCompOptionBean conInsertKokuGaishaLetterCd;

    /**
     * MAWB番号
     */
    private String conInsertMawbBango;

    /**
     * 配布先営業所コード
     */
    private String conInsertHaifusakiEigyoshoCd;

    /**
     * 配布先営業所名
     */
    private String conInsertHaifusakiEigyoshoMei;

    /**
     * VOID日付
     */
    private String conInsertVoidHizuke;

    /**
     * 理由
     */
    private String conInsertRiyu;

    /**
     * 発券営業所コード
     */
    private String conInsertHakkenEigyoshoCd;

    /**
     * MAWB登録ID
     */
    private String conInsertMawbTorokuId;

    /**
     * MAWB配布ID
     */
    private String conInsertMawbHaifuId;

    /**
     * 発券営業所コードDisable
     */
    private Boolean conSearchHakkenEigyoshoCdDisabled;

    /**
     * VOID年月Disable
     */
    private Boolean conSearchVoidNengetsuDisabled;

    /**
     * 航空会社レターコードDisable
     */
    private Boolean conSearchKokuGaishaLetterCdDisabled;
    
    /**
     * 作業区分選択Disabled
     */
    private Boolean conSelectSagyoKubunDisabled;

    /**
     * 単一結果
     */
    private Map<String, Object> singleResult;

    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;

    /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;

    /**
     * 選択された結果
     */
    private List<Map<String, Object>> selectedSearchResult;

}
