/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import javax.faces.model.SelectItem;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.KbnBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.forms.mst.Mst142Form;
import jp.co.kintetsuls.utils.NumberUtils;
import jp.co.kintetsuls.utils.StrUtils;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.PrimeFaces;
import org.primefaces.event.CellEditEvent;

/**
 * 施設マスタ詳細画面
 *
 * @author 王永 (MBP)
 * @version 2019/03/14 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst142")
@ViewScoped
@Data
public class Mst142Bean extends BaseBean {

    /**
     * タイトル
     */
    private final String TITLE = "施設マスタ詳細";

    /**
     * 画面URL
     */
    private String url;

    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

    /**
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    /**
     * 画面フォーム
     */
    @ManagedProperty(value = "#{mst142Form}")
    private Mst142Form mst142Form;

    /**
     * 画面共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * 検索シーケンス処理共通
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;

    /**
     * 履歴一覧処理共通
     */
    @ManagedProperty(value = "#{rirekisyosai}")
    private RirekiSyosaiBean rirekiSyosai;

    /**
     * 一覧単項目チェック共通
     */
    @ManagedProperty(value = "#{listCheckBean}")
    private ListCheckBean listCheckBean;

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;

    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(
            new Object() {
            }.getClass().getEnclosingClass().getName());

    /**
     * スクリーンコード：MST142
     */
    private static final String SC_CD_MST142 = "MST142_SCREEN";

    /**
     * 定数：検索ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH = "MST142_SEARCH";

    /**
     * 定数：フロア検索ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH_FLOOR = "MST142_SEARCH_FLOOR";

    /**
     * 定数：ロケーション検索ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH_LOCATION = "MST142_SEARCH_LOCATION";

    /**
     * 定数：施設申請処理ファンクションコード
     */
    private static final String FUNC_CODE_APPLY = "MST142_APPLY";

    /**
     * 定数：申請ステータス更新ファンクションコード
     */
    private static final String FUNC_CODE_UPDATE_STATUS = "MST142_UPDATE_STATUS";

    /**
     * 定数：明細フロアのデータテーブルID
     */
    private static final String DATA_TABLE_ID_FLOOR = "summary_list";

    /**
     * 定数：明細ロケーションのデータテーブルID
     */
    private static final String DATA_TABLE_ID_LOCATION = "depot_cost_list";

    /**
     * 定数：マスタ情報取得key
     */
    private static final String CONST_MST142_MASTER = "mst142";

    /**
     * 定数：新規登録モードフラグ
     */
    private static final String CONST_MODE_INSERT = "insert";

    /**
     * 定数：詳細照会モードフラグ
     */
    private static final String CONST_MODE_DETAIL = "detail";

    /**
     * 定数：複写申請モードフラグ
     */
    private static final String CONST_MODE_COPY = "copy";

    /**
     * 定数：削除モードフラグ
     */
    private static final String CONST_MODE_DEL = "del";

    /**
     * 定数：論理削除モードフラグ
     */
    private static final String CONST_MODE_FAKEDEL = "fakedel";

    /**
     * 定数：更新モードフラグ
     */
    private static final String CONST_MODE_UPDATE = "update";

    /**
     * ワーク.メッセージリスト
     */
    List<MessageModuleBean> msgList = new ArrayList<>();

    /**
     * 履歴テーブル検索キー
     */
    private Map<String, Object> rirekiSearchKey;

    /**
     * 区分マスタBean
     */
    @ManagedProperty(value = "#{kbnBean}")
    private KbnBean kbnBean;

    /**
     * コンストラクタ
     *
     */
    public Mst142Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId クリックされたメニューID（メニューからの遷移以外はNULL）
     * @param prevScreen 遷移元の画面
     * @param backFlag 戻るフラグ（前画面へボタンからの遷移以外はFALSE）
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {

        try {
            Flash flash = pageCommonBean.getPageParam();

            // パンくず追加
            breadBean.push(TITLE, SCREEN.MST142_SCREEN.name(), this);

            // マスタ内容取得
            pageCommonBean.getMasterInfo(CONST_MST142_MASTER);

            String mode = StrUtils.defaultString(flash.get("mode"));

            // 施設コードリスト初期化
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_SHISETSU);

            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(営業所リスト)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO);

            mst142Form.setListJisCd(autoCompleteViewBean.initAddr("jisCd", ""));

            // 新規登録場合
            if (CONST_MODE_INSERT.equals(mode)) {
                // モード設定
                mst142Form.setMode(CONST_MODE_INSERT);
                // 施設コードリスト初期化
                autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_SHISETSU);

                // フロア情報を初期化する
                List<Map<String, Object>> floorList = new ArrayList<>();
                pageCommonBean.setDatalist(DATA_TABLE_ID_FLOOR, floorList);

                // ロケーション情報を初期化する
                List<Map<String, Object>> loactionList = new ArrayList<>();
                pageCommonBean.setDatalist(DATA_TABLE_ID_LOCATION, loactionList);

                // フロア情報データリストを設定する
                mst142Form.setSearchFloorResultSelectable(new ReportListDataModel(floorList));
                mst142Form.setSearchFloorResult(floorList);

                // ロケーション情報データリストを設定する
                mst142Form.setSearchLocationResultSelectable(new ReportListDataModel(loactionList));
                mst142Form.setSearchLocationResult(loactionList);

                // パタン設定
                patternC();
            }// 詳細照会場合 
            else if (CONST_MODE_DETAIL.equals(mode)) {
                // モード設定
                mst142Form.setMode(CONST_MODE_DETAIL);
                // 施設コード
                mst142Form.setConShisetsuCd(new AutoCompOptionBean(
                        StrUtils.defaultString(flash.get("shisetsuCd")),
                        StrUtils.defaultString(flash.get("shisetsuCd"))));
                // 適用開始日
                mst142Form.setConTekiyoKaishibi(StrUtils.defaultString(flash.get("tekiyoKaishibi")));
                // 適用フラグ
                mst142Form.setListTekiyoFlg(StrUtils.defaultString(flash.get("tekiyoFlg")));

                // パタン設定
                patternB();

                // 検索行う
                search();

            }// 複写申請場合
            else if (CONST_MODE_COPY.equals(mode)) {
                // モード設定
                mst142Form.setMode(CONST_MODE_INSERT);
                // 施設コード
                mst142Form.setConShisetsuCd(new AutoCompOptionBean(
                        StrUtils.defaultString(flash.get("shisetsuCd")),
                        StrUtils.defaultString(flash.get("shisetsuCd"))));
                // 適用開始日
                mst142Form.setConTekiyoKaishibi(StrUtils.defaultString(flash.get("tekiyoKaishibi")));
                // 適用フラグ
                mst142Form.setListTekiyoFlg(StrUtils.defaultString(flash.get("tekiyoFlg")));

                // パタン設定
                patternF();

                // 検索行う
                search();

            }

            // component初期化とユーザ権限により制御設定
            pageCommonBean.setAuthControll(mst142Form, SC_CD_MST142, false);

        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * 検索処理
     *
     */
    public void search() {

        // 施設マスタ情報取得
        List<Map<String, Object>> shisetsuList = getShisetsu();
        if (!shisetsuList.isEmpty()) {
            // 施設コード
            mst142Form.setConShisetsuCd(new AutoCompOptionBean(
                    StrUtils.defaultString(shisetsuList.get(0).get("conShisetsuCd")),
                    StrUtils.defaultString(shisetsuList.get(0).get("conShisetsuCd"))));
            // 申請ステータス
            mst142Form.setConShoninStatus(StrUtils.defaultString(shisetsuList.get(0).get("conShoninStatus")));
            // 適用開始日
            mst142Form.setConTekiyoKaishibi(
                    StrUtils.defaultString(shisetsuList.get(0).get("conTekiyoKaishibi")));
            // 適用名
            mst142Form.setConTekiyoMei(StrUtils.defaultString(shisetsuList.get(0).get("conTekiyoMei")));
            // 適用終了日
            mst142Form.setConTekiyoShuryobi(
                    StrUtils.defaultString(shisetsuList.get(0).get("conTekiyoShuryobi")));
            // 適用終了日がない場合、表示しない
            if (StrUtils.defaultString(shisetsuList.get(0).get("conTekiyoShuryobi")).isEmpty()) {
                mst142Form.setConTekiyoShuryobiHidden(true);
            }
            // 施設名
            mst142Form.setListShisetsuMei(StrUtils.defaultString(shisetsuList.get(0).get("listShisetsuMei")));
            // 管轄営業所コード
            mst142Form.setListKankatsuEigyosho(
                    new AutoCompOptionBean(StrUtils.defaultString(shisetsuList.get(0).get("listKankatsuEigyoshoMei")),
                            StrUtils.defaultString(shisetsuList.get(0).get("listKankatsuEigyoshoCd"))));
            // 有効坪数
            mst142Form.setListYukoTsubosu(NumberUtils.toBigDecimal(shisetsuList.get(0).get("listYukoTsubosu")));
            // 仕入値
            mst142Form.setListShiireNe(NumberUtils.toBigDecimal(shisetsuList.get(0).get("listShiireNe")));
            // 郵便番号
            mst142Form.setListYubinBango(StrUtils.defaultString(shisetsuList.get(0).get("listYubinBango")));
            // JISコード
            mst142Form.setListJisCd(
                    new AutoCompOptionBean(StrUtils.defaultString(shisetsuList.get(0).get("listJisCd")),
                            StrUtils.defaultString(shisetsuList.get(0).get("listJisCd"))));
            // 住所(1行目)
            mst142Form.setListJusho1(StrUtils.defaultString(shisetsuList.get(0).get("listJusho1")));
            // 住所(2行目)
            mst142Form.setListJusho2(StrUtils.defaultString(shisetsuList.get(0).get("listJusho2")));
            // 住所(3行目)
            mst142Form.setListJusho3(StrUtils.defaultString(shisetsuList.get(0).get("listJusho3")));
            // 住所(4行目)

            mst142Form.setListJusho4(StrUtils.defaultString(shisetsuList.get(0).get("listJusho4")));
            // 電話番号
            mst142Form.setListTelBango(StrUtils.defaultString(shisetsuList.get(0).get("listTelBango")));
            // 敷地面積
            mst142Form.setListShikichiMenseki(NumberUtils.toBigDecimal(shisetsuList.get(0).get("listShikichiMenseki")));
            // 延床面積
            mst142Form.setListNobeyukaMenseki(NumberUtils.toBigDecimal(shisetsuList.get(0).get("listNobeyukaMenseki")));
            // 更新者
            mst142Form.setListKoshinsha(StrUtils.defaultString(shisetsuList.get(0).get("listKoshinsha")));
            // 更新日時
            mst142Form.setListKoshinNichiji(StrUtils.defaultString(shisetsuList.get(0).get("listKoshinNichiji")));
            // 見積り最終使用日時
            mst142Form.setListMitsumoriSaishuShiyoHi(
                    StrUtils.defaultString(shisetsuList.get(0).get("listMitsumoriSaishuShiyoHi")));
            // ロジ入力計算最終使用日時
            mst142Form.setListLogiNyuryokuKeisanSaishuShiyoHi(
                    StrUtils.defaultString(shisetsuList.get(0).get("listLogiNyuryokuKeisanSaishuShiyoHi")));
            // 更新ユーザーID
            mst142Form.setKoushinUserCd(StrUtils.defaultString(shisetsuList.get(0).get("koushinUserCd")));
            // 更新カウンタ
            mst142Form.setKoushinCounter(StrUtils.defaultString(shisetsuList.get(0).get("koushinCounter")));
            // バージョン
            mst142Form.setShisetsuDataVersion(StrUtils.defaultString(shisetsuList.get(0).get("shisetsuDataVersion")));
        }

        // フロア情報取得
        List<Map<String, Object>> floorList = getFloor();
        pageCommonBean.setDatalist(DATA_TABLE_ID_FLOOR, floorList);

        // ロケーション情報取得
        List<Map<String, Object>> loactionList = getLocation();
        pageCommonBean.setDatalist(DATA_TABLE_ID_LOCATION, loactionList);

        // フロア情報データリストを設定する
        mst142Form.setSearchFloorResultSelectable(new ReportListDataModel(floorList));

        // ロケーション情報データリストを設定する
        mst142Form.setSearchLocationResultSelectable(new ReportListDataModel(loactionList));

        // フロア計算
        floorCalculate();

        // ロケーション計算
        locationCalculate();

        // フロアリスト更新行う
        updateFloorList();
    }

    /**
     * 施設マスタ情報を取得する
     *
     * @return 施設マスタ情報
     */
    private List<Map<String, Object>> getShisetsu() {

        // パラメータ取得
        Map<String, Object> params = getParams();

        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH);

        try {
            ObjectMapper mapper = new ObjectMapper();
            mst142Form.setSearchResult(mapper.readValue(res.getJson(), List.class));
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }

        // 施設マスタ情報を返却する
        return mst142Form.getSearchResult();
    }

    /**
     * フロア情報を取得する
     *
     * @return フロア情報
     */
    private List<Map<String, Object>> getFloor() {

        // パラメータ取得
        Map<String, Object> params = getParams();

        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH_FLOOR);

        try {
            ObjectMapper mapper = new ObjectMapper();
            mst142Form.setSearchFloorResult(mapper.readValue(res.getJson(), List.class));
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }

        // フロア情報を返却する
        return mst142Form.getSearchFloorResult();
    }

    /**
     * ロケーション情報を取得する
     *
     * @return ロケーション情報
     */
    private List<Map<String, Object>> getLocation() {

        // パラメータ取得
        Map<String, Object> params = getParams();

        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH_LOCATION);

        try {
            ObjectMapper mapper = new ObjectMapper();
            mst142Form.setSearchLocationResult(mapper.readValue(res.getJson(), List.class));
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }

        // ロケーション情報を返却する
        return mst142Form.getSearchLocationResult();
    }

    /**
     * パラメータ設定処理
     *
     * @return パラメータ
     */
    public Map<String, Object> getParams() {

        // パラメータ
        Map<String, Object> params = new HashMap<>();

        // 施設コード
        if (mst142Form.getConShisetsuCd() != null) {
            params.put("conShisetsuCd", mst142Form.getConShisetsuCd().getValue());
        }
        // 適用開始日
        params.put("conTekiyoKaishibi", mst142Form.getConTekiyoKaishibi());

        return params;
    }

    /**
     * テーブル行削除処理
     *
     * @param tableId テーブルID
     */
    public void delRows(String tableId) {

        if (DATA_TABLE_ID_FLOOR.equals(tableId)) {
            // 選択行
            List<Map<String, Object>> selectedFloorSearchResult = mst142Form.getSelectedFloorSearchResult();
            // 行選択チェック
            if (selectedFloorSearchResult == null || selectedFloorSearchResult.isEmpty()) {
                MessageModuleBean message = messagePropertyBean.createMessageModule(
                        MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
                msgList.clear();
                msgList.add(message);
                return;
            }
            mst142Form.getSearchFloorResult().removeAll(selectedFloorSearchResult);
            // フロアリスト更新行う
            updateFloorList();
            // フロア情報計算行う
            floorCalculate();
        } else if (DATA_TABLE_ID_LOCATION.equals(tableId)) {
            // 選択行
            List<Map<String, Object>> selectedLocationSearchResult = mst142Form.getSelectedLocationSearchResult();
            // 行選択チェック
            if (selectedLocationSearchResult == null || selectedLocationSearchResult.isEmpty()) {
                MessageModuleBean message = messagePropertyBean.createMessageModule(
                        MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
                msgList.clear();
                msgList.add(message);
                return;
            }
            mst142Form.getSearchLocationResult().removeAll(selectedLocationSearchResult);
            // 坪数合計計算行う
            locationCalculate();
        }
    }

    /**
     * フロアセル編集
     *
     * @param event セル編集事件対象
     */
    public void floorCellEdit(CellEditEvent event) {

        // フロア入力チェック
        if (!checkFloors()) {
            return;
        }

        // フロアリスト更新行う
        updateFloorList();

        // フロア情報計算行う
        floorCalculate();

        PrimeFaces.current().executeScript("PF('btnRefreshDetailAll').jq.click()");
    }

    /**
     * フロアリスト更新
     *
     */
    public void updateFloorList() {

        // 施設概要情報データリスト
        ReportListDataModel dataModel = mst142Form.getSearchFloorResultSelectable();
        List<Map<String, Object>> datasource = dataModel.getDatasource();

        // 重複データ処理用マップ
        Map<String, String> uniqueFloorMap = new HashMap<>();

        // ソート用リスト
        List<String> listForSort = new ArrayList<>();

        // 重複削除処理
        Integer n = 1;
        for (Map<String, Object> row : datasource) {
            if (!"".equals(row.get("sisetuGaiyohyoListFloorShisetsu"))) {
                uniqueFloorMap.put(StrUtils.defaultString(row.get("sisetuGaiyohyoListFloorShisetsu")), n.toString());
                n++;
            }
        }
        Iterator<String> iterator = uniqueFloorMap.keySet().iterator();
        while (iterator.hasNext()) {
            listForSort.add(iterator.next());
        }

        // リストのソート処理
        listForSort.sort((String str1, String str2) -> str1.compareTo(str2));

        // フロアリスト更新
        List<SelectItem> item = new ArrayList<>();
        for (String floor : listForSort) {
            item.add(new SelectItem(floor));
        }

        // 新しいフロアリストを設定する
        mst142Form.setFloors(item);

        // フロアマップ更新
        mst142Form.setFloorMap(uniqueFloorMap);

        // 倉庫賃料情報データリスト
        ReportListDataModel dataModelLocation = mst142Form.getSearchLocationResultSelectable();
        List<Map<String, Object>> datasourceLocation = dataModelLocation.getDatasource();
        // 新フロアリストよりロケーションのフロアをクリアする
        for (Map<String, Object> row : datasourceLocation) {
            if (!uniqueFloorMap.containsKey(StrUtils.defaultString(row.get("sokoryoOroshiSetteihyoListFloorSouko")))) {
                row.put("sokoryoOroshiSetteihyoListFloorSouko", null);
            }
        }
    }

    /**
     * フロア情報計算
     *
     */
    public void floorCalculate() {

        // 事務所賃料
        BigDecimal jimushoChinryo;
        // 倉庫賃料
        BigDecimal sokoChinryo;
        // 合計坪数
        BigDecimal gokeiTsubosu;
        // 合計賃料
        BigDecimal gokeiChinryo;
        // 事務所坪数合計
        BigDecimal jimushoTsubosuGokei = BigDecimal.ZERO;
        // 事務所賃料合計
        BigDecimal jimushoChinryoGokei = BigDecimal.ZERO;
        // 倉庫坪数合計
        BigDecimal sokoTsubosuGokei = BigDecimal.ZERO;
        // 倉庫賃料合計
        BigDecimal sokoChinryoGokei = BigDecimal.ZERO;
        // 合計坪数合計
        BigDecimal gokeiTsubosuGokei = BigDecimal.ZERO;
        // 合計賃料合計
        BigDecimal gokeiChinryoGokei = BigDecimal.ZERO;

        // 施設概要情報データリスト
        ReportListDataModel dataModel = mst142Form.getSearchFloorResultSelectable();
        List<Map<String, Object>> datasource = dataModel.getDatasource();

        // 行別計算行う
        for (Map<String, Object> row : datasource) {
            // 事務所賃料を計算する： 事務所坪数 * 事務所坪単価
            jimushoChinryo = multiply(
                    row.get("sisetuGaiyohyoListJimushoTsubosu"), row.get("sisetuGaiyohyoListJimushoTsuboTanka"));
            row.put("sisetuGaiyohyoListJimushoChinryo", jimushoChinryo);

            // 倉庫賃料を計算する： 倉庫坪数 * 倉庫坪単価
            sokoChinryo = multiply(row.get("sisetuGaiyohyoListSokoTsubosu"),
                    row.get("sisetuGaiyohyoListSokoTsuboTanka"));
            row.put("sisetuGaiyohyoListSokoChinryo", sokoChinryo);

            // 合計坪数を計算する： 事務所坪数 + 倉庫坪数
            gokeiTsubosu = add(row.get("sisetuGaiyohyoListJimushoTsubosu"), row.get("sisetuGaiyohyoListSokoTsubosu"));
            row.put("sisetuGaiyohyoListGokeiTsubosu", gokeiTsubosu);

            // 合計賃料を計算する： 事務所賃料 + 倉庫賃料
            gokeiChinryo = add(row.get("sisetuGaiyohyoListJimushoChinryo"), row.get("sisetuGaiyohyoListSokoChinryo"));
            row.put("sisetuGaiyohyoListGokeiChinryo", gokeiChinryo);
        }

        // 列別計算行う
        for (Map<String, Object> row : datasource) {
            // 事務所坪数合計を計算する：SUM(事務所坪数)
            jimushoTsubosuGokei = add(jimushoTsubosuGokei, row.get("sisetuGaiyohyoListJimushoTsubosu"));

            // 事務所賃料合計を計算する：SUM(事務所賃料)
            jimushoChinryoGokei = add(jimushoChinryoGokei, row.get("sisetuGaiyohyoListJimushoChinryo"));

            // 倉庫坪数合計を計算する：SUM(倉庫坪数)
            sokoTsubosuGokei = add(sokoTsubosuGokei, row.get("sisetuGaiyohyoListSokoTsubosu"));

            // 倉庫賃料合計を計算する：SUM(倉庫賃料)
            sokoChinryoGokei = add(sokoChinryoGokei, row.get("sisetuGaiyohyoListSokoChinryo"));

            // 合計坪数合計を計算する：SUM(合計坪数)
            gokeiTsubosuGokei = add(gokeiTsubosuGokei, row.get("sisetuGaiyohyoListGokeiTsubosu"));

            // 合計賃料合計を計算する：SUM(合計賃料)
            gokeiChinryoGokei = add(gokeiChinryoGokei, row.get("sisetuGaiyohyoListGokeiChinryo"));
        }

        // 施設概要表.事務所坪数合計
        mst142Form.setSisetuGaiyohyoListJimushoTsubosuGokei(jimushoTsubosuGokei);
        // 施設概要表.事務所賃料合計
        mst142Form.setSisetuGaiyohyoListJimushoChinryoGokei(jimushoChinryoGokei);
        // 施設概要表.倉庫坪数合計
        mst142Form.setSisetuGaiyohyoListSokoTsubosuGokei(sokoTsubosuGokei);
        // 施設概要表.倉庫賃料合計
        mst142Form.setSisetuGaiyohyoListSokoChinryoGokei(sokoChinryoGokei);
        // 施設概要表.合計坪数合計
        mst142Form.setSisetuGaiyohyoListGokeiTsubosuGokei(gokeiTsubosuGokei);
        // 施設概要表.合計賃料合計
        mst142Form.setSisetuGaiyohyoListGokeiChinryoGokei(gokeiChinryoGokei);
    }

    /**
     * ロケーションセル編集
     *
     * @param event セル編集事件対象
     */
    public void locationCellEdit(CellEditEvent event) {

        // ロケーション入力チェック
        if (!checkLocations()) {
            return;
        }

        // 坪数合計計算行う
        locationCalculate();

        PrimeFaces.current().executeScript("PF('btnRefreshDetail2').jq.click()");
    }

    /**
     * ロケーション情報計算
     *
     */
    public void locationCalculate() {

        // 倉庫料卸設定一覧表.坪数合計
        BigDecimal tsubosuGokei = BigDecimal.ZERO;

        // 倉庫料卸情報データリスト
        ReportListDataModel dataModel = mst142Form.getSearchLocationResultSelectable();
        List<Map<String, Object>> datasource = dataModel.getDatasource();

        // 列別計算行う
        for (Map<String, Object> row : datasource) {
            // 坪数合計を計算する：SUM(坪数)
            tsubosuGokei = add(tsubosuGokei, row.get("sokoryoOroshiSetteihyoListSokoryoTsubosu"));
        }

        // 倉庫料卸設定一覧表.坪数合計
        mst142Form.setSokoryoOroshiSetteihyoListTsubosuGokei(tsubosuGokei);
    }

    /**
     * 乗法計算の処理
     *
     * @param value1 乗数１
     * @param value2 乗数２
     * @return 処理結果
     */
    public BigDecimal multiply(Object value1, Object value2) {

        // 両方ヌル場合
        if (value1 == null && value2 == null) {
            return null;
        }

        // 1つヌル場合
        if (value1 == null || value2 == null) {
            return BigDecimal.ZERO;
        }

        BigDecimal x = NumberUtils.toBigDecimal(value1);
        BigDecimal y = NumberUtils.toBigDecimal(value2);

        // 乗法行う
        return x.multiply(y);
    }

    /**
     * 加法計算の処理
     *
     * @param value1 加数１
     * @param value2 加数２
     * @return 処理結果
     */
    public BigDecimal add(Object value1, Object value2) {

        // 両方ヌル場合
        if (value1 == null && value2 == null) {
            return null;
        }

        BigDecimal x = NumberUtils.toBigDecimal(value1);
        BigDecimal y = NumberUtils.toBigDecimal(value2);

        // 加法行う
        return x.add(y);
    }

    /**
     * 比較の処理
     *
     * @param value1 比較対象１
     * @param value2 比較対象２
     * @return 処理結果
     */
    public int compare(Object value1, Object value2) {

        // 両方ヌル場合
        if (value1 == null && value2 == null) {
            return 0;
        }

        BigDecimal x = NumberUtils.toBigDecimal(value1);
        BigDecimal y = NumberUtils.toBigDecimal(value2);

        return x.compareTo(y);
    }

    /**
     * メニュークリック（処理）
     *
     * @param menuId クリックされたメニューID（メニューからの遷移以外はNULL）
     * @param nextScreen 遷移先の画面
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {

        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック（処理）
     *
     * @param nextScreen 遷移先の画面
     * @param breadIndex 選択されたパンくずのIndex
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        url = forward(nextScreen, null, null, true);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {

        return authConfBean.logout();
    }

    /**
     * 申請預処理
     *
     * @return 処理フラグ
     */
    public boolean preapply() {
        // 削除場合
        if (CONST_MODE_DEL.equals(mst142Form.getMode())) {
            // 検索条件入力チェック
            if (!checkCondition()) {
                return false;
            }
        }// 更新・新規場合
        else if (CONST_MODE_UPDATE.equals(mst142Form.getMode()) || CONST_MODE_INSERT.equals(mst142Form.getMode())) {
            // フロア情報一覧入力チェック
            if (!checkFloors()) {
                return false;
            }

            // ロケーション情報一覧入力チェック
            if (!checkLocations()) {
                return false;
            }

            // 業務チェック
            if (!checkBus()) {
                return false;
            }

            // 警告チェック(フロア坪数チェック)
            if (!checkWarning()) {
                // 確認表示
                pageCommonBean.executeScript("km.showConfirmDialog('checkLocationConfirmDialog')");
                return false;
            }
        }

        // 申請処理行う
        return doApply();
    }

    /**
     * モード転換
     *
     * @param actionFlg モードフラグ
     */
    public void modeSwitch(String actionFlg) {

        if (null != actionFlg) {
            switch (actionFlg) {
                // 編集
                case CONST_MODE_UPDATE:
                    // 更新モード設定
                    mst142Form.setMode(CONST_MODE_UPDATE);
                    // 制御パタンD設定
                    patternD();
                    break;
                // 新規申請
                case CONST_MODE_INSERT:

                    // フォームクリア
                    clearForm(mst142Form);
                    // 新規モード設定
                    mst142Form.setMode(CONST_MODE_INSERT);
                    // JISコード設定
                    mst142Form.setListJisCd(autoCompleteViewBean.initAddr("jisCd", ""));

                    // フロア情報を初期化する
                    List<Map<String, Object>> floorList = new ArrayList<>();
                    pageCommonBean.setDatalist(DATA_TABLE_ID_FLOOR, floorList);

                    // ロケーション情報を初期化する
                    List<Map<String, Object>> loactionList = new ArrayList<>();
                    pageCommonBean.setDatalist(DATA_TABLE_ID_LOCATION, loactionList);

                    // フロア情報データリストを設定する
                    mst142Form.setSearchFloorResultSelectable(new ReportListDataModel(floorList));
                    mst142Form.setSearchFloorResult(floorList);

                    // ロケーション情報データリストを設定する
                    mst142Form.setSearchLocationResultSelectable(new ReportListDataModel(loactionList));
                    mst142Form.setSearchLocationResult(loactionList);

                    // component初期化とユーザ権限により制御設定
                    pageCommonBean.setAuthControll(mst142Form, SC_CD_MST142, false);
                    // 制御パタンC設定
                    patternC();
                    break;
                // 複写申請
                case CONST_MODE_COPY:
                    // 新規モード設定
                    mst142Form.setMode(CONST_MODE_INSERT);
                    // 画面データ取得
                    search();
                    // 制御パタンF設定
                    patternF();
                    break;
                // 削除申請
                case CONST_MODE_DEL:
                    // 削除モード設定
                    mst142Form.setMode(CONST_MODE_DEL);
                    // 制御パタンG設定
                    patternG();
                    break;
                // 論理削除
                case CONST_MODE_FAKEDEL:
                    // 論理削除モード設定
                    mst142Form.setMode(CONST_MODE_FAKEDEL);
                    // 制御パタンH設定
                    patternH();
                    break;
                default:
                    break;
            }
        }
    }

    /**
     * 申請ボタンクリック
     *
     * @param hasCheck チェック有無フラグ
     */
    public void apply(boolean hasCheck) {

        boolean isOk;
        if (hasCheck) {
            isOk = preapply();
        } else {
            isOk = doApply();
        }

        if (isOk) {
            pageCommonBean.executeScript("PF('btnRedirect').jq.click()");
        }
    }

    /**
     * 画面遷移
     *
     * @return 遷移先の画面URL
     */
    public String redirect() {
        // 共通申請画面遷移用パラメータ設定
        Flash flash = pageCommonBean.getPageParam();
        // ワーク.キー情報
        flash.put("key", StrUtils.defaultString(mst142Form.getConShisetsuCd().getValue())
                + "," + StrUtils.defaultString(mst142Form.getConTekiyoKaishibi())
                + "," + StrUtils.defaultString(mst142Form.getListTekiyoFlg()));
        // ワーク.申請種別コード
        flash.put("typeCd", "15");
        // ワーク.表示項目1
        flash.put("item1", "新規");
        // ワーク.表示項目2
        flash.put("item2", StrUtils.defaultString(mst142Form.getListKankatsuEigyosho().getValue())
                + "\r\n" + StrUtils.defaultString(mst142Form.getListKankatsuEigyosho().getLabel()));
        // ワーク.表示項目3
        flash.put("item3", "あり");
        // ワーク.表示項目4
        flash.put("item4", "あり");
        // ワーク.表示項目5
        flash.put("item5", "あり");
        // ワーク.表示項目6
        flash.put("item6", mst142Form.getConTekiyoKaishibi());

        // TODO 申請共通画面へ
        url = forward(SCREEN.DEM012_SCREEN.name(), null, SCREEN.DEM012_SCREEN.name(), false);
        return url;
    }

    /**
     * 申請処理
     *
     * @return 処理フラグ
     */
    public boolean doApply() {

        // 申請処理
        // パラメータ
        Map<String, Object> params = new HashMap<>();
        // 施設コード
        params.put("conShisetsuCd", mst142Form.getConShisetsuCd().getValue());
        // 適用開始日
        params.put("conTekiyoKaishibi", mst142Form.getConTekiyoKaishibi());
        // 営業所コード
        if (mst142Form.getListKankatsuEigyosho() != null) {
            params.put("kankatsuEigyoshoCd", mst142Form.getListKankatsuEigyosho().getValue());
        }
        // 更新ユーザーID
        params.put("koushinUserCd", mst142Form.getKoushinUserCd());
        // 更新カウンタ
        params.put("koushinCounter", mst142Form.getKoushinCounter());
        // バージョン
        params.put("shisetsuDataVersion", mst142Form.getShisetsuDataVersion());
        // 施設名
        params.put("listShisetsuMei", mst142Form.getListShisetsuMei());
        // 有効坪数
        params.put("listYukoTsubosu", mst142Form.getListYukoTsubosu());
        // 仕入値
        params.put("listShiireNe", mst142Form.getListShiireNe());
        // 郵便番号
        params.put("listYubinBango", mst142Form.getListYubinBango());
        // JISコード
        if (mst142Form.getListJisCd() != null) {
            params.put("listJisCd", mst142Form.getListJisCd().getValue());
        }
        // 住所１
        params.put("listJusho1", mst142Form.getListJusho1());
        // 住所２
        params.put("listJusho2", mst142Form.getListJusho2());
        // 住所３
        params.put("listJusho3", mst142Form.getListJusho3());
        // 住所４
        params.put("listJusho4", mst142Form.getListJusho4());
        // 電話番号
        params.put("listTelBango", mst142Form.getListTelBango());
        // 敷地面積
        params.put("listShikichiMenseki", mst142Form.getListShikichiMenseki());
        // 延床面積
        params.put("listNobeyukaMenseki", mst142Form.getListNobeyukaMenseki());
        // 適用名
        params.put("conTekiyoMei", mst142Form.getConTekiyoMei());
        // 適用終了日
        params.put("conTekiyoShuryo", mst142Form.getConTekiyoShuryobi());
        // モード
        params.put("mode", mst142Form.getMode());
        // フロア情報リスト
        params.put("floors", mst142Form.getSearchFloorResultSelectable().getDatasource());
        // ロケーション情報リスト
        params.put("locations", mst142Form.getSearchLocationResultSelectable().getDatasource());
        // フロアマップ
        params.put("floorMap", mst142Form.getFloorMap());

        // 処理行う
        ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_APPLY);
        // エラーの場合、処理を終了
        if (res == null) {
            return false;
        }
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            String mstLevel = res.getMessages().get(0)[0];
            String msgCode = res.getMessages().get(0)[1];
            Object[] msgParams = res.getMessages().get(0)[2].split(",");
            MessageModuleBean message = messagePropertyBean.createMessageModule(
                    mstLevel, msgCode, msgParams);
            msgList.clear();
            msgList.add(message);
            messagePropertyBean.messageList(msgList);
            return false;
        }
        return true;
    }

    /**
     * 検索条件入力チェック
     *
     * @return チェックフラグ
     */
    public boolean checkCondition() {
        MessageModuleBean message;
        msgList.clear();
        if (mst142Form.getConShisetsuCd() == null || StrUtils.defaultString(mst142Form.getConShisetsuCd().getValue()).isEmpty()) {
            message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MSTE0003, "施設コード");
            msgList.add(message);
            messagePropertyBean.messageList(msgList);
            return false;
        }

        if (StrUtils.defaultString(mst142Form.getConTekiyoKaishibi()).isEmpty()) {
            message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MSTE0003, "適用開始日");
            msgList.add(message);
            messagePropertyBean.messageList(msgList);
            return false;
        }
        return true;
    }

    /**
     * フロア情報一覧入力チェック
     *
     * @return チェックフラグ
     */
    public boolean checkFloors() {
        // 行選択チェック
        List<Map<String, Object>> floorDatas = mst142Form.getSearchFloorResult();
        if (floorDatas == null || floorDatas.isEmpty()) {
            return true;
        }

        // 入力チェック
        List<ListCheckBean> checks = new ArrayList<>();

        List<MessageModuleBean> checkMsgList = new ArrayList<>();

        // 必須項目チェック
        checks.add(new ListCheckBean("sisetuGaiyohyoListFloorShisetsu",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "施設フロア"));
        checks.add(new ListCheckBean("sisetuGaiyohyoListSokoTsubosu",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "施設倉庫坪数"));
        checks.add(new ListCheckBean("sisetuGaiyohyoListSokoTsuboTanka",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "施設倉庫坪単価"));
        checkMsgList.clear();
        checkMsgList = listCheckBean.check(floorDatas, checks, true);
        if (checkMsgList.size() > 0) {
            return false;
        } else {
            checks.clear();
        }

        // 数値チェック
        checks.add(new ListCheckBean("sisetuGaiyohyoListJimushoTsubosu",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NUMBER, "施設事務所坪数"));
        checks.add(new ListCheckBean("sisetuGaiyohyoListJimushoTsuboTanka",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NUMBER, "施設事務所坪単価"));
        checks.add(new ListCheckBean("sisetuGaiyohyoListSokoTsubosu",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NUMBER, "施設倉庫坪数"));
        checks.add(new ListCheckBean("sisetuGaiyohyoListSokoTsuboTanka",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NUMBER, "施設倉庫坪単価"));
        checkMsgList.clear();
        checkMsgList = listCheckBean.check(floorDatas, checks, true);
        if (checkMsgList.size() > 0) {
            return false;
        } else {
            checks.clear();
        }

        // 最大桁数チェック
        checks.add(new ListCheckBean("sisetuGaiyohyoListFloorShisetsu",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "施設フロア", "20"));
        checks.add(new ListCheckBean("sisetuGaiyohyoListJimushoTsubosu",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "施設事務所坪数", "9"));
        checks.add(new ListCheckBean("sisetuGaiyohyoListJimushoTsuboTanka",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "施設事務所坪単価", "10"));
        checks.add(new ListCheckBean("sisetuGaiyohyoListSokoTsubosu",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "施設倉庫坪数", "9"));
        checks.add(new ListCheckBean("sisetuGaiyohyoListSokoTsuboTanka",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "施設倉庫坪単価", "10"));
        checkMsgList.clear();
        checkMsgList = listCheckBean.check(floorDatas, checks, true);
        if (checkMsgList.size() > 0) {
            return false;
        } else {
            checks.clear();
        }

        // 最小数値チェック
        checks.add(new ListCheckBean("sisetuGaiyohyoListJimushoTsubosu",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MIN_NUMBER, "施設事務所坪数", "1"));
        checks.add(new ListCheckBean("sisetuGaiyohyoListJimushoTsuboTanka",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MIN_NUMBER, "施設事務所坪単価", "1"));
        checks.add(new ListCheckBean("sisetuGaiyohyoListSokoTsubosu",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MIN_NUMBER, "施設倉庫坪数", "1"));
        checks.add(new ListCheckBean("sisetuGaiyohyoListSokoTsuboTanka",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MIN_NUMBER, "施設倉庫坪単価", "1"));
        checkMsgList.clear();
        checkMsgList = listCheckBean.check(floorDatas, checks, true);
        if (checkMsgList.size() > 0) {
            return false;
        } else {
            checks.clear();
        }

        return true;
    }

    /**
     * ロケーション情報一覧入力チェック
     *
     * @return チェックフラグ
     */
    public boolean checkLocations() {
        // 行選択チェック
        List<Map<String, Object>> LocationDatas = mst142Form.getSearchLocationResult();
        if (LocationDatas == null || LocationDatas.isEmpty()) {

            return true;
        }

        // 入力チェック
        List<ListCheckBean> checks = new ArrayList<>();
        List<MessageModuleBean> checkMsgList = new ArrayList<>();

        // 必須項目チェック
        checks.add(new ListCheckBean("sokoryoOroshiSetteihyoListFloorSouko",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "倉庫フロア"));
        checks.add(new ListCheckBean("sokoryoOroshiSetteihyoListHokanShubetsu",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "倉庫保管種別"));
        checks.add(new ListCheckBean("sokoryoOroshiSetteihyoListSokoryoTsubosu",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "倉庫坪数"));
        checkMsgList.clear();
        checkMsgList = listCheckBean.check(LocationDatas, checks, true);
        if (checkMsgList.size() > 0) {
            return false;
        } else {
            checks.clear();
        }

        // 数値チェック
        checks.add(new ListCheckBean("sokoryoOroshiSetteihyoListSokoryoTsubosu",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NUMBER, "倉庫坪数"));
        checks.add(new ListCheckBean("sokoryoOroshiSetteihyoListSokoryoOroshineTsubo",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NUMBER, "倉庫卸値(/坪)"));
        checkMsgList.clear();
        checkMsgList = listCheckBean.check(LocationDatas, checks, true);
        if (checkMsgList.size() > 0) {
            return false;
        } else {
            checks.clear();
        }

        // 最大桁数チェック
        checks.add(new ListCheckBean("sokoryoOroshiSetteihyoListHokanShubetsu",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "倉庫保管種別", "40"));
        checks.add(new ListCheckBean("sokoryoOroshiSetteihyoListSokoryoTsubosu",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "倉庫坪数", "9"));
        checks.add(new ListCheckBean("sokoryoOroshiSetteihyoListSokoryoOroshineTsubo",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "倉庫卸値(/坪)", "10"));
        checkMsgList.clear();
        checkMsgList = listCheckBean.check(LocationDatas, checks, true);
        if (checkMsgList.size() > 0) {
            return false;
        } else {
            checks.clear();
        }

        // 最小数値チェック
        checks.add(new ListCheckBean("sokoryoOroshiSetteihyoListSokoryoOroshineTsubo",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MIN_NUMBER, "倉庫卸値(/坪)", "1"));
        checkMsgList = listCheckBean.check(LocationDatas, checks, true);
        if (checkMsgList.size() > 0) {
            return false;
        } else {
            checks.clear();
        }

        return true;

    }

    /**
     * 業務チェック
     *
     * @return チェックフラグ
     */
    public boolean checkBus() {

        MessageModuleBean message;
        msgList.clear();
        // 仕入値チェック
        if (!mst142Form.getListShiireNe().equals(mst142Form.getSisetuGaiyohyoListGokeiChinryoGokei())) {
            message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MSTE0003);
            msgList.add(message);
            messagePropertyBean.messageList(msgList);
            return false;
        }

        // 有効坪数チェック
        if (!mst142Form.getListYukoTsubosu().equals(mst142Form.getSisetuGaiyohyoListGokeiTsubosuGokei())) {
            message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MSTE0004);
            msgList.add(message);
            messagePropertyBean.messageList(msgList);
            return false;
        }

        // フロア重複チェック
        // 重複データ処理用マップ
        Map<String, String> uniqueMap = new HashMap<>();

        // フロア重複チェック
        // 施設概要情報データリスト
        List<Map<String, Object>> floors = mst142Form.getSearchFloorResult();
        boolean hasRepeat = false;
        for (Map<String, Object> row : floors) {
            String sisetuGaiyohyoListFloorShisetsu = StrUtils.defaultString(row.get("sisetuGaiyohyoListFloorShisetsu"));
            if (!sisetuGaiyohyoListFloorShisetsu.isEmpty()) {
                if (uniqueMap.containsKey(sisetuGaiyohyoListFloorShisetsu)) {
                    hasRepeat = true;
                } else {
                    uniqueMap.put(sisetuGaiyohyoListFloorShisetsu, "1");
                }
            }
        }
        if (hasRepeat) {
            message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MSTE0005);
            msgList.add(message);
            messagePropertyBean.messageList(msgList);
            return false;
        }

        // フロア妥当性チェック
        List<Map<String, Object>> locations = mst142Form.getSearchLocationResult();
        for (Map<String, Object> row : locations) {
            String sokoryoOroshiSetteihyoListFloorSouko = StrUtils.defaultString(row.get("sokoryoOroshiSetteihyoListFloorSouko"));
            if (!sokoryoOroshiSetteihyoListFloorSouko.isEmpty()) {
                if (!uniqueMap.containsKey(sokoryoOroshiSetteihyoListFloorSouko)) {
                    message = messagePropertyBean.createMessageModule(
                            MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MSTE0006);
                    msgList.add(message);
                    messagePropertyBean.messageList(msgList);
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * 警告チェック(フロア坪数チェック)
     *
     * @return チェックフラグ
     */
    public boolean checkWarning() {

        // フロア坪数チェック
        // ロケーションのフロア別坪数合計マップ
        Map<String, Object> locationTsuboMap = new HashMap<>();
        List<Map<String, Object>> LocationDatas = mst142Form.getSearchLocationResult();
        for (Map<String, Object> map : LocationDatas) {
            String floor = (String) map.get("sokoryoOroshiSetteihyoListFloorSouko");
            locationTsuboMap.put(floor,
                    add(map.get("sokoryoOroshiSetteihyoListSokoryoTsubosu"), locationTsuboMap.get(floor)));
        }

        // 施設概要のデータリスト
        List<Map<String, Object>> floorDatas = mst142Form.getSearchFloorResult();
        for (Map<String, Object> map : floorDatas) {
            String floor = (String) map.get("sisetuGaiyohyoListFloorShisetsu");
            // 施設の坪数
            Object tsubo1 = map.get("sisetuGaiyohyoListGokeiTsubosu");
            // 倉庫の坪数
            Object tsubo2 = locationTsuboMap.get(floor);
            // フロア坪数チェック行う
            if (compare(tsubo1, tsubo2) < 0) {
                return false;
            }
        }
        return true;
    }

    /**
     * パタンB
     *
     */
    private void patternB() {
        // 施設コード
        mst142Form.setConShisetsuCdDisabled(false);
        // 適用開始日
        mst142Form.setConTekiyoKaishibiDisabled(false);
        // 適用名
        mst142Form.setConTekiyoMeiDisabled(true);
        // 適用終了
        mst142Form.setConTekiyoShuryobiDisabled(true);
        mst142Form.setConTekiyoShuryobiHidden(true);
        // 施設名
        mst142Form.setListShisetsuMeiDisabled(true);
        // 管轄営業所
        mst142Form.setListKankatsuEigyoshoDisabled(true);
        // 有効坪数
        mst142Form.setListYukoTsubosuDisabled(true);
        // 仕入値
        mst142Form.setListShiireNeDisabled(true);
        // JIS
        mst142Form.setJisDisabled(true);
        // 電話番号
        mst142Form.setListTelBangoDisabled(true);
        // 敷地面積
        mst142Form.setListShikichiMensekiDisabled(true);
        // 延床面積
        mst142Form.setListNobeyukaMensekiDisabled(true);
        // 明細リスト
        mst142Form.setDetailDisabled(true);
        // 前画面へボタン
        mst142Form.setBtnMaeGamenDisabled(false);
        // 編集ボタン
        mst142Form.setBtnHenshuDisabled(false);
        // 新規申請ボタン
        mst142Form.setBtnTorokuShinseiDisabled(false);
        // 複写申請ボタン
        mst142Form.setBtnFukushaShinseiDisabled(false);
        // 削除ボタン
        mst142Form.setBtnSakujoShinseiDisabled(false);
        // 論理削除ボタン
        mst142Form.setBtnRonriSakujoShinseiDisabled(false);
        // 申請ボタン
        mst142Form.setBtnShinseiDisabled(true);
    }

    /**
     * パタンC
     *
     */
    private void patternC() {
        // 施設コード
        mst142Form.setConShisetsuCdDisabled(false);
        // 適用開始日
        mst142Form.setConTekiyoKaishibiDisabled(false);
        // 適用名
        mst142Form.setConTekiyoMeiDisabled(false);
        // 適用終了
        mst142Form.setConTekiyoShuryobiDisabled(true);
        mst142Form.setConTekiyoShuryobiHidden(true);
        // 施設名
        mst142Form.setListShisetsuMeiDisabled(false);
        // 管轄営業所
        mst142Form.setListKankatsuEigyoshoDisabled(false);
        // 有効坪数
        mst142Form.setListYukoTsubosuDisabled(false);
        // 仕入値
        mst142Form.setListShiireNeDisabled(false);
        // JIS
        mst142Form.setJisDisabled(false);
        // 電話番号
        mst142Form.setListTelBangoDisabled(false);
        // 敷地面積
        mst142Form.setListShikichiMensekiDisabled(false);
        // 延床面積
        mst142Form.setListNobeyukaMensekiDisabled(false);
        // 明細リスト
        mst142Form.setDetailDisabled(false);
        // 前画面へボタン
        mst142Form.setBtnMaeGamenDisabled(false);
        // 編集ボタン
        mst142Form.setBtnHenshuDisabled(true);
        // 新規申請ボタン
        mst142Form.setBtnTorokuShinseiDisabled(true);
        // 複写申請ボタン
        mst142Form.setBtnFukushaShinseiDisabled(true);
        // 削除ボタン
        mst142Form.setBtnSakujoShinseiDisabled(true);
        // 論理削除ボタン
        mst142Form.setBtnRonriSakujoShinseiDisabled(true);
        // 申請ボタン
        mst142Form.setBtnShinseiDisabled(false);
    }

    /**
     * パタンD
     *
     */
    private void patternD() {
        // 施設コード
        mst142Form.setConShisetsuCdDisabled(true);
        // 適用開始日
        mst142Form.setConTekiyoKaishibiDisabled(false);
        // 適用名
        mst142Form.setConTekiyoMeiDisabled(false);
        // 適用終了
        mst142Form.setConTekiyoShuryobiDisabled(true);
        mst142Form.setConTekiyoShuryobiHidden(true);
        // 施設名
        mst142Form.setListShisetsuMeiDisabled(false);
        // 管轄営業所
        mst142Form.setListKankatsuEigyoshoDisabled(false);
        // 有効坪数
        mst142Form.setListYukoTsubosuDisabled(false);
        // 仕入値
        mst142Form.setListShiireNeDisabled(false);
        // JIS
        mst142Form.setJisDisabled(false);
        // 電話番号
        mst142Form.setListTelBangoDisabled(false);
        // 敷地面積
        mst142Form.setListShikichiMensekiDisabled(false);
        // 延床面積
        mst142Form.setListNobeyukaMensekiDisabled(false);
        // 明細リスト
        mst142Form.setDetailDisabled(false);
        // 前画面へボタン
        mst142Form.setBtnMaeGamenDisabled(false);
        // 編集ボタン
        mst142Form.setBtnHenshuDisabled(true);
        // 新規申請ボタン
        mst142Form.setBtnTorokuShinseiDisabled(true);
        // 複写申請ボタン
        mst142Form.setBtnFukushaShinseiDisabled(true);
        // 削除ボタン
        mst142Form.setBtnSakujoShinseiDisabled(true);
        // 論理削除ボタン
        mst142Form.setBtnRonriSakujoShinseiDisabled(true);
        // 申請ボタン
        mst142Form.setBtnShinseiDisabled(false);
    }

    /**
     * パタンF
     *
     */
    private void patternF() {
        // 施設コード
        mst142Form.setConShisetsuCdDisabled(false);
        // 適用開始日
        mst142Form.setConTekiyoKaishibiDisabled(false);
        // 適用名
        mst142Form.setConTekiyoMeiDisabled(false);
        // 適用終了
        mst142Form.setConTekiyoShuryobiDisabled(true);
        mst142Form.setConTekiyoShuryobiHidden(true);
        // 施設名
        mst142Form.setListShisetsuMeiDisabled(false);
        // 管轄営業所
        mst142Form.setListKankatsuEigyoshoDisabled(false);
        // 有効坪数
        mst142Form.setListYukoTsubosuDisabled(false);
        // 仕入値
        mst142Form.setListShiireNeDisabled(false);
        // JIS
        mst142Form.setJisDisabled(false);
        // 電話番号
        mst142Form.setListTelBangoDisabled(false);
        // 敷地面積
        mst142Form.setListShikichiMensekiDisabled(false);
        // 延床面積
        mst142Form.setListNobeyukaMensekiDisabled(false);
        // 明細リスト
        mst142Form.setDetailDisabled(false);
        // 前画面へボタン
        mst142Form.setBtnMaeGamenDisabled(false);
        // 編集ボタン
        mst142Form.setBtnHenshuDisabled(true);
        // 新規申請ボタン
        mst142Form.setBtnTorokuShinseiDisabled(true);
        // 複写申請ボタン
        mst142Form.setBtnFukushaShinseiDisabled(true);
        // 削除ボタン
        mst142Form.setBtnSakujoShinseiDisabled(true);
        // 論理削除ボタン
        mst142Form.setBtnRonriSakujoShinseiDisabled(true);
        // 申請ボタン
        mst142Form.setBtnShinseiDisabled(false);
    }

    /**
     * パタンG
     *
     */
    private void patternG() {
        // 施設コード
        mst142Form.setConShisetsuCdDisabled(true);
        // 適用開始日
        mst142Form.setConTekiyoKaishibiDisabled(true);
        // 適用名
        mst142Form.setConTekiyoMeiDisabled(true);
        // 適用終了
        mst142Form.setConTekiyoShuryobiDisabled(false);
        mst142Form.setConTekiyoShuryobiHidden(false);
        // 施設名
        mst142Form.setListShisetsuMeiDisabled(true);
        // 管轄営業所
        mst142Form.setListKankatsuEigyoshoDisabled(true);
        // 有効坪数
        mst142Form.setListYukoTsubosuDisabled(true);
        // 仕入値
        mst142Form.setListShiireNeDisabled(true);
        // JIS
        mst142Form.setJisDisabled(true);
        // 電話番号
        mst142Form.setListTelBangoDisabled(true);
        // 敷地面積
        mst142Form.setListShikichiMensekiDisabled(true);
        // 延床面積
        mst142Form.setListNobeyukaMensekiDisabled(true);
        // 明細リスト
        mst142Form.setDetailDisabled(true);
        // 前画面へボタン
        mst142Form.setBtnMaeGamenDisabled(false);
        // 編集ボタン
        mst142Form.setBtnHenshuDisabled(true);
        // 新規申請ボタン
        mst142Form.setBtnTorokuShinseiDisabled(true);
        // 複写申請ボタン
        mst142Form.setBtnFukushaShinseiDisabled(true);
        // 削除ボタン
        mst142Form.setBtnSakujoShinseiDisabled(true);
        // 論理削除ボタン
        mst142Form.setBtnRonriSakujoShinseiDisabled(true);
        // 申請ボタン
        mst142Form.setBtnShinseiDisabled(false);
    }

    /**
     * パタンH
     *
     */
    private void patternH() {
        // 施設コード
        mst142Form.setConShisetsuCdDisabled(true);
        // 適用開始日
        mst142Form.setConTekiyoKaishibiDisabled(true);
        // 適用名
        mst142Form.setConTekiyoMeiDisabled(true);
        // 適用終了
        mst142Form.setConTekiyoShuryobiDisabled(true);
        mst142Form.setConTekiyoShuryobiHidden(false);
        // 施設名
        mst142Form.setListShisetsuMeiDisabled(true);
        // 管轄営業所
        mst142Form.setListKankatsuEigyoshoDisabled(true);
        // 有効坪数
        mst142Form.setListYukoTsubosuDisabled(true);
        // 仕入値
        mst142Form.setListShiireNeDisabled(true);
        // JIS
        mst142Form.setJisDisabled(true);
        // 電話番号
        mst142Form.setListTelBangoDisabled(true);
        // 敷地面積
        mst142Form.setListShikichiMensekiDisabled(true);
        // 延床面積
        mst142Form.setListNobeyukaMensekiDisabled(true);
        // 明細リスト
        mst142Form.setDetailDisabled(true);
        // 前画面へボタン
        mst142Form.setBtnMaeGamenDisabled(false);
        // 編集ボタン
        mst142Form.setBtnHenshuDisabled(true);
        // 新規申請ボタン
        mst142Form.setBtnTorokuShinseiDisabled(true);
        // 複写申請ボタン
        mst142Form.setBtnFukushaShinseiDisabled(true);
        // 削除ボタン
        mst142Form.setBtnSakujoShinseiDisabled(true);
        // 論理削除ボタン
        mst142Form.setBtnRonriSakujoShinseiDisabled(true);
        // 申請ボタン
        mst142Form.setBtnShinseiDisabled(false);
    }

    /**
     * 数値のフォーマット処理
     *
     * @param data フォーマット対象
     * @param pattern パタン
     * @return フォーマット結果
     */
    public String fmtNumber(Object data, String pattern) {
        if (data == null) {
            return null;
        }
        if (data instanceof String) {
            return StrUtils.defaultString(data);
        }
        return NumberUtils.format(data, pattern);
    }

    /**
     * フォームクリア
     *
     * @param form
     */
    public void clearForm(Object form) {

        Class clazz = form.getClass();
        Field[] fields = clazz.getDeclaredFields();

        for (Field field : fields) {
            field.setAccessible(true);
            try {
                if (field.getName().contains("Disabled") || field.getName().contains("Visible")) {
                    field.set(form, false);
                } else {
                    field.set(form, null);
                }
            } catch (IllegalArgumentException | IllegalAccessException ex) {
            }
        }
    }
}
