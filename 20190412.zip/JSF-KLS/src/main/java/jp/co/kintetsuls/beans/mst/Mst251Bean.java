/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.cnst.SysMsg;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.kintetsuls.service.general.property.ExternalServiceProperty;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Getter;
import lombok.Setter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 仕向地名マスタ画面
 *
 * @author MaLei (MBP)
 * @version 2019/1/24 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst251")
@ViewScoped
public class Mst251Bean extends BaseBean {

    private final String strTitle = "集配料金表";
    private String url;     // URL

    @ManagedProperty(value = "#{breadBean}")
    @Getter
    @Setter
    private BreadCrumbBean breadBean;

    @ManagedProperty(value = "#{authConfBean}")
    @Getter
    @Setter
    private AuthorityConfBean authConfBean;

    private static final Logger logger = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    private RestfullService rest;

    @Getter
    @Setter
    private List<Map<String, String>> searchResult;

    @Getter
    @Setter
    private Map<String, String> selectSearchResult;

    /**
     * 都道府県
     */
    @Getter
    @Setter
    private String conTodofuken;
    /**
     * 仕向地名
     */
    @Getter
    @Setter
    private String conShimukeChiMei;
    /**
     * 削除済のみ
     */
    @Getter
    @Setter
    private String conSakujoSumiNomi[];

    private List<String> years;
    
    private  String [] ary = {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};


    public List<String> getYears() {

        List<String> resultList = new ArrayList<>(ary.length);
        Collections.addAll(resultList,ary);
        years = resultList;
        return years;
        
    }

    /**
     * コンストラクタ
     */
    public void setYears(List<String> years) {
        this.years = years;
    }

    public Mst251Bean() {
        
    }

    /**
     * 初期処理（処理）
     *
     * @param menuId
     * @param prevScreen
     * @param backFlag
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        
        List<String> resultList = new ArrayList<>(ary.length);
        Collections.addAll(resultList,ary);
        years = resultList;
        try {
            // パンくず追加
            breadBean.push("集配料金表", SCREEN.MST501_SCREEN.name(), this);
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }
    }

    /**
     * 検索処理
     *
     */
    public void search() {

        // 入力チェック
        if (conShimukeChiMei.isEmpty()) {

        }

        // 仕向地名マスタ検索し、取得した値を画面項目にセット
        List<Map<String, String>> res = getShimukeList();

    }

    /**
     * DBから仕向地名マスタ情報を取得する
     */
    private List<Map<String, String>> getShimukeList() {
        ServiceInterfaceBean req = new ServiceInterfaceBean();

        req.setFunctionCode(ExternalServiceProperty.getInstance().getProperty("mst501-get-shimuke-detail"));

        //parameter
        Map<String, Object> params = new HashMap<>();
        // 都道府県コード
        if (conTodofuken != null) {
            params.put("conTodofuken", conTodofuken.substring(0, 2));
        } else {
            params.put("conTodofuken", conTodofuken);
        }
        // 仕向地名コード
        params.put("conShimukeChiMei", conShimukeChiMei);
        // 削除済のみ
        params.put("conSakujoSumiNomi", conSakujoSumiNomi);
        String requestData = JSONUtil.makeJSONString(params);
        req.setJson(requestData);

        //JAX-RS接続を実行(SQL側のチェック処理など未実装。)
        rest = RestfullService.getInstance();
        ServiceInterfaceBean res = null;
        try {
            res = rest.request(req);
        } catch (Exception ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
            return null;
        }

        if (res == null || res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return null;
        }

        try {
            ObjectMapper mapper = new ObjectMapper();
            this.searchResult = mapper.readValue(res.getJson(), List.class);

        } catch (IOException ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
            return null;
        }

        // 戻りSIBのステータスチェック、エラー処理
        if (res == null || res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {

            // ToDo:各画面の仕様に従いメッセージ表示などのエラー処理を追加してください
        }

        return this.searchResult;
    }

    /**
     * メニュークリック（処理）
     *
     * @param menuId
     * @param nextScreen
     * @return
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }

        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック（処理）
     *
     * @return
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }
        url = forward(nextScreen, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return
     */
    @Override
    public String logoutClick() {
        return authConfBean.logout();
    }

    /**
     * 画面遷移処理（顧客マスタメンテナンス画面へ）
     *
     * @return
     * @throws java.lang.IllegalAccessException
     * @throws java.lang.reflect.InvocationTargetException
     */
    public String buttonClick() throws IllegalAccessException, InvocationTargetException {

        // 画面遷移
        url = forward(SCREEN.CUS012_SCREEN.name(), null, SCREEN.CUS011_SCREEN.name(), false);
        return url;
    }

    /**
     * @return the strTitle
     */
    public String getStrTitle() {
        return strTitle;
    }

    public List<String> completeText(String query) {
        List<String> tantoEigyosho = new ArrayList();

        tantoEigyosho.add("営業所００１");
        tantoEigyosho.add("営業所００２");
        tantoEigyosho.add("営業所００３");
        tantoEigyosho.add("営業所００４");
        tantoEigyosho.add("営業所００５");

        return tantoEigyosho;
    }
}
