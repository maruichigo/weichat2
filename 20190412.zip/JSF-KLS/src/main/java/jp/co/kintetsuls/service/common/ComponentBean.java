/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.service.common;

import java.io.Serializable;

/**
 * コンポーネント単位での設定値を管理する
 * @author Yuka Kobayashi
 */
public class ComponentBean implements Serializable  {

    private Boolean disabled = false;
    private Boolean visible = false;

    public void setDisabled(Boolean flg){
        this.disabled = flg;
    }
    public Boolean getDisabled(){
        return this.disabled;
    }
    public void setVisible(Boolean flg){
        this.visible = flg;
    }
    public Boolean getVisible(){
        return this.visible;
    }
    
    /**
     * DB設定値をvisibleとdisabledに分けて格納する
     * @param riyoSettei 0:利用不可(非表示),1:表示のみ,2:利用可能
     */
    public void setRiyoSettei(int riyoSettei){
        switch(riyoSettei){
            case 0:
                disabled = true;
                visible = false;
                break;
            case 1:
                disabled = true;
                visible = true;
                break;
            case 2:
                disabled = false;
                visible = true;
                break;
        }
    }
    
    
}
