package jp.co.kintetsuls.service.general;


import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.service.general.property.ExternalAuthTokenClientHeader;
import jp.co.kintetsuls.service.general.property.ExternalServiceProperty;
import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;
import java.io.IOException;
import java.util.*;
import jp.co.kintetsuls.common.cnst.SysMsg;
import org.slf4j.LoggerFactory;

/**
 * JAX-RS接続呼び出しクラス
 * @author klsproj
 */
public class RestfullService {

    private static RestfullService singleton = new RestfullService();

    public static RestfullService getInstance(){
        return singleton;
    }

    /** 
     * JAX-RS接続をServiceInterfaceBeanを指定して実行
    */
    public ServiceInterfaceBean request(ServiceInterfaceBean sib) throws SystemException,IOException {
        // JAX-RS接続情報
        String url = ExternalServiceProperty.getInstance().getProperty("external-service");
        String reqJson = JSONUtil.makeJSONString(sib);

        // Auth Token付与用フィルタ暗号、タイムアウト値設定
        ClientConfig config = new ClientConfig();
        config.register(ExternalAuthTokenClientHeader.class);
        Client client = ClientBuilder.newClient(config);
        client.property(ClientProperties.CONNECT_TIMEOUT, 1200000);

        WebTarget webTarget = client.target(ExternalServiceProperty.getInstance().getProperty("baseurl")).path(url);
        Invocation.Builder invocationBuilder =  webTarget.request(MediaType.APPLICATION_JSON);

        //JAX-RS実行
        Response response = invocationBuilder.post(Entity.entity(reqJson, MediaType.APPLICATION_JSON_TYPE));
        if (response.getStatus() != 200){
            org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());
            
            String msg = new StringBuilder().append("StatusCode ").append(response.getStatus()).append(" : ")
                    .append(SysMsg.ERRJAX).toString();
            logger.error(msg);
            sib.addMessage("ERROR", "エラー", msg);
            throw new SystemException(msg);
        }

        String result = response.readEntity(String.class);
        ObjectMapper mapper = new ObjectMapper();
        //エラーコードの場合はシステムエラーとして処理
        ServiceInterfaceBean res = mapper.readValue(result, new TypeReference<ServiceInterfaceBean>() {});
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_SYSTEM_ERROR){
            throw new SystemException();
        }

        return res;
    }

    public List<Map<String, Object>> jsonResMapList(ServiceInterfaceBean res)  throws IOException {
        List<Map<String, Object>> jsonResMapList = null;
        ObjectMapper mapper = new ObjectMapper();
        jsonResMapList = mapper.readValue(res.getJson(), new TypeReference<List<Map<String, Object>>>(){});
        return jsonResMapList;
    }
}
