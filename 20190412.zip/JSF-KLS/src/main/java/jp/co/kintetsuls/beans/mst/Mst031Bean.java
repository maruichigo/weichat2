/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.KbnBean;
import jp.co.kintetsuls.beans.common.KbnModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiListCol;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst031Form;
import jp.co.kintetsuls.forms.mst.Mst032Form;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 住所マスタ画面
 *
 * @author 曾鳳(MBP)
 * @version 2019/1/28 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst031")
@ViewScoped
@Data
public class Mst031Bean extends AbstractBean {

    /**
     * ダウンロードファイル名
     */
    private final static String FILE_NAME = "住所マスタ一覧";

    /**
     * タイトル
     */
    private final String TITLE = "住所マスタ";

    /**
     * 画面URL
     */
    private String url;
    
    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * ログインユーザー情報
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

    /**
     * 共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * 検索シーケンス処理共通
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;

    /**
     * 履歴一覧処理共通
     */
    @ManagedProperty(value = "#{rirekisyosai}")
    private RirekiSyosaiBean rirekiSyosaiBean;

    /**
     * E2コード定義取得Bean
     */
    @ManagedProperty(value = "#{kbnBean}")
    private KbnBean kbnBean;

    /**
     * ファイルダウンロード
     */
    @ManagedProperty(value = "#{fileBean}")
    private FileBean fileBean;

    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    /**
     * 住所マスタ フォーム
     */
    @ManagedProperty(value = "#{mst031Form}")
    private Mst031Form mst031Form;

    /**
     * 定数：一覧のデータテーブルID
     */
    private static final String DATA_TABLE_ID = "tablesorter_mst031";

    /**
     * スクリーンコード：MST031
     */
    private static final String SC_CD_MST031 = "MST031_SCREEN";

    /**
     * 定数：画面項目保持キー
     */
    private static final String CONST_MST031_FORM = "mst031Form";

    /**
     * 定数：再検索Button取得キー
     */
    private static final String CONST_MST031_SEARCH = "search_mst031";    
    
    /**
     * コンストラクタ
     */
    public Mst031Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId クリックされたメニューID（メニューからの遷移以外はNULL）
     * @param prevScreen 遷移元の画面
     * @param backFlag 戻るフラグ（前画面へボタンからの遷移以外はFALSE）
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            // パンくず追加
            breadBean.push(TITLE, SCREEN.MST031_SCREEN.name(), this);
            
            // 1)システムマスタ取得
            pageCommonBean.getMasterInfo(MsCnst.SYS_CDGROUP_MST031);

            // 検索シーケンス処理を初期化する
            searchHelpBean.regSearchHelp(DATA_TABLE_ID,
                    s -> {return count(false);},
                    s -> {search(); return null;},
                    s -> {return searchCheck();});
            searchHelpBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);

            // DBからマスタの内容を取得
            // ワーク.JIS住所リスト
            autoCompleteViewBean.initAddr("JIS_CD", null);
            // ワーク.営業所リスト
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO, new AutoCompOptionBean("全て", "all"));
            // ワーク.都道府県リスト
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_MS_TODOFUKEN);
            
            // 初期値を設定する
            setInitData();
            
            // 前回の記録をクリアする
            this.clear();
            mst031Form.setSearchResult(null);
            mst031Form.setSearchResultSelectable(null);
            mst031Form.setSelectedSearchResult(null);
            
            Mst031Form preForm = (Mst031Form) pageCommonBean.getPageInfo("mst031Form");
            // 戻ってきた場合
            if (backFlag && preForm != null) {
                PageCommonBean.simpleCopy(preForm, mst031Form);
                // 再検索を実施する
                pageCommonBean.searchAgain(CONST_MST031_SEARCH);
            } else {
                // 進んできた場合
                Flash flash = pageCommonBean.getPageParam();
                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_MST031_FORM) != null) {
                    PageCommonBean.simpleCopy(flash.get(CONST_MST031_FORM), mst031Form);
                    // 再検索を実施する
                    pageCommonBean.searchAgain(CONST_MST031_SEARCH);
                }
            }

            // ダウンロードシーケンスを初期化する
            fileBean.setDataSize(DATA_TABLE_ID, (id -> {return count(true);}));
            fileBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);
            fileBean.setTilte(FILE_NAME);
            fileBean.regDownloadFucntion(DATA_TABLE_ID, getHeader(), (id -> {return getList(true);}));
            fileBean.regBeforeDownFucntion(DATA_TABLE_ID, (comment -> {return beforeDown(comment);}));
            fileBean.setSearchResult(DATA_TABLE_ID, (id -> {return getSearchResult();})); 
            
            // component初期化とユーザ権限により制御を設定する
            pageCommonBean.setAuthControll(mst031Form, SC_CD_MST031, true);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * カウント処理
     *
     * @param downloadFlg ダウンロードフラグ
     * @return 件数
     */
    public long count(boolean downloadFlg) {

        // 前回の記録をクリアする
        Map<String, Object> mapRec = new LinkedHashMap();
        mapRec.put("hideFlg", "hideRow");
        List<Map<String, Object>> mapList = new ArrayList();
        mapList.add(mapRec);
        mst031Form.setSearchResult(mapList);
        mst031Form.setSearchResultSelectable(new ReportListDataModel(mst031Form.getSearchResult()));
        mst031Form.setSelectedSearchResult(null);

        // 件数取得処理
        long kensu = getKensu(downloadFlg);
        
        // サブ検索条件フラグ設定
        fileBean.setSubFlg(subSearchConHad());

        if (!downloadFlg) {

            // 検索部のステータスを変更する
            pageCommonBean.setSerchConDisabled(mst031Form);

            // 検索条件保存
            pageCommonBean.savePageInfo(CONST_MST031_FORM, mst031Form);
        }

        return kensu;
    }

    /**
     * 検索処理
     */
    public void search() {

        // 選択リストを初期化する
        mst031Form.setSelectedSearchResult(new ArrayList<>());
        
        // 一覧情報を検索する
        List<Map<String, Object>> recordList = getList(false);
        if(recordList==null){
            return;
        }
        fileBean.setDataList(recordList);

        // 取得した値を画面項目にセットする
        pageCommonBean.setDatalist(DATA_TABLE_ID, recordList);
        mst031Form.setSearchResultSelectable(new ReportListDataModel(recordList));

        // 検索部のステータス変更
        pageCommonBean.setSerchConDisabled(mst031Form);
    }
    
    /**
     * 検索時のチェック処理
     * 
     * @return チェック結果
     */
    public String searchCheck() {
        
        if (mst031Form.getConSedaiKensakuJoken() != null && mst031Form.getConSedaiKensakuJoken().length > 0) {
            // 世代検索条件で適用日指定が選択されている場合
            if (kbnBean.getKbnCdOfKeyCd(MsCnst.SEDAI_KENSAKU_JOKEN_TEKIYO_HI_SHITEI).equals(
                    mst031Form.getConSedaiKensakuJoken()[mst031Form.getConSedaiKensakuJoken().length - 1])) {
                
                if (mst031Form.getConTekiyoBi() == null) {
                    messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0028,
                        "searchForm:sk:skc:sedaiKensaku_sedaiKensakuCalendar",
                        "適用日指定", "適用日");
                    return "FALSE";
                }
            }
        }
        return "TRUE";
    }

    /**
     * 検索条件変更処理
     */
    public void searchChange() {

        // 検索部のステータスを変更する
        pageCommonBean.setSerchConEnabled(mst031Form);
    }

    /**
     * クリア処理
     */
    public void clear() {

        // 検索部の条件をクリア
        mst031Form.setConTodofuken(null);
        mst031Form.setConJisCd(null);
        mst031Form.setConJisJusho(null);
        mst031Form.setConJisCdNomiKensaku(null);
        mst031Form.setConKanjiJusho(null);
        mst031Form.setConJisCheckKekka(null);
        mst031Form.setConSedaiKensakuJoken(null);
        mst031Form.setConTekiyoBi(null);
        mst031Form.setConSakujoZumiNomiKensaku(null);
        mst031Form.setConRitoKannaiHaiso(null);
        mst031Form.setConKankatsuEigyoshoCd(null);
        mst031Form.setConTekiyoMei(null);
        
        // 初期値を設定する
        setInitData();
            
        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mst031Form);
        pageCommonBean.setBtnSearchChangeVisible(false);
        pageCommonBean.setBtnSearchVisible(true);
    }

    /**
     * アップロード
     * 
     * @return 遷移先画面のURL
     */
    public String upload() {
        
        // flash初期化
        Flash flash = pageCommonBean.getPageParam();
        
        // flashにアップロード機能コードを設定する
        flash.put("uploadFunctionCd", TITLE);
        
        // アップロード画面へ遷移
        url = forward(SCREEN.UPLOAD_SCREEN.name(), null, SCREEN.MST031_SCREEN.name(), false);
        return url;
    }

    /**
     * メニュークリック（処理）
     *
     * @param menuId クリックされたメニューID（メニューからの遷移以外はNULL）
     * @param nextScreen 遷移先の画面
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
   }

    /**
     * パンくずクリック（処理）
     *
     * @param nextScreen 遷移先の画面
     * @param breadIndex 選択されたパンくずのIndex
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        url = forward(nextScreen, null, null, true);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authConfBean.logout();
    }

    /**
     * 画面遷移処理
     *
     * @return 遷移先の画面URL
     * @throws java.lang.IllegalAccessException
     * @throws java.lang.reflect.InvocationTargetException
     */
    public String shimukeChiClick() throws IllegalAccessException, InvocationTargetException {

        // 画面遷移
        url = forward(SCREEN.MST501_SCREEN.name(), null, SCREEN.MST031_SCREEN.name(), false);
        return url;
    }
    
    /**
     * 詳細コンテキストメニュー／詳細ボタンクリック処理
     * 
     * @param buttonFlg 詳細ボタンクリックフラグ(true:詳細ボタンクリック)
     * @return 遷移先の画面URL
     * @throws IllegalAccessException
     * @throws InvocationTargetException 
     * @throws SystemException 
     */
    public String detailClick(boolean buttonFlg)
            throws IllegalAccessException, InvocationTargetException, SystemException {
        
        // 詳細ボタンクリックの場合、チェックを行う
        if (buttonFlg) {
            // 未選択、または、複数選択の場合はエラー
            if (mst031Form.getSelectedSearchResult() == null ||
                    mst031Form.getSelectedSearchResult().isEmpty() ||
                    mst031Form.getSelectedSearchResult().size() > 1) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
                return null;
            }
        }
        
        // 選択されたレコードを取得する
        Map<String, Object> selectedRecord = mst031Form.getSelectedSearchResult().get(0);
        // パラメータを設定する
        setMst032Param(selectedRecord.get("listShimukeChiCd").toString(),
                selectedRecord.get("listTekiyoKaishiBi").toString());

        // 画面遷移
        url = forward(SCREEN.MST032_SCREEN.name(), null, SCREEN.MST031_SCREEN.name(), false);
        return url;
    }
    
    /**
     * 仕向地コードリンククリック処理
     *
     * @param shimukeChiCd 仕向地コード
     * @param tekiyoKaishiBi 適用開始日
     * @return 遷移先の画面URL
     * @throws java.lang.IllegalAccessException
     * @throws java.lang.reflect.InvocationTargetException
     * @throws SystemException
     */
    public String linkClick(String shimukeChiCd, String tekiyoKaishiBi)
            throws IllegalAccessException, InvocationTargetException, SystemException {

        // パラメータを設定する
        setMst032Param(shimukeChiCd, tekiyoKaishiBi);
        
        // 画面遷移
        url = forward(SCREEN.MST032_SCREEN.name(), null, SCREEN.MST031_SCREEN.name(), false);
        return url;
    }
    
    /**
     * 住所マスタ履歴を表示処理
     *
     */
    public void rirekiIchiran() {

        // 履歴テーブル検索キーを設定する
        Map<String, Object> rirekiSearchKey = new HashMap();
        
        // 選択されたレコードを取得する
        Map<String, Object> selectedRecord = mst031Form.getSelectedSearchResult().get(0);
        // 仕向地コード
        rirekiSearchKey.put("listShimukeChiCd", selectedRecord.get("listShimukeChiCd"));
        // 適用開始日
        rirekiSearchKey.put("listTekiyoKaishiBi", selectedRecord.get("listTekiyoKaishiBi"));

        // 履歴タイトルを設定する
        rirekiSyosaiBean.setListColName(new ArrayList<>(Arrays.asList(
                "バージョン情報",
                "仕向地コード",
                "住所",
                "町字",
                "適用開始日",
                "仕向地名",
                "空港",
                "集配地区",
                "管轄営業所コード",
                "管轄営業所名",
                "旧EDI住所",
                "新EDI住所",
                "離島含む",
                "離島件数",
                "館内配送件数",
                "旧住所",
                "JISチェック",
                "適用名",
                "終了")));

        // 履歴beanの項目物理名を設定する
        List<String> colValue = new ArrayList<>(Arrays.asList(
                "listJushoDataVersion",
                "listShimukeChiCd",
                "listJusho",
                "listChoAza",
                "listTekiyoKaishiBi",
                "listShimukeChiMei",
                "listKuko",
                "listShuhaiChiku",
                "listKankatsuEigyoshoCd",
                "listKankatsuEigyoshoMei",
                "listKyuEdiJusho",
                "listShinEdiJusho",
                "listRitoFukumu",
                "listRitoKensu",
                "listKannaiHaisoKensu",
                "listKyuJusho",
                "listJisCheck",
                "listTekiyoMei",
                "listShuryo"));

        List<String> colAlign = new ArrayList<>(Arrays.asList(
                "left",
                "center",
                "left",
                "left",
                "center",
                "left",
                "left",
                "left",
                "left",
                "left",
                "center",
                "center",
                "center",
                "right",
                "right",
                "center",
                "center",
                "left",
                "center"));
        List<RirekiListCol> listCol = new ArrayList<>();
        for (int i = 0; i < colValue.size(); i++) {
           RirekiListCol col = new RirekiListCol();
           col.setColValue(colValue.get(i));
           col.setColAlign(colAlign.get(i));
           listCol.add(col);
        }
        rirekiSyosaiBean.setListCol(listCol);

        // 履歴テーブルを検索する
        rirekiSyosaiBean.searchList("2", "MST031_SEARCH_RIREKI", rirekiSearchKey);
    }

    /**
     * CSVファイルのタイトルを設定する処理
     * 
     * @return 画面タイトル
     */
    public List<CSVDto> getHeader() {
       
        // CSVファイルのタイトルを設定する
        List<CSVDto> header = new ArrayList<>();
        header.add(new CSVDto("仕向地コード", "listShimukeChiCd"));
        header.add(new CSVDto("住所", "listJusho"));
        header.add(new CSVDto("町字", "listChoAza"));
        header.add(new CSVDto("適用開始日", "listTekiyoKaishiBi"));
        header.add(new CSVDto("仕向地名", "listShimukeChiMei"));
        header.add(new CSVDto("空港", "listKuko"));
        header.add(new CSVDto("集配地区", "listShuhaiChiku"));
        header.add(new CSVDto("管轄営業所コード", "listKankatsuEigyoshoCd"));
        header.add(new CSVDto("管轄営業所名", "listKankatsuEigyoshoMei"));
        header.add(new CSVDto("旧EDI住所", "listKyuEdiJusho"));
        header.add(new CSVDto("新EDI住所", "listShinEdiJusho"));
        header.add(new CSVDto("離島含む", "listRitoFukumu"));
        header.add(new CSVDto("離島件数", "listRitoKensu"));
        header.add(new CSVDto("館内配送件数", "listKannaiHaisoKensu"));
        header.add(new CSVDto("旧住所", "listKyuJusho"));
        header.add(new CSVDto("JISチェック", "listJisCheck"));
        header.add(new CSVDto("適用名", "conTekiyoMei"));
        header.add(new CSVDto("終了", "listShuryo"));
        
        // 取得値を返却する
        return header;
    }
    
    /**
     * ダウンロード理由を記録する処理
     *
     * @param comment 理由コメント
     * @return 正常／異常
     * @throws Exception
     */
    public boolean beforeDown(String comment) throws Exception {
        
        // ダウンロード理由を記録する
        System.out.println(comment);
        
        return true;
    }
    
    /**
     * 住所マスタ詳細画面へパラメータを設定する
     * 
     * @param shimukeChiCd 仕向地コード
     * @param tekiyoKaishiBi 適用開始日
     * @throws SystemException 
     */
    private void setMst032Param(String shimukeChiCd, String tekiyoKaishiBi) throws SystemException {
        
        Mst032Form mst032Form = new Mst032Form();
        // JISコード
        mst032Form.setConJisCdTaihi(StringUtils.substring(shimukeChiCd, 0, 4));
        // 適用開始日
        mst032Form.setConTekiyoKaishibi(tekiyoKaishiBi);
        
        Flash flash = pageCommonBean.getPageParam();
        flash.put("mst032Form", mst032Form);
    }

    /**
     * 検索条件を設定する
     * 
     * @param downloadFlg ダウンロードフラグ
     * @return 検索条件
     */
    private Map<String, Object> setCondition(boolean downloadFlg) {
        
        Map<String, Object> params = new HashMap<>();
        
        Mst031Form tempForm = mst031Form;
        if (downloadFlg) {
            tempForm = (Mst031Form)pageCommonBean.getPageInfo(CONST_MST031_FORM);
        }
        
        // 都道府県コード
        params.put("conTodofukenCd", tempForm.getConTodofuken());
        // JISコード
        if (tempForm.getConJisCd() != null) {
            params.put("conJisCd", tempForm.getConJisCd().getValue());
        }
        // JIS住所
        params.put("conJisJusho", tempForm.getConJisJusho());
        // JISコードのみ検索
        if (tempForm.getConJisCdNomiKensaku() != null && tempForm.getConJisCdNomiKensaku().length > 0) {
            params.put("conJisCdNomiKensaku", tempForm.getConJisCdNomiKensaku()[0]);
        }
        // 漢字住所
        params.put("conKanjiJusho", tempForm.getConKanjiJusho());
        // JISチェック結果
        setParamCheckBox(params, tempForm.getConJisCheckKekka(), "conJisCheckKekka", MsCnst.JIS_CHECK_KEKKA);
        // 世代検索条件
        setParamCheckBox(
                params, tempForm.getConSedaiKensakuJoken(), "conSedaiKensakuJoken", MsCnst.SEDAI_KENSAKU_JOKEN);
        // 適用日
        params.put("conTekiyoBi", tempForm.getConTekiyoBi());
        // 削除済のみ検索
        if (tempForm.getConSakujoZumiNomiKensaku() != null && tempForm.getConSakujoZumiNomiKensaku().length > 0) {
            params.put("conSakujoZumiNomiKensaku", tempForm.getConSakujoZumiNomiKensaku()[0]);
        }
        // 離島/館内配送
        setParamCheckBox(params, tempForm.getConRitoKannaiHaiso(), "conRitoKannaiHaiso", MsCnst.RITO_KANNAI_HAISO);
        // 管轄営業所
        if (tempForm.getConKankatsuEigyoshoCd() != null) {
            params.put("conKankatsuEigyoshoCd", tempForm.getConKankatsuEigyoshoCd().getValue());
        }
        // 適用名
        params.put("conTekiyoMei", tempForm.getConTekiyoMei());
        // 全営業所検索
        params.put("allEigyoshoSearch", pageCommonBean.getMasterInfo().getAllEigyoshoSearch());
        // ログインユーザー所属営業所
        params.put("loginUserShozokuEigyosho", authConfBean.getLoginUserShozokuEigyosho());
        
        return params;
    }

    /**
     * 検索条件に一致するデータ件数の取得を行う
     * 
     * @param downloadFlg ダウンロードフラグ
     */
    private long getKensu(boolean downloadFlg) {

        // パラメータ
        Map<String, Object> params = setCondition(downloadFlg);
        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, "mst031-get-kensu");

        return Long.valueOf(res.getJson());
    }

    /**
     * 検索条件に一致するデータの取得を行う
     * 
     * @param downloadFlg ダウンロードフラグ
     */
    private List<Map<String, Object>> getList(boolean downloadFlg) {

        // パラメータ
        Map<String, Object> params = setCondition(downloadFlg);

        try {
            // DBをアクセス
            ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, "mst031-get-detail");
            ObjectMapper mapper = new ObjectMapper();
            mst031Form.setSearchResult(mapper.readValue(res.getJson(), List.class));
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
        return mst031Form.getSearchResult();
    }

    /**
     * 初期値を設定する
     */
    private void setInitData() {
        // JISチェック結果:全てチェック
        List<KbnModuleBean> jisCheckKekkaList = kbnBean.getKbnsOfGroupCd(MsCnst.JIS_CHECK_KEKKA);
        String[] jisCheckKekka = new String[jisCheckKekkaList.size()];
        for (int i = 0; i < jisCheckKekkaList.size(); i++) {
            jisCheckKekka[i] = jisCheckKekkaList.get(i).getKbnCd();
        }
        mst031Form.setConJisCheckKekka(jisCheckKekka);

        // 世代検索条件:"現在適用","未来適用"にチェック
        mst031Form.setConSedaiKensakuJoken(new String[]{
            kbnBean.getKbnCdOfKeyCd(MsCnst.SEDAI_KENSAKU_JOKEN_GENZAI_TEKIYO),
            kbnBean.getKbnCdOfKeyCd(MsCnst.SEDAI_KENSAKU_JOKEN_MIRAI_TEKIYO)});
    }
    
    /**
     * DB検索用のチェックボックスパラメータを設定する
     * 
     * @param params DB検索用のパラメータ
     * @param values 選択されたチェックボックス値
     * @param paramName パラメータ名
     * @param functionCd 区分マスタのグループコード
     */
    private void setParamCheckBox(Map<String, Object> params, String[] values, String paramName, String functionCd) {

        List<String> paramList = new ArrayList<>();
        List<KbnModuleBean> labelValueList = kbnBean.getKbnsOfGroupCd(functionCd);
        List<String> valList = new ArrayList<>();

        for(String val : values) {
            valList.add(val);
        }
        
        for (int i = 0; i < labelValueList.size(); i++) {
            if (valList.contains(labelValueList.get(i).getKbnCd())) {
                paramList.add("1");
            } else {
                paramList.add("0");
            }
        }
        params.put(paramName, paramList);
    }

    /**
     * サブ検索条件入力判断
     * 
     * @return true:入力あり/false:入力しない
     */
    private boolean subSearchConHad() {
        
        // 離島/館内配送
        if (mst031Form.getConRitoKannaiHaiso() != null && mst031Form.getConRitoKannaiHaiso().length > 0) {
            return true;
        }
        // 管轄営業所
        if (mst031Form.getConKankatsuEigyoshoCd() != null) {
            return true;
        }
        // 適用名
        if (!CheckUtils.isEmpty(mst031Form.getConTekiyoMei())) {
            return true;
        }

        return false;
    }

    /**
     * 検索結果を取得する
     * 
     * @return 検索結果
     */
    private List<Map<String, Object>> getSearchResult() {
        return mst031Form.getSearchResult();
    }

}

