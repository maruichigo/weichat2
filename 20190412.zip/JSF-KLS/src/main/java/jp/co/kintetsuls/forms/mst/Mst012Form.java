/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.forms.mst;

import java.util.Date;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import lombok.Data;

/**
 * ユーザーマスタ詳細
 * @author xupenggeyang
 */
@ManagedBean(name = "mst012Form")
@ViewScoped
@Data
public class Mst012Form {
    //ユーザーコード
    private AutoCompOptionBean userCd;

    //社員コードなし
    private Boolean isUserCdNull;

    //承認ステータス
    private String confirmStatus = "承認済";

    //適用開始日
    private Date tekiyoKaishibi;

    //適用名
    private String tekiyoNm;

    //適用終了
    private Boolean isEnd;

    //ユーザー名
    private String userNm;

    //カナ名
    private String userKanaNm;

    //英語表記
    private String userEngNm;

    //メールアドレス
    private String mail;

    //初期パスワード
    private String password;

    //使用区分
    private List<String> useKbn;

    //所属箇所
    private AutoCompOptionBean dependPlace;
    
    private Boolean isUsedDisplay;

    //アクセス可能組織
    private String accessibleSosiki;
    
    //アクセス可能組織名
    private String accessibleSosikiMei;
    
    //箇所長
    private Boolean isKashoLeader;
    
    //デフォルト所属
    private Boolean isDefault;
    
    //所属開始日
    private Date dependStart;
    
    //所属終了日
    private Date dependEnd;
    
    //備考
    private String biko;
    
    //ロールコード
    private String roleCd;
    
    //ロール名
    private String roleNm;
    
    //対象
    private Boolean isTaisho;
    
    //メニューID
    private String menuID;
    
    //テーマ
    private String theme;
    
    //備考1
    private String biko1;
    
    //備考2
    private String biko2;
    
    //備考3
    private String biko3;
    
    //備考4
    private String biko4;
    
    //更新日
    private String updateDate;
    
    //更新者
    private String updateUser;
    
    //最終ログイン日時
    private String recentLoginDate;
}
