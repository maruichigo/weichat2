/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common.annotation.validator;

import java.io.UnsupportedEncodingException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.annotation.MaxByteCheck;

/**
 * 最大桁数（Byte）チェック
 * 
 * @author 李信志(MBP)
 * @version 2019/3/9 新規作成
 */
public class MaxbyteCheckValidator implements ConstraintValidator<MaxByteCheck, Object> {

    private int max;

    @Override
    public void initialize(MaxByteCheck constraintAnnotation) {
        this.max = constraintAnnotation.maxByte();
    }

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext context) {
        try {
            if (value == null) {
                return true;
            }
            String valStr = null;
            if (value.getClass().getTypeName().equals("java.lang.String")) {
                valStr = value.toString();
            } else if (Object.class.getTypeName().equals("AutoCompOptionBean")) {
                valStr = ((AutoCompOptionBean)value).getValue();
            }
            return !(valStr != null && valStr.getBytes("UTF-8").length > max);
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(MaxSizeCheckValidator.class.getName()).log(Level.SEVERE, null, ex);
            return true;
        }
    }
}
