/*
 *Copyright (C) 2014 MBP Corporation All Rights Reserved . 
 */
package jp.co.kintetsuls.beans.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import static jp.co.kintetsuls.beans.common.AutoCompleteBean.COMMON_GET_CREATE_LIST;
import jp.co.kintetsuls.beans.common.dto.AutoCompleteItemDto;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.cnst.SysMsg;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.kintetsuls.utils.DateUtils;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 共通页面(自动补全)Controller
 *
 * @author hq
 */
@ViewScoped
@ManagedBean
@Data
public class AutoCompleteViewBean implements Serializable {

    private HashMap<String, AutoCompleteItemDto> autoCompleteItemDtoList = new HashMap<>();

    private static final long serialVersionUID = 1L;

    private static final Logger logger = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    private RestfullService rest;

    @ManagedProperty(value = "#{addrAutoCompleteViewBean}")
    private AddrAutoCompleteViewBean addrAutoCompleteViewBean;

    @ManagedProperty(value = "#{addr2AutoCompleteViewBean}")
    private Addr2AutoCompleteViewBean addr2AutoCompleteViewBean;

    @ManagedProperty(value = "#{autoComplete}")
    private AutoCompleteBean autoCompleteBean;

    @ManagedProperty(value = "#{kbnBean}")
    private KbnBean kbnBean;

    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    /**
     * 区分マスタのコードキーよりマスタデータを取得する
     *
     * @param name Function_code
     * @param kbnKey 区分マスタのコードキー
     * @return マスタデータ
     */
    public AutoCompOptionBean getComMsDatasByKbnKey(String name, String kbnKey) {

        return getComMsDatasByKbnKey(name, kbnKey, null);
    }

    /**
     * 区分マスタのコードキーよりマスタデータを取得する
     *
     * @param name Function_code
     * @param kbnKey 区分マスタのコードキー
     * @param firstBean 先頭追加表示内容
     * @return マスタデータ
     */
    public AutoCompOptionBean getComMsDatasByKbnKey(String name, String kbnKey, AutoCompOptionBean firstBean) {

        return getComMsDatasByKbnKey(name, kbnKey, firstBean, null);
    }

    /**
     * 区分マスタのコードキーよりマスタデータを取得する
     *
     * @param name Function_code
     * @param kbnKey 区分マスタのコードキー
     * @param firstBean 先頭追加表示内容
     * @param initValue 初期表示値
     * @return マスタデータ
     */
    public AutoCompOptionBean getComMsDatasByKbnKey(String name, String kbnKey, AutoCompOptionBean firstBean, String initValue) {

        Map<String, String> params = new HashMap<>();

        // 付帯料金項目1取得、または、付帯料金項目2取得　の場合
        if (MsCnst.COM_GET_VW_FUTAI_RYOKIN_KOMOKU1.equals(name) || MsCnst.COM_GET_VW_FUTAI_RYOKIN_KOMOKU2.equals(name)) {
            params.put("uriageKbn", kbnBean.getKbnCdOfKeyCd(kbnKey));
            params.put("KBN_KEY", kbnKey);
        }
        return getComMsDatas(name, params, firstBean, initValue);
    }

    /**
     * 指定値よりマスタデータを取得する
     *
     * @param name Function_code
     * @param paramValue 指定値
     * @return マスタデータ
     */
    public AutoCompOptionBean getComMsDatasByVal(String name, String paramValue) {

        return getComMsDatasByVal(name, paramValue, null);
    }

    /**
     * 指定値よりマスタデータを取得する
     *
     * @param name Function_code
     * @param paramValue 指定値
     * @param firstBean 先頭追加表示内容
     * @return マスタデータ
     */
    public AutoCompOptionBean getComMsDatasByVal(String name, String paramValue, AutoCompOptionBean firstBean) {

        return getComMsDatasByVal(name, paramValue, firstBean, null);
    }

    /**
     * 指定値よりマスタデータを取得する
     *
     * @param name Function_code
     * @param paramValue 指定値
     * @param firstBean 先頭追加表示内容
     * @param initValue 初期表示値
     * @return マスタデータ
     */
    public AutoCompOptionBean getComMsDatasByVal(String name, String paramValue, AutoCompOptionBean firstBean, String initValue) {

        Map<String, String> params = new HashMap<>();

        // 付帯料金項目1取得、または、付帯料金項目2取得　の場合
        if (MsCnst.COM_GET_VW_FUTAI_RYOKIN_KOMOKU1.equals(name) || MsCnst.COM_GET_VW_FUTAI_RYOKIN_KOMOKU2.equals(name)) {
            params.put("uriageKbn", paramValue);
            params.put("KBN_KEY", paramValue);
        }
        return getComMsDatas(name, params, firstBean, initValue);
    }

    /**
     * 区分マスタ取得
     *
     * @param kbnGroupCd 区分グループコード
     * @return 区分情報
     */
    public AutoCompOptionBean getMsKbn(String kbnGroupCd) {

        return this.getMsKbn(kbnGroupCd, null);
    }

    /**
     * 区分マスタ取得
     *
     * @param kbnGroupCd 区分グループコード
     * @param firstBean 先頭追加表示内容
     * @return 区分情報
     */
    public AutoCompOptionBean getMsKbn(String kbnGroupCd, AutoCompOptionBean firstBean) {

        return this.getMsKbn(kbnGroupCd, firstBean, null);
    }

    /**
     * 区分マスタ取得
     *
     * @param kbnGroupCd 区分グループコード
     * @param firstBean 先頭追加表示内容
     * @param initValue 初期表示値
     * @return 区分情報
     */
    public AutoCompOptionBean getMsKbn(String kbnGroupCd, AutoCompOptionBean firstBean, String initValue) {

        Map<String, String> params = new HashMap<>();
        params.put("kbnGroupCd", kbnGroupCd);
        return getComMsDatas("COM_GET_MS_KBN", params, firstBean, initValue);
    }

    /**
     * 区分マスタ取得（区分名）
     *
     * @param kbnGroupCd 区分グループコード
     * @return 区分情報
     */
    public AutoCompOptionBean getMsKbnMei(String kbnGroupCd) {

        Map<String, String> params = new HashMap<>();
        params.put("kbnGroupCd", kbnGroupCd);
        return getComMsDatas("COM_GET_MS_KBN_MEI", params, null, null);
    }

    /**
     * 共通マスタ取得（パラメータが必要のSQL）
     *
     * @param name Function_code
     * @param params パラメータ
     * @param initValue 初期表示値
     * @return 初期表示データオプション
     */
    public AutoCompOptionBean getMsDatasWithParam(String name, Map params, String initValue) {
                
        autoCompleteBean.initAutoCompleteWithParam(name, params);

        initWithFuns(name, word -> {
            return autoCompleteBean.getLabelValueListByKey(name, params, null, null, word);
        });
        return autoCompleteBean.getOptionBeanByValue(name, params, initValue, null);
    }

    /**
     * 共通マスタ取得
     *
     * @param name Function_code
     * @return 初期表示データオプション
     */
    public AutoCompOptionBean getComMsDatas(String name) {
        return this.getComMsDatas(name, null, null);
    }

    /**
     * 共通マスタ取得
     *
     * @param name Function_code
     * @param initValue 初期表示値
     * @return 初期表示データオプション
     */
    public AutoCompOptionBean getComMsDatas(String name, String initValue) {
        return this.getComMsDatas(name, null, null, null, initValue);
    }

    /**
     * 共通マスタ取得
     *
     * @param name Function_code
     * @param firstBean 先頭追加表示内容
     * @return 初期表示データオプション
     */
    public AutoCompOptionBean getComMsDatas(String name, AutoCompOptionBean firstBean) {
        return this.getComMsDatas(name, firstBean, null);
    }

    /**
     * 共通マスタ取得
     *
     * @param name Function_code
     * @param firstBean 先頭追加表示内容
     * @param honshaFlg 本社区分（１：本社、２：営業所、NULL：判断しない）
     * @return 初期表示データオプション
     */
    public AutoCompOptionBean getComMsDatas(String name, AutoCompOptionBean firstBean, String honshaFlg) {
        return this.getComMsDatas(name, firstBean, honshaFlg, null);
    }

    /**
     * 共通マスタ取得
     *
     * @param name Function_code
     * @param firstBean 先頭追加表示内容
     * @param honshaFlg 本社区分（１：本社、２：営業所、NULL：判断しない）
     * @param initValue 初期表示値
     * @return 初期表示データオプション
     */
    public AutoCompOptionBean getComMsDatas(String name, AutoCompOptionBean firstBean, String honshaFlg, String initValue) {
        return this.getComMsDatas(name, null, firstBean, honshaFlg, initValue);
    }

    /**
     * 共通マスタ取得
     *
     * @param name Function_code
     * @param params パラメータ
     * @param firstBean 先頭追加表示内容
     * @param honshaFlg 本社区分（１：本社、２：営業所、NULL：判断しない）
     * @param initValue 初期表示値
     * @return 初期表示データオプション
     */
    private AutoCompOptionBean getComMsDatas(String name, Map params, AutoCompOptionBean firstBean, String honshaFlg, String initValue) {
        
        if (params == null) {
            params = new HashMap();
        }
        // ログインユーザーコード
        params.put("loginuserCd", authConfBean.getUserCd());
        // システム日付
        params.put("sysDate", DateUtils.format(DateUtils.getSysDate(), StndConsIF.DF_YYYY_MM_DD));

        autoCompleteBean.initAutoComplete(name, params, firstBean, honshaFlg);

        String key = name;

        // 区分マスタ取得の場合
        if (MsCnst.COM_GET_MS_KBN.equals(name)
                || MsCnst.COM_GET_MS_KBN_MEI.equals(name)) {
            if (params.get("kbnGroupCd") != null) {
                String kbnGroupCd = params.get("kbnGroupCd").toString();

                key = name.concat("_").concat(kbnGroupCd);
            }
        }
        // 付帯料金項目1取得、または、付帯料金項目2取得　の場合
        if (MsCnst.COM_GET_VW_FUTAI_RYOKIN_KOMOKU1.equals(name) || MsCnst.COM_GET_VW_FUTAI_RYOKIN_KOMOKU2.equals(name)) {
            if (params.get("KBN_KEY") != null) {
                String kbnKey = params.get("KBN_KEY").toString();

                key = name.concat("_").concat(kbnKey);
            }
        }
        if (firstBean != null) {
            key = name.concat("_").concat(firstBean.getValue());
        }
        if (!CheckUtils.isEmpty(honshaFlg)) {
            key = key.concat("_honsha_").concat(honshaFlg);
        }

        Map allParams = params;

        initWithFuns(key, word -> {
            return autoCompleteBean.getLabelValueListByKey(name, allParams, firstBean, honshaFlg, word);
        });
        return autoCompleteBean.getOptionBeanByValue(name, allParams, initValue, firstBean);
    }

    /**
     * 共通マスタ取得
     *
     * @param name Function_code
     * @param params パラメータ
     * @param firstBean 先頭追加表示内容
     * @param initValue 初期表示値
     * @return 初期表示データオプション
     */
    private AutoCompOptionBean getComMsDatas(String name, Map params, AutoCompOptionBean firstBean, String initValue) {
        return this.getComMsDatas(name, params, firstBean, null, initValue);
    }

    /**
     * 初期化する
     *
     * @param name
     * @param value
     */
    public void initSample(String name, String value) {
        if (CheckUtils.isEmpty(name)) {
            name = "auto_com_zip";
        }
        AutoCompleteItemDto autoCompleteItemDto = new AutoCompleteItemDto();
        Function<String, List<AutoCompOptionBean>> autoCompeteFun = word -> {
            Map params = new HashMap();
            return getValueLabelFromDB("COM_GET_VW_KOKYAKU", params);
        };

        autoCompleteItemDto.setAutoCompeteFun(autoCompeteFun);

        this.autoCompleteItemDtoList.put(name, autoCompleteItemDto);
    }

    public AutoCompOptionBean initWithFuns(String name, Function<String, List<AutoCompOptionBean>> autoCompeteFun) {
        return initWithFuns(name, null, autoCompeteFun);
    }

    public AutoCompOptionBean initWithFuns(String name, String value, Function<String, List<AutoCompOptionBean>> autoCompeteFun) {
        if (CheckUtils.isEmpty(name)) {
            name = "auto_com_";
        }
        AutoCompleteItemDto autoCompleteItemDto = new AutoCompleteItemDto();

        autoCompleteItemDto.setAutoCompeteFun(autoCompeteFun);

        this.autoCompleteItemDtoList.put(name, autoCompleteItemDto);

        if (value != null && !"".equals(value)) {
            List<AutoCompOptionBean> re = autoCompeteFun.apply(value);
            if (re != null && !re.isEmpty()) {
                return re.get(0);
            }
        }
        return null;
    }

    /**
     * DBからAutoCompleteを取得する
     *
     * @param listId SQL文のID
     * @param param SQL文のパラメータ
     * @return VALUE:LABELのPOJOリスト
     */
    public List<AutoCompOptionBean> getValueLabelFromDB(String listId, Map param) {

        ServiceInterfaceBean req = new ServiceInterfaceBean();
        List<AutoCompOptionBean> resList = new ArrayList<>();

        req.setFunctionCode(COMMON_GET_CREATE_LIST);

        //parameter
        Map<String, Object> params = new HashMap<>();
        params.put("listId", listId);
        params.put("params", param);
        String requestData = JSONUtil.makeJSONString(params);
        req.setJson(requestData);

        //JAX-RS接続を実行(SQL側のチェック処理など未実装。)
        rest = RestfullService.getInstance();
        ServiceInterfaceBean res = null;
        try {
            res = rest.request(req);
        } catch (Exception ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
            return new ArrayList<>();
        }

        if (res == null || res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return new ArrayList<>();
        }

        Map<String, Object> result;
        try {
            ObjectMapper mapper = new ObjectMapper();
            List searchResult = mapper.readValue(res.getJson(), List.class);
            List<Map<String, String>> searchResults = searchResult;
            for (Map<String, String> rec : searchResults) {
                AutoCompOptionBean labelValue = new AutoCompOptionBean();
                labelValue.setLabel(rec.get("LABEL"));
                labelValue.setValue(rec.get("VALUE"));
                resList.add(labelValue);
            }
        } catch (IOException ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
            return new ArrayList<>();
        }
        return resList;
    }

    public AutoCompOptionBean initAddr(String name, String value) {
        return initWithFuns(name, value, temp -> {
            return addrAutoCompleteViewBean.doubleComboJis(temp);
        }
        );
    }

    public AutoCompOptionBean initAddr2(String name, String value) {
        return initWithFuns(name, value, temp -> {
            return addr2AutoCompleteViewBean.doubleComboJis(temp);
        }
        );
    }

}
