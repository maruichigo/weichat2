/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.stc;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.AutoCompleteBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.cnst.SysMsg;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.file.CsvBuilder;
import jp.co.kintetsuls.file.FileDto;
import jp.co.kintetsuls.forms.mst.Mst501Form;
import jp.co.kintetsuls.forms.stc.Stc031Form;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.kintetsuls.service.general.property.ExternalServiceProperty;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 仕向地名マスタ画面
 *
 * @author MaLei (MBP)
 * @version 2019/1/24 新規作成
 */
@javax.faces.bean.ManagedBean(name = "stc031")
@ViewScoped
@Data
public class Stc031Bean extends AbstractBean {

    private final String strTitle = "仕入支払額一覧";
    private String url;     // URL

    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    @ManagedProperty(value = "#{autoComplete}")
    private AutoCompleteBean autoCompleteBean;

    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    @ManagedProperty(value = "#{fileBean}")
    private FileBean fileBean;

    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messageProperty;

    @ManagedProperty(value = "#{stc031Form}")
    private Stc031Form form;

    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommon;
    
    
    private static final Logger logger = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    private RestfullService rest;

    /**
     * メッセージID：COME0029.
     */
    private static final String MSG_ID_COME0029 = "COME0029";

    /**
     * 定数：検索FUNC_CODE.
     */
    private static final String SEARCH_FUNC_CODE = "mst501-get-shimuke-detail";

    /**
     * 定数：SAKUJO_FLG.
     */
    private static final String CONST_SAKUJO_FLG = "SAKUJO_FLG";

    /**
     * 定数：0文字列.
     */
    private static final String CONST_ZERO_STRING = "0";

    /**
     * 定数：COM_GET_MS_TODOFUKEN.
     */
    private static final String CONST_COM_GET_MS_TODOFUKEN = "COM_GET_MS_TODOFUKEN";

    /**
     * コンストラクタ
     */
    public Stc031Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId
     * @param prevScreen
     * @param backFlag
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
//        try {
//            // AutoCompleteを初期化する
//            Map params = new HashMap();
//            params.put(CONST_SAKUJO_FLG, CONST_ZERO_STRING);
//            autoCompleteBean.initAutoComplete(CONST_COM_GET_MS_TODOFUKEN, params);
//
//            fileBean.setTargetController(this);
//            // パンくず追加
//            breadBean.push("仕向地名マスタ一覧画面", SCREEN.MST501_SCREEN.name(), this);
//        } catch (Exception ex) {
//            logger.error(ex.getMessage(), ex);
//        }
    }

    /**
     * 検索処理
     *
     */
    public void search() {

        // 仕向地名マスタ検索し、取得した値を画面項目にセット
        List<Map<String, Object>> res = getShimukeList();
        pageCommon.getDatasLists().put("tablesorter_mst501", res);
        form.setSearchResultSelectable(new ReportListDataModel(res));
    }

    /**
     * 更新処理
     *
     */
    public void update() {

        // 入力チェック
        if (form.getSelectedSearchResult().isEmpty()) {
            messageProperty.message(MessagePropertyBean.SEVERITY_ERROR, MSG_ID_COME0029);
        }

    }

    /**
     * DBから仕向地名マスタ情報を取得する
     */
    private List<Map<String, Object>> getShimukeList() {

        //ServiceInterfaceBean req = new ServiceInterfaceBean();

        //req.setFunctionCode(ExternalServiceProperty.getInstance().getProperty(SEARCH_FUNC_CODE));

        //parameter
        
        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        Map<String, Object> params1 = new HashMap<>();
        params1.put("shiresaki", "仕入先名称Ａ００００１");
        params1.put("shireKbn", "MAWB");
        params1.put("taxCode", "145");
        params1.put("shuseikiKin", "1000000");
        params1.put("hikakusuishuseiki", "0");
        params1.put("shuseikishohisui", "80,000");
        params1.put("shuseikishiharaiKin", "1,080,000");
        params1.put("shoriAndhosokukamoku", "混載輸送原価　航空運賃原価");
        params1.put("shihoraihohou", "01:後払");
        params1.put("seikyukin", "1,100,000");
        params1.put("seikyushohisui", "88,000");
        params1.put("seikyushiharaikKin", "1,188,000");
        list.add(params1);
        
        Map<String, Object> params2 = new HashMap<>();
        params2.put("shiresaki", "仕入先名称Ａ００００１");
        params2.put("shireKbn", "発送中継委託");
        params2.put("taxCode", "145");
        params2.put("shuseikiKin", "2000000");
        params2.put("hikakusuishuseiki", "0");
        params2.put("shuseikishohisui", "160,000");
        params2.put("shuseikishiharaiKin", "2,160,000");
        params2.put("shoriAndhosokukamoku", "混載輸送原価　発送中継原価");
        params2.put("shihoraihohou", "02:後払");
        params2.put("seikyukin", "1,100,000");
        params2.put("seikyushohisui", "88,000");
        params2.put("seikyushiharaikKin", "1,188,000");
        list.add(params2);
        
        Map<String, Object> params3 = new HashMap<>();
        params3.put("shiresaki", "仕入先名称B００００１");
        params3.put("shireKbn", "幹線・母船");
        params3.put("taxCode", "145");
        params3.put("shuseikiKin", "2000000");
        params3.put("hikakusuishuseiki", "0");
        params3.put("shuseikishohisui", "160,000");
        params3.put("shuseikishiharaiKin", "2,160,000");
        params3.put("shoriAndhosokukamoku", "混載輸送原価　発送中継原価");
        params3.put("shihoraihohou", "02:後払");
        params3.put("seikyukin", "1,100,000");
        params3.put("seikyushohisui", "88,000");
        params3.put("seikyushiharaikKin", "1,188,000");
        list.add(params2);
        form.setSearchResult(list);
        return list;
    }

    /**
     * メニュークリック（処理）
     *
     * @param menuId
     * @param nextScreen
     * @return
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }

        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック（処理）
     *
     * @return
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }
        url = forward(nextScreen, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return
     */
    @Override
    public String logoutClick() {
        return authConfBean.logout();
    }

    /**
     * 画面遷移処理（顧客マスタメンテナンス画面へ）
     *
     * @return
     * @throws java.lang.IllegalAccessException
     * @throws java.lang.reflect.InvocationTargetException
     */
    public String buttonClick() throws IllegalAccessException, InvocationTargetException {

        // 画面遷移
        url = forward(SCREEN.CUS012_SCREEN.name(), null, SCREEN.CUS011_SCREEN.name(), false);
        return url;
    }

    /**
     * @return the strTitle
     */
    public String getStrTitle() {
        return strTitle;
    }

    /**
     * CSV作成ファイル
     *
     * @return
     */
    @Override
    public FileDto getDownloadFilePath(String id) throws Exception {
        List<CSVDto> header = new ArrayList<>();
        header.add(new CSVDto("都道府県コード", "listTodofukenCd"));

        header.add(new CSVDto("都道府県名", "listTodofukenMei"));
        header.add(new CSVDto("仕向地名コード", "listShimukeChiMeiCd"));
        header.add(new CSVDto("仕向地名", "listShimukeChiMei"));
        header.add(new CSVDto("備考", "listBiko"));

        List<Map<String, Object>> body = getShimukeList();

        String saveFile = CsvBuilder.saveCsvInfofromMap(header, body);
        return new FileDto("", CsvBuilder.FILE_STORE_FOLDER_TEMP + StndConsIF.FS + saveFile);

    }

}
