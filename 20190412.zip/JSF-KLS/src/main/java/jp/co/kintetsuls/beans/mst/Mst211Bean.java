/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiListCol;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst211Form;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 車両マスタ画面
 *
 * @author 許 彭戈ヤン (MBP)
 * @Version 2019/01/20 新規作成
 */
@ManagedBean(name = "mst211")
@ViewScoped
@Data
public class Mst211Bean extends BaseBean {

    /**
     * タイトル
     */
    private final String TITLE = "車両マスタ";
    
    /**
     * ダウンロードファイル名
     */
    private final static String FILE_NAME = "車両マスタ一覧";

    /**
     * 画面URL
     */
    private String url;

    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;
    
    /**
     * 一覧のAutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoComplete}")
    private AutoCompleteBean autoCompleteBean;

    /**
     * ファイルダウンロード
     */
    @ManagedProperty(value = "#{fileBean}")
    private FileBean fileBean;

    /**
     * 履歴一覧処理共通
     */
    @ManagedProperty(value = "#{rirekisyosai}")
    private RirekiSyosaiBean rirekiSyosai;

    /**
     * 検索シーケンス処理共通
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;

    /**
     * メッセージ処理共通
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messageProperty;

    /**
     * 共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommon;
    
    /**
     * 一覧単項目チェック共通
     */
    @ManagedProperty(value = "#{listCheckBean}")
    private ListCheckBean listCheckBean;
    
    /**
     * 画面フォーム
     */
    @ManagedProperty(value = "#{mst211Form}")
    private Mst211Form mst211Form;

    /**
     * ログ出力
     */
    private final static Logger LOGGER = LogManager.getLogger(
            new Object() {}.getClass().getEnclosingClass().getName());

    /**
     * スクリーンコード：MST211
     */
    private final static String SC_CD_MST211 = "MST211_SCREEN";

    /**
     * 定数：検索
     */
    private final static String FUNC_SEARCH = "mst211-get-sharyo-detail";

    /**
     * 定数：検索件数
     */
    private final static String FUNC_SEARCH_COUNT = "mst211-get-sharyo-count";

    /**
     * 定数：削除
     */
    private final static String FUNC_DELETE = "mst211-delete";

    /**
     * 定数：登録更新
     */
    private final static String FUNC_INSERT_UPDATE = "mst211-insert-update";

    /**
     * 定数：登録更新チェック
     */
    private final static String FUNC_INSERT_UPDATE_CHECK = "mst211-insert-update-check";
    
    /**
     * 定数：車種取得
     */
    private final static String FUNC_GET_SHASHU = "mst211-get-shashu";

    /**
     * 定数：存在チェック
     */
    private final static String FUNC_DELETE_CHECK = "mst211-delete-check";

    /**
     * 文字列：テーブルID
     */
    private final static String DATA_TABLE_ID = "tablesorter_mst211";
    
    /**
     * 文字列：削除
     */
    private final static String SAKUJO = "削除";

    /**
     * 定数：画面項目保持キー
     */
    private final static String CONST_MST211_FORM = "mst211Form";
    
    /**
     * 定数：再検索Button取得キー
     */
    private final static String CONST_MST211_SEARCH = "search_mst211";

    /**
     * 定数：MasterInfo取得キー
     */
    private final static String CONST_MST211_MASTER = "mst211";

    /**
     * 世代検索デフォルト値
     */
    private final static String[] DEFAULT_VALUE = {"01", "02"};

    /**
     * 履歴テーブル検索キー
     */
    private Map<String, Object> rirekiSearchKey;

    /**
     * メッセージリスト
     */
    List<MessageModuleBean> msgList = new ArrayList<>();
    
    /**
     * コンストラクタ
     */
    public Mst211Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId メニューID
     * @param prevScreen 前画面
     * @param backFlag 戻るフラグ
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {

            // パンくず追加
            breadBean.push(TITLE, Cnst.SCREEN.MST211_SCREEN.name(), this);
            
            // システムマスタ取得する
            pageCommon.getMasterInfo(CONST_MST211_MASTER);

            // デフォルト値
            mst211Form.setConSedaiKensakuJoken(DEFAULT_VALUE);
            
            // 車種取得
            mst211Form.setShashu(getShashu());

            // 検索シーケンス処理ため初期化
            searchHelpBean.regSearchHelp(DATA_TABLE_ID,
                    s -> {return getRecordCount();},
                    s -> {search(); return null;},
                    null);
            searchHelpBean.getSettings().put(DATA_TABLE_ID, pageCommon);

            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(営業所)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO, new AutoCompOptionBean("全て", "all"));
            
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(仕入先)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_SHIIRESAKI);
            
            // 前回の記録をクリアする
            this.clear();
            mst211Form.setSearchResult(null);
            mst211Form.setSearchResultSelectable(null);
            mst211Form.setSelectedSearchResult(null);

            // 戻ってきた場合
            Mst211Form preForm = (Mst211Form) pageCommon.getPageInfo(CONST_MST211_FORM);           
            if (backFlag && preForm != null) {
                PageCommonBean.simpleCopy(preForm, mst211Form);
                // 再検索を実施する
                pageCommon.searchAgain(CONST_MST211_SEARCH);
                // 進んできた場合
            } else {
                Flash flash = pageCommon.getPageParam();

                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_MST211_FORM) != null) {
                    PageCommonBean.simpleCopy(flash.get(CONST_MST211_FORM), mst211Form);
                    // 再検索を実施する
                    pageCommon.searchAgain(CONST_MST211_SEARCH);
                }
            }

            // ダウンロードシーケンスを初期化する
            fileBean.setDataSize(DATA_TABLE_ID, (id -> {return getRecordCount();}));
            fileBean.setSearchResult(DATA_TABLE_ID, (id -> {return getSearchResult();})); 
            fileBean.getSettings().put(DATA_TABLE_ID, pageCommon);
            fileBean.setSubFlg(false);
            fileBean.setTilte(FILE_NAME);
            fileBean.regDownloadFucntion(DATA_TABLE_ID, getHeader(), (id -> {return getSharyoList();}));
            fileBean.regBeforeDownFucntion(DATA_TABLE_ID, (comment -> {return beforeDown(comment);}));

            // 行更新また削除するために共通処理へ登録
            pageCommon.regDelFucntion(DATA_TABLE_ID, (dataList -> (this.delRows(dataList))));

            // component初期化とユーザ権限により制御を設定する
            pageCommon.setAuthControll(mst211Form, SC_CD_MST211, true);
            
            // 初期はデータを編集不可にする
            mst211Form.setBtnEditeDisabled(true);

        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

    }

    /**
     * メニュークリック処理
     *
     * @param menuId 遷移先画面ID
     * @param nextScreenId パンくずのインデックス
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreenId) {
        
        try {
            // パンくずを削除するs
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移を行う
        url = forward(nextScreenId, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック処理
     *
     * @param nextScreenId 遷移先画面ID
     * @param breadIndex パンくずのインデックス
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreenId, int breadIndex) {
        
        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        url = forward(nextScreenId, null, null, true);
        return url;
    }

    /**
     * ログアウトクリック処理
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        
        return authConfBean.logout();
    }

    /**
     * カウント処理
     *
     * @return 検索件数
     */
    public long getRecordCount() {
        
        // 前回の記録をクリアする
        Map<String, Object> mapRec = new LinkedHashMap();
        mapRec.put("hideFlg", "hideRow");
        List<Map<String, Object>> mapList = new ArrayList();
        mapList.add(mapRec);
        mst211Form.setSearchResult(mapList);
        mst211Form.setSearchResultSelectable(new ReportListDataModel(mst211Form.getSearchResult()));
        mst211Form.setSelectedSearchResult(null);
        
        // 検索初期はデータを編集不可にする
        mst211Form.setBtnEditeDisabled(true);
        
        // レコード件数を取得する
        long recordCount = getSharyoListCount();
        
        // 検索部のステータスを変更する
        pageCommon.setSerchConDisabled(mst211Form);
        // 参照モードにする
        pageCommon.setEditFlg(false);
        // サブ検索条件フラグ設定
        fileBean.setSubFlg(subSearchConHad());
        
        // 検索条件を保存する
        pageCommon.savePageInfo(CONST_MST211_FORM, mst211Form);
        return recordCount;
    }

    /**
     * 検索処理
     *
     */
    public void search() {
        
        // 適用終了日(チェックボックス)
        int tekiyoShuryobiCheck = 0;
        String tekiyoShuryobiCheckbox = null;
        
        // 選択リストを初期化する
        mst211Form.setSelectedSearchResult(new ArrayList<>());
        mst211Form.setSearchResultSelectable(null);

        // 検査結果を取得する
        List<Map<String, Object>> recordList = getSharyoList();

        // 適用日フォマートリスト
        List<Map<String, Object>> tekiyobiList = new ArrayList<>();
        
        if (recordList == null) {
            return;
        }
        
        for (Map<String, Object> record : recordList) {
            
            // 適用終了日(チェックボックス)
            tekiyoShuryobiCheck = Integer.valueOf(record.get("listTekiyoShuryobiCheckBox").toString());

            // 検索結果は１の場合
            if (tekiyoShuryobiCheck == 1) {
                tekiyoShuryobiCheckbox = "true";
            // 検索結果は１以外の場合    
            } else {
                tekiyoShuryobiCheckbox = "false";
            }
            SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");

            // 変換後の結果をレコードに設定する
            record.replace("listTekiyoShuryobiCheckBox", tekiyoShuryobiCheckbox);
            try {
                // 変換後の結果をレコードに設定する
                record.replace("listTekiyoKaishibi", format.parse(record.get("listTekiyoKaishibi").toString()));
                if(record.get("listTekiyoShuryobiTextBox") != null){
                   record.replace("listTekiyoShuryobiTextBox", format.parse(record.get("listTekiyoShuryobiTextBox").toString())); 
                } 
                if(record.get("listSaishuShiyobi") != null){
                   record.replace("listSaishuShiyobi", format.parse(record.get("listSaishuShiyobi").toString())); 
                } 
            } catch (ParseException ex) {
                LOGGER.error(ex.getMessage(), ex);
            }

            // 適用日リストにデータを追加する
            tekiyobiList.add(record);
        }

        fileBean.setDataList(tekiyobiList);
        
        // HIDDEN営業所を設定する
        if (mst211Form.getConEigyoushoCd() != null) {
            mst211Form.setConEigyoushoCdHid(mst211Form.getConEigyoushoCd().getValue());
        }
        
        // 取得した値を画面項目にセットする
        pageCommon.setDatalist(DATA_TABLE_ID, tekiyobiList);
        mst211Form.setSearchResultSelectable(new ReportListDataModel(tekiyobiList));

        // 検索部のステータスを変更する
        pageCommon.setSerchConDisabled(mst211Form);
        
        // 削除済のみのチェック状態より、明細データを編集可／不可にする
        if (mst211Form.getConSakujonomiKensaku()== null || mst211Form.getConSakujonomiKensaku().isEmpty()) {
            // 有効データを編集可にする
            mst211Form.setBtnEditeDisabled(false);
        } else {
            // 削除済みデータを編集不可にする
            mst211Form.setBtnEditeDisabled(true);
        }
        
        // 検索条件を保存する
        pageCommon.savePageInfo(CONST_MST211_FORM, mst211Form);
        
        // 参照モードにする
        pageCommon.setEditFlg(false);
    }
    
    /**
     * 検索条件変更処理
     *
     */
    public void searchChange() {
        
        // 検索部のステータス変更
        pageCommon.setSerchConEnabled(mst211Form);
    }

    /**
     * 検索条件クリア
     * 
     */
    public void clear() {

        // 世代検索デフォルト値を設定する
        mst211Form.setConSedaiKensakuJoken(DEFAULT_VALUE);

        // 検索部の条件クリア
        mst211Form.setConEigyoushoCd(null);
        mst211Form.setConTekiyoBi(null);
        mst211Form.setConSharyoNo(null);
        mst211Form.setConSharyoMeisho(null);
        mst211Form.setConMishiyoKikanNen(null);
        mst211Form.setConMishiyoKikanGetu(null);
        mst211Form.setConTekiyoMei(null);
        mst211Form.setConSakujonomiKensaku(null);

        // 検索部のステータス変更
        pageCommon.setSerchConEnabled(mst211Form);
        pageCommon.setBtnSearchChangeVisible(false);
        pageCommon.setBtnSearchVisible(Boolean.TRUE);
    }
    
    /**
     * 仕入先コード取得Autocomplete一覧を取得する処理
     * 
     * @param key 検索キー
     * @return Autocompleteリスト
     */    
    public List<String> getAutoCompForShiireSakiCdList(String key) {
        return autoCompleteBean.getStringListByKey(MsCnst.COM_GET_VW_SHIIRESAKI, key);
    }

    /**
     * 更新処理
     *
     */
    public void update() {
        
        // エラーメッセージを格納する変数の初期化を行う
        msgList = new ArrayList<>();
        
        // 明細行が選択されない場合
        if (mst211Form.getSelectedSearchResult() == null || mst211Form.getSelectedSearchResult().isEmpty()) {
            MessageModuleBean message = messageProperty.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
            msgList.add(message);
            
            messageProperty.messageList(msgList);
            return;
        }
                
        // 登録リスト
        List<Map<String, Object>> torokuList = new ArrayList<>();

        // 更新リスト
        List<Map<String, Object>> updateList = new ArrayList<>();
        
        // 単項目チェック処理
        if (!checkJsfParamas(mst211Form.getSelectedSearchResult())) {
            return;
        }
        
        // 登録更新情報設定処理
        for (Map<String, Object> map : mst211Form.getSelectedSearchResult()) {
            
            // 終了チェック(MSTE0058)
            if (map.get("listTekiyoShuryobiCheckBox").equals(true) && !map.containsKey("listTekiyoShuryobiTextBox")) {
                messageProperty.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MSTE0058);
                return;
            }  else if (map.get("listTekiyoShuryobiCheckBox").equals(true) && map.get("listTekiyoShuryobiTextBox") == null) {
                messageProperty.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MSTE0058);
                return;
            }
            // 終了チェック(MSTE0059)
            if (map.get("listTekiyoShuryobiCheckBox").equals(false) && map.get("listTekiyoShuryobiTextBox") != null ) {
                messageProperty.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MSTE0059);
                return;
            } 
            
            map.put("conEigyoushoCd", mst211Form.getConEigyoushoCd().getValue());
            // 仕向地名マスタ一覧.カレント行 = 登録対象の場合
            if (map.get(StndConsIF.CONST_ADD_ROW_KEY) != null) {
                // 登録リストにデータを追加する
                torokuList.add(map);
            } else {               
                // 更新リストにデータを追加する
                updateList.add(map);
            }
        }
        
        // 登録・更新処理を行う
        int status = insertSharyoList();

        // エラーの場合、処理終了
        if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            return;
        }

        // 登録の後に再度検索する
        this.search();

        // 一覧の配色定義をなくす
        pageCommon.resetIchiranColColor(mst211Form.getSelectedSearchResult());

        // メッセージを設定する
        messageProperty.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, "更新");

        // ログ出力を行う
        LOGGER.info("更新 " + mst211Form.getSelectedSearchResult().size() + " 件");
    }
    
    /**
     * 業務削除処理ファンクション領域
     *
     */
    public void delRowsFunc() {

        pageCommon.getSelectedDatasList().put(DATA_TABLE_ID, mst211Form.getSelectedSearchResult());
        pageCommon.delRowsWithMsg(DATA_TABLE_ID, MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0013);
    }

    /**
     * 削除処理
     *
     * @param recordList 削除条件
     * @return 正常／異常
     */
    public Boolean delRows(List<Map<String, Object>> recordList) {

        // エラーメッセージを格納する変数の初期化
        msgList = new ArrayList<>();

        // 明細行が選択されない場合
        if (recordList.isEmpty()) {
            MessageModuleBean message = messageProperty.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0013);
            msgList.add(message);
            messageProperty.messageList(msgList);

            return false;
        }

        // 営業所コード追加
        List<Map<String, Object>> recordWithEigyoshoCd = new ArrayList<>();
        for (Map<String, Object> record : recordList) {
            record.put("conEigyoushoCd", mst211Form.getConEigyoushoCd().getValue());
            recordWithEigyoshoCd.add(record);
        }

        // 存在チェック
        ServiceInterfaceBean serviceInterfaceBean = pageCommon.accsessDBWithList(
                recordWithEigyoshoCd, FUNC_DELETE_CHECK);

        // エラーの場合、処理を終了
        if (serviceInterfaceBean.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {

            MessageModuleBean message = messageProperty.createMessageModule(
                    serviceInterfaceBean.getMessages().get(0)[0],
                    serviceInterfaceBean.getMessages().get(0)[1],
                    serviceInterfaceBean.getMessages().get(0)[2],
                    serviceInterfaceBean.getTableName());
            msgList.add(message);
            messageProperty.messageList(msgList);
            return false;
        }

        // 削除処理を行う
        int status = deleteSharyoList(recordList);

        // 削除処理エラーあり場合
        if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            return false;
        }
        
         // 画面レコード削除
        mst211Form.getSearchResult().removeAll(recordList);
        
        this.search();

        // メッセージを設定する
        messageProperty.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, SAKUJO);
              

        // ログ出力
        LOGGER.info("削除 " + recordList.size() + " 件");
        return true;
    }

    /**
     * 更新履歴を表示処理
     *
     */
    public void rirekiIchiran() {

        // 履歴テーブル検索キーを設定する
        rirekiSearchKey = new HashMap();
        
        // 選択されたレコードを取得する
        Map<String, Object> selectRec = mst211Form.getSelectedSearchResult().get(0);

        // 営業所コード追加
        selectRec.put("conEigyoushoCd", mst211Form.getConEigyoushoCd().getValue());

        // 検索条件
        rirekiSearchKey.put("conEigyoushoCd", selectRec.get("conEigyoushoCd"));
        rirekiSearchKey.put("listSharyoNo", selectRec.get("listSharyoNo"));
        rirekiSearchKey.put("listTekiyoKaishibi", selectRec.get("listTekiyoKaishibi"));

        // 履歴タイトル設定
        rirekiSyosai.setListColName(new ArrayList<>(Arrays.asList(
                "バージョン情報", "車両No", "車両名称", 
                "ナンバープレート","適用開始日", "適用終了日", 
                "適用終了日","車種", "車両一覧表示", "仕入先コード", "仕入先名称", "適用名", "最終使用日")));

        // 履歴beanの項目物理名設定
        List<String> colValue = new ArrayList<>(Arrays.asList(
                "sharyoDataVersion", "rirekiSharyoNo", "rirekiSharyoMeisho", 
                "rirekiNumberPlate","rirekiTekiyoKaishibi", "rirekiTekiyoShuryobiCheckBox", 
                "rirekiTekiyoShuryobiTextBox","rirekiShashu", "rirekiSharyoIchiranHyoji",
                "rirekiShiiresakiCd","rirekiShiiresakiMei", "rirekiTekiyoMei", "rirekiSaishuShiyobi"));
        
        // 履歴beanの項目位置設定
        List<String> colAlign = new ArrayList<>(Arrays.asList(
                "left", "left", "left", 
                "left","center", "left", 
                "left","left", "left",
                "left","left", "left", "left"));
        
        List<RirekiListCol> listCol = new ArrayList<>();
        for (int i = 0; i < colValue.size(); i++) {
           RirekiListCol col = new RirekiListCol();
           col.setColValue(colValue.get(i));
           col.setColAlign(colAlign.get(i));
           listCol.add(col);
        }
        rirekiSyosai.setListCol(listCol);
        
        // 履歴テーブル検索する
        rirekiSyosai.searchList("2", "MST211_SEARCH_RIREKI", rirekiSearchKey);
    }
    
    /**
     * CSVファイルのタイトルを設定する処理
     *
     * @return 画面タイトル
     */
    public List<CSVDto> getHeader() {

        // CSVファイルのタイトルを設定する
        List<CSVDto> header = new ArrayList<>();
        // 車両No
        header.add(new CSVDto("車両No", "listSharyoNo"));
        // 車両名称
        header.add(new CSVDto("車両名称", "listSharyoMeisho"));
        // 車両名称
        header.add(new CSVDto("ナンバープレート", "listNumberPlate"));
        // 適用開始日
        header.add(new CSVDto("適用開始日", "listTekiyoKaishibi"));
        // 適用終了日(チェックボックス)
        header.add(new CSVDto("適用終了日(チェックボックス)", "listTekiyoShuryobiCheckBox"));
        // 適用終了日(テキストボックス)
        header.add(new CSVDto("適用終了日(テキストボックス)", "listTekiyoShuryobiTextBox"));
        // 車種
        header.add(new CSVDto("車種", "listShashu"));
        // 車両一覧表示
        header.add(new CSVDto("車両一覧表示", "listSharyoIchiranHyoji"));
        // 仕入先コード
        header.add(new CSVDto("仕入先コード", "listShiiresakiCd"));
        // 仕入先名称
        header.add(new CSVDto("仕入先名称", "listShiiresakiMei"));
        // 適用名
        header.add(new CSVDto("適用名", "listTekiyoMei"));
        // 最終使用日
        header.add(new CSVDto("最終使用日", "listSaishuShiyobi"));

        // 取得値を返却する
        return header;
    }
    
    

    /**
     * ダウンロードダイアログ
     *
     * @param comment 理由コメント
     * @return 正常／異常
     * @throws Exception
     */
    public boolean beforeDown(String comment) throws Exception {
        
        // ダウンロード理由を記録する
        System.out.println(comment);
        
        return true;
    }
    
    /**
     * アップロード
     * 
     * @return 遷移先画面のURL
     */
    public String upload() {
        
        // flash初期化
        Flash flash = pageCommon.getPageParam();
        
        // flashにアップロード機能コードを設定する
        flash.put("uploadFunctionCd", TITLE);
        
        // アップロードを画面へ遷移
        url = forward(Cnst.SCREEN.UPLOAD_SCREEN.name(), null, Cnst.SCREEN.UPLOAD_SCREEN.name(), false);
        return url;
    }
    
    /**
     * 一覧の単項目チェック処理
     * 
     * @param params 画面一覧パラメータ
     * @return チェックの結果
     */
    public boolean checkJsfParamas(List<Map<String, Object>> params) {

        List<ListCheckBean> checks = new ArrayList<>();
        checks.add(new ListCheckBean("listSharyoNo", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "車両No"));
        checks.add(new ListCheckBean("listSharyoNo", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_IS_HALF, "車両No"));
        checks.add(new ListCheckBean("listSharyoNo", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "車両No", "5"));
        checks.add(new ListCheckBean("listSharyoMeisho",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "車両名称"));
        checks.add(new ListCheckBean("listSharyoMeisho",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "車両名称", "40"));
        checks.add(new ListCheckBean("listNumberPlate", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "ナンバープレート", "40"));
        checks.add(new ListCheckBean("listTekiyoKaishibi",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "適用開始日"));
        checks.add(new ListCheckBean("listShashu",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "車種"));
        checks.add(new ListCheckBean("listSharyoIchiranHyoji", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "車両一覧表示"));
        checks.add(new ListCheckBean("listTekiyoMei",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "適用名"));
        List<MessageModuleBean> checkMsgList = listCheckBean.check(params, checks, true);

        if (checkMsgList != null && !checkMsgList.isEmpty()) {
            return false;
        }
        return true;
    }
    
    /**
     * 車種取得
     * 
     * @return 
     */
    private Map<String, Object> getShashu() {
        Map<String, Object> params = new HashMap<>();

        try {
            // DBをアクセスする
            ServiceInterfaceBean serviceInterfaceBean = pageCommon.getDBInfo(params, FUNC_GET_SHASHU);
            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> shashuMap = new HashMap<>();
            shashuMap.put("", "");
            shashuMap.putAll(mapper.readValue(serviceInterfaceBean.getJson(), Map.class));
            mst211Form.setShashu(shashuMap);

        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
        // 検索結果を返却する
        return mst211Form.getShashu();
    }
    
    /**
     * ダウンロード用検索結果取得
     * 
     * @return 検索結果
     */
    private List<Map<String, Object>> getSearchResult() {
        return mst211Form.getSearchResult();
    }

    /**
     * 検索件数取得
     *
     * @return 検索件数
     */
    private long getSharyoListCount() {

        // パラメータ
        Map<String, Object> params = new HashMap<>();
        
        // 全営業所検索
        if (pageCommon.getMasterInfo().getAllEigyoshoSearch() != null) {
            params.put("allEigyoshoSearch", pageCommon.getMasterInfo().getAllEigyoshoSearch());
        }

        // 営業所
        params.put("conEigyoushoCd", mst211Form.getConEigyoushoCd().getValue());

        // 世代検索条件
        params.put("conSedaiKensakuJoken", mst211Form.getConSedaiKensakuJoken());

        // 適用日
        params.put("conTekiyoBi", mst211Form.getConTekiyoBi());

        // 車両No
        params.put("conSharyoNo", mst211Form.getConSharyoNo());

        // 車両名称
        params.put("conSharyoMeisho", mst211Form.getConSharyoMeisho());

        // 未使用期間(年)
        params.put("conMishiyoKikanNen", mst211Form.getConMishiyoKikanNen());

        // 未使用期間(月)
        params.put("conMishiyoKikanGetu", mst211Form.getConMishiyoKikanGetu());

        // 適用名
        params.put("conTekiyoMei", mst211Form.getConTekiyoMei());

        // 削除のみ検索
        if (mst211Form.getConSakujonomiKensaku() == null || mst211Form.getConSakujonomiKensaku().isEmpty() ){
            // 未選択の場合
            params.put("conSakujonomiKensaku", "0");
        } else {
            // 選択の場合
            params.put("conSakujonomiKensaku", "1");
        }
        
         // ログインユーザー所属営業所
        params.put("loginUserShozokuEigyosho", authConfBean.getLoginUserShozokuEigyosho());

        // DBアクセス
        ServiceInterfaceBean serviceInterfaceBean = pageCommon.getDBInfo(params, FUNC_SEARCH_COUNT);

        // 検索件数を返却する
        return Long.valueOf(serviceInterfaceBean.getJson());
    }

    /**
     * 車両マスタ情報検索
     *
     * @return 車両マスタ情報
     */
    private List<Map<String, Object>> getSharyoList() {

        // 検索条件
        Map<String, Object> params = new HashMap<>();
        
        // 全営業所検索
        if (pageCommon.getMasterInfo().getAllEigyoshoSearch() != null) {
            params.put("allEigyoshoSearch", pageCommon.getMasterInfo().getAllEigyoshoSearch());
        }

        // 営業所
        if (mst211Form.getConEigyoushoCd() != null) {
            params.put("conEigyoushoCd", mst211Form.getConEigyoushoCd().getValue());
        }
        
        // 世代検索条件
        params.put("conSedaiKensakuJoken", mst211Form.getConSedaiKensakuJoken());

        // 適用日
        params.put("conTekiyoBi", mst211Form.getConTekiyoBi());

        // 車両No
        params.put("conSharyoNo", mst211Form.getConSharyoNo());

        // 車両名称
        params.put("conSharyoMeisho", mst211Form.getConSharyoMeisho());

        // 未使用期間(年)
        params.put("conMishiyoKikanNen", mst211Form.getConMishiyoKikanNen());

        // 未使用期間(月)
        params.put("conMishiyoKikanGetu", mst211Form.getConMishiyoKikanGetu());

        // 適用名
        params.put("conTekiyoMei", mst211Form.getConTekiyoMei());

        // 削除のみ処理
        if (mst211Form.getConSakujonomiKensaku() == null || mst211Form.getConSakujonomiKensaku().isEmpty()) {
            params.put("conSakujonomiKensaku", "0");
        } else {
            params.put("conSakujonomiKensaku", "1");
        }
         // ログインユーザー所属営業所
        params.put("loginUserShozokuEigyosho", authConfBean.getLoginUserShozokuEigyosho());
   
        try {
            // DBをアクセスする
            ServiceInterfaceBean serviceInterfaceBean = pageCommon.getDBInfo(params, FUNC_SEARCH);
            ObjectMapper mapper = new ObjectMapper();
            mst211Form.setSearchResult(mapper.readValue(serviceInterfaceBean.getJson(), List.class));

        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
        
        // 適用開始日
        long tekiyoKaishibi = 0;
        // 適用終了日(テキストボックス)
        long tekiyoShuryobi = 0;
        // 最終使用日
        long saishuShiyobi = 0;
        // 適用開始日
        Date tekiyoKaishibiDate = null;
        // 適用終了日(テキストボックス)
        Date tekiyoShuryobiDate = null;
        // 最終使用日
        Date saishuShiyobiDate = null;
        
        List<Map<String, Object>> formatSearchResult = new ArrayList<>();
        for (Map<String, Object> record : mst211Form.getSearchResult()) {

            // 適用開始日
            tekiyoKaishibi = Long.valueOf(record.get("listTekiyoKaishibi").toString());

            // 適用終了日(テキストボックス)
            if (record.get("listTekiyoShuryobiTextBox") == null) {
                tekiyoShuryobi = 0;
            } else {
                tekiyoShuryobi = Long.valueOf(record.get("listTekiyoShuryobiTextBox").toString());
            }
            
            // 最終使用日
            if (record.get("listSaishuShiyobi") != null) {
                saishuShiyobi = Long.valueOf(record.get("listSaishuShiyobi").toString());
            }
            
            // 適用開始日
            tekiyoKaishibiDate = new Date(tekiyoKaishibi);

            // 適用終了日(チェックボックス)
            tekiyoShuryobiDate = new Date(tekiyoShuryobi);
            
            // 最終使用日
            saishuShiyobiDate = new Date(saishuShiyobi);           

            // 変換後の結果をレコードに設定する
            record.replace("listTekiyoKaishibi", DateFormat.getDateInstance().format(tekiyoKaishibiDate));
            record.replace("listTekiyoShuryobiTextBox", DateFormat.getDateInstance().format(tekiyoShuryobiDate));
            record.replace("listSaishuShiyobi", DateFormat.getDateInstance().format(saishuShiyobiDate));

            // 適用日リストにデータを追加する
            formatSearchResult.add(record);
        }
        
        
        // 検索結果を返却する
        return formatSearchResult;
    }

    /**
     * DB車両マスタ情報削除
     * 
     * @param recordList レコードリスト
     * @return ステータスコード
     */
    private int deleteSharyoList(List<Map<String, Object>> recordList) {
        
        // エラーメッセージを格納する変数を初期化する
        msgList = new ArrayList<>();

        // 営業所コード追加
        List<Map<String, Object>> datasWithEigyoshoCd = new ArrayList<>();
        for (Map<String, Object> record : recordList) {
            record.put("conEigyoushoCd", mst211Form.getConEigyoushoCd().getValue());
            datasWithEigyoshoCd.add(record);
        }

        // 削除処理を行う
        ServiceInterfaceBean serviceInterfaceBean = pageCommon.accsessDBWithList(datasWithEigyoshoCd, FUNC_DELETE);
        return serviceInterfaceBean.getStatusCode();
    }

    /**
     * DB車両マスタ情報登録
     * 
     * @return ステータスコード
     */
    private int insertSharyoList() {
        // エラーメッセージを格納する変数を初期化する
        msgList = new ArrayList<>();
        
        // 重複と存在チェック
        ServiceInterfaceBean serviceInterfaceBean = pageCommon.accsessDBWithList(mst211Form.getSelectedSearchResult(),
                FUNC_INSERT_UPDATE_CHECK);
      
        // エラーの場合、処理を終了する
        if (serviceInterfaceBean.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            messageProperty.message(serviceInterfaceBean.getMessages().get(0)[0],
                    serviceInterfaceBean.getMessages().get(0)[1],
                    serviceInterfaceBean.getMessages().get(0)[2],
                    serviceInterfaceBean.getTableName());
            return serviceInterfaceBean.getStatusCode();
        }

        // DBをアクセスする
        serviceInterfaceBean = pageCommon.accsessDBWithList(mst211Form.getSelectedSearchResult(), FUNC_INSERT_UPDATE);
        return serviceInterfaceBean.getStatusCode();
    }
    
     /**
     * サブ検索条件入力判断
     * 
     * @return true:入力あり/false:入力しない
     */
    private boolean subSearchConHad() {
        
        // 車両No
        if (!StringUtils.isEmpty(mst211Form.getConSharyoNo())) {
            return true;
        }
        // 車両名称
        if (!StringUtils.isEmpty(mst211Form.getConSharyoMeisho())) {
            return true;
        }
        // 未使用期間（年）
        if (!StringUtils.isEmpty(mst211Form.getConMishiyoKikanNen())) {
            return true;
        }       
        // 未使用期間（月）
        if (!StringUtils.isEmpty(mst211Form.getConMishiyoKikanGetu())) {
            return true;
        }        
        // 適用名
        if (!StringUtils.isEmpty(mst211Form.getConTekiyoMei())) {
            return true;
        }

        return false;
    }
}
