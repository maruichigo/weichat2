package jp.co.kintetsuls.file;


import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.utils.StrUtils;

import org.apache.commons.io.IOUtils;
import org.apache.commons.io.output.ByteArrayOutputStream;
import org.apache.commons.lang3.text.StrTokenizer;

/**
 * CSVファイル、TSVファイルの操作を行う。
 * <p>
 * CSVファイル、TSVファイルからデータの読み込みを行う。 また、ヘッダ内容、データ内容からファイル内容（バイト配列）を生成する。<br>
 * </p>
 */
public final class CSVTokenizer {

    /**
     * デフォルトトークナイザ
     */
    private static final StrTokenizer TOKENIZER_PROTOTYPE;

    static {
        TOKENIZER_PROTOTYPE = StrTokenizer.getCSVInstance();
    }
    /**
     * デフォルトトークナイザ
     */
    private static long startMillis;
    /**
     * デリミタ。
     */
    private char delimiter = ',';

    /**
     * 囲み文字。
     */
    private char quote = '\"';

    /**
     * ヘッダ内容。
     */
    // private StrTokenizer header = null;
    /**
     * データがnullの場合は囲み文字を追加しない。
     */
    public boolean MinNull = false;
    /**
     * データ内容。
     */
    private LinkedList<StrTokenizer> records = null;

    /**
     * 読込用：ヘッダ
     */
    // private String[] readHeader = null;
    /**
     * 読込用：データ
     */
    private List<String[]> readRecords = null;

    /**
     * CSVTokenizer を構築する。
     */
    private CSVTokenizer() {
    }

    /**
     * CSVTokenizer を構築する。
     * <p>
     * デリミタ: 「,（カンマ）」 囲み文字: 「"（二重引用符）」
     * </p>
     *
     * @return CSVTokenizer インスタンス
     */
    public static CSVTokenizer getInstance() {
        return new CSVTokenizer();
    }

    /**
     * CSVTokenizer を構築する。
     * <p>
     * 指定されたデリミタ、囲み文字で CSVTokenizer を構築する。
     * </p>
     *
     * @param _delimiter デリミタ
     * @param _quote 囲み文字
     * @return CSVTokenizer インスタンス
     */
    public static CSVTokenizer getInstance(char _delimiter, char _quote) {
        // 処理開始時間
        startMillis = System.currentTimeMillis();
        // 処理開始ログ
//        LogUtils.start(CSVTokenizer.class, "doCsv");

        CSVTokenizer token = new CSVTokenizer();
        token.setDelimiter(_delimiter);
        token.setQuote(_quote);
        return token;
    }

    /**
     * CSV文字列へ変換しカンマ区切りで連結する。
     * <p>
     * 取得した文字をCSV文字列へ変換し、デリミタで連結する。変換内容は以下の通り。
     * <ul>
     * <li>ヘッダ値内に囲み文字が存在する場合は、囲み文字2つに変換する</li>
     * <li>ヘッダ値を囲み文字で囲む</li>
     * </ul>
     * </p>
     *
     * @param _values 変換対象の文字
     * @return カンマ区切りに連結されたCSV文字列
     */
    private String toCsvString(String... _values) {
        LinkedList<String> result = new LinkedList<String>();

        for (String value : _values) {
            if (quote == Character.MIN_VALUE) {
                result.add(StrUtils.defaultString(value));
            } else {
                if (MinNull && value == null) {
                    result.add(StrUtils.defaultString(value));
                } else {
                    result.add(new StringBuilder()
                            .append(quote)
                            .append(
                                    StrUtils.replace(StrUtils.defaultString(value), String.valueOf(quote),
                                            StrUtils.repeat(String.valueOf(quote), 2))).append(quote).toString());
                }
            }
        }

        return StrUtils.join(result.toArray(), delimiter);
    }


    /**
     * CSVファイル内容をバイト配列で取得する。
     * <p>
     * 改行コードは、'\r\n' 改行コードを使用してファイル内容を生成する。
     * </p>
     *
     * @return バイト配列
     * @throws SystemException 例外
     */
    public byte[] toByteArray() throws SystemException {
        return toByteArray("Windows-31J");
    }

    /**
     * CSVファイル内容をバイト配列で取得する。
     * <p>
     * 改行コードは、'\r\n' 改行コードを使用してファイル内容を生成する。
     * </p>
     *
     * @param _encoding エンコード
     * @return バイト配列
     * @throws SystemException 例外
     */
    public byte[] toByteArray(String _encoding) throws SystemException {
        return toByteArray("\r\n", _encoding);
    }

    /**
     * CSVファイル内容をバイト配列で取得する。
     *
     * @param _lineSeparator 改行コード
     * @param _encoding エンコード
     * @return バイト配列
     * @throws SystemException I/O例外が発生する場合、
     */
    public byte[] toByteArray(String _lineSeparator, String _encoding) throws SystemException {

        ByteArrayOutputStream out = new ByteArrayOutputStream();

        try {
            LinkedList<String> lines = new LinkedList<String>();

            if (records != null) {
                for (StrTokenizer token : records) {
                    lines.add(token.getContent());
                }
            }
            // encoding
            if (_encoding != null) {
                try {
                    IOUtils.writeLines(lines, _lineSeparator, out, _encoding);
                } catch (IOException e) {
                    throw new SystemException("CSVファイル内容のバイト配列取得でストリームがクローズできません。", e);
                }
            } else {
                try {
                    IOUtils.writeLines(lines, _lineSeparator, out);
                } catch (IOException e) {
                    throw new SystemException("CSVファイル内容のバイト配列取得でストリームがクローズできません。", e);
                }
            }

        } finally {
            try {
                out.close();
            } catch (IOException e) {
                // log
                e.printStackTrace();
            }
        }
        return out.toByteArray();
    }

    /**
     * レコード数を取得する。
     *
     * @return レコード数
     */
    public int size() {
        // if (records == null) {
        // return 0;
        // }
        // return records.size();
        return readRecords == null ? 0 : readRecords.size();
    }

    /**
     * 指定されたインデックスのレコードを 配列形式で取得する。
     *
     * @param _index 取得対象のインデックス
     * @return 配列形式のレコード
     */
    public String[] get(int _index) {
        if (size() <= _index) {
            throw new ArrayIndexOutOfBoundsException("指定されたインデックスのレコードは存在しないため、レコードの取得ができません。index=" + _index);
        }
        // return records.get(_index).getTokenArray();
        return readRecords.get(_index).length < 1 ? new String[]{""} : readRecords.get(_index);
    }


    /**
     * レコードを追加する。
     *
     * @param _values レコード
     */
    public void add(String... _values) {

        if (_values != null && _values.length > 0) {
            StrTokenizer token = (StrTokenizer) TOKENIZER_PROTOTYPE.clone();
            token.reset(toCsvString(_values));

            if (records == null) {
                records = new LinkedList<StrTokenizer>();
            }
            records.add(token);
        }
    }

    /**
     * レコードを先頭追加する。
     *
     * @param _values レコード
     */
    public void addFirst(String... _values) {

        if (_values != null && _values.length > 0) {
            StrTokenizer token = (StrTokenizer) TOKENIZER_PROTOTYPE.clone();
            token.reset(toCsvString(_values));

            if (records == null) {
                records = new LinkedList<StrTokenizer>();
            }
            records.addFirst(token);
        }
    }

    /**
     * ヘッダを追加する。（取り込み用）
     *
     * @param _values レコード
     */
    public void addImportHeader(List<String> _values) {
        if (_values != null && _values.size() > 0) {
            StrTokenizer token = (StrTokenizer) TOKENIZER_PROTOTYPE.clone();
            token.reset(StndConsIF.COMMENT_LINE_HANTEI_MOJI_CSV_TORIKOMI_FILE
                    + toCsvString(_values.toArray(new String[_values.size()])));

            if (records == null) {
                records = new LinkedList<StrTokenizer>();
            }
            records.add(token);
        }
    }

    /**
     * ヘッダを先頭追加する。（取り込み用）
     *
     * @param _values レコード
     */
    public void addImportHeaderFirst(List<String> _values) {
        if (_values != null && _values.size() > 0) {
            StrTokenizer token = (StrTokenizer) TOKENIZER_PROTOTYPE.clone();
            token.reset(StndConsIF.COMMENT_LINE_HANTEI_MOJI_CSV_TORIKOMI_FILE
                    + toCsvString(_values.toArray(new String[_values.size()])));

            if (records == null) {
                records = new LinkedList<StrTokenizer>();
            }
            records.addFirst(token);
        }
    }

    /**
     * ヘッダを追加する。（取り込み以外の場合用）
     *
     * @param _values レコード
     */
    public void addHeader(List<String> _values) {
        if (_values != null && _values.size() > 0) {
            StrTokenizer token = (StrTokenizer) TOKENIZER_PROTOTYPE.clone();
            token.reset(toCsvString(_values.toArray(new String[_values.size()])));

            if (records == null) {
                records = new LinkedList<StrTokenizer>();
            }
            records.add(token);
        }
    }

    public void addHeader(String[] _values) {
        if (_values != null && _values.length > 0) {
            StrTokenizer token = (StrTokenizer) TOKENIZER_PROTOTYPE.clone();
            token.reset(toCsvString(_values));

            if (records == null) {
                records = new LinkedList<StrTokenizer>();
            }
            records.add(token);
        }
    }

    /**
     * ヘッダを先頭追加する。（取り込み以外の場合用）
     *
     * @param _values レコード
     */
    public void addHeaderFirst(List<String> _values) {
        if (_values != null && _values.size() > 0) {
            StrTokenizer token = (StrTokenizer) TOKENIZER_PROTOTYPE.clone();
            token.reset(toCsvString(_values.toArray(new String[_values.size()])));

            if (records == null) {
                records = new LinkedList<StrTokenizer>();
            }
            records.addFirst(token);
        }
    }

    /**
     * レコードを追加する。
     *
     * @param _values レコード
     */
    public void add(List<String> _values) {
        if (_values != null && _values.size() > 0) {
            for (int i = 0; i < _values.size(); i++) {
                if (_values.get(i) != null) {
                    _values.set(i, _values.get(i).replaceAll("\\r\\n|\\r|\\n", ""));
                }
            }
            add(_values.toArray(new String[_values.size()]));
        }
    }

    /**
     * デリミタを設定する。
     *
     * @param _delimiter デリミタ
     */
    private void setDelimiter(char _delimiter) {
        this.delimiter = _delimiter;
        TOKENIZER_PROTOTYPE.setDelimiterChar(_delimiter);
    }

    /**
     * 囲み文字を設定する。
     *
     * @param _quote 囲み文字
     */
    private void setQuote(char _quote) {
        this.quote = _quote;
        TOKENIZER_PROTOTYPE.setQuoteChar(_quote);
    }

    /**
     * データ内容。を取得する。
     *
     * @return データ内容。
     */
    public LinkedList<StrTokenizer> getRecords() {
        return records;
    }

    /**
     * データ内容。を設定する。
     *
     * @param records データ内容。
     */
    public void setRecords(LinkedList<StrTokenizer> records) {
        this.records = records;
    }

}
