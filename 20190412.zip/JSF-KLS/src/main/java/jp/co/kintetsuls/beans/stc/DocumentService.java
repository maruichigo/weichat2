/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.stc;

import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import org.primefaces.model.CheckboxTreeNode;
import org.primefaces.model.TreeNode;

/**
 *
 * @author liuchengjiang
 */
@ManagedBean(name = "stc011servei")
@ViewScoped
public class DocumentService {
    public TreeNode createCheckboxDocuments() {
        TreeNode root = new CheckboxTreeNode(new Document("12345 営業所名称１２３４５", "", "","",""), null);
         
        TreeNode egyosho1 = new CheckboxTreeNode(new Document("A00001 仕入先名称A００００１（SA00001）", "", "","",""), root);

        TreeNode egyosho2 = new CheckboxTreeNode(new Document("A00002 仕入先名称A００００２（SA00002）", "", "","",""), root);
        TreeNode egyosho3 = new CheckboxTreeNode(new Document("   A00003 仕入先名称Ａ００００３（SA00003）", "", "","",""), root);

        TreeNode cahrtNode = new CheckboxTreeNode(new Document("チャータ", "2,000,000", "0","160,000","2,160,000"), egyosho1);
        TreeNode node2_1 = new CheckboxTreeNode(new Document("発送中継委託", "3,000,000", "0","240,000","3,240,000"), egyosho2);
        TreeNode node2_2 = new CheckboxTreeNode(new Document("臨時集配車両", "4,000,000", "0","320,000","4,320,000"), egyosho2);
        TreeNode node3_1 = new CheckboxTreeNode(new Document("ＭＡＷＢ", "1,000,000", "0","8,000","1,080,000"), egyosho3);
         
        return root;
    }
}
