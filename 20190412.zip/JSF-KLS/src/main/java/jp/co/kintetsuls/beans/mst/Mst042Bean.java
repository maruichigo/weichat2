/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.beans.common.SystemMasterBean;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.forms.mst.Mst042Form;
import jp.co.kintetsuls.forms.mst.Mst511Form;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.kintetsuls.utils.DateUtils;
import jp.co.kintetsuls.utils.StrUtils;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 営業所マスタ詳細画面
 *
 * @author 雷珍 (MBP)
 * @version 2019/03/05 新規作成
 */
@ManagedBean(name = "mst042")
@ViewScoped
@Data
public class Mst042Bean extends AbstractBean {

    /**
     * タイトル
     */
    private final String TITLE  = "営業所マスタ詳細";

    /**
     * 画面URL
     */
    private String url;
    
    /**
     * システムマスタ情報
     */
    @ManagedProperty(value = "#{systemMasterBean}")
    private SystemMasterBean systemMasterBean;
    
    /**
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authorityConfBean;

    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;

    /**
     * 画面フォーム
     */
    @ManagedProperty(value = "#{mst042Form}")
    private Mst042Form mst042Form;

    /**
     * 画面共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * 検索シーケンス処理共通
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelp;

    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(
            new Object() {}.getClass().getEnclosingClass().getName());
    
    /**
     * 定数：スクリーンコード：MST501
     */
    private static final String SC_CD_MST042 = "MST042_SCREEN";
    
    /**
     * 定数：画面項目保持key
     */
    private static final String CONST_MST042_FORM = "mst042Form";
    
    /**
     * 定数：検索Button取得キー
     */
    private static final String CONST_MST042_SEARCH = "search_mst042";
    
    /**
     * 定数：MasterInfo取得キー
     */
    private static final String CONST_MST042_MASTER = "mst042";
    
    /**
     * 定数：承認者情報
     */
    private static final String DATA_SHNTABLE_ID = "tableShn_mst042";
    
    /**
     * 定数：営業所グループ情報
     */
    private static final String DATA_EGRPTABLE_ID = "tableEgrp_mst042";
    
    /**
     * 定数：卸単価情報
     */
    private static final String DATA_ORSTABLE_ID = "tableOrs_mst042";
    
    /**
     * 定数：営業所情報検索ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH = "mst042-search";
    
    /**
     * 定数：適用開始日ENTERキー押下ファンクションコード
     */
    private static final String FUNC_CODE_GET_TEKIYO_KAISHIBI = "mst042-get_tekiyo_kaishibi";
       
    /**
     * 定数：更新処理ファンクションコード
     */
    private static final String FUNC_CODE_INSERT_UPDATE = "mst042-insert-update";
    
    /**
     * 定数：登録/更新のチェックファンクションコード
     */
    private static final String FUNC_CODE_INSERT_UPDATE_CHECK = "mst042-insert-update-check";
    
    /**
     * 定数：削除処理ファンクションコード
     */
    private static final String FUNC_CODE_DELETE = "mst042-delete";
    
    /**
     * 定数：削除のチェックファンクションコード
     */
    private static final String FUNC_CODE_DELETE_CHECK = "mst042-delete-check";
    
    /**
     *  定数：複写
     */
    private static final String CONST_FUKUSA = "1";
    
    /**
     *  定数：ワーク.起動モード区分 = 0(新規)
     */
    private static final String MODE_SHINKI_FLG = "0";

    /**
     *  定数：ワーク.起動モード区分 = 1(更新)
     */
    private static final String MODE_UPDATE_FLG = "1";

    /**
     *  定数：ワーク.起動モード区分 = 2(参照)
     */
    private static final String MODE_SANSYOU_FLG = "2";
    
    /**
     * 定数：営業所グループ情報
     */
    private static final String EGRP = "Egrp";

    /**
     * 定数：卸単価情報
     */
    private static final String ORS = "Ors";
    
    /**
     *  ワーク.サブ組織名リスト
     */
    List<String> subSoshikiMeiList = new ArrayList<>();
    
     /**
     *  ワーク.サブ組織リスト
     */
    List<String> subSoshikiList = new ArrayList<>();
     
    /**
     *  ワーク.サブ組織名
     */
    String subSoshikiMeiWk = "";
    
    /**
     *  ワーク.サブ組織
     */
    String subSoshikiWk = "";
     
    /**
     *  ワーク.営業所グループ情報_削除一覧リスト 
     */
    List<Map<String, Object>> eigyoshoOroshiTankaDeleteIchiranList = new ArrayList();
    
    /**
     *  ワーク.営業所グループ情報_削除一覧リスト 
     */
    List<Map<String, Object>> eigyoshoGroupDeleteIchiranList = new ArrayList();
    
    /**
     *  ワーク.初期表示フラグ
     */
    Boolean initFlg = true;
    
    /**
     *  ワーク.営業所グループシーケンス(最大)
     */
    int maxSeqNo = 0;
    
    /**
     * コンストラクタ
     */
    public Mst042Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId　メニューID
     * @param prevScreen 遷移元画面ID
     * @param backFlag 戻るフラグ
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            // パンくず追加
            breadBean.push(TITLE, Cnst.SCREEN.MST042_SCREEN.name(), this);
            
            // メモリ保持内容取得処理
            // システムマスタ取得
            pageCommonBean.getMasterInfo(CONST_MST042_MASTER);
            
            // 戻ってきた場合
            Mst042Form preForm = (Mst042Form) pageCommonBean.getPageInfo(CONST_MST042_FORM);
            if (backFlag && preForm != null) {
                PageCommonBean.simpleCopy(preForm, mst042Form);
                // 再検索を実施する
                pageCommonBean.searchAgain(CONST_MST042_SEARCH);
            // 進んできた場合
            } else {
                // 画面遷移パラメータ取得
                Flash flash = pageCommonBean.getPageParam();
                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_MST042_FORM) != null) {
                    PageCommonBean.simpleCopy(flash.get(CONST_MST042_FORM), mst042Form);
                    
                    // 遷移パラメータ.営業所コードが空白以外の場合
                    if (mst042Form.getConEigyoshoCd() != null) {
                        // 再検索を実施する
                        pageCommonBean.searchAgain(CONST_MST042_SEARCH);
                    }
                }
            }
            
            // ワーク.番号体系(一見顧客)
            mst042Form.setHIchigenKokyakuToroku(systemMasterBean.getSysValByCdAndKanriGroup(
                    MsCnst.SYS_CDGROUP_CUSCMN, MsCnst.SYS_CD_ICHIGEN_KOKYAKU_SENTOU));
            // ワーク.番号体系(社内便顧客)
            mst042Form.setHShanaiBinToroku(systemMasterBean.getSysValByCdAndKanriGroup(
                    MsCnst.SYS_CDGROUP_CUSCMN, MsCnst.SYS_CD_SYANAIBIN_SENTOU));
            
            // 選択肢表示項目取得処理
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(送り状発行営業所リスト)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO);
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(空港リスト)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_MS_KUKO);
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(仕向地リスト)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_SHIMUKE_CHI_CD);
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(銀行口座リスト)	
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_MS_GINKO_KOZA);
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(伝票種別リスト)	
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_MS_DEMPYO_SHUBETSU);
            // JISコード
            autoCompleteViewBean.initAddr("JIS_CD", null);
            
            // 画面用変数初期化        
            // 営業所マスタ基本情報
            mst042Form.setResultEigyoshoInfo(new HashMap<>());
            
            // 承認者情報リスト 
            List<Map<String, Object>> shoninshaRes = new ArrayList<>();
            mst042Form.setListShoninshaDtlSelectable(new ReportListDataModel(shoninshaRes));
            // 営業所グループ情報リスト
            List<Map<String, Object>> egrpRes = new ArrayList<>();
            mst042Form.setListEgrpDtlSelectable(new ReportListDataModel(egrpRes));
            pageCommonBean.setDatalist(DATA_EGRPTABLE_ID, egrpRes);
            // 卸単価情報リスト
            List<Map<String, Object>> orsRes = new ArrayList<>();
            mst042Form.setListOrsDtlSelectable(new ReportListDataModel(orsRes));
            pageCommonBean.setDatalist(DATA_ORSTABLE_ID, orsRes);
            
            // ワーク.営業所グループ情報_削除一覧リスト 
            eigyoshoOroshiTankaDeleteIchiranList = new ArrayList();
            // ワーク.営業所グループ情報_削除一覧リスト 
            eigyoshoGroupDeleteIchiranList = new ArrayList();
            // 履歴テーブル検索キーを初期化する
            mst042Form.setRirekiSearchKey(null);
            
            // 行更新また削除するために共通処理へ登録する
            // 営業所グループ情報
            pageCommonBean.regDelFucntion(DATA_EGRPTABLE_ID, 
                    (dataList -> (this.delRows(DATA_EGRPTABLE_ID, dataList))));
            // 卸単価情報
            pageCommonBean.regDelFucntion(DATA_ORSTABLE_ID, 
                    (dataList -> (this.delRows(DATA_ORSTABLE_ID, dataList))));
            
            // component初期化とユーザ権限により制御を設定する
            pageCommonBean.setAuthControll(mst042Form, SC_CD_MST042, true);
            
            // 営業所マスタ画面から「新規登録」ボタンから遷移する場合
            // 遷移パラメータ.営業所コードが空白の場合
            if ((mst042Form.getConEigyoshoCd() == null
                    || CheckUtils.isEqual(MODE_SHINKI_FLG, mst042Form.getModeKbn()))
                    && !CheckUtils.isEqual(CONST_FUKUSA, mst042Form.getFukushaFlg())) {
                // ワーク.起動モード区分= 0(新規)
                mst042Form.setModeKbn(MODE_SHINKI_FLG);
                // 登録/更新対象区分 = 0(新規)
                mst042Form.setEditKbn(MODE_SHINKI_FLG);
                // 適用終了日を表示しません
                mst042Form.setTekiyoShuryobiHyojiFlg(false);
                // 画面項目が編集できる
                mst042Form.setEditDisabled(false);
                
                // ボタン名称
                mst042Form.setBtnName("登録");
                //「登録」ボタンが活性
                mst042Form.setKoshinBtnDisabled(false);
                //「編集」ボタンが非活性
                mst042Form.setEditBtnDisabled(true);
                //「新規登録」ボタンが非活性
                mst042Form.setTorokuBtnDisabled(true);
                //「複写登録」ボタンが非活性
                mst042Form.setFukushaTorokuBtnDisabled(true);
                //「削除」ボタンが非活性
                mst042Form.setSakujoBtnDisabled(true);
                //「論理削除」ボタンが非活性
                mst042Form.setRonriSakujoBtnDisabled(true);
                //「履歴確認」ボタンが非活性
                mst042Form.setRirekiKakuninBtnDisabled(true);
                // 初期化
                initFlg = false;
            } else {
                // 営業所マスタ画面から「複写登録」ボタンから遷移する場合
                // 遷移パラメータ.複写フラグ = 1(複写)の場合
                if (CheckUtils.isEqual(CONST_FUKUSA, mst042Form.getFukushaFlg())) {
                    // ワーク.起動モード区分= 0(新規)
                    mst042Form.setModeKbn(MODE_SHINKI_FLG);
                    // 登録/更新対象区分 = 0(新規)
                    mst042Form.setEditKbn(MODE_SHINKI_FLG);
                    // 適用終了日を表示しません
                    mst042Form.setTekiyoShuryobiHyojiFlg(false);
                    // 画面項目が編集できる
                    mst042Form.setEditDisabled(false);
                    
                    // ボタン名称
                    mst042Form.setBtnName("登録");
                    //「登録」ボタンが活性
                    mst042Form.setKoshinBtnDisabled(false);
                    //「編集」ボタンが非活性
                    mst042Form.setEditBtnDisabled(true);
                    //「新規登録」ボタンが非活性
                    mst042Form.setTorokuBtnDisabled(true);
                    //「複写登録」ボタンが非活性
                    mst042Form.setFukushaTorokuBtnDisabled(true);
                    //「削除」ボタンが非活性
                    mst042Form.setSakujoBtnDisabled(true);
                    //「論理削除」ボタンが非活性
                    mst042Form.setRonriSakujoBtnDisabled(true);
                    //「履歴確認」ボタンが非活性
                    mst042Form.setRirekiKakuninBtnDisabled(true);
                    
                } else {
                    // ワーク.起動モード区分= 2(参照)
                    mst042Form.setModeKbn(MODE_SANSYOU_FLG);
                    // 登録/更新対象区分 = 1(更新)
                    mst042Form.setEditKbn(MODE_UPDATE_FLG);
                    // 画面モードが「参照」とする
                    // 適用終了日を表示しません
                    mst042Form.setTekiyoShuryobiHyojiFlg(false);
                    // 適用終了日編集不可
                    mst042Form.setTekiyoShuryobiDisabled(true);
                    // 画面項目が編集できません
                    mst042Form.setEditDisabled(true);
                    
                    // ボタン名称
                    mst042Form.setBtnName("更新");
                    //「更新」ボタンが非活性
                    mst042Form.setKoshinBtnDisabled(true);
                    //「編集」ボタンが活性
                    mst042Form.setEditBtnDisabled(false);
                    //「新規登録」ボタンが活性
                    mst042Form.setTorokuBtnDisabled(false);
                    //「複写登録」ボタンが活性
                    mst042Form.setFukushaTorokuBtnDisabled(false);
                    //「削除」ボタンが活性
                    mst042Form.setSakujoBtnDisabled(false);
                    //「論理削除」ボタンが活性
                    mst042Form.setRonriSakujoBtnDisabled(false);
                    //「履歴確認」ボタンが活性
                    mst042Form.setRirekiKakuninBtnDisabled(false);
                }
                // 初期化
                initFlg = true;
            }
            // 営業所コードが編集可
            mst042Form.setConEigyoshoCdDisabled(false);
            // 適用開始日が編集可
            mst042Form.setConTekiyoKaishibiDisabled(false);
            // 削除/論理削除区分
            mst042Form.setDeleteKbn("");
            
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * 検索処理
     * 
     * @throws SystemException システム異常
     */
    public void searchEigyoshoInfo() throws SystemException {
        
        // 入力必須チェック
        // 営業所コード
        if (mst042Form.getConEigyoshoCd() == null) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0003, "営業所コード");
            return;
        }
        // 適用開始日
        if (CheckUtils.isEmpty(mst042Form.getConTekiyoKaishibi())) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0003, "適用開始日");
            return;
        }
        
        // 画面用変数初期化        
        // 営業所マスタ基本情報
        // 画面用項目設定（営業所基本情報）
        setGamenEigyoshoKihonJoho(null);
        mst042Form.setResultEigyoshoInfo(new HashMap<>());
        // 承認者情報リスト  
        mst042Form.setListShoninshaDtlSelectedResult(new ArrayList<>());
        mst042Form.setListShoninshaDtlSelectable(new ReportListDataModel(
            mst042Form.getListShoninshaDtlSelectedResult()));
        // 営業所グループ情報リスト
        mst042Form.setListEgrpDtlSelectedResult(new ArrayList<>());
        mst042Form.setListEgrpDtlSelectable(new ReportListDataModel(
            mst042Form.getListEgrpDtlSelectedResult()));
        pageCommonBean.setDatalist(DATA_EGRPTABLE_ID, mst042Form.getListEgrpDtlSelectedResult());

        // 卸単価情報リスト
        mst042Form.setListOrsDtlSelectedResult(new ArrayList<>());
        mst042Form.setListOrsDtlSelectable(new ReportListDataModel(
            mst042Form.getListOrsDtlSelectedResult()));
        pageCommonBean.setDatalist(DATA_ORSTABLE_ID, mst042Form.getListOrsDtlSelectedResult());
        
        // ワーク.営業所グループ情報_削除一覧リスト 
        eigyoshoOroshiTankaDeleteIchiranList = new ArrayList();
        // ワーク.営業所グループ情報_削除一覧リスト 
        eigyoshoGroupDeleteIchiranList = new ArrayList();
        // ワーク.サブ組織名リスト
        subSoshikiMeiList = new ArrayList<>();
        // ワーク.サブ組織リスト
        subSoshikiList = new ArrayList<>();
            
        // 営業所マスタ情報を検索し、取得した値を画面項目にセット
        Map<String, Object> searchResult = getEigyoshoDetail();
        if (searchResult == null || CheckUtils.isEmpty(StrUtils.defaultString(searchResult.get("resultEigyosho")))) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_WARN, MessageCnst.COMW0001);
            // 営業所基本情報
            setMapEigyoshoKihonJoho();
            
        } else {
            Map<String, Object> resultJusho = (Map<String, Object>) searchResult.get("resultEigyosho");
            // 画面用項目設定（営業所基本情報）
            setGamenEigyoshoKihonJoho(resultJusho);
            // 営業所基本情報
            mst042Form.setResultEigyoshoInfo(resultJusho);
            
            // リストワーク変数
            List<Map<String, Object>> res;

            // 承認者情報リスト           
            res = (List<Map<String, Object>>) searchResult.get("resultShoninsha");
            if (res != null) {
                mst042Form.setListShoninshaDtlSelectedResult(res);
                mst042Form.setListShoninshaDtlSelectable(new ReportListDataModel(res));
                pageCommonBean.setDatalist(DATA_SHNTABLE_ID, res);
            }

            // 営業所グループ情報リスト     
            res = (List<Map<String, Object>>) searchResult.get("resultGroup");
            if (res != null) {
                // AUTOCOMPLETE項目再設定
                AutocompleteSet(res, EGRP);
                mst042Form.setListEgrpDtlSelectedResult(res);
                mst042Form.setListEgrpDtlSelectable(new ReportListDataModel(res));
                pageCommonBean.setDatalist(DATA_EGRPTABLE_ID, res);
            }

            // 卸単価情報リスト     
            res = (List<Map<String, Object>>) searchResult.get("resultOroshiTanka");
            if (res != null) {
                // AUTOCOMPLETE項目再設定
                AutocompleteSet(res, ORS);
                mst042Form.setListOrsDtlSelectedResult(res);
                mst042Form.setListOrsDtlSelectable(new ReportListDataModel(res));
                pageCommonBean.setDatalist(DATA_ORSTABLE_ID, res);
            }
            // 検索処理(実行後) 顧客登録済チェック
            // ワーク.起動モード区分 = 1(更新) または 2(参照) かつ
            if (CheckUtils.isEqual(mst042Form.getModeKbn(), "1")
                    || CheckUtils.isEqual(mst042Form.getModeKbn(), "2")) {
                // 出力表示用のパラメータ
                StringBuilder paramMei = new StringBuilder();
                // ワーク.一見顧客登録フラグ = 0の場合
                if (CheckUtils.isEqual(mst042Form.getDtlHIchigenKokyakuTorokuFlg(), "0")) {
                    // 出力表示用のパラメータ = "一見顧客"
                    paramMei.append("一見顧客");

                }
                // ワーク.社内便登録フラグ = 0の場合  
                if (CheckUtils.isEqual(mst042Form.getDtlHShanaiBinTorokuFlg(), "0")) {
                    // 出力表示用のパラメータ = "社内便顧客"
                    if (CheckUtils.isEmpty(StrUtils.defaultString(paramMei))) {
                        paramMei.append("社内便顧客");
                    } else {
                        paramMei.append("、社内便顧客");
                    }
                }
                // ワーク.着払代引登録フラグ = 0) の場合
                if (CheckUtils.isEqual(mst042Form.getDtlHChakubaraiDaibikiTorokuFlg(), "0")) {
                    // 出力表示用のパラメータ = "着払代引"
                    if (CheckUtils.isEmpty(StrUtils.defaultString(paramMei))) {
                        paramMei.append("着払代引");
                    } else {
                        paramMei.append("、着払代引");
                    }
                }
                // (ワーク.一見顧客登録フラグ = 0 
                // または ワーク.社内便登録フラグ = 0 
                // または ワーク.着払代引登録フラグ = 0) の場合
                if (CheckUtils.isEqual(mst042Form.getDtlHIchigenKokyakuTorokuFlg(), "0")
                        || CheckUtils.isEqual(mst042Form.getDtlHShanaiBinTorokuFlg(), "0")
                        || CheckUtils.isEqual(mst042Form.getDtlHChakubaraiDaibikiTorokuFlg(), "0")) {
                    // 顧客マスタにて{0}が登録されていません。
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_WARN, MessageCnst.MSTE0108, paramMei);
                    
                }
            }
            // 最大の営業所グループシーケンス
            if (!CheckUtils.isEmpty(StrUtils.defaultString(resultJusho.get("maxSeqNo")))) {
                maxSeqNo = Integer.parseInt(StrUtils.defaultString(resultJusho.get("maxSeqNo")));
            } else {
                maxSeqNo = 0;
            }
        }
       
        if (!initFlg) {
            // 検索を行った場合は参照モードとなります。
            // ワーク.起動モード区分= 2(参照)
            mst042Form.setModeKbn(MODE_SANSYOU_FLG);
            // 登録/更新対象区分 = 1(更新)
            mst042Form.setEditKbn(MODE_UPDATE_FLG);
            // 画面モードが「参照」とする
           
            // 適用終了日編集不可
            mst042Form.setTekiyoShuryobiDisabled(true);
            // 画面項目が編集できません
            mst042Form.setEditDisabled(true);
            // ボタン名称
            mst042Form.setBtnName("更新");
            //「更新」ボタンが非活性
            mst042Form.setKoshinBtnDisabled(true);
            //「編集」ボタンが活性
            mst042Form.setEditBtnDisabled(false);
            //「新規登録」ボタンが活性
            mst042Form.setTorokuBtnDisabled(false);
            //「複写登録」ボタンが活性
            mst042Form.setFukushaTorokuBtnDisabled(false);
            //「削除」ボタンが活性
            mst042Form.setSakujoBtnDisabled(false);
            //「論理削除」ボタンが活性
            mst042Form.setRonriSakujoBtnDisabled(false);
            //「履歴確認」ボタンが活性
            mst042Form.setRirekiKakuninBtnDisabled(false);

            // 営業所コードが編集可
            mst042Form.setConEigyoshoCdDisabled(false);
            // 適用開始日が編集可
            mst042Form.setConTekiyoKaishibiDisabled(false);
            // 削除/論理削除区分
            mst042Form.setDeleteKbn("");
            
        } else {
            // 初期フラグを再設定する
            initFlg = false;
        }
        
        // 適用終了日が設定されている場合
        if (!CheckUtils.isEmpty(mst042Form.getTekiyoShuryobi())) {
            // 適用終了日を表示する
            mst042Form.setTekiyoShuryobiHyojiFlg(true);
        } else {
            // 適用終了日を表示しません
            mst042Form.setTekiyoShuryobiHyojiFlg(false);
        }
                
        // 検索条件保存
        pageCommonBean.savePageInfo(CONST_MST042_FORM, mst042Form);
        
        // 履歴テーブル検索キー
        Map<String, Object> rirekiSearchKey = new HashMap();
        // 営業所コード
        rirekiSearchKey.put("eigyoshoCd", mst042Form.getConEigyoshoCd().getValue());
        
        mst042Form.setRirekiSearchKey(rirekiSearchKey);
     }
   
    /**
     * 編集ボタン押下処理
     * 
     */
    public void btnEdit() {
        
        // ボタン名称
        mst042Form.setBtnName("更新");
        // ワーク.起動モード区分= 1(更新)
        mst042Form.setModeKbn(MODE_UPDATE_FLG);
        // 登録/更新対象区分 = 1(更新)
        mst042Form.setEditKbn(MODE_UPDATE_FLG);
        // 営業所コードが編集不可
        mst042Form.setConEigyoshoCdDisabled(true);
        // 適用開始日が編集可
        mst042Form.setConTekiyoKaishibiDisabled(false);
        // 画面項目が編集できる
        mst042Form.setEditDisabled(false);
        //「登録」ボタンが活性
        mst042Form.setKoshinBtnDisabled(false);
        //「編集」ボタンが非活性
        mst042Form.setEditBtnDisabled(true);
        //「新規登録」ボタンが非活性
        mst042Form.setTorokuBtnDisabled(true);
        //「複写登録」ボタンが非活性
        mst042Form.setFukushaTorokuBtnDisabled(true);
        //「削除」ボタンが非活性
        mst042Form.setSakujoBtnDisabled(true);
        //「論理削除」ボタンが非活性
        mst042Form.setRonriSakujoBtnDisabled(true);
    }
    
    /**
     * 新規登録ボタン押下処理
     * 
     * @throws SystemException 異常
     */
    public void btnToroku() throws SystemException {
        
        // ボタン名称
        mst042Form.setBtnName("登録");
        // ワーク.起動モード区分= 0(新規)
        mst042Form.setModeKbn(MODE_SHINKI_FLG);
        // 登録/更新対象区分 = 0(新規)
        mst042Form.setEditKbn(MODE_SHINKI_FLG);
        // 営業所コードが編集可
        mst042Form.setConEigyoshoCdDisabled(false);
        // 適用開始日が編集可
        mst042Form.setConTekiyoKaishibiDisabled(false);
        // 画面項目が編集できる
        mst042Form.setEditDisabled(false);
        //「登録」ボタンが活性
        mst042Form.setKoshinBtnDisabled(false);
        //「編集」ボタンが非活性
        mst042Form.setEditBtnDisabled(true);
        //「新規登録」ボタンが非活性
        mst042Form.setTorokuBtnDisabled(true);
        //「複写登録」ボタンが非活性
        mst042Form.setFukushaTorokuBtnDisabled(true);
        //「削除」ボタンが非活性
        mst042Form.setSakujoBtnDisabled(true);
        //「論理削除」ボタンが非活性
        mst042Form.setRonriSakujoBtnDisabled(true);
        
        // 画面用変数初期化
        // 検索条件クリア
        // 営業所コード	
        mst042Form.setConEigyoshoCd(autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO, ""));
        // 適用開始日
        mst042Form.setConTekiyoKaishibi("");
        // 適用名
        mst042Form.setConTekiyoMei("");
        // 適用終了
        mst042Form.setConTekiyoShuryo(new String[]{"0"});
        // 適用終日
        mst042Form.setTekiyoShuryobi("");
            
        // 営業所マスタ基本情報
        // 画面用項目設定（営業所基本情報）
        setGamenEigyoshoKihonJoho(null);
        mst042Form.setResultEigyoshoInfo(new HashMap<>());
        // 承認者情報リスト  
        mst042Form.setListShoninshaDtlSelectedResult(new ArrayList<>());
        mst042Form.setListShoninshaDtlSelectable(new ReportListDataModel(
            mst042Form.getListShoninshaDtlSelectedResult()));
        // 営業所グループ情報リスト
        mst042Form.setListEgrpDtlSelectedResult(new ArrayList<>());
        mst042Form.setListEgrpDtlSelectable(new ReportListDataModel(
            mst042Form.getListEgrpDtlSelectedResult()));
        pageCommonBean.setDatalist(DATA_EGRPTABLE_ID, mst042Form.getListEgrpDtlSelectedResult());

        // 卸単価情報リスト
        mst042Form.setListOrsDtlSelectedResult(new ArrayList<>());
        mst042Form.setListOrsDtlSelectable(new ReportListDataModel(
            mst042Form.getListOrsDtlSelectedResult()));
        pageCommonBean.setDatalist(DATA_ORSTABLE_ID, mst042Form.getListOrsDtlSelectedResult());
    }
    
    /**
     * 複写登録ボタン押下処理
     * 
     */
    public void btnFukushaToroku() {
        
        // ボタン名称
        mst042Form.setBtnName("登録");
        // ワーク.起動モード区分= 0(新規)
        mst042Form.setModeKbn(MODE_SHINKI_FLG);
        // 登録/更新対象区分 = 0(新規)
        mst042Form.setEditKbn(MODE_SHINKI_FLG);
        // 営業所コードが編集可
        mst042Form.setConEigyoshoCdDisabled(false);
        // 適用開始日が編集可
        mst042Form.setConTekiyoKaishibiDisabled(false);
        // 画面項目が編集できる
        mst042Form.setEditDisabled(false);
        //「登録」ボタンが活性
        mst042Form.setKoshinBtnDisabled(false);
        //「編集」ボタンが非活性
        mst042Form.setEditBtnDisabled(true);
        //「新規登録」ボタンが非活性
        mst042Form.setTorokuBtnDisabled(true);
        //「複写登録」ボタンが非活性
        mst042Form.setFukushaTorokuBtnDisabled(true);
        //「削除」ボタンが非活性
        mst042Form.setSakujoBtnDisabled(true);
        //「論理削除」ボタンが非活性
        mst042Form.setRonriSakujoBtnDisabled(true);
    }
    
    /**
     * 削除ボタン押下処理
     *
     */
    public void btnSakujo() {
        
        // ボタン名称
        mst042Form.setBtnName("更新");
        // ワーク.起動モード区分= 1(更新)
        mst042Form.setModeKbn(MODE_UPDATE_FLG);
        // 登録/更新対象区分 = 1(更新)
        mst042Form.setEditKbn(MODE_UPDATE_FLG);
        // 営業所コードが編集不可
        mst042Form.setConEigyoshoCdDisabled(true);
        // 適用開始日が編集不可
        mst042Form.setConTekiyoKaishibiDisabled(true);
        // 適用終了日を表示する
        mst042Form.setTekiyoShuryobiHyojiFlg(true);
        // 適用終了日編集不可
        mst042Form.setTekiyoShuryobiDisabled(false);
        // 更新ボタンが編集可とする
        mst042Form.setKoshinBtnDisabled(false);
        //「編集」ボタンが非活性
        mst042Form.setEditBtnDisabled(true);
        //「新規登録」ボタンが非活性
        mst042Form.setTorokuBtnDisabled(true);
        //「複写登録」ボタンが非活性
        mst042Form.setFukushaTorokuBtnDisabled(true);
        //「削除」ボタンが非活性
        mst042Form.setSakujoBtnDisabled(true);
        //「論理削除」ボタンが非活性
        mst042Form.setRonriSakujoBtnDisabled(true);
        // 削除フラグ
        mst042Form.setDeleteKbn("Sakujo");
    }
    
     /**
     * 論理削除ボタン押下処理
     *
     */
    public void btnRonriSakujo() {
        
        // ボタン名称
        mst042Form.setBtnName("更新");
        // ワーク.起動モード区分= 1(更新)
        mst042Form.setModeKbn(MODE_UPDATE_FLG);
        // 登録/更新対象区分 = 1(更新)
        mst042Form.setEditKbn(MODE_UPDATE_FLG);
        // 営業所コードが編集不可
        mst042Form.setConEigyoshoCdDisabled(true);
        // 適用開始日が編集不可
        mst042Form.setConTekiyoKaishibiDisabled(true);
        // 更新ボタンが編集可とする
        mst042Form.setKoshinBtnDisabled(false);
        //「編集」ボタンが非活性
        mst042Form.setEditBtnDisabled(true);
        //「新規登録」ボタンが非活性
        mst042Form.setTorokuBtnDisabled(true);
        //「複写登録」ボタンが非活性
        mst042Form.setFukushaTorokuBtnDisabled(true);
        //「削除」ボタンが非活性
        mst042Form.setSakujoBtnDisabled(true);
        //「論理削除」ボタンが非活性
        mst042Form.setRonriSakujoBtnDisabled(true);
        // 削除フラグ
        mst042Form.setDeleteKbn("RonriSakujo");
    }
 
    /**
     * 更新ボタン押下処理
     * 
     * @throws SystemException システム異常
     * @throws UnsupportedEncodingException 異常
     */
    public void btnKoshin() throws SystemException, UnsupportedEncodingException {
        
        // 削除/論理削除の場合
        if (!CheckUtils.isEmpty(mst042Form.getDeleteKbn())) {
            // 削除前チェック処理
            // 重複、存在チェック
            Map<String, Object> params = new HashMap<>();
            // 営業所コード
            params.put("conEigyoshoCd", mst042Form.getConEigyoshoCd().getValue());
            // 適用開始日
            params.put("conTekiyoKaishibi", 
                    DateUtils.parseFmtYMD(mst042Form.getConTekiyoKaishibi()));
            // 適用名
            params.put("conTekiyoMei", mst042Form.getConTekiyoMei());
            // DBをアクセス
            ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, FUNC_CODE_DELETE_CHECK);
            // エラーの場合、処理を終了
            if (serviceInterfaceBean != null && serviceInterfaceBean.getStatusCode()
                    == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
                String[] tableNames = serviceInterfaceBean.getTableName().split(",");
                messagePropertyBean.message(serviceInterfaceBean.getMessages().get(0)[0],
                        serviceInterfaceBean.getMessages().get(0)[1],
                        serviceInterfaceBean.getMessages().get(0)[2],
                        tableNames[0]);
            } else {
                // DBへ営業所マスタ/営業所卸単価マスタ/営業所グループマスタを削除する処理
                deleteList();
            }
            
        } else {
            // 登録前チェック処理
            // 入力内容チェック処理
            int checkResult = inputChcek();

            if (checkResult == 1) {
                // エラーしないの場合
                // 旧住所変更可否チェック
                // ワーク.新JISコード != ""(設定あり) かつ ワーク.旧住所フラグ = 1(旧住所) 
                if (!CheckUtils.isEmpty(mst042Form.getDtlHShinJisCd())
                        && CheckUtils.isEqual(mst042Form.getDtlHKyuJushoFlg(), "1")) {
                    // ワーク.使用不可フラグ = 0(使用可能) の場合
                    if (CheckUtils.isEqual(mst042Form.getDtlHShiyoFukaFlg(), "0")) {
                        // 旧住所設定確認の警告ダイアログを表示する。
                        pageCommonBean.executeScript("km.showConfirmDialog('mst042Dialog')");
                        return;
                    } else if (CheckUtils.isEqual(mst042Form.getDtlHShiyoFukaFlg(), "1")) {
                        // ワーク.使用不可フラグ = 1(使用不可) の場合
                        // 旧住所使用不可のエラーメッセージを表示し、処理を終了する。
                        messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                                    MessageCnst.COME0023, "");
                        return;
                    }
                }

                // DBへ営業所マスタ/営業所卸単価マスタ/営業所グループマスタを登録また更新する処理
                insertUpdateEigyoshoInfo();
            }
        }
    }
    
    /**
     * 検索条件「適用開始日」のENTERキー押下後イベント
     * 検索条件.適用開始日に、取得結果.適用開始日を設定する
     * 
     * @throws SystemException 異常
     */
    public void getTekiyoKaishibi() throws SystemException {

        // パラメータ設定
        Map<String, Object> params = new HashMap<>();
        
        if (mst042Form.getConEigyoshoCd() != null && 
                CheckUtils.isEmpty(mst042Form.getConTekiyoKaishibi())) {
            // 検索条件.営業所コードが入力済み 且つは 検索条件.適用開始日が未入力の場合
            // 営業所コード
            params.put("conEigyoshoCd",mst042Form.getConEigyoshoCd().getValue());
            // DBをアクセス
            ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, FUNC_CODE_GET_TEKIYO_KAISHIBI);
            try {
                ObjectMapper mapper = new ObjectMapper();
                Map<String, Object> searchResult = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
                if (searchResult != null && !CheckUtils.isEmpty(StrUtils.defaultString(
                        searchResult.get("tekiyoKaishibi")))) {
                    // 適用開始日
                    mst042Form.setConTekiyoKaishibi(StrUtils.defaultString(searchResult.get("tekiyoKaishibi")));
                }
            } catch (IOException ex) {
                LOGGER.error(ex.getMessage(), ex);
            }
        }
    }
    
    /**
     * DBから情報を削除する
     *
     * @throws  SystemException 異常
     */
    public void deleteList() throws SystemException {
 
        // 営業所マスタ情報の項目取得を行う。
        // 営業所コード	
        mst042Form.getResultEigyoshoInfo().put("conEigyoshoCd",
                mst042Form.getConEigyoshoCd().getValue());
        // 適用開始日	
        mst042Form.getResultEigyoshoInfo().put("conTekiyoKaishibi",
                DateUtils.parseFmtYMD(mst042Form.getConTekiyoKaishibi()));
        // 適用終了日	
        if (!CheckUtils.isEmpty(mst042Form.getTekiyoShuryobi())) {
            mst042Form.getResultEigyoshoInfo().put("conTekiyoShuryobi",
                DateUtils.parse(mst042Form.getTekiyoShuryobi().concat(" 23:59:59"),
                StndConsIF.DF_YYYY_MM_DD_HH_MM_SS));
        }
        // 削除フラグ	
        mst042Form.getResultEigyoshoInfo().put("dtlSakujoFlg",
                mst042Form.getDtlHSakujoFlg());
        // 営業所データバージョン	
        mst042Form.getResultEigyoshoInfo().put("dtlEigyoshoDataVersion",
                mst042Form.getDtlEigyoshoDataVersion());
        // 更新ユーザーID
        mst042Form.getResultEigyoshoInfo().put("kshnDtlUser",
                mst042Form.getKshnDtlUser());
        // 更新カウンタ
        mst042Form.getResultEigyoshoInfo().put("dtlKoshinCounter",
                mst042Form.getDtlKoshinCounter());
        
        // パラメータ
        Map<String, Object> params = new HashMap<>();
        // 営業所マスタ削除情報
        params.put("eigyoshoDeleteInfo", mst042Form.getResultEigyoshoInfo());
        // 卸単価情報_削除一覧リスト
        params.put("eigyoshoOroshiTankaDeleteList", mst042Form.getListOrsDtlSelectedResult());
        // 営業所グループ情報_削除一覧リスト
        params.put("eigyoshoGroupDeleteList", mst042Form.getListEgrpDtlSelectedResult());
        // 画面検索条件部
        // 削除/論理削除対象
        params.put("deleteKbn", mst042Form.getDeleteKbn());
        
        // 削除処理
        // DBをアクセス
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, FUNC_CODE_DELETE);
        // エラーの場合、処理終了
        if (serviceInterfaceBean != null
                && ServiceInterfaceBean.PROCESS_STATUS_ERROR == serviceInterfaceBean.getStatusCode()) {
            String[] tableNames = serviceInterfaceBean.getTableName().split(",");
                messagePropertyBean.message(serviceInterfaceBean.getMessages().get(0)[0],
                        serviceInterfaceBean.getMessages().get(0)[1],
                        serviceInterfaceBean.getMessages().get(0)[2],
                        tableNames[0]);
        } else {
            
            // 顧客登録済メッセージの表示
            // 一見顧客
            String ichigenKokyakuToroku = "";
            // 社内便顧客
            String shanaiBinToroku = "";       
            // 着払代引顧客
            String chakubaraiDaibikiToroku = "";
            // ワーク.一見顧客登録フラグが1(登録済み)の場合  
            if (CheckUtils.isEqual(mst042Form.getDtlHIchigenKokyakuTorokuFlg(), "1")) {
                // 警告（顧客存在アラート(一見顧客)）
                ichigenKokyakuToroku = "一見顧客を削除して下さい。";
            }
            // ワーク.社内便登録フラグが1(登録済み)の場合
            if (CheckUtils.isEqual(mst042Form.getDtlHShanaiBinTorokuFlg(), "1")) {
                // 警告（顧客存在アラート(社内便顧客)）
                shanaiBinToroku = "社内便顧客を削除して下さい。";
            }
            // ワーク.着払代引登録フラグが1(登録済み)の場合
            if (CheckUtils.isEqual(mst042Form.getDtlHChakubaraiDaibikiTorokuFlg(), "1")) {
                // 警告（顧客存在アラート(着払代引顧客)）
                // 着払代引顧客表示のメッセージ
                chakubaraiDaibikiToroku = "顧客コード(999".concat(mst042Form.getConEigyoshoCd().getValue())
                    .concat(")で着払代引顧客を削除して下さい。");

            }
            
            if (!CheckUtils.isEmpty(ichigenKokyakuToroku) 
                        || !CheckUtils.isEmpty(shanaiBinToroku) 
                        || !CheckUtils.isEmpty(chakubaraiDaibikiToroku)) {
                // 顧客登録済メッセージの表示
                pageCommonBean.executeScript("kokyakuTorokuMessage" 
                        + "('" + ichigenKokyakuToroku  + "', "
                        + "'" + shanaiBinToroku + "', '" + chakubaraiDaibikiToroku + "')");
            }
            
            // 処理完了メッセージを表示する
            if (CheckUtils.isEqual(mst042Form.getDeleteKbn(), "RonriSakujo")) {
                // 論理削除処理
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, "論理削除");
            } else {
                // 削除処理
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, "削除");
            }

            // 検索条件クリア
            // 営業所コード	
            mst042Form.setConEigyoshoCd(autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO, ""));
            // 適用開始日
            mst042Form.setConTekiyoKaishibi("");
            // 適用名
            mst042Form.setConTekiyoMei("");
            // 適用終了
            mst042Form.setConTekiyoShuryo(new String[]{"0"});
            // 適用終日
            mst042Form.setTekiyoShuryobi("");

            // 営業所コードが編集可
            mst042Form.setConEigyoshoCdDisabled(false);
            // 適用開始日が編集可
            mst042Form.setConTekiyoKaishibiDisabled(false);
            // 適用終了日を表示しません
            mst042Form.setTekiyoShuryobiHyojiFlg(false);
            // 削除/論理削除区分
            mst042Form.setDeleteKbn("");
            
            //「更新」ボタンが非活性
            mst042Form.setKoshinBtnDisabled(true);
            //「編集」ボタンが活性
            mst042Form.setEditBtnDisabled(false);
            //「新規登録」ボタンが活性
            mst042Form.setTorokuBtnDisabled(false);
            //「複写登録」ボタンが活性
            mst042Form.setFukushaTorokuBtnDisabled(false);
            //「削除」ボタンが活性
            mst042Form.setSakujoBtnDisabled(false);
            //「論理削除」ボタンが活性
            mst042Form.setRonriSakujoBtnDisabled(false);
            //「履歴確認」ボタンが活性
            mst042Form.setRirekiKakuninBtnDisabled(false);

            // 画面用変数初期化        
            // 営業所マスタ基本情報
            // 画面用項目設定（営業所基本情報）
            setGamenEigyoshoKihonJoho(null);
            mst042Form.setResultEigyoshoInfo(new HashMap<>());
            // 承認者情報リスト  
            mst042Form.setListShoninshaDtlSelectedResult(new ArrayList<>());
            mst042Form.setListShoninshaDtlSelectable(new ReportListDataModel(
                mst042Form.getListShoninshaDtlSelectedResult()));
            // 営業所グループ情報リスト
            mst042Form.setListEgrpDtlSelectedResult(new ArrayList<>());
            mst042Form.setListEgrpDtlSelectable(new ReportListDataModel(
                mst042Form.getListEgrpDtlSelectedResult()));
            pageCommonBean.setDatalist(DATA_EGRPTABLE_ID, mst042Form.getListEgrpDtlSelectedResult());

            // 卸単価情報リスト
            mst042Form.setListOrsDtlSelectedResult(new ArrayList<>());
            mst042Form.setListOrsDtlSelectable(new ReportListDataModel(
                mst042Form.getListOrsDtlSelectedResult()));
            pageCommonBean.setDatalist(DATA_ORSTABLE_ID, mst042Form.getListOrsDtlSelectedResult());
        }
        
    }
    
    /**
     * DBへ営業所マスタ/営業所卸単価マスタ/営業所グループマスタを登録また更新する処理
     * 
     * @throws SystemException システム異常
     */
    public void insertUpdateEigyoshoInfo() throws SystemException {
        
        // 登録一覧リストの初期化を行う。
        // 営業所マスタ情報_登録一覧リスト
        List<Map<String, Object>> eigyoshoTorokuIchiranList = new ArrayList();
        // 卸単価情報_登録一覧リスト
        List<Map<String, Object>> eigyoshoOroshiTankaTorokuIchiranList = new ArrayList();
        // 営業所グループ情報_登録一覧リスト
        List<Map<String, Object>> eigyoshoGroupTorokuIchiranList = new ArrayList();
        
        // 更新一覧リストの初期化を行う。
        // 営業所マスタ情報_更新一覧リスト
        List<Map<String, Object>> eigyoshoKoshinIchiranList = new ArrayList();
        // 卸単価情報_更新一覧リスト
        List<Map<String, Object>> eigyoshoOroshiTankaKoshinIchiranList = new ArrayList();
        // 営業所グループ情報_更新一覧リスト
        List<Map<String, Object>> eigyoshoGroupKoshinIchiranList = new ArrayList();

        // 営業所マスタ情報の項目取得を行う。
        setMapEigyoshoKihonJoho();
        // 営業所マスタ情報_登録一覧リスト
        eigyoshoTorokuIchiranList.add(mst042Form.getResultEigyoshoInfo());
        // 営業所マスタ情報_更新一覧リスト
        eigyoshoKoshinIchiranList.add(mst042Form.getResultEigyoshoInfo()); 
        
        // 登録対象の場合
        if (CheckUtils.isEqual(MODE_SHINKI_FLG, mst042Form.getEditKbn())) {
            // 卸単価情報
            for (Map<String, Object> rec : mst042Form.getListOrsDtlSelectable().getDatasource()) {
                // 登録対象
                if (!CheckUtils.isEmpty(StrUtils.defaultString(rec.get("orsDtlListHDempyoShubetsuCd")))) {
                    // 伝票種別が選択済の場合
                    eigyoshoOroshiTankaTorokuIchiranList.add(rec);
                }
            }

            // 営業所グループ情報
            for (Map<String, Object> rec : mst042Form.getListEgrpDtlSelectable().getDatasource()) {
                if (CheckUtils.isEmpty(StrUtils.defaultString(rec.get("hideFlg")))) {
                    // 営業所グループシーケンス
                    maxSeqNo = maxSeqNo + 1;
                    rec.put("egrpDtlListEigyoshoGroupSeq", maxSeqNo);
                    // サブ組織名選択する
                    if (rec.get("egrpDtlListSubSoshikiCdAut") != null 
                            && rec.get("egrpDtlListSubSoshikiCdAut") != "") {
                        // サブ組織名変数を定義
                        AutoCompOptionBean subSoshikiMeiAut = (AutoCompOptionBean)rec.get("egrpDtlListSubSoshikiCdAut");
                        // サブ組織名を移除
                        rec.remove("egrpDtlListSubSoshikiMei");
                        // サブ組織名を再設定する
                        rec.put("egrpDtlListSubSoshikiMei", subSoshikiMeiAut.getLabel());
                    }
                    // 登録対象
                    eigyoshoGroupTorokuIchiranList.add(rec);
                }
            }
        
        } else if (CheckUtils.isEqual(MODE_UPDATE_FLG, mst042Form.getEditKbn())) {
            // 更新対象の場合
            // 卸単価情報
            for (Map<String, Object> rec : mst042Form.getListOrsDtlSelectable().getDatasource()) {
                if (!CheckUtils.isEmpty(StrUtils.defaultString(rec.get("orsDtlListHDempyoShubetsuCd")))) {
                    // 卸単価情報.カレント行 = 登録対象
                    if (rec.get(StndConsIF.CONST_ADD_ROW_KEY) != null) {
                        // 登録対象
                        eigyoshoOroshiTankaTorokuIchiranList.add(rec);
                    } else {
                        // 更新対象
                        eigyoshoOroshiTankaKoshinIchiranList.add(rec);
                    }
                }
            }

            // 営業所グループ情報
            for (Map<String, Object> rec : mst042Form.getListEgrpDtlSelectable().getDatasource()) {
                if (CheckUtils.isEmpty(StrUtils.defaultString(rec.get("hideFlg")))) {
                    // サブ組織名選択する
                    if (rec.get("egrpDtlListSubSoshikiCdAut") != null 
                            && rec.get("egrpDtlListSubSoshikiCdAut") != "") {
                        // サブ組織名変数を定義
                        AutoCompOptionBean subSoshikiMeiAut = (AutoCompOptionBean)rec.get("egrpDtlListSubSoshikiCdAut");
                        // サブ組織名を移除
                        rec.remove("egrpDtlListSubSoshikiMei");
                        // サブ組織名を再設定する
                        rec.put("egrpDtlListSubSoshikiMei", subSoshikiMeiAut.getLabel());
                    }
                    // 営業所グループ情報.カレント行 = 登録対象
                    if (rec.get(StndConsIF.CONST_ADD_ROW_KEY) != null) {
                        // 営業所グループシーケンス
                        maxSeqNo = maxSeqNo + 1;
                        rec.put("egrpDtlListEigyoshoGroupSeq", maxSeqNo);
                        // 登録対象
                        eigyoshoGroupTorokuIchiranList.add(rec);
                    } else {
                        // 更新対象
                        eigyoshoGroupKoshinIchiranList.add(rec);
                    }
                }
            }
        }
        
        // 営業所グループ情報_一覧の件数が0件の場合
        if (eigyoshoGroupTorokuIchiranList.isEmpty() && eigyoshoGroupKoshinIchiranList.isEmpty()) {
            // 営業所グループ情報メイン組織考慮
            // 営業所グループ情報_一覧の件数が0件の場合 
            Map<String, Object> eigyoshoGroupInfo = new HashMap<>();
            // 営業所グループシーケンス
            eigyoshoGroupInfo.put("egrpDtlListEigyoshoGroupSeq", 1);
            // 上位営業所コード
            eigyoshoGroupInfo.put("egrpDtlListJoiEigyoshoCd", null);
            // メイン組織
            eigyoshoGroupInfo.put("egrpDtlListMainSoshiki", "true");
            // サブ組織名
            eigyoshoGroupInfo.put("egrpDtlListSubSoshikiMei", "メイン");
            // 削除フラグ
            eigyoshoGroupInfo.put("egrpDtlListSakujoFlg", 0);

            // 登録対象
            eigyoshoGroupTorokuIchiranList.add(eigyoshoGroupInfo);
        }
        
        // パラメータ
        Map<String, Object> params = new HashMap<>();
        // 営業所マスタ情報_登録一覧リスト
        params.put("eigyoshoAddList", eigyoshoTorokuIchiranList);
        // 営業所マスタ情報_更新一覧リスト
        params.put("eigyoshoUpdList", eigyoshoKoshinIchiranList);
        // 卸単価情報_登録一覧リスト
        params.put("eigyoshoOroshiTankaAddList", eigyoshoOroshiTankaTorokuIchiranList);
        // 卸単価情報_更新一覧リスト
        params.put("eigyoshoOroshiTankaUpdList", eigyoshoOroshiTankaKoshinIchiranList);
        // 卸単価情報_削除一覧リスト
        params.put("eigyoshoOroshiTankaDelList", eigyoshoOroshiTankaDeleteIchiranList);
        // 営業所グループ情報_登録一覧リスト
        params.put("eigyoshoGroupAddList", eigyoshoGroupTorokuIchiranList);
        // 営業所グループ情報_更新一覧リスト
        params.put("eigyoshoGroupUpdList", eigyoshoGroupKoshinIchiranList);
        // 営業所グループ情報_削除一覧リスト
        params.put("eigyoshoGroupDelList", eigyoshoGroupDeleteIchiranList);
        
        // 画面検索条件部
        // 登録/更新対象
        params.put("editKbn", mst042Form.getEditKbn());
        
        // 登録更新処理
        // DBをアクセス
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, FUNC_CODE_INSERT_UPDATE);
        // エラーの場合、処理終了
        if (serviceInterfaceBean != null
                && ServiceInterfaceBean.PROCESS_STATUS_ERROR == serviceInterfaceBean.getStatusCode()) {
            String[] tableNames = serviceInterfaceBean.getTableName().split(",");
            messagePropertyBean.message(serviceInterfaceBean.getMessages().get(0)[0],
                    serviceInterfaceBean.getMessages().get(0)[1],
                    serviceInterfaceBean.getMessages().get(0)[2],
                    tableNames[0]);
        } else {
            
            // 顧客登録済メッセージの表示
            // 一見顧客
            String ichigenKokyakuToroku = "";
            // 社内便顧客
            String shanaiBinToroku = "";       
            // 着払代引顧客
            String chakubaraiDaibikiToroku = "";
            // ワーク.起動モード区分 = 0(新規)の場合
            if (CheckUtils.isEqual(mst042Form.getModeKbn(), "0")) {
                // 警告（顧客存在アラート(一見顧客)）
                ichigenKokyakuToroku = "一見顧客を追加して下さい。";
                // 警告（顧客存在アラート(社内便顧客)）
                shanaiBinToroku = "社内便顧客を追加して下さい。";
                // 警告（顧客存在アラート(着払代引顧客)）
                chakubaraiDaibikiToroku = "顧客コード(999".concat(mst042Form.getConEigyoshoCd().getValue())
                        .concat(")で着払代引顧客を追加して下さい。");
                
            }
            // ワーク.起動モード区分 = 1(更新)の場合
            if (CheckUtils.isEqual(mst042Form.getModeKbn(), "1")) {

                // ワーク.一見顧客登録フラグが0(未登録)の場合  
                if (CheckUtils.isEqual(mst042Form.getDtlHIchigenKokyakuTorokuFlg(), "0")) {
                    // 警告（顧客存在アラート(一見顧客)）
                    ichigenKokyakuToroku = "一見顧客を追加して下さい。";
                }
                // ワーク.社内便登録フラグが0(未登録)の場合
                if (CheckUtils.isEqual(mst042Form.getDtlHShanaiBinTorokuFlg(), "0")) {
                    // 警告（顧客存在アラート(社内便顧客)）
                    shanaiBinToroku = "社内便顧客を追加して下さい。";
                }
                // ワーク.着払代引登録フラグが0(未登録)の場合
                if (CheckUtils.isEqual(mst042Form.getDtlHChakubaraiDaibikiTorokuFlg(), "0")) {
                    // 警告（顧客存在アラート(着払代引顧客)）
                    chakubaraiDaibikiToroku = "顧客コード(999".concat(mst042Form.getConEigyoshoCd().getValue())
                        .concat(")で着払代引顧客を追加して下さい。");
                }
            }
            if (!CheckUtils.isEmpty(ichigenKokyakuToroku) 
                        || !CheckUtils.isEmpty(shanaiBinToroku) 
                        || !CheckUtils.isEmpty(chakubaraiDaibikiToroku)) {
                // 顧客登録済メッセージの表示
                pageCommonBean.executeScript("kokyakuTorokuMessage" 
                        + "('" + ichigenKokyakuToroku + "', '" 
                        + shanaiBinToroku + "', '" + chakubaraiDaibikiToroku + "')");
            }
            // 処理完了メッセージを表示する
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, "更新");

            // 登録の後に再度検索する
            this.searchEigyoshoInfo();
        }
    }
    
     /**
     * 代理承認者設定ボタンクリック処理
     * 
     * @return 遷移先の画面URL
     * @throws IllegalAccessException 異常
     * @throws InvocationTargetException 異常
     * @throws SystemException 異常
     */
    public String btnBtnDairiShoninUserClick()
            throws IllegalAccessException, InvocationTargetException, SystemException {
        
        // 条件保存
        pageCommonBean.savePageInfo(CONST_MST042_FORM, mst042Form);
        
        // 遷移パラメータを設定する
        Mst511Form mst511Form = new Mst511Form();
        // 営業所コード
        if (mst042Form.getConEigyoshoCd() != null) {
            mst511Form.setEigyoshokodo(autoCompleteViewBean.getComMsDatas(
                        MsCnst.COM_GET_VW_EIGYOSHO, 
                        mst042Form.getConEigyoshoCd().getValue()));
        } else {
            mst511Form.setEigyoshokodo(autoCompleteViewBean.getComMsDatas(
                        MsCnst.COM_GET_VW_EIGYOSHO, 
                        ""));
        }
        // 削除のみ検索
        mst511Form.setConSakujoSumiNomi(new String[]{"0"});
        // 所属終了を含む
        mst511Form.setConShozokuShuryoWoFukumu(new String[]{"0"});

        Flash flash = pageCommonBean.getPageParam();
        flash.put("mst511Form", mst511Form);

        // 画面遷移
        url = forward(Cnst.SCREEN.MST511_SCREEN.name(), null, Cnst.SCREEN.MST042_SCREEN.name(), false);
        
        return url;
    }
    
    /**
     * メニュークリック処理
     *
     * @param menuId メニューID
     * @param nextScreenId 遷移先画面ID
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreenId) {
        try {
            // パンくずを削除する
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移を行う
        url = forward(nextScreenId, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック処理
     *
     * @param nextScreenId 遷移先画面ID
     * @param breadIndex パンくずのインデックス
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreenId, int breadIndex) {

        try {
            // パンくずを削除する
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        
        // 画面遷移を行う
        url = forward(nextScreenId, null, null, true);
        return url;
    }

    /**
     * ログアウトクリック処理
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        // 遷移先の画面URL
        return authorityConfBean.logout();
    }

    /**
     * AUTOCOMPLETE項目再設定
     *
     * @param resList 設定対象リスト
     * @param editFlg 設定対象 
     */
    public void AutocompleteSet(List<Map<String, Object>> resList, String editFlg) {
        if (resList.size() > 0) {
            // 営業所コード
            String eigyoshoCd = "";
                    
            for (Map<String, Object> record : resList) {
                if (CheckUtils.isEqual(EGRP, editFlg)) {
                    // 営業所グループ情報の場合
                    // 上位営業所コード
                    eigyoshoCd = StrUtils.defaultString(record.get("egrpDtlListJoiEigyoshoCd"));
                    record.put("egrpDtlListJoiEigyoshoCdAut",
                            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO, eigyoshoCd));
                    
                    // サブ組織コード
                    eigyoshoCd = StrUtils.defaultString(record.get("egrpDtlListSubSoshikiCd"));
                    // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(サブ組織名リスト)
                    // 検索条件
                    Map params = new HashMap<>();
                    // 営業所コード
                    params.put("eigyoshoCd", mst042Form.getConEigyoshoCd().getValue());
                    // 適用開始日
                    params.put("tekiyoKaishibi", mst042Form.getConTekiyoKaishibi());
                    record.put("egrpDtlListSubSoshikiCdAut",autoCompleteViewBean.getMsDatasWithParam(
                            MsCnst.COM_GET_SUB_SOSHIKI_MEI, params, eigyoshoCd));
                    // サブ組織名リストを取得する
                    List<AutoCompOptionBean> subsoshiMeiBeanList = 
                            autoCompleteViewBean.getValueLabelFromDB(MsCnst.COM_GET_SUB_SOSHIKI_MEI, params);
                    // サブ組織名リストが存在の場合
                    if (subsoshiMeiBeanList != null && subsoshiMeiBeanList.size() > 0) {

                        // サブ組織名リストの件数分繰り返す。
                        for (AutoCompOptionBean subsoshiMeiBean : subsoshiMeiBeanList) {
                            // ワーク.サブ組織名リストを設定する
                            subSoshikiMeiList.add(
                                StrUtils.defaultString(subsoshiMeiBean.getValue()).concat(" ").concat(
                                        StrUtils.defaultString(subsoshiMeiBean.getLabel())));
                            subSoshikiList.add(StrUtils.defaultString(subsoshiMeiBean.getLabel()));
                        }
                    }
                    // ワーク.サブ組織名リスト
                    mst042Form.setSubSoshikiMeiList(subSoshikiMeiList);
                    
                } else if (CheckUtils.isEqual(ORS, editFlg)) {
                    // 卸単価情報の場合
                    // 集荷卸計上先営業所コード
                    eigyoshoCd = StrUtils.defaultString(record.get("orsDtlListShukaOroshiKeijoEighoshoCd"));
                    record.put("orsDtlListShukaOroshiKeijoEighoshoCdAut",
                            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO, eigyoshoCd));
                    
                    // 発送母船卸計上先営業所コード
                    eigyoshoCd = StrUtils.defaultString(record.get("orsDtlListHsoBosenKeijoEighoshoCd"));
                    record.put("orsDtlListHsoBosenKeijoEighoshoCdAut",
                            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO, eigyoshoCd));
                    
                    // 到着母船卸計上先営業所コード 
                    eigyoshoCd = StrUtils.defaultString(record.get("orsDtlListTckBosenKeijoEighoshoCd"));
                    record.put("orsDtlListTckBosenKeijoEighoshoCdAut",
                            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO, eigyoshoCd));
                    
                    // 仕分卸計上先営業所コード
                    eigyoshoCd = StrUtils.defaultString(record.get("orsDtlListSwkOroshiKeijoEighoshoCd"));
                    record.put("orsDtlListSwkOroshiKeijoEighoshoCdAut",
                            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO, eigyoshoCd));
                    
                    // 配達卸計上先営業所コード 
                    eigyoshoCd = StrUtils.defaultString(record.get("orsDtlListHttOroshiKeijoEighoshoCd"));
                    record.put("orsDtlListHttOroshiKeijoEighoshoCdAut",
                            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO, eigyoshoCd));
                    
                }
            }
        }
    }

    /**
     * AUTOCOMPLETE選択時コードと名称の設定処理
     *
     * @param row 明細行番号
     * @param option 選択されたAUTOCOMPLETEデータ
     * @param colCodeName 設定先コード
     * @param colNameName 設定先名称
     * @param editFlg 設定対象 
     */
    public void setListCodeName(int row,
            AutoCompOptionBean option,
            String colCodeName, 
            String colNameName,
            String editFlg) {
        
        if (option == null) {
            if (CheckUtils.isEqual(EGRP, editFlg)) {
                // 営業所グループ情報の場合
                mst042Form.getListEgrpDtlSelectable().getDatasource().get(row).put(colCodeName, 
                        "");
                mst042Form.getListEgrpDtlSelectable().getDatasource().get(row).put(colNameName, 
                        "");
            } else if (CheckUtils.isEqual(ORS, editFlg)) {
                // 卸単価情報の場合
                mst042Form.getListOrsDtlSelectable().getDatasource().get(row).put(colCodeName, 
                        "");
                mst042Form.getListOrsDtlSelectable().getDatasource().get(row).put(colNameName, 
                        "");
            }

        } else {
            if (CheckUtils.isEqual(EGRP, editFlg)) {
                // 営業所グループ情報の場合
                mst042Form.getListEgrpDtlSelectable().getDatasource().get(row).put(colCodeName, 
                        option.getValue());
                mst042Form.getListEgrpDtlSelectable().getDatasource().get(row).put(colNameName, 
                        option.getLabel());
            } else if (CheckUtils.isEqual(ORS, editFlg)) {
                // 卸単価情報の場合
                mst042Form.getListOrsDtlSelectable().getDatasource().get(row).put(colCodeName, 
                        option.getValue());
                mst042Form.getListOrsDtlSelectable().getDatasource().get(row).put(colNameName, 
                        option.getLabel());
            
            }
        }
    }
   
    /**
     * サブ組織名ENTERキー押下
     *
     * @param row 明細行番号
     * @param eigyoshoCd 選択された上位営業所コードデータ
     * @param option 選択されたAUTOCOMPLETEデータ
     * @param colCodeName 設定先コード
     * @param colNameName 設定先名称
     * @param enterFlg ENTERキーフラグ
     */
    public void getSubSoshikiMeisho(int row,
            AutoCompOptionBean eigyoshoCd, 
            AutoCompOptionBean option,
            String colCodeName, 
            String colNameName,
            String enterFlg) {
    
        // 上位営業所コード
        String strEigyoshoCd = "";
        if (eigyoshoCd != null) {
            strEigyoshoCd = eigyoshoCd.getValue();
        }
        // サブ組織Cd
        String strSubSoshiki = "";
        // サブ組織名
        String strSubSoshikiMei = "";
        if (option != null) {
            // サブ組織Cd
            strSubSoshiki = option.getLabel();
            // サブ組織名
            strSubSoshikiMei = option.getValue();
        }
        // ワーク.サブ組織
        subSoshikiMeiWk = strSubSoshiki.concat(" ").concat(strSubSoshikiMei);
        subSoshikiWk = strSubSoshiki;
        // サブ組織名ENTERキー押下の場合
        if (CheckUtils.isEqual(enterFlg, "true")) {
            // 営業所グループ情報.上位営業所コードが入力済み AND 営業所グループ情報.サブ組織名が入力済み 
            // AND 入力されたサブ組織名がワーク.サブ組織名リスト上に存在しない場合
            if (!CheckUtils.isEmpty(strEigyoshoCd) 
                    && !CheckUtils.isEmpty(strSubSoshikiMei) 
                    && !subSoshikiList.contains(strSubSoshikiMei)) {
                // サブ組織追加確認の警告ダイアログを表示する
                pageCommonBean.executeScript("km.showConfirmDialog('mst042SubSoshikiDialog')");
            }
        } else {
            // サブ組織名をワーク.サブ組織名リストに追加する。
            if (!subSoshikiList.contains(strSubSoshikiMei)) {
                subSoshikiMeiList.add(subSoshikiMeiWk);
                subSoshikiList.add(subSoshikiWk);
                mst042Form.setSubSoshikiMeiList(subSoshikiMeiList);
            }
        }
    }
         
    /**
     * サブ組織追加確認の警告ダイアログの「はい」ボタンを押下した場合
     *
     */
    public void subSoshikiMeishoCallBack() {
        
        // サブ組織名をワーク.サブ組織名リストに追加する。
        subSoshikiMeiList.add(subSoshikiMeiWk);
        subSoshikiList.add(subSoshikiWk);
        mst042Form.setSubSoshikiMeiList(subSoshikiMeiList);
    }
    
    /**
     * 画面用項目設定（営業所基本情報）
     *
     * @param res 検索結果
     * @throws SystemException システム異常
     */
    private void setGamenEigyoshoKihonJoho(Map<String, Object> res) throws SystemException {
        if (res != null && res.size() > 0) {
            // 管理情報
            // 営業所名
            mst042Form.setKnrDtlEigyoshoMei(StrUtils.defaultString(res.get("knrDtlEigyoshoMei")));
            // 営業所カナ名
            mst042Form.setKnrDtlEigyoshoKanaMei(StrUtils.defaultString(res.get("knrDtlEigyoshoKanaMei")));
            // 営業所略称
            mst042Form.setKnrDtlEigyoshoRyakusho(StrUtils.defaultString(res.get("knrDtlEigyoshoRyakusho")));
            // 英語表記
            mst042Form.setKnrDtlEigoHyoki(StrUtils.defaultString(res.get("knrDtlEigoHyoki")));
            // 使用区分
            List<String> knrDtlShiyoKbnList = (List<String>)res.get("knrDtlShiyoKbn");
            mst042Form.setKnrDtlShiyoKbn(knrDtlShiyoKbnList.toArray(new String[knrDtlShiyoKbnList.size()]));
            // 送り状発行営業所コード
            if (!CheckUtils.isEmpty(StrUtils.defaultString(res.get("knrDtlOkurijoHakkoEigyoshoCd")))) {
                mst042Form.setKnrDtlOkurijoHakkoEigyoshoCd(autoCompleteViewBean.getComMsDatas(
                        MsCnst.COM_GET_VW_EIGYOSHO, 
                        StrUtils.defaultString(res.get("knrDtlOkurijoHakkoEigyoshoCd"))));
            } else {
                mst042Form.setKnrDtlOkurijoHakkoEigyoshoCd(autoCompleteViewBean.getComMsDatas(
                        MsCnst.COM_GET_VW_EIGYOSHO, 
                        ""));
            }
            // 送り状発行営業所名
            mst042Form.setKnrDtlOkurijoHakkoEigyoshoMei(StrUtils.defaultString(
                    res.get("knrDtlOkurijoHakkoEigyoshoMei")));
            // 経理変換先コード
            mst042Form.setKnrDtlKeirisakiHenkanCd(StrUtils.defaultString(res.get("knrDtlKeirisakiHenkanCd")));
            // 営業所種別コード
            mst042Form.setKnrDtlHEigyoshoShubetsuCd(StrUtils.defaultString(res.get("knrDtlHEigyoshoShubetsuCd")));
            // 営業所種別
            mst042Form.setKnrDtlEigyoshoShubetsu(StrUtils.defaultString(res.get("knrDtlEigyoshoShubetsu")));
            // 承認営業所区分コード
            mst042Form.setKnrDtlHShoninEigyoshoKbnCd(StrUtils.defaultString(res.get("knrDtlHShoninEigyoshoKbnCd")));
            // 承認区分
            mst042Form.setKnrDtlShoninKbn(StrUtils.defaultString(res.get("knrDtlShoninKbn")));
            
            // 基本情報
            // 郵便番号
            mst042Form.setKhnDtlYubinBango(StrUtils.defaultString(res.get("khnDtlYubinBango")));
            // JISコード
            // ワーク.起動モード区分 = 2(参照)以外の場合
            if (!CheckUtils.isEmpty(StrUtils.defaultString(res.get("khnDtlJisCd")))) {
                mst042Form.setKhnDtlJisCd(autoCompleteViewBean.initAddr("JIS_CD",
                        StrUtils.defaultString(res.get("khnDtlJisCd"))));
            } else {
                mst042Form.setKhnDtlJisCd(autoCompleteViewBean.initAddr("JIS_CD",
                        null));
            }
            // ワーク.起動モード区分 = 2(参照)の場合
            mst042Form.setKhnDtlJisCdHyoji(StrUtils.defaultString(res.get("khnDtlJisCd")));
            // 住所1
            mst042Form.setKhnDtlJusho1(StrUtils.defaultString(res.get("khnDtlJusho1")));
            // 住所2
            mst042Form.setKhnDtlJusho2(StrUtils.defaultString(res.get("khnDtlJusho2")));
            // 住所3
            mst042Form.setKhnDtlJusho3(StrUtils.defaultString(res.get("khnDtlJusho3")));
            // 住所4
            mst042Form.setKhnDtlJusho4(StrUtils.defaultString(res.get("khnDtlJusho4")));
            // 空港コード
            if (!CheckUtils.isEmpty(StrUtils.defaultString(res.get("khnDtlKukoCd")))) {
                mst042Form.setKhnDtlKukoCd(autoCompleteViewBean.getComMsDatas(
                        MsCnst.COM_GET_MS_KUKO, 
                        StrUtils.defaultString(res.get("khnDtlKukoCd"))));
            } else {
                mst042Form.setKhnDtlKukoCd(autoCompleteViewBean.getComMsDatas(
                        MsCnst.COM_GET_MS_KUKO, 
                        ""));
            }
            // 空港名
            mst042Form.setKhnDtlKukoMei(StrUtils.defaultString(res.get("khnDtlKukoMei")));
            // 仕向地
            if (!CheckUtils.isEmpty(StrUtils.defaultString(res.get("khnDtlShimukeChi")))) {
                mst042Form.setKhnDtlShimukeChi(autoCompleteViewBean.getComMsDatas(
                        MsCnst.COM_GET_SHIMUKE_CHI_CD, 
                        StrUtils.defaultString(res.get("khnDtlShimukeChi"))));
            } else {
                mst042Form.setKhnDtlShimukeChi(autoCompleteViewBean.getComMsDatas(
                        MsCnst.COM_GET_SHIMUKE_CHI_CD, 
                        ""));
            }
            // 仕向地名
            mst042Form.setKhnDtlShimukeChiMei(StrUtils.defaultString(res.get("khnDtlShimukeChiMei")));
            // 集配地区コード
            mst042Form.setKhnDtlShuhaiChikuCd(StrUtils.defaultString(res.get("khnDtlShuhaiChikuCd")));
            // 電話番号1
            mst042Form.setKhnDtlTelBango1(StrUtils.defaultString(res.get("khnDtlTelBango1")));
            // 電話番号2
            mst042Form.setKhnDtlTelBango2(StrUtils.defaultString(res.get("khnDtlTelBango2")));
            // 社内電話番号
            mst042Form.setKhnDtlShanaiTelBango(StrUtils.defaultString(res.get("khnDtlShanaiTelBango")));
            // FAX番号
            mst042Form.setKhnDtlFaxBango(StrUtils.defaultString(res.get("khnDtlFaxBango")));
            
            // 口座情報
            // 銀行口座コード
            if (!CheckUtils.isEmpty(StrUtils.defaultString(res.get("kzaDtlGinkoKozaCd")))) {
                mst042Form.setKzaDtlGinkoKozaCd(autoCompleteViewBean.getComMsDatas(
                        MsCnst.COM_GET_MS_GINKO_KOZA, 
                        StrUtils.defaultString(res.get("kzaDtlGinkoKozaCd"))));
            } else {
                mst042Form.setKzaDtlGinkoKozaCd(autoCompleteViewBean.getComMsDatas(
                        MsCnst.COM_GET_MS_GINKO_KOZA, 
                        ""));
            }
            // 銀行口座名
            mst042Form.setKzaDtlGinkoKozaMei(StrUtils.defaultString(res.get("kzaDtlGinkoKozaMei")));
            // 金融機関コード
            mst042Form.setKzaDtlKinyuKikanCd(StrUtils.defaultString(res.get("kzaDtlKinyuKikanCd")));
            // 金融機関名
            mst042Form.setKzaDtlKinyuKikanMei(StrUtils.defaultString(res.get("kzaDtlKinyuKikanMei")));
            // 支店コード
            mst042Form.setKzaDtlShitenCd(StrUtils.defaultString(res.get("kzaDtlShitenCd")));
            // 支店名
            mst042Form.setKzaDtlShitenMei(StrUtils.defaultString(res.get("kzaDtlShitenMei")));
            // 口座種別コード
            mst042Form.setKzaDtlKozaShubetsuCd(StrUtils.defaultString(res.get("kzaDtlKozaShubetsuCd")));
            // 口座種別名
            mst042Form.setKzaDtlKozaShubetsuMei(StrUtils.defaultString(res.get("kzaDtlKozaShubetsuMei")));
            // 口座番号
            mst042Form.setKzaDtlKozaBango(StrUtils.defaultString(res.get("kzaDtlKozaBango")));
            // 名義人名
            mst042Form.setKzaDtlMeigininMei(StrUtils.defaultString(res.get("kzaDtlMeigininMei")));
            
            // 卸単価情報
            // 仕立営業所コード
            if (!CheckUtils.isEmpty(StrUtils.defaultString(res.get("orsDtlShitateEigyoshoCd")))) {
                mst042Form.setOrsDtlShitateEigyoshoCd(autoCompleteViewBean.getComMsDatas(
                        MsCnst.COM_GET_VW_EIGYOSHO, 
                        StrUtils.defaultString(res.get("orsDtlShitateEigyoshoCd"))));
            } else {
                mst042Form.setOrsDtlShitateEigyoshoCd(autoCompleteViewBean.getComMsDatas(
                        MsCnst.COM_GET_VW_EIGYOSHO, 
                        ""));
            }
            // 仕立営業所名
            mst042Form.setOrsDtlShitateEigyoshoMei(StrUtils.defaultString(res.get("orsDtlShitateEigyoshoMei")));
            // 他社中継卸値率
            mst042Form.setOrsDtlTashaChukeiOroshineritsu(StrUtils.defaultString(
                    res.get("orsDtlTashaChukeiOroshineritsu")));
            
            // 更新情報・最終使用日
            // ユーザ
            mst042Form.setKshnDtlUser(StrUtils.defaultString(res.get("kshnDtlUser")));
            // 更新日時
            mst042Form.setKshnDtlKoshinNichiji(StrUtils.defaultString(res.get("kshnDtlKoshinNichiji")));
            // 最終使用日(売上管理)
            mst042Form.setKshnDtlSaishuShiyoHiUriageKanri(StrUtils.defaultString(
                    res.get("kshnDtlSaishuShiyoHiUriageKanri")));
            // 最終使用日(卸計算)
            mst042Form.setKshnDtlSaishuShiyoHiOroshiKanri(StrUtils.defaultString(
                    res.get("kshnDtlSaishuShiyoHiOroshiKanri")));
            // 最終使用日(仕入管理)
            mst042Form.setKshnDtlSaishuShiyoHiShiireKanri(StrUtils.defaultString(
                    res.get("kshnDtlSaishuShiyoHiShiireKanri")));
            
            // ワーク
            // 一見顧客登録フラグ
            mst042Form.setDtlHIchigenKokyakuTorokuFlg(StrUtils.defaultString(
                    res.get("dtlHIchigenKokyakuTorokuFlg")));
            // 社内便登録フラグ
            mst042Form.setDtlHShanaiBinTorokuFlg(StrUtils.defaultString(
                    res.get("dtlHShanaiBinTorokuFlg")));
            // 着払代引登録フラグ
            mst042Form.setDtlHChakubaraiDaibikiTorokuFlg(StrUtils.defaultString(
                    res.get("dtlHChakubaraiDaibikiTorokuFlg")));
            
            // 旧住所フラグ
            mst042Form.setDtlHKyuJushoFlg(StrUtils.defaultString(res.get("dtlHKyuJushoFlg")));
            // 使用不可フラグ
            mst042Form.setDtlHShiyoFukaFlg(StrUtils.defaultString(res.get("dtlHShiyoFukaFlg")));
            // 新JISコード
            mst042Form.setDtlHShinJisCd(StrUtils.defaultString(res.get("dtlHShinJisCd")));
            // 営業所データバージョン
            mst042Form.setDtlEigyoshoDataVersion(StrUtils.defaultString(res.get("dtlEigyoshoDataVersion")));
            // 更新カウンタ
            mst042Form.setDtlKoshinCounter(StrUtils.defaultString(res.get("dtlKoshinCounter")));
            // 適用終了日
            mst042Form.setTekiyoShuryobi(StrUtils.defaultString(res.get("tekiyoShuryobi")));
            
        } else {
            // 画面項目の初期化
            // 管理情報
            // 営業所名
            mst042Form.setKnrDtlEigyoshoMei("");
            // 営業所カナ名
            mst042Form.setKnrDtlEigyoshoKanaMei("");
            // 営業所略称
            mst042Form.setKnrDtlEigyoshoRyakusho("");
            // 英語表記
            mst042Form.setKnrDtlEigoHyoki("");
            // 使用区分
            String[] knrDtlShiyoKbn = {"0", "0", "0", "0", "0", "0", "0"};
            mst042Form.setKnrDtlShiyoKbn(knrDtlShiyoKbn);
            // 送り状発行営業所コード
            mst042Form.setKnrDtlOkurijoHakkoEigyoshoCd(autoCompleteViewBean.getComMsDatas(
                        MsCnst.COM_GET_VW_EIGYOSHO, ""));
            // 送り状発行営業所名
            mst042Form.setKnrDtlOkurijoHakkoEigyoshoMei("");
            // 経理変換先コード
            mst042Form.setKnrDtlKeirisakiHenkanCd("");
            // 営業所種別コード
            mst042Form.setKnrDtlHEigyoshoShubetsuCd("");
            // 営業所種別
            mst042Form.setKnrDtlEigyoshoShubetsu("");
            // 承認営業所区分コード
            mst042Form.setKnrDtlHShoninEigyoshoKbnCd("");
            // 承認区分
            mst042Form.setKnrDtlShoninKbn("");
            
            // 基本情報
            // 郵便番号
            mst042Form.setKhnDtlYubinBango("");
            // JISコード
            // ワーク.起動モード区分 = 2(参照)以外の場合
            mst042Form.setKhnDtlJisCd(autoCompleteViewBean.initAddr("JIS_CD",
                    null));
            // ワーク.起動モード区分 = 2(参照)の場合
            mst042Form.setKhnDtlJisCdHyoji("");
            // 住所1
            mst042Form.setKhnDtlJusho1("");
            // 住所2
            mst042Form.setKhnDtlJusho2("");
            // 住所3
            mst042Form.setKhnDtlJusho3("");
            // 住所4
            mst042Form.setKhnDtlJusho4("");
            // 空港コード
            mst042Form.setKhnDtlKukoCd(autoCompleteViewBean.getComMsDatas(
                        MsCnst.COM_GET_MS_KUKO, ""));
            // 空港名
            mst042Form.setKhnDtlKukoMei("");
            // 仕向地
            mst042Form.setKhnDtlShimukeChi(autoCompleteViewBean.getComMsDatas(
                        MsCnst.COM_GET_SHIMUKE_CHI_CD, ""));
            // 仕向地名
            mst042Form.setKhnDtlShimukeChiMei("");
            // 集配地区コード
            mst042Form.setKhnDtlShuhaiChikuCd("");
            // 電話番号1
            mst042Form.setKhnDtlTelBango1("");
            // 電話番号2
            mst042Form.setKhnDtlTelBango2("");
            // 社内電話番号
            mst042Form.setKhnDtlShanaiTelBango("");
            // FAX番号
            mst042Form.setKhnDtlFaxBango("");
            
            // 口座情報
            // 銀行口座コード
            mst042Form.setKzaDtlGinkoKozaCd(autoCompleteViewBean.getComMsDatas(
                        MsCnst.COM_GET_MS_GINKO_KOZA, ""));
            // 銀行口座名
            mst042Form.setKzaDtlGinkoKozaMei("");
            // 金融機関コード
            mst042Form.setKzaDtlKinyuKikanCd("");
            // 金融機関名
            mst042Form.setKzaDtlKinyuKikanMei("");
            // 支店コード
            mst042Form.setKzaDtlShitenCd("");
            // 支店名
            mst042Form.setKzaDtlShitenMei("");
            // 口座種別コード
            mst042Form.setKzaDtlKozaShubetsuCd("");
            // 口座種別名
            mst042Form.setKzaDtlKozaShubetsuMei("");
            // 口座番号
            mst042Form.setKzaDtlKozaBango("");
            // 名義人名
            mst042Form.setKzaDtlMeigininMei("");
            
            // 卸単価情報
            // 仕立営業所コード
            mst042Form.setOrsDtlShitateEigyoshoCd(autoCompleteViewBean.getComMsDatas(
                        MsCnst.COM_GET_VW_EIGYOSHO, ""));
            // 仕立営業所名
            mst042Form.setOrsDtlShitateEigyoshoMei("");
            // 他社中継卸値率
            mst042Form.setOrsDtlTashaChukeiOroshineritsu("");
            
            // 更新情報・最終使用日
            // ユーザ
            mst042Form.setKshnDtlUser("");
            // 更新日時
            mst042Form.setKshnDtlKoshinNichiji("");
            // 最終使用日(売上管理)
            mst042Form.setKshnDtlSaishuShiyoHiUriageKanri("");
            // 最終使用日(卸計算)
            mst042Form.setKshnDtlSaishuShiyoHiOroshiKanri("");
            // 最終使用日(仕入管理)
            mst042Form.setKshnDtlSaishuShiyoHiShiireKanri("");
            
            // ワーク
            // 一見顧客登録フラグ
            mst042Form.setDtlHIchigenKokyakuTorokuFlg("");
            // 社内便登録フラグ
            mst042Form.setDtlHShanaiBinTorokuFlg("");
            // 着払代引登録フラグ
            mst042Form.setDtlHChakubaraiDaibikiTorokuFlg("");
            // 旧住所フラグ
            mst042Form.setDtlHKyuJushoFlg("");
            // 使用不可フラグ
            mst042Form.setDtlHShiyoFukaFlg("");
            // 新JISコード
            mst042Form.setDtlHShinJisCd("");
            // 営業所データバージョン
            mst042Form.setDtlEigyoshoDataVersion("");
            //  更新カウンタ
            mst042Form.setDtlKoshinCounter("");
            // 適用終了日
            mst042Form.setTekiyoShuryobi("");
        }
    }
    
     /**
     * 登録/更新用項目設定（営業所マスタ情報）
     *
     * @throws 異常
     */
    private void setMapEigyoshoKihonJoho() throws SystemException {
        
        // 営業所マスタ情報を初期化
        if (mst042Form.getResultEigyoshoInfo() == null) {
            mst042Form.setResultEigyoshoInfo(new HashMap<>());
        }
        
        // 検索の場合
        // 営業所コード	
        mst042Form.getResultEigyoshoInfo().put("conEigyoshoCd",
                mst042Form.getConEigyoshoCd().getValue());
        // 適用開始日	
        mst042Form.getResultEigyoshoInfo().put("conTekiyoKaishibi",
                DateUtils.parseFmtYMD(mst042Form.getConTekiyoKaishibi()));
        
        // 適用名
        mst042Form.getResultEigyoshoInfo().put("conTekiyoMei",
                mst042Form.getConTekiyoMei());
        // 営業所名	
        mst042Form.getResultEigyoshoInfo().put("knrDtlEigyoshoMei",
                mst042Form.getKnrDtlEigyoshoMei());
        // 営業所カナ名
        mst042Form.getResultEigyoshoInfo().put("knrDtlEigyoshoKanaMei",
                mst042Form.getKnrDtlEigyoshoKanaMei());	
        // 営業所略称
        mst042Form.getResultEigyoshoInfo().put("knrDtlEigyoshoRyakusho",
                mst042Form.getKnrDtlEigyoshoRyakusho());	
        // 英語表記
        mst042Form.getResultEigyoshoInfo().put("knrDtlEigoHyoki",
                mst042Form.getKnrDtlEigoHyoki());
         
        // 使用区分.集荷営業所
        String shukaEigyoshoFlg = "0";
        // 使用区分.配達営業所
        String haitatsuEigyoshoFlg = "0";
        // 使用区分.チャーター起点
        String kitenFlg = "0";
        // 使用区分.売上
        String uriageFlg = "0";
        // 使用区分.発券営業所
        String hakkenEigyoshoFlg = "0";
        // 使用区分.車両管理
        String sharyoKanriFlg = "0";
        // 使用区分.配達伝票出力営業所
        String haidenOutputEigyoshoFlg = "0";

        if (mst042Form.getKnrDtlShiyoKbn() != null && 
                mst042Form.getKnrDtlShiyoKbn().length > 0) {
            for (int i=0; i<mst042Form.getKnrDtlShiyoKbn().length; i++) {
                switch(mst042Form.getKnrDtlShiyoKbn()[i]) {
                    case "1":
                        // 使用区分.集荷営業所
                        shukaEigyoshoFlg = "1";
                        break;
                    case "2":
                        // 使用区分.配達営業所
                        haitatsuEigyoshoFlg = "1";
                        break;
                    case "3":
                        // 使用区分.チャーター起点
                        kitenFlg = "1";
                        break;
                    case "4":
                        // 使用区分.売上
                        uriageFlg = "1";
                        break;
                    case "5":
                        // 使用区分.発券営業所
                        hakkenEigyoshoFlg = "1";
                        break;
                    case "6":
                        // 使用区分.車両管理
                        sharyoKanriFlg = "1";
                        break;
                    case "7":
                        // 使用区分.配達伝票出力営業所
                        haidenOutputEigyoshoFlg = "1";
                        break;
                }
            }
        }
        // 集荷営業所フラグ
        mst042Form.getResultEigyoshoInfo().put("knrDtlShiyoShukaKbn",
                shukaEigyoshoFlg);	
        // 配達営業所フラグ
        mst042Form.getResultEigyoshoInfo().put("knrDtlShiyoHaitatsuKbn",
                haitatsuEigyoshoFlg);	
        // 起点フラグ	
        mst042Form.getResultEigyoshoInfo().put("knrDtlShiyoKitenKbn",
                kitenFlg);
        // 売上フラグ
        mst042Form.getResultEigyoshoInfo().put("knrDtlShiyoUriageKbn",
                uriageFlg);	
        // 発券営業所フラグ	
        mst042Form.getResultEigyoshoInfo().put("knrDtlShiyoHakkenKbn",
                hakkenEigyoshoFlg);
        // 車両管理フラグ
        mst042Form.getResultEigyoshoInfo().put("knrDtlShiyoSharyoKbn",
                sharyoKanriFlg);	
        // 配達伝票出力営業所フラグ
        mst042Form.getResultEigyoshoInfo().put("knrDtlShiyoHaidenKbn",
                haidenOutputEigyoshoFlg);	
        // 送り状発行営業所コード	
        if (mst042Form.getKnrDtlOkurijoHakkoEigyoshoCd() != null) {
            mst042Form.getResultEigyoshoInfo().put("knrDtlOkurijoHakkoEigyoshoCd",
                mst042Form.getKnrDtlOkurijoHakkoEigyoshoCd().getValue());
        }
        // 経理変換先コード	
        mst042Form.getResultEigyoshoInfo().put("knrDtlKeirisakiHenkanCd",
                mst042Form.getKnrDtlKeirisakiHenkanCd());
        // 営業所種別コード	
        mst042Form.getResultEigyoshoInfo().put("knrDtlHEigyoshoShubetsuCd",
                mst042Form.getKnrDtlHEigyoshoShubetsuCd());
        // 承認営業所区分コード	
        mst042Form.getResultEigyoshoInfo().put("knrDtlHShoninEigyoshoKbnCd",
                mst042Form.getKnrDtlHShoninEigyoshoKbnCd());
        // 郵便番号	
        mst042Form.getResultEigyoshoInfo().put("khnDtlYubinBango",
                mst042Form.getKhnDtlYubinBango());
        // JISコード
        if (mst042Form.getKhnDtlJisCd() != null) {
            mst042Form.getResultEigyoshoInfo().put("khnDtlJisCd",
                mst042Form.getKhnDtlJisCd().getValue());	
        }
        // 住所１	
        mst042Form.getResultEigyoshoInfo().put("khnDtlJusho1",
                mst042Form.getKhnDtlJusho1());
        // 住所２
        mst042Form.getResultEigyoshoInfo().put("khnDtlJusho2",
                mst042Form.getKhnDtlJusho2());	
        // 住所３
        mst042Form.getResultEigyoshoInfo().put("khnDtlJusho3",
                mst042Form.getKhnDtlJusho3());	
        // 住所４
        mst042Form.getResultEigyoshoInfo().put("khnDtlJusho4",
                mst042Form.getKhnDtlJusho4());	
        // 空港コード	
        if (mst042Form.getKhnDtlKukoCd() != null) {
            mst042Form.getResultEigyoshoInfo().put("khnDtlKukoCd",
                mst042Form.getKhnDtlKukoCd().getValue());
        }
        // 仕向地コード	
        if (mst042Form.getKhnDtlShimukeChi() != null) {
            mst042Form.getResultEigyoshoInfo().put("khnDtlShimukeChi",
                mst042Form.getKhnDtlShimukeChi().getValue());
        }
        // 集配地区コード
        mst042Form.getResultEigyoshoInfo().put("khnDtlShuhaiChikuCd",
                mst042Form.getKhnDtlShuhaiChikuCd());	
        // 電話番号１	
        mst042Form.getResultEigyoshoInfo().put("khnDtlTelBango1",
                mst042Form.getKhnDtlTelBango1());
        // 電話番号２	
        mst042Form.getResultEigyoshoInfo().put("khnDtlTelBango2",
                mst042Form.getKhnDtlTelBango2());
        // 社内電話番号	
        mst042Form.getResultEigyoshoInfo().put("khnDtlShanaiTelBango",
                mst042Form.getKhnDtlShanaiTelBango());
        // FAX番号	
        mst042Form.getResultEigyoshoInfo().put("khnDtlFaxBango",
                mst042Form.getKhnDtlFaxBango());
        // 銀行口座コード
        if (mst042Form.getKzaDtlGinkoKozaCd() != null) {
            mst042Form.getResultEigyoshoInfo().put("kzaDtlGinkoKozaCd",
                mst042Form.getKzaDtlGinkoKozaCd().getValue());	
        }
        // 仕立営業所コード	
        if (mst042Form.getOrsDtlShitateEigyoshoCd() != null) {
            mst042Form.getResultEigyoshoInfo().put("orsDtlShitateEigyoshoCd",
                mst042Form.getOrsDtlShitateEigyoshoCd().getValue());
        }
        // 他社中継卸値率	
        mst042Form.getResultEigyoshoInfo().put("orsDtlTashaChukeiOroshineritsu",
                mst042Form.getOrsDtlTashaChukeiOroshineritsu());
        // 登録対象の場合
        if (CheckUtils.isEqual(MODE_SHINKI_FLG, mst042Form.getEditKbn())) {
            // 一見顧客登録フラグ	
            mst042Form.getResultEigyoshoInfo().put("dtlHIchigenKokyakuTorokuFlg", "0");
            // 社内便登録フラグ	
            mst042Form.getResultEigyoshoInfo().put("dtlHShanaiBinTorokuFlg", "0");
            // 着払代引登録フラグ	
            mst042Form.getResultEigyoshoInfo().put("dtlHChakubaraiDaibikiTorokuFlg", "0");
        
        } else if (CheckUtils.isEqual(MODE_UPDATE_FLG, mst042Form.getEditKbn())) {
            // 更新対象の場合
            // 一見顧客登録フラグ	
            mst042Form.getResultEigyoshoInfo().put("dtlHIchigenKokyakuTorokuFlg",
                    mst042Form.getDtlHIchigenKokyakuTorokuFlg());
            // 社内便登録フラグ	
            mst042Form.getResultEigyoshoInfo().put("dtlHShanaiBinTorokuFlg",
                    mst042Form.getDtlHShanaiBinTorokuFlg());
            // 着払代引登録フラグ	
            mst042Form.getResultEigyoshoInfo().put("dtlHChakubaraiDaibikiTorokuFlg",
                    mst042Form.getDtlHChakubaraiDaibikiTorokuFlg());
        
        }
        // 適用終了日	
        mst042Form.getResultEigyoshoInfo().put("conTekiyoShuryobi",
                DateUtils.getSysDate());
        // 削除フラグ	
        mst042Form.getResultEigyoshoInfo().put("dtlSakujoFlg",
                mst042Form.getDtlHSakujoFlg());
        // 営業所データバージョン	
        mst042Form.getResultEigyoshoInfo().put("dtlEigyoshoDataVersion",
                mst042Form.getDtlEigyoshoDataVersion());
        // 更新ユーザーID
        mst042Form.getResultEigyoshoInfo().put("kshnDtlUser",
                mst042Form.getKshnDtlUser());
        // 更新カウンタ
        mst042Form.getResultEigyoshoInfo().put("dtlKoshinCounter",
                mst042Form.getDtlKoshinCounter());
    }
    
     /**
     * 入力内容チェック処理
     * 
     * @throws SystemException 異常
     * @throws UnsupportedEncodingException 異常
     * @return 処理結果
     */
    private int inputChcek() throws SystemException, UnsupportedEncodingException {

        // 入力必須チェック
        // 営業所コード
        if (mst042Form.getConEigyoshoCd() == null) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0003, "営業所コード");
            return -1;
        }
        // 適用開始日
        if (CheckUtils.isEmpty(mst042Form.getConTekiyoKaishibi())) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0003, "適用開始日");
            return -1;
        }
        // 適用名最大桁数チェック
        if (!maxSizeCheck(mst042Form.getConTekiyoMei(), 40)) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0002, "適用名", "40");
            return -1;
        }
        // 営業所名
        if (mst042Form.getKnrDtlEigyoshoMei() == null || CheckUtils.isEmpty(
                mst042Form.getKnrDtlEigyoshoMei().trim())) {
            // 必須チェック
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0003, "営業所名");
            return -1;
        } else {
            // 最大桁数チェック
            if (!maxSizeCheck(mst042Form.getKnrDtlEigyoshoMei(), 40)) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                        MessageCnst.COME0002, "営業所名", "40");
                return -1;
            }
        }
        // 営業所カナ名最大桁数チェック
        if (!maxSizeCheck(mst042Form.getKnrDtlEigyoshoKanaMei(), 40)) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0002, "営業所カナ名", "40");
            return -1;
        }
        // 営業所略称最大桁数チェック
        if (!maxSizeCheck(mst042Form.getKnrDtlEigyoshoRyakusho(), 40)) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0002, "営業所略称", "40");
            return -1;
        }
        // 英語表記最大桁数チェック
        if (!maxSizeCheck(mst042Form.getKnrDtlEigoHyoki(), 40)) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0002, "英語表記", "40");
            return -1;
        }
        // 営業所種別
        if (mst042Form.getKnrDtlHEigyoshoShubetsuCd() == null || CheckUtils.isEmpty(
                mst042Form.getKnrDtlHEigyoshoShubetsuCd())) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0003, "営業所種別");
            return -1;
        }
        // 承認区分
        if (mst042Form.getKnrDtlHShoninEigyoshoKbnCd() == null || CheckUtils.isEmpty(
                mst042Form.getKnrDtlHShoninEigyoshoKbnCd())) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0003, "承認区分");
            return -1;
        }
        // JISコード
        if (mst042Form.getKhnDtlJisCd() == null || CheckUtils.isEmpty(
                mst042Form.getKhnDtlJisCd().getValue())) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0003, "JISコード");
            return -1;
        }
        
        // 郵便番号最大桁数チェック
        if (!maxSizeCheck(mst042Form.getKhnDtlYubinBango(), 7)) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0002, "郵便番号", "7");
            return -1;
        }
        // 住所1
        if (mst042Form.getKhnDtlJusho1() == null || CheckUtils.isEmpty(
                mst042Form.getKhnDtlJusho1().trim())) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0003, "住所1");
            return -1;
        } else {
            // 住所1最大桁数チェック
            if (!maxSizeCheck(mst042Form.getKhnDtlJusho1(), 40)) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                        MessageCnst.COME0002, "住所1", "40");
                return -1;
            }
        }
        
        // 住所2最大桁数チェック
        if (!maxSizeCheck(mst042Form.getKhnDtlJusho2(), 40)) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0002, "住所2", "40");
            return -1;
        }

        // 住所3最大桁数チェック
        if (!maxSizeCheck(mst042Form.getKhnDtlJusho3(), 40)) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0002, "住所3", "40");
            return -1;
        }
        
        // 住所4最大桁数チェック
        if (!maxSizeCheck(mst042Form.getKhnDtlJusho4(), 40)) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0002, "住所4", "40");
            return -1;
        }
            
        // 空港コード
        if (mst042Form.getKhnDtlKukoCd() == null || CheckUtils.isEmpty(
                mst042Form.getKhnDtlKukoCd().getValue())) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0003, "空港コード");
            return -1;
        }
        // 仕向地
        if (mst042Form.getKhnDtlShimukeChi() == null || CheckUtils.isEmpty(
                mst042Form.getKhnDtlShimukeChi().getValue())) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0003, "仕向地");
            return -1;
        }
        // 集配地区コード
        if (CheckUtils.isEmpty(mst042Form.getKhnDtlShuhaiChikuCd())) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0003, "集配地区コード");
            return -1;
        }

        // 伝票種別リスト
        List<String> dempyoShubetsuList = new ArrayList<>();
        // 卸単価情報リスト
        List<Map<String, Object>> orsList = mst042Form.getListOrsDtlSelectable().getDatasource();
        for (Map<String, Object> orsInfo1 : orsList) {
            // 伝票種別リストを設定する
            if (!CheckUtils.isEmpty(StrUtils.defaultString(orsInfo1.get("orsDtlListHDempyoShubetsuCd")))) {
                dempyoShubetsuList.add(StrUtils.defaultString(orsInfo1.get("orsDtlListHDempyoShubetsuCd")));
            }
        }
        for (Map<String, Object> rec : orsList) {
            // 伝票種別重複チェック
            if (!CheckUtils.isEmpty(StrUtils.defaultString(rec.get("orsDtlListHDempyoShubetsuCd")))) {
                List<String> filterList = dempyoShubetsuList.stream()
                    .filter((String sub) -> StrUtils.defaultString(rec.get("orsDtlListHDempyoShubetsuCd")).equals(sub))
                    .collect(Collectors.toList());
                if (filterList.size() > 1) {
                    // 伝票種別が重複しています。
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                            MessageCnst.COME0055, "伝票種別");
                    return -1;
                }
            }

            // 卸未入力チェック
            // 卸項目が入力済みで、伝票種別が未入力の場合
            // 集荷卸単価が入力済また、						
            // 集荷卸最低額が入力済また、						
            // 集荷卸計上先コードが入力済また、								
            // 集荷卸計上先営業所名が入力済また、								
            // 発送母船卸単価が入力済また、								
            // 発送母船卸最低額が入力済また、								
            // 発送母船卸計上先コードが入力済また、								
            // 発送母船卸計上先営業所名が入力済また、								
            // 到着母船卸単価が入力済また、								
            // 到着母船卸最低額が入力済また、								
            // 到着母船卸計上先コード	が入力済また、							
            // 到着母船卸計上先営業所名が入力済また、								
            // 仕分卸単価が入力済また、								
            // 仕分卸最低額が入力済また、								
            // 仕分卸計上先コードが入力済また、								
            // 仕分卸計上先営業所名が入力済また、								
            // 配達卸単価が入力済また、								
            // 配達卸最低額が入力済また、								
            // 配達卸計上先コードが入力済また、								
            // 配達卸計上先営業所名が入力済また、
            if (!CheckUtils.isEmpty(StrUtils.defaultString(
                    rec.get("orsDtlListShukaOroshiTanka")).trim())
                    || !CheckUtils.isEmpty(StrUtils.defaultString(
                            rec.get("orsDtlListShukaOroshiSaiteiGaku")).trim())
                    || !CheckUtils.isEmpty(StrUtils.defaultString(
                            rec.get("orsDtlListShukaOroshiKeijoEighoshoCd")).trim())
                    || !CheckUtils.isEmpty(StrUtils.defaultString(
                            rec.get("orsDtlListHsoBosenTanka")).trim())
                    || !CheckUtils.isEmpty(StrUtils.defaultString(
                            rec.get("orsDtlListHsoBosenSaiteiGaku")).trim())
                    || !CheckUtils.isEmpty(StrUtils.defaultString(
                            rec.get("orsDtlListHsoBosenKeijoEighoshoCd")).trim())
                    || !CheckUtils.isEmpty(StrUtils.defaultString(
                            rec.get("orsDtlListTckBosenTanka")).trim())
                    || !CheckUtils.isEmpty(StrUtils.defaultString(
                            rec.get("orsDtlListTckBosenSaiteiGaku")).trim())
                    || !CheckUtils.isEmpty(StrUtils.defaultString(
                            rec.get("orsDtlListTckBosenKeijoEighoshoCd")).trim())
                    || !CheckUtils.isEmpty(StrUtils.defaultString(
                            rec.get("orsDtlListSwkOroshiTanka")).trim())
                    || !CheckUtils.isEmpty(StrUtils.defaultString(
                            rec.get("orsDtlListSwkOroshiSaiteiGaku")).trim())
                    || !CheckUtils.isEmpty(StrUtils.defaultString(
                            rec.get("orsDtlListSwkOroshiKeijoEighoshoCd")).trim())
                    || !CheckUtils.isEmpty(StrUtils.defaultString(
                            rec.get("orsDtlListHttOroshiTanka")).trim())
                    || !CheckUtils.isEmpty(StrUtils.defaultString(
                            rec.get("orsDtlListHttOroshiSaiteiGaku")).trim())
                    || !CheckUtils.isEmpty(StrUtils.defaultString(
                            rec.get("orsDtlListHttOroshiKeijoEighoshoCd")).trim())) {
                
                // 伝票種別が未入力の場合
                if (CheckUtils.isEmpty(StrUtils.defaultString(rec.get("orsDtlListHDempyoShubetsuCd")))) {
                    // 
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, 
                            MessageCnst.COME0021, 
                            "卸",
                            "伝票種別");
                    return -1;
                }
            }
            
            // 伝票種別未入力チェック
            // 伝票種別が選択済み
            // 集荷卸単価が未入力						
            // 集荷卸最低額が未入力						
            // 集荷卸計上先コードが未入力								
            // 集荷卸計上先営業所名が未入力								
            // 発送母船卸単価が未入力								
            // 発送母船卸最低額が未入力								
            // 発送母船卸計上先コードが未入力								
            // 発送母船卸計上先営業所名が未入力								
            // 到着母船卸単価が未入力								
            // 到着母船卸最低額が未入力								
            // 到着母船卸計上先コード	が未入力							
            // 到着母船卸計上先営業所名が未入力								
            // 仕分卸単価が未入力								
            // 仕分卸最低額が未入力								
            // 仕分卸計上先コードが未入力								
            // 仕分卸計上先営業所名が未入力								
            // 配達卸単価が未入力								
            // 配達卸最低額が未入力								
            // 配達卸計上先コードが未入力								
            // 配達卸計上先営業所名が未入力								
            if (!CheckUtils.isEmpty(StrUtils.defaultString(rec.get("orsDtlListHDempyoShubetsuCd")))) {
                 // いずれかの卸単位で項目が未入力の場合
                 if (CheckUtils.isEmpty(StrUtils.defaultString(
                         rec.get("orsDtlListShukaOroshiTanka")).trim())
                         && CheckUtils.isEmpty(StrUtils.defaultString(
                                 rec.get("orsDtlListShukaOroshiSaiteiGaku")).trim())
                         && CheckUtils.isEmpty(StrUtils.defaultString(
                                 rec.get("orsDtlListShukaOroshiKeijoEighoshoCd")).trim())
                         && CheckUtils.isEmpty(StrUtils.defaultString(
                                 rec.get("orsDtlListHsoBosenTanka")).trim())
                         && CheckUtils.isEmpty(StrUtils.defaultString(
                                 rec.get("orsDtlListHsoBosenSaiteiGaku")).trim())
                         && CheckUtils.isEmpty(StrUtils.defaultString(
                                 rec.get("orsDtlListHsoBosenKeijoEighoshoCd")).trim())
                         && CheckUtils.isEmpty(StrUtils.defaultString(
                                 rec.get("orsDtlListTckBosenTanka")).trim())
                         && CheckUtils.isEmpty(StrUtils.defaultString(
                                 rec.get("orsDtlListTckBosenSaiteiGaku")).trim())
                         && CheckUtils.isEmpty(StrUtils.defaultString(
                                 rec.get("orsDtlListTckBosenKeijoEighoshoCd")).trim())
                         && CheckUtils.isEmpty(StrUtils.defaultString(
                                 rec.get("orsDtlListSwkOroshiTanka")).trim())
                         && CheckUtils.isEmpty(StrUtils.defaultString(
                                 rec.get("orsDtlListSwkOroshiSaiteiGaku")).trim())
                         && CheckUtils.isEmpty(StrUtils.defaultString(
                                 rec.get("orsDtlListSwkOroshiKeijoEighoshoCd")).trim())
                         && CheckUtils.isEmpty(StrUtils.defaultString(
                                 rec.get("orsDtlListHttOroshiTanka")).trim())
                         && CheckUtils.isEmpty(StrUtils.defaultString(
                                 rec.get("orsDtlListHttOroshiSaiteiGaku")).trim())
                         && CheckUtils.isEmpty(StrUtils.defaultString(
                                 rec.get("orsDtlListHttOroshiKeijoEighoshoCd")).trim())) {
                    // 伝票種別を選択した場合、いずれかの卸に設定を行ってください。
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                            MessageCnst.MSTE0107);
                    return -1;
                 }
             }
        }
        
        // メイン組織チェック（複数）
        // 上位営業所リスト
        List<String> eigyoshoCdList = new ArrayList<>();
        // メイン組織チェックボックスリスト
        List<String> mainSoshikiList = new ArrayList<>();
        // 営業所グループ情報リスト
        List<Map<String, Object>> egrpList = mst042Form.getListEgrpDtlSelectable().getDatasource();
        for (Map<String, Object> egrpInfo : egrpList) {
            // 上位営業所リストを設定する
            if (!CheckUtils.isEmpty(StrUtils.defaultString(egrpInfo.get("egrpDtlListJoiEigyoshoCd")))) {
                eigyoshoCdList.add(StrUtils.defaultString(egrpInfo.get("egrpDtlListJoiEigyoshoCd")));
            }
            // メイン組織チェックボックスリストを設定する
            if (CheckUtils.isEqual(StrUtils.defaultString(egrpInfo.get("egrpDtlListMainSoshiki")), "true")) {
                mainSoshikiList.add(StrUtils.defaultString(egrpInfo.get("egrpDtlListMainSoshiki")));
            }
            
            if (egrpInfo.get("egrpDtlListSubSoshikiCdAut") != null 
                            && egrpInfo.get("egrpDtlListSubSoshikiCdAut") != "") {
                // サブ組織名変数を定義
                AutoCompOptionBean subSoshikiMeiAut = (AutoCompOptionBean)egrpInfo.get("egrpDtlListSubSoshikiCdAut");
                // サブ組織名を移除
                egrpInfo.remove("egrpDtlListSubSoshikiMei");
                // サブ組織名を再設定する
                egrpInfo.put("egrpDtlListSubSoshikiMei", subSoshikiMeiAut.getLabel());
            }
        }
        
        // 上位営業所が1つ以上設定されている かつ メイン組織チェックボックスが二つ以上設定されている場合
        if (eigyoshoCdList.size() >= 1 && mainSoshikiList.size() >= 2) {
            // メイン組織が2つ以上選択されています。
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                        MessageCnst.COME0056, "メイン組織");
            return -1;
        }
        
        // 上位営業所が1つ以上設定されている かつ メイン組織チェックボックスが未設定の場合
        if (eigyoshoCdList.size() >= 1 && 0 == mainSoshikiList.size()) {
            // メイン組織が選択されていません。
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                        MessageCnst.COME0057, "メイン組織");
            return -1;
        }
        
        // 重複、存在チェック
        Map<String, Object> params = new HashMap<>();
        // 登録/更新区分
        params.put("editKbn", mst042Form.getEditKbn());
        // 営業所コード
        params.put("conEigyoshoCd", mst042Form.getConEigyoshoCd().getValue());
        // 適用開始日	
        params.put("conTekiyoKaishibi", DateUtils.parseFmtYMD(mst042Form.getConTekiyoKaishibi()));
        // JIS存在チェック
        params.put("khnDtlJisCd", mst042Form.getKhnDtlJisCd().getValue());
        // 空港存在チェック
        params.put("khnDtlKukoCd", mst042Form.getKhnDtlKukoCd().getValue());
        // 仕向地存在チェック
        params.put("khnDtlShimukeChi", mst042Form.getKhnDtlShimukeChi().getValue());
        // 送り状発行営業所存在チェック
        if (mst042Form.getKnrDtlOkurijoHakkoEigyoshoCd() != null) {
            params.put("knrDtlOkurijoHakkoEigyoshoCd", mst042Form.getKnrDtlOkurijoHakkoEigyoshoCd().getValue());
        }
        // 銀行口座存在チェック
        if (mst042Form.getKzaDtlGinkoKozaCd() != null) {
            params.put("kzaDtlGinkoKozaCd", mst042Form.getKzaDtlGinkoKozaCd().getValue());
        }
        // 仕立営業所コード存在チェック
        if (mst042Form.getOrsDtlShitateEigyoshoCd() != null) {
            params.put("orsDtlShitateEigyoshoCd", mst042Form.getOrsDtlShitateEigyoshoCd().getValue());
        }
        // チェック対象：営業所グループ情報リスト
        params.put("egrpList", egrpList);
        // チェック対象：卸単価情報リスト
        params.put("orsList", orsList);
        // DBをアクセス
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, FUNC_CODE_INSERT_UPDATE_CHECK);
        // エラーの場合、処理を終了
        if (serviceInterfaceBean != null && serviceInterfaceBean.getStatusCode()
                == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            String[] tableNames = serviceInterfaceBean.getTableName().split(",");
            messagePropertyBean.message(serviceInterfaceBean.getMessages().get(0)[0],
                    serviceInterfaceBean.getMessages().get(0)[1],
                    serviceInterfaceBean.getMessages().get(0)[2],
                    tableNames[0]);
            return serviceInterfaceBean.getStatusCode();
        }
        
        return 1;
    }

    /**
     * 業務削除処理
     *
     * @param id 営業所グループ情報／卸単価情報フラグ
     * @param recordList レコードリスト
     * @return 正常／異常
     */
    public Boolean delRows(String id, List<Map<String, Object>> recordList) {

        // 削除処理
        pageCommonBean.getDatasLists().get(id).removeAll(recordList);
        // 営業所グループ情報_削除一覧リスト
        if (CheckUtils.isEqual(id, DATA_EGRPTABLE_ID)) {
            for (Map<String, Object> rec : mst042Form.getListEgrpDtlSelectedResult()) {
                // 営業所グループ情報.カレント行 = 登録対象
                if (rec.get(StndConsIF.CONST_ADD_ROW_KEY) == null) {
                    // 削除対象
                    eigyoshoGroupDeleteIchiranList.add(rec);
                }
            }
        }
        
        // 卸単価情報_削除一覧リスト
        if (CheckUtils.isEqual(id, DATA_ORSTABLE_ID)) {
            for (Map<String, Object> rec : mst042Form.getListOrsDtlSelectedResult()) {
                // 営業所グループ情報.カレント行 = 登録対象
                if (rec.get(StndConsIF.CONST_ADD_ROW_KEY) == null) {
                    // 削除対象
                    eigyoshoOroshiTankaDeleteIchiranList.add(rec);
                }
            }
        }
        
        return true;
    }
    
    /**
     * 営業所マスタ情報取得する
     * 
     * @throws 異常
     * @return 検索結果
     */
    private Map<String, Object> getEigyoshoDetail() throws SystemException {

        // パラメータ設定
        Map<String, Object> params = new HashMap<>();

        // 営業所コード
        params.put("conEigyoshoCd", mst042Form.getConEigyoshoCd().getValue());
        // 適用開始日
        params.put("conTekiyoKaishibi", DateUtils.parseFmtYMD(mst042Form.getConTekiyoKaishibi()));
        // 適用名
        params.put("conTekiyoMei", mst042Form.getConTekiyoMei());
        // ワーク.起動モード区分
        params.put("modeKbn", mst042Form.getModeKbn());

        // DBをアクセス
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH);
        try {
            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> searchResult = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
            return searchResult;
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
    }
    
    /**
     * 最大桁数チェック
     *
     * @param value チェック対象
     * @param maxLength 最大入力桁数
     * @throws UnsupportedEncodingException 異常
     * @return チェック結果
     */
    private boolean maxSizeCheck(String value, int maxLength) throws UnsupportedEncodingException {

        return !(value != null && value.getBytes("UTF-8").length > maxLength);
    }
    
    /**
     * 行追加（営業所グループ情報）
     *
     * @param id 画面リストID
     * @param toLast listの下に追加するフラグ
     */
    public void addRow(String id, Boolean toLast) {

        // 営業所コード
        if (mst042Form.getConEigyoshoCd() == null) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0003, "営業所コード");
            return;
        }
        // 適用開始日
        if (CheckUtils.isEmpty(mst042Form.getConTekiyoKaishibi())) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0003, "適用開始日");
            return;
        }
        // 対象リスト取得
        List<Map<String, Object>> selectList = pageCommonBean.getDatasLists().get(id);
        if (selectList.isEmpty()) {
            toLast = true;
        }
        pageCommonBean.addRow(id, toLast);
        // 検索条件
        Map params = new HashMap<>();
        // 営業所コード
        params.put("eigyoshoCd", mst042Form.getConEigyoshoCd().getValue());
        // 適用開始日
        params.put("tekiyoKaishibi", mst042Form.getConTekiyoKaishibi());
        autoCompleteViewBean.getMsDatasWithParam(MsCnst.COM_GET_SUB_SOSHIKI_MEI, params, null);
        // サブ組織名リストを取得する
        if (mst042Form.getSubSoshikiMeiList() !=null && 
                mst042Form.getSubSoshikiMeiList().isEmpty()) {
            List<AutoCompOptionBean> subsoshiMeiBeanList = 
                autoCompleteViewBean.getValueLabelFromDB(MsCnst.COM_GET_SUB_SOSHIKI_MEI, params);
            // サブ組織名リストが存在の場合
            if (subsoshiMeiBeanList != null && subsoshiMeiBeanList.size() > 0) {

                // サブ組織名リストの件数分繰り返す。
                for (AutoCompOptionBean subsoshiMeiBean : subsoshiMeiBeanList) {
                    // ワーク.サブ組織名リストを設定する
                    subSoshikiMeiList.add(
                        StrUtils.defaultString(subsoshiMeiBean.getValue()).concat(" ").concat(
                                StrUtils.defaultString(subsoshiMeiBean.getLabel())));
                    subSoshikiList.add(StrUtils.defaultString(subsoshiMeiBean.getLabel()));
                }
            }
            // ワーク.サブ組織名リスト
            mst042Form.setSubSoshikiMeiList(subSoshikiMeiList);  
        }
            
    }
}