/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import jp.co.kintetsuls.forms.mst.Mst471Form;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Level;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.AddrAutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.KbnBean;
import jp.co.kintetsuls.beans.common.LabelValueBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.kintetsuls.utils.DateUtils;
import jp.co.kintetsuls.utils.StrUtils;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 号車マスタ 画面
 *
 * @author 徐有川 (MBP)
 * @version 2019/1/28 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst471")
@ViewScoped
@Data
public class Mst471Bean extends AbstractBean {

    /**
     * タイトル
     */
    private final String titleName = "号車マスタ一覧";
    
    /**
     * パンくず名とCSVタイトル
     */
    private final String TITLE = "号車マスタ";

    private final String goshaShikuTitle = "号車仕向地設定ダイアログ";
    
    /**
     * 画面URL
     */
    private String url;
    
    /**
     * 号車項目マスタ
     */
    private List<Map<String, Object>> searchResult;

    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;
    
    /**
     * 共通页面(自动补全)
     */
    @ManagedProperty(value = "#{addrAutoCompleteViewBean}")
    private AddrAutoCompleteViewBean addrAutoCompleteViewBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

    /**
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    /**
     * ファイルダウンロード
     */
    @ManagedProperty(value = "#{fileBean}")
    private FileBean fileBean;

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;

    /**
     * 画面項目保持
     */
    @ManagedProperty(value = "#{mst471Form}")
    private Mst471Form mst471Form;
    
    /**
     * E2コード定義取得Bean
     */
    @ManagedProperty(value = "#{kbnBean}")
    private KbnBean kbnBean;

    /**
     * 共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * 共通作業
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;
    /**
     * 履歴一覧処理共通
     */
    @ManagedProperty(value = "#{rirekisyosai}")
    private RirekiSyosaiBean rirekiSyosaiBean;

    /**
     * 一覧単項目チェック共通
     */
    @ManagedProperty(value = "#{listCheckBean}")
    private ListCheckBean listCheckBean;
    
    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(
            new Object() {}.getClass().getEnclosingClass().getName());

    /**
     * 履歴テーブル検索キー
     */
    private Map<String, Object> rirekiSearchKey;
    
    /**
     * ScreenCode：MST471
     */
    private static final String SC_CD_MST471 = "MST471_SCREEN";

    @ManagedProperty(value = "#{labelValueBean}")
    private LabelValueBean labelValueBean;

    /**
     * 定数：登録の重複チェックファンクションコード
     */
    private static final String FUNC_CODE_INSERT_UPDATE_CHECK = "mst471-insert-update-check";
    
        /**
     * 定数：登録の重複チェックFUNC_CODE.
     */
    private static final String FUNC_CODE_INSERT_DUPLICATED = "mst471-insert-duplicated-kensu";

    /**
     * 定数：登録の 存在チェックFUNC_CODE.
     */
    private static final String FUNC_CODE_INSERT_TEKIYOSHURYOBI_EXIST = "mst471-insert-tekiyoshuryobi-exist";

    /**
     * 定数：登録の 存在チェックFUNC_CODE.
     */
    private static final String FUNC_CODE_UPDATE_TEKIYOSHURYOBI_EXIST = "mst471-update-tekiyoshuryobi-exist";

    /**
     * 定数：更新の存在チェックFUNC_CODE.
     */
    private static final String FUNC_CODE_UPDATE_EXIST = "mst471-update-exist";

    /**
     * 定数：検索件数取得FUNC_CODE.
     */
    private static final String FUNC_CODE_SEARCH_KENSU = "mst471-get-gosha-kensu";

    /**
     * 定数：検索FUNC_CODE.
     */
    private static final String FUNC_CODE_SEARCH = "mst471-get-gosha-detail";

    /**
     * 定数：号車マスタ登録更新FUNC_CODE.
     */
    private static final String FUNC_CODE_INSERT_UPDATE = "mst471-insertupdate-gosha";

    /**
     * 定数：削除の存在チェックファンクションコード
     */
    private static final String FUNC_CODE_DELETE_EXIST = "mst471-delete-exist";
    
    /**
     * 定数：行削除FUNC_CODE.
     */
    private static final String FUNC_CODE_DELETE_ROW = "mst471-delete-row-detail";

    /**
     * 定数：号車仕向地 削除FUNC_CODE.
     */
    private static final String FUNC_CODE_UPDATEDELETE = "mst471-updatedelete-shimuke-detail";

    /**
     * 定数：検索 号車仕向地 FUNC_CODE.
     */
    private static final String FUNC_CODE_GOSHASHIMUKECHI = "mst471-get-goshashimuke-detail";
     /**
     * 定数：Add 号車仕向地 FUNC_CODE.
     */
    private static final String FUNC_CODE_SHIMUKECHI_INSERT = "mst471-shimukechi-insert";
    /**
     * 定数：Add 号車仕向地件数 FUNC_CODE.
     */
    private static final String FUNC_CODE_SHIMUKECHI_COUNT = "mst471-shimukechimei-count";

    /**
     * 定数：一覧のDataTableのID.
     */
    private static final String DATA_TABLE_ID = "tablesorter_mst471";

    /**
     * 定数：仕向地名マスタ 一覧のDataTableのID.
     */
    private static final String DATA_TABLESHIMUKE_ID = "tablesorterShimuke_mst471";

    /**
     * 定数：画面項目保持key.
     */
    private static final String CONST_MST471_FORM = "mst471Form";

    /**
     * 定数：MasterInfo取得key.
     */
    private static final String CONST_MST471_MASTER = "mst471";

    /**
     * 定数：再検索Button取得キー
     */
    private static final String CONST_MST471_SEARCH = "search_mst471"; 
    
    /**
     * マスタ情報.
     */
    private MasterInfoBean masterInfo;

    /**
     * ワーク.メッセージリスト.
     */
    List<MessageModuleBean> msgList = new ArrayList<>();

    /**
     * コンストラクタ
     */
    public Mst471Bean() {

    }

    /**
     * 号車マスタ 初期処理（処理）
     *
     * @param menuId
     * @param prevScreen
     * @param backFlag
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            // パンくず追加
            breadBean.push(TITLE, SCREEN.MST471_SCREEN.name(), this);

            // マスタ内容取得
            pageCommonBean.getMasterInfo(CONST_MST471_MASTER);
            // 検索シーケンス処理を初期化する
            searchHelpBean.regSearchHelp(DATA_TABLE_ID,
                    s -> {return getRecordCount(false);},
                    s -> {search(); return null;},
                    s -> {return checkParamas();});
            searchHelpBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);

            // AutoCompleteを初期化する
            //営業所取得
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO, new AutoCompOptionBean("全て", "all"));
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO);
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(ハンディ持参区分)
            autoCompleteViewBean.getMsKbn(MsCnst.HANDY_JISAN_KBN);
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(車両リスト)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_SHARYO);
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(ドライバーリスト)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_DRIVER);
            
            // 前回の記録をクリアする
            this.clear();
            mst471Form.setSearchResult(null);
            mst471Form.setSearchResultSelectable(null);
            mst471Form.setSelectedSearchResult(null);
            
            // 戻ってきた場合
            Mst471Form preForm = (Mst471Form) pageCommonBean.getPageInfo(CONST_MST471_FORM);
            if (backFlag && preForm != null) {
                PageCommonBean.simpleCopy(preForm, mst471Form);
                // 再検索を実施する
                pageCommonBean.searchAgain(CONST_MST471_SEARCH);
            } else {
                // 進んできた場合
                Flash flash = pageCommonBean.getPageParam();
                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_MST471_FORM) != null) {
                    PageCommonBean.simpleCopy(flash.get(CONST_MST471_FORM), mst471Form);
                    // 再検索を実施する
                    pageCommonBean.searchAgain(CONST_MST471_SEARCH);
                }
            }

            // ダウンロードシーケンス初期化
            fileBean.setDataSize(DATA_TABLE_ID, 
                    (id -> {return getRecordCount(true);}));
            
            fileBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);
            
            fileBean.setSubFlg(false);
            
            fileBean.setTilte(titleName);
            
            fileBean.regDownloadFucntion(DATA_TABLE_ID, getHeader(), 
                    (id -> {return getGoshaList(true);}));
            
            fileBean.setSearchResult(DATA_TABLE_ID, 
                    (id -> {return getSearchResult();})); 
            
            fileBean.regBeforeDownFucntion(DATA_TABLE_ID, 
                    (comment -> {return beforeDown(comment);}));

            // 行削除するため登録
            pageCommonBean.regDelFucntion(DATA_TABLE_ID,
                    (dataList -> (this.delRows(dataList))));

            // component初期化とユーザ権限により制御設定
            pageCommonBean.setAuthControll(mst471Form, SC_CD_MST471, true);

            mst471Form.setConDisabled(false);
            // 初期はデータを編集不可にする
            mst471Form.setBtnEditeDisabled(true);
            // 市区町村の場合、市区町村コードを初期表示する
            autoCompleteViewBean.initAddr("jisCd", "01001");
            // 仕向地リスト
            autoCompleteViewBean.initAddr2("shimukechiCd", "0100101");
            // 世代検索条件:"現在適用"にチェック
            mst471Form.setConSedaiKensakuJoken(new String[]{
            kbnBean.getKbnCdOfKeyCd(MsCnst.SEDAI_KENSAKU_JOKEN_GENZAI_TEKIYO),
            kbnBean.getKbnCdOfKeyCd(MsCnst.SEDAI_KENSAKU_JOKEN_MIRAI_TEKIYO)});
            
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * 検索パラメータチェック
     * 
     * @return チェックの結果
     */
    public String checkParamas() {
        
        if (mst471Form.getConSedaiKensakuJoken() != null && mst471Form.getConSedaiKensakuJoken().length > 0) {
            // 世代検索条件で適用日指定が選択されている場合
            if (kbnBean.getKbnCdOfKeyCd(MsCnst.SEDAI_KENSAKU_JOKEN_TEKIYO_HI_SHITEI).equals(
                    mst471Form.getConSedaiKensakuJoken()[mst471Form.getConSedaiKensakuJoken().length - 1])) {
                
                if (mst471Form.getConTekiyoBi() == null) {
                    messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0028,
                        "searchForm:sk:skc:sedaiKensaku_sedaiKensakuCalendar",
                        "適用日指定", "適用日");
                    return "FALSE";
                }
            }
        }
        return "TRUE";
    }
    
    /**
     * カウント処理
     *
     * @param downloadFlg ダウンロードフラグ
     * @return 取得件数
     */
     public Long getRecordCount(boolean downloadFlg) {
         
        // 前回の記録をクリアする
        Map<String, Object> mapRec = new LinkedHashMap();
        mapRec.put(StndConsIF.CONST_ZERO_STRING, true);
        List<Map<String, Object>> mapList = new ArrayList();
        mapList.add(mapRec);
        // Formに設定
        mst471Form.setSearchResult(mapList);
        mst471Form.setSearchResultSelectable(new ReportListDataModel(mst471Form.getSearchResult()));
        mst471Form.setSelectedSearchResult(null);
        
        // 検索初期はデータを編集不可にする
        mst471Form.setBtnEditeDisabled(true);
        
        // レコード件数を取得する
        long recordCount = getShimukeListCount(downloadFlg);
        
        // サブ検索条件フラグ設定
        fileBean.setSubFlg(subSearchConHad());
        
        if (!downloadFlg) {

            // 検索部のステータスを変更する
            mst471Form.setConDisabled(true);

            // 参照モードにする
            pageCommonBean.setEditFlg(false);

            // 検索条件保存
            pageCommonBean.savePageInfo(CONST_MST471_FORM, mst471Form);
        }
        
        return recordCount;
    }

     /**
     * サブ検索条件入力判断
     * 
     * @return true:入力あり/false:入力しない
     */
    private boolean subSearchConHad() {
        
        // 適用名
        if (!CheckUtils.isEmpty(mst471Form.getConTekiyoMei())) {
            return true;
        }
        return false;
    }
    
    /**
     * 号車マスタ 検索処理 OK
     */
    public void search() {
        // エラーメッセージを格納する変数を初期化する
        msgList = new ArrayList<>();
        
        // ログインユーザーの所属営業所リストを取得する。
        boolean checkFlag = false;

        //「適用日指定」を選択されて、「適用日」はnull
        if (mst471Form.getConSedaiKensakuJoken().length == 1 && "05".equals(mst471Form.getConSedaiKensakuJoken()[0])) {
            if (mst471Form.getConTekiyoBi() == null) {
                MessageModuleBean message = messagePropertyBean.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0028, "適用日指定", "適用日");
                msgList.add(message);
                checkFlag = true;
            }
        }
        
        // エラー判定
        if (checkFlag) {
            // エラーメッセージ
            messagePropertyBean.messageList(msgList);
            // clear エラーメッセージ
            msgList.clear();
            return;
        }
        // 号車マスタ検索し、取得した値を画面項目にセット
        List<Map<String, Object>> res = getGoshaList(false);
        
        fileBean.setDataList(res);
        
        // 取得した値を画面項目にセット
        mst471Form.setSearchResult(res);
        pageCommonBean.setDatalist(DATA_TABLE_ID, res);
        // 検索値をFormに設定
        try {
            mst471Form.setSearchResultSelectable(new ReportListDataModel(res));
        } catch (Exception e) {
            java.util.logging.Logger.getLogger(Mst471Bean.class.getName()).log(Level.SEVERE, null, e);
        }

	// 検索部のステータスを変更する
        pageCommonBean.setSerchConDisabled(mst471Form);
        
        // 削除済のみのチェック状態より、明細データを編集可／不可にする
        if (mst471Form.getConSakujoNomiKensaku()== null || mst471Form.getConSakujoNomiKensaku().length == 0) {
            // 有効データを編集可にする
            mst471Form.setBtnEditeDisabled(false);
        } else {
            // 削除済みデータを編集不可にする
            mst471Form.setBtnEditeDisabled(true);
        }
       
        // 検索条件保存
        pageCommonBean.savePageInfo(CONST_MST471_FORM, mst471Form);
        
        // 参照モードにする
        pageCommonBean.setEditFlg(false);
    }

    /**
     * 検索条件変更処理 検索部のステータス変更
     */
    public void searchChange()  {
        
        // 検索部のステータスを変更する
        pageCommonBean.setSerchConEnabled(mst471Form);
    }

    /**
     * クリア処理
     */
    public void clear() {
        // 検索部の条件クリア
        mst471Form.setConEigyoshoCd(null);
        mst471Form.setConEigyoshoMei(null);
        mst471Form.setConGoshaCd(null);
        mst471Form.setConGoshaMei(null);
        mst471Form.setConSharyoNo(null);
        mst471Form.setConSharyoMei(null);
        mst471Form.setConDriverCd(null);
        mst471Form.setConDriverMei(null);
        mst471Form.setConSedaiKensakuJoken(new String[]{
        kbnBean.getKbnCdOfKeyCd(MsCnst.SEDAI_KENSAKU_JOKEN_GENZAI_TEKIYO),
        kbnBean.getKbnCdOfKeyCd(MsCnst.SEDAI_KENSAKU_JOKEN_MIRAI_TEKIYO)});
        mst471Form.setConTekiyoBi(null);
        mst471Form.setConSakujoNomiKensaku(null);
        mst471Form.setConTekiyoMei(null);
        
        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mst471Form);
        pageCommonBean.setBtnSearchChangeVisible(false);
        pageCommonBean.setBtnSearchVisible(Boolean.TRUE);
    }

    /**
     * 適用終了日 chenckbox 選択 処理
     * 
     */
    public void tekiyoShuryoBiChk() {
        
        //選択した行データ
        List<Map<String, Object>> selectedSearchResult = mst471Form.getSelectedSearchResult();
        //遍歴 データを選択する
        for (int i = 0; i < selectedSearchResult.size(); i++) {
            //checkbox  選択する
            if (selectedSearchResult.get(i).get("listTekiyoShuryoBiChk").equals(true))  {
                //カレンダー框可編集
                mst471Form.setListTekiyoShuryoBiDisabled(false);
                
            //checkbox  不選択する
            } else {
                //カレンダー框不可編集
                mst471Form.setListTekiyoShuryoBiDisabled(true);
                selectedSearchResult.get(i).replace("listTekiyoShuryoBiText", null);
            }
        }
    }

    /**
     * 号車、号車仕向地 マスタ 更新処理
     *
     */
    public void update() {
        // エラーメッセージを格納する変数を初期化する
        msgList = new ArrayList<>();
        MessageModuleBean message = null;
        boolean checkFlag = false;
        
        // 行選択チェックを行う
        if (mst471Form.getSelectedSearchResult() == null || mst471Form.getSelectedSearchResult().isEmpty()) {

            message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
            msgList.add(message);

            messagePropertyBean.messageList(msgList);
            return;
        }

        // 適用終了日を判定
        for (int i = 0; i < mst471Form.getSelectedSearchResult().size(); i++) {
            
            // 営業所コード
            if (!mst471Form.getSelectedSearchResult().get(i).containsKey("listEigyoshoCd")) {
                mst471Form.getSelectedSearchResult().get(i).put("listEigyoshoCd", mst471Form.getConEigyoshoCd().getValue());
            }
            
            // 終了チェック 適用終了日が入力済みの場合
            if (!Boolean.valueOf(StrUtils.defaultString(mst471Form.getSelectedSearchResult().get(i).get("listTekiyoShuryoBiChk")))) {
                if (!CheckUtils.isEmpty(StrUtils.defaultString(mst471Form.getSelectedSearchResult().get(i).get("listTekiyoShuryoBiText")))) {
                    message = messagePropertyBean.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0048, "適用終了日");
                    msgList.add(message);
                    checkFlag = true;
                }
            }
                
            // 適用終了日(チェックボックスを選択した)、必須チェック
            if (CheckUtils.isEmpty(StrUtils.defaultString(mst471Form.getSelectedSearchResult().get(i).get("listTekiyoShuryoBiText")))) {
                if (Boolean.valueOf(StrUtils.defaultString(mst471Form.getSelectedSearchResult().get(i).get("listTekiyoShuryoBiChk")))) {
                    message = messagePropertyBean.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0041, "適用終了日");
                    msgList.add(message);
                    checkFlag = true;
                }
            }
            // 適用終了日が適用開始日より過去
            try {
                if (mst471Form.getSelectedSearchResult().get(i).containsKey("addFlg")) {
                    if (!CheckUtils.isEmpty(StrUtils.defaultString(mst471Form.getSelectedSearchResult().get(i).get("listTekiyoShuryoBiText")))) {
                        if (!CheckUtils.isEmpty(StrUtils.defaultString(mst471Form.getSelectedSearchResult().get(i).get("listTekiyoKaishiBi")))) {
                            if (CheckUtils.isLessThan(DateUtils.parse(StrUtils.defaultString(mst471Form.getSelectedSearchResult().get(i).get("listTekiyoShuryoBiText")), "EEE MMM dd HH:mm:ss z yyyy", Locale.US),
                                    DateUtils.parse(StrUtils.defaultString(mst471Form.getSelectedSearchResult().get(i).get("listTekiyoKaishiBi")), "EEE MMM dd HH:mm:ss z yyyy", Locale.US))) {
                                message = messagePropertyBean.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0053, "適用終了日", "適用開始日");
                                msgList.add(message);
                                checkFlag = true;
                            }
                        }
                    }
                } else {
                    if (!CheckUtils.isEmpty(StrUtils.defaultString(mst471Form.getSelectedSearchResult().get(i).get("listTekiyoShuryoBiText")))) {
                        if (!CheckUtils.isEmpty(StrUtils.defaultString(mst471Form.getSelectedSearchResult().get(i).get("listTekiyoKaishiBi")))) {
                            if (CheckUtils.isLessThan(DateUtils.parse(StrUtils.defaultString(mst471Form.getSelectedSearchResult().get(i).get("listTekiyoShuryoBiText")), "EEE MMM dd HH:mm:ss z yyyy", Locale.US),
                                    DateUtils.parse(StrUtils.defaultString(mst471Form.getSelectedSearchResult().get(i).get("listTekiyoKaishiBi")), StndConsIF.DF_YYYY_MM_DD))) {
                                message = messagePropertyBean.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0053, "適用終了日", "適用開始日");
                                msgList.add(message);
                                checkFlag = true;
                            }
                        }
                    }
                }
            } catch (SystemException ex) {
                java.util.logging.Logger.getLogger(Mst471Bean.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        // エラー判定
        if (checkFlag) {
            // エラーメッセージ
            messagePropertyBean.messageList(msgList);
            // clear エラーメッセージ
            msgList.clear();
            return;
        }
        
        // 単項目チェック処理
        if (!checkJsfParamas(mst471Form.getSelectedSearchResult())) {
            return;
        }
        
        // 登録一覧リストの初期化を行う
        List<Map<String, Object>> torokuIchiranList = new ArrayList();
        // 更新一覧リストの初期化を行う
        List<Map<String, Object>> koshinIchiranList = new ArrayList();
        
        // 登録更新情報設定処理
        for (Map<String, Object> rec : mst471Form.getSelectedSearchResult()) {
            // 仕向地名マスタ一覧.カレント行 = 登録対象
            if (rec.get(StndConsIF.CONST_ADD_ROW_KEY) != null) {
                torokuIchiranList.add(rec);
            } else {
                koshinIchiranList.add(rec);
            }
        }
        
        // 登録一覧リストの登録処理
        if (torokuIchiranList.size() > 0 || koshinIchiranList.size() > 0) {
            int status = insertShimukeList(torokuIchiranList, koshinIchiranList);
            if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
                return;
            }
        }
        
        // 登録・更新処理を行う
        int status = insertUpdateGoshaShiku();
        
        // エラーの場合、処理終了
        if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            return;
        }
        
        // 登録の後に再度検索する
        this.search();
        
         // 一覧の配色定義をなくす
        pageCommonBean.resetIchiranColColor(mst471Form.getSelectedSearchResult());

        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0007, "更新");
        
        // ログ出力を行う
        LOGGER.info("更新 " + mst471Form.getSelectedSearchResult().size() + " 件");
    }

    /**
     * DBへ号車マスタ、号車仕向地 マスタを登録する
     */
    private int insertShimukeList(List<Map<String, Object>> torokuIchiranList, List<Map<String, Object>> koshinIchiranList) {

        Map<String, Object> params = new HashMap<>();
        // 重複チェック
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(torokuIchiranList, FUNC_CODE_INSERT_DUPLICATED);
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            messagePropertyBean.message(res.getMessages().get(0)[0], res.getMessages().get(0)[1], res.getMessages().get(0)[2], "号車マスタ");
            return res.getStatusCode();
        }

        // 適用終了チェック（登録）
        res = pageCommonBean.accsessDBWithList(torokuIchiranList, FUNC_CODE_INSERT_TEKIYOSHURYOBI_EXIST);
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            messagePropertyBean.message(res.getMessages().get(0)[0], res.getMessages().get(0)[1], res.getMessages().get(0)[2], "適用終了日");
            return res.getStatusCode();
        }

        // 存在チェック
        res = pageCommonBean.accsessDBWithList(koshinIchiranList, FUNC_CODE_UPDATE_EXIST);
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            messagePropertyBean.message(res.getMessages().get(0)[0], res.getMessages().get(0)[1], res.getMessages().get(0)[2], "号車マスタ");
            return res.getStatusCode();
        }

        // 適用終了チェック（更新）
        res = pageCommonBean.accsessDBWithList(koshinIchiranList, FUNC_CODE_UPDATE_TEKIYOSHURYOBI_EXIST);
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            messagePropertyBean.message(res.getMessages().get(0)[0], res.getMessages().get(0)[1], res.getMessages().get(0)[2], "適用終了日");
            return res.getStatusCode();
        }

        //仕向地登録一覧リストの初期化を行う
        List<Map<String, Object>> shimukechiTorokuIchiranList = mst471Form.getGdShimukechiList();
        //号車マスタ
        params.put("torokuIchiranList", mst471Form.getSelectedSearchResult());
        //号車仕向地マスタ
        params.put("shimukechiTorokuIchiranList", shimukechiTorokuIchiranList);

        // 登録一覧リストの内容で新規登録する
        ServiceInterfaceBean req = new ServiceInterfaceBean();
        req.setFunctionCode(FUNC_CODE_INSERT_UPDATE);
        res = pageCommonBean.getDBInfo(params, FUNC_CODE_INSERT_UPDATE);

        return res.getStatusCode();
    }
    
    /**
     * 一覧の単項目チェック処理
     * 
     * @param params 画面一覧パラメータ
     * @return チェックの結果
     */
    private boolean checkJsfParamas(List<Map<String, Object>> params) {

        List<ListCheckBean> checks = new ArrayList<>();
        // 号車コード
        checks.add(new ListCheckBean("listGoshaCd", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "号車コード"));
        // 号車名
        checks.add(new ListCheckBean("listGoshaMei", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "号車名"));
        // 適用開始日
        checks.add(new ListCheckBean("listTekiyoKaishiBi",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "適用開始日"));
        // 適用終了日
        checks.add(new ListCheckBean("listTekiyoShuryoBiText",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "適用終了日"));
        // 車両NO
        checks.add(new ListCheckBean("listSharyoNo",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "車両NO"));
        // ドライバーコード
        checks.add(new ListCheckBean("listDriverCd",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "ドライバーコード"));
        // 適用名
        checks.add(new ListCheckBean("listTekiyoMei",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "適用名"));
        // 桁数をチェック
        checks.add(new ListCheckBean("listGoshaCd",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "号車コード", "5"));
        checks.add(new ListCheckBean("listGoshaMei",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "号車名", "40"));
        checks.add(new ListCheckBean("listKaishiJisJusho",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "開始住所", "160"));
        checks.add(new ListCheckBean("listShuryoJisJusho",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "終了住所", "160"));
        checks.add(new ListCheckBean("listTekiyoMei",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "適用名", "40"));
        List<MessageModuleBean> checkMsgList = listCheckBean.check(params, checks, true);
        // エラーメッセージ
        if (!checkMsgList.isEmpty()) {
            return false;
        }
        return true;
    }
    
    /**
     *号車仕向地 マスタ 更新処理
     * 
     * @return
     */
    private int insertUpdateGoshaShiku() {
        
        // 重複、存在チェック
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.accsessDBWithList(
                mst471Form.getSelectedSearchResult(), FUNC_CODE_INSERT_UPDATE_CHECK);

        // エラーの場合、処理を終了
        if (serviceInterfaceBean.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            messagePropertyBean.message(serviceInterfaceBean.getMessages().get(0)[0],
                    serviceInterfaceBean.getMessages().get(0)[1],
                    serviceInterfaceBean.getMessages().get(0)[2],
                    serviceInterfaceBean.getTableName());
            return serviceInterfaceBean.getStatusCode();
        }
        
        // 登録一覧リストと更新一覧リストの内容を処理する
        serviceInterfaceBean = pageCommonBean.accsessDBWithList(
                mst471Form.getSelectedSearchResult(), FUNC_CODE_INSERT_UPDATE);
        // ステータスコードを戻り
        return serviceInterfaceBean.getStatusCode();
    }
    
    /**
     * 更新履歴を表示処理
     *
     */
    public void rirekiIchiran() {

        // 履歴テーブル検索キーを設定する
        rirekiSearchKey = new HashMap();
        
        // 選択されたレコードを取得する
        Map<String, Object> selectedRecord = mst471Form.getSelectedSearchResult().get(0);
        //号車コード
        rirekiSearchKey.put("listGoshaCd", selectedRecord.get("listGoshaCd"));
        //営業所コード
        rirekiSearchKey.put("listEigyoshoCd", selectedRecord.get("listEigyoshoCd"));
        //適用日
        rirekiSearchKey.put("listTekiyoKaishiBi", selectedRecord.get("listTekiyoKaishiBi"));

        // 履歴タイトルを設定する
        rirekiSyosaiBean.setListColName(
                new ArrayList<>(Arrays.asList(
                        "号車コード", "号車名", "適用開始日", "適用終了日", "車両No", 
                        "車両名", "ドライバーコード", "ドライバー名", "開始住所JISコード", 
                        "開始住所", "終了住所JISコード", "終了住所", "ハンディ持参区分", 
                        "仕向地設定件数", "適用名")));
        
        // 履歴beanの項目物理名を設定する
        rirekiSyosaiBean.setListColValue(
                new ArrayList<>(Arrays.asList(
                        "listGoshaCd", "listGoshaMei", "listTekiyoKaishiBi", "listTekiyoShuryoBiTextTab", "listSharyoNo", 
                        "listSharyoMei", "listDriverCd", "listDriverMei", "listKaishiJisCd", 
                        "listKaishiJisJusho", "listShuryoJisCd", "listShuryoJisJusho", "listHandyJisanKbnMei", 
                        "listShimukechiSetteiKensu", "listTekiyoMei")));
        
        // 履歴テーブルを検索する
        rirekiSyosaiBean.searchList("2", "MST471_SEARCH_RIREKI", rirekiSearchKey);
    }
    
    /**
     * 業務削除処理ファンクション領域
     *
     */
    public void delRowsFunc() {
        // エラーメッセージを格納する変数を初期化する
        msgList = new ArrayList<>();

        // 行選択チェック
        if (mst471Form.getSelectedSearchResult().isEmpty()) {
            MessageModuleBean message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0013);
            msgList.add(message);
        }
        
        if (!msgList.isEmpty()) {
            messagePropertyBean.messageList(msgList);
            return;
        }
        // 共通関数実行
        pageCommonBean.getSelectedDatasList().put(DATA_TABLE_ID, mst471Form.getSelectedSearchResult());
        pageCommonBean.delRows(DATA_TABLE_ID);
    }

    /**
     * 号車マスタ 業務削除処理
     *
     * @param recordList
     * @return
     */
    public boolean delRows(List<Map<String, Object>> recordList) {
        // エラーメッセージを格納する変数を初期化する
        msgList = new ArrayList<>();
        
        // 存在チェック
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(recordList,
                FUNC_CODE_DELETE_EXIST);
        
        // エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {

            MessageModuleBean message = messagePropertyBean.createMessageModule(
                    res.getMessages().get(0)[0],
                    res.getMessages().get(0)[1],
                    res.getMessages().get(0)[2],
                    "号車マスタ");
            msgList.add(message);
            messagePropertyBean.messageList(msgList);
            return false;
        }
        
        // 削除処理を行う
        int status = deleteGoshaShiku(recordList);
        
        // エラーの場合、処理を終了
        if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            return false;
        }

        try {
            // 画面レコード削除
             mst471Form.getSearchResult().removeAll(recordList);
        } catch (Exception e) {
            java.util.logging.Logger.getLogger(Mst291Bean.class.getName()).log(Level.SEVERE, null, e);
        }
        
        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, "削除");
        
        // ログ出力
        LOGGER.info("削除 " + recordList.size() + " 件");
        
        return true;
    }

    /**
     * DBから号車仕向地マスタ情報を削除する
     * 
     * @param recordList ダークリスト
     * @return ステータスコード     
     */
    private int deleteGoshaShiku(List<Map<String, Object>> recordList) {

        // 削除処理を行う、DBをアクセス
        ServiceInterfaceBean serviceInterfaceBean =
                pageCommonBean.accsessDBWithList(recordList, FUNC_CODE_DELETE_ROW);

        // ステータスコードを返却する
        return serviceInterfaceBean.getStatusCode();
    }   
    
    /**
     * 号車仕向地マスタ 更新処理
     *
     */
    public void updateShimukeRows() {
        
        // 行選択チェック
        if (mst471Form.getSelectedShimuSearchResult().isEmpty()) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0013);
        }else{
            List<Map<String, Object>> updParam = mst471Form.getSelectedShimuSearchResult();
            for (Map<String, Object> map : updParam) {
                map.put("conEigyoshoCd", mst471Form.getSimukechiEgyouCd());
                map.put("conGoshaCd", mst471Form.getSimukechiGoshaCd());
                map.put("conTekiyoKaishiBi", mst471Form.getSimukechiTeiKyouBi());
            }
            // DBをアクセス
            ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(updParam, FUNC_CODE_SHIMUKECHI_INSERT);
            // エラーの場合、処理を終了
            if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
                MessageModuleBean message = messagePropertyBean.createMessageModule(
                        res.getMessages().get(0)[0],
                        res.getMessages().get(0)[1],
                        res.getMessages().get(0)[2],
                        "号車仕向地マスタ");
                msgList.add(message);
                messagePropertyBean.messageList(msgList);
            }
        }
        // 号車仕向地再検索
        AutoCompOptionBean aco = autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO,mst471Form.getSimukechiEgyouCd());
        this.searchGoshaShimukechi(aco, mst471Form.getSimukechiGoshaCd(), mst471Form.getSimukechiTeiKyouBi());
        
    }

    /**
     * 号車仕向地マスタ 削除処理
     *
     */
    public void deleteShimukeRows() {
        // 削除実施
        deleteShimukeList();
    }

    /**
     * DBから仕向地名マスタ情報を削除する
     */
    private void deleteShimukeList() {
        // 行選択チェック
        if (mst471Form.getSelectedShimuSearchResult().isEmpty()) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0013);
            return;
        }
        
        List<Map<String, Object>> updParam = mst471Form.getSelectedShimuSearchResult();
        for (Map<String, Object> map : updParam) {
            map.put("conEigyoshoCd", mst471Form.getSimukechiEgyouCd());
            map.put("conGoshaCd", mst471Form.getSimukechiGoshaCd());
            map.put("conTekiyoKaishiBi", mst471Form.getSimukechiTeiKyouBi());
        }
        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(updParam, FUNC_CODE_UPDATEDELETE);
        // エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {

            MessageModuleBean message = messagePropertyBean.createMessageModule(
                    res.getMessages().get(0)[0],
                    res.getMessages().get(0)[1],
                    res.getMessages().get(0)[2],
                    "号車仕向地マスタ");
            msgList.add(message);
            messagePropertyBean.messageList(msgList);
        }
        // 号車仕向地再検索
        AutoCompOptionBean aco = autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO,mst471Form.getSimukechiEgyouCd());
        this.searchGoshaShimukechi(aco, mst471Form.getSimukechiGoshaCd(), mst471Form.getSimukechiTeiKyouBi());    }

    /**
     * DBから号車マスタ情報を取得する
     * @param downloadFlg ダウンロードフラグ
     */
    private List<Map<String, Object>> getGoshaList(boolean downloadFlg) {

        if (downloadFlg) {
            mst471Form = (Mst471Form)pageCommonBean.getPageInfo(CONST_MST471_FORM);
        }
        
        // パラメータ
        Map<String, Object> params = new HashMap<>();
        // 営業所コード 
        params.put("conEigyoshoCd", mst471Form.getConEigyoshoCd().getValue());
        // ログインユーザー所属営業所
        params.put("loginUserShozokuEigyosho", authConfBean.getLoginUserShozokuEigyosho());
        // 号車コード
        params.put("conGoshaCd", mst471Form.getConGoshaCd());
        // 号車名
        params.put("conGoshaMei", mst471Form.getConGoshaMei());
        //車両No
        if (mst471Form.getConSharyoNo() != null) {
            params.put("conSharyoNo", mst471Form.getConSharyoNo().getValue());
        } else {
            params.put("conSharyoNo", null);
        }
        //ドライバーコード
        if (mst471Form.getConDriverCd() != null) {
            params.put("conDriverCd", mst471Form.getConDriverCd().getValue());
        } else {
            params.put("conDriverCd", null);
        }
        //世代検索条件
        params.put("conSedaiKensakuJoken", getSedaiKensaku(mst471Form.getConSedaiKensakuJoken()));
        try {
            //適用日
            if (Arrays.asList(mst471Form.getConSedaiKensakuJoken()).contains("05")) {
                if (mst471Form.getConTekiyoBi() != null) {
                    params.put("conTekiyoBi", DateUtils.format(mst471Form.getConTekiyoBi(),  StndConsIF.DF_YYYY_MM_DD));
                } else {
                    params.put("conTekiyoBi", null);
                }
            }
        } catch (SystemException ex) {
            java.util.logging.Logger.getLogger(Mst471Bean.class.getName()).log(Level.SEVERE, null, ex);
        }
        // 削除済のみ
        params.put("conSakujoNomiKensaku", mst471Form.getConSakujoNomiKensaku());
        //適用名
        params.put("conTekiyoMei", mst471Form.getConTekiyoMei());

        try {
            // DBをアクセス
            ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH);
            ObjectMapper mapper = new ObjectMapper();
            this.searchResult = mapper.readValue(res.getJson(), List.class);

        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
        //JISコード初期化の設定
        for (Map<String, Object> record : searchResult) {
            // 開始住所
            Object listKaishiJisCdObj = record.get("listKaishiJisCd");
            String listKaishiJisCdStr = "";
             // コード取得
            if (listKaishiJisCdObj != null) {
                listKaishiJisCdStr = listKaishiJisCdObj.toString();
            }
            // 開始住所AutoComplete取得
            record.put("listKaishiJis",
                    autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_JIS_CD, listKaishiJisCdStr));
            // 終了住所
            Object listShuryoJisCdObj = record.get("listShuryoJisCd");
            String listShuryoJisCdStr = "";
            // コード取得
            if (listShuryoJisCdObj != null) {
                listShuryoJisCdStr = listShuryoJisCdObj.toString();
            }
            // 終了住所AutoComplete取得
            record.put("listShuryoJis",
                    autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_JIS_CD, listShuryoJisCdStr));
            // 仕向地件数の検索
            ServiceInterfaceBean resCount = pageCommonBean.getDBInfo(record, FUNC_CODE_SHIMUKECHI_COUNT);
            record.put("shimukechiList", resCount.getJson());
        }
        return this.searchResult;
    }

    /**
     * 設定ボタンをクリック、 仕向地名マスタを検索
     * @param listEigyoshoCd 営業所コード
     * @param listGoshaCd 号車コード
     * @param listTekiyoKaishiBi 適用開始日
     */
    public void searchGoshaShimukechi(AutoCompOptionBean listEigyoshoCd, String listGoshaCd, String listTekiyoKaishiBi) {

        // 仕向地名マスタ検索し、取得した値を画面項目にセット
        
        ServiceInterfaceBean req = new ServiceInterfaceBean();
        req.setFunctionCode(FUNC_CODE_GOSHASHIMUKECHI);

        //入力Param定義
        Map<String, Object> params = new HashMap<>();
        // 号車コード
        params.put("listGoshaCd", listGoshaCd);
        // 営業所コード
        params.put("listEigyoshoCd", listEigyoshoCd.getValue());
        // 適用開始日 
        params.put("listTekiyoKaishiBi", listTekiyoKaishiBi);
        
        // FormにSet
       // 仕向地営業所コード
        mst471Form.setSimukechiEgyouCd(params.get("listEigyoshoCd").toString());
        // 仕向地号車コード
        mst471Form.setSimukechiGoshaCd(params.get("listGoshaCd").toString());
        // 仕向地適用開始日 
        mst471Form.setSimukechiTeiKyouBi(params.get("listTekiyoKaishiBi").toString());
        AutoCompOptionBean simukechiGoshaMei = autoCompleteViewBean.getComMsDatas("COM_GET_VW_GOSHA",mst471Form.getSimukechiGoshaCd());
        // 仕向地号車名称
        mst471Form.setSimukechiGoshaMei(simukechiGoshaMei == null ? "" : simukechiGoshaMei.getLabel());
        
        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_GOSHASHIMUKECHI);
        try {
            ObjectMapper mapper = new ObjectMapper();
            this.searchResult = mapper.readValue(res.getJson(), List.class);
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
         
        //JISコード初期化の設定
        for (Map<String, Object> record : searchResult) {
            // 仕向地住所
            Object lisShimukechiCdObj = record.get("listShimukechiJisCd");
            String listShimukechiCdStr = "";
            // コード取得
            if (lisShimukechiCdObj != null) {
                listShimukechiCdStr = lisShimukechiCdObj.toString();
            }
            // 仕向地住所AutoComplete取得
            record.put("listShimukechiJis",autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_JIS_CD, listShimukechiCdStr));
           
        }
        
        // 仕向地の場合、仕向地コードを初期表示する
        mst471Form.setSearchResult(this.searchResult);
        pageCommonBean.setDatalist(DATA_TABLESHIMUKE_ID, this.searchResult);
        mst471Form.setSearchResultShimukechi(new ReportListDataModel(this.searchResult));

    }
   
    /**
     * 件数取得処理 データを取得する
     */
    private long getShimukeListCount(boolean downloadFlg) {

        if (downloadFlg) {
            mst471Form = (Mst471Form)pageCommonBean.getPageInfo(CONST_MST471_FORM);
        }
        
        // パラメータ
        Map<String, Object> params = new HashMap<>();
        // 営業所コード
        if (mst471Form.getConEigyoshoCd() != null) {
            params.put("conEigyoshoCd", mst471Form.getConEigyoshoCd().getValue());
        }
        // ログインユーザー所属営業所
        params.put("loginUserShozokuEigyosho", authConfBean.getLoginUserShozokuEigyosho());
        // 号車コード
        params.put("conGoshaCd", mst471Form.getConGoshaCd());
        // 号車名
        params.put("conGoshaMei", mst471Form.getConGoshaMei());
        //車両No
        if (mst471Form.getConSharyoNo() != null) {
            params.put("conSharyoNo", mst471Form.getConSharyoNo().getValue());
        } else {
            params.put("conSharyoNo", null);
        }
        //ドライバーコード
        if (mst471Form.getConDriverCd() != null) {
            params.put("conDriverCd", mst471Form.getConDriverCd().getValue());
        } else {
            params.put("conDriverCd", null);
        }
        //世代検索条件
        params.put("conSedaiKensakuJoken", getSedaiKensaku(mst471Form.getConSedaiKensakuJoken()));
        try {
            //適用日
            if (Arrays.asList(mst471Form.getConSedaiKensakuJoken()).contains("05")) {
                if (mst471Form.getConTekiyoBi() != null) {
                    params.put("conTekiyoBi", DateUtils.format(mst471Form.getConTekiyoBi(),  StndConsIF.DF_YYYY_MM_DD));
                } else {
                    params.put("conTekiyoBi", null);
                }
            }
        } catch (SystemException ex) {
            java.util.logging.Logger.getLogger(Mst471Bean.class.getName()).log(Level.SEVERE, null, ex);
        }
        // 削除済のみ
        params.put("conSakujoNomiKensaku", mst471Form.getConSakujoNomiKensaku());
        //適用名
        params.put("conTekiyoMei", mst471Form.getConTekiyoMei());
        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH_KENSU);

        return Long.valueOf(res.getJson());
    }

    /**
     * メニュークリック処理
     *
     * @param menuId // メニューID
     * @param nextScreenId // 遷移先画面ID
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreenId) {
        try {
            // パンくずを削除する
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移を行う
        url = forward(nextScreenId, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック（処理）
     *
     * @return
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        url = forward(nextScreen, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authConfBean.logout();
    }

    /**
     * 画面遷移処理（顧客マスタメンテナンス画面へ）
     *
     * @return
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     */
    public String buttonClick() throws IllegalAccessException, InvocationTargetException {

        // 画面遷移
        url = forward(SCREEN.CUS012_SCREEN.name(), null, SCREEN.CUS011_SCREEN.name(), false);
        return url;
    }

    /**
     * 画面タイトルを取得する処理
     * 
     * @return 画面タイトル
     */
    public String getTitleName() {
        return titleName;
    }

    public List<CSVDto> getHeader() {
        // CSVファイルのタイトルを設定
        List<CSVDto> header = new ArrayList<>();
        // 号車コード
        header.add(new CSVDto("号車コード", "listGoshaCd"));
        // 号車名
        header.add(new CSVDto("号車名", "listGoshaMei"));
        // 適用開始日
        header.add(new CSVDto("適用開始日", "listTekiyoKaishiBi"));
        // 適用終了日
        header.add(new CSVDto("適用終了日", "listTekiyoShuryoBiText"));
        // 車両No
        header.add(new CSVDto("車両No", "listSharyoNo"));
        // 車両名
        header.add(new CSVDto("車両名", "listSharyoMei"));
        // ドライバーコード
        header.add(new CSVDto("ドライバーコード", "listDriverCd"));
        // ドライバー名
        header.add(new CSVDto("ドライバー名", "listDriverMei"));
        // 開始住所JISコード
        header.add(new CSVDto("開始住所JISコード", "listKaishiJisCd"));
        // 開始住所
        header.add(new CSVDto("開始住所", "listKaishiJisJusho"));
        // 終了住所JISコード
        header.add(new CSVDto("終了住所JISコード", "listShuryoJisCd"));
        // 終了住所
        header.add(new CSVDto("終了住所", "listShuryoJisJusho"));
        // ハンディ持参区分
        header.add(new CSVDto("ハンディ持参区分", "listHandyJisanKbn"));
        // 仕向地設定
        header.add(new CSVDto("仕向地設定", "listShimukechiSettei"));
        // 適用名
        header.add(new CSVDto("適用名", "listTekiyoMei"));
        return header;
    }

    /**
     * @return the goshaShikuTitle
     */
    public String getGoshaShikuTitle() {
        return goshaShikuTitle;
    }

    /**
     * ダウンロードダイアログ
     *
     * @param comment
     * @return boolean
     * @throws Exception
     */
    public boolean beforeDown(String comment) throws Exception {
        System.out.println(comment);
        return true;
    }
    
    /**
     * 選択した世代検索を編集
     * @return 
     */
    private String[] getSedaiKensaku(String[] conSedaiKensakuJoken){
        // 世代検索値を定義
        String[] sedai = new String[5];
        for (int i = 1; i <= 5; i++) {
            //現在適用を選択
            if (Arrays.asList(conSedaiKensakuJoken).contains("0"+i)){
                // 選択した設定
                sedai[i-1] = "1";
            }else{
                sedai[i-1] = "0";
            }
        }
        return sedai;
    }
    
   /**
     * 一覧のAutoCompleteリスト選択した場合はLABELを対応項目に反映する
     *
     * @param list tableList
     * @param row 行番
     * @param colName 反映先項目
     * @param msCnst 取得する共通マスタ対象
     * @param value 選択した値
     */
   public void autoCompSelectForChange(List<Map<String, Object>> list,int row,String colName,String msCnst,String value) {
            list.get(row).put(colName, pageCommonBean.getLabelByValue(msCnst, value));
       
    }
        
    /**
     * 検索結果を取得する
     * 
     * @return 検索結果
     */
    private List<Map<String, Object>> getSearchResult() {
        return mst471Form.getSearchResult();
    }
    
    /**
     * 一覧のAutoCompleteリスト選択した場合はLABELを対応項目に反映する
     *
     * @param list tableList
     * @param row 行番
     * @param colCode 反映先項目Code
     * @param colName 反映先項目
     * @param jsyoName 住所名称
     * @param dtId 住所名称
     */
    public void setJiscdForList(List<Map<String, Object>> list, int row, String colCode, String colName,String jsyoName, String dtId) {
        
            // 画面IDを定義
            String hidName = "Listmst471:" + dtId + ":"+ row +":"+ colCode +"_hinput";
            // 画面値を取得
            String value = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get(hidName);
            String msCnst = "COM_GET_VW_JIS_CD";
            // 都道府県の判定
            if (!value.isEmpty() && value.length() == 2){
                msCnst = "COM_GET_MS_TODOFUKEN";
                // 都道府県AutoComplete再検索
                list.get(row).put(jsyoName,autoCompleteViewBean.getComMsDatas(msCnst, value));
            }
            // 選択した行の値を更新
            list.get(row).put(colCode, value);
            list.get(row).put(colName, pageCommonBean.getLabelByValue(msCnst, value));
            // 仕向地の場合、Jisコードを検索
            if ("listShimukechiJis".equals(jsyoName)){
                msCnst = "COM_GET_VW_JIS_CD";
                // 検索を繰り返し
                for (int i = 0; i < list.size(); i++) {
                    if (list.get(i).get(colCode) != null && list.get(i).get(colCode).toString().length() == 5){
                        list.get(i).put(jsyoName,autoCompleteViewBean.getComMsDatas(msCnst, list.get(i).get(colCode).toString()));
                    }
              }
            }
    }
}
