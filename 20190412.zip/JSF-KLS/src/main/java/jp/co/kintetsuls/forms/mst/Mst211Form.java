/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mst;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.annotation.MaxSizeCheck;
import jp.co.kintetsuls.beans.common.annotation.NotEmpty;
import jp.co.kintetsuls.beans.common.annotation.NotNull;
import lombok.Data;

/**
 * 車両マスタフォーム
 *
 * @author 許 彭戈ヤン (MBP)
 * @version 2019/01/20 新規作成
 */
@ManagedBean(name = "mst211Form")
@ViewScoped
@Data
public class Mst211Form implements Serializable {

    private static final long serialVersionUID = 1L;
    
    /**
     * 車種リスト
     */
    private Map<String, Object> shashu;

    /**
     * 営業所コード
     */
    @NotNull(name = "営業所")
    private AutoCompOptionBean conEigyoushoCd;

    /**
     * 世代検索条件
     */
    @NotEmpty(name = "世代検索条件")
    private String[] conSedaiKensakuJoken;

    /**
     * 適用日
     */
    @NotNull(message = "{COME0028}", checkTime = "適用日指定選択時", name = "適用日")
    private Date conTekiyoBi;

    /**
     * 検索条件保持用営業所コード
     */
    private String conEigyoushoCdHid;

    /**
     * 車両NO
     */
    @NotNull(name = "車両NO")
    @MaxSizeCheck(maxSize = 5, name = "車両NO")
    private String conSharyoNo;

    /**
     * 車両名称
     */
    @MaxSizeCheck(maxSize = 40, name = "車両名称")
    private String conSharyoMeisho;

    /**
     * 未使用期間(年)
     */
    @MaxSizeCheck(maxSize = 2, name = "未使用期間(年)")
    private String conMishiyoKikanNen;

    /**
     * 未使用期間(月)
     */
    @NotNull(name = "未使用期間(月)")
    @MaxSizeCheck(maxSize = 2, name = "未使用期間(月)")
    private String conMishiyoKikanGetu;

    /**
     * 適用名
     */
    @NotNull(name = "適用名")
    @MaxSizeCheck(maxSize = 40, name = "適用名")
    private String conTekiyoMei;

    /**
     * 削除のみ検索
     */
    private List<String> conSakujonomiKensaku;

    /**
     * 仕入先コード
     */
    private AutoCompOptionBean listShiiresakiCd;

    /**
     * 検索件数
     */
    private String count;

    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;

    /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;

    /**
     * 選択された結果
     */
    private List<Map<String, Object>> selectedSearchResult;

    /**
     * 営業所コードDisable
     */
    private boolean conEigyoushoCdDisabled;

    /**
     * 営業所名称Disable
     */
    private boolean conEigyoushoMeiDisabled;

    /**
     * 世代検索条件Disable
     */
    private boolean conSedaiKensakuJokenDisabled;

    /**
     * 適用日Disable
     */
    private boolean conTekiyoBiDisabled;

    /**
     * 検索条件保持用営業所コードDisable
     */
    private boolean conEigyoushoCdHidDisabled;

    /**
     * 車両NODisable
     */
    private boolean conSharyoNoDisabled;

    /**
     * 車両名称Disable
     */
    private boolean conSharyoMeishoDisabled;

    /**
     * 未使用期間Disable
     */
    private boolean conMishiyoKikanDisabled;

    /**
     * 適用名Disable
     */
    private boolean conTekiyoMeiDisabled;

    /**
     * 削除のみ検索Disable
     */
    private boolean conSakujonomiKensakuDisabled;

    /**
     * 編集Disabled
     */
    private boolean btnEditeDisabled;

}
