/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.PostConstruct;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.cnst.SysMsg;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.kintetsuls.service.general.property.ExternalServiceProperty;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * E2システムマスタ定義取得Bean
 * 
 * @author zf (MBP)
 * @version 2019/2/25 新規作成
 */
@ManagedBean(name = "systemMasterBean", eager = true)
@ApplicationScoped
@Data
public class SystemMasterBean {

    private static final Logger logger = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    /**
     * E2システムマスタ定義モード
     */
    @ManagedProperty(value = "#{systemMasterModuleBean}")
    private List<SystemMasterModuleBean> systemMasterModuleBeanList;

    @PostConstruct
    public void init() {

        // DBをアクセス
        ServiceInterfaceBean res = getDBInfo("common-get-system-master");
        systemMasterModuleBeanList = new ArrayList<>();

        if (res != null) {
            ObjectMapper mapper = new ObjectMapper();
            try {
                List<Map<String, Object>> searchResult = mapper.readValue(res.getJson(), List.class);
                SystemMasterModuleBean systemMasterModuleBean;
                for (Map<String, Object> rstMap : searchResult) {
                    systemMasterModuleBean = new SystemMasterModuleBean();
                    // 管理グループ
                    systemMasterModuleBean.setKanriGroup((String)rstMap.get("cdGroup"));
                    // コード
                    systemMasterModuleBean.setCode((String)rstMap.get("cd"));
                    // 値
                    systemMasterModuleBean.setValue((String)rstMap.get("val"));
                    // 説明
                    systemMasterModuleBean.setSetsumei((String)rstMap.get("setsumei"));
                    systemMasterModuleBeanList.add(systemMasterModuleBean);
                }
            } catch (IOException ex) {
                logger.error(ex.getMessage(), ex);
            }
        }
    }
    
    /**
     * 全てシステムマスタ情報を取得する
     * 
     * @return 全て区分情報
     */
    public List<SystemMasterModuleBean> getAllSysInfos() {
        return systemMasterModuleBeanList;
    }
    
    /**
     * 管理グループとコードよりシステムマスタ情報を取得する
     * <br/>
     * 複数管理グループが指定できる。
     * 前管理グループ+コードがあれば、前のシステムマスタ情報を返却する。
     * 前管理グループ+コードがなければ、後のシステムマスタ情報を返却する。
     * 
     * @param code コード
     * @param kanriGroups 管理グループリスト
     * @return システムマスタ情報
     */
    public SystemMasterModuleBean getSysInfoByCdAndKanriGroup(String code, String... kanriGroups) {
        
        for (int i = 0; i < kanriGroups.length; i++) {
            SystemMasterModuleBean sysInfo = getSysInfoOfOneKriGpAndCd(kanriGroups[i], code);
            if (sysInfo != null) {
                return sysInfo;
            }
            if (i == kanriGroups.length - 1) {
                return sysInfo;
            }
        }
        return null;
    }

    /**
     * 管理グループとコードより値を取得する
     * <br/>
     * 複数管理グループが指定できる。
     * 前管理グループ+コードがあれば、前のシステムマスタ情報の設定値を返却する。
     * 前管理グループ+コードがなければ、後のシステムマスタ情報の設定値を返却する。
     * 
     * @param code コード
     * @param kanriGroups 管理グループリスト
     * @return システムマスタ設定値
     */
    public String getSysValByCdAndKanriGroup(String code, String... kanriGroups) {
        
        SystemMasterModuleBean sysInfo = getSysInfoByCdAndKanriGroup(code, kanriGroups);
        if (sysInfo != null) {
            return sysInfo.getValue();
        }
        return null;
    }

    /**
     * 一つ管理グループとコードよりシステムマスタ情報を取得する
     * 
     * @param kanriGroup 管理グループ
     * @param code コード
     * @return システムマスタ情報
     */
    private SystemMasterModuleBean getSysInfoOfOneKriGpAndCd(String kanriGroup, String code) {
        
        List<SystemMasterModuleBean> retList = systemMasterModuleBeanList.stream()
                .filter((SystemMasterModuleBean sub) -> kanriGroup.equals(sub.getKanriGroup()) && code.equals(sub.getCode()))
                .collect(Collectors.toList());
        if (retList != null && retList.size() > 0) {
            return retList.get(0);
        }
        return null;
    }
    
    /**
     * DBアクセス用
     *
     * @param functionCode
     * @return ServiceInterfaceBean
     */
    private ServiceInterfaceBean getDBInfo(String functionCode) {

        ServiceInterfaceBean req = new ServiceInterfaceBean();
        req.setFunctionCode(ExternalServiceProperty.getInstance().getProperty(functionCode));
        String requestData = JSONUtil.makeJSONString(null);
        req.setJson(requestData);

        //JAX-RS接続を実行(SQL側のチェック処理など未実装。)
        RestfullService rest = RestfullService.getInstance();
        ServiceInterfaceBean res = null;
        try {
            res = rest.request(req);
        } catch (Exception ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
            return null;
        }

        if (res == null || res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return null;
        }

        // 戻りSIBのステータスチェック、エラー処理
        if (res == null || res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            // ToDo:各画面の仕様に従いメッセージ表示などのエラー処理を追加してください
        }
        return res;
    }

}
