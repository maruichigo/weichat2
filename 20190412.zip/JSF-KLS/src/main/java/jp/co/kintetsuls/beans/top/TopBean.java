/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.top;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Getter;
import lombok.Setter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 *
 * @author y_kamata
 */
@javax.faces.bean.ManagedBean(name = "top")
@ViewScoped
public class TopBean extends BaseBean {

    private final String strTitle = "トップ画面";
    private String url;     // URL

    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    @Getter
    @Setter
    private String gamenId;

    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    private static final Logger logger = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    /**
     * コンストラクタ
     */
    public TopBean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId
     * @param prevScreen
     * @param backFlag
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            breadBean.push("TOP", "TOP_SCREEN", this);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }
    }

    /**
     * メニュークリック（処理）
     *
     * @param menuId
     * @param nextScreen
     * @return
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {
        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック（処理）
     *
     * @return
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {
        return url;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return
     */
    @Override
    public String logoutClick() {
        return getAuthConfBean().logout();
    }

    /**
     * 画面遷移処理
     *
     * @return
     * @throws java.lang.IllegalAccessException
     * @throws java.lang.reflect.InvocationTargetException
     */
    public String buttonClick() throws IllegalAccessException, InvocationTargetException {
        url = forward(gamenId, null, Cnst.SCREEN.TOP_SCREEN.name(), false);
//        url = forward(Cnst.SCREEN.MST501_SCREEN.name(), null, Cnst.SCREEN.TOP_SCREEN.name(), false);
        return url;
    }

    /**
     * 画面遷移処理
     *
     * @return
     * @throws java.lang.IllegalAccessException
     * @throws java.lang.reflect.InvocationTargetException
     */
    public String buttonClick(String gamenId) throws IllegalAccessException, InvocationTargetException {
        url = forward(gamenId, null, Cnst.SCREEN.TOP_SCREEN.name(), false);
//        url = forward(Cnst.SCREEN.MST501_SCREEN.name(), null, Cnst.SCREEN.TOP_SCREEN.name(), false);
        return url;
    }

    public List<String> completeMethod(String key) {
        List<String> results = new ArrayList<>();
        for (SCREEN screen : Cnst.SCREEN.values()) {
            results.add(screen.name());
        }
        return results;
    }

    /**
     * @return the strTitle
     */
    public String getStrTitle() {
        return strTitle;
    }

    /**
     * @return the breadBean
     */
    public BreadCrumbBean getBreadBean() {
        return breadBean;
    }

    /**
     * @param breadBean the breadBean to set
     */
    public void setBreadBean(BreadCrumbBean breadBean) {
        this.breadBean = breadBean;
    }

    /**
     * @return the authConfBean
     */
    public AuthorityConfBean getAuthConfBean() {
        return authConfBean;
    }

    /**
     * @param authConfBean the authConfBean to set
     */
    public void setAuthConfBean(AuthorityConfBean authConfBean) {
        this.authConfBean = authConfBean;
    }

}
