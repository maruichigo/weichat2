/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.service.common;

import jp.co.kintetsuls.service.general.RestfullService;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 *
 * @author Yuka Kobayashi
 */
public class AuthorityService {
    
    private static final Logger logger = LogManager.getLogger(new Object(){}.getClass().getEnclosingClass().getName());

    public ServiceInterfaceBean getAuthority(String userCd, RestfullService rest, AuthorityConfBean authConf) throws SystemException, IOException {
        ServiceInterfaceBean res = new ServiceInterfaceBean();
        
        // デフォルト営業所、アクセスかの営業所リストを取得・格納
        res = getOfficeList(userCd, rest, authConf);
        if (res.getStatusCode() != ServiceInterfaceBean.PROCESS_STATUS_SUCCESS){
            return res;
        }

        // コンポーネント単位の利用可否を取得・格納
        res = getComponentSetting(userCd, rest, authConf);
        if (res.getStatusCode() != ServiceInterfaceBean.PROCESS_STATUS_SUCCESS){
            return res;
        }

        return res;
    }
    
    public ServiceInterfaceBean eigyoshoShubetsuCheck(String defaultEigyosho) {
        ServiceInterfaceBean req = new ServiceInterfaceBean();
        req.setFunctionCode("EIGYOSHO_SHUBETSU");
        req.setDefaultEigyosho(defaultEigyosho);
        
        //parameter
        Map<String, Object> params = new HashMap<>();
        params.put("defaultEigyosho", defaultEigyosho);
        String requestData = JSONUtil.makeJSONString(params);
        req.setJson(requestData);
        
        //JAX-RS接続を実行
        RestfullService rest = RestfullService.getInstance();
        ServiceInterfaceBean res = null;

        try {
            res = rest.request(req);

            if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR){
                return res;
            }

        } catch (Exception e) {
        }
        return res;
    }
    
    
    /**
     * DBからアクセス可能営業所とデフォルトを取得し、authConfに格納する
     * @param userCd
     * @param rest
     * @param authConf 
     */
    private ServiceInterfaceBean getOfficeList(String userCd, RestfullService rest, AuthorityConfBean authConf) throws SystemException {
        ServiceInterfaceBean req = new ServiceInterfaceBean();
        req.setFunctionCode("COMMON_GET_ACCESSIBLE_OFFICE");
        req.setUserCd(userCd);
        
        //parameter
        Map<String, Object> params = new HashMap<>();
        params.put("userCd", userCd);
        String requestData = JSONUtil.makeJSONString(params);
        req.setJson(requestData);

        //JAX-RS接続を実行
        rest = RestfullService.getInstance();
        ServiceInterfaceBean res;
        List authResult = null;

        try {
            res = rest.request(req);

            if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR){
                String msg = "アクセス可能な営業所の取得に失敗しました。";
                logger.error(msg);
                return res;
            }

            authResult = rest.jsonResMapList(res);

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            throw new SystemException(e);
        }
        
        try {
            // デフォルト営業所を格納
            Map<String, String> defmap = (Map<String, String>)authResult.get(0);
            String defaultEigyosho = (String)defmap.get("VALUE");
            
            authConf.setDefaultEigyosho(defaultEigyosho);
            authResult.remove(0);

            //営業所一覧に表示するためのリストを格納
            authConf.setAvailableEigyoshoMap(makeOfficeList(authResult));
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            throw e;
        }

        if(authConf.getDefaultEigyosho() == null || authConf.getAvailableEigyoshoMap().isEmpty()) {
            res.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            String msg = "アクセス可能な営業所が取得できませんでした。";
            res.addMessage("ERROR", "エラー", msg);
            logger.error(msg);
            return res;
        }

        return res;
    }
   
    /**
     * 営業所一覧に表示するための営業所リストを作成
     * @param optionList
     * @return 
     */
    public static Map<String, String> makeOfficeList(List<Map <String, String>> optionList){
        Map<String, String> eigyoshoMap = new HashMap<>();   

        for (Map<String, String> one : optionList){
            String eigyoshoCd = one.get("VALUE");
            String eigyoshoName = one.get("LABEL_VALUE");
            eigyoshoMap.put(eigyoshoCd, eigyoshoName);
        }
        return eigyoshoMap;
    }

    /**
     *  コンポーネント毎の利用設定を取得・格納する。
     * @param userCd
     * @param rest
     * @param authConf 
     */
    private ServiceInterfaceBean getComponentSetting(String userCd, RestfullService rest, AuthorityConfBean authConf) throws SystemException {
        String msg = "利用可能な機能が取得できませんでした。";
        Map<String, Map<String, ComponentBean>> authComponentMap = new HashMap<>();

        ServiceInterfaceBean req = new ServiceInterfaceBean();
        //functionCode(USER_GET_ALLMENU)
        req.setFunctionCode("COMMON_GET_AUTHORITY_COMPONENT");
        req.setUserCd(userCd);
        //parameter
        Map<String, Object> params = new HashMap<>();
        params.put("userCd", userCd);
        String requestData = JSONUtil.makeJSONString(params);
        req.setJson(requestData);
        //JAX-RS接続を実行
        rest = RestfullService.getInstance();
        ServiceInterfaceBean res = null;
        List<Map<String, Object>> authResult = null;

        try {
            res = rest.request(req);
            if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR){
                logger.error(msg);
                res.addMessage("ERROR", "エラー", msg);
                res.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                return res;
            }

            authResult = rest.jsonResMapList(res);

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            throw new SystemException(e);
        }
        
        try {
            //SQL取得結果の格納処理
            for (Map<String, Object> map : authResult){
                String screenCode = (String)map.get("screenCode");
                Map<String, ComponentBean> compoMap = new HashMap<>();

                for(Map<String, Object> component : (List<Map>)map.get("components")){
                    String componentName = (String)component.get("componentName");
                    int riyoSettei = (int)component.get("riyoSettei");
                    ComponentBean comp = new ComponentBean();
                    comp.setRiyoSettei(riyoSettei);
                    compoMap.put(componentName, comp);
                }
                
                authComponentMap.put(screenCode, compoMap);

            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            throw e;
        }

        authConf.setAuthComponentMap(authComponentMap);

        return res;
    }
    
    
}
