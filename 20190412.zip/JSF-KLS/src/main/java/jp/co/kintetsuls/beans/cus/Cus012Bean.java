/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.cus;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.FacesEvent;
import javax.faces.model.SelectItem;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.cnst.SysMsg;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.event.SelectEvent;
import lombok.Data;

/**
 *
 * @author y_kamata
 */
@Data
@javax.faces.bean.ManagedBean(name = "cus012")
@ViewScoped
public class Cus012Bean extends BaseBean {
    
    private final String strTitle = "顧客マスタメンテナンス画面";
    private final String shortTitle = "顧客マスタメンテ";
    private String url;     // URL
    
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;
    private RestfullService rest;
    
    private static final Logger logger = LogManager.getLogger(new Object(){}.getClass().getEnclosingClass().getName());
    
    private String kokyakuCd;
    private Date tekiyoKaishibi;
    private Date oldTekiyoKaishibi;
    private String status;
    
    private List<String> kokyakuCdList;
    private Map<String, String> kokyakuMap;
    private String kokyakuMei1;
    private String kokyakuMei2;
    private String kokyakuMei3;
    private String kokyakuMei4;
    private String kokyakuMei;

    private String tekiyoMei;
    
    private String kokyakuShubetsu;
    private List<SelectItem> kokyakuShubetsuList;
    private String kokyakuKbn;
    private List<SelectItem> kokyakuKbnList;
    
    // サンプル用営業所AutoComplete
    private List<String> eigyoshoCdList;
    private Map<String, String> eigyoshoMap;
    private String eigyoshoCd;
    private String eigyoshoMei;
    
    /**
     * 新規モードフラグ
     */
    private Boolean createModeFlg = false;  // 検索条件の顧客コードAutoCompleteのforceSelect制御に使用(モード未実装のためサンプルでは使用無し)
    
    /**
     * 検索済みフラグ
     */
    private Boolean searchedFlg;
    
    /**
     * コンストラクタ
     */
    public Cus012Bean() {
    }
    
    /**
     * 初期処理（処理）
     * @param menuId
     * @param prevScreen
     * @param backFlag
     */      
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag){
        try {
            // パンくず追加
            breadBean.push("顧客メンテナンス画面", SCREEN.CUS012_SCREEN.name(), this);
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }
        
        // 画面項目初期値設定(ダミー値)
        // ToDo:実際の開発では適切なテーブルから取得したデータをセットしてください
        setKokyakuCdList();
        setKokyakuShubetsuList();
        setKokyakuKbnList();

        // 利用可能営業所を営業所AutoCompleteにセット
        eigyoshoCdList = new ArrayList<>();
        eigyoshoMap = new HashMap(authConfBean.getAvailableEigyoshoMap());
        eigyoshoMap.keySet().forEach((cd) -> {
            eigyoshoCdList.add(cd);
        });
        // デフォルト営業所がある場合はセット(サンプル画面では検索条件でないためコメントアウトしてます) 
        
        if(null != authConfBean.getDefaultEigyosho()){
            eigyoshoCd = authConfBean.getDefaultEigyosho();
            eigyoshoMei = eigyoshoMap.get(eigyoshoCd);
        }
        
        // 検索条件入力値の初期化
        clear();
        // 検索済みフラグクリア
        searchedFlg = false;
    }
    
    /**
     * メニュークリック（処理）
     * @param menuId
     * @param nextScreen
     * @return 
     */    
    @Override
    public String menuClick(String menuId, String nextScreen){
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }

        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
    }
    
    /**
     * パンくずクリック（処理）
     * @return 
     */   
    @Override
    public String breadClumClick(String nextScreen, int breadIndex){

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }        
        url = forward(nextScreen, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     * @return 
     */   
    @Override
    public String logoutClick(){
        return authConfBean.logout();
    }
    
    /**
     * 画面遷移処理
     * @return 
     */     
    public String buttonClick() {
        // 画面遷移
        url = forward(SCREEN.CUS011_SCREEN.name(), null, SCREEN.CUS012_SCREEN.name(), false);
        return url;
    }   

    /**
     * @return the strTitle
     */
    public String getStrTitle() {
        return strTitle;
    }

    /**
     * @return the breadBean
     */
    public BreadCrumbBean getBreadBean() {
        return breadBean;
    }

    /**
     * @param breadBean the breadBean to set
     */
    public void setBreadBean(BreadCrumbBean breadBean) {
        this.breadBean = breadBean;
    }

    ////////////// buttons 
    /**
     * 検索ボタン押下イベント
     */
    public void search(){
        // 必須チェック
        if(kokyakuCd == null || kokyakuCd.isEmpty()){
            FacesContext.getCurrentInstance().addMessage("message" , new FacesMessage(FacesMessage.SEVERITY_WARN, "警告", SysMsg.WRNREQ));
            return;
        }
        // 桁数チェック
        if(kokyakuCd.length() != 6){
            FacesContext.getCurrentInstance().addMessage("message" , new FacesMessage(FacesMessage.SEVERITY_WARN, "警告", "顧客コードの桁数は6桁で入力してください"));
            return;
        }
        
        // 顧客マスタ検索し、取得した値を画面項目にセット
        ServiceInterfaceBean res = getKokyakuDetail();

        // 戻りSIBのステータスチェック、エラー処理
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR){
            // ToDo:各画面や共通メッセージ仕様に従い、メッセージ表示などのエラー処理を追加してください
            // 以下メッセージ表示サンプル
            MsgExec.message(res.getMessages());
            return;
        }
        
        // 検索済みフラグを立てる
        searchedFlg = true;
    }
    
    /**
     * DB検索し、取得した情報を画面項目にセットする
     * @return 
     */
    private ServiceInterfaceBean getKokyakuDetail(){
        ServiceInterfaceBean req = new ServiceInterfaceBean();
        req.setFunctionCode("CUS012_GET_KOKYAKU_DETAIL");
        
        //parameter
        Map<String, Object> params = new HashMap<>();
        params.put("kokyakuCd", kokyakuCd);
        params.put("tekiyoMei", tekiyoMei);
        params.put("tekiyoKaishibi", FormatUtil.dateToJsonString(tekiyoKaishibi));
        String requestData = JSONUtil.makeJSONString(params);
        req.setJson(requestData);

        //JAX-RS接続を実行(SQL側のチェック処理など未実装。)
        rest = RestfullService.getInstance();
        ServiceInterfaceBean res = null;
        Map<String, Object> result;

        try {
            res = rest.request(req);

            if (res == null){
                throw new Exception();
            }
            if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR){
                return res;
            }

            ObjectMapper mapper = new ObjectMapper();
            result = mapper.readValue(res.getJson(), new TypeReference<Map<String, Object>>(){});
            
        } catch (Exception ex) {
            if(res == null){
                res.addMessage("WARN", "警告", SysMsg.ERRRTN);
                res.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            }
            logger.error(ex.getMessage(), ex);
            return res;
        }

        // 取得値を画面項目用に格納
        tekiyoKaishibi = FormatUtil.jsonStringToDate((String)result.get("tekiyoKaishibi"));
        oldTekiyoKaishibi = FormatUtil.jsonStringToDate((String)result.get("tekiyoKaishibi"));
        tekiyoMei = (String)result.get("tekiyoMei");
        status = (String) result.get("shinseiStatusCd");
        kokyakuShubetsu = (String) result.get("kokyakuShubetsu");
        kokyakuKbn = (String)result.get("kokyakuKbn");
        kokyakuMei1 = (String) result.get("kokyakuMeiKanji1");
        kokyakuMei2 = (String) result.get("kokyakuMeiKanji2");
        kokyakuMei3 = (String) result.get("kokyakuMeiKanji3");
        kokyakuMei4 = (String) result.get("kokyakuMeiKanji4");
        kokyakuMei = (String) result.get("kokyakuMei");
        
        return res;
    }
    
    public void changeConditions(){
        searchedFlg = false;
    }
    
    /**
     * 検索条件クリア
     * 初期処理、クリアボタンにて使用
     */
    public void clear(){
        kokyakuCd = "";
        kokyakuMei = " ";
        tekiyoKaishibi = null;
        tekiyoMei = "";

        searchedFlg = false;
    }
    
    /**
     * 新規登録ボタン
     */
    public void create(){
        // 必須チェック
        if(kokyakuCd == null || kokyakuCd.isEmpty()
                || tekiyoKaishibi == null
                || kokyakuShubetsu == null || kokyakuShubetsu.isEmpty()
                || kokyakuKbn == null || kokyakuKbn.isEmpty()){
            FacesContext.getCurrentInstance().addMessage("message" , new FacesMessage(FacesMessage.SEVERITY_WARN, "警告", SysMsg.WRNREQ));
            return;
        }
        // 桁数チェック
        if(kokyakuCd.length() != 6){
            FacesContext.getCurrentInstance().addMessage("message" , new FacesMessage(FacesMessage.SEVERITY_WARN, "警告", "顧客コードの桁数は6桁で入力してください"));
            return;
        }

        // insert処理を実行
        ServiceInterfaceBean res = insertKokyakuData();

        // ToDo:各画面や共通メッセージ仕様に従い、メッセージ表示などのエラー処理を追加してください
        // 以下メッセージ表示サンプル
        MsgExec.message(res.getMessages());
    }
    /**
     * 顧客レコード新規登録処理
     * @return 
     */
    private ServiceInterfaceBean insertKokyakuData(){
        ServiceInterfaceBean req = new ServiceInterfaceBean();
        req.setFunctionCode("CUS012_INSERT_KOKYAKU_DATA");
        
        //parameter
        Map<String, Object> params = new HashMap<>();
        params.put("kokyakuCd", kokyakuCd);
        params.put("tekiyoKaishibi", FormatUtil.dateToJsonString(tekiyoKaishibi));
        params.put("tekiyoMei", tekiyoMei);
        params.put("kokyakuShubetsu", kokyakuShubetsu);
        params.put("kokyakuKbn", kokyakuKbn);
        params.put("kokyakuMeiKanji1", kokyakuMei1);
        params.put("kokyakuMeiKanji2", kokyakuMei2);
        params.put("kokyakuMeiKanji3", kokyakuMei3);
        params.put("kokyakuMeiKanji4", kokyakuMei4);
        params.put("kokyakuMei", kokyakuMei1 + kokyakuMei2 + kokyakuMei3 + kokyakuMei4);
        params.put("userCd", authConfBean.getUserCd());
        String requestData = JSONUtil.makeJSONString(params);
        req.setJson(requestData);

        //JAX-RS接続を実行(SQL側のチェック処理など未実装。)
        rest = RestfullService.getInstance();
        ServiceInterfaceBean res = null;

        try {
            res = rest.request(req);

            if (res == null){
                throw new Exception();
            }
            
        } catch (Exception ex) {
            if(res == null){
                res.addMessage("WARN", "警告", SysMsg.ERRRTN);
                res.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            }
            logger.error(ex.getMessage(), ex);
            return res;
        }
        
        return res;
    }
    
    /**
     * 更新ボタン
     */
    public void update(){
        // 必須チェック
        if(kokyakuCd == null || kokyakuCd.isEmpty()
                || tekiyoKaishibi == null
                || kokyakuShubetsu == null || kokyakuShubetsu.isEmpty()
                || kokyakuKbn == null || kokyakuKbn.isEmpty()){
            FacesContext.getCurrentInstance().addMessage("message" , new FacesMessage(FacesMessage.SEVERITY_WARN, "警告", SysMsg.WRNREQ));
            return;
        }
        // 桁数チェック
        if(kokyakuCd.length() != 6){
            FacesContext.getCurrentInstance().addMessage("message" , new FacesMessage(FacesMessage.SEVERITY_WARN, "警告", "顧客コードの桁数は6桁で入力してください"));
            return;
        }

        // 顧客マスタ検索し、取得した値を画面項目にセット
        ServiceInterfaceBean res = updateKokyakuData();

        // ToDo:各画面や共通メッセージ仕様に従い、メッセージ表示などのエラー処理を追加してください
        // 以下メッセージ表示サンプル
        MsgExec.message(res.getMessages());
    }
    /**
     * 顧客レコード更新処理
     * @return 
     */
    private ServiceInterfaceBean updateKokyakuData(){
        ServiceInterfaceBean req = new ServiceInterfaceBean();
        req.setFunctionCode("CUS012_UPDATE_KOKYAKU_DATA");
        
        //parameter
        Map<String, Object> params = new HashMap<>();
        params.put("kokyakuCd", kokyakuCd);
        params.put("tekiyoKaishibi", FormatUtil.dateToJsonString(tekiyoKaishibi));
        params.put("oldTekiyoKaishibi", FormatUtil.dateToJsonString(oldTekiyoKaishibi));
        params.put("tekiyoMei", tekiyoMei);
        params.put("kokyakuShubetsu", kokyakuShubetsu);
        params.put("kokyakuKbn", kokyakuKbn);
        params.put("kokyakuMeiKanji1", kokyakuMei1);
        params.put("kokyakuMeiKanji2", kokyakuMei2);
        params.put("kokyakuMeiKanji3", kokyakuMei3);
        params.put("kokyakuMeiKanji4", kokyakuMei4);
        params.put("kokyakuMei", kokyakuMei1 + kokyakuMei2 + kokyakuMei3 + kokyakuMei4);
        params.put("userCd", authConfBean.getUserCd());
        String requestData = JSONUtil.makeJSONString(params);
        req.setJson(requestData);

        //JAX-RS接続を実行(SQL側のチェック処理など未実装。)
        rest = RestfullService.getInstance();
        ServiceInterfaceBean res = null;

        try {
            res = rest.request(req);

            if (res == null){
                throw new Exception();
            }
            
        } catch (Exception ex) {
            if(res == null){
                res.addMessage("WARN", "警告", SysMsg.ERRRTN);
                res.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            }
            logger.error(ex.getMessage(), ex);
            return res;
        }
        return res;
    }

    /**
     * 論理削除ボタン
     */
    public void logicalDelete(){

        // 顧客マスタから論理削除
        ServiceInterfaceBean res = logicalDeleteKokyakuData();

        // 戻りSIBのステータスチェック、エラー処理
        if (res.getStatusCode() != ServiceInterfaceBean.PROCESS_STATUS_ERROR){
            // ToDo:各画面や共通メッセージ仕様に従い、メッセージ表示などのエラー処理を追加してください
            // 以下メッセージ表示サンプル
            searchedFlg = false;
        }
        MsgExec.message(res.getMessages());
    }
    /**
     * 顧客レコード論理削除処理
     * @return 
     */
    private ServiceInterfaceBean logicalDeleteKokyakuData(){
        ServiceInterfaceBean req = new ServiceInterfaceBean();
        req.setFunctionCode("CUS012_LOGICAL_DELETE_KOKYAKU_DATA");
        
        //parameter
        Map<String, Object> params = new HashMap<>();
        params.put("kokyakuCd", kokyakuCd);
        params.put("tekiyoKaishibi", FormatUtil.dateToJsonString(tekiyoKaishibi));
        params.put("oldTekiyoKaishibi", FormatUtil.dateToJsonString(oldTekiyoKaishibi));
        params.put("userCd", authConfBean.getUserCd());
        String requestData = JSONUtil.makeJSONString(params);
        req.setJson(requestData);

        //JAX-RS接続を実行(SQL側のチェック処理など未実装。)
        rest = RestfullService.getInstance();
        ServiceInterfaceBean res = null;

        try {
            res = rest.request(req);

            if (res == null){
                throw new Exception();
            }
            
        } catch (Exception ex) {
            if(res == null){
                res.addMessage("WARN", "警告", SysMsg.ERRRTN);
                res.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            }
            logger.error(ex.getMessage(), ex);
            return res;
        }
        return res;
    }

    

    /////////////// 画面項目
    
    /**
     * 営業所コードAutoCompleteのcompleteイベント
     * @param query
     * @return 
     */
    public List<String> completeEigyoshoCd(String query) {
        return eigyoshoCdList.stream().filter(m -> m.contains(query)).collect(Collectors.toList());
    }
    /**
     * 営業所コードAutoCompleteのクリアイベント
     */
    public void clearEigyoshoCd(FacesEvent event){
        eigyoshoMei= "";
    }
    /**
     * 営業所コードAutoCompleteの選択時イベント
     * 選択された顧客の名称をラベルに設定
     * @param event 
     */
    public void handleEigyoshoCdChange(SelectEvent event){
        eigyoshoMei = eigyoshoMap.get(event.getObject().toString());
    }
    
    /**
     * 顧客コードAutoCompleteのcompleteイベント
     * @param query
     * @return 
     */
    public List<String> completeKokyakuCd(String query) {
        return kokyakuCdList.stream().filter(m -> m.contains(query)).collect(Collectors.toList());
    }
    /**
     * 顧客コードAutoCompleteのクリアイベント
     */
    public void clearKokyakuCd(FacesEvent event){
        kokyakuMei= "";
    }
    /**
     * 顧客コードAutoCompleteの選択時イベント
     * 選択された顧客の名称をラベルに設定
     * @param event 
     */
    public void handleKokyakuCdChange(SelectEvent event){
        kokyakuMei = kokyakuMap.get(event.getObject().toString());
    }
    
    
    ///// 以下　サンプル用ダミー値生成
    
    /**
     * 顧客コードAutoCompleteのリスト設定
     * ToDo:顧客マスタからの取得値を設定するように変更してください
     */
    public void setKokyakuCdList(){
        getKokyakuMap();
        // 顧客マスタから論理削除
        ServiceInterfaceBean res = getKokyakuMap();

        // サンプル用　取得できなかった場合は固定値を追加
        if(res == null || res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR){
            kokyakuCdList = Arrays.asList("000000", "000001", "123456", "L00001");
            kokyakuMap = new HashMap<String, String>(){
                    {put("000000", "テスト顧客000000");}
                    {put("000001", "テスト顧客000001");}
                    {put("123456", "テスト顧客123456");}
                    {put("L00001", "テスト顧客L00001");}
            };
        }
    }
    /**
     * 顧客マスタ検索し、AutoCompleteにセット
     */
    private ServiceInterfaceBean getKokyakuMap(){
        ServiceInterfaceBean req = new ServiceInterfaceBean();
        req.setFunctionCode("CUS012_GET_KOKYAKU_MAP");
        
        //parameter
        Map<String, Object> params = new HashMap<>();
        String requestData = JSONUtil.makeJSONString(params);
        req.setJson(requestData);

        //JAX-RS接続を実行(SQL側のチェック処理など未実装。)
        rest = RestfullService.getInstance();
        ServiceInterfaceBean res = null;
        List<Cus012Def> resList;
        Map<String, Object> result;

        try {
            res = rest.request(req);

            if (res == null){
                throw new Exception();
            }
            if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR){
                return res;
            }

            ObjectMapper mapper = new ObjectMapper();
            resList = mapper.readValue(res.getJson(), new TypeReference<List<Cus012Def>>(){});
            
        } catch (Exception ex) {
            if(res == null){
                res.addMessage("WARN", "警告", SysMsg.ERRRTN);
                res.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            }
            logger.error(ex.getMessage(), ex);
            return res;
        }

        kokyakuCdList = new ArrayList<>();
        kokyakuMap = new HashMap<>();
        
        // 取得値を画面項目用に格納
        for(int i = 0; i < resList.size(); i++) {
            String kokyaku_cd = resList.get(i).getKokyakuCd();
            String kokyaku_mei = resList.get(i).getKokyakuMei();
            kokyakuCdList.add(kokyaku_cd);
            kokyakuMap.put(kokyaku_cd, kokyaku_mei);
        }
        return res;
    }    
    /**
     * 顧客種別SELECTのリスト設定
     * ToDo:区分マスタからの取得値を設定するように変更してください
     */
    public void setKokyakuShubetsuList(){
        kokyakuShubetsuList = new ArrayList<>();
        kokyakuShubetsuList.add(new SelectItem("", ""));
        kokyakuShubetsuList.add(new SelectItem("01", "輸送"));
        kokyakuShubetsuList.add(new SelectItem("02", "その他売上"));
        kokyakuShubetsuList.add(new SelectItem("03", "ロジ"));
        kokyakuShubetsuList.add(new SelectItem("04", "その他請求"));
        kokyakuShubetsuList.add(new SelectItem("05", "取りまとめ"));
    }
    
    /**
     * 顧客区分SELECTのリスト設定
     * ToDo:区分マスタからの取得値を設定するように変更してください
     */
    public void setKokyakuKbnList(){
        kokyakuKbnList = new ArrayList<>();
        kokyakuKbnList.add(new SelectItem("", ""));
        kokyakuKbnList.add(new SelectItem("01", "一般"));
        kokyakuKbnList.add(new SelectItem("02", "代理店"));
        kokyakuKbnList.add(new SelectItem("03", "3PL"));
    }
            

}
