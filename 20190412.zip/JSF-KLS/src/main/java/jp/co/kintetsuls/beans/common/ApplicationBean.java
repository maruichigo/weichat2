
package jp.co.kintetsuls.beans.common;
import java.io.Serializable;
import jp.co.kintetsuls.service.general.property.ExternalServiceProperty;

@javax.faces.bean.ManagedBean(name="appBean", eager=true)
@javax.faces.bean.ApplicationScoped
@lombok.Data
public class ApplicationBean implements Serializable {

    /** APサーバ名 */
    private String APserver = null;
    /** #タイムアウトまでの時間(秒)  */
    private int timeoutSession = 0;
    /** タイムアウト時間通知ポップアップ表示までの時間(秒) */
    private int timeoutSessionPopup = 0;

    @javax.annotation.PostConstruct
    public void init() {
        setProperty(this);
    }

    private void setProperty(ApplicationBean bean){
        ExternalServiceProperty prop = ExternalServiceProperty.getInstance();
        bean.APserver = prop.getProperty("APserver");
        bean.timeoutSession =60 * 1000 * Integer.parseInt(prop.getProperty("timeoutSession"));
        bean.timeoutSessionPopup = 60 * 1000 * Integer.parseInt(prop.getProperty("timeoutSessionPopup"));
    }
    
    
    public void doNothing(){
        
    }
}
