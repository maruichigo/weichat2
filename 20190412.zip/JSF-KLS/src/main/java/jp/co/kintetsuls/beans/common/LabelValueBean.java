/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.cnst.SysMsg;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.forms.common.LabelValueForm;
import jp.co.kintetsuls.service.general.RestfullService;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 *
 * @author zengfeng
 */
@javax.faces.bean.ManagedBean(name = "labelValueBean")
@ViewScoped
@Data
public class LabelValueBean implements Serializable {
    
    private static final long serialVersionUID = 1L;

    private static final Logger logger = LogManager.getLogger(new Object(){}.getClass().getEnclosingClass().getName());    
    
    private RestfullService rest;    

    private List<Map<String, String>> searchResult;    
    
    // 定数：COMMON_GET_CREATE_LIST.
    public static final String COMMON_GET_CREATE_LIST = "COMMON_GET_CREATE_LIST";    
    
    /**
     * コンストラクタ
     */
    public LabelValueBean() {

    }

    /**
     * DBからAutoCompleteの文字列を取得する
     */    
    public List<LabelValueForm> getStringList(String listId){
        return this.getStringList(listId, null);
    }
    
    /**
     * DBからAutoCompleteの文字列を取得する
     */    
    public List<LabelValueForm> getStringList(String listId, String paramId){
        
        ServiceInterfaceBean req = new ServiceInterfaceBean();
        List<LabelValueForm> resList = new ArrayList<>();
        
        req.setFunctionCode(COMMON_GET_CREATE_LIST);

        //parameter
        Map<String, Object> params = new HashMap<>();
        params.put("listId", listId);
        if (paramId != null) {
            Map paramMap = new HashMap();
            paramMap.put("param0", paramId);
            params.put("params", paramMap);
        }
        String requestData = JSONUtil.makeJSONString(params);
        req.setJson(requestData);

        //JAX-RS接続を実行(SQL側のチェック処理など未実装。)
        rest = RestfullService.getInstance();
        ServiceInterfaceBean res = null;
        try {
            res = rest.request(req);
        } catch (Exception ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
            return new ArrayList<>();
        }

        if (res == null || res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR){
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return new ArrayList<>();
        }

        Map<String, Object> result;
        try {
            ObjectMapper mapper = new ObjectMapper();
            List searchResult = mapper.readValue(res.getJson(), List.class);
            this.searchResult = searchResult;
            for (Map<String, String> rec : this.searchResult) {
                LabelValueForm labelValueForm = new LabelValueForm();
                labelValueForm.setLabel(rec.get("LABEL"));
                labelValueForm.setValue(rec.get("VALUE"));
                resList.add(labelValueForm);
            }

        } catch (IOException ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
            return new ArrayList<>();
        }

        return resList;
    }
    
}
