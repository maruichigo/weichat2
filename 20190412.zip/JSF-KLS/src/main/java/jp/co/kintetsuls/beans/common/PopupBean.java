/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.common;

import java.io.Serializable;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import lombok.Data;
import org.primefaces.PrimeFaces;

/**
 * ポップアップで利用する共通Bean
 *
 * @author huanghua (MBP)
 * @version 2019/3/1 新規作成
 */
@ManagedBean(name = "popupBean")
@ViewScoped
@Data
public class PopupBean implements Serializable {

    /**
     * 画面共通
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * 新しいブラウザで画面を開く
     *
     * @param url
     * @param form 画面内容維持のフォーム
     * @param param パラメータ
     */
    public void show(String url, Object form, Map param) {
        // 画面内容維持
        if (null != form) {
            pageCommonBean.savePageInfo("preForm", form);
        }
        if (null != param) {
            pageCommonBean.savePageInfo("param", param);
        }

        //　画面遷移
        PrimeFaces.current().executeScript("km.showNewTab('" + url + "');");

    }
}
