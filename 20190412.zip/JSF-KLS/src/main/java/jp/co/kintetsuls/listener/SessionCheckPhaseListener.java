package jp.co.kintetsuls.listener;
import javax.faces.event.PhaseListener;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import javax.faces.application.ConfigurableNavigationHandler;
import javax.faces.application.FacesMessage;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import jp.co.kintetsuls.beans.common.SessionBean;
import jp.co.kintetsuls.beans.common.ApplicationBean;
import jp.co.kintetsuls.cnst.Cnst;

/** ページ遷移時に呼び出されるクラス（セッションチェック関連）

*/
public class SessionCheckPhaseListener implements PhaseListener {
    private static final long serialVersionUID = -7462937908829777735L;
    private static final Logger logger = LogManager.getLogger(new Object(){}.getClass().getEnclosingClass().getName());

    @Override
    public void beforePhase(final PhaseEvent event) {

        // 認証済みチェック(ログインせずにurl直接遷移時はTOPへ移動)
        final FacesContext context = event.getFacesContext();
        final String viewId = context.getViewRoot().getViewId();
        if ("/login.xhtml".equals(viewId)|| !viewId.endsWith("xhtml")) {
            return;//logim.xhmtlもしくは、xhtml以外のリソースは処理終了
        }

        final ExternalContext extContext = context.getExternalContext();
        final HttpSession session = (HttpSession) extContext.getSession(false);
        if (null == session){
            //ブラウザを開いてxxx.xhtmlを直接指定した場合、loginへ移動
            logger.debug("not session listener:" + viewId);
            moveLogin();
            return;
        }

        AuthorityConfBean authConf = null;
        try {
            authConf = (AuthorityConfBean)session.getAttribute("authConfBean");
            if(null == authConf.getUserCd() || "".equals(authConf.getUserCd())){
                //topxhtmlを開いた後に、xxx.xhtmlを直接指定した場合、loginへ移動
                logger.debug("not user listener:" + viewId);
                moveLogin();
                return;
            }
        } catch (Exception e){
            String message = "loginBeanにauthConfBeanが宣言されていません";//e.getMessage();
            FacesMessage fsmsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "エラー", message);
            FacesContext.getCurrentInstance().addMessage("message" , fsmsg);
        }

        try {
            long now = java.lang.System.currentTimeMillis();
            SessionBean sessionBean = (SessionBean)session.getAttribute("sessionBean");
            long nexttime = sessionBean.getTimeLimitSession();
            if (0 == nexttime || now < nexttime){
                //初期値、或いは現在の時間＜セッション切れ想定時間の場合は、次の想定時間を代入
                ApplicationBean appBean = (ApplicationBean)extContext.getApplicationMap().get("appBean");
                nexttime = now + appBean.getTimeoutSession();
                sessionBean.setTimeLimitSession(nexttime);
                return;
            } else {
                //現在の時間＞＝セッション切れ想定時間の場合、ログアウト処理
                authConf.logout();
                moveLogin();
                return;
            }
        } catch (Exception e){
            String message = "loginBeanにsessionBean、もしくはappBeanが宣言されていません";
            FacesMessage fsmsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "エラー", message);
            FacesContext.getCurrentInstance().addMessage("message" , fsmsg);
        }
    }

    /** topへ移動 */
    private void moveLogin(){
        ConfigurableNavigationHandler handler = (ConfigurableNavigationHandler)FacesContext.getCurrentInstance().getApplication().getNavigationHandler();
        handler.performNavigation(Cnst.SCREEN.LOGIN_SCREEN.getXhtml()+"?faces-redirect=true");
    }

    @Override
    public void afterPhase(final PhaseEvent arg0) {

    }

    @Override
    public PhaseId getPhaseId() {
        return PhaseId.RENDER_RESPONSE;
    }
}
