/*
 *   Copyright(c) 2015 KAIMA DATA
 */
package jp.co.kintetsuls.file;

import java.io.InputStream;
import java.io.OutputStream;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author Xiaobo Zheng
 * @date 2005-12-28
 */
@Data
@AllArgsConstructor
public class FileDto {

    private String fileName;
    private String filePath;
//    private InputStream stream;

}
