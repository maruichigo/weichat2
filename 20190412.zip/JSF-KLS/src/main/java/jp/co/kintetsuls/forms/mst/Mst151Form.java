/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mst;

import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.annotation.SelectOne;
import lombok.Data;

/**
 * 品名マスタ フォーム
 * 
 * @author 许博 (MBP)
 * @version 2019/1/28 新規作成
 */
@ManagedBean(name = "mst151Form")
@ViewScoped
@Data
public class Mst151Form {
    
    /**
     * 営業所コード
     */
    @SelectOne(name = "営業所コード", message = "{COME0003}")
    private AutoCompOptionBean conEigyosho;
    
    /**
     * 営業所コードDisabled
     */
    private boolean conEigyoshoDisabled;
    
    /**
     * 顧客コード
     */
    @SelectOne(name = "顧客コード", message = "{COME0003}")
    private AutoCompOptionBean conKokyaku;
    
    /**
     * 顧客コードDisabled
     */
    private boolean conKokyakuDisabled;
    
    /**
     * 検索Visabled
     */
    private boolean btnSearchVisible;

    /**
     * 検索条件変更Visabled
     */
    private boolean btnSearchChangeVisible;
    
    /**
     * 編集Disabled
     */
    private boolean btnEditeDisabled;

    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;

    /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;

    /**
     * 選択された結果
     */
    private List<Map<String, Object>> selectedSearchResult;
}
