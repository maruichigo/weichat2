/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.AutoCompleteBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiListCol;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst382Form;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * チャーター料金項目マスタ
 *
 * @author 黄義輝 (MBP)
 * @version 2019/1/24 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst382")
@ViewScoped
@Data
public class Mst382Bean extends AbstractBean{

    /**
     * ダウンロードファイル名
     */
    private final static String FILE_NAME = "チャーター料金項目マスタ一覧";

    /**
     * タイトル
     */
    private final String TITLE = "チャーター料金項目マスタ";   

    /**
     * 画面URL
     */
    private String url;    

    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

    /**
     * 一覧のAutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoComplete}")
    private AutoCompleteBean autoCompleteBean;

    /**
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authorityConfBean;

    /**
     * ファイルダウンロード
     */
    @ManagedProperty(value = "#{fileBean}")
    private FileBean fileBean;

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;

    /**
     * 画面フォーム
     */
    @ManagedProperty(value = "#{mst382Form}")
    private Mst382Form mst382Form;

    /**
     * 画面共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * 検索シーケンス処理共通
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;

    /**
     * 履歴一覧処理共通
     */
    @ManagedProperty(value = "#{rirekisyosai}")
    private RirekiSyosaiBean rirekiSyosaiBean;
    
    /**
     * 一覧単項目チェック共通
     */
    @ManagedProperty(value = "#{listCheckBean}")
    private ListCheckBean listCheckBean;

    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(
            new Object() {}.getClass().getEnclosingClass().getName());

    /**
     * スクリーンコード：MST382
     */
    private static final String SC_CD_MST382 = "MST382_SCREEN";

    /**
     * 定数：検索FUNC_CODE.
     */
    private static final String FUNC_CODE_SEARCH = "mst382-get-charterRyokinKomoku-detail";

    /**
     * 定数：検索件数取得FUNC_CODE.
     */
    private static final String FUNC_CODE_SEARCH_KENSU = "mst382-get-charterRyokinKomoku-kensu";

    /**
     * 定数：登録更新FUNC_CODE.
     */
    private static final String FUNC_CODE_INSERT_UPDATE_CHECK = "mst382-insert-update-check";

    /**
     * 定数：登録更新チェックFUNC_CODE.
     */
    private static final String FUNC_CODE_INSERT_UPDATE = "mst382-insert-update";
 
    /**
     * 定数：削除の存在チェックFUNC_CODE.
     */
    private static final String FUNC_CODE_DELETE_EXIST = "mst382-delete-exist";

    /**
     * 定数：行削除FUNC_CODE.
     */
    private static final String FUNC_CODE_DELETE_ROW = "mst382-delete-row-detail";
    
    /**
     * 定数：一覧のDataTableのID.
     */
    private static final String DATA_TABLE_ID = "tablesorter_mst382";

    /**
     * 定数：画面項目保持key.
     */
    private static final String CONST_MST382_FORM = "mst382Form";
    
    /**
     * 定数：MasterInfo取得key.
     */
    private static final String CONST_MST382_MASTER = "mst382";

    /**
     * 定数：再検索Button取得キー
     */
    private static final String CONST_MST382_SEARCH = "search_mst382";  
    
    /**
     * 世代検索条件 デフォルト値
     */
    private static final String[] DEFAULT_VALUE = {"01", "02"};

    /**
     * マスタ情報.
     */
    private MasterInfoBean masterInfo;

    /**
     * 履歴テーブル検索キー.
     */
    private Map<String, Object> rirekiSearchKey;

    /**
     * ワーク.メッセージリスト
     */
    List<MessageModuleBean> msgList = new ArrayList<>();

    /**
     * コンストラクタ
     */
    public Mst382Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId メニューID
     * @param prevScreen 遷移元画面ID
     * @param backFlag 戻るフラグ
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {

            // パンくず追加
            breadBean.push(TITLE, SCREEN.MST382_SCREEN.name(), this);

            // マスタ内容取得
            pageCommonBean.getMasterInfo(CONST_MST382_MASTER);

            // 検索シーケンス処理ため初期化
            searchHelpBean.regSearchHelp(DATA_TABLE_ID,
                    s -> {return getRecordCount();},
                    s -> {search(); return null;},
                    null);

            searchHelpBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);

            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する
            // 処理科目リスト
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_SHORI_KAMOKU_CD);
            // 補助科目リスト
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_HOJO_KAMOKU_CD);

            // 前回の記録をクリアする
            this.clear();
            mst382Form.setSearchResult(null);
            mst382Form.setSearchResultSelectable(null);
            mst382Form.setSelectedSearchResult(null);

            // 戻ってきた場合
            Mst382Form preForm = (Mst382Form) pageCommonBean.getPageInfo(CONST_MST382_FORM);
            if (backFlag && preForm != null) {
                PageCommonBean.simpleCopy(preForm, mst382Form);
                // 再検索を実施する
                pageCommonBean.searchAgain(CONST_MST382_SEARCH);
            // 進んできた場合
            } else {
                Flash flash = pageCommonBean.getPageParam();
                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_MST382_FORM) != null) {
                    PageCommonBean.simpleCopy(flash.get(CONST_MST382_FORM), mst382Form);
                    // 再検索を実施する
                    pageCommonBean.searchAgain(CONST_MST382_SEARCH);
                }
            }

            // ダウンロードシーケンス初期化
            fileBean.setDataSize(DATA_TABLE_ID, (id -> {return getRecordCount();}));

            fileBean.setSearchResult(DATA_TABLE_ID, (id -> {return getSearchResult();})); 

            fileBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);

            fileBean.setSubFlg(true);

            fileBean.setTilte(FILE_NAME);

            fileBean.regDownloadFucntion(DATA_TABLE_ID, getHeader(),
                    (id -> {return getCharterRyokinKomokuList();}));

            fileBean.regBeforeDownFucntion(DATA_TABLE_ID,
                    (comment -> {return beforeDown(comment);}));

            // 行更新また削除するために共通処理へ登録
            pageCommonBean.regDelFucntion(DATA_TABLE_ID,
                    (dataList -> (this.delRows(dataList))));

            // component初期化とユーザ権限により制御設定
            pageCommonBean.setAuthControll(mst382Form, SC_CD_MST382, true);
            
            // 初期はデータを編集不可にする
            mst382Form.setBtnEditeDisabled(true);
            
            // 世代検索条件を初期化する
            mst382Form.setConSedaiKensakuJoken(DEFAULT_VALUE);

        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * カウント処理
     *
     * @return レコード件数
     */
    public Long getRecordCount() {

        // 前回の記録をクリアする
        Map<String, Object> mapRec = new LinkedHashMap();
        mapRec.put("hideFlg", "hideRow");
        List<Map<String, Object>> mapList = new ArrayList();
        mapList.add(mapRec);
        mst382Form.setSearchResult(mapList);
        mst382Form.setSearchResultSelectable(new ReportListDataModel(mst382Form.getSearchResult()));
        mst382Form.setSelectedSearchResult(null);

        // 検索初期はデータを編集不可にする
        mst382Form.setBtnEditeDisabled(true);

        // レコード件数を取得する
        long kensu = getCharterRyokinKomokuListKensu();

        // 検索部のステータスを変更する
        pageCommonBean.setSerchConDisabled(mst382Form);

        // 参照モードにする
        pageCommonBean.setEditFlg(false);
        
        // サブ検索条件フラグ設定
        fileBean.setSubFlg(subSearchConHad());

        // 検索条件保存
        pageCommonBean.savePageInfo(CONST_MST382_FORM, mst382Form);

        return kensu;
    }

    /**
     * 検索処理
     *
     */
    public void search() {

        // 選択リストを初期化
        mst382Form.setSelectedSearchResult(new ArrayList<>());
        mst382Form.setSearchResultSelectable(null);

        // チャーター料金項目マス検索し、取得した値を画面項目にセット
        List<Map<String, Object>> recordList = getCharterRyokinKomokuList();

         if (recordList == null) {
            return;
        }

        // 配色定義を設定する
        setIchiranColor(recordList);

        fileBean.setDataList(recordList);

        // 取得した値を画面項目にセットする
        pageCommonBean.setDatalist(DATA_TABLE_ID, recordList);
        mst382Form.setSearchResultSelectable(new ReportListDataModel(recordList));
        
        // 検索部のステータスを変更する
        pageCommonBean.setSerchConDisabled(mst382Form);

        // 削除済のみのチェック状態より、明細データを編集可／不可にする
        if (mst382Form.getConSakujoSumiNomi() == null || mst382Form.getConSakujoSumiNomi().length == 0) {
            // 削除済みデータを編集可にする
            mst382Form.setBtnEditeDisabled(false);
        } else {
            // 削除済みデータを編集不可にする
            mst382Form.setBtnEditeDisabled(true);
        }

        // 検索条件保存
        pageCommonBean.savePageInfo(CONST_MST382_FORM, mst382Form);

        // 参照モードにする
        pageCommonBean.setEditFlg(false);
    }

    /**
     * 配色定義の設定処理
     *
     * @param recordList レコードリスト
     */
    public void setIchiranColor(List<Map<String, Object>> recordList) {

        // 配色定義の判定
        
    }

    /**
     * 検索条件変更処理
     *
     */
    public void searchChange() {

        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mst382Form);
    }

    /**
     * クリア処理
     *
     */
    public void clear() {

        // 検索部の条件クリア
        mst382Form.setConRyokinKomokuCd(null);
        mst382Form.setConRyokinKomokuMeisho(null);
        mst382Form.setConSyoriKamoku(null);
        mst382Form.setConHojoKamoku(null);
        // 世代検索条件を初期化する
        mst382Form.setConSedaiKensakuJoken(DEFAULT_VALUE);
        mst382Form.setConTekiyoBi(null);
        mst382Form.setConTekiyoMei(null);
        mst382Form.setConSakujoSumiNomi(null);

        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mst382Form);
        pageCommonBean.setBtnSearchChangeVisible(false);
        pageCommonBean.setBtnSearchVisible(Boolean.TRUE);
    }

    /**
     * 更新処理
     *
     */
    public void update() {

        // エラーメッセージを格納する変数の初期化を行う
        msgList = new ArrayList();

        // 行選択チェック
        if (mst382Form.getSelectedSearchResult() == null || mst382Form.getSelectedSearchResult().isEmpty()) {

            MessageModuleBean message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
            msgList.add(message);

            messagePropertyBean.messageList(msgList);
            return;
        }

        // 登録一覧リストの初期化を行う
        List<Map<String, Object>> torokuIchiranList = new ArrayList();

        // 更新一覧リストの初期化を行う
        List<Map<String, Object>> koshinIchiranList = new ArrayList();  

        // 単項目チェック処理
        if (!checkJsfParamas(mst382Form.getSelectedSearchResult())) {
            return;
        }

        // 登録更新情報設定処理
        mst382Form.getSelectedSearchResult().forEach((rec) -> {
            // チャーター料金項目マスタ一覧.カレント行 = 登録対象
            if (rec.get(StndConsIF.CONST_ADD_ROW_KEY) != null) {
                // 登録データワークにデータを設定する
                torokuIchiranList.add(rec);
            } else {
                // 更新データワークにデータを設定する
                koshinIchiranList.add(rec);
            }
        });

        // 登録一覧リストと更新一覧リストの登録処理
        if (torokuIchiranList.size() > 0 || koshinIchiranList.size() > 0) {

            // 登録・更新処理を行う
            int status = insertUpdateCharterRyokinKomokuList();

            // エラーの場合、処理終了
            if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
                return;
            }
            
            // 登録の後に再度検索する
            this.search();
        }

        // 一覧の配色定義をなくす
        pageCommonBean.resetIchiranColColor(mst382Form.getSelectedSearchResult());

        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0007, "更新");

        // ログ出力を行う
        LOGGER.info("更新 " + mst382Form.getSelectedSearchResult().size() + " 件");
    }

    /**
     * 一覧の単項目チェック処理
     * 
     * @param params 画面一覧パラメータ
     * @return チェックの結果
     */
    private boolean checkJsfParamas(List<Map<String, Object>> params) {

        List<Map<String, Object>> checkParamas = params;

        List<ListCheckBean> checks = new ArrayList<>();
        checks.add(new ListCheckBean("listRyokinKomokuCd", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "料金項目コード"));
        checks.add(new ListCheckBean("listRyokinKomokuCd", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_SIZE, "料金項目コード", "3"));
        checks.add(new ListCheckBean("listRyokinKomokuCd", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_IS_HALF, "料金項目コード"));
        checks.add(new ListCheckBean("listRyokinKomokuMeisho", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "料金項目名称"));
        checks.add(new ListCheckBean("listRyokinKomokuMeisho", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "料金項目名称", "40"));
        checks.add(new ListCheckBean("listTekiyoKaishibi", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "適用開始日"));
        checks.add(new ListCheckBean("listShosutenKbn", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "小数点区分"));
        checks.add(new ListCheckBean("listSeigyoKbn", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "制御区分"));
        checks.add(new ListCheckBean("listZeiKbn", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "税区分"));
        checks.add(new ListCheckBean("listYusoUriageSetSaki", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "輸送売上セット先"));
        checks.add(new ListCheckBean("listOroshitanka", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "卸単価", "9"));
        checks.add(new ListCheckBean("listOroshitanka", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NUMBER, "卸単価"));
        checks.add(new ListCheckBean("listOroshineritsu", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "卸値率", "5"));
        checks.add(new ListCheckBean("listOroshineritsu", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NUMBER, "卸値率"));
        checks.add(new ListCheckBean("listOroshineritsu", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_DECIMAL_MAXE_SIZE, "卸値率", "1"));
        checks.add(new ListCheckBean("listOroshineritsu", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_INTEGER_MAXE_SIZE, "卸値率", "3"));
        checks.add(new ListCheckBean("listOroshineritsu", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "卸値率", "5"));
        checks.add(new ListCheckBean("listShoriKamokuCd", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "処理科目コード"));
        checks.add(new ListCheckBean("listHojoKamokuCd", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "補助科目コード"));
        checks.add(new ListCheckBean("listTekiyoMei", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "適用名"));
        checks.add(new ListCheckBean("listTekiyoMei", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "適用名", "40"));
        List<MessageModuleBean> checkMsgList = listCheckBean.check(checkParamas, checks,true);

        return checkMsgList.isEmpty();
    }

    /**
     * 更新履歴を表示処理
     *
     */
    public void rirekiIchiran() {

        //履歴テーブル検索キー設定
        rirekiSearchKey = new HashMap();

        // 選択されたレコードを取得する
        Map<String, Object> selectRec = mst382Form.getSelectedSearchResult().get(0);
        rirekiSearchKey.put("listRyokinKomokuCd", selectRec.get("listRyokinKomokuCd"));
        rirekiSearchKey.put("listTekiyoKaishibi", selectRec.get("listTekiyoKaishibi"));

        //履歴タイトル設定
        rirekiSyosaiBean.setListColName(new ArrayList<>(Arrays.asList("バージョン情報", "料金項目コード",
                "料金項目名称", "適用開始日", "明細区分", "値引不可フラグ", "小数点区分", "制御区分",
                "制御区分名称", "税区分", "輸送売上セット先", "卸単価", "卸値率", "卸科目コード", "卸科目名称",
                "処理科目コード", "処理科目名称", "補助科目コード", "補助科目名称", "適用名", "適用終了日")));

        //履歴beanの項目物理名設定
        List<String> colValue = new ArrayList<>(Arrays.asList("listCharterRyokinKomokuVersion",
                "listRyokinKomokuCd", "listRyokinKomokuMeisho", "listTekiyoKaishibiRire", "listMeisaiKbn",
                "listNebikifukaFlg", "listShosutenKbn", "listSeigyoKbn", "listSeigyoKbnName", "listZeiKbn",
                "listYusoUriageSetSaki", "listOroshitanka", "listOroshineritsu", "listOroshiKamokuCd",
                "listOroshiKamokuMeisho", "listShoriKamokuCd", "listShoriKamokuMeisho", "listHojoKamokuCd",
                "listHojoKamokuMeisho", "listTekiyoMei", "listTekiyoShuryobiRire"));

        List<String> colAlign = new ArrayList<>(Arrays.asList("center", "left", "left", "left", "center",
                "center", "left", "left", "left", "left", "left", "right", "right", "left", "left", "left",
                "left", "left", "left", "left", "left"));
         
        List<RirekiListCol> listCol = new ArrayList<>();
        for (int i = 0; i < colValue.size(); i++) {
            RirekiListCol col = new RirekiListCol();
            col.setColValue(colValue.get(i));
            col.setColAlign(colAlign.get(i));
            listCol.add(col);
        }
        rirekiSyosaiBean.setListCol(listCol);

        //履歴テーブル検索する
        rirekiSyosaiBean.searchList("2", "MST382_SEARCH_RIREKI", rirekiSearchKey);
    }
 
    /**
     * メニュークリック処理
     *
     * @param menuId メニューID
     * @param nextScreenId 遷移先画面ID
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreenId) {
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移を行う
        url = forward(nextScreenId, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック処理
     *
     * @param nextScreenId 遷移先画面ID
     * @param breadIndex パンくずのインデックス
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreenId, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        url = forward(nextScreenId, null, null, true);
        return url;
    }

    /**
     * ログアウトクリック処理
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authorityConfBean.logout();
    }

    /**
     * 卸科目取得Autocomplete一覧を取得する処理
     * 
     * @param key 検索キー
     * @return Autocompleteリスト
     */
    public List<String> getAutoCompForOroshiKamokuCdList(String key) {
        return autoCompleteBean.getStringListByKey(MsCnst.COM_GET_OROSHI_KAMOKU_CD, key);
    }

    /**
     * 処理科目取得Autocomplete一覧を取得する処理
     * 
     * @param key 検索キー
     * @return Autocompleteリスト
     */
    public List<String> getAutoCompForShoriKamokuCdList(String key) {
        return autoCompleteBean.getStringListByKey(MsCnst.COM_GET_SHORI_KAMOKU_CD, key);
    }

    /**
     * 補助科目取得Autocomplete一覧を取得する処理
     * 
     * @param key 検索キー
     * @return Autocompleteリスト
     */    
    public List<String> getAutoCompForHojoKamokuCdList(String key) {
        return autoCompleteBean.getStringListByKey(MsCnst.COM_GET_HOJO_KAMOKU_CD, key);
    }

    /**
     * CSVファイルのタイトルを設定する処理
     * 
     * @return 画面タイトル
     */
    public List<CSVDto> getHeader() {
       
        List<CSVDto> header = new ArrayList<>();
        header.add(new CSVDto("料金項目コード", "listRyokinKomokuCd"));
        header.add(new CSVDto("料金項目名称", "listRyokinKomokuMeisho"));
        header.add(new CSVDto("適用開始日", "listTekiyoKaishibiDownload"));
        header.add(new CSVDto("明細区分", "listMeisaiKbn"));
        header.add(new CSVDto("値引不可フラグ", "listNebikifukaFlg"));
        header.add(new CSVDto("小数点区分", "listShosutenKbn"));
        header.add(new CSVDto("制御区分", "listSeigyoKbn"));
        header.add(new CSVDto("制御区分名称", "listSeigyoKbnName"));
        header.add(new CSVDto("税区分", "listZeiKbn"));
        header.add(new CSVDto("輸送売上セット先", "listYusoUriageSetSaki"));
        header.add(new CSVDto("卸単価", "listOroshitanka"));
        header.add(new CSVDto("卸値率", "listOroshineritsu"));
        header.add(new CSVDto("卸科目コード", "listOroshiKamokuCd"));
        header.add(new CSVDto("卸科目名称", "listOroshiKamokuMeisho"));
        header.add(new CSVDto("処理科目コード", "listShoriKamokuCd"));
        header.add(new CSVDto("処理科目名称", "listShoriKamokuMeisho"));
        header.add(new CSVDto("補助科目コード", "listHojoKamokuCd"));
        header.add(new CSVDto("補助科目名称", "listHojoKamokuMeisho"));
        header.add(new CSVDto("適用名", "listTekiyoMei"));
        header.add(new CSVDto("適用終了日", "listTekiyoShuryobiDownload"));
        
        // 取得値を返却する
        return header;
    }

    /**
     * 業務削除処理ファンクション領域
     *
     */
    public void delRowsFunc() {

        pageCommonBean.getSelectedDatasList().put(DATA_TABLE_ID, mst382Form.getSelectedSearchResult());
        pageCommonBean.delRows(DATA_TABLE_ID);

    }
    
    /**
     * 業務削除処理
     *
     * @param recordList レコードリスト
     * @return 正常／異常
     */
    public Boolean delRows(List<Map<String, Object>> recordList) {

        // エラーメッセージを格納する変数の初期化
        msgList = new ArrayList<>();

        // 行選択チェック
        if (recordList.isEmpty()) {
            MessageModuleBean message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0013);
            msgList.add(message);
            return false;
        }

        // 存在チェック
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(recordList, FUNC_CODE_DELETE_EXIST);

        // エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {

            MessageModuleBean message = messagePropertyBean.createMessageModule(
                    res.getMessages().get(0)[0],
                    res.getMessages().get(0)[1],
                    res.getMessages().get(0)[2],
                    TITLE);
            msgList.add(message);
            messagePropertyBean.messageList(msgList);

            return false;
        }

        // 削除実施
        int status = deleteCharterRyokinKomokuList(recordList);

        // エラーの場合、処理を終了
        if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            return false;
        }

        // 画面レコード削除
        mst382Form.getSearchResult().removeAll(recordList);

        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0004, "削除");

        // ログ出力
        LOGGER.info("削除 " + recordList.size() + " 件");

        return true;
    }

    /**
     * ダウンロード理由を記録する処理
     *
     * @param comment 理由コメント
     * @return 正常／異常
     * @throws Exception
     */
    public boolean beforeDown(String comment) throws Exception {
        
        // ダウンロード理由を記録する
        System.out.println(comment);
        
        return true;
    }

    /**
     * DBからチャーター料金項目マスタ検索件数を取得する
     */
    private long getCharterRyokinKomokuListKensu() {

        // パラメータ
        Map<String, Object> params = new HashMap<>();

        // 処理科目
        if (mst382Form.getConSyoriKamoku() != null) {
            params.put("conShorikamoku", mst382Form.getConSyoriKamoku().getValue());
        } else {
            params.put("conShorikamoku", null);
        }
         // 補助科目
        if (mst382Form.getConHojoKamoku() != null) {
            params.put("conHojoKamoku", mst382Form.getConHojoKamoku().getValue());
        } else {
            params.put("conHojoKamoku", null);
        }

        // 料金項目コード
        params.put("conRyokinKomokuCd", mst382Form.getConRyokinKomokuCd());
        // 料金項目名称
        params.put("conRyokinKomokuMeisho", mst382Form.getConRyokinKomokuMeisho());
        // 世代検索条件
        params.put("conSedaiKensakuJoken", mst382Form.getConSedaiKensakuJoken());
        // 適用日
        params.put("conTekiyoBi", mst382Form.getConTekiyoBi());
        // 適用名
        params.put("conTekiyoMei", mst382Form.getConTekiyoMei());
        // 削除済のみ
        params.put("conSakujoSumiNomi", mst382Form.getConSakujoSumiNomi());
        
        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH_KENSU);

        return Long.valueOf(res.getJson());
    }

    /**
     * ダウンロード用検索結果取得
     * 
     * @return 検索結果
     */
    private List<Map<String, Object>> getSearchResult() {
        return mst382Form.getSearchResult();
    }

    /**
     * DBからチャーター料金項目マス情報を取得する
     */
    private List<Map<String, Object>> getCharterRyokinKomokuList() {

        // パラメータ
        Map<String, Object> params = new HashMap<>();

        // ワーク.料金項目コード
        params.put("conRyokinKomokuCd", mst382Form.getConRyokinKomokuCd());

        // ワーク.料金項目名称
        params.put("conRyokinKomokuMeisho", mst382Form.getConRyokinKomokuMeisho());

        // 処理科目
        if (mst382Form.getConSyoriKamoku() != null) {
            params.put("conShorikamoku", mst382Form.getConSyoriKamoku().getValue());
        } else {
            params.put("conShorikamoku", null);
        }
         // 補助科目
        if (mst382Form.getConHojoKamoku() != null) {
            params.put("conHojoKamoku", mst382Form.getConHojoKamoku().getValue());
        } else {
            params.put("conHojoKamoku", null);
        }

        // ワーク.補助科目名
        params.put("conHojoKamokuMei", mst382Form.getConHojoKamokuMei());

        // ワーク.世代検索条件
        params.put("conSedaiKensakuJoken", mst382Form.getConSedaiKensakuJoken());

        // ワーク.適用日
        params.put("conTekiyoBi", mst382Form.getConTekiyoBi());

        // ワーク.削除のみ検索
        params.put("conSakujoSumiNomi", mst382Form.getConSakujoSumiNomi());

        // ワーク.適用名
        params.put("conTekiyoMei", mst382Form.getConTekiyoMei());

        try {
             // DBをアクセス
            ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH);

            ObjectMapper mapper = new ObjectMapper();
            mst382Form.setSearchResult(mapper.readValue(res.getJson(), List.class));

        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }

        // 検索結果一覧データ
        List<Map<String, Object>> searchResultList = new ArrayList();

        // 金額フォーマット(###,###,###)
        DecimalFormat decimalFormat1 = new DecimalFormat("###,###,###");
        // 金額フォーマット(###.#)
        DecimalFormat decimalFormat2 = new DecimalFormat("###.#");

        // 日付フォーマット
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");

        for(Map<String, Object> result : mst382Form.getSearchResult()) {

            // 適用開始日ダウンロード
            if (result.get("listTekiyoKaishibiDownload") != null &&  result.get("listTekiyoKaishibiDownload") != "") {
                result.replace("listTekiyoKaishibiDownload", 
                    dateFormat.format(result.get("listTekiyoKaishibiDownload")));
            }

            // 卸単価
            if (result.get("listOroshitanka") != null &&  result.get("listOroshitanka") != "") {
                result.replace("listOroshitanka", 
                    decimalFormat1.format(result.get("listOroshitanka")));
            }

            // 卸値率
            if (result.get("listOroshineritsu") != null &&  result.get("listOroshineritsu") != "") {
                result.replace("listOroshineritsu", 
                    decimalFormat2.format(result.get("listOroshineritsu")));
            }

            // 適用終了日ダウンロード
            if (result.get("listTekiyoShuryobiDownload") != null &&  result.get("listTekiyoShuryobiDownload") != "") {
                result.replace("listTekiyoShuryobiDownload", 
                    dateFormat.format(result.get("listTekiyoShuryobiDownload")));
            }

            searchResultList.add(result);

        }
        
        mst382Form.setSearchResult(null);
        mst382Form.setSearchResult(searchResultList);

        // らチャーター料金項目マス情報を返却する
        return mst382Form.getSearchResult();
    }
    
    /**
     * DBへチャーター料金項目マスタを登録また更新する
     */
    private int insertUpdateCharterRyokinKomokuList() {
        
        // 更新、登録チェック
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(
                mst382Form.getSelectedSearchResult(), FUNC_CODE_INSERT_UPDATE_CHECK);

        // エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            messagePropertyBean.message(
                            res.getMessages().get(0)[0],
                            res.getMessages().get(0)[1],
                            res.getMessages().get(0)[2],
                            res.getTableName());
            return res.getStatusCode();
        }

        // 登録一覧リストと更新一覧リストの内容処理する
        res = pageCommonBean.accsessDBWithList(mst382Form.getSelectedSearchResult(), FUNC_CODE_INSERT_UPDATE);

        return res.getStatusCode();
    }

    /**
     * DBからチャーター料金項目マスタ情報を削除する
     * 
     * @param recordList レコードリスト
     * @return ステータスコード
     */
    private int deleteCharterRyokinKomokuList(List<Map<String, Object>> recordList) {

        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(recordList, FUNC_CODE_DELETE_ROW);

        return res.getStatusCode();
    }

    /**
     * サブ検索条件入力判断
     * 
     * @return true:入力あり/false:入力しない
     */
    private boolean subSearchConHad() {

        // 適用名
        return !StringUtils.isEmpty(mst382Form.getConTekiyoMei());
    }

}