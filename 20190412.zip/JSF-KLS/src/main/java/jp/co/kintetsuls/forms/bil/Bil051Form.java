/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.forms.bil;

import java.util.List;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import lombok.Data;

/**
 *
 * @author qiuzhiyuan
 */
@javax.faces.bean.ManagedBean(name = "bil051Form")
@ViewScoped
@Data
public class Bil051Form {
    
    /**
     * 営業所コード
     */
    private AutoCompOptionBean conEigyoshoCd;
    
    /**
     * 請求先
     */
    private AutoCompOptionBean conSeikyuSaki;
    
    /**
     * 期間From
     */
     private String conKaishibi;
     
     /**
     * 期間To
     */
     private String conShuryobi;
     
     /**
     * 検索Visabled
     */
    private boolean btnSearchVisible;

    /**
     * 検索条件変更Visabled
     */
    private boolean btnSearchChangeVisible;
     
    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;

     /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;    

    /**
     * 選択された結果
     */
    private List<Map<String, String>> selectedSearchResult;
    
}
