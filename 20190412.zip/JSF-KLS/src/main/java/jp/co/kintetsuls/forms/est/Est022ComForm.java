/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.est;

import java.util.List;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.est.EstimationTab;
import lombok.Data;

/**
 * 見積り詳細画面 フォーム
 *
 * @author 作成者 (MBP)
 * @version 2019/1/29 新規作成
 */
@javax.faces.bean.ManagedBean(name = "est022ComForm")
@ViewScoped
@Data
public class Est022ComForm {

    // *****見積り提案情報**********
    /**
     * 見積り提案番号
     */
    private String teianMitsumoriTeianNo;

    /**
     * 提案名
     */
    private String teianTeianMei;

    /**
     * 顧客コード
     */
    private String teianKokyakuCd;

    /**
     * 顧客名
     */
    private String teianKokyakuMei;

    /**
     * 適用開始日
     */
    private String teianTekiyoKaishibi;

    /**
     * 伝票種別
     */
    private String teianDenpyoShubetsuCd;

    /**
     * 元払／着払／引取
     */
    private String teianMotoChakuHikitoriKbn;

    /**
     * 申請ステータス
     */
    private String teianMitsumoriStatusCd;

    // *****各種料金設定エリア**********
    /**
     * 見積り作成エリアのタブ
     */
    private List<EstimationTab> mitsuTab;
    
    /**
     * 表示タブ
     */
    private int activeTab;

     /**
     * タブindex
     */
    private int tabIndex;
    
    // *****見積り基本情報**********
    /**
     * 見積り番号
     */
    private String mitsuMitsumoriNo;

    /**
     * メモ
     */
    private String mitsuMitsumoriMemo;

    /**
     * 営業担当者
     */
    private String mitsuEigyoTantoUserMei;

    /**
     * 更新者
     */
    private String mitsuKoshinUserMei;

    /**
     * 更新日時
     */
    private String mitsuKoshinBi;

    /**
     * 値引(割増)/割戻
     */
    private String mitsuNebikiWarimds;
    
    /**
     * 値引
     */
    private String mitsuNebikiWarimdsBtn;
	 
    /**
     * 見積りタイトル
     */
    private String mitsuTanoMitsumoriTabCreate;

    // *****備考**********
    /**
     * 段組み
     */
    private String mitsuDangumi;
    
    /**
     * 備考内容選択（１列目）
     */
    private List<String> mitsuBikoSelectList1;
    
    /**
     * 備考１列目
     */
    private String mitsuBiko1;
    
    /**
     * 備考内容選択（２列目）
     */
    private List<String> mitsuBikoSelectList2;
    
    /**
     * 備考２列目
     */
    private String mitsuBiko2;
    
}
