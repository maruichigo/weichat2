package jp.co.kintetsuls.cnst;

/**
 * ManagedBeanのアノテーションを定義
 */
public class Cnst {

    public enum SCREEN {
        //各画面情報を追記してください。
        //ここで定義したものは画面遷移で使用されます。
        //ex.  SCREEN_ID(BeanのAnnotation, xhtmlファイル名),
        SAMPLE("sample","/contents/sample/sample.xhtml"),
        LOGIN_SCREEN("login","/login.xhtml"),
        TOP_SCREEN("top", "/contents/top/top.xhtml"), //トップ画面
        //車輌管理
        CAR011_SCREEN("car011", "/contents/car/car011.xhtml"), //車両一覧画面
        CAR021_SCREEN("car021", "/contents/car/car021.xhtml"), //車両配達詳細画面

        //現金回収
        CAS011_SCREEN("cas011", "/contents/cas/cas011.xhtml"),//現金回収入力画面
        CAS021_SCREEN("cas021", "/contents/cas/cas021.xhtml"),//現金回収管理台帳画面

        //顧客管理
        CUS011_SCREEN("cus011", "/contents/cus/cus011.xhtml"), //顧客一覧画面
        CUS012_SCREEN("cus012", "/contents/cus/cus012.xhtml"), //顧客マスタメンテナンス画面
		
        //EDI
        EDI021_SCREEN("edi021","/contents/top/edi021.xhtml"),   //顧客EDI設定画面
        EDI011_SCREEN("edi011","/contents/edi/edi021.xhtml"), //EDI一覧画面

        //見積り
        EST041_SCREEN("est041", "/contents/est/est041.xhtml"),//ロジ料金表メンテナンス画面

        //送り状管理
        INV011_SCREEN("inv011", "/contents/inv/inv011.xhtml"), //送り状発行一覧
        INV012_SCREEN("inv012", "/contents/inv/inv012.xhtml"), //送り状発行実績
        INV021_SCREEN("inv021", "/contents/inv/inv021.xhtml"), //送り状発行詳細
        INV022_SCREEN("inv022", "/contents/inv/inv022.xhtml"), //送り状発行荷受人選択
        INV023_SCREEN("inv023", "/contents/inv/inv023.xhtml"), //送り状発行パターン一覧画面

        //ログイン
        LGN011_SCREEN("lgn011", "/contents/lgn/lgn011.xhtml"), //ログイン画面
        LGN021_SCREEN("lgn021", "/contents/lgn/lgn021.xhtml"), //パスワード変更画面
        LGN031_SCREEN("lgn031", "/contents/lgn/lgn031.xhtml"), //パスワード初期化画面

        //マスタ管理
        MST011_SCREEN("mst011", "/contents/mst/mst011.xhtml"), //ユーザマスタ画面
        MST031_SCREEN("mst031", "/contents/mst/mst031.xhtml"), //住所マスタ画面
        MST032_SCREEN("mst032", "/contents/mst/mst032.xhtml"), //住所マスタ詳細画面
        MST041_SCREEN("mst041", "/contents/mst/mst041.xhtml"), //営業所マスタ画面
        MST042_SCREEN("mst042", "/contents/mst/mst042.xhtml"), //営業所詳細画面
        MST051_SCREEN("mst051", "/contents/mst/mst051.xhtml"), //代理店マスタ画面
        MST052_SCREEN("mst052", "/contents/mst/mst052.xhtml"), //代理店マスタ詳細
        MST071_SCREEN("mst071", "/contents/mst/mst071.xhtml"), //集約コードマスタ画面
        MST081_SCREEN("mst081", "/contents/mst/mst081.xhtml"), //顧客集約設定マスタ画面
        MST091_SCREEN("mst091", "/contents/mst/mst091.xhtml"), //仕入予定一覧画面
        MST092_SCREEN("mst092", "/contents/mst/mst092.xhtml"), //仕入予定詳細
        MST111_SCREEN("mst111", "/contents/mst/mst111.xhtml"), //ルートマスタ画面
        MST131_SCREEN("mst131", "/contents/mst/mst131.xhtml"),//仕込先マスタ画面
        MST132_SCREEN("mst132", "/contents/mst/mst132.xhtml"), //仕込先マスタ詳細画面
        MST141_SCREEN("mst141", "/contents/mst/mst141.xhtml"), //施設マスタ一覧
        MST142_SCREEN("mst142", "/contents/mst/mst142.xhtml"), //施設マスタ詳細
        MST151_SCREEN("mst151", "/contents/mst/mst151.xhtml"), //品名マスタ画面
        MST171_SCREEN("mst171", "/contents/mst/mst171.xhtml"), //荷受人マスタ画面
        MST172_SCREEN("mst172", "/contents/mst/mst172.xhtml"), //荷受人マスタ詳細画面     
        MST181_SCREEN("mst181", "/contents/mst/mst181.xhtml"), //記事マスタ画面
        MST211_SCREEN("mst211", "/contents/mst/mst211.xhtml"), //車両マスタ画面
        MST264_SCREEN("mst264", "/contents/mst/mst264.xhtml"), //航空運賃表詳細
        MST271_SCREEN("mst271", "/contents/mst/mst271.xhtml"), //Mst271_代理店・中継配達料金表一覧
        MST272_SCREEN("mst272", "/contents/mst/mst272.xhtml"), //Mst272_代理店・中継配達料金表詳細
        MST291_SCREEN("mst291", "/contents/mst/mst291.xhtml"), //料金項目マスタ画面
        MST301_SCREEN("mst301", "/contents/mst/mst301.xhtml"), //ロジ料金項目マスタ
        MST351_SCREEN("mst351", "/contents/mst/mst351.xhtml"), //卸分配マスタ画面
        MST361_SCREEN("mst361", "/contents/mst/mst361.xhtml"), //月額自動請求マスタ(輸送売上)
        MST362_SCREEN("mst362", "/contents/mst/mst362.xhtml"), //月額自動請求マスタ(その他請求)画面
        MST363_SCREEN("mst363", "/contents/mst/mst363.xhtml"), //月額自動請求項目マスタ(その他売上)画面
        MST371_SCREEN("mst371", "/contents/mst/mst371.xhtml"), //付帯料金項目マスタ画面
        MST382_SCREEN("mst382", "/contents/mst/mst382.xhtml"), //チャーター付帯料金項目マスタ
        MST451_SCREEN("mst451", "/contents/mst/mst451.xhtml"), //利用可能機能権限グループ画面
        MST461_SCREEN("mst461", "/contents/mst/mst461.xhtml"), //営業日カレンダー画面
        MST471_SCREEN("mst471", "/contents/mst/mst471.xhtml"), //号車マスタ画面
        MST481_SCREEN("mst481", "/contents/mst/mst481.xhtml"), //K-INGコード変換マスタ画面
        MST501_SCREEN("mst501", "/contents/mst/mst501.xhtml"), //仕向地名マスタ画面
        MST012_SCREEN("mst012", "/contents/mst/mst012.xhtml"), //住所マスタ画面
        MST511_SCREEN("mst511", "/contents/mst/mst511.xhtml"), //Mst511_代理承認者設定マスタ

        //Mwb
        MWB011_SCREEN("mwb011", "/contents/mwb/mwb011.xhtml"), //Mwb011_MAWB一覧
        MWB031_SCREEN("mwb031", "/contents/mwb/mwb031.xhtml"), //VOID入力
        MWB041_SCREEN("mwb041", "/contents/mwb/mwb041.xhtml"), //MAWB状況照会画面

        //売上管理
        PRO012_SCREEN("pro012", "/contents/pro/pro012.xthml"), //売上入力訂正
        PRO013_SCREEN("pro013", "/contents/pro/pro013.xthml"), //売上一覧訂正
        PRO014_SCREEN("pro014", "/contents/pro/pro014.xhtml"), //売上入力訂正（その他売上）画面
        PRO015_SCREEN("pro015", "/contents/pro/pro015.xhtml"), //売上スキャン結果一覧画面
        PRO016_SCREEN("pro016", "/contents/pro/pro016.xhtml"), //売上スキャン訂正画面
        PRO018_SCREEN("pro018", "/contents/pro/pro018.xthml"), //売上状況管理画面
        PRO019_SCREEN("pro019", "/contents/pro/pro019.xthml"), //売上漏れ一覧画面
        PRO032_SCREEN("pro032", "/contents/pro/pro032.xthml"), //売上入力訂正(ロジ)
        PRO033_SCREEN("pro033", "/contents/pro/pro033.xhtml"), //売上入力訂正（ロジ）_明細入力画面
        PRO034_SCREEN("pro034", "/contents/pro/pro034.xhtml"), //ロジ元データ修正画面
        PRO041_SCREEN("pro041", "/contents/pro/pro041.xhtml"), //その他請求一覧画面
        PRO042_SCREEN("pro042", "/contents/pro/pro042.xhtml"), //売上入力訂正(その他請求)画面

        //TOP
        TOP011_SCREEN("top011", "/contents/top/top011.xhtml"), //TOP

        //輸送管理
        TRN021_SCREEN("trn021", "/contents/trn/trn021.xhtml"), //貨物詳細
        TRN026_SCREEN("trn026", "/contents/trn/trn026.xhtml"), //トレース入力詳細画面
        TRN041_SCREEN("trn041", "/contents/trn/trn041.xhtml"), //委託貨物照会画面
        TRN051_SCREEN("trn051", "/contents/trn/trn051.xhtml"), //トレース入力画面

        //請求管理
        BIL051_SCREEN("bil051", "/contents/bil/bil051.xhtml"), //請求予定画面
        UNC061_SCREEN("unc061", "/contents/unc/unc061.xhtml"), //顧客未収残高報告画面
        UNC021_SCREEN("unc021","/contents/unc/unc021.xhtml"),   //入金入力画面
        BIL041_SCREEN("bil041","/contents/bil/bil041.xhtml"), //特別締め画面
        BIL021_SCREEN("bil021","/contents/bil/bil021.xhtml"),   //請求書の詳細画面

        //履歴画面用
        RIREKISYOSAI_SCREEN("rirekisyosai", "/contents/mst/rirekisyosai.xhtml"), //履歴詳細画面
        RIREKILIST_SCREEN("rirekiList", "/contents/mst/rirekiList.xhtml"), //履歴一覧
        
        EST022_SCREEN("est022","/contents/est/est022.xhtml"),   //見積り詳細画面
        
        //共通画面
        UPLOAD_SCREEN("upload", "/contents/upload/upload.xhtml"), // 共通アップロード画面
        DEM012_SCREEN("dem012", "/contents/dem/dem012.xhtml"), // 共通申請画面 
        DEM011_SCREEN("dem011", "/contents/dem/dem011.xhtml"), // 申請一覧 
        ;
        private final String anno;
        private final String xhtml;
        private SCREEN(String anno, String xhtml) {
            this.anno = anno;
            this.xhtml = xhtml;
        }

        public String getAnno() {
            return anno;
        }
        public String getXhtml() {
            return xhtml;
        } 
    }
    
    public enum SCREEN_ACT {
        //メニュー、パンくずクリック時のonstart,oncompleteのイベントをここで定義してください。
        //全画面に展開されます
        //イベントが無い場合は記載しません。
        //ex.  (onstartのイベント, oncompleteのイベント),
        START_COMPLETE("","")    //定義情報
        //START_COMPLETE("PF('blw').block();","doConfirm(args); PF('blw').unblock();scrollTo(0,0);")
        ;
        private final String onStart;
        private final String onComplete;
        
        private SCREEN_ACT(String onStart, String onComplete) {
            this.onStart = onStart;
            this.onComplete = onComplete;
        }

        public String getOnStart() {
            return onStart;
        }
        public String getOnComplete() {
            return onComplete;
        } 
    }


}
