/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.est;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.event.FacesEvent;
import javax.faces.model.SelectItem;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.exception.LogicException;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.forms.est.Est022ComForm;
import jp.co.kintetsuls.forms.est.Est022PackForm;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.component.commandbutton.CommandButton;

/**
 * 見積り詳細画面画面
 *
 * @author 作成者 (MBP)
 * @version 2019/1/29 新規作成
 */
@javax.faces.bean.ManagedBean(name = "est022")
@ViewScoped
@Data
public class Est022Bean extends BaseBean {

    private final String strTitle = "見積り詳細画面";
    private String url;

    // パンくずリスト
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    // 権限
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    // メッセージ
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messageProperty;

    // 見積り共通部分情報
    @ManagedProperty(value = "#{est022ComForm}")
    private Est022ComForm comForm;

    // 見積りパック料金
    @ManagedProperty(value = "#{est022PackForm}")
    private Est022PackForm packForm;

    // 見積りパック料金
    @ManagedProperty(value = "#{est022PackDetail}")
    private Est022PackDetail packDetail;

    private static final Logger logger = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    /**
     * コンストラクタ
     */
    public Est022Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId クリックされたメニューID（メニューからの遷移以外はNULL）
     * @param prevScreen 遷移元の画面
     * @param backFlag 戻るフラグ（前画面へボタンからの遷移以外はFALSE）
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            // パンくず追加
            breadBean.push("見積り詳細画面", SCREEN.EST022_SCREEN.name(), this);

            // タブ初期化
            initTabs();

        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }

        // TODO CHECKBOXリストを取得する
        //est022Form.setXXXLabelValueList(labelValueBean.getStringList("Function code", "サービスパラメーター"));
    }

    /**
     * メニュークリック（処理）
     *
     * @param menuId クリックされたメニューID（メニューからの遷移以外はNULL）
     * @param nextScreen 遷移先の画面
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }

        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック（処理）
     *
     * @param nextScreen 遷移先の画面
     * @param breadIndex 選択されたパンくずのIndex
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }
        url = forward(nextScreen, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authConfBean.logout();
    }

    public String getStrTitle() {
        return strTitle;
    }

    /**
     * 見積り画面起動時の初期処理
     *
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    public void initTabs()
            throws LogicException, SystemException {

        //見積り提案情報部
        initMitsuBasic();

        //画面タブ
        this.comForm.setMitsuTab(new ArrayList());
        this.comForm.setActiveTab(-1);
        this.comForm.setTabIndex(-1);

    }

    /**
     * 見積り画面にTabを追加するメソッド
     *
     * @param event
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    public void addDetailTab(FacesEvent event)
            throws LogicException, SystemException {
        // 各画面をタブに追加
        String id = ((CommandButton) event.getSource()).getId();
        //パック
        if (id != null && id.equals("SBT_PACK")) {
            addNewTab("パック料金", "./est022_pack_detail.xhtml", 0);
            //ノーマル
        } else if (id != null && id.equals("SBT_NORMAL")) {
            addNewTab("ノーマル運賃", "./est022_normal_detail.xhtml", 1);
            //付帯
        } else if (id != null && id.equals("SBT_INCIDENTAL")) {
            addNewTab("付帯料金", "./est022_incidental_detail.xhtml", 2);
            //チャーター
        } else if (id != null && id.equals("SBT_CHARTER")) {
            addNewTab("チャーター料金", "./est022_charter_detail.xhtml", 3);
        }
    }

    /**
     * TAB追加
     *
     * @param title
     * @param url
     * @param index
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    private void addNewTab(String title, String url, int index) throws LogicException, SystemException {
        List<EstimationTab> tabs = comForm.getMitsuTab();
        EstimationTab tab = new EstimationTab(title, url, index);
        boolean exist = false;
        int activeIndex = 0;
        // タブ存在かどうか
        for (EstimationTab item : tabs) {
            if (item.getTitle().equals(title)) {
                exist = true;
                activeIndex = tabs.indexOf(item);
                break;
            }
        }
        if (!exist) {
            tabs.add(tab);
            // 見積り基本情報部
            initEstimationHeader();
            // タブ詳細部
            initTabDetail(index);
            // 備考
            initEstimationFooter();
            
            activeIndex = tabs.size() -1;
        }
        this.comForm.setActiveTab(activeIndex);
        this.comForm.setTabIndex(index);
    }

    /**
     * 追加TAB初期化
     *
     * @param index
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    private void initTabDetail(int index) throws LogicException, SystemException {
        // 各タブを初期化する
        switch (index) {
            case 0:
                // パック料金作成
                initPack();
                break;
            case 1:
                // ノーマル運賃作成
                initNormal();
                break;
            case 2:
                // 付帯料金作成
                initIncidental();
                break;
            case 3:
                // チャーター料金作成
                initCharter();
                break;
            default:
                break;
        }
    }

    /**
     * パック料金設定画面　初期処理（Tab追加時）
     *
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    private void initPack() throws LogicException, SystemException {

        //パック料金設定部 項目初期化
        this.packDetail.initpackCommom();

        //都道府県リスト１～３セット
        this.packDetail.initPackPrefectures();

        //市区町村リストセット
        this.packDetail.initPackMunicipalities();

        //料金セット
        this.packDetail.initPackPrices();

        //ランク別設定情報セット
        this.packDetail.initPackRanks();

    }

    /**
     * ノーマル運賃設定画面　初期処理（Tab追加時）
     *
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    private void initNormal() throws LogicException, SystemException {
        //ノーマル運賃設定部 項目初期化

    }

    /**
     * チャーター料金設定画面　初期処理（Tab追加時）
     *
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    private void initCharter() throws LogicException, SystemException {
        //チャーター料金設定部 項目初期化

    }

    /**
     * 付帯料金設定画面　初期処理（Tab追加時）
     *
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    private void initIncidental() throws LogicException, SystemException {
        //付帯料金設定部 項目初期化

    }

    /**
     * 見積り提案情報　初期処理
     *
     * @param item
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    private void initMitsuBasic() throws LogicException, SystemException {

        // 見積り提案番号
        this.comForm.setTeianMitsumoriTeianNo("test");

        // 提案名
        this.comForm.setTeianTeianMei("test");

        // 顧客コード
        this.comForm.setTeianKokyakuCd("test");

        // 顧客名
        this.comForm.setTeianKokyakuMei("test");

        // 適用開始日
        this.comForm.setTeianTekiyoKaishibi("test");

        // 伝票種別
        this.comForm.setTeianDenpyoShubetsuCd("test");

        // 元払／着払／引取
        this.comForm.setTeianMotoChakuHikitoriKbn("test");

        // 申請ステータス
        this.comForm.setTeianMitsumoriStatusCd("test");
    }

    /**
     * 見積り基本情報　初期処理（Tab追加時）
     *
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    private void initEstimationHeader() throws LogicException, SystemException {
        // 見積り番号
        this.comForm.setMitsuMitsumoriNo("test");

        // メモ
        this.comForm.setMitsuMitsumoriMemo("test");

        // 営業担当者
        this.comForm.setMitsuEigyoTantoUserMei("test");

        // 更新者
        this.comForm.setMitsuKoshinUserMei("test");

        // 更新日時
        this.comForm.setMitsuKoshinBi("test");

        // 値引(割増)/割戻
        this.comForm.setMitsuNebikiWarimds("test");

        // 値引
        this.comForm.setMitsuNebikiWarimdsBtn("test");

        // 見積りタイトル
        this.comForm.setMitsuTanoMitsumoriTabCreate("test");
    }

    /**
     * 備考　初期処理（Tab追加時）
     *
     * @throws jp.co.kintetsuls.exception.LogicException logic
     * @throws jp.co.kintetsuls.exception.SystemException system
     */
    private void initEstimationFooter() throws LogicException, SystemException {
        // 段組み
        this.comForm.setMitsuDangumi("01");

        // 備考内容選択（１列目）
        this.comForm.setMitsuBikoSelectList1(new ArrayList());

        // 備考１列目
        this.comForm.setMitsuBiko1("test");

        // 備考内容選択（２列目）
        this.comForm.setMitsuBikoSelectList2(new ArrayList());

        // 備考２列目
        this.comForm.setMitsuBiko2("test");
    }

}
