/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.forms.mst.Mst092Form;
import static jp.co.kintetsuls.utils.DateUtils.ROUND_UP;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 仕入予定詳細
 *
 * @author 廖鈺 (MBP)
 * @version 2019/2/02 新規作成
 */
@ManagedBean(name = "mst092")
@ViewScoped
@Data
public class Mst092Bean extends BaseBean {

    /**
     * パンくず名とCSVタイトル
     */
    private final String TITLE = "仕入予定詳細";

    /**
     * 画面URL
     */
    private String url;

    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * 画面共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

    /**
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authorityConfBean;
    
    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;

    /**
     * 画面項目保持
     */
    @ManagedProperty(value = "#{mst092Form}")
    private Mst092Form mst092Form;

    /**
     * 履歴一覧処理共通
     */
    @ManagedProperty(value = "#{rirekisyosai}")
    private RirekiSyosaiBean rirekiSyosai;

    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(
            new Object() {}.getClass().getEnclosingClass().getName());

    /**
     * スクリーンコード：MST092
     */
    private static final String SC_CD_MST092 = "MST092_SCREEN";

    /**
     * 定数：検索ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH_SHIIRE_YOTEI = "mst092_search_shiire_yotei";

    /**
     * 定数：検索ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH_SHIIRE_YOTEI_MEISAI = "mst092_search_shiire_yotei_meisai";

    /**
     * 定数：適用開始日エンターキー押下ファンクションコード
     */
    private static final String FUNC_CODE_GET_TEKIYO_KAISHIBI = "mst092_get_tekiyo_kaishibi"; 
 
    /**
     * 定数：登録処理ファンクションコード
     */
    private static final String FUNC_CODE_INSERT = "mst092_insert";
    
    /**
     * 定数：更新処理ファンクションコード
     */
    private static final String FUNC_CODE_UPDATE = "mst092_update";
    
    /**
     * 定数：論理削除処理ファンクションコード
     */
    private static final String FUNC_CODE_RONRI_DELETE = "mst092_ronri_delete";
    
    /**
     * 定数：削除処理ファンクションコード
     */
    private static final String FUNC_CODE_DELETE = "mst092_delete";
    
    /**
     * 定数：削除処理ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH_ZEI_RITSU = "mst092_search_zei_ritsu";
    
    /**
     * 定数：登録のチェックファンクションコード
     */
    private static final String FUNC_CODE_INSERT_EXIST_CHECK = "mst092_insert_exist_check";
    
    /**
     * 定数：更新のチェックファンクションコード
     */
    private static final String FUNC_CODE_UPDATE_EXIST_CHECK = "mst092_update_exist_check";

    /**
     * 定数：一覧のデータテーブルID
     */
    private static final String DATA_SHIIRE_YOTEI_ID = "tablesorter_mst092_2";
    
    /**
     * 定数：一覧のデータテーブルID
     */
    private static final String DATA_SHIIRE_YOTEI_MEISAI_ID = "tablesorter_mst092";
    
    /**
     * 定数：削除の存在チェックファンクションコード
     */
    private static final String FUNC_CODE_DELETE_EXIST_CHECK = "mst092_delete_exist_check";
    
    /**
     * 定数：画面項目保持キー
     */
    private static final String CONST_MST092_FORM = "mst092Form";
    
    /**
     * 定数：MasterInfo取得キー
     */
    private static final String CONST_MST092_MASTER = "mst092";
    
    /**
     * 定数：再検索ボタン取得キー
     */
    private static final String CONST_MST092_SEARCH = "search_mst092";    

    /**
     * ワーク.メッセージリスト
     */
    List<MessageModuleBean> msgList = new ArrayList<>();

    /**
     * コンストラクタ
     */
    public Mst092Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId　メニューID
     * @param prevScreen 遷移元画面ID
     * @param backFlag 戻るフラグ
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {

            // パンくず追加
            breadBean.push(TITLE, Cnst.SCREEN.MST092_SCREEN.name(), this);

            // マスタ内容取得
            pageCommonBean.getMasterInfo(CONST_MST092_MASTER);

            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(営業所リスト)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO);
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(仕入先)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_SHIIRESAKI);
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(仕入区分)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_MS_SHIIRE_RYOKIN_KOMOKU);
            
            // 税率検索
            try {
                ServiceInterfaceBean res = pageCommonBean.getDBInfo(null, FUNC_CODE_SEARCH_ZEI_RITSU);
                ObjectMapper mapper = new ObjectMapper();
                mst092Form.setZeiRitsuResult(mapper.readValue(res.getJson(), Map.class));
            } catch (IOException ex) {
                LOGGER.error(ex.getMessage(), ex);
            }
            // 戻ってきた場合
            Mst092Form preForm = (Mst092Form) pageCommonBean.getPageInfo(CONST_MST092_FORM);
            if (backFlag && preForm != null) {
                PageCommonBean.simpleCopy(preForm, mst092Form);
                // 再検索を実施する
                pageCommonBean.searchAgain(CONST_MST092_SEARCH);
            } else {
                // 進んできた場合
                Flash flash = pageCommonBean.getPageParam();
                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_MST092_FORM) != null) {
                    PageCommonBean.simpleCopy(flash.get(CONST_MST092_FORM), mst092Form);
                    // 再検索を実施する
                    pageCommonBean.searchAgain(CONST_MST092_SEARCH);
                }
            }
            
            // component初期化とユーザ権限により制御設定
            pageCommonBean.setAuthControll(mst092Form, SC_CD_MST092, true);

            List<Map<String, Object>> res = new ArrayList<>();
            mst092Form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(res));
            pageCommonBean.setDatalist(DATA_SHIIRE_YOTEI_MEISAI_ID, res);

            // 初期はデータを編集不可にする
            mst092Form.setBtnEditeDisabled(true);

        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * メニュークリック処理
     *
     * @param menuId メニューID
     * @param nextScreen 遷移先画面ID
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック処理
     *
     * @param nextScreen 遷移先画面ID
     * @param breadIndex パンくずのインデックス
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {
        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        url = forward(nextScreen, null, null, true);
        return url;
    }

    /**
     * ログアウトクリック処理
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authorityConfBean.logout();
    }
    
    /**
     * 検索入力項目チェック
     *
     * @return 正常／異常
     */
    public boolean searchCheck() {
        
        boolean checked = true;
        // 営業所コード チェック
        if (mst092Form.getConEigyoshoCd() == null || "".equals(mst092Form.getConEigyoshoCd().getValue())) {
            messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003,
                        "listFormMst092:Eigyosho:conEigyosho",
                        "営業所コード");
            checked = false;
        }
        
        // 仕入先コード チェック
        if (mst092Form.getConShiiresakiCd() == null || "".equals(mst092Form.getConShiiresakiCd().getValue())) {
            messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003,
                        "listFormMst092:Shiiresaki:conShiiresaki",
                        "仕入先コード");
            checked = false;
        }
        
        // 仕入区分 チェック
        if (mst092Form.getConShiireKbn() == null || "".equals(mst092Form.getConShiireKbn().getValue())) {
            messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003,
                        "listFormMst092:shiireKbn:conShiireKbn",
                        "仕入区分コード");
            checked = false;
        }
        
        // 適用開始日 チェック
        if (mst092Form.getConTekiyoKaishibi()== null || "".equals(mst092Form.getConTekiyoKaishibi())) {
            messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003,
                        "listFormMst092:tekiyoKaishibi:conTekiyoKaishibi",
                        "適用開始日");
            checked = false;
        }
        
        return checked;
    }

    /**
     * 検索処理
     *
     */
    public void search() {

        if(!searchCheck()) {
            return ;
        }
        // 選択リストを初期化
        mst092Form.setSelectedSearchResult(new ArrayList<>());
        mst092Form.setSearchResultMsShiireYotel(null);
        mst092Form.setSearchResultMsShiireYotelMeisai(null);
        
       // 履歴テーブル検索キーを初期化する
       mst092Form.setRirekiSearchKey(null);
        
        // 検索結果リストを初期化
        List<Map<String, Object>> res = new ArrayList<>();

        // 仕入予定マスタ検索し、取得した値を画面項目にセット
        res = getMsShiireYotelResultList();
        
        if(res != null) {
          mst092Form.setSearchResultMsShiireYotel(new ReportListDataModel(res));  
        }
        pageCommonBean.setDatalist(DATA_SHIIRE_YOTEI_ID, res);

        // 仕入予定明細マスタ検索し、取得した値を画面項目にセット
        res = new ArrayList<>();
        res = getMsShiireYotelMeisaiResultList();
        
        if(res != null) {
          mst092Form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(res));
        }
        pageCommonBean.setDatalist(DATA_SHIIRE_YOTEI_MEISAI_ID, res);
        // 有効データを編集可にする
        mst092Form.setBtnEditeDisabled(false);

        // 検索条件保存
        pageCommonBean.savePageInfo(CONST_MST092_FORM, mst092Form);

        // 参照モードにする
        pageCommonBean.setEditFlg(false);
        
        // 履歴テーブル検索キー
        Map<String, Object> rirekiSearchKey = new HashMap();
        rirekiSearchKey.put("EIGYOSHO_CD", mst092Form.getConEigyoshoCd().getValue());
        rirekiSearchKey.put("SHIIRESAKI_CD", mst092Form.getConShiiresakiCd().getValue());
        rirekiSearchKey.put("SHIIRE_KBN_CD", mst092Form.getConShiireKbn().getValue());
        
         mst092Form.setRirekiSearchKey(rirekiSearchKey);
         
         mst092Form.setConEigyoshoCdDisabled(true);
         mst092Form.setConShiireKbnDisabled(true);
         mst092Form.setConShiiresakiCdDisabled(true);
         mst092Form.setConTekiyoKaishibiDisabled(true);
        
        taniChange();
    }
    
    /**
     * 単位変更表示切替処理
     * 
     */
    public void taniChange() {
        
        String selectedVal = mst092Form.getConTani();
        // 月と日(明細) 仕入予定明細テーブルを表示する
        if ("1".equals(selectedVal) || "3".equals(selectedVal)) {
            mst092Form.setShiireYoteiMeisaiRendered(Boolean.TRUE);
            mst092Form.setShiireYoteiRendered(Boolean.FALSE);
        } else if ("2".equals(selectedVal)) {
            // 日(曜日) 曜日別仕入額テーブルを表示
            mst092Form.setShiireYoteiMeisaiRendered(Boolean.FALSE);
            mst092Form.setShiireYoteiRendered(Boolean.TRUE);
        } else {
            // 未選択全てテーブルを非表示する
            mst092Form.setShiireYoteiMeisaiRendered(Boolean.FALSE);
            mst092Form.setShiireYoteiRendered(Boolean.FALSE);
        }
    }

    /**
     * 金額計算処理
     * 
     */
    public void calBtnClick() {
        
        // 選択された結果取得キー
        int rowIndex = mst092Form.getSearchResultMsShiireYotelMeisai().getRowIndex();
        // 仕入額 入力チェック
        if (mst092Form.getCalSearchResult().get("listShiiregaku") == null || "".equals(
                mst092Form.getCalSearchResult().get("listShiiregaku"))) {
            return;
        }
        // うち非課税額 入力チェック
        if (mst092Form.getCalSearchResult().get("listUchiHikazeigaku") == null || "".equals(
                mst092Form.getCalSearchResult().get("listUchiHikazeigaku"))) {
            return;
        }
        // 税率 入力チェック
        if (mst092Form.getZeiRitsuResult().get("ZEI_RITSU") == null || "".equals(
                mst092Form.getZeiRitsuResult().get("ZEI_RITSU"))) {
            return;
        }
        // 仕入額 
        BigDecimal shiiregaku = new BigDecimal(
                String.valueOf(mst092Form.getCalSearchResult().get("listShiiregaku")));
        // うち非課税額 
        BigDecimal uchiHikazeigaku = new BigDecimal(
                String.valueOf(mst092Form.getCalSearchResult().get("listUchiHikazeigaku")));
        // 税率
        BigDecimal zeiRitsu = new BigDecimal(
                String.valueOf(mst092Form.getZeiRitsuResult().get("ZEI_RITSU")));
        
        // 消費税額（外税）
        BigDecimal shohizei = shiiregaku.subtract(uchiHikazeigaku).multiply(zeiRitsu).divide(
                new BigDecimal(100).add(zeiRitsu), ROUND_UP);
        // 経費負担額
        BigDecimal keihiHutangaku = shiiregaku.subtract(uchiHikazeigaku).subtract(shohizei);
        
        if(mst092Form.getSearchResultMsShiireYotelMeisai().getDatasource().get(rowIndex).get(
                "listKeihiHutangaku") == null ) {
            // 選択された結果経費負担額を设定する
            mst092Form.getSearchResultMsShiireYotelMeisai().getDatasource().get(rowIndex).put(
                    "listKeihiHutangaku", keihiHutangaku);
            // 選択された結果消費税額（外税）を设定する
            mst092Form.getSearchResultMsShiireYotelMeisai().getDatasource().get(rowIndex).put(
                    "listShohizei", shohizei);
        } else {
            // 選択された結果経費負担額を设定する
            mst092Form.getSearchResultMsShiireYotelMeisai().getDatasource().get(rowIndex).replace(
                    "listKeihiHutangaku", keihiHutangaku);
            // 選択された結果消費税額（外税）を设定する
            mst092Form.getSearchResultMsShiireYotelMeisai().getDatasource().get(rowIndex).replace(
                    "listShohizei", shohizei);
        }
    }
    
    /**
     * 検索条件「適用開始日」のENTERキー押下後イベント
     * 検索条件.適用開始日に、取得結果.適用開始日を設定する
     * 
     */
    public void getTekiyoKaishibi() {

        // パラメータ設定
        Map<String, Object> params = new HashMap<>();

        if(mst092Form.getConEigyoshoCd() != null) {
            // 営業所コード
            params.put("conEigyoshoCd",mst092Form.getConEigyoshoCd().getValue());
        } 
        if(mst092Form.getConShiiresakiCd() != null) {
            // 仕入先コード
            params.put("conShiiresakiCd",mst092Form.getConShiiresakiCd().getValue());
        } 
        if(mst092Form.getConShiireKbn() != null) {
            // 仕入区分
            params.put("conShiireKbn",mst092Form.getConShiireKbn().getValue());
        } 
        if(mst092Form.getConEigyoshoCd() == null || mst092Form.getConShiiresakiCd() == null || 
                mst092Form.getConShiireKbn() == null || mst092Form.getConTekiyoKaishibi() != null) {
            return;
        }
        
        try {
            // DBをアクセス
            ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, FUNC_CODE_GET_TEKIYO_KAISHIBI);
            ObjectMapper mapper = new ObjectMapper();
            List<Map<String, Object>> searchResult = mapper.readValue(serviceInterfaceBean.getJson(), List.class);
            if (searchResult != null && searchResult.size() > 0) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
                // 適用開始日
                mst092Form.setConTekiyoKaishibi(dateFormat.format(
                        new Date(Long.valueOf(searchResult.get(0).get("LISTTEKIYOKAISHIBI").toString()))));
                // 適用開始日（退避用）
                mst092Form.setConTekiyoKaishibiTaihi(
                        new Date(Long.valueOf(searchResult.get(0).get("LISTTEKIYOKAISHIBI").toString())));
            }
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }
    
        
    /**
     * 行追加（仕入予定明細テーブル用）
     *
     * @param id 画面リストID
     * @param toLast listの下に追加するフラグ
     */
    public void addRow(String id, Boolean toLast) {

        // 対象リスト取得
        List<Map<String, Object>> selectList = pageCommonBean.getDatasLists().get(id);
        if (selectList.isEmpty()) {
            toLast = true;
        }

        pageCommonBean.addRow(id, toLast);
    }
    
    /**
     * 登録処理 更新処理
     *
     */
    public void insertOrUpdate() { 
        
        List<Map<String, Object>> params = getShiireYoteiParams();
        params.addAll(getShiireYoteiMeisaiParams());
        
        if(params.get(0).get("listSearchFlg") != null) {
            // 更新処理
            update();
        } else {
            // 登録処理を行う
            insert();
        }
    }
    
    /**
     * 業務論理削除処理
     *
     */
    public void ronriDelRows() {
	
        // エラーメッセージを格納する変数の初期化を行う
        msgList = new ArrayList();
	// 論理削除処理を行う
        List<Map<String, Object>> params = getShiireYoteiParams();
        params.addAll(getShiireYoteiMeisaiParams());

        // 存在チェック
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(params, FUNC_CODE_DELETE_EXIST_CHECK);
        
        // エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
	    
            MessageModuleBean message = messagePropertyBean.createMessageModule( 
                    res.getMessages().get(0)[0], 
                    res.getMessages().get(0)[1],
                    res.getMessages().get(0)[2]);
            msgList.add(message);
            messagePropertyBean.messageList(msgList);
	    return;
        }

        // 削除処理を行う
        int status = ronriDelete(params);
        
        // エラーの場合、処理を終了
        if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            MessageModuleBean message = messagePropertyBean.createMessageModule( 
                   "WARN", MessageCnst.COME0014);
            msgList.add(message);
            messagePropertyBean.messageList(msgList);
            return;
        }
	
	// 画面初期表示とする
        // 単位
	mst092Form.setConTani(null);
	// 単価
        mst092Form.setConTanka(null);
	// 営業所コード
        mst092Form.setConEigyoshoCd(null);
	// 仕入区分
        mst092Form.setConShiireKbn(null);
	// 仕入先コード
        mst092Form.setConShiiresakiCd(null);
	// 適用名
        mst092Form.setConTekiyoMei(null);
	// 適用開始日
        mst092Form.setConTekiyoKaishibi(null);
	// 適用終了
        mst092Form.setConTekiyoShuryo(null);
	// 適用終了日
	mst092Form.setListTekiyoShuryobi(null);
	// 明細一覧
        List<Map<String, Object>> result = new ArrayList<>();
        mst092Form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(result));
        pageCommonBean.setDatalist(DATA_SHIIRE_YOTEI_MEISAI_ID, result);
	// 予定一覧
	mst092Form.setSearchResultMsShiireYotel(null);
	// 土
	mst092Form.setListYobibetuShiiregakuDoyo(new BigDecimal("0"));
	// 月
	mst092Form.setListYobibetuShiiregakuGetuyo(new BigDecimal("0"));
	// 火
	mst092Form.setListYobibetuShiiregakuKayo(new BigDecimal("0"));
	// 金
	mst092Form.setListYobibetuShiiregakuKinyo(new BigDecimal("0"));
	// 木
	mst092Form.setListYobibetuShiiregakuMokuyo(new BigDecimal("0"));
	// 日祝
	mst092Form.setListYobibetuShiiregakuNichiSuku(new BigDecimal("0"));
	// 水
	mst092Form.setListYobibetuShiiregakuSuiyo(new BigDecimal("0"));
	taniChange();
        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, "論理削除");

    }
    
    /**
     * 業務削除処理
     *
     */
    public void delRows() {
        
        // エラーメッセージを格納する変数の初期化を行う
        msgList = new ArrayList();
	
	// 論理削除処理を行う
        List<Map<String, Object>> params = getShiireYoteiParams();

        // 存在チェック
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(params, FUNC_CODE_DELETE_EXIST_CHECK);
        
        // エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
	    
            MessageModuleBean message = messagePropertyBean.createMessageModule( 
                    res.getMessages().get(0)[0], 
                    res.getMessages().get(0)[1],
                    res.getMessages().get(0)[2]);
            msgList.add(message);
            messagePropertyBean.messageList(msgList);
            return;
        }

        // 削除処理を行う
        int status = delete(params);
        
        // エラーの場合、処理を終了
        if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            MessageModuleBean message = messagePropertyBean.createMessageModule( 
                   "WARN", MessageCnst.COME0014);
            msgList.add(message);
            messagePropertyBean.messageList(msgList);
            return;
        }
        // 画面初期表示とする
        // 単位
        mst092Form.setConTani(null);
        // 単価
        mst092Form.setConTanka(null);
        // 営業所コード
        mst092Form.setConEigyoshoCd(null);
        // 仕入区分
        mst092Form.setConShiireKbn(null);
        // 仕入先コード
        mst092Form.setConShiiresakiCd(null);
        // 適用名
        mst092Form.setConTekiyoMei(null);
        // 適用開始日
        mst092Form.setConTekiyoKaishibi(null);
        // 適用終了
        mst092Form.setConTekiyoShuryo(null);
        // 適用終了日
        mst092Form.setListTekiyoShuryobi(null);
        // 明細一覧
        List<Map<String, Object>> result = new ArrayList<>();
        mst092Form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(result));
        pageCommonBean.setDatalist(DATA_SHIIRE_YOTEI_MEISAI_ID, result);
        // 予定一覧
        mst092Form.setSearchResultMsShiireYotel(null);
        // 土
        mst092Form.setListYobibetuShiiregakuDoyo(new BigDecimal("0"));
        // 月
        mst092Form.setListYobibetuShiiregakuGetuyo(new BigDecimal("0"));
        // 火
        mst092Form.setListYobibetuShiiregakuKayo(new BigDecimal("0"));
        // 金
        mst092Form.setListYobibetuShiiregakuKinyo(new BigDecimal("0"));
        // 木
        mst092Form.setListYobibetuShiiregakuMokuyo(new BigDecimal("0"));
        // 日祝
        mst092Form.setListYobibetuShiiregakuNichiSuku(new BigDecimal("0"));
        // 水
        mst092Form.setListYobibetuShiiregakuSuiyo(new BigDecimal("0"));
        taniChange();

        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, "削除");
        
    }
    
    /**
     * DBから仕向地名マスタ情報を取得する
     * 
     * @param downloadFlg ダウンロードフラグ
     */
    private List<Map<String, Object>> getMsShiireYotelResultList() {

        // パラメータ
        Map<String, Object> params = getParamas();

        try {
            // DBをアクセス
            ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH_SHIIRE_YOTEI);
            ObjectMapper mapper = new ObjectMapper();
            mst092Form.setSearchResult(mapper.readValue(res.getJson(), List.class));

        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
        if(!mst092Form.getSearchResult().isEmpty()) {
            setShiireYoteiData(mst092Form.getSearchResult());
        }
       
        return mst092Form.getSearchResult();
    }
    
    /**
     * 曜日別仕入額テーブルデータを设定する
     * 
     * @param resultList 仕入予定マスタ検索結果一覧データ
     */
    private void setShiireYoteiData(List<Map<String, Object>> resultList) {
        
            // 曜日別仕入額_土
            mst092Form.setListYobibetuShiiregakuDoyo(new BigDecimal(
                     resultList.get(0).get("listYobibetuShiiregakuDoyo").toString()));
            // 曜日別仕入額_月
            mst092Form.setListYobibetuShiiregakuGetuyo(new BigDecimal(
                    resultList.get(0).get("listYobibetuShiiregakuGetuyo").toString()));
            // 曜日別仕入額_火
            mst092Form.setListYobibetuShiiregakuKayo(new BigDecimal(
                    resultList.get(0).get("listYobibetuShiiregakuKayo").toString()));
            // 曜日別仕入額_金
            mst092Form.setListYobibetuShiiregakuKinyo(new BigDecimal(
                    resultList.get(0).get("listYobibetuShiiregakuKinyo").toString()));
            // 曜日別仕入額_木
            mst092Form.setListYobibetuShiiregakuMokuyo(new BigDecimal(
                    resultList.get(0).get("listYobibetuShiiregakuMokuyo").toString()));
            // 曜日別仕入額_日祝
            mst092Form.setListYobibetuShiiregakuNichiSuku(new BigDecimal(
                    resultList.get(0).get("listYobibetuShiiregakuNichiSuku").toString()));
            // 曜日別仕入額_水
            mst092Form.setListYobibetuShiiregakuSuiyo(new BigDecimal(
                    resultList.get(0).get("listYobibetuShiiregakuSuiyo").toString()));
            // 単位
            mst092Form.setConTani(resultList.get(0).get("conTani").toString());
            // 単価
            mst092Form.setConTanka(resultList.get(0).get("conTanka").toString());
            // 適用終了日
            if(resultList.get(0).get("listTekiyoShuryobi") != null) {
                 mst092Form.setListTekiyoShuryobi(resultList.get(0).get("listTekiyoShuryobi").toString());
            }
            // 仕入予定データバージョン
            mst092Form.setListShiireYoteiDataVersion(
                    resultList.get(0).get("listShiireYoteiDataVersion").toString());
    }

    /**
     * DBから仕向地名マスタ情報を取得する
     * 
     * @param downloadFlg ダウンロードフラグ
     */
    private List<Map<String, Object>> getMsShiireYotelMeisaiResultList() {

        // パラメータ
        Map<String, Object> params = getParamas();

        try {
            // DBをアクセス
            ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH_SHIIRE_YOTEI_MEISAI);
            ObjectMapper mapper = new ObjectMapper();
            mst092Form.setSearchResult(mapper.readValue(res.getJson(), List.class));

        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
        return mst092Form.getSearchResult();
    }
    
    /**
     * パラメータを設定する
     * 
     * @param downloadFlg ダウンロードフラグ
     * @return 検索結果パラメータ
     */
    private Map<String, Object> getParamas() {
        
        // パラメータを設定する
        Map<String, Object> params = new HashMap<>();
        
        // 画面フォームを取得する
        Mst092Form tempForm = mst092Form;
        
        // 営業所コード
        params.put("conEigyoshoCd", tempForm.getConEigyoshoCd().getValue());
        // 仕入先コード
        params.put("conShiiresakiCd", tempForm.getConShiiresakiCd().getValue());
        // 仕入区分
        params.put("conShiireKbn", tempForm.getConShiireKbn().getValue());
        // 適用開始日
        params.put("conTekiyoKaishibi", tempForm.getConTekiyoKaishibi());
        // 適用名
        params.put("conTekiyoMei", tempForm.getConTekiyoMei());
        return params;
    }
    
    /**
     * 登録処理
     *
     */
    private void insert() {

        // エラーメッセージを格納する変数の初期化を行う
        msgList = new ArrayList();
        
	// 登録処理を行う
        List<Map<String, Object>> params = getShiireYoteiParams();
        params.addAll(getShiireYoteiMeisaiParams());
	
                
        // 登録前チェック
	if (!insertOrUpdateCheck(params)) {
            return;
        }
        
	// 存在チェック
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(params, FUNC_CODE_INSERT_EXIST_CHECK);
	
	// エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
	    
            MessageModuleBean message = messagePropertyBean.createMessageModule( 
                    res.getMessages().get(0)[0], 
                    res.getMessages().get(0)[1],
                    res.getMessages().get(0)[2]);
            msgList.add(message);
            messagePropertyBean.messageList(msgList);
	    return;
        }
	    
        // DBをアクセスする
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.accsessDBWithList(params, FUNC_CODE_INSERT);
         // エラーの場合、処理終了
        if (serviceInterfaceBean.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            return;
        }
        // 再検索を実施する
        pageCommonBean.searchAgain(CONST_MST092_SEARCH);
        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, "登録");
        
	
    }
    
    /**
     * 更新処理
     *
     */
    private void update() {

        // エラーメッセージを格納する変数の初期化を行う
        msgList = new ArrayList();
        // 更新処理を行う
        List<Map<String, Object>> params = getShiireYoteiParams();
        params.addAll(getShiireYoteiMeisaiParams());
        
        // 更新前チェック
	if (!insertOrUpdateCheck(params)) {
            return;
        }

        // 存在チェック
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(params, FUNC_CODE_UPDATE_EXIST_CHECK);
        
        // エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
	    
            MessageModuleBean message = messagePropertyBean.createMessageModule( 
                    res.getMessages().get(0)[0], 
                    res.getMessages().get(0)[1],
                    res.getMessages().get(0)[2]);
            msgList.add(message);
            messagePropertyBean.messageList(msgList);
	    return;
        } 
        
        int status =  updateShiireList(params);
        
	// エラーの場合、処理終了
        if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
             MessageModuleBean message = messagePropertyBean.createMessageModule( 
                   "WARN", MessageCnst.COME0014);
            msgList.add(message);
            messagePropertyBean.messageList(msgList);
            return;
        }

        // 再検索を実施する
        pageCommonBean.searchAgain(CONST_MST092_SEARCH);
        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, "更新");

    }
    
    /**
     * DBへ仕入予定詳細を更新する処理
     * 
     * @param recordList レコードリスト
     * @return 正常／異常コード
     */
    private int updateShiireList(List<Map<String, Object>> recordList) {
	
	// DBをアクセス
        ServiceInterfaceBean serviceInterfaceBean =
                pageCommonBean.accsessDBWithList(recordList, FUNC_CODE_UPDATE);
        return serviceInterfaceBean.getStatusCode();
	
    }
    
    /**
     * 論理削除処理
     *
     * @param recordList レコードリスト
     * @return 正常／異常コード
     */
    private int ronriDelete(List<Map<String, Object>> recordList) {

        // DBをアクセス
        ServiceInterfaceBean serviceInterfaceBean =
                pageCommonBean.accsessDBWithList(recordList, FUNC_CODE_RONRI_DELETE);	    
        return serviceInterfaceBean.getStatusCode();
    }
    
    /**
     * 削除処理
     * 
     * @param recordList レコードリスト
     * @return 正常／異常コード
     */
    private int delete(List<Map<String, Object>> recordList) {

        // DBをアクセス
        ServiceInterfaceBean serviceInterfaceBean =
                pageCommonBean.accsessDBWithList(recordList, FUNC_CODE_DELETE);
        return serviceInterfaceBean.getStatusCode();
    }
    
    /**
     * 更新（登録）入力項目チェック
     * 
     * @param params
     * @return 
     */
    public boolean insertOrUpdateCheck(List<Map<String, Object>> params) {
        
        // チェックFlg
        boolean checked = true;
        for (Map<String, Object> param : params) {
            if ("shiireYotei".equals(param.get("tableFlg").toString())) {
                // 営業所コード
                if (param.get("conEigyoshoCd") == null) {
                    // エラーの場合、処理終了
                    messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003,
                            "listFormMst092:Eigyosho:conEigyosho",
                            "営業所コード");
                    checked = false;
                }
                // 仕入先コード
                if (param.get("conShiiresakiCd") == null) {
                    // エラーの場合、処理終了
                    messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003,
                            "listFormMst092:Shiiresaki:conShiiresaki",
                            "仕入先コード");
                    checked = false;
                }
                // 仕入区分コード
                if (param.get("conShiireKbn") == null) {
                    // エラーの場合、処理終了
                    messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003,
                            "listFormMst092:shiireKbn:conShiireKbn",
                            "仕入区分コード");
                    checked = false;
                }
                // 適用開始日
                if (param.get("conTekiyoKaishibi") == null) {
                    // エラーの場合、処理終了
                    messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003,
                            "listFormMst092:tekiyoKaishibi:conTekiyoKaishibi",
                            "適用開始日");
                    checked = false;
                }
                // 適用名
                if (param.get("conTekiyoMei") == null) {
                    // エラーの場合、処理終了
                    messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003,
                            "listFormMst092:tekiyoMei:conTekiyoMei",
                            "適用名");
                    checked = false;
                }
                // 単位
                if (param.get("conTani") == null) {
                    // エラーの場合、処理終了
                    messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003,
                            "listFormMst092:tani:listTani",
                            "単位");
                    checked = false;
                }
                // 単価
                if (param.get("conTanka") == null) {
                    // エラーの場合、処理終了
                    messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003,
                            "listFormMst092:tanka:conTanka",
                            "単価");
                    checked = false;
                }
            }
        }
        if(checked)
        {
            checked = checkParams(params);
        }
        
        return checked;
    }
    
    private boolean checkParams(List<Map<String, Object>> params) {
        
        // エラーメッセージを格納する変数の初期化を行う
        msgList = new ArrayList();
        for (Map<String, Object> param : params) {
            if ("shiireYotei".equals(param.get("tableFlg").toString())) {
                // 曜日別仕入額(月)
                if (param.get("listYobibetuShiiregakuGetu") == null) {
                    MessageModuleBean message = messagePropertyBean.createMessageModule(
                            MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003,
                            "曜日別仕入額(月)");
                    msgList.add(message);
                    messagePropertyBean.messageList(msgList);
                    return false;
                } else {
                    if (Long.valueOf(param.get("listYobibetuShiiregakuGetu").toString()) < 0) {
                        MessageModuleBean message = messagePropertyBean.createMessageModule(
                                MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0024,
                                "曜日別仕入額(月)",
                                "0円");
                        msgList.add(message);
                        messagePropertyBean.messageList(msgList);
                        return false;
                    }
                }
                // 曜日別仕入額(火)
                if (param.get("listYobibetuShiiregakuKa") == null) {
                    MessageModuleBean message = messagePropertyBean.createMessageModule(
                            MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003,
                            "曜日別仕入額(火)");
                    msgList.add(message);
                    messagePropertyBean.messageList(msgList);
                    return false;
                } else {
                    if (Long.valueOf(param.get("listYobibetuShiiregakuKa").toString()) < 0) {
                        MessageModuleBean message = messagePropertyBean.createMessageModule(
                                MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0024,
                                "曜日別仕入額(火)",
                                "0円");
                        msgList.add(message);
                        messagePropertyBean.messageList(msgList);
                        return false;
                    }
                }
                // 曜日別仕入額(水)
                if (param.get("listYobibetuShiiregakuSui") == null) {
                    MessageModuleBean message = messagePropertyBean.createMessageModule(
                            MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003,
                            "曜日別仕入額(水)");
                    msgList.add(message);
                    messagePropertyBean.messageList(msgList);
                    return false;
                } else {
                    if (Long.valueOf(param.get("listYobibetuShiiregakuSui").toString()) < 0) {
                        MessageModuleBean message = messagePropertyBean.createMessageModule(
                                MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0024,
                                "曜日別仕入額(水)",
                                "0円");
                        msgList.add(message);
                        messagePropertyBean.messageList(msgList);
                        return false;
                    }
                }
                // 曜日別仕入額(木)
                if (param.get("listYobibetuShiiregakuMoku") == null) {
                    MessageModuleBean message = messagePropertyBean.createMessageModule(
                            MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003,
                            "曜日別仕入額(木)");
                    msgList.add(message);
                    messagePropertyBean.messageList(msgList);
                    return false;
                } else {
                    if (Long.valueOf(param.get("listYobibetuShiiregakuMoku").toString()) < 0) {
                        MessageModuleBean message = messagePropertyBean.createMessageModule(
                                MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0024,
                                "曜日別仕入額(木)",
                                "0円");
                        msgList.add(message);
                        messagePropertyBean.messageList(msgList);
                        return false;
                    }
                }
                // 曜日別仕入額(金)
                if (param.get("listYobibetuShiiregakuKin") == null) {
                    MessageModuleBean message = messagePropertyBean.createMessageModule(
                            MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003,
                            "曜日別仕入額(金)");
                    msgList.add(message);
                    messagePropertyBean.messageList(msgList);
                    return false;
                } else {
                    if (Long.valueOf(param.get("listYobibetuShiiregakuKin").toString()) < 0) {
                        MessageModuleBean message = messagePropertyBean.createMessageModule(
                                MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0024,
                                "曜日別仕入額(金)",
                                "0円");
                        msgList.add(message);
                        messagePropertyBean.messageList(msgList);
                        return false;
                    }
                }
                // 曜日別仕入額(土)
                if (param.get("listYobibetuShiiregakuDo") == null) {
                    MessageModuleBean message = messagePropertyBean.createMessageModule(
                            MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003,
                            "曜日別仕入額(土)");
                    msgList.add(message);
                    messagePropertyBean.messageList(msgList);
                    return false;
                } else {
                    if (Long.valueOf(param.get("listYobibetuShiiregakuDo").toString()) < 0) {
                        MessageModuleBean message = messagePropertyBean.createMessageModule(
                                MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0024,
                                "曜日別仕入額(土)",
                                "0円");
                        msgList.add(message);
                        messagePropertyBean.messageList(msgList);
                        return false;
                    }
                }
                // 曜日別仕入額(日祝)
                if (param.get("listYobibetuShiiregakuNichiSuku") == null) {
                    MessageModuleBean message = messagePropertyBean.createMessageModule(
                            MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003,
                            "曜日別仕入額(日祝)");
                    msgList.add(message);
                    messagePropertyBean.messageList(msgList);
                    return false;
                } else {
                    if (Long.valueOf(param.get("listYobibetuShiiregakuNichiSuku").toString()) < 0) {
                        MessageModuleBean message = messagePropertyBean.createMessageModule(
                                MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0024,
                                "曜日別仕入額(日祝)",
                                "0円");
                        msgList.add(message);
                        messagePropertyBean.messageList(msgList);
                        return false;
                    }
                }
            } else {
                // 管理NO
                if (param.get("listKanriNo") != null && !"".equals(param.get("listKanriNo"))) {
                    
                    Pattern pattern = Pattern.compile("[0-9]*");
                    Matcher isNum = pattern.matcher(param.get("listKanriNo").toString());
                    if (!isNum.matches()) {
                        MessageModuleBean message = messagePropertyBean.createMessageModule(
                                MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0010,
                                "管理NO");
                        msgList.add(message);
                        messagePropertyBean.messageList(msgList);
                        return false;
                    }
                }
                // うち非課税額
                if (param.get("listUchiHikazeigaku") == null || "".equals(param.get("listUchiHikazeigaku"))) {
                    MessageModuleBean message = messagePropertyBean.createMessageModule(
                            MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0024,
                            "うち非課税額",
                            "0円");
                    msgList.add(message);
                    messagePropertyBean.messageList(msgList);
                    return false;
                } else {
                    if (Long.valueOf(param.get("listUchiHikazeigaku").toString()) < 0) {
                        MessageModuleBean message = messagePropertyBean.createMessageModule(
                                MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0024,
                                "うち非課税額",
                                "0円");
                        msgList.add(message);
                        messagePropertyBean.messageList(msgList);
                        return false;
                    }
                }
                // 仕入額
                if (param.get("listShiiregaku") == null || "".equals(param.get("listShiiregaku"))) {
                    MessageModuleBean message = messagePropertyBean.createMessageModule(
                            MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003,
                            "仕入額");
                    msgList.add(message);
                    messagePropertyBean.messageList(msgList);
                    return false;
                } else {
                    if (Long.valueOf(param.get("listShiiregaku").toString()) < 0) {
                        MessageModuleBean message = messagePropertyBean.createMessageModule(
                                MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0024,
                                "仕入額",
                                "0円");
                        msgList.add(message);
                        messagePropertyBean.messageList(msgList);
                        return false;
                    }
                }
            }
        }
        
        return true;
    }
    
    /**
     * 仕入予定マスタパラメータを设定する
     *
     */
    private List<Map<String, Object>> getShiireYoteiParams() {

        // パラメータ
        List<Map<String, Object>> params = new ArrayList<>();
	
	Map<String, Object> param = new HashMap<>();
        
        // 営業所コード
        if (mst092Form.getConEigyoshoCd() != null) {
            param.put("conEigyoshoCd", mst092Form.getConEigyoshoCd().getValue());
        }
        // 仕入先コード
        if (mst092Form.getConShiiresakiCd() != null) {
            param.put("conShiiresakiCd", mst092Form.getConShiiresakiCd().getValue());
        }
        // 仕入区分
        if (mst092Form.getConShiireKbn() != null) {
            param.put("conShiireKbn", mst092Form.getConShiireKbn().getValue());
        }
        // 適用開始日
        if (mst092Form.getConTekiyoKaishibi() != null) {
            param.put("conTekiyoKaishibi", mst092Form.getConTekiyoKaishibi() + " 00:00:00");
        }
        // 適用名
        if (!"".equals(mst092Form.getConTekiyoMei()) && mst092Form.getConTekiyoMei() != null) {
            param.put("conTekiyoMei", mst092Form.getConTekiyoMei());
        }
        // 単位
        if (!"".equals(mst092Form.getConTani()) && mst092Form.getConTani() != null) {
            param.put("conTani", mst092Form.getConTani());
        }
        // 単価
        if (!"".equals(mst092Form.getConTanka()) && mst092Form.getConTanka() != null) {
            param.put("conTanka", mst092Form.getConTanka());
        }
        
        // 適用終了日
        if (!"".equals(mst092Form.getListTekiyoShuryobi()) && mst092Form.getListTekiyoShuryobi() != null) {
            param.put("listTekiyoShuryobi", mst092Form.getListTekiyoShuryobi() + " 23:59:59");
        }

        // 曜日別仕入額(月)
        param.put("listYobibetuShiiregakuGetu", mst092Form.getListYobibetuShiiregakuGetuyo());
        // 曜日別仕入額(火)
        param.put("listYobibetuShiiregakuKa", mst092Form.getListYobibetuShiiregakuKayo());
        // 曜日別仕入額(水)
        param.put("listYobibetuShiiregakuSui", mst092Form.getListYobibetuShiiregakuSuiyo());
        // 曜日別仕入額(木)
        param.put("listYobibetuShiiregakuMoku", mst092Form.getListYobibetuShiiregakuMokuyo());
        // 曜日別仕入額(金)
        param.put("listYobibetuShiiregakuKin", mst092Form.getListYobibetuShiiregakuKinyo());
        // 曜日別仕入額(土)
        param.put("listYobibetuShiiregakuDo", mst092Form.getListYobibetuShiiregakuDoyo());
        // 曜日別仕入額(日祝)
        param.put("listYobibetuShiiregakuNichiSuku", mst092Form.getListYobibetuShiiregakuNichiSuku());
        // 仕入予定データバージョン
        param.put("listShiireYoteiDataVersion", mst092Form.getListShiireYoteiDataVersion());
        if (mst092Form.getSearchResultMsShiireYotel() != null && 
                mst092Form.getSearchResultMsShiireYotel().getDatasource().size() >0) {
            // 更新ユーザーID
            param.put("koushinUserCd", 
                    mst092Form.getSearchResultMsShiireYotel().getDatasource().get(0).get("koushinUserCd"));
            // 更新カウンタ
            param.put("koushinCounter", 
                    mst092Form.getSearchResultMsShiireYotel().getDatasource().get(0).get("koushinCounter"));
            param.put("listSearchFlg", 
                    mst092Form.getSearchResultMsShiireYotel().getDatasource().get(0).get("listSearchFlg"));
        }
        
        // テーブルFLG
        param.put("tableFlg", "shiireYotei");

        params.add(param);
                
	return params;
    
    }
    
    /**
     * 仕入予定明細マスタパラメータを设定する
     *
     */
    private List<Map<String, Object>> getShiireYoteiMeisaiParams() {

        // パラメータ
        List<Map<String, Object>> params = new ArrayList<>();

        Map<String, Object> param = null;

        if (mst092Form.getSearchResultMsShiireYotelMeisai() != null
                && mst092Form.getSearchResultMsShiireYotelMeisai().getDatasource().size() > 0) {
            for (Map<String, Object> data : mst092Form.getSearchResultMsShiireYotelMeisai().getDatasource()) {
                param = new HashMap();
                // 営業所コード
                if (mst092Form.getConEigyoshoCd() != null) {
                    param.put("conEigyoshoCd", mst092Form.getConEigyoshoCd().getValue());
                }
                // 仕入先コード
                if (mst092Form.getConShiiresakiCd() != null) {
                    param.put("conShiiresakiCd", mst092Form.getConShiiresakiCd().getValue());
                }
                // 仕入区分
                if (mst092Form.getConShiireKbn() != null) {
                    param.put("conShiireKbn", mst092Form.getConShiireKbn().getValue());
                }
                // 適用開始日
                if (mst092Form.getConTekiyoKaishibi() != null) {
                    param.put("conTekiyoKaishibi", mst092Form.getConTekiyoKaishibi() + " 00:00:00");
                }
                // テーブルFLG
                param.put("tableFlg", "shiireYoteiMeisai");
                // 明細NO
                param.put("listMeisaiNo", data.get("listMeisaiNo"));
                // 管理NO
                param.put("listKanriNo", data.get("listKanriNo"));
                // 経費負担額
                param.put("listKeihiHutangaku", data.get("listKeihiHutangaku"));
                // うち非課税額
                param.put("listUchiHikazeigaku", data.get("listUchiHikazeigaku"));
                // 消費税(外税)
                param.put("listShohizei", data.get("listShohizei"));
                // 仕入額
                param.put("listShiiregaku", data.get("listShiiregaku"));
                // メモ
                param.put("listMemo", data.get("listMemo"));
                // 仕入予定データバージョン
                param.put("listShiireYoteiMeisaiDataVersion", data.get("listShiireYoteiDataVersion"));
                // 更新ユーザーID
                param.put("koushinUserCd", data.get("koushinUserCd"));
                // 更新カウンタ
                param.put("koushinCounter", data.get("koushinCounter"));
                
                // 追加flg
                if(data.get("addFlg") != null) {
                    param.put("addFlg", data.get("addFlg"));
                }

                params.add(param);
            } 
        } else {
            param = new HashMap();
            // 営業所コード
            if (mst092Form.getConEigyoshoCd() != null) {
                param.put("conEigyoshoCd", mst092Form.getConEigyoshoCd().getValue());
            }
            // 仕入先コード
            if (mst092Form.getConShiiresakiCd() != null) {
                param.put("conShiiresakiCd", mst092Form.getConShiiresakiCd().getValue());
            }
            // 仕入区分
            if (mst092Form.getConShiireKbn() != null) {
                param.put("conShiireKbn", mst092Form.getConShiireKbn().getValue());
            }
            // 適用開始日
            if (mst092Form.getConTekiyoKaishibi() != null) {
                param.put("conTekiyoKaishibi", mst092Form.getConTekiyoKaishibi());
            }
            // テーブルFLG
            param.put("tableFlg", "shiireYoteiMeisai");
            // 明細NO
            param.put("listMeisaiNo", "");
            // 管理NO
            param.put("listKanriNo", "");
            // 経費負担額
            param.put("listKeihiHutangaku", "");
            // うち非課税額
            param.put("listUchiHikazeigaku", "");
            // 消費税(外税)
            param.put("listShohizei", "");
            // 仕入額
            param.put("listShiiregaku", "");
            // メモ
            param.put("listMemo", "");
            // 仕入予定データバージョン
            param.put("listShiireYoteiMeisaiDataVersion", "");
            // 追加flg
            param.put("addFlg", "true");

            params.add(param);

            mst092Form.setSearchResultMsShiireYotelMeisai(new ReportListDataModel(params));
        }

        return params;

    }
}
