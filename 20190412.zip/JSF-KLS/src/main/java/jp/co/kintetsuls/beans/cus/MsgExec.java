package jp.co.kintetsuls.beans.cus;

import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

/**
 * メッセージ出力
 * @author ss.furutani
    ・java側から呼ぶ場合（1行単位)
    MsgExec.message("WARN", "", "msg");
    ・java側から呼ぶ場合（複数行単位)
    List<String[]> list = new java.util.ArrayList<>();
    list.add(new String[]{"INFO","","通常情報"});
    MsgExec.message(list);

    このクラスでのメソッドが呼ばれた場合、
    messagesコンポーネントで出力される。
 */
public class MsgExec {

    /**
     * javaの複数メッセージ呼び出し用
     *  
     * @param list
     *　 args[0] level   INFO,WARN,ERROR,FATAL
     * 　args[1] 強調メッセージ
     *   args[2] 画面出力メッセージ
     */
    public static void message(List<String[]> list){
        if (null == list || 0 == list.size()) {
            return; 
        }
        int size = list.size();
        if (0 != size) {
            FacesContext context = FacesContext.getCurrentInstance();
            for (String[] args : list){
                if (args.length == 1){
                    addMessage(context, getFaceMessage("INFO", "", args[0]));
                } else if (args.length == 2){
                    addMessage(context, getFaceMessage(args[0], "", args[1]));
                } else if (args.length >= 3){
                    addMessage(context, getFaceMessage(args[0], args[1], args[2]));
                }
            }
        }
    }

    /** 
     * xhtml画面用、通常メッセージ出力を行う。
     * new MsgExec().eInfoMessage("情報メッセージ");
     */
    public static void eInfoMessage(String message) {
        FacesContext.getCurrentInstance().addMessage("growl" , getFaceMessage("INFO", "", message));
    }
    /**
     * xhtml画面用、注意メッセージを画面出力する。
     * new MsgExec().eWarnMessage("注意メッセージ");
     * @param message 
     */
    public static void eWarnMessage(String message) {
        FacesContext.getCurrentInstance().addMessage("message" , getFaceMessage("WARN", "", message));
    }
    /**
     * xhtml画面用、警告メッセージを画面出力する
     * new MsgExec().eErrorMessage("警告メッセージ");
     */
    public static void eErrorMessage(String message) {
        FacesContext.getCurrentInstance().addMessage("message" , getFaceMessage("ERROR", "", message));
    }
    /**
     * xhtml画面用、異常メッセージを画面出力する
     * new MsgExec().eFatalMessage("異常メッセージ");
     */
    public static void eFatalMessage(String message) {
        FacesContext.getCurrentInstance().addMessage("message" , getFaceMessage("FATAL", "", message));
    }

    /**
     * facesMessageを生成
     * @param level   INFO,WARN,ERROR,FATAL
     * @param summary 協調メッセージ
     * @param message メッセージ内容
     * @return 
     */
    private static FacesMessage getFaceMessage(String level, String summary, String message){
        FacesMessage.Severity severity = getMsgIcon(level);
        return new FacesMessage(severity, summary, message);
    }

    /**
     * メッセージレベルによって処理を出力先を決定
     * @param context
     * @param fmsg 
     */
    private static void addMessage(FacesContext context, FacesMessage fmsg){
        if (fmsg.getSeverity() == FacesMessage.SEVERITY_INFO){
            //growl!
            context.addMessage("growl", fmsg);
        } else {
            //message!
            context.addMessage("message", fmsg);
        }
    }

    /**
    * メッセージleveliconを返却
     * @param level   INFO,WARN,ERROR,FATAL
     * INFO(通常)/WARN(注意)/ERROR(警告)/FATAL(異常)
     * @return Severity
     */
    public static FacesMessage.Severity getMsgIcon(String level){
        switch (level) {
            case "通常":
            case "INFO":
                return FacesMessage.SEVERITY_INFO;
            case "注意":
            case "WARN":
                return FacesMessage.SEVERITY_WARN;
            case "警告":
            case "ERROR":
                return FacesMessage.SEVERITY_ERROR;
            case "異常":
            case "FATAL":
                return FacesMessage.SEVERITY_FATAL;
            default:
                return FacesMessage.SEVERITY_INFO;
        }
    }
}
