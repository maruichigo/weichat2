/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.lgn;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import javax.naming.AuthenticationException;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.DirContextBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.SystemMasterBean;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.forms.lgn.Lgn011Form;
import jp.co.kintetsuls.service.LoginService;
import jp.co.kintetsuls.service.common.AuthorityService;
import jp.co.kintetsuls.service.common.MenuService;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.kintetsuls.utils.DateUtils;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import jp.co.sharedsys.beans.session.MenuBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * ログイン画面
 *
 * @author 黄華(MBP)
 * @version 2019/1/24 新規作成
 */
@javax.faces.bean.ManagedBean(name = "lgn011")
@ViewScoped
@Data
public class Lgn011Bean extends AbstractBean {

    /**
     * タイトル
     */
    private final String TITLE = "ログイン";
    
    /**
     * 遷移用URL
     */
    private String url;

    /**
     * 画面フォーム
     */
    @ManagedProperty(value = "#{lgn011Form}")
    private Lgn011Form lgn011Form;

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;

    /**
     * 画面共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * システムマスタBean
     */
    @ManagedProperty(value = "#{systemMasterBean}")
    private SystemMasterBean systemMasterBean;

    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * ログインユーザー情報
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    /**
     * メニューBean
     */
    @ManagedProperty(value = "#{menuBean}")
    private MenuBean menuBean;

    /**
     * ADサーバ接続BEAN
     */
    @ManagedProperty(value = "#{dirContextBean}")
    private DirContextBean dirContextBean;
    
    /**
     * ログイン情報取得サービス
     */
    private LoginService loginService = new LoginService();
    
    /**
     * 権限情報取得サービス
     */
    private AuthorityService authService = new AuthorityService();
    
    /**
     * Menu情報取得サービス
     */
    private MenuService menuService = new MenuService();
    
    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(
            new Object() {}.getClass().getEnclosingClass().getName());

    /**
     * Restサーバー接続サービス
     */
    private RestfullService rest;

    /**
     * 定数：お知らせ取得ファンクションコード
     */
    private static final String SEARCH_INFORM_FUNC_CODE = "lgn011-get-inform-detail";

    /**
     * 定数：パスワード誤入力回数を初期化するファンクションコード
     */
    private static final String INIT_KAISU_FUNC_CODE = "lgn011-init-pwdkaisu";

    /**
     * 定数：パスワード誤入力回数を登録更新するファンクションコード
     */
    private static final String UPDATE_KAISU_FUNC_CODE = "lgn011-update-pwdkaisu";

    /**
     * 定数：ユーザーコード存在チェックファンクションコード
     */
    private static final String LGN011_CHECK_USERCD = "lgn011-check-usercd";

    /**
     * 定数：ワンタイムパスワードログイン取得キー
     */
    private static final String CONST_ONETIME_PASS_LOGIN = "onetimePassLogin";    

    /**
     * 定数：画面項目維持用キー.
     */
    private static final String CONST_LGN011_FORM = "lgn011Form";

    /**
     * コンストラクタ
     */
    public Lgn011Bean() {

    }

    /**
     * 初期処理
     *
     * @param menuId メニューID
     * @param prevScreen 遷移元画面ID
     * @param backFlag 戻るフラグ
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            // システムマスタからパスワード誤入力最大回数取得
            lgn011Form.setHyoDtlPasswordGoNyuryokuSaidaiKaisu(
                    Integer.valueOf(systemMasterBean.getSysValByCdAndKanriGroup(
                            MsCnst.SYS_CD_PASSWORD_ERROR_MAX_KAISU,
                            MsCnst.SYS_CDGROUP_LGN011, MsCnst.SYS_CDGROUP_SYSTEM)));

            // お知らせ取得
            getInform();

        } catch (IOException ex) {
            // ログ出力
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * ログイン処理
     *
     * @return 遷移先の画面URL
     */
    public String login() {

        //ユーザー存在チェック
        if (!userCdExist()) {
            return "";
        }

        // ADサーバログイン
        try {
            // ADサーバログイン処理
            // 接続用コンテキストを作成する
            DirContext ctx = dirContextBean.initialDirContext(
                    lgn011Form.getHyoDtlUserCd(), lgn011Form.getHyoDtlPassword());
            
            // 接続成功した場合
            // パスワード誤入力回数初期化
            initPwdErrorKaisu();

            ctx.close();
            
            // 遷移先画面判定 
            return moveToScreenJudge();
        } catch (AuthenticationException ex) {
            // 接続に失敗した場合(AuthenticationException発生時)
            // パスワード誤入力回数登録更新
            // 取得結果.回数
            int kaisu = updatePwdErrorKaisu();

            // 取得結果.件数 + 1 <= ワーク.パスワード誤入力最大回数 の場合
            if (kaisu + 1 <= lgn011Form.getHyoDtlPasswordGoNyuryokuSaidaiKaisu()) {

                messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR,
                        MessageCnst.LGNE0009, "loginForm:hyoDtlErrorMessage");
                return "";
            } else {
                // 取得結果.件数 + 1 > ワーク.パスワード誤入力最大回数 の場合
                // エラーメッセージ表示を行い、ログイン(Lgn011)への遷移を行う
                messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR,
                        MessageCnst.LGNE0003, "loginForm:hyoDtlErrorMessage");
                return "";
            }
        } catch (Exception e) {
            // システムエラーが発生した場合(AuthenticationException以外のException発生時)
            messagePropertyBean.messageToArea(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COMF0002, "loginForm:hyoDtlErrorMessage");
            return "";
        }
    }

    /**
     * パスワード初期化ページへ遷移する
     *
     * @return 遷移URL
     */
    public String pwdInitLink() {
        url = forward(SCREEN.LGN031_SCREEN.name(), null, SCREEN.LGN011_SCREEN.name(), false);
        return url;
    }

    /**
     * メニュークリック処理
     *
     * @param menuId メニューID
     * @param nextScreen 遷移先画面ID
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {
        return null;
    }

    /**
     * パンくずクリック処理
     *
     * @param nextScreenId 遷移先画面ID
     * @param breadIndex パンくずのインデックス
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreenId, int breadIndex) {
        return null;
    }

    /**
     * ログアウトクリック処理
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return null;
    }
    
    /**
     * 初期設定ボタンクリック処理
     * 
     * @return 遷移先の画面URL
     */
    public String initSetting() {
        // TODO QA:DEV_KLS-1084
        url = forward(SCREEN.TOP011_SCREEN.name(), null, SCREEN.LGN011_SCREEN.name(), false);
        return url;
    }
    
    /**
     * .NET Frameworkボタンクリック処理
     * 
     * @return 遷移先の画面URL
     */
    public String netFramework() {
        // TODO QA:DEV_KLS-1084
        url = forward(SCREEN.TOP011_SCREEN.name(), null, SCREEN.LGN011_SCREEN.name(), false);
        return url;
    }
    
    /**
     * ユーザー存在チェック
     *
     * @return true:ユーザーコード存在、false:ユーザーコード存在しない
     */
    private boolean userCdExist() {

        // パラメータ構築
        Map<String, Object> params = new HashMap<>();
        params.put("hyoDtlUserCd", lgn011Form.getHyoDtlUserCd());

        // DBをアクセスして、ユーザー件数を取得する
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, LGN011_CHECK_USERCD);
        int kensu = Integer.valueOf(serviceInterfaceBean.getJson());

        // 戻り値設定
        if (kensu == 0) {
            messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0006, "loginForm:hyoDtlErrorMessage", "ユーザーコード", "ユーザーマスタ");
            return false;
        }
        return true;
    }

    /**
     * お知らせ取得処理
     *
     * @throws IOException
     */
    private void getInform() throws IOException {

        // パラメータ構築
        Map<String, Object> params = new HashMap<>();

        // DBをアクセスして、お知らせを取得する
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, SEARCH_INFORM_FUNC_CODE);

        // 戻り値設定
        ObjectMapper mapper = new ObjectMapper();
        List<Map<String, Object>> res = mapper.readValue(serviceInterfaceBean.getJson(), List.class);
        lgn011Form.setInformResultList(res);
    }
    
    /**
     * パスワード誤入力回数を初期化する
     */
    private void initPwdErrorKaisu() {

        // パラメータ構築
        Map<String, Object> params = new HashMap<>();
        params.put("userCd", lgn011Form.getHyoDtlUserCd());

        // DBをアクセスして、パスワード誤入力回数を初期化する
        pageCommonBean.getDBInfo(params, INIT_KAISU_FUNC_CODE);
    }

    /**
     * パスワード誤入力回数を登録更新する
     */
    private int updatePwdErrorKaisu() {

        // パラメータ構築
        Map<String, Object> params = new HashMap<>();
        params.put("userCd", lgn011Form.getHyoDtlUserCd());

        // DBをアクセスして、パスワード誤入力回数を更新化する
        ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, UPDATE_KAISU_FUNC_CODE);
        
        // 取得結果.回数
        return Integer.valueOf(res.getJson());
    }

    /**
     * 遷移先画面判定
     *
     * @throws NamingException
     */
    private String moveToScreenJudge() throws Exception {

        // ワンタイムパスワードフラグ
        String oneTimePasswordFlag = null;
        // パスワード有効期限
        Date passwordDeadLine = null;
        // TODO QA DEV_KLS-1083
        // 他システムでログインフラグ
        Boolean otherSysLoginFlag = false;
        
        // バインドユーザ
        String bindUser = messagePropertyBean.getProperties(StndConsIF.BIND_USER);
        // バインドユーザのパスワード
        String bindUserPassword = messagePropertyBean.getProperties(StndConsIF.BIND_USER_PASSWORD);
        
        // 接続用コンテキストを作成する
        DirContext ctx = dirContextBean.initialDirContext(bindUser, bindUserPassword);
       
        // 検索範囲指定用オブジェクトの初期化を行う
        SearchControls searchControls = new SearchControls();
        searchControls.setSearchScope(SearchControls.ONELEVEL_SCOPE);
        // 検索を実行する
        NamingEnumeration<SearchResult> result = ctx.search(
                bindUser, "CN=" + lgn011Form.getHyoDtlUserCd(), searchControls);

        // 検索結果を取得する
        while (result.hasMore()) {
            SearchResult sr = result.next();
            NamingEnumeration attributes = sr.getAttributes().getAll();

            while (attributes.hasMore()) {
                Attribute attr = (Attribute) attributes.nextElement();
                Enumeration values = attr.getAll();
                // 属性を1件ずつ取得して処理
                while (values.hasMoreElements()) {
                    // userCertificateを取得する
                    if("userCertificate".equals(attr.getID())) {
                        // ワンタイムパスワードフラグ
                        oneTimePasswordFlag = values.nextElement().toString();
                    } else if("userCert".equals(attr.getID())) {
                        // ワンタイムパスワード有効期限
                        passwordDeadLine  = DateUtils.parse(values.nextElement().toString(), StndConsIF.DF_YYYY_MM_DD);
                    } else {
                        values.nextElement();
                    }
                }
            }
        }

        ctx.close();

        // 他システムでログインが行われていない場合
        if (!otherSysLoginFlag) {

            // ログインなどの情報を取得する
            if (!this.setLoginInfo()) {
                return "";
            }

            // ワンタイムパスワードフラグ = 1
            if (CheckUtils.isEqual("1", oneTimePasswordFlag)) {

                // パスワード変更(Lgn021)へ遷移を行う
                Flash flash = pageCommonBean.getPageParam();
                flash.put(CONST_ONETIME_PASS_LOGIN, "1");
                url = forward(SCREEN.LGN021_SCREEN.name(), null, SCREEN.LGN011_SCREEN.name(), false);
            } else if (CheckUtils.isEqual("0", oneTimePasswordFlag)) {
                
                // TOP(TOP011)へ遷移を行う
                url = forward(SCREEN.TOP011_SCREEN.name(), null, SCREEN.LGN011_SCREEN.name(), false);
            } else if (passwordDeadLine.before(new Date())) {

                // パスワード有効期限 < SYSDATE
                // パスワード変更(Lgn021)へ遷移を行う
                Flash flash = pageCommonBean.getPageParam();
                flash.put(CONST_ONETIME_PASS_LOGIN, "0");
                url = forward(SCREEN.LGN021_SCREEN.name(), null, SCREEN.LGN011_SCREEN.name(), false);
            }
        }

        return url;
    }

    /**
     * ログインなどの情報を取得する
     * 
     * @return 成功:true、失敗:false
     */
    private boolean setLoginInfo() throws Exception {

        // ログイン情報取得を呼ぶ
        ServiceInterfaceBean sib = loginService.getLoginInfo(
                authConfBean, rest, lgn011Form.getHyoDtlUserCd(), lgn011Form.getHyoDtlPassword());
        if (sib.getStatusCode() != ServiceInterfaceBean.PROCESS_STATUS_SUCCESS){
            return false;
        }

        // 権限取得を呼ぶ
        sib = authService.getAuthority(lgn011Form.getHyoDtlUserCd(), rest, authConfBean);
        if (sib.getStatusCode() != ServiceInterfaceBean.PROCESS_STATUS_SUCCESS) {
            return false;
        }

        // Menu取得を呼ぶ
        sib = menuService.getMenu(lgn011Form.getHyoDtlUserCd(), rest, menuBean);
        if (sib.getStatusCode() != ServiceInterfaceBean.PROCESS_STATUS_SUCCESS) {
            return false;
        }

        // ログイン情報保持
        pageCommonBean.savePageInfo(CONST_LGN011_FORM, lgn011Form);
        
        return true;
    }

}
