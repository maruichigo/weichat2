/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.common;

import java.io.Serializable;
import javax.faces.bean.ViewScoped;
import lombok.Data;

/**
 *
 * @author MaLei (MBP)
 */
@javax.faces.bean.ManagedBean(name = "masterInfo")
@ViewScoped
@Data
public class MasterInfoBean implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * ワーク.表示最大件数
     */
    private String dispMaxRows;

    /**
     * ワーク.取得最大件数
     */
    private String maxRows;

    /**
     * ワーク.ダウンロード最大件数
     */
    private String downloadMaxRows;

    /**
     * ワーク.CSVのみダウンロード最大件数
     */
    private String csvDownloadMaxRows;

    /**
     * ワーク.ページ毎最大件数
     */
    private String pageMaxRows;

    /**
     * ワーク.全営業所検索
     */
    private String allEigyoshoSearch;

    /**
     * ワーク.削除済のみ
     */
    private String sakujoZumiNomi;

    /**
     * ワーク.初期選択件数
     */
    private String defaultSelectRows;

    /**
     * ワーク.ページプルダウン値
     */
    private String selectOptionRows;    
    
}
