
package jp.co.kintetsuls.exception;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * サービスフレームワークアプリケーション例外。
 * <p>
 * サービスフレームワーク内にてアプリケーション例外を生成する場合はこの例外クラスをスローする。
 * </p>
 *
 * @author tdm
 */
public class ApplicationException extends RuntimeException implements Serializable{
    
    /**
     * 例外の発生原因となったメッセージリスト。
     */
    private List<String> errorMessages = new ArrayList<>();
    
    /**
     * ApplicationException を構築します。
     */
    public ApplicationException() {
        super();
    }
    
    /**
     * 指定された詳細メッセージを示す ApplicationException を構築します。
     *
     * @param _message 詳細メッセージ
     */
    public ApplicationException(String _message) {
        super(_message);
    }

    /**
     * 指定された原因を持つ ApplicationException を構築します。
     *
     * @param _throwable 原因
     */
    public ApplicationException(Throwable _throwable) {
        super(_throwable);
    }

    /**
     * 指定された詳細メッセージと原因を持つ ApplicationException を構築します.
     *
     * @param _message 詳細メッセージ
     * @param _throwable 原因
     */
    public ApplicationException(String _message, Throwable _throwable) {
        super(_message, _throwable);
    }
    
    /**
     * 指定された詳細メッセージを示す ApplicationException を構築します。
     * 
     * @param _message 詳細メッセージ
     * @param _errorMessages エラーメッセージ情報
     */
    public ApplicationException(String _message, ArrayList<String> _errorMessages) {
        super(_message);
        setErrorMessages(_errorMessages);
    }

    /**
     * 指定された詳細メッセージと原因を持つ ApplicationException を構築します。
     * 
     * @param _message 詳細メッセージ
     * @param _errorMessages エラーメッセージ情報
     * @param _throwable 原因
     */
    public ApplicationException(String _message, ArrayList<String> _errorMessages, Throwable _throwable) {
        super(_message, _throwable);
        setErrorMessages(_errorMessages);
    }
    
    /**
     * 例外の発生原因となったメッセージリストを取得します。
     * 
     * @return メッセージリスト
     */
    public List<String> getErrorMessages() {
        return errorMessages;
    }

    /**
     * 例外の発生原因となったメッセージリストを設定します。
     * 
     * @param _errorMessages メッセージリスト
     */
    public final void setErrorMessages(List<String> _errorMessages) {
        errorMessages = _errorMessages;
    }
}
