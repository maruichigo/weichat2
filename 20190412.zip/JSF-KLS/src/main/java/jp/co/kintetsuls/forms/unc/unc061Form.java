/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.unc;

import jp.co.kintetsuls.forms.mst.*;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.LabelValueBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import lombok.Data;

/**
 *仕向地名マスタフォーム
 * 
 * @author MaLei (MBP)
 * @version 2019/1/24 新規作成
 */
@javax.faces.bean.ManagedBean(name = "unc061Form")
@ViewScoped
@Data
public class unc061Form {
    
    
    /**
     * 営業所コード
     */
    private String conEigyoshoCd;

    /**
     * 仕向地名
     */
    private String conShimukeChiMei;

    /**
     * 削除済のみ
     */
    private String[] conSakujoSumiNomi;
    
    /**
     * 削除済のみリスト
     */
    private List<LabelValueBean> conSakujoSumiNomiLabelValueList;

    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;

     /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;    

     /**
     * 選択された結果
     */
    private List<Map<String, String>> selectedSearchResult;
}
