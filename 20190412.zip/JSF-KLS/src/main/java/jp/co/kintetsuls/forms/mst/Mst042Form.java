/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mst;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.annotation.DateCheck;
import lombok.Data;

/**
 * 営業所マスタ詳細フォーム
 * 
 * @author 雷珍 (MBP)
 * @version 2019/03/05 新規作成
 */
@ManagedBean(name = "mst042Form")
@ViewScoped
@Data
public class Mst042Form implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 削除/論理削除区分
     */
    private String deleteKbn;
    
    /**
     * 登録/更新対象区分
     */
    private String editKbn;
    
    /**
     * 起動モード区分
     */
    private String modeKbn;
    
    /**
     * 複写フラグ 
     */
    private String fukushaFlg;
    
     /**
     * ワーク.番号体系(一見顧客)
     */
    private String hIchigenKokyakuToroku;
    
     /**
     * ワーク.番号体系(社内便顧客)
     */
    private String hShanaiBinToroku;
    
    /**
     * 営業所コード
     */
    private AutoCompOptionBean conEigyoshoCd;
    
     /**
     * 営業所コードDisabled
     */
    private boolean conEigyoshoCdDisabled;
    
    /**
     * 適用開始日
     */
    @DateCheck(name = "適用開始日")
    private String conTekiyoKaishibi;
    
    /**
     * 適用開始日Disabled
     */
    private boolean conTekiyoKaishibiDisabled;
    
    /**
     * 適用名
     */
    private String conTekiyoMei;
    
    /**
     * 適用終了
     */
    private String[] conTekiyoShuryo;

     /**
     * 適用終了日
     */
    @DateCheck(name = "適用終了日")
    private String tekiyoShuryobi;
    
    /**
     * 適用終了日表示フラグ
     */
    private boolean tekiyoShuryobiHyojiFlg;
            
     /**
     * 適用終了日Disabled
     */
    private boolean tekiyoShuryobiDisabled;
    
    /**
     * 編集Disabled
     */
    private boolean editBtnDisabled;
    
    /**
     * 新規登録Disabled
     */
    private boolean torokuBtnDisabled;
    
     /**
     * 複写登録Disabled
     */
    private boolean fukushaTorokuBtnDisabled;
    
    /**
     * 削除Disabled
     */
    private boolean sakujoBtnDisabled;
    
    /**
     * 論理削除Disabled
     */
    private boolean ronriSakujoBtnDisabled;
    
    /**
     * 更新Disabled
     */
    private boolean koshinBtnDisabled;
    
    /**
     * 履歴確認Disabled
     */
    private boolean rirekiKakuninBtnDisabled;
    
    /**
     * 画面項目編集Disabled
     */
    private boolean editDisabled;
    
    /**
     * 登録/更新ボタン名称
     */
    private String btnName;
    
    /**
     * 営業所名
     */
    private String knrDtlEigyoshoMei;

    /**
     * 営業所カナ名
     */
    private String knrDtlEigyoshoKanaMei;

    /**
     * 営業所略称
     */
    private String knrDtlEigyoshoRyakusho;

    /**
     * 英語表記
     */
    private String knrDtlEigoHyoki;

    /**
     * 使用区分
     */
    private String[] knrDtlShiyoKbn;
   
    /**
     * 使用区分.集荷営業所
     */
    private String knrDtlShiyoShukaKbn;

    /**
     * 使用区分.配達営業所
     */
    private String knrDtlShiyoHaitatsuKbn;

    /**
     * 使用区分.チャーター起点
     */
    private String knrDtlShiyoKitenKbn;

    /**
     * 使用区分.売上
     */
    private String knrDtlShiyoUriageKbn;

    /**
     * 使用区分.発券営業所
     */
    private String knrDtlShiyoHakkenKbn;

    /**
     * 使用区分.車両管理
     */
    private String knrDtlShiyoSharyoKbn;

    /**
     * 使用区分.配達伝票出力営業所
     */
    private String knrDtlShiyoHaidenKbn;

    /**
     * 送り状発行営業所コード
     */
    private AutoCompOptionBean knrDtlOkurijoHakkoEigyoshoCd;

    /**
     * 送り状発行営業所名
     */
    private String knrDtlOkurijoHakkoEigyoshoMei;

    /**
     * 経理先変換コード
     */
    private String knrDtlKeirisakiHenkanCd;

    /**
     * 営業所種別コード
     */
    private String knrDtlHEigyoshoShubetsuCd;

    /**
     * 営業所種別
     */
    private String knrDtlEigyoshoShubetsu;

    /**
     * 承認営業所区分コード
     */
    private String knrDtlHShoninEigyoshoKbnCd;

    /**
     * 承認区分
     */
    private String knrDtlShoninKbn;

    /**
     * 郵便番号
     */
    private String khnDtlYubinBango;

    /**
     * JISコード
     */
    private AutoCompOptionBean khnDtlJisCd;
    
     /**
     * JISコード表示用
     */
    private String khnDtlJisCdHyoji;

    /**
     * 住所1
     */
    private String khnDtlJusho1;

    /**
     * 住所2
     */
    private String khnDtlJusho2;

    /**
     * 住所3
     */
    private String khnDtlJusho3;

    /**
     * 住所4
     */
    private String khnDtlJusho4;

    /**
     * 空港コード
     */
    private AutoCompOptionBean khnDtlKukoCd;

    /**
     * 空港名
     */
    private String khnDtlKukoMei;

    /**
     * 仕向地
     */
    private AutoCompOptionBean khnDtlShimukeChi;

    /**
     * 仕向地名
     */
    private String khnDtlShimukeChiMei;

    /**
     * 集配地区コード
     */
    private String khnDtlShuhaiChikuCd;

    /**
     * 電話番号1
     */
    private String khnDtlTelBango1;

    /**
     * 電話番号2
     */
    private String khnDtlTelBango2;

    /**
     * 社内電話番号
     */
    private String khnDtlShanaiTelBango;

    /**
     * FAX番号
     */
    private String khnDtlFaxBango;

    /**
     * 銀行口座コード
     */
    private AutoCompOptionBean kzaDtlGinkoKozaCd;

    /**
     * 銀行口座名
     */
    private String kzaDtlGinkoKozaMei;

    /**
     * 金融機関コード
     */
    private String kzaDtlKinyuKikanCd;

    /**
     * 金融機関名
     */
    private String kzaDtlKinyuKikanMei;

    /**
     * 支店コード
     */
    private String kzaDtlShitenCd;

    /**
     * 支店名
     */
    private String kzaDtlShitenMei;

    /**
     * 口座種別コード
     */
    private String kzaDtlKozaShubetsuCd;

    /**
     * 口座種別名
     */
    private String kzaDtlKozaShubetsuMei;

    /**
     * 口座番号
     */
    private String kzaDtlKozaBango;

    /**
     * 名義人名
     */
    private String kzaDtlMeigininMei;

    /**
     * 仕立営業所コード
     */
    private AutoCompOptionBean orsDtlShitateEigyoshoCd;
    
    /**
     * 仕立営業所名
     */
    private String orsDtlShitateEigyoshoMei;
    
    /**
     * 他社中継卸値率
     */
    private String orsDtlTashaChukeiOroshineritsu;
    
     /**
     * 更新ユーザ
     */
    private String kshnDtlUser;
    
    /**
     * 更新日時
     */
    private String kshnDtlKoshinNichiji;
    
    /**
     * 最終使用日(売上管理)
     */
    private String kshnDtlSaishuShiyoHiUriageKanri;
    
    /**
     * 最終使用日(卸計算)
     */
    private String kshnDtlSaishuShiyoHiOroshiKanri;
   
    /**
     * 最終使用日(仕入管理)
     */
    private String kshnDtlSaishuShiyoHiShiireKanri;
    
    /**
     * 一見顧客登録フラグ
     */
    private String dtlHIchigenKokyakuTorokuFlg;
    
    /**
     * 社内便登録フラグ
     */
    private String dtlHShanaiBinTorokuFlg;
    
    /**
     * 着払代引登録フラグ
     */
    private String dtlHChakubaraiDaibikiTorokuFlg;
   
    /**
     * 旧住所フラグ
     */
    private String dtlHKyuJushoFlg;
    
    /**
     * 使用不可フラグ
     */
    private String dtlHShiyoFukaFlg;
   
    /**
     * 新JISコード
     */
    private String dtlHShinJisCd;
    
    /**
     * 削除フラグ
     */
    private String dtlHSakujoFlg;
    
     /**
     * 営業所データバージョン
     */
    private String dtlEigyoshoDataVersion;
    
    /**
     * 更新カウンタ
     */
    private String dtlKoshinCounter;
    
    /**
     * 検索結果営業所マスタ基本情報
     */
    private Map<String, Object> resultEigyoshoInfo;
    
     /**
     * 承認者情報
     */
    private ReportListDataModel listShoninshaDtlSelectable;
    
    /**
     * 承認者情報選択された結果
     */
    private List<Map<String, Object>> listShoninshaDtlSelectedResult;
    
    /**
     * 営業所グループ情報リスト検索結果一覧選択できる
     */
    private ReportListDataModel listEgrpDtlSelectable;
    
    /**
     * 営業所グループ情報選択された結果
     */
    private List<Map<String, Object>> listEgrpDtlSelectedResult;
    
    /**
     * 卸単価情報リスト検索結果一覧選択できる
     */
    private ReportListDataModel listOrsDtlSelectable;
    
    /**
     * 卸単価情報リスト選択された結果
     */
    private List<Map<String, Object>> listOrsDtlSelectedResult;
    
    /**
     *  ワーク.サブ組織名リスト
     */
    private List<String> subSoshikiMeiList;
     
    /**
     * 履歴テーブル検索キー
     */
    private Map<String, Object> rirekiSearchKey;
}
