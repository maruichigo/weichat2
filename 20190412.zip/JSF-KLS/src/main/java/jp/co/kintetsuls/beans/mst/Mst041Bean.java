/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.LabelValueBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiListCol;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst041Form;
import jp.co.kintetsuls.forms.mst.Mst042Form;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 営業所マスタ画面
 *
 * @author 雷新然 (MBP)
 * @version 2019/2/18 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst041")
@ViewScoped
@Data
public class Mst041Bean extends AbstractBean {

    /**
     * タイトル
     */
    private final String TITLE = "営業所マスタ";
    
    /**
     * パンくず名とCSVタイトル
     */
    private final static String FILE_NAME = "営業所マスタ一覧"; 

    /**
     * 画面URL
     */
    private String url;

    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

    /**
     *
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authorityConfBean;
    
    /**
     * ファイルダウンロード
     */
    @ManagedProperty(value = "#{fileBean}")
    private FileBean fileBean;

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;

    /**
     * 画面フォーム
     */
    @ManagedProperty(value = "#{mst041Form}")
    private Mst041Form mst041Form;

    /**
     * 画面共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;
    
    /**
     * 共通マスタ取得
     */
    @ManagedProperty(value = "#{labelValueBean}")
    private LabelValueBean labelValueBean;

    /**
     * 検索シーケンス処理共通
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;

    /**
     * 履歴一覧処理共通
     */
    @ManagedProperty(value = "#{rirekisyosai}")
    private RirekiSyosaiBean rirekiSyosaiBean;

    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(
            new Object() {}.getClass().getEnclosingClass().getName());
    /**
     * スクリーン：MST042
     */
    private static final String MST042_SCREEN_NAME = SCREEN.MST042_SCREEN.name();
    
    /**
     * スクリーン：MST041
     */
    private static final String MST041_SCREEN_NAME = SCREEN.MST041_SCREEN.name();
    
    /**
     * 世代検索条件 デフォルト値
     */
    private static final String[] DEFAULT_VALUE = {"01", "02"};

    /**
     * スクリーンコード：MST041
     */
    private static final String SC_CD_MST041 = "MST041_SCREEN";

    /**
     * 定数：検索件数取得ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH_KENSU = "mst041-get-eigyosho-kensu";

    /**
     * 定数：検索ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH = "mst041-get-eigyosho-detail";

    /**
     * 定数：一覧のデータテーブルID
     */
    private static final String DATA_TABLE_ID = "tablesorter_mst041";

    /**
     * 定数：画面項目保持キー
     */
    private static final String CONST_MST041_FORM = "mst041Form";

    /**
     * 定数：MasterInfo取得キー
     */
    private static final String CONST_MST041_MASTER = "mst041";
    
    /**
     * 定数：再検索Button取得キー
     */
    private static final String CONST_MST041_SEARCH = "search_mst041";

    /**
     * 履歴テーブル検索キー
     */
    private Map<String, Object> rirekiSearchKey;

    /**
     * ワーク.メッセージリスト
     */
    List<MessageModuleBean> msgList = new ArrayList<>();

    /**
     * コンストラクタ
     */
    public Mst041Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId メニューID
     * @param prevScreen 遷移元画面ID
     * @param backFlag 戻るフラグ
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {

            // パンくずを追加する
            breadBean.push(TITLE, SCREEN.MST041_SCREEN.name(), this);
	    
	    // 世代検索条件:"現在適用","未来適用"にチェック
            mst041Form.setConSedaiKensakuJoken(DEFAULT_VALUE);

            // システムマスタ取得する
            pageCommonBean.getMasterInfo(CONST_MST041_MASTER);

            // 検索シーケンス処理を初期化する
            searchHelpBean.regSearchHelp(DATA_TABLE_ID,
                    s -> {return getRecordCount(false);},
                    s -> {search(); return null;},
                    null);
            searchHelpBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);

	    // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(営業所コードリスト)
	    autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO, new AutoCompOptionBean("全て", "all"));
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(仕向地コードリスト)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_SHIMUKE_CHI_CD);
	    
	    // 前回の記録をクリアする
            this.clear();
            mst041Form.setSearchResult(null);
            mst041Form.setSearchResultSelectable(null);
            mst041Form.setSelectedSearchResult(null);

            // 戻ってきた場合
            Mst041Form preForm = (Mst041Form) pageCommonBean.getPageInfo(CONST_MST041_FORM);
            if (backFlag && preForm != null) {
                PageCommonBean.simpleCopy(preForm, mst041Form);
                // 再検索を実施する
                pageCommonBean.searchAgain(CONST_MST041_SEARCH);
                // 進んできた場合
            } else {
                Flash flash = pageCommonBean.getPageParam();
                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_MST041_FORM) != null) {
                    PageCommonBean.simpleCopy(flash.get(CONST_MST041_FORM), mst041Form);
                    // 再検索を実施する
                    pageCommonBean.searchAgain(CONST_MST041_SEARCH);
                }
            }

            // ダウンロードシーケンスを初期化する
            fileBean.setDataSize(DATA_TABLE_ID,
                    (id -> {return getRecordCount(true);}));
	    fileBean.setSearchResult(DATA_TABLE_ID, (id -> {return getSearchResult();})); 
            fileBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);
            fileBean.setSubFlg(true);
	    fileBean.setTilte(FILE_NAME);
            fileBean.regDownloadFucntion(DATA_TABLE_ID, getHeader() ,
                    (id -> {return getEigyoshoList(false);}));
            fileBean.regBeforeDownFucntion(DATA_TABLE_ID,
                    (comment -> {return beforeDown(comment);}));

            // component初期化とユーザ権限により制御を設定する
            pageCommonBean.setAuthControll(mst041Form, SC_CD_MST041, true);

        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * カウント処理
     *
     * @param downloadFlg ダウンロードフラグ
     * @return 取得件数
     */
    public Long getRecordCount(boolean downloadFlg) {

	// 前回の記録をクリアする
        Map<String, Object> mapRec = new LinkedHashMap();
        mapRec.put("hideFlg", "hideRow");
        List<Map<String, Object>> mapList = new ArrayList();
        mapList.add(mapRec);
        mst041Form.setSearchResult(mapList);
        mst041Form.setSearchResultSelectable(new ReportListDataModel(mst041Form.getSearchResult()));
        mst041Form.setSelectedSearchResult(null);
	// サブ検索条件フラグ設定
        fileBean.setSubFlg(subSearchConHad());
	
	// パラメータを設定
        Map<String, Object> params = getParamas(downloadFlg);
        // レコード件数を取得する
        long recordCount = getEigyoshoListCount(downloadFlg);
	
	if (!downloadFlg) {

	    // 検索部のステータスを変更する
	    pageCommonBean.setSerchConDisabled(mst041Form);

	    // 検索条件保存
	    pageCommonBean.savePageInfo(CONST_MST041_FORM, mst041Form);
        }

        return recordCount;
    }

    /**
     * 検索処理
     *
     */
    public void search() {
	
        // 選択リストを初期化する
        mst041Form.setSelectedSearchResult(new ArrayList<>());
        mst041Form.setSearchResultSelectable(null);
	
        // 営業所マスタ検索を行う
        List<Map<String, Object>> recordList = getEigyoshoList(false);
        fileBean.setDataList(recordList);
	
        // 取得した値を画面項目にセットする
        pageCommonBean.setDatalist(DATA_TABLE_ID, recordList);
	if(recordList != null && recordList.size() > 0) {
	    mst041Form.setSearchResultSelectable(new ReportListDataModel(recordList));
	}
        
        // 検索部のステータスを変更する
        pageCommonBean.setSerchConDisabled(mst041Form);
	
	pageCommonBean.setDatalist(DATA_TABLE_ID, recordList);

        // 検索条件を保存する
        pageCommonBean.savePageInfo(CONST_MST041_FORM, mst041Form);
	
	if (!mst041Form.getSearchResult().isEmpty()) {
	    // 参照モードにする
	    pageCommonBean.setEditFlg(true);
	    
	}
    }
    
    /**
     * 検索条件変更処理
     *
     */
    public void searchChange() {

        // 検索部のステータスを変更する
        pageCommonBean.setSerchConEnabled(mst041Form);
    }

    /**
     * クリア処理
     *
     */
    public void clear() {

	// 営業所コード
        mst041Form.setConEigyoshoCd(null);
	// 営業所名
        mst041Form.setConEigyoshoMei(null);
	// 世代検索条件
        mst041Form.setConSedaiKensakuJoken(null);
	// 適用日
        mst041Form.setConTekiyoBi(null);
	// 削除済のみ
        mst041Form.setConSakujoSumiNomi(null);
	// 使用区分
        mst041Form.setConShiyoKbn(null);
	// 仕向地コード
        mst041Form.setConShimukeChiCd(null);
	// 仕向地名
        mst041Form.setConShimukeChiMei(null);
	// 適用名
        mst041Form.setConTekiyoMei(null);
	// 住所
        mst041Form.setConJusho(null);
	
	// 検索部の世代検索条件初期化
        mst041Form.setConSedaiKensakuJoken(DEFAULT_VALUE);
        
        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mst041Form);
        pageCommonBean.setBtnSearchChangeVisible(false);
        pageCommonBean.setBtnSearchVisible(Boolean.TRUE);
    }

    /**
     * 更新履歴を表示処理
     *
     */
    public void rirekiIchiran() {

        // 履歴テーブル検索キーを設定する
        rirekiSearchKey = new HashMap();
        
        // 選択されたレコードを取得する
        Map<String, Object> selectRec = mst041Form.getSelectedSearchResult().get(0);
	// 営業所コード
        rirekiSearchKey.put("listEigyoshoCd", selectRec.get("listEigyoshoCd"));
	// 適用開始日
        rirekiSearchKey.put("listTekiyoKaishibi", selectRec.get("listTekiyoKaishibi"));
        
        // 履歴タイトルを設定する
        rirekiSyosaiBean.setListColName(
                new ArrayList<>(Arrays.asList("バージョン情報", "営業所コード", "営業所名", "適用開始日", "住所",
			"仕向地コード", "仕向地名", "集荷営業所フラグ", "配達営業所フラグ", "チャーター起点フラグ",
			"売上フラグ", "発券営業所フラグ", "車両管理フラグ", "配達伝票出力営業所フラグ", "適用名",
			"終了", "最終使用日付")));

        // 履歴beanの項目物理名を設定する
        List<String> colValue = new ArrayList<>(Arrays.asList("rirekiDataVersion", "rirekiEigyoshoCd",
		"rirekiEigyoshoMei", "rirekiTekiyoKaishibi", "rirekiJusho", "rirekiShimukeChiCd", "rirekiShimukeChiMei",
		"rirekiShukaEigyoshoFlg", "rirekiHaitatsuEigyoshoFlg", "rirekiCharterKitenFlg", "rirekiUriageFlg",
		"rirekiHakkenEigyoshoFlg", "rirekiSharyoKanriFlg", "rirekiHaidenOutputEigyoshoFlg",
		"rirekiTekiyoMei", "rirekiShuryo", "rirekiSaishuShiyoHiduke"));

	List<String> colAlign = new ArrayList<>(Arrays.asList("left", "center", "left", "center", "left", "left",
		"left", "center", "center", "center", "center", "center", "center", "center", "left",
		"center", "center"));
	
	List<RirekiListCol> listCol = new ArrayList<>();
        for (int i = 0; i < colValue.size(); i++) {
           RirekiListCol col = new RirekiListCol();
           col.setColValue(colValue.get(i));
           col.setColAlign(colAlign.get(i));
           listCol.add(col);
        }
	rirekiSyosaiBean.setListCol(listCol);
	
        // 履歴テーブルを検索する
        rirekiSyosaiBean.searchList("2", "MST041_SEARCH_RIREKI", rirekiSearchKey);
    }

    /**
     * 画面遷移処理 (複写登録)
     *
     * @return 遷移先の画面URL
     * @throws java.text.ParseException
     */
    public String btnFukushaTorokuClick() throws ParseException {
	
	// エラーメッセージを格納する変数を初期化する
        msgList = new ArrayList<>();
	
	// 行選択データ
        List<Map<String, Object>> recordList = mst041Form.getSelectedSearchResult();
        
        // 未選択の場合、エラーメッセージを表示させる
        if (recordList.isEmpty()) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
            return null;
        }
        // 複数選択の場合、エラーメッセージを表示させる
        if (recordList.size() > 1) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
            return null;
        }
       
        Mst042Form mst042Form = new Mst042Form();
	
        // 営業所コード
	mst042Form.setConEigyoshoCd(autoCompleteViewBean.getComMsDatas(
                        MsCnst.COM_GET_VW_EIGYOSHO, 
                        recordList.get(0).get("listEigyoshoCd").toString()));
        // 適用開始日
        mst042Form.setConTekiyoKaishibi(recordList.get(0).get("listTekiyoKaishibi").toString());
	// 適用名
	mst042Form.setConTekiyoMei(recordList.get(0).get("listTekiyoMei").toString());
	// 適用終了
	String str = String.valueOf(recordList.get(0).get("listShuryoFlg"));
	mst042Form.setConTekiyoShuryo(new String [] {str});
        // 複写フラグ
	mst042Form.setFukushaFlg(String.valueOf(1));
	
	// 遷移画面パラメータを設定する
        Flash flash = pageCommonBean.getPageParam();
        flash.put("mst042Form", mst042Form);
	
	// 営業所マスタ詳細画面に遷移する
        return url = forward(MST042_SCREEN_NAME, null, MST041_SCREEN_NAME, false);

    }
    
    /**
     * 画面遷移処理 (営業所コードリンク)
     *
     * @return 遷移先の画面URL
     * @throws java.text.ParseException
     */
    public String btnEigyoshoLinkClick() throws ParseException {
	
	// 行選択データ
        Map<String, Object> recordList = mst041Form.getLinkSearchResult();
        
        Mst042Form mst042Form = new Mst042Form();
	
        // 営業所コード
        mst042Form.setConEigyoshoCd(autoCompleteViewBean.getComMsDatas(
                        MsCnst.COM_GET_VW_EIGYOSHO, 
                        recordList.get("listEigyoshoCd").toString()));
        // 適用開始日
        mst042Form.setConTekiyoKaishibi(recordList.get("listTekiyoKaishibi").toString());
	// 適用名
	mst042Form.setConTekiyoMei(recordList.get("listTekiyoMei").toString());
	// 適用終了
	String str = String.valueOf(recordList.get("listShuryoFlg"));
	mst042Form.setConTekiyoShuryo(new String [] {str});
        // 複写フラグ
	mst042Form.setFukushaFlg(String.valueOf(0));
	
	// 遷移画面パラメータを設定する
        Flash flash = pageCommonBean.getPageParam();
        flash.put("mst042Form", mst042Form);
	
	// 営業所マスタ詳細画面に遷移する
        return url = forward(MST042_SCREEN_NAME, null, MST041_SCREEN_NAME, false);
         
    }
    
    /**
     * 画面遷移処理 (新規追加）
     *
     * @return 遷移先の画面URL
     */
    public String btnShinkiTorokuClick() {
        
	Mst042Form mst042Form = new Mst042Form();
        // 複写フラグ
	mst042Form.setFukushaFlg(String.valueOf(0));
	
	// 遷移画面パラメータを設定する
        Flash flash = pageCommonBean.getPageParam();
        flash.put("mst042Form", mst042Form);
	
	// 営業所マスタ詳細画面に遷移する
        return url = forward(MST042_SCREEN_NAME, null, MST041_SCREEN_NAME, false);
    }
    
    /**
     * ダウンロード検査結果取得
     * 
     * @return 検索結果
     */
    public List<Map<String, Object>> getSearchResult() {
        return mst041Form.getSearchResult();
    }
    
    /**
     * 画面遷移処理 (詳細）
     *
     * @return 遷移先の画面URL
     * @throws java.text.ParseException
     */
    public String btnShousaiClick() throws ParseException {
	
	// エラーメッセージを格納する変数を初期化する
        msgList = new ArrayList<>();
	
	// 行選択データ
        List<Map<String, Object>> recordList = mst041Form.getSelectedSearchResult();
        
        // 未選択の場合、エラーメッセージを表示させる
        if (recordList.isEmpty()) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
            return null;
        }
        // 複数選択の場合、エラーメッセージを表示させる
        if (recordList.size() > 1) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
            return null;
        }
       
        Mst042Form mst042Form = new Mst042Form();
	
        // 営業所コード
	mst042Form.setConEigyoshoCd(autoCompleteViewBean.getComMsDatas(
                        MsCnst.COM_GET_VW_EIGYOSHO, 
                        recordList.get(0).get("listEigyoshoCd").toString()));
        // 適用開始日
        mst042Form.setConTekiyoKaishibi(recordList.get(0).get("listTekiyoKaishibi").toString());
	// 適用名
	mst042Form.setConTekiyoMei(recordList.get(0).get("listTekiyoMei").toString());
	// 適用終了
	String str = String.valueOf(recordList.get(0).get("listShuryoFlg"));
	mst042Form.setConTekiyoShuryo(new String [] {str});
        // 複写フラグ
	mst042Form.setFukushaFlg(String.valueOf(0));
	
	// 遷移画面パラメータを設定する
        Flash flash = pageCommonBean.getPageParam();
        flash.put("mst042Form", mst042Form);
	
	// 営業所マスタ詳細画面に遷移する
        return url = forward(MST042_SCREEN_NAME, null, MST041_SCREEN_NAME, false);
    }
    
    /**
     * メニュークリック処理
     *
     * @param menuId メニューID
     * @param nextScreenId 遷移先画面ID
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreenId) {
        try {
            // パンくずを削除する
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移を行う
        url = forward(nextScreenId, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック処理
     *
     * @param nextScreenId 遷移先画面ID
     * @param breadIndex パンくずのインデックス
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreenId, int breadIndex) {

        try {
            // パンくずを削除する
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        
        // 画面遷移を行う
        url = forward(nextScreenId, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック処理
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authorityConfBean.logout();
    }

    /**
     * CSVファイルのタイトルを設定する処理
     * 
     * @return 画面タイトル
     */
    public List<CSVDto> getHeader() {
       
        // CSVファイルのタイトルを設定する
        List<CSVDto> header = new ArrayList<>();
	// 営業所コード
        header.add(new CSVDto("営業所コード", "listEigyoshoCd"));
	// 営業所名
        header.add(new CSVDto("営業所名", "listEigyoshoMei"));
	// 適用開始日
        header.add(new CSVDto("適用開始日", "listTekiyoKaishibi"));
	// 住所
        header.add(new CSVDto("住所", "listJusho"));
	// 仕向地コード
        header.add(new CSVDto("仕向地コード", "listShimukeChiCd"));
	// 仕向地名
        header.add(new CSVDto("仕向地名", "listShimukeChiMei"));
	// 集荷営業所フラグ
        header.add(new CSVDto("集荷営業所フラグ", "listShukaEigyoshoFlg"));
	// 配達営業所フラグ
        header.add(new CSVDto("配達営業所フラグ", "listHaitatsuEigyoshoFlg"));
	// チャーター起点フラグ
        header.add(new CSVDto("チャーター起点フラグ", "listCharterKitenFlg"));
	// 売上フラグ
        header.add(new CSVDto("売上フラグ", "listUriageFlg"));
	// 発券営業所フラグ
        header.add(new CSVDto("発券営業所フラグ", "listHakkenEigyoshoFlg"));
	// 車両管理フラグ
        header.add(new CSVDto("車両管理フラグ", "listSharyoKanriFlg"));
	// 配達伝票出力営業所フラグ
        header.add(new CSVDto("配達伝票出力営業所フラグ", "listHaidenOutputEigyoshoFlg"));
	// 適用名
        header.add(new CSVDto("適用名", "listTekiyoMei"));
	// 終了
        header.add(new CSVDto("終了", "rirekiShuryo"));
	// 最終使用日付
        header.add(new CSVDto("最終使用日付", "listSaishuShiyoHiduke"));
        
        // 取得値を返却する
        return header;
    }

    /**
     * ダウンロード理由を記録する処理
     *
     * @param comment 理由コメント
     * @return 正常／異常
     * @throws Exception
     */
    public boolean beforeDown(String comment) throws Exception {
        
        // ダウンロード理由を記録する
        System.out.println(comment);
        
        return true;
    }
    
    /**
     * 仕向地コードのフォマート転換
     * 
     */
    public void convertShimukeChiCd() {
	
	String shimukeChiCd = mst041Form.getConShimukeChiCd().getValue();
	String shimukeChiCdNew = shimukeChiCd.substring(0, 5) + "-" + shimukeChiCd.substring(5, 7);
	mst041Form.getConShimukeChiCd().setValue(shimukeChiCdNew);
    }
    
    /**
     * DBから営業所マスタ検索件数を取得する処理
     * 
     */
    private long getEigyoshoListCount(boolean downloadFlg) {

        // パラメータ
        Map<String, Object> params = getParamas(downloadFlg);
        
        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH_KENSU);

        // 検索件数を返却する
        return Long.valueOf(res.getJson());
    }
    
    /**
     * パラメータを設定する
     * 
     * @param downloadFlg ダウンロードフラグ
     * @return 検索結果パラメータ
     */
    private Map<String, Object> getParamas(boolean downloadFlg) {
        
        // パラメータを設定する
        Map<String, Object> params = new HashMap<>();
        
        Mst041Form tempForm = mst041Form;
        if (downloadFlg) {
            tempForm = (Mst041Form)pageCommonBean.getPageInfo(CONST_MST041_FORM);
        }
        
        // 営業所コード
        if (tempForm.getConEigyoshoCd() != null) {
            params.put("conEigyoshoCd", tempForm.getConEigyoshoCd().getValue());
        }
        // 使用区分
	if (tempForm.getConShiyoKbn() != null && tempForm.getConShiyoKbn().length != 0) {
	    params.put("conShiyoKbn", tempForm.getConShiyoKbn());
	}
        // 仕向地コード
	if (tempForm.getConShimukeChiCd() != null) {
	    params.put("conShimukeChiCd", tempForm.getConShimukeChiCd().getValue());
	}
        // 適用名
	if (!"".equals(tempForm.getConTekiyoMei()) && tempForm.getConTekiyoMei() != null) {
	    params.put("conTekiyoMei", tempForm.getConTekiyoMei());
	}
        // 住所
	if (!"".equals(tempForm.getConJusho()) && tempForm.getConJusho() != null) {
	    params.put("conJusho", tempForm.getConJusho());
	}
	// 適用日
        if (!"".equals(tempForm.getConTekiyoBi()) && tempForm.getConTekiyoBi() != null) {
            params.put("conTekiyoBi", tempForm.getConTekiyoBi());
        }
	// 全営業所検索
        if (pageCommonBean.getMasterInfo().getAllEigyoshoSearch() != null) {
            params.put("allEigyoshoSearch", pageCommonBean.getMasterInfo().getAllEigyoshoSearch());
        }
        // ログインユーザー所属営業所
        params.put("loginUserShozokuEigyosho", authorityConfBean.getLoginUserShozokuEigyosho());
        // 世代検索条件
        params.put("conSedaiKensakuJoken", tempForm.getConSedaiKensakuJoken());
        // 削除済のみ
        if (tempForm.getConSakujoSumiNomi() == null || tempForm.getConSakujoSumiNomi().isEmpty()) {
	    // 未選択の場合
            params.put("conSakujoSumiNomi", "0");
        } else {
	    // 選択の場合
            params.put("conSakujoSumiNomi", "1");
        }
        return params;
    }

    /**
     * DBから営業所マスタ情報を取得する処理
     * 
     */
    private List<Map<String, Object>> getEigyoshoList(boolean downloadFlg) {

        // パラメータ
        Map<String, Object> params = getParamas(downloadFlg);
        
        try {
	    // DBをアクセスする
            ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH);

            ObjectMapper mapper = new ObjectMapper();
            mst041Form.setSearchResult(mapper.readValue(serviceInterfaceBean.getJson(), List.class));

        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
	
	// 検索結果一覧データ
        List<Map<String, Object>> searchResultList = new ArrayList();
	
        // 適用開始日フォーマット
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
	for (Map<String, Object> result : mst041Form.getSearchResult()) {
            
            // 適用開始日
	    if (result.get("listTekiyoKaishibi") != null && result.get("listTekiyoKaishibi") != "") {
                result.replace("listTekiyoKaishibi", dateFormat.format(
			Long.valueOf(result.get("listTekiyoKaishibi").toString())));
	    }
            
	    // 最終使用日付
	    if (result.get("listSaishuShiyoHiduke") != null && result.get("listSaishuShiyoHiduke") != "") {
		result.replace("listSaishuShiyoHiduke", dateFormat.format(
			Long.valueOf(result.get("listSaishuShiyoHiduke").toString())));
	    }
	    // 仕向地コード
	    if (!StringUtils.isEmpty(result.get("listShimukeChiCd").toString())) {
		result.replace("listShimukeChiCd",String.valueOf(
			result.get("listShimukeChiCd").toString()).substring(0, 5) + "-" +
			result.get("listShimukeChiCd").toString().substring(5, 7));
	    }
	    
            searchResultList.add(result);
        }
	mst041Form.setSearchResult(null);
        mst041Form.setSearchResult(searchResultList);
	
	if(!mst041Form.getSearchResult().isEmpty()) {
	    // 参照モードにする
            pageCommonBean.setEditFlg(false);
	    
	}
        
        // 営業所マスタ情報を返却する
        return mst041Form.getSearchResult();
    }
    
    /**
     * サブ検索条件入力判断
     * 
     * @return true:入力あり/false:入力しない
     */
    private boolean subSearchConHad() {
        
        // 使用区分
        if (mst041Form.getConShiyoKbn() != null && mst041Form.getConShiyoKbn().length > 0) {
            return true;
        }
        // 仕向地コード
        if (mst041Form.getConShimukeChiCd() != null) {
            return true;
        }
        // 適用名
        if (!StringUtils.isEmpty(mst041Form.getConTekiyoMei())) {
            return true;
        }
	// 住所
	if (!StringUtils.isEmpty(mst041Form.getConJusho())) {
            return true;
        }

        return false;
    }

}
