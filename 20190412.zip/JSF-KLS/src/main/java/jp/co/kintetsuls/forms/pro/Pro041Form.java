/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.pro;

import jp.co.kintetsuls.forms.mst.*;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.LabelValueBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import lombok.Data;

/**
 * 航空運賃表詳細フォーム
 * 
 * @author MaLei (MBP)
 * @version 2019/1/24 新規作成
 */
@javax.faces.bean.ManagedBean(name = "pro041Form")
@ViewScoped
@Data
public class Pro041Form {
    
    /**
     * 都道府県
     */
    private String conTodofuken;

    /**
     * 仕向地名
     */
    private String conShimukeChiMei;

    /**
     * 削除済のみ
     */
    private String[] conSakujoSumiNomi;
    
    /**
     * 削除済のみリスト
     */
    private List<LabelValueBean> conSakujoSumiNomiLabelValueList;

    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;

     /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;    

     /**
     * 選択された結果
     */
    private List<Map<String, String>> selectedSearchResult;

}
