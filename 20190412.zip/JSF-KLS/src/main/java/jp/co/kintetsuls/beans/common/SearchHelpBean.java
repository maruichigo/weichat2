/*
 *Copyright (C) 2014 MBP Corporation All Rights Reserved . 
 */
package jp.co.kintetsuls.beans.common;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.inject.Inject;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.exception.FunctionCust;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.PrimeFaces;

/**
 * 検索シーケンス処理
 *
 * @author hq
 */
@ViewScoped
@ManagedBean
@Data
public class SearchHelpBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private final Map<String, FunctionCust<String, Long>> checkSizeFunctionList = new HashMap();

    private final Map<String, FunctionCust<String, String>> checkFunctionList = new HashMap();

    private final Map<String, FunctionCust<String, String>> searchFunctionList = new HashMap();
    
    private final Map<String, PageCommonBean> settings = new HashMap<>();
    
    private boolean flg = true;
    
    private boolean downloadFlg = true;

    private static final Logger logger = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());
    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;
    
    public void regSearchHelp(String id, FunctionCust<String, Long> checkSizeFunction,
        FunctionCust<String, String> searchFunction, FunctionCust<String, String> checkFunction) {
        checkSizeFunctionList.put(id, checkSizeFunction);
        if (checkFunction != null) {
            checkFunctionList.put(id, checkFunction);
        }
        searchFunctionList.put(id, searchFunction);
    }

    public void checkSearch(String id) throws Exception {
        //TODO 関連チェック実行　修正必要
        if (checkFunctionList.containsKey(id)) {
            String flg = checkFunctionList.get(id).apply("");
            if (flg.equals("FALSE")) {
                return;
            }
        }
        PageCommonBean setting = settings.get(id);
        setting.setBtnSearchVisible(false);
        setting.setBtnSearchChangeVisible(true);
        settings.put(id, setting);

        if (checkSizeFunctionList.containsKey(id)) {
            Long size = checkSizeFunctionList.get(id).apply("");

            if (downloadFlg) {
                PrimeFaces.current().executeScript("buttonChange"+"('"+checkSizeRe(id, size)+"')");
            }
            PrimeFaces.current().executeScript("checkSearch" //
                    + id + "('" + checkSizeRe(id, size) + "')");
        }
    }

    public void search(String id) throws Exception {
        if (searchFunctionList.containsKey(id)) {
            searchFunctionList.get(id).apply("");
        }
        PageCommonBean setting = settings.get(id);
        setting.setBtnSearchVisible(false);
        setting.setBtnSearchChangeVisible(true);
        setting.setCollapsed(true);
    }

    public void searchChange(String id) throws Exception {
        PageCommonBean setting = settings.get(id);
        setting.setBtnSearchVisible(true);
        setting.setBtnSearchChangeVisible(false);
        setting.setCollapsed(false);
    }

    private String checkSizeRe(String id, Long size) throws Exception {
        PageCommonBean setting = settings.get(id);
        if (Integer.valueOf(setting.getMasterInfo().getDispMaxRows()) < size &&
                size <= Integer.valueOf(setting.getMasterInfo().getMaxRows())) {
            return "B";
        }
        if (Integer.valueOf(setting.getMasterInfo().getMaxRows()) < size &&
                size <= Integer.valueOf(setting.getMasterInfo().getCsvDownloadMaxRows())) {
            flg = false;
             PrimeFaces.current().executeScript("clearTbody"+"("+")");
            return "C";
        }
        if (Integer.valueOf(setting.getMasterInfo().getCsvDownloadMaxRows()) < size) {
            PrimeFaces.current().executeScript("clearTbody"+"("+")");
            flg = false;
            return "D";
        }
        if (size < 1) {
             PrimeFaces.current().executeScript("clearTbody"+"("+")");
            return "E";
        }
        else {
            return "A";
        }
    }

    public void setMsg() throws Exception{
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_WARN,MessageCnst.COMW0001);
    }
}
