/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common.annotation.validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import jp.co.kintetsuls.beans.common.annotation.HalfEisuKigou;

/**
 * 半角英数字記号チェック
 * 
 * @author 李信志 (MBP)
 * @version 2019/3/27 新規作成
 */
public class HalfEisuKigouValidator implements ConstraintValidator<HalfEisuKigou, String> { 

    @Override
    public void initialize(HalfEisuKigou constraintAnnotation) {
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        Pattern pattern = Pattern.compile("[0-9A-Za-z\u0020-\u007e]*");
           Matcher isNum = pattern.matcher(value);
           if( !isNum.matches() ){
               return false;
           }
           return true;
    }
    
}
