/*
 * Mst151Bean.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.pro;

import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Getter;
import lombok.Setter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 *
 * @author xubo
 */
@ManagedBean(name = "pro042")
@ViewScoped
public class Pro042Bean extends BaseBean {
    
    private final String strTitle = "売上入力訂正(その他請求)画面";
    private String url;     // URL
    
    @ManagedProperty(value = "#{breadBean}")
    @Getter
    @Setter
    private BreadCrumbBean breadBean;

    @ManagedProperty(value = "#{authConfBean}")
    @Getter
    @Setter
    private AuthorityConfBean authConfBean;
    
    private RestfullService rest;
    
    private static final Logger logger = LogManager.getLogger(new Object(){}.getClass().getEnclosingClass().getName());
    
    @Getter
    @Setter
    private List<Map<String, String>> searchResult;

    @Getter
    @Setter
    private Map<String, String> selectSearchResult;
    
    /**
     * 請求計上No
     */
    @Getter
    @Setter
    private String biko;
    
    /**
     * 顧客コード
     */
    @Getter
    @Setter
    private String conKokyakuCd;
    
    /**
     * 営業所コード
     */
    @Getter
    @Setter
    private String conEigyoshoCd;
    
    /**
     * 請求日付
     */
    @Getter
    @Setter
    private Date date1;
    
    /**
     * 売上計上日
     */
    @Getter
    @Setter
    private Date date2;
    
    /**
     * 料金項目1
     */
    @Getter
    @Setter
    private String ryokinn1;
    
    /**
     * 料金項目2
     */
    @Getter
    @Setter
    private String ryokinn2;
    
    /**
     * 数量
     */
    @Getter
    @Setter
    private int amount;
    
    /**
     * 請求書No
     */
    @Getter
    @Setter
    private String reqNo;
    
    /**
     * コンストラクタ
     */
    public Pro042Bean() {

    }
    
    /**
     * 初期処理（処理）
     *
     * @param menuId
     * @param prevScreen
     * @param backFlag
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlg) {
         try {
            // パンくず追加
            breadBean.push("売上入力訂正(その他請求)画面", Cnst.SCREEN.PRO042_SCREEN.name(), this);
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }
    }

    @Override
    public String menuClick(String menuId, String nextScreen) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String logoutClick() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * @return the strTitle
     */
    public String getStrTitle() {
        return strTitle;
    }
}

