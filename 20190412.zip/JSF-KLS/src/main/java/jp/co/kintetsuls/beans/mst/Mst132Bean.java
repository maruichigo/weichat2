/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.KbnBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.forms.mst.Mst132Form;
import jp.co.kintetsuls.utils.DateUtils;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 仕入先マスタ詳細画面
 *
 * @author 劉成江 (MBP)
 * @version 2019/1/24 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst132")
@ViewScoped
@Data
public class Mst132Bean extends AbstractBean {
    /**
     * タイトル
     */
    private final String TITLE = "仕入先マスタ詳細";

    /**
     * 画面URL
     */
    private String url;
    
    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoComplete}")
    private AutoCompleteBean autoCompleteBean;

    /**
     *
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authorityConfBean;

    /**
     * ファイルダウンロード
     */
    @ManagedProperty(value = "#{fileBean}")
    private FileBean fileBean;

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;

    /**
     * 画面フォーム
     */
    @ManagedProperty(value = "#{mst132Form}")
    private Mst132Form mst132Form;

    /**
     * 画面共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * 検索シーケンス処理共通
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;

    /**
     * 履歴一覧処理共通
     */
    @ManagedProperty(value = "#{rirekisyosai}")
    private RirekiSyosaiBean rirekiSyosaiBean;

    /**
     * 一覧単項目チェック共通
     */
    @ManagedProperty(value = "#{listCheckBean}")
    private ListCheckBean listCheckBean;

    /***/
    @ManagedProperty(value = "#{kbnBean}")
    private KbnBean kbnBean;
    
    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(
            new Object() {}.getClass().getEnclosingClass().getName());

    /**
     * スクリーンコード：MST501
     */
    private static final String SC_CD_MST132 = "MST132_SCREEN";

    /**
     * 定数：検索ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH = "mst132-get-shiiresaki-detail";

    /**
     * 採番処理
     */
    private static final String SAIBAN = "mst132-saiban";

    /**
     * 定数：MasterInfo取得キー
     */
    private static final String CONST_MST132_MASTER = "mst132";

    /**
     * 適用開始日検索
     */
    private static final String CONST_TEKIYOU_KAISHIBI = "mst132-search-tekiyou-kaishibi";

    /**
     * 
     */
    private static final String CONST_SHINSEI = "mst132-do-shinsei";
    
    /**
     * 履歴テーブル検索キー
     */
    private Map<String, Object> rirekiSearchKey;

    /**
     * ワーク.メッセージリスト
     */
    List<MessageModuleBean> msgList = new ArrayList<>();

    /**
     * コンストラクタ
     */
    public Mst132Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId　メニューID
     * @param prevScreen 遷移元画面ID
     * @param backFlag 戻るフラグ
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            // パンくずを追加する
            breadBean.push(TITLE, SCREEN.MST132_SCREEN.name(), this);
            Flash passParam = pageCommonBean.getPageParam();
            // 渡すパラメータ
            Map<String, Object> param = (Map<String, Object>) passParam.get("param");
            if (param != null) {
                if ("2".equals(param.get("moveMode").toString())) {
                    // 編集モード
                    mst132Form.setMode("2");
                    mst132Form.setRirekiDisabled(false);
                } else if ("3".equals(param.get("moveMode").toString())) {
                    // 参照モード
                    mst132Form.setMode("3");
                    mst132Form.setRirekiDisabled(false);
                }
            } else {
                // 新規モード
                mst132Form.setMode("1");
                mst132Form.setRirekiDisabled(true);
                mst132Form.setKhnDtlJisCdEdit(autoCompleteViewBean.initAddr("jisCd", null));
            }
            // システムマスタ取得する
            pageCommonBean.getMasterInfo(CONST_MST132_MASTER);
            // 管轄営業所コード
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO,
                    new AutoCompOptionBean("全て", "all"), null,
                    authorityConfBean.getDefaultEigyosho());

            // 仕入先コード
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_SHIIRESAKI);
            // 法人番号コード
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_MS_HOJIN_BANGO);
            // SS仕入先コード
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_MS_SS_SHIIRESAKI);
            // その他作業営業所コード
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_ALL_VW_EIGYOSHO);
            // 空港コード
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_MS_KUKO);
            // 仕向地
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_SHIMUKE_CHI_CD);
            // 口座種別コード
            autoCompleteViewBean.getMsKbn(MsCnst.GINKO_KOZA_SHUBETU);
            // 集配地区
            autoCompleteViewBean.getMsKbn(MsCnst.SHUHAI_CHIKU);
            // 戻ってきた場合
            if (backFlag) {
                // 何もしない
            } else {
                // 進んできた場合
                // 検索パラメータがある場合
                if (param != null) {
                    // 管轄区分
                    mst132Form.setConKankatsuKbn(param.get("kankaKbn").toString());
                    // 営業所コードと営業所名
                    if ("all".equals(param.get("eigyoshoCd").toString())) {
                        mst132Form.setConKankatsuEigyosho(new AutoCompOptionBean("全て", "all"));
                    } else {
                        mst132Form.setConKankatsuEigyosho(
                        new AutoCompOptionBean(param.get("eigyoshoMei").toString(),
                                param.get("eigyoshoCd").toString()));
                    }
                    // ステタス
                    mst132Form.setConShinseiStatus(param.get("status").toString());
                    // 仕入先コード
                    mst132Form.setConShiiresakiCdStr(param.get("shiiresakiCd").toString());
                    mst132Form.setConShiiresakiCd(new AutoCompOptionBean(param.get("shiiresakiCd").toString(),
                        param.get("shiiresakiCd").toString()));
                    // 適用開始日
                    mst132Form.setConTekiyoKaishibi(param.get("kaishiBi").toString());
                    // 適用名
                    mst132Form.setConTekiyoMei(param.get("teikiyoMei").toString());
                    search(param.get("shiiresakiCd").toString(), param.get("kaishiBi").toString());
                }
            }

            // component初期化とユーザ権限により制御を設定する
            pageCommonBean.setAuthControll(mst132Form, SC_CD_MST132, false);

        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * 検索処理
     *
     * @param conShiiresakiCd 仕入先コード
     * @param conTekiyoKaishibi 適用開始日
     */
    public void search(String conShiiresakiCd, String conTekiyoKaishibi) {
        // 検索パラメータ設定
        Map<String, Object> params = new HashMap<>();
        // 仕入先コード
        params.put("conShiiresakiCd", conShiiresakiCd);
        // 適用開始日
        params.put("conTekiyoKaishibi", conTekiyoKaishibi);
        // 検索結果
        List<Map<String, Object>> resList = new ArrayList<>();
        try {
            //DB情報取得
            ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH);
            ObjectMapper mapper = new ObjectMapper();
            resList = mapper.readValue(res.getJson(), List.class);
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        Map<String, Object> gamenMap = new HashMap();
        if (!resList.isEmpty()) {
            gamenMap = resList.get(0);
        }
        // 検索結果値を画面へ設定する
        gamenSet(gamenMap);
        // 履歴検索パラメータ
        Map<String, Object> rirekiSearch = new HashMap<>();
        rirekiSearch.put("shiiresakiCd", mst132Form.getConShiiresakiCdStr());
        rirekiSearch.put("conTekiyoKaishibi", mst132Form.getConTekiyoKaishibi());
        mst132Form.setRirekiSearchKey(rirekiSearch);
    }

    /**
     * 適用開始日検索
     *
     * @throws IOException 異常処理
     * @throws ParseException
     */
    public void tekiyouKaishiBi() throws IOException, ParseException {
        Map<String, Object> params = new HashMap<>();
        // 仕入先コード
        params.put("conShiiresakiCd", mst132Form.getConShiiresakiCd().getValue());
        // ＤＢから適用開始日取得
        ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, CONST_TEKIYOU_KAISHIBI);
        List<Map<String, Object>> tekiyouKaishiBiList = new ArrayList<>();
        ObjectMapper mapper = new ObjectMapper();
        tekiyouKaishiBiList = mapper.readValue(res.getJson(), List.class);
        // 検索結果は０件以上
        if (!tekiyouKaishiBiList.isEmpty()) {
            String tekiyouKaishiBi = tekiyouKaishiBiList.get(0).get("TEKIYO_KAISHIBI").toString();
            pageCommonBean.executeScript("setTekiyouKaishiBi" + "('" + tekiyouKaishiBi + "')");
        }
    }

    /**
     * 採番処理
     * 
     */
    public void saiBan() {
        // DBからデータ取得
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(null, SAIBAN);

        ObjectMapper mapper = new ObjectMapper();
        Map<String, String> saibanNo = new HashMap<>();
        try {
            saibanNo = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
            if (saibanNo != null) {
                mst132Form.setConShiiresakiCd(new AutoCompOptionBean(saibanNo.get("saiBanNo"),
                        saibanNo.get("saiBanNo")));
            }
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * 検索結果値を画面へ設定する
     *
     * @param gamenMap 画面データ
     */
    public void gamenSet(Map<String, Object> gamenMap) {

        // 仕入先名
        if (gamenMap.get("knrDtlShiiresakiMei") != null) {
            mst132Form.setKnrDtlShiiresakiMei(gamenMap.get("knrDtlShiiresakiMei").toString());
        }
        // 仕入先名カナ
        if (gamenMap.get("knrDtlShiiresakiMeikana") != null) {
            mst132Form.setKnrDtlShiiresakiMeikana(gamenMap.get("knrDtlShiiresakiMeikana").toString());
        }
        // 仕入先名備考
        if (gamenMap.get("knrDtlShiiresakiMeiBiko") != null) {
            mst132Form.setKnrDtlShiiresakiMeiBiko(gamenMap.get("knrDtlShiiresakiMeiBiko").toString());
        }
        // 法人番号コードand法人番号名
        if (gamenMap.get("knrDtlHojinBangoCd") != null) {
            mst132Form.setKnrDtlHojinBango(new AutoCompOptionBean(gamenMap.get("knrDtlHojinBangoMei").toString(),
                    gamenMap.get("knrDtlHojinBangoCd").toString()));
        }

        // 適用終了
        if (gamenMap.get("conTekiyoShuryobi") != null && !"".equals(gamenMap.get("conTekiyoShuryobi").toString())) {
            List<String> list = new ArrayList<>();
            list.add("01");
            mst132Form.setConTekiyoShuryobi(list);
        }
        // SS仕入先コード
        if (gamenMap.get("knrDtlSsShiiresakiCd") != null &&
                gamenMap.get("knrDtlSsShiiresakiMei").toString() != null) {
            mst132Form.setKnrDtlSsShiiresaki(new AutoCompOptionBean(gamenMap.get("knrDtlSsShiiresakiMei").toString(),
            gamenMap.get("knrDtlSsShiiresakiCd").toString()));
        }
        // SS企業コード
        if (gamenMap.get("knrDtlSskigyoCd") != null) {
            mst132Form.setKnrDtlSskigyoCd(gamenMap.get("knrDtlSskigyoCd").toString());
        }
        // その他使用営業所コード
        if (gamenMap.get("knrDtlSonotaShiyoEigyoshoCd") != null
                && gamenMap.get("knrDtlSonotaShiyoEigyoshoMei") != null) {
            mst132Form.setKnrDtlSonotaShiyoEigyosho(new AutoCompOptionBean(
                    gamenMap.get("knrDtlSonotaShiyoEigyoshoMei").toString(),
                    gamenMap.get("knrDtlSonotaShiyoEigyoshoCd").toString()));
        }
        // その他使用営業所備考
        if (gamenMap.get("knrDtlSonotaShiyoEigyoshoBiko") != null) {
            mst132Form.setKnrDtlSonotaShiyoEigyoshoBiko(
                    gamenMap.get("knrDtlSonotaShiyoEigyoshoBiko").toString());
        }
        // 仕入先データバージョン
        if (gamenMap.get("knrDtlHShiiresakiDataVersion") != null) {
            mst132Form.setKnrDtlHShiiresakiDataVersion(gamenMap.get("knrDtlHShiiresakiDataVersion").toString());
        }
        // 適用フラグ
        if (gamenMap.get("knrDtlHTekiyoFlg") != null) {
            mst132Form.setKnrDtlHTekiyoFlg(gamenMap.get("knrDtlHTekiyoFlg").toString());
        }
        // 会社名
        if (gamenMap.get("khnDtlKaishaMei") != null) {
            mst132Form.setKhnDtlKaishaMei(gamenMap.get("khnDtlKaishaMei").toString());
        }
        // 会社名カナ
        if (gamenMap.get("khnDtlKaishaMeiKana") != null) {
            mst132Form.setKhnDtlKaishaMeiKana(gamenMap.get("khnDtlKaishaMeiKana").toString());
        }
        // 支店/営業所名
        if (gamenMap.get("khnDtlShitenEigyoshoMei") != null) {
            mst132Form.setKhnDtlShitenEigyoshoMei(gamenMap.get("khnDtlShitenEigyoshoMei").toString());
        }
        // 支店/営業所名カナ
        if (gamenMap.get("khnDtlShitenEigyoshoMeiKana") != null) {
            mst132Form.setKhnDtlShitenEigyoshoMeiKana(gamenMap.get("khnDtlShitenEigyoshoMeiKana").toString());
        }
        // 部署/担当者１
        if (gamenMap.get("khnDtlBushoTantosha1") != null) {
            mst132Form.setKhnDtlBushoTantosha1(gamenMap.get("khnDtlBushoTantosha1").toString());
        }
        // 部署/担当者２
        if (gamenMap.get("khnDtlBushoTantosha2") != null) {
            mst132Form.setKhnDtlBushoTantosha2(gamenMap.get("khnDtlBushoTantosha2").toString());
        }
        // 旧住所
        if (gamenMap.get("khnDtlKyuJusho") != null) {
            mst132Form.setKhnDtlKyuJusho(gamenMap.get("khnDtlKyuJusho").toString());
        }
        // 使用不可
        if (gamenMap.get("khnDtlShiyoFuka") != null) {
            mst132Form.setKhnDtlShiyoFuka(gamenMap.get("khnDtlShiyoFuka").toString());
        }
        // 新住所反映
        if (gamenMap.get("khnDtlSinJushoHanei") != null) {
            mst132Form.setKhnDtlSinJushoHanei(gamenMap.get("khnDtlSinJushoHanei").toString());
        }
        // 郵便番号
        if (gamenMap.get("khnDtlYubinBango") != null && gamenMap.get("khnDtlYubinBango").toString().length() > 3) {
            StringBuilder yuBinBango = new StringBuilder(gamenMap.get("khnDtlYubinBango").toString());
            yuBinBango.insert(3, "-");
            mst132Form.setKhnDtlYubinBango(yuBinBango.toString());
        }
        // JISコード
        if (gamenMap.get("khnDtlJisCd") != null) {
            mst132Form.setKhnDtlJisCd(gamenMap.get("khnDtlJisCd").toString());
            AutoCompOptionBean jisCd = autoCompleteViewBean.initAddr("jisCd", gamenMap.get("khnDtlJisCd").toString());
            mst132Form.setKhnDtlJisCdEdit(jisCd);
        }
        // 住所1
        if (gamenMap.get("khnDtlJusho1") != null) {
            mst132Form.setKhnDtlJusho1(gamenMap.get("khnDtlJusho1").toString());
        }
        // 住所2
        if (gamenMap.get("khnDtlJusho2") != null) {
            mst132Form.setKhnDtlJusho2(gamenMap.get("khnDtlJusho2").toString());
        }
        // 住所3
        if (gamenMap.get("khnDtlJusho3") != null) {
            mst132Form.setKhnDtlJusho3(gamenMap.get("khnDtlJusho3").toString());
        }
        // 住所4
        if (gamenMap.get("khnDtlJusho4") != null) {
            mst132Form.setKhnDtlJusho4(gamenMap.get("khnDtlJusho4").toString());
        }
        // 空港コード
        if (gamenMap.get("khnDtlKukoCd") != null && gamenMap.get("khnDtlKukoMei") != null) {
            mst132Form.setKhnDtlKuko(new AutoCompOptionBean(
                    gamenMap.get("khnDtlKukoMei").toString(),
                    gamenMap.get("khnDtlKukoCd").toString()));
        }
        // 仕向地
        if (gamenMap.get("khnDtlShimukeChiCd") != null && gamenMap.get("khnDtlShimukeChiMei") != null) {
            mst132Form.setKhnDtlShimukeChi(autoCompleteViewBean.getComMsDatas("COM_GET_SHIMUKE_CHI_CD",
                    gamenMap.get("khnDtlShimukeChiCd").toString()));
            mst132Form.setKhnDtlShimukeChiStr(gamenMap.get("khnDtlShimukeChiCd").toString());
        }
        // 集配地区コード
        if (gamenMap.get("khnDtlShuhaiChikuCd") != null) {
            Map<String, String> params = new HashMap<>();
            params.put("kbnGroupCd", MsCnst.SHUHAI_CHIKU);
            mst132Form.setKhnDtlShuhaiChikuCdLabelValueListt(
                autoCompleteBean.getOptionBeanByName(MsCnst.COM_GET_MS_KBN, params,
                    gamenMap.get("khnDtlShuhaiChikuCd").toString(), null));
        }
        // 電話番号１
        if (gamenMap.get("khnDtlTelBango1") != null) {
            mst132Form.setKhnDtlTelBango1(gamenMap.get("khnDtlTelBango1").toString());
        }
        // 電話番号２
        if (gamenMap.get("khnDtlTelBango2") != null) {
            mst132Form.setKhnDtlTelBango2(gamenMap.get("khnDtlTelBango2").toString());
        }
        // FAX番号
        if (gamenMap.get("khnDtlFaxBango") != null) {
            mst132Form.setKhnDtlFaxBango(gamenMap.get("khnDtlFaxBango").toString());
        }
        // 金融機関名
        if (gamenMap.get("trhkDtlKinyuKikanMei") != null) {
            mst132Form.setTrhkDtlKinyuKikanMei(gamenMap.get("trhkDtlKinyuKikanMei").toString());
        }
        // 支店名
        if (gamenMap.get("trhkDtlShitenMei") != null) {
            mst132Form.setTrhkDtlShitenMei(gamenMap.get("trhkDtlShitenMei").toString());
        }
        // 口座種別コード
        if (gamenMap.get("trhkDtlKozaShubetsuCd") != null) {
            mst132Form.setTrhkDtlKozaShubetsu(new AutoCompOptionBean(
                    gamenMap.get("trhkDtlKozaShubetsuMei").toString(),
                    gamenMap.get("trhkDtlKozaShubetsuCd").toString()));
        }
        // 口座番号
        if (gamenMap.get("trhkDtlKozaBango") != null) {
            mst132Form.setTrhkDtlKozaBango(gamenMap.get("trhkDtlKozaBango").toString());
        }
        // 名義人名
        if (gamenMap.get("trhkDtlMeigininMei") != null) {
            mst132Form.setTrhkDtlMeigininMei(gamenMap.get("trhkDtlMeigininMei").toString());
        }
        // 手数料負担
        if (gamenMap.get("trhkDtlTesuryoFutan") != null) {
            mst132Form.setTrhkDtlTesuryoFutan(gamenMap.get("trhkDtlTesuryoFutan").toString());
        }
        // 支払条件
        if (gamenMap.get("trhkDtlShiharaiJoken") != null) {
            mst132Form.setTrhkDtlShiharaiJoken(gamenMap.get("trhkDtlShiharaiJoken").toString());
        }
        // 買掛金コード
        if (gamenMap.get("trhkDtlKaikakekinCd") != null) {
            mst132Form.setTrhkDtlKaikakekinCd(gamenMap.get("trhkDtlKaikakekinCd").toString());
        }
        // メモ
        if (gamenMap.get("sntDtlMemo") != null) {
            mst132Form.setSntDtlMemo(gamenMap.get("sntDtlMemo").toString());
        }
        // 更新日時
        if (gamenMap.get("lastDtlKoshinNichiji") != null) {
            mst132Form.setLastDtlKoshinNichiji(gamenMap.get("lastDtlKoshinNichiji").toString());
        }
        // 更新者
        if (gamenMap.get("lastDtlKoshinSha") != null) {
            mst132Form.setLastDtlKoshinSha(gamenMap.get("lastDtlKoshinSha").toString());
        }
        // 最終使用日(代理店マスタ)
        if (gamenMap.get("lastDtlShiyoHizukeMsDairiten") != null) {
            mst132Form.setLastDtlShiyoHizukeMsDairiten(gamenMap.get("lastDtlShiyoHizukeMsDairiten").toString());
        }
        // 最終使用日(仕入管理)
        if (gamenMap.get("lastDtlShiyoHizukeTrShiireKanri") != null) {
            mst132Form.setLastDtlShiyoHizukeTrShiireKanri(gamenMap.get("lastDtlShiyoHizukeTrShiireKanri").toString());
        }
        // 更新コンタ
        if (gamenMap.get("koushinCounter") != null) {
            mst132Form.setKoushinCounter(gamenMap.get("koushinCounter").toString());
        }
        // データバジョン
        if (gamenMap.get("dtlShiiresakiDataVersion") != null) {
            mst132Form.setDtlShiiresakiDataVersion(gamenMap.get("dtlShiiresakiDataVersion").toString());
        }
        // 適用フラグ
        if (gamenMap.get("tekiyoFlg") != null) {
            mst132Form.setTekiyouFlg(gamenMap.get("tekiyoFlg").toString());
        }
        // 使用区分
        List<String> shiyouKbn = new ArrayList<>();
        if (gamenMap.get("knrDtlShiyokbn0") != null) {
            if ("1".equals(gamenMap.get("knrDtlShiyokbn0").toString())) {
                shiyouKbn.add("1");
            }
        }
        if (gamenMap.get("knrDtlShiyokbn1") != null) {
            if ("1".equals(gamenMap.get("knrDtlShiyokbn1").toString())) {
                shiyouKbn.add("2");
            }
        }
        if (gamenMap.get("knrDtlShiyokbn2") != null) {
            if ("1".equals(gamenMap.get("knrDtlShiyokbn2").toString())) {
                shiyouKbn.add("3");
            }
        }
        if (gamenMap.get("knrDtlShiyokbn3") != null) {
            if ("1".equals(gamenMap.get("knrDtlShiyokbn3").toString())) {
                shiyouKbn.add("4");
            }
        }
        if (gamenMap.get("knrDtlShiyokbn4") != null) {
            if ("1".equals(gamenMap.get("knrDtlShiyokbn4").toString())) {
                shiyouKbn.add("5");
            }
        }
        if (gamenMap.get("knrDtlShiyokbn5") != null) {
            if ("1".equals(gamenMap.get("knrDtlShiyokbn5").toString())) {
                shiyouKbn.add("6");
            }
        }
        mst132Form.setKnrDtlShiyokbn(shiyouKbn);
    }

    /**
     * 管轄営業所入力チェック
     *
     * @return チェック結果
     */
    public boolean eigyoshoCheck() {
        if (kbnBean.getKbnCdOfKeyCd(MsCnst.KANKATSU_KBN_KASHO).equals(mst132Form.getConKankatsuKbn())) {
            if (mst132Form.getConKankatsuEigyosho() == null) {
                    messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0011, "mst132DataForm:eigyosho:conKankatsuEigyosho", "管轄営業所コード");
                    return false;
            }
        }
        return true;
    }

    /**
     * 仕入先登録申請
     * 
     */
    public String tourokuShinsei() {
        
        return shinsei("1");
    }
    
    /**
     * 申請処理
     * 
     * @param shinseiMode 申請モード
     */
    public String shinsei(String shinseiMode) {
        if (!eigyoshoCheck()) {
            return "";
        }
        // 申請パラメータ
        Map<String, Object> sinseiParams = new HashMap<>();
        sinseiParams = setShinseiParam(shinseiMode);

        // 仕入先申請実行
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(sinseiParams, CONST_SHINSEI);
        // エラーの場合、処理を終了
        if (serviceInterfaceBean.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            messagePropertyBean.message(serviceInterfaceBean.getMessages().get(0)[0],
                    serviceInterfaceBean.getMessages().get(0)[1]);
            return "";
        }
        // 画面遷移を行う
        url = forward(SCREEN.DEM012_SCREEN.name(), null, SCREEN.MST132_SCREEN.name(), false);
        return url;
    } 
    /**
     * 仕入先論理削除申請
     */
    public String ronriSakujyouShinsei(){
        return shinsei("3");
    }

    /**
     * 仕入先削除申請
     */
    public String sakujyouShinsei(){
        return shinsei("4");
    }
    
    /**
     * 申請パラメータ設定
     * 
     * @param shinseiMode 申請モード
     * @return 申請パラメータ
     */
    public Map<String, Object> setShinseiParam(String shinseiMode) {
        // パラメータ初期化
        Map<String, Object> shinseiParams = new HashMap<>();
        // 申請モード
        shinseiParams.put("shinSeiMode", shinseiMode);
        // 仕入先コード
        if (mst132Form.getConShiiresakiCd() != null) {
            shinseiParams.put("conShiiresakiCd", mst132Form.getConShiiresakiCd().getValue());
        }
        // 適用開始日
        shinseiParams.put("conTekiyoKaishibi", mst132Form.getConTekiyoKaishibi());
        // 管轄区分
        shinseiParams.put("conKankatsuKbn", mst132Form.getConKankatsuKbn());
        // 管轄営業所コード
        if (mst132Form.getConKankatsuEigyosho() != null) {
            shinseiParams.put("conKankatsuEigyoshoCd", mst132Form.getConKankatsuEigyosho().getValue());
        }
        // 適用終了
        if (!mst132Form.getConTekiyoShuryobi().isEmpty()) {
            shinseiParams.put("conTekiyoShuryobi", DateUtils.getSysDate());
        }
        // 適用名
        shinseiParams.put("conTekiyoMei", mst132Form.getConTekiyoMei());
        // 仕入先名
        shinseiParams.put("knrDtlShiiresakiMei", mst132Form.getKnrDtlShiiresakiMei());
        // 仕入先カナ
        shinseiParams.put("knrDtlShiiresakiMeikana", mst132Form.getKnrDtlShiiresakiMeikana());
        // 法人番号コード
        shinseiParams.put("knrDtlHojinBangoCd", mst132Form.getKnrDtlHojinBango().getValue());
        // 使用区分
        shinseiParams.put("conShiyoKbn", mst132Form.getKnrDtlShiyokbn());
        // SS仕入先コード
        shinseiParams.put("knrDtlSsShiiresakiCd", mst132Form.getKnrDtlSsShiiresaki().getValue());
        // SS企業コード
        shinseiParams.put("knrDtlSskigyoCd", mst132Form.getKnrDtlSskigyoCd());
        // その他使用営業所コード
        if (mst132Form.getKnrDtlSonotaShiyoEigyosho() != null) {
            shinseiParams.put("knrDtlSonotaShiyoEigyoshoCd", mst132Form.getKnrDtlSonotaShiyoEigyosho().getValue());
        }
        // 会社名
        shinseiParams.put("khnDtlKaishaMei", mst132Form.getKhnDtlKaishaMei());
        // 会社名カナ
        shinseiParams.put("khnDtlKaishaMeiKana", mst132Form.getKhnDtlKaishaMeiKana());
        // 支店営業所名
        shinseiParams.put("khnDtlShitenEigyoshoMei", mst132Form.getKhnDtlShitenEigyoshoMei());
        // 支店営業所カナ
        shinseiParams.put("khnDtlShitenEigyoshoMeiKana", mst132Form.getKhnDtlShitenEigyoshoMeiKana());
        // 部署担当者１
        shinseiParams.put("khnDtlBushoTantosha1", mst132Form.getKhnDtlBushoTantosha1());
        // 部署担当者2
        shinseiParams.put("khnDtlBushoTantosha2", mst132Form.getKhnDtlBushoTantosha2());
        // 郵便番号
        String youbinBango = mst132Form.getKhnDtlYubinBango().replace("-", "");
        shinseiParams.put("khnDtlYubinBango", youbinBango);
        // JISコード
        shinseiParams.put("khnDtlJisCd", mst132Form.getKhnDtlJisCdEdit().getValue());
        // 住所1
        shinseiParams.put("khnDtlJusho1", mst132Form.getKhnDtlJusho1());
        // 住所2
        shinseiParams.put("khnDtlJusho2", mst132Form.getKhnDtlJusho2());
        // 住所3
        shinseiParams.put("khnDtlJusho3", mst132Form.getKhnDtlJusho3());
        // 住所4
        shinseiParams.put("khnDtlJusho4", mst132Form.getKhnDtlJusho4());
        // 空港コード
        shinseiParams.put("khnDtlKukoCd", mst132Form.getKhnDtlKuko().getValue());
        // 仕向地コード
        shinseiParams.put("khnDtlShimukeChiCd", mst132Form.getKhnDtlShimukeChi().getValue());
        // 集配地区
        shinseiParams.put("khnDtlShuhaiChikuCd", mst132Form.getKhnDtlShuhaiChikuCdLabelValueListt().getLabel());
        // 電話番号１
        shinseiParams.put("khnDtlTelBango1", mst132Form.getKhnDtlTelBango1());
        // 電話番号2
        shinseiParams.put("khnDtlTelBango2", mst132Form.getKhnDtlTelBango2());
        // FAX番号
        shinseiParams.put("khnDtlFaxBango", mst132Form.getKhnDtlFaxBango());
        // 金融機関名
        shinseiParams.put("trhkDtlKinyuKikanMei", mst132Form.getTrhkDtlKinyuKikanMei());
        // 支店名
        shinseiParams.put("trhkDtlShitenMei", mst132Form.getTrhkDtlShitenMei());
        // 口座種別
        if (mst132Form.getTrhkDtlKozaShubetsu() != null) {
            shinseiParams.put("trhkDtlKozaShubetsuCd", mst132Form.getTrhkDtlKozaShubetsu().getValue());
        }
        // 口座番号
        shinseiParams.put("trhkDtlKozaBango", mst132Form.getTrhkDtlKozaBango());
        // 名義人名
        shinseiParams.put("trhkDtlMeigininMei", mst132Form.getTrhkDtlMeigininMei());
        // 手数料負担
        shinseiParams.put("trhkDtlTesuryoFutan", mst132Form.getTrhkDtlTesuryoFutan());
        // 支払条件
        shinseiParams.put("trhkDtlShiharaiJoken", mst132Form.getTrhkDtlShiharaiJoken());
        // 買掛金コード
        shinseiParams.put("trhkDtlKaikakekinCd", mst132Form.getTrhkDtlKaikakekinCd());
        // メモ
        shinseiParams.put("sntDtlMemo", mst132Form.getSntDtlMemo());
        // データバジョン
        shinseiParams.put("dtlShiiresakiDataVersion", mst132Form.getKnrDtlHShiiresakiDataVersion());
        // 更新カウンタ
        shinseiParams.put("koushinCounter", mst132Form.getKoushinCounter());
        // 更新ユーザ
        shinseiParams.put("koushinUser", mst132Form.getLastDtlKoshinSha());
        // 適用フラグ
        shinseiParams.put("tekiyoFlg", mst132Form.getTekiyouFlg());
        return shinseiParams;
    }
    
    /**
     * メニュークリック処理
     *
     * @param menuId メニューID
     * @param nextScreenId 遷移先画面ID
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreenId) {
        try {
            // パンくずを削除する
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移を行う
        url = forward(nextScreenId, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック処理
     *
     * @param nextScreenId 遷移先画面ID
     * @param breadIndex パンくずのインデックス
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreenId, int breadIndex) {

        try {
            // パンくずを削除する
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移を行う
        url = forward(nextScreenId, null, null, true);
        return url;
    }

    /**
     * ログアウトクリック処理
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authorityConfBean.logout();
    }

}
