package jp.co.kintetsuls.utils;

import javax.faces.context.FacesContext;
import javax.faces.context.Flash;

/**
 *
 * @author malei
 */
public class FlashUtil {
   
    /**
     * 画面パラメータ得用また設定用
     *
     * @return obj
     */
    public Flash getPageParam() {
        return FacesContext.getCurrentInstance().getExternalContext().getFlash();
    }
}
