/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common;

import java.io.Serializable;
import javax.faces.bean.ApplicationScoped;
import lombok.Data;

/**
 * E2コード定義モード
 * 
 * @author zf (MBP)
 * @version 2019/2/21 新規作成
 */
@ApplicationScoped
@Data
public class KbnModuleBean implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 区分グループコード(コード種別)
     */
    private String kbnGroupCd;

    /**
     * 区分グループ名(コード種別名)
     */
    private String kbnGroupMei;

    /**
     * 区分コード(コード)
     */
    private String kbnCd;

    /**
     * 並び順
     */
    private Integer narabijun;

    /**
     * 区分名(コード名)
     */
    private String kbnMei;

    /**
     * 区分キー(コードキー)
     */
    private String kbnKey;

    public KbnModuleBean() {
    }

}
