/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.cnst.SysMsg;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.kintetsuls.utils.DateUtils;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @author MaLei (MBP)
 */
@ManagedBean(name = "autoComplete")
@SessionScoped
@Data
public class AutoCompleteBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private static final Logger logger = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    private RestfullService rest;

    private List<Map<String, String>> searchResult;

    private Map<String, List<AutoCompOptionBean>> searchResultMap;

    // 定数：AutoCompleteを取得XML指定.
    public static final String COMMON_GET_CREATE_LIST = "COMMON_GET_CREATE_LIST";

    /**
     * E2コード定義取得Bean
     */
    @ManagedProperty(value = "#{kbnBean}")
    private KbnBean kbnBean;

    /**
     * コンストラクタ
     */
    public AutoCompleteBean() {
        this.searchResultMap = new HashMap();
    }

    /**
     * AutoCompleteの文字列リストを取得する
     *
     * @param listId SQL文のID
     * @return VALUE:LABEL文字列形式リスト
     */
    public List<String> getStringList(String listId) {

        List<String> resComList = new ArrayList<>();
        List<AutoCompOptionBean> comList = null;

        if (searchResultMap.get(listId) == null) {
            comList = getValueLabelFromDB(listId, new HashMap(), null);
            if (comList != null && comList.size() > 0) {
                searchResultMap.put(listId, comList);
            }
        } else {
            comList = searchResultMap.get(listId);
        }

        if (comList != null && comList.size() > 0) {
            for (AutoCompOptionBean rec : comList) {
                resComList.add(rec.getValue() + " " + rec.getLabel());
            }
        }
        return resComList;
    }

    /**
     * AutoCompleteの文字列リストを取得する
     *
     * @param listId SQL文のID
     * @param key
     * @return VALUE:LABEL文字列形式リスト
     */
    public List<String> getStringListByKey(String listId, String key) {

        List<String> resComList = new ArrayList<>();
        List<AutoCompOptionBean> comList = null;

        if (searchResultMap.get(listId) == null) {
            comList = getValueLabelFromDB(listId, new HashMap(), null);
            if (comList != null && comList.size() > 0) {
                searchResultMap.put(listId, comList);
            }
        } else {
            comList = searchResultMap.get(listId);
        }

        if (comList != null && comList.size() > 0) {
            for (AutoCompOptionBean rec : comList) {
                if (rec.getValue().equals(key) || rec.getValue().startsWith(key)
                        || rec.getLabel().equals(key) || rec.getLabel().startsWith(key)) {
                    resComList.add(rec.getValue() + " " + rec.getLabel());
                }
            }
        }
        return resComList;
    }

    /**
     * AutoCompleteの文字列リストを取得する
     *
     * @param listId SQL文のID
     * @param value
     * @return ValueよりLABELを返す
     */
    public String getLabelByValue(String listId, String value) {

        List<String> resComList = new ArrayList<>();
        List<AutoCompOptionBean> comList = null;

        if (searchResultMap.get(listId) == null) {
            comList = getValueLabelFromDB(listId, new HashMap(), null);
            if (comList != null && comList.size() > 0) {
                searchResultMap.put(listId, comList);
            }
        } else {
            comList = searchResultMap.get(listId);
        }

        if (comList != null && comList.size() > 0) {
            for (AutoCompOptionBean rec : comList) {
                if (rec != null && rec.getValue().equals(value)) {
                    return rec.getLabel();
                }
            }
        }
        return null;
    }

    /**
     * AutoCompleteの文字列リストを取得する
     *
     * @param listId SQL文のID
     * @return VALUEのみ文字列形式リスト
     */
    public List<String> getStringListValueOnly(String listId) {

        List<String> resComList = new ArrayList<>();
        List<AutoCompOptionBean> comList = null;

        if (searchResultMap.get(listId) == null) {
            Map params = new HashMap();
            // ログインユーザーコード
            params.put("loginuserCd", authConfBean.getUserCd());
            // システム日付
            params.put("sysDate", DateUtils.format(DateUtils.getSysDate(), StndConsIF.DF_YYYY_MM_DD));

            comList = getValueLabelFromDB(listId, params, null);
            if (comList != null && comList.size() > 0) {
                searchResultMap.put(listId, comList);
            }
        } else {
            comList = searchResultMap.get(listId);
        }

        if (comList != null && comList.size() > 0) {
            for (AutoCompOptionBean rec : comList) {
                resComList.add(rec.getValue());
            }
        }
        return resComList;
    }

    /**
     * AutoCompleteのLabelValueクラスリストを取得する
     *
     * @param listId SQL文のID
     * @return AutoCompOptionBeanクラスリスト
     */
    public List<AutoCompOptionBean> getLabelValueList(String listId) {

        List<AutoCompOptionBean> comList = null;

        if (searchResultMap.get(listId) == null) {
            comList = getValueLabelFromDB(listId, new HashMap(), null);
            if (comList != null && comList.size() > 0) {
                searchResultMap.put(listId, comList);
            }
        } else {
            comList = searchResultMap.get(listId);
        }
        return comList;
    }

    /**
     * AutoCompleteの文字列リストを取得する
     *
     * @param listId SQL文のID
     * @param param パラメータ
     * @return VALUEのみ文字列形式リスト
     */
    public List<String> getStringListValueOnly(String listId, String param) {

        List<String> resComList = new ArrayList<>();

        Map params = new HashMap();
        // ログインユーザーコードの取得について TODO
        params.put("loginuserCd", "axis00");
        // システム日付
        params.put("sysDate", DateUtils.format(DateUtils.getSysDate(), StndConsIF.DF_YYYY_MM_DD));

        String key = listId;

        // 区分マスタ取得、付帯料金項目1取得、または、付帯料金項目2取得の特別処理
        if (MsCnst.COM_GET_MS_KBN.equals(listId)
                || MsCnst.COM_GET_MS_KBN_MEI.equals(listId)
                || MsCnst.COM_GET_VW_FUTAI_RYOKIN_KOMOKU1.equals(listId)
                || MsCnst.COM_GET_VW_FUTAI_RYOKIN_KOMOKU2.equals(listId)) {
            if (param != null) {
                key = listId.concat("_").concat(param);

                if (MsCnst.COM_GET_MS_KBN.equals(listId)
                        || MsCnst.COM_GET_MS_KBN_MEI.equals(listId)) {
                    params.put("kbnGroupCd", param);
                } else {
                    params.put("uriageKbn", kbnBean.getKbnCdOfKeyCd(param));
                    params.put("KBN_KEY", param);
                }
            }
        }
        initAutoComplete(listId, params);

        if (getSearchResultMap() != null
                && getSearchResultMap().get(key) != null
                && getSearchResultMap().get(key).size() > 0) {

            for (AutoCompOptionBean autoCompList : getSearchResultMap().get(key)) {
                resComList.add(autoCompList.getValue());
            }
        }
        return resComList;
    }

    /**
     * AutoCompleteの文字列リストを取得する
     *
     * @param listId SQL文のID
     * @param param パラメータ
     * @return VALUEのみ文字列形式リスト
     */
    public List<String> getStringList(String listId, String param) {

        List<String> resComList = new ArrayList<>();

        Map params = new HashMap();
        // ログインユーザーコードの取得について TODO
        params.put("loginuserCd", "axis00");
        // システム日付
        params.put("sysDate", DateUtils.format(DateUtils.getSysDate(), StndConsIF.DF_YYYY_MM_DD));

        String key = listId;

        // 区分マスタ取得、付帯料金項目1取得、または、付帯料金項目2取得の特別処理
        if (MsCnst.COM_GET_MS_KBN.equals(listId)
                || MsCnst.COM_GET_MS_KBN_MEI.equals(listId)
                || MsCnst.COM_GET_VW_FUTAI_RYOKIN_KOMOKU1.equals(listId)
                || MsCnst.COM_GET_VW_FUTAI_RYOKIN_KOMOKU2.equals(listId)) {
            if (param != null) {
                key = listId.concat("_").concat(param);

                if (MsCnst.COM_GET_MS_KBN.equals(listId)
                        || MsCnst.COM_GET_MS_KBN_MEI.equals(listId)) {
                    params.put("kbnGroupCd", param);
                } else {
                    params.put("uriageKbn", kbnBean.getKbnCdOfKeyCd(param));
                    params.put("KBN_KEY", param);
                }
            }
        }
        initAutoComplete(listId, params);

        if (getSearchResultMap() != null
                && getSearchResultMap().get(key) != null
                && getSearchResultMap().get(key).size() > 0) {

            for (AutoCompOptionBean autoCompList : getSearchResultMap().get(key)) {
                resComList.add(autoCompList.getValue() + " " + autoCompList.getLabel());
            }
        }
        return resComList;
    }

    /**
     * AutoCompleteのLabelValueクラスリストを入力keyより取得する
     *
     * @param listId SQL文のID
     * @param key 画面入力したkey
     * @return AutoCompOptionBeanクラスリスト
     */
    public List<AutoCompOptionBean> getLabelValueListByKey(String listId, String key) {
        return getLabelValueListByKey(listId, null, key);
    }

    /**
     * AutoCompleteのLabelValueクラスリストを入力keyより取得する
     *
     * @param listId SQL文のID
     * @param params SQL文のパラメータ
     * @param key 画面入力したkey
     * @return AutoCompOptionBeanクラスリスト
     */
    public List<AutoCompOptionBean> getLabelValueListByKey(String listId, Map params, String key) {
        return getLabelValueListByKey(listId, params, null, null, key);
    }

    /**
     * AutoCompleteのLabelValueクラスリストを入力keyより取得する
     *
     * @param listId SQL文のID
     * @param params SQL文のパラメータ
     * @param firstBean 先頭追加表示内容
     * @param honshaFlg 本社区分（１：本社、２：営業所、NULL：判断しない）
     * @param key 画面入力したkey
     * @return AutoCompOptionBeanクラスリスト
     */
    public List<AutoCompOptionBean> getLabelValueListByKey(String listId, Map params, AutoCompOptionBean firstBean, String honshaFlg, String key) {

        List<AutoCompOptionBean> comList = null;
        List<AutoCompOptionBean> comListfilte = new ArrayList<>();

        String mapKey = listId;

        // 区分マスタ取得の特別処理
        if (MsCnst.COM_GET_MS_KBN.equals(listId)
                || MsCnst.COM_GET_MS_KBN_MEI.equals(listId)) {
            if (params != null) {
                String kbnGroupCd = params.get("kbnGroupCd").toString();

                mapKey = listId.concat("_").concat(kbnGroupCd);
            }
        }
        // 付帯料金項目1取得、または、付帯料金項目2取得　の場合
        if (MsCnst.COM_GET_VW_FUTAI_RYOKIN_KOMOKU1.equals(listId) || MsCnst.COM_GET_VW_FUTAI_RYOKIN_KOMOKU2.equals(listId)) {
            if (params.get("KBN_KEY") != null) {
                String kbnKey = params.get("KBN_KEY").toString();

                mapKey = listId.concat("_").concat(kbnKey);
            }
        }
        if (firstBean != null) {
            mapKey = listId.concat("_").concat(firstBean.getValue());
        }
        if (!CheckUtils.isEmpty(honshaFlg)) {
            mapKey = mapKey.concat("_honsha_").concat(honshaFlg);
        }

        if (searchResultMap.get(mapKey) == null) {
            comList = getValueLabelFromDB(listId, params, firstBean);
            if (comList != null && comList.size() > 0) {
                searchResultMap.put(mapKey, comList);
            }
        } else {
            comList = searchResultMap.get(mapKey);
        }

        if ((key == null || "".equals(key)) && firstBean != null) {
            if (comList == null || comList.isEmpty()) {
                comList = new ArrayList<>();
            }
            if (!comList.contains(firstBean)) {
                comList.add(0, firstBean);
            }
        }

        if (comList != null && !comList.isEmpty()) {
            for (AutoCompOptionBean rec : comList) {
                if (rec.getValue().equals(key) || rec.getValue().startsWith(key)
                        || objectToStringOrBlank(rec.getLabel()).equals(key) || objectToStringOrBlank(rec.getLabel()).startsWith(key)) {
                    rec.setLabel(objectToStringOrBlank(rec.getLabel()));
                    comListfilte.add(rec);
                }
            }
        }
        return comListfilte;
    }

    /**
     * AutoCompleteのMapを初期化する
     *
     * @param listId SQL文のID
     * @param param SQL文のパラメータ
     */
    public void initAutoComplete(String listId, Map param) {
        this.initAutoComplete(listId, param, null);
    }

    /**
     * AutoCompleteのMapを初期化する
     *
     * @param listId SQL文のID
     * @param param SQL文のパラメータ
     * @param firstBean 先頭追加表示内容
     */
    public void initAutoComplete(String listId, Map param, AutoCompOptionBean firstBean) {
        this.initAutoComplete(listId, param, firstBean, null);
    }

    /**
     * AutoCompleteのMapを初期化する（パラメータが必要のSQL）
     *
     * @param listId SQL文のID
     * @param param SQL文のパラメータ
     */
    public void initAutoCompleteWithParam(String listId, Map param) {

        List<AutoCompOptionBean> comList = getValueLabelFromDB(listId, param, null);
        searchResultMap.put(listId, comList);
    }

    /**
     * AutoCompleteのMapを初期化する
     *
     * @param listId SQL文のID
     * @param param SQL文のパラメータ
     * @param firstBean 先頭追加表示内容
     * @param honshaFlg 本社区分（１：本社、２：営業所、NULL：判断しない）
     */
    public void initAutoComplete(String listId, Map param, AutoCompOptionBean firstBean, String honshaFlg) {

        List<AutoCompOptionBean> comList = null;

        String key = listId;

        // 区分マスタ取得の特別処理
        if (MsCnst.COM_GET_MS_KBN.equals(listId)
                || MsCnst.COM_GET_MS_KBN_MEI.equals(listId)) {
            if (param != null) {
                String kbnGroupCd = param.get("kbnGroupCd").toString();

                key = listId.concat("_").concat(kbnGroupCd);
            }
        }
        // 付帯料金項目1取得、または、付帯料金項目2取得　の場合
        if (MsCnst.COM_GET_VW_FUTAI_RYOKIN_KOMOKU1.equals(listId) || MsCnst.COM_GET_VW_FUTAI_RYOKIN_KOMOKU2.equals(listId)) {
            if (param.get("KBN_KEY") != null) {
                String kbnKey = param.get("KBN_KEY").toString();

                key = listId.concat("_").concat(kbnKey);
            }
        }
        if (firstBean != null) {
            key = listId.concat("_").concat(firstBean.getValue());
        }
        if (!CheckUtils.isEmpty(honshaFlg)) {
            key = key.concat("_honsha_").concat(honshaFlg);
        }

        if (searchResultMap.get(key) == null) {
            // 区分マスタ取得の特別処理
            if (MsCnst.COM_GET_MS_KBN.equals(listId)) {
                comList = kbnBean.getKbnsAutoCompOfGroupCd(param.get("kbnGroupCd").toString());
            } else if (MsCnst.COM_GET_MS_KBN_MEI.equals(listId)) {
                comList = kbnBean.getKbnMeiAutoCompOfGroupCd(param.get("kbnGroupCd").toString());
            } else {
                comList = getValueLabelFromDB(listId, param, firstBean, honshaFlg);
            }
            if (comList != null) {
                searchResultMap.put(key, comList);
            }
        }
    }

    /**
     * コードよりオプションを取得する
     *
     * @param listId キーID
     * @param params パラメータ
     * @param value コード値
     * @param firstBean 先頭追加表示内容
     * @return オプションデータ
     */
    public AutoCompOptionBean getOptionBeanByValue(String listId, Map params, String value, AutoCompOptionBean firstBean) {
        String key = listId;

        // 区分マスタ取得の特別処理
        if (MsCnst.COM_GET_MS_KBN.equals(listId)
                || MsCnst.COM_GET_MS_KBN_MEI.equals(listId)) {
            if (params != null) {
                String kbnGroupCd = params.get("kbnGroupCd").toString();

                key = listId.concat("_").concat(kbnGroupCd);
            }
        }
        // 付帯料金項目1取得、または、付帯料金項目2取得　の場合
        if (MsCnst.COM_GET_VW_FUTAI_RYOKIN_KOMOKU1.equals(listId) || MsCnst.COM_GET_VW_FUTAI_RYOKIN_KOMOKU2.equals(listId)) {
            if (params.get("KBN_KEY") != null) {
                String kbnKey = params.get("KBN_KEY").toString();

                key = listId.concat("_").concat(kbnKey);
            }
        }
        if (firstBean != null) {
            key = listId.concat("_").concat(firstBean.getValue());
        }

        List<AutoCompOptionBean> dataList = searchResultMap.get(key);
        if (dataList != null && value != null && !"".equals(value)) {
            List<AutoCompOptionBean> filterList = dataList.stream()
                    .filter((AutoCompOptionBean bean) -> value.equals(bean.getValue()))
                    .collect(Collectors.toList());
            if (filterList.size() > 0) {
                return filterList.get(0);
            }
        }
        return null;
    }
    
    /**
     * 名称よりオプションを取得する
     * 
     * @param listId キーID
     * @param params パラメータ
     * @param value コード値
     * @param firstBean 先頭追加表示内容
     * @return オプションデータ
     */
    public AutoCompOptionBean getOptionBeanByName(String listId, Map params, String value, AutoCompOptionBean firstBean) {
        String key = listId;

        // 区分マスタ取得の特別処理
        if (MsCnst.COM_GET_MS_KBN.equals(listId)
                || MsCnst.COM_GET_MS_KBN_MEI.equals(listId)) {
            if (params != null) {
                String kbnGroupCd = params.get("kbnGroupCd").toString();

                key = listId.concat("_").concat(kbnGroupCd);
            }
        }
        // 付帯料金項目1取得、または、付帯料金項目2取得　の場合
        if (MsCnst.COM_GET_VW_FUTAI_RYOKIN_KOMOKU1.equals(listId) || MsCnst.COM_GET_VW_FUTAI_RYOKIN_KOMOKU2.equals(listId)) {
            if (params.get("KBN_KEY") != null) {
                String kbnKey = params.get("KBN_KEY").toString();

                key = listId.concat("_").concat(kbnKey);
            }
        }
        if (firstBean != null) {
            key = listId.concat("_").concat(firstBean.getValue());
        }

        List<AutoCompOptionBean> dataList = searchResultMap.get(key);
        if (dataList != null && value != null && !"".equals(value)) {
            List<AutoCompOptionBean> filterList = dataList.stream()
                    .filter((AutoCompOptionBean bean) -> value.equals(bean.getLabel()))
                    .collect(Collectors.toList());
            if (filterList.size() > 0) {
                return filterList.get(0);
            }
        }
        return null;
    }

    /**
     * DBからAutoCompleteを取得する
     *
     * @param listId SQL文のID
     * @param param SQL文のパラメータ
     * @param firstBean 先頭追加表示内容
     * @return VALUE:LABELのPOJOリスト
     */
    public List<AutoCompOptionBean> getValueLabelFromDB(String listId, Map param, AutoCompOptionBean firstBean) {
        return this.getValueLabelFromDB(listId, param, firstBean, null);
    }

    /**
     * DBからAutoCompleteを取得する
     *
     * @param listId SQL文のID
     * @param param SQL文のパラメータ
     * @param firstBean 先頭追加表示内容
     * @param honshaFlg 本社区分（１：本社、２：営業所、NULL：判断しない）
     * @return VALUE:LABELのPOJOリスト
     */
    public List<AutoCompOptionBean> getValueLabelFromDB(String listId, Map param, AutoCompOptionBean firstBean, String honshaFlg) {

        ServiceInterfaceBean req = new ServiceInterfaceBean();
        List<AutoCompOptionBean> resList = new ArrayList<>();

        req.setFunctionCode(COMMON_GET_CREATE_LIST);

        //parameter
        Map<String, Object> params = new HashMap<>();
        params.put("listId", listId);
        params.put("params", param);
        String requestData = JSONUtil.makeJSONString(params);
        req.setJson(requestData);

        //JAX-RS接続を実行(SQL側のチェック処理など未実装。)
        rest = RestfullService.getInstance();
        ServiceInterfaceBean res = null;
        try {
            res = rest.request(req);
        } catch (Exception ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
            return new ArrayList<>();
        }

        if (res == null || res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return new ArrayList<>();
        }

        Map<String, Object> result;
        try {
            ObjectMapper mapper = new ObjectMapper();
            List searchResult = mapper.readValue(res.getJson(), List.class);
            this.searchResult = searchResult;
            for (Map<String, String> rec : this.searchResult) {
                AutoCompOptionBean labelValue = new AutoCompOptionBean();
                labelValue.setLabel(rec.get("LABEL"));
                labelValue.setValue(rec.get("VALUE"));
                resList.add(labelValue);
            }
        } catch (IOException ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
            return new ArrayList<>();
        }
        if (firstBean != null) {
            resList.add(0, firstBean);
        }
        // 営業所コードの場合
        if ("COM_GET_VW_EIGYOSHO".equals(listId) && !CheckUtils.isEmpty(honshaFlg) && CheckUtils.isEqual("2", honshaFlg)) {
            for (int i = resList.size() - 1; i >= 0; i--) {
                AutoCompOptionBean dto = resList.get(i);
                if (!authConfBean.getLoginUserShozokuEigyosho().contains(dto.getValue()) && dto != firstBean) {
                    resList.remove(dto);
                }
            }
        }
        return resList;
    }

    public String objectToStringOrBlank(Object o) {
        if (o == null) {
            return "";
        }
        return o.toString();
    }
    
    /**
     * AutoComplete選択したLabelを消す
     *
     * @param valueLabel
     * @param label
     */
//    public void autoCompleteTrimLabel(AutoCompOptionBean valueLabel,String label) {
//        label = valueLabel.getLabel();
//        // valueLabel.setLabel("");
//    }
}
