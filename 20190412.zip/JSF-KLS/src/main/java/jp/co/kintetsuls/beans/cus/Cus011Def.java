/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.cus;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 *
 * @author y_kamata
 */
@Data
public class Cus011Def implements Serializable {

    private static final long serialVersionUID = 7013090829426790999L;
    
    public String id;
    public String kokyakuCd;
    public Date tekiyoKaishibi;
    public String kokyakuMei;  
    public String kokyakuKanaMeisho;
    public String jusho;
    public String telBango1;
    public String shinseiStatusCd;
    public String seikyuEigyoshoCd;
    public String hojinGroupCd;
    public String sakujoFlg;
    public String honTorokuShinseiKanoFlg;
    public String actionFlg;        // 0:更新なし 1:登録 2:更新
    public String errFlg;           // 0:エラーなし 1:エラーあり
    public String checkFlg;         // 0:チェックなし 1:チェックあり

}
