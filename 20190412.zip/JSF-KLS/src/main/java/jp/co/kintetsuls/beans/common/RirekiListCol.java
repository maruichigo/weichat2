/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.common;

import java.io.Serializable;
import javax.faces.bean.ViewScoped;
import lombok.Data;

/**
 * 一覧履歴カラ
 * 
 * @author YinMingLong (MBP)
 */
@javax.faces.bean.ManagedBean(name = "rirekilistcol")
@ViewScoped
@Data
public class RirekiListCol implements Serializable {

    private static final long serialVersionUID = 1L;
  
    // 一覧履歴DB物理カラム
    private  String colValue;
    
    // 一覧履歴カラム表示位置
    private  String colAlign;

    // 一覧履歴カラムタイプ (chkb:selectBooleanCheckbox)
    private  String colType;
    
     // 一覧履歴カラムカーラー 
    private  String colColor;
}
