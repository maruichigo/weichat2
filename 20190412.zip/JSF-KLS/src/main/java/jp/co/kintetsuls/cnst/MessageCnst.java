/*
 * Copyright (C) 2014 MBP Corporation All Rights Reserved .
 */
package jp.co.kintetsuls.cnst;

/**
 * メッセージ定数.
 *
 * @author COMM
 * @version 2019/2/22 新規作成
 */
public interface MessageCnst {
    
    /** 設定が完了しました。 **/			
    public static final String MSTI0001 = "MSTI0001";			
    /** 顧客コード({$0})で{$1}を{$2}して下さい。 **/			
    public static final String MSTW0010 = "MSTW0010";			
    /** {$0}を追加して下さい。 **/			
    public static final String MSTW0011 = "MSTW0011";			
    /** フロアの坪数が、倉庫料卸設定一覧の対象フロアの坪数の坪数合計を超えていますが、登録しますか？ **/			
    public static final String MSTW0001 = "MSTW0001";			
    /** 料金表が設定されていません。 **/			
    public static final String MSTW0002 = "MSTW0002";			
    /** 適用開始日に過去日付が入力されていますが、よろしいいですか。 **/			
    public static final String MSTW0003 = "MSTW0003";			
    /** 前月以前の日付が入力されています。登録/更新しますか？ **/			
    public static final String MSTW0004 = "MSTW0004";			
    /** この料金表を使用している顧客コードが{$0}件あります。削除すると料金計算ができなくなります。本当によろしいですか？ **/			
    public static final String MSTW0005 = "MSTW0005";			
    /** 代理店コード：{$0}と、送り状No範囲が重複しています。このまま登録してよろしいですか。 **/			
    public static final String MSTW0006 = "MSTW0006";			
    /** JIS住所（仕向地コード下2桁が00）の{$0}が外れています。このまま登録してよろしいですか。 **/			
    public static final String MSTW0009 = "MSTW0009";			
    /** 同じ{$0}が複写先で使用されています。 **/			
    public static final String MSTE0001 = "MSTE0001";			
    /** 複写元と複写先の{$0}が同一です。 **/			
    public static final String MSTE0002 = "MSTE0002";			
    /** 仕入値は、施設概要の賃料の合計と同じ値を入力してください。 **/			
    public static final String MSTE0003 = "MSTE0003";			
    /** 有効坪数は、施設概要の倉庫坪数の合計と同じ値を入力してください。 **/			
    public static final String MSTE0004 = "MSTE0004";			
    /** フロアが重複しています。 **/			
    public static final String MSTE0005 = "MSTE0005";			
    /** 存在しないフロアが入力されています。 **/			
    public static final String MSTE0006 = "MSTE0006";			
    /** JISコードが重複しています。 **/			
    public static final String MSTE0007 = "MSTE0007";			
    /** 対象のデータは削除できません。 **/			
    public static final String MSTE0008 = "MSTE0008";			
    /** {$0}が存在しません。 **/			
    public static final String MSTE0009 = "MSTE0009";			
    /** 適用されているデータの削除は行えません。 **/			
    public static final String MSTE0010 = "MSTE0010";			
    /** 該当する{$0}がありません。 **/			
    public static final String MSTE0011 = "MSTE0011";			
    /** デフォルト設定されているため、終了状態で登録/更新できません。 **/			
    public static final String MSTE0012 = "MSTE0012";			
    /** デフォルト設定されているため、削除できません。 **/			
    public static final String MSTE0013 = "MSTE0013";			
    /** 重量が重複しています。 **/			
    public static final String MSTE0014 = "MSTE0014";			
    /** 個数が重複しています。 **/			
    public static final String MSTE0015 = "MSTE0015";			
    /** 増分の2件目以降は、1つ前の閾値以下の値を入力することはできません。 **/			
    public static final String MSTE0016 = "MSTE0016";			
    /** 入力された代理店・中継業者の料金表は、既に登録されています。 **/			
    public static final String MSTE0017 = "MSTE0017";			
    /** 仕入先データと紐づく有効な代理店データが存在しません。 **/			
    public static final String MSTE0018 = "MSTE0018";			
    /** 有効な営業所データが存在しません。 **/			
    public static final String MSTE0019 = "MSTE0019";			
    /** 有効な仕入先コードが存在しません。 **/			
    public static final String MSTE0020 = "MSTE0020";			
    /** 送り状マスタ参照を設定している顧客は、{$0}の登録更新はできません。 **/			
    public static final String MSTE0021 = "MSTE0021";			
    /** 所属営業所が異なるため、{$0}の登録更新はできません。 **/			
    public static final String MSTE0022 = "MSTE0022";			
    /** 複写元のデータが選択されていません。 **/			
    public static final String MSTE0023 = "MSTE0023";			
    /** 未入力の重量があります。 **/			
    public static final String MSTE0024 = "MSTE0024";			
    /** {$0}が未入力の行があります。 **/			
    public static final String MSTE0025 = "MSTE0025";			
    /** 重量が重複しています。 **/			
    public static final String MSTE0026 = "MSTE0026";			
    /** 発空港と着空港に同一空港を設定している行があります。 **/			
    public static final String MSTE0027 = "MSTE0027";			
    /** 発空港と着空港の設定が、重複している行があります。 **/			
    public static final String MSTE0028 = "MSTE0028";			
    /** Axisのメッセージを削除することはできません。 **/			
    public static final String MSTE0029 = "MSTE0029";			
    /** 同じJISコード内に適用開始日が異なるデータが存在します。 **/			
    public static final String MSTE0030 = "MSTE0030";			
    /** JISコードと仕向地コード（上5桁）が等しくありません。 **/			
    public static final String MSTE0031 = "MSTE0031";			
    /** 指定されたJISコードは削除済です。 **/			
    public static final String MSTE0032 = "MSTE0032";			
    /** 経費負担額、うち非課税額、消費税(外税)の合計が仕入額と一致ししない行が存在します。 **/			
    public static final String MSTE0033 = "MSTE0033";			
    /** 選択された仕入区分は、既に登録されています。 **/			
    public static final String MSTE0034 = "MSTE0034";			
    /** 送信先区分で個別指定を選択した場合、送信先を1行以上入力してください。 **/			
    public static final String MSTE0035 = "MSTE0035";			
    /** 仕向地コードは、既に使用されています。 **/			
    public static final String MSTE0036 = "MSTE0036";			
    /** {$0}に{$1は仕様できません。 **/			
    public static final String MSTE0037 = "MSTE0037";			
    /** 売上締日は一日のみ設定可能です。 **/			
    public static final String MSTE0038 = "MSTE0038";			
    /** 入金締日は一日のみ設定可能です。 **/			
    public static final String MSTE0039 = "MSTE0039";			
    /** 年月日が重複しています。 **/			
    public static final String MSTE0040 = "MSTE0040";			
    /** 入力されていない日があります。 **/			
    public static final String MSTE0041 = "MSTE0041";			
    /** 入力された表示順は、同一料金項目グループ内で使用されています。 **/			
    public static final String MSTE0042 = "MSTE0042";			
    /** 固定項目の料金項目は削除することができません。 **/			
    public static final String MSTE0043 = "MSTE0043";			
    /** 集約区分が選択されていません。 **/			
    public static final String MSTE0044 = "MSTE0044";			
    /** 集約区分が集約コード（営業所）で営業所が選択されていません。 **/			
    public static final String MSTE0045 = "MSTE0045";			
    /** 集約区分が集約コード（営業所）以外で営業所が選択されています。 **/			
    public static final String MSTE0046 = "MSTE0046";			
    /** 登録しようとした集約コードが存在しています。 **/			
    public static final String MSTE0047 = "MSTE0047";			
    /** 更新しようとした集約コードが存在していません。 **/			
    public static final String MSTE0048 = "MSTE0048";			
    /** 削除しようとした集約コードが存在していません。 **/			
    public static final String MSTE0049 = "MSTE0049";			
    /** 他仕向地コードの変換情報と重複しています。（【{$0}：{$1}】） **/			
    public static final String MSTE0050 = "MSTE0050";			
    /** 他施設名と重複しています。（【{$0}】） **/			
    public static final String MSTE0051 = "MSTE0051";			
    /** 登録されていない{$0}が設定されています。 **/			
    public static final String MSTE0052 = "MSTE0052";			
    /** 入力された料金項目コードのデータは既に存在します。 **/			
    public static final String MSTE0053 = "MSTE0053";			
    /** 処理科目は存在しません。 **/			
    public static final String MSTE0054 = "MSTE0054";			
    /** 補助科目は存在しません。 **/			
    public static final String MSTE0055 = "MSTE0055";			
    /** 卸値率、卸単価のいずれか１項目のみ入力してください。 **/			
    public static final String MSTE0056 = "MSTE0056";			
    /** 入力された車両データは既に存在します。 **/			
    public static final String MSTE0057 = "MSTE0057";			
    /** 終了する場合、適用終了日を入力して下さい。 **/			
    public static final String MSTE0058 = "MSTE0058";			
    /** 終了しない場合、適用終了日を入力することはできません。 **/			
    public static final String MSTE0059 = "MSTE0059";			
    /** 有効な車両NOが存在しません。 **/			
    public static final String MSTE0060 = "MSTE0060";			
    /** 指定した代表コード{$0}には、別の代表コード{$1}{$2}が設定されています。 **/			
    public static final String MSTE0061 = "MSTE0061";			
    /** 代表代理店に送り状Noが設定されていません。 **/			
    public static final String MSTE0062 = "MSTE0062";			
    /** 代表代理店ではない場合、代表コードは必須項目です。 **/			
    public static final String MSTE0063 = "MSTE0063";			
    /** 送り状No範囲が重複しています。 **/			
    public static final String MSTE0064 = "MSTE0064";			
    /** 代理店コード：{$0}と、送り状No範囲が重複しています。 **/			
    public static final String MSTE0065 = "MSTE0065";			
    /** 使用区分に代理店が設定されていない仕入先は、設定不可です。 **/			
    public static final String MSTE0066 = "MSTE0066";			
    /** 承認待ちのデータである為、使用できません。 **/			
    public static final String MSTE0067 = "MSTE0067";			
    /** 代表コードが設定されていないため、会社単位の設定は不可能です。 **/			
    public static final String MSTE0068 = "MSTE0068";			
    /** 卸種別区分が卸値なしの場合、単価がブランクもしくは0以外は登録できません。 **/			
    public static final String MSTE0069 = "MSTE0069";			
    /** 入力された拠点間卸値は既に存在します。 **/			
    public static final String MSTE0070 = "MSTE0070";			
    /** 入力された拠点間卸値が存在しません。 **/			
    public static final String MSTE0071 = "MSTE0071";			
    /** 有効な拠点間卸値が存在しません。 **/			
    public static final String MSTE0072 = "MSTE0072";			
    /** 削除する拠点間卸値がルートマスタの発地、経由地、着地に存在するため削除出来ません。 **/			
    public static final String MSTE0073 = "MSTE0073";			
    /** 優先順位が重複しています。 **/			
    public static final String MSTE0074 = "MSTE0074";			
    /** 入力された発地・着地・経由地は既に存在します。 **/			
    public static final String MSTE0075 = "MSTE0075";			
    /** 入力されたルートが拠点間卸値マスタに存在しません。 **/			
    public static final String MSTE0076 = "MSTE0076";			
    /** 入力されたロールは存在しません。 **/			
    public static final String MSTE0077 = "MSTE0077";			
    /** 入力された機能グループは存在しません。 **/			
    public static final String MSTE0078 = "MSTE0078";			
    /** 入力された機能グループ種別は存在しません。 **/			
    public static final String MSTE0079 = "MSTE0079";			
    /** ロールと機能グループの紐付けが重複しています。 **/			
    public static final String MSTE0080 = "MSTE0080";			
    /** ロールと機能グループの紐付けが存在しません。 **/			
    public static final String MSTE0081 = "MSTE0081";			
    /** 該当のデータは既に登録されています。別のコードを指定してください。 **/			
    public static final String MSTE0082 = "MSTE0082";			
    /** 該当のロールは、ユーザによって使用されています。 **/			
    public static final String MSTE0083 = "MSTE0083";			
    /** 該当のロールは、機能グループとの関連付けが行われています。 **/			
    public static final String MSTE0084 = "MSTE0084";			
    /** 入力されたK-INGコード変換情報は既に存在します。 **/			
    public static final String MSTE0085 = "MSTE0085";			
    /** 入力されたK-INGコード変換情報が存在しません。 **/			
    public static final String MSTE0086 = "MSTE0086";			
    /** 営業所コードが存在しません。 **/			
    public static final String MSTE0087 = "MSTE0087";			
    /** 該当のデータは既に登録されています。 **/			
    public static final String MSTE0088 = "MSTE0088";			
    /** 該当のデータが存在しません。 **/			
    public static final String MSTE0089 = "MSTE0089";			
    /** 入力されたユーザは営業所に所属していません。 **/			
    public static final String MSTE0090 = "MSTE0090";			
    /** 入力されたユーザは所属期間外です。 **/			
    public static final String MSTE0091 = "MSTE0091";			
    /** 所属完了まで1か月のユーザが設定されています。登録を行いますか？ **/			
    public static final String MSTE0092 = "MSTE0092";			
    /** 行が選択されていません。 **/			
    public static final String MSTE0093 = "MSTE0093";			
    /** デフォルト所属は一か所のみ設定可能です。 **/			
    public static final String MSTE0094 = "MSTE0094";			
    /** 申請が必要な項目が編集されています。 **/			
    public static final String MSTE0095 = "MSTE0095";			
    /** 申請が不要な項目が編集されています。 **/			
    public static final String MSTE0096 = "MSTE0096";			
    /** 営業所と顧客の組み合わせが存在しません。 **/			
    public static final String MSTE0097 = "MSTE0097";			
    /** 営業所コード、顧客コード、品名コードの組み合わせは既に登録済みです。 **/			
    public static final String MSTE0098 = "MSTE0098";			
    /** 営業所コード、顧客コード、品名コードの組み合わせが登録されていません。 **/			
    public static final String MSTE0099 = "MSTE0099";			
    /** 営業所コード、顧客コード、記事コードの組み合わせは既に登録済みです。 **/			
    public static final String MSTE0100 = "MSTE0100";			
    /** 営業所コード、顧客コード、記事コードの組み合わせが登録されていません。 **/			
    public static final String MSTE0101 = "MSTE0101";			
    /** 過去の日付が設定されています。 **/			
    public static final String MSTE0102 = "MSTE0102";			
    /** {$0}を新規追加します。よろしいですか？ **/			
    public static final String MSTE0103 = "MSTE0103";			
    /** 住所が20文字を超えました。{$0} **/			
    public static final String MSTE0104 = "MSTE0104";			
    /** 該当のデータは既に登録されています。別のコード、または別の適用開始日を指定してください。 **/			
    public static final String MSTE0106 = "MSTE0106";			
    /** 伝票種別を選択した場合、いずれかの卸に設定を行ってください。 **/			
    public static final String MSTE0107 = "MSTE0107";			
    /** 顧客マスタにて{$0}が登録されていません。 **/			
    public static final String MSTE0108 = "MSTE0108";			
    /** 削除しようとした{0}が存在していません。 **/			
    public static final String MSTE0109 = "MSTE0109";			
    /** {0}は適用終了しています。 **/			
    public static final String MSTE0110 = "MSTE0110";			
    /** 仕向地コード下2桁に、99は使用できません。 **/			
    public static final String MSTE0111 = "MSTE0111";
    /** 申請が必要な項目は編集されていません。 **/
    public static final String MSTE0112 = "MSTE0112";
    /** 未承認のカレンダーデータが存在します。承認を行ってください。 **/
    public static final String MSTE0113 = "MSTE0113";
    /** ワンタイムパスワードを発行しました。連絡先担当者への連絡を行ってください。 **/			
    public static final String LGNI0001 = "LGNI0001";			
    /** ワンタイムパスワード発行のお知らせ **/			
    public static final String LGNI0002 = "LGNI0002";			
    /** パスワード初期化処理が行われました。下記のURLからパスワード変更を行ってください。{$0} **/			
    public static final String LGNI0003 = "LGNI0003";			
    /** 本人連絡済ステータスの更新を行いました。 **/			
    public static final String LGNI0004 = "LGNI0004";			
    /** ブラウザのブックマーク機能をご利用ください。 CtrlボタンとDボタン同時押しでブックマークに追加できます。 **/			
    public static final String LGNI0005 = "LGNI0005";			
    /** コメントが記入されていませんが登録を行いますか？ **/			
    public static final String LGNW0001 = "LGNW0001";			
    /** 新しいパスワードと新しいパスワード(確認)の内容が異なっています。 **/			
    public static final String LGNE0001 = "LGNE0001";			
    /** 設定されているパスワードと異なっています。 **/			
    public static final String LGNE0002 = "LGNE0002";			
    /** 一定回数パスワードの誤入力が発生しました。再度ログインを行ってください。 **/			
    public static final String LGNE0003 = "LGNE0003";			
    /** パスワードポリシーを満たしていません。 **/			
    public static final String LGNE0004 = "LGNE0004";			
    /** メール申請ロック期間内である為、申請できません。 **/			
    public static final String LGNE0005 = "LGNE0005";			
    /** 一定回数メールアドレスの誤入力が発生した為、メール申請をロックしました。 **/			
    public static final String LGNE0006 = "LGNE0006";			
    /** 登録されているメールアドレスの内容と一致しません。 **/			
    public static final String LGNE0007 = "LGNE0007";			
    /** 通知方法が選択されていません。メールか電話のどちらかを選択してください。 **/			
    public static final String LGNE0008 = "LGNE0008";			
    /** ユーザーコード、パスワードの組み合わせに誤りがある為、ログインに失敗しました。 **/			
    public static final String LGNE0009 = "LGNE0009";			
    /** 仕入入力確定済のデータです。 **/			
    public static final String STCW0001 = "STCW0001";			
    /** 経費負担額、うち非課税額、消費税(外税)の合計が仕入額と一致しない行が存在します。処理を継続しますか？ **/			
    public static final String STCW0002 = "STCW0002";			
    /** 請求経費負担額、うち非課税額（請求）、請求消費税(外税)の合計が請求支払額と一致しない行が存在します。処理を継続しますか？ **/			
    public static final String STCW0003 = "STCW0003";			
    /** 対象の営業所は仕入入力確定されているため、変更できません。仕入支払額一覧画面にて変更を行ってください。 **/			
    public static final String STCE0001 = "STCE0001";			
    /** 仕入詳細画面以外で登録されたデータが含まれているため、削除できません。 **/			
    public static final String STCE0002 = "STCE0002";			
    /** 現在の日時が仕入入力確定可能日を超えているため、仕入確定できません。 **/			
    public static final String STCE0003 = "STCE0003";			
    /** 仕入区分が{$0}の場合、{$1}は必須項目です。 **/			
    public static final String STCE0004 = "STCE0004";			
    /** {$0}、{$1}は当月日付を入力してください。 **/			
    public static final String STCE0005 = "STCE0005";			
    /** {$0}確定済みのため、更新できません。 **/			
    public static final String STCE0006 = "STCE0006";			
    /** 現在の日時が支払額確定可能日を超えているため、支払額確定できません。 **/			
    public static final String STCE0007 = "STCE0007";			
    /** 選択された営業所の経理支払額{$0}が未確定のため、出力できません。 **/			
    public static final String STCE0008 = "STCE0008";			
    /** 選択された営業所のデータは既に出力済みです。 **/			
    public static final String STCE0009 = "STCE0009";			
    /** 選択された営業所のデータは出力されていません。先に出力処理を行ってください。 **/			
    public static final String STCE0010 = "STCE0010";			
    /** 運賃一括再計算処理が終了しました。 **/			
    public static final String PROI0001 = "PROI0001";			
    /** この請求を再締するには締解除が必要です。締解除せずに修正した場合、翌請求分に赤黒が載りますがよろしいですか？ **/			
    public static final String PROI0002 = "PROI0002";			
    /** 登録後の処理を選択してください。 **/			
    public static final String PROI0003 = "PROI0003";			
    /** 選択された料金項目のみ表示しています。 **/			
    public static final String PROI0004 = "PROI0004";			
    /** ※明細単位の計算では小数点以下が四捨五入されるため、明細合計と実際の請求金額が異なる場合があります。 **/			
    public static final String PROI0005 = "PROI0005";			
    /** 対象の{$0}を削除します。よろしいですか？ **/			
    public static final String PROI0006 = "PROI0006";			
    /** この請求を再締するには締解除が必要です。締解除せずに修正した場合、翌請求分に赤黒が載ります。 **/			
    public static final String PROW0001 = "PROW0001";			
    /** 再締めが完了していません。請求書の詳細画面で再締めしますか？ **/			
    public static final String PROW0002 = "PROW0002";			
    /** 最大値を超えている請求項目があります。最大値を適用してもよろしいでしょうか？ **/			
    public static final String PROW0003 = "PROW0003";			
    /** 最低値を下回る請求項目があります。最低値を適用してもよろしいでしょうか？ **/			
    public static final String PROW0004 = "PROW0004";			
    /** {$0}設定を{$1}回っているため設定値で計算しています。(入力値:{$2}) **/			
    public static final String PROW0005 = "PROW0005";			
    /** 再締めが必要です。 **/			
    public static final String PROW0006 = "PROW0006";			
    /** 請求が回収済みの為、翌月赤黒しかできません。翌月赤黒を実行しますか？ **/			
    public static final String PROW0007 = "PROW0007";			
    /** {$0}の登録が完了していません。このまま表示を切り替えますか？ **/			
    public static final String PROW0008 = "PROW0008";			
    /** 実績日付指定時、日付指定は必須入力です。 **/			
    public static final String PROE0001 = "PROE0001";			
    /** 選択内容に誤りがあります。 **/			
    public static final String PROE0002 = "PROE0002";			
    /** この請求は訂正期限が過ぎている為、訂正できません。 **/			
    public static final String PROE0003 = "PROE0003";			
    /** この請求は回収済みの為、訂正できません。 **/			
    public static final String PROE0004 = "PROE0004";			
    /** 卸値の計算単位の設定が正しくありません。 **/			
    public static final String PROE0005 = "PROE0005";			
    /** スポット追加分以外を削除することはできません。 **/			
    public static final String PROE0006 = "PROE0006";			
    /** 明細データが入力済みのため削除することができません。明細入力画面で売上を削除してください。 **/			
    public static final String PROE0007 = "PROE0007";			
    /** 選択された項目は、スポット追加が許可されていません。 **/			
    public static final String PROE0008 = "PROE0008";			
    /** 請求ロック中のため、売上データを操作することはできません。 **/			
    public static final String PROE0009 = "PROE0009";			
    /** データ元が空以外の行を削除するには、申請が必要です。 **/			
    public static final String PROE0010 = "PROE0010";			
    /** データ元が空の行では、削除申請は不要です。 **/			
    public static final String PROE0011 = "PROE0011";			
    /** スキャンデータの未確定が0件の為、確定できません **/			
    public static final String PROE0012 = "PROE0012";			
    /** スキャンデータの要修正が1件以上残っている為、確定できません。 **/			
    public static final String PROE0013 = "PROE0013";			
    /** {$0}のイメージは削除出来ません。 **/			
    public static final String PROE0014 = "PROE0014";			
    /** 売上入力済のため、売上入力不要に出来ません。 **/			
    public static final String PROE0015 = "PROE0015";			
    /** 切替先の画像が存在しません。 **/			
    public static final String PROE0016 = "PROE0016";			
    /** 小口送り状Noを更新します。よろしいですか？ **/			
    public static final String MWBI0001 = "MWBI0001";			
    /** {$0}のToの値にFromの値よりも小さな数値が指定されています。 **/			
    public static final String MWBE0001 = "MWBE0001";			
    /** 該当する{$0}がありません。 **/			
    public static final String MWBE0002 = "MWBE0002";			
    /** 使用済のMAWB番号が指定されています。 **/			
    public static final String MWBE0003 = "MWBE0003";			
    /** {$0}済のMAWB番号が指定されています。 **/			
    public static final String MWBE0004 = "MWBE0004";			
    /** 指定されたMAWB番号が現在のMAWB番号の範囲外のため、{$0}できません。 **/			
    public static final String MWBE0005 = "MWBE0005";			
    /** 配布先営業所に変更がありません。 **/			
    public static final String MWBE0006 = "MWBE0006";			
    /** 指定されたMAWB番号は配布されていません。 **/			
    public static final String MWBE0007 = "MWBE0007";			
    /** 航空会社とMAWB番号の組み合わせが正しくありません。 **/			
    public static final String MWBE0008 = "MWBE0008";			
    /** 検索結果が表示されていません。検索を実施してください。 **/			
    public static final String MWBE0009 = "MWBE0009";			
    /** 入力された送り状Noが、存在していません。 **/			
    public static final String MWBE0010 = "MWBE0010";			
    /** 変更されたデータがありません。 **/			
    public static final String MWBE0011 = "MWBE0011";			
    /** 指定された{$0}MAWB番号はMAWB番号の範囲と異なるため、{$1}できません。 **/			
    public static final String MWBE0012 = "MWBE0012";			
    /** 回収予定金額はXXX,XXX円です。再確認してください。 **/			
    public static final String CASE0001 = "CASE0001";			
    /** 入力した送り状Noは他担当の送り状Noです。再確認してください。 **/			
    public static final String CASE0002 = "CASE0002";			
    /** 申請処理が完了しました。 **/			
    public static final String DEMI0001 = "DEMI0001";			
    /** 承認処理が完了しました。 **/			
    public static final String DEMI0002 = "DEMI0002";			
    /** 差戻し処理が完了しました。 **/			
    public static final String DEMI0003 = "DEMI0003";			
    /** コメント登録が完了しました。 **/			
    public static final String DEMI0004 = "DEMI0004";			
    /** 承認プロセスが1件も設定されていません。 **/			
    public static final String DEME0001 = "DEME0001";			
    /** 承認プロセス間に未入力データがあります。 **/			
    public static final String DEME0002 = "DEME0002";			
    /** 既に適用されているデータの編集は行えません。 **/			
    public static final String DEME0003 = "DEME0003";			
    /** 簡易見積り計算が完了しました。 **/			
    public static final String ESTI0001 = "ESTI0001";			
    /** 運賃計算パターンを変更します。よろしいでしょうか？ **/			
    public static final String ESTW0003 = "ESTW0003";			
    /** {$0}では{$1}と{$2}を組み合わせて使用できません。 **/			
    public static final String ESTW0001 = "ESTW0001";			
    /** 一時保存されている料金表があります。 **/			
    public static final String ESTW0002 = "ESTW0002";			
    /** まだ保存されていません。保存してからやり直してください。 **/			
    public static final String ESTE0020 = "ESTE0020";			
    /** 設定可能な過去日を超えています。 **/			
    public static final String ESTE0021 = "ESTE0021";			
    /** いずれかの検索条件を指定してください。 **/			
    public static final String ESTE0022 = "ESTE0022";			
    /** 同一の見積種類は1つだけしか選択できません。 **/			
    public static final String ESTE0023 = "ESTE0023";			
    /** 運賃ランクが設定されていません。 **/			
    public static final String ESTE0024 = "ESTE0024";			
    /** 着地域が設定されていません。 **/			
    public static final String ESTE0025 = "ESTE0025";			
    /** 見積りステータスの組合せが不正です。 **/			
    public static final String ESTE0001 = "ESTE0001";			
    /** 該当する料金表が存在しません。 **/			
    public static final String ESTE0002 = "ESTE0002";			
    /** 運賃計算に失敗しました。 **/			
    public static final String ESTE0003 = "ESTE0003";			
    /** 建値・個数は小さい順に指定してください。 **/			
    public static final String ESTE0004 = "ESTE0004";			
    /** 建値・個数には、「/Kg」は指定できません。 **/			
    public static final String ESTE0005 = "ESTE0005";			
    /** 「増し」は小さい順に指定してください。 **/			
    public static final String ESTE0006 = "ESTE0006";			
    /** 建値・重量は小さい順に指定してください。 **/			
    public static final String ESTE0007 = "ESTE0007";			
    /** 「増し」「/Kg」は小さい順に指定してください。 **/			
    public static final String ESTE0008 = "ESTE0008";			
    /** 「増し」「/Kg」は同時に両方指定することはできません。 **/			
    public static final String ESTE0009 = "ESTE0009";			
    /** 発地域／着地域に同じ地域が指定されていません。 **/			
    public static final String ESTE0010 = "ESTE0010";			
    /** 備考の入力文字数が最大値を超えました。 **/			
    public static final String ESTE0011 = "ESTE0011";			
    /** 適用開始日は{$0}ヶ月前より過去日は指定できません。 **/			
    public static final String ESTE0012 = "ESTE0012";			
    /** {$0}の前に、画面にて編集中の見積りを保存してください。 **/			
    public static final String ESTE0013 = "ESTE0013";			
    /** ステータスが「作成中」の見積り以外は削除できません。 **/			
    public static final String ESTE0014 = "ESTE0014";			
    /** 「{$0}」を同時に選択できません。 **/			
    public static final String ESTE0015 = "ESTE0015";			
    /** ステータスが「作成中」または「見積り提案承認済」の見積り以外は提案申請できません。 **/			
    public static final String ESTE0016 = "ESTE0016";			
    /** 値引額・割引率には、「0」は入力できません。 **/			
    public static final String ESTE0017 = "ESTE0017";			
    /** 顧客別集荷料金表が未登録です。 **/			
    public static final String ESTE0018 = "ESTE0018";			
    /** 「増し」が設定されていません。 **/			
    public static final String ESTE0019 = "ESTE0019";			
    /** 建値・距離は小さい順に指定してください。 **/			
    public static final String ESTE0026 = "ESTE0026";			
    /** 建値・時間は小さい順に指定してください。 **/			
    public static final String ESTE0027 = "ESTE0027";			
    /** ロック中の請求書以外を出力しました。 **/			
    public static final String BILI0001 = "BILI0001";			
    /** 運賃未確定データが{$0}件あります。 **/			
    public static final String BILI0002 = "BILI0002";			
    /** 運賃未確定があります。 **/			
    public static final String BILI0003 = "BILI0003";			
    /** ロジ売上の日割り計算は行いません。 **/			
    public static final String BILI0004 = "BILI0004";			
    /** 再締が完了しました。請求書NO：{$0} **/			
    public static final String BILI0005 = "BILI0005";			
    /** 特別締めが完了しました。 **/			
    public static final String BILI0006 = "BILI0006";			
    /** 請求書の詳細画面で再度チェックしてください。請求書NO：{$0} **/			
    public static final String BILI0007 = "BILI0007";			
    /** 請求書出力請求先ではありません。請求書出力請求先で再度検索しますか？ **/			
    public static final String BILW0001 = "BILW0001";			
    /** 検索結果に通常締と決算締で日付が異なる請求書が含まれています。 **/			
    public static final String BILW0002 = "BILW0002";			
    /** エラーの請求書があります。確認してください。 **/			
    public static final String BILW0003 = "BILW0003";			
    /** 運賃未確定のデータがありますがよろしいですか? **/			
    public static final String BILW0004 = "BILW0004";			
    /** ロック中の請求書は対象外になります。 **/			
    public static final String BILW0005 = "BILW0005";			
    /** 対象の請求データが{$0}によりロックされています。 **/			
    public static final String BILW0006 = "BILW0006";			
    /** 対象の請求データが{$0}により印刷中です。 **/			
    public static final String BILW0007 = "BILW0007";			
    /** 請求金額の合計がマイナスです。 **/			
    public static final String BILW0008 = "BILW0008";			
    /** 未チェック状態に戻しますがよろしいですか? **/			
    public static final String BILW0009 = "BILW0009";			
    /** 検索条件にメイン以外の検索条件が存在します。実行してもよいですか? **/			
    public static final String BILW0010 = "BILW0010";			
    /** 請求書ロック中データが選択されています。実行してもよいですか? **/			
    public static final String BILW0011 = "BILW0011";			
    /** 再締めモレの請求があります。 **/			
    public static final String BILW0012 = "BILW0012";			
    /** この請求はロックされています。 **/			
    public static final String BILW0013 = "BILW0013";			
    /** 特別締めを行う場合「今すぐ発行」を選択してください **/			
    public static final String BILW0014 = "BILW0014";			
    /** 「未印刷」は「請求書未チェック」、「印刷済」、「Web請求対象」と混在しての印刷は行えません。 **/			
    public static final String BILE0001 = "BILE0001";			
    /** 請求情報のないデータが選択されています。 **/			
    public static final String BILE0002 = "BILE0002";			
    /** 選択した請求が全てロックされています。 **/			
    public static final String BILE0003 = "BILE0003";			
    /** 請求書が未作成のため表示できません **/			
    public static final String BILE0004 = "BILE0004";			
    /** {$0}によりロック中のため印刷を中止しました。 **/			
    public static final String BILE0005 = "BILE0005";			
    /** 選択した請求書は分割できないため印刷を中止します。 **/			
    public static final String BILE0006 = "BILE0006";			
    /** 既に入金が行われているため変更できません。 **/			
    public static final String BILE0007 = "BILE0007";			
    /** 請求ロックが行われているため入金方法を変更できません。 **/			
    public static final String BILE0008 = "BILE0008";			
    /** 請求対象となる売上がありません。 **/			
    public static final String BILE0009 = "BILE0009";			
    /** ロジ売上を検索できる期間を超えています。 **/			
    public static final String BILE0010 = "BILE0010";			
    /** 請求書{$0}の入金予定日が重複しています。 **/			
    public static final String BILE0011 = "BILE0011";			
    /** 請求が選択されていないため出力できません **/			
    public static final String BILE0012 = "BILE0012";			
    /** 再締め対象の請求ではありません。 **/			
    public static final String BILE0013 = "BILE0013";			
    /** 請求書が印刷中のため、再締めができません。 **/			
    public static final String BILE0014 = "BILE0014";			
    /** {$0}年{$1}月{$2}日締日の請求書は作成されていません。 **/			
    public static final String BILE0015 = "BILE0015";			
    /** 請求書の詳細画面で再度チェックしてください。{$0} **/			
    public static final String BILE0016 = "BILE0016";			
    /** 請求データ作成バッチにて処理エラーが発生しました。{$0}{$1} **/			
    public static final String BILE0017 = "BILE0017";			
    /** 複数の入金IDが検索されました。検索条件の絞り込みもしくは入金一覧画面で入金IDを特定してください。 **/			
    public static final String BILE0018 = "BILE0018";			
    /** 入金日が当月以外の入金IDが検索されました。検索条件の絞り込みもしくは入金一覧画面で入金IDを特定してください。 **/			
    public static final String BILE0019 = "BILE0019";			
    /** 入金日が当月以外の入金IDは削除できません。 **/			
    public static final String BILE0020 = "BILE0020";			
    /** 銀行コード:{$0} 支店コード:{$1} 口座種別コード:{$2} 口座番号:{$3} はマスタ未登録です。 **/			
    public static final String BILE0021 = "BILE0021";			
    /** 取引科目コード:{$0} はマスタ未登録です。 **/			
    public static final String BILE0022 = "BILE0022";			
    /** 入金科目コード１:{$0} はマスタ未登録です。 **/			
    public static final String BILE0023 = "BILE0023";			
    /** 入金科目コード２:{$0} はマスタ未登録です。 **/			
    public static final String BILE0024 = "BILE0024";			
    /** 消込ID:{$0}の貸方が存在しない、または借方と貸方の金額が一致しません。 **/			
    public static final String BILE0025 = "BILE0025";			
    /** 入金取消対象のファイルが選択されていません。いずれかを選択してください。 **/			
    public static final String BILE0026 = "BILE0026";			
    /** 月を跨いでいない請求書が選択されています。当月の請求書は削除処理で入金削除してください。 **/			
    public static final String BILE0027 = "BILE0027";			
    /** 回収済請求書が検索されていません。 **/			
    public static final String BILE0028 = "BILE0028";			
    /** 予約可能な期間({$0} 日)を超えています。 **/			
    public static final String BILE0029 = "BILE0029";			
    /** 入力された請求Noの請求は存在しません。 **/			
    public static final String BILE0030 = "BILE0030";			
    /** 借方 金額 ＞ 貸方 金額 となっています。借方 金額 ≦ 貸方 金額となる様に指定してください。 **/			
    public static final String BILE0031 = "BILE0031";			
    /** 要求締日が基準日の設定可能制約を超えています。 **/			
    public static final String BILE0032 = "BILE0032";			
    /** 実績が存在しないため、日報を出力することができません。 **/			
    public static final String CARE0001 = "CARE0001";			
    /** 引渡日が空欄の場合、初回出力時の日時で再出力されます。 **/			
    public static final String TRMI0001 = "TRMI0001";			
    /** 配達完了トレースが重複しています。 **/			
    public static final String TRMW0001 = "TRMW0001";			
    /** 送り状NO、お客様管理NOは、どちらか必須です。 **/			
    public static final String TRME0001 = "TRME0001";			
    /** データは既に登録されています。データを削除してから登録を行ってください。 **/			
    public static final String TRME0002 = "TRME0002";			
    /** マニフェスト発行有無は「未発行」「発行済」のどちらかはチェックを入れてください。 **/			
    public static final String TRME0003 = "TRME0003";			
    /** 発行済のデータが含まれていますので、再検索してください。 **/			
    public static final String TRME0004 = "TRME0004";			
    /** マニフェストは「未発行」「発行済」を同時に出力できません。 **/			
    public static final String TRME0005 = "TRME0005";			
    /** 入力したデータに同じデータが複数存在します。 **/			
    public static final String TRME0006 = "TRME0006";			
    /** {$0}を選択していない場合は{$1}を入力しないでください。 **/			
    public static final String TRME0007 = "TRME0007";			
    /** {$0}を選択している場合は{$1}を入力してください。 **/			
    public static final String TRME0008 = "TRME0008";			
    /** 前回と同じ送り状Noで発行されます。再発行を行いますか。 **/			
    public static final String INVW0001 = "INVW0001";			
    /** {$0}の日付を指定する場合は、{$1}に「あり」を選択してください。 **/			
    public static final String INVE0001 = "INVE0001";			
    /** 荷札発行の場合、{$0}は必須項目です。  **/			
    public static final String INVE0002 = "INVE0002";			
    /** 送り状発行、荷札発行のチェックボックスは、どちらか必須です。 **/			
    public static final String INVE0003 = "INVE0003";			
    /** 発行済の{$0}を再度発行することはできません。同一内容で新たに送り状NOを採番して発行する場合は、複製登録を行ってください。 **/		
    public static final String INVE0004 = "INVE0004";			
    /** 送り状未発行時は、荷札を発行することはできません。 **/			
    public static final String INVE0005 = "INVE0005";			
    /** 発行済の送り状発行情報を削除することはできません。 **/			
    public static final String INVE0006 = "INVE0006";			
    /** 発行営業所が自営業所ではない場合、送り状・荷札を発行することはできません。 **/			
    public static final String INVE0007 = "INVE0007";			
    /** 発行対象に{$0}未発行のデータが含まれているため、{$0}を発行することはできません。 **/			
    public static final String INVE0008 = "INVE0008";			
    /** 要求営業所が自営業所ではない場合、送り状発行情報を削除することはできません。 **/			
    public static final String INVE0009 = "INVE0009";			
    /** 登録区分が「取込」または「取込後変更」の場合は複数行選択することはできません。 **/			
    public static final String INVE0010 = "INVE0010";			
    /** 引取の場合、先に担当営業所を入力してください。 **/			
    public static final String INVE0011 = "INVE0011";			
    /** 送り状マスタ参照を設定している顧客は、{$0}マスタの登録更新はできません。 **/			
    public static final String INVE0012 = "INVE0012";			
    /** 引取の場合、{$0}を行うことはできません。 **/			
    public static final String INVE0013 = "INVE0013";			
    /** 送り状NOのFROM～TOには、同一顧客の送り状NOを指定してください。 **/			
    public static final String INVE0014 = "INVE0014";			
    /** 出力対象に送り状が含まれる場合、送り状NOは枝番なしで指定してください。 **/			
    public static final String INVE0015 = "INVE0015";			
    /** 送り状NOのFROMを{$0}で指定した場合、TOも{$0}で指定してください。 **/			
    public static final String INVE0016 = "INVE0016";			
    /** 枝番を指定する場合、異なる送り状NOで発行することはできません。 **/			
    public static final String INVE0017 = "INVE0017";			
    /** 送り状NOのFROM～TOは、逆転して入力することはできません。 **/			
    public static final String INVE0018 = "INVE0018";			
    /** 送り状NOのFROM～TOは、{$0}～{$1}で指定してください。 **/			
    public static final String INVE0019 = "INVE0019";			
    /** 送り状NOのFROM～TOは、{$0}～{$1}または{$2}～{$3}で指定してください。 **/			
    public static final String INVE0020 = "INVE0020";			
    /** 発行対象に存在しない送り状NOが含まれているため、送り状・荷札を発行することはできません。 **/			
    public static final String INVE0021 = "INVE0021";			
    /** 申請が必要となりますがよろしいですか？ **/			
    public static final String CUSI0001 = "CUSI0001";			
    /** とりまとめ請求の明細に設定されていますがよろしいですか？ **/			
    public static final String CUSI0002 = "CUSI0002";			
    /** 他の顧客から請求先に指定されていますがよろしいですか？ **/			
    public static final String CUSI0003 = "CUSI0003";			
    /** 他の顧客から契約先に指定されていますがよろしいですか？ **/			
    public static final String CUSI0004 = "CUSI0004";			
    /** 顧客ステータスが混在しています。 **/			
    public static final String CUSE0001 = "CUSE0001";			
    /** 選択された顧客で申請IDが複数に分かれています。 **/			
    public static final String CUSE0002 = "CUSE0002";			
    /** 顧客の一括変更は営業所毎に行なってください。 **/			
    public static final String CUSE0003 = "CUSE0003";			
    /** 請求営業所と担当営業所で別々の営業所が設定されています。 **/			
    public static final String CUSE0004 = "CUSE0004";			
    /** 選択解除した伝票種別は料金表で使用されています。 **/			
    public static final String CUSE0005 = "CUSE0005";			
    /** 担当営業所が変更されたので集約コード（営業所毎）の再設定が必要です。 **/			
    public static final String CUSE0006 = "CUSE0006";			
    /** とりまとめ請求の親と子で{$0}が異なります。 **/			
    public static final String CUSE0007 = "CUSE0007";			
    /** 入力された法人番号は他の顧客で設定されています。 **/			
    public static final String CUSE0008 = "CUSE0008";			
    /** とりまとめられた請求{$0}は適用開始日以降で締められています。 **/			
    public static final String CUSE0009 = "CUSE0009";			
    /** アドレスが入力されていませんが、登録を行いますか？ **/			
    public static final String EDIW0001 = "EDIW0001";			
    /** パスワード強度が"Weak"ですが、登録を行いますか？ **/			
    public static final String EDIW0002 = "EDIW0002";			
    /** 代表となる顧客を一つ選択してください。 **/			
    public static final String EDIE0001 = "EDIE0001";			
    /** メールを送信するタイミングを最低一つ選択してください。 **/			
    public static final String EDIE0002 = "EDIE0002";			
    /** 送信対象となるトレースを最低一つ選択してください。 **/			
    public static final String EDIE0003 = "EDIE0003";			
    /** {$0}します。よろしいですか？ **/			
    public static final String COMI0012 = "COMI0012";			
    /** {$0}を開始しました。 **/			
    public static final String COMI0013 = "COMI0013";			
    /** {$0}を終了しました。 **/			
    public static final String COMI0014 = "COMI0014";			
    /** 新JISに置き換えた際に40バイトを超えました。そのため、40バイトをはみ出した旧住所の{$0}は削除されました。 **/			
    public static final String COMI0015 = "COMI0015";			
    /** 新JISの漢字が40バイトを超えたため、住所２から40バイトをはみ出した旧住所２の{$0}は削除されました。 **/			
    public static final String COMI0016 = "COMI0016";			
    /** 検索が完了しました。（{$0}件） **/			
    public static final String COMI0001 = "COMI0001";			
    /** 登録が完了しました。{$0} **/			
    public static final String COMI0002 = "COMI0002";			
    /** 登録します。よろしいですか？ **/			
    public static final String COMI0003 = "COMI0003";			
    /** 削除が完了しました。{$0} **/			
    public static final String COMI0004 = "COMI0004";			
    /** ファイルダウンロードが完了しました。{$0} **/			
    public static final String COMI0005 = "COMI0005";			
    /** 印刷が完了しました。{$0} **/			
    public static final String COMI0006 = "COMI0006";			
    /** 更新が完了しました。{$0} **/			
    public static final String COMI0007 = "COMI0007";			
    /** 選択行の明細を全て削除しますが、よろしいですか。 **/			
    public static final String COMI0008 = "COMI0008";			
    /** ファイルアップロードが完了しました。{$0} **/			
    public static final String COMI0009 = "COMI0009";			
    /** 出力が完了しました。{$0} **/			
    public static final String COMI0010 = "COMI0010";			
    /** {$0}が完了しました。 **/			
    public static final String COMI0011 = "COMI0011";			
    /** 履歴データが存在しません。 **/			
    public static final String COMW0009 = "COMW0009";			
    /** 変更内容が反映されていません。移動しますか？ **/			
    public static final String COMW0010 = "COMW0010";			
    /** 該当のデータがありませんでした。 **/			
    public static final String COMW0011 = "COMW0011";			
    /** 検索結果がありませんでした。 **/			
    public static final String COMW0001 = "COMW0001";			
    /** 検索件数が上限を超えました。 **/			
    public static final String COMW0002 = "COMW0002";			
    /** {$0}は現在ロック中の為、入力編集不可の参照モードで起動します。 **/			
    public static final String COMW0003 = "COMW0003";			
    /** 旧住所が設定されています。そのまま{$0}してよろしいですか？ **/			
    public static final String COMW0004 = "COMW0004";			
    /** {$0}を破棄します。よろしいですか？ **/			
    public static final String COMW0005 = "COMW0005";			
    /** データの登録が完了していません。このまま遷移しますか？ **/			
    public static final String COMW0006 = "COMW0006";			
    /** 旧住所が選択されました。確認してください。 **/			
    public static final String COMW0007 = "COMW0007";			
    /** 入力中の内容が破棄されますが、よろしいですか？ **/			
    public static final String COMW0008 = "COMW0008";			
    /** {$0}は{$1}桁で入力してください。 **/			
    public static final String COME0001 = "COME0001";			
    /** {$0}は{$1}桁以内で入力してください。  **/			
    public static final String COME0002 = "COME0002";			
    /** {$0}は必須項目です。  **/			
    public static final String COME0003 = "COME0003";			
    /** 日付に誤りがあります。 **/			
    public static final String COME0004 = "COME0004";			
    /** 無効なアカウントです。 **/			
    public static final String COME0005 = "COME0005";			
    /** {$0}は{$1}に存在しません。 **/			
    public static final String COME0006 = "COME0006";			
    /** {$0}の入力に誤りがあります。 **/			
    public static final String COME0007 = "COME0007";			
    /** {$0}の終了日が開始日より前の日付です。 **/			
    public static final String COME0008 = "COME0008";			
    /** パラメーターが不正です。 **/			
    public static final String COME0009 = "COME0009";			
    /** {$0}の形式が正しくありません。 **/			
    public static final String COME0010 = "COME0010";			
    /** {$0}項目を1つ以上選択してください。 **/			
    public static final String COME0011 = "COME0011";			
    /** {$0}は、未来日で検索することはできません。 **/			
    public static final String COME0012 = "COME0012";			
    /** 1行以上選択してください。 **/			
    public static final String COME0013 = "COME0013";			
    /** 他のユーザによって変更されました。 **/			
    public static final String COME0014 = "COME0014";			
    /** 他のユーザによって削除されました。 **/			
    public static final String COME0015 = "COME0015";			
    /** {$0}は{$1}桁以上で入力してください。  **/			
    public static final String COME0016 = "COME0016";			
    /** 更新対象が存在しません。 **/			
    public static final String COME0017 = "COME0017";			
    /** {$0}は{$1}に既に存在します。 **/			
    public static final String COME0018 = "COME0018";			
    /** {$0}は{$1}Byte以内で入力してください。 **/			
    public static final String COME0019 = "COME0019";			
    /** 複数行選択することはできません。 **/			
    public static final String COME0020 = "COME0020";			
    /** {$0}入力時は{$1}は必須入力となります。 **/			
    public static final String COME0021 = "COME0021";			
    /** 選択してください。 **/			
    public static final String COME0022 = "COME0022";			
    /** 使用不可能な旧住所が設定されています。住所を変更してください。 **/			
    public static final String COME0023 = "COME0023";			
    /** {$0}の値は{$1}以上で入力してください。 **/			
    public static final String COME0024 = "COME0024";			
    /** 複数件検索されました。入力条件を変更し再度検索してください **/			
    public static final String COME0025 = "COME0025";			
    /** {$0}の値は{$1}から{$2}の間で入力してください。 **/			
    public static final String COME0026 = "COME0026";			
    /** {$0}のチェックディジット入力に誤りがあります。 **/			
    public static final String COME0027 = "COME0027";			
    /** {$0}の場合、{$1}は必須項目です。 **/			
    public static final String COME0028 = "COME0028";			
    /** 1行選択してください。 **/			
    public static final String COME0029 = "COME0029";			
    /** 申請状況のチェックボックスが選択されていません。いずれかを選択してください。 **/			
    public static final String COME0030 = "COME0030";			
    /** 時刻に誤りがあります。 **/			
    public static final String COME0031 = "COME0031";			
    /** アップロード対象のファイルが選択されていません。 **/			
    public static final String COME0032 = "COME0032";			
    /** アップロード対象ファイルの拡張子が不正です。 **/			
    public static final String COME0033 = "COME0033";			
    /** アップロード対象ファイルの件数が上限を超えています。 **/			
    public static final String COME0034 = "COME0034";			
    /** アップロード対象ファイルの項目数が正しくありません。 **/			
    public static final String COME0035 = "COME0035";			
    /** アップロード対象ファイルが空（0byte）です **/			
    public static final String COME0036 = "COME0036";			
    /** アップロード対象ファイルの名称が正しくありません。 **/			
    public static final String COME0037 = "COME0037";			
    /** ファイルの文字コードが{$0}ではありません。 **/			
    public static final String COME0038 = "COME0038";			
    /** 入力された{$0}は、存在しません。 **/			
    public static final String COME0039 = "COME0039";			
    /** {$0}への{$1}権限がありません。 **/			
    public static final String COME0040 = "COME0040";			
    /** {$0}を入力してください。 **/			
    public static final String COME0041 = "COME0041";			
    /** 同じファイル名のファイルが存在します。{$0} **/			
    public static final String COME0042 = "COME0042";			
    /** {$0}は、存在しません。 **/			
    public static final String COME0043 = "COME0043";			
    /** 1行以上入力してください。 **/			
    public static final String COME0044 = "COME0044";			
    /** {$0}が入力されていません。 **/			
    public static final String COME0045 = "COME0045";			
    /** 該当のデータが存在しません。 **/			
    public static final String COME0046 = "COME0046";			
    /** {$0}は、既に使用されています。 **/			
    public static final String COME0047 = "COME0047";			
    /** {$0}を入力することはできません。 **/			
    public static final String COME0048 = "COME0048";			
    /** {$0}と{$1}が同時に選択されている行が存在します。 **/			
    public static final String COME0049 = "COME0049";			
    /** {$0}または、{$1}はどちらか必須です。 **/			
    public static final String COME0050 = "COME0050";			
    /** 存在しない{$0}が設定されています。{$1} **/			
    public static final String COME0051 = "COME0051";			
    /** {$0}と設定が異なる箇所があります。 **/			
    public static final String COME0052 = "COME0052";			
    /** {$0}は{$1}より過去は指定できません。 **/			
    public static final String COME0053 = "COME0053";			
    /** {$0}は、{$1}範囲で入力してください。 **/			
    public static final String COME0054 = "COME0054";			
    /** {$0}が重複しています。 **/			
    public static final String COME0055 = "COME0055";			
    /** {$0}が2つ以上選択されています。 **/			
    public static final String COME0056 = "COME0056";			
    /** {$0}が選択されていません。 **/			
    public static final String COME0057 = "COME0057";			
    /** {$0}の有効期限が過ぎています。 **/			
    public static final String COME0058 = "COME0058";			
    /** 該当のデータは、他ユーザーによって更新されました。該当データを再表示してください。 **/			
    public static final String COME0059 = "COME0059";			
    /** {$0}が異常終了しました。 **/			
    public static final String COMF0012 = "COMF0012";			
    /** セッションタイムアウトが発生しました。再ログインして下さい。 **/			
    public static final String COMF0001 = "COMF0001";			
    /** システムエラーが発生しました。システム部にご連絡下さい。 **/			
    public static final String COMF0002 = "COMF0002";			
    /** 印刷処理に失敗しました。 **/			
    public static final String COMF0003 = "COMF0003";			
    /** ダウンロード処理に失敗しました。 **/			
    public static final String COMF0004 = "COMF0004";			
    /** ファイルの登録に失敗しました。 **/			
    public static final String COMF0005 = "COMF0005";			
    /** ファイルの削除に失敗しました。 **/			
    public static final String COMF0006 = "COMF0006";			
    /** {$0}エラーが発生しました。 **/			
    public static final String COMF0007 = "COMF0007";			
    /** アップロード処理に失敗しました。 **/			
    public static final String COMF0008 = "COMF0008";			
    /** 登録に失敗しました。 **/			
    public static final String COMF0009 = "COMF0009";			
    /** 更新に失敗しました。 **/			
    public static final String COMF0010 = "COMF0010";			
    /** 削除に失敗しました。 **/			
    public static final String COMF0011 = "COMF0011";			
    /** 【{$0}】受信エラー **/			
    public static final String OIFF0003 = "OIFF0003";			
    /** 【{$0}】送信エラー **/			
    public static final String OIFF0004 = "OIFF0004";			
    /** ID：{$0}、処理名：{$1}の受信中にエラーが発生しました。 **/			
    public static final String OIFF0005 = "OIFF0005";			
    /** ID：{$0}、処理名：{$1}の送信中にエラーが発生しました。 **/			
    public static final String OIFF0006 = "OIFF0006";			
    /** 連携されたファイルの形式に不備があります。 **/			
    public static final String OIFF0001 = "OIFF0001";			
    /** ファイル中の項目数が一致しません。 **/			
    public static final String OIFF0002 = "OIFF0002";			

}
