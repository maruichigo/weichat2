/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mst;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.annotation.MaxSizeCheck;
import jp.co.kintetsuls.beans.common.annotation.NotEmpty;
import lombok.Data;

/**
 *料金項目マスタ
 * 
 * @author 呉俊 (MBP)
 * @version 2019/1/29 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst291Form")
@ViewScoped
@Data
public class Mst291Form implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;

    /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;

    /**
     * 選択された結果
     */
    private List<Map<String, Object>> selectedSearchResult;
    
    /**
     * 世代検索
     */
    @NotEmpty(name = "世代検索条件")
    private String[] conSedaiKensakuJoken;
    
    /**
     * 世代検索のみDisabled
     */
    private boolean conSedaiKensakuJokenDisabled;

    /**
     * 世代検索Visabled
     */
    private boolean conSedaiKensakuJokenVisible;
    
    /**
     * 料金項目コード
     */
    @MaxSizeCheck(maxSize = 3, name = "料金項目コード")
    private String conRyokinKomokuCd;
    
    /**
     * 料金項目コードのみDisabled
     */
    private boolean conRyokinKomokuCdDisabled;

    /**
     * 料金項目コードのみVisabled
     */
    private boolean conRyokinKomokuCdVisible;
    
    /**
     * 料金項目名称
     */
    @MaxSizeCheck(maxSize = 40, name = "料金項目名称")
    private String conRyokinKomokuMeisho;
    
    /**
     * 料金項目名称のみDisabled
     */
    private boolean conRyokinKomokuMeishoDisabled;

    /**
     * 料金項目名称のみVisabled
     */
    private boolean conRyokinKomokuMeishoVisible;
    
    /**
     * 料金項目グループ
     */
    private AutoCompOptionBean conRyokinKomokuGroup;
    
    /**
     * 料金項目グループのみDisabled
     */
    private boolean conRyokinKomokuGroupDisabled;

    /**
     * 料金項目グループのみVisabled
     */
    private boolean conRyokinKomokuGroupVisible;
    
    /**
     * 処理科目
     */
    private AutoCompOptionBean conSyoriKamoku;
    
    /**
     * 処理科目のみDisabled
     */
    private boolean conSyoriKamokuDisabled;

    /**
     * 処理科目のみVisabled
     */
    private boolean conSyoriKamokuVisible;
    
    /**
     * 補助科目
     */
    private AutoCompOptionBean conHojoKamoku;
    
    /**
     * 補助科目のみDisabled
     */
    private boolean conHojoKamokuDisabled;

    /**
     * 補助科目のみVisabled
     */
    private boolean conHojoKamokuVisible;
    
    /**
     * 輸送売上セット先
     */
    private AutoCompOptionBean conYusoUriageSetSaki;
    
    /**
     * 輸送売上セット先のみDisabled
     */
    private boolean conYusoUriageSetSakiDisabled;

    /**
     * 輸送売上セット先のみVisabled
     */
    private boolean conYusoUriageSetSakiVisible;
    
    /**
     * プルーフ用集約項目
     */
    private AutoCompOptionBean conProofYouShuyakuKomoku;
    
    /**
     * プルーフ用集約項目のみDisabled
     */
    private boolean conProofYouShuyakuKomokuDisabled;

    /**
     * プルーフ用集約項目のみVisabled
     */
    private boolean conProofYouShuyakuKomokuVisible;
    
    /**
     * 適用日
     */
    private Date conTekiyoBi;
    
    /**
     * 適用日のみDisabled
     */
    private boolean tekiyoBiDisabled = false;

    /**
     * 適用日のみVisabled
     */
    private boolean conTekiyoBiVisible;
    
    /**
     * 適用名
     */
    @MaxSizeCheck(maxSize = 40, name = "適用名")
    private String conTekiyoMei;
    
    /**
     * 適用名のみDisabled
     */
    private boolean conTekiyoMeiDisabled;

    /**
     * 適用名のみVisabled
     */
    private boolean conTekiyoMeiVisible;
    
    /**
     * 削除のみ検索
     */
    private String[] conSakujoNomiKensaku;
    
    /**
     * 削除のみ検索のみDisabled
     */
    private boolean conSakujoNomiKensakuDisabled;

    /**
     * 削除のみ検索のみVisabled
     */
    private boolean conSakujoNomiKensakuVisible;
    
    /**
     * 編集Disabled
     */
    private boolean btnEditeDisabled;
    
    /**
     * 検索Visabled
     */
    private boolean btnSearchVisible;

    /**
     * 検索条件変更Visabled
     */
    private boolean btnSearchChangeVisible;
}
