/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mst;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.LabelValueBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.annotation.MaxSizeCheck;
import jp.co.kintetsuls.beans.common.annotation.NotEmpty;
import jp.co.kintetsuls.beans.common.annotation.NotNull;
import jp.co.kintetsuls.beans.common.annotation.SizeCheck;
import jp.co.kintetsuls.forms.common.LabelValueForm;
import lombok.Data;

/**
 *チャーター料金項目マスタフォーム
 * 
 * @author 黄義輝 (MBP)
 * @version 2019/1/24 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst382Form")
@ViewScoped
@Data
public class Mst382Form implements Serializable {
    
    /* 処理科目AutoComp */
    private AutoCompOptionBean conSyoriKamoku;

    /* 処理科目Label */
    private String conSyoriKamokuLabel;
    
    /* 処理科目Disabled */
    private boolean conSyoriKamokuDisabled;

    /* 処理科目Visabled */
    private boolean conSyoriKamokuVisible;

    /* 補助科目AutoComp */
    private AutoCompOptionBean conHojoKamoku;

    /* 補助科目Label */
    private String conHojoKamokuLabel;
    
    /* 補助科目Disabled */
    private boolean conHojoKamokuDisabled;

    /* 補助科目Visabled */
    private boolean conHojoKamokuVisible;
    
    /* 料金項目コード */
    @SizeCheck(size = 3, name = "料金項目コード")
    private String conRyokinKomokuCd;

    /* 料金項目コードDisabled */
    private boolean conRyokinKomokuCdDisabled;

    /* 料金項目コードVisabled */
    private boolean conRyokinKomokuCdVisabled;
    
    /* 料金項目名称 */
    @MaxSizeCheck(maxSize = 40, name = "料金項目名称")
    private String conRyokinKomokuMeisho;
    
    /* 料金項目名称Disabled */
    private boolean conRyokinKomokuMeishoDisabled;
    
    /* 料金項目名称Visabled */
    private boolean conRyokinKomokuMeishoVisabled;

    /* 処理科目名 */
    private String conSyoriKamokuMei;
    
    /* 処理科目名Disabled */
    private boolean conSyoriKamokuMeiDisabled;
    
    /* 処理科目名Visabled */
    private boolean conSyoriKamokuMeiVisabled;
    
    /* 補助科目名 */
    private String conHojoKamokuMei;
    
    /* 補助科目名Disabled */
    private boolean conHojoKamokuMeiDisabled;

    /* 補助科目名Visabled */
    private boolean conHojoKamokuMeiVisabled;
    
    /* 世代検索条件 */
    @NotEmpty(message = "{COME0022}")
    private String[] conSedaiKensakuJoken;    

    /* 世代検索条件Disabled */
    private boolean conSedaiKensakuJokenDisabled;

    /* 世代検索条件Visabled */
    private boolean conSedaiKensakuJokenVisabled;

    /* 世代検索条件checkbox */
    private List<LabelValueForm> seidaiKensakujokencheckBox;
    
    /* 適用日 */
    @NotNull(message = "{COME0028}", checkTime = "適用日指定", name = "適用日")
    private Date conTekiyoBi;
    
    /* 適用日Disabled */
    private boolean conTekiyoBiDisabled;
    
    /* 適用日Visabled */
    private boolean conTekiyoBiVisabled;

    /* 適用名 */
    private String conTekiyoMei;
    
    /* 適用名Disabled */
    private boolean conTekiyoMeiDisabled;
    
    /* 適用名Visabled */
    private boolean conTekiyoMeiVisabled;

    /* チャーター料金項目データーバージョン */
    private Integer listCharterRyokinKomokuVersion;

    /* チャーター料金項目データーバージョンDisabled */
    private boolean listCharterRyokinKomokuVersionDisabled;

    /* チャーター料金項目データーバージョンVisabled */
    private boolean listCharterRyokinKomokuVersionVisabled;

    /* 更新カウンタ */
    private Integer listKoshinCounter;

    /* 更新カウンタDisabled */
    private boolean listKoshinCounterDisabled;

    /* 更新カウンタVisabled */
    private boolean listKoshinCounterVisabled;

    /* 削除済のみ */
    private String[] conSakujoSumiNomi;
    
    /* 削除済のみDisabled */
    private boolean conSakujoSumiNomiDisabled;
    
    /* 削除済のみVisabled */
    private boolean conSakujoSumiNomiVisabled;

    /* 削除済のみリスト */
    private List<LabelValueBean> conSakujoSumiNomiLabelValueList;
    
    /* 削除済のみリストDisabled */
    private boolean conSakujoSumiNomiLabelValueListDisabled;
    
    /* 削除済のみリストVisabled */
    private boolean conSakujoSumiNomiLabelValueListVisabled;

    /* 削除済のみcheckBox */
    private List<LabelValueForm> sakujosumiNomicheckBox;

    /* 編集Disabled */
    private boolean btnEditeDisabled;

    /* 検索件数*/
    private long count;

    /* 検索Visabled */
    private boolean btnSearchVisible;

    /* 検索条件変更Visabled */
    private boolean btnSearchChangeVisible;

    /* 検索結果一覧データ */
    private List<Map<String, Object>> searchResult;

    /* 検索結果一覧選択できる */
    private ReportListDataModel searchResultSelectable;    

    /* 選択された結果 */
    private List<Map<String, Object>> selectedSearchResult;
    
    /* 明細区分checkBox */
    private List<LabelValueForm> meisaiKbnCheckBox;

    /* 小数点区分checkBox */
    private List<LabelValueForm> shosutenKbCheckBox;

    /* 制御区分分checkBox */
    private List<LabelValueForm> seigyoKbnCheckBox;

    /* 税区分checkBox */
    private List<LabelValueForm> zeiKbnCheckBox;

    /* 輸送売上セット先checkBox */
    private List<LabelValueForm> yusoUriageSetSakiCheckBox;

}