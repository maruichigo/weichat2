/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.cus;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 *
 * @author y_kamata
 */
@Data
public class Cus012Def implements Serializable {

    private static final long serialVersionUID = 7013090829426790523L;
    
    private String kokyakuCd;
    private Date tekiyoKaishibi;
    private String tekiyoMei;
    private String shinseiStatusCd;
    private String kokyakuShubetsu;
    private String kokyakuKbn;
    private String kokyakuMeiKanji1;        
    private String kokyakuMeiKanji2;        
    private String kokyakuMeiKanji3;        
    private String kokyakuMeiKanji4;        
    private String kokyakuMei;
}
