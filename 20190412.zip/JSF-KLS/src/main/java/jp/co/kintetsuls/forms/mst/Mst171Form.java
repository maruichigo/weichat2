/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mst;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.annotation.HalfNumber;
import jp.co.kintetsuls.beans.common.annotation.MaxSizeCheck;
import jp.co.kintetsuls.beans.common.annotation.NumberRange;
import jp.co.kintetsuls.beans.common.annotation.SelectOne;
import lombok.Data;

/**
 * 荷受人/荷送人マスタ フォーム
 *
 * @author 張誠(MBP)
 * @version 2019/3/18 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst171Form")
@ViewScoped
@Data
public class Mst171Form implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 荷受人/荷送人モード
     */
    private String conNiukeNiokurininMode;

    /**
     * 参照/編集/新規モード
     */
    private String conSanshoHenshuShinkiMode;

    /**
     * 営業所コード
     */
    @SelectOne(name = "営業所コード", message = "{COME0003}")
    private AutoCompOptionBean conEigyoshoCd;

    /**
     * 営業所Disabled
     */
    private boolean conEigyoshoCdDisabled;

    /**
     * 営業所コード退避
     */
    private String conEigyoshoCdTaihi;

    /**
     * 顧客コード
     */
    @SelectOne(name = "顧客コード", message = "{COME0003}")
    private AutoCompOptionBean conKokyakuCd;

    /**
     * 顧客Disabled
     */
    private boolean conKokyakuCdDisabled;

    /**
     * 顧客コード退避
     */
    private String conKokyakuCdTaihi;

    /**
     * 荷受人発行コード
     */
    @MaxSizeCheck(name = "荷受人発行コード", maxSize = 20)
    private String conNiukeninHakkoCd;

    /**
     * 荷受人発行コードDisabled
     */
    private boolean conNiukeninHakkoCdDisabled;

    /**
     * 荷受人名称
     */
    @MaxSizeCheck(name = "荷受人名称", maxSize = 160)
    private String conNiukeninMei;

    /**
     * 荷受人名称Disabled
     */
    private boolean conNiukeninMeiDisabled;

    /**
     * 荷受人カナ名称
     */
    @MaxSizeCheck(name = "荷受人カナ名称", maxSize = 40)
    private String conNiukeninKanaMei;

    /**
     * 荷受人カナ名称Disabled
     */
    private boolean conNiukeninKanaMeiDisabled;

    /**
     * 荷受人住所
     */
    @MaxSizeCheck(name = "荷受人住所", maxSize = 160)
    private String conNiukeninJusho;

    /**
     * 荷受人住所Disabled
     */
    private boolean conNiukeninJushoDisabled;

    /**
     * 荷受人電話番号
     */
    @MaxSizeCheck(name = "荷受人電話番号", maxSize = 19)
    private String conNiukeninTel;

    /**
     * 荷受人電話番号Disabled
     */
    private boolean conNiukeninTelDisabled;

    /**
     * 荷受人検索キー
     */
    @MaxSizeCheck(name = "荷受人検索キー", maxSize = 40)
    private String conNiukeninKey;

    /**
     * 荷受人検索キーDisabled
     */
    private boolean conNiukeninKeyDisabled;

    /**
     * 荷送人発行コード
     */
    @MaxSizeCheck(name = "荷受人検索キー", maxSize = 20)
    private String conNiokurininHakkoCd;

    /**
     * 荷送人発行コードDisabled
     */
    private boolean conNiokurininHakkoCdDisabled;

    /**
     * 荷送人名称
     */
    @MaxSizeCheck(name = "荷送人名称", maxSize = 160)
    private String conNiokurininMei;

    /**
     * 荷送人名称Disabled
     */
    private boolean conNiokurininMeiDisabled;

    /**
     * 荷送人カナ名称
     */
    @MaxSizeCheck(name = "荷送人カナ名称", maxSize = 40)
    private String conNiokurininKanaMei;

    /**
     * 荷送人カナ名称Disabled
     */
    private boolean conNiokurininKanaMeiDisabled;

    /**
     * 荷送人住所名称
     */
    @MaxSizeCheck(name = "荷送人カナ名称", maxSize = 160)
    private String conNiokurininJusho;

    /**
     * 荷送人住所Disabled
     */
    private boolean conNiokurininJushoDisabled;

    /**
     * 荷送人電話番号
     */
    @MaxSizeCheck(name = "荷送人電話番号", maxSize = 19)
    private String conNiokurininTel;

    /**
     * 荷送人電話番号Disabled
     */
    private boolean conNiokurininTelDisabled;

    /**
     * 荷送人検索キー
     */
    @MaxSizeCheck(name = "荷送人検索キー", maxSize = 40)
    private String conNiokurininKey;

    /**
     * 荷送人検索キーDisabled
     */
    private boolean conNiokurininKeyDisabled;

    /**
     * 並び順
     */
    private String conSortJun;

    /**
     * 並び順Disabled
     */
    private boolean conSortJunDisabled;

    /**
     * 要修正分のみ
     */
    private String conYoshuseiNomi[];

    /**
     * 要修正分のみDisabled
     */
    private boolean conYoshuseiNomiDisabled;

    /**
     * 旧住所警告分も表示する
     */
    private String conKyuJushoHyoji[];

    /**
     * 旧住所警告分も表示するDisabled
     */
    private boolean conKyuJushoHyojiDisabled;

    /**
     * 未使用期間（年）
     */
    @HalfNumber(name = "未使用期間（年）")
    @MaxSizeCheck(name = "未使用期間（年）", maxSize = 2)
    private String conMishiyoKikanNen;

    /**
     * 未使用期間（年）Disabled
     */
    private boolean conMishiyoKikanNenDisabled;

    /**
     * 未使用期間（月）
     */
    @HalfNumber(name = "未使用期間（月）")
    @MaxSizeCheck(name = "未使用期間（月）", maxSize = 2)
    @NumberRange(name = "未使用期間（月）", minValue = 1, maxValue = 11)
    private String conMishiyoKikanTsuki;

    /**
     * 未使用期間（月）退避
     */
    private String conMishiyoKikanTsukiTaihi;

    /**
     * 未使用期間（月）Disabled
     */
    private boolean conMishiyoKikanTsukiDisabled;

    /**
     * 削除済みを含む
     */
    private String conSakujozumiFukumu[];

    /**
     * 削除済みを含むDisabled
     */
    private boolean conSakujozumiFukumuDisabled;

    /**
     * 複写顧客コード
     */
    private String conHKokyakuCd;
    
    /**
     * 複写顧客コード退避
     */
    private String conHKokyakuCdTaihi;
    

    /**
     * 複写顧客コードDisabled
     */
    private boolean conHKokyakuCdDisabled;

    /**
     * 複写顧客名称
     */
    private String listKokyakuMei;

    /**
     * 複写顧客名称Disabled
     */
    private boolean listKokyakuMeiDisabled;

    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;

    /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;

    /**
     * 選択された結果
     */
    private List<Map<String, Object>> selectedSearchResult;

    /**
     * 検索Visabled
     */
    private boolean btnSearchVisible;

    /**
     * 検索条件変更Visabled
     */
    private boolean btnSearchChangeVisible;

    /**
     * 新規登録ボタンDisabled
     */
    private boolean btnShinkiTorokuDisabled;

    /**
     * 複写登録ボタンDisabled
     */
    private boolean btnFukushaTorokuDisabled;

    /**
     * 詳細ボタンDisabled
     */
    private boolean btnShosaiDisabled;

    /**
     * 削除ボタンDisabled
     */
    private boolean btnSakujoDisabled;

    /**
     * ダウンロードボタンDisabled
     */
    private boolean btnDownloadDisabled;

    /**
     * アップロードボタンDisabled
     */
    private boolean btnUploadDisabled;

    /**
     * 他顧客コードからの一括複写ボタンDisabled
     */
    private boolean btnTakokyakuCdKaraIkkatsuFukushaDisabled;

    /**
     * 一括登録ボタンDisabled
     */
    private boolean btnIkkatsuTorokuDisabled;

    /**
     * 取消ボタンDisabled
     */
    private boolean btnTorikeshiDisabled;

}
