/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common.annotation.validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import jp.co.kintetsuls.beans.common.annotation.ZipCode;
import jp.co.kintetsuls.utils.CheckUtils;

/**
 * 郵便番号チェック
 * 
 * @author 曾鳳 (MBP)
 * @version 2019/4/1 新規作成
 */
public class ZipCodeValidator implements ConstraintValidator<ZipCode, String> { 

    @Override
    public void initialize(ZipCode constraintAnnotation) {
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {

        if (CheckUtils.isEmpty(value)) {
            return true;
        }

        Pattern pattern = Pattern.compile("[0-9]{3}-[0-9]{4}");
        Matcher isChar = pattern.matcher(value);
        if(!isChar.matches()){
            return false;
        }
        return true;
    }
    
}
