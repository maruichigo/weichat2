/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mst;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.annotation.MaxSizeCheck;
import jp.co.kintetsuls.beans.common.annotation.NotEmpty;
import jp.co.kintetsuls.beans.common.annotation.NotNull;
import jp.co.kintetsuls.beans.common.annotation.SizeCheck;
import lombok.Data;

/**
 * 施設マスタ一覧 フォーム
 *
 * @author 王永 (MBP)
 * @version 2019/1/31 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst141Form")
@ViewScoped
@Data
public class Mst141Form implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 管轄営業所AutoCompelete
     */
    @NotNull(name = "管轄営業所", message = "{COME0003}")
    private AutoCompOptionBean conKankatsuEigyosho;

    /**
     * 管轄営業所Label
     */
    private String conKankatsuEigyoshoLabel;

    /**
     * 管轄営業所Disabled
     */
    private boolean conKankatsuEigyoshoDisabled;

    /**
     * 管轄営業所Visabled
     */
    private boolean conKankatsuEigyoshoVisible;

    /**
     * 施設コード
     */
    @SizeCheck(size = 5, name = "施設コード")
    private String conShisetsuCd;

    /**
     * 施設コードDisabled
     */
    private boolean conShisetsuCdDisabled;

    /**
     * 施設コードVisabled
     */
    private boolean conShisetsuCdVisible;

    /**
     * 施設名
     */
    @MaxSizeCheck(maxSize = 40, name = "施設名")
    private String conShisetsuMei;

    /**
     * 施設名Disabled
     */
    private boolean conShisetsuMeiDisabled;

    /**
     * 施設名Visabled
     */
    private boolean conShisetsuMeiVisible;

    /**
     * 世代検索条件
     */
    @NotEmpty(name = "世代検索条件", message = "{COME0022}")
    private String[] conSedaiKensakuJoken;

    /**
     * 世代検索条件Disabled
     */
    private boolean conSedaiKensakuJokenDisabled;

    /**
     * 世代検索条件Visabled
     */
    private boolean conSedaiKensakuJokenVisible;

    /**
     * 適用日
     */
    private Date conTekiyoHi;

    /**
     * 削除済のみ
     */
    private String[] conSakujoSumiNomi;

    /**
     * 削除済のみDisabled
     */
    private boolean conSakujoSumiNomiDisabled;

    /**
     * 削除済のみVisabled
     */
    private boolean conSakujoSumiNomiVisible;

    /**
     * 申請状況
     */
    @NotEmpty(name = "申請状況", message = "{DEME0001}")
    private String[] conShinseiJokyo;

    /**
     * 申請状況Disabled
     */
    private boolean conShinseiJokyoDisabled;

    /**
     * 申請状況Visabled
     */
    private boolean conShinseiJokyoVisible;

    /**
     * 適用名
     */
    @MaxSizeCheck(maxSize = 40, name = "適用名")
    private String conTekiyoMei;

    /**
     * 適用名Disabled
     */
    private boolean conTekiyoMeiDisabled;

    /**
     * 適用名Visabled
     */
    private boolean conTekiyoMeiVisible;

    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;

    /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;

    /**
     * 選択された結果
     */
    private List<Map<String, Object>> selectedSearchResult;

    /**
     * 検索Visabled
     */
    private boolean btnSearchVisible;

    /**
     * 検索条件変更Visabled
     */
    private boolean btnSearchChangeVisible;

    /**
     * サブ検索条件折畳
     */
    private boolean collapsed;

}
