/*
 * Mst151Bean.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.edi;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteBean;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 *
 * @author xubo
 */
@ManagedBean(name = "edi011")
@ViewScoped
@Data
public class Edi011Bean extends AbstractBean {

    private final String strTitle = "EDI一覧画面";
    private String url;     // URL

    /**
     * 定数：SAKUJO_FLG.
     */
    private static final String CONST_SAKUJO_FLG = "SAKUJO_FLG";

    /**
     * 定数：0文字列.
     */
    private static final String CONST_ZERO_STRING = "0";

    /**
     * 定数：COM_GET_MS_TODOFUKEN.
     */
    private static final String CONST_COM_GET_VW_EIGYOSHO = "COM_GET_VW_EIGYOSHO";

    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    @ManagedProperty(value = "#{autoComplete}")
    private AutoCompleteBean autoCompleteBean;

    private RestfullService rest;

    private static final Logger logger = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    private List<Map<String, String>> searchResult;

    private Map<String, String> selectSearchResult;

    /**
     * 区分選択
     */
    private int conSelectedKbn;

    /**
     * 送受信区分
     */
    private String conSoujuushinKbn;

    /**
     * 送受信区分Visabled
     */
    private boolean conSoujuushinKbnVisible;

    /**
     * ファイル名
     */
    private String conFileName;

    /**
     * ファイル名Visabled
     */
    private boolean conFileNameVisible;

    /**
     * EDI種別
     */
    private String conEDIType;

    /**
     * EDI種別Visabled
     */
    private boolean conEDITypeVisible;

    /**
     * 表示基準
     */
    private String conHyoujiKijun;

    /**
     * 表示基準Visabled
     */
    private boolean conHyoujiKijunVisible;

    /**
     * 代表顧客
     */
    private AutoCompOptionBean conKokyakuCd;

    /**
     * 代表顧客Visabled
     */
    private boolean conKokyakuCdVisible;

    /**
     * 外部システム名
     */
    private String conExSysName;

    /**
     * 外部システム名Visabled
     */
    private boolean conExSysNameVisible;

    /**
     * データ種別
     */
    private String conDataype;

    /**
     * データ種別Visabled
     */
    private boolean conDataypeVisible;

    /**
     * バッチ名
     */
    private String conBatch;

    /**
     * バッチ名Visabled
     */
    private boolean conBatchVisible;

    /**
     * 機能名
     */
    private String conKinoMei;

    /**
     * 機能名Visabled
     */
    private boolean conKinoMeiVisible;

    /**
     * ファイル種別
     */
    private String conFileType;

    /**
     * ファイル種別Visabled
     */
    private boolean conFileTypeVisible;

    /**
     * 実行結果
     */
    private String conJikkouKekka;

    /**
     * 営業所
     */
    private AutoCompOptionBean conEigyoshoCd;

    /**
     * 営業所Visabled
     */
    private boolean conEigyoshoCdVisible;

    /**
     * 代表営業所
     */
    private AutoCompOptionBean conEigyoshoCd1;

    /**
     * 代表営業所Visabled
     */
    private boolean conEigyoshoCd1Visible;

    /**
     * 関連営業所
     */
    private AutoCompOptionBean conKanrenEigyoshoCd;

    /**
     * 関連営業所Visabled
     */
    private boolean conKanrenEigyoshoCdVisible;

    /**
     * 関連顧客
     */
    private AutoCompOptionBean conKanrenKokyakuCd;

    /**
     * 関連顧客Visabled
     */
    private boolean conKanrenKokyakuCdVisible;
    
    /** list */
    
    /**
     * 顧客名/EDI名/ファイル名Visabled
     */
    private boolean listKokyakuMeiVisible;
    
    /**
     * 外部システム名/外部システムIF名Visabled
     */
    private boolean listSysNameVisible;
    
    /**
     * バッチ名Visabled
     */
    private boolean listBatchVisible;
    
    /**
     * 機能名/アップロードファイル種別Visabled
     */
    private boolean listKinoMeiVisible;
    
    /**
     * OK件数Visabled
     */
    private boolean listOkKensuVisible;
    
    /**
     * 要修正件数Visabled
     */
    private boolean listShuuseiKensuVisible;
    
    /**
     * NG件数Visabled
     */
    private boolean listNgKennsuVisible;
    
    /**
     * スキップ件数Visabled
     */
    private boolean listSkipKennsuVisible;
    
    /**
     * 代表顧客Visabled
     */
    private boolean listKokyakuDaihyoVisible;
    
    /**
     * 代表営業所Visabled
     */
    private boolean listEigyoshoDaihyoVisible;
    
    /**
     * 顧客コードVisabled
     */
    private boolean listKokyakuCdVisible;
    
    /**
     * コンストラクタ
     */
    public Edi011Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId
     * @param prevScreen
     * @param backFlag
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlg) {
        try {
            //検索条件を初期化する
            conSelectedKbn = 1;
            conSoujuushinKbnVisible = true;
            conFileNameVisible = true;
            conEDITypeVisible = true;
            conHyoujiKijunVisible = true;
            conKokyakuCdVisible = true;
            conEigyoshoCd1Visible = true;
            conKanrenEigyoshoCdVisible = true;
            conKanrenKokyakuCdVisible = true;
            conExSysNameVisible = false;
            conDataypeVisible = false;
            conKinoMeiVisible = false;
            conEigyoshoCdVisible = false;
            conBatchVisible = false;
            //検索結果部を初期化する
            listKokyakuMeiVisible = true;
            listSysNameVisible = false;
            listBatchVisible = false;
            listKinoMeiVisible = false;
            listOkKensuVisible = true;
            listShuuseiKensuVisible = true;
            listNgKennsuVisible = true;
            listSkipKennsuVisible = true;
            listKokyakuDaihyoVisible = true;
            listEigyoshoDaihyoVisible = true;
            listKokyakuCdVisible = false;
            // AutoCompleteを初期化する
            Map params = new HashMap();
            params.put(CONST_SAKUJO_FLG, CONST_ZERO_STRING);
            autoCompleteBean.initAutoComplete(CONST_COM_GET_VW_EIGYOSHO, params);
            // パンくず追加
            breadBean.push("EDI一覧画面", Cnst.SCREEN.EDI011_SCREEN.name(), this);
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }
    }

    @Override
    public String menuClick(String menuId, String nextScreen) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return
     */
    @Override
    public String logoutClick() {
        return authConfBean.logout();
    }

    /**
     * @return the strTitle
     */
    public String getStrTitle() {
        return strTitle;
    }

    /**
     * 区分の切り替え（処理）
     *
     */
    public void modeEvent() {
        if (1 == (conSelectedKbn)) {
            conSoujuushinKbnVisible = true;
            conFileNameVisible = true;
            conEDITypeVisible = true;
            conHyoujiKijunVisible = true;
            conKokyakuCdVisible = true;
            conEigyoshoCd1Visible = true;
            conKanrenEigyoshoCdVisible = true;
            conKanrenKokyakuCdVisible = true;
            conExSysNameVisible = false;
            conDataypeVisible = false;
            conKinoMeiVisible = false;
            conEigyoshoCdVisible = false;
            conBatchVisible = false;
            
            listKokyakuMeiVisible = true;
            listSysNameVisible = false;
            listBatchVisible = false;
            listKinoMeiVisible = false;
            listOkKensuVisible = true;
            listShuuseiKensuVisible = true;
            listNgKennsuVisible = true;
            listSkipKennsuVisible = true;
            listKokyakuDaihyoVisible = true;
            listEigyoshoDaihyoVisible = true;
            listKokyakuCdVisible = false;
        } else if (2 == (conSelectedKbn)) {
            conSoujuushinKbnVisible = true;
            conExSysNameVisible = true;
            conDataypeVisible = true;
            conEDITypeVisible = false;
            conEigyoshoCdVisible = true;
            conHyoujiKijunVisible = false;
            conKokyakuCdVisible = false;
            conEigyoshoCd1Visible = false;
            conKanrenEigyoshoCdVisible = false;
            conKanrenKokyakuCdVisible = false;
            conFileNameVisible = false;
            conKinoMeiVisible = false; 
            conBatchVisible = false;
            
            listKokyakuMeiVisible = false;
            listSysNameVisible = true;
            listBatchVisible = false;
            listKinoMeiVisible = false;
            listOkKensuVisible = false;
            listShuuseiKensuVisible = false;
            listNgKennsuVisible = false;
            listSkipKennsuVisible = false;
            listKokyakuDaihyoVisible = false;
            listEigyoshoDaihyoVisible = false;
            listKokyakuCdVisible = false;
        } else if (3 == (conSelectedKbn)) {
            conSoujuushinKbnVisible = false;
            conFileNameVisible = false;
            conEDITypeVisible = false;
            conHyoujiKijunVisible = false;
            conKokyakuCdVisible = false;
            conEigyoshoCd1Visible = false;
            conKanrenEigyoshoCdVisible = false;
            conKanrenKokyakuCdVisible = false;
            conExSysNameVisible = false;
            conDataypeVisible = false;
            conKinoMeiVisible = false;
            conEigyoshoCdVisible = true;
            conBatchVisible = true;
            
            listKokyakuMeiVisible = false;
            listSysNameVisible = false;
            listBatchVisible = true;
            listKinoMeiVisible = false;
            listOkKensuVisible = false;
            listShuuseiKensuVisible = false;
            listNgKennsuVisible = false;
            listSkipKennsuVisible = false;
            listKokyakuDaihyoVisible = false;
            listEigyoshoDaihyoVisible = false;
            listKokyakuCdVisible = false;
        } else {
            conSoujuushinKbnVisible = false;
            conFileNameVisible = true;
            conEDITypeVisible = false;
            conHyoujiKijunVisible = false;
            conKokyakuCdVisible = true;
            conEigyoshoCd1Visible = false;
            conKanrenEigyoshoCdVisible = false;
            conKanrenKokyakuCdVisible = false;
            conExSysNameVisible = false;
            conDataypeVisible = true;
            conKinoMeiVisible = true;
            conEigyoshoCdVisible = true;
            conBatchVisible = false;
            
            listKokyakuMeiVisible = false;
            listSysNameVisible = false;
            listBatchVisible = false;
            listKinoMeiVisible = true;
            listOkKensuVisible = true;
            listShuuseiKensuVisible = true;
            listNgKennsuVisible = true;
            listSkipKennsuVisible = true;
            listKokyakuDaihyoVisible = false;
            listEigyoshoDaihyoVisible = false;
            listKokyakuCdVisible = true;
        }
    }
}
