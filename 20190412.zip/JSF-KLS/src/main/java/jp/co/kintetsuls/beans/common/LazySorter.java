/*
 * LazySorter.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.Map;
import org.primefaces.model.SortOrder;
import org.slf4j.LoggerFactory;

/**
 *
 * @author saihara
 */
public class LazySorter implements Comparator<Map<String, Object>> {
    private String sortField;
     
    private SortOrder sortOrder;
     
    public LazySorter(String sortField, SortOrder sortOrder) {
        this.sortField = sortField;
        this.sortOrder = sortOrder;
    }
 
    public int compare(Map<String, Object> val1, Map<String, Object> val2) {
        try {
            Object value1 = null;
            Object value2 = null;
            if (val1.get(sortField) instanceof Long) {
                value1 = new BigDecimal((Long) val1.get(sortField));
            } else if(val1.get(sortField) instanceof Double) {
                value1 = new BigDecimal((Double)val1.get(sortField));
            } else if(val1.get(sortField) instanceof String) {
                value1 = (String)val1.get(sortField);
            } else {
                value1 = new BigDecimal(Long.valueOf((int) val1.get(sortField)));
            }


            if (val2.get(sortField) instanceof Long) {
                value2 = new BigDecimal((Long) val2.get(sortField));
            } else if(val2.get(sortField) instanceof Double) {
                value2 = new BigDecimal((Double)val2.get(sortField));
            }  else if(val2.get(sortField) instanceof String) {
                value2 = val2.get(sortField);
            }  else {
                value2 = new BigDecimal(Long.valueOf((int) val2.get(sortField)));
            }
            
            // nullの場合は空文字に置き換える
            if(value1 == null){
                value1 = "";
            }
            if(value2 == null){
                value2 = "";
            }           
            int value = ((Comparable)value1).compareTo(value2);
             
            return SortOrder.ASCENDING.equals(sortOrder) ? value : -1 * value;
        } catch(Exception e) {
            LoggerFactory.getLogger(this.getClass()).error(e.getMessage(), e);
            throw new RuntimeException();
        }
    }    
}
