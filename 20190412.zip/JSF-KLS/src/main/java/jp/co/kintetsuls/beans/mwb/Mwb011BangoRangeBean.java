/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mwb;

import lombok.Data;

/**
 * MAWB一覧 登録MAWB番号の範囲
 *
 * @author 尹明龍(MBP)
 * @version 2019/2/19 新規作成
 */
@Data
public class Mwb011BangoRangeBean {
    /**
     * 登録MAWB番号From
     */
    private String torokuMawbBangoFrom;

    /**
     * 登録MAWB番号To
     */
    private String torokuMawbBangoTo;
    
}
