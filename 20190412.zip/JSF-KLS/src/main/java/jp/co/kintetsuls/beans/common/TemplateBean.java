package jp.co.kintetsuls.beans.common;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.exception.FunctionCust;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.file.CsvBuilder;
import jp.co.kintetsuls.file.ExcelBuilder;
import static jp.co.kintetsuls.file.ExcelBuilder.FILE_STORE_FOLDER_TEMP;
import jp.co.kintetsuls.file.FileDto;
import jp.co.kintetsuls.forms.mwb.Mwb031Form;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.kintetsuls.utils.DateUtils;
import jp.co.kintetsuls.utils.FileUtils;
import lombok.Getter;
import lombok.Setter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.primefaces.PrimeFaces;
import static org.primefaces.behavior.confirm.ConfirmBehavior.PropertyKeys.header;
import org.primefaces.context.RequestContext;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

/**
 * ファイル操作Bean
 *
 * @author
 */
@ManagedBean(name = "templeteBean")
@ViewScoped
public class TemplateBean extends AbstractBean {

    private final Map<String, FunctionCust<String, List>> downLoadFunctionList = new HashMap();

    private final Map<String, FunctionCust<String, List>> getSearchResultFunctionList = new HashMap();
    
    private final Map<String, FunctionCust<String, Boolean>> beforDownFunctionList = new HashMap();

    private final Map<String, FunctionCust<String, Long>> checkSizeFunctionList = new HashMap();
    
    @Getter
    @Setter
    private List<Map<String, Object>> dataList;
    
    private List<CSVDto> headerList;
    
    @Getter
    @Setter
    private String tilte = "";
    
    @Getter
    @Setter
    private boolean splitButtonSta = true;
    
    @Getter
    @Setter
    private boolean excelButtonSta = false;
    
    @Getter
    @Setter
    private Mwb031Form mwb031Form;
    
    /**
     * 存在フラグ
     */
    @Getter
    @Setter
    private boolean subFlg;

    @Getter
    @Setter
    private final Map<String, PageCommonBean> settings = new HashMap();

    @Getter
    @Setter
    private String comment;

    public Object returnNull() {
        System.out.println("returnNull called");
        return null;

    }

    /**
     * ファイルダウンロード
     *
     */
    public StreamedContent getDownloadFile(String id , String type, String btype) throws Exception {
        

        // DataTable連動
        List<Map<String, Object>> body = null;
        String mode = getCheckResult(id);
        String  temp = null;
        if ("1".equals(mode)) {
            temp = excelDown(mwb031Form);
        } else {
            if (!downLoadFunctionList.containsKey(id)) {
                return null;
            }
            List<Map<String, Object>> data = downLoadFunctionList.get(id).apply("");
            temp = excelDown(mwb031Form);
        }
        FileDto file = null;
        
        if ("excel".equals(type)) {
            String saveFile = excelDown(mwb031Form);
            file = new FileDto("", CsvBuilder.FILE_STORE_FOLDER_TEMP + StndConsIF.FS + saveFile);
        } else {
            String saveFile = excelDown(mwb031Form);
            file = new FileDto("", CsvBuilder.FILE_STORE_FOLDER_TEMP + StndConsIF.FS + saveFile);
        }

        if (file == null) {
            return null;
        }
        String downloadFilePath = file.getFilePath();
        String downloadFileName = file.getFileName();
        if (CheckUtils.isEmpty(downloadFilePath)) {
            return null;
        }
        if (CheckUtils.isEmpty(downloadFileName)) {
            downloadFileName = tilte + "_" + FileUtils.getFileName(downloadFilePath);
        }

        InputStream stream = new FileInputStream(FileUtils.getAbsolutePath(downloadFilePath));

        StreamedContent fileOut = new DefaultStreamedContent(stream, FileUtils.getContentType(downloadFileName), downloadFileName);
        return fileOut;
    }

    @Override
    public void init(String menuId, String prevScreen, boolean backFlg) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String menuClick(String menuId, String nextScreen) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String logoutClick() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * 業務ダウンロード方法を設定する。
     *
     * @param id
     * @param delFunction
     */
    public void regDownloadFucntion(String id, List<CSVDto> header,
            FunctionCust<String, List> downloadFunction) {
        downLoadFunctionList.put(id, downloadFunction);
        this.headerList = header;

    }
    
    public String getCheckResult(String id) throws Exception {
        PageCommonBean setting = settings.get(id);
        List<Map<String, Object>> data = downLoadFunctionList.get(id).apply("");
        if (data.size() == 1 && "hideRow".equals(data.get(0).get("hideFlg"))) {
            return "0";
        }             
        if (data.size() <= Integer.valueOf(setting.getMasterInfo().getMaxRows())) {
                return "1";
            }
        return "0";
    }
    
    public void regBeforeDownFucntion(String id,
            FunctionCust<String, Boolean> beforeDownFucntion) {
        beforDownFunctionList.put(id, beforeDownFucntion);

    }

    public void setDataSize(String id, FunctionCust<String, Long> checkSizeFunction) {
        checkSizeFunctionList.put(id, checkSizeFunction);
    }

    public void setSearchResult(String id, FunctionCust<String, List> searchResultFuction) {
        getSearchResultFunctionList.put(id, searchResultFuction);
    }
    public void beforeDown(String id, String type) throws Exception {

        PrimeFaces pf = PrimeFaces.current();
         Long cheLong;
         List<Map<String, Object>> searchResult = new ArrayList<>();
        if (!beforDownFunctionList.containsKey(id)) {
            return;
        }
        if (checkSizeFunctionList.containsKey(id)) {
            String mode = getCheckResult(id);
            if ("1".equals(mode)) {
                searchResult = getSearchResultFunctionList.get(id).apply("");
                int size = searchResult.size();
                cheLong = (long)size;
            } else {
                cheLong = checkSizeFunctionList.get(id).apply("");
            }
            pf.executeScript("getCSV ('" + checkSizeRe(id,cheLong) + "', '" + type + "')");
        }

    }

 
    
     private String checkSizeRe(String id, Long size) {

        PageCommonBean setting = settings.get(id);
        Integer msxRows = Integer.valueOf(setting.getMasterInfo().getMaxRows());
        Integer downloadMaxRows = Integer.valueOf(setting.getMasterInfo().getDownloadMaxRows());
        String allEigyoshoSearch = setting.getMasterInfo().getAllEigyoshoSearch();
        if (msxRows >= size && size > 0) {
            if ("0".equals(allEigyoshoSearch)) {
                if (!subFlg) {
                    return "F";
                } else {
                    return "G";
                }
            } else {
                if (!subFlg) {
                    return "H";
                } else {
                    return "I";
                }
            }
        }
        if (msxRows < size && size <= downloadMaxRows) {
            if ("0".equals(allEigyoshoSearch)) {
                if (!subFlg) {
                    return "J";
                } else {
                    return "K";
                }
            } else {
                if (!subFlg) {
                    return "L";
                } else {
                    return "M";
                }
            }
        }
        if (size > downloadMaxRows) {
            if (!subFlg) {
                return "N";
            } else {
                return "O";
            }
        } else {
            return "E";
        }
    }
     
     public void changeButtonStatas(String kbn) {
         if ("E".equals(kbn)) {
            splitButtonSta = true;
            return;
         }
         splitButtonSta = false;
         if ("D".equals(kbn)) {
             excelButtonSta = true;
         } else {
             excelButtonSta = false;
         }
     }
     
     public void saveComment() {
        PrimeFaces pf = PrimeFaces.current();

         if (comment == null || "".equals(comment.trim())) {
             return;
         } else {
            pf.executeScript("downLoadFile()");
         }
     }
     
    /**
     * ボイド報告書
     * 
     * @param form
     * @return 
     * @throws IOException 
     * @throws java.text.ParseException 
     */
    public String excelDown(Mwb031Form form) throws IOException, ParseException {
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy/MM");
            SimpleDateFormat outFormat = new SimpleDateFormat("yyyy年MM月分");

            // VOID年月
            String year = "(" + outFormat.format(format.parse(mwb031Form.getConSearchVoidNengetsu())) + ")";

            // 航空会社
            String airCompany = mwb031Form.getConSearchKokuGaishaLetterCd().getLabel() + "　御中";

            // 会社名
            String kaishaMei = "株式会社近鉄ロジスティクス・システムズ";

            // 営業所コード
            String eigyoshoMei = mwb031Form.getConSearchHakkenEigyoshoCd().getLabel();

            // 検索結果
            List<Map<String, Object>> searchResult = mwb031Form.getSearchResult();

            // MAWB番号リスト
            List<String> mawbBangoList = new ArrayList<>();

            // 検索結果からMAWB番号を取得する
            for (Map<String, Object> map : searchResult) {
                String mawbBango = map.get("listMawbBango").toString();
                String mawbCompany = mwb031Form.getConSearchKokuGaishaLetterCd().getValue();
                mawbBangoList.add(mawbCompany + "-" +mawbBango);
            }

            // テンプレートを読み
            FacesContext context = FacesContext.getCurrentInstance();
            HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest();
            String path = request.getRealPath("/") + "resources\\template\\Mwb031template.xlsx";
            InputStream inputStream = new FileInputStream(path);
            XSSFWorkbook tpWorkBook = new XSSFWorkbook(inputStream);

            // テンプレートシートを取得する
            XSSFSheet sheet = tpWorkBook.getSheetAt(0);

            // VOID年月セール
            XSSFCell yearCell = sheet.getRow(4).getCell(4);
            yearCell.setCellValue(year);
            
            // 航空会社セール
            XSSFCell kokuKaisha = sheet.getRow(6).getCell(1);
            kokuKaisha.setCellValue(airCompany);
            
            // 会社名セール
            XSSFCell kaisha = sheet.getRow(8).getCell(6);
            kaisha.setCellValue(kaishaMei);
            
            // 営業所コードセール
            XSSFCell eigyoshoCell = sheet.getRow(10).getCell(7);
            eigyoshoCell.setCellValue(eigyoshoMei);
            
            // MAWB番号リスト
            XSSFCell mawbCell = null;
            String mawbBango = null;
            for (int i = 0; i < mawbBangoList.size(); i++) {
                if (i > 34) {
                    mawbBango = mawbBangoList.get(i);
                    mawbCell = sheet.getRow(13 + i - 35).getCell(7);
                    mawbCell.setCellValue(mawbBango);
                } else {
                    mawbBango = mawbBangoList.get(i);
                    mawbCell = sheet.getRow(13 + i).getCell(2);
                    mawbCell.setCellValue(mawbBango);
                }
            }
            
            String filename = DateUtils.format(DateUtils.getSysDate(), StndConsIF.DF_YYYYMMDDHHMMSS);
            String filepath = FileUtils.getAbsolutePath(FILE_STORE_FOLDER_TEMP);
            OutputStream os = new FileOutputStream(filepath + StndConsIF.FS + filename + ".xlsx", false);
            tpWorkBook.write(os);
            os.close();
            return filename + ".xlsx";
        } catch (FileNotFoundException ex) {
            throw ex;
        }     
    }
}
