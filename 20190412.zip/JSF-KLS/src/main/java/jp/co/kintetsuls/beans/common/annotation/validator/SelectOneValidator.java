/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common.annotation.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.annotation.SelectOne;

/**
 * Select/Auto_Completeの必須選択チェック
 * 
 * @author zf (MBP)
 * @version 2019/3/7 新規作成
 */
public class SelectOneValidator implements ConstraintValidator<SelectOne, AutoCompOptionBean> { 

    @Override
    public void initialize(SelectOne constraintAnnotation) {
    }

    @Override
    public boolean isValid(AutoCompOptionBean value, ConstraintValidatorContext context) {
        return !(value == null);
    }
    
}
