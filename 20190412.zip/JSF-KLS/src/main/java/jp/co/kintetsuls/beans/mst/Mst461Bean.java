/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.KbnBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.beans.common.SystemMasterBean;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst461Form;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.kintetsuls.utils.DateUtils;
import jp.co.kintetsuls.utils.StrUtils;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import lombok.Data;
import org.apache.commons.lang.math.NumberUtils;

/**
 * 営業日カレンダー画面
 *
 * @author 曾鳳 (MBP)
 * @version 2019/4/6 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst461")
@ViewScoped
@Data
public class Mst461Bean extends BaseBean {

    /**
     * タイトル
     */
    private final String TITLE = "営業日カレンダー";

    /**
     * ダウンロードファイル名
     */
    private final static String FILE_NAME = "営業日カレンダー";

    /**
     * 画面URL
     */
    private String url;

    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * ログインユーザー情報
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    /**
     * 共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * システムマスタBean
     */
    @ManagedProperty(value = "#{systemMasterBean}")
    private SystemMasterBean systemMasterBean;

    /**
     * E2コード定義取得Bean
     */
    @ManagedProperty(value = "#{kbnBean}")
    private KbnBean kbnBean;

    /**
     * ファイルダウンロード
     */
    @ManagedProperty(value = "#{fileBean}")
    private FileBean fileBean;

    /**
     * 検索シーケンス処理共通
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;

    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(
            new Object() {}.getClass().getEnclosingClass().getName());

    /**
     * 営業日カレンダー フォーム
     */
    @ManagedProperty(value = "#{mst461Form}")
    private Mst461Form mst461Form;

    /**
     * 定数：画面項目保持キー
     */
    private static final String CONST_MST461_FORM = "mst461Form";
    
    /**
     * 定数：一覧のデータテーブルID
     */
    private static final String DATA_TABLE_ID = "table_mst461";
    
    /**
     * 定数：再検索Button取得キー
     */
    private static final String CONST_MST461_SEARCH = "search_mst461";    
    
    /**
     * コンストラクタ
     */
    public Mst461Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId クリックされたメニューID（メニューからの遷移以外はNULL）
     * @param prevScreen 遷移元の画面
     * @param backFlag 戻るフラグ（前画面へボタンからの遷移以外はFALSE）
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            // パンくず追加
            breadBean.push(TITLE, SCREEN.MST461_SCREEN.name(), this);
            
            // 1)システムマスタ取得
            pageCommonBean.getMasterInfo(MsCnst.SYS_CDGROUP_MST461);
            // ワーク.売上締日
            mst461Form.setUriageShimebi(systemMasterBean.getSysValByCdAndKanriGroup(
                            MsCnst.SYS_CD_URIAGE_SHIMEBI,
                            MsCnst.SYS_CDGROUP_MST461, MsCnst.SYS_CDGROUP_SYSTEM));
            // ワーク.入金締日
            mst461Form.setNyukinShimebi(systemMasterBean.getSysValByCdAndKanriGroup(
                            MsCnst.SYS_CD_NYUKIN_SHIMEBI,
                            MsCnst.SYS_CDGROUP_MST461, MsCnst.SYS_CDGROUP_SYSTEM));
            // ワーク.設定済一覧前
            mst461Form.setSetteisumiIchiranMae(systemMasterBean.getSysValByCdAndKanriGroup(
                            MsCnst.SYS_CD_SETTEISUMI_ICHIRAN_MAE,
                            MsCnst.SYS_CDGROUP_MST461, MsCnst.SYS_CDGROUP_SYSTEM));
            // ワーク.設定済一覧後
            mst461Form.setSetteisumiIchiranUshiro(systemMasterBean.getSysValByCdAndKanriGroup(
                            MsCnst.SYS_CD_SETTEISUMI_ICHIRAN_USHIRO,
                            MsCnst.SYS_CDGROUP_MST461, MsCnst.SYS_CDGROUP_SYSTEM));
            // ワーク.カレンダー警告日数
            mst461Form.setCalendarKeikokuNissu(systemMasterBean.getSysValByCdAndKanriGroup(
                            MsCnst.SYS_CD_CALENDAR_KEIKOKU_NISSU,
                            MsCnst.SYS_CDGROUP_MST461, MsCnst.SYS_CDGROUP_SYSTEM));
            
            // 検索年月 = サーバー日付の年月
            mst461Form.setConKensakuNengetsu(
                    DateUtils.format(DateUtils.getSysDateFromApServer(), StndConsIF.DF_YYYY_MM));
            
            // 検索シーケンス処理を初期化する
            searchHelpBean.regSearchHelp(DATA_TABLE_ID,
                    s -> {return count(false);},
                    s -> {search(); return null;},
                    null);
            searchHelpBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);

            Mst461Form preForm = (Mst461Form) pageCommonBean.getPageInfo(CONST_MST461_FORM);
            // 戻ってきた場合
            if (backFlag) {
                if (preForm != null) {
                    PageCommonBean.simpleCopy(preForm, mst461Form);
                }
                // 再検索を実施する
                pageCommonBean.searchAgain(CONST_MST461_SEARCH);
            } else {
                // 進んできた場合
                // 再検索を実施する
                pageCommonBean.searchAgain(CONST_MST461_SEARCH);
            }

            // ダウンロードシーケンスを初期化する
            fileBean.setDataSize(DATA_TABLE_ID, (id -> {return count(true);}));
            fileBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);
            fileBean.setTilte(FILE_NAME);
            fileBean.regDownloadFucntion(DATA_TABLE_ID, getHeader(), (id -> {return getCalendarList(true);}));
            fileBean.regBeforeDownFucntion(DATA_TABLE_ID, (comment -> {return beforeDown(comment);}));
            fileBean.setSearchResult(DATA_TABLE_ID, (id -> {return getSearchResult();})); 
            fileBean.setSplitButtonSta(false);
            
            // component初期化とユーザ権限により制御を設定する
            pageCommonBean.setAuthControll(mst461Form, Cnst.SCREEN.MST461_SCREEN.name(), true);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * カウント処理
     *
     * @param downloadFlg ダウンロードフラグ
     * @return 件数
     * @throws SystemException
     */
    public long count(boolean downloadFlg) throws SystemException {
        
        // 前回の記録をクリアする
        // カレンダー情報をクリア
        mst461Form.setCalendarList(null);
        mst461Form.setCalendarNoNullList(null);
        // 設定済一覧情報をクリア
        mst461Form.setSetteisumiList(null);

        // 件数取得処理
        long kensu = getKensu(downloadFlg);

        if (!downloadFlg) {

            // 検索部のステータスを変更する
            pageCommonBean.setSerchConDisabled(mst461Form);

            // 検索条件保存
            pageCommonBean.savePageInfo(CONST_MST461_FORM, mst461Form);
        }

        return kensu;
    }

    /**
     * 検索処理
     */
    public void search() {

        // カレンダー情報をクリア
        mst461Form.setCalendarList(null);
        mst461Form.setCalendarNoNullList(null);
        // 設定済一覧情報をクリア
        mst461Form.setSetteisumiList(null);
        // 編集ボタン状態:活性
        mst461Form.setMode(false);

        try {
            // 営業日カレンダー情報取得
            List<Map<String, Object>> result = getCalendarList(false);
            
            if (result != null) {
                // 曜日
                int startYobi = NumberUtils.toInt(DateUtils.getWeekName(
                        DateUtils.parse(result.get(0).get("nengappi").toString(), StndConsIF.DF_YYYYMMDD)));
                // カレンダー情報の先頭空白を追加
                for (int i = 1; i < startYobi; i++) {
                    result.add(0, new HashMap());
                }

                // 曜日
                int endYobi = NumberUtils.toInt(DateUtils.getWeekName(DateUtils.parse(
                        result.get(result.size() - 1).get("nengappi").toString(), StndConsIF.DF_YYYYMMDD)));
                // カレンダー情報の末尾空白を追加
                for (int i = endYobi + 1; i <= 7; i++) {
                    result.add(new HashMap());
                }
            }
            mst461Form.setCalendarList(result);
            
            // 設定済一覧情報
            // パラメータ
            Map<String, Object> params = setSearchParam(false);
            ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, "mst461-search-settei");
            ObjectMapper mapper = new ObjectMapper();
            mst461Form.setSetteisumiList(mapper.readValue(res.getJson(), List.class));
            
            // 検索部のステータス変更
            pageCommonBean.setSerchConDisabled(mst461Form);
        } catch (SystemException | IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }
    
    /**
     * クリア処理
     */
    public void clear() {

        // 検索部の条件をクリア
        // 検索年月 = サーバー日付の年月
        mst461Form.setConKensakuNengetsu(
                DateUtils.format(DateUtils.getSysDateFromApServer(), StndConsIF.DF_YYYY_MM));
        // 編集ボタン状態:活性
        mst461Form.setMode(false);

        // 検索部のステータス変更
        // 条件部を有効化
        pageCommonBean.setSerchConEnabled(mst461Form);
        pageCommonBean.setBtnSearchChangeVisible(false);
        pageCommonBean.setBtnSearchVisible(true);
    }

    /**
     * 検索条件変更処理
     */
    public void searchChange() {

        // 検索部のステータスを変更する
        // 条件部を有効化
        pageCommonBean.setSerchConEnabled(mst461Form);
        // 編集ボタン状態:活性
        mst461Form.setMode(false);
    }
    
    /**
     * 編集ボタン押下処理
     */
    public void changeMode() {
        // 編集ボタン状態:非活性
        mst461Form.setMode(true);
    }
    
    /**
     * 登録申請
     * 
     * @return 遷移先画面のURL
     */
    public String update() {

        // 入力チェック
        if (!updateCheck()) {
            return null;
        }
        
        // 申請処理
        ServiceInterfaceBean res = 
                pageCommonBean.accsessDBWithList(mst461Form.getCalendarList(), "mst461-touroku-shinsei");
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            messagePropertyBean.message(res.getMessages().get(0)[0], res.getMessages().get(0)[1]);
            return null;
        }
        
        // 共通申請(Dem012)への遷移を行う
        url = forward(SCREEN.DEM012_SCREEN.name(), null, SCREEN.MST461_SCREEN.name(), false);
        return url;
    }
    
    /**
     * 承認後処理
     */
    public void shonin() {
        // TODO
        Flash flash = pageCommonBean.getPageParam();
        if (flash != null) {
            // 年月(YYYYMM形式)
            String nengetsu = StrUtils.defaultString(flash.get("nengetsu"));
            // 申請ステータス
            String shinseiStatus = StrUtils.defaultString(flash.get("shinseiStatus"));
            
            // キー情報が存在している場合、承認処理を行う
            if (!CheckUtils.isEmpty(nengetsu) && !CheckUtils.isEmpty(shinseiStatus)) {
                Map<String, Object> params = new HashMap();
                params.put("nengetsu", nengetsu);
                params.put("shinseiStatus", shinseiStatus);
                
                // 承認処理
                pageCommonBean.getDBInfo(params, "mst461-shonin");
            }
        }
    }

    /**
     * 未設定カレンダーチェック処理
     */
    public void misetteiCalendarCheck() {

        // ワーク.カレンダー警告日数
        String calendarKeikokuNissu = mst461Form.getCalendarKeikokuNissu();
        int calendarKeikokuNissuInt = NumberUtils.toInt(calendarKeikokuNissu);
        // サーバー日付の取得を行い、カレンダー警告日数の値を加算する
        Date kensakuTaishoDate = DateUtils.addDays(DateUtils.getSysDateFromApServer(), calendarKeikokuNissuInt);
        // 加算した結果を年月形式に変換する
        String kensakuTaishoNengetsu = DateUtils.format(kensakuTaishoDate, StndConsIF.DF_YYYYMM);

        // パラメータ
        Map<String, Object> params = new HashMap<>();
        params.put("kensakuTaishoNengetsu", kensakuTaishoNengetsu);
        
        try {
            // 設定状況検索
            ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, "mst461-misettei-calendar-check");
            ObjectMapper mapper = new ObjectMapper();
            String result = mapper.readValue(res.getJson(), String.class);

            // 取得件数 = 0の場合
            if (CheckUtils.isEmpty(result)) {
                // アラート表示処理
                // メッセージID:MSTE0113の内容を表示する
                pageCommonBean.executeScript("km.showConfirmDialog('mste0113Dialog')");
            } else {
                // 実行結果.SHONIN_STATUS = "0"
                if (CheckUtils.isEqual("0", result)) {
                    // アラート表示処理
                    // メッセージID:MSTE0113の内容を表示する
                    pageCommonBean.executeScript("km.showConfirmDialog('mste0113Dialog')");
                } else {
                    // 実行結果.SHONIN_STATUS = "1"
                    // 正常終了処理
                    // なし
                }
            }
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }
    
    /**
     * アップロード
     * 
     * @return 遷移先画面のURL
     */
    public String upload() {
        
        // flash初期化
        Flash flash = pageCommonBean.getPageParam();
        
        // flashにアップロード機能コードを設定する
        flash.put("uploadFunctionCd", TITLE);
        
        // アップロード画面へ遷移
        url = forward(SCREEN.UPLOAD_SCREEN.name(), null, SCREEN.MST461_SCREEN.name(), false);
        return url;
    }

    /**
     * CSVファイルのタイトルを設定する処理
     * 
     * @return 画面タイトル
     */
    public List<CSVDto> getHeader() {
       
        // CSVファイルのタイトルを設定する
        List<CSVDto> header = new ArrayList<>();
        header.add(new CSVDto("日付", "nengappi"));
        header.add(new CSVDto("休日", "kyujitsuFlgDl"));
        header.add(new CSVDto("日祝", "nichiShukuDl"));
        header.add(new CSVDto("祝日名称", "listCalendarShukujitsuMeisho"));
        header.add(new CSVDto("入金締日", "nyukinShimebiFlgDl"));
        header.add(new CSVDto("売上締日", "uriageShimebiFlgDl"));
        
        // 取得値を返却する
        return header;
    }
    
    /**
     * ダウンロード理由を記録する処理
     *
     * @param comment 理由コメント
     * @return 正常／異常
     * @throws Exception
     */
    public boolean beforeDown(String comment) throws Exception {
        
        // ダウンロード理由を記録する
        System.out.println(comment);
        
        return true;
    }
    
    /**
     * メニュークリック（処理）
     *
     * @param menuId クリックされたメニューID（メニューからの遷移以外はNULL）
     * @param nextScreen 遷移先の画面
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
   }

    /**
     * パンくずクリック（処理）
     *
     * @param nextScreen 遷移先の画面
     * @param breadIndex 選択されたパンくずのIndex
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        url = forward(nextScreen, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authConfBean.logout();
    }

    /**
     * 検索条件に一致するデータ件数の取得を行う
     * 
     * @param downloadFlg ダウンロードフラグ
     */
    private long getKensu(boolean downloadFlg) throws SystemException {

        // パラメータ
        Map<String, Object> params = setSearchParam(downloadFlg);
        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, "mst461-count-calendar");

        return Long.valueOf(res.getJson());
    }

    /**
     * 検索条件を設定する
     * 
     * @param downloadFlg ダウンロードフラグ
     * @return 検索条件Map
     * @throws SystemException 
     */
    private Map<String, Object> setSearchParam(boolean downloadFlg) throws SystemException {

        Map<String, Object> params = new HashMap<>();
        
        Mst461Form tempForm = mst461Form;
        if (downloadFlg) {
            tempForm = (Mst461Form)pageCommonBean.getPageInfo(CONST_MST461_FORM);
        }
        
        // 検索年月
        params.put("conKensakuNengetsu",
                DateUtils.format(tempForm.getConKensakuNengetsu(), StndConsIF.DF_YYYY_MM, StndConsIF.DF_YYYYMM));
        // ワーク.設定済一覧前
        params.put("setteisumiIchiranMae", tempForm.getSetteisumiIchiranMae());
        // ワーク.設定済一覧後
        params.put("setteisumiIchiranUshiro", tempForm.getSetteisumiIchiranUshiro());
        // ワーク.売上締日
        params.put("uriageShimebi", tempForm.getUriageShimebi());
        // ワーク.入金締日
        params.put("nyukinShimebi", tempForm.getNyukinShimebi());
        // ワーク.設定済区分[0].名称
        params.put("setteisumiKubunMiSettei",
                kbnBean.getKbnsOfGroupCd(MsCnst.SETTEISUMI_KUBUN, "").get(0).getKbnMei());
        return params;
    }
    
    /**
     * 営業日カレンダー情報取得
     * 
     * @param downloadFlg ダウンロードフラグ
     * @return 営業日カレンダー情報
     * @throws SystemException 
     */
    private List<Map<String, Object>> getCalendarList(boolean downloadFlg) throws SystemException {

        // パラメータ
        Map<String, Object> params = setSearchParam(downloadFlg);
        List<Map<String, Object>> calendarNoNullList = new ArrayList();

        try {
            // DBをアクセス
            ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, "mst461-search-calendar");
            ObjectMapper mapper = new ObjectMapper();
            calendarNoNullList = mapper.readValue(res.getJson(), List.class);
            mst461Form.setCalendarNoNullList(mapper.readValue(res.getJson(), List.class));
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
        return calendarNoNullList;
    }

    /**
     * 検索結果を取得する
     * 
     * @return 検索結果
     */
    private List<Map<String, Object>> getSearchResult() {
        return mst461Form.getCalendarNoNullList();
    }

    /**
     * 申請前のチェック処理
     * 
     * @return チェック結果(true:エラーがない、false:エラーがあり)
     */
    private boolean updateCheck() {
        // カレンダー情報
        List<Map<String, Object>> calendarList = mst461Form.getCalendarList();
        // 売上締日フラグ
        int uriageShimebi = 0;
        // 入金締日チェック
        int nyukinShimebi = 0;

        for (Map<String, Object> data : calendarList) {
            // 売上締日フラグが選択されている場合
            if ("true".equals(StrUtils.defaultString(data.get("listCalendarUriageShimebi")))) {
                uriageShimebi++;
            }
            // 入金締日フラグが選択されている場合
            if ("true".equals(StrUtils.defaultString(data.get("listCalendarNyukinShimebi")))) {
                nyukinShimebi++;
            }
        }
        
        // 一つの月に売上締日フラグが選択されている日が存在しない場合
        if (uriageShimebi != 1) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MSTE0038);
            return false;
        }
        
        // 一つの月に入金締日フラグが選択されている日が存在しない場合
        if (nyukinShimebi != 1) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MSTE0039);
            return false;
        }
        return true;
    }
    
}