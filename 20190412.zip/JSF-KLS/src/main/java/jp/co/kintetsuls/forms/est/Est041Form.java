/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.est;

import java.util.List;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.forms.common.LabelValueForm;
import lombok.Data;

/**
 * ロジ料金表メンテナンス フォーム
 *
 * @author 作成者 (MBP)
 * @version 2019/1/29 新規作成
 */
@javax.faces.bean.ManagedBean(name = "est041Form")
@ViewScoped
@Data
public class Est041Form {

     /**
     * 営業所コード
     */
    private String k10;
    /**
     * 営業所名
     */
    private String k11;

    /**
     * 顧客コード
     */
    private String k12;

    /**
     * 顧客名
     */
    private String k13;

    /**
     * 適用開始日
     */
    private String k14;

    /**
     * 上書き
     */
    private String k15;

    /**
     * 申請ステータス
     */
    private String k16;

    /**
     * 適用名
     */
    private String k20;

    /**
     * 値引(割増)/割戻
     */
    private String k21;

    /**
     * 値引　金額・率
     */
    private String k22;

    /**
     * 単位
     */
    private String k23;

    /**
     * 項番
     */
    private String k25;

    /**
     * 選択チェック
     */
    private String k26;

    /**
     * 管理項目1
     */
    private String k27;

    /**
     * 表示名1
     */
    private String k28;

    /**
     * 管理項目2
     */
    private String k29;

    /**
     * 表示名2
     */
    private String k30;

    /**
     * 表示名3
     */
    private String k31;

    /**
     * 表示
     */
    private String k32;

    /**
     * 小計グループ
     */
    private String k33;

    /**
     * 施設
     */
    private String k34;

    /**
     * フロア
     */
    private String k35;

    /**
     * 保管種別
     */
    private String k36;

    /**
     * 実費
     */
    private String k37;

    /**
     * 単価
     */
    private String k38;

    /**
     * 単位
     */
    private String k39;

    /**
     * 小数点
     */
    private String k40;

    /**
     * 値引
     */
    private String k41;

    /**
     * 自動入力
     */
    private String k42;

    /**
     * 上限下限
     */
    private String k43;

    /**
     * 請求書備考
     */
    private String k44;

    /**
     * 入力メモ
     */
    private String k45;

    /**
     * ランク
     */
    private String k46;

    /**
     * 所要時間
     */
    private String k47;

    /**
     * 卸単価
     */
    private String k48;

    /**
     * 卸値率
     */
    private String k49;

    /**
     * 卸値
     */
    private String k50;

    /**
     * 粗利
     */
    private String k51;

    /**
     * 経理科目
     */
    private String k52;

    /**
     * EDI備考
     */
    private String k53;

    /**
     * No
     */
    private String k63;

    /**
     * ロジ元備考
     */
    private String k64;

    /**
     * グルーピング設定
     */
    private String k67;

    /**
     * グループ名
     */
    private String k68;

    /**
     * 小計表示
     */
    private String k69;

    /**
     * 表示設定
     */
    private String k70;

    /**
     * 明細表示
     */
    private String k71;

    /**
     * 小計位置
     */
    private String k72;

    /**
     * 請求書印字イメージ
     */
    private String k73;

    /**
     * 請求項目3
     */
    private String k74;

    /**
     * 単価
     */
    private String k75;

    /**
     * 単位
     */
    private String k76;

    /**
     * 数量
     */
    private String k77;

    /**
     * 金額
     */
    private String k78;

    /**
     * 項目
     */
    private String k82;

    /**
     * 単価
     */
    private String k83;

    /**
     * 単位
     */
    private String k84;

    /**
     * 値引
     */
    private String k85;

    /**
     * 自動入力設定
     */
    private String k86;

    /**
     * 
     */
    private String k87;

    /**
     * 
     */
    private String k88;

    /**
     * 
     */
    private String k89;

    /**
     * 項目
     */
    private String k94;

    /**
     * 単価
     */
    private String k95;

    /**
     * 単位
     */
    private String k96;

    /**
     * 値引
     */
    private String k97;

    /**
     * 数量
     */
    private String k98;

    /**
     * 
     */
    private String k99;

    /**
     * 金額
     */
    private String k100;

    /**
     * 
     */
    private String k101;


}
