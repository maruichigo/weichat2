/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.unc;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.faces.bean.ViewScoped;
import lombok.Data;
import org.primefaces.model.SelectableDataModel;

/**
 *
 * @author wujun
 */
@ViewScoped
@Data
public class Unc021Model implements SelectableDataModel, Serializable{
    /** 営業所コード */
    private String eigyoshoCd;
    /** 営業所名 */
    private String eigyoshoName;
    /** 請求先コード */
    private String seikyusakiCd;
    /** 請求先名 */
    private String seikyusakiName;
    /** 請求書No. */
    private String seikyushoNo;
    /** 締日 */
    private String shiDate;
    /** 請求金額 */
    private BigDecimal seikyuKin;
    /** 入金金額 */
    private BigDecimal nyuKin;
    /** 残高金額 */
    private BigDecimal zankoukuKin;
    /** 入金日 */
    private String nyuKinDate;
    /** 入金方法 */
    private String nyuKinhou;
    /** 条件外 */
    private String jyoukenGai;
    /** 最新入力者 */
    private String lastAuther;

    public String getShiDate() {
        return shiDate;
    }

    public void setShiDate(String shiDate) {
        this.shiDate = shiDate;
    }

    public String getNyuKinDate() {
        return nyuKinDate;
    }

    public void setNyuKinDate(String nyuKinDate) {
        this.nyuKinDate = nyuKinDate;
    }

    public String getEigyoshoCd() {
        return eigyoshoCd;
    }

    public void setEigyoshoCd(String eigyoshoCd) {
        this.eigyoshoCd = eigyoshoCd;
    }

    public String getEigyoshoName() {
        return eigyoshoName;
    }

    public void setEigyoshoName(String eigyoshoName) {
        this.eigyoshoName = eigyoshoName;
    }

    public String getSeikyusakiCd() {
        return seikyusakiCd;
    }

    public void setSeikyusakiCd(String seikyusakiCd) {
        this.seikyusakiCd = seikyusakiCd;
    }

    public String getSeikyusakiName() {
        return seikyusakiName;
    }

    public void setSeikyusakiName(String seikyusakiName) {
        this.seikyusakiName = seikyusakiName;
    }

    public String getSeikyushoNo() {
        return seikyushoNo;
    }

    public void setSeikyushoNo(String seikyushoNo) {
        this.seikyushoNo = seikyushoNo;
    }

    public BigDecimal getSeikyuKin() {
        return seikyuKin;
    }

    public void setSeikyuKin(BigDecimal seikyuKin) {
        this.seikyuKin = seikyuKin;
    }

    public BigDecimal getNyuKin() {
        return nyuKin;
    }

    public void setNyuKin(BigDecimal nyuKin) {
        this.nyuKin = nyuKin;
    }

    public BigDecimal getZankoukuKin() {
        return zankoukuKin;
    }

    public void setZankoukuKin(BigDecimal zankoukuKin) {
        this.zankoukuKin = zankoukuKin;
    }

    public String getNyuKinhou() {
        return nyuKinhou;
    }

    public void setNyuKinhou(String nyuKinhou) {
        this.nyuKinhou = nyuKinhou;
    }

    public String getJyoukenGai() {
        return jyoukenGai;
    }

    public void setJyoukenGai(String jyoukenGai) {
        this.jyoukenGai = jyoukenGai;
    }

    public String getLastAuther() {
        return lastAuther;
    }

    public void setLastAuther(String lastAuther) {
        this.lastAuther = lastAuther;
    }

    @Override
    public Object getRowKey(Object t) {
                return this.eigyoshoCd;
    }

    @Override
    public Object getRowData(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
