/*
 * Copyright (C) 2014 MBP Corporation All Rights Reserved .
 */
package jp.co.kintetsuls.utils;

import jp.co.kintetsuls.cnst.StndConsIF;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import javax.faces.context.FacesContext;
import jp.co.kintetsuls.exception.SystemException;
import org.apache.commons.lang.math.NumberUtils;

import org.apache.commons.lang.time.DurationFormatUtils;

/**
 * 日付に関するユーティリティクラス。
 *
 * @author t.d.m
 */
public final class DateUtils {

    /**
     * 時間計算で端数が発生した場合に切り捨てるモード。
     */
    public static final int ROUND_DOWN = 1;

    /**
     * 時間計算で端数が発生した場合に切り上げるモード。
     */
    public static final int ROUND_UP = 2;

    /**
     * 時間計算で端数が発生した場合にもっとも近い時間に丸めるモード。
     * <p>
     * 両隣りの時間が等距離の場合は切り上げる。
     * </p>
     */
    public static final int ROUND_HALF_UP = 3;

    /**
     * 時間計算で端数が発生した場合にもっとも近い時間に丸めるモード。
     * <p>
     * 両隣りの時間が等距離の場合は切り下げる。
     * </p>
     */
    public static final int ROUND_HALF_DOWN = 4;

    /**
     * 時間計算で端数が発生した場合にもっとも近い時間に丸めるモード。
     * <p>
     * 両隣りの時間が等距離の場合は偶数側に丸める。
     * </p>
     */
    public static final int ROUND_HALF_EVEN = 5;

    /**
     * デフォルトの和暦フォーマット(yyMMdd)
     */
    public static final String DEFAULT_WAREKI_FORMAT = "yyMMdd";

    /**
     * デフォルトの西暦フォーマット(yyyyMMdd)
     */
    public static final String DEFAULT_SEIREKI_FORMAT = "yyyyMMdd";

    /**
     * DateUtils を構築する。
     */
    private DateUtils() {
    }

    /**
     * APサーバーからシステム日付を取得する。
     *
     * @return 現在のシステム日付
     */
    public static Date getSysDateFromApServer() {
        return Calendar.getInstance().getTime();
    }

    /**
     * メモリのシステム運用日を取得する。
     *
     * @return メモリで保存されたシステム運用日
     * @throws SystemException 失敗した場合スロー
     */
    public static Date getSysDate() {
//        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
//        dateFormat.setLenient(false);
//        ParsePosition pos = new ParsePosition(0);
//
//        Date date = dateFormat.parse(System.getProperty("kyotu.system.unyou.date"), pos);

        return Calendar.getInstance().getTime();
    }

    /**
     * 指定された形式の日付時刻文字列を日付型に変換する。
     *
     * @param _text 日付時刻文字列
     * @param _format 日付時刻文字列の形式
     * @param _locale ロカール
     * @return 変換後の日付
     * @throws SystemException 日付時刻文字列の変換に失敗した場合スロー
     */
    public static Date parse(String _text, String _format, Locale _locale) throws SystemException {

        if (CheckUtils.isEmpty(_text) || CheckUtils.isEmpty(_format)) {
            throw new IllegalArgumentException();
        }

        SimpleDateFormat dateFormat = new SimpleDateFormat(_format, _locale);
        dateFormat.setLenient(false);
        ParsePosition pos = new ParsePosition(0);

        Date date = dateFormat.parse(_text, pos);

        if (pos.getErrorIndex() >= 0) {
            // FIXME 
            throw new SystemException(new ParseException("日付時刻文字列(" + _text + ")の日付型変換に失敗しました。" + "形式=" + _format,
                    pos.getErrorIndex()));
        }

        return date;
    }

    /**
     * 指定された形式の日付時刻文字列を日付型に変換する。
     *
     * @param _text 日付時刻文字列
     * @param _format 日付時刻文字列の形式
     * @return 変換後の日付
     * @throws SystemException 日付時刻文字列の変換に失敗した場合スロー
     */
    public static Date parseFixLen(String _text, String _format) throws SystemException {
        _format = StrUtils.left(_format, StrUtils.getStringLength(_text));
        return parse(_text, _format);
    }

    /**
     * 日付型。
     *
     * @param _text 日付時刻文字列
     * @param _format 日付時刻文字列の形式
     * @return
     */
    public static boolean isDate(String _text, String _format) {
        try {
            parse(_text, _format);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    public static Date parse(String _text, String _format) throws SystemException {

        if (CheckUtils.isEmpty(_text) || CheckUtils.isEmpty(_format)) {
            throw new IllegalArgumentException();
        }
        SimpleDateFormat dateFormat = new SimpleDateFormat(_format);
        dateFormat.setLenient(false);
        ParsePosition pos = new ParsePosition(0);

        Date date = dateFormat.parse(_text, pos);

        if (pos.getErrorIndex() >= 0) {

            // FIXME 
            throw new SystemException(new ParseException("日付時刻文字列(" + _text + ")の日付型変換に失敗しました。" + "形式=" + _format,
                    pos.getErrorIndex()));
        }

        return date;
    }

    /**
     * 指定された形式の配列から日付時刻文字列を日付型に変換する。
     * <p>
     * 指定された形式の配列から日付時刻文字列に一致したフォーマットで変換し日付型を返却する。
     * </p>
     *
     * @param _text 日付時刻文字列
     * @param _formats 日付時刻文字列の形式の配列
     * @return 変換後の日付
     * @throws SystemException 日付時刻文字列の変換に失敗した場合スロー
     */
    public static Date parse(String _text, String[] _formats) throws SystemException {
        if (CheckUtils.isEmpty(_text) || _formats == null) {
            throw new IllegalArgumentException();
        }

        SystemException exception = null;
        for (String format : _formats) {
            try {
                return parse(_text, format);
            } catch (SystemException e) {
                exception = e;
            }
        }
        throw exception;
    }

    /**
     * yyyyMMdd形式の日付文字列を日付型に変換する。
     *
     * @param _text yyyyMMdd形式の日付文字列
     * @return 変換後の日付
     * @throws SystemException 変換に失敗した場合スロー
     */
    public static Date parseYMD(String _text) throws SystemException {
        return parse(_text, "yyyyMMdd");
    }

    /**
     * yyyy/MM/dd形式の日付文字列を日付型に変換する。
     *
     * @param _text yyyy/MM/dd形式の日付文字列
     * @return 変換後の日付
     * @throws SystemException 変換に失敗した場合スロー
     */
    public static Date parseFmtYMD(String _text) throws SystemException {
        return parse(_text, "yyyy/MM/dd");
    }

    /**
     * yyyyMMddHHmmss形式の日付文字列を日付型に変換する。
     *
     * @param _text yyyyMMddHHmmss形式の日付文字列
     * @return 変換後の日付
     * @throws SystemException 変換に失敗した場合スロー
     */
    public static Date parseYMDHMS(String _text) throws SystemException {
        return parse(_text, "yyyyMMddHHmmss");
    }

    /**
     * yyyy/MM/dd|HH:mm:ss形式の日付文字列を日付型に変換する。
     *
     * @param _text yyyy/MM/dd|HH:mm:ss形式の日付文字列
     * @return 変換後の日付
     * @throws SystemException 変換に失敗した場合スロー
     */
    public static Date parseImYMDHMS(String _text) throws SystemException {
        return parse(_text, "yyyy/MM/dd|HH:mm:ss");
    }

    /**
     * yyyy/MM/dd HH:mm:ss形式の日付文字列を日付型に変換する。
     *
     * @param _text yyyy/MM/dd HH:mm:ss形式の日付文字列
     * @return 変換後の日付
     * @throws SystemException 変換に失敗した場合スロー
     */
    public static Date parseFmtYMDHMS(String _text) throws SystemException {
        return parse(_text, "yyyy/MM/dd HH:mm:ss");
    }

    /**
     * 日付を指定された形式の日付時刻文字列に変換する。
     *
     * @param _date 日付
     * @param _format 日付時刻文字列の形式
     * @param _locale ロカール
     * @return 変換後の日付時刻文字列
     */
    public static String format(Date _date, String _format, Locale _locale) {
        if (_date == null || CheckUtils.isEmpty(_format)) {
            throw new IllegalArgumentException();
        }

        SimpleDateFormat dateFormat = new SimpleDateFormat(_format, _locale);
        return dateFormat.format(_date);
    }

    /**
     * 日付を指定された形式の日付時刻文字列に変換する。
     *
     * @param _date 日付
     * @param _format 日付時刻文字列の形式
     * @return 変換後の日付時刻文字列
     */
    public static String format(Date _date, String _format) {
        if (_date == null || CheckUtils.isEmpty(_format)) {
            return "";
        }
        FacesContext context = FacesContext.getCurrentInstance();
        Locale _locale = Locale.getDefault();
        if (context != null && context.getViewRoot() != null) {
            _locale = context.getViewRoot().getLocale();

        }
        SimpleDateFormat dateFormat = new SimpleDateFormat(_format, _locale);
        return dateFormat.format(_date);
    }

    /**
     * 日付文字列を指定された日付書式に変換し返却する。
     * <p>
     * 入力値を入力書式で日付変換を行い、出力書式に変換し返却する。
     * </p>
     *
     * @param _text 変換対象の文字列
     * @param _informat 入力値の書式
     * @param _outformat 出力する書式
     * @return 書式変換後の文字列
     * @throws SystemException 変換に失敗した場合スロー
     */
    public static String format(String _text, String _informat, String _outformat) throws SystemException {
        String outDate = "";
        try {
            Date date = parse(_text, _informat);
            outDate = format(date, _outformat);
        } catch (Exception e) {
            outDate = _text;
        }
        return outDate;

    }

    /**
     * 日付文字列を指定された日付書式に変換し返却する。
     * <p>
     * 入力値の書式は複数指定可能、入力値に一致する書式で日付変換を行い、出力書式に変換し返却する。
     * </p>
     *
     * @param _text 変換対象の文字列
     * @param _informat 入力値の書式
     * @param _outformat 出力する書式
     * @return 書式変換後の文字列
     * @throws SystemException 変換に失敗した場合スロー
     */
    public static String format(String _text, String[] _informat, String _outformat) throws SystemException {

        Date date = parse(_text, _informat);
        return format(date, _outformat);

    }

    /**
     * 日付文字列を指定された日付書式に変換し返却する。
     * <p>
     * 入力された日付文字列の書式を出力書式から推測して日付変換を行う。<br>
     * 入力値の入力書式は、以下の書式に限定する。
     * </p>
     *
     * <pre>
     * ・年月日時分秒
     * yyyyMMddHHmmss
     * yyyy/MM/dd|HH:mm:ss
     * yyyy/MM/ddHH:mm:ss
     * yyyy年MM月dd日 HH時mm分ss秒
     * yyyy年MM月dd日HH時mm分ss秒
     *
     * ・年月日時分
     * yyyyMMddHHmm
     * yyyy/MM/dd|HH:mm
     * yyyy/MM/ddHH:mm
     * yyyy年MM月dd日 HH時mm分
     * yyyy年MM月dd日HH時mm分
     *
     * ・年月日時
     * yyyyMMddHH
     * yyyy/MM/dd|HH
     * yyyy/MM/ddHH
     * yyyy年MM月dd日 HH時
     * yyyy年MM月dd日HH時
     *
     * ・年月日
     * yyyyMMdd
     * yyyy/MM/dd
     * yyyy年MM月dd日
     *
     * ・年月
     * yyyyMM
     * yyyy/MM
     * yyyy年MM月
     *
     * ・年
     * yyyy
     * yyyy年
     *
     * ・月日
     * MM/dd
     * MM月dd日
     * MMdd
     *
     * ・月
     * MM
     * MM月
     *
     * ・日
     * dd
     * dd日
     *
     * ・時分秒
     * HHmmss
     * HH:mm:ss
     * HH時mm分ss秒
     *
     * ・時分
     * HHmm
     * HH:mm
     * HH時mm分
     *
     * ・時
     * HH
     * HH時
     *
     * ・分秒
     * mmss
     * mm:ss
     * mm分ss秒
     *
     * ・分
     * mm
     * mm分
     *
     * ・秒
     * ss
     * ss秒
     * </pre>
     *
     * @param _text 変換対象の文字列
     * @param _outformat 出力する書式
     * @return 書式変換後の文字列
     * @throws SystemException 変換に失敗した場合スロー
     */
    public static String format(String _text, String _outformat) throws SystemException {

        List<String> patterns = new LinkedList<String>();

        boolean isexists = false;

        // 長いフォーマットのパターンから設定していく
        // 年月日時分秒
        patterns.add("yyyyMMddHHmmss");
        patterns.add("yyyy/MM/dd|HH:mm:ss");
        patterns.add("yyyy/MM/dd HH:mm:ss");
        patterns.add("yyyy年MM月dd日 HH時mm分ss秒");
        patterns.add("yyyy年MM月dd日HH時mm分ss秒");
        isexists = patterns.contains(_outformat);

        // 年月日時分
        if (!isexists) {
            patterns.add("yyyyMMddHHmm");
            patterns.add("yyyy/MM/dd|HH:mm");
            patterns.add("yyyy/MM/dd HH:mm");
            patterns.add("yyyy年MM月dd日 HH時mm分");
            patterns.add("yyyy年MM月dd日HH時mm分");
            isexists = patterns.contains(_outformat);
        }

        // 年月日時
        if (!isexists) {
            patterns.add("yyyyMMddHH");
            patterns.add("yyyy/MM/dd|HH");
            patterns.add("yyyy/MM/dd HH");
            patterns.add("yyyy年MM月dd日 HH時");
            patterns.add("yyyy年MM月dd日HH時");
            isexists = patterns.contains(_outformat);
        }

        if (!isexists) {
            if (_outformat.startsWith("y")) {
                // 年月日
                patterns.add("yyyyMMdd");
                patterns.add("yyyy/MM/dd");
                patterns.add("yyyy年MM月dd日");
                isexists = patterns.contains(_outformat);

                // 年月
                if (!isexists) {
                    patterns.add("yyyyMM");
                    patterns.add("yyyy/MM");
                    patterns.add("yyyy年MM月");
                    isexists = patterns.contains(_outformat);
                }

                // 年
                if (!isexists) {
                    patterns.add("yyyy");
                    patterns.add("yyyy年");
                    isexists = patterns.contains(_outformat);
                }
            }
        }

        if (!isexists) {
            if (_outformat.startsWith("M")) {
                // 月日
                patterns.add("MM/dd");
                patterns.add("MM月dd日");
                patterns.add("MMdd");
                isexists = patterns.contains(_outformat);

                // 月
                if (!isexists) {
                    patterns.add("MM");
                    patterns.add("MM月");
                    isexists = patterns.contains(_outformat);
                }
            }
        }

        // 日
        if (!isexists) {
            if (_outformat.startsWith("d")) {
                patterns.add("dd");
                patterns.add("dd日");
                isexists = patterns.contains(_outformat);
            }
        }

        if (!isexists) {
            if (_outformat.startsWith("H")) {
                // 時分秒
                patterns.add("HHmmss");
                patterns.add("HH:mm:ss");
                patterns.add("HH時mm分ss秒");
                isexists = patterns.contains(_outformat);

                // 時分
                if (!isexists) {
                    patterns.add("HHmm");
                    patterns.add("HH:mm");
                    patterns.add("HH時mm分");
                    isexists = patterns.contains(_outformat);
                }

                // 時
                if (!isexists) {
                    patterns.add("HH");
                    patterns.add("HH時");
                    isexists = patterns.contains(_outformat);
                }
            }
        }

        if (!isexists) {
            if (_outformat.startsWith("m")) {
                // 分秒
                patterns.add("mmss");
                patterns.add("mm:ss");
                patterns.add("mm分ss秒");
                isexists = patterns.contains(_outformat);

                // 分
                if (!isexists) {
                    patterns.add("mm");
                    patterns.add("mm分");
                    isexists = patterns.contains(_outformat);
                }
            }
        }

        if (!isexists) {
            if (_outformat.startsWith("s")) {
                // 秒
                if (!isexists) {
                    patterns.add("ss");
                    patterns.add("ss秒");
                    isexists = patterns.contains(_outformat);
                }
            }
        }

        if (!isexists) {
            // それでもなかったら、変換フォーマットを追加
            patterns.add(_outformat);
        }

        String[] pattern = patterns.toArray(new String[patterns.size()]);
        return format(_text, pattern, _outformat);
    }

    /**
     * 年数を加算後の日付を取得する。
     *
     * @param _date 計算対象の日付
     * @param _amount 加算する年数
     * @return 日付に年数を加算した結果の日付
     */
    public static Date addYears(Date _date, int _amount) {
        return org.apache.commons.lang.time.DateUtils.addYears(_date, _amount);
    }

    /**
     * 月数を加算後の日付を取得する。
     * <p>
     * addMonths(2008/01/30, 2) = 2008/03/30<br>
     * addMonths(2008/01/30, 1) = 2008/02/29<br>
     * addMonths(2008/03/30, -1) = 2008/02/29
     * </p>
     *
     * @param _date 計算対象の日付
     * @param _amount 加算する月数
     * @return 日付に月数を加算した結果の日付
     */
    public static Date addMonths(Date _date, int _amount) {
        return org.apache.commons.lang.time.DateUtils.addMonths(_date, _amount);
    }

    /**
     * 週数を加算後の日付を取得する。
     *
     * @param _date 計算対象の日付
     * @param _amount 加算する週数
     * @return 日付に週数を加算した結果の日付
     */
    public static Date addWeeks(Date _date, int _amount) {
        return org.apache.commons.lang.time.DateUtils.addWeeks(_date, _amount);
    }

    /**
     * 日数を加算後の日付を取得する。
     *
     * @param _date 計算対象の日付
     * @param _amount 加算する日数
     * @return 日付に日数を加算した結果の日付
     */
    public static Date addDays(Date _date, int _amount) {
        return org.apache.commons.lang.time.DateUtils.addDays(_date, _amount);
    }

    /**
     * 時間数を加算後の日付を取得する。
     *
     * @param _date 計算対象の日付
     * @param _amount 加算する時間数
     * @return 日付に時間数を加算した結果の日付
     */
    public static Date addHours(Date _date, int _amount) {
        return org.apache.commons.lang.time.DateUtils.addHours(_date, _amount);
    }

    /**
     * 分数を加算後の日付を取得する。
     *
     * @param _date 計算対象の日付
     * @param _amount 加算する分数
     * @return 日付に分数を加算した結果の日付
     */
    public static Date addMinutes(Date _date, int _amount) {
        return org.apache.commons.lang.time.DateUtils.addMinutes(_date, _amount);
    }

    /**
     * 秒数を加算後の日付を取得する。
     *
     * @param _date 計算対象の日付
     * @param _amount 加算する秒数
     * @return 日付に秒数を加算した結果の日付
     */
    public static Date addSeconds(Date _date, int _amount) {
        return org.apache.commons.lang.time.DateUtils.addSeconds(_date, _amount);
    }

    /**
     * 指定された単位で日時を切捨てる
     *
     * @param _date 計算対象の日付
     * @param _amount 単位
     * @return 結果の日付
     */
    public static Date truncate(Date _date, int _amount) {
        return org.apache.commons.lang.time.DateUtils.truncate(_date, _amount);
    }

    // 日付の差を取得する
    /**
     * 開始から終了の時間の差を年数で取得する。
     * <p>
     * 開始から終了の時間の差を年数で取得する。<br>
     * 端数は切り捨てる。
     * </p>
     *
     * @param _startDate 開始日時
     * @param _endDate 終了日時
     * @return 年数
     */
    public static int pireodYears(Date _startDate, Date _endDate) {
        return pireodAge(_startDate, _endDate);
        // return pireodYears(_startDate, _endDate, ROUND_DOWN);
    }

    /**
     * 開始から終了の時間の差を年数で取得する。
     * <p>
     * 端数処理（丸め）は以下を対象とし丸めモードに指定する。丸め幅は対応しない。
     * <ul>
     * <li>切り捨て({@link DateUtils#ROUND_DOWN})</li>
     * <li>切り上げ({@link DateUtils#ROUND_UP})</li>
     * <li>近い方へ丸める({@link DateUtils#ROUND_HALF_UP})</li>
     * <li>近い偶数へ丸める({@link DateUtils#ROUND_HALF_EVEN})</li>
     * </ul>
     * </p>
     *
     * @param _startDate 開始日時
     * @param _endDate 終了日時
     * @param _roundMode 丸めモード
     * @return 年数
     */
    // public static int pireodYears(Date _startDate, Date _endDate, int _roundMode) {
    //
    // if (_startDate == null || _endDate == null) {
    // throw new IllegalArgumentException();
    // }
    //
    // Date sdate = null;
    // Date edate = null;
    //
    // if (_startDate.after(_endDate)) {
    // sdate = _endDate;
    // edate = _startDate;
    // } else {
    // sdate = _startDate;
    // edate = _endDate;
    // }
    //
    // String diffYears = DurationFormatUtils.formatPeriod(sdate.getTime(), edate.getTime(), "y");
    //
    // int pireod = new Integer(diffYears).intValue();
    //
    // long months = pireodMonths(addYears(sdate, pireod), edate, ROUND_UP);
    //
    // if (months > 0) {
    // switch (_roundMode) {
    // case ROUND_UP:
    // pireod++;
    // break;
    // case ROUND_HALF_DOWN:
    // case ROUND_HALF_UP:
    // if (months > 6) {
    // pireod++;
    // }
    // break;
    // case ROUND_HALF_EVEN:
    // if (CheckUtils.isEven(pireod + 1)) {
    // pireod++;
    // }
    // break;
    // default:
    // break;
    // }
    // }
    //
    // return pireod;
    // }
    /**
     * 開始年月と終了年月により期間年数を算出する。(NEW)
     *
     * @param _startYM 開始年月（西暦）
     * @param _endYM 終了年月（西暦）
     * @return 年数
     */
    public static int pireodYears(String _startYM, String _endYM) throws SystemException {
        Date startDate = parseYMD(_startYM + "01");
        Date endDate = parseYMD(_endYM + "01");
        if (startDate.after(endDate)) {
            throw new IllegalArgumentException();
        }
        int pireod = pireodYears(startDate, endDate) + 1;
        if (pireod > 99) {
            throw new IllegalArgumentException();
        }
        return pireod;
    }

    /**
     * 開始から終了の時間の差を月数で取得する。
     * <p>
     * 端数は切り捨てる。
     * </p>
     *
     * @param _startDate 開始日時
     * @param _endDate 終了日時
     * @return 月数
     */
    public static int pireodMonths(Date _startDate, Date _endDate) {
        return pireodMonths(_startDate, _endDate, ROUND_DOWN);
    }

    /**
     * 開始から終了の時間の差を月数で取得する。
     * <p>
     * 端数処理（丸め）は以下を対象とし丸めモードに指定する。丸め幅は対応しない。
     * <ul>
     * <li>切り捨て({@link DateUtils#ROUND_DOWN})</li>
     * <li>切り上げ({@link DateUtils#ROUND_UP})</li>
     * <li>近い方へ丸める({@link DateUtils#ROUND_HALF_UP})</li>
     * <li>近い偶数へ丸める({@link DateUtils#ROUND_HALF_EVEN})</li>
     * </ul>
     * </p>
     *
     * @param _startDate 開始日時
     * @param _endDate 終了日時
     * @param _roundMode 丸めモード
     * @return 月数
     * @since 1.0
     */
    public static int pireodMonths(Date _startDate, Date _endDate, int _roundMode) {

        if (_startDate == null || _endDate == null) {
            throw new IllegalArgumentException();
        }

        Date sdate = null;
        Date edate = null;

        if (_startDate.after(_endDate)) {
            sdate = _endDate;
            edate = _startDate;
        } else {
            sdate = _startDate;
            edate = _endDate;
        }

        String diffMonths = DurationFormatUtils.formatPeriod(sdate.getTime(), edate.getTime(), "M");

        int pireod = new Integer(diffMonths).intValue();

        long days = pireodDays(addMonths(sdate, pireod), edate, ROUND_UP);

        if (days > 0) {
            switch (_roundMode) {
                case ROUND_UP:
                    pireod++;
                    break;
                case ROUND_HALF_DOWN:
                case ROUND_HALF_UP:
                    if (days > 15) {
                        pireod++;
                    }
                    break;
                case ROUND_HALF_EVEN:
                    if (CheckUtils.isEven(pireod + 1)) {
                        pireod++;
                    }
                    break;
                default:
                    break;
            }
        }

        return pireod;
    }

    /**
     * 開始から終了の時間の差を日数で取得する。
     * <p>
     * 端数は切り捨てる。
     * </p>
     *
     * @param _startDate 開始日時
     * @param _endDate 終了日時
     * @return 日数
     */
    public static int pireodDays(Date _startDate, Date _endDate) {
        return pireodDays(_startDate, _endDate, ROUND_DOWN);
    }

    /**
     * 開始から終了の時間の差を日数で取得する。
     * <p>
     * 端数処理（丸め）は以下を対象とし丸めモードに指定する。丸め幅は対応しない。
     * <ul>
     * <li>切り捨て({@link DateUtils#ROUND_DOWN})</li>
     * <li>切り上げ({@link DateUtils#ROUND_UP})</li>
     * <li>近い方へ丸める、真ん中は切り上げ({@link DateUtils#ROUND_HALF_UP})</li>
     * <li>近い方へ丸める、真ん中は切り下げ({@link DateUtils#ROUND_HALF_DOWN})</li>
     * <li>近い偶数へ丸める({@link DateUtils#ROUND_HALF_EVEN})</li>
     * </ul>
     * </p>
     *
     * @param _startDate 開始日時
     * @param _endDate 終了日時
     * @param _roundMode 丸めモード
     * @return 日数
     */
    public static int pireodDays(Date _startDate, Date _endDate, int _roundMode) {

        if (_startDate == null || _endDate == null) {
            throw new IllegalArgumentException();
        }

        Date sdate = null;
        Date edate = null;

        if (_startDate.after(_endDate)) {
            sdate = _endDate;
            edate = _startDate;
        } else {
            sdate = _startDate;
            edate = _endDate;
        }

        String diffDays = DurationFormatUtils.formatPeriod(sdate.getTime(), edate.getTime(), "d");

        int pireod = new Integer(diffDays).intValue();

        long hours = pireodHours(addDays(sdate, pireod), edate, ROUND_UP);

        if (hours > 0) {
            switch (_roundMode) {
                case ROUND_UP:
                    pireod++;
                    break;
                case ROUND_HALF_DOWN:
                    if (hours > 12) {
                        pireod++;
                    }
                    break;
                case ROUND_HALF_UP:
                    if (hours >= 12) {
                        pireod++;
                    }
                    break;
                case ROUND_HALF_EVEN:
                    if (CheckUtils.isEven(pireod + 1)) {
                        pireod++;
                    }
                    break;
                default:
                    break;
            }
        }

        return pireod;
    }

    /**
     * 開始から終了の時間の差を時間数で取得する。
     * <p>
     * 端数は切り捨てる。
     * </p>
     *
     * @param _startDate 開始日時
     * @param _endDate 終了日時
     * @return 時間数
     */
    public static long pireodHours(Date _startDate, Date _endDate) {
        return pireodHours(_startDate, _endDate, ROUND_DOWN);
    }

    /**
     * 開始から終了の時間の差を時間数で取得する。
     * <p>
     * 端数処理（丸め）は以下を対象とし丸めモードに指定する。丸め幅は対応しない。
     * <ul>
     * <li>切り捨て({@link DateUtils#ROUND_DOWN})</li>
     * <li>切り上げ({@link DateUtils#ROUND_UP})</li>
     * <li>近い方へ丸める、真ん中は切り上げ({@link DateUtils#ROUND_HALF_UP})</li>
     * <li>近い方へ丸める、真ん中は切り下げ({@link DateUtils#ROUND_HALF_DOWN})</li>
     * <li>近い偶数へ丸める({@link DateUtils#ROUND_HALF_EVEN})</li>
     * </ul>
     * </p>
     *
     * @param _startDate 開始日時
     * @param _endDate 終了日時
     * @param _roundMode 丸めモード
     * @return 時間数
     * @since 1.0
     */
    public static long pireodHours(Date _startDate, Date _endDate, int _roundMode) {

        if (_startDate == null || _endDate == null) {
            throw new IllegalArgumentException();
        }

        Date sdate = null;
        Date edate = null;

        if (_startDate.after(_endDate)) {
            sdate = _endDate;
            edate = _startDate;
        } else {
            sdate = _startDate;
            edate = _endDate;
        }

        String diffHours = DurationFormatUtils.formatPeriod(sdate.getTime(), edate.getTime(), "H");

        long pireod = new Long(diffHours).longValue();

        long minutes = pireodMinutes(addHours(sdate, (int) pireod), edate, ROUND_UP);

        if (minutes > 0) {
            switch (_roundMode) {
                case ROUND_UP:
                    pireod++;
                    break;
                case ROUND_HALF_DOWN:
                    if (minutes > 30) {
                        pireod++;
                    }
                    break;
                case ROUND_HALF_UP:
                    if (minutes >= 30) {
                        pireod++;
                    }
                    break;
                case ROUND_HALF_EVEN:
                    if (CheckUtils.isEven((int) pireod + 1)) {
                        pireod++;
                    }
                    break;
                default:
                    break;
            }
        }

        return pireod;
    }

    /**
     * 開始から終了の時間の差を分数で取得する。
     * <p>
     * 端数は切り捨てる。
     * </p>
     *
     * @param _startDate 開始日時
     * @param _endDate 終了日時
     * @return 分数
     */
    public static long pireodMinutes(Date _startDate, Date _endDate) {
        return pireodMinutes(_startDate, _endDate, ROUND_DOWN);
    }

    /**
     * 開始から終了の時間の差を分数で取得する。
     * <p>
     * 端数処理（丸め）は以下を対象とし丸めモードに指定する。丸め幅は対応しない。
     * <ul>
     * <li>切り捨て({@link DateUtils#ROUND_DOWN})</li>
     * <li>切り上げ({@link DateUtils#ROUND_UP})</li>
     * <li>近い方へ丸める、真ん中は切り上げ({@link DateUtils#ROUND_HALF_UP})</li>
     * <li>近い方へ丸める、真ん中は切り下げ({@link DateUtils#ROUND_HALF_DOWN})</li>
     * <li>近い偶数へ丸める({@link DateUtils#ROUND_HALF_EVEN})</li>
     * </ul>
     * </p>
     *
     * @param _startDate 開始日時
     * @param _endDate 終了日時
     * @param _roundMode 丸めモード
     * @return 分数
     * @since 1.0
     */
    public static long pireodMinutes(Date _startDate, Date _endDate, int _roundMode) {

        if (_startDate == null || _endDate == null) {
            throw new IllegalArgumentException();
        }

        Date sdate = null;
        Date edate = null;

        if (_startDate.after(_endDate)) {
            sdate = _endDate;
            edate = _startDate;
        } else {
            sdate = _startDate;
            edate = _endDate;
        }

        String diffMinutes = DurationFormatUtils.formatPeriod(sdate.getTime(), edate.getTime(), "m");

        long pireod = new Long(diffMinutes).longValue();

        long seconds = pireodSeconds(addMinutes(sdate, (int) pireod), edate);

        if (seconds > 0) {
            switch (_roundMode) {
                case ROUND_UP:
                    pireod++;
                    break;
                case ROUND_HALF_DOWN:
                    if (seconds > 30) {
                        pireod++;
                    }
                    break;
                case ROUND_HALF_UP:
                    if (seconds >= 30) {
                        pireod++;
                    }
                    break;
                case ROUND_HALF_EVEN:
                    if (CheckUtils.isEven((int) pireod + 1)) {
                        pireod++;
                    }
                    break;
                default:
                    break;
            }
        }

        return pireod;
    }

    /**
     * 開始から終了の時間の差を秒数で取得する。
     *
     * @param _startDate 開始日時
     * @param _endDate 終了日時
     * @return 秒数
     */
    public static long pireodSeconds(Date _startDate, Date _endDate) {

        if (_startDate == null || _endDate == null) {
            throw new IllegalArgumentException();
        }

        Date sdate = null;
        Date edate = null;

        if (_startDate.after(_endDate)) {
            sdate = _endDate;
            edate = _startDate;
        } else {
            sdate = _startDate;
            edate = _endDate;
        }

        String diffSeconds = DurationFormatUtils.formatPeriod(sdate.getTime(), edate.getTime(), "s");

        long pireod = new Long(diffSeconds).longValue();

        return pireod;
    }

    /**
     * 開始から終了の時間の差を指定した書式で取得する。
     *
     * @param _startMillis 開始ミリ秒
     * @param _endMillis 終了ミリ秒
     * @param _format 取得する文字列書式
     * @return 経過時間
     */
    public static String pireod(long _startMillis, long _endMillis, String _format) {
        return DurationFormatUtils.formatPeriod(_startMillis, _endMillis, _format);
    }

    /**
     * 指定された日付の月末日を取得する。
     *
     * @param _date 日付
     * @return 月末日
     */
    public static Date getMonthEndDay(Date _date) {

        if (_date == null) {
            throw new IllegalArgumentException();
        }

        Calendar calendar = Calendar.getInstance();

        calendar.setTime(_date);
        int monthEndDay = calendar.getActualMaximum(Calendar.DATE);
        calendar.set(Calendar.DATE, monthEndDay);

        return calendar.getTime();
    }

    /**
     * 指定された値にintra-mart標準に準拠した開始時間を付与する
     *
     * @param _value 指定日付
     * @return String 指定日付+"|00:00:00"
     */
    public static String addIntramartStart(String _value) {

        StringBuilder builder = new StringBuilder();

        builder.append(_value);
        builder.append("|00:00:00");

        return builder.toString();
    }

    /**
     * 指定された値にintra-mart標準に準拠した終了時間を付与する
     *
     * @param _value 指定日付
     * @return String 指定日付+"|23:59:59"
     */
    public static String addIntramartEnd(String _value) {

        StringBuilder builder = new StringBuilder();

        builder.append(_value);
        builder.append("|23:59:59");

        return builder.toString();
    }

    /**
     * 和暦日付の妥当性チェックを行います
     *
     * @param eraCode 元号
     * @param year 年
     * @param month 月
     * @param day 日
     * @return チェック結果
     * @throws SystemException
     */
    public static boolean validateWareki(String eraCode, String year, String month, String day) {
        if (CheckUtils.isEmpty(eraCode) || CheckUtils.isEmpty(year) || CheckUtils.isEmpty(month)
                || CheckUtils.isEmpty(day)) {
            return false;
        }
        if (!CheckUtils.isNumber(eraCode) || !CheckUtils.isNumber(year) || !CheckUtils.isNumber(month)
                || !CheckUtils.isNumber(day)) {
            return false;
        }

        return ImperialCalendar.isWarekiDate(eraCode, NumberUtils.toInt(year), NumberUtils.toInt(month),
                NumberUtils.toInt(day), ImperialCalendar.WAREKI_MODE.YMD);
    }

    /**
     * 和暦日付の妥当性チェックを行います
     *
     * @param eraCode 年号のコード値
     * @param year 和暦年
     * @param month 和暦月
     * @return チェック結果
     * @throws SystemException
     */
    public static boolean validateWareki(String eraCode, String year, String month) throws SystemException {
        if (CheckUtils.isEmpty(eraCode) || CheckUtils.isEmpty(year) || CheckUtils.isEmpty(month)) {
            return false;
        }
        if (!CheckUtils.isNumber(eraCode) || !CheckUtils.isNumber(year) || !CheckUtils.isNumber(month)) {
            return false;
        }
        return ImperialCalendar.isWarekiDate(eraCode, year, month);
    }

    /**
     * 和暦日付の妥当性チェックを行います
     *
     * @param eraCode 年号のコード値
     * @param year 和暦年
     * @return チェック結果
     * @throws SystemException
     */
    public static boolean validateWareki(String eraCode, String year) throws SystemException {
        if (CheckUtils.isEmpty(eraCode) || CheckUtils.isEmpty(year)) {
            return false;
        }
        if (!CheckUtils.isNumber(eraCode) || !CheckUtils.isNumber(year)) {
            return false;
        }
        return ImperialCalendar.isWarekiDate(eraCode, year);
    }

    /**
     * <p>
     * 元号コードと和暦文字列から、<code>Date</code>を生成します
     * </p>
     * 和暦文字列は、"yyMMdd"形式である必要があります。
     *
     * @param eraCode 元号
     * @param year 和暦年
     * @param month 和暦月
     * @param day 和暦日
     * @return <code>Date</code>
     * @throws SystemException
     */
    public static Date warekiToDate(String eraCode, String year, String month, String day) throws SystemException {
        if (!validateWareki(eraCode, year, month, day)) {
            throw new SystemException("和暦日付時刻文字列(" + eraCode + year + month + day + ")の日付型変換に失敗しました。");
        }
        ImperialCalendar impCal = new ImperialCalendar(eraCode, converterWareki(year, month, day));
        return impCal.getDate();
    }

    /**
     * 取得される和暦文字列のフォーマットは"yyMMdd"になります。
     *
     * @param warekiYear 和暦・年文字列
     * @param warekiMonth 和暦・月文字列
     * @param warekiDay 和暦。日文字列
     * @return 和暦文字列
     * @throws SystemException
     */
    public static String converterWareki(String warekiYear, String warekiMonth, String warekiDay) {
        StringBuffer Buffer_ = new StringBuffer();

        Buffer_.append(StrUtils.leftPad(String.valueOf(NumberUtils.toInt(warekiYear)), 2, "0"));
        Buffer_.append(StrUtils.leftPad(String.valueOf(NumberUtils.toInt(warekiMonth)), 2, "0"));
        Buffer_.append(StrUtils.leftPad(String.valueOf(NumberUtils.toInt(warekiDay)), 2, "0"));

        return Buffer_.toString();
    }

    /**
     * 西暦から、その年の年号のコード値を取得します。
     * 引数として指定する西暦のフォーマットは{@link #DEFAULT_SEIREKI_FORMAT}であるものとして処理されます。
     *
     * @param seireki 西暦文字列
     * @return 該当する年号のコード値
     * @throws SystemException
     * @see ImperialCalendar#format(String)
     */
    public static String getEraCode(String seireki, ImperialCalendar.WAREKI_MODE mode) throws SystemException {
        return getEraCode(seireki, DEFAULT_SEIREKI_FORMAT, mode);
    }

    /**
     * 西暦から、その年の和暦のコード値を取得する
     * <p>
     * 例
     * </p>
     * <ul>
     * <li>DateUtil.getEraCode("20121201","yyyyMMdd", WAREKI_MODE.YMD); ⇒
     * "19801101"</li>
     *
     * @param seireki 西暦文字列
     * @param format 西暦文字列の書式
     * @return 指定された年月日に対応する年号のコード値
     * @throws SystemException
     * @see ImperialCalendar#format(String)
     */
    public static String getEraCode(String seireki, String format, ImperialCalendar.WAREKI_MODE mode)
            throws SystemException {

        // 西暦文字列が空白かNullの場合は空白文字列を返す
        if (CheckUtils.isEmpty(seireki)) {
            return StrUtils.EMPTY;
        }

        return getEraCode(DateUtils.parse(seireki, new String[]{format}), mode);
    }

    /**
     * <code>Date</code>から、その年の和暦のコード値を取得する
     *
     * @param date Date
     * @return 指定された年月日に対応する年号のコード値
     * @throws SystemException
     * @see ImperialCalendar#format(String)
     */
    public static String getEraCode(Date date, ImperialCalendar.WAREKI_MODE mode) throws SystemException {
        Date tmp = date;

        // 年月モードでの判定だった場合、月末日での判定とする
        if (mode == ImperialCalendar.WAREKI_MODE.YM) {
            tmp = DateUtils.addDays(
                    org.apache.commons.lang.time.DateUtils.truncate(DateUtils.addMonths(date, 1), Calendar.MONTH), -1);
        }

        ImperialCalendar impCal = new ImperialCalendar(tmp);
        return impCal.getEraCode();
    }

    /**
     * <p>
     * 元号コードと和暦文字列から、西暦文字列を生成します。
     * </p>
     * 和暦文字列は、"yyMMdd"形式である必要があります。
     * <p>
     * 例
     * </p>
     * <ul>
     * <li>DateUtil.getWarekiString("4", "25","12","1","yyyyMMdd"); ⇒
     * "19801101"</li>
     * </ul>
     *
     * @param eraCode 元号コード
     * @param year 和暦年
     * @param month 和暦月
     * @param day 和暦日
     * @param format 取得する西暦のフォーマット
     * @return 西暦文字列
     * @throws SystemException
     */
    public static String warekiToSeireki(String eraCode, String year, String month, String day, String format)
            throws SystemException {

        // 和暦文字列の妥当性チェック
        if (!validateWareki(eraCode, year, month, day)) {
            throw new SystemException("和暦日付時刻文字列(" + eraCode + year + month + day + ")の日付型変換に失敗しました。");
        }

        SimpleDateFormat sdf = new SimpleDateFormat(format);
        return sdf.format(warekiToDate(eraCode, year, month, day));
    }

    /**
     * <p>
     * 元号コードと和暦文字列から、西暦文字列を生成します。
     * </p>
     * 和暦文字列は、"yyMMdd"形式である必要があります。
     * <p>
     * 例
     * </p>
     * <ul>
     * <li>DateUtil.getWarekiString("4", "25","12","1"); ⇒ "19801101"</li>
     * </ul>
     *
     * @param eraCode 元号コード
     * @param year 和暦年
     * @param month 和暦月
     * @param day 和暦日
     * @return 西暦文字列
     * @throws SystemException
     */
    public static String warekiToSeireki(String eraCode, String year, String month, String day) throws SystemException {

        // 和暦文字列の妥当性チェック
        if (!validateWareki(eraCode, year, month, day)) {
            throw new SystemException("和暦日付時刻文字列(" + eraCode + year + month + day + ")の日付型変換に失敗しました。");
        }

        SimpleDateFormat sdf = new SimpleDateFormat(DEFAULT_SEIREKI_FORMAT);
        return sdf.format(warekiToDate(eraCode, year, month, day));
    }

    /**
     * 和暦から西暦に変更する
     *
     * @param _era 元号
     * @param _year 年
     * @return
     * @throws SystemException 例外が発生した
     */
    public static String warekiToSeireki(String _era, String _year) throws SystemException {
        return ImperialCalendar.wareki_to_seireki(_era, _year);
    }

    /**
     * 和暦から西暦に変更する
     *
     * @param _era 元号
     * @param _year 年
     * @param _month 月
     * @return
     * @throws SystemException 例外が発生した
     */
    public static String warekiToSeireki(String _era, String _year, String _month) throws SystemException {
        return ImperialCalendar.wareki_to_seireki(_era, _year, _month);
    }

    /**
     * 和暦から西暦年度に変更する
     *
     * @param _era 元号
     * @param _year 年
     * @param _month 月
     * @return
     * @throws SystemException 例外が発生した
     */
    // public static String warekiToNendo(String _era, String _year, String _month) throws SystemException {
    // return ImperialCalendar.wareki_to_nendo(_era, _year, _month);
    // }
    /**
     * <p>
     * 指定した西暦文字列から和暦文字列を取得します
     * </p>
     *
     * @param seireki 西暦文字列
     * @param seirekiFormat 西暦のフォーマット
     * @return 指定和暦のフォーマット形式の和暦文字列
     * @throws SystemException
     */
    public static String[] getWarekiArrayInput(String seireki, String seirekiFormat) throws SystemException {
        if (CheckUtils.isEqual(seirekiFormat, "yyyy") || CheckUtils.isEqual(seirekiFormat, "yyyyMM")) {
            return ImperialCalendar.seireki_to_wareki_array_input(seireki);
        } else {
            Date date = DateUtils.parse(seireki, new String[]{seirekiFormat});
            ImperialCalendar impCal = new ImperialCalendar(date);
            return impCal.format_array_input("yy.MM.dd").split("\\.");
        }
    }

    /**
     * <p>
     * 指定した西暦文字列から和暦文字列を取得します
     * </p>
     *
     * @param seireki 西暦文字列
     * @param seirekiFormat 西暦のフォーマット
     * @return 指定和暦のフォーマット形式の和暦文字列
     * @throws SystemException
     */
    public static String[] getWarekiArray(String seireki, String seirekiFormat) throws SystemException {
        if (CheckUtils.isEqual(seirekiFormat, "yyyy") || CheckUtils.isEqual(seirekiFormat, "yyyyMM")) {
            return ImperialCalendar.seireki_to_wareki_array(seireki);
        } else {
            Date date = DateUtils.parse(seireki, new String[]{seirekiFormat});
            ImperialCalendar impCal = new ImperialCalendar(date);
            return impCal.format_array("yy.MM.dd").split("\\.");
        }
    }

    /**
     * 西暦から和暦に変更する
     *
     * @param _date 西暦 (例：2011又は201108)
     * @return
     * @throws SystemException 例外が発生した
     */
    public static String seirekiToWareki(String _date) throws SystemException {
        return ImperialCalendar.seireki_to_wareki(_date);
    }

    /**
     * <p>
     * 指定した西暦文字列から和暦文字列を取得します
     * </p>
     *
     * @param seireki 西暦文字列
     * @param seirekiFormat 西暦のフォーマット
     * @param warekiFormat 和暦のフォーマット
     * @return 指定和暦のフォーマット形式の和暦文字列
     * @throws SystemException
     */
    public static String seirekiToWareki(String seireki, String seirekiFormat, String warekiFormat)
            throws SystemException {
        return seirekiToWareki(seireki, seirekiFormat, warekiFormat, ImperialCalendar.WAREKI_MODE.YMD);
    }

    /**
     * <p>
     * 西暦文字列を和暦文字列に変換します(GZ9.Z9.Z9)
     * </p>
     * 西暦文字列の書式は{@link SimpleDateFormat}の書式と同等です。
     * 取得する和暦文字列の書式は{@link ImperialCalendar#format(String)}の書式と同等です。
     * <ul>
     * <li>DateUtil.getWarekiString("19801101", "yyyyMMdd", "GGyyMMdd"); ⇒
     * "S5511 1"</li>
     * <li>DateUtil.getWarekiString("19801101", "yyyyMMdd", "GGGGyy年MM月dd日"); ⇒
     * "昭和55年11月 1日"</li>
     * </ul>
     *
     * @param seireki 西暦文字列
     * @param seirekiFormat 西暦文字列の書式
     * @param warekiFormat 取得する和暦文字列の書式
     * @return 指定した書式の和暦文字列
     * @throws SystemException
     * @see ImperialCalendar#format(String)
     */
    public static String seirekiToWareki(String seireki, String seirekiFormat, String warekiFormat,
            ImperialCalendar.WAREKI_MODE mode) throws SystemException {

        // 与えられた西暦が空白、もしくはNullだった場合は空文字列を返す
        if (CheckUtils.isEmpty(seireki)) {
            return StrUtils.EMPTY;
        }

        Date date = DateUtils.parse(seireki, new String[]{seirekiFormat});

        // 年月モードの場合は月末日とする
        if (mode == ImperialCalendar.WAREKI_MODE.YM) {
            date = DateUtils.addDays(
                    org.apache.commons.lang.time.DateUtils.truncate(DateUtils.addMonths(date, 1), Calendar.MONTH), -1);
        }

        ImperialCalendar impCal = new ImperialCalendar(date);
        return impCal.format(warekiFormat);
    }

    /**
     * <p>
     * 西暦文字列を和暦文字列に変換します(G99.99.99)
     * </p>
     * 西暦文字列の書式は{@link SimpleDateFormat}の書式と同等です。
     * 取得する和暦文字列の書式は{@link ImperialCalendar#format(String)}の書式と同等です。
     * <ul>
     * <li>DateUtil.getWarekiString("19801101", "yyyyMMdd", "GGyyMMdd"); ⇒
     * "S551101"</li>
     * <li>DateUtil.getWarekiString("19801101", "yyyyMMdd", "GGGGyy年MM月dd日"); ⇒
     * "昭和55年11月01日"</li>
     * </ul>
     *
     * @param seireki 西暦文字列
     * @param seirekiFormat 西暦文字列の書式
     * @param warekiFormat 取得する和暦文字列の書式
     * @return 指定した書式の和暦文字列
     * @throws SystemException
     * @see ImperialCalendar#format(String)
     */
    public static String seirekiToWarekiStr(String seireki, String seirekiFormat, String warekiFormat)
            throws SystemException {

        // 与えられた西暦が空白、もしくはNullだった場合は空文字列を返す
        if (CheckUtils.isEmpty(seireki)) {
            return StrUtils.EMPTY;
        }

        Date date = DateUtils.parse(seireki, new String[]{seirekiFormat});

        ImperialCalendar impCal = new ImperialCalendar(date);
        return impCal.format_wareki(warekiFormat);
    }

    /**
     * 指定された日付の翌月の日数を取得する。
     *
     * @param _date 日付
     * @return 翌月の日数
     */
    public static String getNextMonthDays(Date _date) {

        if (_date == null) {
            throw new IllegalArgumentException();
        }

        Date truncateDate = truncate(DateUtils.addMonths(Calendar.getInstance().getTime(), 2), Calendar.MONTH);
        Date nextMonthEndDay = DateUtils.addDays(truncateDate, -1);
        return DateUtils.format(nextMonthEndDay, "d");

    }

    /**
     * 開始から終了の時間の実年数で取得する。
     * <p>
     * 開始から終了の時間の差を年数で取得する。<br>
     * </p>
     *
     * @param _startDate 開始日時
     * @param _endDate 終了日時
     * @return 年数
     */
    public static int pireodAge(Date _startDate, Date _endDate) {
        int age_ = 0;
        // int isMinus = 1;
        //
        if (CheckUtils.isMoreThan(_startDate, _endDate)) {
            // isMinus = -1;
            Date temp_ = _startDate;
            _startDate = _endDate;
            _endDate = temp_;
        }
        while (!CheckUtils.isMoreThan(_startDate, _endDate)) {
            _startDate = DateUtils.addYears(_startDate, 1);
            age_ = age_ + 1;
        }
        age_ = age_ - 1;

        // age_ = age_ * isMinus;
        return age_;
    }

    private static final Calendar cstImplementTheLawOfHoliday = new GregorianCalendar(1948, Calendar.JULY, 20); // 祝日法施行
    private static final Calendar cstAkihitoKekkon = new GregorianCalendar(1959, Calendar.APRIL, 10); // 明仁親王の結婚の儀
    private static final Calendar cstShowaTaiso = new GregorianCalendar(1989, Calendar.FEBRUARY, 24);// 昭和天皇大喪の礼
    private static final Calendar cstNorihitoKekkon = new GregorianCalendar(1993, Calendar.JUNE, 9);// 徳仁親王の結婚の儀
    private static final Calendar cstSokuireiseiden = new GregorianCalendar(1990, Calendar.NOVEMBER, 12);// 即位礼正殿の儀
    private static final Calendar cstImplementHoliday = new GregorianCalendar(1973, Calendar.APRIL, 12);// 振替休日施行

    // [prmDate]には "yyyymmdd"形式の日付文字列を渡す
    public static String getHolidayName(String prmDate) {
        try {
            String HolidayName_ret = "";
            SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
            Calendar MyDate = Calendar.getInstance();
            MyDate.setTime(formatter.parse(prmDate));
            String HolidayName = prvHolidayChk(MyDate);
            if (HolidayName == "") {
                // 月曜以外は振替休日判定不要
                if (MyDate.after(cstImplementHoliday) || MyDate.equals(cstImplementHoliday)) {
                    if (MyDate.get(Calendar.DAY_OF_WEEK) == Calendar.MONDAY) {
                        Calendar YesterDay = (Calendar) MyDate.clone();
                        YesterDay.add(Calendar.DATE, -1);
                        HolidayName = prvHolidayChk(YesterDay);
                        HolidayName_ret = "";
                        if (HolidayName != "") {
                            HolidayName_ret = "振替休日";
                        } else {
                            HolidayName_ret = "";
                        }
                    } else {
                        HolidayName_ret = "";
                    }
                    if ((MyDate.get(Calendar.MONTH) + 1 == 5)
                            && (MyDate.get(Calendar.DATE) == 6)
                            && (MyDate.get(Calendar.DAY_OF_WEEK) <= Calendar.WEDNESDAY)
                            && (MyDate.get(Calendar.DAY_OF_WEEK) >= Calendar.MONDAY)) {
                        HolidayName_ret = "振替休日";
                    }
                } else {
                    HolidayName_ret = "";
                }
//                if (MyDate.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {
//                    HolidayName_ret = "休日";
//                }
//
//                if (MyDate.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
//                    HolidayName_ret = "休日";
//                }
            } else {
                HolidayName_ret = HolidayName;
            }
            return HolidayName_ret;
        } catch (ParseException e) {
            return null;
        }
    }

    // ===============================================================
    private static String prvHolidayChk(Calendar MyDate) {
        int NumberOfWeek;
        String Result;
        int MyYear = MyDate.get(Calendar.YEAR);
        int MyMonth = MyDate.get(Calendar.MONTH) + 1; // MyMonth:1～12
        int MyDay = MyDate.get(Calendar.DATE);

        if (MyDate.before(cstImplementTheLawOfHoliday)) {
            return ""; // 祝日法施行(1948/7/20 )以前
        } else
            ;

        Result = "";
        switch (MyMonth) {
            // １月 //
            case 1:
                if (MyDay == 1) {
                    Result = "元日";
                } else {
                    if (MyYear >= 2000) {
                        NumberOfWeek = ((MyDay - 1) / 7) + 1;
                        if ((NumberOfWeek == 2) && (MyDate.get(Calendar.DAY_OF_WEEK) == Calendar.MONDAY)) {
                            Result = "成人の日";
                        } else
                            ;
                    } else {
                        if (MyDay == 15) {
                            Result = "成人の日";
                        } else
                            ;
                    }
                }
                break;
            // ２月 //
            case 2:
                if (MyDay == 11) {
                    if (MyYear >= 1967) {
                        Result = "建国記念の日";
                    } else
                        ;
                } else {
                    if (MyDate.equals(cstShowaTaiso)) {
                        Result = "昭和天皇の大喪の礼";
                    } else
                        ;
                }
                break;
            // ３月 //
            case 3:
                if (MyDay == prvDayOfSpringEquinox(MyYear)) { // 1948～2150以外は[99]
                    Result = "春分の日"; // が返るので､必ず≠になる
                } else
                    ;
                break;
            // ４月 //
            case 4:
                if (MyDay == 29) {
                    if (MyYear >= 1989) {
                        Result = "昭和の日";
                    } else {
                        Result = "天皇誕生日";
                    }
                } else {
                    if (MyDate.equals(cstAkihitoKekkon)) {
                        Result = "皇太子明仁親王の結婚の儀";// ( =1959/4/10 )
                    } else
                        ;
                }
                break;
            // ５月 //
            case 5:
                if (MyDay == 3) {
                    Result = "憲法記念日";
                } else {
                    if (MyDay == 4) {
//                        if (MyDate.get(Calendar.DAY_OF_WEEK) > Calendar.MONDAY) {
                        // 5/4が日曜日は『只の日曜』､月曜日は『憲法記念日の振替休日』
                        if (MyYear >= 1986) {
                            Result = "みどりの日";
                        } else
                                ;
//                        } else
//                            ;
                    } else {
                        if (MyDay == 5) {
                            Result = "子供の日";
                        } else
                            ;
                    }
                }
                break;
            // ６月 //
            case 6:
                if (MyDate.equals(cstNorihitoKekkon)) {
                    Result = "皇太子徳仁親王の結婚の儀";
                } else
                    ;
                break;
            // ７月 //
            case 7:
                if (MyYear >= 2003) {
                    NumberOfWeek = ((MyDay - 1) / 7) + 1;
                    if ((NumberOfWeek == 3) && (MyDate.get(Calendar.DAY_OF_WEEK) == Calendar.MONDAY)) {
                        Result = "海の日";
                    } else
                        ;
                } else {
                    if (MyYear >= 1996) {
                        if (MyDay == 20) {
                            Result = "海の日";
                        } else
                            ;
                    } else
                        ;
                }
                break;
            // ８月 //
            case 8:
                if (MyYear >= 2016) {
                    if (MyDate.equals(11)) {
                        Result = "山の日";
                    } else
                    ;
                } else
                    ;
                break;
            // ９月 //
            case 9:
                // 第３月曜日( 15～21 )と秋分日(22～24 )が重なる事はない
                int MyAutumnEquinox = prvDayOfAutumnEquinox(MyYear);
                if (MyDay == MyAutumnEquinox) { // 1948～2150以外は[99]
                    Result = "秋分の日"; // が返るので､必ず≠になる
                } else {
                    if (MyYear >= 2003) {
                        NumberOfWeek = ((MyDay - 1) / 7) + 1;
                        if ((NumberOfWeek == 3)) {
                            if (MyDate.get(Calendar.DAY_OF_WEEK) == Calendar.MONDAY) {
                                Result = "敬老の日";
                            }
                        }
                        NumberOfWeek = ((MyDay - 3) / 7) + 1;
                        if ((NumberOfWeek == 3)) {
                            if (MyDate.get(Calendar.DAY_OF_WEEK) == Calendar.TUESDAY) {
                                if (MyDay == (MyAutumnEquinox - 1)) {
                                    Result = "国民の休日";
                                }
                            }

                        }
                    } else {
                        if (MyYear >= 1966) {
                            if (MyDay == 15) {
                                Result = "敬老の日";
                            } else
                                ;
                        } else
                            ;
                    }
                }
                break;
            // １０月 //
            case 10:
                if (MyYear >= 2000) {
                    NumberOfWeek = ((MyDay - 1) / 7) + 1;
                    if ((NumberOfWeek == 2) && (MyDate.get(Calendar.DAY_OF_WEEK) == Calendar.MONDAY)) {
                        Result = "体育の日";
                    } else
                        ;
                } else {
                    if (MyYear >= 1966) {
                        if (MyDay == 10) {
                            Result = "体育の日";
                        } else
                            ;
                    } else
                        ;
                }
                break;
            // １１月 //
            case 11:
                if (MyDay == 3) {
                    Result = "文化の日";
                } else {
                    if (MyDay == 23) {
                        Result = "勤労感謝の日";
                    } else {
                        if (MyDate.equals(cstSokuireiseiden)) {
                            Result = "即位礼正殿の儀";
                        } else
                            ;
                    }
                }
                break;
            // １２月 //
            case 12:
                if (MyDay == 23) {
                    if (MyYear >= 1989) {
                        Result = "天皇誕生日";
                    } else
                        ;
                } else
                    ;
                break;
        }

        return Result;
    }

    // ===================================================================
    // 春分/秋分日の略算式は
    // 『海上保安庁水路部 暦計算研究会編 新こよみ便利帳』
    // で紹介されている式です。
    private static int prvDayOfSpringEquinox(int MyYear) {
        int SpringEquinox_ret;
        if (MyYear <= 1947) {
            SpringEquinox_ret = 99; // 祝日法施行前
        } else {
            if (MyYear <= 1979) {
                SpringEquinox_ret = (int) (20.8357 + (0.242194 * (MyYear - 1980)) - (int) ((MyYear - 1983) / 4));
            } else {
                if (MyYear <= 2099) {
                    SpringEquinox_ret = (int) (20.8431 + (0.242194 * (MyYear - 1980)) - (int) ((MyYear - 1980) / 4));
                } else {
                    if (MyYear <= 2150) {
                        SpringEquinox_ret = (int) (21.851 + (0.242194 * (MyYear - 1980)) - (int) ((MyYear - 1980) / 4));
                    } else {
                        SpringEquinox_ret = 99; // 2151年以降は略算式が無いので不明
                    }
                }
            }
        }
        return SpringEquinox_ret;
    }

    // =====================================================================
    private static int prvDayOfAutumnEquinox(int MyYear) {
        int AutumnEquinox_ret;
        if (MyYear <= 1947) {
            AutumnEquinox_ret = 99; // 祝日法施行前
        } else {
            if (MyYear <= 1979) {
                AutumnEquinox_ret = (int) (23.2588 + (0.242194 * (MyYear - 1980)) - (int) ((MyYear - 1983) / 4));
            } else {
                if (MyYear <= 2099) {
                    AutumnEquinox_ret = (int) (23.2488 + (0.242194 * (MyYear - 1980)) - (int) ((MyYear - 1980) / 4));
                } else {
                    if (MyYear <= 2150) {
                        AutumnEquinox_ret = (int) (24.2488 + (0.242194 * (MyYear - 1980)) - (int) ((MyYear - 1980) / 4));
                    } else {
                        AutumnEquinox_ret = 99; // 2151年以降は略算式が無いので不明
                    }
                }
            }
        }
        return AutumnEquinox_ret;
    }

    /**
     * 获取该日期是星期几
     *
     * @param date
     * @return * 1:星期天 2:星期一 3:星期二 4:星期三 5:星期四 6:星期五 7:星期六
     */
    public static String getWeekName(Date date) {
        if (date == null) {
            return null;
        }
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        return String.valueOf(cal.get(Calendar.DAY_OF_WEEK));
    }

    /**
     * 获取该星期的开始
     *
     * @param date
     * @return *
     */
    public static Date getWeekStart(Date date) throws SystemException {
        if (date == null) {
            return null;
        }
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
        Date weekStartDate = addDays(date, 7 - dayOfWeek);
        weekStartDate = parse(format(weekStartDate, StndConsIF.DF_YYYYMMDD) + "000000000",
                StndConsIF.DF_YYYYMMDDHHMMSSSSS);
        return addDays(date, 1 - dayOfWeek);
    }

    /**
     * 获取该星期的结束
     *
     * @param date
     * @return *
     */
    public static Date getWeekEnd(Date date) throws SystemException {
        if (date == null) {
            return null;
        }
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
        Date weekEndDate = addDays(date, 7 - dayOfWeek);
        weekEndDate = parse(format(weekEndDate, StndConsIF.DF_YYYYMMDD) + "235959999",
                StndConsIF.DF_YYYYMMDDHHMMSSSSS);
        return weekEndDate;
    }

    public static Date getWeekDay(Date date, int dayOfWeek) throws SystemException {
        if (date == null) {
            return null;
        }
        return addDays(getWeekStart(date), dayOfWeek - 1);
    }

    public static void main(String[] args) throws SystemException {
//        Date date = parse("20160318", StndConsIF.DF_YYYYMMDD);
//        System.out.println(getWeekStart(date));
//        System.out.println(getWeekDay(date, 1));
//        System.out.println(getWeekDay(date, 2));
//        System.out.println(getWeekDay(date, 3));
//        System.out.println(getWeekDay(date, 4));
//        System.out.println(getWeekDay(date, 5));
//        System.out.println(getWeekDay(date, 6));
//        System.out.println(getWeekDay(date, 7));
//        System.out.println(getWeekEnd(date));
//        date = parse("20160317", StndConsIF.DF_YYYYMMDD);
//        System.out.println(getWeekStart(date));
//        System.out.println(getWeekEnd(date));
//        System.out.println(format(getSysDate(), "yyyy年MM月dd日（E）"));
        for (int m = 2009; m < 2037; m++) {
            for (int i = 0; i < 20; i++) {
                Date tmp = addDays(parse(m + "0910", "yyyyMMdd"), i);
                String tmps = format(tmp, "yyyyMMdd");
                System.out.println(tmps + ":" + getHolidayName(tmps));
            }
        }
    }

}
