/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.common;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.cnst.SysMsg;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.service.common.ComponentBean;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.kintetsuls.service.general.property.ExternalServiceProperty;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.PrimeFaces;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.ToggleSelectEvent;
import org.primefaces.event.UnselectEvent;
import org.primefaces.model.menu.DefaultMenuItem;

/**
 *
 * @author fupengcheng
 */
@javax.faces.bean.ManagedBean(name = "pageCommon")
@ViewScoped
@Data
public class PageCommonBean extends BaseBean {

    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messageProperty;

    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    @ManagedProperty(value = "#{masterInfo}")
    private MasterInfoBean masterInfo;

    @ManagedProperty(value = "#{systemMasterBean}")
    private SystemMasterBean systemMasterBean;
    
    @ManagedProperty(value = "#{sessionBean}")
    private SessionBean sessionBean;

    @ManagedProperty(value = "#{autoComplete}")
    private AutoCompleteBean autoComplete;    

    @ManagedProperty(value = "#{fileFtpToDataspider}")
    private FileFtpToDataspider fileFtpToDataspider;
    
    private final Map<String, List<Map<String, Object>>> selectedDatasList = new HashMap();

    private final Map<String, Object> foucesDataList = new HashMap();

    private final Map<String, List<Map<String, Object>>> datasLists = new HashMap();

    private final Map<String, Integer> datasAddCounts = new HashMap();

    private final Map<String, Function<List<Map<String, Object>>, Boolean>> delFunctionList = new HashMap();

    private boolean editFlg = false;

    private Boolean btnSearchVisible = true;

    private Boolean btnSearchChangeVisible = false;
    
    private Boolean collapsed = false;

    private static final Logger logger = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    private RestfullService rest;

    /**
     * 初期処理（処理）
     *
     * @param menuId
     * @param prevScreen
     * @param backFlag
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
    }

    /**
     * メニュークリック（処理）
     *
     * @param menuId
     * @param nextScreen
     * @return
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {
        return null;
    }

    /**
     * パンくずクリック（処理）
     *
     * @return
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {
        return null;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return
     */
    @Override
    public String logoutClick() {
        return null;
    }

    /**
     * 前の画面に戻る（前画面へボタン）
     *
     * @return url
     */
    public String backforward() {
        // パラメータ取得
        String nextScreen = "";     //遷移先画面
        int curindex;

        // パンくずリストから現在画面のindexを取得
        curindex = breadBean.getMenuindex() - 1;
        DefaultMenuItem item = (DefaultMenuItem) breadBean.getModel().getElements().get(curindex - 1);
        if (item != null) {
            nextScreen = item.getParams().get("screenId").get(0);
        }

        String preurl = "";
        if (!"".equals(nextScreen)) {
            // 戻る画面URL取得
            preurl = forward(nextScreen, null, null, true);
            // 現在の画面IDと戻るの画面をリストから削除(遷移先画面初期化でpushあるため)
            try {
                breadBean.pop(curindex - 1);
            } catch (IllegalAccessException | InvocationTargetException ex) {
                logger.error(ex.getMessage(), ex);
            }
        }
        return preurl;
    }

    /**
     * 遷移元画面へ戻る
     *
     * @return
     * @throws java.lang.IllegalAccessException
     * @throws java.lang.reflect.InvocationTargetException
     */
    public String goBack() throws IllegalAccessException, InvocationTargetException {
        String backurl = backforward();
        return backurl;
    }

    /**
     * ぱんくず表示数が２以上の場合「前画面へ」非表示
     *
     * @return 表示/非表示
     */
    public boolean gobackFlag() {
        return (breadBean.getMenuindex() >= 2);
    }

    /**
     * チェックイベント（ON）
     *
     * @param event
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     */
    public void check(SelectEvent event) throws IllegalAccessException, InvocationTargetException {
        String id = ((DataTable) event.getSource()).getId();
        selectedDatasList.put(id, (List) ((DataTable) event.getSource()).getSelection());
        foucesDataList.put(id, event.getObject());
        FacesContext.getCurrentInstance().getViewRoot().findComponent(id);
//        List<Object> getSelectDatas = getSelectDatas(id);
//        getSelectDatas.add(event.getObject());
    }

    /**
     * チェックイベント（ON）
     *
     * @param event
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     */
    public void check(ToggleSelectEvent event) throws IllegalAccessException, InvocationTargetException {
        String id = ((DataTable) event.getSource()).getId();
        List list = (List) ((DataTable) event.getSource()).getSelection();
        selectedDatasList.put(id, list);
        if (list != null && list.size() > 0) {
            for (int i = 0; i < list.size(); i++) {
                foucesDataList.put(id, list.get(i));
            }
        }
        FacesContext.getCurrentInstance().getViewRoot().findComponent(id);
    }    
    
    /**
     * アンチェックイベント（OFF）
     *
     * @param event
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     */
    public void uncheck(UnselectEvent event) throws IllegalAccessException, InvocationTargetException {
        String id = ((DataTable) event.getSource()).getId();
        selectedDatasList.put(id, (List) ((DataTable) event.getSource()).getSelection());
        foucesDataList.put(id, event.getObject());
//        List<Object> getSelectDatas = getSelectDatas(id);
//        getSelectDatas.remove(event.getObject());
    }

    /**
     * 選択したデータを取得
     *
     * @param　tableList id
     * @return 選択リスト
     */
    private List< Map<String, Object>> getSelectDatas(String id) {
        if (!selectedDatasList.containsKey(id)) {
            selectedDatasList.put(id, new ArrayList<>());
        }
        return selectedDatasList.get(id);

    }

    /**
     * テーブルにデータを追加
     *
     * @param id
     * @param toLast listの下に追加するフラグ
     */
    public void addRow(String id, Boolean toLast) {

        if (!datasLists.containsKey(id)) {
            return;
        }
        List<Map<String, Object>> body = datasLists.get(id);
        datasAddCounts.put(id, (datasAddCounts.containsKey(id) ? datasAddCounts.get(id) + 1 : 0));
        Map<String, Object> data = new LinkedHashMap<>();
        data.put(StndConsIF.CONST_ADD_ROW_KEY, true);
        data.put(ReportListDataModel.UNIQUE_KEY, "A" + datasAddCounts.get(id));
        if (toLast) {
            body.add(data);
        } else {
            if (foucesDataList.isEmpty()) {
                body.add(0, data);
            } else {
                body.add(body.indexOf(foucesDataList.get(id)), data);
            }
        }
//        DataTable dt = (DataTable) FacesContext.getCurrentInstance().getViewRoot().findComponent(id);

    }

    /**
     * テーブルにデータをコピー
     *
     * @param id tableList id
     * @param toLast listの下に追加するフラグ
     */
    public void copyRows(String id, Boolean toLast) {

        if (!datasLists.containsKey(id) || !selectedDatasList.containsKey(id)) {
            return;
        }

        List<Map<String, Object>> body = datasLists.get(id);

        List<Map<String, Object>> selectedDatas = selectedDatasList.get(id);
        if (selectedDatas.isEmpty()) {
            return;
        }
        List< Map<String, Object>> newDatas = new ArrayList<>();
        selectedDatas.stream().map((selectedData) -> {
            datasAddCounts.put(id, (datasAddCounts.containsKey(id) ? datasAddCounts.get(id) + 1 : 0));
            Map<String, Object> newData = new LinkedHashMap();
            newData.putAll(selectedData);
            return newData;
        }).map((newData) -> {
            newData.put(ReportListDataModel.UNIQUE_KEY, "A" + datasAddCounts.get(id));
            newData.put(StndConsIF.CONST_ADD_ROW_KEY, true);
            return newData;
        }).forEachOrdered((newData) -> {
            newDatas.add(newData);
        });

        if (toLast) {
            body.addAll(newDatas);
        } else {
            int maxIndex = 0;
            for (Map<String, Object> selectedData : selectedDatas) {
                int newIndex = body.indexOf(selectedData);
                maxIndex = maxIndex > newIndex ? maxIndex : newIndex;
            }
            body.addAll(maxIndex + 1, newDatas);
        }
    }

    /**
     * 業務削除方法を設定する。
     *
     * @param id
     * @param delFunction
     */
    public void regDelFucntion(String id, Function<List<Map<String, Object>>, Boolean> delFunction) {
        delFunctionList.put(id, delFunction);

    }

    /**
     * 一覧のデータを先に設定する。
     *
     * @param id
     * @param datalist
     */
    public void setDatalist(String id, List<Map<String, Object>> datalist) {
        datasLists.put(id, datalist);
        selectedDatasList.remove(id);
    }

    /**
     * テーブルにデータを削除
     *
     * @param id tableList
     */
    public void delRows(String id) {

        if (!datasLists.containsKey(id) || !selectedDatasList.containsKey(id)) {
            messageProperty.message(MessagePropertyBean.SEVERITY_ERROR, "COME0029");
            return;
        }

        List<Map<String, Object>> body = datasLists.get(id);
        List<Map<String, Object>> selectedDatas = selectedDatasList.get(id);
        if (selectedDatas.isEmpty()) {
            messageProperty.message(MessagePropertyBean.SEVERITY_ERROR, "COME0029");
            return;
        }
        
        // 追加データ直接画面から削除
        List<Map<String, Object>> addRowDatas = new ArrayList<>();
        for (Map<String, Object> rec : selectedDatas) {
            if (rec.get(StndConsIF.CONST_ADD_ROW_KEY) != null) {
                addRowDatas.add(rec);
            }
        }
        selectedDatas.removeAll(addRowDatas);
        body.removeAll(addRowDatas);
        
        if (selectedDatas.isEmpty()) {
            messageProperty.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0004,"削除");
        } else {
            //業務削除方法を実行
            if (delFunctionList.containsKey(id)) {
                delFunctionList.get(id).apply(selectedDatas);
            }
        }
        
        // 全て明細が削除された場合
        if (body.isEmpty()) {
            Map<String, Object> mapRec = new LinkedHashMap();
            mapRec.put("hideFlg", "hideRow");
            body.add(mapRec);
        }
    }

    /**
     * テーブルにデータを削除カスタマイズメッセージ設定あり
     *
     * @param id tableList
     * @param severity
     * @param msgId 報告したい空データメッセージ
     */
    public void delRowsWithMsg(String id,String severity,String msgId) {
        
        if (!datasLists.containsKey(id) || !selectedDatasList.containsKey(id)) {
            messageProperty.message(severity, msgId);
            return;
        }

        List<Map<String, Object>> body = datasLists.get(id);
        List<Map<String, Object>> selectedDatas = selectedDatasList.get(id);
        if (selectedDatas.isEmpty()) {
            messageProperty.message(severity, msgId);
            return;
        }
        this.delRows(id);
    }     

    /**
     * 一覧のAutoCompleteリスト選択した場合はLABELを対応項目に反映する
     *
     * @param list tableList
     * @param row 行番
     * @param colName 反映先項目
     * @param msCnst 取得する共通マスタ対象
     * @param value 選択した値
     */
    public void autoCompSelectForList(List<Map<String, Object>> list,int row,String colName,String msCnst,String value) {
            list.get(row).put(colName, this.getLabelByValue(msCnst, value));
    } 

    /**
     * 参照モード切替用
     *
     */
    public void chgMode() {
        if (this.editFlg) {
            setEditFlg(false);
        } else {
            setEditFlg(true);
        }
    }

    /**
     * 権限取得と設定
     *
     * @param form
     * @param screenCd
     * @param initFlg component初期化フラグ
     */
    public void setAuthControll(Object form, String screenCd, boolean initFlg) {

        Class c = form.getClass();
        Field[] f = c.getDeclaredFields();

        // component初期化
        if (initFlg) {
            for (Field fie : f) {
                fie.setAccessible(true);
                try {
                    if (fie.getName().contains("Disabled")) {
                        fie.set(form, false);
                    }
                    if (fie.getName().contains("Visible")) {
                        fie.set(form, true);
                    }
                } catch (IllegalArgumentException | IllegalAccessException ex) {
                    logger.error(ex.getMessage(), ex);
                }
            }
        }

        // 権限により設定
        Map<String, ComponentBean> authComponentMap = authConfBean.getAuthComponentMap().get(screenCd);
        if (null == authComponentMap) {
            return;
        }
        for (Map.Entry<String, ComponentBean> entry : authComponentMap.entrySet()) {
            for (Field fie : f) {
                fie.setAccessible(true);
                try {
                    if ((entry.getKey() + "Disabled").equals(fie.getName())) {
                        fie.set(form, entry.getValue().getDisabled());
                    }
                    if ((entry.getKey() + "Visible").equals(fie.getName())) {
                        fie.set(form, entry.getValue().getVisible());
                    }
                } catch (IllegalArgumentException | IllegalAccessException ex) {
                    logger.error(ex.getMessage(), ex);
                }
            }
        }
    }

    /**
     * 画面項目保存用
     *
     * @param key
     * @param obj
     */
    public void savePageInfo(String key, Object obj) {
        try {
            Class c = obj.getClass();
            Object objNew = c.newInstance();
            PageCommonBean.simpleCopy(obj, objNew);
            sessionBean.setPageConData(key, objNew);
        } catch (InstantiationException | IllegalAccessException ex) {
            logger.error(ex.getMessage(), ex);
        }
    }

    /**
     * 画面項目取得用
     *
     * @param key
     * @return obj
     */
    public Object getPageInfo(String key) {
        return sessionBean.getPageConData(key);
    }

    /**
     * 画面パラメータ得用また設定用
     *
     * @return obj
     */
    public Flash getPageParam() {
        return FacesContext.getCurrentInstance().getExternalContext().getFlash();
    }

    /**
     * DBアクセス用
     *
     * @param params
     * @param functionCode
     * @return ServiceInterfaceBean
     */
    public ServiceInterfaceBean getDBInfo(Map<String, Object> params, String functionCode) {

        ServiceInterfaceBean req = new ServiceInterfaceBean();
        req.setUserCd(authConfBean.getUserCd());
        req.setDefaultEigyosho(authConfBean.getDefaultEigyosho());
        //req.setLoginUserShozokuEigyosho(authConfBean.getLoginUserShozokuEigyosho());
        req.setFunctionCode(ExternalServiceProperty.getInstance().getProperty(functionCode));
        String requestData = JSONUtil.makeJSONString(params);
        req.setJson(requestData);

        //JAX-RS接続を実行(SQL側のチェック処理など未実装。)
        rest = RestfullService.getInstance();
        ServiceInterfaceBean res;
        try {
            res = rest.request(req);
        } catch (IOException | SystemException ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
            return null;
        }

        return res;
    }

    /**
     * DBアクセス用(Listパラメータ)
     *
     * @param params
     * @param functionCode
     * @return ServiceInterfaceBean
     */
    public ServiceInterfaceBean accsessDBWithList(List<Map<String, Object>> params, String functionCode) {

        ServiceInterfaceBean req = new ServiceInterfaceBean();
        req.setUserCd(authConfBean.getUserCd());
        req.setDefaultEigyosho(authConfBean.getDefaultEigyosho());
        req.setFunctionCode(ExternalServiceProperty.getInstance().getProperty(functionCode));
        String requestData = JSONUtil.makeJSONString(params);
        req.setJson(requestData);

        //JAX-RS接続を実行(SQL側のチェック処理など未実装。)
        rest = RestfullService.getInstance();
        ServiceInterfaceBean res;
        try {
            res = rest.request(req);
        } catch (IOException | SystemException ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
            return null;
        }
        return res;
    }

    /**
     * DBアップロード用(Listパラメータ)
     *
     * @param params
     * @param functionCode
     * @param tableName
     * @return ServiceInterfaceBean
     */
    public ServiceInterfaceBean uploadDBWithList(List<Map<String, Object>> params, String functionCode,String tableName) {

        ServiceInterfaceBean req = new ServiceInterfaceBean();
        req.setTableName(tableName);
        req.setUserCd(authConfBean.getUserCd());
        req.setDefaultEigyosho(authConfBean.getDefaultEigyosho());
        req.setFunctionCode(ExternalServiceProperty.getInstance().getProperty(functionCode));
        String requestData = JSONUtil.makeJSONString(params);
        req.setJson(requestData);

        //JAX-RS接続を実行(SQL側のチェック処理など未実装。)
        rest = RestfullService.getInstance();
        ServiceInterfaceBean res;
        try {
            res = rest.request(req);
        } catch (IOException | SystemException ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
            return null;
        }
        return res;
    }
    
    /**
     * マスタ内容取得用
     *
     * @param groupCd
     */
    public void getMasterInfo(String groupCd) {

        // ワーク.表示最大件数
        masterInfo.setDispMaxRows(systemMasterBean.getSysValByCdAndKanriGroup(
                MsCnst.SYS_CD_DISP_MAX_ROWS, groupCd, MsCnst.SYS_CDGROUP_SYSTEM));
        // ワーク.取得最大件数
        masterInfo.setMaxRows(systemMasterBean.getSysValByCdAndKanriGroup(
                MsCnst.SYS_CD_MAX_ROWS, groupCd, MsCnst.SYS_CDGROUP_SYSTEM));
        // ワーク.ダウンロード最大件数
        masterInfo.setDownloadMaxRows(systemMasterBean.getSysValByCdAndKanriGroup(
                MsCnst.SYS_CD_DOWNLOAD_MAX_ROWS, groupCd, MsCnst.SYS_CDGROUP_SYSTEM));
        // ワーク.CSVのみダウンロード最大件数
        masterInfo.setCsvDownloadMaxRows(systemMasterBean.getSysValByCdAndKanriGroup(
                MsCnst.SYS_CD_CSV_DOWNLOAD_MAX_ROWS, groupCd, MsCnst.SYS_CDGROUP_SYSTEM));
        // ワーク.ページ毎最大件数
        masterInfo.setPageMaxRows(systemMasterBean.getSysValByCdAndKanriGroup(
                MsCnst.SYS_CD_PAGE_MAX_ROWS, groupCd, MsCnst.SYS_CDGROUP_SYSTEM));
        // ワーク.全営業所検索
        masterInfo.setAllEigyoshoSearch(systemMasterBean.getSysValByCdAndKanriGroup(
                MsCnst.SYS_CD_ALL_EIGYOSHO_SEARCH, groupCd, MsCnst.SYS_CDGROUP_SYSTEM));
        // ワーク.ページ初期選択件数
        masterInfo.setDefaultSelectRows(systemMasterBean.getSysValByCdAndKanriGroup(
                MsCnst.SYS_CD_DEFAULT_SELECT_ROWS, groupCd, MsCnst.SYS_CDGROUP_SYSTEM));
        // ワーク.ページプルダウン値
        masterInfo.setSelectOptionRows(systemMasterBean.getSysValByCdAndKanriGroup(
                MsCnst.SYS_CD_SELECT_OPTION_ROWS, groupCd, MsCnst.SYS_CDGROUP_SYSTEM));
    }

    /**
     * Beanに同じ属性があればを新しいBeanにコピーする
     *
     * @param <T>
     * @param <K>
     * @param source
     * @param target
     */
    public static <T, K> void simpleCopy(T source, K target) {
        try {
            BeanUtils.copyProperties(target, source);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }
    }

    /**
     * 検索ボタンを押した時に条件部を無効化
     *
     * @param form
     */
    public void setSerchConDisabled(Object form) {

        Class c = form.getClass();
        Field[] f = c.getDeclaredFields();

        for (Field fie : f) {
            fie.setAccessible(true);
            try {
                if (fie.getName().startsWith("con") && fie.getName().endsWith("Disabled")) {
                    fie.set(form, true);
                }
            } catch (IllegalArgumentException | IllegalAccessException ex) {
                logger.error(ex.getMessage(), ex);
            }
        }
    }

    /**
     * 検索条件ボタンを押した時に条件部を有効化
     *
     * @param form
     */
    public void setSerchConEnabled(Object form) {

        Class c = form.getClass();
        Field[] f = c.getDeclaredFields();

        for (Field fie : f) {
            fie.setAccessible(true);
            try {
                if (fie.getName().startsWith("con") && fie.getName().endsWith("Disabled")) {
                    fie.set(form, false);
                }
            } catch (IllegalArgumentException | IllegalAccessException ex) {
                logger.error(ex.getMessage(), ex);
            }
        }
    }

    /**
     * 一覧の一行を指定した配色定義を設定
     *
     * @param res
     * @param style
     */
    public void setIchiranRowColor(Map<String, Object> res, String style) {

        Map temMao = new LinkedHashMap();

        res.keySet().forEach((key) -> {
            temMao.put(key + "_emp", style + "_emp");
        });
        res.putAll(temMao);
    }

    /**
     * 一覧の一行の指定項目を指定した配色定義を設定
     *
     * @param res
     * @param nameAndStyle
     */
    public void setIchiranRowColorByName(Map<String, Object> res, Map<String, String> nameAndStyle) {

        Map temMao = new LinkedHashMap();

        nameAndStyle.entrySet().forEach((entry) -> {
            temMao.put(entry.getKey() + "_emp", entry.getValue() + "_emp");
        });
        res.putAll(temMao);

    }

    /**
     * 一覧の一列を指定した配色定義を設定
     *
     * @param resList
     * @param style
     * @param colName
     */
    public void setIchiranColColor(List<Map<String, Object>> resList, String style, String colName) {

        if (resList != null && resList.size() > 0) {
            for (Map<String, Object> rec : resList) {
                Map temMao = new LinkedHashMap();
                temMao.put(colName + "_emp", style + "_emp");
                rec.putAll(temMao);
            }
        }
    }

    /**
     * 一覧の配色定義をなくす
     *
     * @param resList
     */
    public void resetIchiranColColor(List<Map<String, Object>> resList) {

        if (resList != null && resList.size() > 0) {
            resList.forEach((rec) -> {
                Map tmpMap = new HashMap();
                rec.keySet().forEach((key) -> {
                    if (key.contains("_emp")) {
                        tmpMap.put(key, null);
                    }
                });
                rec.putAll(tmpMap);
            });
        }
    }

    /**
     * 一覧を再検索する
     *
     * @param btnId
     */
    public void searchAgain(String btnId) {

        PrimeFaces.current().executeScript("searchAgain('" + btnId + "')");

    }
    
    /**
     * スクリプトを実行する
     *
     * @param jScript
     */
    public void executeScript(String jScript) {

        PrimeFaces.current().executeScript(jScript);

    }

    /**
     * 一覧をDataVersionプラス1する
     *
     * @param list
     */
    public void addIchiranDataVersion(List<Map<String, Object>> list) {

        for (Map<String, Object> rec : list) {
            if (rec.get("listDataVersion") != null) {
                int tmpDv = Integer.valueOf(objectToString(rec.get("listDataVersion"))) + 1;
                rec.put("listDataVersion", tmpDv);
            }
            if (rec.get("koushinCounter") != null) {
                int tmpCc = Integer.valueOf(objectToString(rec.get("koushinCounter"))) + 1;
                rec.put("koushinCounter", tmpCc);
            }
        }
    }

    public String objectToString(Object o) {
        if (o == null) {
            return null;
        }
        return o.toString();
    }

    public String objectToStringOrBlank(Object o) {
        if (o == null) {
            return "";
        }
        return o.toString();
    }

    /**
     * AutoCompleteの文字列リストを取得する
     *
     * @param listId SQL文のID
     * @param value
     * @return ValueよりLABELを返す
     */
    public String getLabelByValue(String listId,String value) {
        return autoComplete.getLabelByValue(listId, value);
    }

    /**
     *画面情報をシリーズ化する
     *
     * @param str 保存するMapキー(将来はDBに保存する)
     * @param pageData 画面情報
     */
    public void setPageDataSeria(String str, Object pageData) {
        byte[] mapNew = clone(pageData);
        sessionBean.setPageConData(str, mapNew);
    }

    /**
     *画面情報をアンシリーズ化する
     *
     * @param str 保存するMapキー(将来はDBから取得する)
     */
    public Object getPageDataUnseria(String str) {
        ObjectInputStream ois = null;
        if (sessionBean.getPageConData(str) != null) {
            Object res = null;
            try {
                ByteArrayInputStream bais = new ByteArrayInputStream((byte[]) sessionBean.getPageConData(str));
                ois = new ObjectInputStream(bais);
                res = ois.readObject();
                return res;
            } catch (EOFException ex) {
                return res;
            } catch (IOException | ClassNotFoundException ex) {
               logger.error(ex.getMessage(), ex);
            } finally {
                try {
                    ois.close();
                } catch (IOException ex) {
                    logger.error(ex.getMessage(), ex);
                }
            }
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private static <T extends Serializable> T clone(Object obj) {

        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            oos.writeObject(obj);
            oos.close();

            return (T) baos.toByteArray();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 循環DataTable該当行の情報を取得する
     *
     * @param var xhtml中に定義した循環変数
     */
    public Map getEvaluateExpression(String var) {
        return FacesContext
                .getCurrentInstance()
                .getApplication()
                .evaluateExpressionGet(FacesContext.getCurrentInstance(),
                        "#{" + var + "}", Map.class);
    }

    /**
     * Bean --> Mapを転換する
     *
     * @param obj 転換元のオブジェクト
     */
     public Map<String, Object> transBean2Map(Object obj) {
 
         if(obj == null){
             return null;
         }        
         Map<String, Object> map = new HashMap<String, Object>();
         try {
             BeanInfo beanInfo = Introspector.getBeanInfo(obj.getClass());
             PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
             for (PropertyDescriptor property : propertyDescriptors) {
                 String key = property.getName();
 
                 // クラス属性
                 if (!key.equals("class")) {
                     // propertyのgetter
                     Method getter = property.getReadMethod();
                     Object value = getter.invoke(obj);
                     map.put(key, value);
                 }
             }
         } catch (Exception e) {
             System.out.println("transBean2Map Error " + e);
         }
         return map;
     }

    /**
     * DataSpiderのメール送信機能を使用して、メール送信処理を行う
     *
     * @param address 宛先
     * @param title タイトル
     * @param context メール本文
     */
    public void sendMailWithDataSpider(String address,String title,String context) {

        String str = "\"" + address + "\",\"" + title + "\",\"" + context + "\"";

        InputStream is = new ByteArrayInputStream(str.getBytes());

        // ファイルアップロード(InputStream)
        fileFtpToDataspider.uploadFtpFileWithInputStream("/mail","mail.csv",is);
        
    }
     
}
