/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common.annotation.validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.annotation.HalfEisu;

/**
 * 半角英数字チェック
 * 
 * @author zf (MBP)
 * @version 2019/3/27 新規作成
 */
public class HalfEisuValidator implements ConstraintValidator<HalfEisu, Object> { 

    @Override
    public void initialize(HalfEisu constraintAnnotation) {
    }

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext context) {
        if (value == null) {
            return true;
        }
        Pattern pattern = Pattern.compile("[0-9a-zA-Z]*");
        String valStr = null;
        if (value.getClass().getTypeName().equals("java.lang.String")) {
            valStr = value.toString();
        } else if (value.getClass().getTypeName().equals("jp.co.kintetsuls.beans.common.AutoCompOptionBean")) {
            valStr = ((AutoCompOptionBean)value).getValue();
        }
        Matcher isNum = pattern.matcher(valStr);
        if(!isNum.matches()){
           return false;
        }
        return true;
    }
    
}
