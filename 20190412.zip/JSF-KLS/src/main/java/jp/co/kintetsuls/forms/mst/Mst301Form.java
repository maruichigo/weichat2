/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mst;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.KbnModuleBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.annotation.DateCheck;
import jp.co.kintetsuls.beans.common.annotation.NotEmpty;
import lombok.Data;

/**
 * ロジ料金項目マスタフォーム
 * 
 * @author 尹彥旭（MBP）
 * @version 2019/1/24 新規作成
 */
@ManagedBean(name = "mst301Form")
@ViewScoped
@Data
public class Mst301Form implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;

    /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;

    /**
     * 選択された結果
     */
    private List<Map<String, Object>> selectedSearchResult;

    /**
     * 料金項目1コード
     */
    private String conRyokinKomoku1Cd;

    /**
     * 料金項目1名称
     */
    private String conRyokinKomoku1Mei;
    
    /**
     * 料金項目2コード
     */
    private String conRyokinKomoku2Cd;

    /**
     * 料金項目2名称
     */
    private String conRyokinKomoku2Mei;

    /**
     * 処理科目
     */
    private AutoCompOptionBean conSyoriKamoku;

    /**
     * 補助科目
     */
    private AutoCompOptionBean conHojoKamoku;

    /**
     * 卸値計算パターン
     */
    private String conOroshineKeisanPattern;

    /**
     * 適用名
     */
    private String conTekiyoMei;

    /**
     * 世代検索条件
     */
    @NotEmpty(message = "{COME0022}")
    private String[] conSedaiKensakuJoken;

    /**
     * 適用日
     */
    @DateCheck(name = "適用日")
    private String conTekiyoBi;

    /**
     * 削除のみ検索
     */
    private String[] conSakujoNomiKensaku;

    /**
     * 卸値計算パターン
     */
    private List<KbnModuleBean> oroshiKeisanPattern;

    /**
     * 世代検索条件リスト
     */
    private List<KbnModuleBean> conSedaiKensakuJokenLabelValueList;

    /**
     * 小数点区分
     */
    private List<KbnModuleBean> shosutenKbnList;

    /**
     * 税区分
     */
    private List<KbnModuleBean> taxType;

    /**
     * 輸送売上セット先
     */
    private List<KbnModuleBean> yusouriageSetSaki;

    /**
     * 料金項目明細区分
     */
    private List<KbnModuleBean> ryokinKomokuMeisaiKbn;

    /**
     * 編集Disabled
     */
    private boolean btnEditeDisabled;

    /**
     * 検索Visible
     */
    private boolean conDisabled;
}
