/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mst;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.annotation.DateCheck;
import jp.co.kintetsuls.beans.common.annotation.MaxSizeCheck;
import jp.co.kintetsuls.beans.common.annotation.NotNull;
import jp.co.kintetsuls.forms.common.LabelValueForm;
import lombok.Data;

/**
 * 施設マスタ詳細 フォーム
 *
 * @author 王永 (MBP)
 * @version 2019/3/14 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst142Form")
@ViewScoped
@Data
public class Mst142Form {

    /**
     * 施設コードAutoCompelete
     */
    @NotNull(name = "施設コード", message = "{COME0003}")
    private AutoCompOptionBean conShisetsuCd;

    /**
     * 施設コードLabel
     */
    private String conShisetsuCdLabel;

    /**
     * 施設コードDisabled
     */
    private boolean conShisetsuCdDisabled;

    /**
     * 承認ステータス
     */
    private String conShoninStatus;

    /**
     * 適用開始日
     */
    @NotNull(name = "適用開始日", message = "{COME0003}")
    @DateCheck(name = "適用開始日")
    private String conTekiyoKaishibi;

    /**
     * 適用開始日Disabled
     */
    private boolean conTekiyoKaishibiDisabled;

    /**
     * 適用名
     */
    @MaxSizeCheck(maxSize = 40, name = "適用名")
    private String conTekiyoMei;

    /**
     * 適用名Disabled
     */
    private boolean conTekiyoMeiDisabled;

    /**
     * 適用フラグ
     */
    private String listTekiyoFlg;

    /**
     * 適用終了日
     */
    @DateCheck(name = "適用終了日")
    private String conTekiyoShuryobi;

    /**
     * 適用終了日Disabled
     */
    private boolean conTekiyoShuryobiDisabled;

    /**
     * 適用終了日Hidden
     */
    private boolean conTekiyoShuryobiHidden;

    /**
     * 適用終了リスト
     */
    private List<LabelValueForm> conTekiyoShuryoLabelValueList;

    /**
     * 施設名
     */
    @MaxSizeCheck(maxSize = 40, name = "施設名")
    @NotNull(name = "施設名", message = "{COME0003}")
    private String listShisetsuMei;

    /**
     * /* 施設名Disabled
     */
    private boolean listShisetsuMeiDisabled;

    /**
     * 管轄営業所名
     */
    private String listKankatsuEigyoshoMei;

    /**
     * 管轄営業所AutoCompelete
     */
    @NotNull(name = "管轄営業所", message = "{COME0003}")
    private AutoCompOptionBean listKankatsuEigyosho;

    /**
     * 管轄営業所Label
     */
    private String listKankatsuEigyoshoLabel;

    /**
     * 管轄営業所Disabled
     */
    private boolean listKankatsuEigyoshoDisabled;

    /**
     * 有効坪数
     */
//    @MaxSizeCheck(maxSize = 9, name = "有効坪数")
    @NotNull(name = "有効坪数", message = "{COME0003}")
    private BigDecimal listYukoTsubosu;

    /**
     * /* 有効坪数Disabled
     */
    private boolean listYukoTsubosuDisabled;

    /**
     * 仕入値
     */
//    @MaxSizeCheck(maxSize = 10, name = "仕入値")
    @NotNull(name = "仕入値", message = "{COME0003}")
    private BigDecimal listShiireNe;

    /**
     * /* 仕入値Disabled
     */
    private boolean listShiireNeDisabled;

    /**
     * 郵便番号
     */
    @MaxSizeCheck(maxSize = 7, name = "郵便番号")
    private String listYubinBango;

    /**
     * JISコード
     */
    @NotNull(name = "JISコード", message = "{COME0003}")
    private AutoCompOptionBean listJisCd;

    /**
     * /* JISDisabled
     */
    private boolean jisDisabled;

    /**
     * 住所(1行目)
     */
    @MaxSizeCheck(maxSize = 40, name = "住所1")
    @NotNull(name = "住所1", message = "{COME0003}")
    private String listJusho1;

    /**
     * 住所(2行目)
     */
    @MaxSizeCheck(maxSize = 40, name = "住所2")
    private String listJusho2;

    /**
     * 住所(3行目)
     */
    @MaxSizeCheck(maxSize = 40, name = "住所3")
    private String listJusho3;

    /**
     * 住所(4行目)
     */
    @MaxSizeCheck(maxSize = 40, name = "住所4")
    private String listJusho4;

    /**
     * 住所
     */
    private String listJusho;

    /**
     * 電話番号
     */
    @MaxSizeCheck(maxSize = 19, name = "電話番号")
    private String listTelBango;

    /**
     * /* 電話番号Disabled
     */
    private boolean listTelBangoDisabled;

    /**
     * 敷地面積
     */
//    @MaxSizeCheck(maxSize = 8, name = "敷地面積")
    private BigDecimal listShikichiMenseki;

    /**
     * /* 敷地面積Disabled
     */
    private boolean listShikichiMensekiDisabled;

    /**
     * 延床面積
     */
//    @MaxSizeCheck(maxSize = 8, name = "延床面積")
    private BigDecimal listNobeyukaMenseki;

    /**
     * /* 延床面積Disabled
     */
    private boolean listNobeyukaMensekiDisabled;

    /**
     * /* 明細Disabled
     */
    private boolean detailDisabled;

    /**
     * 検索結果一覧データ
     */
    private List<Map<String, String>> meisaiDataList;

    /**
     * フロア情報検索結果一覧選択できる
     */
    private ReportListDataModel searchFloorResultSelectable;

    /**
     * ロケーション情報検索結果一覧選択できる
     */
    private ReportListDataModel searchLocationResultSelectable;

    /**
     * フロア情報選択された結果
     */
    private List<Map<String, Object>> selectedFloorSearchResult;

    /**
     * ロケーション情報選択された結果
     */
    private List<Map<String, Object>> selectedLocationSearchResult;

    /**
     * 更新者
     */
    private String listKoshinsha;

    /**
     * 更新日時
     */
    private String listKoshinNichiji;

    /**
     * 見積り最終使用日
     */
    private String listMitsumoriSaishuShiyoHi;

    /**
     * ロジ入力計算最終使用日
     */
    private String listLogiNyuryokuKeisanSaishuShiyoHi;

    /**
     * モード
     */
    private String listMode;

    /**
     * 施設データバージョン
     */
    private String listShisetsuDataVersion;

    /**
     * バージョン
     */
    private String rirekiVersion;

    /**
     * 適用開始日
     */
    private String rirekiTekiyoKaishibi;

    /**
     * 最終更新日
     */
    private String rirekiSaishuOpKoshinNichuiji;

    /**
     * 最終更新者
     */
    private String rirekiSaishuOpUser;

    /**
     * 検索結果データ
     */
    private List<Map<String, Object>> searchResult;

    /**
     * フロア情報検索結果データ
     */
    private List<Map<String, Object>> searchFloorResult;

    /**
     * ロケーション情報検索結果データ
     */
    private List<Map<String, Object>> searchLocationResult;

    /**
     * フロアリスト
     */
    private List<SelectItem> floors;

    /**
     * フロアマップ
     */
    private Map<String, String> floorMap;

    /**
     * 施設概要表.事務所坪数合計
     */
    private BigDecimal sisetuGaiyohyoListJimushoTsubosuGokei;

    /**
     * 施設概要表.事務所賃料合計
     */
    private BigDecimal sisetuGaiyohyoListJimushoChinryoGokei;

    /**
     * 施設概要表.倉庫坪数合計
     */
    private BigDecimal sisetuGaiyohyoListSokoTsubosuGokei;

    /**
     * 施設概要表.倉庫賃料合計
     */
    private BigDecimal sisetuGaiyohyoListSokoChinryoGokei;

    /**
     * 施設概要表.合計坪数合計
     */
    private BigDecimal sisetuGaiyohyoListGokeiTsubosuGokei;

    /**
     * 施設概要表.合計賃料合計
     */
    private BigDecimal sisetuGaiyohyoListGokeiChinryoGokei;

    /**
     * 倉庫料卸設定一覧表.坪数合計
     */
    private BigDecimal sokoryoOroshiSetteihyoListTsubosuGokei;

    /**
     * /* 前画面へDisabled
     */
    private boolean btnMaeGamenDisabled;

    /**
     * /* 編集Disabled
     */
    private boolean btnHenshuDisabled;

    /**
     * /* 登録申請Disabled
     */
    private boolean btnTorokuShinseiDisabled;

    /**
     * /* 複写申請Disabled
     */
    private boolean btnFukushaShinseiDisabled;

    /**
     * /* 削除申請Disabled
     */
    private boolean btnSakujoShinseiDisabled;

    /**
     * /* 論理削除申請Disabled
     */
    private boolean btnRonriSakujoShinseiDisabled;

    /**
     * /* 申請Disabled
     */
    private boolean btnShinseiDisabled;

    /**
     * /* モード
     */
    private String mode;

    /**
     * データビジョン
     */
    private String shisetsuDataVersion;

    /**
     * 更新ユーザーコード
     */
    private String koushinUserCd;

    /**
     * 更新カウンタ
     */
    private String koushinCounter;

}
