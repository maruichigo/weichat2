/*
 * EstimatePackRank.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.est;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class EstimatePackRank implements Serializable {

    //運賃ランク
    private String rank;

    public String getRank() {
        return rank;
    }

    public void setRank(String value) {
        this.rank = value;
    }

    //運賃ランクカラー
    private String rankColor;

    public String getRankColor() {
        return rankColor;
    }

    public void setRankColor(String value) {
        this.rankColor = value;
    }

    //ランク選択フラグ
    private boolean selected;

    public boolean getSelected() {
        return selected;
    }

    public void setSelected(boolean value) {
        this.selected = value;
    }

    //発・着地域名
    private String region;

    public String getRegion() {
        return region;
    }

    public void setRegion(String value) {
        this.region = value;
    }

    //発・着地List
    private List<String> cities;

    public List<String> getCities() {
        return cities;
    }

    public void setCities(List<String> value) {
        this.cities = value;
    }

    //印刷用の地域名１
    private String printRegion1;

    public String getPrintRegion1() {
        return printRegion1;
    }

    public void setPrintRegion1(String value) {
        this.printRegion1 = value;
    }

    //印刷用の地域名２
    private String printRegion2;

    public String getPrintRegion2() {
        return printRegion2;
    }

    public void setPrintRegion2(String value) {
        this.printRegion2 = value;
    }

    //印刷用の地域名３
    private String printRegion3;

    public String getPrintRegion3() {
        return printRegion3;
    }

    public void setPrintRegion3(String value) {
        this.printRegion3 = value;
    }

    //印刷用の地域名４
    private String printRegion4;

    public String getPrintRegion4() {
        return printRegion4;
    }

    public void setPrintRegion4(String value) {
        this.printRegion4 = value;
    }

    //印刷用の地域名５
    private String printRegion5;

    public String getPrintRegion5() {
        return printRegion5;
    }

    public void setPrintRegion5(String value) {
        this.printRegion5 = value;
    }

    //印刷用の地域名６
    private String printRegion6;

    public String getPrintRegion6() {
        return printRegion6;
    }

    public void setPrintRegion6(String value) {
        this.printRegion6 = value;
    }

    //印刷用の地域名７
    private String printRegion7;

    public String getPrintRegion7() {
        return printRegion7;
    }

    public void setPrintRegion7(String value) {
        this.printRegion7 = value;
    }

    //印刷用の地域名８
    private String printRegion8;

    public String getPrintRegion8() {
        return printRegion8;
    }

    public void setPrintRegion8(String value) {
        this.printRegion8 = value;
    }

    //列並び順
    private int colOrder;

    public int getColOrder() {
        return colOrder;
    }

    public void setColOrder(int value) {
        this.colOrder = value;
    }

    //RegionIndex（引取時の着地Index）
    private int regindex;

    public int getRegindex() {
        return regindex;
    }

    public void setRegindex(int value) {
        this.regindex = value;
    }

    public EstimatePackRank() {
        //運賃ランク
        this.rank = "";

        //運賃ランクカラー
        this.rankColor = "";

        //ランク選択フラグ
        this.selected = false;

        //発・着地域名
        this.region = "";

        //発・着地List
        this.cities = new ArrayList<>();

        //印刷用の地域名１
        this.printRegion1 = "";

        //印刷用の地域名２
        this.printRegion2 = "";

        //印刷用の地域名３
        this.printRegion3 = "";

        //印刷用の地域名４
        this.printRegion4 = "";

        //印刷用の地域名５
        this.printRegion5 = "";

        //印刷用の地域名６
        this.printRegion6 = "";

        //印刷用の地域名７
        this.printRegion7 = "";

        //印刷用の地域名８
        this.printRegion8 = "";

        //列並び順
        this.colOrder = 0;

        //RegionIndex（引取時の着地Index）
        this.regindex = 0;
    }
}
