/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.RirekiListCol;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.forms.mst.Mst091Form;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst092Form;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 仕入予定一覧画面
 *
 * @author 廖鈺 (MBP)
 * @version 2019/1/24 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst091")
@ViewScoped
@Data
public class Mst091Bean extends AbstractBean {

    /**
     * タイトル
     */
    private final String TITLE = "仕入予定一覧";
    
    /**
     * ダウンロードファイル名
     */
    private final static String FILE_NAME = "仕入予定マスタ一覧";    
    
    /**
     * 画面URL
     */
    private String url;

    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authorityConfBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;

    /**
     * ファイルダウンロード
     */
    @ManagedProperty(value = "#{fileBean}")
    private FileBean fileBean;

    /**
     * 画面フォーム
     */
    @ManagedProperty(value = "#{mst091Form}")
    private Mst091Form mst091Form;

    /**
     * 画面共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * 検索シーケンス処理共通
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;

    /**
     * 履歴一覧処理共通
     */
    @ManagedProperty(value = "#{rirekisyosai}")
    private RirekiSyosaiBean rirekiSyosaiBean;

    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    /**
     * スクリーンコード：MST091
     */
    private static final String SC_CD_MST091 = "MST091_SCREEN";

    /**
     * 世代検索条件 デフォルト値
     */
    private static final String[] DEFAULT_VALUE = {"01", "02"};

    /**
     * 定数：検索ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH = "mst091_search";

    /**
     * 定数：検索件数取得件数ファンクションコード
     */
    private static final String FUNC_CODE_COUNT = "mst091_count";

    /**
     * 定数：仕入予定一覧削除ファンクションコード
     */
    private static final String FUNC_CODE_DELETE = "mst091_delete";

    /**
     * 定数：削除の存在チェックファンクションコード
     */
    private static final String FUNC_CODE_DELETE_EXIST_CHECK = "mst091_delete_exist_check";

    /**
     * 定数：一覧のデータテーブルID
     */
    private static final String DATA_TABLE_ID = "tablesorter_mst091";

    /**
     * 定数：画面項目保持キー
     */
    private static final String CONST_MST091_FORM = "mst091Form";

    /**
     * 定数：MasterInfo取得キー
     */
    private static final String CONST_MST091_MASTER = "mst091";
    
     /**
     * 定数：再検索ボタン取得キー
     */
    private static final String CONST_MST091_SEARCH = "search_mst091";    

    /**
     * 履歴テーブル検索キー
     */
    private Map<String, Object> rirekiSearchKey;

    /**
     * ワーク.メッセージリスト
     */
    List<MessageModuleBean> msgList = new ArrayList<>();

    /**
     * コンストラクタ
     */
    public Mst091Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId メニューID
     * @param prevScreen 遷移元画面ID
     * @param backFlag 戻るフラグ
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            
            // パンくず追加
            breadBean.push(TITLE, SCREEN.MST091_SCREEN.name(), this);

            // マスタ内容取得
            pageCommonBean.getMasterInfo(CONST_MST091_MASTER);

            // 検索シーケンス処理ため初期化
            searchHelpBean.regSearchHelp(DATA_TABLE_ID,
                    s -> { return getRecordCount();},
                    s -> { search();return null;},
                    null);
            searchHelpBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);

            // 世代検索条件:"現在適用","未来適用"にチェック
            mst091Form.setConSedaiKensakuJoken(DEFAULT_VALUE);

            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(営業所リスト)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO, new AutoCompOptionBean("全て", "all"));
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(仕入先(Axis)リスト)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_SHIIRESAKI);
             // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(仕入先（SS）リスト)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_MS_SS_SHIIRESAKI);
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(仕入区分リスト)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_MS_SHIIRE_RYOKIN_KOMOKU);
           
            // 前回の記録をクリアする
            this.clear();
            mst091Form.setSearchResult(null);
            mst091Form.setSearchResultSelectable(null);
            mst091Form.setSelectedSearchResult(null);

            // 戻ってきた場合
            Mst091Form preForm = (Mst091Form) pageCommonBean.getPageInfo(CONST_MST091_FORM);
            if (backFlag && preForm != null) {
                PageCommonBean.simpleCopy(preForm, mst091Form);
                // 再検索を実施する
                pageCommonBean.searchAgain(CONST_MST091_SEARCH);
            } else {
                // 進んできた場合
                Flash flash = pageCommonBean.getPageParam();
                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_MST091_FORM) != null) {
                    PageCommonBean.simpleCopy(flash.get(CONST_MST091_FORM), mst091Form);
                    // 再検索を実施する
                    pageCommonBean.searchAgain(CONST_MST091_SEARCH);
                }
            }

            // ダウンロードシーケンス初期化
            fileBean.setDataSize(DATA_TABLE_ID, (id -> {return getRecordCount();})); 
            fileBean.setSearchResult(DATA_TABLE_ID, (id -> {return getSearchResult();})); 
            fileBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);    
            fileBean.setSubFlg(false);
            fileBean.setTilte(FILE_NAME);
            fileBean.regDownloadFucntion(DATA_TABLE_ID, getHeader(),(id -> { return getShiireYotelList();}));
            fileBean.regBeforeDownFucntion(DATA_TABLE_ID, (comment -> {return beforeDown(comment);}));

            // 削除するため登録
            pageCommonBean.regDelFucntion(DATA_TABLE_ID, (dataList -> (this.delRows(dataList))));

            // component初期化とユーザ権限により制御設定
            pageCommonBean.setAuthControll(mst091Form, SC_CD_MST091, true);
            
            // 初期はデータを編集不可にする
            mst091Form.setBtnEditeDisabled(true);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * カウント処理
     *
     * @return 件数
     */
    public long getRecordCount() {

        // 前回の記録をクリアする
        Map<String, Object> mapRec = new LinkedHashMap();
        mapRec.put(StndConsIF.CONST_ZERO_STRING, true);
        List<Map<String, Object>> mapList = new ArrayList();
        mapList.add(mapRec);
        mst091Form.setSearchResult(mapList);
        mst091Form.setSearchResultSelectable(new ReportListDataModel(mst091Form.getSearchResult()));
        mst091Form.setSelectedSearchResult(null);
        
        // 検索初期はデータを編集不可にする
        mst091Form.setBtnEditeDisabled(true);
        
        // レコード件数を取得する
        long recordCount = getShiireYotelListKensu();
        
        // 検索部のステータスを変更する
        pageCommonBean.setSerchConDisabled(mst091Form);
        // 参照モードにする
        pageCommonBean.setEditFlg(false);

        // 検索条件保存
        pageCommonBean.savePageInfo(CONST_MST091_FORM, mst091Form);

        return recordCount;
    }

    /**
     * 検索処理
     *
     */
    public void search() {

        // 選択リストを初期化
        mst091Form.setSelectedSearchResult(new ArrayList<>());
        mst091Form.setSearchResultSelectable(null);

        // 検索実施
        List<Map<String, Object>> recordList = getShiireYotelList();

        fileBean.setDataList(recordList);

        // 取得した値を画面項目にセットする
        pageCommonBean.setDatalist(DATA_TABLE_ID, recordList);
        
        if(recordList != null) {
            mst091Form.setSearchResultSelectable(new ReportListDataModel(recordList));
        }
        // 検索部のステータスを変更する
        pageCommonBean.setSerchConDisabled(mst091Form);

        // 検索部のステータス変更
        if (mst091Form.getConSakujoSumiNomi() == null || mst091Form.getConSakujoSumiNomi().length == 0) {
            // 削除済みデータを編集可にする
            mst091Form.setBtnEditeDisabled(false);
        } else {
            // 削除済みデータを編集不可にする
            mst091Form.setBtnEditeDisabled(true);
        }

        // 検索条件保存
        pageCommonBean.savePageInfo(CONST_MST091_FORM, mst091Form);

        // 参照モードにする
        pageCommonBean.setEditFlg(false);
    }

    /**
     * 検索条件変更処理
     *
     */
    public void searchChange() {

        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mst091Form);
    }

    /**
     * クリア処理
     *
     */
    public void clear() {

        // 検索部の条件クリア
        mst091Form.setConEigyoshoCd(null);
        mst091Form.setConShiiresakiCdAxis(null);
        mst091Form.setConShiiresakiCdSS(null);
        mst091Form.setConShiireKbn(null);
        mst091Form.setConTekiyobi(null);
        mst091Form.setConSakujoSumiNomi(null);
        
        // 検索部の世代検索条件初期化
        mst091Form.setConSedaiKensakuJoken(DEFAULT_VALUE);
        
        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mst091Form);
        pageCommonBean.setBtnSearchChangeVisible(false);
        pageCommonBean.setBtnSearchVisible(Boolean.TRUE);
    }
    
    /**
     * 業務削除前チェック処理
     * 
     */
    public void delBeforeCheck() {
        
        // エラーメッセージを格納する変数を初期化する
        msgList = new ArrayList<>();

        // 行選択チェック
        if (mst091Form.getSelectedSearchResult() == null || mst091Form.getSelectedSearchResult().isEmpty()) {
            // メッセージを設定する
             MessageModuleBean message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
            msgList.add(message);

            messagePropertyBean.messageList(msgList);
        } else {
            // 削除確認ダイアログ表示
            pageCommonBean.executeScript("PF('confirmDialog').show()");
        }
    }
    
    /**
     * 業務削除処理ファンクション領域
     *
     */
    public void delRowsFunc() {
            
        pageCommonBean.getSelectedDatasList().put(DATA_TABLE_ID, mst091Form.getSelectedSearchResult());
        pageCommonBean.delRows(DATA_TABLE_ID);

    }
    
    /**
     * 業務削除処理
     *
     * @param recordList レコードリスト
     * @return 正常／異常
     */
    public Boolean delRows(List<Map<String, Object>> recordList) {

        // エラーメッセージを格納する変数を初期化する
        msgList = new ArrayList<>();

        // 存在チェック
        ServiceInterfaceBean serviceInterfaceBean =
                pageCommonBean.accsessDBWithList(recordList, FUNC_CODE_DELETE_EXIST_CHECK);

        // エラーの場合、処理を終了
        if (serviceInterfaceBean.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            
            // 存在しない場合は画面から削除しない
            
            MessageModuleBean message = messagePropertyBean.createMessageModule(
                    serviceInterfaceBean.getMessages().get(0)[0],
                    serviceInterfaceBean.getMessages().get(0)[1],
                    serviceInterfaceBean.getMessages().get(0)[2],
                    serviceInterfaceBean.getTableName());
            msgList.add(message);
            messagePropertyBean.messageList(msgList);
            return false;
        }

        // 削除処理を行う
        int status = findAndDeleteRecord(recordList);
        
        // エラーの場合、処理を終了
        if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            return false;
        }

        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0004, "削除");
        
        // ログ出力
        LOGGER.info("削除 " + recordList.size() + " 件");
        
        // 画面レコード削除
        mst091Form.getSearchResult().removeAll(recordList);
        
        return true;
    }
    
    /**
     * メニュークリック処理
     *
     * @param menuId メニューID
     * @param nextScreenId 遷移先画面ID
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreenId) {
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移を行う
        url = forward(nextScreenId, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック処理
     *
     * @param nextScreenId 遷移先画面ID
     * @param breadIndex パンくずのインデックス
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreenId, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        
        // 画面遷移を行う
        url = forward(nextScreenId, null, null, true);
        return url;
    }

    /**
     * ログアウトクリック処理
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authorityConfBean.logout();
    }
    
        /**
     * 画面遷移処理 (仕入区分リンク）
     *
     * @return 遷移先の画面URL
     */
    public String linkClick() {
        
        // 行選択データ
        Map<String, Object> recordList = mst091Form.getLinkSearchResult();

        Mst092Form mst092Form = new Mst092Form();
        AutoCompOptionBean autoCompOptionBean = null;
        
        // 営業所コード
        autoCompOptionBean = new AutoCompOptionBean();
        autoCompOptionBean.setValue(recordList.get("listEigyoshoCd").toString());
        autoCompOptionBean.setLabel(recordList.get("listEigyoshoMei").toString());
        mst092Form.setConEigyoshoCd(autoCompOptionBean);
        // 仕入区分コード
        autoCompOptionBean = new AutoCompOptionBean();
        autoCompOptionBean.setValue(recordList.get("listShiireKbnCd").toString());
        autoCompOptionBean.setLabel(recordList.get("listShiireKbn").toString());
        mst092Form.setConShiireKbn(autoCompOptionBean);
        // 仕入先コード
        autoCompOptionBean = new AutoCompOptionBean();
        autoCompOptionBean.setValue(recordList.get("listShiiresakiCd").toString());
        autoCompOptionBean.setLabel(recordList.get("listShiiresakiMei").toString());
        mst092Form.setConShiiresakiCd(autoCompOptionBean);
        // 適用開始日
        mst092Form.setConTekiyoKaishibi(recordList.get("listTekiyoKaisibi").toString());
        // 遷移画面パラメータを設定する
        Flash flash = pageCommonBean.getPageParam();
        flash.put("mst092Form", mst092Form);
        
        // 仕入予定詳細画面に遷移する
        return url = forward(SCREEN.MST092_SCREEN.name(), null, SCREEN.MST091_SCREEN.name(), false);
    }

    /**
     * 画面遷移処理 (新規追加）
     *
     * @return 遷移先の画面URL
     */
    public String btnShinkiTorokuClick() {
        
        //遷移画面パラメータ設定
        Flash flash = pageCommonBean.getPageParam();
        
        // 仕入区分コード
        flash.put("listShiireKbnCd", "");
        // 仕入先コード
        flash.put("listShiiresakiCd", "");
        // 適用開始日
        flash.put("listTekiyoKaisibi", "");
        // 営業所コード
        flash.put("listEigyoshoCd", "");
        
        // 仕入予定詳細画面に遷移する
        return url = forward(SCREEN.MST092_SCREEN.name(), null, SCREEN.MST091_SCREEN.name(), false);
    }

    /**
     * 画面遷移処理 (複写登録)
     *
     * @return 遷移先の画面URL
     */
    public String btnCopyTorokuClick() {
        
        // エラーメッセージを格納する変数を初期化する
        msgList = new ArrayList<>();
        AutoCompOptionBean autoCompOptionBean = null;
        
        // 行選択データ
        List<Map<String, Object>> recordList = mst091Form.getSelectedSearchResult();
        
        // 行選択チェック
        if (recordList == null || recordList.isEmpty()) {
            MessageModuleBean message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
            msgList.add(message);
            messagePropertyBean.messageList(msgList);
            return null;
        }
        // 複数選択チェック
        if (recordList.size() > 1) {
            MessageModuleBean message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
            msgList.add(message);
            messagePropertyBean.messageList(msgList);
            return null;
        }
        
        Mst092Form mst092Form = new Mst092Form();
        
        // 営業所コード
        autoCompOptionBean = new AutoCompOptionBean();
        autoCompOptionBean.setValue(recordList.get(0).get("listEigyoshoCd").toString());
        autoCompOptionBean.setLabel(recordList.get(0).get("listEigyoshoMei").toString());
        mst092Form.setConEigyoshoCd(autoCompOptionBean);
        // 仕入区分コード
        autoCompOptionBean = new AutoCompOptionBean();
        autoCompOptionBean.setValue(recordList.get(0).get("listShiireKbnCd").toString());
        autoCompOptionBean.setLabel(recordList.get(0).get("listShiireKbn").toString());
        mst092Form.setConShiireKbn(autoCompOptionBean);
        // 仕入先コード
        autoCompOptionBean = new AutoCompOptionBean();
        autoCompOptionBean.setValue(recordList.get(0).get("listShiiresakiCd").toString());
        autoCompOptionBean.setLabel(recordList.get(0).get("listShiiresakiMei").toString());
        mst092Form.setConShiiresakiCd(autoCompOptionBean);
        // 適用開始日
        mst092Form.setConTekiyoKaishibi(recordList.get(0).get("listTekiyoKaisibi").toString());
        // 遷移画面パラメータを設定する
        Flash flash = pageCommonBean.getPageParam();
        flash.put("mst092Form", mst092Form);

        // 仕入予定詳細画面に遷移する
        return url = forward(SCREEN.MST092_SCREEN.name(), null, SCREEN.MST091_SCREEN.name(), false);
    }

    /**
     * 更新履歴を表示処理
     *
     */
    public void rirekiIchiran() {

        // 履歴テーブル検索キー設定
        rirekiSearchKey = new HashMap();
        
        // 選択されたレコードを取得する
        Map<String, Object> selectRec = mst091Form.getSelectedSearchResult().get(0);
        
        // 営業所コード
        rirekiSearchKey.put("listEigyoshoCd", selectRec.get("listEigyoshoCd"));
        // 仕入先コード
        rirekiSearchKey.put("listShiiresakiCd", selectRec.get("listShiiresakiCd"));
        // 仕入区分コード
        rirekiSearchKey.put("listShiireKbnCd", selectRec.get("listShiireKbnCd"));
        // 適用開始日
        rirekiSearchKey.put("listTekiyoKaisibi", selectRec.get("listTekiyoKaisibi"));

        // 履歴タイトルを設定する
        rirekiSyosaiBean.setListColName(new ArrayList<>(Arrays.asList( "バージョン情報","仕入区分", 
                "仕入先コード", "仕入先名称", "適用開始日", "単位", "単価", "曜日別仕入額_月", "曜日別仕入額_火", 
                "曜日別仕入額_水", "曜日別仕入額_木", "曜日別仕入額_金", "曜日別仕入額_土", "曜日別仕入額_日祝",
                "仕入予定明細合計金額", "営業所コード", "営業所名称", "終了フラグ")));

        // 履歴beanの項目物理名を設定する
        List<String> colValue = new ArrayList<>(Arrays.asList("listDataVersion","listShiireKbn",
                "listShiiresakiCd", "listShiiresakiMei", "listTekiyoKaisibi", "listTani", "listTanka",
                "listYobibetuShiiregakuGetuyo", "listYobibetuShiiregakuKayo", "listYobibetuShiiregakuSuiyo",
                "listYobibetuShiiregakuMokuyo", "listYobibetuShiiregakuKinyo", "listYobibetuShiiregakuDoyo",
                "listYobibetuShiiregakuNitiShuku", "listShiireYoteiMeisaiGokeiKingaku", "listEigyoshoCd",
                "listEigyoshoMei", "listShuryo"));
        List<String> colAlign = new ArrayList<>(Arrays.asList("left","left",
                "left", "left", "center", "center", "right",
                "right", "right", "right",
                "right", "right", "right",
                "right", "right", "left",
                "left", "center"));
        List<RirekiListCol> listCol = new ArrayList<>();
        for (int i = 0; i < colValue.size(); i++) {
           RirekiListCol col = new RirekiListCol();
           col.setColValue(colValue.get(i));
           col.setColAlign(colAlign.get(i));
           listCol.add(col);
        }
        rirekiSyosaiBean.setListCol(listCol);

        // 履歴テーブルを検索する
        rirekiSyosaiBean.searchList("2", "MST091_SEARCH_RIREKI", rirekiSearchKey);
    }

    /**
     * ダウンロード理由を記録する処理
     *
     * @param comment 理由コメント
     * @return 正常／異常
     * @throws Exception
     */
    public boolean beforeDown(String comment) throws Exception {
        
        // ダウンロード理由を記録する
        System.out.println(comment);
        
        return true;
    }

    /**
     * CSVファイルのタイトルを設定する処理
     * 
     * @return 画面タイトル
     */
    public List<CSVDto> getHeader() {
        
        // CSVファイルのタイトルを設定する
        List<CSVDto> header = new ArrayList<>();
        // 仕入区分
        header.add(new CSVDto("仕入区分", "listShiireKbn"));
        // 仕入先コード
        header.add(new CSVDto("仕入先コード", "listShiiresakiCd"));
        // 仕入先名称
        header.add(new CSVDto("仕入先名称", "listShiiresakiMei"));
        // 適用開始日
        header.add(new CSVDto("適用開始日", "listTekiyoKaisibi"));
        // 単位
        header.add(new CSVDto("単位", "listTani"));
        // 単価
        header.add(new CSVDto("単価", "listTanka"));
        // 曜日別仕入額_月
        header.add(new CSVDto("曜日別仕入額_月", "listYobibetuShiiregakuGetuyo"));
        // 曜日別仕入額_火
        header.add(new CSVDto("曜日別仕入額_火", "listYobibetuShiiregakuKayo"));
        // 曜日別仕入額_水
        header.add(new CSVDto("曜日別仕入額_水", "listYobibetuShiiregakuSuiyo"));
        // 曜日別仕入額_木
        header.add(new CSVDto("曜日別仕入額_木", "listYobibetuShiiregakuMokuyo"));
        // 曜日別仕入額_金
        header.add(new CSVDto("曜日別仕入額_金", "listYobibetuShiiregakuKinyo"));
        // 曜日別仕入額_土
        header.add(new CSVDto("曜日別仕入額_土", "listYobibetuShiiregakuDoyo"));
        // 曜日別仕入額_日祝
        header.add(new CSVDto("曜日別仕入額_日祝", "listYobibetuShiiregakuNitiShuku"));
        // 仕入予定明細合計金額
        header.add(new CSVDto("仕入予定明細合計金額", "listShiireYoteiMeisaiGokeiKingaku"));
        // 営業所コード
        header.add(new CSVDto("営業所コード", "listEigyoshoCd"));
        // 営業所名称
        header.add(new CSVDto("営業所名称", "listEigyoshoMei"));
        // 終了フラグ
        header.add(new CSVDto("終了フラグ", "listShuryo"));

        // 取得値を返却する
        return header;
    }
    
    
    /**
     * ダウンロード検査結果取得
     * 
     * @return 検索結果
     */
    public List<Map<String, Object>> getSearchResult() {
        return mst091Form.getSearchResult();
    }
    
    /**
     * DBから仕入予定一覧検索件数を取得する
     * 
     */
    private long getShiireYotelListKensu() {

        // パラメータ
        Map<String, Object> params = new HashMap<>();
        
        // 全営業所検索
        if (pageCommonBean.getMasterInfo().getAllEigyoshoSearch() != null) {
            params.put("allEigyoshoSearch", pageCommonBean.getMasterInfo().getAllEigyoshoSearch());
        }
        // 営業所コード
        if (mst091Form.getConEigyoshoCd() != null) {
            params.put("conEigyoshoCd", mst091Form.getConEigyoshoCd().getValue());
        }
        // 仕入先コード（Axis)
        if (mst091Form.getConShiiresakiCdAxis() != null) {
            params.put("conShiiresakiCdAxis", mst091Form.getConShiiresakiCdAxis().getValue());
        }
        // 仕入先コード(SS)
        if (mst091Form.getConShiiresakiCdSS() != null) {
            params.put("conShiiresakiCdSS", mst091Form.getConShiiresakiCdSS());
        }
        // 仕入区分
        if (mst091Form.getConShiireKbn() != null) {
            params.put("conShiireKbn", mst091Form.getConShiireKbn().getValue());
        }
        // 世代検索条件
        params.put("conSedaiKensakuJoken", mst091Form.getConSedaiKensakuJoken());
        // 適用開始日
        if (mst091Form.getConTekiyobi() != null) {
            params.put("conTekiyobi", mst091Form.getConTekiyobi());
        }
        // 削除済のみ
        if (mst091Form.getConSakujoSumiNomi() == null || mst091Form.getConSakujoSumiNomi().length == 0) {
            params.put("conSakujoSumiNomi", "0");
        } else {
            params.put("conSakujoSumiNomi", "1");
        }
        // ログインユーザー所属営業所
        params.put("loginUserShozokuEigyosho", authorityConfBean.getLoginUserShozokuEigyosho());
        
        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_COUNT);

        // 検索件数を返却する
        return Long.valueOf(res.getJson());
    }

    /**
     * 仕入予定一覧情報を取得する
     * 
     */
    private List<Map<String, Object>> getShiireYotelList() {

        // パラメータ
        Map<String, Object> params = new HashMap<>();
        
        // 全営業所検索
        if (pageCommonBean.getMasterInfo().getAllEigyoshoSearch() != null) {
            params.put("allEigyoshoSearch", pageCommonBean.getMasterInfo().getAllEigyoshoSearch());
        }
        // 営業所コード
        if (mst091Form.getConEigyoshoCd() != null) {
            params.put("conEigyoshoCd", mst091Form.getConEigyoshoCd().getValue());
        }
        // 仕入先コード（Axis)
        if (mst091Form.getConShiiresakiCdAxis() != null) {
            params.put("conShiiresakiCdAxis", mst091Form.getConShiiresakiCdAxis().getValue());
        }
        // 仕入先コード(SS)
        if (mst091Form.getConShiiresakiCdSS() != null) {
            params.put("conShiiresakiCdSS", mst091Form.getConShiiresakiCdSS());
        }
        // 仕入区分
        if (mst091Form.getConShiireKbn() != null) {
            params.put("conShiireKbn", mst091Form.getConShiireKbn().getValue());
        }
        // 世代検索条件
        params.put("conSedaiKensakuJoken", mst091Form.getConSedaiKensakuJoken());
        // 適用開始日
        if (mst091Form.getConTekiyobi() != null) {
            params.put("conTekiyobi", mst091Form.getConTekiyobi());
        }
        // 削除済のみ
        if (mst091Form.getConSakujoSumiNomi() == null || mst091Form.getConSakujoSumiNomi().length == 0) {
            params.put("conSakujoSumiNomi", "0");
        } else {
            params.put("conSakujoSumiNomi", "1");
        }
        // ログインユーザー所属営業所
        params.put("loginUserShozokuEigyosho", authorityConfBean.getLoginUserShozokuEigyosho());
        
        try {
            // DBをアクセスする
            ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH);
            ObjectMapper mapper = new ObjectMapper();
            mst091Form.setSearchResult(mapper.readValue(serviceInterfaceBean.getJson(), List.class));
            
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
        
        // 検索結果一覧データ
        List<Map<String, Object>> searchResultList = new ArrayList();
        
        // 金額フォーマット
        DecimalFormat decimalFormat = new DecimalFormat("#,###,###,###");
        // 適用開始日フォーマット
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        
        for(Map<String, Object> result : mst091Form.getSearchResult()) {
            
            // 適用開始日
            result.replace("listTekiyoKaisibi", 
                    dateFormat.format(result.get("listTekiyoKaisibi")));
            // 単価
            result.replace("listTanka", 
                    decimalFormat.format(result.get("listTanka")));
            // 曜日別仕入額_月
            result.replace("listYobibetuShiiregakuGetuyo", 
                    decimalFormat.format(result.get("listYobibetuShiiregakuGetuyo")));
            // 曜日別仕入額_火
            result.replace("listYobibetuShiiregakuKayo",
                     decimalFormat.format(result.get("listYobibetuShiiregakuKayo")));
            // 曜日別仕入額_水
            result.replace("listYobibetuShiiregakuSuiyo",
                     decimalFormat.format(result.get("listYobibetuShiiregakuSuiyo")));
            // 曜日別仕入額_木
            result.replace("listYobibetuShiiregakuMokuyo",
                     decimalFormat.format(result.get("listYobibetuShiiregakuMokuyo")));
            // 曜日別仕入額_金
            result.replace("listYobibetuShiiregakuKinyo",
                     decimalFormat.format(result.get("listYobibetuShiiregakuKinyo")));
            // 曜日別仕入額_土
            result.replace("listYobibetuShiiregakuDoyo",
                     decimalFormat.format(result.get("listYobibetuShiiregakuDoyo")));
            // 曜日別仕入額_日祝
            result.replace("listYobibetuShiiregakuNitiShuku",
                     decimalFormat.format(result.get("listYobibetuShiiregakuNitiShuku")));
            // 仕入予定明細合計金額
            result.replace("listShiireYoteiMeisaiGokeiKingaku",
                     decimalFormat.format(result.get("listShiireYoteiMeisaiGokeiKingaku")));
            
            searchResultList.add(result);
        }
        
        mst091Form.setSearchResult(null);
        mst091Form.setSearchResult(searchResultList);
        // 仕入予定一覧情報を返却する
        return mst091Form.getSearchResult();
    }

    /**
     * DBから仕入予定一覧情報を削除する
     * 
     * @param recordList レコードリスト
     * @return ステータスコード
     */
    private int findAndDeleteRecord(List<Map<String, Object>> recordList) {
        
        // DBをアクセス
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.accsessDBWithList(recordList, FUNC_CODE_DELETE);

        // ステータスコードを返却する
        return serviceInterfaceBean.getStatusCode();
    }
}
