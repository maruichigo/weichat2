/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.pro;

import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompleteBean;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 *
 * @author xupenggeyang
 */
@ManagedBean(name = "pro032")
@ViewScoped
@Data
public class Pro032Bean extends BaseBean {

    private final String strTitle = "売上入力訂正(ロジ)";
    private String url;     // URL

    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    @ManagedProperty(value = "#{autoComplete}")
    private AutoCompleteBean autoCompleteBean;

    private RestfullService rest;

    private static final Logger logger = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    //営業所コード
    private String eigyoshoCd = "";

    private String kokyakuCd = "";

    //日付指定チェック
    private Boolean hizukeCheck = Boolean.TRUE;

    //日付指定日時
    private Date hizukeDate = new Date();

    //請求タイミング
    private String requestTiming = "";

    //顧客コード
    private String customerCd = "";

    //並び順
    private String sortMethod = "1";

    //時間
    private int overTime = 1;

    private int count = 0;

    //売上入力・訂正未チェック顧客
    private int inputUncheckCustomer = 70;

    //プルーフチェック (未チェック顧客)
    private int fallbackUncheck = 86;

    public Pro032Bean() {

    }

    @Override
    public void init(String menuId, String prevScreen, boolean backFlg) {
        try {
            // パンくず追加
            breadBean.push("車両マスタ", Cnst.SCREEN.MST211_SCREEN.name(), this);
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }
    }

    @Override
    public String menuClick(String menuId, String nextScreen) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String logoutClick() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
//    private List<Car> cars;
//
//    private Car selectedCar;
//
//    private List<Car> selectedCars;
//
//    @ManagedProperty("#{carService}")
//    private CarService service;
//
//    @PostConstruct
//    public void init() {
//        cars = service.createCars(10);
//    }
//
//    public void setService(CarService service) {
//        this.service = service;
//    }
//
//    public Car getSelectedCar() {
//        return selectedCar;
//    }
//
//    public void setSelectedCar(Car selectedCar) {
//        this.selectedCar = selectedCar;
//    }
//
//    public List<Car> getSelectedCars() {
//        return selectedCars;
//    }
//
//    public void setSelectedCars(List<Car> selectedCars) {
//        this.selectedCars = selectedCars;
//    }
}
