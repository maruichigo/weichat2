/*
 * Copyright (C) 2014 MBP Corporation All Rights Reserved . 
 */
package jp.co.kintetsuls.file;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 *
 * @author wangmin
 */
@Data
@AllArgsConstructor
public class CSVDto{

    //タイトル
    private String title;

    //項目名称
    private String name;

    //辞書名
    private String converterName;

    //タイムフォーマット
    private String fomart;

    private List<FaceCodeMasterDto> codeMasterList;

    public CSVDto(String title, String name) {
        this.title = title;
        this.name = name;
    }

    public CSVDto(String title, String name, String converterName) {
        this.title = title;
        this.name = name;
        this.converterName = converterName;
    }

    public CSVDto(String title, String name, List<FaceCodeMasterDto> codeMasterList) {
        this.title = title;
        this.name = name;
        this.codeMasterList = codeMasterList;
    }
}
