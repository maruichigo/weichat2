/*
 * EstimateColumnModel.java 

 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.est;

import java.io.Serializable;

public class EstimateColumnModel implements Serializable {

    private String header;
    private String property;

    public EstimateColumnModel(String header, String property) {
        this.header = header;
        this.property = property;
    }

    public String getHeader() {
        return header;
    }

    public String getProperty() {
        return property;
    }
}