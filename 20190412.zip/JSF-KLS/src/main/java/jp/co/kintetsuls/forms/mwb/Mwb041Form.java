/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mwb;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.annotation.MaxSizeCheck;
import jp.co.kintetsuls.beans.common.annotation.NotEmpty;
import jp.co.kintetsuls.beans.common.annotation.NotNull;
import jp.co.kintetsuls.beans.common.annotation.DateCheck;
import lombok.Data;

/**
  * MAWB状況照会フォーム
 *
 * @author 廖鈺 (MBP)
 * @version 2019/2/02 新規作成
 */
@ManagedBean(name = "mwb041Form")
@ViewScoped
@Data
public class Mwb041Form implements  Serializable {
    
    private static final long serialVersionUID = 1L;

    /**
     * 発券営業所コード value
     */
    @NotNull(name = "発券営業所")
    private AutoCompOptionBean conHakkenEigyoshoCd;
    
    /**
     * 発券営業所コード Disabled
     */
    private boolean conHakkenEigyoshoCdDisabled;
    
    /**
     * 配布先営業所コード value
     */
    @NotNull(name = "配布先営業所")
    private AutoCompOptionBean conHaifusakiEigyoshoCd;
    
    /**
     * 配布先営業所コード Disabled
     */
    private boolean conHaifusakiEigyoshoCdDisabled;
    
    /**
     * 航空会社 value
     */
    @NotNull(name = "航空会社")
    private String conKokuGaisha;
    
    /**
     * 航空会社 Disabled
     */
    private boolean conKokuGaishaDisabled;
    
    /**
     * MAWB番号 value
     */
    @MaxSizeCheck(maxSize = 8, name = "MAWB番号")
    private String conMawbBango;
    
    /**
     * MAWB番号 Disabled
     */
    private boolean conMawbBangoDisabled;
    
    /**
     * 搭載日付From value
     */
    @DateCheck(name = " 搭載日付FROM") 
    private String conTosaiHizukeFrom;
    
    /**
     * 搭載日付From Disabled
     */
    private boolean conTosaiHizukeFromDisabled;
    
    /**
     * 搭載日付To value
     */
    @DateCheck(name = " 搭載日付TO") 
    private String conTosaiHizukeTo;
    
    /**
     * 搭載日付To Disabled
     */
    private boolean conTosaiHizukeToDisabled;
    
    /**
     * 表示条件選択
     */
    @NotEmpty(name = "表示条件選択")
    private String[] conHyojiJyokenSentaku;
    
    /**
     * 表示条件選択 Disabled
     */
    private boolean conHyojiJyokenSentakuDisabled;
    
    /**
     * 検索Visabled
     */
    private boolean btnSearchVisible;

    /**
     * 検索条件変更Visabled
     */
    private boolean btnSearchChangeVisible;
    
    /**
     * 編集Disabled
     */
    private boolean btnEditeDisabled;
    
    /***
     * 件数
     */
    private int kensu;
    
    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;
    
    /**
     * ダウンロードデータ
     */
    private List<Map<String, Object>> downloadResult;

    /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;

    /**
     * 選択された結果
     */
    private List<Map<String, Object>> selectedSearchResult;

    /**
     * 変更前
     */
    private Map<String, String> searchMotoList;
}
