package jp.co.kintetsuls.beans.common;

import javax.faces.bean.ManagedProperty;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;


@javax.faces.bean.ManagedBean(name = "sessionBean")
@javax.faces.bean.SessionScoped
@lombok.Data
public class SessionBean implements java.io.Serializable {

    @ManagedProperty(value = "#{appBean}")
    private ApplicationBean appBean;

    private static final long serialVersionUID = -55427847487642L;
    private long timeLimitSession = 0;

    // 画面保持情報
    private Map<String, Object> pageConData;    
    
    public SessionBean() {
        this.pageConData = new HashMap();
    }
    
    public void resetSessionTimeout(){
        timeLimitSession = System.currentTimeMillis() + appBean.getTimeoutSession();
    }
    
    public Object getPageConData(String str) {
        return pageConData.get(str);
    }

    public void setPageConData(String str, Object pageConData) {
        this.pageConData.put(str, pageConData);
    }

    @SuppressWarnings("unchecked")
    private static <T extends Serializable> T clone(HashMap obj) {

        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            oos.writeObject(obj);
            oos.close();

            return (T) baos.toByteArray();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
}
