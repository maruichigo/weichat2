/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.forms.mst;

import java.util.List;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.LabelValueBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.annotation.NotNull;
import lombok.Data;

/**
 * Mst351_拠点間卸値マスタ フォーム
 *
 * @author 邱志遠
 * @version 2019/1/9 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst351Form")
@ViewScoped
@Data
public class Mst351Form {
    
    /**
     * 発営業所
     */
    @NotNull(name = "発営業所")
    private AutoCompOptionBean conHatsuEigyousho;
    
    /**
     * 着営業所
     */
    @NotNull(name = "着営業所")
    private AutoCompOptionBean conChakuEigyousho;
            
    /**
     * 輸送方法コード
     */
    @NotNull(name = "輸送方法コード")
    private AutoCompOptionBean conYusoHohoCd;
                
    /**
     * 卸種別区分(検索条件)
     */
    @NotNull(name = "卸種別区分")
    private AutoCompOptionBean conOroshiShubetsuKbn;
                    
    /**
     * 計上先
     */
    @NotNull(name = "計上先")
    private AutoCompOptionBean conKeijhoSaki;
    
    /**
     * デフォルトフラグ
     */
    private String[] conDefaultFlg;
    
    /**
     * 削除済のみ
     */
    private String[] conSakujonomiKensaku;
    
    /**
     * 削除済のみリスト
     */
    private List<LabelValueBean> conSakujonomiKensakuLabelValueList;

    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;

     /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;    

     /**
     * 選択された結果
     */
    private List<Map<String, Object>> selectedSearchResult;
    
    /**
     * 検索Visabled
     */
    private boolean btnSearchVisible;

    /**
     * 検索条件変更Visabled
     */
    private boolean btnSearchChangeVisible;
    
    /**
     * 編集Disabled
     */
    private boolean btnEditeDisabled;
    
    /**
     * 検索条件Disabled
     */
    private boolean conSearchJokenDisabled;
}
