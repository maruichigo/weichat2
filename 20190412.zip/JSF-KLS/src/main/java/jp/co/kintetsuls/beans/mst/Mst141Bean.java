/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.KbnBean;
import jp.co.kintetsuls.beans.common.KbnModuleBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiListCol;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst141Form;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.kintetsuls.utils.DateUtils;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 施設マスタ一覧画面
 *
 * @author 王永 (MBP)
 * @version 2019/1/31 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst141")
@ViewScoped
@Data
public class Mst141Bean extends AbstractBean {

    /**
     * ダウンロードファイル名
     */
    private final static String FILE_NAME = "施設マスタ一覧";

    /**
     * タイトル
     */
    private final String TITLE = "施設マスタ一覧";

    /**
     * 画面URL
     */
    private String url;

    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

    /**
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    /**
     * ファイルダウンロード
     */
    @ManagedProperty(value = "#{fileBean}")
    private FileBean fileBean;

    /**
     * 画面フォーム
     */
    @ManagedProperty(value = "#{mst141Form}")
    private Mst141Form mst141Form;
    
    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;

    /**
     * 画面共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * 検索シーケンス処理共通
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;

    /**
     * 履歴一覧処理共通
     */
    @ManagedProperty(value = "#{rirekisyosai}")
    private RirekiSyosaiBean rirekiSyosai;

    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(
            new Object() {}.getClass().getEnclosingClass().getName());

    /**
     * スクリーンコード：MST141
     */
    private static final String SC_CD_MST141 = "MST141_SCREEN";

    /**
     * 定数：検索件数取得ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH_KENSU = "MST141_SEARCH_KENSU";

    /**
     * 定数：検索ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH = "MST141_SEARCH";

    /**
     * 定数：更新履歴取得ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH_RIREKI = "MST141_SEARCH_RIREKI";
    
    /**
     * 定数：削除申請ファンクションコード
     */
    private static final String FUNC_CODE_DEL_APPLY = "MST141_DEL_APPLY";
    
    /**
     * 定数：申請ステータス更新ファンクションコード
     */
    private static final String FUNC_CODE_UPDATE_STATUS = "MST141_UPDATE_STATUS";

    /**
     * 定数：一覧のデータテーブルID
     */
    private static final String DATA_TABLE_ID = "tablesorter_mst141";

    /**
     * 定数：画面項目保持キー
     */
    private static final String CONST_MST141_FORM = "mst141Form";

    /**
     * 定数：マスタ情報取得key
     */
    private static final String CONST_MST141_MASTER = "mst141";

    /**
     * 定数：再検索ボタン取得キー
     */
    private static final String CONST_MST141_SEARCH = "search_mst141";

    /**
     * ワーク.メッセージリスト
     */
    List<MessageModuleBean> msgList = new ArrayList<>();

    /**
     * 履歴テーブル検索キー
     */
    private Map<String, Object> rirekiSearchKey;
    
    /**
     * 区分マスタBean
     */
    @ManagedProperty(value = "#{kbnBean}")
    private KbnBean kbnBean;

    /**
     * コンストラクタ
     */
    public Mst141Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId メニューID
     * @param prevScreen 遷移元の画面
     * @param backFlag 戻るフラグ
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {

        try {
            // パンくず追加
            breadBean.push(TITLE, SCREEN.MST141_SCREEN.name(), this);

            // マスタ内容取得
            pageCommonBean.getMasterInfo(CONST_MST141_MASTER);

            // 検索シーケンス処理を初期化する
            searchHelpBean.regSearchHelp(DATA_TABLE_ID, s -> {return getRecordCount();},
                    s -> {search();return null;}, s -> {return searchCheck();});

            searchHelpBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);

            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(営業所リスト)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO, new AutoCompOptionBean("全て", "all"));

            // 前回の記録をクリアする
            this.clear();
            mst141Form.setSearchResult(null);
            mst141Form.setSearchResultSelectable(null);
            mst141Form.setSelectedSearchResult(null);

            // 戻ってきた場合
            Mst141Form preForm = (Mst141Form) pageCommonBean.getPageInfo(CONST_MST141_FORM);
            if (backFlag) {
                PageCommonBean.simpleCopy(preForm, mst141Form);
                // 再検索を実施する
                pageCommonBean.searchAgain(CONST_MST141_SEARCH);
                // 進んできた場合
            } else {
                Flash flash = pageCommonBean.getPageParam();
                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_MST141_FORM) != null) {
                    PageCommonBean.simpleCopy(flash.get(CONST_MST141_FORM), mst141Form);
                    // 再検索を実施する
                    pageCommonBean.searchAgain(CONST_MST141_SEARCH);
                }
            }

            // ダウンロードシーケンスを初期化する
            fileBean.setDataSize(DATA_TABLE_ID, (id -> {return getRecordCount();}));

            fileBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);

            fileBean.setTilte(FILE_NAME);

            fileBean.regDownloadFucntion(DATA_TABLE_ID, getHeader(), (id -> {return getShisetsuList();}));

            fileBean.regBeforeDownFucntion(DATA_TABLE_ID, (comment -> {return beforeDown(comment);}));
            
            fileBean.setSearchResult(DATA_TABLE_ID, (id -> {return getSearchResult();}));

            // component初期化とユーザ権限により制御設定
            pageCommonBean.setAuthControll(mst141Form, SC_CD_MST141, true);
            
            // 復帰画面データ保存
            pageCommonBean.savePageInfo(CONST_MST141_FORM, mst141Form);

        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

    }
    
    /**
     * 検索結果取得
     * 
     * @return 検索結果
     */
    public List<Map<String, Object>> getSearchResult() {
        return mst141Form.getSearchResult();
    }

    /**
     * カウント処理
     *
     * @return 検索件数
     */
    public Long getRecordCount() {

        // 前回の記録をクリアする
        Map<String, Object> mapRec = new LinkedHashMap();
        mapRec.put("hideFlg", "hideRow");
        List<Map<String, Object>> mapList = new ArrayList();
        mapList.add(mapRec);
        mst141Form.setSearchResult(mapList);
        mst141Form.setSearchResultSelectable(new ReportListDataModel(mst141Form.getSearchResult()));
        mst141Form.setSelectedSearchResult(null);

        // レコード件数を取得する
        long recordCount = getShisetsuKensu();

        // 検索部のステータスを変更する
        pageCommonBean.setSerchConDisabled(mst141Form);

        // 参照モードにする
        pageCommonBean.setEditFlg(false);
        
        // サブ検索条件フラグ設定
        fileBean.setSubFlg(subSearchConHad());

        // 検索条件保存
        pageCommonBean.savePageInfo(CONST_MST141_FORM, mst141Form);

        return recordCount;
    }
    
    /**
     * サブ検索条件入力判断
     * 
     * @return true:入力あり/false:入力しない
     */
    public boolean subSearchConHad() {
        
        // 世代検索条件
        if (mst141Form.getConSedaiKensakuJoken() != null && mst141Form.getConSedaiKensakuJoken().length > 0) {
            return true;
        }
        // 適用日
        if (mst141Form.getConTekiyoHi() != null) {
            return true;
        }
        // 申請状況
        if (mst141Form.getConShinseiJokyo() != null && mst141Form.getConShinseiJokyo().length > 0) {
            return true;
        }
        // 削除のみ
        if (mst141Form.getConSakujoSumiNomi() != null && mst141Form.getConSakujoSumiNomi().length > 0) {
            return true;
        }
        // 適用名
        if (!CheckUtils.isEmpty(mst141Form.getConTekiyoMei())) {
            return true;
        }

        return false;
    }

    /**
     * 検索処理
     *
     */
    public void search() {

        // 選択リストを初期化する
        mst141Form.setSelectedSearchResult(new ArrayList<>());
        mst141Form.setSearchResultSelectable(null);

        // 検索結果取得
        List<Map<String, Object>> recordList = getShisetsuList();

        // 配色定義を設定する
        setIchiranColor(recordList);

        fileBean.setDataList(recordList);

        // 取得した値を画面項目にセットする
        pageCommonBean.setDatalist(DATA_TABLE_ID, recordList);

        mst141Form.setSearchResultSelectable(new ReportListDataModel(recordList));

        // 検索部のステータスを変更する
        pageCommonBean.setSerchConDisabled(mst141Form);

        pageCommonBean.setDatalist(DATA_TABLE_ID, recordList);

        // 検索条件を保存する
        pageCommonBean.savePageInfo(CONST_MST141_FORM, mst141Form);

        // 参照モードにする
        pageCommonBean.setEditFlg(false);
        
        // サブ検索条件折畳む設定
        mst141Form.setCollapsed(true);
    }
    
    /**
     * 検索チェック
     * 
     * @return チェック通過・未通過
     */
    public String searchCheck() {

        // 世代検索条件で04(適用日指定)が選択されている場合、適用日の入力が行われているかチェックを行う。
        String[] checkList = mst141Form.getConSedaiKensakuJoken();
        if (checkList == null) {
            return "TRUE";
        }
        boolean hasFlg = Arrays.asList(checkList).contains("05");
        // 適用日指定を選択場合
        if (hasFlg) {
            msgList = new ArrayList<>();
            if (mst141Form.getConTekiyoHi() == null) {
                MessageModuleBean message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0028, "適用日指定", "適用日");
                msgList.add(message);
                messagePropertyBean.messageList(msgList);
                
                // チェック未通過
                return "FALSE";
            }
        }

        // チェック通過
        return "TRUE";
    }

    /**
     * 配色定義を設定する処理
     *
     * @param recordList レコードリスト
     */
    public void setIchiranColor(List<Map<String, Object>> recordList) {

        // 配色定義の判定を行う
    }

    /**
     * 検索条件変更処理
     *
     */
    public void searchChange() {

        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mst141Form);
        
        // サブ検索条件折畳む設定
        mst141Form.setCollapsed(false);
    }

    /**
     * クリア処理
     *
     */
    public void clear() {

        // 管轄営業所
        mst141Form.setConKankatsuEigyosho(null);
        // 施設コード
        mst141Form.setConShisetsuCd(null);
        // 施設名
        mst141Form.setConShisetsuMei(null);
        // 世代検索条件
        mst141Form.setConSedaiKensakuJoken(new String[5]);
        // 適用日
        mst141Form.setConTekiyoHi(null);
        // 申請状況
        mst141Form.setConShinseiJokyo(new String[5]);
        // 削除のみ検索
        mst141Form.setConSakujoSumiNomi(new String[1]);
        // 適用名
        mst141Form.setConTekiyoMei(null);

        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mst141Form);
        pageCommonBean.setBtnSearchChangeVisible(false);
        pageCommonBean.setBtnSearchVisible(Boolean.TRUE);
    }

    /**
     * DBから施設マスタ検索件数を取得する
     *
     * @return 検索件数
     */
    private Long getShisetsuKensu() {

        // パラメータ取得
        Map<String, Object> params = getParams();

        // DBをアクセスする
        ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH_KENSU);

        // 検索件数を返却する
        return Long.valueOf(res.getJson());
    }

    /**
     * 施設マスタ一覧情報を取得する
     *
     * @return 施設マスタ一覧情報
     */
    private List<Map<String, Object>> getShisetsuList() {

        // パラメータ取得
        Map<String, Object> params = getParams();

        try {
            // DBをアクセス
            ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH);
            ObjectMapper mapper = new ObjectMapper();
            mst141Form.setSearchResult(mapper.readValue(res.getJson(), List.class));
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return new ArrayList<>();
        }

        // 施設マスタ情報を返却する
        return mst141Form.getSearchResult();
    }

    /**
     * パラメータ設定処理
     *
     * @return パラメータ
     */
    public Map<String, Object> getParams() {

        // パラメータ
        Map<String, Object> params = new HashMap<>();

        // 管轄営業所
        if (mst141Form.getConKankatsuEigyosho() != null) {
            params.put("conKankatsuEigyoshoCd", mst141Form.getConKankatsuEigyosho().getValue());
        }
        // 全営業所検索
        params.put("allEigyoshoSearch", pageCommonBean.getMasterInfo().getAllEigyoshoSearch());
        // ログインユーザー管轄営業所リスト
        params.put("loginUserShozokuEigyosho", pageCommonBean.getAuthConfBean().getLoginUserShozokuEigyosho());
        // 施設コード
        params.put("conShisetsuCd", mst141Form.getConShisetsuCd());
        // 施設名
        params.put("conShisetsuMei", mst141Form.getConShisetsuMei());

        // 世代検索条件
        params.put("conSedaiKensakuJoken", mst141Form.getConSedaiKensakuJoken());
        // 現在適用
        params.put("conSedai1", "0");
        // 未来適用
        params.put("conSedai2", "0");
        // 終了予定
        params.put("conSedai3", "0");
        // 適用終了
        params.put("conSedai4", "0");
        // 適用日指定
        params.put("conSedai5", "0");
        List<String> sedaiKensakuJokenArr = getCheckedList(mst141Form.getConSedaiKensakuJoken(), MsCnst.SEDAI_KENSAKU_JOKEN);
        for (String sedai : sedaiKensakuJokenArr) {
            params.put("conSedai" + sedai, "1");
        }
        // 適用日
        params.put("conTekiyoHi", DateUtils.format(mst141Form.getConTekiyoHi(), "yyyy-MM-dd"));

        // 削除のみ検索
        if (mst141Form.getConSakujoSumiNomi().length == 0) {
            params.put("conSakujoNomiKensaku", "0");
        } else {
            params.put("conSakujoNomiKensaku", mst141Form.getConSakujoSumiNomi()[0]);
        }

        // 申請状況
        params.put("conShinseiJokyo", mst141Form.getConShinseiJokyo());
        // 未申請
        params.put("conStat1", "0");
        // 承認待ち
        params.put("conStat2", "0");
        // 承認済み
        params.put("conStat3", "0");
        // 差戻し
        params.put("conStat4", "0");
        List<String> shinseiJokyoArr = getCheckedList(mst141Form.getConShinseiJokyo(), MsCnst.SHINSEI_JOKYO);
        for (String stat : shinseiJokyoArr) {
            params.put("conStat" + stat, "1");
        }
        List<String> shinseiJokyoList = Arrays.asList(mst141Form.getConShinseiJokyo());
        if (shinseiJokyoList.size() == 1 && "03".equals(shinseiJokyoList.get(0))) {
            // 承認済のみ選択
            params.put("approveFlg", "1");
        } else {
            // 承認済以外も選択
            params.put("approveFlg", "0");
        }
        // 適用名
        params.put("conTekiyoMei", mst141Form.getConTekiyoMei());

        return params;
    }
    
    /**
     * チェックボックス選択内容転換
     * @param selectResults チェックボックス選択内容
     * @param groupCd 区分グループコード
     * @return 転換結果
     */
    private List<String> getCheckedList(String[] selectResults, String groupCd) {
        
        // 区分リスト
        List<KbnModuleBean> kbns = kbnBean.getKbnsOfGroupCd(groupCd);
        // 転換結果リスト
        List<String> checkedList = new ArrayList<>();
        // 配列からリストに転換する
        List<String> selectList = Arrays.asList(selectResults);
        for (int i = 0; i < kbns.size(); i++) {
            if (selectList.contains(kbns.get(i).getKbnCd())) {
                checkedList.add(String.valueOf(i + 1));
            }
        }
        return checkedList;
    }

    /**
     * 更新履歴を表示処理
     *
     */
    public void rirekiIchiran() {

        // 履歴テーブル検索キー設定
        rirekiSearchKey = new HashMap();
        Map<String, Object> selectRec = mst141Form.getSelectedSearchResult().get(0);
        // 施設コード
        rirekiSearchKey.put("listShisetsuCd", selectRec.get("listShisetsuCd"));
        // 適用開始日
        rirekiSearchKey.put("listTekiyoKaishibi", selectRec.get("listTekiyoKaishibiStr"));

        // 履歴タイトル設定
        rirekiSyosai.setListColName(new ArrayList<>(Arrays.asList(
                "バージョン情報", 
                "施設コード",
                "施設名",
                "適用開始日",
                "管轄営業所",
                "所在地",
                "電話番号",
                "敷地面積",
                "延床面積",
                "有効坪数",
                "事業所坪数",
                "倉庫坪数",
                "ステータス"
        )));

        // 履歴テーブル物理カラム設定
        List<String> colValue = new ArrayList<>(Arrays.asList(
                "shisetsuDataVersion",
                "listShisetsuCd",
                "listShisetsuMei",
                "listTekiyoKaishibiStr",
                "listKankatsuEigyosho",
                "listShozaichi",
                "listTelBango",
                "listShikichiMenseki",
                "listNobeyukaMenseki",
                "listYukoTsubosu",
                "listJigyoshoTsubosu",
                "listSokoTsubosu",
                "listStatus"
        ));
        
        List<String> colAlign = new ArrayList<>(Arrays.asList(
                "center",
                "center",
                "left",
                "center",
                "left",
                "left",
                "center",
                "right",
                "right",
                "right",
                "right",
                "right",
                "left"
        ));

        List<RirekiListCol> listCol = new ArrayList<>();
        for (int i = 0; i < colValue.size(); i++) {
           RirekiListCol col = new RirekiListCol();
           col.setColValue(colValue.get(i));
           col.setColAlign(colAlign.get(i));
           listCol.add(col);
        }
        rirekiSyosai.setListCol(listCol);

        // 履歴テーブルを検索する
        rirekiSyosai.searchList("2", FUNC_CODE_SEARCH_RIREKI, rirekiSearchKey);
    }

    /**
     * 出力ファイルヘッダー取得
     *
     * @return ヘッダー
     */
    public List<CSVDto> getHeader() {

        // CSVファイルのタイトルを設定
        List<CSVDto> header = new ArrayList<>();
        // 施設コード
        header.add(new CSVDto("施設コード", "listShisetsuCd"));
        // 施設名
        header.add(new CSVDto("施設名", "listShisetsuMei"));
        // 適用開始日
        header.add(new CSVDto("適用開始日", "listTekiyoKaishibiStr"));
        // 管轄営業所
        header.add(new CSVDto("管轄営業所", "listKankatsuEigyosho"));
        // 所在地
        header.add(new CSVDto("所在地", "listShozaichi"));
        // 電話番号
        header.add(new CSVDto("電話番号", "listTelBango"));
        // 敷地面積
        header.add(new CSVDto("敷地面積", "listShikichiMenseki"));
        // 延床面積
        header.add(new CSVDto("延床面積", "listNobeyukaMenseki"));
        // 有効坪数
        header.add(new CSVDto("有効坪数", "listYukoTsubosu"));
        // 事業所坪数
        header.add(new CSVDto("事業所坪数", "listJigyoshoTsubosu"));
        // 倉庫坪数
        header.add(new CSVDto("倉庫坪数", "listSokoTsubosu"));
        // ステータス
        header.add(new CSVDto("ステータス", "listStatus"));
        return header;
    }

    /**
     * メニュークリック処理
     *
     * @param menuId メニューID
     * @param nextScreenId 遷移先画面ID
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreenId) {

        try {
            // パンくずを削除する
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移を行う
        url = forward(nextScreenId, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック（処理）
     *
     * @param nextScreen 遷移先の画面
     * @param breadIndex 選択されたパンくずのIndex
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移を行う
        url = forward(nextScreen, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authConfBean.logout();
    }

    /**
     * 画面遷移処理
     *
     * @param actionFlg 処理フラグ
     * @return 遷移先の画面URL
     * @throws java.lang.IllegalAccessException
     * @throws java.lang.reflect.InvocationTargetException
     */
    public String buttonClick(String actionFlg) throws IllegalAccessException, InvocationTargetException {

        // パラメータ設定
        Flash flash = pageCommonBean.getPageParam();
        // モード
        flash.put("mode", actionFlg);

        // 新規以外場合
        if (!"insert".equals(actionFlg)) {
            // 行選択チェック
            msgList = new ArrayList<>();
            if (mst141Form.getSelectedSearchResult() == null || mst141Form.getSelectedSearchResult().isEmpty()) {
                // 選択しない場合
                MessageModuleBean message = messagePropertyBean.createMessageModule(
                        MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
                msgList.add(message);

                messagePropertyBean.messageList(msgList);
                return null;
            }
            if (mst141Form.getSelectedSearchResult().size() > 1) {
                // 選択行数が２行以上場合
                MessageModuleBean message = messagePropertyBean.createMessageModule(
                        MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0020);
                msgList.add(message);

                messagePropertyBean.messageList(msgList);
                return null;
            }
        
            // 施設コード
            flash.put("shisetsuCd", mst141Form.getSelectedSearchResult().get(0).get("listShisetsuCd"));
            // 適用開始日
            flash.put("tekiyoKaishibi", DateUtils.format(
                    new Date((Long)mst141Form.getSelectedSearchResult().get(0).get("listTekiyoKaishibi")), "yyyy/MM/dd"));
            // 適用フラグ
            flash.put("tekiyoFlg", mst141Form.getSelectedSearchResult().get(0).get("tekiyoFlg"));
        }

        // Mst142_施設マスタ詳細画面へ遷移 
        url = forward(SCREEN.MST142_SCREEN.name(), null, SCREEN.MST142_SCREEN.name(), false);
        return url;
    }

    /**
     * 明細照会へ
     *
     * @param shisetsuCd 施設コード
     * @param tekiyoKaishibi 適用開始日
     * @param tekiyoFlg 適用フラグ
     * @return 遷移先の画面URL
     */
    public String detail(String shisetsuCd, String tekiyoKaishibi, String tekiyoFlg) {

        // パラメータ設定
        Flash flash = pageCommonBean.getPageParam();
        // 施設コード
        flash.put("shisetsuCd", shisetsuCd);
        // 適用開始日
        flash.put("tekiyoKaishibi", DateUtils.format(new Date(Long.valueOf(tekiyoKaishibi)), "yyyy/MM/dd"));
        // 適用フラグ
        flash.put("tekiyoFlg", tekiyoFlg);
        // モード
        flash.put("mode", "detail");

        // Mst142_施設マスタ詳細画面へ遷移 
        url = forward(SCREEN.MST142_SCREEN.name(), null, SCREEN.MST142_SCREEN.name(), false);
        return url;
    }

    /**
     * 削除申請
     *
     * @return 遷移先の画面URL
     */
    public String delApply() {

        // 行選択チェック
        msgList = new ArrayList<>();
        if (mst141Form.getSelectedSearchResult() == null || mst141Form.getSelectedSearchResult().isEmpty()) {

            MessageModuleBean message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
            msgList.add(message);

            messagePropertyBean.messageList(msgList);
            return null;
        }
        // TODO QA待ち:DEV_KLS-1074 
        /*// 削除申請処理（データのチェック、更新、登録）
        // パラメータ
        Map<String, Object> params = new HashMap<>();
        // 選択したデータ
        List<Map<String, Object>> selectedSearchResult = mst141Form.getSelectedSearchResult();
        // 施設コード
        params.put("listShisetsuCd", selectedSearchResult.get(0).get("listShisetsuCd"));
        // 適用開始日
        params.put("listTekiyoKaishibi", DateUtils.format(
                (Date)selectedSearchResult.get(0).get("listTekiyoKaishibi"),
                DateUtils.DEFAULT_SEIREKI_FORMAT));
        // 更新ユーザーID
        params.put("koushinUserCd", selectedSearchResult.get(0).get("koushinUserCd"));
        // 更新カウンタ
        params.put("koushinCounter", selectedSearchResult.get(0).get("koushinCounter"));
        // バージョン
        params.put("shisetsuDataVersion", selectedSearchResult.get(0).get("shisetsuDataVersion"));
        
        // 処理行う
         ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_DEL_APPLY);
        // エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            MessageModuleBean message = messagePropertyBean.createMessageModule(
                    res.getMessages().get(0)[0],
                    res.getMessages().get(0)[1]);
            msgList = new ArrayList<>();
            msgList.add(message);
            messagePropertyBean.messageList(msgList);
            return null;
        }*/

        // パラメータ設定
        Flash flash = pageCommonBean.getPageParam();
        // ワーク.キー情報
        flash.put("key", mst141Form.getSelectedSearchResult().get(0).get("listShisetsuCd")
            + "," + mst141Form.getSelectedSearchResult().get(0).get("listTekiyoKaishibi"));
        // ワーク.申請種別コード
        flash.put("typeCd", "15");
        // ワーク.表示項目1
        flash.put("item1", "削除");
        // ワーク.表示項目2
        flash.put("item2", mst141Form.getSelectedSearchResult().get(0).get("listKankatsuEigyoshoCd")
            + "\r\n" + mst141Form.getSelectedSearchResult().get(0).get("listKankatsuEigyoshoMei"));
        // ワーク.表示項目3
        flash.put("item3", "無し");
        // ワーク.表示項目4
        flash.put("item4", "無し");
        // ワーク.表示項目5
        flash.put("item5", "無し");
        // ワーク.表示項目6
        flash.put("item6", mst141Form.getSelectedSearchResult().get(0).get("listTekiyoKaishibi"));

        // TODO 申請共通画面へ
        url = forward(SCREEN.DEM012_SCREEN.name(), null, SCREEN.DEM012_SCREEN.name(), false);
        return url;
    }
    
    /**
     * 申請ステータス更新
     * 
     * @param status ステータス
     */
    public void updateShinseiStatus(String status) {

        // パラメータ
        Map<String, Object> params = new HashMap<>();
        // 選択したデータ
        List<Map<String, Object>> selectedSearchResult = mst141Form.getSelectedSearchResult();
        // 施設コード
        params.put("listShisetsuCd", selectedSearchResult.get(0).get("listShisetsuCd"));
        // 適用開始日
        params.put("listTekiyoKaishibi", selectedSearchResult.get(0).get("listTekiyoKaishibi"));
        // DBをアクセスする
        pageCommonBean.getDBInfo(params, FUNC_CODE_UPDATE_STATUS);
    }

    /**
     * ダウンロード理由を記録する処理
     *
     * @param comment 理由コメント
     * @return 正常／異常
     * @throws Exception 異常
     */
    public boolean beforeDown(String comment) throws Exception {

        // ダウンロード理由を記録する
        System.out.println(comment);

        return true;
    }
}
