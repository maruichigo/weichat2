/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mst;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.LabelValueBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.forms.common.LabelValueForm;
import lombok.Data;

/**
 *ルートマスタフォーム
 * 
 * @author 黄義輝 (MBP)
 * @version 2019/03/19 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst111Form")
@ViewScoped
@Data
public class Mst111Form implements Serializable {

    /* 発地AutoComp */
    private AutoCompOptionBean conHatsuchi;

    /* 発地Label */
    private String conHatsuchiLabel;
    
    /* 発地Disabled */
    private boolean conHatsuchiDisabled;

    /* 発地Visabled */
    private boolean conHatsuchiVisible;

    /* 発地名 */
    private String conHatsuchiMei;
    
    /* 発地名Disabled */
    private boolean conHatsuchiMeiDisabled;
    
    /* 発地名Visabled */
    private boolean conHatsuchiMeiVisabled;

    /* 着地AutoComp */
    private AutoCompOptionBean conChakuchi;

    /* 着地Label */
    private String conChakuchiLabel;
    
    /* 着地Disabled */
    private boolean conChakuchiDisabled;

    /* 着地Visabled */
    private boolean conChakuchiVisible;
    
    /* 着地名 */
    private String conChakuchiMei;
    
    /* 着地名Disabled */
    private boolean conChakuchiMeiDisabled;

    /* 着地名Visabled */
    private boolean conChakuchiMeiVisabled;
    
    /* デフォルトルート検索 */
    private String[] conDefaultRouteKensaku;
    
    /* デフォルトルート検索Disabled */
    private boolean conDefaultRouteKensakuDisabled;
    
    /* デフォルトルート検索Visabled */
    private boolean conDefaultRouteKensakuVisabled;

    /* デフォルトルート検索リスト */
    private List<LabelValueBean> conDefaultRouteKensakuLabelValueList;
    
    /* デフォルトルート検索リストDisabled */
    private boolean conDefaultRouteKensakuLabelValueListDisabled;
    
    /* デフォルトルート検索リストVisabled */
    private boolean conDefaultRouteKensakuLabelValueListVisabled;

    /* デフォルトルート検索checkBox */
    private List<LabelValueForm> conDefaultRouteKensakuCheckBox;

    /* 削除済のみ */
    private String[] conSakujoSumiNomi;
    
    /* 削除済のみDisabled */
    private boolean conSakujoSumiNomiDisabled;
    
    /* 削除済のみVisabled */
    private boolean conSakujoSumiNomiVisabled;

    /* 削除済のみリスト */
    private List<LabelValueBean> conSakujoSumiNomiLabelValueList;
    
    /* 削除済のみリストDisabled */
    private boolean conSakujoSumiNomiLabelValueListDisabled;
    
    /* 削除済のみリストVisabled */
    private boolean conSakujoSumiNomiLabelValueListVisabled;

    /* 削除済のみcheckBox */
    private List<LabelValueForm> conSakujoSumiNomiCheckBox;

    /* 編集Disabled */
    private boolean btnEditeDisabled;

    /* 検索件数*/
    private long count;

    /* 検索Visabled */
    private boolean btnSearchVisible;

    /* 検索条件変更Visabled */
    private boolean btnSearchChangeVisible;

    /* 検索結果一覧データ */
    private List<Map<String, Object>> searchResult;

    /* 検索結果一覧選択できる */
    private ReportListDataModel searchResultSelectable;    

    /* 選択された結果 */
    private List<Map<String, Object>> selectedSearchResult;

    /* 経由地選択フラグ */
    private String selectedKeiyuchiFlag;

    /* 選択行FROM拠点コード */
    private String selectedFromKyotenCd;

    /* 選択行経由地１コード */
    private String selectedKeiyuchi1Cd;

    /* 選択行経由地2コード */
    private String selectedKeiyuchi2Cd;

}