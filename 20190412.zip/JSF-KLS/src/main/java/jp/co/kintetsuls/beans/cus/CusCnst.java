/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.cus;

import lombok.Data;

/**
 *
 * @author y_kamata
 */
@Data
public class CusCnst {
    public final static String ERR_BACK_COLOR = "background-color:red;";    // エラー色
    public final static String KOKYAKU_KBN_VALUE[] = {"1","2","3"};      // 顧客区分値
    public final static String KOKYAKU_KBN_MEI[] = {"一般","代理店","3PL"};  // 顧客名
    public final static String SHINSEI_STATUS_VALUE[] = {"01","02","03"};   // 申請ステータス値  
    public final static String SHINSEI_STATUS_MEI[] = {"未承認","承認待ち","承認済み"}; // 申請ステータス名
}
