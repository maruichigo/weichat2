/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Level;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import javax.faces.event.AjaxBehaviorEvent;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.KbnBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst363Form;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Mst363_月額自動請求マスタ(その他売上) 画面
 *
 * @author 邱志遠
 * @version 2019/1/9新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst363")
@ViewScoped
@Data
public class Mst363Bean extends AbstractBean {
    
    /**
     * タイトル
     */
    private final String titleName = "その他売上自動入力マスタ";
    
    /**
     * パンくず名
     */
    private final static String TITLE = "月額自動請求マスタ(その他売上)"; 
    
    /**
     * ダウンロードファイル名
     */
    private final static String FILE_NAME = "月額自動請求マスタ(その他売上)一覧";
    
    /**
     * 画面URL
     */
    private String url;     
    
    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;
    
    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

    /**
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;
    
    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messageProperty;
       
    /**
     * 画面フォーム
     */
    @ManagedProperty(value = "#{mst363Form}")
    private Mst363Form mst363Form;
    
    /**
     * ファイルダウンロード
     */
    @ManagedProperty(value = "#{fileBean}")
    private FileBean fileBean;
    
    /**
     * 共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * 検索シーケンス処理共通
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;

    /**
     * 履歴一覧処理共通
     */
    @ManagedProperty(value = "#{rirekisyosai}")
    private RirekiSyosaiBean rirekiSyosaiBean;  
    
    /**
     * 一覧単項目チェック共通
     */
    @ManagedProperty(value = "#{listCheckBean}")
    private ListCheckBean listCheckBean;
    
    /**
     * kbnBean
     */
    @ManagedProperty(value = "#{kbnBean}")
    private KbnBean kbnBean;
    
    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    /**
     * スクリーンコード：MST363
     */
    private static final String SC_CD_MST363 = "MST363_SCREEN";
    
    /**
     * 定数：検索件数取得ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH_KENSU = "mst363_search_kensu";
    
    /**
     * 定数：検索ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH = "mst363_search";
    
    /**
     * 定数：登録申請ファンクションコード
     */
    private static final String FUNC_CODE_UPDATE = "mst363_update";
    
    /**
     * 定数：登録申請チェックファンクションコード
     */
    private static final String FUNC_CODE_SONZAI_CHECK = "mst363_sonzai_check";
    
    /**
     * 定数：削除申請ファンクションコード
     */
    private static final String FUNC_CODE_DELETE = "mst363_delete";
    
    /**
     * 定数：削除の存在チェックファンクションコード
     */
    private static final String FUNC_CODE_DELETE_CHECK = "mst363_delete_check";
    
    /**
     * 定数：申請ステータス更新処理ファンクションコード
     */
    private static final String FUNC_CODE_UPDATE_CALLBACK = "mst363_update_callback";
    
    /**
     * 定数：未申請データ削除処理ファンクションコード
     */
    private static final String FUNC_CODE_DELETE_CALLBACK = "mst363_delete_callback";
    
    /**
     * 定数：一覧のデータテーブルID
     */
    private static final String DATA_TABLE_ID = "tablesorter_mst363";
    
    /**
     * 定数：画面項目保持キー
     */
    private static final String CONST_MST363_FORM = "mst363Form";

    /**
     * 定数：MasterInfo取得key.
     */
    private static final String CONST_MST363_MASTER = "mst363";
    
    /**
     * マスタ情報
     */
    private MasterInfoBean masterInfo;
    
    /**
     * 定数：再検索Button取得キー
     */
    private static final String CONST_MST363_SEARCH = "search_mst363";        

    /**
     * 履歴テーブル検索キー
     */
    private Map<String, Object> rirekiSearchKey;

    /**
     * ワーク.メッセージリスト
     */
    List<MessageModuleBean> msgList = new ArrayList<>();    
    
    /**
     * コンストラクタ
     */
    public Mst363Bean() {

    }
    
    /**
     * 一覧の単項目チェック処理
     * 
     * @param params 画面一覧パラメータ
     * @return チェックの結果
     */
    private boolean checkJsfParamas(List<Map<String, Object>> params) {

        List<ListCheckBean> checks = new ArrayList<>();
        /*
         * 顧客コード
         */
        checks.add(new ListCheckBean("listKokyakuCd", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "顧客コード"));
        /*
         * 売上日FROM
         */
        checks.add(new ListCheckBean("listUriagebiFrom",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "売上日FROM"));
        /*
         * 売上日TO
         */
        checks.add(new ListCheckBean("listUriagebiTo", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "売上日TO"));
        /*
         * お題目
         */
        checks.add(new ListCheckBean("listOdaimoku", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "お題目"));
        /*
         * お題目
         */
        checks.add(new ListCheckBean("listOdaimoku",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "お題目", "40"));
        /*
         * 伝票種別
         */
        checks.add(new ListCheckBean("listDempyoShubetsu",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "伝票種別"));
        /*
         * 料金項目
         */
        checks.add(new ListCheckBean("listRyokinKomoku",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "料金項目"));
        /*
         * 表示名
         */ 
        checks.add(new ListCheckBean("listHyojiMei",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "表示名", "40"));
        /*
         * 適用開始日
         */
        checks.add(new ListCheckBean("listTekiyoKaishibi",
                StndConsIF.DATA_TYPE_CALENDAR, StndConsIF.LIST_CHECK_NOT_NULL, "適用開始日"));
        /*
         * 単価
         */
        checks.add(new ListCheckBean("listTanka",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "単価", "10"));
        /*
         * 数量
         */
        checks.add(new ListCheckBean("listSuryo",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "数量", "9"));
        /*
         * 金額
         */
        checks.add(new ListCheckBean("listKingaku",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "金額", "10"));
        /*
         * 請求書備考1
         */
        checks.add(new ListCheckBean("listSeikyushoBiko1",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "請求書備考1", "40"));
        List<MessageModuleBean> checkMsgList = listCheckBean.check(params, checks, true);

        if (!checkMsgList.isEmpty()) {
            return false;
        }
        return true;
    }
    
    /**
     * 初期処理（処理）
     *
     * @param menuId  メニューID
     * @param prevScreen  遷移元画面ID
     * @param backFlag  戻るフラグ
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            // パンくず追加
            breadBean.push(TITLE, Cnst.SCREEN.MST363_SCREEN.name(), this);
            
            // システムマスタ取得する
            pageCommonBean.getMasterInfo(CONST_MST363_MASTER);
            
            // 検索シーケンス処理ため初期化
            searchHelpBean.regSearchHelp(DATA_TABLE_ID,
                    s -> {return getRecordCount(false);},
                    s -> { search();return null;},
                    s -> {return checkParamas();});
            searchHelpBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);
            
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する
            // 営業所
            // ワーク.営業所リスト
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO, new AutoCompOptionBean("全て", "all"));
            // 顧客
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_KOKYAKU);
            // 料金
            autoCompleteViewBean.getComMsDatasByVal(MsCnst.COM_GET_VW_FUTAI_RYOKIN_KOMOKU2, "9");
            // 売上日
            autoCompleteViewBean.getMsKbn(MsCnst.NYURYOKU_HIZUKE);
            
            // 前回の記録をクリアする
            this.clear();
            mst363Form.setSearchResult(null);
            mst363Form.setSearchResultSelectable(null);
            mst363Form.setSelectedSearchResult(null);
            
            // 戻ってきた場合
            Mst363Form preForm = (Mst363Form) pageCommonBean.getPageInfo(CONST_MST363_FORM);
            if (backFlag && preForm != null) {
                PageCommonBean.simpleCopy(preForm, mst363Form);
                // 再検索を実施する
                pageCommonBean.searchAgain(CONST_MST363_SEARCH);
            } else {
                // 進んできた場合
                Flash flash = pageCommonBean.getPageParam();
                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_MST363_FORM) != null) {
                    PageCommonBean.simpleCopy(flash.get(CONST_MST363_FORM), mst363Form);
                    // 再検索を実施する
                    pageCommonBean.searchAgain(CONST_MST363_SEARCH);
                }
            }
            
            // ダウンロードシーケンスを初期化する
            fileBean.setDataSize(DATA_TABLE_ID, (id -> {return getRecordCount(true);}));

            fileBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);

            fileBean.setSubFlg(false);

            fileBean.setTilte(FILE_NAME);

            fileBean.regDownloadFucntion(DATA_TABLE_ID, getHeader() ,
                    (id -> {return getKensakuList(true);}));
            
            fileBean.regBeforeDownFucntion(DATA_TABLE_ID,
                    (comment -> {return beforeDown(comment);}));
            
            fileBean.setSearchResult(DATA_TABLE_ID, (id -> {return getSearchResult();}));

            // 行更新また削除するために共通処理へ登録する
            pageCommonBean.regDelFucntion(DATA_TABLE_ID,
                    (dataList -> (this.delRows(dataList))));
            
            // component初期化とユーザ権限により制御設定
            pageCommonBean.setAuthControll(mst363Form, SC_CD_MST363, true);
            
            // 初期はデータを編集不可にする
            mst363Form.setBtnEditeDisabled(true);
                    
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        
        // 世代検索条件を初期化する
        mst363Form.setConSedaiKensakuJoken(new String[]{"01", "02"});
        
        // 申請状況を初期化する
        mst363Form.setConShinseiJokyo(new String[]{"01","02","03","04","05"});
    }
    
    /**
     * 検索パラメータチェック
     * 
     * @return チェックの結果
     */
    public String checkParamas() {
        
        // 行選択チェック
        if (mst363Form.getConSedaiKensakuJoken() != null && mst363Form.getConSedaiKensakuJoken().length > 0) {
            // 世代検索条件で適用日指定が選択されている場合
            if (kbnBean.getKbnCdOfKeyCd(MsCnst.SEDAI_KENSAKU_JOKEN_TEKIYO_HI_SHITEI).equals(
                    mst363Form.getConSedaiKensakuJoken()[mst363Form.getConSedaiKensakuJoken().length - 1])) {
                // 適用日
                if (mst363Form.getConTekiyoBi() == null) {
                    messageProperty.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0028,
                        "searchForm:sk:skc:sedaiKensaku_sedaiKensakuCalendar",
                        "適用日指定", "適用日");
                    return "FALSE";
                }
            }
        }
        return "TRUE";
    }
    
    /**
     * カウント処理
     *
     * @param downloadFlg ダウンロードフラグ
     * @return 取得件数
     */
    public Long getRecordCount(boolean downloadFlg) {
        
        // 前回の記録をクリアする
        Map<String, Object> mapRec = new LinkedHashMap();
        mapRec.put(StndConsIF.CONST_ZERO_STRING, true);
        List<Map<String, Object>> mapList = new ArrayList();
        mapList.add(mapRec);
        mst363Form.setSearchResult(mapList);
        mst363Form.setSearchResultSelectable(new ReportListDataModel(mst363Form.getSearchResult()));
        mst363Form.setSelectedSearchResult(null);
        
        // 検索初期はデータを編集不可にする
        mst363Form.setBtnEditeDisabled(true);
        
        // レコード件数を取得する
        long recordCount = getSearchKensu(downloadFlg);
        
        // サブ検索条件フラグ設定
        fileBean.setSubFlg(subSearchConHad());

        // ダウンロードチェック
        if (!downloadFlg) {

            // 検索部のステータスを変更する
            mst363Form.setConSearchJokenDisabled(true);

            // 参照モードにする
            pageCommonBean.setEditFlg(false);

            // 検索条件保存
            pageCommonBean.savePageInfo(CONST_MST363_FORM, mst363Form);
        }

        // 件数
        return recordCount;
    }
    
    /**
     * サブ検索条件入力判断
     * 
     * @return true:入力あり/false:入力しない
     */
    private boolean subSearchConHad() {
        
        // 適用名
        if (!CheckUtils.isEmpty(mst363Form.getConTekiyoMei())) {
            return true;
        }
        // 世代検索条件
        if (mst363Form.getConSedaiKensakuJoken() != null && mst363Form.getConSedaiKensakuJoken().length > 0) {
            return true;
        }
        // 適用日
        if (mst363Form.getConTekiyoBi() != null) {
            return true;
        }
        // 削除のみ
        if (mst363Form.getConSakujonomiKensaku() != null && mst363Form.getConSakujonomiKensaku().length > 0) {
            return true;
        }

        return false;
    }
    
    /**
     * DBから検索件数を取得する
     */
    private Long getSearchKensu(boolean downloadFlg) {
        
        // ダウンロードチェック
        if (downloadFlg) {
            mst363Form = (Mst363Form)pageCommonBean.getPageInfo(CONST_MST363_FORM);
        }
        // パラメータ
        Map<String, Object> params = new HashMap<>();
        // 営業所コード
        if (mst363Form.getConEigyoshoCd() != null) {
            params.put("conEigyoshoCd", mst363Form.getConEigyoshoCd().getValue());
        } else {
            params.put("conEigyoshoCd", mst363Form.getConEigyoshoCd());
        }
        // 顧客コード
        if (mst363Form.getConKokyakuCd() != null) {
            params.put("conKokyakuCd", mst363Form.getConKokyakuCd().getValue());
        } else {
            params.put("conKokyakuCd", mst363Form.getConKokyakuCd());
        } 
        // 料金項目
        if (mst363Form.getConRyokinKomoku() != null) {
            params.put("conRyokinKomoku", mst363Form.getConRyokinKomoku().getValue());
        } else {
            params.put("conRyokinKomoku", mst363Form.getConRyokinKomoku());
        }
        // 適用名
        params.put("conTekiyoMei", mst363Form.getConTekiyoMei());
        // 世代検索
        String[] conSedaiKensakuJoken = new String[5];
        List conSedaiKensakuJokenList = Arrays.asList(mst363Form.getConSedaiKensakuJoken());
        for (int i = 1; i < 6; i++) {
            if (conSedaiKensakuJokenList.isEmpty()) {
                conSedaiKensakuJoken[i - 1] = "0";
            } else {
                //循环リスト 比較値して値をつける
                for (Object object : conSedaiKensakuJokenList) {
                    if (i == Integer.valueOf(String.valueOf(object))) {
                        conSedaiKensakuJoken[i - 1] = "1";
                        break;
                    } else {
                        conSedaiKensakuJoken[i - 1] = "0";
                    }
                }
            }
        }
        params.put("conSedaiKensakuJoken", conSedaiKensakuJoken);
        // 申請状況
        List conShinseiJokyoList = Arrays.asList(mst363Form.getConShinseiJokyo());
        String[] conShinseiJokyo = {"", "", "", "", ""};
        if (!conShinseiJokyoList.isEmpty()) {
            if (conShinseiJokyoList.contains("01")) {
                conShinseiJokyo[0] = "01";
                params.put("conShinseiJokyo", conShinseiJokyo);
            }
            if (conShinseiJokyoList.contains("02")) {
                conShinseiJokyo[1] = "02";
                params.put("conShinseiJokyo", conShinseiJokyo);
            }
            if (conShinseiJokyoList.contains("03")) {
                conShinseiJokyo[2] = "03";
                params.put("conShinseiJokyo", conShinseiJokyo);
            }
            if (conShinseiJokyoList.contains("04")) {
                conShinseiJokyo[3] = "04";
                params.put("conShinseiJokyo", conShinseiJokyo);
            }
            if (conShinseiJokyoList.contains("05")) {
                conShinseiJokyo[4] = "05";
                params.put("conShinseiJokyo", conShinseiJokyo);
            }
        }
        // 適用日
        params.put("conTekiyoBi", mst363Form.getConTekiyoBi());
        // 削除済のみ
        params.put("conSakujonomiKensaku", mst363Form.getConSakujonomiKensaku());
        // ログインユーザー所属営業所
        params.put("loginUserShozokuEigyosho", authConfBean.getLoginUserShozokuEigyosho());
        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH_KENSU);

        // 検索件数を返却する
        return Long.valueOf(res.getJson());
    }
    
    /**
     * 検索処理
     *
     */
    public void search() {
        
        // 選択リストを初期化する
        mst363Form.setSelectedSearchResult(new ArrayList<>());
        mst363Form.setSearchResultSelectable(null);
        
        // 検索を行う
        List<Map<String, Object>> recordList = getKensakuList(false);
        
        // 配色定義を設定する
        setIchiranColor(recordList);
        // ダウンロード
        fileBean.setDataList(recordList);
        // 取得した値を画面項目にセットする
        pageCommonBean.setDatalist(DATA_TABLE_ID, recordList);
        
         try {
            mst363Form.setSearchResultSelectable(new ReportListDataModel(recordList));
        } catch (Exception e) {
        }
        
        // 検索部のステータスを変更する
        pageCommonBean.setSerchConDisabled(mst363Form);
        
        // 削除済のみのチェック状態より、明細データを編集可／不可にする
        if (mst363Form.getConSakujonomiKensaku() == null || mst363Form.getConSakujonomiKensaku().length == 0) {
            // 削除済みデータを編集可にする
            mst363Form.setBtnEditeDisabled(false);
        } else {
            // 削除済みデータを編集不可にする
            mst363Form.setBtnEditeDisabled(true);
        }
        // 検索条件保存
        pageCommonBean.savePageInfo(CONST_MST363_FORM, mst363Form);
        
        // 参照モードにする
        pageCommonBean.setEditFlg(false);
    }
    
    /**
     * 配色定義を設定する処理
     *
     * @param recordList // レコードリスト
     */
    public void setIchiranColor(List<Map<String, Object>> recordList) {

        // 配色定義の判定を行う
    }
    
    /**
     * 検索条件変更処理
     */
    public void searchChange() {
        
        // 検索部のステータスを変更する
        pageCommonBean.setSerchConEnabled(mst363Form);
    }
    
    /**
     * クリア処理
     */
    public void clear() {
        // 営業所クリア
        mst363Form.setConEigyoshoCd(null);
        // 顧客クリア
        mst363Form.setConKokyakuCd(null);
        // 料金科目クリア
        mst363Form.setConRyokinKomoku(null);
        // 削除済クリア
        mst363Form.setConSakujonomiKensaku(null);
        // 適用名クリア
        mst363Form.setConTekiyoMei(null);
        // 世代検索条件を初期化する
        mst363Form.setConTekiyoBi(null);
        // 現在適用：チェックあり
        // 未来適用：チェックあり
        mst363Form.setConSedaiKensakuJoken(new String[]{"01", "02"});
        // 申請状況を初期化する
        // すべてをチェックする
        mst363Form.setConShinseiJokyo(new String[]{"01","02","03","04","05"});
        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mst363Form);
        pageCommonBean.setBtnSearchChangeVisible(false);
        pageCommonBean.setBtnSearchVisible(Boolean.TRUE);
    }
    
    /**
     * 登録申請処理
     */
    public void update() {
        
        List<Map<String, Object>> datas = mst363Form.getSelectedSearchResult();
        // 行選択チェックを行う
        if (datas.isEmpty()) {
            messageProperty.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
            return;
        }
        
        // 単項目チェック処理
        if (!checkJsfParamas(datas)) {
            return;
        }
        
        // 必須チェック
        for (int row = 0; row < datas.size(); row++) {
            boolean checkFlag = false;
            // 終了チェック
            if (Boolean.parseBoolean(datas.get(row).get("listShuryoFlg").toString())
                    && datas.get(row).get("listTekiyoShuryobi") == null
                            ) {
                MessageModuleBean message = messageProperty.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0041, "終了する場合、適用終了日");
                msgList.add(message);
                checkFlag = true;
            }
            // 適用終了日
            if (Boolean.parseBoolean(datas.get(row).get("listShuryoFlg").toString())
                    && datas.get(row).get("listTekiyoShuryobi") != null
                            ) {
                MessageModuleBean message = messageProperty.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0048, "終了しない場合、適用終了日");
                msgList.add(message);
                checkFlag = true;
            }
            // 売上日FROM範囲チェック
            if (!CheckUtils.isAlphaNum(datas.get(row).get("listUriagebiFrom").toString())) {
                MessageModuleBean message = messageProperty.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0054, "売上日FROM", "1～31、99(月末)");
                msgList.add(message);
                checkFlag = true;
            }
            if (Integer.parseInt(datas.get(row).get("listUriagebiFrom").toString()) != 99) {
                if (!CheckUtils.isInRange(Integer.parseInt(datas.get(row).get("listUriagebiFrom").toString()), 1, 31)) {
                    MessageModuleBean message = messageProperty.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0054, "売上日FROM", "1～31、99(月末)");
                    msgList.add(message);
                    checkFlag = true;
                }
            }
            // 売上日TO範囲チェック
            if (!CheckUtils.isAlphaNum(datas.get(row).get("listUriagebiTo").toString())) {
                MessageModuleBean message = messageProperty.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0054, "listUriagebiTo", "1～31、99(月末)");
                msgList.add(message);
                checkFlag = true;
            }
            if (Integer.parseInt(datas.get(row).get("listUriagebiTo").toString()) != 99) {
                if (!CheckUtils.isInRange(Integer.parseInt(datas.get(row).get("listUriagebiTo").toString()), 1, 31)) {
                    MessageModuleBean message = messageProperty.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0054, "売上日TO", "1～31、99(月末)");
                    msgList.add(message);
                    checkFlag = true;
                }
            }
            // 単位・単価・数量・金額
            if (datas.get(row).get("listTanka") == null
                    || datas.get(row).get("listSuryo") == null
                    || datas.get(row).get("listTani") == null
                    ) {
                MessageModuleBean message = messageProperty.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0050, "単位・単価・数量", "金額");
                msgList.add(message);
                checkFlag = true;
            } else if (!CheckUtils.isEmpty(Integer.parseInt(datas.get(row).get("listTanka").toString())) 
                    && !CheckUtils.isEmpty(Integer.parseInt(datas.get(row).get("listTani").toString())) 
                    && !CheckUtils.isEmpty(Integer.parseInt(datas.get(row).get("listSuryo").toString())) 
                    ) {
                if (datas.get(row).get("listKingaku") == null) {
                    MessageModuleBean message = messageProperty.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0050, "単位・単価・数量", "金額");
                    msgList.add(message);
                    checkFlag = true;
                }
            }
            
            if (checkFlag) {
                messageProperty.messageList(msgList);
                msgList.clear();
                return;
            }
        }

        // 登録・更新処理を行う
        int status = insertUpdate();
        // エラーの場合、処理終了
        if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            return;
        }
    }
    /**
     * 登録申請処理
     *
     * @return
     */
    public int insertUpdate() {
        
        // 開始日フォーマット
        List<Map<String, Object>> kaishibiList = new ArrayList<>();
        for (Map<String, Object> row : mst363Form.getSelectedSearchResult()) {
            try {
                // 適用日フォーマット
                SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", Locale.US);
                row.put("listTekiyoKaishibi",  sdf.parse(row.get("listTekiyoKaishibi").toString()));
                kaishibiList.add(row);
            } catch (ParseException ex) {
                java.util.logging.Logger.getLogger(Mst363Bean.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        mst363Form.setSelectedSearchResult(kaishibiList);
        // 重複チェック、存在チェック
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(mst363Form.getSelectedSearchResult(), FUNC_CODE_SONZAI_CHECK);
        // エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            messageProperty.message(res.getMessages().get(0)[0], res.getMessages().get(0)[1], res.getMessages().get(0)[2], res.getTableName());
            return res.getStatusCode();
        }
        
        // 登録一覧リストの内容で新規登録する
        res = pageCommonBean.accsessDBWithList(mst363Form.getSelectedSearchResult(), FUNC_CODE_UPDATE);

        return res.getStatusCode();
    }

    /**
     * DBから情報を取得する
     * @param downloadFlg ダウンロードフラグ
     */
    private List<Map<String, Object>> getKensakuList(boolean downloadFlg) {
        // ダウンロードチェック
        if (downloadFlg) {
            mst363Form = (Mst363Form)pageCommonBean.getPageInfo(CONST_MST363_FORM);
        }
        // パラメータ
        Map<String, Object> params = new HashMap<>();
        // 営業所コード
        if (mst363Form.getConEigyoshoCd() != null) {
            params.put("conEigyoshoCd", mst363Form.getConEigyoshoCd().getValue());
        } else {
            params.put("conEigyoshoCd", mst363Form.getConEigyoshoCd());
        }
        // 顧客コード
        if (mst363Form.getConKokyakuCd() != null) {
            params.put("conKokyakuCd", mst363Form.getConKokyakuCd().getValue());
        } else {
            params.put("conKokyakuCd", mst363Form.getConKokyakuCd());
        } 
        // 料金項目
        if (mst363Form.getConRyokinKomoku() != null) {
            params.put("conRyokinKomoku", mst363Form.getConRyokinKomoku().getValue());
        } else {
            params.put("conRyokinKomoku", mst363Form.getConRyokinKomoku());
        }
        // 適用名
        params.put("conTekiyoMei", mst363Form.getConTekiyoMei());
        // 世代検索
        String[] conSedaiKensakuJoken = new String[5];
        List conSedaiKensakuJokenList = Arrays.asList(mst363Form.getConSedaiKensakuJoken());
        for (int i = 1; i < 6; i++) {
            if (conSedaiKensakuJokenList.isEmpty()) {
                conSedaiKensakuJoken[i - 1] = "0";
            } else {
                //循环リスト 比較値して値をつける
                for (Object object : conSedaiKensakuJokenList) {
                    if (i == Integer.valueOf(String.valueOf(object))) {
                        conSedaiKensakuJoken[i - 1] = "1";
                        break;
                    } else {
                        conSedaiKensakuJoken[i - 1] = "0";
                    }
                }
            }
        }
        params.put("conSedaiKensakuJoken", conSedaiKensakuJoken);
        
        // 申請状況
        List conShinseiJokyoList = Arrays.asList(mst363Form.getConShinseiJokyo());
        String[] conShinseiJokyo = {"", "", "", "", ""};
        if (!conShinseiJokyoList.isEmpty()) {
            if (conShinseiJokyoList.contains("01")) {
                conShinseiJokyo[0] = "01";
                params.put("conShinseiJokyo", conShinseiJokyo);
            }
            if (conShinseiJokyoList.contains("02")) {
                conShinseiJokyo[1] = "02";
                params.put("conShinseiJokyo", conShinseiJokyo);
            }
            if (conShinseiJokyoList.contains("03")) {
                conShinseiJokyo[2] = "03";
                params.put("conShinseiJokyo", conShinseiJokyo);
            }
            if (conShinseiJokyoList.contains("04")) {
                conShinseiJokyo[3] = "04";
                params.put("conShinseiJokyo", conShinseiJokyo);
            }
            if (conShinseiJokyoList.contains("05")) {
                conShinseiJokyo[4] = "05";
                params.put("conShinseiJokyo", conShinseiJokyo);
            }
        }
        // 適用日
        params.put("conTekiyoBi", mst363Form.getConTekiyoBi());
        // 削除済のみ
        params.put("conSakujonomiKensaku", mst363Form.getConSakujonomiKensaku());
        // ログインユーザー所属営業所
        params.put("loginUserShozokuEigyosho", authConfBean.getLoginUserShozokuEigyosho());

        try {
            // DBをアクセス
            ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH);
            ObjectMapper mapper = new ObjectMapper();
            mst363Form.setSearchResult(mapper.readValue(res.getJson(), List.class));

        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
        // 情報を返却する
        return mst363Form.getSearchResult();
    }
    
    /**
     * メニュークリック（処理）
     *
     * @param menuId メニューID
     * @param nextScreen 遷移先画面ID
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック処理
     *
     * @param nextScreenId 遷移先画面ID
     * @param breadIndex パンくずのインデックス
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreenId, int breadIndex) {
        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        url = forward(nextScreenId, null, null, true);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authConfBean.logout();
    }

    /**
     * 画面遷移処理（顧客マスタメンテナンス画面へ）
     *
     * @return 遷移先の画面URL
     * @throws java.lang.IllegalAccessException
     * @throws java.lang.reflect.InvocationTargetException
     */
    public String buttonClick() throws IllegalAccessException, InvocationTargetException {

        // 画面遷移
        url = forward(Cnst.SCREEN.CUS012_SCREEN.name(), null, Cnst.SCREEN.CUS011_SCREEN.name(), false);
        return url;
    }

    /**
     * 画面タイトルを取得する処理
     * @return 画面タイトル
     */
    public String getTitleName() {
        return titleName;
    }
    
    /**
     * 終了チェック
     * @param event 
     */
    public void shuryoubiCheck(AjaxBehaviorEvent event) {
        mst363Form.getSearchResultSelectable();
        mst363Form.getSelectedSearchResult();
    }
    
    /**
     * CSV作成ファイル
     *
     * @return
     */
    public List<CSVDto> getHeader() {

        // CSVファイルのタイトルを設定
        List<CSVDto> header = new ArrayList<>();
        /*
         * 顧客コード
         */
        header.add(new CSVDto("顧客コード", "listKokyakuCd"));
        /*
         * 顧客名
         */
        header.add(new CSVDto("顧客名", "listKokyakuMei"));
        /*
         * 売上日FROM
         */
        header.add(new CSVDto("売上日FROM", "listUriagebiFrom"));
        /*
         * 売上日TO
         */
        header.add(new CSVDto("売上日TO", "listUriagebiTo"));
        /*
         * 休日計上
         */
        header.add(new CSVDto("休日計上", "listKyujitsuKeijo"));
        /*
         * お題目
         */
        header.add(new CSVDto("お題目", "listOdaimoku"));
        /*
         * 伝票種別
         */
        header.add(new CSVDto("伝票種別", "listDempyoShubetsu"));
        /*
         * 伝票種別名
         */
        header.add(new CSVDto("伝票種別名", "listDempyoShubetsuMei"));
        /*
         * 料金項目コード
         */
        header.add(new CSVDto("料金項目コード", "listRyokinKomoku"));
        /*
         * 料金項目名
         */
        header.add(new CSVDto("料金項目名", "listRyokinKomokuMei"));
        /*
         * 明細区分
         */
        header.add(new CSVDto("明細区分", "hListMeisaiKbn"));
        /*
         * 表示名
         */
        header.add(new CSVDto("表示名", "listHyojiMei"));
        /*
         * 適用開始日
         */
        header.add(new CSVDto("適用開始日", "listTekiyoKaishibi"));
        /*
         * 単価
         */
        header.add(new CSVDto("単価", "listTanka"));
        /*
         * 単位
         */
        header.add(new CSVDto("単位", "listTani"));
        /*
         * 数量
         */
        header.add(new CSVDto("数量", "listSuryo"));
        /*
         * 金額
         */
        header.add(new CSVDto("金額", "listKingaku"));
        /*
         * 請求書備考1
         */
        header.add(new CSVDto("請求書備考1", "listSeikyushoBiko1"));
        /*
         * 適用名
         */
        header.add(new CSVDto("適用名", "listTekiyoMei"));
        /*
         * 適用終了日
         */
        header.add(new CSVDto("適用終了日", "listTekiyoShuryobi"));
        /*
         * 申請ステータス
         */
        header.add(new CSVDto("申請ステータス", "hListShinseiStatus"));
        /*
         * 申請状況
         */
        header.add(new CSVDto("申請状況", "listShinseiJokyo"));
        /*
         * データバージョン
         */
        header.add(new CSVDto("データバージョン", "listDataVersion"));
        /*
         * 適用フラグ
         */
        header.add(new CSVDto("適用フラグ", "listTekiyoFlg"));
        
        // 取得値を返却する
        return header;
    }
    
    /**
     * ダウンロード理由を記録する処理
     *
     * @param comment 理由コメント
     * @return boolean 正常／異常
     * @throws java.lang.Exception
     */
    public boolean beforeDown(String comment) throws Exception {
        // ダウンロード理由を記録する
        System.out.println(comment);
        return true;
    }
    
     /**
     * 更新履歴を表示処理
     */
    public void rirekiIchiran() {

        // 履歴テーブル検索キーを設定する
        rirekiSearchKey = new HashMap();
        // 選択されたレコードを取得する
        Map<String, Object> selectRec = mst363Form.getSelectedSearchResult().get(0);
        // 顧客コード
        rirekiSearchKey.put("listKokyakuCd", selectRec.get("listKokyakuCd"));
        // 売上日FROM
        rirekiSearchKey.put("listUriagebiFrom", selectRec.get("listUriagebiFrom"));
        // 売上日TO
        rirekiSearchKey.put("listUriagebiTo", selectRec.get("listUriagebiTo"));
        // 休日計上フラグ
        if (Boolean.parseBoolean(selectRec.get("listKyujitsuKeijo").toString())) {
            rirekiSearchKey.put("listKyujitsuKeijo", "1");
        } else {
            rirekiSearchKey.put("listKyujitsuKeijo", "0");
        }
        // 料金項目
        rirekiSearchKey.put("listRyokinKomoku", selectRec.get("listRyokinKomoku"));
        // 適用開始日
        if (CheckUtils.isEqual("java.lang.String", selectRec.get("listTekiyoKaishibi").getClass().getTypeName())) {
            rirekiSearchKey.put("listTekiyoKaishibi", selectRec.get("listTekiyoKaishibi"));
        } else {
            try {
                // 適用日フォーマット
                SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", Locale.US);
                rirekiSearchKey.put("listTekiyoKaishibi",  sdf.parse(selectRec.get("listTekiyoKaishibi").toString()));
            } catch (ParseException ex) {
                java.util.logging.Logger.getLogger(Mst363Bean.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        // 履歴タイトル設定
        rirekiSyosaiBean.setListColName(new ArrayList<>(Arrays.asList("顧客コード", "顧客名", "売上日FROM", "売上日TO", "休日計上", "お題目",
                "伝票種別", "伝票種別名", "料金項目", "料金項目名", "表示名", "適用開始日", "単価", "単位", "数量", "金額", "請求書備考1",
                "適用名", "適用終了日", "申請状況")));

        // 履歴beanの項目物理名を設定する
        rirekiSyosaiBean.setListColValue(new ArrayList<>(Arrays.asList("listKokyakuCd", "listKokyakuMei", "listUriagebiFrom", "listUriagebiTo", "listKyujitsuKeijo",
                "listOdaimoku", "listDempyoShubetsu", "listDempyoShubetsuMei", "listRyokinKomoku", "listRyokinKomokuMei", "listHyojiMei", "listTekiyoKaishibi",
                "listTanka", "listTani", "listSuryo", "listKingaku", "listSeikyushoBiko1", "listTekiyoMei", "listTekiyoShuryobi", "listShinseiJokyo")));

        // 履歴テーブル検索する
        rirekiSyosaiBean.searchList("2", "MST363_SEARCH_VW_JIDOSEIKYU_KOMOKU_SONOTA_URIAGE_RIREKI", rirekiSearchKey);

    }
    
    /**
     * 削除申請処理ファンクション領域
     */
    public void delRowsFunc() {

        // 行選択チェックを行う
        if (mst363Form.getSelectedSearchResult().isEmpty()) {
            messageProperty.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0011, "選択");
            return;
        }
        pageCommonBean.getSelectedDatasList().put(DATA_TABLE_ID, mst363Form.getSelectedSearchResult());
        pageCommonBean.delRows(DATA_TABLE_ID);
    }
    
    /**
     * 削除申請処理
     *
     * @param datas レコードリスト
     * @return 正常／異常
     */
    public Boolean delRows(List<Map<String, Object>> datas){
        
        // 行選択チェックを行う
        if (mst363Form.getSelectedSearchResult().isEmpty()) {
            messageProperty.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0011, "選択");
            return false;
        }
        
        // エラーメッセージを格納する変数の初期化
        msgList = new ArrayList<>();

        // 単項目チェック処理
        if (!checkJsfParamas(datas)) {
            return false;
        }
        
        // 必須チェック
        for (int row = 0; row < datas.size(); row++) {
            boolean checkFlag = false;
            // 終了チェック
            if (Boolean.parseBoolean(datas.get(row).get("listShuryoFlg").toString())
                    && datas.get(row).get("listTekiyoShuryobi") == null
                            ) {
                MessageModuleBean message = messageProperty.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0041, "終了する場合、適用終了日");
                msgList.add(message);
                checkFlag = true;
            }
            // 適用終了日
            if (Boolean.parseBoolean(datas.get(row).get("listShuryoFlg").toString())
                    && datas.get(row).get("listTekiyoShuryobi") != null
                            ) {
                MessageModuleBean message = messageProperty.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0048, "終了しない場合、適用終了日");
                msgList.add(message);
                checkFlag = true;
            }
            // 適用終了日が適用開始日より過去日付の場合。
            if (Boolean.parseBoolean(datas.get(row).get("listShuryoFlg").toString())
                    && datas.get(row).get("listTekiyoShuryobi") != null) {
                try {
                    SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", Locale.US);
                    Date tekiyoShuryobi = (Date) sdf.parse(datas.get(row).get("listTekiyoShuryobi").toString());
                    Date tekiyoKaishibi = (Date) sdf.parse(datas.get(row).get("listTekiyoKaishibi").toString());
                    if (CheckUtils.isLessThan(tekiyoShuryobi,
                            tekiyoKaishibi)) {
                        messageProperty.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0053, "適用終了日", "適用開始日");
                        return false;
                    }
                } catch (ParseException ex) {
                    java.util.logging.Logger.getLogger(Mst361Bean.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            // 単位・単価・数量・金額
            if (datas.get(row).get("listTanka") == null
                    || datas.get(row).get("listSuryo") == null
                    || datas.get(row).get("listTani") == null
                    ) {
                MessageModuleBean message = messageProperty.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0050, "単位・単価・数量", "金額");
                msgList.add(message);
                checkFlag = true;
            } else if (!CheckUtils.isEmpty(Integer.parseInt(datas.get(row).get("listTanka").toString())) 
                    && !CheckUtils.isEmpty(Integer.parseInt(datas.get(row).get("listTani").toString())) 
                    && !CheckUtils.isEmpty(Integer.parseInt(datas.get(row).get("listSuryo").toString())) 
                    ) {
                if (datas.get(row).get("listKingaku") == null) {
                    MessageModuleBean message = messageProperty.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0050, "単位・単価・数量", "金額");
                    msgList.add(message);
                    checkFlag = true;
                }
            }
            if (checkFlag) {
                messageProperty.messageList(msgList);
                msgList.clear();
                return false;
            }
        }
        
        // 存在チェック
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(datas, FUNC_CODE_DELETE_CHECK);
        
        // エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            
            MessageModuleBean message = messageProperty.createMessageModule(
                    res.getMessages().get(0)[0], 
                    res.getMessages().get(0)[1],
                    res.getMessages().get(0)[2],
                    "");
            msgList.add(message);
            messageProperty.messageList(msgList);
            msgList.clear();
            return false;
        }
        // 削除処理を行う
        int status = deleteDataList(datas);
        // エラーの場合、処理を終了
        if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            return false;
        }

         try {
            // 画面レコード削除
            mst363Form.getSearchResult().removeAll(datas);
        } catch (Exception e) {
             java.util.logging.Logger.getLogger(Mst351Bean.class.getName()).log(Level.SEVERE, null, e);
        }
        // ログ出力
        LOGGER.info("削除申請 " + datas.size() + " 件");
        return true;
    }
    
    /**
     * DBからマスタ情報を削除する
     * @param datas レコードリスト
     * @return ステータスコード
     */
    private int deleteDataList(List<Map<String, Object>> datas) {

        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(datas, FUNC_CODE_DELETE);
        // ステータスコードを返却する
        return res.getStatusCode();
    }
    
    /**
     * 未申請データ削除
     *
     * @param datas
     */
    public void callBackDataSakujo(List<Map<String, Object>> datas) {
        
        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(datas, FUNC_CODE_DELETE_CALLBACK);
    }
    
    /**
     * 申請ステータス更新
     *
     * @param datas
     */
    public void callBackDataUpdate(List<Map<String, Object>> datas) {
        
        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(datas, FUNC_CODE_UPDATE_CALLBACK);
    }
    
    /**
     * 検索結果を取得する
     * 
     * @return 検索結果
     */
    private List<Map<String, Object>> getSearchResult() {
        return mst363Form.getSearchResult();
    }
    
    /**
     * 申請画面
     * 
     * @return 遷移先画面のURL
     */
    public String shinsei() {

        // アップロード画面へ遷移
        url = forward(SCREEN.DEM012_SCREEN.name(), null, SCREEN.MST363_SCREEN.name(), false);
        return url;
    }
}
