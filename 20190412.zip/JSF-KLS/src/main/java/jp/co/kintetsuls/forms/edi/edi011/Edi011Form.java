/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.forms.edi.edi011;

import java.io.Serializable;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import lombok.Data;
import org.primefaces.model.TreeNode;

/**
 *
 * @author xubo
 */
@ManagedBean(name = "edi011Form")
@ViewScoped
@Data
public class Edi011Form implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private TreeNode root;
    
    @ManagedProperty("#{documentService}")
    private Edi011DocumentService service;
     
    @PostConstruct
    public void init() {
        root = service.createCheckboxDocuments();
    }
    
    public TreeNode getRoot() {
        return root;
    }
 
    public void setService(Edi011DocumentService service) {
        this.service = service;
    }
}
