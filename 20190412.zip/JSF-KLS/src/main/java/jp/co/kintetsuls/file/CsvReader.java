///*
// * Copyright(c) 2015 KAIMADATA CORPORATION
// */
//package jp.co.kintetsuls.file;
//
//import java.io.File;
//import java.io.FileNotFoundException;
//import java.io.IOException;
//import java.io.UnsupportedEncodingException;
//import java.nio.charset.Charset;
//import java.util.ArrayList;
//import java.util.Iterator;
//import java.util.List;
//import java.util.Map;
//import org.apache.commons.csv.*;
//
///**
// * 校務支援システム仕様のCSV読込クラス.
// *
// * @author bpchikazawa
// */
//public class CsvReader {
//
//    private CSVParser parser;
//
//     private Iterator<CSVRecord> it ;
//    /**
//     * コンストラクタ.
//     *
//     * @param _file ファイルオブジェクト.
//     * @param _fileCharSet ファイル文字コード
//     * @throws ApplicationException 文字コード不正
//     */
//    public CsvReader(File _file, String _fileCharSet) throws SystemException, IOException {
//        try {
////             File csvData = new File("/path/to/csv");
//            parser = CSVParser.parse(_file, Charset.forName(_fileCharSet), CSVFormat.RFC4180);
//            
//          it = parser.iterator();
////            parser.
////            for (CSVRecord csvRecord : parser) {
////              for( int i = 0; i< csvRecord.size() ; i++ ){
////                  System.out.println(csvRecord.get(i));
////              }
////            }
//
//        } catch (UnsupportedEncodingException e) {
//            // エラー
//            throw new SystemException("ファイルの文字コードが不正です。Shift_JIS で保存しなおして再試行して下さい。", e);
//        } catch (FileNotFoundException e) {
//            // エラー
//            throw new SystemException("ファイルパスの取得が失敗しました。", e);
//        }
//    }
//
//    /**
//     * ファイルから1行を読み込み、項目分割したリストを返します.
//     *
//     * @return 項目が設定されたリスト（ファイル最終に達した場合は null）
//     * @throws SystemException 予期せぬ例外発生時
//     */
//    public String[] readLine() throws SystemException {
//        // システム例外
//        if (it.hasNext()) {
//            CSVRecord tmp = it.next();
//            String[] tmpString = new String[new Long(tmp.size()).intValue()];
//            for (int i = 0; i < tmp.size(); i++) {
//                tmpString[i] = tmp.get(i);
//            }
//            return tmpString;
//        } else {
//            return null;
//        }
//
//    }
//
//    /**
//     * ファイルから1行を読み込み、項目分割したリストを返します.
//     *
//     * @return 項目が設定されたリスト（ファイル最終に達した場合は null）
//     * @throws SystemException 予期せぬ例外発生時
//     */
//    public List<String[]> readAll() throws SystemException {
//
//        // リスト
//        List<String[]> result_ = new ArrayList<>();
//        // リストに格納する
//        CSVRecord tmp;
//        while (it.hasNext()) {
//            tmp = it.next();
//            String[] tmpString = new String[new Long(tmp.size()).intValue()];
//            for (int i = 0; i < tmp.size(); i++) {
//                tmpString[i] = tmp.get(i);
//            }
//            result_.add(tmpString);
////            System.out.println(tmp.toString());
//        }
//
//        // 返却
//        return result_;
//
//    }
//
//    /**
//     * ファイルクローズ.
//     *
//     * @throws SystemException
//     */
//    public void close() throws SystemException {
//        try {
//            parser.close();
//        } catch (IOException e) {
//            throw new SystemException(e);
//        }
//    }
//
//    public int size() throws SystemException {
//        return new Long(parser.getRecordNumber()).intValue();
//    }
//
//    public static void main(String[] args) throws IOException {
//        File file = new File("D:\\NK-契約0926.csv");
//
//        CsvReader a = new CsvReader(file, "shift-jis");
//        String[] t = a.readLine();
//        while (t != null) {
//            String tmpLine = "";
//            for (String tmp : t) {
//                tmpLine += "|" + tmp;
//
//            }
//            System.out.println(tmpLine);
//            t = a.readLine();
//        }
//
//    }
//
//}
