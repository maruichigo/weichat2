/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.stc;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author yinyanxu
 */
@ManagedBean(name = "stc021")
@ViewScoped
public class Stc021Bean {
    /** モード */
    @Getter
    @Setter
    private String mode;
}
