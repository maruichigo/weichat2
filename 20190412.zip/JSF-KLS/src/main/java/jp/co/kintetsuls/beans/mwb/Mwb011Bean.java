/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mwb;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import javax.faces.model.SelectItem;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.SearchHelpNoDownloadBean;
import jp.co.kintetsuls.forms.mwb.Mwb011Form;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.kintetsuls.utils.DateUtils;
import jp.co.kintetsuls.utils.NumberUtils;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.model.CheckboxTreeNode;
import org.primefaces.model.TreeNode;

/**
 * /**
 * MAWB一覧画面
 *
 * @author YinMingLong (MBP)
 * @version 2019/1/28 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mwb011")
@ViewScoped
@Data
public class Mwb011Bean extends AbstractBean {

    /**
     * 定数：ScreenCode MWB011.
     */
    private static final String SC_CD_MWB011 = "MWB011_SCREEN";
    
    /**
     * 定数：検索件数取得FUNC_CODE.
     */
    private static final String FUNC_CODE_SEARCH_KENSU = "mwb011-get-mawbbango-kensu";
    
    /**
     * 定数：検索情報取得FUNC_CODE.
     */
    private static final String FUNC_CODE_SEARCH_DATA = "mwb011-get-mawbbango-data";

    /**
     * 定数：MAWB登録処理FUNC_CODE.
     */
    private static final String FUNC_CODE_MAWB_TOROKU = "mwb011-get-mawbbango-insert";
    
    /**
     * 定数：MAWB更新処理FUNC_CODE.
     */
    private static final String FUNC_CODE_MAWB_KOSHIN = "mwb011-get-mawbbango-update";
    
    /**
     * 定数：MAWB削除処理FUNC_CODE.
     */
    private static final String FUNC_CODE_MAWB_SAKUJO = "mwb011-get-mawbbango-delete";
    
    /**
     * 定数：MAWB配布更新処理FUNC_CODE.
     */
    private static final String FUNC_CODE_MAWB_HAIFU_KOSHIN = "mwb011-haifu-update";
    
    /**
     * 定数：MAWB配布削除処理FUNC_CODE.
     */
    private static final String FUNC_CODE_MAWB_HAIFU_SAKUJO = "mwb011-haifu-delete";
    
    /**
     * 画面URL
     */
    private String url;
    
    /**
     * タイトル
     */
    private final String TITLE = "MAWB一覧";

    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

    /**
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authorityConfBean;

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;

    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(
            new Object() {}.getClass().getEnclosingClass().getName());

    /**
     * 画面項目保持
     */
    @ManagedProperty(value = "#{mwb011Form}")
    private Mwb011Form mwb011Form;

    /**
     * 共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * 定数：一覧のTreeTableのID
     */
    private static final String TREE_TABLE_ID = "tablesorter_mwb011";
    
    /**
     * 定数：画面項目保持キー
     */
    private static final String CONST_MWB011_FORM = "mwb011Form";
    
    /**
     * 定数：MasterInfo取得キー
     */
    private static final String CONST_MWB011_MASTER = "mwb011";

    /**
     * 定数：再検索Button取得キー
     */
    private static final String CONST_MWB011_SEARCH = "search_mwb011";

    /**
     * ワーク.航空会社リスト
     */
    private List<SelectItem> kokuGaishaList;

    /**
     * ワーク.未使用MAWB表示
     */
    private String[] mishiyoMawbHyojiValue;

    /**
     * ワーク.検索条件
     */
    private Map<String, Object> searchCriteria;

    /**
     * 検索シーケンス処理共通
     */
    @ManagedProperty(value = "#{SearchHelpNoDownloadBean}")
    private SearchHelpNoDownloadBean searchHelpBean;

    /**
     * 1.初期処理
     *
     * @param menuId　メニューID
     * @param prevScreen 遷移元画面ID
     * @param backFlag 戻るフラグ
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            // パンくずを追加する
            breadBean.push(TITLE, SCREEN.MWB011_SCREEN.name(), this);

            // システムマスタ取得する
            pageCommonBean.getMasterInfo(CONST_MWB011_MASTER);

            // 未使用MAWB表示
            setMishiyoMawbHyojiValue(new String[]{"1"});

            // 検索シーケンス処理を初期化する
            searchHelpBean.regSearchHelp(TREE_TABLE_ID,
                    s -> {return getRecordCount();},
                    s -> {search(); return null;},
                    s -> {return searchCheck();});
            searchHelpBean.getSettings().put(TREE_TABLE_ID, pageCommonBean);

            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する
            // ワーク.営業所リスト
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO);
            // ワーク.航空会社リスト
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_MS_KOKU_GAISHA);

            // 前回の記録をクリアする
            this.clear();
            mwb011Form.setSearchResult(null);
            mwb011Form.setMawbBean(null);
            mwb011Form.setSelectedNode(null);

            // 戻ってきた場合
            Mwb011Form preForm = (Mwb011Form) pageCommonBean.getPageInfo(CONST_MWB011_FORM);
            if (backFlag && preForm != null) {
                PageCommonBean.simpleCopy(preForm, mwb011Form);
                // 再検索を実施する
                pageCommonBean.searchAgain(CONST_MWB011_SEARCH);
                // 進んできた場合
            } else {
                Flash flash = pageCommonBean.getPageParam();
                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_MWB011_FORM) != null) {
                    PageCommonBean.simpleCopy(flash.get(CONST_MWB011_FORM), mwb011Form);
                    // 再検索を実施する
                    pageCommonBean.searchAgain(CONST_MWB011_SEARCH);
                } else {
                    // 各項目の配置、編集内容、初期値は、詳細設計書の「画面項目定義」を参照。
                    // 未使用MAWB表示 チェックあり
                    mwb011Form.setConMishiyoMawbHyoji(mishiyoMawbHyojiValue);
                    mwb011Form.setRoot(new CheckboxTreeNode(new Mwb011MawbBangoBean(0), null));
                    mwb011Form.setSelectedBean(new Mwb011MawbBangoBean(5));
                }
            }
            // component初期化とユーザ権限により制御を設定する
            pageCommonBean.setAuthControll(mwb011Form, SC_CD_MWB011, true);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * 2.検索処理　カウント処理
     *
     * @return 取得件数
     */
    public Long getRecordCount() {
        searchCriteria.put(Mwb011Form.CONST_CON_SQL_ID, "searchForCount");
        Long count = getSearchResultCount(FUNC_CODE_SEARCH_KENSU, searchCriteria);
        return count;
    }

    /**
     * 2.検索処理 データ検索
     *
     */
    public void search() {
        // 検索条件保存
        pageCommonBean.savePageInfo(CONST_MWB011_FORM, mwb011Form);

        // 検索結果取得
        getSearchResult();
        if (mwb011Form.getMawbBean() != null) {
            // 画面項目設定
            createTreeNodes();
        }

        // 検索部のステータス変更
        pageCommonBean.setSerchConDisabled(mwb011Form);

        pageCommonBean.setEditFlg(false);
    }

    /**
     * 3.検索条件クリア処理
     *
     */
    public void clear() {
        // ワーク.発券営業所コード
        mwb011Form.setConHakkenEigyosho(null);
        // ワーク.航空会社コード
        mwb011Form.setConKokuGaishaCd(null);
        // ワーク.配布年月日From
        mwb011Form.setConHaifuHizukeFrom(null);
        // ワーク.配布年月日To
        mwb011Form.setConHaifuHizukeTo(null);
        // ワーク.配布先営業所コード
        mwb011Form.setConHaifusakiEigyosho(null);
        // ワーク.MAWB番号
        mwb011Form.setConMawbBango("");
        // 未使用MAWB表示
        mwb011Form.setConMishiyoMawbHyoji(getMishiyoMawbHyojiValue());
        
        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mwb011Form);
        pageCommonBean.setBtnSearchChangeVisible(false);
        pageCommonBean.setBtnSearchVisible(Boolean.TRUE);
    }

    /**
     * 検索条件変更処理
     *
     */
    public void searchChange() {

        // 検索部のステータスを変更する
        pageCommonBean.setSerchConEnabled(mwb011Form);
    }

    /**
     * ツリー表示とするノードを作成する
     *
     */
    private void createTreeNodes() {
        Mwb011MawbBangoBean mawbBean = mwb011Form.getMawbBean();
        TreeNode root = new CheckboxTreeNode(mawbBean, null);
        if (mawbBean.getChildNodes() != null && mawbBean.getChildNodes().size() > 0) {
            for (Mwb011MawbBangoBean childNode : mawbBean.getChildNodes()) {
                createTreeNodes(childNode, root);
            }
        }

        mwb011Form.setRoot(root);
    }

    /**
     * ツリー表示とするノードを作成する
     *
     * @param mawbBean 編集用リストの内容
     * @param parentNode 親ノード
     */
    private void createTreeNodes(Mwb011MawbBangoBean mawbBean, TreeNode parentNode) {
        if (mawbBean.getChildNodes() != null && mawbBean.getChildNodes().size() > 0) {
            TreeNode treeNode = new CheckboxTreeNode(mawbBean, parentNode);
            for (Mwb011MawbBangoBean childNode : mawbBean.getChildNodes()) {
                createTreeNodes(childNode, treeNode);
            }
        } else {
            TreeNode treeNode = new CheckboxTreeNode("mawbBango", mawbBean, parentNode);
        }
    }

    /**
     * 検索条件の情報を入力パラメータ(検索条件)として取得する。
     *
     * @exception SystemException
     */
    private void getSearchParams() throws SystemException {
        searchCriteria = new HashMap<>();
        // ワーク.発券営業所コード
        if (mwb011Form.getConHakkenEigyosho() != null) {
            searchCriteria.put(Mwb011Form.CONST_CON_HAKKEN_EIGYOSHO_CD, mwb011Form.getConHakkenEigyosho().getValue());
        }
        // ワーク.航空会社コード
        if (mwb011Form.getConKokuGaishaCd() != null) {
            searchCriteria.put(Mwb011Form.CONST_CON_KOKU_GAISHA_CD, mwb011Form.getConKokuGaishaCd().getValue());
        }
        // ワーク.配布年月日From
        if (mwb011Form.getConHaifuHizukeFrom() == null || "".equals(mwb011Form.getConHaifuHizukeFrom())) {
            searchCriteria.put(Mwb011Form.CONST_CON_HAIFU_HIZUKE_FROM, null);
        } else {
            searchCriteria.put(Mwb011Form.CONST_CON_HAIFU_HIZUKE_FROM,
                    DateUtils.parseFmtYMD(mwb011Form.getConHaifuHizukeFrom()));
        }
        // ワーク.配布年月日To
        if (mwb011Form.getConHaifuHizukeTo() == null || "".equals(mwb011Form.getConHaifuHizukeTo())) {
            searchCriteria.put(Mwb011Form.CONST_CON_HAIFU_HIZUKE_TO, null);
        } else {
            searchCriteria.put(Mwb011Form.CONST_CON_HAIFU_HIZUKE_TO,
                    DateUtils.parseFmtYMD(mwb011Form.getConHaifuHizukeTo()));
        }
        // ワーク.配布先営業所コード
        if (mwb011Form.getConHaifusakiEigyosho() != null) {
            searchCriteria.put(Mwb011Form.CONST_CON_HAIFUSAKI_EIGYOSHO_CD,
                    mwb011Form.getConHaifusakiEigyosho().getValue());
        }
        // ワーク.MAWB番号
        searchCriteria.put(Mwb011Form.CONST_CON_MAWB_BANGO, mwb011Form.getConMawbBango());

        // 実行結果を格納するワーク変数を初期化する。
        // ワーク.件数
        mwb011Form.setSearchResultCount(0);
        // ワーク.一覧
        mwb011Form.setSearchResult(new ArrayList<>());
    }

    /**
     * 入力項目チェック
     *
     * @param checkNumber チェックパターン
     * @return チェック結果
     */
    public boolean inputCheck(int checkNumber) {
        boolean result = true;
        switch (checkNumber) {
            case 1:
                // 配布日付FROM 配布日付TO 相関チェック
                if (mwb011Form.getConHaifuHizukeFrom() != null && mwb011Form.getConHaifuHizukeTo() != null) {
                    if (mwb011Form.getConHaifuHizukeFrom().compareTo(mwb011Form.getConHaifuHizukeTo()) > 0) {
                        messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0008, "配布日付");
                        return false;
                    }
                }
                break;
            // 枚数計算 登録MAWB番号
            case 2:
                // 登録MAWB番号From 登録MAWB番号To 相関チェック
                if (mwb011Form.getSelectedBean().getSaiTorokuMawbBangoFrom() != null
                        && mwb011Form.getSelectedBean().getSaiTorokuMawbBangoTo() != null) {
                    if (Integer.valueOf(mwb011Form.getSelectedBean().getSaiTorokuMawbBangoFrom())
                            > Integer.valueOf(mwb011Form.getSelectedBean().getSaiTorokuMawbBangoTo())) {
                        messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MWBE0001, "登録MAWB番号");
                        return false;
                    }
                }
                break;
            // 枚数計算
            case 9:
                // 再配布MAWB番号From 再配布MAWB番号To 相関チェック
                if (mwb011Form.getSelectedBean().getSaiHaifuMawbBangoFrom() != null
                        && mwb011Form.getSelectedBean().getSaiHaifuMawbBangoTo() != null) {
                    if (Integer.valueOf(mwb011Form.getSelectedBean().getSaiHaifuMawbBangoFrom())
                            > Integer.valueOf(mwb011Form.getSelectedBean().getSaiHaifuMawbBangoTo())) {
                        messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MWBE0001, "再配布MAWB番号");
                        return false;
                    }
                }
                break;
            // 登録ボタン（MAWB番号登録）、更新ボタン（MAWB番号登録）、削除ボタン（MAWB番号登録）    
            case 3:
                // 登録MAWB番号From 必須チェック
                if (!requiredCheck(mwb011Form.getSelectedBean().getSaiTorokuMawbBangoFrom())) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "登録MAWB番号From");
                    return false;
                }
                // 登録MAWB番号To 必須チェック
                if (!requiredCheck(mwb011Form.getSelectedBean().getSaiTorokuMawbBangoTo())) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "登録MAWB番号To");
                    return false;
                }
                // 登録MAWB番号From 7DRチェック
                if (!sevenDRCheck(mwb011Form.getSelectedBean().getSaiTorokuMawbBangoFrom())) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0007, "登録MAWB番号From");
                    return false;
                }
                // 登録MAWB番号To 7DRチェック
                if (!sevenDRCheck(mwb011Form.getSelectedBean().getSaiTorokuMawbBangoTo())) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0007, "登録MAWB番号To");
                    return false;
                }
                // 登録MAWB番号From登録MAWB番号To 相関チェック
                if (!reversalCheck(mwb011Form.getSelectedBean().getSaiTorokuMawbBangoFrom(),
                        mwb011Form.getSelectedBean().getSaiTorokuMawbBangoTo())) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MWBE0001, "登録MAWB番号");
                    return false;
                }
                break;

            // 更新ボタン（範囲指定時）（MAWB番号登録）    
            case 4:
                // 再配布日付 必須チェック
                if (!requiredCheck(mwb011Form.getSelectedBean().getSaiHaifuHizuke())) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "再配布日付");
                    return false;
                }
                // 再配布先営業所コード 必須チェック
                if (!requiredCheck(mwb011Form.getSelectedBean().getSaiHaifusakiEigyosho())) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "再配布先営業所コード");
                    return false;
                }
                // 再配布先営業所名 必須チェック
                if (!requiredCheck(mwb011Form.getSelectedBean().getSaiHaifusakiEigyosho().getLabel())) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "再配布先営業所名");
                    return false;
                }
                // 再配布MAWB番号From 必須チェック
                if (!requiredCheck(mwb011Form.getSelectedBean().getSaiHaifuMawbBangoFrom())) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "再配布MAWB番号From");
                    return false;
                }
                // 再配布MAWB番号To 必須チェック
                if (!requiredCheck(mwb011Form.getSelectedBean().getSaiHaifuMawbBangoTo())) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "再配布MAWB番号To");
                    return false;
                }

                // 再配布MAWB番号From 7DRチェック
                if (!sevenDRCheck(mwb011Form.getSelectedBean().getSaiHaifuMawbBangoFrom())) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0007, "再配布MAWB番号From");
                    return false;
                }

                // 再配布MAWB番号To 7DRチェック
                if (!sevenDRCheck(mwb011Form.getSelectedBean().getSaiHaifuMawbBangoTo())) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0007, "再配布MAWB番号To");
                    return false;
                }

                // 再配布MAWB番号From 再配布MAWB番号To 相関チェック
                if (!reversalCheck(mwb011Form.getSelectedBean().getSaiHaifuMawbBangoFrom(),
                        mwb011Form.getSelectedBean().getSaiHaifuMawbBangoTo())) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MWBE0001, "再配布MAWB番号");
                    return false;
                }
                break;

            // 更新ボタン（番号指定時）（MAWB配布登録）
            case 5:
                // 再配布日付 必須チェック
                if (!requiredCheck(mwb011Form.getSelectedBean().getSaiHaifuHizuke())) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "再配布日付");
                    return false;
                }
                // 再配布先営業所コード 必須チェック
                if (!requiredCheck(mwb011Form.getSelectedBean().getSaiHaifusakiEigyosho())) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "再配布先営業所コード");
                    return false;
                }
                // 再配布先営業所名 必須チェック
                if (!requiredCheck(mwb011Form.getSelectedBean().getSaiHaifusakiEigyosho().getLabel())) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "再配布先営業所名");
                    return false;
                }
                // 再配布MAWB番号リスト 7DRチェック
                for (String bango : mwb011Form.getSelectedBean().getSelectedMawbBangoList()) {
                    if (!sevenDRCheck(bango)) {
                        messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0007, "再配布MAWB番号リスト");
                        return false;
                    }
                }
                break;
            // 削除ボタン（MAWB配布登録）
            case 6:
                // 再配布MAWB番号From 必須チェック
                if (!requiredCheck(mwb011Form.getSelectedBean().getSaiHaifuMawbBangoFrom())) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "再配布MAWB番号From");
                    return false;
                }
                // 再配布MAWB番号To 必須チェック
                if (!requiredCheck(mwb011Form.getSelectedBean().getSaiHaifuMawbBangoTo())) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "再配布MAWB番号To");
                    return false;
                }
                // 再配布MAWB番号From 再配布MAWB番号To 相関チェック
                if (!reversalCheck(mwb011Form.getSelectedBean().getSaiHaifuMawbBangoFrom(),
                        mwb011Form.getSelectedBean().getSaiHaifuMawbBangoTo())) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MWBE0001, "再配布MAWB番号");
                    return false;
                }
                break;
            // 枚数計算（範囲指定時）    
            case 7:
                // 登録MAWB番号From 必須チェック
                if (!requiredCheck(mwb011Form.getSelectedBean().getSaiTorokuMawbBangoFrom())) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "登録MAWB番号From");
                    return false;
                }
                // 登録MAWB番号To 必須チェック
                if (!requiredCheck(mwb011Form.getSelectedBean().getSaiTorokuMawbBangoTo())) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "登録MAWB番号To");
                    return false;
                }
                // 登録MAWB番号From登録MAWB番号To 相関チェック
                if (!reversalCheck(mwb011Form.getSelectedBean().getSaiTorokuMawbBangoFrom(),
                        mwb011Form.getSelectedBean().getSaiTorokuMawbBangoTo())) {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MWBE0001, "登録MAWB番号");
                    return false;
                }
                break;

        }
        return result;
    }

    /**
     * 件数を取得する。
     *
     * @param functionCode 検索用ファンクションコード
     * @param searchCriteria 検索用パラメータ
     * @return 件数
     */
    private Long getSearchResultCount(String functionCode, Map<String, Object> searchCriteria) {

        // DBをアクセスする
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(searchCriteria, functionCode);

        // 検索件数を返却する
        return Long.valueOf(serviceInterfaceBean.getJson());
    }

    /**
     * MAWB一覧を取得する。
     *
     */
    private void getSearchResult() {
        // 以下の内容でMAWB一覧情報を取得する。
        searchCriteria.put(Mwb011Form.CONST_CON_SQL_ID, "searchForData");
        List<Map<String, Object>> searchResult = getSearchDataFromDb(FUNC_CODE_SEARCH_DATA, searchCriteria);
        // 1)ワーク一覧変数設定
        mwb011Form.setSearchResult(searchResult);

        // 取得結果のマージを行う。
        mergeResult();
    }

    /**
     * 情報を取得する
     *
     * @param functionfunctionCodeCode 検索用ファンクションコード
     * @param searchCriteria 検索用パラメータ
     * @return 検索結果
     */
    private List<Map<String, Object>> getSearchDataFromDb(String functionCode, Map<String, Object> searchCriteria) {
        
        List<Map<String, Object>> resultList = new ArrayList();
        try {
            // DBをアクセスする
            ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(searchCriteria, functionCode);
            ObjectMapper mapper = new ObjectMapper();
            resultList = mapper.readValue(serviceInterfaceBean.getJson(), List.class);
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        
        return resultList;

    }

    /**
     * 検索取得結果のマージを行う。
     *
     */
    private void mergeResult() {
        // 未使用MAWB表示
        Boolean isMiShiyoMawbHuoji = false;
        if (mwb011Form.getConMishiyoMawbHyoji().length > 0) {
            isMiShiyoMawbHuoji = true;
        }

        List<Map<String, Object>> list = mwb011Form.getSearchResult();
        Mwb011MawbBangoBean mawbBean = new Mwb011MawbBangoBean(0);
        
        if(mwb011Form.getMawbBean() != null) {
            mawbBean = mwb011Form.getMawbBean();
        }
        mwb011Form.setMawbBean(mawbBean);

        // 発券営業所の行
        Mwb011MawbBangoBean eigyoshoBean;
        // 航空会社の行
        Mwb011MawbBangoBean gaishaBean;
        // 登録MAWB番号の行
        Mwb011MawbBangoBean bangoBean;

        // 表示内容を取得
        List<Mwb011MawbBangoBean> hyojiList = getHyojiData(list, isMiShiyoMawbHuoji);

        // 検索結果は「発券営業所」「航空会社」「登録MAWB番号」単位毎にツリー表示とする。
        for (Mwb011MawbBangoBean tempMawbBean : hyojiList) {
            // 前データ取得
            Mwb011MawbBangoBean preMawbBean = getPreMawbBean(mawbBean);
            // 【IF】発券営業所コードが前データと等しい場合
            if (tempMawbBean.getHakkenEigyoshoCd().equals(preMawbBean.getHakkenEigyoshoCd())) {
                // 退避する発券営業所の行取得
                eigyoshoBean = getParentMawbBean(mawbBean, 1);
                // 以下を加算する。
                if (!tempMawbBean.getKokuGaishaCd().equals(preMawbBean.getKokuGaishaCd())
                        || !tempMawbBean.getTorokuMawbBango().equals(preMawbBean.getTorokuMawbBango())) {
                    // 受入枚数
                    eigyoshoBean.setUkeireMaisu(eigyoshoBean.getUkeireMaisu() + tempMawbBean.getUkeireMaisu());
                }
                sumMaisu(eigyoshoBean, tempMawbBean);
            } // 【ELSE】発券営業所コードが前データと異なる場合
            else {
                // 発券営業所の行を新規に作成し、退避する。
                eigyoshoBean = createParentMawbBean(1, tempMawbBean);
                // ワーク.編集用リストにデータを追加する。
                mawbBean.getChildNodes().add(eigyoshoBean);
            }

            // 【IF】航空会社コードが前データと等しい場合
            if (tempMawbBean.getHakkenEigyoshoCd().equals(preMawbBean.getHakkenEigyoshoCd())
                    && tempMawbBean.getKokuGaishaCd().equals(preMawbBean.getKokuGaishaCd())) {
                // 退避する航空会社の行取得
                gaishaBean = getParentMawbBean(mawbBean, 2);
                // 以下を加算する。
                if (!tempMawbBean.getTorokuMawbBango().equals(preMawbBean.getTorokuMawbBango())) {
                    // 受入枚数
                    gaishaBean.setUkeireMaisu(gaishaBean.getUkeireMaisu() + tempMawbBean.getUkeireMaisu());
                }
                sumMaisu(gaishaBean, tempMawbBean);
            } // 【ELSE】航空会社コードが前データと異なる場合
            else {
                // 航空会社の行を新規に作成し、退避する。
                gaishaBean = createParentMawbBean(2, tempMawbBean);
                // ワーク.編集用リストにデータを追加する。
                eigyoshoBean.getChildNodes().add(gaishaBean);

            }

            // 【IF】登録MAWB番号が前データと等しい場合
            if (tempMawbBean.getHakkenEigyoshoCd().equals(preMawbBean.getHakkenEigyoshoCd())
                    && tempMawbBean.getKokuGaishaCd().equals(preMawbBean.getKokuGaishaCd())
                    && tempMawbBean.getTorokuMawbBango().equals(preMawbBean.getTorokuMawbBango())) {
                // 退避する登録MAWB番号の行取得
                bangoBean = getParentMawbBean(mawbBean, 3);
                // 以下を加算する。
                sumMaisu(bangoBean, tempMawbBean);
            } else {
                // 登録MAWB番号の行を新規に作成し、退避する。
                bangoBean = createParentMawbBean(3, tempMawbBean);
                // ワーク.編集用リストにデータを追加する。
                gaishaBean.getChildNodes().add(bangoBean);
            }

            // 配布MAWB番号の開始から終了までの値を以下のリストに格納後、ワーク.一覧に追加する。
            setHaifuMawbBangoList(tempMawbBean);
            // ワーク.編集用リストにデータを追加する。
            bangoBean.getChildNodes().add(tempMawbBean);
        }

        // 編集したワーク.編集用リストの件数をチェックする。
        int count = getDataListCount(mawbBean);
        //【IF】ワーク.編集用リストの件数 = 0の場合
        if (count == 0) {
            // メッセージを表示する。
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_WARN, MessageCnst.COMW0001);
        } // 【ELSE】ワーク.編集用リストの件数 > 検索結果最大件数の場合
        else if (count > Integer.valueOf(pageCommonBean.getMasterInfo().getMaxRows())) {
            // メッセージを表示する。
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_WARN, MessageCnst.COMW0002);
            mwb011Form.setMawbBean(null);
        }
    }

    /**
     * 親ノードを作成する。
     *
     * @param level 発券営業所用データ行　航空会社用データ行　登録MAWB番号用データ行
     * @param tempMawbBean 編集用リストの内容
     * @return 処理結果
     */
    private Mwb011MawbBangoBean createParentMawbBean(int level, Mwb011MawbBangoBean tempMawbBean) {
        Mwb011MawbBangoBean mawbBean = new Mwb011MawbBangoBean(level);
        // 発券営業所コード
        mawbBean.setHakkenEigyoshoCd(tempMawbBean.getHakkenEigyoshoCd());
        // 発券営業所名
        mawbBean.setHakkenEigyoshoMei(tempMawbBean.getHakkenEigyoshoMei());
        switch (level) {
            // 登録MAWB番号
            case 3:
                // 航空会社コード
                mawbBean.setKokuGaishaCd(tempMawbBean.getKokuGaishaCd());
                // MAWB登録ID
                mawbBean.setMawbTorokuId(tempMawbBean.getMawbTorokuId());
                // 発券営業所・航空会社・登録MAWB番号
                mawbBean.setDispMawbBango(tempMawbBean.getTorokuMawbBango());
                // 受入日付
                mawbBean.setUkeireHizuke(tempMawbBean.getUkeireHizuke());
                // 受入日付
                mawbBean.setStrUkeireHizuke(tempMawbBean.getDateStringValue(tempMawbBean.getUkeireHizuke()));
                // 受入日付
                mawbBean.setSaiUkeireHizuke(tempMawbBean.getStrUkeireHizuke());
                // 受入枚数
                mawbBean.setUkeireMaisu(tempMawbBean.getUkeireMaisu());
                // 配布MAWB番号 使用率を設定する。
                mawbBean.setHaifuMawbBango(getShiyoRitu(tempMawbBean));
                // 配布枚数
                mawbBean.setHaifuMaisu(tempMawbBean.getHaifuMaisu());
                // 使用枚数
                mawbBean.setShiyoMaisu(tempMawbBean.getShiyoMaisu());
                // VOID枚数
                mawbBean.setVoidMaisu(tempMawbBean.getVoidMaisu());
                // 未使用枚数
                mawbBean.setMishiyoMaisu(tempMawbBean.getMishiyoMaisu());
                // 開始MAWB番号
                mawbBean.setTorokuMawbBangoFrom(tempMawbBean.getTorokuMawbBangoFrom());
                // 終了MAWB番号
                mawbBean.setTorokuMawbBangoTo(tempMawbBean.getTorokuMawbBangoTo());
                break;
            // 航空会社
            case 2:
                // 航空会社コード
                mawbBean.setKokuGaishaCd(tempMawbBean.getKokuGaishaCd());
                // 発券営業所・航空会社・登録MAWB番号
                mawbBean.setDispMawbBango(tempMawbBean.getKokuGaishaCd());
                // 受入枚数
                mawbBean.setUkeireMaisu(tempMawbBean.getUkeireMaisu());
                // 配布MAWB番号 使用率を設定する。
                mawbBean.setHaifuMawbBango(getShiyoRitu(tempMawbBean));
                // 配布枚数
                mawbBean.setHaifuMaisu(tempMawbBean.getHaifuMaisu());
                // 使用枚数
                mawbBean.setShiyoMaisu(tempMawbBean.getShiyoMaisu());
                // VOID枚数
                mawbBean.setVoidMaisu(tempMawbBean.getVoidMaisu());
                // 未使用枚数
                mawbBean.setMishiyoMaisu(tempMawbBean.getMishiyoMaisu());
                break;
            // 発券営業所
            case 1:
                // 発券営業所・航空会社・登録MAWB番号
                mawbBean.setDispMawbBango(tempMawbBean.getHakkenEigyoshoMei());
                // 受入枚数
                mawbBean.setUkeireMaisu(tempMawbBean.getUkeireMaisu());
                // 配布MAWB番号 使用率を設定する。
                mawbBean.setHaifuMawbBango(getShiyoRitu(tempMawbBean));
                // 配布枚数
                mawbBean.setHaifuMaisu(tempMawbBean.getHaifuMaisu());
                // 使用枚数
                mawbBean.setShiyoMaisu(tempMawbBean.getShiyoMaisu());
                // VOID枚数
                mawbBean.setVoidMaisu(tempMawbBean.getVoidMaisu());
                // 未使用枚数
                mawbBean.setMishiyoMaisu(tempMawbBean.getMishiyoMaisu());
                break;
        }
        return mawbBean;
    }

    /**
     * 配布枚数に対しての使用枚数の割合を計算する。
     *
     * @param tempMawbBean 編集用リストの内容
     * @return 計算結果
     */
    private String getShiyoRitu(Mwb011MawbBangoBean tempMawbBean) {
        // 使用率＝(使用枚数+VOID枚数)/配布枚数*100　小数点以下四捨五入
        if (tempMawbBean.getHaifuMaisu() > 0) {
            // 使用枚数
            BigDecimal shiyoMaisu = NumberUtils.toBigDecimal(tempMawbBean.getShiyoMaisu());
            // VOID枚数
            BigDecimal voidMaisu = NumberUtils.toBigDecimal(tempMawbBean.getVoidMaisu());
            // 配布枚数
            BigDecimal haifuMaisu = NumberUtils.toBigDecimal(tempMawbBean.getHaifuMaisu());
            // 小数点以下四捨五入
            BigDecimal shiyoRitu
                    = shiyoMaisu.add(voidMaisu).multiply(NumberUtils.toBigDecimal(100)).divide(haifuMaisu, 0, BigDecimal.ROUND_HALF_UP);
            return "使用率：" + String.valueOf(shiyoRitu) + "%";
        } else {
            return "";
        }
    }

    /**
     * 前ノードを取得する。
     *
     * @param mawbBean 編集用リストの内容
     * @return 処理結果
     */
    private Mwb011MawbBangoBean getPreMawbBean(Mwb011MawbBangoBean mawbBean) {
        Mwb011MawbBangoBean preBean = new Mwb011MawbBangoBean(5);
        if (mawbBean.getChildNodes() != null && mawbBean.getChildNodes().size() > 0) {
            preBean = getChildBean(mawbBean.getChildNodes().get(mawbBean.getChildNodes().size() - 1));
        }
        return preBean;
    }

    /**
     * 最後の子ノードを取得する。
     *
     * @param mawbBean 編集用リストの内容
     * @return 処理結果
     */
    private Mwb011MawbBangoBean getChildBean(Mwb011MawbBangoBean mawbBean) {
        if (mawbBean.getChildNodes() != null && mawbBean.getChildNodes().size() > 0) {
            return getChildBean(mawbBean.getChildNodes().get(mawbBean.getChildNodes().size() - 1));
        } else {
            return mawbBean;
        }
    }

    /**
     * 枚数を計算する。
     *
     * @param mawbBean 編集用リストの内容
     * @param tempMawbBean 編集用リストの内容(退避用)
     */
    private void sumMaisu(Mwb011MawbBangoBean mawbBean, Mwb011MawbBangoBean tempMawbBean) {
        if (mawbBean != null) {
            // 配布枚数
            mawbBean.setHaifuMaisu(mawbBean.getHaifuMaisu() + tempMawbBean.getHaifuMaisu());
            // 使用枚数
            mawbBean.setShiyoMaisu(mawbBean.getShiyoMaisu() + tempMawbBean.getShiyoMaisu());
            // VOID枚数
            mawbBean.setVoidMaisu(mawbBean.getVoidMaisu() + tempMawbBean.getVoidMaisu());
            // 未使用枚数
            mawbBean.setMishiyoMaisu(mawbBean.getMishiyoMaisu() + tempMawbBean.getMishiyoMaisu());
            // 配布MAWB番号 使用率を設定する。
            mawbBean.setHaifuMawbBango(getShiyoRitu(mawbBean));
        }
    }

    /**
     * 親ノードを取得する。
     *
     * @param rootBean 編集用リストの内容
     * @param level 各データ行
     * @return 処理結果
     */
    private Mwb011MawbBangoBean getParentMawbBean(Mwb011MawbBangoBean rootBean, int level) {
        Mwb011MawbBangoBean mawbBean = null;
        int count;
        switch (level) {
            // 登録MAWB番号
            case 3:
                count = rootBean.getChildNodes().size();
                mawbBean = rootBean.getChildNodes().get(count - 1);
                count = mawbBean.getChildNodes().size();
                mawbBean = mawbBean.getChildNodes().get(count - 1);
                count = mawbBean.getChildNodes().size();
                mawbBean = mawbBean.getChildNodes().get(count - 1);
                break;
            // 航空会社
            case 2:
                count = rootBean.getChildNodes().size();
                mawbBean = rootBean.getChildNodes().get(count - 1);
                count = mawbBean.getChildNodes().size();
                mawbBean = mawbBean.getChildNodes().get(count - 1);
                break;
            // 発券営業所
            case 1:
                count = rootBean.getChildNodes().size();
                mawbBean = rootBean.getChildNodes().get(count - 1);
                break;
        }
        return mawbBean;
    }

    /**
     * 配布MAWB番号の開始から終了までの値を以下のリストに格納後、ワーク.一覧に追加する。
     *
     * @param tempMawbBean 編集用リストの内容
     */
    private void setHaifuMawbBangoList(Mwb011MawbBangoBean tempMawbBean) {
        tempMawbBean.setSelectMawbBangoList(new ArrayList<>());
        if (tempMawbBean.getHaifuMawbBangoFrom() != null && !"".equals(tempMawbBean.getHaifuMawbBangoFrom())
                && tempMawbBean.getHaifuMawbBangoTo() != null && !"".equals(tempMawbBean.getHaifuMawbBangoTo())) {
            int fromNumber = Integer.valueOf(tempMawbBean.getHaifuMawbBangoFrom().substring(0, 7));
            int toNumber = Integer.valueOf(tempMawbBean.getHaifuMawbBangoTo().substring(0, 7));

            for (int number = fromNumber; number <= toNumber; number++) {
                tempMawbBean.getSelectMawbBangoList().add(String.valueOf(number) + (number % 7));
            }
        }
    }

    /**
     * レコード行数を取得
     *
     * @param mawbBean 一覧内容
     * @return 行数
     */
    private int getDataListCount(Mwb011MawbBangoBean mawbBean) {
        int count1 = mawbBean.getChildNodes().size();
        int count2;
        int count3;
        if (count1 > 0) {
            for (Mwb011MawbBangoBean tempBean1 : mawbBean.getChildNodes()) {
                count2 = tempBean1.getChildNodes().size();
                count1 += count2;
                if (count2 > 0) {
                    for (Mwb011MawbBangoBean tempBean2 : tempBean1.getChildNodes()) {
                        count3 = tempBean2.getChildNodes().size();
                        count1 += count3;
                    }
                }
            }
        }
        return count1;
    }

    /**
     * 未使用MAWB表示が未チェックの場合、未使用枚数が1件以上の場合非表示
     *
     * @param list 一覧内容
     * @param mishiyoHyojiFlg 非表示フラグ
     * @return 処理結果
     */
    private List<Mwb011MawbBangoBean> getHyojiData(List<Map<String, Object>> list, Boolean mishiyoHyojiFlg) {
        List<Mwb011MawbBangoBean> listResult = new ArrayList<>();
        for (Map<String, Object> data : list) {
            Mwb011MawbBangoBean tempMawbBean = new Mwb011MawbBangoBean(4, data);
            // 未使用枚数を算出する。
            // 受入枚数 - (使用枚数 + VOID枚数)
            tempMawbBean.setMishiyoMaisu(tempMawbBean.getHaifuMaisu()
                    - (tempMawbBean.getShiyoMaisu() + tempMawbBean.getVoidMaisu()));
            // 【IF】未使用MAWB表示にチェックが入っていた場合
            if (mishiyoHyojiFlg) {
                listResult.add(tempMawbBean);
            } else {
                // 【IF】未使用枚数が0件以上の場合
                if (tempMawbBean.getMishiyoMaisu() == 0) {
                    listResult.add(tempMawbBean);
                }
                // 【ELSE】未使用枚数が1件の場合
                //  何もしない
            }
        }

        return listResult;
    }

    /**
     * 12.MAWB番号登録コンテキストメニュー 14.MAWB番号登録ボタン
     *
     */
    public void onMawbBangoMenuClick() {
        TreeNode treeNode = mwb011Form.getSelectedNode();
        if (treeNode == null || treeNode.getData() == null) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_WARN, MessageCnst.COME0029);
            return;
        }

        Object data = treeNode.getData();
        if (data instanceof Mwb011MawbBangoBean) {
            Mwb011MawbBangoBean selectedBean = (Mwb011MawbBangoBean) data;
            if (selectedBean.getLevel() == 2 || selectedBean.getLevel() == 3) {
                mwb011Form.setSelectedBean(selectedBean);
                // MAWB番号登録表示の初期処理
                initSelectedMawbBangoBean();
                // MAWB番号登録表示
                pageCommonBean.executeScript("PF('mwbBangou').show();");
            }
        }
    }

    /**
     * 13.MAWB配布登録コンテキストメニュー 15.MAWB配布登録ボタン
     *
     */
    public void onMawbHaifuMenuClick() {
        TreeNode treeNode = mwb011Form.getSelectedNode();
        if (treeNode == null || treeNode.getData() == null) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_WARN, MessageCnst.COME0029);
            return;
        }
        Object data = treeNode.getData();
        if (data instanceof Mwb011MawbBangoBean) {
            Mwb011MawbBangoBean selectedBean = (Mwb011MawbBangoBean) data;
            // 【IF】航空会社行のみ選択されている場合
            if (selectedBean.getLevel() == 4) {
                mwb011Form.setSelectedBean(selectedBean);
                // 更新登録モードにてモーダル画面を表示する
                pageCommonBean.executeScript("PF('mwbHaifu').show();");
            } else {

                return;
            }
        } else {

            return;
        }
    }

    /**
     * 登録MAWB番号枚数の計算を実施する
     *
     */
    public void torokuMawbBangoMaisuKeisan() {
        if ("".equals(mwb011Form.getSelectedBean().getSaiTorokuMawbBangoFrom())
                || "".equals(mwb011Form.getSelectedBean().getSaiTorokuMawbBangoTo())) {
            // 画面に表示する。
            mwb011Form.getSelectedBean().setSaiUkeireMaisu(0);
        } else {
            // 相関チェック
            if (!inputCheck(2)) {
                return;
            }
            int maisuFrom = 0;
            int maisuTo = 0;
            if (mwb011Form.getSelectedBean().getSaiTorokuMawbBangoFrom().length() > 7) {
                maisuFrom = Integer.valueOf(mwb011Form.getSelectedBean().getSaiTorokuMawbBangoFrom().substring(0, 7));
            } else {
                maisuFrom = Integer.valueOf(mwb011Form.getSelectedBean().getSaiTorokuMawbBangoFrom());
            }
            if (mwb011Form.getSelectedBean().getSaiTorokuMawbBangoTo().length() > 7) {
                maisuTo = Integer.valueOf(mwb011Form.getSelectedBean().getSaiTorokuMawbBangoTo().substring(0, 7));
            } else {
                maisuTo = Integer.valueOf(mwb011Form.getSelectedBean().getSaiTorokuMawbBangoTo());
            }
            // 登録MAWB番号Toの入力値 - 登録MAWB番号Fromの入力値 + 1
            int maisu = maisuTo - maisuFrom + 1;
            // 画面に表示する。
            mwb011Form.getSelectedBean().setSaiUkeireMaisu(maisu);
        }
    }

    /**
     * 22.枚数計算(範囲指定時)
     *
     */
    public void haifuMawbBangoRangeMaisuKeisan() {
        if ("".equals(mwb011Form.getSelectedBean().getSaiHaifuMawbBangoFrom())
                || "".equals(mwb011Form.getSelectedBean().getSaiHaifuMawbBangoTo())) {
            mwb011Form.getSelectedBean().setSaiHaifuMeisu(0);
        } else {
            // 相関チェック
            if (!inputCheck(9)) {
                return;
            }
            if (mwb011Form.getSelectedBean().getSaiHaifuMawbBangoFrom() != null
                    && mwb011Form.getSelectedBean().getSaiHaifuMawbBangoTo() != null) {
                int maisuFrom = 0;
                int maisuTo = 0;
                if (mwb011Form.getSelectedBean().getSaiHaifuMawbBangoFrom().length() > 7) {
                    maisuFrom = Integer.valueOf(mwb011Form.getSelectedBean().getSaiHaifuMawbBangoFrom().substring(0, 7));
                } else {
                    maisuFrom = Integer.valueOf(mwb011Form.getSelectedBean().getSaiHaifuMawbBangoFrom());
                }

                if (mwb011Form.getSelectedBean().getSaiHaifuMawbBangoTo().length() > 7) {
                    maisuTo = Integer.valueOf(mwb011Form.getSelectedBean().getSaiHaifuMawbBangoTo().substring(0, 7));
                } else {
                    maisuTo = Integer.valueOf(mwb011Form.getSelectedBean().getSaiHaifuMawbBangoTo());
                }
                // 登録MAWB番号Toの入力値 - 登録MAWB番号Fromの入力値 + 1
                int maisu = maisuTo - maisuFrom + 1;
                // 画面に表示する。
                mwb011Form.getSelectedBean().setSaiHaifuMeisu(maisu);
            }
        }
    }

    /**
     * 23.枚数計算(番号指定時)
     *
     */
    public void haifuMawbBangoListMaisuKeisan() {
        if (mwb011Form.getSelectedBean().getSelectedMawbBangoList() == null) {
            mwb011Form.getSelectedBean().setSaiHaifuMeisu(0);
        } else {
            mwb011Form.getSelectedBean().setSaiHaifuMeisu(
                    mwb011Form.getSelectedBean().getSelectedMawbBangoList().size());
        }
    }

    /**
     * 23.枚数計算(番号指定時)
     *
     */
    public void onSaiHaifuTypeChange() {
        if (mwb011Form.getSelectedBean().getSaiHaifuType() == 0) {
            haifuMawbBangoRangeMaisuKeisan();
        } else {
            haifuMawbBangoListMaisuKeisan();
        }
    }

    /**
     * MAWB番号登録表示の初期処理
     *
     */
    private void initSelectedMawbBangoBean() {
        Mwb011MawbBangoBean bean = mwb011Form.getSelectedBean();
        // 【IF】航空会社行のみ選択されている場合
        if (bean.getLevel() == 2) {
            // 新規登録モードにてモーダル画面を表示する
            // 受入日付
            bean.setSaiUkeireHizuke(null);
            // 登録MAWB番号
            bean.setSaiTorokuMawbBangoFrom("");
            bean.setSaiTorokuMawbBangoTo("");
            // 受入枚数
            bean.setSaiUkeireMaisu(0);
        } // 【ELSE】登録MAWB番号が一行のみ選択されている場合
        else if (bean.getLevel() == 3) {
            // 更新モードにてモーダル画面を表示する
            // 受入日付
            bean.setSaiUkeireHizuke(bean.getStrUkeireHizuke());
            // 登録MAWB番号
            bean.setSaiTorokuMawbBangoFrom(bean.getTorokuMawbBangoFrom());
            bean.setSaiTorokuMawbBangoTo(bean.getTorokuMawbBangoTo());
            // 受入枚数
            torokuMawbBangoMaisuKeisan();
        }

    }

    /**
     * 30.閉じるボタン(MAWB番号選択)
     *
     */
    public void onMawbBangoSelectColseClick() {
        // 枚数計算(番号指定時)
        haifuMawbBangoListMaisuKeisan();
    }

    /**
     * 18.登録ボタン(MAWB番号登録)
     *
     */
    public void torokuMawbBangoInsert() {
        // 入力項目チェック
        if (!inputCheck(3)) {
            return;
        }

        // 入力パラメータの作成
        Map<String, Object> criteria = createInputParams(2);
        // 重複チェック
        criteria.put(Mwb011Form.CONST_CON_SQL_ID, "searchCountForMawbToruko");
        long repeatBangoCount = getSearchResultCount(FUNC_CODE_SEARCH_KENSU, criteria);
        // 【IF】取得結果が1件以上存在する場合
        if (repeatBangoCount > 0) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MWBE0003);
            return;
        }

        // 2.MAWB番号登録
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(criteria, FUNC_CODE_MAWB_TOROKU);

        // エラーの場合、処理終了
        if (serviceInterfaceBean == null
                || ServiceInterfaceBean.PROCESS_STATUS_ERROR == serviceInterfaceBean.getStatusCode()) {
            return;
        }

        // 3.呼び出し元画面再描画
        // MAWB一覧にて検索処理を実施し、画面の再描画を行う。
        mawbTorokuGamenHiden();
        search();
    }

    /**
     * 19.更新ボタン(MAWB番号登録)
     *
     */
    public void torokuMawbBangoUpdate() {

        // 1.入力項目チェック
        if (!inputCheck(3)) {
            return;
        }

        // 2)存在チェック呼出し
        if (sonzaiCheck()) {
            // 取得結果が1件以上存在する場合
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MWBE0003);
            return;
        }

        // 入力パラメータの作成
        Map<String, Object> criteria = createInputParams(2);
        // 3)重複チェック呼出し
        criteria.put(Mwb011Form.CONST_CON_SQL_ID, "searchForMawbKoshin");
        long repeatBangoCount = getSearchResultCount(FUNC_CODE_SEARCH_KENSU, criteria);
        // 【IF】取得結果が1件以上存在する場合
        if (repeatBangoCount > 0) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MWBE0004, "登録");
            return;
        }

        // 2.MAWB番号更新
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(criteria, FUNC_CODE_MAWB_KOSHIN);

        // エラーの場合、処理終了
        if (serviceInterfaceBean == null
                || ServiceInterfaceBean.PROCESS_STATUS_ERROR == serviceInterfaceBean.getStatusCode()) {
            return;
        }

        // 3.呼び出し元画面再描画
        // MAWB一覧にて検索処理を実施し、画面の再描画を行う。
        mawbTorokuGamenHiden();
        search();
    }

    /**
     * 20.削除ボタン(MAWB番号登録)
     *
     */
    public void torokuMawbBangoDelete() {
        // 1.入力項目チェック
        if (!inputCheck(3)) {
            return;
        }

        // 範囲チェック
        // 呼び出し元画面から渡された登録MAWB番号From
        int torokuMawbBangoFromOld = Integer.valueOf(mwb011Form.getSelectedBean().getTorokuMawbBangoFrom());
        // 呼び出し元画面から渡された登録MAWB番号To
        int torokuMawbBangoToOld = Integer.valueOf(mwb011Form.getSelectedBean().getTorokuMawbBangoTo());
        // 登録MAWB番号From
        int torokuMawbBangoFromNew = Integer.valueOf(mwb011Form.getSelectedBean().getSaiTorokuMawbBangoFrom());
        // 登録MAWB番号To
        int torokuMawbBangoToNew = Integer.valueOf(mwb011Form.getSelectedBean().getSaiTorokuMawbBangoTo());
        // 元画面から渡された登録MAWB番号の範囲内に削除するMAWB番号の範囲（登録MAWB番号From～登録MAWB番号To)が含まれない場合
        if (!((torokuMawbBangoToOld >= torokuMawbBangoFromNew && torokuMawbBangoFromNew >= torokuMawbBangoFromOld)
                || (torokuMawbBangoFromOld <= torokuMawbBangoToNew && torokuMawbBangoToNew <= torokuMawbBangoToOld))) {
            // メッセージを表示する。
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MWBE0005, "削除");
            return;
        }

        // 存在チェック
        List<Map<String, Object>> searchList = getUsedMawbBangoList(mwb011Form.getSelectedBean().getHakkenEigyoshoCd(),
                mwb011Form.getSelectedBean().getKokuGaishaCd(),
                mwb011Form.getSelectedBean().getSaiTorokuMawbBangoFrom(),
                mwb011Form.getSelectedBean().getSaiTorokuMawbBangoTo());
        if (searchList.size() > 0) {
            // 取得結果が1件以上存在する場合
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MWBE0003);
            return;
        }

        // 入力パラメータの作成
        Map<String, Object> criteria = createInputParams(3);
        // MAWB番号削除
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(criteria, FUNC_CODE_MAWB_SAKUJO);

        // エラーの場合、処理を終了
        if (serviceInterfaceBean != null
                && serviceInterfaceBean.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            messagePropertyBean.message(serviceInterfaceBean.getMessages().get(0)[0],
                    serviceInterfaceBean.getMessages().get(0)[1],
                    serviceInterfaceBean.getMessages().get(0)[2]);
            return;
        }
        // MAWB一覧にて検索処理を実施し、画面の再描画を行う。
        mawbTorokuGamenHiden();
        search();
    }

    /**
     * 21.再配布形式
     *
     */
    public void haifuMawbBangoUpdate() {
        // 【IF】再配布MAWB番号が範囲指定の場合
        if (mwb011Form.getSelectedBean().getSaiHaifuType() == 0) {
            haifuMawbBangoRangeUpdate();
        } else {
            haifuMawbBangoListUpdate();
        }
    }

    /**
     * 26.更新ボタン(範囲指定時)(MAWB配布登録)
     *
     */
    public void haifuMawbBangoRangeUpdate() {

        // 再配布営業所が、呼び出し元画面から渡された再配布営業所と等しいかチェックを行う。        
        if (mwb011Form.getSelectedBean().getSaiHaifusakiEigyosho() != null) {
            String eigyosho = mwb011Form.getSelectedBean().getSaiHaifusakiEigyosho().getValue();
            if (eigyosho.equals(mwb011Form.getSelectedBean().getHaifusakiEigyoshoCd())) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MWBE0006);
                return;
            }
        }

        // 1.入力項目チェック
        if (!inputCheck(4)) {
            return;
        }

        // 3)範囲チェック
        // 再配布MAWB番号From
        int saiHaifuFrom = Integer.valueOf(mwb011Form.getSelectedBean().getSaiHaifuMawbBangoFrom());
        // 再配布MAWB番号To
        int saiHaifuTo = Integer.valueOf(mwb011Form.getSelectedBean().getSaiHaifuMawbBangoTo());
        // 呼び出し元画面から渡された再配布MAWB番号From
        int haifuFrom = Integer.valueOf(mwb011Form.getSelectedBean().getHaifuMawbBangoFrom());
        // 呼び出し元画面から渡された再配布MAWB番号To
        int haifuTo = Integer.valueOf(mwb011Form.getSelectedBean().getHaifuMawbBangoTo());

        // 【IF】再配布MAWB番号の範囲内である場合
        if (saiHaifuFrom >= haifuFrom && saiHaifuTo <= haifuTo) {
            // 何もしない。
        } else {
            // メッセージを表示する
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MWBE0005, "更新");
            return;
        }

        // 4)存在チェック
        List<Map<String, Object>> searchList = getUsedMawbBangoList(mwb011Form.getSelectedBean().getHakkenEigyoshoCd(),
                mwb011Form.getSelectedBean().getKokuGaishaCd(),
                mwb011Form.getSelectedBean().getSaiHaifuMawbBangoFrom(),
                mwb011Form.getSelectedBean().getSaiHaifuMawbBangoTo());
        if (searchList.size() > 0) {
            // 取得結果が1件以上存在する場合
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MWBE0003);
            return;
        }

        // 入力パラメータの作成
        Map<String, Object> criteria = createInputParams(4);
        // 2.再配布処理
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(criteria, FUNC_CODE_MAWB_HAIFU_KOSHIN);

        // エラーの場合、処理終了
        if (serviceInterfaceBean == null
                || ServiceInterfaceBean.PROCESS_STATUS_ERROR == serviceInterfaceBean.getStatusCode()) {
            return;
        }

        // 3.呼び出し元画面再描画
        // MAWB一覧にて検索処理を実施し、画面の再描画を行う。
        mawbHaifuGamenHiden();
        search();
    }

    /**
     * 27.更新ボタン(番号指定時)(MAWB配布登録)
     *
     */
    public void haifuMawbBangoListUpdate() {

        // 再配布営業所が、呼び出し元画面から渡された再配布営業所と等しいかチェックを行う。
        if (mwb011Form.getSelectedBean().getSaiHaifusakiEigyosho() != null) {
            String eigyosho = mwb011Form.getSelectedBean().getSaiHaifusakiEigyosho().getValue();
            if (eigyosho.equals(mwb011Form.getSelectedBean().getHaifusakiEigyoshoCd())) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MWBE0006);
                return;
            }
        }

        // MAWB番号選択画面にてMAWB番号が選択済がチェックを行う。
        if (mwb011Form.getSelectedBean().getSelectedMawbBangoList() == null
                || mwb011Form.getSelectedBean().getSelectedMawbBangoList().isEmpty()) {
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0007, "MAWB番号");
            return;
        }

        // 入力項目チェック
        if (!inputCheck(5)) {
            return;
        }

        // 3)範囲チェック
        // 再配布MAWB番号リスト
        List<String> bangoList = mwb011Form.getSelectedBean().getSelectedMawbBangoList();
        // 呼び出し元画面から渡された再配布MAWB番号From
        int haifuFrom = Integer.valueOf(mwb011Form.getSelectedBean().getHaifuMawbBangoFrom());
        // 呼び出し元画面から渡された再配布MAWB番号To
        int haifuTo = Integer.valueOf(mwb011Form.getSelectedBean().getHaifuMawbBangoTo());
        for (String bango : bangoList) {
            int haifuBango = Integer.valueOf(bango);
            if (!(haifuBango >= haifuFrom && haifuBango <= haifuTo)) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MWBE0005, "更新");
                return;
            }
        }
        // 入力パラメータの作成
        Map<String, Object> criteria = createInputParams(5);
        criteria.put(Mwb011Form.CONST_CON_HAKKEN_EIGYOSHO_CD, mwb011Form.getSelectedBean().getHakkenEigyoshoCd());
        criteria.put(Mwb011Form.CONST_CON_KOKU_GAISHA_CD, mwb011Form.getSelectedBean().getKokuGaishaCd());
        criteria.put(Mwb011Form.CONST_CON_SQL_ID, "searchUsedMawbBangoByList");
        // 4)存在チェック
        List<Map<String, Object>> searchList = getSearchDataFromDb(FUNC_CODE_SEARCH_DATA, criteria);
        if (searchList.size() > 0) {
            // 取得結果が1件以上存在する場合
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MWBE0003);
            return;
        }

        // 2.再配布処理        
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(criteria, FUNC_CODE_MAWB_HAIFU_KOSHIN);

        // エラーの場合、処理終了
        if (serviceInterfaceBean == null
                || ServiceInterfaceBean.PROCESS_STATUS_ERROR == serviceInterfaceBean.getStatusCode()) {
            return;
        }

        // 3.呼び出し元画面再描画
        // MAWB一覧にて検索処理を実施し、画面の再描画を行う。
        mawbHaifuGamenHiden();
        search();
    }

    /**
     * 28.削除ボタン(MAWB配布登録)
     *
     */
    public void haifuMawbBangoDelete() {
        // 入力パラメータ
        Map<String, Object> criteria;

        // 【IF】再配布MAWB番号が範囲指定の場合
        if (mwb011Form.getSelectedBean().getSaiHaifuType() == 0) {
            // 各項目のチェック条件は、シート「チェック仕様」のNo6を参照。
            if (!inputCheck(6)) {
                return;
            }

            // 2)範囲チェック
            // 再配布MAWB番号From
            int saiHaifuFrom = Integer.valueOf(mwb011Form.getSelectedBean().getSaiHaifuMawbBangoFrom());
            // 再配布MAWB番号To
            int saiHaifuTo = Integer.valueOf(mwb011Form.getSelectedBean().getSaiHaifuMawbBangoTo());
            // 呼び出し元画面から渡された再配布MAWB番号From
            int haifuFrom = Integer.valueOf(mwb011Form.getSelectedBean().getHaifuMawbBangoFrom());
            // 呼び出し元画面から渡された再配布MAWB番号To
            int haifuTo = Integer.valueOf(mwb011Form.getSelectedBean().getHaifuMawbBangoTo());

            // 【IF】再配布MAWB番号の範囲内である場合
            if (saiHaifuFrom >= haifuFrom && saiHaifuTo <= haifuTo) {
                // 何もしない。
            } else {
                // メッセージを表示する。
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MWBE0012, "再配布", "削除");
                return;
            }

            // 3)存在チェック
            List<Map<String, Object>> searchList = getUsedMawbBangoList(
                    mwb011Form.getSelectedBean().getHakkenEigyoshoCd(),
                    mwb011Form.getSelectedBean().getKokuGaishaCd(),
                    mwb011Form.getSelectedBean().getSaiHaifuMawbBangoFrom(),
                    mwb011Form.getSelectedBean().getSaiHaifuMawbBangoTo());
            if (searchList.size() > 0) {
                // 取得結果が1件以上存在する場合
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MWBE0003);
                return;
            }
            // 入力パラメータの作成
            criteria = createInputParams(6);
        } else {
            // 【IF】再配布MAWB番号リストにMAWB番号が存在する場合
            if (mwb011Form.getSelectedBean().getSelectedMawbBangoList() == null
                    || mwb011Form.getSelectedBean().getSelectedMawbBangoList().isEmpty()) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0007, "MAWB番号");
                return;
            }

            // 2)範囲チェック
            // 再配布MAWB番号リスト
            List<String> bangoList = mwb011Form.getSelectedBean().getSelectedMawbBangoList();
            // 呼び出し元画面から渡された再配布MAWB番号From
            int haifuFrom = Integer.valueOf(mwb011Form.getSelectedBean().getHaifuMawbBangoFrom());
            // 呼び出し元画面から渡された再配布MAWB番号To
            int haifuTo = Integer.valueOf(mwb011Form.getSelectedBean().getHaifuMawbBangoTo());
            for (String bango : bangoList) {
                int haifuBango = Integer.valueOf(bango);
                if (haifuBango >= haifuFrom && haifuBango <= haifuTo) {
                    //何もしない。
                } else {
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR,
                            MessageCnst.MWBE0012, "再配布", "削除");
                    break;
                }
            }

            // 入力パラメータの作成
            criteria = createInputParams(6);
            criteria.put(Mwb011Form.CONST_CON_HAKKEN_EIGYOSHO_CD, mwb011Form.getSelectedBean().getHakkenEigyoshoCd());
            criteria.put(Mwb011Form.CONST_CON_KOKU_GAISHA_CD, mwb011Form.getSelectedBean().getKokuGaishaCd());
            criteria.put(Mwb011Form.CONST_CON_SQL_ID, "searchUsedMawbBangoByList");
            // 4)存在チェック
            List<Map<String, Object>> searchList = getSearchDataFromDb(FUNC_CODE_SEARCH_DATA, criteria);
            if (searchList.size() > 0) {
                // 取得結果が1件以上存在する場合
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MWBE0003);
                return;
            }
        }

        // 2.MAWB番号削除        
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(criteria, FUNC_CODE_MAWB_HAIFU_SAKUJO);

        // エラーの場合、処理終了
        if (serviceInterfaceBean == null
                || ServiceInterfaceBean.PROCESS_STATUS_ERROR == serviceInterfaceBean.getStatusCode()) {
            return;
        }

        // 3.呼び出し元画面再描画
        // MAWB一覧にて検索処理を実施し、画面の再描画を行う。
        mawbHaifuGamenHiden();
        search();
    }

    /**
     * 17.閉じるボタン（MAWB番号登録）
     *
     */
    public void mawbTorokuGamenHiden() {

        // 項目初期化
        // 受入日付
        mwb011Form.getSelectedBean().setSaiUkeireHizuke("");
        // 登録MAWB番号 
        mwb011Form.getSelectedBean().setSaiTorokuMawbBangoFrom("");
        mwb011Form.getSelectedBean().setSaiTorokuMawbBangoTo("");
        mwb011Form.getSelectedBean().setSaiUkeireMaisu(0);
        pageCommonBean.executeScript("PF('mwbBangou').hide();");
    }

    /**
     * 30.閉じるボタン(MAWB番号選択)
     *
     */
    public void mawbHaifuGamenHiden() {
        // 項目初期化
        mwb011Form.getSelectedBean().setSaiHaifuHizuke("");
        // 再配布先営業所 
        mwb011Form.getSelectedBean().setSaiHaifusakiEigyosho(null);
        // 再配布形式 
        mwb011Form.getSelectedBean().setSaiHaifuType(0);
        // 再配布MAWB番号 
        mwb011Form.getSelectedBean().setSaiHaifuMawbBangoFrom("");
        mwb011Form.getSelectedBean().setSaiHaifuMawbBangoTo("");
        mwb011Form.getSelectedBean().setSaiHaifuMeisu(0);
        pageCommonBean.executeScript("PF('mwbHaifu').hide();");
    }

    /**
     * 入力パラメータの取得
     *
     * @return 入力パラメータリスト
     * @param mode モード
     */
    public Map<String, Object> createInputParams(int mode) {
        Map<String, Object> criteria = new HashMap<>();
        switch (mode) {
            // 登録ボタン(MAWB番号登録)
            case 1:
                // 発券営業所コード
                criteria.put(Mwb011Form.PARAM_NAME_BNG_HAKKEN_EIGYOSHO_CD,
                        mwb011Form.getSelectedBean().getHakkenEigyoshoCd());
                // 航空会社コード
                criteria.put(Mwb011Form.PARAM_NAME_BNG_KOKU_GAISHA_CD,
                        mwb011Form.getSelectedBean().getKokuGaishaCd());
                // 受入日付
                criteria.put(Mwb011Form.PARAM_NAME_BNG_UKEIRE_HIZUKE,
                        mwb011Form.getSelectedBean().getSaiUkeireHizuke());
                // 登録MAWB番号From
                criteria.put(Mwb011Form.PARAM_NAME_BNG_SAITOROKU_MAWB_BANGO_FROM,
                        mwb011Form.getSelectedBean().getSaiTorokuMawbBangoFrom());
                // 登録MAWB番号To
                criteria.put(Mwb011Form.PARAM_NAME_BNG_SAITOROKU_MAWB_BANGO_TO,
                        mwb011Form.getSelectedBean().getSaiTorokuMawbBangoTo());
                break;

            // 更新ボタン(MAWB番号登録)
            case 2:
                // 発券営業所コード
                criteria.put(Mwb011Form.PARAM_NAME_BNG_HAKKEN_EIGYOSHO_CD,
                        mwb011Form.getSelectedBean().getHakkenEigyoshoCd());
                // 航空会社コード
                criteria.put(Mwb011Form.PARAM_NAME_BNG_KOKU_GAISHA_CD,
                        mwb011Form.getSelectedBean().getKokuGaishaCd());
                // MAWB登録ID
                criteria.put(Mwb011Form.PARAM_NAME_BNG_MAWB_TOROKU_ID,
                        mwb011Form.getSelectedBean().getMawbTorokuId());
                // 受入日付
                criteria.put(Mwb011Form.PARAM_NAME_BNG_UKEIRE_HIZUKE,
                        mwb011Form.getSelectedBean().getSaiUkeireHizuke());
                // 登録MAWB番号From
                criteria.put(Mwb011Form.PARAM_NAME_BNG_TOROKU_MAWB_BANGO_FROM,
                        mwb011Form.getSelectedBean().getTorokuMawbBangoFrom());
                // 登録MAWB番号To
                criteria.put(Mwb011Form.PARAM_NAME_BNG_TOROKU_MAWB_BANGO_TO,
                        mwb011Form.getSelectedBean().getTorokuMawbBangoTo());
                // 登録MAWB番号From
                criteria.put(Mwb011Form.PARAM_NAME_BNG_SAITOROKU_MAWB_BANGO_FROM,
                        mwb011Form.getSelectedBean().getSaiTorokuMawbBangoFrom());
                // 登録MAWB番号To
                criteria.put(Mwb011Form.PARAM_NAME_BNG_SAITOROKU_MAWB_BANGO_TO,
                        mwb011Form.getSelectedBean().getSaiTorokuMawbBangoTo());
                break;

            // 削除ボタン(MAWB番号登録)    
            case 3:
                // 発券営業所コード
                criteria.put(Mwb011Form.PARAM_NAME_BNG_HAKKEN_EIGYOSHO_CD,
                        mwb011Form.getSelectedBean().getHakkenEigyoshoCd());
                // 航空会社コード
                criteria.put(Mwb011Form.PARAM_NAME_BNG_KOKU_GAISHA_CD,
                        mwb011Form.getSelectedBean().getKokuGaishaCd());
                // MAWB登録ID
                criteria.put(Mwb011Form.PARAM_NAME_BNG_MAWB_TOROKU_ID,
                        mwb011Form.getSelectedBean().getMawbTorokuId());
                // 受入日付
                criteria.put(Mwb011Form.PARAM_NAME_BNG_UKEIRE_HIZUKE,
                        mwb011Form.getSelectedBean().getSaiUkeireHizuke());
                // 登録MAWB番号From
                criteria.put(Mwb011Form.PARAM_NAME_BNG_TOROKU_MAWB_BANGO_FROM,
                        mwb011Form.getSelectedBean().getTorokuMawbBangoFrom());
                // 登録MAWB番号To
                criteria.put(Mwb011Form.PARAM_NAME_BNG_TOROKU_MAWB_BANGO_TO,
                        mwb011Form.getSelectedBean().getTorokuMawbBangoTo());
                // 登録MAWB番号From
                criteria.put(Mwb011Form.PARAM_NAME_BNG_SAITOROKU_MAWB_BANGO_FROM,
                        mwb011Form.getSelectedBean().getSaiTorokuMawbBangoFrom());
                // 登録MAWB番号To
                criteria.put(Mwb011Form.PARAM_NAME_BNG_SAITOROKU_MAWB_BANGO_TO,
                        mwb011Form.getSelectedBean().getSaiTorokuMawbBangoTo());
                break;

            // 更新ボタン(範囲指定時)(MAWB配布登録)
            case 4:
            case 5:
            case 6:
                // 発券営業所コード
                criteria.put(Mwb011Form.PARAM_NAME_HIF_HAKKEN_EIGYOSHO_CD,
                        mwb011Form.getSelectedBean().getHakkenEigyoshoCd());
                // 航空会社コード
                criteria.put(Mwb011Form.PARAM_NAME_HIF_KOKU_GAISHA_CD,
                        mwb011Form.getSelectedBean().getKokuGaishaCd());
                // MAWB登録ID
                criteria.put(Mwb011Form.PARAM_NAME_HIF_MAWB_TOROKU_ID,
                        mwb011Form.getSelectedBean().getMawbTorokuId());
                // 配布営業所コード
                criteria.put(Mwb011Form.PARAM_NAME_HIF_HAIFUSAKI_EIGYOSHO_CD,
                        mwb011Form.getSelectedBean().getHaifusakiEigyoshoCd());
                // MAWB配布ID
                criteria.put(Mwb011Form.PARAM_NAME_HIF_MAWB_HAIFU_ID, mwb011Form.getSelectedBean().getMawbHaifuId());
                // 配布MAWB番号From
                criteria.put(Mwb011Form.PARAM_NAME_HIF_HAIFU_MAWB_BANGO_FROM,
                        mwb011Form.getSelectedBean().getHaifuMawbBangoFrom());
                // 配布MAWB番号To
                criteria.put(Mwb011Form.PARAM_NAME_HIF_HAIFU_MAWB_BANGO_TO,
                        mwb011Form.getSelectedBean().getHaifuMawbBangoTo());
                // 再配布日付
                criteria.put(Mwb011Form.PARAM_NAME_HIF_SAIHAIFU_HIZUKE,
                        mwb011Form.getSelectedBean().getSaiHaifuHizuke());
                // 再配布先営業所
                if (mwb011Form.getSelectedBean().getSaiHaifusakiEigyosho() != null) {
                    criteria.put(Mwb011Form.PARAM_NAME_HIF_SAIHAIFUSAKI_EIGYOSHO_CD,
                            mwb011Form.getSelectedBean().getSaiHaifusakiEigyosho().getValue());
                } else {
                    criteria.put(Mwb011Form.PARAM_NAME_HIF_SAIHAIFUSAKI_EIGYOSHO_CD, "");
                }
                // 再配布形式
                criteria.put(Mwb011Form.PARAM_NAME_HIF_SAIHAIFU_KEISHIKI,
                        mwb011Form.getSelectedBean().getSaiHaifuType());
                // 再配布MAWB番号
                criteria.put(Mwb011Form.PARAM_NAME_HIF_SAIHAIFU_MAWB_BANGO_FROM,
                        mwb011Form.getSelectedBean().getSaiHaifuMawbBangoFrom());
                criteria.put(Mwb011Form.PARAM_NAME_HIF_SAIHAIFU_MAWB_BANGO_TO,
                        mwb011Form.getSelectedBean().getSaiHaifuMawbBangoTo());
                criteria.put(Mwb011Form.PARAM_NAME_HIF_SENTAKU_SELECT_MAWB_BANGO,
                        mwb011Form.getSelectedBean().getSelectedMawbBangoList());
                break;
        }
        return criteria;
    }

    /**
     * 入力項目必須チェック
     *
     * @param value チェック対象
     * @return チェック結果
     */
    protected boolean requiredCheck(Object value) {
        boolean hasValue = true;
        if (value == null || "".equals(value.toString().trim())) {
            hasValue = false;
        }
        return hasValue;
    }

    /**
     * FROMとTOが逆転していないかチェック
     *
     * @param from チェック開始対象
     * @param to チェック終了対象
     * @return チェック結果
     */
    public boolean reversalCheck(Object from, Object to) {
        boolean isFormat = true;
        if (from != null && to != null) {
            if (from instanceof Date && to instanceof Date) {
                Date fromDate = (Date) from;
                Date toDate = (Date) to;
                if (fromDate.getTime() > toDate.getTime()) {
                    isFormat = false;
                }
            } else if (from instanceof String && to instanceof String) {
                int fromValue = Integer.valueOf(from.toString());
                int toValue = Integer.valueOf(to.toString());
                if (fromValue > toValue) {
                    isFormat = false;
                }
            }
        }

        return isFormat;
    }

    /**
     * 7DRチェック
     *
     * @param value チェック対象
     * @return チェック結果
     */
    private boolean sevenDRCheck(Object value) {
        boolean isFormat = false;
        if (value != null && value.toString().length() == 8) {
            // MAWB番号の上7桁
            int maeNumber = Integer.valueOf(value.toString().substring(0, 7));
            // MAWB番号の下1桁
            int lastNumber = Integer.valueOf(value.toString().substring(7, 8));
            // 1)MAWB番号の上7桁を7で割り、余りを求める。(余り = 7DR)
            int mod = maeNumber % 7;
            // 2)7DRと、MAWB番号の下1桁が一致するかをチェックする。
            if (mod == lastNumber) {
                isFormat = true;
            }
        }

        return isFormat;
    }

    /**
     * 存在チェック
     *
     * @return チェック結果
     */
    private boolean sonzaiCheck() {
        boolean result = false;
        // 登録MAWB番号の範囲と呼び出し元画面から渡された登録MAWB番号の範囲を比較し、
        // チェックが必要である場合に存在チェックを行う。
        // 登録MAWB番号のチェック範囲を取得
        List<Mwb011BangoRangeBean> checkBangoRangeList = getBngTorokuMawbBangoRange();
        // チェックが必要である場合
        if (checkBangoRangeList != null && checkBangoRangeList.size() > 0) {
            // 存在チェックを行う
            List<Map<String, Object>> usedList
                    = getUsedMawbBangoList(mwb011Form.getSelectedBean().getHakkenEigyoshoCd(),
                            mwb011Form.getSelectedBean().getKokuGaishaCd(), checkBangoRangeList);
            if (usedList != null && usedList.size() > 0) {
                result = true;
            }
        }

        return result;
    }

    /**
     * 登録MAWB番号の範囲と呼び出し元画面から渡された登録MAWB番号の範囲を比較しチェック範囲を取得する
     *
     * @return チェック結果リスト
     */
    private List<Mwb011BangoRangeBean> getBngTorokuMawbBangoRange() {
        List<Mwb011BangoRangeBean> resultRange = new ArrayList<>();
        int atoFrom = Integer.valueOf(mwb011Form.getSelectedBean().getSaiTorokuMawbBangoFrom());
        int atoTo = Integer.valueOf(mwb011Form.getSelectedBean().getSaiTorokuMawbBangoTo());
        int maeFrom = Integer.valueOf(mwb011Form.getSelectedBean().getTorokuMawbBangoFrom());
        int maeTo = Integer.valueOf(mwb011Form.getSelectedBean().getTorokuMawbBangoTo());

        // A.更新前From < 更新後From かつ 更新後From < 更新前To のパターン
        // C.更新前To > 更新後To かつ 更新前From < 更新後To のパターン
        // AとCの複合パターン
        if ((maeFrom < atoFrom && atoFrom < maeTo) && (maeTo > atoTo && maeFrom < atoTo)) {
            // AとCの複合パターン
            Mwb011BangoRangeBean bangoRange = new Mwb011BangoRangeBean();
            bangoRange.setTorokuMawbBangoFrom(formatMawbBango(maeFrom));
            bangoRange.setTorokuMawbBangoTo(formatMawbBango(getMinusOneNumber(atoFrom)));
            resultRange.add(bangoRange);

            bangoRange = new Mwb011BangoRangeBean();
            bangoRange.setTorokuMawbBangoFrom(formatMawbBango(getPlusOneNumber(atoTo)));
            bangoRange.setTorokuMawbBangoTo(formatMawbBango(maeTo));
            resultRange.add(bangoRange);

        } else {
            // A.更新前From < 更新後From かつ 更新後From < 更新前To のパターン
            if (maeFrom < atoFrom && atoFrom < maeTo) {
                Mwb011BangoRangeBean bangoRange = new Mwb011BangoRangeBean();
                bangoRange.setTorokuMawbBangoFrom(formatMawbBango(maeFrom));
                bangoRange.setTorokuMawbBangoTo(formatMawbBango(getMinusOneNumber(atoFrom)));
                resultRange.add(bangoRange);
            }

            // C.更新前To > 更新後To かつ 更新前From < 更新後To のパターン
            if (maeTo > atoTo && maeFrom < atoTo) {
                Mwb011BangoRangeBean bangoRange = new Mwb011BangoRangeBean();
                bangoRange.setTorokuMawbBangoFrom(formatMawbBango(getPlusOneNumber(atoTo)));
                bangoRange.setTorokuMawbBangoTo(formatMawbBango(maeTo));
                resultRange.add(bangoRange);
            }
        }

        // B.更新前From < 更新後From かつ 更新後From ≧ 更新前To のパターン
        if (maeFrom < atoFrom && atoFrom >= maeTo) {
            Mwb011BangoRangeBean bangoRange = new Mwb011BangoRangeBean();
            bangoRange.setTorokuMawbBangoFrom(formatMawbBango(maeFrom));
            bangoRange.setTorokuMawbBangoTo(formatMawbBango(maeTo));
            resultRange.add(bangoRange);
        }

        // D.更新前To > 更新後To かつ 更新前From ≧ 更新後To のパターン
        if (maeTo > atoTo && maeFrom >= atoTo) {
            Mwb011BangoRangeBean bangoRange = new Mwb011BangoRangeBean();
            bangoRange.setTorokuMawbBangoFrom(formatMawbBango(maeFrom));
            bangoRange.setTorokuMawbBangoTo(formatMawbBango(maeTo));
            resultRange.add(bangoRange);
        }

        return resultRange;
    }

    /**
     * 登録MAWB番号複合
     *
     * @param number MAWB番号
     * @return 処理結果
     */
    public String formatMawbBango(int number) {
        String strNumber = String.valueOf(number);
        while (strNumber.length() < 8) {
            strNumber = "0" + strNumber;
        }
        return strNumber;
    }

    /**
     * 登録MAWB番号 存在チェック
     *
     * @param keyEigyoshoCd 営業所コード
     * @param keyGaishaCd 会社コード
     * @param rangeList 範囲リスト
     * @return チェック結果リスト
     */
    protected List<Map<String, Object>> getUsedMawbBangoList(
            Object keyEigyoshoCd, Object keyGaishaCd, List<Mwb011BangoRangeBean> rangeList) {
        List<Map<String, Object>> resultList = new ArrayList<>();

        for (Mwb011BangoRangeBean bangoRange : rangeList) {
            List<Map<String, Object>> searchList = getUsedMawbBangoList(
                    keyEigyoshoCd, keyGaishaCd, bangoRange.getTorokuMawbBangoFrom(), bangoRange.getTorokuMawbBangoTo());
            resultList.addAll(searchList);
        }
        return resultList;
    }

    /**
     * 登録MAWB番号 存在チェック<br>
     *
     * @param eigyoshoCd 営業所コード
     * @param gaishaCd 会社コード
     * @param bangoFrom 登録MAWB開始番号
     * @param bangoTo 登録MAWB終了番号
     * @return
     */
    private List<Map<String, Object>> getUsedMawbBangoList(Object eigyoshoCd,
            Object gaishaCd, Object bangoFrom, Object bangoTo) {
        Map<String, Object> criteria = new HashMap<>();
        criteria.put(Mwb011Form.CONST_CON_HAKKEN_EIGYOSHO_CD, eigyoshoCd);
        criteria.put(Mwb011Form.CONST_CON_KOKU_GAISHA_CD, gaishaCd);
        criteria.put(Mwb011Form.CONST_CON_KAISHI_MAWB_BANGO, bangoFrom);
        criteria.put(Mwb011Form.CONST_CON_SHURYO_MAWB_BANGO, bangoTo);
        criteria.put(Mwb011Form.CONST_CON_SQL_ID, "searchUsedMawbBango");
        return getSearchDataFromDb(FUNC_CODE_SEARCH_DATA, criteria);
    }

    /**
     * MAWB番号+1
     *
     * @param MAWB番号
     * @return MAWB番号+1
     */
    private int getPlusOneNumber(int number) {
        int newNumber = number / 10;
        newNumber = newNumber + 1;
        int mod = newNumber % 7;
        newNumber = newNumber * 10 + mod;
        return newNumber;
    }

    /**
     * MAWB番号-1
     *
     * @param MAWB番号
     * @return MAWB番号-1
     */
    private int getMinusOneNumber(int number) {
        int newNumber = number / 10;
        newNumber = newNumber - 1;
        int mod = newNumber % 7;
        newNumber = newNumber * 10 + mod;
        return newNumber;
    }

    /**
     * 検索条件チェック
     *
     * @return チェック結果
     * @throws SystemException
     */
    public String searchCheck() throws SystemException {
        // 検索条件チェック
        // 1.パラメータ取得
        getSearchParams();

        // ワーク.一覧
        mwb011Form.setSearchResult(new ArrayList<>());
        // 2.入力項目チェック
        if (!inputCheck(1)) {
            return "FALSE";
        }
        return "TRUE";
    }

    /**
     * メニュークリック処理
     *
     * @param menuId メニューID
     * @param nextScreenId 遷移先画面ID
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreenId) {
        try {
            // パンくずを削除する
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移を行う
        url = forward(nextScreenId, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック処理
     *
     * @param nextScreenId 遷移先画面ID
     * @param breadIndex パンくずのインデックス
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreenId, int breadIndex) {

        try {
            // パンくずを削除する
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移を行う
        url = forward(nextScreenId, null, null, true);
        return url;
    }

    /**
     * ログアウトクリック処理
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authorityConfBean.logout();
    }
}
