/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.JushoComponentBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.forms.mst.Mst172Form;
import static jp.co.kintetsuls.utils.StrUtils.objectToString;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 荷受人/荷送人マスタ詳細画面
 * 
 * @author 许博 (MBP)
 * @version 2019/3/7 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst172")
@ViewScoped
@Data
public class Mst172Bean extends AbstractBean {
    
    /**
     * 荷受人タイトル
     */
    private final String TITLE1 = "荷受人マスタ詳細";
    
    /**
     * 荷送人タイトル
     */
    private final String TITLE2 = "荷送人マスタ詳細";
    
    /**
     * 画面URL
     */
    private String url;

    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

    /**
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authorityConfBean;
    
    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;
    
    /**
     * 画面フォーム
     */
    @ManagedProperty(value = "#{mst172Form}")
    private Mst172Form mst172Form;
    
    /**
     * 画面共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;
    
    /**
     * 住所共通作業
     */
    @ManagedProperty(value = "#{jushoComponent}")
    private JushoComponentBean jushoComponentBean;

    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(
            new Object() {}.getClass().getEnclosingClass().getName());
    
    /**
     * 定数：画面項目保持キー
     */
    private static final String CONST_MST172_FORM = "mst172Form";

    /**
     * 定数：MasterInfo取得キー
     */
    private static final String CONST_MST172_MASTER = "mst172";
    
    /**
     * スクリーンコード：MST151
     */
    private static final String SC_CD_MST172 = "MST172_SCREEN";
    
    /**
     * 定数：荷受人/荷送人情報検索ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH = "mst172-search";
    
    /**
     * 定数：荷受人/荷送人自動採番処理ファンクションコード
     */
    private static final String FUNC_CODE_SAIBAN = "mst172-saiban";
    
    /**
     * 定数：荷送人マスタと荷受人マスタ登録更新ファンクションコード
     */
    private static final String FUNC_CODE_INSERT_UPDATE = "mst172-insert-update";
    
    /**
     * 定数：登録の重複チェックファンクションコード
     */
    private static final String FUNC_CODE_INSERT_UPDATE_CHECK = "mst172-insert-update-check";
    
    /**
     * ワーク.メッセージリスト
     */
    List<MessageModuleBean> msgList = new ArrayList<>();

    /**
     * コンストラクタ
     */
    public Mst172Bean() {

    }
    
    /**
     * 初期処理（処理）
     *
     * @param menuId　メニューID
     * @param prevScreen 遷移元画面ID
     * @param backFlag 戻るフラグ
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {   
            Flash flash = null;
            String searchKokyaku = "";
            // 戻ってきた場合
            Mst172Form preForm = (Mst172Form) pageCommonBean.getPageInfo(CONST_MST172_FORM);
            if (backFlag && preForm != null) {
                PageCommonBean.simpleCopy(preForm, mst172Form);
                // 何もしない
                // 画面用項目設定（荷受人情報）
                setSearchJoho(preForm.getSearchResult());;
                // 進んできた場合
            } else {
                flash = pageCommonBean.getPageParam();
            }
            
            // 初期化の時パラメータを設定
            if(flash != null){  
                // 荷受人/荷送人モード設定
                mst172Form.setConNiukeNiokurininMode(objectToString(flash.get("conNiukeNiokurininMode")));
                // 参照/編集/新規モード設定
                mst172Form.setConSanshoHenshuShinkiMode(objectToString(flash.get("conSanshoHenshuShinkiMode")));
                // 荷受人発行コード設定
                if(flash.get("dtlNiukeninHakkoCd") != null){
                    mst172Form.setDtlNiukeninHakkoCd(objectToString(flash.get("dtlNiukeninHakkoCd")));
                }
                // 荷送人発行コード設定
                if(flash.get("dtlNiokurininHakkoCd") != null){
                    mst172Form.setDtlNiokurininHakkoCd(objectToString(flash.get("dtlNiokurininHakkoCd")));
                }    
                // 顧客コード設定
                if(flash.get("dtlKokyakuCd") != null){
                    mst172Form.setDtlKokyakuCd(objectToString(flash.get("dtlKokyakuCd")));
                }
                // 検索条件顧客コード設定
                if(flash.get("kokyakuCd") != null){
                    searchKokyaku = objectToString(flash.get("kokyakuCd"));
                }
                
                // モード区分によって初期化する
                if("2".equals(mst172Form.getConSanshoHenshuShinkiMode())){
                    // 複写登録の場合
                    if(mst172Form.getDtlKokyakuCd() != null && 
                            (mst172Form.getDtlNiukeninHakkoCd() != null || mst172Form.getDtlNiokurininHakkoCd() != null)){
                        // 検索処理
                        searchInfo(); 
                    // 新規作成の場合
                    }else{
                        // 前画面の顧客コード検索条件が入力されていた場合、入力フォームの「顧客コード」に代入し、編集不可とする
                        mst172Form.setDtlKokyakuCdDisabled(true);
                        mst172Form.setDtlKokyakuCd(searchKokyaku);
                    }
                // 他の場合
                }else{
                    // 検索処理
                    searchInfo();  
                }
            }         
             
            // パンくずを追加する
            if("1".equals( mst172Form.getConNiukeNiokurininMode())){
                breadBean.push(TITLE1, Cnst.SCREEN.MST172_SCREEN.name(), this);
            }else{
                breadBean.push(TITLE2, Cnst.SCREEN.MST172_SCREEN.name(), this);
            }

            // システムマスタ取得する
            pageCommonBean.getMasterInfo(CONST_MST172_MASTER);
            
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する
            // 仕向地取得
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_SHIMUKE_CHI_CD);
            // 営業所取得
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO);
            // JISコード
            autoCompleteViewBean.initAddr("JIS_CD", null);
       
            // component初期化とユーザ権限により制御を設定する
            pageCommonBean.setAuthControll(mst172Form, SC_CD_MST172, true);
      
        }catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        } catch (SystemException ex) {
            java.util.logging.Logger.getLogger(Mst172Bean.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * 検索処理
     *
     * @throws jp.co.kintetsuls.exception.SystemException
     */
    public void searchInfo() throws SystemException {
        
        // 画面用変数初期化             
        // 荷受人マスタ情報を検索し、取得した値を画面項目にセット
        Map<String, Object> searchResult = getHakkoDetail();

        if(searchResult != null){
            if (StringUtils.equals(searchResult.get("searchResult").toString(), StringUtils.EMPTY)) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_WARN, MessageCnst.COMW0001);
            } else {
                Map<String, Object> result = (Map<String, Object>) searchResult.get("searchResult");
                // 画面用項目設定（荷受人情報）
                setSearchJoho(result);
                mst172Form.setSearchResult(result);
            }
        }

        // 検索条件保存
        pageCommonBean.savePageInfo(CONST_MST172_FORM, mst172Form);
    }
    
    /**
     * メニュークリック処理
     *
     * @param menuId メニューID
     * @param nextScreenId 遷移先画面ID
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreenId) {
        try {
            // パンくずを削除する
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移を行う
        url = forward(nextScreenId, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック処理
     *
     * @param nextScreenId 遷移先画面ID
     * @param breadIndex パンくずのインデックス
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreenId, int breadIndex) {
        try {
            // パンくずを削除する
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        
        // 画面遷移を行う
        url = forward(nextScreenId, null, null, true);
        return url;
    }

    /**
     * ログアウトクリック処理
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        // 遷移先の画面URL
        return authorityConfBean.logout();
    }
    
    /**
     * 荷受人/荷送人マスタ情報取得する
     * 
     * @return  荷受人/荷送人マスタ情報取得結果
     */
    private Map<String, Object> getHakkoDetail() {

        // パラメータ設定
        Map<String, Object> params = new HashMap<>();

        // 顧客コード
        params.put("conKokyakuCd", mst172Form.getDtlKokyakuCd());
        // 荷受人/荷送人モード区分
        params.put("conNiukeNiokurininMode", mst172Form.getConNiukeNiokurininMode());
        
        if("1".equals(mst172Form.getConNiukeNiokurininMode())){
            // 荷受人発行コード
            params.put("conNiukeninHakkoCd", mst172Form.getDtlNiukeninHakkoCd());
        }else{
            // 荷送人発行コード
            params.put("conNiokurininHakkoCd", mst172Form.getDtlNiokurininHakkoCd());
        }
 
        try {
            // DBをアクセス
            ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH);
            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> searchResult = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
            return searchResult;
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
    }
    
    /**
     * 更新チェック処理
     * 
     * @throws jp.co.kintetsuls.exception.SystemException
     */
    public void updatecheck() throws SystemException{
        // 新住所未反映の場合
        if(jushoComponentBean.getSearchResult().isEmpty()){
            if(null != mst172Form.getDtlShinJisCd()) {
                if("1".equals(mst172Form.getDtlKyuJushoFlg()) && "0".equals(mst172Form.getDtlShiyoFukaFlg())) {
                    // 旧住所設定確認の警告ダイアログを表示する。
                    pageCommonBean.executeScript("km.showConfirmDialog('mst172DialogShisetsu')");
                    return;
                    
                } else if("1".equals(mst172Form.getDtlKyuJushoFlg()) && "1".equals(mst172Form.getDtlShiyoFukaFlg())){
                    // 旧住所使用不可のエラーメッセージを表示し、処理を終了する。
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_WARN, MessageCnst.COME0023);
                    return;
                }
            }
            update();
        // 新住所反映完了の場合
        }else{
            Map<String, Object> res = jushoComponentBean.getSearchResult();
            if(null != res.get("shinJisCd")) {
                if("1".equals(res.get("kyuJushoFlg")) && "0".equals(res.get("shiyoFukaFlg"))) {
                    // 旧住所設定確認の警告ダイアログを表示する。
                    pageCommonBean.executeScript("km.showConfirmDialog('mst172DialogShisetsu')");
                    return;

                } else if("1".equals(res.get("kyuJushoFlg")) && "1".equals(res.get("shiyoFukaFlg"))){
                    // 旧住所使用不可のエラーメッセージを表示し、処理を終了する。
                    messagePropertyBean.message(MessagePropertyBean.SEVERITY_WARN, MessageCnst.COME0023);
                    return;
                }
            }
            // 新住所詳細を反映する
            mst172Form.setDtlJisCd((AutoCompOptionBean) res.get("jisCd"));
            mst172Form.setDtlJisCdRead(objectToString(res.get("jisCd")));
            if(res.get("jusho1") != null){
                mst172Form.setDtlNiukeninJusho1(objectToString(res.get("jusho1")));
                mst172Form.setDtlNiokurininJusho1(objectToString(res.get("jusho1")));
            }
            update();
        }
    }
 
    /**
     * 更新処理
     * 
     * @throws jp.co.kintetsuls.exception.SystemException
     */
    public void update() throws SystemException{
        // エラーメッセージを格納する変数の初期化を行う
        msgList = new ArrayList();
        
        //更新と登録チェックリストを設定する
        List<Map<String, Object>> allList = new ArrayList();
        Map<String, Object> record=new HashMap<>();
        
        // ログインユーザー所属営業所を設定する
        record.put("loginUserShozokuEigyosho", authorityConfBean.getLoginUserShozokuEigyosho());
        // 営業所コード
        record.put("dtlEigyoshoCd", mst172Form.getDtlEigyoshoCd());
        // JISコード
        record.put("JisCd", mst172Form.getDtlJisCd());
        // 荷送人コード
        record.put("NiokurininHakkoCd", mst172Form.getDtlNiokurininHakkoCd());
        // 荷受人コード
        record.put("NiukeninHakkoCd", mst172Form.getDtlNiukeninHakkoCd());
        // 顧客コード
        record.put("kokyakuCd", mst172Form.getDtlKokyakuCd());
        // 郵便番号
        record.put("yubinBango", mst172Form.getDtlYubinBango().replace("-", ""));
        // 荷受人/荷送人モード(1:荷受人モード/2:荷送人モード)
        record.put("conNiukeNiokurininMode", mst172Form.getConNiukeNiokurininMode());
        // 荷受人/荷送人モード(1:荷受人モード/2:荷送人モード)
        record.put("conSanshoHenshuShinkiMode", mst172Form.getConSanshoHenshuShinkiMode());
        // 荷受人更新カウンタ
        record.put("niukeninKoshinCounter", mst172Form.getNiukeninKoshinCounter());
        // 荷送人更新カウンタ
        record.put("niokurininKoshinCounter", mst172Form.getNiokurininKoshinCounter());
        // 荷受人更新ユーザーID
        record.put("niukeninKoushinUserCd",mst172Form.getNiukeninKoshinUserCd());
        // 荷受人更新ユーザーID
        record.put("niokurininKoushinUserCd",mst172Form.getNiokurininKoshinUserCd());
        allList.add(record);
        
        // 登録・更新データがある場合
        if (allList.size() > 0) {
            
            // 登録・更新チェック処理を行う
            int status = insertUpdateCheck(allList);

            // エラーの場合、処理終了
            if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
                return;
            }
        }
        // ＤＢへ登録・更新処理を行う
        insertUpdateNiukeninList();
        // 再検索を行う
        searchInfo();
    }     
            
    /**
     * 荷受人/荷送人自動採番処理
     * 
     */
    public void getHakkoCd(){
        // 荷受人モード自動採番
        if("1".equals(mst172Form.getConNiukeNiokurininMode())){
            if("".equals(mst172Form.getDtlNiukeninHakkoCd())){
                String hakkoCd1 = hakkoSaiban(mst172Form.getDtlKokyakuCd());
                // 荷受人発行コードを設定する
                mst172Form.setDtlNiukeninHakkoCd(hakkoCd1);
            }
        // 荷送人モード自動採番   
        }else{
            if("".equals(mst172Form.getDtlNiokurininHakkoCd())){
                String hakkoCd2 = hakkoSaiban(mst172Form.getDtlKokyakuCd());
                // 荷送人発行コードを設定する
                mst172Form.setDtlNiokurininHakkoCd(hakkoCd2);
            }
        }
    }
    
    /**
     * DBへ荷受人/荷送人マスタを登録また更新する処理
     * 
     */
    private void insertUpdateNiukeninList() {
        
        // beanはmapに変更
        Map tempMap = pageCommonBean.transBean2Map(mst172Form);
        tempMap.remove("resultNiokurininInfo");
        tempMap.remove("dtlEibunTorokuAri");
        tempMap.remove("searchResult");
        tempMap.remove("rirekiSearchKey");
        
        // jisコード
        tempMap.put("dtlJisCd", mst172Form.getDtlJisCd().getValue());
        // 仕向け地コード
        if(null !=mst172Form.getDtlShimukechiCd()){
            tempMap.put("dtlShimukechiCd", mst172Form.getDtlShimukechiCd().getValue());
        }
        // 営業所コード
        if(null !=mst172Form.getDtlShimukechiCd()){
            tempMap.put("dtlHaitatsuEigyoshoCd", mst172Form.getDtlHaitatsuEigyoshoCd().getValue());
        }
        // 記述1コード
        if(null !=mst172Form.getDtlKiji1Cd()){
            tempMap.put("dtlKiji1Cd", mst172Form.getDtlKiji1Cd().getValue());
        }
        // データバッジョン
        tempMap.put("niukeninDataVersion",mst172Form.getNiukeninDataVersion());
        // データバッジョン
        tempMap.put("niokurininDataVersion",mst172Form.getNiokurininDataVersion());
        // 記述2コード
        if(null !=mst172Form.getDtlKiji2Cd()){
            tempMap.put("dtlKiji2Cd", mst172Form.getDtlKiji2Cd().getValue());
        }
        // 記述3コード
        if(null !=mst172Form.getDtlKiji3Cd()){
            tempMap.put("dtlKiji3Cd", mst172Form.getDtlKiji3Cd().getValue());
         }
        // 記述4コード
        if(null !=mst172Form.getDtlKiji4Cd()){
            tempMap.put("dtlKiji4Cd", mst172Form.getDtlKiji4Cd().getValue());
         }
        // 記述5コード
        if(null !=mst172Form.getDtlKiji5Cd()){
            tempMap.put("dtlKiji5Cd", mst172Form.getDtlKiji5Cd().getValue());
        }
        
        //登録・更新を実施
        pageCommonBean.getDBInfo(tempMap, FUNC_CODE_INSERT_UPDATE);

        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, "更新");
    }
    
    
    /**
     * DBへ荷受人/荷送人マスタを登録また更新する時のチェック処理
     * 
     * @return チェック処理結果
     */
    private int insertUpdateCheck(List<Map<String, Object>> params) {
        
        // 重複、存在チェック
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(
                params, FUNC_CODE_INSERT_UPDATE_CHECK);
        
        // エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            messagePropertyBean.message(res.getMessages().get(0)[0],
                    res.getMessages().get(0)[1],
                    res.getMessages().get(0)[2],
                    res.getTableName());
            return res.getStatusCode();    
        }
        return 1;
    }
    
    /**
     * 画面用項目設定（荷受人/荷送人基本情報）
     *
     * @param result 検索結果
     */
    private void setSearchJoho(Map<String, Object> result) throws SystemException {
        
        if (result != null && result.size() > 0) {
            // 顧客コード
            mst172Form.setDtlKokyakuCd(objectToString(result.get("dtlKokyakuCd")));
            // 顧客名
            mst172Form.setDtlKokyakuMei(objectToString(result.get("dtlKokyakuMei")));
            // 営業所コード
            mst172Form.setDtlEigyoshoCd(objectToString(result.get("dtlEigyoshoCd")));
            // 営業所名称
            mst172Form.setDtlEigyoshoMei(objectToString(result.get("dtlEigyoshoMei")));
            // 荷受人発行コード
            mst172Form.setDtlNiukeninHakkoCd(objectToString(result.get("dtlNiukeninHakkoCd")));
            // 荷受人名称1
            mst172Form.setDtlNiukeninMei1(objectToString(result.get("dtlNiukeninMei1")));
            // 荷受人名称2
            mst172Form.setDtlNiukeninMei2(objectToString(result.get("dtlNiukeninMei2")));
            // 荷受人名称3
            mst172Form.setDtlNiukeninMei3(objectToString(result.get("dtlNiukeninMei3")));
            // 荷受人名称4
            mst172Form.setDtlNiukeninMei4(objectToString(result.get("dtlNiukeninMei4")));
            // 荷受人略称
            mst172Form.setDtlNiukeninRyaku(objectToString(result.get("dtlNiukeninRyaku")));
            // 荷受人カナ名称
            mst172Form.setDtlNiukeninKana(objectToString(result.get("dtlNiukeninKana")));
            // 荷送人発行コード
            mst172Form.setDtlNiokurininHakkoCd(objectToString(result.get("dtlNiokurininHakkoCd")));
            // 荷送人名称1
            mst172Form.setDtlNiokurininMei1(objectToString(result.get("dtlNiokurininMei1")));
            // 荷送人名称2
            mst172Form.setDtlNiokurininMei2(objectToString(result.get("dtlNiokurininMei2")));
            // 荷送人名称3
            mst172Form.setDtlNiokurininMei3(objectToString(result.get("dtlNiokurininMei3")));
            // 荷送人名称4
            mst172Form.setDtlNiokurininMei4(objectToString(result.get("dtlNiokurininMei4")));
            // 荷送人略称
            mst172Form.setDtlNiokurininRyaku(objectToString(result.get("dtlNiokurininRyaku")));
            // 荷送人カナ名称
            mst172Form.setDtlNiokurininKana(objectToString(result.get("dtlNiokurininKana")));
            // 荷受人名称(英文)1
            mst172Form.setDtlNiukeninEiMei1(objectToString(result.get("dtlNiukeninEiMei1")));
            // 荷受人名称(英文)2
            mst172Form.setDtlNiukeninEiMei2(objectToString(result.get("dtlNiukeninEiMei2")));
            // 荷受人名称(英文)3
            mst172Form.setDtlNiukeninEiMei3(objectToString(result.get("dtlNiukeninEiMei3")));
            // 荷受人名称(英文)4
            mst172Form.setDtlNiukeninEiMei4(objectToString(result.get("dtlNiukeninEiMei4")));
            // 荷受人略称(英文)
            mst172Form.setDtlNiukeninEiRyaku(objectToString(result.get("dtlNiukeninEiRyaku")));
            // 荷送人名称(英文)1
            mst172Form.setDtlNiokurininEiMei1(objectToString(result.get("dtlNiokurininEiMei1")));
            // 荷送人名称(英文)2
            mst172Form.setDtlNiokurininEiMei2(objectToString(result.get("dtlNiokurininEiMei2")));
            // 荷送人名称(英文)3
            mst172Form.setDtlNiokurininEiMei3(objectToString(result.get("dtlNiokurininEiMei3")));
            // 荷送人名称(英文)4
            mst172Form.setDtlNiokurininEiMei4(objectToString(result.get("dtlNiokurininEiMei4")));
            // 荷送人略称(英文)
            mst172Form.setDtlNiokurininEiRyaku(objectToString(result.get("dtlNiokurininEiRyaku")));
            // 旧住所
            mst172Form.setDtlKyuJushoFlg(objectToString(result.get("dtlKyuJusho")));
            // 使用不可
            mst172Form.setDtlShiyoFukaFlg(objectToString(result.get("dtlShiyoFuka")));
            // 新住所反映
            mst172Form.setDtlShinJushoHanei(objectToString(result.get("dtlShinJushoHanei")));
            // 新JISコード
            mst172Form.setDtlShinJisCd(objectToString(result.get("dtlShinJisCd")));
            // 郵便番号
            if(result.get("dtlYubinBango") != null && !"".equals(result.get("dtlYubinBango"))){
                StringBuilder yubin = new StringBuilder(objectToString(result.get("dtlYubinBango")));
                String YUBIN = "" + yubin.insert(3,"-");
                mst172Form.setDtlYubinBango(YUBIN);
            }  
            // JISコード
            if (result.get("dtlJisCd") != null) {
                mst172Form.setDtlJisCd(autoCompleteViewBean.initAddr("JIS_CD",
                        result.get("dtlJisCd").toString()));
            } else {
                // JISコードNULLの場合
                mst172Form.setDtlJisCd(autoCompleteViewBean.initAddr("JIS_CD",
                        null));
            }
            
            // JISコード
            mst172Form.setDtlJisCdRead(objectToString(result.get("dtlJisCd")));
            
            // 荷受人住所1
            mst172Form.setDtlNiukeninJusho1(objectToString(result.get("dtlNiukeninJusho1")));
            // 荷受人住所2
            mst172Form.setDtlNiukeninJusho2(objectToString(result.get("dtlNiukeninJusho2")));
            // 荷受人住所3
            mst172Form.setDtlNiukeninJusho3(objectToString(result.get("dtlNiukeninJusho3")));
            // 荷受人住所4
            mst172Form.setDtlNiukeninJusho4(objectToString(result.get("dtlNiukeninJusho4")));
            // 荷受人電話番号
            mst172Form.setDtlNiukeninTel(objectToString(result.get("dtlNiukeninTel")));
            // 荷送人住所1
            mst172Form.setDtlNiokurininJusho1(objectToString(result.get("dtlNiokurininJusho1")));
            // 荷送人住所2
            mst172Form.setDtlNiokurininJusho2(objectToString(result.get("dtlNiokurininJusho2")));
            // 荷送人住所3
            mst172Form.setDtlNiokurininJusho3(objectToString(result.get("dtlNiokurininJusho3")));
            // 荷送人住所4
            mst172Form.setDtlNiokurininJusho4(objectToString(result.get("dtlNiokurininJusho4")));
            // 荷送人電話番号
            mst172Form.setDtlNiokurininTel(objectToString(result.get("dtlNiokurininTel")));
            
            // 仕向地コード
            if (result.get("dtlShimukechiCd") != null) {
                mst172Form.setDtlShimukechiCd(autoCompleteViewBean.getComMsDatas(
                        MsCnst.COM_GET_SHIMUKE_CHI_CD, 
                        result.get("dtlShimukechiCd").toString()));
            } else {
                // 仕向地コードNULLの場合
                mst172Form.setDtlShimukechiCd(autoCompleteViewBean.getComMsDatas(
                        MsCnst.COM_GET_SHIMUKE_CHI_CD, 
                        StringUtils.EMPTY));
            }

            // 仕向地名
            mst172Form.setDtlShimukechiMei(objectToString(result.get("dtlShimukechiMei")));
            
            // 配達営業所
            if (result.get("dtlHaitatsuEigyoshoCd") != null) {
                mst172Form.setDtlHaitatsuEigyoshoCd(autoCompleteViewBean.getComMsDatas(
                        MsCnst.COM_GET_VW_EIGYOSHO, 
                        result.get("dtlHaitatsuEigyoshoCd").toString()));
            } else {
                // 配達営業所NULLの場合
                mst172Form.setDtlHaitatsuEigyoshoCd(autoCompleteViewBean.getComMsDatas(
                        MsCnst.COM_GET_VW_EIGYOSHO, 
                        StringUtils.EMPTY));
            }

            // 配達営業所名
            mst172Form.setDtlHaitatsuEigyoshoMei(objectToString(result.get("dtlHaitatsuEigyoshoMei")));
            // 荷受人住所(英文)1
            mst172Form.setDtlNiukeninEiJusho1(objectToString(result.get("dtlNiukeninEiJusho1")));
            // 荷受人住所(英文)2
            mst172Form.setDtlNiukeninEiJusho2(objectToString(result.get("dtlNiukeninEiJusho2")));
            // 荷受人住所(英文)3
            mst172Form.setDtlNiukeninEiJusho3(objectToString(result.get("dtlNiukeninEiJusho3")));
            // 荷受人住所(英文)4
            mst172Form.setDtlNiukeninEiJusho4(objectToString(result.get("dtlNiukeninEiJusho4")));
            // 荷送人住所(英文)1
            mst172Form.setDtlNiokurininEiJusho1(objectToString(result.get("dtlNiokurininEiJusho1")));
            // 荷送人住所(英文)2
            mst172Form.setDtlNiokurininEiJusho2(objectToString(result.get("dtlNiokurininEiJusho2")));
            // 荷送人住所(英文)3
            mst172Form.setDtlNiokurininEiJusho3(objectToString(result.get("dtlNiokurininEiJusho3")));
            // 荷送人住所(英文)4
            mst172Form.setDtlNiokurininEiJusho4(objectToString(result.get("dtlNiokurininEiJusho4")));
            // 検索キー
            mst172Form.setDtlKensakuKey(objectToString(result.get("dtlKensakuKey")));
            
            // 記事リストの取得パラメータを設定する
            Map params = new HashMap();
            params.put("eigyoshoCd", mst172Form.getDtlEigyoshoCd());
            params.put("kokyakuCd", mst172Form.getDtlKokyakuCd());
            // 記事1コード
            if (result.get("dtlKiji1Cd") != null) {
                mst172Form.setDtlKiji1Cd(autoCompleteViewBean.getMsDatasWithParam(
                        MsCnst.COM_GET_MS_KIJI, params,
                        result.get("dtlKiji1Cd").toString()));
            } else {
                // 記事1コードNULLの場合
                mst172Form.setDtlKiji1Cd(autoCompleteViewBean.getMsDatasWithParam(
                        MsCnst.COM_GET_MS_KIJI, params,
                        StringUtils.EMPTY));
            }
            // 記事1内容
            mst172Form.setDtlKiji1Naiyo(objectToString(result.get("dtlKiji1Naiyo")));
            
            // 記事2コード
            if (result.get("dtlKiji2Cd") != null) {
                mst172Form.setDtlKiji2Cd(autoCompleteViewBean.getMsDatasWithParam(
                        MsCnst.COM_GET_MS_KIJI, params,
                        result.get("dtlKiji2Cd").toString()));
            } else {
                // 記事2コードNULLの場合
                mst172Form.setDtlKiji2Cd(autoCompleteViewBean.getMsDatasWithParam(
                        MsCnst.COM_GET_MS_KIJI, params,
                        StringUtils.EMPTY));
            }

            // 記事2内容
            mst172Form.setDtlKiji2Naiyo(objectToString(result.get("dtlKiji2Naiyo")));
            
            // 記事3コード
            if (result.get("dtlKiji3Cd") != null) {
                mst172Form.setDtlKiji3Cd(autoCompleteViewBean.getMsDatasWithParam(
                        MsCnst.COM_GET_MS_KIJI, params,
                        result.get("dtlKiji3Cd").toString()));
            } else {
                // 記事3コードNULLの場合
                mst172Form.setDtlKiji3Cd(autoCompleteViewBean.getMsDatasWithParam(
                        MsCnst.COM_GET_MS_KIJI, params,
                        StringUtils.EMPTY));
            }
            
            // 記事3内容
            mst172Form.setDtlKiji3Naiyo(objectToString(result.get("dtlKiji3Naiyo")));
            
            // 記事4コード
            if (result.get("dtlKiji4Cd") != null) {
                mst172Form.setDtlKiji4Cd(autoCompleteViewBean.getMsDatasWithParam(
                        MsCnst.COM_GET_MS_KIJI, params,
                        result.get("dtlKiji4Cd").toString()));
            } else {
                // 記事4コードNULLの場合
                mst172Form.setDtlKiji4Cd(autoCompleteViewBean.getMsDatasWithParam(
                        MsCnst.COM_GET_MS_KIJI, params,
                        StringUtils.EMPTY));
            }

            // 記事4内容
            mst172Form.setDtlKiji4Naiyo(objectToString(result.get("dtlKiji4Naiyo")));
            
            // 記事5コード
            if (result.get("dtlKiji5Cd") != null) {
                mst172Form.setDtlKiji5Cd(autoCompleteViewBean.getMsDatasWithParam(
                        MsCnst.COM_GET_MS_KIJI, params,
                        result.get("dtlKiji5Cd").toString()));
            } else {
                // 記事5コードNULLの場合
                mst172Form.setDtlKiji5Cd(autoCompleteViewBean.getMsDatasWithParam(
                        MsCnst.COM_GET_MS_KIJI, params,
                        StringUtils.EMPTY));
            }

            // 記事5内容
            mst172Form.setDtlKiji5Naiyo(objectToString(result.get("dtlKiji5Naiyo")));
            // メモ
            mst172Form.setDtlMemo(objectToString(result.get("dtlMemo")));
            // 適用開始日
            mst172Form.setDtlTekiyoKaishibi(objectToString(result.get("dtlTekiyoKaishibi")));    
            // 最終使用日
            mst172Form.setDtlSaishuShiyobi(objectToString(result.get("dtlSaishuShiyobi")));
            // 荷受人更新カウンタ
            if(result.get("niukeninKoshinCounter") != null){
                mst172Form.setNiukeninKoshinCounter((int) result.get("niukeninKoshinCounter"));
            }
            // 荷送人更新カウンタ
            if(result.get("niokurininKoshinCounter") != null){
                mst172Form.setNiokurininKoshinCounter((int) result.get("niokurininKoshinCounter"));
            }
            // 荷受人更新ユーザーID
            mst172Form.setNiukeninKoshinUserCd(objectToString(result.get("niukeninKoshinUser")));
            // 荷送人更新ユーザーID
            mst172Form.setNiokurininKoshinUserCd(objectToString(result.get("niokurininKoshinUser")));
            // 荷受人マスタデータバージョン
            mst172Form.setNiukeninDataVersion(objectToString(result.get("niukeninDataVersion")));
            // 荷送人マスタデータバージョン
            mst172Form.setNiokurininDataVersion(objectToString(result.get("niokurininDataVersion")));

            // 履歴検索キーを設定する
            Map<String, Object> rirekiSearchKey = new HashMap();
            rirekiSearchKey.put("conKokyakuCd", mst172Form.getDtlKokyakuCd());
            rirekiSearchKey.put("conNiukeninHakkoCd", mst172Form.getDtlNiukeninHakkoCd());
            rirekiSearchKey.put("conNiokurininHakkoCd", mst172Form.getDtlNiokurininHakkoCd());
            rirekiSearchKey.put("conNiukeNiokurininMode", mst172Form.getConNiukeNiokurininMode());
            mst172Form.setRirekiSearchKey(rirekiSearchKey);
        }
    }

    /**
     * DBへ自動採番情報取得する
     * 
     * @return 自動採番処理結果
     */
    private String hakkoSaiban(String kokyakuCd) {
        
        // パラメータ設定
        Map<String, Object> params = new HashMap<>();

        // 顧客コード
        params.put("conKokyakuCd", kokyakuCd);
        // 荷受人/荷送人モード
        params.put("conNiukeNiokurininMode", mst172Form.getConNiukeNiokurininMode());

        try {
            // DBをアクセス
            ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, FUNC_CODE_SAIBAN);
            ObjectMapper mapper = new ObjectMapper();
            String searchResult = mapper.readValue(serviceInterfaceBean.getJson(), String.class);
            return searchResult;
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
    }
}
