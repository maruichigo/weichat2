/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.est;

import java.math.BigDecimal;
import java.util.List;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;
import jp.co.kintetsuls.beans.common.LabelValueBean;
import jp.co.kintetsuls.beans.est.EstimateColumnModel;
import jp.co.kintetsuls.beans.est.EstimatePackCityMunicipality;
import jp.co.kintetsuls.beans.est.EstimatePackCityPrefectures;
import jp.co.kintetsuls.beans.est.EstimatePackRank;
import lombok.Data;

/**
 * 見積り詳細画面パック料金 フォーム
 *
 * @author 作成者 (MBP)
 * @version 2019/1/29 新規作成
 */
@javax.faces.bean.ManagedBean(name = "est022PackForm")
@ViewScoped
@Data
public class Est022PackForm {

    //*****************パック料金設定部*************
    /**
     * 発地／着地（タイトル）
     */
    private String packHattiOrChakutiTitle;
    /**
     * 地図／一覧
     */
    private String packMapOrList;
    /**
     * 元払／着払／引取
     */
    private String packMotoChakuHikitoriKbn;
    
    /**
     * 都道府県一覧
     */
    private List<EstimatePackCityPrefectures> prefectures1;
    private List<EstimatePackCityPrefectures> selectedPrefectures1;
    private List<EstimatePackCityPrefectures> prefectures2;
    private List<EstimatePackCityPrefectures> selectedPrefectures2;
    private List<EstimatePackCityPrefectures> prefectures3;
    private List<EstimatePackCityPrefectures> selectedPrefectures3;
    
    /**
     * 市区町村
     */
    List<EstimatePackCityMunicipality> municipalities;
    List<EstimatePackCityMunicipality> selectedMunicipalities;
    
    /**
     * 運賃計算パターン
     */
    private String selectKeisanPtn;
    private List<SelectItem> packUnchinKeisanPtn;

    /**
     * 発地／着地域
     */
    private String selectChakuchiiki;
    private List<SelectItem> packHattiOrChakuchiiki;
    
    /**
     * 発着同じ住所
     */
    private boolean packHatsuChakuDoJusho;
    
    /**
     * 往復同一料金
     */
    private boolean packOfukuDoRyokin;
    
     /**
     * 料金
     */
    private List<List<BigDecimal>> prices;
    
     /**
     * 料金表ドラッグ＆ドロップモード
     */
    private boolean draggableColumns;
    
      /**
     * 運賃グリッド列
     */
   private List<EstimateColumnModel> columns;
    
    /**
     * 運賃ランク
     */
    private List<EstimatePackRank> ranks;

     /**
     * 運賃グリッド長さ
     */
    private int unchinWidth;
    
      /**
     * 入力列
     */
    private String inputRank;
 
}
