/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.bil;

import java.util.List;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.LabelValueBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.forms.common.LabelValueForm;
import lombok.Data;

/**
 * 月額自動請求マスタ(輸送売上)フォーム
 * 
 * @author Song Yuyang
 * @version 2019/1/28 新規作成
 */
@javax.faces.bean.ManagedBean(name = "bil021Form")
@ViewScoped
@Data
public class Bil021Form {
    
    /**
     * 営業所オプション
     */
    private AutoCompOptionBean conEigyoshoCd;
    
    /**
     * 顧客オプション
     */
    private AutoCompOptionBean conKokyakuCd;
    
    /**
     * 料金項目オプション
     */
    private AutoCompOptionBean conRyokinKomokuCd;
    
    /**
     * 適用名 
     */
    private String conTekiyoMei;
    
    /**
     * 世代検索条件
     */
    private List<String> conSedaiKensakuJoken;
    
    /**
     * 世代検索条件オプション
     */
    private List<SelectItem> conSedaiKensakuJokens;
    
    /**
     * 適用日
     */
    private String conTekiyoBi;
    
    /**
     * 削除済のみ
     */
    private boolean conSakujoSumiNomi;
    
    /**
     * 明細フラグ
     */
    private boolean meisaiFlg;
    
    /**
     * 明細フラグ
     */
    private boolean yusoFlg;
    
    /**
     * 明細フラグ
     */
    private boolean logiFlg;
    
    /**
     * 明細フラグ
     */
    private boolean sonohokaFlg;

    /**
     * 削除済のみリスト
     */
    private List<LabelValueForm> conSakujoSumiNomiLabelValueList;

    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;

    /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;

    /**
     * 選択された結果
     */
    private List<Map<String, String>> selectedSearchResult;
    
    /**
     * 適用日フラグ
     */
    private boolean tekiyobiShitei = false;

}
