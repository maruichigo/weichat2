/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.common;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author MaLei (MBP)
 */
@ManagedBean(name = "autoCompOptionBean")
@ViewScoped
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AutoCompOptionBean {

    private String label;
    private String value;

    private Boolean real = true;

    public AutoCompOptionBean(String label, String value) {
        this.label = label;
        this.value = value;

    }

    public String getLabelWithValue() {
        return (this.value + " " + this.label).trim();
    }

    public String substring(Long l) {
        return (this.value).trim();
    }
}
