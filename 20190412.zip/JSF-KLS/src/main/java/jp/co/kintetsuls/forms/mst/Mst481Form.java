/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mst;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.annotation.MaxSizeCheck;
import jp.co.kintetsuls.beans.common.annotation.NotNull;
import lombok.Data;

/**
 * K-INGコード変換マスタフォーム
 * 
 * @author 雷新然 (MBP)
 * @version 2019/2/12 新規作成
 */
@ManagedBean(name = "mst481Form")
@ViewScoped
@Data
public class Mst481Form implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    /**
     * 顧客コードAutoCompelete
     */
    @NotNull(name = "顧客コード")
    private AutoCompOptionBean conKokyakuCd;
    
    /**
     * 顧客コードDisabled
     */
    private boolean conKokyakuCdDisabled;
    
    /**
     * 顧客名称
     */
    private String conKokyakuMei;
    
    /**
     * 顧客名称Disabled
     */
    private boolean conKokyakuMeiDisabled;

    /**
     * 国内箇所区分
     */
    @MaxSizeCheck(maxSize = 3, name = "国内箇所区分")
    private String conKokunaiKashoKbn;
    
    /**
     * 国内箇所区分Disabled
     */
    private boolean conKokunaiKashoKbnDisabled;
    
    /**
     * 輸入箇所コード
     */
    @MaxSizeCheck(maxSize = 15, name = "輸入箇所コード")
    private String conYunyuKashoCd;
    
    /**
     * 輸入箇所コードDisabled
     */
    private boolean conYunyuKashoCdDisabled;
    
    /**
     * 輸入顧客コード
     */
    @MaxSizeCheck(maxSize = 15, name = "輸入顧客コード")
    private String conYunyuKokyakuCd;
    
    /**
     * 輸入顧客コードDisabled
     */
    private boolean conYunyuKokyakuCdDisabled;
    
    /**
     * 販売形態区分
     */
    private String conHambaiKeitaiKbn;
    
    /**
     * 販売形態区分Disabled
     */
    private boolean conHambaiKeitaiKbnDisabled;
    
    /**
     * 削除のみ検索
     */
    private String[] conSakujonomiKensaku;
             
    /**
     * 削除のみ検索Disabled
     */
    private boolean conSakujonomiKensakuDisabled;
    
    /**
     * 編集Disabled
     */
    private boolean btnHenshuDisabled;
    
    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;

    /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;    

    /**
     * 選択された結果
     */
    private List<Map<String, Object>> selectedSearchResult;
    
}
