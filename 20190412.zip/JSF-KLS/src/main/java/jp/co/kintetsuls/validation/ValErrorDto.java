package jp.co.kintetsuls.validation;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author hq
 * @date 2014-07-29
 */
@Data
@AllArgsConstructor
public class ValErrorDto {

    private String Message;
    private String target;

}
