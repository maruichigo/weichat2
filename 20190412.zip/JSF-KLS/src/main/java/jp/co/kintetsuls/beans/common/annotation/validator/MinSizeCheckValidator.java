/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common.annotation.validator;

import java.io.UnsupportedEncodingException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import jp.co.kintetsuls.beans.common.annotation.MinSizeCheck;

/**
 * 最小桁数チェック
 * 
 * @author zf(MBP)
 * @version 2019/3/11 新規作成
 */
public class MinSizeCheckValidator implements ConstraintValidator<MinSizeCheck, String> {

    private int min;

    @Override
    public void initialize(MinSizeCheck constraintAnnotation) {
        this.min = constraintAnnotation.minSize();
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        try {
            return !(value == null || value.getBytes("UTF-8").length < min);
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(MinSizeCheckValidator.class.getName()).log(Level.SEVERE, null, ex);
            return true;
        }
    }
}
