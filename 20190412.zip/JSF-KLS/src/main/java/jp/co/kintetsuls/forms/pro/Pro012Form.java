/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.pro;

import java.util.List;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.forms.common.LabelValueForm;
import lombok.Data;

/**
 * 売上入力訂正 フォーム
 *
 * @author 作成者 (MBP)
 * @version 2019/1/31 新規作成
 */
@javax.faces.bean.ManagedBean(name = "pro012Form")
@ViewScoped
@Data
public class Pro012Form {

    /**
     * 集荷日
     */
    private String k11;

    /**
     * 送り状No
     */
    private String k12;

    /**
     * 集荷トレース
     */
    private String k13;

    /**
     * 経理計上日
     */
    private String k14;

    /**
     * 伝票種別
     */
    private String k15;

    /**
     * 伝票種別名
     */
    private String k16;

    /**
     * 輸送方法
     */
    private String k17;

    /**
     * 輸送方法名
     */
    private String k18;

    /**
     * 元着区分
     */
    private String k19;

    /**
     * 元着区分名
     */
    private String k20;

    /**
     * 支払方法
     */
    private String k21;

    /**
     * 支払方法名
     */
    private String k22;

    /**
     * 引取輸送
     */
    private String k23;

    /**
     * 他社中継
     */
    private String k24;

    /**
     * 第三者払フラグ
     */
    private String k25;

    /**
     * 第三者払
     */
    private String k26;

    /**
     * 第三者顧客名
     */
    private String k27;

    /**
     * 第三者担当営業所
     */
    private String k28;

    /**
     * 請求先
     */
    private String k29;

    /**
     * 請求先顧客名
     */
    private String k30;

    /**
     * 請求先担当営業所
     */
    private String k31;

    /**
     * 契約先
     */
    private String k32;

    /**
     * 契約先顧客名
     */
    private String k33;

    /**
     * 契約先担当営業所
     */
    private String k34;

    /**
     * 着払請求先
     */
    private String k35;

    /**
     * 着払請求先顧客名
     */
    private String k36;

    /**
     * 着払請求先担当営業所
     */
    private String k37;

    /**
     * 個数
     */
    private String k38;

    /**
     * 重量
     */
    private String k39;

    /**
     * 容積重量
     */
    private String k40;

    /**
     * 特記事項
     */
    private String k41;

    /**
     * 備考欄
     */
    private String k42;

    /**
     * 請求金額
     */
    private String k43;

    /**
     * 配達営業所
     */
    private String k45;

    /**
     * 配達営業所名
     */
    private String k46;

    /**
     * 着空港
     */
    private String k47;

    /**
     * 着空港名
     */
    private String k48;

    /**
     * 配達指示
     */
    private String k49;

    /**
     * 配達指示名
     */
    private String k50;

    /**
     * 配達指定日
     */
    private String k51;

    /**
     * 経由空港
     */
    private String k52;

    /**
     * 経由空港名
     */
    private String k53;

    /**
     * 集荷営業所
     */
    private String k54;

    /**
     * 集荷営業所名
     */
    private String k55;

    /**
     * 発空港
     */
    private String k56;

    /**
     * 発空港名
     */
    private String k57;

    /**
     * 集荷指示
     */
    private String k58;

    /**
     * 集荷指示名
     */
    private String k59;

    /**
     * 保険
     */
    private String k60;

    /**
     * 保険名
     */
    private String k61;

    /**
     * 保険料
     */
    private String k62;

    /**
     * MAWB(小口)フラグ
     */
    private String k63;

    /**
     * 航空会社コード
     */
    private String k64;

    /**
     * 航空会社名称
     */
    private String k65;

    /**
     * MAWB番号
     */
    private String k66;

    /**
     * 他社送り状
     */
    private String k67;

    /**
     * 委託元名称
     */
    private String k68;

    /**
     * 他社送り状No
     */
    private String k69;

    /**
     * 荷受人電話番号
     */
    private String k70;

    /**
     * 配達地区
     */
    private String k71;

    /**
     * 郵便番号
     */
    private String k72;

    /**
     * JISコード
     */
    private String k73;

    /**
     * 荷受人住所1
     */
    private String k74;

    /**
     * 荷受人住所2
     */
    private String k75;

    /**
     * 荷受人住所3
     */
    private String k76;

    /**
     * 荷受人住所4
     */
    private String k77;

    /**
     * 荷受人名称1
     */
    private String k78;

    /**
     * 荷受人名称2
     */
    private String k79;

    /**
     * 荷受人名称3
     */
    private String k80;

    /**
     * 荷受人名称4
     */
    private String k81;

    /**
     * 仕向地コード
     */
    private String k82;

    /**
     * 仕向地名
     */
    private String k83;

    /**
     * 荷送人コード
     */
    private String k84;

    /**
     * 荷送人電話番号
     */
    private String k85;

    /**
     * 集荷地区
     */
    private String k86;

    /**
     * 郵便番号
     */
    private String k87;

    /**
     * JISコード
     */
    private String k88;

    /**
     * 荷送人住所1
     */
    private String k89;

    /**
     * 荷送人住所2
     */
    private String k90;

    /**
     * 荷送人住所3
     */
    private String k91;

    /**
     * 荷送人住所4
     */
    private String k92;

    /**
     * 荷送人名称1
     */
    private String k93;

    /**
     * 荷送人名称2
     */
    private String k94;

    /**
     * 荷送人名称3
     */
    private String k95;

    /**
     * 荷送人名称4
     */
    private String k96;

    /**
     * 品名
     */
    private String k97;

    /**
     * 記事1
     */
    private String k98;

    /**
     * 記事2
     */
    private String k99;

    /**
     * 記事3
     */
    private String k100;

    /**
     * 記事4
     */
    private String k101;

    /**
     * 記事5
     */
    private String k102;

    /**
     * 受領書
     */
    private String k103;

    /**
     * ステータス
     */
    private String k104;

    /**
     * エラー情報
     */
    private String k105;

    /**
     * 締日
     */
    private String k106;

    /**
     * 請求書No.
     */
    private String k107;

    /**
     * 請求書記載日
     */
    private String k108;

    /**
     * 入力営業所
     */
    private String k109;

    /**
     * 入力担当者
     */
    private String k110;

    /**
     * 入力日時
     */
    private String k111;

    /**
     * 更新営業所
     */
    private String k112;

    /**
     * 更新担当者
     */
    private String k113;

    /**
     * 更新日時
     */
    private String k114;

    /**
     * お客様管理№入力
     */
    private String k115;

    /**
     * 項番
     */
    private String k116;

    /**
     * 削除選択
     */
    private String k117;

    /**
     * お客様管理番号
     */
    private String k118;

    /**
     * 親選択
     */
    private String k119;

    /**
     * 運賃計算
     */
    private String k131;

    /**
     * パック運賃
     */
    private String k132;

    /**
     * 航空運賃
     */
    private String k133;

    /**
     * 集荷料
     */
    private String k134;

    /**
     * 取扱料
     */
    private String k135;

    /**
     * 配達料
     */
    private String k136;

    /**
     * 小計
     */
    private String k137;

    /**
     * 通信料
     */
    private String k138;

    /**
     * 発地その他
     */
    private String k139;

    /**
     * 着地その他
     */
    private String k140;

    /**
     * 着払手数料
     */
    private String k141;

    /**
     * 代引手数料
     */
    private String k142;

    /**
     * 明細合計
     */
    private String k143;

    /**
     * 直送チャーター料
     */
    private String k144;

    /**
     * 集荷チャーター料
     */
    private String k145;

    /**
     * 配達チャーター料
     */
    private String k146;

    /**
     * 消費税額
     */
    private String k147;

    /**
     * 保険料
     */
    private String k148;

    /**
     * 内税金額
     */
    private String k149;

    /**
     * 値引額
     */
    private String k150;

    /**
     * 運賃合計
     */
    private String k151;

    /**
     * 卸値計
     */
    private String k152;

    /**
     * 粗利益
     */
    private String k153;

    /**
     * 着払回収金額
     */
    private String k154;

    /**
     * 代引回収金額
     */
    private String k155;

    /**
     * 削除選択
     */
    private String k158;

    /**
     * 明細コード
     */
    private String k159;

    /**
     * 項目名
     */
    private String k160;

    /**
     * 表示名
     */
    private String k161;

    /**
     * 単価
     */
    private String k162;

    /**
     * 単位
     */
    private String k163;

    /**
     * 数量
     */
    private String k164;

    /**
     * 金額
     */
    private String k165;

    /**
     * 値引/割増
     */
    private String k166;

    /**
     * 小計
     */
    private String k167;

    /**
     * 卸値
     */
    private String k168;

    /**
     * 種別
     */
    private String k171;

    /**
     * 条件
     */
    private String k172;

    /**
     * 単価
     */
    private String k173;

    /**
     * 単位
     */
    private String k174;

    /**
     * 数量
     */
    private String k175;

    /**
     * 料金
     */
    private String k176;

    /**
     * 手入力料金
     */
    private String k177;

    /**
     * 卸値
     */
    private String k178;

    /**
     * 種別
     */
    private String k180;

    /**
     * 条件
     */
    private String k181;

    /**
     * 単価
     */
    private String k182;

    /**
     * 単位
     */
    private String k183;

    /**
     * 数量
     */
    private String k184;

    /**
     * 料金
     */
    private String k185;

    /**
     * 手入力料金
     */
    private String k186;

    /**
     * 卸値
     */
    private String k187;

    /**
     * 種別
     */
    private String k189;

    /**
     * 条件
     */
    private String k190;

    /**
     * 単価
     */
    private String k191;

    /**
     * 単位
     */
    private String k192;

    /**
     * 数量
     */
    private String k193;

    /**
     * 料金
     */
    private String k194;

    /**
     * 手入力料金
     */
    private String k195;

    /**
     * 卸値
     */
    private String k196;

    /**
     * 削
     */
    private String k198;

    /**
     * 仕入項目
     */
    private String k199;

    /**
     * 仕入先
     */
    private String k200;

    /**
     * 金額
     */
    private String k201;

    /**
     * 営業所
     */
    private String k202;

    /**
     * コメント
     */
    private String k203;

    /**
     * 分配先
     */
    private String k206;

    /**
     * 分配先名
     */
    private String k207;

    /**
     * 卸科目
     */
    private String k208;

    /**
     * 卸値
     */
    private String k209;
    
    /**
     * 画像
     */
    private List<String> images;
}