/*
 *Copyright (C) 2014 MBP Corporation All Rights Reserved . 
 */
package jp.co.kintetsuls.beans.common;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.utils.DateUtils;
import lombok.Data;

/**
 * 共通页面(自动补全)Controller
 *
 * @author hq
 */
@ViewScoped
@ManagedBean
@Data
public class Addr2AutoCompleteViewBean implements Serializable {

    @ManagedProperty(value = "#{autoComplete}")
    private AutoCompleteBean autoCompleteBean;

    protected List<AutoCompOptionBean> todofuken = new ArrayList<>();

    protected Map<String, List<AutoCompOptionBean>> jiss = new HashMap<>();
    
    protected Map<String, List<AutoCompOptionBean>> shimukechi = new HashMap<>();

    protected List<AutoCompOptionBean> originalOptions = new ArrayList<>();

    public List<AutoCompOptionBean> doubleComboJis(String query) {
        List<AutoCompOptionBean> filtered = null;
        int selection = 0;
        String trueQuery = query;
        if (query.matches("^\\{TODOFUKEN\\}.*")) {
            selection = 1;
            trueQuery = query.replaceFirst("^\\{TODOFUKEN\\}", "");
        }
        if (query.matches("^\\{SHIKUCHOSON\\}.*")) {
            selection = 2;
            trueQuery = query.replaceFirst("^\\{SHIKUCHOSON\\}", "");
        }
        if (query.matches("^\\{CONVERTER\\}.*")) {
            selection = 3;
            trueQuery = query.replaceFirst("^\\{CONVERTER\\}", "");
        }
        if (query.matches("^\\{SHIMUKECHI\\}.*")) {
            selection = 4;
            trueQuery = query.replaceFirst("^\\{SHIMUKECHI\\}", "");
        }

        if (selection == 3) {
            // コンバーター用
            filtered = filterDoubleComboJisConverter(trueQuery);
        } else if (trueQuery.matches("^[0-9]*$")) {
            // 入力値が数字のみの場合
            switch (trueQuery.length()) {
                case 0:
                    // 0桁の場合
                    if (selection == 0 || selection == 1) {
                        // キー入力 or 都道府県プルダウンの場合
                        // 都道府県でフィルタ
                        filtered = filterDoubleComboJisTodofuken(trueQuery);
                    }
                    break;
                case 1:
                    // 1桁の場合
                    if (selection == 0 || selection == 1) {
                        // キー入力 or 都道府県プルダウンの場合
                        // 都道府県でフィルタ
                        filtered = filterDoubleComboJisTodofuken(trueQuery);
                    }
                    break;
                case 2:
                    // 2桁の場合
                    if (selection == 1) {
                        // 都道府県プルダウンの場合
                        // 都道府県でフィルタ
                        filtered = filterDoubleComboJisTodofuken(trueQuery);
                    } else {
                        // キー入力 or 市区町村プルダウンの場合
                        // 市区町村でフィルタ
                        filtered = filterDoubleComboJisShikuchoson(trueQuery);
                    }
                    break;
                case 3:
                    // 3桁の場合
                    // 市区町村でフィルタ
                    filtered = filterDoubleComboJisShikuchoson(trueQuery);
                    break;
                case 4:
                    // 4桁の場合
                    // 市区町村でフィルタ
                    filtered = filterDoubleComboJisShikuchoson(trueQuery);
                    break;
                case 5:
                    // 5桁の場合
                    if (selection == 2) {
                        // 市区町村プルダウンの場合
                        // 市区町村でフィルタ
                        filtered = filterDoubleComboJisShikuchoson(trueQuery);
                    } else {
                        // 仕向地でフィルタ
                        filtered = filterDoubleComboShimukechi(trueQuery);
                    }
                    break;
                default:
                    // 6桁以上の場合
                    if (selection == 1) {
                        // 都道府県プルダウンの場合
                        filtered = filterDoubleComboJisTodofuken(trueQuery.substring(0, 2));
                    } else if (selection == 2) {
                        // キー入力 or 市区町村プルダウンの場合
                        // 市区町村でフィルタ
                        filtered = filterDoubleComboJisShikuchoson(trueQuery.substring(0, 5));
                    } else {
                        // 仕向地でフィルタ
                        filtered = filterDoubleComboShimukechi(trueQuery);
                    }
                    break;
            }
        } else {
            // 入力値に数字以外が含まれる場合
            filtered = new ArrayList<>();
//            for (AutoCompOptionBean option : options) {
//                String[] split = option.getLabel().split(":");
//                if (split[1].startsWith(trueQuery)) {
//                    filtered.add(option);
//                }
//            }
        }

        return filtered;
    }

    private List<AutoCompOptionBean> filterDoubleComboJisConverter(String query) {
        String key = query.substring(0, 2);

        List<AutoCompOptionBean> options = jiss.get(key);
//        String filter = query.length() > 2 ? query.substring(2, query.length()) : "";

        if (options == null) {
            Map<String, Object> param = new HashMap();
            param.put("SAKUJO_FLG", StndConsIF.CONST_ZERO_STRING);
            param.put("JIS_CD", key );
            options = autoCompleteBean.getValueLabelFromDB(MsCnst.COM_GET_VW_JIS_CD, param, null);
            jiss.put(key, options);
        }
        List<AutoCompOptionBean> filtered = new ArrayList<>();
        for (AutoCompOptionBean option : options) {
            if (option.getLabel().startsWith(query)) {
                filtered.add(option);
                break;
            }
        }
        return filtered;
    }

    private List<AutoCompOptionBean> filterDoubleComboJisTodofuken(String query) {
        List<AutoCompOptionBean> filtered = new ArrayList<>();
        if (todofuken.isEmpty()) {
            Map<String, Object> param = new HashMap();
            param.put("SAKUJO_FLG", StndConsIF.CONST_ZERO_STRING);
            todofuken = autoCompleteBean.getValueLabelFromDB(MsCnst.COM_GET_MS_TODOFUKEN, param, null);

        }
        for (AutoCompOptionBean option : todofuken) {
            if (option.getValue().startsWith(query) || option.getValue().startsWith(query)) {
                filtered.add(option);
                option.setReal(false);
            }
        }
        return filtered;
    }

    private List<AutoCompOptionBean> filterDoubleComboJisShikuchoson(String query) {
        String key = query.substring(0, 2);
        List<AutoCompOptionBean> options = jiss.get(key);
//        String filter = query.length() > 2 ? query.substring(2, query.length()) : "";
        if (options == null) {
            Map<String, Object> param = new HashMap();
            param.put("sysDate", DateUtils.format(DateUtils.getSysDate(), StndConsIF.DF_YYYY_MM_DD));
            options = autoCompleteBean.getValueLabelFromDB(MsCnst.COM_GET_VW_JIS_CD, param, null);
            jiss.put(key, options);
        }
        List<AutoCompOptionBean> filtered = new ArrayList<>();
        for (AutoCompOptionBean option : options) {
            if (option.getValue().startsWith(query)) {
                filtered.add(option);
            }
        }
        return filtered;
    }

    private List<AutoCompOptionBean> filterDoubleComboShimukechi(String query) {
        String key = query.substring(0, 5);
        List<AutoCompOptionBean> options = shimukechi.get(key);
        if (options == null) {
            Map<String, Object> param = new HashMap();
            param.put("sysDate", DateUtils.format(DateUtils.getSysDate(), StndConsIF.DF_YYYY_MM_DD));
            options = autoCompleteBean.getValueLabelFromDB(MsCnst.COM_GET_CHOAZA, param, null);
            shimukechi.put(key, options);
        }
        List<AutoCompOptionBean> filtered = new ArrayList<>();
        for (AutoCompOptionBean option : options) {
            if (option.getValue().startsWith(query)) {
                filtered.add(option);
            }
        }
        return filtered;
    }

}
