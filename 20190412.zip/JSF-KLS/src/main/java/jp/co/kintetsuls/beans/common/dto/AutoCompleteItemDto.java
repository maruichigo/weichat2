/*
 *   Copyright(c) 2015 KAIMA DATA
 */
package jp.co.kintetsuls.beans.common.dto;

import java.util.List;
import java.util.function.Function;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import lombok.Data;

/**
 * 自动补全控件用DTO
 *
 * @author
 * @date
 */
@Data
public class AutoCompleteItemDto {

    private Function<String, List<AutoCompOptionBean>> autoCompeteFun;

    public List<AutoCompOptionBean> autoComplete(String key) throws Exception {

        return autoCompeteFun.apply(key);
    }
}
