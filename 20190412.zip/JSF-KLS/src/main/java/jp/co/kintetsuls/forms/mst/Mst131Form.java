/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mst;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.annotation.DateCheck;
import lombok.Data;
import jp.co.kintetsuls.beans.common.annotation.ListNotEmpty;

/**
 * 仕入先マスタ一覧
 *
 * @author MBP劉 (MBP)
 * @version 2019/1/24 新規作成
 */
@ManagedBean(name = "mst131Form")
@ViewScoped
@Data
public class Mst131Form implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * ドンロド用リスト
     */
    private List<Map<String, Object>> downLoadList;

    /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;

    /**
     * 管轄区分
     */
    private List<String> conKankatsuKbn;

    /**
     * 管轄営業所コード
     */
    private String conSsShiiresakiMei;

    /**
     * 管轄営業所Disabled
     */
    private boolean conSsShiiresakiMeiDisabled;

    /**
     * SS仕入先コード
     */
    private String conSsShiiresakiCd;

    /**
     * 仕入先コード
     */
    private String conShiiresakiCd;

    /**
     * 会社名
     */
    private String conKaishaMei;

    /**
     * 支店/営業所名
     */
    private String conShitenEigyoshoMei;

    /**
     * 仕入先名
     */
    private String conShiiresakiMei;

    /**
     * 使用区分
     */
    private List<String> conShiyoKbn;

    /**
     * 世代検索条件
     */
    @ListNotEmpty(message = "{COME0011}", name = "世代検索条件")
    private List<String> conSedaiKensakuJoken;

    /**
     * 適用日
     */
    @DateCheck(name = "適用日")
    private String conTekiyoBi;

    /**
     * 削除済のみ
     */
    private List<String> conSakujoSumiNomi;

    /**
     * カナ名称
     */
    private String conKanaMeisho;

    /**
     * 申請状況
     */
    @ListNotEmpty(message = "{COME0011}", name = "申請状況")
    private List<String> conShinseiJokyo;

    /**
     * 都道府県コード
     */
    private String conTodofukenCd;

    /**
     * 住所
     */
    private String conJusho;

    /**
     * 未使用期間（年）
     */
    private int conMishiyoKikanNen;

    /**
     * 未使用期間（月）
     */
    private int conMishiyoKikanTsuki;

    /**
     * 管轄営業所
     */
    private AutoCompOptionBean kankatsuEigyosho;

    /**
     * 管轄営業所コード
     */
    private String listHEigyoshoCd;

    /**
     * 仕入先データバージョン
     */
    private String listHShiiresakiDataVersion;

    /**
     * 適用フラグ
     */
    private String listHTekiyoFlg;

    /**
     * 編集Disabled
     */
    private boolean btnEditeDisabled;

    /**
     * 選択された結果
     */
    private List<Map<String, Object>> selectedSearchResult;

    /**
     * 都道府県AutoComp
     */
    private AutoCompOptionBean conTodofuken;

    /**
     * 都道府県Disabled
     */
    private boolean conTodofukenDisabled;

    /**
     * 管轄区分Disabled
     */
    private boolean conKankatsuKbnDisabled;

    /**
     * 削除済のみDisabled
     */
    private boolean conSakujoSumiNomiDisabled;

    /**
     * 営業所Disabled
     */
    private boolean conEigyoshoDisabled;

    /**
     * SS仕入先コードDisabled
     */
    private boolean conSsShiiresakiCdDisabled;

    /**
     * 仕入先コードDisabled
     */
    private boolean conShiiresakiCdDisabled;

    /**
     * 会社名Disabled
     */
    private boolean conKaishaMeiDisabled;

    /**
     * 支店/営業所名Disabled
     */
    private boolean conShitenEigyoshoMeiDisabled;

    /**
     * 仕入先名Disabled
     */
    private boolean conShiiresakiMeiDisabled;

    /**
     * 使用区分Disabled
     */
    private boolean conShiyoKbnDisabled;

    /**
     * 世代検索条件Disabled
     */
    private boolean conSedaiKensakuJokenDisabled;

    /**
     * カナ名称Disabled
     */
    private boolean conKanaMeishoDisabled;

    /**
     * 申請状況Disabled
     */
    private boolean conShinseiJokyoDisabled;

    /**
     * 住所Disabled
     */
    private boolean conJushoDisabled;

    /**
     * 未使用期間（年）Disabled
     */
    private boolean conMishiyoKikanNenDisabled;

    /**
     * 未使用期間（月）Disabled
     */
    private boolean conMishiyoKikanTsukiDisabled;

    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;

}
