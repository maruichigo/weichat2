/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.forms.mst;

import java.util.List;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.annotation.MaxSizeCheck;
import jp.co.kintetsuls.beans.common.annotation.NotEmpty;
import jp.co.kintetsuls.beans.common.annotation.NotNull;
import lombok.Data;

/**
 * Mst363_月額自動請求マスタ(その他売上) フォーム
 *
 * @author 邱志遠
 * @version 2019/1/9 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst363Form")
@ViewScoped
@Data
public class Mst363Form {
    
    /**
     * 営業所コード
     */
    @NotNull(message = "{COME0003}", name = "営業所コード")
    private AutoCompOptionBean conEigyoshoCd;
    
    /**
     * 顧客コード
     */
    private AutoCompOptionBean conKokyakuCd;
            
    /**
     * 料金項目
     */
    private AutoCompOptionBean conRyokinKomoku;
                
    /**
     * 適用名
     */
    @MaxSizeCheck(maxSize = 40, name = "適用名")
    private String conTekiyoMei;
                    
    /**
     * 世代検索条件
     */
    @NotEmpty(message = "{COME0003}", name = "世代検索条件")
    private String[] conSedaiKensakuJoken;
    
    /**
     * 適用日
     */
    private String conTekiyoBi;
    
    /**
     * 削除済のみ
     */
    private String[] conSakujonomiKensaku;
    
    /**
     * 申請状況
     */
    private String[] conShinseiJokyo;
    
    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;

     /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;    

     /**
     * 選択された結果
     */
    private List<Map<String, Object>> selectedSearchResult;
    
    /**
     * 検索Visabled
     */
    private boolean btnSearchVisible;

    /**
     * 検索条件変更Visabled
     */
    private boolean btnSearchChangeVisible;
    
    /**
     * 検索条件Disabled
     */
    private boolean conSearchJokenDisabled;
    
    /**
     * 編集Disabled
     */
    private boolean btnEditeDisabled;
    
}
