/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.inv;

import jp.co.kintetsuls.beans.mst.*;
import jp.co.kintetsuls.beans.mst.*;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.util.FormatUtil;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.cnst.SysMsg;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.kintetsuls.service.general.property.ExternalServiceProperty;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 *
 * @author y_kamata
 */
@javax.faces.bean.ManagedBean(name = "inv023")
@ViewScoped
@Data
public class Inv023Bean extends BaseBean {
    
    private final String strTitle = "送り状発行パターン一覧";
    private String url;     // URL
    
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;
    
    private RestfullService rest;
    
    private static final Logger logger = LogManager.getLogger(new Object(){}.getClass().getEnclosingClass().getName());
    

    @Getter
    @Setter
    private String conEigyoshoCd;
    
    @Getter
    @Setter
    private String conShiiresakiCdAxis;
    

    /**
     * コンストラクタ
     */
    public Inv023Bean() {

    }
    
    /**
     * 初期処理（処理）
     * @param menuId
     * @param prevScreen
     * @param backFlag
     */      
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag){
        try {
            // パンくず追加
            breadBean.push("送り状発行パターン一覧画面", SCREEN.INV023_SCREEN.name(), this);
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }
    }
    
    /**
     * メニュークリック（処理）
     * @param menuId
     * @param nextScreen
     * @return 
     */    
    @Override
    public String menuClick(String menuId, String nextScreen){
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }

        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
    }
    
    /**
     * パンくずクリック（処理）
     * @return 
     */   
    @Override
    public String breadClumClick(String nextScreen, int breadIndex){
        
        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }        
        url = forward(nextScreen, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     * @return 
     */   
    @Override
    public String logoutClick(){
        return authConfBean.logout();
    }
    
    /**
     * 画面遷移処理（顧客マスタメンテナンス画面へ）
     * @return 
     * @throws java.lang.IllegalAccessException 
     * @throws java.lang.reflect.InvocationTargetException 
     */     
    public String buttonClick() throws IllegalAccessException, InvocationTargetException {
        
        // 画面遷移
        url = forward(SCREEN.CUS012_SCREEN.name(), null, SCREEN.CUS011_SCREEN.name(), false);
        return url;
    }   
    
    public List<String> completeText(String query) {
        List<String> tantoEigyosho = new ArrayList();
        
        tantoEigyosho.add("営業所００１");
        tantoEigyosho.add("営業所００２");
        tantoEigyosho.add("営業所００３");
        tantoEigyosho.add("営業所００４");
        tantoEigyosho.add("営業所００５");
        
        return tantoEigyosho;
    }
    
    /**
     * 検索条件クリア
     */
    public void clear(){
    }
    

    
}
