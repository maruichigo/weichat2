/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.lgn;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.DirContextBean;
import jp.co.kintetsuls.beans.common.KbnBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.beans.common.SystemMasterBean;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.forms.lgn.Lgn031Form;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.kintetsuls.utils.DateUtils;
import jp.co.kintetsuls.utils.StrUtils;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.commons.lang.BooleanUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * パスワード初期化
 *
 * @author 黄義輝 (MBP)
 * @version 2019/04/01 新規作成
 */
@javax.faces.bean.ManagedBean(name = "lgn031")
@ViewScoped
@Data
public class Lgn031Bean extends AbstractBean {

    /**
     * タイトル
     */
    private final String TITLE = "パスワード初期化";   

    /**
     * 画面URL
     */
    private String url;  

    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * システムマスタBean
     */
    @ManagedProperty(value = "#{systemMasterBean}")
    private SystemMasterBean systemMasterBean;

    /**
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authorityConfBean;

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;

    /**
     * 画面フォーム
     */
    @ManagedProperty(value = "#{lgn031Form}")
    private Lgn031Form lgn031Form;

    /**
     * 画面共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * 検索シーケンス処理共通
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;

    /**
     * 一覧単項目チェック共通
     */
    @ManagedProperty(value = "#{listCheckBean}")
    private ListCheckBean listCheckBean;

    /**
     * ADサーバ接続BEAN
     */
    @ManagedProperty(value = "#{dirContextBean}")
    private DirContextBean dirContextBean;

    /**
     * E2コード定義取得Bean
     */
    @ManagedProperty(value = "#{kbnBean}")
    private KbnBean kbnBean;
    
    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(
            new Object() {}.getClass().getEnclosingClass().getName());

    /**
     * スクリーンコード：LGN031
     */
    private static final String SC_CD_LGN031 = "LGN031_SCREEN";

    /**
     * 定数：承認者情報取得FUNC_CODE.
     */
    private static final String FUNC_CODE_SEARCH_SHONINSHAINFO = "lgn031-get-shoninshaInfo-detail";

    /**
     * 定数：申請チェックFUNC_CODE.
     */
    private static final String FUNC_CODE_DOAPPLY_CHECK = "lgn031-doapply-check";

    /**
     * 定数：申請FUNC_CODEC.
     */
    private static final String FUNC_CODE_DOAPPLY = "lgn031-doapply";

    /**
     * 定数：申請詳細処理完了FUNC_CODEC.
     */
    private static final String FUNC_CODE_DOAPPLY_SYORIZUMI = "lgn031-doapply-syoriZumi";

    /**
     * 定数：検索処理FUNC_CODE.
     */
    private static final String FUNC_CODE_SEARCH = "lgn031-get-detail";

    /**
     * 定数：本人連絡済処理FUNC_CODE.
     */
    private static final String FUNC_CODE_UPDATE_HONNINRENRAKUSUMI = "lgn031-update-honninrenrakuSumi";

    /**
     * 定数：登録処理FUNC_CODE.
     */
    private static final String FUNC_CODE_INSERT = "lgn031-insert";

    /**
     * 定数：承認処理FUNC_CODE.
     */
    private static final String FUNC_CODE_SHONIN = "lgn031-shonin";

    /**
     * 定数：差戻し処理FUNC_CODE.
     */
    private static final String FUNC_CODE_SASHIMODOSHI = "lgn031-sashimodoshi";

    /**
     * 定数：画面項目保持key.
     */
    private static final String CONST_LGN031_FORM = "lgn031Form";

    /**
     * ワーク.メッセージリスト
     */
    List<MessageModuleBean> msgList = null;

    /**
     * コンストラクタ
     */
    public Lgn031Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId メニューID
     * @param prevScreen 遷移元画面ID
     * @param backFlag 戻るフラグ
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {

            // パンくず追加
            breadBean.push(TITLE, SCREEN.LGN031_SCREEN.name(), this);
            
            // システムマスタ取得
            getSysInfo();

            // 承認者情報の取得
            getShoninshaInfo();

            // 戻ってきた場合
            Lgn031Form preForm = (Lgn031Form) pageCommonBean.getPageInfo(CONST_LGN031_FORM);
            if (backFlag && preForm != null) {

                PageCommonBean.simpleCopy(preForm, lgn031Form);
                // 再検索を実施する
                search();
                
            // 進んできた場合
            } else {

                // 前画面情報.menuId != null OR 前画面情報.prevScreen = Lgn011
                if (!CheckUtils.isEmpty(menuId) || Cnst.SCREEN.LGN011_SCREEN.name().equals(prevScreen)) {
                    // メニューからの遷移か、ログイン画面からの遷移の場合、モードを申請モードとする。
                    lgn031Form.setMode("1");

                // 前画面情報.prevScreen = Dem011
                } else if (Cnst.SCREEN.DEM011_SCREEN.name().equals(prevScreen)) {

                    Flash flash = pageCommonBean.getPageParam();
                    // 申請ID
                    String hyoDtlShinseiId = StrUtils.defaultString(flash.get("shinseiId"));
                    // 申請ステータス
                    // 01:未申請, 02:承認待ち, 03:一部承認待ち, 04:承認済, 05:差戻し
                    String hyoDtlShinseiStatus = StrUtils.defaultString(flash.get("shinseiStatus"));

                    // 申請ID取得を行う
                    lgn031Form.setHyoDtlShinseiId(hyoDtlShinseiId);

                    // 申請ステータス取得を行う
                    lgn031Form.setHyoDtlShinseiStatus(hyoDtlShinseiStatus);

                    // ログインユーザーが承認者の場合
                    if (lgn031Form.getShoninshaInfoList() != null && !lgn031Form.getShoninshaInfoList().isEmpty()) {

                        // 申請ステータスが"承認済"の場合
                        if (("04").equals(hyoDtlShinseiStatus)) {

                            // モードをパスワード発行後モードとする。
                            lgn031Form.setMode("3");

                            // 検索を実施する。
                            search();

                        // 申請ステータスが"承認済"以外の場合
                        } else {

                            // モードをパスワード発行後モードとする。
                            lgn031Form.setMode("2");

                            // 検索を実施する。
                            search();
                        }
                    // ログインユーザーが承認者ではない場合
                    } else {
                        // モードをパスワード発行後モードとする。
                        lgn031Form.setMode("1");
                    }
                }
            }

            // component初期化とユーザ権限により制御設定
            pageCommonBean.setAuthControll(lgn031Form, SC_CD_LGN031, true);

        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * 申請処理
     */
    public void doApply() {

        // 画面入力項目チェック処理
        if (checkJsfInputParamas() > 0) {
            return;
        }

        // パラメータマップ
        Map<String, Object> paramMap = new HashMap();

        // ワーク.ユーザーコード
        paramMap.put("hyoDtlUserCd", lgn031Form.getHyoDtlUserCd());
        // ワーク.メールアドレス
        paramMap.put("hyoDtlMailAddress", lgn031Form.getHyoDtlMailAddress());
        // ワーク.メール申請ロック期間
        paramMap.put("mailShinseiLockKikan", lgn031Form.getMailShinseiLockKikan());
        // ワーク.メールアドレス不一致最大回数
        paramMap.put("mailAddressFuitchiKaisu", lgn031Form.getMailAddressFuitchiKaisu());
        // ワーク.通知方法
        paramMap.put("hyoDtlTsuchiHoho", lgn031Form.getHyoDtlTsuchiHoho());
        // ワーク.電話番号
        paramMap.put("hyoDtlTelBango", lgn031Form.getHyoDtlTelBango());
        // ワーク.連絡先担当者名
        paramMap.put("hyoDtlRenrakusakiTantoshaMei", lgn031Form.getHyoDtlRenrakusakiTantoshaMei());
        // ワーク.申請理由
        paramMap.put("hyoDtlShinseiRiyu", lgn031Form.getHyoDtlShinseiRiyu());

        try {

            // 1.チェック処理
            ServiceInterfaceBean res = pageCommonBean.getDBInfo(paramMap, FUNC_CODE_DOAPPLY_CHECK);

            // エラーの場合、処理を終了
            if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
                messagePropertyBean.message(
                        res.getMessages().get(0)[0],
                        res.getMessages().get(0)[1],
                        res.getMessages().get(0)[2],
                        res.getTableName());
                return;
            }

            // ワーク.申請ID
            String shinseiId = "";

            // 2.申請処理
            ServiceInterfaceBean doapplyRes =  pageCommonBean.getDBInfo(paramMap, FUNC_CODE_DOAPPLY);
            ObjectMapper mapper = new ObjectMapper();
            Map doapplyResMap = mapper.readValue(doapplyRes.getJson(), Map.class);
            if (doapplyResMap != null) {

                // ワーク.申請ID設定
                shinseiId = StrUtils.objectToString(doapplyResMap.get("shinseiId"));
                
                paramMap.put("shinseiId", shinseiId);
            }
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 通知方法 = メールの場合
        if (("1").equals(lgn031Form.getHyoDtlTsuchiHoho())) {

            // 3.ワンタイムパスワード発行
            Map onetimePasswordHakkoMap = onetimePasswordHakko();
            msgList = new ArrayList();
            msgList = (List)onetimePasswordHakkoMap.get("msgList");

            if (!msgList.isEmpty()) {
                messagePropertyBean.messageList(msgList);
                return;
            }

            // 4.メール送信
            String onetimePassword = StrUtils.objectToString(onetimePasswordHakkoMap.get("onetimePassword"));
            String userCd = lgn031Form.getHyoDtlUserCd();
            String addressUrl = lgn031Form.getHyoDtlMailAddress();
            addressUrl = addressUrl + "?userCd=" + userCd + "&onetimePassword=" + onetimePassword;
            pageCommonBean.sendMailWithDataSpider(addressUrl, MessageCnst.LGNI0002, MessageCnst.LGNI0003);
            // 5.申請詳細登録(処理完了)
            pageCommonBean.getDBInfo(paramMap, FUNC_CODE_DOAPPLY_SYORIZUMI);
        }

        // 完了メッセージ表示
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.DEMI0001);

        // モードは申請モードとする。
        lgn031Form.setMode("1");
    }

    /**
     * 本人連絡済処理
     */
    public void honninrenrakuSumiSyori() {

        // パラメータマップ
        Map<String, Object> paramMap = new HashMap();
        // ワーク.ユーザーコード
        paramMap.put("hyoDtlUserCd", lgn031Form.getHyoDtlUserCd());
        // ワーク.申請ID
        paramMap.put("shinseiId", lgn031Form.getHyoDtlShinseiId());

        // 本人連絡済処理
        pageCommonBean.getDBInfo(paramMap, FUNC_CODE_UPDATE_HONNINRENRAKUSUMI);
        
        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.LGNI0004);

        // モードはパスワード発行後モードとする。
        lgn031Form.setMode("3");
        search();

    }

    /**
     * コメントチェック処理
     *
     * @param kbn イベント区分 1：登録ボタン、2：承認ボタン、3：差戻しボタン
     */
    public void commentCheckSyori(int kbn) {
        
        // 承認状況取得
        for (Map<String, String> syouninJyoukyouMap : lgn031Form.getSyouninJyoukyouList()) {
            if (("false").equals(StrUtils.objectToString(syouninJyoukyouMap.get("shinseiCommentDisabled")))) {
                // 送信データ取得
                lgn031Form.setSubmitDateMap(syouninJyoukyouMap);
                // コメント
                lgn031Form.setShnDtlListComment(syouninJyoukyouMap.get("shinseiComment"));
                break;
            }
        }

        switch (kbn) {
            case 1 :
                // 登録場合 コメント未入力チェック
                if (lgn031Form.getShnDtlListComment() == null || lgn031Form.getShnDtlListComment().isEmpty()) {

                    pageCommonBean.executeScript("km.showConfirmDialog('lgn031DialogInsertCommentCheck')");
                    return;
                }
                insertSyori();
                break;

            case 2:
                // 承認場合 コメント未入力チェック
                if (lgn031Form.getShnDtlListComment() == null || lgn031Form.getShnDtlListComment().isEmpty()) {

                    pageCommonBean.executeScript("km.showConfirmDialog('lgn031DialogShoninCommentCheck')");
                    return;
                }
                shoninSyori();
                break;

            default:
                // 差戻し場合 コメント未入力チェック
                if (lgn031Form.getShnDtlListComment() == null || lgn031Form.getShnDtlListComment().isEmpty()) {

                    pageCommonBean.executeScript("km.showConfirmDialog('lgn031DialogSashimodoshiCommentCheck')");
                    return;
                }
                sashimodoshiSyori();
                break;
        }
    }

    /**
     * 登録処理
     */
    public void insertSyori() {

        // パラメータマップ
        Map<String, Object> paramMap = new HashMap();
        // ワーク.申請ID
        paramMap.put("shinseiId", lgn031Form.getHyoDtlShinseiId());
        // ワーク.コメント
        paramMap.put("shnDtlListComment", lgn031Form.getShnDtlListComment());
        // ワーク.承認者情報
        paramMap.put("shoninshaInfoList", lgn031Form.getShoninshaInfoList());
        // 登録処理
        pageCommonBean.getDBInfo(paramMap, FUNC_CODE_INSERT);

        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.DEMI0004);

        // モードはパスワード発行モードとする。
        lgn031Form.setMode("2");
        // 再検索を実施する
        search();
    }

    /**
     * 承認処理
     */
    public void shoninSyori() { 

        msgList = new ArrayList();
        // 1.承認処理
        // パラメータマップ
        Map<String, Object> paramMap = new HashMap();
        // ワーク.申請ID
        paramMap.put("shinseiId", lgn031Form.getHyoDtlShinseiId());
        // ワーク.コメント
        paramMap.put("shnDtlListComment", lgn031Form.getShnDtlListComment());
        // ワーク.承認者情報
        paramMap.put("shoninshaInfoList", lgn031Form.getShoninshaInfoList());

        try {

            // 承認処理
            ServiceInterfaceBean res = pageCommonBean.getDBInfo(paramMap, FUNC_CODE_SHONIN);
            ObjectMapper mapper = new ObjectMapper();
            Map resMap = mapper.readValue(res.getJson(), Map.class);

            // 申請.申請ステータス
            String shinseiStatus = StrUtils.objectToString(resMap.get("shinseiStatus"));

            // 画面の再描画を行う。
            // 申請.申請ステータス = '04'(承認済)
            if (("04").equals(shinseiStatus)) {
                
                // 「ワンタイムパスワード発行」を行う
                Map onetimePasswordHakkoMap = onetimePasswordHakko();
                msgList = new ArrayList();
                msgList = (List)onetimePasswordHakkoMap.get("msgList");
                if (!msgList.isEmpty()) {
                    messagePropertyBean.messageList(msgList);
                    return;
                }
                // ワンタイムパスワード、及び連絡先担当者への連絡を促すメッセージの表示を行う。
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.LGNI0001);

                // 申請詳細登録(処理完了)
                pageCommonBean.getDBInfo(paramMap, FUNC_CODE_DOAPPLY_SYORIZUMI);

                // モードはパスワード発行後モードとする。
                lgn031Form.setMode("3");
            } else {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.DEMI0002);
                // モードはパスワード発行モードとする。
                lgn031Form.setMode("2");
            }
            // 再検索を実施する
            search();

        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * 差戻し処理
     */
    public void sashimodoshiSyori() { 
        
        msgList = new ArrayList();
        // 1.差戻し処理
        // パラメータマップ
        Map<String, Object> paramMap = new HashMap();
        // ワーク.申請ID
        paramMap.put("shinseiId", lgn031Form.getHyoDtlShinseiId());
        // ワーク.コメント
        paramMap.put("shnDtlListComment", lgn031Form.getShnDtlListComment());
        // ワーク.承認者情報
        paramMap.put("shoninshaInfoList", lgn031Form.getShoninshaInfoList());
        // 差戻し処理
        pageCommonBean.getDBInfo(paramMap, FUNC_CODE_SASHIMODOSHI);

        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.DEMI0003);

        // モードはパスワード発行モードとする。
        lgn031Form.setMode("2");
        search();

    }

    /**
     * ユーザーコードリンク処理
     *
     * @return 遷移先の画面URL
     */
    public String userClick() {

        Map<String, Object> param = new HashMap<>();

        // ユーザーコード
        param.put("hyoDtlUserCd", lgn031Form.getHyoDtlUserCd());
        // 適用開始日
        param.put("hyoDtlUserTekiyoKaishibi", lgn031Form.getHyoDtlUserTekiyoKaishibi());

        Flash flash = pageCommonBean.getPageParam();
        flash.put("param", param);

        // 画面遷移を行う
        url = forward(SCREEN.MST012_SCREEN.name(), null, SCREEN.LGN031_SCREEN.name(), false);
        return url;
    }

    /**
     * メニュークリック処理
     *
     * @param menuId メニューID
     * @param nextScreenId 遷移先画面ID
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreenId) {
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移を行う
        url = forward(nextScreenId, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック処理
     *
     * @param nextScreenId 遷移先画面ID
     * @param breadIndex パンくずのインデックス
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreenId, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        url = forward(nextScreenId, null, null, true);
        return url;
    }

    /**
     * ログアウトクリック処理
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authorityConfBean.logout();
    }

    /**
     * 再発行処理
     * 
     */
    public void saiHakko() {

        // ワンタイムパスワード発行
        Map resultMap = onetimePasswordHakko();
        msgList = (List)resultMap.get("msgList");
        if (!msgList.isEmpty()) {
            messagePropertyBean.messageList(msgList);
            return;
        }

        // ワンタイムパスワード、及び連絡先担当者への連絡を促すメッセージの表示を行う。
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.LGNI0001);

        // 画面の再描画を行う。 モードはパスワード発行後モードとする。
        lgn031Form.setMode("3");
        search();

    }

    /**
     * ワンタイムパスワード発行
     * 
     * @return ワンタイムパスワード
     */
    private Map onetimePasswordHakko() {

        // 1 パラメータ設定
        // エラーメッセージを格納する変数の初期化を行う。
        msgList = new ArrayList();

        // ワンタイムパスワード桁数を格納する変数の初期化を行う。
        int passwordLen = 8;

        // ワンタイムパスワードを格納する配列の初期化を行う。
        Character[] onetimePassword = new Character[8];
 
        // ワンタイムパスワード使用文字列変数を格納する配列の初期化を行う。
        String[] passwordString = new String[4];
        // ワーク.英小文字
        passwordString[0] = StndConsIF.RANDLOWER;
        // ワーク.英大文字
        passwordString[1] = StndConsIF.RANDUPPER;
        // ワーク.アラビア数字
        passwordString[2] = StndConsIF.RANDNUMBER;
        // ワーク.特殊文字
        passwordString[3] = StndConsIF.RANDSYMBOL;

        // ワンタイムパスワード使用文字列をすべて格納する変数の初期化を行う。
        String passwordStringAll = null;

        // パスワードの何文字目に設定を行っているか管理する変数の初期化を行う。
        int editLen = 0;
        
        // 文字列の入れ替え処理で使用する変数の初期化を行う。
        // ワーク.乱数1
        int randOne;
        // ワーク.乱数2
        int randTwo;
        // ワーク.退避
        Character stringTmp;
        
        // 2 ワンタイムパスワード発行
        try {
            // 乱数生成クラスである、SecureRandomクラスの宣言を行う。
            // 乱数生成アルゴリズムは、SHA1PRNGを使用する。
            SecureRandom sr = SecureRandom.getInstance("SHA1PRNG");

            // 下記の処理を、ワーク.パスワード使用文字.lengthの分繰り返す。
            for (int i = 0; i < passwordString.length; i++) {

                // ワーク.ワンタイムパスワード[ワーク.編集中桁数]に、パスワード使用文字から抽出した一文字を代入する。
                onetimePassword[editLen] = 
                        passwordString[i].charAt(sr.nextInt(passwordString[i].length()));

                // ワーク.全パスワード使用文字にワーク.パスワード使用文字[LOOP変数]を足しこむ。
                passwordStringAll += passwordString[i];

                // ワーク.編集中桁数の加算を行う。
                editLen++;
            }

            // 下記の処理を、ワーク.編集中桁数 < ワーク.パスワード桁数である間繰り返す。
            for (; editLen < passwordLen; editLen++) {

                // ワーク.ワンタイムパスワード[LOOP変数]に、ワーク.全パスワード使用文字から抽出した一文字を代入する。
                onetimePassword[editLen] = passwordStringAll.charAt(sr.nextInt(passwordStringAll.length()));
            }

            // 下記の処理を、10万回分繰り返す。
            for (int i = 0; i < 100000; i++) {

                // SecureRandomのnextIntメソッドを使用して乱数を生成する。引数はワーク.パスワード桁数とする。
                randOne = sr.nextInt(passwordLen);
                randTwo = sr.nextInt(passwordLen);

                // 生成した乱数を添え字として、ワーク.ワンタイムパスワードの文字列の入れ替えを行う。
                stringTmp = onetimePassword[randOne];
                onetimePassword[randOne] = onetimePassword[randTwo];
                onetimePassword[randTwo] = stringTmp;
            }

        } catch (NoSuchAlgorithmException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 3 ADサーバ登録
        // LDAPパスワード更新処理
        updatePassword(StrUtils.objectToString(onetimePassword), msgList);

        // 4 終了処理
        // 呼び出し元に以下のパラメータを返却する。
        // ワーク.ワンタイムパスワード
        Map<String, Object> resultMap = new HashMap();
        resultMap.put("onetimePassword", onetimePassword);
        resultMap.put("msgList", msgList);

        return resultMap;
    }

    /**
     * 検索処理
     */
    private void search() {

        try {
            // 承認者情報
            Map<String, Object> shoninshaInfo = null;
            if (lgn031Form.getShoninshaInfoList() != null && !lgn031Form.getShoninshaInfoList().isEmpty()) {
                shoninshaInfo = lgn031Form.getShoninshaInfoList().get(0);
            }
            
            // パラメータマップ
            Map<String, Object> paramMap = new HashMap();
            // ワーク.申請ID
            paramMap.put("shinseiId", lgn031Form.getHyoDtlShinseiId());
            // パスワード誤入力最大回数
            paramMap.put("passwordGoNyuryokuSaidaiKaisu", lgn031Form.getHyoDtlPasswordGoNyuryokuSaidaiKaisu());
            // ワーク.承認者情報
            paramMap.put("shoninshaInfo", shoninshaInfo);
            // ワーク.Axis処理
            paramMap.put("axisShori", kbnBean.getKbnMeiOfKeyCd(MsCnst.SHONIN_JOKYO_JIDO_JIKKO_AXIS_SHORI));
            // ワーク.自動実行
            paramMap.put("jidoJikko", kbnBean.getKbnMeiOfKeyCd(MsCnst.SHONIN_JOKYO_JIDO_JIKKO_JIDO_JIKKO));
            
            // 申請情報取得
            List<Map<String, String>> getShinseiInfoList;
            // 承認状況取得
             List<Map<String, String>> getSyouninJyoukyouList;

            // DBをアクセス
            ServiceInterfaceBean res = pageCommonBean.getDBInfo(paramMap, FUNC_CODE_SEARCH);
            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> resMap = mapper.readValue(res.getJson(), Map.class);

            if (resMap != null) {
                if (resMap.get("getShinseiInfoList") != null) {
                    // 申請情報取得
                    getShinseiInfoList = (List)resMap.get("getShinseiInfoList");
                    lgn031Form.setShinseiInfoList(getShinseiInfoList);
                    // 申請情報画面項目設定
                    shinseiInfoKamenSettei(getShinseiInfoList);
                }

                if (resMap.get("getSyouninJyoukyouList") != null) {
                    // 承認状況取得
                    getSyouninJyoukyouList = (List) resMap.get("getSyouninJyoukyouList");
                    lgn031Form.setSyouninJyoukyouList(getSyouninJyoukyouList);
                }
            }

            // ワンタイムパスワード取得 ワンタイムパスワードをADサーバから取得する。
            // ログインユーザーが最終承認者の場合、取得を行う。
            // ワーク.承認者情報.最終承認者フラグ取得
            String saishuShoninShaFlg = "";
            if (shoninshaInfo != null) {
                // 最終承認者フラグ
                saishuShoninShaFlg = StrUtils.objectToString(shoninshaInfo.get("saishuShoninShaFlg"));
            }

            // ワーク.承認者情報.最終承認者フラグ = 1
            if (("1").equals(saishuShoninShaFlg)) {
                
                // ワーク.ワンタイムパスワード表示内容
                String oneTimePasswordHyoujiNaiyou = "";

                // ADサーバより、申請者のパスワード情報を取得する。
                Map<String, String> shinseishaInfo = getShinseishaPassInfo();

                // ワーク.ワンタイムパスワード
                String oneTimePassword = StrUtils.defaultString(shinseishaInfo.get("oneTimePassword"));
                // ワーク.ワンタイムパスワードフラグ
                String oneTimePasswordFlag = StrUtils.defaultString(shinseishaInfo.get("oneTimePasswordFlag"));
                // ワーク.ワンタイムパスワード有効期限
                String passwordDeadLineStr = StrUtils.defaultString(shinseishaInfo.get("passwordDeadLine"));
                Date passwordDeadLine = null;
                if (!CheckUtils.isEmpty(passwordDeadLineStr)) {
                    passwordDeadLine = DateUtils.parse(passwordDeadLineStr, StndConsIF.DF_YYYY_MM_DD);
                }

                // ワーク.ワンタイムパスワードフラグ = 0の場合
                if (("0").equals(oneTimePasswordFlag)) {
                    oneTimePasswordHyoujiNaiyou = "パスワード変更済み";

                // ワーク.ワンタイムパスワード有効期限 < サーバ日付の場合
                } else if (passwordDeadLine != null && passwordDeadLine.compareTo(DateUtils.getSysDate()) < 0) {
                    oneTimePasswordHyoujiNaiyou = "期限切れ";

                // ワーク.ワンタイムパスワード有効期限 >= サーバ日付の場合
                }  else if (passwordDeadLine != null && passwordDeadLine.compareTo(DateUtils.getSysDate()) >= 0) {
                    oneTimePasswordHyoujiNaiyou = oneTimePassword + "(" + passwordDeadLine + "まで有効)";
                }
                
                // ワンタイムパスワード設定
                lgn031Form.setHyoDtlOnetimePassword(oneTimePasswordHyoujiNaiyou);
            }

        } catch (IOException | NamingException | SystemException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * LDAPパスワード更新処理
     * 
     * @param onetimePassword ワンタイムパスワード
     * @param msgList ワーク.メッセージリスト
     */
    private void updatePassword(String onetimePassword, List msgList) {

        // バインドユーザ
        String bindUser = messagePropertyBean.getProperties(StndConsIF.BIND_USER);
        // バインドユーザのパスワード
        String bindUserPassword = messagePropertyBean.getProperties(StndConsIF.BIND_USER_PASSWORD);

        try {

            // LDAP接続処理
            // TODO 外部残QA DEV_KLS-1076
            DirContext ctx = dirContextBean.initialDirContext(bindUser, bindUserPassword);

            // パスワードの暗号化を行う
            String password = onetimePassword;
            char unicodePwd[] = password.toCharArray();
            byte pwdArray[] = new byte[unicodePwd.length * 2];
            for (int i = 0; i < unicodePwd.length; i++) {
                pwdArray[i * 2 + 1] = (byte) (unicodePwd[i] >>> 8);
                pwdArray[i * 2 + 0] = (byte) (unicodePwd[i] & 0xff);
            }

            ModificationItem[] mods = new ModificationItem[3];
            // 暗号化したパスワードをModificationItemクラスの配列オブジェクトに代入する
            mods[0] = new ModificationItem(
                    DirContext.REPLACE_ATTRIBUTE, new BasicAttribute("unicodePwd", pwdArray));
            // ワンタイムパスワードフラグ TODO  外部残QA DEV_KLS-1076
            // ワンタイムパスワードフラグ = 1として更新する
            mods[1] = new ModificationItem(
                    DirContext.REPLACE_ATTRIBUTE, new BasicAttribute("userCertificate", "1"));
            // ワンタイムパスワード有効期限 TODO 外部残QA DEV_KLS-1076
            // ワンタイムパスワード有効期限 = ワーク.サーバ日付の1日後の日付
            String yukoKikan = DateUtils.format(
                    DateUtils.addDays(DateUtils.getSysDateFromApServer(), 1), StndConsIF.DF_YYYY_MM_DD);
            mods[2] = new ModificationItem(
                    DirContext.REPLACE_ATTRIBUTE, new BasicAttribute("userCert", yukoKikan));

            // ユーザーコード
            String userCd = lgn031Form.getHyoDtlUserCd();

            // 対象ユーザーのパスワード変更処理を行う
            
            //TODO 外部残QA DEV_KLS-1076
            ctx.modifyAttributes(userCd, mods);

            ctx.close();
        } catch (NamingException e) {
            // パスワードの更新に失敗した場合
            MessageModuleBean message = 
                    messagePropertyBean.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.LGNE0004);
            msgList.add(message);
        }
    }

    /**
     * 画面入力項目チェック処理
     * 
     * @param params 画面一覧パラメータ
     * @return チェックの結果
     */
    private int checkJsfInputParamas() {

        // エラーメッセージを格納する変数の初期化を行う
        msgList = new ArrayList();
        
        // メール、電話のどちらかが選択されているかチェックを行う。
        if (CheckUtils.isEmpty(lgn031Form.getHyoDtlTsuchiHoho())) {
            MessageModuleBean message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.LGNE0008);
            msgList.add(message);
        } else {
            // メールアドレス ワーク.通知方法 = 1(メール)の場合、入力必須チェック
            if (("1").equals(lgn031Form.getHyoDtlTsuchiHoho()) 
                    && (CheckUtils.isEmpty(lgn031Form.getHyoDtlMailAddress()))) {
                MessageModuleBean message = messagePropertyBean.createMessageModule(
                        MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "メールアドレス");
                msgList.add(message);
            }

            // 電話番号 ワーク.通知方法 = 2(電話)の場合、入力必須チェック
            if (("2").equals(lgn031Form.getHyoDtlTsuchiHoho())
                    && (CheckUtils.isEmpty(lgn031Form.getHyoDtlTelBango()))) {
                MessageModuleBean message = messagePropertyBean.createMessageModule(
                        MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "電話番号");
                msgList.add(message);
            }

            // 連絡先担当者名 ワーク.通知方法 = 2(電話)の場合、入力必須チェック
            if (("2").equals(lgn031Form.getHyoDtlTsuchiHoho()) 
                    && (CheckUtils.isEmpty(lgn031Form.getHyoDtlRenrakusakiTantoshaMei()))) {
                MessageModuleBean message = messagePropertyBean.createMessageModule(
                        MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, "連絡先担当者名");
                msgList.add(message);
            }
        }

        messagePropertyBean.messageList(msgList);
        return msgList.size();
    }

    /**
     * 申請情報画面項目設定
     * 
     * @param getShinseiInfoList 申請情報
     */
    private void shinseiInfoKamenSettei(List<Map<String, String>> getShinseiInfoList) {

        if (getShinseiInfoList != null && !getShinseiInfoList.isEmpty()) {

            // ユーザーコード
            lgn031Form.setHyoDtlUserCd(getShinseiInfoList.get(0).get("userCd"));
            // ユーザー名
            lgn031Form.setHyoDtlUserMei(getShinseiInfoList.get(0).get("userMei"));
            // ユーザー適用開始日
            lgn031Form.setHyoDtlUserTekiyoKaishibi(getShinseiInfoList.get(0).get("tekiyoKaishibi"));
            // 通知方法
            lgn031Form.setHyoDtlTsuchiHoho(getShinseiInfoList.get(0).get("tsuchiHoho"));
            // 電話番号
            lgn031Form.setHyoDtlTelBango(getShinseiInfoList.get(0).get("telBango"));
            // 連絡先担当者名
            lgn031Form.setHyoDtlRenrakusakiTantoshaMei(getShinseiInfoList.get(0).get("renrakusaki"));
            // メールアドレス
            lgn031Form.setHyoDtlMailAddress(getShinseiInfoList.get(0).get("mailAddress"));
            // 申請理由
            lgn031Form.setHyoDtlShinseiRiyu(getShinseiInfoList.get(0).get("shinseiRiyu"));
            // 所属営業所
            lgn031Form.setHyoDtlShozokuEigyosho(getShinseiInfoList.get(0).get("eigyoshoMei"));
            // 権限ロール
            lgn031Form.setHyoDtlKengenRole(getShinseiInfoList.get(0).get("roleMei"));
            // 申請回数
            if (!CheckUtils.isEmpty(getShinseiInfoList.get(0).get("shinseiKaisu"))) {
                lgn031Form.setHyoDtlShinseiKaisuu(getShinseiInfoList.get(0).get("shinseiKaisu") + "回目");
            }
            // パスワード誤入力回数
            lgn031Form.setHyoDtlPasswordGoNyuryokuKaisuu(getShinseiInfoList.get(0).get("passwordGoNyuryokuKaisu"));
            // 本人連絡
            lgn031Form.setHyoDtlHonninrenraku(getShinseiInfoList.get(0).get("honninRenraku"));
            // パスワード変更
            lgn031Form.setHyoDtlPasswordHenko(getShinseiInfoList.get(0).get("passwordHenko")); 
        }
    }
    
    /**
     * システムマスタ取得
     */
    private void getSysInfo() {

        // ワーク.メール申請ロック期間
        lgn031Form.setMailShinseiLockKikan(
                systemMasterBean.getSysValByCdAndKanriGroup(
                        MsCnst.SYS_CD_MAIL_APP_LOCK_DATE,
                        MsCnst.SYS_CDGROUP_LGN031,
                        MsCnst.SYS_CDGROUP_SYSTEM));

        // システムマスタからパスワード誤入力最大回数取得
        lgn031Form.setHyoDtlPasswordGoNyuryokuSaidaiKaisu(
                Integer.valueOf(systemMasterBean.getSysValByCdAndKanriGroup(
                        MsCnst.SYS_CD_PASSWORD_ERROR_MAX_KAISU,
                        MsCnst.SYS_CDGROUP_LGN031, MsCnst.SYS_CDGROUP_SYSTEM)));

        // ワーク.メールアドレス不一致最大回数
        lgn031Form.setMailAddressFuitchiKaisu(
                Integer.valueOf(systemMasterBean.getSysValByCdAndKanriGroup(
                            MsCnst.SYS_CD_MAILADDRESS_FUITCHI_MAX_KAISU,
                            MsCnst.SYS_CDGROUP_LGN031,
                            MsCnst.SYS_CDGROUP_SYSTEM)));
    }

    /**
     * 承認者情報の取得
     */
    private void getShoninshaInfo() {
        try {
            // DBをアクセス
            ServiceInterfaceBean res = pageCommonBean.getDBInfo(new HashMap(), FUNC_CODE_SEARCH_SHONINSHAINFO);
            ObjectMapper mapper = new ObjectMapper();
            lgn031Form.setShoninshaInfoList(mapper.readValue(res.getJson(), List.class));
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * ADサーバより、申請者のパスワード情報を取得する
     * 
     * @return 申請者のパスワード情報
     * @throws NamingException
     */
    private Map<String, String> getShinseishaPassInfo() throws NamingException {
        
        // 返却情報MAP
        Map<String, String> resultMap = new HashMap();
        // バインドユーザ
        String bindUser = messagePropertyBean.getProperties(StndConsIF.BIND_USER);
        // バインドユーザのパスワード
        String bindUserPassword = messagePropertyBean.getProperties(StndConsIF.BIND_USER_PASSWORD);
        
        // 接続用コンテキストを作成する
        DirContext ctx = dirContextBean.initialDirContext(bindUser, bindUserPassword);
       
        // 検索範囲指定用オブジェクトの初期化を行う
        SearchControls searchControls = new SearchControls();
        searchControls.setSearchScope(SearchControls.ONELEVEL_SCOPE);
        // 検索を実行する
        NamingEnumeration<SearchResult> result = ctx.search(
                bindUser, "CN=" + lgn031Form.getHyoDtlUserCd(), searchControls);

        // 検索結果を取得する
        while (result.hasMore()) {
            SearchResult sr = result.next();
            NamingEnumeration attributes = sr.getAttributes().getAll();

            while (attributes.hasMore()) {
                Attribute attr = (Attribute) attributes.nextElement();
                Enumeration values = attr.getAll();
                // 属性を1件ずつ取得して処理
                while (values.hasMoreElements()) {
                    // userCertificateを取得する
                    if("userCertificate".equals(attr.getID())) {
                        // ワンタイムパスワードフラグ
                        resultMap.put("oneTimePasswordFlag", values.nextElement().toString());
                    } else if("userCert".equals(attr.getID())) {
                        // ワンタイムパスワード有効期限
                        resultMap.put("passwordDeadLine",values.nextElement().toString());
                    } else if("userParameters".equals(attr.getID())) {
                        // ワンタイムパスワード
                        resultMap.put("oneTimePassword", values.nextElement().toString());
                    } else {
                        values.nextElement();
                    }
                }
            }
        }
        ctx.close();
        return resultMap;
    }
}
