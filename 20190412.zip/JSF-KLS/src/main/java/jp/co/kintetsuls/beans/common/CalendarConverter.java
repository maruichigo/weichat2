/*
 * CalendarConverter.java 
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common;

import java.util.Date;
import javax.faces.bean.ViewScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import org.primefaces.component.calendar.Calendar;

/**
 * Calendar コンポーネントで使用するPOJOを変換するためのクラス
 * @author MaLei
 */
@FacesConverter("calendarConverter")
@ViewScoped
public class CalendarConverter implements Converter {

    /**
     * リストから選択された時に呼び出されるメソッド。
     * 通常は入力された value からサービス呼出等でPOJOを取得するが、
     * @param context facesContext
     * @param component AutoComplete
     * @param value 入力値
     * @return selected object
     */
    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        Calendar uiobj = (Calendar)component;
        return value;
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {

        if (value instanceof String) {
            return String.valueOf(value);
        }

        if (value != null) {
            return ((Date)value).toString();
        } else {
            return null;
        }
    }
}
