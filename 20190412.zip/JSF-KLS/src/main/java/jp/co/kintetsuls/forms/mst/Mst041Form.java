/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mst;

import java.util.List;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.annotation.DateCheck;
import jp.co.kintetsuls.beans.common.annotation.MaxSizeCheck;
import jp.co.kintetsuls.beans.common.annotation.NotEmpty;
import jp.co.kintetsuls.beans.common.annotation.NotNull;
import lombok.Data;

/**
 * 営業所マスタフォーム
 * 
 * @author 雷新然 (MBP)
 * @version 2019/2/18 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst041Form")
@ViewScoped
@Data
public class Mst041Form {
    
    /**
     * 営業所コードAutoCompelete
     */
    @NotNull(name = "営業所")
    private AutoCompOptionBean conEigyoshoCd;
    
    /**
     * 営業所コードDisabled
     */
    private boolean conEigyoshoCdDisabled;
    
    /**
     * 営業所名
     */
    private String conEigyoshoMei;
    
    /**
     * 営業所名Disabled
     */
    private boolean conEigyoshoMeiDisabled;
    
    /**
     * 世代検索条件
     */
    @NotEmpty(name = "世代検索条件")
    private String[] conSedaiKensakuJoken;
    
    /**
     * 世代検索条件Disabled
     */
    private boolean conSedaiKensakuJokenDisabled;
    
    /**
     * 適用日
     */
    @DateCheck(name = "適用日")
    @NotNull(message = "{COME0028}", checkTime = "適用日指定", name = "適用日")
    private String conTekiyoBi;
    
    /**
     * 適用日Disabled
     */
    private boolean conTekiyoBiDisabled;

    /**
     * 削除済のみ
     */
    private List<String> conSakujoSumiNomi;
    
    /**
     * 削除済のみDisabled
     */
    private boolean conSakujoSumiNomiDisabled;
    
    /**
     * 使用区分
     */
    private String[] conShiyoKbn;
    
    /**
     * 使用区分Disabled
     */
    private boolean conShiyoKbnDisabled;
    
    /**
     * 仕向地コードAutoCompelete
     */
    private AutoCompOptionBean conShimukeChiCd;
    
    /**
     * 仕向地コードDisabled
     */
    private boolean conShimukeChiCdDisabled;
    
    /**
     * 仕向地名
     */
    private String conShimukeChiMei;
    
    /**
     * 仕向地名Disabled
     */
    private boolean conShimukeChiMeiDisabled;
    
    /**
     * 適用名
     */
    @MaxSizeCheck(maxSize = 40, name = "適用名")
    private String conTekiyoMei;
    
    /**
     * 適用名Disabled
     */
    private boolean conTekiyoMeiDisabled;
    
    /**
     * 住所
     */
    private String conJusho;
    
    /**
     * 住所Disabled
     */
    private boolean conJushoDisabled;

    /**
     * 検索条件変更Visabled
     */
    private boolean btnKensakuChangeVisible;
    
    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;

     /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;    

     /**
     * 選択された結果
     */
    private List<Map<String, Object>> selectedSearchResult;
    
    /**
     * リンクされた結果
     */
    private Map<String, Object> linkSearchResult;
    
}
