/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common.annotation.validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import jp.co.kintetsuls.beans.common.annotation.UpperCheck;

/**
 * A_Zチェック
 * 
 * @author liuchengjiang (MBP)
 * @version 2019/3/7 新規作成
 */
public class UpperCheckValidator implements ConstraintValidator<UpperCheck, String> { 

    @Override
    public void initialize(UpperCheck constraintAnnotation) {
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        Pattern pattern = Pattern.compile("[A-Z]*");
           Matcher isChar = pattern.matcher(value);
           if( !isChar.matches() ){
               return false;
           }
           return true;
    }
    
}
