/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.forms.edi.edi011;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 *
 * @author xubo
 */
@Data
public class Edi011Document implements Serializable, Comparable<Edi011Document> {

    /**
     * 顧客名/EDI名/ファイル名
     */
    private String listKokyakuMei;
    
    /**
     * 外部システム名/外部システムIF名
     */
    private String listSysName;
    
    /**
     * バッチ名
     */
    private String listBatch;
    
    /**
     * 機能名/アップロードファイル種別
     */
    private String listKinoMei;

    /**
     * 実行結果
     */
    private String listJikkouKekka;
    /**
     * 実行回数
     */
    private String listJikkouKaisuu;
    /**
     * 処理件数
     */
    private String listShoriKensuu;
    /**
     * OK件数
     */
    private String listOkKensuu;
    /**
     * 要修正件数
     */
    private String listShuuseiKensu;
    /**
     * NG件数
     */
    private String listNgKennsu;
    /**
     * スキップ件数
     */
    private String listSkipKennsu;
    /**
     * 代表顧客
     */
    private String listKokyakuDaihyo;
    /**
     * 代表営業所
     */
    private String listEigyoshoDaihyo;
    /**
     * 複数営業所
     */
    private String listFukusuuEigyosho;
    
    /**
     * 顧客コード
     */
    private String listKokyakuCd;
    /**
     * 実行開始日時
     */
    private String listStartDay;
    /**
     * 実行終了日時
     */
    private String listEndDay;
    /**
     * 実行結果配信先
     */
    private String listJikkouKekkaHaishinSaki;
    /**
     * ログ有無
     */
    private String listIfLog;

    public Edi011Document(String listKokyakuMei, String listSysName, String listBatch, String listKinoMei, String listJikkouKekka, String listJikkouKaisuu, String listShoriKensuu, String listOkKensuu, String listShuuseiKensu, String listNgKennsu, String listSkipKennsu, String listKokyakuDaihyo, String listEigyoshoDaihyo, String listFukusuuEigyosho, String listKokyakuCd, String listStartDay, String listEndDay, String listJikkouKekkaHaishinSaki, String listIfLog) {
        this.listKokyakuMei = listKokyakuMei;
        this.listSysName = listSysName;
        this.listBatch = listBatch;
        this.listKinoMei = listKinoMei;
        this.listJikkouKekka = listJikkouKekka;
        this.listJikkouKaisuu = listJikkouKaisuu;
        this.listShoriKensuu = listShoriKensuu;
        this.listOkKensuu = listOkKensuu;
        this.listShuuseiKensu = listShuuseiKensu;
        this.listNgKennsu = listNgKennsu;
        this.listSkipKennsu = listSkipKennsu;
        this.listKokyakuDaihyo = listKokyakuDaihyo;
        this.listEigyoshoDaihyo = listEigyoshoDaihyo;
        this.listFukusuuEigyosho = listFukusuuEigyosho;
        this.listKokyakuCd = listKokyakuCd;
        this.listStartDay = listStartDay;
        this.listEndDay = listEndDay;
        this.listJikkouKekkaHaishinSaki = listJikkouKekkaHaishinSaki;
        this.listIfLog = listIfLog;
    }

    
    
    public Edi011Document(String listKokyakuMei, String listJikkouKekka, String listJikkouKaisuu, String listShoriKensuu, String listOkKensuu, String listShuuseiKensu, String listNgKennsu, String listSkipKennsu, String listKokyakuDaihyo, String listEigyoshoDaihyo, String listFukusuuEigyosho, String listStartDay, String listEndDay, String listJikkouKekkaHaishinSaki, String listIfLog) {
        this.listKokyakuMei = listKokyakuMei;
        
        this.listJikkouKekka = listJikkouKekka;
        this.listJikkouKaisuu = listJikkouKaisuu;
        this.listShoriKensuu = listShoriKensuu;
        this.listOkKensuu = listOkKensuu;
        this.listShuuseiKensu = listShuuseiKensu;
        this.listNgKennsu = listNgKennsu;
        this.listSkipKennsu = listSkipKennsu;
        this.listKokyakuDaihyo = listKokyakuDaihyo;
        this.listEigyoshoDaihyo = listEigyoshoDaihyo;
        this.listFukusuuEigyosho = listFukusuuEigyosho;
        this.listStartDay = listStartDay;
        this.listEndDay = listEndDay;
        this.listJikkouKekkaHaishinSaki = listJikkouKekkaHaishinSaki;
        this.listIfLog = listIfLog;
    }
    
    

    @Override
    public int compareTo(Edi011Document o) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
