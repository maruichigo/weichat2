/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.cus;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.primefaces.context.RequestContext;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortMeta;
import org.primefaces.model.SortOrder;

/**
 *
 * @author y_kamata
 */
public class LazyCus011DataModel extends LazyDataModel<Cus011Def> implements Serializable {
   
    private List<Cus011Def> datasource;
    private boolean firstLoad;
    private List<Cus011Def> selectedList;
    private boolean cachingRowData;
    private Map<String,Object> filters;
    private int first;
    private List<SortMeta> multiSortMeta;
    private int pageSize;
    private transient Map<Integer, List<Cus011Def>> rowDataCache;
    private int count = 0;
    
    // フィルタ対象項目
    private final String columnList[] =
    {
         "kokyakuCd"            // 顧客コード
        ,"kokyakuMei"           // 顧客名
        ,"kokyakuKanaMeisho"    // 顧客カナ名称
        ,"jusho"                // 住所
        ,"telBango1"            // 電話番号１
    };
    
    public LazyCus011DataModel(List<Cus011Def> datas) {
        super();
        
        // IDを設定
        for (int i = 0; i<datas.size();i++){
            Cus011Def data = datas.get(i);
            data.setId(Integer.toString(i));
            data.setActionFlg("0");
            data.setErrFlg("0");
            data.setCheckFlg("0");
        }
        datasource = datas;
        firstLoad = true;
        selectedList = new ArrayList<>();
        count = datasource.size();

    }

    @Override
    public Cus011Def getRowData(String rowKey) {
        // 選択イベントが発生した場合、p:dataTable属性のrowKeyからユニークキーが送信されるので、
        // datasourceから該当するデータを返却する
        for (Cus011Def data : getDatasource()){
            if (rowKey.equals(data.getId())){
               selectedList.add(data);
                return data; 
            }        
        }
        return null;
    }
    
    @Override
    public Object getRowKey(Cus011Def cus) {
        return cus.getId();
    }

    // シングルソート
    @Override
    public List<Cus011Def> load(int first, int pageSize, String sortField, SortOrder sortOrder, Map<String,Object> filters) {
       List<Cus011Def> data = new ArrayList<>();

        //filter //保持データを繰り返し
        for(Cus011Def cus : getDatasource()) {
            boolean match = true;
            
            //filterのidがclassのidに一致する場合、match=trueとしてdata追加
            if (!filters.isEmpty()) {
                Object gFilter = filters.get("globalFilter");
                if (gFilter != null && gFilter.toString().length() != 0) {
                    //グローバルフィルタ用
                    match = false;
                    try {
                        Object filterValue = gFilter;
                        for (String column : columnList) {
                            String filterProperty = column;
                            String fieldValue = String.valueOf(cus.getClass().getField(filterProperty).get(cus));
                            if (fieldValue.contains(filterValue.toString())) {
                                match = true;
                                break;
                            }
                        }
                    } catch (Exception e) {
                        match = false;
                    }
                } else {
                    //通常フィルタ用
                    for (Iterator<String> it = filters.keySet().iterator(); it.hasNext();) {
                        try {
                            String filterProperty = it.next();
                            if(!"globalFilter".equals(filterProperty)) {
                                Object filterValue = filters.get(filterProperty);
                                String fieldValue = String.valueOf(cus.getClass().getField(filterProperty).get(cus));

                                if (filterValue == null || fieldValue.contains(filterValue.toString())) {
                                    match = true;
                                } else {
                                    match = false;
                                    break;
                                }   
                            }
                        } catch (Exception e) {
                            match = false;
                        }
                    }
                }
            }

            if(match) { //一致するもの
                data.add(cus);
            }
        }

        //sort
        if(sortField != null) {
            Collections.sort(data, new LazyCus011Sorter(sortField, sortOrder));
        }

        //rowCount //件数を設定
        int dataSize = data.size();
        this.setRowCount(dataSize);
        this.setWrappedData(data);

        //paginate　200 > 10の場合
        if(dataSize > pageSize) {
            try {
                return data.subList(first, first + pageSize);
            }
            catch(IndexOutOfBoundsException e) {
                return data.subList(first, first + (dataSize % pageSize));
            }
        }
        else {
            return data;
        }
    }  
    
    // マルチソート
    @Override
    public  List<Cus011Def> load(int first, int pageSize, List<SortMeta> multiSortMeta, Map<String, Object> filters){
       List<Cus011Def> data = new ArrayList<>();

        if (getDatasource() == null) return data;

        if (firstLoad) {
            this.preload(first, pageSize, multiSortMeta, filters);
            firstLoad = false;
        }

        //filter //保持データを繰り返し
        for (Cus011Def cus : getDatasource()) {
            boolean match = true;

            //filterのidがclassのidに一致する場合、match=trueとしてdata追加
            if (filters != null) {
                Object gFilter = filters.get("globalFilter");
                if (gFilter != null && gFilter.toString().length() != 0) {
                    //グローバルフィルタ用
                    match = false;
                    try {
                        Object filterValue = gFilter;
                        for (String column : columnList) {
                            String filterProperty = column;
                            String fieldValue = String.valueOf(cus.getClass().getField(filterProperty).get(cus));
                            if (fieldValue.contains(filterValue.toString())) {
                                match = true;
                                break;
                            }
                        }
                    } catch (Exception e) {
                        match = false;
                    }
                    
                    if (match){
                        for (Iterator<String> it = filters.keySet().iterator(); it.hasNext();) {
                            try {
                                String filterProperty = it.next();
                                if ("globalFilter".equals(filterProperty)) { //グローバルの場合は対象外
                                    continue;
                                }
                                Object filterValue = filters.get(filterProperty);
                                String fieldValue = String.valueOf(filters.get(filterProperty));

                                if (filterValue == null || fieldValue.contains(filterValue.toString())) {
                                    match = true;
                                } else {
                                    match = false;
                                    break;
                                }
                            } catch (Exception e) {
                                match = false;
                            }
                        }
                    }

                } else {
                    //通常フィルタ用
                    for (Iterator<String> it = filters.keySet().iterator(); it.hasNext();) {
                        try {
                            String filterProperty = it.next();
                            if(!"globalFilter".equals(filterProperty)) {
                                Object filterValue = filters.get(filterProperty);
                                String fieldValue = String.valueOf(cus.getClass().getField(filterProperty).get(cus));

                                if (filterValue == null || fieldValue.contains(filterValue.toString())) {
                                    match = true;
                                } else {
                                    match = false;
                                    break;
                                }   
                            }
                        } catch (Exception e) {
                            match = false;
                        }
                    }
                }
            }

            if (match) {
                data.add(cus);
            }
        }

        //sort
        if (multiSortMeta != null){
            if (multiSortMeta.get(0).getSortField() != null && multiSortMeta.get(0).getSortOrder() != null) {
                Collections.sort(data, new LazyCus011Sorter(multiSortMeta.get(0).getSortField(), multiSortMeta.get(0).getSortOrder()));
            }
        }

        //rowCount //件数を設定
        int dataSize = data.size();
        setRowCount(dataSize);
        setWrappedData(data);
        RequestContext.getCurrentInstance().execute("setHiddentablecount('"+dataSize+"');");
        
        //paginate
        if (dataSize > pageSize) {
            try {
                return data.subList(first, first + pageSize);
            } catch (IndexOutOfBoundsException e) {
                return data.subList(first, first + (dataSize % pageSize));
            }
        } else {
            return data;
        }
    }
                     
    /**
     * Initializes the Row Data Cache and stores the Load Values that will
     * be used when loading the Row Data Cache
     *
     * @param first the Row Index of the First Row to load the in the DataModel
     * @param pageSize the DataModel Page / Scroll Size
     * @param multiSortMeta the MultiSortMeta that is to be applied to the DataModel
     * @param filters the Filters that are to be applied to the DataModel
     */
    public void preload(int first, int pageSize, List<SortMeta> multiSortMeta, Map<String,Object> filters){
        // Remember Load Values for Reloading Row Data Cache
        if(!isCachingRowData()){
            this.first = first;
            this.pageSize = pageSize;
            this.multiSortMeta = multiSortMeta;
            this.filters = filters;
        }

        // Create the Row Data Cache once for the first load.
        if(!isCachingRowData() && first == 0){
            createRowDataCache();
        }
    }

    /**
    * Returns whether the DataModel is "re"loading data using one of the
    * load() methods for the purpose of Caching Row Data in order to properly
    * process child components
    *
    * @return true if caching row data; false otherwise
    */
   private boolean isCachingRowData(){
       return cachingRowData;
   }
   
   /**
    * Creates a new Row Data Cache up to [N] Rows at a time; N being the
    * Page / Scroll Size defined when the DataModel is loaded.
    */
   private void createRowDataCache(){
       this.rowDataCache = new LinkedHashMap<Integer, List<Cus011Def>>(getPageSize()){
           @Override
           protected boolean removeEldestEntry(Map.Entry<Integer, List<Cus011Def>> eldest){
               return size() > getPageSize();
           }
       };   
   }

    /**
     * @return the datasource
     */
    public List<Cus011Def> getDatasource() {
        return datasource;
    }

    /**
     * @param datasource the datasource to set
     */
    public void setDatasource(List<Cus011Def> datasource) {
        this.datasource = datasource;
    }

    /**
     * @return the count
     */
    public int getCount() {
        return count;
    }

    /**
     * @param count the count to set
     */
    public void setCount(int count) {
        this.count = count;
    }
}
