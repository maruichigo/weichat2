package jp.co.kintetsuls.exception;

import java.util.ArrayList;
import java.util.List;
import jp.co.kintetsuls.validation.ValErrorDto;
import lombok.Data;

/**
 * バリデーションエラー例外.
 *
 * @author tdm
 */
@Data
public class ValidateException extends ApplicationException {

    private List<ValErrorDto> errorList = new ArrayList<>();

    /**
     * ValidateException を構築します。
     */
    public ValidateException() {
        super();
    }

    /**
     * 指定された詳細メッセージを示す ValidateException を構築します。
     *
     * @param _message 詳細メッセージ
     */
    public ValidateException(String _message) {
        super(_message);
    }

    /**
     * 指定された原因を持つ ValidateException を構築します。
     *
     * @param _throwable 原因
     */
    public ValidateException(Throwable _throwable) {
        super(_throwable);
    }

    /**
     * 指定された詳細メッセージと原因を持つ ValidateException を構築します.
     *
     * @param _message 詳細メッセージ
     * @param _throwable 原因
     */
    public ValidateException(String _message, Throwable _throwable) {
        super(_message, _throwable);
    }

    /**
     * 指定された詳細メッセージを示す ValidateException を構築します。
     *
     * @param _message 詳細メッセージ
     * @param _errorMessages エラーメッセージ情報
     */
    public ValidateException(String _message, List<ValErrorDto> _errorMessages) {
        super(_message);
        setErrorList(_errorMessages);
    }

    /**
     * 指定された詳細メッセージと原因を持つ ValidateException を構築します。
     *
     * @param _message 詳細メッセージ
     * @param _errorMessages エラーメッセージ情報
     * @param _throwable 原因
     */
    public ValidateException(String _message, List<ValErrorDto> _errorMessages, Throwable _throwable) {
        super(_message, _throwable);
        setErrorList(_errorMessages);
    }
}
