/*
 *Copyright (C) 2014 MBP Corporation All Rights Reserved . 
 */
package jp.co.kintetsuls.beans.common;

import java.io.Serializable;
import java.util.Properties;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.service.general.property.ExternalServiceProperty;

/**
 * ADサーバ接続BEAN
 * 
 * @author 曾鳳(MBP)
 * @version 2019/3/15 新規作成
 */
@ManagedBean(name = "dirContextBean")
@ViewScoped
public class DirContextBean implements Serializable {
    
    /**
     * ADサーバ接続
     * 
     * @param userCd ユーザーコード（"CN=...,DC=..."のような形式）
     * @param password パスワード
     * @return DirContext
     * @throws NamingException
     */
    public DirContext initialDirContext(String userCd, String password) throws NamingException {
        
        // ADサーバのアドレス
        String adServerAddress = ExternalServiceProperty.getInstance().getProperty(StndConsIF.AD_SERVER_ADDRESS);
        // ポート番号
        String adServerPort = ExternalServiceProperty.getInstance().getProperty(StndConsIF.AD_SERVER_PORT);
        // ユーザーコード に対応したdn
        String dn = ExternalServiceProperty.getInstance().getProperty(StndConsIF.DN);

        Properties env = new Properties();
        env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        env.put(Context.PROVIDER_URL, "ldap://" + adServerAddress + ":" + adServerPort);
        env.put(Context.SECURITY_AUTHENTICATION, "simple");
        env.put(Context.SECURITY_PRINCIPAL, userCd);
        env.put(Context.SECURITY_CREDENTIALS, password);
        env.put(Context.SECURITY_PROTOCOL, "ssl");
        
        return new InitialDirContext(env);
    }
}
