/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common.annotation.validator;

import java.util.List;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import jp.co.kintetsuls.beans.common.annotation.ListNotEmpty;

/**
 * Checkboxの必須選択チェック
 * 
 * @author zf (MBP)
 * @version 2019/3/7 新規作成
 */
public class ListNotEmptyValidator implements ConstraintValidator<ListNotEmpty, List<String>> { 

    @Override
    public void initialize(ListNotEmpty constraintAnnotation) {
    }

    @Override
    public boolean isValid(List<String> value, ConstraintValidatorContext context) {
        return !(value == null || value.size() == 0);
    }
    
}
