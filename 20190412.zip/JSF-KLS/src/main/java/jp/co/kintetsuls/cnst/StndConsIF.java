/*
 * Copyright (C) 2014 MBP Corporation All Rights Reserved .
 */
package jp.co.kintetsuls.cnst;

/**
 * 基盤定数.
 *
 * @author COMM
 */
public interface StndConsIF {

    /**
     * カナ文字の記号
     * <ul>
     * <li>(:0x0028</li>
     * <li>):0x0029</li>
     * <li>-(ハイフン):0x002D</li>
     * <li>.(ピリオド):0x002E</li>
     * <li>スペース:0x0020</li>
     * </ul>
     */
    char[] KANA_KIGOU = {0x0028, 0x0029, 0x002D, 0x002E, 0x0020};
    /**
     * 日付フォーマットパターン：YYYYMMDD（年月日）
     */
    static final String DF_YYYYMMDD = "yyyyMMdd";
    /**
     * 共通.日付フォーマットパターン：YYMMDD（年月日）
     */
    static final String DF_YYMMDD = "yyMMdd";

    /**
     * 日付フォーマットパターン：YYYYMM（年月）
     */
    static final String DF_YYYYMM = "yyyyMM";
    /**
     * 共通.日付フォーマットパターン：YYMM（年月）
     */
    static final String DF_YYMM = "yyMM";
    /**
     * 日付フォーマットパターン：YYYY/MM/DD（年/月/日）
     */
    static final String DF_YYYY_MM_DD = "yyyy/MM/dd";
    /**
     * 日付フォーマットパターン：MM/DD（月/日）
     */
    static final String DF_MM_DD = "MM/dd";
    /**
     * 日付フォーマットパターン：YYYY（年）
     */
    static final String DF_YYYY = "yyyy";
    /**
     * 日付フォーマットパターン：MM（月）
     */
    static final String DF_MM = "MM";
    /**
     * 日付フォーマットパターン：M（月）
     */
    static final String HIZUKE_FORMAT_PTN_M_MONTH = "M";
    /**
     * 日付フォーマットパターン：H（時）
     */
    static final String HIZUKE_FORMAT_PTN_H_HOUR = "H";
    /**
     * 日付フォーマットパターン：m（分）
     */
    static final String HIZUKE_FORMAT_PTN_M_MINUTE = "m";
    /**
     * 日付フォーマットパターン：DD（日）
     */
    static final String DF_DD = "dd";
    /**
     * 日付フォーマットパターン：a（AM/PM）
     */
    static final String DF_AM_PM = "a";
    /**
     * 日付フォーマットパターン：yyyy/MM/dd|HH:mm:ss（年/月/日|時:分:秒）
     */
    static final String DF_YYYY_MM_DD_HH_MM_SS_VERTICAL_BAR = "yyyy/MM/dd|HH:mm:ss";
    /**
     * 日付フォーマットパターン：yyyy/MM/dd|HH:mm:ss.SSS（年/月/日|時:分:秒.ミリ秒）
     */
    static final String DF_YYYY_MM_DD_HH_MM_SS_SSS_VERTICAL_BAR = "yyyy/MM/dd|HH:mm:ss.SSS";
    /**
     * 日付フォーマットパターン：yyyyMMddHHmmss（年月日時分秒）
     */
    static final String DF_YYYYMMDDHHMMSS = "yyyyMMddHHmmss";
    /**
     * 日付フォーマットパターン：yyyyMMddHHmmssSSS（年月日時分秒ミリ秒）
     */
    static final String DF_YYYYMMDDHHMMSSSSS = "yyyyMMddHHmmssSSS";
    /**
     * 日付フォーマットパターン：yyyy/MM/dd HH:mm（年/月/日 時:分）
     */
    static final String DF_YYYY_MM_DD_HH_MM = "yyyy/MM/dd HH:mm";
    /**
     * 日付フォーマットパターン：yyyy/MM/dd HH:mm:ss（年/月/日 時:分:秒）
     */
    static final String DF_YYYY_MM_DD_HH_MM_SS = "yyyy/MM/dd HH:mm:ss";
    /**
     * 日付フォーマットパターン：yyyy/MM/dd HH:mm:ss.SSS（年/月/日 時:分:秒.ミリ秒）
     */
    static final String DF_YYYY_MM_DD_HH_MM_SS_SSS = "yyyy/MM/dd HH:mm:ss.SSS";
    /**
     * 日付フォーマットパターン：yyyy/MM（年/月）
     */
    static final String DF_YYYY_MM = "yyyy/MM";
    /**
     * 日付フォーマットパターン：ログファイル生成用日付書式
     */
    static final String DF_LOG_FILE = "yyyyMMdd_HHmmss_SSS";
    /**
     * 日付フォーマットパターン：yyyy-MM-dd HH:mm
     */
    static final String DF_YYYYMMDD_HHMM = "yyyy-MM-dd HH:mm";
    /**
     * 日付フォーマットパターン：yyyy-MM-dd HH:mm:ss
     */
    static final String DF_YYYYMMDD_HHMMSS = "yyyyMMdd_HHmmss_SSS";
    /**
     * 日付フォーマットパターン：MM/dd HH:mm（月/日 時:分）
     */
    static final String DF_MM_DD_HH_MM = "MM/dd HH:mm";
    /**
     * 日付フォーマットパターン：yyyy年MM月dd日
     */
    static final String DF_YYYY_YEAR_MM_MONTH_DD_DATE = "yyyy年MM月dd日";
    /**
     * 日付フォーマットパターン：yyyy年MM月dd日 mm:ss
     */
    static final String DF_YYYY_YEAR_MM_MONTH_DD_HH_MM_DATE = "yyyy年MM月dd日 HH:mm";

    /**
     * 日付フォーマットパターン：yyyy年MM月dd日（E）
     */
    static final String DF_YYYY_YEAR_MM_MONTH_DD_DATE_E = "yyyy年MM月dd日（E）";
    /**
     * 日付フォーマットパターン：yyyy年MM月dd日（E曜）
     */
    static final String DF_YYYY_YEAR_MM_MONTH_DD_DATE_E_YOU = "yyyy年MM月dd日（E曜）";
    /**
     * 日付フォーマットパターン：yyyy年MM月dd日（E曜日）
     */
    static final String DF_YYYY_YEAR_MM_MONTH_DD_DATE_E_YOBI = "yyyy年MM月dd日（E曜日）";
    /**
     * 日付フォーマットパターン：yyyy年MM月
     */
    static final String DF_YYYY_YEAR_MM_MONTH = "yyyy年MM月";
    /**
     * 日付フォーマットパターン：MM月dd日
     */
    static final String DF_MM_MONTH_DD_DATE = "MM月dd日";
    /**
     * 日付フォーマットパターン：E
     */
    static final String DF_E = "E";
    /**
     * 日付フォーマットパターン：E曜
     */
    static final String DF_E_YOU = "E曜";
    /**
     * 日付フォーマットパターン：E曜日
     */
    static final String DF_E_YOBI = "E曜日";
    /**
     * 日付フォーマットパターン：（E）
     */
    static final String DF_E_KAKO = "（E）";
    /**
     * 日付フォーマットパターン：（E曜）
     */
    static final String DF_E_YOU_KAKO = "（E曜）";
    /**
     * 日付フォーマットパターン：（E曜日）
     */
    static final String DF_E_YOBI_KAKO = "（E曜日）";
    /**
     * 日付フォーマットパターン：タイムスタンプ
     */
    static final String DF_TIMESTAMP = "yyyy-MM-dd HH:mm:ss.SSS";
    /**
     * 日付フォーマットパターン：MM月dd日（E）
     */
    static final String DF_MM_MONTH_DD_DATE_E = "MM月dd日（E）";
    /**
     * 日付フォーマットパターン：MM月dd日（E曜）
     */
    static final String DF_MM_MONTH_DD_DATE_E_YOU = "MM月dd日（E曜）";
    /**
     * 日付フォーマットパターン：MM月dd日（E曜日）
     */
    static final String DF_MM_MONTH_DD_DATE_E_YOBI = "MM月dd日（E曜日）";
    /**
     * 日付フォーマットパターン：dd日（E）
     */
    static final String DF_DD_DATE_E = "dd日（E）";
    /**
     * 日付フォーマットパターン：dd日（E曜）
     */
    static final String DF_DD_DATE_E_YOU = "dd日（E曜）";
    /**
     * 日付フォーマットパターン：dd日（E曜日）
     */
    static final String DF_DD_DATE_E_YOBI = "dd日（E曜日）";
    /**
     * 日付フォーマットパターン：dd（E）
     */
    static final String DF_DD_E = "dd（E）";
    /**
     * 日付フォーマットパターン：dd（E曜）
     */
    static final String DF_DD_E_YOU = "dd（E曜）";
    /**
     * 日付フォーマットパターン：dd（E曜日）
     */
    static final String DF_DD_E_YOBI = "dd（E曜日）";
    /**
     * 日付フォーマットパターン：Gyy
     */
    static final String DF_GYY = "Gyy";
    /**
     * 日付フォーマットパターン：GGGGyy年MM月dd日 HH時mm分
     */
    static final String DF_GGGGYY_YEAR_MM_MONTH_DD_DATE_HH_JI_MM_MINUTE = "GGGGyy年MM月dd日 HH時mm分";
    /**
     * 日付フォーマットパターン：GGGGyy年MM月dd日
     */
    static final String DF_GGGGYY_YEAR_MM_MONTH_DD_DATE = "GGGGyy年MM月dd日";
    /**
     * 日付フォーマットパターン：GGGGyy年MM月
     */
    static final String DF_GGGGYY_YEAR_MM = "GGGGyy年MM月";
    /**
     * 日付フォーマットパターン：Gyy.MM.dd
     */
    static final String DF_GYY_MM_DD = "Gyy.MM.dd";
    /**
     * 日付フォーマットパターン：Gyy.MM
     */
    static final String DF_GYY_MM = "Gyy.MM";
    /**
     * 日付フォーマットパターン：GyyMM
     */
    static final String DF_GYYMM = "GyyMM";
    /**
     * 日付フォーマットパターン：GyyMMdd
     */
    static final String DF_GYYMMDD = "GyyMMdd";
    /**
     * 日付フォーマットパターン：GGGGyy
     */
    static final String DF_GGGGYY = "GGGGyy";
    /**
     * 日付フォーマットパターン：Gyy年
     */
    static final String DF_GYY_YEAR = "Gyy年";
    /**
     * 日付フォーマットパターン：GGYY.MM.DD（元号年月日）
     */
    static final String DF_GGYY_MM_DD = "GGyy.MM.dd";
    /**
     * 日付フォーマットパターン：GGGGYY.MM.DD（元号年月日）
     */
    static final String DF_GGGGYY_MM_DD = "GGGGyy.MM.dd";
    /**
     * 日付フォーマットパターン（時刻）：HHmmss（時分秒）
     */
    static final String DF_TIME_HHMMSS = "HHmmss";
    /**
     * 日付フォーマットパターン（時刻）：HH:mm:ss（時:分:秒）
     */
    static final String DF_TIME_HH_MM_SS = "HH:mm:ss";
    /**
     * 日付フォーマットパターン（時刻）：HHmm（時分）
     */
    static final String DF_TIME_HHMM = "HHmm";
    /**
     * 日付フォーマットパターン（時刻）：HH:mm（時:分）
     */
    static final String DF_TIME_HH_MM_JI_MINUTE = "HH:mm";
    /**
     * 日付フォーマットパターン（時刻）：HH（時）
     */
    static final String DF_TIME_HH = "HH";
    /**
     * 日付フォーマットパターン（時刻）：HH時mm分
     */
    static final String DF_TIME_HH_HOUR_MM_MINUTE = "HH時mm分";
    /**
     * 日付フォーマットパターン（時刻）：mm（分）
     */
    static final String DF_TIME_MM = "mm";
    /**
     * 日付フォーマットパターン（時刻）：ss（秒）
     */
    static final String DF_TIME_SS = "ss";
    /**
     * 数値フォーマットパターン：#,###
     */
    static final String SUTI_FORMAT_PTN_NUM = "#,###";
    /**
     * 数値フォーマットパターン：#,###円
     */
    static final String SUTI_FORMAT_PTN_NUM_YEN = "#,###円";
    /**
     * 数値フォーマットパターン：#,###.00
     */
    static final String SUUI_FORMAT_PTN_NUM_POINT_DOUBLE_ZERO = "#,###.00";
    /**
     * コメント行判定文字：CSV取込ファイル
     */
    static final String COMMENT_LINE_HANTEI_MOJI_CSV_TORIKOMI_FILE = "#";
    /**
     * イメージ保存ルートパス
     */
//    static final String IMAGE_SAVE_ROOT_PATH = "storage/image/";
    /**
     * 共通.試験問題添付ファイルパス
     */
//    static final String GPW_E_LEARNING_QUESTION_FILE_PATH = "storage/gpw_e_learning/question_file/";

    /**
     * パス分離符号
     */
    static final String PS = System.getProperty("path.separator");
    /**
     * ファイル分離符号
     */
    static final String FS = System.getProperty("file.separator");
    /**
     * 改行符号
     */
    static final String LINE_SEPARATOR = System.getProperty("line.separator");
    /**
     * 改行符号
     */
    static final String LS = System.getProperty("line.separator");
    /**
     * 改行符号（LINUX）
     */
    static final String LINE_SEPARATOR_LINUX = "\n";
    /**
     * 改行符号
     */
    static final String STRING_SEPARATOR = "|";

    /**
     * エンコード（UTF8）
     */
    static final String KYOTU_ENCODE_UTF8 = "UTF-8";
    /**
     * エンコード（Shift-JIS）
     */
    static final String KYOTU_ENCODE_SHIFT_JIS = "MS932";
    /**
     * ファイル文字コード.SHIFT_JIS
     */
    static final String FILE_ENCODE_SHIFT_JIS = "shift-jis";
    /**
     * ファイル文字コード.UTF_8
     */
    static final String FILE_ENCODE_UTF_8 = "utf-8";

    /**
     * データタイプ.STRING
     */
    static final String DATA_TYPE_STRING = "01";
    /**
     * データタイプ.INT
     */
    static final String DATA_TYPE_INT = "02";
    /**
     * データタイプ.BIGDECIMAL
     */
    static final String DATA_TYPE_BIGDECIMAL = "03";
    /**
     * データタイプ.CALENDAR
     */
    static final String DATA_TYPE_CALENDAR = "04";
    /**
     * データタイプ.LONG
     */
    static final String DATA_TYPE_LONG = "05";
    /**
     * データタイプ.STRING[]
     */
    static final String DATA_TYPE_STRINGS = "06";
    /**
     * データタイプ.AutoCompOptionBean
     */
    static final String DATA_TYPE_AUTO_COMP_OPTION_BEAN = "07";

    /**
     * ＡＴＴＲを使用
     */
    static final String ATTR_FLG_Y = "Y";
    /**
     * ＡＴＴＲを使用しない
     */
    static final String ATTR_FLG_N = "N";

    /**
     * 定数：追加、複製した行キー.
     */
    static final String CONST_ADD_ROW_KEY = "addFlg";

    /**
     * 定数：文字列0.
     */
    static final String CONST_ZERO_STRING = "0";

    /**
     * 定数：文字列1.
     */
    static final String CONST_ONE_STRING = "1";

    /**
     * 画面ID.mst032
     */
    static final String GAMENID_MST032 = "mst032";

    /**
     * 画面ID.mst501
     */
    static final String GAMENID_MST501 = "mst501";

    /**
     * 定数：整数0.
     */
    static final int CONST_ZERO_NUMBER = 0;

    /**
     * 定数：整数1.
     */
    static final int CONST_ONE_NUMBER = 1;

    /**
     * 一覧データチェック：必須チェック
     */
    static final String LIST_CHECK_NOT_NULL = "1";

    /**
     * 一覧データチェック：数値チェック
     */
    static final String LIST_CHECK_NUMBER = "2";

    /**
     * 一覧データチェック：日付チェック
     */
    static final String LIST_CHECK_DATE = "3";

    /**
     * 一覧データチェック：桁数チェック
     */
    static final String LIST_CHECK_SIZE = "4";

    /**
     * 一覧データチェック：最大桁数チェック
     */
    static final String LIST_CHECK_MAX_SIZE = "5";

    /**
     * 一覧データチェック：最小桁数チェック
     */
    static final String LIST_CHECK_MIN_SIZE = "6";

    /**
     * 一覧データチェック：半角チェック
     */
    static final String LIST_CHECK_IS_HALF = "7";

    /**
     * 一覧データチェック：整数最大桁数チェック
     */
    static final String LIST_CHECK_INTEGER_MAXE_SIZE = "8";

    /**
     * 一覧データチェック：小数最大桁数チェック
     */
    static final String LIST_CHECK_DECIMAL_MAXE_SIZE = "9";

    /**
     * 一覧データチェック：最小数値チェック
     */
    static final String LIST_CHECK_MIN_NUMBER = "10";

    /**
     * 配色：通常
     */
    static final String COLOR_NORMAL = "0";

    /**
     * 配色：無効(非活性)
     */
    static final String COLOR_DISABLED = "1";

    /**
     * 配色：必須
     */
    static final String COLOR_NOTNULL = "2";

    /**
     * 配色：変更
     */
    static final String COLOR_CHANGE = "3";

    /**
     * 配色：注意
     */
    static final String COLOR_WARN = "4";

    /**
     * 配色：エラー
     */
    static final String COLOR_ERROR = "5";

    /**
     * 配色：完了色
     */
    static final String COLOR_COMPLETE = "6";

    /**
     * 配色：ポイント色
     */
    static final String COLOR_POINT = "7";

    /**
     * 配色：選択色
     */
    static final String COLOR_SELECTED = "8";

    /**
     * 配色：マウスオーバー色
     */
    static final String COLOR_MOUSEOVER = "9";

    /**
     * ADサーバ
     */
    static final String AD_SERVER_ADDRESS = "ad-server-address";

    /**
     * ADサーバ
     */
    static final String AD_SERVER_PORT = "ad-server-port";

    /**
     * ドメイン
     */
    static final String DN = "dn";

    /**
     * バインドユーザ
     */
    static final String BIND_USER = "bind-user";
    
    /**
     * バインドユーザのパスワード
     */
    static final String BIND_USER_PASSWORD = "bind-user-password";
    
    /**
     * ワンタイムパスワード
     */
    static final String ONETIME_PASSWORD = "onetime-password";

    /**
     * 本社区分:本社
     */
    static final String HONSHAKBN_HONSHA = "1";

    /**
     * 本社区分:営業所
     */
    static final String HONSHAKBN_EIGYOSHO = "2";

    /**
     * ワンタイムパスワード使用文字列:英小文字
     */
     static final String RANDLOWER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    /**
     * ワンタイムパスワード使用文字列:英大文字
     */
    static final String RANDUPPER = "abcdefghijklmnopqrstuvwxyz";

    /**
     * ワンタイムパスワード使用文字列:アラビア数字
     */
    static final String RANDNUMBER = "0123456789";

    /**
     * ワンタイムパスワード使用文字列:特殊文字
     */
    static final String RANDSYMBOL = "~`!@#$%^&*()_-+=\\|{[}]:;\"'<,>.?/";

}
