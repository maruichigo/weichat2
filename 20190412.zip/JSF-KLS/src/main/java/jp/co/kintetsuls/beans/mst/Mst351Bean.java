/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst351Form;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.utils.NumberUtils;
import jp.co.kintetsuls.utils.StrUtils;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Mst351_拠点間卸値マスタ
 *
 * @author 邱志遠
 * @version 2019/1/9 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst351")
@ViewScoped
@Data
public class Mst351Bean extends AbstractBean {
    
    /**
     * タイトル
     */
    private final String strTitle = "拠点間卸値マスタ";
    
    /**
     * パンくず名とCSVタイトル
     */
    private final static String TITLE = "拠点間卸値マスタ";    
    
    /**
     * 画面URL
     */
    private String url;
    
    /**
     * パンくずリスト
     */      
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * ユーザ権限
     */  
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    /**
     * メッセージ出力
     */ 
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messageProperty;
      
    /**
     * 画面共通作業
     */ 
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;
    
    /**
     * 画面フォーム
     */   
    @ManagedProperty(value = "#{mst351Form}")
    private Mst351Form mst351Form;
    
    /**
     * ファイルダウンロード
     */ 
    @ManagedProperty(value = "#{fileBean}")
    private FileBean fileBean;
    
    /**
     * 検索シーケンス処理共通
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;

    /**
     * 履歴一覧処理共通
     */
    @ManagedProperty(value = "#{rirekisyosai}")
    private RirekiSyosaiBean rirekiSyosai;
    
    /**
     * 一覧単項目チェック共通
     */
    @ManagedProperty(value = "#{listCheckBean}")
    private ListCheckBean listCheckBean;
    
    /**
     * ワーク.メッセージリスト
     */
    List<MessageModuleBean> msgList = new ArrayList<>();    
    
    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());
    
    /**
     * ScreenCode：MST351
     */
    private static final String SC_CD_MST351 = "MST351_SCREEN";
    
    /**
     * 定数：一覧のDataTableのID
     */
    private static final String DATA_TABLE_ID = "tablesorter_mst351";
    
    /**
     * 定数：MST351_SEARCH
     */
    private static final String FUNC_CODE_SEARCH = "mst351_search";
    
    /**
     * 定数：MST351_SEARCH_KENSU
     */
    private static final String FUNC_CODE_KENSU = "mst351_search_kensu";
    
    /**
     * 定数：削除FUNC_CODE
     */
    private static final String FUNC_CODE_DELETE = "mst351_delete";
    
    /**
     * 定数：更新FUNC_CODE
     */
    private static final String FUNC_CODE_UPDATE = "mst351_update";
    
    /**
     * 定数：更新チェックFUNC_CODE
     */
    private static final String FUNC_CODE_UPDATE_CHECK = "mst351_update_check";
    
    /**
     * 定数：削除チェックFUNC_CODE
     */
    private static final String FUNC_CODE_DELETE_CHECK = "mst351_delete_check";
    
    /**
     * 定数：画面項目保持キー
     */
    private static final String CONST_MST351_FORM = "mst351Form";

    /**
     * 定数：MasterInfo取得キー
     */
    private static final String CONST_MST351_MASTER = "mst351";
    
    /**
     * 定数：再検索Button取得キー
     */
    private static final String CONST_MST351_SEARCH = "search_mst351";        
    /**
     * 履歴テーブル検索キー
     */
    private Map<String, Object> rirekiSearchKey;
    
    /**
     * コンストラクタ
     */
    public Mst351Bean() {

    }
    
    /**
     * 一覧の単項目チェック処理
     * 
     * @param params 画面一覧パラメータ
     * @return チェックの結果
     */
    private boolean checkJsfParamas(List<Map<String, Object>> params) {

        List<ListCheckBean> checks = new ArrayList<>();
        // 発営業所 必須チェック
        checks.add(new ListCheckBean("listHatsuEigyousho", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "発営業所"));
        // 着営業所 必須チェック
        checks.add(new ListCheckBean("listChakuEigyousho",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "着営業所"));
        // 輸送方法コード 必須チェック
        checks.add(new ListCheckBean("listYusoHohoCd", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "輸送方法コード"));
        // 計上先 必須チェック
        checks.add(new ListCheckBean("listKeijhoSaki", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "計上先"));
        // 単価(kgあたり） IMEチェック
        checks.add(new ListCheckBean("listTanka",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NUMBER, "単価(kgあたり）"));
        // 単価(kgあたり） 桁数チェック
        checks.add(new ListCheckBean("listTanka",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "単価(kgあたり）", "10"));
        List<MessageModuleBean> checkMsgList = listCheckBean.check(params, checks, true);

        if (!checkMsgList.isEmpty()) {
            return false;
        }
        return true;
    }
    
    /**
     * 初期処理（処理）
     *
     * @param menuId メニューID
     * @param prevScreen 遷移元画面ID
     * @param backFlag 戻るフラグ
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            // パンくず追加
            breadBean.push(TITLE, Cnst.SCREEN.MST351_SCREEN.name(), this);
            
            // マスタ内容取得
            pageCommonBean.getMasterInfo(CONST_MST351_MASTER);
            // 検索シーケンス処理ため初期化
            searchHelpBean.regSearchHelp(DATA_TABLE_ID,
                    s -> {return getRecordCount();},
                    s -> {search(); return null;},
                    null);
            searchHelpBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);
           
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する
            // 計上先
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_ALL_VW_EIGYOSHO);
            // 発営業所 と 着営業所
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_EIGYOSHO_DAIRITEN);
            // 輸送方法
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_YUSO_HOHO);
            // 卸種別
            autoCompleteViewBean.getMsKbn(MsCnst.OROSHI_SYUBETU_KBN);
            
            // 前回の記録をクリアする
            this.clear();
            mst351Form.setSearchResult(null);
            mst351Form.setSearchResultSelectable(null);
            mst351Form.setSelectedSearchResult(null);
            
            // 戻ってきた場合
            Mst351Form preForm = (Mst351Form) pageCommonBean.getPageInfo(CONST_MST351_FORM);
            if (backFlag && preForm != null) {
                PageCommonBean.simpleCopy(preForm, mst351Form);
                // 再検索を実施する
                pageCommonBean.searchAgain(CONST_MST351_SEARCH);
            } else {
                // 進んできた場合
                Flash flash = pageCommonBean.getPageParam();
                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_MST351_FORM) != null) {
                    PageCommonBean.simpleCopy(flash.get(CONST_MST351_FORM), mst351Form);
                    // 再検索を実施する
                    pageCommonBean.searchAgain(CONST_MST351_SEARCH);
                }
            }
            
            // ダウンロードシーケンスを初期化する
            fileBean.setDataSize(DATA_TABLE_ID, (id -> {return getRecordCount();}));

            fileBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);

            fileBean.setSubFlg(false);

            fileBean.setTilte(strTitle);

            fileBean.regDownloadFucntion(DATA_TABLE_ID, getHeader() ,
                    (id -> {return getKensakuList();}));
            
            fileBean.regBeforeDownFucntion(DATA_TABLE_ID,
                    (comment -> {return beforeDown(comment);}));
            
            fileBean.setSearchResult(DATA_TABLE_ID, (id -> {return getSearchResult();}));

            // 行更新また削除するために共通処理へ登録する
            pageCommonBean.regDelFucntion(DATA_TABLE_ID,
                    (dataList -> (this.delRows(dataList))));

            // component初期化とユーザ権限により制御を設定する
            pageCommonBean.setAuthControll(mst351Form, SC_CD_MST351, true);
            
            // 初期はデータを編集不可にする
            mst351Form.setBtnEditeDisabled(true);
            
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }
    
    /**
     * カウント処理
     * @return 取得件数
     */
    public Long getRecordCount() {
        
        // 前回の記録をクリアする
        Map<String, Object> mapRec = new LinkedHashMap();
        mapRec.put(StndConsIF.CONST_ZERO_STRING, true);
        List<Map<String, Object>> mapList = new ArrayList();
        mapList.add(mapRec);
        mst351Form.setSearchResult(mapList);
        mst351Form.setSearchResultSelectable(new ReportListDataModel(mst351Form.getSearchResult()));
        mst351Form.setSelectedSearchResult(null);
        
        // 検索初期はデータを編集不可にする
        mst351Form.setBtnEditeDisabled(true);
        
        // レコード件数を取得する
        long kensu = getKensakuKensu();
        // 参照モードにする
        pageCommonBean.setEditFlg(false);
        
        // 検索部のステータスを変更する
        pageCommonBean.setSerchConDisabled(mst351Form);

        // 検索条件保存
        pageCommonBean.savePageInfo(CONST_MST351_FORM, mst351Form);
        return kensu;
    }
    
    /**
     * 検索処理
     *
     */
    public void search() {
        
        // 選択リストを初期化する
        mst351Form.setSelectedSearchResult(new ArrayList<>());
        mst351Form.setSearchResultSelectable(null);

        // 検索を行う
        List<Map<String, Object>> recordList = getKensakuList();
        // 配色定義を設定する
        setIchiranColor(recordList);
        
        fileBean.setDataList(recordList);
        // 取得した値を画面項目にセットする
        pageCommonBean.setDatalist(DATA_TABLE_ID, recordList);

        try {
            mst351Form.setSearchResultSelectable(new ReportListDataModel(recordList));
        } catch (Exception e) {
        }
        // 検索部のステータスを変更する
        pageCommonBean.setSerchConDisabled(mst351Form);
        
        // 削除済のみのチェック状態より、明細データを編集可／不可にする
        if (mst351Form.getConSakujonomiKensaku() == null || mst351Form.getConSakujonomiKensaku().length == 0) {
            // 削除済みデータを編集可にする
            mst351Form.setBtnEditeDisabled(false);
        } else {
            // 削除済みデータを編集不可にする
            mst351Form.setBtnEditeDisabled(true);
        }
        // 検索条件保存
        pageCommonBean.savePageInfo(CONST_MST351_FORM, mst351Form);
        
        // 参照モードにする
        pageCommonBean.setEditFlg(false);
    }
    
    /**
     * 配色定義を設定する処理
     *
     * @param recordList // レコードリスト
     */
    public void setIchiranColor(List<Map<String, Object>> recordList) {

        // 配色定義の判定を行う
    }
    /**
     * 検索条件変更処理
     */
    public void searchChange() {

        // 検索部のステータスを変更する
        pageCommonBean.setSerchConEnabled(mst351Form);
    }
    
    /**
     * クリア処理
     */
    public void clear() {

        // 検索部の条件クリア
        mst351Form.setConChakuEigyousho(null);
        mst351Form.setConHatsuEigyousho(null);
        mst351Form.setConKeijhoSaki(null);
        mst351Form.setConYusoHohoCd(null);
        mst351Form.setConOroshiShubetsuKbn(null);
        mst351Form.setConDefaultFlg(null);
        mst351Form.setConSakujonomiKensaku(null);
        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mst351Form);
        pageCommonBean.setBtnSearchChangeVisible(false);
        pageCommonBean.setBtnSearchVisible(Boolean.TRUE);
    }

    /**
     * 更新履歴を表示処理
     *
     */
    public void rirekiIchiran() {
        // 履歴テーブル検索キー設定
        rirekiSearchKey = new HashMap();
        Map<String, Object> selectRec = mst351Form.getSelectedSearchResult().get(0);
        // 発営業所
        rirekiSearchKey.put("listHatsuEigyousho", selectRec.get("listHatsuEigyousho"));
        // 着営業所
        rirekiSearchKey.put("listChakuEigyousho", selectRec.get("listChakuEigyousho"));
        // 輸送方法コード
        rirekiSearchKey.put("listYusoHohoCd", selectRec.get("listYusoHohoCd"));
        
        // 履歴タイトル設定
        rirekiSyosai.setListColName(new ArrayList<>(Arrays.asList("発営業所", "発営業所名称", "着営業所", "着営業所名称", "輸送方法コード", "輸送方法名称",
                "単価(kgあたり）", "卸種別区分(一覧)", "卸種別名称(一覧)", "計上先", "計上先名称", "デフォルトフラグ")));

        // 履歴beanの項目物理名設定
        rirekiSyosai.setListColValue(new ArrayList<>(Arrays.asList("listHatsuEigyousho", "listHatsuEigyoushoMei", "listChakuEigyousho", "listChakuEigyoushoMei",
                "listYusoHohoCd", "listYusoHohoMei", "listTanka", "listOroshiShubetsuKbn", "listOroshiShubetsuMei", "listKeijhoSaki", "listKeijhoSakiMei",
                "listDefaultFlg")));
        
         // 表示位置設定
//        List<String> colAlign = new ArrayList<>(Arrays.asList("left","left","left",
//                "left", "left", "left", "right", 
//                "left", "left", "left", "left", 
//                "center"));
//
//        List<RirekiListCol> listCol = new ArrayList<>();
//                for (int i = 0; i < colValue.size(); i++) {
//                   RirekiListCol col = new RirekiListCol();
//                   col.setColValue(colValue.get(i));
//                   col.setColAlign(colAlign.get(i));
//                   listCol.add(col);
//        }
//        rirekiSyosai.setListCol(listCol);
        // 履歴テーブル検索する
        rirekiSyosai.searchList("2", "MST351_SEARCH_RIREKI", rirekiSearchKey);

    }
    /**
     * 業務更新処理
     *
     */
    public void update() {
        // 入力チェック
        if (mst351Form.getSelectedSearchResult().isEmpty()) {
            messageProperty.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0013);
            return;
        }
        final List<Map<String, Object>> datas = mst351Form.getSelectedSearchResult();
        // 相関チェック
        for (int row = 0; row < datas.size(); row++) {
            if ((StrUtils.defaultString(datas.get(row).get("listOroshiShubetsuKbn"))).equals("0")
                   && !CheckUtils.isEmpty(NumberUtils.toInt(StrUtils.defaultString(datas.get(row).get("listTanka"))))) {
                messageProperty.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MSTE0069);
                return;
            }
        }
        // 単項目チェック処理
        if (!checkJsfParamas(mst351Form.getSelectedSearchResult())) {
            return;
        }

        // 登録・更新処理を行う
        int status = insertUpdate();
        // エラーの場合、処理終了
        if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            return;
        }
        
        // 登録の後に再度検索する
        this.search();

        // 一覧の配色定義をなくす
        pageCommonBean.resetIchiranColColor(mst351Form.getSelectedSearchResult());

        // メッセージを設定する
        messageProperty.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, "更新");
        
        // ログ出力を行う
        LOGGER.info("更新 " + mst351Form.getSelectedSearchResult().size() + " 件");
    }
    
    /**
     * 更新処理
     *
     * @return
     */
    public int insertUpdate() {
        
        // 重複チェック、存在チェック
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(mst351Form.getSelectedSearchResult(), FUNC_CODE_UPDATE_CHECK);
        // エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            messageProperty.message(res.getMessages().get(0)[0],
                    res.getMessages().get(0)[1],
                    res.getMessages().get(0)[2],
                    res.getTableName());

            return res.getStatusCode();
        }
        
        // 登録一覧リストと更新一覧リストの内容を処理する
        res = pageCommonBean.accsessDBWithList(mst351Form.getSelectedSearchResult(), FUNC_CODE_UPDATE);

        return res.getStatusCode();
    }

    /**
     * DBから検索件数を取得する
     */
    private Long getKensakuKensu() {

        // パラメータ
        Map<String, Object> params = new HashMap<>();
        // 発営業所コード
        if (mst351Form.getConHatsuEigyousho() != null) {
            params.put("conHatsuEigyousho", mst351Form.getConHatsuEigyousho().getValue());
        } else {
            params.put("conHatsuEigyousho", mst351Form.getConHatsuEigyousho());
        }
        // 着営業所コード
        if (mst351Form.getConChakuEigyousho() != null) {
            params.put("conChakuEigyousho", mst351Form.getConChakuEigyousho().getValue());
        } else {
            params.put("conChakuEigyousho", mst351Form.getConChakuEigyousho());
        }
        // 輸送方法コード
        if (mst351Form.getConYusoHohoCd() != null) {
            params.put("conYusoHohoCd", mst351Form.getConYusoHohoCd().getValue());
        } else {
            params.put("conYusoHohoCd", mst351Form.getConYusoHohoCd());
        } 
        // 卸種別区分
        if (mst351Form.getConOroshiShubetsuKbn() != null) {
            params.put("conOroshiShubetsuKbn", mst351Form.getConOroshiShubetsuKbn().getValue());
        } else {
            params.put("conOroshiShubetsuKbn", mst351Form.getConOroshiShubetsuKbn());
        }
        // 計上先
        if (mst351Form.getConKeijhoSaki() != null) {
            params.put("conKeijhoSaki", mst351Form.getConKeijhoSaki().getValue());
        } else {
            params.put("conKeijhoSaki", mst351Form.getConKeijhoSaki());
        }
        // 削除済のみ
        params.put("conSakujonomiKensaku", mst351Form.getConSakujonomiKensaku());
        // デフォルトフラグ
        params.put("conDefaultFlg", mst351Form.getConDefaultFlg());
        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_KENSU);
        // 検索件数を返却する
        return Long.valueOf(res.getJson());
    }
    
    /**
     * DBから営業所情報を取得する
     */
    private List<Map<String, Object>> getKensakuList() {

        // パラメータ
        Map<String, Object> params = new HashMap<>();
        // 発営業所コード
        if (mst351Form.getConHatsuEigyousho() != null) {
            params.put("conHatsuEigyousho", mst351Form.getConHatsuEigyousho().getValue());
        } else {
            params.put("conHatsuEigyousho", mst351Form.getConHatsuEigyousho());
        }
        // 着営業所コード
        if (mst351Form.getConChakuEigyousho() != null) {
            params.put("conChakuEigyousho", mst351Form.getConChakuEigyousho().getValue());
        } else {
            params.put("conChakuEigyousho", mst351Form.getConChakuEigyousho());
        }
        // 輸送方法コード
        if (mst351Form.getConYusoHohoCd() != null) {
            params.put("conYusoHohoCd", mst351Form.getConYusoHohoCd().getValue());
        } else {
            params.put("conYusoHohoCd", mst351Form.getConYusoHohoCd());
        } 
        // 卸種別区分
        if (mst351Form.getConOroshiShubetsuKbn() != null) {
            params.put("conOroshiShubetsuKbn", mst351Form.getConOroshiShubetsuKbn().getValue());
        } else {
            params.put("conOroshiShubetsuKbn", mst351Form.getConOroshiShubetsuKbn());
        }
        // 計上先
        if (mst351Form.getConKeijhoSaki() != null) {
            params.put("conKeijhoSaki", mst351Form.getConKeijhoSaki().getValue());
        } else {
            params.put("conKeijhoSaki", mst351Form.getConKeijhoSaki());
        }
        // 削除済のみ
        params.put("conSakujonomiKensaku", mst351Form.getConSakujonomiKensaku());
        // デフォルトフラグ
        params.put("conDefaultFlg", mst351Form.getConDefaultFlg());

        try {
            // DBをアクセス
            ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH);
            ObjectMapper mapper = new ObjectMapper();
            mst351Form.setSearchResult(mapper.readValue(res.getJson(), List.class));
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
        // 情報を返却する
        return mst351Form.getSearchResult();
    }
    
    /**
     * メニュークリック（処理）
     *
     * @param menuId メニューID
     * @param nextScreen 遷移先画面ID
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック処理
     *
     * @param nextScreenId 遷移先画面ID
     * @param breadIndex パンくずのインデックス
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreenId, int breadIndex) {
        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        url = forward(nextScreenId, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authConfBean.logout();
    }

    /**
     * 画面遷移処理（顧客マスタメンテナンス画面へ）
     *
     * @return 遷移先の画面URL
     * @throws java.lang.IllegalAccessException
     * @throws java.lang.reflect.InvocationTargetException
     */
    public String buttonClick() throws IllegalAccessException, InvocationTargetException {

        // 画面遷移
        url = forward(Cnst.SCREEN.CUS012_SCREEN.name(), null, Cnst.SCREEN.CUS011_SCREEN.name(), false);
        return url;
    }

    /**
     * 画面タイトルを取得する処理
     * @return 画面タイトル
     */
    public String getStrTitle() {
        return strTitle;
    }
    
    /**
     * 業務削除処理ファンクション領域
     *
     */
    public void delRowsFunc() {

        pageCommonBean.getSelectedDatasList().put(DATA_TABLE_ID, mst351Form.getSelectedSearchResult());
        pageCommonBean.delRows(DATA_TABLE_ID);
    }
    
    /**
     * 業務削除処理
     *
     * @param datas レコードリスト
     * @return 正常／異常
     */
    public Boolean delRows(List<Map<String, Object>> datas) {
        
        // エラーメッセージを格納する変数の初期化
        msgList = new ArrayList<>();

        // 行選択チェック
        if (datas.isEmpty()) {
            MessageModuleBean message = messageProperty.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0013);
            msgList.add(message);
            return false;
        }
        
        // 存在チェック
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(datas, FUNC_CODE_DELETE_CHECK);
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            MessageModuleBean message = messageProperty.createMessageModule(res.getMessages().get(0)[0], res.getMessages().get(0)[1], res.getMessages().get(0)[2], "");
            msgList.add(message);
            messageProperty.messageList(msgList);
            msgList.clear();
            return false;
        }
        // 削除実施
        int status = deleteKyotenkanList(datas);
        // エラーの場合、処理を終了
        if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            return false;
        }

        try {
            // 画面レコード削除
            mst351Form.getSearchResult().removeAll(datas);
        } catch (Exception e) {
             java.util.logging.Logger.getLogger(Mst351Bean.class.getName()).log(Level.SEVERE, null, e);
        }
        // メッセージを設定する
        messageProperty.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, "削除");
        // ログ出力
        LOGGER.info("削除 " + datas.size() + " 件");
        return true;
    }

    /**
     * DBから拠点間卸値マスタ情報を削除する
     * @param datas レコードリスト
     * @return ステータスコード
     */
    private int deleteKyotenkanList(List<Map<String, Object>> datas) {

        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(datas, FUNC_CODE_DELETE);
        // ステータスコードを返却する
        return res.getStatusCode();
    }

    /**
     * EXCEL作成ファイル
     *
     * @return
     */
    public List<CSVDto> getHeader() {
        List<CSVDto> header = new ArrayList<>();
        // CSVファイルのタイトルを設定
        // 発営業所
        header.add(new CSVDto("発営業所", "listHatsuEigyousho"));
        // 発営業所名称
        header.add(new CSVDto("発営業所名称", "listHatsuEigyoushoMei"));
        // 着営業所
        header.add(new CSVDto("着営業所", "listChakuEigyousho"));
        // 着営業所名称
        header.add(new CSVDto("着営業所名称", "listChakuEigyoushoMei"));
        // 輸送方法コード
        header.add(new CSVDto("輸送方法コード", "listYusoHohoCd"));
        // 輸送方法名称
        header.add(new CSVDto("輸送方法名称", "listYusoHohoMei"));
        // 単価(kgあたり）
        header.add(new CSVDto("単価(kgあたり）", "listTanka"));
        // 卸種別区分
        header.add(new CSVDto("卸種別区分", "listOroshiShubetsuKbn"));
        // 卸種別名称
        header.add(new CSVDto("卸種別名称", "listOroshiShubetsuMei"));
        // 計上先
        header.add(new CSVDto("計上先", "listKeijhoSaki"));
        // 計上先名称
        header.add(new CSVDto("計上先名称", "listKeijhoSakiMei"));
        // デフォルトフラグ
        header.add(new CSVDto("デフォルトフラグ", "listDefaultFlg"));
       return header;
    }

    /**
     * ダウンロード理由を記録する処理
     *
     * @param comment 理由コメント
     * @return boolean 正常／異常
     * @throws java.lang.Exception
     */
    public boolean beforeDown(String comment) throws Exception {
        // ダウンロード理由を記録する
        System.out.println(comment);
        return true;
    }
    
    /**
     * アップロード
     * 
     * @return 遷移先画面のURL
     */
    public String upload() {
        
        // flash初期化
        Flash flash = pageCommonBean.getPageParam();
        
        // flashにアップロード機能コードを設定する
        flash.put("MST351_UPLOAD", TITLE);
        
        // アップロードを画面へ遷移
        url = forward(Cnst.SCREEN.UPLOAD_SCREEN.name(), null, Cnst.SCREEN.UPLOAD_SCREEN.name(), false);
        return url;
    }
    
    /**
     * 検索結果を取得する
     * 
     * @return 検索結果
     */
    private List<Map<String, Object>> getSearchResult() {
        return mst351Form.getSearchResult();
    }
}
