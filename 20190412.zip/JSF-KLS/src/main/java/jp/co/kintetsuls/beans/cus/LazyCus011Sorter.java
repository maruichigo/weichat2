/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.cus;

import java.util.Comparator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.model.SortOrder;

/**
 *
 * @author y_kamata
 */
public class LazyCus011Sorter implements Comparator<Cus011Def> {
    private String sortField;
    private SortOrder sortOrder;
    
    private static Logger logger = LogManager.getLogger(new Object(){}.getClass().getEnclosingClass().getName());
     
    public LazyCus011Sorter(String sortField, SortOrder sortOrder) {
        this.sortField = sortField;
        this.sortOrder = sortOrder;
    }

    public int compare(Cus011Def cus1, Cus011Def cus2) {
        try {
            Object value1 = Cus011Def.class.getField(this.sortField).get(cus1);
            Object value2 = Cus011Def.class.getField(this.sortField).get(cus2);

            // nullの場合は空文字に置き換える
            if(value1 == null){
                value1 = "";
            }
            if(value2 == null){
                value2 = "";
            }           
            int value = ((Comparable)value1).compareTo(value2);

            return SortOrder.ASCENDING.equals(sortOrder) ? value : -1 * value;
        }
        catch(Exception ex) {
            logger.error(ex.getMessage(), ex);
            throw new RuntimeException();
        }
    }  
}
