/*
 * Copyright (c) Shared System Inc.
 */

package jp.co.kintetsuls.beans.trn;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.LabelValueBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.forms.trn.Trn021Form;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Getter;
import lombok.Setter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 貨物詳細画面
 *
 * @author zf (MBP)
 * @version 2019/1/31 新規作成
 */
@javax.faces.bean.ManagedBean(name = "trn021")
@ViewScoped
public class Trn021Bean extends BaseBean {

    private final String strTitle = "貨物詳細";
    private String url;

    @ManagedProperty(value = "#{breadBean}")
    @Getter
    @Setter
    private BreadCrumbBean breadBean;

    @ManagedProperty(value = "#{authConfBean}")
    @Getter
    @Setter
    private AuthorityConfBean authConfBean;

    @ManagedProperty(value = "#{labelValueBean}")
    @Getter
    @Setter
    private LabelValueBean labelValueBean;

    private static final Logger logger = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    @ManagedProperty(value = "#{trn021Form}")
    @Getter
    @Setter
    private Trn021Form trn021Form;

    /**
     * コンストラクタ
     */
    public Trn021Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId クリックされたメニューID（メニューからの遷移以外はNULL）
     * @param prevScreen 遷移元の画面
     * @param backFlag 戻るフラグ（前画面へボタンからの遷移以外はFALSE）
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            // パンくず追加
            breadBean.push("貨物詳細", SCREEN.TRN021_SCREEN.name(), this);
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }
        
        // トレース一覧情報を取得する
        getB45List();
        // お客様管理No一覧情報を取得する
        getB105List();
        // 関連ファイル情報を取得する
        getB116List();
        // 送り状選択ポップアップリストを取得する
        getB146List();
        // 項目2内容2Listを取得する
        getK169List();
        // 枝番一覧情報を取得する
        getB173List();
        // 領収書発行情報を取得する
        getB182List();
        // 送り状一覧情報を取得する
        getB189List();
    }

    /**
     * メニュークリック（処理）
     *
     * @param menuId クリックされたメニューID（メニューからの遷移以外はNULL）
     * @param nextScreen 遷移先の画面
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }

        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
   }

    /**
     * パンくずクリック（処理）
     *
     * @param nextScreen 遷移先の画面
     * @param breadIndex 選択されたパンくずのIndex
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }
        url = forward(nextScreen, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authConfBean.logout();
    }

    /**
     * 画面遷移処理
     *
     * @return 遷移先の画面URL
     * @throws java.lang.IllegalAccessException
     * @throws java.lang.reflect.InvocationTargetException
     */
    public String buttonClick() throws IllegalAccessException, InvocationTargetException {

        // 画面遷移 TODO
        url = forward(SCREEN.CUS012_SCREEN.name(), null, SCREEN.CUS011_SCREEN.name(), false);
        return url;
    }

    public String getStrTitle() {
        return strTitle;
    }
    
    /**
     * トレース一覧情報を取得する
     */
    private void getB45List() {

        List<Map<String, String>> datas = new ArrayList<>();
        Map<String, String> data = new HashMap<>();
        data.put("k46", "配達完了");
        data.put("k47", "福岡営業所");
        data.put("k48", "");
        data.put("k49", "近　鉄夫");
        data.put("k50", "2017/10/03  10:30");
        data.put("k51", "3");
        data.put("k52", "正常");
        data.put("k53", "");
        datas.add(data);
        
        data = new HashMap<>();
        data.put("k46", "持出");
        data.put("k47", "福岡営業所");
        data.put("k48", "");
        data.put("k49", "近　鉄夫");
        data.put("k50", "2017/10/03  10:30");
        data.put("k51", "3");
        data.put("k52", "正常");
        data.put("k53", "");
        datas.add(data);
        
        data = new HashMap<>();
        data.put("k46", "積込");
        data.put("k47", "東京オペ");
        data.put("k48", "あり");
        data.put("k49", "近鉄　一郎");
        data.put("k50", "2017/10/02  20:30");
        data.put("k51", "3");
        data.put("k52", "正常");
        data.put("k53", "あり");
        datas.add(data);
        trn021Form.setB45List(datas);
    }
    
    /**
     * お客様管理No一覧情報を取得する
     */
    private void getB105List() {
        
        List<Map<String, String>> datas = new ArrayList<>();
        Map<String, String> data = new HashMap<>();
        data.put("k107", "12345678901234567890");
        data.put("k108", "");
        datas.add(data);
        
        data = new HashMap<>();
        data.put("k107", "12345678901234567891");
        data.put("k108", "");
        datas.add(data);
        
        data = new HashMap<>();
        data.put("k107", "12345678901234567892");
        data.put("k108", "●");
        datas.add(data);
        
        data = new HashMap<>();
        data.put("k107", "12345678901234567893");
        data.put("k108", "");
        datas.add(data);
        
        data = new HashMap<>();
        data.put("k107", "12345678901234567894");
        data.put("k108", "");
        datas.add(data);
        
        data = new HashMap<>();
        data.put("k107", "12345678901234567895");
        data.put("k108", "");
        datas.add(data);
        
        data = new HashMap<>();
        data.put("k107", "12345678901234567896");
        data.put("k108", "");
        datas.add(data);
        
        data = new HashMap<>();
        data.put("k107", "12345678901234567897");
        data.put("k108", "");
        datas.add(data);
        
        data = new HashMap<>();
        data.put("k107", "12345678901234567898");
        data.put("k108", "");
        datas.add(data);
        
        data = new HashMap<>();
        data.put("k107", "12345678901234567899");
        data.put("k108", "");
        datas.add(data);
        trn021Form.setB105List(datas);
    }

    /**
     * 関連ファイル情報を取得する
     */
    private void getB116List() {
        
        List<Map<String, Object>> datas = new ArrayList<>();
        Map<String, Object> data = new HashMap<>();
        data.put("k118", "登録ファイル1");
        data.put("k119", "");
        datas.add(data);
        
        data = new HashMap<>();
        data.put("k118", "登録ファイル2");
        data.put("k119", "アップロードファイルDragDrop");
        datas.add(data);
        
        data = new HashMap<>();
        data.put("k118", "登録ファイル3");
        data.put("k119", "ここにアップロードするファイルをドロップしてください");
        datas.add(data);
        trn021Form.setB116List(new ReportListDataModel(datas));
    }
    
    /**
     * 送り状選択ポップアップリストを取得する
     */
    private void getB146List() {
        
        List<Map<String, String>> datas = new ArrayList<>();
        Map<String, String> data = new HashMap<>();
        data.put("k147", "123456-1234567");
        data.put("k148", "12345678901234567890");
        data.put("k149", "2018/01/10");
        data.put("k150", "2018/01/12");
        data.put("k151", "1234567");
        data.put("k152", "近　鉄夫");
        data.put("k153", "株式会社 〇〇");
        data.put("k154", "東京都品川区××２－");
        datas.add(data);
        
        data = new HashMap<>();
        data.put("k147", "123456-1234567");
        data.put("k148", "12345678901234567890");
        data.put("k149", "2018/02/20");
        data.put("k150", "2018/02/22");
        data.put("k151", "1234567");
        data.put("k152", "近　鉄夫");
        data.put("k153", "株式会社 △△");
        data.put("k154", "東京都新宿区××５－");
        datas.add(data);
        trn021Form.setB146List(datas);
    }
    
    /**
     * 項目2内容2Listを取得する
     */
    private void getK169List() {
        
        List<Map<String, String>> datas = new ArrayList<>();
        Map<String, String> data = new HashMap<>();
        data.put("k169", "項目2");
        data.put("k170", "内容2");
        datas.add(data);
        for(int i = datas.size() + 1; i <= 4; i++) {
            datas.add(new HashMap<>());
        }
        trn021Form.setK169List(datas);
    }
    
    /**
     * 枝番一覧情報を取得する
     */
    private void getB173List() {
        
        List<Map<String, String>> datas = new ArrayList<>();
        Map<String, String> data = new HashMap<>();
        data.put("k174", "001");
        data.put("k175", "12345");
        data.put("k176", "配完");
        data.put("k177", "2017/10/03  10:30");
        data.put("k178", "品川営業所");
        data.put("k179", "〇〇　××");
        data.put("k180", "AA");
        data.put("k181", "HTバーコード読込");
        datas.add(data);
        
        data = new HashMap<>();
        data.put("k174", "002");
        data.put("k175", "12345");
        data.put("k176", "配完");
        data.put("k177", "2017/10/03  10:30");
        data.put("k178", "品川営業所");
        data.put("k179", "〇〇　××");
        data.put("k180", "");
        data.put("k181", "");
        datas.add(data);
        trn021Form.setB173List(datas);
    }
    
    /**
     * 領収書発行情報を取得する
     */
    private void getB182List() {
        
        List<Map<String, String>> datas = new ArrayList<>();
        Map<String, String> data = new HashMap<>();
        data.put("k183", "1234001");
        data.put("k184", "2017/10/03  11:30");
        data.put("k185", "20,000");
        data.put("k186", "〇〇　□□");
        datas.add(data);
        
        data = new HashMap<>();
        data.put("k183", "1234002");
        data.put("k184", "2017/10/03  12:30");
        data.put("k185", "20,000");
        data.put("k186", "〇〇　□□");
        datas.add(data);
        trn021Form.setB182List(datas);
    }
    
    /**
     * 送り状一覧情報を取得する
     */
    private void getB189List() {
        
        List<Map<String, String>> datas = new ArrayList<>();
        Map<String, String> data = new HashMap<>();
        data.put("k191", "123456-1234567");
        data.put("k192", "001");
        datas.add(data);
        
        data = new HashMap<>();
        data.put("k191", "123456-1234567");
        data.put("k192", "002");
        datas.add(data);
        trn021Form.setB189List(datas);
    }

}
