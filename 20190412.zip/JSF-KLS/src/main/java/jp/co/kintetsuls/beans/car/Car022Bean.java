/*
 * Copyright (c) Shared System Inc.
 */

package jp.co.kintetsuls.beans.car;

import jp.co.kintetsuls.beans.mst.*;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.LabelValueBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.forms.mst.Mst031Form;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Getter;
import lombok.Setter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 住所マスタ画面
 *
 * @author 作成者 (MBP)
 * @version 2019/1/28 新規作成
 */
@javax.faces.bean.ManagedBean(name = "car022")
@ViewScoped
public class Car022Bean extends BaseBean {

    private final String title = "車両配達詳細地図";
    private final String strTitle = "https://maps.googleapis.com/maps/api/js?key=AIzaSyDJW4jsPlNKgv6jFm3B5Edp5ywgdqLWdmc&sensor=false";
    private String url;

    @ManagedProperty(value = "#{breadBean}")
    @Getter
    @Setter
    private BreadCrumbBean breadBean;

    @ManagedProperty(value = "#{authConfBean}")
    @Getter
    @Setter
    private AuthorityConfBean authConfBean;

    @ManagedProperty(value = "#{labelValueBean}")
    @Getter
    @Setter
    private LabelValueBean labelValueBean;

    private static final Logger logger = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    @Getter
    @Setter
    private Map<String, String> selectSearchResult;

    @ManagedProperty(value = "#{mst031Form}")
    @Getter
    @Setter
    private Mst031Form mst031Form;

    /**
     * コンストラクタ
     */
    public Car022Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId クリックされたメニューID（メニューからの遷移以外はNULL）
     * @param prevScreen 遷移元の画面
     * @param backFlag 戻るフラグ（前画面へボタンからの遷移以外はFALSE）
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            // パンくず追加
            breadBean.push("住所マスタ", SCREEN.MST031_SCREEN.name(), this);
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }
        
//        // JISコードのみ検索リスト
//        mst031Form.setConJisCdNomiKensakuLabelValueList(labelValueBean.getStringList("COM_GET_MS_KBN", "JIS_CD_NOMI_KENSAKU"));
//        // JISチェック結果リスト
//        mst031Form.setConJisCheckKekkaLabelValueList(labelValueBean.getStringList("COM_GET_MS_KBN", "JIS_CHECK_KEKKA"));
//        // 世代検索条件リスト
//        mst031Form.setConSedaiKensakuJokenLabelValueList(labelValueBean.getStringList("COM_GET_MS_KBN", "SEDAI_KENSAKU_JOKEN"));
//        // 削除済のみ検索リスト
//        mst031Form.setConSakujoZumiNomiKensakuLabelValueList(labelValueBean.getStringList("COM_GET_MS_KBN", "SAKUJO_NOMI_KENSAKU"));
//        // 離島/館内配送リスト
//        mst031Form.setConRitoKannaiHaisoLabelValueList(labelValueBean.getStringList("COM_GET_MS_KBN", "RITO_KANNAI_HAISO"));
    }

    /**
     * 検索処理
     *
     */
    public void search() {

        List<Map<String, Object>> datas = new ArrayList<>();
        Map<String, Object> data = new HashMap<>();
        data.put("listShimukeChiCd", "1310300");
        data.put("listJusho", "東京都港区");
        data.put("listChoAza", "");
        data.put("listTekiyoKaishiBi", "2018/04/01");
        data.put("listShimukeChiMei", "東京都港区");
        data.put("listKuko", "NRT");
        data.put("listShuhaiChiku", "A");
        data.put("listKankatsuEigyoshoCd", "121");
        data.put("listKankatsuEigyoshoMei", "新東京営業所");
        data.put("listKyuEdiJusho", "○");
        data.put("listShinEdiJusho", "○");
        data.put("listRitoFukumu", "○");
        data.put("listRitoKensu", "3");
        data.put("listKannaiHaisoKensu", "3");
        data.put("listKyuJusho", "");
        data.put("listJisCheck", "変更");
        data.put("listTekiyoMei", "2018年度適用データ");
        data.put("listShuryo", "");
        data.put("listTekiyoShuryoFlg", "0");
        datas.add(data);
        
        data = new HashMap<>();
        data.put("listShimukeChiCd", "1310301");
        data.put("listJusho", "東京都港区");
        data.put("listChoAza", "海岸");
        data.put("listTekiyoKaishiBi", "2018/04/01");
        data.put("listShimukeChiMei", "港区海岸");
        data.put("listKuko", "HND");
        data.put("listShuhaiChiku", "A");
        data.put("listKankatsuEigyoshoCd", "131");
        data.put("listKankatsuEigyoshoMei", "品川営業所");
        data.put("listKyuEdiJusho", "");
        data.put("listShinEdiJusho", "");
        data.put("listRitoFukumu", "○");
        data.put("listRitoKensu", "3");
        data.put("listKannaiHaisoKensu", "3");
        data.put("listKyuJusho", "不可");
        data.put("listJisCheck", "変更");
        data.put("listTekiyoMei", "2018年度適用データ");
        data.put("listShuryo", "○");
        data.put("listTekiyoShuryoFlg", "1");
        datas.add(data);
        mst031Form.setSearchResultSelectable(new ReportListDataModel(datas));
    }

    /**
     * メニュークリック（処理）
     *
     * @param menuId クリックされたメニューID（メニューからの遷移以外はNULL）
     * @param nextScreen 遷移先の画面
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }

        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
   }

    /**
     * パンくずクリック（処理）
     *
     * @param nextScreen 遷移先の画面
     * @param breadIndex 選択されたパンくずのIndex
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }
        url = forward(nextScreen, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authConfBean.logout();
    }

    /**
     * 画面遷移処理
     *
     * @return 遷移先の画面URL
     * @throws java.lang.IllegalAccessException
     * @throws java.lang.reflect.InvocationTargetException
     */
    public String buttonClick() throws IllegalAccessException, InvocationTargetException {

        // 画面遷移 TODO
        url = forward(SCREEN.CUS012_SCREEN.name(), null, SCREEN.CUS011_SCREEN.name(), false);
        return url;
    }

    public String getStrTitle() {
        return strTitle;
    }

    public String getTitle() {
        return title;
    }    
}

