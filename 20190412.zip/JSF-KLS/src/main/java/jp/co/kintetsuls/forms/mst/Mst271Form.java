/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mst;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.annotation.DateCheck;
import jp.co.kintetsuls.beans.common.annotation.MaxSizeCheck;
import jp.co.kintetsuls.beans.common.annotation.NotEmpty;
import lombok.Data;

/**
 * 代理店・中継配達料金表一覧フォーム
 *
 * @author 強 超 (MBP)
 * @version 2019/1/24 新規作成
 */
@ManagedBean(name = "mst271Form")
@ViewScoped
@Data
public class Mst271Form implements Serializable {

    private static final long serialVersionUID = 1L;

    private boolean conTodofukenDisabled;
    
    //代理店
    private boolean conDairitenDisabled;
    
    //管轄営業所
    private boolean conKankatsuEigyoshoDisabled;

    //代理店
    private String checkConDairitenDisplay;

    //中継業者
    private String checkConKankatsuEigyoshoDisplay;

    //会社名
    private boolean conKaishaMeiDisabled;

    //伝票種別
    private boolean conDempyoShubetuDisabled;

    /**
     * ワーク.業者区分
     */
    private String conGyoshaKbn;

    /**
     * ワーク.代理店コード
     */
    private AutoCompOptionBean conDairiten;

    /**
     * ワーク.管轄営業所コード
     */
    private AutoCompOptionBean conKankatsuEigyosho;

    /**
     * ワーク.仕入先
     */
    private AutoCompOptionBean conSiiresaki;

    /**
     * ワーク.世代検索条件
     */
    @NotEmpty(message = "{COME0011}", name = "世代検索条件")
    private String[] conSedaiKensakuJoken;

    /**
     * ワーク.適用日指定
     */
    @DateCheck(name = "適用日") 
    private String conTekiyoHi;

    /**
     * ワーク.削除済のみ
     */
    private List<String> conSakujoSumiNomi;

    /**
     * ワーク.料金表設定
     */
    private List<String> conRyokinhyoSettei;

    /**
     * ワーク.会社名
     */
    private AutoCompOptionBean conKaishaMei;

    /**
     * ワーク.支店/営業所
     */
    private AutoCompOptionBean conSitenEigyosho;

    /**
     * ワーク.伝票種別コード
     */
    private AutoCompOptionBean conDempyoShubetu;

    /**
     * ワーク.仕入先名称
     */
    @MaxSizeCheck(maxSize = 40, name = "仕入先名称")
    private String conSiiresakiMeisho;

    /**
     * ワーク.仕入先略称
     */
    private String conSiiresakiRyakusho;
    
    /**
     * ワーク.伝票種別コード
     */
    private AutoCompOptionBean conDempyoShubetu1;

    /**
     * ワーク.仕入先名称
     */
    @MaxSizeCheck(maxSize = 40, name = "仕入先名称")
    private String conSiiresakiMeisho1;

    /**
     * ワーク.仕入先略称
     */
    private String conSiiresakiRyakusho1;

     /**
     * ワーク.デフォルトのみ
     */
    private List<String> conDefaultNomi;


     /**
     * 検索Visabled
     */
    private boolean btnSearchVisible;

    /**
     * 検索条件変更Visabled
     */
    private boolean btnSearchChangeVisible;

    /**
     * 検索条件変更Class
     */
    private String disableClass;

    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult ;

    /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;

    /**
     * 選択された結果
     */
    private List<Map<String, String>> selectedSearchResult;

}
