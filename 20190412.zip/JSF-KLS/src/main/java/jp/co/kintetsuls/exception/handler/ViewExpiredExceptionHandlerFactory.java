package jp.co.kintetsuls.exception.handler;

import javax.faces.FacesException;
import javax.faces.context.ExceptionHandlerFactory;
import java.util.Iterator;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExceptionHandler;
import javax.faces.context.ExceptionHandlerWrapper;
import javax.faces.context.FacesContext;
import javax.faces.event.ExceptionQueuedEvent;
import javax.faces.event.ExceptionQueuedEventContext;
import jp.co.kintetsuls.exception.LogicException;
import org.slf4j.LoggerFactory;

/**
  * カスタム例外ハンドラファクトリの実装
 * @author 
 */
public class ViewExpiredExceptionHandlerFactory extends ExceptionHandlerFactory {

    private ExceptionHandlerFactory parent;

    public ViewExpiredExceptionHandlerFactory(ExceptionHandlerFactory parent) {
        this.parent = parent;
    }
	
    @Override
    public ExceptionHandler getExceptionHandler() {
        ExceptionHandler handler = new ViewExpiredExceptionHandler(parent.getExceptionHandler());
        return handler;
    }
    
    private class ViewExpiredExceptionHandler extends ExceptionHandlerWrapper {

        private ExceptionHandler wrapped;

        ViewExpiredExceptionHandler(ExceptionHandler exception) {
            this.wrapped = exception;
        }

        @Override
        public ExceptionHandler getWrapped() {
            return wrapped;
        }

        @Override
        public void handle() throws FacesException {
            for (Iterator<ExceptionQueuedEvent> it = getUnhandledExceptionQueuedEvents().iterator(); it.hasNext() == true;) {
                ExceptionQueuedEventContext eventContext = it.next().getContext();

                // 1. ハンドリング対象のアプリケーション例外を取得
                Throwable th = getRootCause(eventContext.getException()).getCause();
                if (!(th instanceof LogicException)) {

                    FacesContext facesContext = eventContext.getContext();
                    // メッセージを追加する
                    FacesMessage.Severity level = FacesMessage.SEVERITY_ERROR;
                    String summary = "System Error";
                    String msg =  "システムエラーが発生しました。システム管理者にご連絡ください。";
                    facesContext.addMessage("message", new FacesMessage(level, summary, msg));

                    it.remove();
                }
                LoggerFactory.getLogger(this.getClass()).error(eventContext.getException().getMessage(), eventContext.getException());
            }
            wrapped.handle();
        }
    }
}