/*
 *Copyright (C) 2014 MBP Corporation All Rights Reserved . 
 */
package jp.co.kintetsuls.beans.common;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.inject.Inject;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.exception.FunctionCust;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.PrimeFaces;

/**
 * 検索シーケンス処理
 *
 * @author hq
 */
@ViewScoped
@ManagedBean(name = "SearchHelpNoDownloadBean")
@Data
public class SearchHelpNoDownloadBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private final Map<String, FunctionCust<String, Long>> checkSizeFunctionList = new HashMap();

    private final Map<String, FunctionCust<String, String>> checkFunctionList = new HashMap();

    private final Map<String, FunctionCust<String, String>> searchFunctionList = new HashMap();
    
    private final Map<String, PageCommonBean> settings = new HashMap<>();
    
    private boolean flg = true;
    

    private static final Logger logger = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());
    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;
    
    public void regSearchHelp(String id, FunctionCust<String, Long> checkSizeFunction,
        FunctionCust<String, String> searchFunction, FunctionCust<String, String> checkFunction) {
        checkSizeFunctionList.put(id, checkSizeFunction);
        if (checkFunction != null) {
            checkFunctionList.put(id, checkFunction);
        }
        searchFunctionList.put(id, searchFunction);
    }

    public void checkSearch(String id) throws Exception {
        //TODO 関連チェック実行　修正必要
        if (checkFunctionList.containsKey(id)) {
            String flg = checkFunctionList.get(id).apply("");
            if (flg.equals("FALSE")) {
                return;
            }
        }
        PageCommonBean setting = settings.get(id);
        setting.setBtnSearchVisible(false);
        setting.setBtnSearchChangeVisible(true);
        setting.setCollapsed(true);
        settings.put(id, setting);

        if (checkSizeFunctionList.containsKey(id)) {
            Long size = checkSizeFunctionList.get(id).apply("");

            PrimeFaces.current().executeScript("checkNoDownloadSearch" //
                    + id + "('" + "A" + "')");
        }
    }

    public void search(String id) throws Exception {
        if (searchFunctionList.containsKey(id)) {
            searchFunctionList.get(id).apply("");
        }
        PageCommonBean setting = settings.get(id);
        setting.setBtnSearchVisible(false);
        setting.setBtnSearchChangeVisible(true);
    }

    public void searchChange(String id) throws Exception {
        PageCommonBean setting = settings.get(id);
        setting.setBtnSearchVisible(true);
        setting.setBtnSearchChangeVisible(false);
    }

    public void setMsg() throws Exception{
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_WARN,MessageCnst.COMW0001);
    }
    
    public void setMaxMsg() throws Exception{
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_WARN,MessageCnst.COMW0002);
    }
}
