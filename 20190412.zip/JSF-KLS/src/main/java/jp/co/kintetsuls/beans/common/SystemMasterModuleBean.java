/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common;

import java.io.Serializable;
import javax.faces.bean.ApplicationScoped;
import lombok.Data;

/**
 * E2システムマスタ定義モード
 * 
 * @author zf (MBP)
 * @version 2019/2/25 新規作成
 */
@ApplicationScoped
@Data
public class SystemMasterModuleBean implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 管理グループ
     */
    private String kanriGroup;

    /**
     * コード
     */
    private String code;

    /**
     * 値
     */
    private String value;

    /**
     * 説明
     */
    private String setsumei;

    public SystemMasterModuleBean() {
    }

}
