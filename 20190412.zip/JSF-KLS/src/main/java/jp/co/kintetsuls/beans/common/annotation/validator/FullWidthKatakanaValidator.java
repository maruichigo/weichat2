/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common.annotation.validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import jp.co.kintetsuls.beans.common.annotation.FullWidthKatakanaCheck;

/**
 * カタカナチェック
 * 
 * @author 李信志 (MBP)
 * @version 2019/3/27 新規作成
 */
public class FullWidthKatakanaValidator implements ConstraintValidator<FullWidthKatakanaCheck, String> { 

    @Override
    public void initialize(FullWidthKatakanaCheck constraintAnnotation) {
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
       Pattern pattern = Pattern.compile("[ァアィイゥウェエォオカガキギクグケゲコゴサザシジスズセソソゾタダチヂッツヅテデトドナニヌネノハバパヒビピフブプヘベペホボポマミムメモャヤュユョヨラリルレロヮワヰヱヲンヴヵヶ????・ーヽヽヾ]*");
           Matcher isFullWidthKatakana = pattern.matcher(value);
           if( !isFullWidthKatakana.matches() ){
               return false;
           }
           return true;
    }
    
}
