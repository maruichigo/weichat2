/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;
import jp.co.kintetsuls.beans.common.annotation.validator.HalfEisuKigouValidator;

/**
 * 半角英数字記号チェック
 * 
 * @author 李信志 (MBP)
 * @version 2019/3/27 新規作成
 */
@Documented
@Constraint(validatedBy = {HalfEisuKigouValidator.class})
@Target({java.lang.annotation.ElementType.METHOD, java.lang.annotation.ElementType.FIELD, java.lang.annotation.ElementType.ANNOTATION_TYPE, java.lang.annotation.ElementType.CONSTRUCTOR, java.lang.annotation.ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
public @interface HalfEisuKigou {

    public String name() default "";

    public String message() default "{COME0010}";
    
    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

}
