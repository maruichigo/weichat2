/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.lgn;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.annotation.NotNull;
import jp.co.kintetsuls.beans.common.annotation.SizeCheck;
import lombok.Data;

/**
 * ログイン フォーム
 *
 * @author 黄華 (MBP)
 * @version 2019/1/29 新規作成
 */
@javax.faces.bean.ManagedBean(name = "lgn011Form")
@ViewScoped
@Data
public class Lgn011Form implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * パスワード誤入力最大回数
     */
    private Integer hyoDtlPasswordGoNyuryokuSaidaiKaisu;
    
    /**
     * ユーザーコード
     */
    @NotNull(name = "ユーザーコード")
    @SizeCheck(name = "ユーザーコード", size = 7)
    private String hyoDtlUserCd;
    
    /**
     * パスワード
     */
    @NotNull(name = "パスワード")
    private String hyoDtlPassword;
    
    /**
     * お知らせ一覧
     */
    private List<Map<String, Object>> informResultList;

}
