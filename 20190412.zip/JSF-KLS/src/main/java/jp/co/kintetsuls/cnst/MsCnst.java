/*
 * Copyright (C) 2014 MBP Corporation All Rights Reserved .
 */
package jp.co.kintetsuls.cnst;

/**
 * 共通マスタ取得と区分マスタとシステムマスタ取得定数.
 *
 * @author COMM
 * @version 2019/2/22 新規作成
 */
public interface MsCnst {

    /** 共通マスタ取得.区分マスタ取得 */
    public static final String COM_GET_MS_KBN = "COM_GET_MS_KBN";
    /** 共通マスタ取得.区分マスタ取得(区分名) */
    public static final String COM_GET_MS_KBN_MEI = "COM_GET_MS_KBN_MEI";
    /** 共通マスタ取得.営業所取得 */
    public static final String COM_GET_VW_EIGYOSHO = "COM_GET_VW_EIGYOSHO";
    /** 共通マスタ取得.都道府県取得 */
    public static final String COM_GET_MS_TODOFUKEN = "COM_GET_MS_TODOFUKEN";
    /** 共通マスタ取得.法人番号取得 */
    public static final String COM_GET_MS_HOJIN_BANGO = "COM_GET_MS_HOJIN_BANGO";
    /** 共通マスタ取得.仕入先取得 */
    public static final String COM_GET_VW_SHIIRESAKI = "COM_GET_VW_SHIIRESAKI";
    /** 共通マスタ取得.SS仕入先取得 */
    public static final String COM_GET_MS_SS_SHIIRESAKI = "COM_GET_MS_SS_SHIIRESAKI";
    /** 共通マスタ取得.全営業所取得 */
    public static final String COM_GET_ALL_VW_EIGYOSHO = "COM_GET_ALL_VW_EIGYOSHO";
    /** 共通マスタ取得.JISコード取得 */
    public static final String COM_GET_JIS_CD = "COM_GET_JIS_CD";
    /** 共通マスタ取得.空港取得 */
    public static final String COM_GET_MS_KUKO = "COM_GET_MS_KUKO";
    /** 共通マスタ取得.仕向地取得 */
    public static final String COM_GET_SHIMUKE_CHI_CD = "COM_GET_SHIMUKE_CHI_CD";
    /** 共通マスタ取得.集配地区取得 */
    public static final String COM_GET_SHUHAI_CHIKU_CD = "COM_GET_SHUHAI_CHIKU_CD";
    /** 共通マスタ取得.区分マスタコード名称取得 */
    public static final String COM_GET_EDIT_MS_KBN = "COM_GET_EDIT_MS_KBN";
    /** 共通マスタ取得.仕入区分取得 */
    public static final String COM_GET_MS_SHIIRE_RYOKIN_KOMOKU = "COM_GET_MS_SHIIRE_RYOKIN_KOMOKU";
    /** 共通マスタ取得.集約コード取得 */
    public static final String COM_GET_MS_SHUYAKU_CD = "COM_GET_MS_SHUYAKU_CD";
    /** 共通マスタ取得.伝票種別取得 */
    public static final String COM_GET_MS_DEMPYO_SHUBETSU = "COM_GET_MS_DEMPYO_SHUBETSU";
    /** 共通マスタ取得.銀行口座取得 */
    public static final String COM_GET_MS_GINKO_KOZA = "COM_GET_MS_GINKO_KOZA";
    /** 共通マスタ取得.会社名取得 */
    public static final String COM_GET_KAISHA_MEI = "COM_GET_KAISHA_MEI";
    /** 共通マスタ取得.サブ組織名取得 */
    public static final String COM_GET_SUB_SOSHIKI_MEI = "COM_GET_SUB_SOSHIKI_MEI";
    /** 共通マスタ取得.ロール取得 */
    public static final String COM_GET_MS_ROLE = "COM_GET_MS_ROLE";
    /** 共通マスタ取得.機能グループ取得 */
    public static final String COM_GET_MS_KINO_GROUP = "COM_GET_MS_KINO_GROUP";
    /** 共通マスタ取得.機能グループ種別取得 */
    public static final String COM_GET_MS_KINO_GROUP_SHUBETSU = "COM_GET_MS_KINO_GROUP_SHUBETSU";
    /** 共通マスタ取得.航空会社取得 */
    public static final String COM_GET_MS_KOKU_GAISHA = "COM_GET_MS_KOKU_GAISHA";
    /** 共通マスタ取得.処理科目コード取得 */
    public static final String COM_GET_SHORI_KAMOKU_CD = "COM_GET_SHORI_KAMOKU_CD";
    /** 共通マスタ取得.補助科目コード取得 */
    public static final String COM_GET_HOJO_KAMOKU_CD = "COM_GET_HOJO_KAMOKU_CD";
    /** 共通マスタ取得.号車マスタ取得 */
    public static final String COM_GET_VW_GOSHA = "COM_GET_VW_GOSHA";
    /** 共通マスタ取得.車両マスタ取得 */
    public static final String COM_GET_VW_SHARYO = "COM_GET_VW_SHARYO";
    /** 共通マスタ取得.ユーザーマスタ取得 */
    public static final String COM_GET_VW_USER = "COM_GET_VW_USER";
    /** 共通マスタ取得.JISコードマスタ取得 */
    public static final String COM_GET_VW_JIS_CD = "COM_GET_VW_JIS_CD";
    /** 共通マスタ取得.料金項目グループマスタ取得 */
    public static final String COM_GET_MS_RYOKIN_KOMOKU_GROUP = "COM_GET_MS_RYOKIN_KOMOKU_GROUP";
    /** 共通マスタ取得.卸計上箇所取得 */
    public static final String COM_GET_OROSHI_KEIJO_KASHO = "COM_GET_OROSHI_KEIJO_KASHO";
    /** 共通マスタ取得.顧客取得 */
    public static final String COM_GET_VW_KOKYAKU = "COM_GET_VW_KOKYAKU";
    /** 共通マスタ取得.代理店取得 */
    public static final String COM_GET_VW_DAIRITEN = "COM_GET_VW_DAIRITEN";
    /** 共通マスタ取得.記事取得 */
    public static final String COM_GET_MS_KIJI = "COM_GET_MS_KIJI";
    /** 共通マスタ取得.付帯料金項目1取得 */
    public static final String COM_GET_VW_FUTAI_RYOKIN_KOMOKU1 = "COM_GET_VW_FUTAI_RYOKIN_KOMOKU1";
    /** 共通マスタ取得.付帯料金項目2取得 */
    public static final String COM_GET_VW_FUTAI_RYOKIN_KOMOKU2 = "COM_GET_VW_FUTAI_RYOKIN_KOMOKU2";
    /** 共通マスタ取得.単位マスタ取得 */
    public static final String COM_GET_MS_TANI = "COM_GET_MS_TANI";
    /** 共通マスタ取得.施設取得 */
    public static final String COM_GET_VW_SHISETSU = "COM_GET_VW_SHISETSU";
    /** 共通マスタ取得.消費税取得 */
    public static final String COM_GET_VW_SHOHIZEI = "COM_GET_VW_SHOHIZEI";
    /** 共通マスタ取得.システム名称マスタ取得 */
    public static final String COM_GET_MS_SYSTEM_MEISHO = "COM_GET_MS_SYSTEM_MEISHO";
    /** 共通マスタ取得.機能取得 */
    public static final String COM_GET_MS_KINO = "COM_GET_MS_KINO";
    /** 共通マスタ取得.システムIF種別名取得 */
    public static final String COM_GET_MS_SYSTEM_IF_SHUBETSU = "COM_GET_MS_SYSTEM_IF_SHUBETSU";
    /** 共通マスタ取得.バッチ名称マスタ取得 */
    public static final String COM_GET_MS_BATCH_MEISHO = "COM_GET_MS_BATCH_MEISHO";
    /** 共通マスタ取得.アップロード機能マスタ取得 */
    public static final String COM_GET_MS_UPLOAD_KINO = "COM_GET_MS_UPLOAD_KINO";
    /** 共通マスタ取得.データファイル名取得 */
    public static final String COM_GET_DATA_FILE_MEI = "COM_GET_DATA_FILE_MEI";
    /** 共通マスタ取得.スクリプト名取得 */
    public static final String COM_GET_MS_SCRIPT = "COM_GET_MS_SCRIPT";
    /** 共通マスタ取得.発地（検索条件）取得 */
    public static final String COM_GET_HATSUCHI_KENSAKU_JOKEN = "COM_GET_HATSUCHI_KENSAKU_JOKEN";
    /** 共通マスタ取得.着地（検索条件）取得 */
    public static final String COM_GET_CHAKUCHI_KENSAKU_JOKEN = "COM_GET_CHAKUCHI_KENSAKU_JOKEN";
    /** 共通マスタ取得.発地（一覧）取得 */
    public static final String COM_GET_HATSUCHI_ICHIRAN = "COM_GET_HATSUCHI_ICHIRAN";
    /** 共通マスタ取得.着地（一覧）取得 */
    public static final String COM_GET_CHAKUCHI_ICHIRAN = "COM_GET_CHAKUCHI_ICHIRAN";
    /** 共通マスタ取得.経由地1（一覧）取得 */
    public static final String COM_GET_KEIYUCHI1_ICHIRAN = "COM_GET_KEIYUCHI1_ICHIRAN";
    /** 共通マスタ取得.経由地2（一覧）取得 */
    public static final String COM_GET_KEIYUCHI2_ICHIRAN = "COM_GET_KEIYUCHI2_ICHIRAN";
    /** 共通マスタ取得.経由地3（一覧）取得 */
    public static final String COM_GET_KEIYUCHI3_ICHIRAN = "COM_GET_KEIYUCHI3_ICHIRAN";
    /** 共通マスタ取得.法人グループ取得 */
    public static final String COM_GET_MS_HOJIN_GROUP = "COM_GET_MS_HOJIN_GROUP";
    /** 共通マスタ取得.郵便番号JIS取得 */
    public static final String COM_GET_MS_YUBIN_BANGO = "COM_GET_MS_YUBIN_BANGO";
    /** 共通マスタ取得.企業集約コード取得 */
    public static final String COM_GET_KIGYO_SHUYAKU_CD = "COM_GET_KIGYO_SHUYAKU_CD";
    /** 共通マスタ取得.集約コード（営業所）取得 */
    public static final String COM_GET_SHUYAKU_CD_EIGYOSHO = "COM_GET_SHUYAKU_CD_EIGYOSHO";
    /** 共通マスタ取得.集約コード（本社）取得 */
    public static final String COM_GET_SHUYAKU_CD_HONSHA = "COM_GET_SHUYAKU_CD_HONSHA";
    /** 共通マスタ取得.集約コード（その他）取得 */
    public static final String COM_GET_SHUYAKU_CD_SONOTA = "COM_GET_SHUYAKU_CD_SONOTA";
    /** 共通マスタ取得.営業担当者取得 */
    public static final String COM_GET_EIGYO_TANTOSHA = "COM_GET_EIGYO_TANTOSHA";
    /** 共通マスタ取得.契約先顧客取得 */
    public static final String COM_GET_KEIYAKU_KOKYAKU = "COM_GET_KEIYAKU_KOKYAKU";
    /** 共通マスタ取得.卸科目コード取得 */
    public static final String COM_GET_OROSHI_KAMOKU_CD = "COM_GET_OROSHI_KAMOKU_CD";
    /** 共通マスタ取得.ロジ料金項目取得 */
    public static final String COM_GET_LOGI_RYOKIN_KOMOKU_CD = "COM_GET_LOGI_RYOKIN_KOMOKU_CD";
    /** 共通マスタ取得.作業ランク取得 */
    public static final String COM_GET_SAGYO_RANK = "COM_GET_SAGYO_RANK";
    /** 共通マスタ取得.ロジ施設情報取得 */
    public static final String COM_GET_LOGI_SHISETSU_JOHO = "COM_GET_LOGI_SHISETSU_JOHO";
    /** 共通マスタ取得.集配料金表年度取得 */
    public static final String COM_GET_SHUHAI_RYOKINHYO_CATEGORY = "COM_GET_SHUHAI_RYOKINHYO_CATEGORY";
    /** 共通マスタ取得.集配料金表料金表名取得 */
    public static final String COM_GET_SHUHAI_RYOKINHYO_MEISHO = "COM_GET_SHUHAI_RYOKINHYO_MEISHO";
    /** 共通マスタ取得.航空運賃表年度取得 */
    public static final String COM_GET_KOKU_UNCHINHYO_NENDO = "COM_GET_KOKU_UNCHINHYO_NENDO";
    /** 共通マスタ取得.航空運賃表料金表名取得 */
    public static final String COM_GET_KOKU_UNCHINHYO_MEI = "COM_GET_KOKU_UNCHINHYO_MEI";
    /** 共通マスタ取得.付帯料金項目取得 */
    public static final String COM_GET_FUTAI_RYOKIN_KOMOKU = "COM_GET_FUTAI_RYOKIN_KOMOKU";
    /** 共通マスタ取得.支店営業所取得 */
    public static final String COM_GET_SHITEN_MEI = "COM_GET_SHITEN_MEI";
    /** 共通マスタ取得.見積り備考取得 */
    public static final String COM_GET_MITSUMORI_BIKO = "COM_GET_MITSUMORI_BIKO";
    /** 共通マスタ取得.ドライバー取得 */
    public static final String COM_GET_DRIVER = "COM_GET_DRIVER";
    /** 共通マスタ取得.仕向地コード住所取得 */
    public static final String COM_GET_SHIMUKE_CHI_CD_JUSHO = "COM_GET_SHIMUKE_CHI_CD_JUSHO";
    /** 共通マスタ取得.営業所代理店取得 */
    public static final String COM_GET_EIGYOSHO_DAIRITEN = "COM_GET_EIGYOSHO_DAIRITEN";
    /** 共通マスタ取得.輸送方法取得 */
    public static final String COM_GET_YUSO_HOHO = "COM_GET_YUSO_HOHO";
    /** 共通マスタ取得.ユーザーマスタ（未来所属含む）取得 */
    public static final String COM_GET_VW_USER_MIRAI = "COM_GET_VW_USER_MIRAI";
    /** 共通マスタ取得.チャーター付帯料金項目取得 */
    public static final String COM_GET_CHARTER_FUTAI_RYOKIN_KOMOKU = "COM_GET_CHARTER_FUTAI_RYOKIN_KOMOKU";
    /** 共通マスタ取得.付帯料金項目(その他請求)取得 */
    public static final String COM_GET_VW_FUTAI_RYOKIN_KOMOKU_SONOTA_SEIKYU = "COM_GET_VW_FUTAI_RYOKIN_KOMOKU_SONOTA_SEIKYU";
    /** 共通マスタ取得.請求先顧客取得 */
    public static final String COM_GET_SEIKYU_KOKYAKU = "COM_GET_SEIKYU_KOKYAKU";
    /** 共通マスタ取得.送り状マスタ参照顧客取得 */
    public static final String COM_GET_OKURIJO_MASTER_KOKYAKU = "COM_GET_OKURIJO_MASTER_KOKYAKU";
    /** 共通マスタ取得.輸送請求書料金項目パターン取得 */
    public static final String COM_GET_YUSO_SEIKYUSHO_RYOKIN_PTN = "COM_GET_YUSO_SEIKYUSHO_RYOKIN_PTN";
    /** 共通マスタ取得.法人グループ設定取得 */
    public static final String COM_GET_MS_HOJIN_GROUP_SETTEI = "COM_GET_MS_HOJIN_GROUP_SETTEI";
    /** 共通マスタ取得.町字取得 */
    public static final String COM_GET_CHOAZA = "COM_GET_CHOAZA";
    /** 共通マスタ取得.輸送請求項目名称マスタ */
    public static final String COM_GET_MS_YUSO_SEIKYU_KOMOKU_MEISHO = "COM_GET_MS_YUSO_SEIKYU_KOMOKU_MEISHO";
    /** 車種取得 */
    public static final String COM_GET_SHASHU = "COM_GET_SHASHU";
    /** 仕向地名取得 */
    public static final String COM_GET_SHIMUKE_CHI_MEI = "COM_GET_SHIMUKE_CHI_MEI";

    /** 区分マスタ.営業所種別 */
    public static final String SALES_OFFICE_TYPE = "SALES_OFFICE_TYPE";
    /** 区分マスタ.休日区分 */
    public static final String BUSINESS_HOLIDAY_TYPE = "BUSINESS_HOLIDAY_TYPE";
    /** 区分マスタ.顧客登録区分 */
    public static final String CUSTOMER_RSV_TYPE = "CUSTOMER_RSV_TYPE";
    /** 区分マスタ.顧客メモ重要度 */
    public static final String CUSTOMER_MEMO_PRIORITY = "CUSTOMER_MEMO_PRIORITY";
    /** 区分マスタ.税区分 */
    public static final String TAX_TYPE = "TAX_TYPE";
    /** 区分マスタ.請求状態区分 */
    public static final String SEIKYU_JOTAI_TYPE = "SEIKYU_JOTAI_TYPE";
    /** 区分マスタ.済区分 */
    public static final String SUMI_TYPE = "SUMI_TYPE";
    /** 区分マスタ.再締対象区分 */
    public static final String SAISHIME_TAISHO_TYPE = "SAISHIME_TAISHO_TYPE";
    /** 区分マスタ.未請求区分 */
    public static final String MISEIKYU_TYPE = "MISEIKYU_TYPE";
    /** 区分マスタ.締区分 */
    public static final String SHIME_TYPE = "SHIME_TYPE";
    /** 区分マスタ.回収状態 */
    public static final String KAISYU_TYPE = "KAISYU_TYPE";
    /** 区分マスタ.請求書エラー区分 */
    public static final String SEIKYUSHO_ERROR_TYPE = "SEIKYUSHO_ERROR_TYPE";
    /** 区分マスタ.表示基準 */
    public static final String HYOJI_KIJUN = "HYOJI_KIJUN";
    /** 区分マスタ.元着区分 */
    public static final String MOTO_CHAKU_KBN = "MOTO_CHAKU_KBN";
    /** 区分マスタ.印刷請求書 */
    public static final String INSATU_SEIKYUSHO_STATUS = "INSATU_SEIKYUSHO_STATUS";
    /** 区分マスタ.Web請求書 */
    public static final String WEB_SEIKYUSHO_STATUS = "WEB_SEIKYUSHO_STATUS";
    /** 区分マスタ.とりまとめ請求 */
    public static final String TORIMATOME_SEIKYUS_STATUS = "TORIMATOME_SEIKYUS_STATUS";
    /** 区分マスタ.締日選択 */
    public static final String SIMEBI_SELECT = "SIMEBI_SELECT";
    /** 区分マスタ.請求書発行ソート */
    public static final String SEIKYUSHO_HAKKO_SORT = "SEIKYUSHO_HAKKO_SORT";
    /** 区分マスタ.請求書チェック */
    public static final String SEIKYUSHO_CHECK_KBN = "SEIKYUSHO_CHECK_KBN";
    /** 区分マスタ.請求書詳細入金方法 */
    public static final String SEIKYUSHO_SHOSAI_NYUKINHOUHOU = "SEIKYUSHO_SHOSAI_NYUKINHOUHOU";
    /** 区分マスタ.通知方法 */
    public static final String TSUCHI_HOHO = "TSUCHI_HOHO";
    /** 区分マスタ.見積ステータス（画面検索条件） */
    public static final String ESTIMATION_STATUS_SEARCH = "ESTIMATION_STATUS_SEARCH";
    /** 区分マスタ.元着引取区分（見積用） */
    public static final String TRANSACTION_TYPE = "TRANSACTION_TYPE";
    /** 区分マスタ.顧客別／テンプレート／標準料金 */
    public static final String ESTIMATION_KIND = "ESTIMATION_KIND";
    /** 区分マスタ.見積り種類 */
    public static final String ESTIMATION_TYPE = "ESTIMATION_TYPE";
    /** 区分マスタ.見積り登録区分 */
    public static final String ESTIMATION_ENTRY_KBN = "ESTIMATION_ENTRY_KBN";
    /** 区分マスタ.値引（割増）/割戻 */
    public static final String DISCOUNT_KBN = "DISCOUNT_KBN";
    /** 区分マスタ.顧客区分 */
    public static final String KOKYAKU_KBN = "KOKYAKU_KBN";
    /** 区分マスタ.顧客種別 */
    public static final String KOKYAKU_SHUBETSU = "KOKYAKU_SHUBETSU";
    /** 区分マスタ.申請一覧操作区分 */
    public static final String SHINSEI_ICHIRAN_SOSA_KBN = "SHINSEI_ICHIRAN_SOSA_KBN";
    /** 区分マスタ.適用終了 */
    public static final String TEKIYO_SHURYO = "TEKIYO_SHURYO";
    /** 区分マスタ.申請一覧チェックボックス */
    public static final String SHINSEI_ICHIRAN_CHECK_BOX = "SHINSEI_ICHIRAN_CHECK_BOX";
    /** 区分マスタ.料金種類区分 */
    public static final String FARE_TYPE = "FARE_TYPE";
    /** 区分マスタ.値引(割増)/割戻単位区分 */
    public static final String DISCOUNT_UNIT = "DISCOUNT_UNIT";
    /** 区分マスタ.運賃計算パターン */
    public static final String FARE_CALCULATE_PATTERN = "FARE_CALCULATE_PATTERN";
    /** 区分マスタ.増区分 */
    public static final String INCREASE_TYPE = "INCREASE_TYPE";
    /** 区分マスタ.小数点区分 */
    public static final String DECIMAL_TYPE = "DECIMAL_TYPE";
    /** 区分マスタ.割増区分 */
    public static final String EXTRA_TYPE = "EXTRA_TYPE";
    /** 区分マスタ.パワーゲート　割増区分 */
    public static final String POWER_GATE_EXTRA_TYPE = "POWER_GATE_EXTRA_TYPE";
    /** 区分マスタ.エアサス　割増区分 */
    public static final String AIR_SUS_EXTRA_TYPE = "AIR_SUS_EXTRA_TYPE";
    /** 区分マスタ.空調　割増区分 */
    public static final String AIR_CONDITIONER_EXTRA_TYPE = "AIR_CONDITIONER_EXTRA_TYPE";
    /** 区分マスタ.発地着地区分 */
    public static final String FROM_TO_AREA_KBN = "FROM_TO_AREA_KBN";
    /** 区分マスタ.見積ステータス */
    public static final String ESTIMATION_STATUS = "ESTIMATION_STATUS";
    /** 区分マスタ.チャーター区分 */
    public static final String CHARTER_TYPE = "CHARTER_TYPE";
    /** 区分マスタ.売上区分 */
    public static final String SALES_TYPE = "SALES_TYPE";
    /** 区分マスタ.支払区分 */
    public static final String PAYMENT_TYPE = "PAYMENT_TYPE";
    /** 区分マスタ.引取区分 */
    public static final String HIKITORI_KBN = "HIKITORI_KBN";
    /** 区分マスタ.集荷指示 */
    public static final String PICKUP_INDICATION = "PICKUP_INDICATION";
    /** 区分マスタ.配達指示 */
    public static final String DELIVERY_INDICATION = "DELIVERY_INDICATION";
    /** 区分マスタ.伝票種別 */
    public static final String INVOICE_TYPE = "INVOICE_TYPE";
    /** 区分マスタ.輸送方法 */
    public static final String TRANSPORTATION = "TRANSPORTATION";
    /** 区分マスタ.運賃計算パターン（ロジ料金） */
    public static final String UNCHIN_KEISAN_PTN_LOGI_RYOKIN = "UNCHIN_KEISAN_PTN_LOGI_RYOKIN";
    /** 区分マスタ.顧客種別(省略) */
    public static final String KOKYAKU_SYUBETU_RYAKU = "KOKYAKU_SYUBETU_RYAKU";
    /** 区分マスタ.顧客状態 */
    public static final String KOKYAKU_STATUS = "KOKYAKU_STATUS";
    /** 区分マスタ.送り状登録区分 */
    public static final String OKURIJO_RSV_TYPE = "OKURIJO_RSV_TYPE";
    /** 区分マスタ.送り状荷札発行状態 */
    public static final String OKURIJO_NIFUDA_HAAKO_STATUS = "OKURIJO_NIFUDA_HAAKO_STATUS";
    /** 区分マスタ.データ元_輸送その他 */
    public static final String DATA_MOTO_YUSOU_SONOTA_TYPE = "DATA_MOTO_YUSOU_SONOTA_TYPE";
    /** 区分マスタ.データ元_ロジ */
    public static final String DATA_MOTO_LOGI_TYPE = "DATA_MOTO_LOGI_TYPE";
    /** 区分マスタ.チェックステータス */
    public static final String CHECK_STATUS_TYPE = "CHECK_STATUS_TYPE";
    /** 区分マスタ.入力箇所 */
    public static final String NYURYOKU_KASHO_TYPE = "NYURYOKU_KASHO_TYPE";
    /** 区分マスタ.新規修正 */
    public static final String SHINKI_SHUSEI_TYPE = "SHINKI_SHUSEI_TYPE";
    /** 区分マスタ.注意宛先 */
    public static final String TYUUI_ATESAKI_TYPE = "TYUUI_ATESAKI_TYPE";
    /** 区分マスタ.卸値変更あり */
    public static final String OROSHINE_HENKO_ARI_TYPE = "OROSHINE_HENKO_ARI_TYPE";
    /** 区分マスタ.輸送売上ステータス */
    public static final String YUSO_URIAGE_STATUS = "YUSO_URIAGE_STATUS";
    /** 区分マスタ.プルーフチェックステータス */
    public static final String PROOF_CHECK_STATUS = "PROOF_CHECK_STATUS";
    /** 区分マスタ.条件外未収ランク */
    public static final String JOKEN_GAI_MISHU_RANK = "JOKEN_GAI_MISHU_RANK";
    /** 区分マスタ.課税区分 */
    public static final String TAXATION_TYPE = "TAXATION_TYPE";
    /** 区分マスタ.Web請求書利用 */
    public static final String WEB_SEIKYUSHO_RIYOU = "WEB_SEIKYUSHO_RIYOU";
    /** 区分マスタ.ＣＳＶダウンロード */
    public static final String CSV_DOWNLOAD = "CSV_DOWNLOAD";
    /** 区分マスタ.請求基準 */
    public static final String SEIKYU_KIJUN = "SEIKYU_KIJUN";
    /** 区分マスタ.請求書チェック */
    public static final String SEIKYUSHO_CHECK = "SEIKYUSHO_CHECK";
    /** 区分マスタ.月末土日入金 */
    public static final String GETSUMATSU_DONICHI_NYUKIN = "GETSUMATSU_DONICHI_NYUKIN";
    /** 区分マスタ.支払方法 */
    public static final String SHIHARAI_HOHO = "SHIHARAI_HOHO";
    /** 区分マスタ.支払サイト */
    public static final String SHIHARAI_SITE = "SHIHARAI_SITE";
    /** 区分マスタ.口座選択方法 */
    public static final String KOZA_SENTAKU_HOHO = "KOZA_SENTAKU_HOHO";
    /** 区分マスタ.口座種別 */
    public static final String KOZA_SHUBETSU = "KOZA_SHUBETSU";
    /** 区分マスタ.伝まる登録 */
    public static final String DEMMARU_TOROKU = "DEMMARU_TOROKU";
    /** 区分マスタ.住所名称の表示 */
    public static final String JUSHO_MEISHO_NO_HYOJI = "JUSHO_MEISHO_NO_HYOJI";
    /** 区分マスタ.小計のありなし */
    public static final String SHOKEI_UMU = "SHOKEI_UMU";
    /** 区分マスタ.取引承認 */
    public static final String TORIHIKI_SHONIN = "TORIHIKI_SHONIN";
    /** 区分マスタ.売上入力デフォルト画面 */
    public static final String URIAGE_NYURYOKU_DEFAULT_GAMEN = "URIAGE_NYURYOKU_DEFAULT_GAMEN";
    /** 区分マスタ.その他備考 */
    public static final String SONOTA_BIKO = "SONOTA_BIKO";
    /** 区分マスタ.承認箇所区分 */
    public static final String SHONIN_KASHO_KBN = "SHONIN_KASHO_KBN";
    /** 区分マスタ.パック料金重量増区分 */
    public static final String PAC_WEIGHT_INCREASE_TYPE = "PAC_WEIGHT_INCREASE_TYPE";
    /** 区分マスタ.パック料金重量増区分 */
    public static final String PAC_NUMBER_INCREASE_TYPE = "PAC_NUMBER_INCREASE_TYPE";
    /** 区分マスタ.翌着予定日区分 */
    public static final String YOKUCHAKU_YOTEIBI_KBN = "YOKUCHAKU_YOTEIBI_KBN";
    /** 区分マスタ.到着時間帯区分 */
    public static final String TOCHAKU_JIKANTAI_KBN = "TOCHAKU_JIKANTAI_KBN";
    /** 区分マスタ.翌着可否 */
    public static final String YOKUCHAKU_KAHI = "YOKUCHAKU_KAHI";
    /** 区分マスタ.変更区分 */
    public static final String HENKO_KBN = "HENKO_KBN";
    /** 区分マスタ.適用終了表示用キャプション */
    public static final String TEKIYO_SHURYO_HYOJI_YO = "TEKIYO_SHURYO_HYOJI_YO";
    /** 区分マスタ.委託貨物照会　備考 */
    public static final String ITAKU_KAMOTSU_BIKO = "ITAKU_KAMOTSU_BIKO";
    /** 区分マスタ.データ入力元 */
    public static final String DATA_NYURYOKU_MOTO = "DATA_NYURYOKU_MOTO";
    /** 区分マスタ.申請種別 */
    public static final String SINSEI_SHUBETSU = "SINSEI_SHUBETSU";
    /** 区分マスタ.申請種別変更区分 */
    public static final String SINSEI_SHUBETSU_HENKO_KBN = "SINSEI_SHUBETSU_HENKO_KBN";
    /** 区分マスタ.I/F区分 */
    public static final String IF_TYPE = "IF_TYPE";
    /** 区分マスタ.赤黒区分 */
    public static final String AKA_KURO_TYPE = "AKA_KURO_TYPE";
    /** 区分マスタ.汎用フラグ */
    public static final String HANYO_FLG = "HANYO_FLG";
    /** 区分マスタ.ユーザーマスタ使用区分 */
    public static final String USER_MASTER_SIYO_KBN = "USER_MASTER_SIYO_KBN";
    /** 区分マスタ.輸送売上チェック判定ステータス */
    public static final String YUSO_URIAGE_CHECK_HANTEI_STATUS = "YUSO_URIAGE_CHECK_HANTEI_STATUS";
    /** 区分マスタ.業者区分 */
    public static final String GYOSHA_KBN = "GYOSHA_KBN";
    /** 区分マスタ.借方 科目１ */
    public static final String KARIKATA_KAMOKU1 = "KARIKATA_KAMOKU1";
    /** 区分マスタ.取引科目 */
    public static final String TORIHIKI_KAMOKU = "TORIHIKI_KAMOKU";
    /** 区分マスタ.貸方 科目１ */
    public static final String KASHIKATA_KAMOKU1 = "KASHIKATA_KAMOKU1";
    /** 区分マスタ.トレース入力状況 */
    public static final String TRACE_NYURYOKU_JOKYO = "TRACE_NYURYOKU_JOKYO";
    /** 区分マスタ.申請アクティビティ */
    public static final String SHINSEI_ACTIVITY = "SHINSEI_ACTIVITY";
    /** 区分マスタ.スキャン_エラー内容 */
    public static final String SCAN_ERROR_NAIYO = "SCAN_ERROR_NAIYO";
    /** 区分マスタ.増し区分 */
    public static final String MASHI_KBN = "MASHI_KBN";
    /** 区分マスタ.配達指定時刻_注釈 */
    public static final String HAITATSU_SHITEI_JIKOKU_CHUSHAKU = "HAITATSU_SHITEI_JIKOKU_CHUSHAKU";
    /** 区分マスタ.送り状管理_出力対象 */
    public static final String OKURIJO_KANRI_SHUTSU_TAISHO = "OKURIJO_KANRI_SHUTSU_TAISHO";
    /** 区分マスタ.送り状荷札_発行区分 */
    public static final String OKURIJO_NIFUDA_HAKKO_KBN = "OKURIJO_NIFUDA_HAKKO_KBN";
    /** 区分マスタ.送り状再発行区分 */
    public static final String OKURIJO_SAI_HAKKO_KBN = "OKURIJO_SAI_HAKKO_KBN";
    /** 区分マスタ.送り状発行先区分 */
    public static final String OKURIJO_HAKKO_SAKI_KBN = "OKURIJO_HAKKO_SAKI_KBN";
    /** 区分マスタ.重量区分 */
    public static final String JURYO_KUBUN = "JURYO_KUBUN";
    /** 区分マスタ.往復区分 */
    public static final String OFUKU_KUBUN = "OFUKU_KUBUN";
    /** 区分マスタ.新規使用可否 */
    public static final String SHINKI_SIYO_KAHI = "SHINKI_SIYO_KAHI";
    /** 区分マスタ.運賃種別 */
    public static final String UNCHIN_SHUBETSU = "UNCHIN_SHUBETSU";
    /** 区分マスタ.仕入予定一覧_単位 */
    public static final String SHIIRE_YOTEI_ICHIRAN_TANI = "SHIIRE_YOTEI_ICHIRAN_TANI";
    /** 区分マスタ.入金方法 */
    public static final String NYUKIN_HOHO_KBN = "NYUKIN_HOHO_KBN";
    /** 区分マスタ.送り状NO入力元 */
    public static final String OKURIJO_NO_NYURYOKU_MOTO = "OKURIJO_NO_NYURYOKU_MOTO";
    /** 区分マスタ.JISチェック結果 */
    public static final String JIS_CHECK_KEKKA = "JIS_CHECK_KEKKA";
    /** 区分マスタ.緊急度 */
    public static final String KINKYUDO = "KINKYUDO";
    /** 区分マスタ.メッセージ種別 */
    public static final String MESSAGE_SHUBETSU = "MESSAGE_SHUBETSU";
    /** 区分マスタ.無効のみ検索表示用キャプション */
    public static final String MUKOU_NOMI_KENSAKU = "MUKOU_NOMI_KENSAKU";
    /** 区分マスタ.通知エリア表示有無 */
    public static final String TSUCHI_AREA_HYOJI_UMU = "TSUCHI_AREA_HYOJI_UMU";
    /** 区分マスタ.仕入予定単位 */
    public static final String SHIIRE_YOTEI_TANI = "SHIIRE_YOTEI_TANI";
    /** 区分マスタ.通知エリア表示期間 */
    public static final String TSUCHI_AREA_HYOJI_KIKAN = "TSUCHI_AREA_HYOJI_KIKAN";
    /** 区分マスタ.対応要否 */
    public static final String TAIO_YOHI = "TAIO_YOHI";
    /** 区分マスタ.有効無効 */
    public static final String YUKO_MUKO = "YUKO_MUKO";
    /** 区分マスタ.送信先区分 */
    public static final String SOSHINSAKI_KBN = "SOSHINSAKI_KBN";
    /** 区分マスタ.通知エリア表示一覧用 */
    public static final String TSUCHI_AREA_HYOJI_ICHIRAN_YO = "TSUCHI_AREA_HYOJI_ICHIRAN_YO";
    /** 区分マスタ.通知エリア表示期限 */
    public static final String TSUCHI_AREA_HYOJI_KIGEN = "TSUCHI_AREA_HYOJI_KIGEN";
    /** 区分マスタ.曜日 */
    public static final String YOBI = "YOBI";
    /** 区分マスタ.カレンダーチェックボックス */
    public static final String CALENDAR_CHECKBOX = "CALENDAR_CHECKBOX";
    /** 区分マスタ.カレンダーラジオボタン */
    public static final String CALENDAR_RADIO = "CALENDAR_RADIO";
    /** 区分マスタ.設定済区分 */
    public static final String SETTEISUMI_KUBUN = "SETTEISUMI_KUBUN";
    /** 区分マスタ.送信対象トレース */
    public static final String SOSHIN_TAISHO_TRACE = "SOSHIN_TAISHO_TRACE";
    /** 区分マスタ.料金項目明細区分 */
    public static final String RYOKIN_KOMOKU_MEISAI_KBN = "RYOKIN_KOMOKU_MEISAI_KBN";
    /** 区分マスタ.料金項目明細項目 */
    public static final String RYOKIN_KOMOKU_MEISAI_KOMOKU = "RYOKIN_KOMOKU_MEISAI_KOMOKU";
    /** 区分マスタ.料金項目固定項目コード */
    public static final String RYOKIN_KOMOKU_KOTEI_KOMOKU_CD = "RYOKIN_KOMOKU_KOTEI_KOMOKU_CD";
    /** 区分マスタ.プルーフ用集約項目 */
    public static final String PROOF_YOU_SHUYAKU_KOMOKU = "PROOF_YOU_SHUYAKU_KOMOKU";
    /** 区分マスタ.卸計上箇所 */
    public static final String OROSHI_KEIJO_KASHO = "OROSHI_KEIJO_KASHO";
    /** 区分マスタ.卸値計算パターン */
    public static final String OROSHI_KEISAN_PATTERN = "OROSHI_KEISAN_PATTERN";
    /** 区分マスタ.売上セット先 */
    public static final String URIAGE_SET_SAKI = "URIAGE_SET_SAKI";
    /** 区分マスタ.世代検索条件 */
    public static final String SEDAI_KENSAKU_JOKEN = "SEDAI_KENSAKU_JOKEN";
    /** 区分マスタ.代理店使用区分 */
    public static final String DAIRITEN_SIYO_KUBUN = "DAIRITEN_SIYO_KUBUN";
    /** 区分マスタ.画面表示用フラグ文字 */
    public static final String GAMEN_HYOJIYO_FLG_MOJI = "GAMEN_HYOJIYO_FLG_MOJI";
    /** 区分マスタ.画面表示用フラグ記号 */
    public static final String GAMEN_HYOJIYO_FLG_KIGO = "GAMEN_HYOJIYO_FLG_KIGO";
    /** 区分マスタ.集約コード区分 */
    public static final String SHUYAKU_CD_KBN = "SHUYAKU_CD_KBN";
    /** 区分マスタ.制御区分 */
    public static final String SEIGYO_KBN = "SEIGYO_KBN";
    /** 区分マスタ.送り状管理単位 */
    public static final String OKURIJO_KANRI_TANI = "OKURIJO_KANRI_TANI";
    /** 区分マスタ.送り状チェックディジット */
    public static final String OKURIJO_CHECK_DIGIT = "OKURIJO_CHECK_DIGIT";
    /** 区分マスタ.送り状バーコード */
    public static final String OKURIJO_BARCODE = "OKURIJO_BARCODE";
    /** 区分マスタ.送り状スタートストップ */
    public static final String OKURIJO_START_STOP = "OKURIJO_START_STOP";
    /** 区分マスタ.荷札印字体系 */
    public static final String NIFUDA_INJI_TAIKEI = "NIFUDA_INJI_TAIKEI";
    /** 区分マスタ.荷札枝番体系 */
    public static final String NIFUDA_EDABAN_TAIKEI = "NIFUDA_EDABAN_TAIKEI";
    /** 区分マスタ.荷札バーコード */
    public static final String NIFUDA_BARCODE = "NIFUDA_BARCODE";
    /** 区分マスタ.荷札スタートストップ */
    public static final String NIFUDA_START_STOP = "NIFUDA_START_STOP";
    /** 区分マスタ.銀行口座種別 */
    public static final String GINKO_KOZA_SHUBETU = "GINKO_KOZA_SHUBETU";
    /** 区分マスタ.並び順 */
    public static final String NARABIJUN = "NARABIJUN";
    /** 区分マスタ.卸種別区分 */
    public static final String OROSHI_SYUBETU_KBN = "OROSHI_SYUBETU_KBN";
    /** 区分マスタ.デフォルトフラグ */
    public static final String DEFAULT_FLG = "DEFAULT_FLG";
    /** 区分マスタ.ユーザー使用区分 */
    public static final String USER_SIYO_KBN = "USER_SIYO_KBN";
    /** 区分マスタ.グループ紐付け区分 */
    public static final String GROUP_HIMODUKE_KBN = "GROUP_HIMODUKE_KBN";
    /** 区分マスタ.機能種別 */
    public static final String KINO_SHUBETSU = "KINO_SHUBETSU";
    /** 区分マスタ.利用設定 */
    public static final String RIYO_SETTEI = "RIYO_SETTEI";
    /** 区分マスタ.デフォルトルート検索 */
    public static final String DEFAULT_ROUTE_KENSAKU = "DEFAULT_ROUTE_KENSAKU";
    /** 区分マスタ.手数料負担 */
    public static final String TESURYO_FUTAN = "TESURYO_FUTAN";
    /** 区分マスタ.支払条件 */
    public static final String SHIHARAI_JOKEN = "SHIHARAI_JOKEN";
    /** 区分マスタ.買掛金コード */
    public static final String KAIKAKEKIN_CD = "KAIKAKEKIN_CD";
    /** 区分マスタ.販売形態区分 */
    public static final String HANBAI_KETAI_KBN = "HANBAI_KETAI_KBN";
    /** 区分マスタ.付帯料金項目_売上区分 */
    public static final String FUTAI_RYOKIN_KOMOKU_SALES_TYPE = "FUTAI_RYOKIN_KOMOKU_SALES_TYPE";
    /** 区分マスタ.管轄区分 */
    public static final String KANKATSU_KBN = "KANKATSU_KBN";
    /** 区分マスタ.使用区分 */
    public static final String SHIYO_KBN = "SHIYO_KBN";
    /** 区分マスタ.削除済のみ */
    public static final String SAKUJO_SUMI_NOMI = "SAKUJO_SUMI_NOMI";
    /** 区分マスタ.運賃計算区分 */
    public static final String UNCHIN_KEISAN_KBN = "UNCHIN_KEISAN_KBN";
    /** 区分マスタ.車両一覧表示区分 */
    public static final String SHARYO_ITIRAN_HYOJI_KBN = "SHARYO_ITIRAN_HYOJI_KBN";
    /** 区分マスタ.承認区分 */
    public static final String SHONIN_KBN = "SHONIN_KBN";
    /** 区分マスタ.営業所マスタ_営業所種別 */
    public static final String MS_EIGYOSHO_SHUBETSU = "MS_EIGYOSHO_SHUBETSU";
    /** 区分マスタ.離島館内配送 */
    public static final String RITO_KANNAI_HAISO = "RITO_KANNAI_HAISO";
    /** 区分マスタ.離島有無 */
    public static final String RITO_UMU = "RITO_UMU";
    /** 区分マスタ.旧住所区分 */
    public static final String KYU_JUSHO_KBN = "KYU_JUSHO_KBN";
    /** 区分マスタ.営業所マスタ_使用区分 */
    public static final String MS_EIGYOSHO_SIYO_KBN = "MS_EIGYOSHO_SIYO_KBN";
    /** 区分マスタ.荷受人マスタ検索条件並び順 */
    public static final String NIUKENIN_MST_KENSAKUJOKEN_NARABIJUN = "NIUKENIN_MST_KENSAKUJOKEN_NARABIJUN";
    /** 区分マスタ.要修正分のみ */
    public static final String YOSHUSEIBUN_NOMI = "YOSHUSEIBUN_NOMI";
    /** 区分マスタ.旧住所警告分も表示 */
    public static final String KYU_JUSHO_KEIKOKUBUN_MO_HYOJI = "KYU_JUSHO_KEIKOKUBUN_MO_HYOJI";
    /** 区分マスタ.VOID入力_作業区分 */
    public static final String VOID_NYURYOKU_SAGYO_KBN = "VOID_NYURYOKU_SAGYO_KBN";
    /** 区分マスタ.料金表設定なし検索 */
    public static final String RYOKIN_HYO_SETTEI_NASHI_KENSAKU = "RYOKIN_HYO_SETTEI_NASHI_KENSAKU";
    /** 区分マスタ.デフォルトのみ検索 */
    public static final String DEFAULT_NOMI_KENSAKU = "DEFAULT_NOMI_KENSAKU";
    /** 区分マスタ.輸送売上セット先 */
    public static final String YUSOURIAGE_SET_SAKI = "YUSOURIAGE_SET_SAKI";
    /** 区分マスタ.所属終了含む検索 */
    public static final String SHOZOKU_SHURYO_FUKUMU_KENSAKU = "SHOZOKU_SHURYO_FUKUMU_KENSAKU";
    /** 区分マスタ.休日計上 */
    public static final String KYUJITSU_KEIJO = "KYUJITSU_KEIJO";
    /** 区分マスタ.理由・対処方法入力有無 */
    public static final String JOKEN_GAI_MISHU_RIYU_TAISHO_UMU = "JOKEN_GAI_MISHU_RIYU_TAISHO_UMU";
    /** 区分マスタ.ランク入力有無 */
    public static final String JOKEN_GAI_MISHU_RANK_UMU = "JOKEN_GAI_MISHU_RANK_UMU";
    /** 区分マスタ.残高有無 */
    public static final String JOKEN_GAI_MISHU_ZANDAKA_UMU = "JOKEN_GAI_MISHU_ZANDAKA_UMU";
    /** 区分マスタ.MAWB状況照会_使用区分 */
    public static final String MAWB_JYOKYO_SHOKAI_SIYO_KBN = "MAWB_JYOKYO_SHOKAI_SIYO_KBN";
    /** 区分マスタ.業務種別 */
    public static final String GYOMU_SHUBETSU = "GYOMU_SHUBETSU";
    /** 区分マスタ.予定表示切替 */
    public static final String YOTEI_HYOJI_KIRIKAE = "YOTEI_HYOJI_KIRIKAE";
    /** 区分マスタ.顧客EDI区分選択 */
    public static final String KOKYAKU_EDI_KBN_SENTAKU = "KOKYAKU_EDI_KBN_SENTAKU";
    /** 区分マスタ.EDI種別 */
    public static final String EDI_SHUBETSU = "EDI_SHUBETSU";
    /** 区分マスタ.添付ファイル設定 */
    public static final String TEMPU_FILE_SETTEI = "TEMPU_FILE_SETTEI";
    /** 区分マスタ.パスワード生成方式 */
    public static final String PASSWORD_SEISEI_HOSHIKI = "PASSWORD_SEISEI_HOSHIKI";
    /** 区分マスタ.パスワード送付 */
    public static final String PASSWORD_SOFU = "PASSWORD_SOFU";
    /** 区分マスタ.ファイルタイプ */
    public static final String FILE_TYPE = "FILE_TYPE";
    /** 区分マスタ.実行タイミング区分 */
    public static final String JIKKO_TIMMING_KBN = "JIKKO_TIMMING_KBN";
    /** 区分マスタ.休日送信設定 */
    public static final String KYUJITSU_SOSHIN_SETTEI = "KYUJITSU_SOSHIN_SETTEI";
    /** 区分マスタ.請求情報_送信区分 */
    public static final String SEIKYU_INFO_SOSHIN_KBN = "SEIKYU_INFO_SOSHIN_KBN";
    /** 区分マスタ.メール設定_送信区分 */
    public static final String MAIL_SETTEI_SOSHIN_KBN = "MAIL_SETTEI_SOSHIN_KBN";
    /** 区分マスタ.現金回収_支払区分 */
    public static final String GENKIN_KAISHU_SHIHARAI_KBN = "GENKIN_KAISHU_SHIHARAI_KBN";
    /** 区分マスタ.現金回収_状態 */
    public static final String GENKIN_KAISHU_JOTAI = "GENKIN_KAISHU_JOTAI";
    /** 区分マスタ.申請ステータス */
    public static final String SHINSEI_STATUS = "SHINSEI_STATUS";
    /** 区分マスタ.JISコードのみ */
    public static final String JIS_CD_NOMI = "JIS_CD_NOMI";
    /** 区分マスタ.未使用MAWB表示 */
    public static final String MISHIYO_MAWB_HYOJI = "MISHIYO_MAWB_HYOJI";
    /** 区分マスタ.荷受人マスタ_旧住所区分 */
    public static final String MS_NIUKENIN_KYU_JUSHO_KBN = "MS_NIUKENIN_KYU_JUSHO_KBN";
    /** 区分マスタ.荷受人マスタ_エラー内容 */
    public static final String MS_NIUKENIN_ERROR_NAIYO = "MS_NIUKENIN_ERROR_NAIYO";
    /** 区分マスタ.小計位置 */
    public static final String SUBTOTAL_POSITION = "SUBTOTAL_POSITION";
    /** 区分マスタ.売上入力の個数を使用 */
    public static final String URIAGE_NYURYOKU_KOSU_SHIYO = "URIAGE_NYURYOKU_KOSU_SHIYO";
    /** 区分マスタ.備考段組み */
    public static final String BIKO_DANGUMI = "BIKO_DANGUMI";
    /** 区分マスタ.ハンディ持参区分 */
    public static final String HANDY_JISAN_KBN = "HANDY_JISAN_KBN";
    /** 区分マスタ.ノーマル運賃重量増区分 */
    public static final String NORMAL_WEIGHT_INCREASE_TYPE = "NORMAL_WEIGHT_INCREASE_TYPE";
    /** 区分マスタ.状態区分 */
    public static final String JOTAI_KBN = "JOTAI_KBN";
    /** 区分マスタ.登録区分 */
    public static final String TOROKU_KBN = "TOROKU_KBN";
    /** 区分マスタ.入力日付 */
    public static final String NYURYOKU_HIZUKE = "NYURYOKU_HIZUKE";
    /** 区分マスタ.見積りシミュレーション実行ステータス */
    public static final String SIM_JIKKO_STATUS = "SIM_JIKKO_STATUS";
    /** 区分マスタ.業種 */
    public static final String GYOSHU = "GYOSHU";
    /** 区分マスタ.KWE輸出入区分 */
    public static final String KWE_YUSHUTSUNYU_KBN = "KWE_YUSHUTSUNYU_KBN";
    /** 区分マスタ.消費税計算単位 */
    public static final String SHOHIZEI_KEISAN_TANI = "SHOHIZEI_KEISAN_TANI";
    /** 区分マスタ.重量区分 */
    public static final String JURYO_KBN = "JURYO_KBN";
    /** 区分マスタ.ロジ売上計算単位 */
    public static final String LOGI_URIAGE_KEISAN_TANI = "LOGI_URIAGE_KEISAN_TANI";
    /** 区分マスタ.請求書フォーム */
    public static final String SEIKYUSHO_FORM = "SEIKYUSHO_FORM";
    /** 区分マスタ.請求書並び順 */
    public static final String SEIKYUSHO_NARABIJUN = "SEIKYUSHO_NARABIJUN";
    /** 区分マスタ.摘要欄１ */
    public static final String TEKIYO_RAN_1 = "TEKIYO_RAN_1";
    /** 区分マスタ.摘要欄２ */
    public static final String TEKIYO_RAN_2 = "TEKIYO_RAN_2";
    /** 区分マスタ.送り状マスタ参照 */
    public static final String OKURIJOU_SANSYO = "OKURIJOU_SANSYO";
    /** 区分マスタ.申請ステータス（一覧） */
    public static final String SHINSEI_STATUS_ICHIRAN = "SHINSEI_STATUS_ICHIRAN";
    /** 区分マスタ.申請状況 */
    public static final String SHINSEI_JOKYO = "SHINSEI_JOKYO";
    /** 区分マスタ.サブ組織表示用キャプション */
    public static final String SUB_SOSHIKI_HYOJI_YO = "SUB_SOSHIKI_HYOJI_YO";
    /** 区分マスタ.集配地区 */
    public static final String SHUHAI_CHIKU = "SHUHAI_CHIKU";
    /** 区分マスタ.承認状況自動実行 */
    public static final String SHONIN_JOKYO_JIDO_JIKKO = "SHONIN_JOKYO_JIDO_JIKKO";

    /** 区分マスタ.営業所種別.営業所 */
    public static final String SALES_OFFICE_TYPE_EIGYOSHO = "SALES_OFFICE_TYPE_EIGYOSHO";
    /** 区分マスタ.営業所種別.オペセン */
    public static final String SALES_OFFICE_TYPE_OPE_CEN = "SALES_OFFICE_TYPE_OPE_CEN";
    /** 区分マスタ.営業所種別.FC */
    public static final String SALES_OFFICE_TYPE_FC = "SALES_OFFICE_TYPE_FC";
    /** 区分マスタ.営業所種別.営業部 */
    public static final String SALES_OFFICE_TYPE_EIGYO_BU = "SALES_OFFICE_TYPE_EIGYO_BU";
    /** 区分マスタ.休日区分.日祝 */
    public static final String BUSINESS_HOLIDAY_TYPE_NICHISHUKU = "BUSINESS_HOLIDAY_TYPE_NICHISHUKU";
    /** 区分マスタ.休日区分.毎週日曜 */
    public static final String BUSINESS_HOLIDAY_TYPE_MAISHU_NICHIYO = "BUSINESS_HOLIDAY_TYPE_MAISHU_NICHIYO";
    /** 区分マスタ.休日区分.毎週木曜 */
    public static final String BUSINESS_HOLIDAY_TYPE_MAISHU_MOKUYO = "BUSINESS_HOLIDAY_TYPE_MAISHU_MOKUYO";
    /** 区分マスタ.休日区分.土日 */
    public static final String BUSINESS_HOLIDAY_TYPE_DONICHI = "BUSINESS_HOLIDAY_TYPE_DONICHI";
    /** 区分マスタ.休日区分.毎週月曜 */
    public static final String BUSINESS_HOLIDAY_TYPE_MAISHU_GETSUYO = "BUSINESS_HOLIDAY_TYPE_MAISHU_GETSUYO";
    /** 区分マスタ.休日区分.毎週金曜 */
    public static final String BUSINESS_HOLIDAY_TYPE_MAISHU_KINYO = "BUSINESS_HOLIDAY_TYPE_MAISHU_KINYO";
    /** 区分マスタ.休日区分.土日祝 */
    public static final String BUSINESS_HOLIDAY_TYPE_DONICHISHUKU = "BUSINESS_HOLIDAY_TYPE_DONICHISHUKU";
    /** 区分マスタ.休日区分.毎週火曜 */
    public static final String BUSINESS_HOLIDAY_TYPE_MAISHU_KAYO = "BUSINESS_HOLIDAY_TYPE_MAISHU_KAYO";
    /** 区分マスタ.休日区分.毎週土曜 */
    public static final String BUSINESS_HOLIDAY_TYPE_MAISHU_DOYO = "BUSINESS_HOLIDAY_TYPE_MAISHU_DOYO";
    /** 区分マスタ.休日区分.毎週水曜 */
    public static final String BUSINESS_HOLIDAY_TYPE_MAISHU_SUIYO = "BUSINESS_HOLIDAY_TYPE_MAISHU_SUIYO";
    /** 区分マスタ.顧客登録区分.与信未チェック */
    public static final String CUSTOMER_RSV_TYPE_YOSHIN_MI_CHECK = "CUSTOMER_RSV_TYPE_YOSHIN_MI_CHECK";
    /** 区分マスタ.顧客登録区分.取引停止 */
    public static final String CUSTOMER_RSV_TYPE_TORIHIKI_TEISHI = "CUSTOMER_RSV_TYPE_TORIHIKI_TEISHI";
    /** 区分マスタ.顧客登録区分.与信チェック票出力済 */
    public static final String CUSTOMER_RSV_TYPE_YOSHIN_CHECK_HYO_SHUTSURYOKU_SUMI = "CUSTOMER_RSV_TYPE_YOSHIN_CHECK_HYO_SHUTSURYOKU_SUMI";
    /** 区分マスタ.顧客登録区分.取引停止／不良 */
    public static final String CUSTOMER_RSV_TYPE_TORIHIKI_TEISHI_FURYO = "CUSTOMER_RSV_TYPE_TORIHIKI_TEISHI_FURYO";
    /** 区分マスタ.顧客登録区分.正式登録 */
    public static final String CUSTOMER_RSV_TYPE_SEISHIKI_TOROKU = "CUSTOMER_RSV_TYPE_SEISHIKI_TOROKU";
    /** 区分マスタ.顧客登録区分.移転済 */
    public static final String CUSTOMER_RSV_TYPE_ITEN_SUMI = "CUSTOMER_RSV_TYPE_ITEN_SUMI";
    /** 区分マスタ.顧客登録区分.要調査 */
    public static final String CUSTOMER_RSV_TYPE_YO_CHOSA = "CUSTOMER_RSV_TYPE_YO_CHOSA";
    /** 区分マスタ.顧客登録区分.削除 */
    public static final String CUSTOMER_RSV_TYPE_SAKUJO = "CUSTOMER_RSV_TYPE_SAKUJO";
    /** 区分マスタ.顧客メモ重要度.最重要 */
    public static final String CUSTOMER_MEMO_PRIORITY_SAI_JUYO = "CUSTOMER_MEMO_PRIORITY_SAI_JUYO";
    /** 区分マスタ.顧客メモ重要度.重要 */
    public static final String CUSTOMER_MEMO_PRIORITY_JUYO = "CUSTOMER_MEMO_PRIORITY_JUYO";
    /** 区分マスタ.顧客メモ重要度.通常 */
    public static final String CUSTOMER_MEMO_PRIORITY_TSUJO = "CUSTOMER_MEMO_PRIORITY_TSUJO";
    /** 区分マスタ.税区分.内税 */
    public static final String TAX_TYPE_UCHI_ZEI = "TAX_TYPE_UCHI_ZEI";
    /** 区分マスタ.税区分.外税 */
    public static final String TAX_TYPE_GAI_ZEI = "TAX_TYPE_GAI_ZEI";
    /** 区分マスタ.税区分.非課税 */
    public static final String TAX_TYPE_HIKAZEI = "TAX_TYPE_HIKAZEI";
    /** 区分マスタ.請求状態区分.請求済 */
    public static final String SEIKYU_JOTAI_TYPE_SEIKYU_SUMI = "SEIKYU_JOTAI_TYPE_SEIKYU_SUMI";
    /** 区分マスタ.請求状態区分.次回請求分 */
    public static final String SEIKYU_JOTAI_TYPE_JIKAI_SEIKYU_BUN = "SEIKYU_JOTAI_TYPE_JIKAI_SEIKYU_BUN";
    /** 区分マスタ.請求状態区分.要再締 */
    public static final String SEIKYU_JOTAI_TYPE_YO_SAI_SHIME = "SEIKYU_JOTAI_TYPE_YO_SAI_SHIME";
    /** 区分マスタ.済区分.未 */
    public static final String SUMI_TYPE_MI = "SUMI_TYPE_MI";
    /** 区分マスタ.済区分.済 */
    public static final String SUMI_TYPE_SUMI = "SUMI_TYPE_SUMI";
    /** 区分マスタ.再締対象区分.要 */
    public static final String SAISHIME_TAISHO_TYPE_YO = "SAISHIME_TAISHO_TYPE_YO";
    /** 区分マスタ.未請求区分.未請求 */
    public static final String MISEIKYU_TYPE_MI_SEIKYU = "MISEIKYU_TYPE_MI_SEIKYU";
    /** 区分マスタ.締区分.通常締 */
    public static final String SHIME_TYPE_TSUJO_SHIME = "SHIME_TYPE_TSUJO_SHIME";
    /** 区分マスタ.締区分.特別締 */
    public static final String SHIME_TYPE_TOKUBETSU_SHIME = "SHIME_TYPE_TOKUBETSU_SHIME";
    /** 区分マスタ.締区分.決算締 */
    public static final String SHIME_TYPE_KESSAN_SHIME = "SHIME_TYPE_KESSAN_SHIME";
    /** 区分マスタ.回収状態.未回収 */
    public static final String KAISYU_TYPE_MI_KAISHU = "KAISYU_TYPE_MI_KAISHU";
    /** 区分マスタ.回収状態.一部回収 */
    public static final String KAISYU_TYPE_ICHIBU_KAISHU = "KAISYU_TYPE_ICHIBU_KAISHU";
    /** 区分マスタ.回収状態.回収済 */
    public static final String KAISYU_TYPE_KAISHU_SUMI = "KAISYU_TYPE_KAISHU_SUMI";
    /** 区分マスタ.請求書エラー区分.再締漏れ */
    public static final String SEIKYUSHO_ERROR_TYPE_SAI_SHIME_MORE = "SEIKYUSHO_ERROR_TYPE_SAI_SHIME_MORE";
    /** 区分マスタ.請求書エラー区分.請求漏れ */
    public static final String SEIKYUSHO_ERROR_TYPE_SEIKYU_MORE = "SEIKYUSHO_ERROR_TYPE_SEIKYU_MORE";
    /** 区分マスタ.請求書エラー区分.運賃未確定 */
    public static final String SEIKYUSHO_ERROR_TYPE_UNCHIN_MIKAKUTEI = "SEIKYUSHO_ERROR_TYPE_UNCHIN_MIKAKUTEI";
    /** 区分マスタ.請求書エラー区分.長期未印刷 */
    public static final String SEIKYUSHO_ERROR_TYPE_CHOKI_MI_INSATSU = "SEIKYUSHO_ERROR_TYPE_CHOKI_MI_INSATSU";
    /** 区分マスタ.請求書エラー区分.マイナス請求書 */
    public static final String SEIKYUSHO_ERROR_TYPE_MINUS_SEIKYUSHO = "SEIKYUSHO_ERROR_TYPE_MINUS_SEIKYUSHO";
    /** 区分マスタ.表示基準.コース */
    public static final String HYOJI_KIJUN_COURSE = "HYOJI_KIJUN_COURSE";
    /** 区分マスタ.表示基準.車両 */
    public static final String HYOJI_KIJUN_SHARYO = "HYOJI_KIJUN_SHARYO";
    /** 区分マスタ.表示基準.ドライバー */
    public static final String HYOJI_KIJUN_DRIVER = "HYOJI_KIJUN_DRIVER";
    /** 区分マスタ.元着区分.元払 */
    public static final String MOTO_CHAKU_KBN_MOTO_HARAI = "MOTO_CHAKU_KBN_MOTO_HARAI";
    /** 区分マスタ.元着区分.着払 */
    public static final String MOTO_CHAKU_KBN_CHAKUBARAI = "MOTO_CHAKU_KBN_CHAKUBARAI";
    /** 区分マスタ.印刷請求書.全て */
    public static final String INSATU_SEIKYUSHO_STATUS_ALL = "INSATU_SEIKYUSHO_STATUS_ALL";
    /** 区分マスタ.印刷請求書.未チェック */
    public static final String INSATU_SEIKYUSHO_STATUS_MI_CHECK = "INSATU_SEIKYUSHO_STATUS_MI_CHECK";
    /** 区分マスタ.印刷請求書.未印刷 */
    public static final String INSATU_SEIKYUSHO_STATUS_MI_INSATSU = "INSATU_SEIKYUSHO_STATUS_MI_INSATSU";
    /** 区分マスタ.印刷請求書.印刷済み */
    public static final String INSATU_SEIKYUSHO_STATUS_INSATSU_SUMI = "INSATU_SEIKYUSHO_STATUS_INSATSU_SUMI";
    /** 区分マスタ.Web請求書.全て */
    public static final String WEB_SEIKYUSHO_STATUS_ALL = "WEB_SEIKYUSHO_STATUS_ALL";
    /** 区分マスタ.Web請求書.未チェック */
    public static final String WEB_SEIKYUSHO_STATUS_MI_CHECK = "WEB_SEIKYUSHO_STATUS_MI_CHECK";
    /** 区分マスタ.Web請求書.済(顧客未印刷) */
    public static final String WEB_SEIKYUSHO_STATUS_SUMI_KOKYAKU_MI_INSATSU = "WEB_SEIKYUSHO_STATUS_SUMI_KOKYAKU_MI_INSATSU";
    /** 区分マスタ.Web請求書.済(顧客印刷済み) */
    public static final String WEB_SEIKYUSHO_STATUS_SUMI_KOKYAKU_INSATSU_SUMI = "WEB_SEIKYUSHO_STATUS_SUMI_KOKYAKU_INSATSU_SUMI";
    /** 区分マスタ.とりまとめ請求.全て */
    public static final String TORIMATOME_SEIKYUS_STATUS_ALL = "TORIMATOME_SEIKYUS_STATUS_ALL";
    /** 区分マスタ.とりまとめ請求.とりまとめ請求のみ */
    public static final String TORIMATOME_SEIKYUS_STATUS_TORIMATOME_SEIKYU_NOMI = "TORIMATOME_SEIKYUS_STATUS_TORIMATOME_SEIKYU_NOMI";
    /** 区分マスタ.とりまとめ請求.とりまとめ請求以外 */
    public static final String TORIMATOME_SEIKYUS_STATUS_TORIMATOME_SEIKYU_IGAI = "TORIMATOME_SEIKYUS_STATUS_TORIMATOME_SEIKYU_IGAI";
    /** 区分マスタ.締日選択.最新の請求のみ表示 */
    public static final String SIMEBI_SELECT_LATEST_SEIKYU_NOMI_HYOJI = "SIMEBI_SELECT_LATEST_SEIKYU_NOMI_HYOJI";
    /** 区分マスタ.締日選択.請求書の無い締日も表示 */
    public static final String SIMEBI_SELECT_SEIKYUSHO_NO_NAI_SHIMEBI_MO_HYOJI = "SIMEBI_SELECT_SEIKYUSHO_NO_NAI_SHIMEBI_MO_HYOJI";
    /** 区分マスタ.請求書発行ソート.通常 */
    public static final String SEIKYUSHO_HAKKO_SORT_TSUJO = "SEIKYUSHO_HAKKO_SORT_TSUJO";
    /** 区分マスタ.請求書発行ソート.カナ名称順 */
    public static final String SEIKYUSHO_HAKKO_SORT_KANA_MEISHO_JUN = "SEIKYUSHO_HAKKO_SORT_KANA_MEISHO_JUN";
    /** 区分マスタ.請求書発行ソート.請求先コード順 */
    public static final String SEIKYUSHO_HAKKO_SORT_SEIKYUSAKI_CD_JUN = "SEIKYUSHO_HAKKO_SORT_SEIKYUSAKI_CD_JUN";
    /** 区分マスタ.請求書発行ソート.締日順 */
    public static final String SEIKYUSHO_HAKKO_SORT_SHIMEBI_JUN = "SEIKYUSHO_HAKKO_SORT_SHIMEBI_JUN";
    /** 区分マスタ.請求書チェック.未チェック */
    public static final String SEIKYUSHO_CHECK_KBN_MI_CHECK = "SEIKYUSHO_CHECK_KBN_MI_CHECK";
    /** 区分マスタ.請求書チェック.チェック済 */
    public static final String SEIKYUSHO_CHECK_KBN_CHECK_SUMI = "SEIKYUSHO_CHECK_KBN_CHECK_SUMI";
    /** 区分マスタ.請求書詳細入金方法.集金 */
    public static final String SEIKYUSHO_SHOSAI_NYUKINHOUHOU_SHUKIN = "SEIKYUSHO_SHOSAI_NYUKINHOUHOU_SHUKIN";
    /** 区分マスタ.請求書詳細入金方法.振込 */
    public static final String SEIKYUSHO_SHOSAI_NYUKINHOUHOU_FURIKOMI = "SEIKYUSHO_SHOSAI_NYUKINHOUHOU_FURIKOMI";
    /** 区分マスタ.請求書詳細入金方法.手形 */
    public static final String SEIKYUSHO_SHOSAI_NYUKINHOUHOU_TEGATA = "SEIKYUSHO_SHOSAI_NYUKINHOUHOU_TEGATA";
    /** 区分マスタ.通知方法.メール */
    public static final String TSUCHI_HOHO_MAIL = "TSUCHI_HOHO_MAIL";
    /** 区分マスタ.通知方法.電話 */
    public static final String TSUCHI_HOHO_TEL = "TSUCHI_HOHO_TEL";
    /** 区分マスタ.見積ステータス（画面検索条件）.作成/承認中 */
    public static final String ESTIMATION_STATUS_SEARCH_SAKUSEI_SHONIN_CHU = "ESTIMATION_STATUS_SEARCH_SAKUSEI_SHONIN_CHU";
    /** 区分マスタ.見積ステータス（画面検索条件）.承認済 */
    public static final String ESTIMATION_STATUS_SEARCH_SHONIN_SUMI = "ESTIMATION_STATUS_SEARCH_SHONIN_SUMI";
    /** 区分マスタ.見積ステータス（画面検索条件）.適用終了 */
    public static final String ESTIMATION_STATUS_SEARCH_TEKIYO_SHURYO = "ESTIMATION_STATUS_SEARCH_TEKIYO_SHURYO";
    /** 区分マスタ.見積ステータス（画面検索条件）.削除/取消 */
    public static final String ESTIMATION_STATUS_SEARCH_SAKUJO_TORIKESHI = "ESTIMATION_STATUS_SEARCH_SAKUJO_TORIKESHI";
    /** 区分マスタ.元着引取区分（見積用）.元払 */
    public static final String TRANSACTION_TYPE_MOTO_HARAI = "TRANSACTION_TYPE_MOTO_HARAI";
    /** 区分マスタ.元着引取区分（見積用）.着払 */
    public static final String TRANSACTION_TYPE_CHAKUBARAI = "TRANSACTION_TYPE_CHAKUBARAI";
    /** 区分マスタ.元着引取区分（見積用）.引取 */
    public static final String TRANSACTION_TYPE_HIKITORI = "TRANSACTION_TYPE_HIKITORI";
    /** 区分マスタ.顧客別／テンプレート／標準料金.顧客別見積 */
    public static final String ESTIMATION_KIND_KOKYAKU_BETSU_MITSUMORI = "ESTIMATION_KIND_KOKYAKU_BETSU_MITSUMORI";
    /** 区分マスタ.顧客別／テンプレート／標準料金.テンプレート */
    public static final String ESTIMATION_KIND_TEMPLATE = "ESTIMATION_KIND_TEMPLATE";
    /** 区分マスタ.顧客別／テンプレート／標準料金.標準料金 */
    public static final String ESTIMATION_KIND_HYOJUN_RYOKIN = "ESTIMATION_KIND_HYOJUN_RYOKIN";
    /** 区分マスタ.見積り種類.パック料金 */
    public static final String ESTIMATION_TYPE_PACK_RYOKIN = "ESTIMATION_TYPE_PACK_RYOKIN";
    /** 区分マスタ.見積り種類.ノーマル運賃 */
    public static final String ESTIMATION_TYPE_NORMAL_UNCHIN = "ESTIMATION_TYPE_NORMAL_UNCHIN";
    /** 区分マスタ.見積り種類.チャーター料金 */
    public static final String ESTIMATION_TYPE_CHARTER_RYOKIN = "ESTIMATION_TYPE_CHARTER_RYOKIN";
    /** 区分マスタ.見積り種類.付帯料金 */
    public static final String ESTIMATION_TYPE_FUTAI_RYOKIN = "ESTIMATION_TYPE_FUTAI_RYOKIN";
    /** 区分マスタ.見積り登録区分.初版 */
    public static final String ESTIMATION_ENTRY_KBN_SHOHAN = "ESTIMATION_ENTRY_KBN_SHOHAN";
    /** 区分マスタ.見積り登録区分.改訂 */
    public static final String ESTIMATION_ENTRY_KBN_KAITEI = "ESTIMATION_ENTRY_KBN_KAITEI";
    /** 区分マスタ.見積り登録区分.継続 */
    public static final String ESTIMATION_ENTRY_KBN_KEIZOKU = "ESTIMATION_ENTRY_KBN_KEIZOKU";
    /** 区分マスタ.見積り登録区分.廃止 */
    public static final String ESTIMATION_ENTRY_KBN_HAISHI = "ESTIMATION_ENTRY_KBN_HAISHI";
    /** 区分マスタ.見積り登録区分.取消 */
    public static final String ESTIMATION_ENTRY_KBN_TORIKESHI = "ESTIMATION_ENTRY_KBN_TORIKESHI";
    /** 区分マスタ.値引（割増）/割戻.値引 */
    public static final String DISCOUNT_KBN_NEBIKI = "DISCOUNT_KBN_NEBIKI";
    /** 区分マスタ.値引（割増）/割戻.割増 */
    public static final String DISCOUNT_KBN_WARIMASHI = "DISCOUNT_KBN_WARIMASHI";
    /** 区分マスタ.値引（割増）/割戻.割戻 */
    public static final String DISCOUNT_KBN_WARIMDS = "DISCOUNT_KBN_WARIMDS";
    /** 区分マスタ.顧客区分.一般 */
    public static final String KOKYAKU_KBN_IPPAN = "KOKYAKU_KBN_IPPAN";
    /** 区分マスタ.顧客区分.代理店 */
    public static final String KOKYAKU_KBN_DAIRITEN = "KOKYAKU_KBN_DAIRITEN";
    /** 区分マスタ.顧客区分.3PL */
    public static final String KOKYAKU_KBN_3PL = "KOKYAKU_KBN_3PL";
    /** 区分マスタ.顧客種別.輸送顧客 */
    public static final String KOKYAKU_SHUBETSU_YUSO_KOKYAKU = "KOKYAKU_SHUBETSU_YUSO_KOKYAKU";
    /** 区分マスタ.顧客種別.ロジ顧客 */
    public static final String KOKYAKU_SHUBETSU_LOGI_KOKYAKU = "KOKYAKU_SHUBETSU_LOGI_KOKYAKU";
    /** 区分マスタ.顧客種別.その他請求 */
    public static final String KOKYAKU_SHUBETSU_SONOTA_SEIKYU = "KOKYAKU_SHUBETSU_SONOTA_SEIKYU";
    /** 区分マスタ.顧客種別.とりまとめ鑑 */
    public static final String KOKYAKU_SHUBETSU_TORIMATOME_KAN = "KOKYAKU_SHUBETSU_TORIMATOME_KAN";
    /** 区分マスタ.顧客種別.一見 */
    public static final String KOKYAKU_SHUBETSU_ICHIGEN = "KOKYAKU_SHUBETSU_ICHIGEN";
    /** 区分マスタ.顧客種別.社内便 */
    public static final String KOKYAKU_SHUBETSU_SHANAI_BIN = "KOKYAKU_SHUBETSU_SHANAI_BIN";
    /** 区分マスタ.顧客種別.着払代引未収 */
    public static final String KOKYAKU_SHUBETSU_CHAKUBARAI_DAIBIKI_MISHU = "KOKYAKU_SHUBETSU_CHAKUBARAI_DAIBIKI_MISHU";
    /** 区分マスタ.申請一覧操作区分.自分の申請分 */
    public static final String SHINSEI_ICHIRAN_SOSA_KBN_MY_SHINSEI_BUN = "SHINSEI_ICHIRAN_SOSA_KBN_MY_SHINSEI_BUN";
    /** 区分マスタ.申請一覧操作区分.自分の承認待ち */
    public static final String SHINSEI_ICHIRAN_SOSA_KBN_MY_SHONIN_MACHI = "SHINSEI_ICHIRAN_SOSA_KBN_MY_SHONIN_MACHI";
    /** 区分マスタ.申請一覧操作区分.その他 */
    public static final String SHINSEI_ICHIRAN_SOSA_KBN_SONOTA = "SHINSEI_ICHIRAN_SOSA_KBN_SONOTA";
    /** 区分マスタ.適用終了.終了 */
    public static final String TEKIYO_SHURYO_SHURYO = "TEKIYO_SHURYO_SHURYO";
    /** 区分マスタ.申請一覧チェックボックス.至急のみ */
    public static final String SHINSEI_ICHIRAN_CHECK_BOX_SHIKYU_NOMI = "SHINSEI_ICHIRAN_CHECK_BOX_SHIKYU_NOMI";
    /** 区分マスタ.申請一覧チェックボックス.再申請のみ */
    public static final String SHINSEI_ICHIRAN_CHECK_BOX_SAI_SHINSEI_NOMI = "SHINSEI_ICHIRAN_CHECK_BOX_SAI_SHINSEI_NOMI";
    /** 区分マスタ.申請一覧チェックボックス.コメントあり */
    public static final String SHINSEI_ICHIRAN_CHECK_BOX_COMMENT_ARI = "SHINSEI_ICHIRAN_CHECK_BOX_COMMENT_ARI";
    /** 区分マスタ.申請一覧チェックボックス.要注意コメント(承認者がコメントだけ登録) */
    public static final String SHINSEI_ICHIRAN_CHECK_BOX_YO_CHUI_COMMENT_SHONINSHA_GA_COMMENT_DAKE_TOROKU = "SHINSEI_ICHIRAN_CHECK_BOX_YO_CHUI_COMMENT_SHONINSHA_GA_COMMENT_DAKE_TOROKU";
    /** 区分マスタ.料金種類区分.パック料金 */
    public static final String FARE_TYPE_PACK_RYOKIN = "FARE_TYPE_PACK_RYOKIN";
    /** 区分マスタ.料金種類区分.ノーマル運賃 */
    public static final String FARE_TYPE_NORMAL_UNCHIN = "FARE_TYPE_NORMAL_UNCHIN";
    /** 区分マスタ.料金種類区分.チャーター料金 */
    public static final String FARE_TYPE_CHARTER_RYOKIN = "FARE_TYPE_CHARTER_RYOKIN";
    /** 区分マスタ.料金種類区分.付帯料金 */
    public static final String FARE_TYPE_FUTAI_RYOKIN = "FARE_TYPE_FUTAI_RYOKIN";
    /** 区分マスタ.値引(割増)/割戻単位区分.% */
    public static final String DISCOUNT_UNIT_PERCENT = "DISCOUNT_UNIT_PERCENT";
    /** 区分マスタ.値引(割増)/割戻単位区分.円 */
    public static final String DISCOUNT_UNIT_YEN_MAI_KEN = "DISCOUNT_UNIT_YEN_MAI_KEN";
    /** 区分マスタ.運賃計算パターン.個建て */
    public static final String FARE_CALCULATE_PATTERN_MAI_KO_DATE = "FARE_CALCULATE_PATTERN_MAI_KO_DATE";
    /** 区分マスタ.運賃計算パターン.重量建て */
    public static final String FARE_CALCULATE_PATTERN_JURYO_DATE = "FARE_CALCULATE_PATTERN_JURYO_DATE";
    /** 区分マスタ.運賃計算パターン.重量別個建て */
    public static final String FARE_CALCULATE_PATTERN_JURYO_BETSU_MAI_KO_DATE = "FARE_CALCULATE_PATTERN_JURYO_BETSU_MAI_KO_DATE";
    /** 区分マスタ.運賃計算パターン.総個数建て */
    public static final String FARE_CALCULATE_PATTERN_SOU_KOSU_DATE = "FARE_CALCULATE_PATTERN_SOU_KOSU_DATE";
    /** 区分マスタ.運賃計算パターン.総重量建て */
    public static final String FARE_CALCULATE_PATTERN_SOU_JURYO_DATE = "FARE_CALCULATE_PATTERN_SOU_JURYO_DATE";
    /** 区分マスタ.運賃計算パターン.品名建て */
    public static final String FARE_CALCULATE_PATTERN_HIMMEI_DATE = "FARE_CALCULATE_PATTERN_HIMMEI_DATE";
    /** 区分マスタ.増区分.通常 */
    public static final String INCREASE_TYPE_TSUJO = "INCREASE_TYPE_TSUJO";
    /** 区分マスタ.増区分.増し */
    public static final String INCREASE_TYPE_MASHI = "INCREASE_TYPE_MASHI";
    /** 区分マスタ.小数点区分.整数のみ */
    public static final String DECIMAL_TYPE_SEISU_NOMI = "DECIMAL_TYPE_SEISU_NOMI";
    /** 区分マスタ.小数点区分.小数点可 */
    public static final String DECIMAL_TYPE_SHOTENSU_KA = "DECIMAL_TYPE_SHOTENSU_KA";
    /** 区分マスタ.小数点区分.0.5単位 */
    public static final String DECIMAL_TYPE_0_5_TANI = "DECIMAL_TYPE_0_5_TANI";
    /** 区分マスタ.割増区分.割増(%) */
    public static final String EXTRA_TYPE_WARIMASHI_PERCENT = "EXTRA_TYPE_WARIMASHI_PERCENT";
    /** 区分マスタ.割増区分.加算(円) */
    public static final String EXTRA_TYPE_KASAN_YEN = "EXTRA_TYPE_KASAN_YEN";
    /** 区分マスタ.パワーゲート　割増区分.割増(%) */
    public static final String POWER_GATE_EXTRA_TYPE_WARIMASHI_PERCENT = "POWER_GATE_EXTRA_TYPE_WARIMASHI_PERCENT";
    /** 区分マスタ.パワーゲート　割増区分.加算(円) */
    public static final String POWER_GATE_EXTRA_TYPE_KASAN_YEN = "POWER_GATE_EXTRA_TYPE_KASAN_YEN";
    /** 区分マスタ.エアサス　割増区分.割増(%) */
    public static final String AIR_SUS_EXTRA_TYPE_WARIMASHI_PERCENT = "AIR_SUS_EXTRA_TYPE_WARIMASHI_PERCENT";
    /** 区分マスタ.エアサス　割増区分.加算(円) */
    public static final String AIR_SUS_EXTRA_TYPE_KASAN_YEN = "AIR_SUS_EXTRA_TYPE_KASAN_YEN";
    /** 区分マスタ.空調　割増区分.割増(%) */
    public static final String AIR_CONDITIONER_EXTRA_TYPE_WARIMASHI_PERCENT = "AIR_CONDITIONER_EXTRA_TYPE_WARIMASHI_PERCENT";
    /** 区分マスタ.空調　割増区分.加算(円) */
    public static final String AIR_CONDITIONER_EXTRA_TYPE_KASAN_YEN = "AIR_CONDITIONER_EXTRA_TYPE_KASAN_YEN";
    /** 区分マスタ.発地着地区分.発地 */
    public static final String FROM_TO_AREA_KBN_HOTCHI = "FROM_TO_AREA_KBN_HOTCHI";
    /** 区分マスタ.発地着地区分.着地 */
    public static final String FROM_TO_AREA_KBN_CHAKUCHI = "FROM_TO_AREA_KBN_CHAKUCHI";
    /** 区分マスタ.チャーター区分.集荷 */
    public static final String CHARTER_TYPE_SHUKA = "CHARTER_TYPE_SHUKA";
    /** 区分マスタ.チャーター区分.配達 */
    public static final String CHARTER_TYPE_HAITATSU = "CHARTER_TYPE_HAITATSU";
    /** 区分マスタ.チャーター区分.直送 */
    public static final String CHARTER_TYPE_CHOKUSO = "CHARTER_TYPE_CHOKUSO";
    /** 区分マスタ.売上区分.輸送売上 */
    public static final String SALES_TYPE_YUSO_URIAGE = "SALES_TYPE_YUSO_URIAGE";
    /** 区分マスタ.売上区分.その他売上 */
    public static final String SALES_TYPE_SONOTA_URIAGE = "SALES_TYPE_SONOTA_URIAGE";
    /** 区分マスタ.売上区分.ロジ売上 */
    public static final String SALES_TYPE_LOGI_URIAGE = "SALES_TYPE_LOGI_URIAGE";
    /** 区分マスタ.売上区分.その他請求 */
    public static final String SALES_TYPE_SONOTA_SEIKYU = "SALES_TYPE_SONOTA_SEIKYU";
    /** 区分マスタ.支払区分.前払(現収) */
    public static final String PAYMENT_TYPE_MAEBARAI_GENSHU = "PAYMENT_TYPE_MAEBARAI_GENSHU";
    /** 区分マスタ.支払区分.後払(第三者払) */
    public static final String PAYMENT_TYPE_ATOBARAI_DAISANSHA_HARAI = "PAYMENT_TYPE_ATOBARAI_DAISANSHA_HARAI";
    /** 区分マスタ.支払区分.着払 */
    public static final String PAYMENT_TYPE_CHAKUBARAI = "PAYMENT_TYPE_CHAKUBARAI";
    /** 区分マスタ.支払区分.代引あり */
    public static final String PAYMENT_TYPE_DAIBIKI_ARI = "PAYMENT_TYPE_DAIBIKI_ARI";
    /** 区分マスタ.支払区分.後払(後払確定) */
    public static final String PAYMENT_TYPE_ATOBARAI_ATOBARAI_KAKUTEI = "PAYMENT_TYPE_ATOBARAI_ATOBARAI_KAKUTEI";
    /** 区分マスタ.引取区分.通常 */
    public static final String HIKITORI_KBN_TSUJO = "HIKITORI_KBN_TSUJO";
    /** 区分マスタ.引取区分.引取 */
    public static final String HIKITORI_KBN_HIKITORI = "HIKITORI_KBN_HIKITORI";
    /** 区分マスタ.集荷指示.集荷 */
    public static final String PICKUP_INDICATION_SHUKA = "PICKUP_INDICATION_SHUKA";
    /** 区分マスタ.集荷指示.持込 */
    public static final String PICKUP_INDICATION_MOCHIKOMI = "PICKUP_INDICATION_MOCHIKOMI";
    /** 区分マスタ.集荷指示.チャーター */
    public static final String PICKUP_INDICATION_CHARTER = "PICKUP_INDICATION_CHARTER";
    /** 区分マスタ.配達指示.配達 */
    public static final String DELIVERY_INDICATION_HAITATSU = "DELIVERY_INDICATION_HAITATSU";
    /** 区分マスタ.配達指示.市内止 */
    public static final String DELIVERY_INDICATION_SHINAI_DOME = "DELIVERY_INDICATION_SHINAI_DOME";
    /** 区分マスタ.配達指示.空港止 */
    public static final String DELIVERY_INDICATION_KUKO_DOME = "DELIVERY_INDICATION_KUKO_DOME";
    /** 区分マスタ.配達指示.配達日指定 */
    public static final String DELIVERY_INDICATION_HAITATSU_HI_SHITEI = "DELIVERY_INDICATION_HAITATSU_HI_SHITEI";
    /** 区分マスタ.配達指示.日祝指定 */
    public static final String DELIVERY_INDICATION_NICHISHUKU_SHITEI = "DELIVERY_INDICATION_NICHISHUKU_SHITEI";
    /** 区分マスタ.配達指示.時間指定 */
    public static final String DELIVERY_INDICATION_JIKAN_SHITEI = "DELIVERY_INDICATION_JIKAN_SHITEI";
    /** 区分マスタ.配達指示.午前 */
    public static final String DELIVERY_INDICATION_GOZEN = "DELIVERY_INDICATION_GOZEN";
    /** 区分マスタ.配達指示.午後 */
    public static final String DELIVERY_INDICATION_GOGO = "DELIVERY_INDICATION_GOGO";
    /** 区分マスタ.配達指示.チャーター */
    public static final String DELIVERY_INDICATION_CHARTER = "DELIVERY_INDICATION_CHARTER";
    /** 区分マスタ.運賃計算パターン（ロジ料金）.保険料 */
    public static final String UNCHIN_KEISAN_PTN_LOGI_RYOKIN_HOKEN_RYO = "UNCHIN_KEISAN_PTN_LOGI_RYOKIN_HOKEN_RYO";
    /** 区分マスタ.運賃計算パターン（ロジ料金）.作業料 */
    public static final String UNCHIN_KEISAN_PTN_LOGI_RYOKIN_SAGYORYO = "UNCHIN_KEISAN_PTN_LOGI_RYOKIN_SAGYORYO";
    /** 区分マスタ.運賃計算パターン（ロジ料金）.その他 */
    public static final String UNCHIN_KEISAN_PTN_LOGI_RYOKIN_SONOTA = "UNCHIN_KEISAN_PTN_LOGI_RYOKIN_SONOTA";
    /** 区分マスタ.顧客種別(省略).輸送 */
    public static final String KOKYAKU_SYUBETU_RYAKU_YUSO = "KOKYAKU_SYUBETU_RYAKU_YUSO";
    /** 区分マスタ.顧客種別(省略).ロジ */
    public static final String KOKYAKU_SYUBETU_RYAKU_LOGI = "KOKYAKU_SYUBETU_RYAKU_LOGI";
    /** 区分マスタ.顧客種別(省略).その他請求 */
    public static final String KOKYAKU_SYUBETU_RYAKU_SONOTA_SEIKYU = "KOKYAKU_SYUBETU_RYAKU_SONOTA_SEIKYU";
    /** 区分マスタ.顧客種別(省略).鑑 */
    public static final String KOKYAKU_SYUBETU_RYAKU_KAN = "KOKYAKU_SYUBETU_RYAKU_KAN";
    /** 区分マスタ.顧客種別(省略).一見 */
    public static final String KOKYAKU_SYUBETU_RYAKU_ICHIGEN = "KOKYAKU_SYUBETU_RYAKU_ICHIGEN";
    /** 区分マスタ.顧客種別(省略).社内便 */
    public static final String KOKYAKU_SYUBETU_RYAKU_SHANAI_BIN = "KOKYAKU_SYUBETU_RYAKU_SHANAI_BIN";
    /** 区分マスタ.顧客種別(省略).着払代引未収 */
    public static final String KOKYAKU_SYUBETU_RYAKU_CHAKUBARAI_DAIBIKI_MISHU = "KOKYAKU_SYUBETU_RYAKU_CHAKUBARAI_DAIBIKI_MISHU";
    /** 区分マスタ.顧客状態.仮登録 */
    public static final String KOKYAKU_STATUS_KARI_TOROKU = "KOKYAKU_STATUS_KARI_TOROKU";
    /** 区分マスタ.顧客状態.申請中 */
    public static final String KOKYAKU_STATUS_SHINSEI_CHU = "KOKYAKU_STATUS_SHINSEI_CHU";
    /** 区分マスタ.顧客状態.登録済 */
    public static final String KOKYAKU_STATUS_TOROKU_SUMI = "KOKYAKU_STATUS_TOROKU_SUMI";
    /** 区分マスタ.顧客状態.適用終了 */
    public static final String KOKYAKU_STATUS_TEKIYO_SHURYO = "KOKYAKU_STATUS_TEKIYO_SHURYO";
    /** 区分マスタ.送り状登録区分.画面 */
    public static final String OKURIJO_RSV_TYPE_GAMEN = "OKURIJO_RSV_TYPE_GAMEN";
    /** 区分マスタ.送り状登録区分.取込 */
    public static final String OKURIJO_RSV_TYPE_TORIKOMI = "OKURIJO_RSV_TYPE_TORIKOMI";
    /** 区分マスタ.送り状登録区分.取込後修正 */
    public static final String OKURIJO_RSV_TYPE_TORIKOMI_ATO_SHUSEI = "OKURIJO_RSV_TYPE_TORIKOMI_ATO_SHUSEI";
    /** 区分マスタ.送り状登録区分.EDI */
    public static final String OKURIJO_RSV_TYPE_EDI = "OKURIJO_RSV_TYPE_EDI";
    /** 区分マスタ.送り状荷札発行状態.データ未修正 */
    public static final String OKURIJO_NIFUDA_HAAKO_STATUS_DATA_MI_SHUSEI = "OKURIJO_NIFUDA_HAAKO_STATUS_DATA_MI_SHUSEI";
    /** 区分マスタ.送り状荷札発行状態.送り状未発行 */
    public static final String OKURIJO_NIFUDA_HAAKO_STATUS_OKURIJO_MI_HAKKO = "OKURIJO_NIFUDA_HAAKO_STATUS_OKURIJO_MI_HAKKO";
    /** 区分マスタ.送り状荷札発行状態.荷札ラベル未発行 */
    public static final String OKURIJO_NIFUDA_HAAKO_STATUS_NIFUDA_LABEL_MI_HAKKO = "OKURIJO_NIFUDA_HAAKO_STATUS_NIFUDA_LABEL_MI_HAKKO";
    /** 区分マスタ.送り状荷札発行状態.完了 */
    public static final String OKURIJO_NIFUDA_HAAKO_STATUS_KANRYO = "OKURIJO_NIFUDA_HAAKO_STATUS_KANRYO";
    /** 区分マスタ.データ元_輸送その他.全て */
    public static final String DATA_MOTO_YUSOU_SONOTA_TYPE_ALL = "DATA_MOTO_YUSOU_SONOTA_TYPE_ALL";
    /** 区分マスタ.データ元_輸送その他.伝まる */
    public static final String DATA_MOTO_YUSOU_SONOTA_TYPE_DEMMARU = "DATA_MOTO_YUSOU_SONOTA_TYPE_DEMMARU";
    /** 区分マスタ.データ元_輸送その他.EDI */
    public static final String DATA_MOTO_YUSOU_SONOTA_TYPE_EDI = "DATA_MOTO_YUSOU_SONOTA_TYPE_EDI";
    /** 区分マスタ.データ元_輸送その他.PC */
    public static final String DATA_MOTO_YUSOU_SONOTA_TYPE_PC = "DATA_MOTO_YUSOU_SONOTA_TYPE_PC";
    /** 区分マスタ.データ元_輸送その他.HT */
    public static final String DATA_MOTO_YUSOU_SONOTA_TYPE_HT = "DATA_MOTO_YUSOU_SONOTA_TYPE_HT";
    /** 区分マスタ.データ元_輸送その他.引取依頼分 */
    public static final String DATA_MOTO_YUSOU_SONOTA_TYPE_HIKITORI_IRAI_BUN = "DATA_MOTO_YUSOU_SONOTA_TYPE_HIKITORI_IRAI_BUN";
    /** 区分マスタ.データ元_ロジ.全て */
    public static final String DATA_MOTO_LOGI_TYPE_ALL = "DATA_MOTO_LOGI_TYPE_ALL";
    /** 区分マスタ.データ元_ロジ.Axis */
    public static final String DATA_MOTO_LOGI_TYPE_AXIS = "DATA_MOTO_LOGI_TYPE_AXIS";
    /** 区分マスタ.データ元_ロジ.EDI */
    public static final String DATA_MOTO_LOGI_TYPE_EDI = "DATA_MOTO_LOGI_TYPE_EDI";
    /** 区分マスタ.データ元_ロジ.手入力 */
    public static final String DATA_MOTO_LOGI_TYPE_TENYURYOKU = "DATA_MOTO_LOGI_TYPE_TENYURYOKU";
    /** 区分マスタ.データ元_ロジ.自動 */
    public static final String DATA_MOTO_LOGI_TYPE_JIDO = "DATA_MOTO_LOGI_TYPE_JIDO";
    /** 区分マスタ.チェックステータス.全て */
    public static final String CHECK_STATUS_TYPE_ALL = "CHECK_STATUS_TYPE_ALL";
    /** 区分マスタ.チェックステータス.チェック済み */
    public static final String CHECK_STATUS_TYPE_CHECK_SUMI = "CHECK_STATUS_TYPE_CHECK_SUMI";
    /** 区分マスタ.チェックステータス.未チェック */
    public static final String CHECK_STATUS_TYPE_MI_CHECK = "CHECK_STATUS_TYPE_MI_CHECK";
    /** 区分マスタ.チェックステータス.保留 */
    public static final String CHECK_STATUS_TYPE_HORYU = "CHECK_STATUS_TYPE_HORYU";
    /** 区分マスタ.入力箇所.全て */
    public static final String NYURYOKU_KASHO_TYPE_ALL = "NYURYOKU_KASHO_TYPE_ALL";
    /** 区分マスタ.入力箇所.自箇所入力 */
    public static final String NYURYOKU_KASHO_TYPE_JIKASHO_NYURYOKU = "NYURYOKU_KASHO_TYPE_JIKASHO_NYURYOKU";
    /** 区分マスタ.入力箇所.未収振替 */
    public static final String NYURYOKU_KASHO_TYPE_MISHU_FURIKAE = "NYURYOKU_KASHO_TYPE_MISHU_FURIKAE";
    /** 区分マスタ.新規修正.全て */
    public static final String SHINKI_SHUSEI_TYPE_ALL = "SHINKI_SHUSEI_TYPE_ALL";
    /** 区分マスタ.新規修正.新規 */
    public static final String SHINKI_SHUSEI_TYPE_SHINKI = "SHINKI_SHUSEI_TYPE_SHINKI";
    /** 区分マスタ.新規修正.修正 */
    public static final String SHINKI_SHUSEI_TYPE_SHUSEI = "SHINKI_SHUSEI_TYPE_SHUSEI";
    /** 区分マスタ.注意宛先.全て */
    public static final String TYUUI_ATESAKI_TYPE_ALL = "TYUUI_ATESAKI_TYPE_ALL";
    /** 区分マスタ.注意宛先.離島 */
    public static final String TYUUI_ATESAKI_TYPE_RITO = "TYUUI_ATESAKI_TYPE_RITO";
    /** 区分マスタ.注意宛先.館内配送 */
    public static final String TYUUI_ATESAKI_TYPE_KANNAIHAISO = "TYUUI_ATESAKI_TYPE_KANNAIHAISO";
    /** 区分マスタ.卸値変更あり.全て */
    public static final String OROSHINE_HENKO_ARI_TYPE_ALL = "OROSHINE_HENKO_ARI_TYPE_ALL";
    /** 区分マスタ.卸値変更あり.離島 */
    public static final String OROSHINE_HENKO_ARI_TYPE_RITO = "OROSHINE_HENKO_ARI_TYPE_RITO";
    /** 区分マスタ.卸値変更あり.館内配送 */
    public static final String OROSHINE_HENKO_ARI_TYPE_KANNAIHAISO = "OROSHINE_HENKO_ARI_TYPE_KANNAIHAISO";
    /** 区分マスタ.卸値変更あり.チャーター */
    public static final String OROSHINE_HENKO_ARI_TYPE_CHARTER = "OROSHINE_HENKO_ARI_TYPE_CHARTER";
    /** 区分マスタ.輸送売上ステータス.未チェック */
    public static final String YUSO_URIAGE_STATUS_MI_CHECK = "YUSO_URIAGE_STATUS_MI_CHECK";
    /** 区分マスタ.輸送売上ステータス.チェック済み */
    public static final String YUSO_URIAGE_STATUS_CHECK_SUMI = "YUSO_URIAGE_STATUS_CHECK_SUMI";
    /** 区分マスタ.輸送売上ステータス.パラメータ不足 */
    public static final String YUSO_URIAGE_STATUS_PARAMETER_BUSOKU = "YUSO_URIAGE_STATUS_PARAMETER_BUSOKU";
    /** 区分マスタ.輸送売上ステータス.エラー */
    public static final String YUSO_URIAGE_STATUS_ERROR = "YUSO_URIAGE_STATUS_ERROR";
    /** 区分マスタ.プルーフチェックステータス.未チェック */
    public static final String PROOF_CHECK_STATUS_MI_CHECK = "PROOF_CHECK_STATUS_MI_CHECK";
    /** 区分マスタ.プルーフチェックステータス.チェック完了 */
    public static final String PROOF_CHECK_STATUS_CHECK_KANRYO = "PROOF_CHECK_STATUS_CHECK_KANRYO";
    /** 区分マスタ.プルーフチェックステータス.保留 */
    public static final String PROOF_CHECK_STATUS_HORYU = "PROOF_CHECK_STATUS_HORYU";
    /** 区分マスタ.条件外未収ランク.RANK:A */
    public static final String JOKEN_GAI_MISHU_RANK_RANK_A = "JOKEN_GAI_MISHU_RANK_RANK_A";
    /** 区分マスタ.条件外未収ランク.RANK:B */
    public static final String JOKEN_GAI_MISHU_RANK_RANK_B = "JOKEN_GAI_MISHU_RANK_RANK_B";
    /** 区分マスタ.条件外未収ランク.RANK:C */
    public static final String JOKEN_GAI_MISHU_RANK_RANK_C = "JOKEN_GAI_MISHU_RANK_RANK_C";
    /** 区分マスタ.条件外未収ランク.RANK:D */
    public static final String JOKEN_GAI_MISHU_RANK_RANK_D = "JOKEN_GAI_MISHU_RANK_RANK_D";
    /** 区分マスタ.条件外未収ランク.RANK:E */
    public static final String JOKEN_GAI_MISHU_RANK_RANK_E = "JOKEN_GAI_MISHU_RANK_RANK_E";
    /** 区分マスタ.条件外未収ランク.RANK:F */
    public static final String JOKEN_GAI_MISHU_RANK_RANK_F = "JOKEN_GAI_MISHU_RANK_RANK_F";
    /** 区分マスタ.課税区分.課税 */
    public static final String TAXATION_TYPE_KAZEI = "TAXATION_TYPE_KAZEI";
    /** 区分マスタ.課税区分.免税 */
    public static final String TAXATION_TYPE_MENZEI = "TAXATION_TYPE_MENZEI";
    /** 区分マスタ.Web請求書利用.有効 */
    public static final String WEB_SEIKYUSHO_RIYOU_YUKO = "WEB_SEIKYUSHO_RIYOU_YUKO";
    /** 区分マスタ.Web請求書利用.無効 */
    public static final String WEB_SEIKYUSHO_RIYOU_MUKO = "WEB_SEIKYUSHO_RIYOU_MUKO";
    /** 区分マスタ.ＣＳＶダウンロード.可能 */
    public static final String CSV_DOWNLOAD_KANO = "CSV_DOWNLOAD_KANO";
    /** 区分マスタ.ＣＳＶダウンロード.不可 */
    public static final String CSV_DOWNLOAD_FUKA = "CSV_DOWNLOAD_FUKA";
    /** 区分マスタ.請求基準.集荷 */
    public static final String SEIKYU_KIJUN_SHUKA = "SEIKYU_KIJUN_SHUKA";
    /** 区分マスタ.請求基準.配完 */
    public static final String SEIKYU_KIJUN_HAIKAN = "SEIKYU_KIJUN_HAIKAN";
    /** 区分マスタ.請求書チェック.要 */
    public static final String SEIKYUSHO_CHECK_YO = "SEIKYUSHO_CHECK_YO";
    /** 区分マスタ.請求書チェック.不要 */
    public static final String SEIKYUSHO_CHECK_FUYO = "SEIKYUSHO_CHECK_FUYO";
    /** 区分マスタ.月末土日入金.前月末入金 */
    public static final String GETSUMATSU_DONICHI_NYUKIN_ZENGETSU_MATSU_NYUKIN = "GETSUMATSU_DONICHI_NYUKIN_ZENGETSU_MATSU_NYUKIN";
    /** 区分マスタ.月末土日入金.翌月初め入金 */
    public static final String GETSUMATSU_DONICHI_NYUKIN_YOKUGETSU_HAJIME_NYUKIN = "GETSUMATSU_DONICHI_NYUKIN_YOKUGETSU_HAJIME_NYUKIN";
    /** 区分マスタ.支払方法.集金 */
    public static final String SHIHARAI_HOHO_SHUKIN = "SHIHARAI_HOHO_SHUKIN";
    /** 区分マスタ.支払方法.振込 */
    public static final String SHIHARAI_HOHO_FURIKOMI = "SHIHARAI_HOHO_FURIKOMI";
    /** 区分マスタ.支払方法.手形 */
    public static final String SHIHARAI_HOHO_TEGATA = "SHIHARAI_HOHO_TEGATA";
    /** 区分マスタ.支払サイト.当月 */
    public static final String SHIHARAI_SITE_TOGETSU = "SHIHARAI_SITE_TOGETSU";
    /** 区分マスタ.支払サイト.翌月 */
    public static final String SHIHARAI_SITE_YOKUGETSU = "SHIHARAI_SITE_YOKUGETSU";
    /** 区分マスタ.支払サイト.翌々月 */
    public static final String SHIHARAI_SITE_YOKUYOKUGETSU = "SHIHARAI_SITE_YOKUYOKUGETSU";
    /** 区分マスタ.口座選択方法.営業所標準口座を指定 */
    public static final String KOZA_SENTAKU_HOHO_EIGYOSHO_HYOJUN_KOZA_SITEI = "KOZA_SENTAKU_HOHO_EIGYOSHO_HYOJUN_KOZA_SITEI";
    /** 区分マスタ.口座選択方法.その他の口座を指定 */
    public static final String KOZA_SENTAKU_HOHO_SONOTA_KOZA_SHITEI = "KOZA_SENTAKU_HOHO_SONOTA_KOZA_SHITEI";
    /** 区分マスタ.口座種別.普通 */
    public static final String KOZA_SHUBETSU_FUTSU = "KOZA_SHUBETSU_FUTSU";
    /** 区分マスタ.口座種別.当座 */
    public static final String KOZA_SHUBETSU_TOZA = "KOZA_SHUBETSU_TOZA";
    /** 区分マスタ.口座種別.定期 */
    public static final String KOZA_SHUBETSU_TEIKI = "KOZA_SHUBETSU_TEIKI";
    /** 区分マスタ.伝まる登録.未申請 */
    public static final String DEMMARU_TOROKU_MI_SHINSEI = "DEMMARU_TOROKU_MI_SHINSEI";
    /** 区分マスタ.伝まる登録.申請中 */
    public static final String DEMMARU_TOROKU_SHINSEI_CHU = "DEMMARU_TOROKU_SHINSEI_CHU";
    /** 区分マスタ.伝まる登録.登録済 */
    public static final String DEMMARU_TOROKU_TOROKU_SUMI = "DEMMARU_TOROKU_TOROKU_SUMI";
    /** 区分マスタ.住所名称の表示.荷送人 */
    public static final String JUSHO_MEISHO_NO_HYOJI_NIOKURININ = "JUSHO_MEISHO_NO_HYOJI_NIOKURININ";
    /** 区分マスタ.住所名称の表示.荷受人 */
    public static final String JUSHO_MEISHO_NO_HYOJI_NIUKENIN = "JUSHO_MEISHO_NO_HYOJI_NIUKENIN";
    /** 区分マスタ.住所名称の表示.自動 */
    public static final String JUSHO_MEISHO_NO_HYOJI_JIDO = "JUSHO_MEISHO_NO_HYOJI_JIDO";
    /** 区分マスタ.住所名称の表示.両方 */
    public static final String JUSHO_MEISHO_NO_HYOJI_RYOHO = "JUSHO_MEISHO_NO_HYOJI_RYOHO";
    /** 区分マスタ.小計のありなし.あり */
    public static final String SHOKEI_UMU_ARI = "SHOKEI_UMU_ARI";
    /** 区分マスタ.小計のありなし.なし */
    public static final String SHOKEI_UMU_NASHI = "SHOKEI_UMU_NASHI";
    /** 区分マスタ.取引承認.未 */
    public static final String TORIHIKI_SHONIN_MI = "TORIHIKI_SHONIN_MI";
    /** 区分マスタ.取引承認.済 */
    public static final String TORIHIKI_SHONIN_SUMI = "TORIHIKI_SHONIN_SUMI";
    /** 区分マスタ.売上入力デフォルト画面.売上入力訂正 */
    public static final String URIAGE_NYURYOKU_DEFAULT_GAMEN_URIAGE_NYURYOKU_TEISEI = "URIAGE_NYURYOKU_DEFAULT_GAMEN_URIAGE_NYURYOKU_TEISEI";
    /** 区分マスタ.売上入力デフォルト画面.売上一覧訂正 */
    public static final String URIAGE_NYURYOKU_DEFAULT_GAMEN_URIAGE_ICHIRAN_TEISEI = "URIAGE_NYURYOKU_DEFAULT_GAMEN_URIAGE_ICHIRAN_TEISEI";
    /** 区分マスタ.その他備考.使用する */
    public static final String SONOTA_BIKO_SHIYO_SURU = "SONOTA_BIKO_SHIYO_SURU";
    /** 区分マスタ.その他備考.使用しない */
    public static final String SONOTA_BIKO_SHIYO_SHINAI = "SONOTA_BIKO_SHIYO_SHINAI";
    /** 区分マスタ.承認箇所区分.営業部 */
    public static final String SHONIN_KASHO_KBN_EIGYO_BU = "SHONIN_KASHO_KBN_EIGYO_BU";
    /** 区分マスタ.承認箇所区分.本社営業部 */
    public static final String SHONIN_KASHO_KBN_HONSHA_EIGYO_BU = "SHONIN_KASHO_KBN_HONSHA_EIGYO_BU";
    /** 区分マスタ.承認箇所区分.本社 */
    public static final String SHONIN_KASHO_KBN_HONSHA = "SHONIN_KASHO_KBN_HONSHA";
    /** 区分マスタ.パック料金重量増区分.増し */
    public static final String PAC_WEIGHT_INCREASE_TYPE_MASHI = "PAC_WEIGHT_INCREASE_TYPE_MASHI";
    /** 区分マスタ.パック料金重量増区分./Kg */
    public static final String PAC_WEIGHT_INCREASE_TYPE_MAI_KG = "PAC_WEIGHT_INCREASE_TYPE_MAI_KG";
    /** 区分マスタ.パック料金重量増区分.増し */
    public static final String PAC_NUMBER_INCREASE_TYPE_MASHI = "PAC_NUMBER_INCREASE_TYPE_MASHI";
    /** 区分マスタ.翌着予定日区分.当日 */
    public static final String YOKUCHAKU_YOTEIBI_KBN_TOJITSU = "YOKUCHAKU_YOTEIBI_KBN_TOJITSU";
    /** 区分マスタ.翌着予定日区分.翌日 */
    public static final String YOKUCHAKU_YOTEIBI_KBN_YOKUJITU = "YOKUCHAKU_YOTEIBI_KBN_YOKUJITU";
    /** 区分マスタ.翌着予定日区分.翌々日 */
    public static final String YOKUCHAKU_YOTEIBI_KBN_YOKUYOKUJITSU = "YOKUCHAKU_YOTEIBI_KBN_YOKUYOKUJITSU";
    /** 区分マスタ.翌着予定日区分.翌々日以降 */
    public static final String YOKUCHAKU_YOTEIBI_KBN_YOKUYOKUJITSU_IKO = "YOKUCHAKU_YOTEIBI_KBN_YOKUYOKUJITSU_IKO";
    /** 区分マスタ.到着時間帯区分.午前中 */
    public static final String TOCHAKU_JIKANTAI_KBN_GOZEN_CHU = "TOCHAKU_JIKANTAI_KBN_GOZEN_CHU";
    /** 区分マスタ.到着時間帯区分.午後 */
    public static final String TOCHAKU_JIKANTAI_KBN_GOGO = "TOCHAKU_JIKANTAI_KBN_GOGO";
    /** 区分マスタ.到着時間帯区分.時間指定 */
    public static final String TOCHAKU_JIKANTAI_KBN_JIKAN_SHITEI = "TOCHAKU_JIKANTAI_KBN_JIKAN_SHITEI";
    /** 区分マスタ.翌着可否.不可 */
    public static final String YOKUCHAKU_KAHI_FUKA = "YOKUCHAKU_KAHI_FUKA";
    /** 区分マスタ.翌着可否.可 */
    public static final String YOKUCHAKU_KAHI_KA = "YOKUCHAKU_KAHI_KA";
    /** 区分マスタ.変更区分.新規 */
    public static final String HENKO_KBN_SHINKI = "HENKO_KBN_SHINKI";
    /** 区分マスタ.変更区分.変更 */
    public static final String HENKO_KBN_HENKO = "HENKO_KBN_HENKO";
    /** 区分マスタ.変更区分.削除 */
    public static final String HENKO_KBN_SAKUJO = "HENKO_KBN_SAKUJO";
    /** 区分マスタ.適用終了表示用キャプション.終了 */
    public static final String TEKIYO_SHURYO_HYOJI_YO_SHURYO = "TEKIYO_SHURYO_HYOJI_YO_SHURYO";
    /** 区分マスタ.委託貨物照会　備考.売上情報なし */
    public static final String ITAKU_KAMOTSU_BIKO_URIAGE_JOHO_NASHI = "ITAKU_KAMOTSU_BIKO_URIAGE_JOHO_NASHI";
    /** 区分マスタ.委託貨物照会　備考.売上情報不備（住所なし） */
    public static final String ITAKU_KAMOTSU_BIKO_URIAGE_JOHO_FUBI_JUSHO_NASHI = "ITAKU_KAMOTSU_BIKO_URIAGE_JOHO_FUBI_JUSHO_NASHI";
    /** 区分マスタ.委託貨物照会　備考.売上情報不備（売上個数なし） */
    public static final String ITAKU_KAMOTSU_BIKO_URIAGE_JOHO_FUBI_URIAGE_KOSU_NASHI = "ITAKU_KAMOTSU_BIKO_URIAGE_JOHO_FUBI_URIAGE_KOSU_NASHI";
    /** 区分マスタ.委託貨物照会　備考.売上情報不備（売上重量なし） */
    public static final String ITAKU_KAMOTSU_BIKO_URIAGE_JOHO_FUBI_URIAGE_JURYO_NASHI = "ITAKU_KAMOTSU_BIKO_URIAGE_JOHO_FUBI_URIAGE_JURYO_NASHI";
    /** 区分マスタ.委託貨物照会　備考.個数不一致 */
    public static final String ITAKU_KAMOTSU_BIKO_KOSU_FUICCHI = "ITAKU_KAMOTSU_BIKO_KOSU_FUICCHI";
    /** 区分マスタ.委託貨物照会　備考.配達料計算エラー */
    public static final String ITAKU_KAMOTSU_BIKO_HAITATSU_RYO_KEISAN_ERROR = "ITAKU_KAMOTSU_BIKO_HAITATSU_RYO_KEISAN_ERROR";
    /** 区分マスタ.データ入力元.手入力 */
    public static final String DATA_NYURYOKU_MOTO_TENYURYOKU = "DATA_NYURYOKU_MOTO_TENYURYOKU";
    /** 区分マスタ.データ入力元.Axis */
    public static final String DATA_NYURYOKU_MOTO_AXIS = "DATA_NYURYOKU_MOTO_AXIS";
    /** 区分マスタ.データ入力元.伝まる */
    public static final String DATA_NYURYOKU_MOTO_DEMMARU = "DATA_NYURYOKU_MOTO_DEMMARU";
    /** 区分マスタ.データ入力元.HT(DRS) */
    public static final String DATA_NYURYOKU_MOTO_HT_DRS = "DATA_NYURYOKU_MOTO_HT_DRS";
    /** 区分マスタ.データ入力元.EDI */
    public static final String DATA_NYURYOKU_MOTO_EDI = "DATA_NYURYOKU_MOTO_EDI";
    /** 区分マスタ.申請種別.提案申請 */
    public static final String SINSEI_SHUBETSU_TEIAN_SHINSEI = "SINSEI_SHUBETSU_TEIAN_SHINSEI";
    /** 区分マスタ.申請種別.料金登録申請 */
    public static final String SINSEI_SHUBETSU_RYOKIN_TOROKU_SHINSEI = "SINSEI_SHUBETSU_RYOKIN_TOROKU_SHINSEI";
    /** 区分マスタ.申請種別.売上削除申請 */
    public static final String SINSEI_SHUBETSU_URIAGE_SAKUJO_SHINSEI = "SINSEI_SHUBETSU_URIAGE_SAKUJO_SHINSEI";
    /** 区分マスタ.申請種別.その他売上削除申請 */
    public static final String SINSEI_SHUBETSU_SONOTA_URIAGE_SAKUJO_SHINSEI = "SINSEI_SHUBETSU_SONOTA_URIAGE_SAKUJO_SHINSEI";
    /** 区分マスタ.申請種別.その他請求売上削除申請 */
    public static final String SINSEI_SHUBETSU_SONOTA_SEIKYU_URIAGE_SAKUJO_SHINSEI = "SINSEI_SHUBETSU_SONOTA_SEIKYU_URIAGE_SAKUJO_SHINSEI";
    /** 区分マスタ.申請種別.現金回収解除申請 */
    public static final String SINSEI_SHUBETSU_KIN_KAISHU_KAIJO_SHINSEI = "SINSEI_SHUBETSU_KIN_KAISHU_KAIJO_SHINSEI";
    /** 区分マスタ.申請種別.トレース削除申請 */
    public static final String SINSEI_SHUBETSU_TRACE_SAKUJO_SHINSEI = "SINSEI_SHUBETSU_TRACE_SAKUJO_SHINSEI";
    /** 区分マスタ.申請種別.締め解除申請 */
    public static final String SINSEI_SHUBETSU_SHIME_KAIJO_SHINSEI = "SINSEI_SHUBETSU_SHIME_KAIJO_SHINSEI";
    /** 区分マスタ.申請種別.ロジデータ削除申請 */
    public static final String SINSEI_SHUBETSU_LOGI_DATA_SAKUJO_SHINSEI = "SINSEI_SHUBETSU_LOGI_DATA_SAKUJO_SHINSEI";
    /** 区分マスタ.申請種別.集金解除申請 */
    public static final String SINSEI_SHUBETSU_SHUKIN_KAIJO_SHINSEI = "SINSEI_SHUBETSU_SHUKIN_KAIJO_SHINSEI";
    /** 区分マスタ.申請種別.パスワード初期化申請 */
    public static final String SINSEI_SHUBETSU_PASSWORD_SHOKIKA_SHINSEI = "SINSEI_SHUBETSU_PASSWORD_SHOKIKA_SHINSEI";
    /** 区分マスタ.申請種別.ユーザマスタ申請 */
    public static final String SINSEI_SHUBETSU_USER_MASTER_SHINSEI = "SINSEI_SHUBETSU_USER_MASTER_SHINSEI";
    /** 区分マスタ.申請種別.顧客マスタ申請 */
    public static final String SINSEI_SHUBETSU_KOKYAKU_MASTER_SHINSEI = "SINSEI_SHUBETSU_KOKYAKU_MASTER_SHINSEI";
    /** 区分マスタ.申請種別.仕入先マスタ申請 */
    public static final String SINSEI_SHUBETSU_SHIIRESAKI_MASTER_SHINSEI = "SINSEI_SHUBETSU_SHIIRESAKI_MASTER_SHINSEI";
    /** 区分マスタ.申請種別.施設マスタ申請 */
    public static final String SINSEI_SHUBETSU_SHISETSU_MASTER_SHINSEI = "SINSEI_SHUBETSU_SHISETSU_MASTER_SHINSEI";
    /** 区分マスタ.申請種別.月額自動請求マスタ */
    public static final String SINSEI_SHUBETSU_GETSUGAKU_JIDO_SEIKYU_MASTER = "SINSEI_SHUBETSU_GETSUGAKU_JIDO_SEIKYU_MASTER";
    /** 区分マスタ.申請種別.営業日カレンダー */
    public static final String SINSEI_SHUBETSU_EIGYOBI_CALENDER = "SINSEI_SHUBETSU_EIGYOBI_CALENDER";
    /** 区分マスタ.申請種別.ロジ料金表 */
    public static final String SINSEI_SHUBETSU_LOGI_RYOKIN_HYO = "SINSEI_SHUBETSU_LOGI_RYOKIN_HYO";
    /** 区分マスタ.申請種別.大量データDL */
    public static final String SINSEI_SHUBETSU_TAIRYO_DATA_DL = "SINSEI_SHUBETSU_TAIRYO_DATA_DL";
    /** 区分マスタ.申請種別.料金表取消申請 */
    public static final String SINSEI_SHUBETSU_RYOKIN_HYO_TORIKESHI = "SINSEI_SHUBETSU_RYOKIN_HYO_TORIKESHI";
    /** 区分マスタ.申請種別変更区分.登録 */
    public static final String SINSEI_SHUBETSU_HENKO_KBN_TOROKU = "SINSEI_SHUBETSU_HENKO_KBN_TOROKU";
    /** 区分マスタ.申請種別変更区分.変更 */
    public static final String SINSEI_SHUBETSU_HENKO_KBN_HENKO = "SINSEI_SHUBETSU_HENKO_KBN_HENKO";
    /** 区分マスタ.申請種別変更区分.削除 */
    public static final String SINSEI_SHUBETSU_HENKO_KBN_SAKUJO = "SINSEI_SHUBETSU_HENKO_KBN_SAKUJO";
    /** 区分マスタ.申請種別変更区分.適用終了 */
    public static final String SINSEI_SHUBETSU_HENKO_KBN_TEKIYO_SHURYO = "SINSEI_SHUBETSU_HENKO_KBN_TEKIYO_SHURYO";
    /** 区分マスタ.I/F区分.不要 */
    public static final String IF_TYPE_FUYO = "IF_TYPE_FUYO";
    /** 区分マスタ.I/F区分.要 */
    public static final String IF_TYPE_YO = "IF_TYPE_YO";
    /** 区分マスタ.I/F区分.済 */
    public static final String IF_TYPE_SUMI = "IF_TYPE_SUMI";
    /** 区分マスタ.赤黒区分.黒 */
    public static final String AKA_KURO_TYPE_KURO = "AKA_KURO_TYPE_KURO";
    /** 区分マスタ.赤黒区分.赤 */
    public static final String AKA_KURO_TYPE_AKA = "AKA_KURO_TYPE_AKA";
    /** 区分マスタ.汎用フラグ.OFF */
    public static final String HANYO_FLG_OFF = "HANYO_FLG_OFF";
    /** 区分マスタ.汎用フラグ.ON */
    public static final String HANYO_FLG_ON = "HANYO_FLG_ON";
    /** 区分マスタ.ユーザーマスタ使用区分.営業所ユーザー */
    public static final String USER_MASTER_SIYO_KBN_EIGYOSHO_USER = "USER_MASTER_SIYO_KBN_EIGYOSHO_USER";
    /** 区分マスタ.ユーザーマスタ使用区分.ドライバー */
    public static final String USER_MASTER_SIYO_KBN_DRIVER = "USER_MASTER_SIYO_KBN_DRIVER";
    /** 区分マスタ.輸送売上チェック判定ステータス.全て */
    public static final String YUSO_URIAGE_CHECK_HANTEI_STATUS_ALL = "YUSO_URIAGE_CHECK_HANTEI_STATUS_ALL";
    /** 区分マスタ.輸送売上チェック判定ステータス.プルーフチェック済 */
    public static final String YUSO_URIAGE_CHECK_HANTEI_STATUS_PROOF_CHECK_SUMI = "YUSO_URIAGE_CHECK_HANTEI_STATUS_PROOF_CHECK_SUMI";
    /** 区分マスタ.輸送売上チェック判定ステータス.プルーフ未チェック */
    public static final String YUSO_URIAGE_CHECK_HANTEI_STATUS_PROOF_MI_CHECK = "YUSO_URIAGE_CHECK_HANTEI_STATUS_PROOF_MI_CHECK";
    /** 区分マスタ.輸送売上チェック判定ステータス.チェック済 */
    public static final String YUSO_URIAGE_CHECK_HANTEI_STATUS_CHECK_SUMI = "YUSO_URIAGE_CHECK_HANTEI_STATUS_CHECK_SUMI";
    /** 区分マスタ.輸送売上チェック判定ステータス.未チェック */
    public static final String YUSO_URIAGE_CHECK_HANTEI_STATUS_MI_CHECK = "YUSO_URIAGE_CHECK_HANTEI_STATUS_MI_CHECK";
    /** 区分マスタ.輸送売上チェック判定ステータス.エラーあり */
    public static final String YUSO_URIAGE_CHECK_HANTEI_STATUS_ERROR_ARI = "YUSO_URIAGE_CHECK_HANTEI_STATUS_ERROR_ARI";
    /** 区分マスタ.輸送売上チェック判定ステータス.パラメータ不足 */
    public static final String YUSO_URIAGE_CHECK_HANTEI_STATUS_PARAMETER_BUSOKU = "YUSO_URIAGE_CHECK_HANTEI_STATUS_PARAMETER_BUSOKU";
    /** 区分マスタ.輸送売上チェック判定ステータス.保留 */
    public static final String YUSO_URIAGE_CHECK_HANTEI_STATUS_HORYU = "YUSO_URIAGE_CHECK_HANTEI_STATUS_HORYU";
    /** 区分マスタ.業者区分.代理店 */
    public static final String GYOSHA_KBN_DAIRITEN = "GYOSHA_KBN_DAIRITEN";
    /** 区分マスタ.業者区分.中継業者 */
    public static final String GYOSHA_KBN_CHUKEI_GYOSHA = "GYOSHA_KBN_CHUKEI_GYOSHA";
    /** 区分マスタ.借方 科目１.営業所現金 */
    public static final String KARIKATA_KAMOKU1_EIGYOSHO_KIN = "KARIKATA_KAMOKU1_EIGYOSHO_KIN";
    /** 区分マスタ.借方 科目１.当座預金 */
    public static final String KARIKATA_KAMOKU1_TOZA_YOKIN = "KARIKATA_KAMOKU1_TOZA_YOKIN";
    /** 区分マスタ.借方 科目１.電子記録債権 */
    public static final String KARIKATA_KAMOKU1_DENSHI_KIROKU_SAIKEN = "KARIKATA_KAMOKU1_DENSHI_KIROKU_SAIKEN";
    /** 区分マスタ.借方 科目１.顧客未収金CORE */
    public static final String KARIKATA_KAMOKU1_KOKYAKU_MISHU_KIN_CORE = "KARIKATA_KAMOKU1_KOKYAKU_MISHU_KIN_CORE";
    /** 区分マスタ.借方 科目１.代理店未収金 */
    public static final String KARIKATA_KAMOKU1_DAIRITEN_MISHU_KIN = "KARIKATA_KAMOKU1_DAIRITEN_MISHU_KIN";
    /** 区分マスタ.取引科目.振込入金 */
    public static final String TORIHIKI_KAMOKU_FURIKOMI_NYUKIN = "TORIHIKI_KAMOKU_FURIKOMI_NYUKIN";
    /** 区分マスタ.取引科目.みなし手数料 */
    public static final String TORIHIKI_KAMOKU_MINASHI_TESURYO = "TORIHIKI_KAMOKU_MINASHI_TESURYO";
    /** 区分マスタ.取引科目.仮受金 */
    public static final String TORIHIKI_KAMOKU_KARIUKEKIN = "TORIHIKI_KAMOKU_KARIUKEKIN";
    /** 区分マスタ.取引科目.振込手数料 */
    public static final String TORIHIKI_KAMOKU_FURIKOMI_TESURYO = "TORIHIKI_KAMOKU_FURIKOMI_TESURYO";
    /** 区分マスタ.貸方 科目１.顧客未収 */
    public static final String KASHIKATA_KAMOKU1_KOKYAKU_MISHU = "KASHIKATA_KAMOKU1_KOKYAKU_MISHU";
    /** 区分マスタ.トレース入力状況.集荷トレース未入力 */
    public static final String TRACE_NYURYOKU_JOKYO_SHUKA_TRACE_MI_NYURYOKU = "TRACE_NYURYOKU_JOKYO_SHUKA_TRACE_MI_NYURYOKU";
    /** 区分マスタ.トレース入力状況.配達完了トレース未入力 */
    public static final String TRACE_NYURYOKU_JOKYO_HAIKAN_TRACE_MI_NYURYOKU = "TRACE_NYURYOKU_JOKYO_HAIKAN_TRACE_MI_NYURYOKU";
    /** 区分マスタ.トレース入力状況.不在持帰トレース入力 */
    public static final String TRACE_NYURYOKU_JOKYO_FUZAI_MOCHI_KAESA_TRACE_NYURYOKU = "TRACE_NYURYOKU_JOKYO_FUZAI_MOCHI_KAESA_TRACE_NYURYOKU";
    /** 区分マスタ.トレース入力状況.持出トレース入力 */
    public static final String TRACE_NYURYOKU_JOKYO_MOCHIDASHI_TRACE_NYURYOKU = "TRACE_NYURYOKU_JOKYO_MOCHIDASHI_TRACE_NYURYOKU";
    /** 区分マスタ.申請アクティビティ.申請アクティビティ */
    public static final String SHINSEI_ACTIVITY_SHINSEI_ACTIVITY = "SHINSEI_ACTIVITY_SHINSEI_ACTIVITY";
    /** 区分マスタ.スキャン_エラー内容.読取不可 */
    public static final String SCAN_ERROR_NAIYO_YOMITORI_FUKA = "SCAN_ERROR_NAIYO_YOMITORI_FUKA";
    /** 区分マスタ.スキャン_エラー内容.複数バーコード有 */
    public static final String SCAN_ERROR_NAIYO_FUKUSU_BARCODE_ARI = "SCAN_ERROR_NAIYO_FUKUSU_BARCODE_ARI";
    /** 区分マスタ.スキャン_エラー内容.送り状No.重複 */
    public static final String SCAN_ERROR_NAIYO_OKURIJO_NO_CHOFUKU = "SCAN_ERROR_NAIYO_OKURIJO_NO_CHOFUKU";
    /** 区分マスタ.増し区分./Kg */
    public static final String MASHI_KBN_MAI_KG = "MASHI_KBN_MAI_KG";
    /** 区分マスタ.増し区分.増し */
    public static final String MASHI_KBN_MASHI = "MASHI_KBN_MASHI";
    /** 区分マスタ.配達指定時刻_注釈.指定 */
    public static final String HAITATSU_SHITEI_JIKOKU_CHUSHAKU_SHITEI = "HAITATSU_SHITEI_JIKOKU_CHUSHAKU_SHITEI";
    /** 区分マスタ.配達指定時刻_注釈.必着 */
    public static final String HAITATSU_SHITEI_JIKOKU_CHUSHAKU_HICCHAKU = "HAITATSU_SHITEI_JIKOKU_CHUSHAKU_HICCHAKU";
    /** 区分マスタ.送り状管理_出力対象.送り状 */
    public static final String OKURIJO_KANRI_SHUTSU_TAISHO_OKURIJO = "OKURIJO_KANRI_SHUTSU_TAISHO_OKURIJO";
    /** 区分マスタ.送り状管理_出力対象.荷札 */
    public static final String OKURIJO_KANRI_SHUTSU_TAISHO_NIFUDA = "OKURIJO_KANRI_SHUTSU_TAISHO_NIFUDA";
    /** 区分マスタ.送り状荷札_発行区分.未発行 */
    public static final String OKURIJO_NIFUDA_HAKKO_KBN_MI_HAKKO = "OKURIJO_NIFUDA_HAKKO_KBN_MI_HAKKO";
    /** 区分マスタ.送り状荷札_発行区分.発行済 */
    public static final String OKURIJO_NIFUDA_HAKKO_KBN_HAKKO_SUMI = "OKURIJO_NIFUDA_HAKKO_KBN_HAKKO_SUMI";
    /** 区分マスタ.送り状再発行区分.再発行 */
    public static final String OKURIJO_SAI_HAKKO_KBN_SAI_HAKKO = "OKURIJO_SAI_HAKKO_KBN_SAI_HAKKO";
    /** 区分マスタ.送り状再発行区分.仮発行 */
    public static final String OKURIJO_SAI_HAKKO_KBN_KARI_HAKKO = "OKURIJO_SAI_HAKKO_KBN_KARI_HAKKO";
    /** 区分マスタ.送り状発行先区分.Axis */
    public static final String OKURIJO_HAKKO_SAKI_KBN_AXIS = "OKURIJO_HAKKO_SAKI_KBN_AXIS";
    /** 区分マスタ.送り状発行先区分.伝まる */
    public static final String OKURIJO_HAKKO_SAKI_KBN_DEMMARU = "OKURIJO_HAKKO_SAKI_KBN_DEMMARU";
    /** 区分マスタ.重量区分.未満 */
    public static final String JURYO_KUBUN_MIMAN = "JURYO_KUBUN_MIMAN";
    /** 区分マスタ.重量区分.以下 */
    public static final String JURYO_KUBUN_IKA = "JURYO_KUBUN_IKA";
    /** 区分マスタ.重量区分.以上 */
    public static final String JURYO_KUBUN_IJO = "JURYO_KUBUN_IJO";
    /** 区分マスタ.往復区分.片道 */
    public static final String OFUKU_KUBUN_KATAMICHI = "OFUKU_KUBUN_KATAMICHI";
    /** 区分マスタ.往復区分.往復 */
    public static final String OFUKU_KUBUN_OFUKU = "OFUKU_KUBUN_OFUKU";
    /** 区分マスタ.新規使用可否.可 */
    public static final String SHINKI_SIYO_KAHI_KA = "SHINKI_SIYO_KAHI_KA";
    /** 区分マスタ.新規使用可否.不可 */
    public static final String SHINKI_SIYO_KAHI_FUKA = "SHINKI_SIYO_KAHI_FUKA";
    /** 区分マスタ.運賃種別.定額運賃 */
    public static final String UNCHIN_SHUBETSU_TEIGAKU_UNCHIN = "UNCHIN_SHUBETSU_TEIGAKU_UNCHIN";
    /** 区分マスタ.運賃種別.Kg当り運賃 */
    public static final String UNCHIN_SHUBETSU_KG_ATARI_UNCHIN = "UNCHIN_SHUBETSU_KG_ATARI_UNCHIN";
    /** 区分マスタ.仕入予定一覧_単位.月 */
    public static final String SHIIRE_YOTEI_ICHIRAN_TANI_TSUKI = "SHIIRE_YOTEI_ICHIRAN_TANI_TSUKI";
    /** 区分マスタ.仕入予定一覧_単位.日(曜日) */
    public static final String SHIIRE_YOTEI_ICHIRAN_TANI_HI_YOBI = "SHIIRE_YOTEI_ICHIRAN_TANI_HI_YOBI";
    /** 区分マスタ.仕入予定一覧_単位.日(明細) */
    public static final String SHIIRE_YOTEI_ICHIRAN_TANI_HI_MEISAI = "SHIIRE_YOTEI_ICHIRAN_TANI_HI_MEISAI";
    /** 区分マスタ.入金方法.集金 */
    public static final String NYUKIN_HOHO_KBN_SHUKIN = "NYUKIN_HOHO_KBN_SHUKIN";
    /** 区分マスタ.入金方法.振込 */
    public static final String NYUKIN_HOHO_KBN_FURIKOMI = "NYUKIN_HOHO_KBN_FURIKOMI";
    /** 区分マスタ.入金方法.手形 */
    public static final String NYUKIN_HOHO_KBN_TEGATA = "NYUKIN_HOHO_KBN_TEGATA";
    /** 区分マスタ.送り状NO入力元.手入力 */
    public static final String OKURIJO_NO_NYURYOKU_MOTO_TENYURYOKU = "OKURIJO_NO_NYURYOKU_MOTO_TENYURYOKU";
    /** 区分マスタ.送り状NO入力元.バーコード */
    public static final String OKURIJO_NO_NYURYOKU_MOTO_BARCODE = "OKURIJO_NO_NYURYOKU_MOTO_BARCODE";
    /** 区分マスタ.送り状NO入力元.QRコード */
    public static final String OKURIJO_NO_NYURYOKU_MOTO_QR_CD = "OKURIJO_NO_NYURYOKU_MOTO_QR_CD";
    /** 区分マスタ.JISチェック結果.すべて */
    public static final String JIS_CHECK_KEKKA_ALL = "JIS_CHECK_KEKKA_ALL";
    /** 区分マスタ.JISチェック結果.OK */
    public static final String JIS_CHECK_KEKKA_OK = "JIS_CHECK_KEKKA_OK";
    /** 区分マスタ.JISチェック結果.新規 */
    public static final String JIS_CHECK_KEKKA_SHINKI = "JIS_CHECK_KEKKA_SHINKI";
    /** 区分マスタ.JISチェック結果.差異あり */
    public static final String JIS_CHECK_KEKKA_SAI_ARI = "JIS_CHECK_KEKKA_SAI_ARI";
    /** 区分マスタ.JISチェック結果.廃止 */
    public static final String JIS_CHECK_KEKKA_HAISHI = "JIS_CHECK_KEKKA_HAISHI";
    /** 区分マスタ.JISチェック結果.データなし */
    public static final String JIS_CHECK_KEKKA_DATA_NASHI = "JIS_CHECK_KEKKA_DATA_NASHI";
    /** 区分マスタ.緊急度.緊急 */
    public static final String KINKYUDO_KINKYU = "KINKYUDO_KINKYU";
    /** 区分マスタ.緊急度.重要 */
    public static final String KINKYUDO_JUYO = "KINKYUDO_JUYO";
    /** 区分マスタ.緊急度.情報 */
    public static final String KINKYUDO_JOHO = "KINKYUDO_JOHO";
    /** 区分マスタ.メッセージ種別.事故防止 */
    public static final String MESSAGE_SHUBETSU_JIKOBOSHI = "MESSAGE_SHUBETSU_JIKOBOSHI";
    /** 区分マスタ.メッセージ種別.日次確認 */
    public static final String MESSAGE_SHUBETSU_HI_TSUGI_KAKUNIN = "MESSAGE_SHUBETSU_HI_TSUGI_KAKUNIN";
    /** 区分マスタ.メッセージ種別.処理完了通知 */
    public static final String MESSAGE_SHUBETSU_SHORI_KANRYO_TSUCHI = "MESSAGE_SHUBETSU_SHORI_KANRYO_TSUCHI";
    /** 区分マスタ.メッセージ種別.未処理警告 */
    public static final String MESSAGE_SHUBETSU_MI_SHORI_KEIKOKU = "MESSAGE_SHUBETSU_MI_SHORI_KEIKOKU";
    /** 区分マスタ.メッセージ種別.外部メッセージ */
    public static final String MESSAGE_SHUBETSU_GAIBU_MESSAGE = "MESSAGE_SHUBETSU_GAIBU_MESSAGE";
    /** 区分マスタ.無効のみ検索表示用キャプション.無効のみ検索 */
    public static final String MUKOU_NOMI_KENSAKU_MUKO_NOMI_KENSAKU = "MUKOU_NOMI_KENSAKU_MUKO_NOMI_KENSAKU";
    /** 区分マスタ.通知エリア表示有無.する */
    public static final String TSUCHI_AREA_HYOJI_UMU_SURU = "TSUCHI_AREA_HYOJI_UMU_SURU";
    /** 区分マスタ.通知エリア表示有無.しない */
    public static final String TSUCHI_AREA_HYOJI_UMU_SHINAI = "TSUCHI_AREA_HYOJI_UMU_SHINAI";
    /** 区分マスタ.仕入予定単位.日 */
    public static final String SHIIRE_YOTEI_TANI_HI = "SHIIRE_YOTEI_TANI_HI";
    /** 区分マスタ.仕入予定単位.月 */
    public static final String SHIIRE_YOTEI_TANI_TSUKI = "SHIIRE_YOTEI_TANI_TSUKI";
    /** 区分マスタ.通知エリア表示期間.分間 */
    public static final String TSUCHI_AREA_HYOJI_KIKAN_FUN_KAN = "TSUCHI_AREA_HYOJI_KIKAN_FUN_KAN";
    /** 区分マスタ.通知エリア表示期間.時間 */
    public static final String TSUCHI_AREA_HYOJI_KIKAN_JI_KAN = "TSUCHI_AREA_HYOJI_KIKAN_JI_KAN";
    /** 区分マスタ.通知エリア表示期間.日間 */
    public static final String TSUCHI_AREA_HYOJI_KIKAN_NICHI_KAN = "TSUCHI_AREA_HYOJI_KIKAN_NICHI_KAN";
    /** 区分マスタ.対応要否.対応要 */
    public static final String TAIO_YOHI_TAIO_YO = "TAIO_YOHI_TAIO_YO";
    /** 区分マスタ.対応要否.対応不要 */
    public static final String TAIO_YOHI_TAIO_FUYO = "TAIO_YOHI_TAIO_FUYO";
    /** 区分マスタ.有効無効.有効 */
    public static final String YUKO_MUKO_YUKO = "YUKO_MUKO_YUKO";
    /** 区分マスタ.有効無効.無効 */
    public static final String YUKO_MUKO_MUKO = "YUKO_MUKO_MUKO";
    /** 区分マスタ.送信先区分.全ユーザー */
    public static final String SOSHINSAKI_KBN_ZEN_USER = "SOSHINSAKI_KBN_ZEN_USER";
    /** 区分マスタ.送信先区分.指定 */
    public static final String SOSHINSAKI_KBN_SHITEI = "SOSHINSAKI_KBN_SHITEI";
    /** 区分マスタ.通知エリア表示一覧用.期限指定 */
    public static final String TSUCHI_AREA_HYOJI_ICHIRAN_YO_KIGEN_SHITEI = "TSUCHI_AREA_HYOJI_ICHIRAN_YO_KIGEN_SHITEI";
    /** 区分マスタ.通知エリア表示一覧用.期間指定 */
    public static final String TSUCHI_AREA_HYOJI_ICHIRAN_YO_KIKAN_SHITEI = "TSUCHI_AREA_HYOJI_ICHIRAN_YO_KIKAN_SHITEI";
    /** 区分マスタ.通知エリア表示一覧用.しない */
    public static final String TSUCHI_AREA_HYOJI_ICHIRAN_YO_SHINAI = "TSUCHI_AREA_HYOJI_ICHIRAN_YO_SHINAI";
    /** 区分マスタ.通知エリア表示期限.当日中 */
    public static final String TSUCHI_AREA_HYOJI_KIGEN_TOJITSU_CHU = "TSUCHI_AREA_HYOJI_KIGEN_TOJITSU_CHU";
    /** 区分マスタ.通知エリア表示期限.指定 */
    public static final String TSUCHI_AREA_HYOJI_KIGEN_SHITEI = "TSUCHI_AREA_HYOJI_KIGEN_SHITEI";
    /** 区分マスタ.曜日.日 */
    public static final String YOBI_HI = "YOBI_HI";
    /** 区分マスタ.曜日.月 */
    public static final String YOBI_TSUKI = "YOBI_TSUKI";
    /** 区分マスタ.曜日.火 */
    public static final String YOBI_KA = "YOBI_KA";
    /** 区分マスタ.曜日.水 */
    public static final String YOBI_SUI = "YOBI_SUI";
    /** 区分マスタ.曜日.木 */
    public static final String YOBI_MOKU = "YOBI_MOKU";
    /** 区分マスタ.曜日.金 */
    public static final String YOBI_KIN = "YOBI_KIN";
    /** 区分マスタ.曜日.土 */
    public static final String YOBI_DO = "YOBI_DO";
    /** 区分マスタ.カレンダーチェックボックス.休日 */
    public static final String CALENDAR_CHECKBOX_KYUJITSU = "CALENDAR_CHECKBOX_KYUJITSU";
    /** 区分マスタ.カレンダーチェックボックス.祝日 */
    public static final String CALENDAR_CHECKBOX_SHUKUJITSU = "CALENDAR_CHECKBOX_SHUKUJITSU";
    /** 区分マスタ.カレンダーチェックボックス.日曜 */
    public static final String CALENDAR_CHECKBOX_NICHIYO = "CALENDAR_CHECKBOX_NICHIYO";
    /** 区分マスタ.カレンダーラジオボタン.売上締日 */
    public static final String CALENDAR_RADIO_URIAGE_SHIMEBI = "CALENDAR_RADIO_URIAGE_SHIMEBI";
    /** 区分マスタ.カレンダーラジオボタン.入金締日 */
    public static final String CALENDAR_RADIO_NYUKIN_SHIMEBI = "CALENDAR_RADIO_NYUKIN_SHIMEBI";
    /** 区分マスタ.設定済区分.未設定 */
    public static final String SETTEISUMI_KUBUN_MI_SETTEI = "SETTEISUMI_KUBUN_MI_SETTEI";
    /** 区分マスタ.設定済区分.設定済 */
    public static final String SETTEISUMI_KUBUN_SETTEI_SUMI = "SETTEISUMI_KUBUN_SETTEI_SUMI";
    /** 区分マスタ.送信対象トレース.集荷 */
    public static final String SOSHIN_TAISHO_TRACE_SHUKA = "SOSHIN_TAISHO_TRACE_SHUKA";
    /** 区分マスタ.送信対象トレース.集荷降 */
    public static final String SOSHIN_TAISHO_TRACE_SHUKA_KO = "SOSHIN_TAISHO_TRACE_SHUKA_KO";
    /** 区分マスタ.送信対象トレース.積込 */
    public static final String SOSHIN_TAISHO_TRACE_TSUMIKOMI = "SOSHIN_TAISHO_TRACE_TSUMIKOMI";
    /** 区分マスタ.送信対象トレース.到着 */
    public static final String SOSHIN_TAISHO_TRACE_TOCHAKU = "SOSHIN_TAISHO_TRACE_TOCHAKU";
    /** 区分マスタ.送信対象トレース.持出 */
    public static final String SOSHIN_TAISHO_TRACE_MOCHIDASHI = "SOSHIN_TAISHO_TRACE_MOCHIDASHI";
    /** 区分マスタ.送信対象トレース.保管 */
    public static final String SOSHIN_TAISHO_TRACE_HOKAN = "SOSHIN_TAISHO_TRACE_HOKAN";
    /** 区分マスタ.送信対象トレース.不在持帰 */
    public static final String SOSHIN_TAISHO_TRACE_FUZAI_MOCHI_KAESA = "SOSHIN_TAISHO_TRACE_FUZAI_MOCHI_KAESA";
    /** 区分マスタ.送信対象トレース.受取拒否 */
    public static final String SOSHIN_TAISHO_TRACE_UKETORI_KYOHI = "SOSHIN_TAISHO_TRACE_UKETORI_KYOHI";
    /** 区分マスタ.送信対象トレース.顧客指示 */
    public static final String SOSHIN_TAISHO_TRACE_KOKYAKU_SHIJI = "SOSHIN_TAISHO_TRACE_KOKYAKU_SHIJI";
    /** 区分マスタ.送信対象トレース.配完 */
    public static final String SOSHIN_TAISHO_TRACE_HAIKAN = "SOSHIN_TAISHO_TRACE_HAIKAN";
    /** 区分マスタ.料金項目明細区分.通常 */
    public static final String RYOKIN_KOMOKU_MEISAI_KBN_TSUJO = "RYOKIN_KOMOKU_MEISAI_KBN_TSUJO";
    /** 区分マスタ.料金項目明細区分.値引 */
    public static final String RYOKIN_KOMOKU_MEISAI_KBN_NEBIKI = "RYOKIN_KOMOKU_MEISAI_KBN_NEBIKI";
    /** 区分マスタ.料金項目明細項目.明細以外 */
    public static final String RYOKIN_KOMOKU_MEISAI_KOMOKU_MEISAI_IGAI = "RYOKIN_KOMOKU_MEISAI_KOMOKU_MEISAI_IGAI";
    /** 区分マスタ.料金項目明細項目.明細合計 */
    public static final String RYOKIN_KOMOKU_MEISAI_KOMOKU_MEISAI_GOKEI = "RYOKIN_KOMOKU_MEISAI_KOMOKU_MEISAI_GOKEI";
    /** 区分マスタ.料金項目明細項目.直送チャーター料 */
    public static final String RYOKIN_KOMOKU_MEISAI_KOMOKU_CHOKUSO_CHARTER_RYO = "RYOKIN_KOMOKU_MEISAI_KOMOKU_CHOKUSO_CHARTER_RYO";
    /** 区分マスタ.料金項目明細項目.集荷チャーター料 */
    public static final String RYOKIN_KOMOKU_MEISAI_KOMOKU_SHUKA_CHARTER_RYO = "RYOKIN_KOMOKU_MEISAI_KOMOKU_SHUKA_CHARTER_RYO";
    /** 区分マスタ.料金項目明細項目.配達チャーター料 */
    public static final String RYOKIN_KOMOKU_MEISAI_KOMOKU_HAITATSU_CHARTER_RYO = "RYOKIN_KOMOKU_MEISAI_KOMOKU_HAITATSU_CHARTER_RYO";
    /** 区分マスタ.料金項目固定項目コード.パック運賃 */
    public static final String RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_PACK_UNCHIN = "RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_PACK_UNCHIN";
    /** 区分マスタ.料金項目固定項目コード.航空運賃 */
    public static final String RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_KOKU_UNCHIN = "RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_KOKU_UNCHIN";
    /** 区分マスタ.料金項目固定項目コード.集荷料 */
    public static final String RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_SHUKA_RYO = "RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_SHUKA_RYO";
    /** 区分マスタ.料金項目固定項目コード.取扱料 */
    public static final String RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_TORIATSUKAI_RYO = "RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_TORIATSUKAI_RYO";
    /** 区分マスタ.料金項目固定項目コード.配達料 */
    public static final String RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_HAITATSU_RYO = "RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_HAITATSU_RYO";
    /** 区分マスタ.料金項目固定項目コード.通信料 */
    public static final String RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_TSUSHIN_RYO = "RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_TSUSHIN_RYO";
    /** 区分マスタ.料金項目固定項目コード.発地その他 */
    public static final String RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_HOTCHI_SONOTA = "RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_HOTCHI_SONOTA";
    /** 区分マスタ.料金項目固定項目コード.着地その他 */
    public static final String RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_CHAKUCHI_SONOTA = "RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_CHAKUCHI_SONOTA";
    /** 区分マスタ.料金項目固定項目コード.着払手数料 */
    public static final String RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_CHAKUBARAI_TESURYO = "RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_CHAKUBARAI_TESURYO";
    /** 区分マスタ.料金項目固定項目コード.代引手数料 */
    public static final String RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_DAIBIKI_TESURYO = "RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_DAIBIKI_TESURYO";
    /** 区分マスタ.料金項目固定項目コード.明細合計 */
    public static final String RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_MEISAI_GOKEI = "RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_MEISAI_GOKEI";
    /** 区分マスタ.料金項目固定項目コード.直送チャーター料 */
    public static final String RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_CHOKUSO_CHARTER_RYO = "RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_CHOKUSO_CHARTER_RYO";
    /** 区分マスタ.料金項目固定項目コード.集荷チャーター料 */
    public static final String RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_SHUKA_CHARTER_RYO = "RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_SHUKA_CHARTER_RYO";
    /** 区分マスタ.料金項目固定項目コード.配達チャーター料 */
    public static final String RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_HAITATSU_CHARTER_RYO = "RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_HAITATSU_CHARTER_RYO";
    /** 区分マスタ.料金項目固定項目コード.消費税額 */
    public static final String RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_SHOHIZEI_GAKU = "RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_SHOHIZEI_GAKU";
    /** 区分マスタ.料金項目固定項目コード.保険料 */
    public static final String RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_HOKEN_RYO = "RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_HOKEN_RYO";
    /** 区分マスタ.料金項目固定項目コード.内税金額 */
    public static final String RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_UCHI_ZEI_KINGAKU = "RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_UCHI_ZEI_KINGAKU";
    /** 区分マスタ.料金項目固定項目コード.値引額 */
    public static final String RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_NEBIKI_GAKU = "RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_NEBIKI_GAKU";
    /** 区分マスタ.料金項目固定項目コード.運賃合計 */
    public static final String RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_UNCHIN_GOKEI = "RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_UNCHIN_GOKEI";
    /** 区分マスタ.料金項目固定項目コード.卸値計 */
    public static final String RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_OROSHINE_KEI = "RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_OROSHINE_KEI";
    /** 区分マスタ.料金項目固定項目コード.粗利益 */
    public static final String RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_ARARIEKI = "RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_ARARIEKI";
    /** 区分マスタ.料金項目固定項目コード.割戻 */
    public static final String RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_WARIMDS = "RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_WARIMDS";
    /** 区分マスタ.料金項目固定項目コード.着払回収金額 */
    public static final String RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_CHAKUBARAI_KAISHU_KINGAKU = "RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_CHAKUBARAI_KAISHU_KINGAKU";
    /** 区分マスタ.料金項目固定項目コード.代引回収金額 */
    public static final String RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_DAIBIKI_KAISHU_KINGAKU = "RYOKIN_KOMOKU_KOTEI_KOMOKU_CD_DAIBIKI_KAISHU_KINGAKU";
    /** 区分マスタ.プルーフ用集約項目.パック運賃 */
    public static final String PROOF_YOU_SHUYAKU_KOMOKU_PACK_UNCHIN = "PROOF_YOU_SHUYAKU_KOMOKU_PACK_UNCHIN";
    /** 区分マスタ.プルーフ用集約項目.集荷料 */
    public static final String PROOF_YOU_SHUYAKU_KOMOKU_SHUKA_RYO = "PROOF_YOU_SHUYAKU_KOMOKU_SHUKA_RYO";
    /** 区分マスタ.プルーフ用集約項目.航空料 */
    public static final String PROOF_YOU_SHUYAKU_KOMOKU_KOKU_RYO = "PROOF_YOU_SHUYAKU_KOMOKU_KOKU_RYO";
    /** 区分マスタ.プルーフ用集約項目.配達料 */
    public static final String PROOF_YOU_SHUYAKU_KOMOKU_HAITATSU_RYO = "PROOF_YOU_SHUYAKU_KOMOKU_HAITATSU_RYO";
    /** 区分マスタ.プルーフ用集約項目.集・直チャータ料 */
    public static final String PROOF_YOU_SHUYAKU_KOMOKU_SHU_CHAKU_CHARTER_RYO = "PROOF_YOU_SHUYAKU_KOMOKU_SHU_CHAKU_CHARTER_RYO";
    /** 区分マスタ.プルーフ用集約項目.配達チャータ料 */
    public static final String PROOF_YOU_SHUYAKU_KOMOKU_HAITATSU_CHARTER_RYO = "PROOF_YOU_SHUYAKU_KOMOKU_HAITATSU_CHARTER_RYO";
    /** 区分マスタ.プルーフ用集約項目.明細・その他 */
    public static final String PROOF_YOU_SHUYAKU_KOMOKU_MEISAI_SONOTA = "PROOF_YOU_SHUYAKU_KOMOKU_MEISAI_SONOTA";
    /** 区分マスタ.卸計上箇所.発営業所 */
    public static final String OROSHI_KEIJO_KASHO_HATSU_EIGYOSHO = "OROSHI_KEIJO_KASHO_HATSU_EIGYOSHO";
    /** 区分マスタ.卸計上箇所.着箇所 */
    public static final String OROSHI_KEIJO_KASHO_CHAKU_KASHO = "OROSHI_KEIJO_KASHO_CHAKU_KASHO";
    /** 区分マスタ.卸計上箇所.依頼箇所(引取) */
    public static final String OROSHI_KEIJO_KASHO_IRAI_KASHO_HIKITORI = "OROSHI_KEIJO_KASHO_IRAI_KASHO_HIKITORI";
    /** 区分マスタ.卸計上箇所.卸分配計算対象 */
    public static final String OROSHI_KEIJO_KASHO_OROSHI_BUMPAI_KEISAN_TAISHO = "OROSHI_KEIJO_KASHO_OROSHI_BUMPAI_KEISAN_TAISHO";
    /** 区分マスタ.卸値計算パターン.作業料 */
    public static final String OROSHI_KEISAN_PATTERN_SAGYORYO = "OROSHI_KEISAN_PATTERN_SAGYORYO";
    /** 区分マスタ.卸値計算パターン.倉庫料 */
    public static final String OROSHI_KEISAN_PATTERN_SOKO_RYO = "OROSHI_KEISAN_PATTERN_SOKO_RYO";
    /** 区分マスタ.卸値計算パターン.その他 */
    public static final String OROSHI_KEISAN_PATTERN_SONOTA = "OROSHI_KEISAN_PATTERN_SONOTA";
    /** 区分マスタ.売上セット先.スポット追加不可 */
    public static final String URIAGE_SET_SAKI_SPOT_TSUIKA_FUKA = "URIAGE_SET_SAKI_SPOT_TSUIKA_FUKA";
    /** 区分マスタ.売上セット先.スポット追加可能 */
    public static final String URIAGE_SET_SAKI_SPOT_TSUIKA_KANO = "URIAGE_SET_SAKI_SPOT_TSUIKA_KANO";
    /** 区分マスタ.世代検索条件.現在適用 */
    public static final String SEDAI_KENSAKU_JOKEN_GENZAI_TEKIYO = "SEDAI_KENSAKU_JOKEN_GENZAI_TEKIYO";
    /** 区分マスタ.世代検索条件.未来適用 */
    public static final String SEDAI_KENSAKU_JOKEN_MIRAI_TEKIYO = "SEDAI_KENSAKU_JOKEN_MIRAI_TEKIYO";
    /** 区分マスタ.世代検索条件.終了予定 */
    public static final String SEDAI_KENSAKU_JOKEN_SHURYO_YOTEI = "SEDAI_KENSAKU_JOKEN_SHURYO_YOTEI";
    /** 区分マスタ.世代検索条件.適用終了 */
    public static final String SEDAI_KENSAKU_JOKEN_TEKIYO_SHURYO = "SEDAI_KENSAKU_JOKEN_TEKIYO_SHURYO";
    /** 区分マスタ.世代検索条件.適用日指定 */
    public static final String SEDAI_KENSAKU_JOKEN_TEKIYO_HI_SHITEI = "SEDAI_KENSAKU_JOKEN_TEKIYO_HI_SHITEI";
    /** 区分マスタ.代理店使用区分.集荷店 */
    public static final String DAIRITEN_SIYO_KUBUN_SHUKA_TEN = "DAIRITEN_SIYO_KUBUN_SHUKA_TEN";
    /** 区分マスタ.代理店使用区分.配達店 */
    public static final String DAIRITEN_SIYO_KUBUN_HAITATSU_TEN = "DAIRITEN_SIYO_KUBUN_HAITATSU_TEN";
    /** 区分マスタ.代理店使用区分.チャーター起点 */
    public static final String DAIRITEN_SIYO_KUBUN_CHARTER_KITEN = "DAIRITEN_SIYO_KUBUN_CHARTER_KITEN";
    /** 区分マスタ.代理店使用区分.配達伝票出力店 */
    public static final String DAIRITEN_SIYO_KUBUN_HAIDEN_OUTPUT_TEN = "DAIRITEN_SIYO_KUBUN_HAIDEN_OUTPUT_TEN";
    /** 区分マスタ.画面表示用フラグ文字.無し */
    public static final String GAMEN_HYOJIYO_FLG_MOJI_NASHI = "GAMEN_HYOJIYO_FLG_MOJI_NASHI";
    /** 区分マスタ.画面表示用フラグ文字.あり */
    public static final String GAMEN_HYOJIYO_FLG_MOJI_ARI = "GAMEN_HYOJIYO_FLG_MOJI_ARI";
    /** 区分マスタ.画面表示用フラグ記号. */
    public static final String GAMEN_HYOJIYO_FLG_KIGO_BLANK = "GAMEN_HYOJIYO_FLG_KIGO_BLANK";
    /** 区分マスタ.画面表示用フラグ記号.○ */
    public static final String GAMEN_HYOJIYO_FLG_KIGO_MARU = "GAMEN_HYOJIYO_FLG_KIGO_MARU";
    /** 区分マスタ.集約コード区分.集約コード(営業所) */
    public static final String SHUYAKU_CD_KBN_SHUYAKU_CD_EIGYOSHO = "SHUYAKU_CD_KBN_SHUYAKU_CD_EIGYOSHO";
    /** 区分マスタ.集約コード区分.集約コード(本社) */
    public static final String SHUYAKU_CD_KBN_SHUYAKU_CD_HONSHA = "SHUYAKU_CD_KBN_SHUYAKU_CD_HONSHA";
    /** 区分マスタ.集約コード区分.集約コード(その他) */
    public static final String SHUYAKU_CD_KBN_SHUYAKU_CD_SONOTA = "SHUYAKU_CD_KBN_SHUYAKU_CD_SONOTA";
    /** 区分マスタ.集約コード区分.企業集約コード */
    public static final String SHUYAKU_CD_KBN_KIGYO_SHUYAKU_CD = "SHUYAKU_CD_KBN_KIGYO_SHUYAKU_CD";
    /** 区分マスタ.集約コード区分.法人グループ */
    public static final String SHUYAKU_CD_KBN_HOJIN_GROUP = "SHUYAKU_CD_KBN_HOJIN_GROUP";
    /** 区分マスタ.制御区分.表示しない */
    public static final String SEIGYO_KBN_HYOJI_SHINAI = "SEIGYO_KBN_HYOJI_SHINAI";
    /** 区分マスタ.制御区分.すべて表示 */
    public static final String SEIGYO_KBN_ALL_HYOJI = "SEIGYO_KBN_ALL_HYOJI";
    /** 区分マスタ.制御区分.業者のみ表示 */
    public static final String SEIGYO_KBN_GYOSHA_NOMI_HYOJI = "SEIGYO_KBN_GYOSHA_NOMI_HYOJI";
    /** 区分マスタ.送り状管理単位.会社単位 */
    public static final String OKURIJO_KANRI_TANI_KAISHA_TANI = "OKURIJO_KANRI_TANI_KAISHA_TANI";
    /** 区分マスタ.送り状管理単位.支店単位 */
    public static final String OKURIJO_KANRI_TANI_SHITEN_TANI = "OKURIJO_KANRI_TANI_SHITEN_TANI";
    /** 区分マスタ.送り状チェックディジット. */
    public static final String OKURIJO_CHECK_DIGIT_BLANK = "OKURIJO_CHECK_DIGIT_BLANK";
    /** 区分マスタ.送り状バーコード.NW-7 */
    public static final String OKURIJO_BARCODE_NW7 = "OKURIJO_BARCODE_NW7";
    /** 区分マスタ.送り状スタートストップ.* */
    public static final String OKURIJO_START_STOP_ASTERISK = "OKURIJO_START_STOP_ASTERISK";
    /** 区分マスタ.荷札印字体系.印字なし */
    public static final String NIFUDA_INJI_TAIKEI_INJI_NASHI = "NIFUDA_INJI_TAIKEI_INJI_NASHI";
    /** 区分マスタ.荷札印字体系.バーコード印字なし */
    public static final String NIFUDA_INJI_TAIKEI_BARCODE_INJI_NASHI = "NIFUDA_INJI_TAIKEI_BARCODE_INJI_NASHI";
    /** 区分マスタ.荷札枝番体系. */
    public static final String NIFUDA_EDABAN_TAIKEI_BLANK = "NIFUDA_EDABAN_TAIKEI_BLANK";
    /** 区分マスタ.荷札バーコード.NW-7 */
    public static final String NIFUDA_BARCODE_NW7 = "NIFUDA_BARCODE_NW7";
    /** 区分マスタ.荷札スタートストップ.* */
    public static final String NIFUDA_START_STOP_ASTERISK = "NIFUDA_START_STOP_ASTERISK";
    /** 区分マスタ.銀行口座種別.普通預金 */
    public static final String GINKO_KOZA_SHUBETU_FUTSU_YOKIN = "GINKO_KOZA_SHUBETU_FUTSU_YOKIN";
    /** 区分マスタ.銀行口座種別.当座預金 */
    public static final String GINKO_KOZA_SHUBETU_TOZA_YOKIN = "GINKO_KOZA_SHUBETU_TOZA_YOKIN";
    /** 区分マスタ.銀行口座種別.その他 */
    public static final String GINKO_KOZA_SHUBETU_SONOTA = "GINKO_KOZA_SHUBETU_SONOTA";
    /** 区分マスタ.並び順.集荷日順 */
    public static final String NARABIJUN_SHUKABI_JUN = "NARABIJUN_SHUKABI_JUN";
    /** 区分マスタ.並び順.荷送人順 */
    public static final String NARABIJUN_NIOKURININ_JUN = "NARABIJUN_NIOKURININ_JUN";
    /** 区分マスタ.並び順.仕向地順 */
    public static final String NARABIJUN_SHIMUKE_CHI_JUN = "NARABIJUN_SHIMUKE_CHI_JUN";
    /** 区分マスタ.並び順.登録順 */
    public static final String NARABIJUN_TOROKU_JUN = "NARABIJUN_TOROKU_JUN";
    /** 区分マスタ.卸種別区分.卸値なし */
    public static final String OROSHI_SYUBETU_KBN_OROSHINE_NASHI = "OROSHI_SYUBETU_KBN_OROSHINE_NASHI";
    /** 区分マスタ.卸種別区分.幹線卸 */
    public static final String OROSHI_SYUBETU_KBN_KANSEN_OROSHI = "OROSHI_SYUBETU_KBN_KANSEN_OROSHI";
    /** 区分マスタ.デフォルトフラグ.デフォルト */
    public static final String DEFAULT_FLG_DEFAULT = "DEFAULT_FLG_DEFAULT";
    /** 区分マスタ.ユーザー使用区分.未使用 */
    public static final String USER_SIYO_KBN_MI_SHIYO = "USER_SIYO_KBN_MI_SHIYO";
    /** 区分マスタ.ユーザー使用区分.使用中 */
    public static final String USER_SIYO_KBN_SHIYOCHU = "USER_SIYO_KBN_SHIYOCHU";
    /** 区分マスタ.グループ紐付け区分.未設定 */
    public static final String GROUP_HIMODUKE_KBN_MI_SETTEI = "GROUP_HIMODUKE_KBN_MI_SETTEI";
    /** 区分マスタ.グループ紐付け区分.設定済 */
    public static final String GROUP_HIMODUKE_KBN_SETTEI_SUMI = "GROUP_HIMODUKE_KBN_SETTEI_SUMI";
    /** 区分マスタ.機能種別.SCREEN */
    public static final String KINO_SHUBETSU_SCREEN = "KINO_SHUBETSU_SCREEN";
    /** 区分マスタ.機能種別.ACTION */
    public static final String KINO_SHUBETSU_ACTION = "KINO_SHUBETSU_ACTION";
    /** 区分マスタ.機能種別.TEXT */
    public static final String KINO_SHUBETSU_TEXT = "KINO_SHUBETSU_TEXT";
    /** 区分マスタ.利用設定.利用不可（非表示） */
    public static final String RIYO_SETTEI_RIYO_FUKA_HIHYOJI = "RIYO_SETTEI_RIYO_FUKA_HIHYOJI";
    /** 区分マスタ.利用設定.表示のみ */
    public static final String RIYO_SETTEI_HYOJI_NOMI = "RIYO_SETTEI_HYOJI_NOMI";
    /** 区分マスタ.利用設定.利用可能 */
    public static final String RIYO_SETTEI_RIYO_KANO = "RIYO_SETTEI_RIYO_KANO";
    /** 区分マスタ.デフォルトルート検索.デフォルトルート */
    public static final String DEFAULT_ROUTE_KENSAKU_DEFAULT_ROOT = "DEFAULT_ROUTE_KENSAKU_DEFAULT_ROOT";
    /** 区分マスタ.手数料負担.相手先負担 */
    public static final String TESURYO_FUTAN_AITESAKI_FUTAN = "TESURYO_FUTAN_AITESAKI_FUTAN";
    /** 区分マスタ.手数料負担.ＫＬＳ負担 */
    public static final String TESURYO_FUTAN_KLS_FUTAN = "TESURYO_FUTAN_KLS_FUTAN";
    /** 区分マスタ.支払条件.翌月末払い */
    public static final String SHIHARAI_JOKEN_YOKUGETSU_MATSU_BARAI = "SHIHARAI_JOKEN_YOKUGETSU_MATSU_BARAI";
    /** 区分マスタ.支払条件.その他　／ */
    public static final String SHIHARAI_JOKEN_SONOTA = "SHIHARAI_JOKEN_SONOTA";
    /** 区分マスタ.買掛金コード.営業未払金（ＡＰ）1022-01 */
    public static final String KAIKAKEKIN_CD_EIGYO_MIBARAIKIN_AP_1022_01 = "KAIKAKEKIN_CD_EIGYO_MIBARAIKIN_AP_1022_01";
    /** 区分マスタ.買掛金コード.未払金（ＡＰ）1050-01 */
    public static final String KAIKAKEKIN_CD_MIBARAIKIN_AP_1050_01 = "KAIKAKEKIN_CD_MIBARAIKIN_AP_1050_01";
    /** 区分マスタ.販売形態区分.A */
    public static final String HANBAI_KETAI_KBN_A = "HANBAI_KETAI_KBN_A";
    /** 区分マスタ.販売形態区分.N */
    public static final String HANBAI_KETAI_KBN_N = "HANBAI_KETAI_KBN_N";
    /** 区分マスタ.付帯料金項目_売上区分.輸送／その他売上 */
    public static final String FUTAI_RYOKIN_KOMOKU_SALES_TYPE_YUSO_SONOTA_URIAGE = "FUTAI_RYOKIN_KOMOKU_SALES_TYPE_YUSO_SONOTA_URIAGE";
    /** 区分マスタ.付帯料金項目_売上区分.その他請求 */
    public static final String FUTAI_RYOKIN_KOMOKU_SALES_TYPE_SONOTA_SEIKYU = "FUTAI_RYOKIN_KOMOKU_SALES_TYPE_SONOTA_SEIKYU";
    /** 区分マスタ.管轄区分.全社 */
    public static final String KANKATSU_KBN_ZENSHA = "KANKATSU_KBN_ZENSHA";
    /** 区分マスタ.管轄区分.箇所 */
    public static final String KANKATSU_KBN_KASHO = "KANKATSU_KBN_KASHO";
    /** 区分マスタ.使用区分.航空会社 */
    public static final String SHIYO_KBN_KOKU_GAISHA = "SHIYO_KBN_KOKU_GAISHA";
    /** 区分マスタ.使用区分.代理店 */
    public static final String SHIYO_KBN_DAIRITEN = "SHIYO_KBN_DAIRITEN";
    /** 区分マスタ.使用区分.幹線業者 */
    public static final String SHIYO_KBN_KANSEN_GYOSHA = "SHIYO_KBN_KANSEN_GYOSHA";
    /** 区分マスタ.使用区分.中継業者 */
    public static final String SHIYO_KBN_CHUKEI_GYOSHA = "SHIYO_KBN_CHUKEI_GYOSHA";
    /** 区分マスタ.使用区分.チャーター業者 */
    public static final String SHIYO_KBN_CHARTER_GYOSHA = "SHIYO_KBN_CHARTER_GYOSHA";
    /** 区分マスタ.使用区分.その他 */
    public static final String SHIYO_KBN_SONOTA = "SHIYO_KBN_SONOTA";
    /** 区分マスタ.削除済のみ.削除済のみ */
    public static final String SAKUJO_SUMI_NOMI_SAKUJO_SUMI_NOMI = "SAKUJO_SUMI_NOMI_SAKUJO_SUMI_NOMI";
    /** 区分マスタ.運賃計算区分.自動 */
    public static final String UNCHIN_KEISAN_KBN_JIDO = "UNCHIN_KEISAN_KBN_JIDO";
    /** 区分マスタ.運賃計算区分.手動 */
    public static final String UNCHIN_KEISAN_KBN_SHUDO = "UNCHIN_KEISAN_KBN_SHUDO";
    /** 区分マスタ.車両一覧表示区分. */
    public static final String SHARYO_ITIRAN_HYOJI_KBN_BLANK = "SHARYO_ITIRAN_HYOJI_KBN_BLANK";
    /** 区分マスタ.車両一覧表示区分.有 */
    public static final String SHARYO_ITIRAN_HYOJI_KBN_ARI = "SHARYO_ITIRAN_HYOJI_KBN_ARI";
    /** 区分マスタ.車両一覧表示区分.無 */
    public static final String SHARYO_ITIRAN_HYOJI_KBN_NASHI = "SHARYO_ITIRAN_HYOJI_KBN_NASHI";
    /** 区分マスタ.承認区分.営業所 */
    public static final String SHONIN_KBN_EIGYOSHO = "SHONIN_KBN_EIGYOSHO";
    /** 区分マスタ.承認区分.本社営業部 */
    public static final String SHONIN_KBN_HONSHA_EIGYO_BU = "SHONIN_KBN_HONSHA_EIGYO_BU";
    /** 区分マスタ.承認区分.本社 */
    public static final String SHONIN_KBN_HONSHA = "SHONIN_KBN_HONSHA";
    /** 区分マスタ.営業所マスタ_営業所種別.営業所 */
    public static final String MS_EIGYOSHO_SHUBETSU_EIGYOSHO = "MS_EIGYOSHO_SHUBETSU_EIGYOSHO";
    /** 区分マスタ.営業所マスタ_営業所種別.FC */
    public static final String MS_EIGYOSHO_SHUBETSU_FC = "MS_EIGYOSHO_SHUBETSU_FC";
    /** 区分マスタ.営業所マスタ_営業所種別.本社 */
    public static final String MS_EIGYOSHO_SHUBETSU_HONSHA = "MS_EIGYOSHO_SHUBETSU_HONSHA";
    /** 区分マスタ.離島館内配送.離島含む */
    public static final String RITO_KANNAI_HAISO_RITO_FUKUMU = "RITO_KANNAI_HAISO_RITO_FUKUMU";
    /** 区分マスタ.離島館内配送.離島住所登録あり */
    public static final String RITO_KANNAI_HAISO_RITO_JUSHO_TOROKU_ARI = "RITO_KANNAI_HAISO_RITO_JUSHO_TOROKU_ARI";
    /** 区分マスタ.離島館内配送.館内配送登録あり */
    public static final String RITO_KANNAI_HAISO_KANNAI_HAISO_TOUROKU_ARI = "RITO_KANNAI_HAISO_KANNAI_HAISO_TOUROKU_ARI";
    /** 区分マスタ.離島有無.離島を含む */
    public static final String RITO_UMU_RITO_FUKUMU = "RITO_UMU_RITO_FUKUMU";
    /** 区分マスタ.旧住所区分.旧住所 */
    public static final String KYU_JUSHO_KBN_KYU_JUSHO = "KYU_JUSHO_KBN_KYU_JUSHO";
    /** 区分マスタ.旧住所区分.使用不可 */
    public static final String KYU_JUSHO_KBN_SHIYO_FUKA = "KYU_JUSHO_KBN_SHIYO_FUKA";
    /** 区分マスタ.営業所マスタ_使用区分.集荷営業所 */
    public static final String MS_EIGYOSHO_SIYO_KBN_SHUKA_EIGYOSHO = "MS_EIGYOSHO_SIYO_KBN_SHUKA_EIGYOSHO";
    /** 区分マスタ.営業所マスタ_使用区分.配達営業所 */
    public static final String MS_EIGYOSHO_SIYO_KBN_HAITATSU_EIGYOSHO = "MS_EIGYOSHO_SIYO_KBN_HAITATSU_EIGYOSHO";
    /** 区分マスタ.営業所マスタ_使用区分.チャーター起点 */
    public static final String MS_EIGYOSHO_SIYO_KBN_CHARTER_KITEN = "MS_EIGYOSHO_SIYO_KBN_CHARTER_KITEN";
    /** 区分マスタ.営業所マスタ_使用区分.売上 */
    public static final String MS_EIGYOSHO_SIYO_KBN_URIAGE = "MS_EIGYOSHO_SIYO_KBN_URIAGE";
    /** 区分マスタ.営業所マスタ_使用区分.発券営業所 */
    public static final String MS_EIGYOSHO_SIYO_KBN_HAKKEN_EIGYOSHO = "MS_EIGYOSHO_SIYO_KBN_HAKKEN_EIGYOSHO";
    /** 区分マスタ.営業所マスタ_使用区分.車両管理 */
    public static final String MS_EIGYOSHO_SIYO_KBN_SHARYO_KANRI = "MS_EIGYOSHO_SIYO_KBN_SHARYO_KANRI";
    /** 区分マスタ.営業所マスタ_使用区分.配達伝票出力営業所 */
    public static final String MS_EIGYOSHO_SIYO_KBN_HAIDEN_OUTPUT_EIGYOSHO = "MS_EIGYOSHO_SIYO_KBN_HAIDEN_OUTPUT_EIGYOSHO";
    /** 区分マスタ.荷受人マスタ検索条件並び順.コード順 */
    public static final String NIUKENIN_MST_KENSAKUJOKEN_NARABIJUN_CODEJUN = "NIUKENIN_MST_KENSAKUJOKEN_NARABIJUN_CODEJUN";
    /** 区分マスタ.荷受人マスタ検索条件並び順.カナ順 */
    public static final String NIUKENIN_MST_KENSAKUJOKEN_NARABIJUN_KANAJUN = "NIUKENIN_MST_KENSAKUJOKEN_NARABIJUN_KANAJUN";
    /** 区分マスタ.荷受人マスタ検索条件並び順.住所順 */
    public static final String NIUKENIN_MST_KENSAKUJOKEN_NARABIJUN_JUSHOJUN = "NIUKENIN_MST_KENSAKUJOKEN_NARABIJUN_JUSHOJUN";
    /** 区分マスタ.荷受人マスタ検索条件並び順.使用日順 */
    public static final String NIUKENIN_MST_KENSAKUJOKEN_NARABIJUN_SHIYOBIJUN = "NIUKENIN_MST_KENSAKUJOKEN_NARABIJUN_SHIYOBIJUN";
    /** 区分マスタ.要修正分のみ.要修正分のみ */
    public static final String YOSHUSEIBUN_NOMI_YOSHUSEIBUN_NOMI = "YOSHUSEIBUN_NOMI_YOSHUSEIBUN_NOMI";
    /** 区分マスタ.旧住所警告分も表示.旧住所警告分も表示 */
    public static final String KYU_JUSHO_KEIKOKUBUN_MO_HYOJI_KYU_JUSHO_KEIKOKUBUN_MO_HYOJI = "KYU_JUSHO_KEIKOKUBUN_MO_HYOJI_KYU_JUSHO_KEIKOKUBUN_MO_HYOJI";
    /** 区分マスタ.VOID入力_作業区分.登録 */
    public static final String VOID_NYURYOKU_SAGYO_KBN_TOROKU = "VOID_NYURYOKU_SAGYO_KBN_TOROKU";
    /** 区分マスタ.VOID入力_作業区分.検索 */
    public static final String VOID_NYURYOKU_SAGYO_KBN_KENSAKU = "VOID_NYURYOKU_SAGYO_KBN_KENSAKU";
    /** 区分マスタ.料金表設定なし検索.料金表設定のないコードも表示する */
    public static final String RYOKIN_HYO_SETTEI_NASHI_KENSAK_RYOKIN_HYO_SETTEI_NASHI = "RYOKIN_HYO_SETTEI_NASHI_KENSAK_RYOKIN_HYO_SETTEI_NASHI";
    /** 区分マスタ.デフォルトのみ検索.デフォルトのみ */
    public static final String DEFAULT_NOMI_KENSAKU_DEFAULT_NOMI = "DEFAULT_NOMI_KENSAKU_DEFAULT_NOMI";
    /** 区分マスタ.輸送売上セット先.運賃１ */
    public static final String YUSOURIAGE_SET_SAKI_UNCHIN_1 = "YUSOURIAGE_SET_SAKI_UNCHIN_1";
    /** 区分マスタ.輸送売上セット先.その他１ */
    public static final String YUSOURIAGE_SET_SAKI_SONOTA_1 = "YUSOURIAGE_SET_SAKI_SONOTA_1";
    /** 区分マスタ.所属終了含む検索.所属終了含む */
    public static final String SHOZOKU_SHURYO_FUKUMU_KENSAKU_SHOZOKU_SHURYO_FUKUMU = "SHOZOKU_SHURYO_FUKUMU_KENSAKU_SHOZOKU_SHURYO_FUKUMU";
    /** 区分マスタ.休日計上.する */
    public static final String KYUJITSU_KEIJO_KYUJITSU_KEIJO = "KYUJITSU_KEIJO_KYUJITSU_KEIJO";
    /** 区分マスタ.理由・対処方法入力有無.全て */
    public static final String JOKEN_GAI_MISHU_RIYU_TAISHO_UMU_ALL = "JOKEN_GAI_MISHU_RIYU_TAISHO_UMU_ALL";
    /** 区分マスタ.理由・対処方法入力有無.有り */
    public static final String JOKEN_GAI_MISHU_RIYU_TAISHO_UMU_ARI = "JOKEN_GAI_MISHU_RIYU_TAISHO_UMU_ARI";
    /** 区分マスタ.理由・対処方法入力有無.無し */
    public static final String JOKEN_GAI_MISHU_RIYU_TAISHO_UMU_NASHI = "JOKEN_GAI_MISHU_RIYU_TAISHO_UMU_NASHI";
    /** 区分マスタ.ランク入力有無.全て */
    public static final String JOKEN_GAI_MISHU_RANK_UMU_ALL = "JOKEN_GAI_MISHU_RANK_UMU_ALL";
    /** 区分マスタ.ランク入力有無.有り */
    public static final String JOKEN_GAI_MISHU_RANK_UMU_ARI = "JOKEN_GAI_MISHU_RANK_UMU_ARI";
    /** 区分マスタ.ランク入力有無.無し */
    public static final String JOKEN_GAI_MISHU_RANK_UMU_NASHI = "JOKEN_GAI_MISHU_RANK_UMU_NASHI";
    /** 区分マスタ.残高有無.すべて */
    public static final String JOKEN_GAI_MISHU_ZANDAKA_UMU_ALL = "JOKEN_GAI_MISHU_ZANDAKA_UMU_ALL";
    /** 区分マスタ.残高有無.残高あり */
    public static final String JOKEN_GAI_MISHU_ZANDAKA_UMU_ARI = "JOKEN_GAI_MISHU_ZANDAKA_UMU_ARI";
    /** 区分マスタ.残高有無.残高なし */
    public static final String JOKEN_GAI_MISHU_ZANDAKA_UMU_NASHI = "JOKEN_GAI_MISHU_ZANDAKA_UMU_NASHI";
    /** 区分マスタ.MAWB状況照会_使用区分.使用済 */
    public static final String MAWB_JYOKYO_SHOKAI_SIYO_KBN_SHIYOZUMI = "MAWB_JYOKYO_SHOKAI_SIYO_KBN_SHIYOZUMI";
    /** 区分マスタ.MAWB状況照会_使用区分.未使用 */
    public static final String MAWB_JYOKYO_SHOKAI_SIYO_KBN_MISHIYO = "MAWB_JYOKYO_SHOKAI_SIYO_KBN_MISHIYO";
    /** 区分マスタ.MAWB状況照会_使用区分.VOID済 */
    public static final String MAWB_JYOKYO_SHOKAI_SIYO_KBN_VOIDZUMI = "MAWB_JYOKYO_SHOKAI_SIYO_KBN_VOIDZUMI";
    /** 区分マスタ.MAWB状況照会_使用区分.小口分のみ */
    public static final String MAWB_JYOKYO_SHOKAI_SIYO_KBN_KOGUCHIBUNNOMI = "MAWB_JYOKYO_SHOKAI_SIYO_KBN_KOGUCHIBUNNOMI";
    /** 区分マスタ.業務種別.配達業務 */
    public static final String GYOMU_SHUBETSU_HAITATSU_GYOMU = "GYOMU_SHUBETSU_HAITATSU_GYOMU";
    /** 区分マスタ.業務種別.集荷業務 */
    public static final String GYOMU_SHUBETSU_SHUKA_GYOMU = "GYOMU_SHUBETSU_SHUKA_GYOMU";
    /** 区分マスタ.予定表示切替.配達予定 */
    public static final String YOTEI_HYOJI_KIRIKAE_YOTEI_HYOJI_KIRIKAE_HAITATSU_YOTEI = "YOTEI_HYOJI_KIRIKAE_YOTEI_HYOJI_KIRIKAE_HAITATSU_YOTEI";
    /** 区分マスタ.予定表示切替.集荷予定 */
    public static final String YOTEI_HYOJI_KIRIKAE_YOTEI_HYOJI_KIRIKAE_SHUKA_YOTEI = "YOTEI_HYOJI_KIRIKAE_YOTEI_HYOJI_KIRIKAE_SHUKA_YOTEI";
    /** 区分マスタ.顧客EDI区分選択.アップロード */
    public static final String KOKYAKU_EDI_KBN_SENTAKU_UPLOAD = "KOKYAKU_EDI_KBN_SENTAKU_UPLOAD";
    /** 区分マスタ.顧客EDI区分選択.顧客EDI */
    public static final String KOKYAKU_EDI_KBN_SENTAKU_KOKYAKU_EDI = "KOKYAKU_EDI_KBN_SENTAKU_KOKYAKU_EDI";
    /** 区分マスタ.顧客EDI区分選択.外部I/F */
    public static final String KOKYAKU_EDI_KBN_SENTAKU_GAIBU_IF = "KOKYAKU_EDI_KBN_SENTAKU_GAIBU_IF";
    /** 区分マスタ.顧客EDI区分選択.バッチ */
    public static final String KOKYAKU_EDI_KBN_SENTAKU_BATCH = "KOKYAKU_EDI_KBN_SENTAKU_BATCH";
    /** 区分マスタ.EDI種別.トレース送信 */
    public static final String EDI_SHUBETSU_TRACE_SOSHIN = "EDI_SHUBETSU_TRACE_SOSHIN";
    /** 区分マスタ.EDI種別.請求情報送信 */
    public static final String EDI_SHUBETSU_SEIKYU_JOHO_SOSHIN = "EDI_SHUBETSU_SEIKYU_JOHO_SOSHIN";
    /** 区分マスタ.EDI種別.その他 */
    public static final String EDI_SHUBETSU_SONOTA = "EDI_SHUBETSU_SONOTA";
    /** 区分マスタ.添付ファイル設定.平文 */
    public static final String TEMPU_FILE_SETTEI_HIRABUN = "TEMPU_FILE_SETTEI_HIRABUN";
    /** 区分マスタ.添付ファイル設定.ZIP圧縮 */
    public static final String TEMPU_FILE_SETTEI_ZIP_ASSHUKU = "TEMPU_FILE_SETTEI_ZIP_ASSHUKU";
    /** 区分マスタ.添付ファイル設定.暗号化ZIP */
    public static final String TEMPU_FILE_SETTEI_ANGOKA_ZIP = "TEMPU_FILE_SETTEI_ANGOKA_ZIP";
    /** 区分マスタ.パスワード生成方式.固定 */
    public static final String PASSWORD_SEISEI_HOSHIKI_KOTEI = "PASSWORD_SEISEI_HOSHIKI_KOTEI";
    /** 区分マスタ.パスワード生成方式.ランダム */
    public static final String PASSWORD_SEISEI_HOSHIKI_RANDOM = "PASSWORD_SEISEI_HOSHIKI_RANDOM";
    /** 区分マスタ.パスワード送付.別メール */
    public static final String PASSWORD_SOFU_BETSU_MAIL = "PASSWORD_SOFU_BETSU_MAIL";
    /** 区分マスタ.パスワード送付.送付なし */
    public static final String PASSWORD_SOFU_SOFU_NASHI = "PASSWORD_SOFU_SOFU_NASHI";
    /** 区分マスタ.ファイルタイプ.固定長 */
    public static final String FILE_TYPE_KOTEICHO = "FILE_TYPE_KOTEICHO";
    /** 区分マスタ.ファイルタイプ.CSV */
    public static final String FILE_TYPE_CSV = "FILE_TYPE_CSV";
    /** 区分マスタ.ファイルタイプ.TSV */
    public static final String FILE_TYPE_TSV = "FILE_TYPE_TSV";
    /** 区分マスタ.ファイルタイプ.Excel */
    public static final String FILE_TYPE_EXCEL = "FILE_TYPE_EXCEL";
    /** 区分マスタ.実行タイミング区分.毎日 */
    public static final String JIKKO_TIMMING_KBN_MAINICHI = "JIKKO_TIMMING_KBN_MAINICHI";
    /** 区分マスタ.実行タイミング区分.指定日 */
    public static final String JIKKO_TIMMING_KBN_SHITEI_BI = "JIKKO_TIMMING_KBN_SHITEI_BI";
    /** 区分マスタ.実行タイミング区分.指定曜日 */
    public static final String JIKKO_TIMMING_KBN_SHITEI_YOBI = "JIKKO_TIMMING_KBN_SHITEI_YOBI";
    /** 区分マスタ.休日送信設定.土曜日送信 */
    public static final String KYUJITSU_SOSHIN_SETTEI_DOYO_BI_SOSHIN = "KYUJITSU_SOSHIN_SETTEI_DOYO_BI_SOSHIN";
    /** 区分マスタ.休日送信設定.日曜日送信 */
    public static final String KYUJITSU_SOSHIN_SETTEI_NICHIYO_BI_SOSHIN = "KYUJITSU_SOSHIN_SETTEI_NICHIYO_BI_SOSHIN";
    /** 区分マスタ.休日送信設定.祝日送信 */
    public static final String KYUJITSU_SOSHIN_SETTEI_SHUKUJITSU_SOSHIN = "KYUJITSU_SOSHIN_SETTEI_SHUKUJITSU_SOSHIN";
    /** 区分マスタ.休日送信設定.KLS休日送信 */
    public static final String KYUJITSU_SOSHIN_SETTEI_KLS_KYUJITSU_SOSHIN = "KYUJITSU_SOSHIN_SETTEI_KLS_KYUJITSU_SOSHIN";
    /** 区分マスタ.請求情報_送信区分.料金報告(日次) */
    public static final String SEIKYU_INFO_SOSHIN_KBN_RYOKIN_HOKOKU_NICHIJI = "SEIKYU_INFO_SOSHIN_KBN_RYOKIN_HOKOKU_NICHIJI";
    /** 区分マスタ.請求情報_送信区分.料金報告(任意) */
    public static final String SEIKYU_INFO_SOSHIN_KBN_RYOKIN_HOKOKU_NINI = "SEIKYU_INFO_SOSHIN_KBN_RYOKIN_HOKOKU_NINI";
    /** 区分マスタ.請求情報_送信区分.締め請求データ(通常) */
    public static final String SEIKYU_INFO_SOSHIN_KBN_SHIME_SEIKYU_DATA_TSUJO = "SEIKYU_INFO_SOSHIN_KBN_SHIME_SEIKYU_DATA_TSUJO";
    /** 区分マスタ.請求情報_送信区分.締め請求データ(任意) */
    public static final String SEIKYU_INFO_SOSHIN_KBN_SHIME_SEIKYU_DATA_NINI = "SEIKYU_INFO_SOSHIN_KBN_SHIME_SEIKYU_DATA_NINI";
    /** 区分マスタ.メール設定_送信区分.To */
    public static final String MAIL_SETTEI_SOSHIN_KBN_TO = "MAIL_SETTEI_SOSHIN_KBN_TO";
    /** 区分マスタ.メール設定_送信区分.CC */
    public static final String MAIL_SETTEI_SOSHIN_KBN_CC = "MAIL_SETTEI_SOSHIN_KBN_CC";
    /** 区分マスタ.メール設定_送信区分.BCC */
    public static final String MAIL_SETTEI_SOSHIN_KBN_BCC = "MAIL_SETTEI_SOSHIN_KBN_BCC";
    /** 区分マスタ.現金回収_支払区分.全件 */
    public static final String GENKIN_KAISHU_SHIHARAI_KBN_ZENKEN = "GENKIN_KAISHU_SHIHARAI_KBN_ZENKEN";
    /** 区分マスタ.現金回収_支払区分.前払 */
    public static final String GENKIN_KAISHU_SHIHARAI_KBN_MAEBARAI = "GENKIN_KAISHU_SHIHARAI_KBN_MAEBARAI";
    /** 区分マスタ.現金回収_支払区分.着払 */
    public static final String GENKIN_KAISHU_SHIHARAI_KBN_CHAKUBARAI = "GENKIN_KAISHU_SHIHARAI_KBN_CHAKUBARAI";
    /** 区分マスタ.現金回収_支払区分.他社後払 */
    public static final String GENKIN_KAISHU_SHIHARAI_KBN_TASHA_ATOBARAI = "GENKIN_KAISHU_SHIHARAI_KBN_TASHA_ATOBARAI";
    /** 区分マスタ.現金回収_支払区分.代引 */
    public static final String GENKIN_KAISHU_SHIHARAI_KBN_DAIBIKI = "GENKIN_KAISHU_SHIHARAI_KBN_DAIBIKI";
    /** 区分マスタ.現金回収_状態.全件 */
    public static final String GENKIN_KAISHU_JOTAI_ZENKEN = "GENKIN_KAISHU_JOTAI_ZENKEN";
    /** 区分マスタ.現金回収_状態.未回収 */
    public static final String GENKIN_KAISHU_JOTAI_MI_KAISHU = "GENKIN_KAISHU_JOTAI_MI_KAISHU";
    /** 区分マスタ.現金回収_状態.回収済 */
    public static final String GENKIN_KAISHU_JOTAI_KAISHU_SUMI = "GENKIN_KAISHU_JOTAI_KAISHU_SUMI";
    /** 区分マスタ.現金回収_状態.後払確定済 */
    public static final String GENKIN_KAISHU_JOTAI_ATOBARAI_KAKUTEI_SUMI = "GENKIN_KAISHU_JOTAI_ATOBARAI_KAKUTEI_SUMI";
    /** 区分マスタ.申請ステータス.未申請 */
    public static final String SHINSEI_STATUS_MI_SHINSEI = "SHINSEI_STATUS_MI_SHINSEI";
    /** 区分マスタ.申請ステータス.承認待ち */
    public static final String SHINSEI_STATUS_SHONIN_MACHI = "SHINSEI_STATUS_SHONIN_MACHI";
    /** 区分マスタ.申請ステータス.承認済み */
    public static final String SHINSEI_STATUS_SHONIN_ZUMI = "SHINSEI_STATUS_SHONIN_ZUMI";
    /** 区分マスタ.申請ステータス.差戻し */
    public static final String SHINSEI_STATUS_SASHIMODOSHI = "SHINSEI_STATUS_SASHIMODOSHI";
    /** 区分マスタ.申請ステータス.申請取消 */
    public static final String SHINSEI_STATUS_SHINSEI_TORIKESHI = "SHINSEI_STATUS_SHINSEI_TORIKESHI";
    /** 区分マスタ.JISコードのみ.JISコードのみ */
    public static final String JIS_CD_NOMI_JIS_CD_NOMI = "JIS_CD_NOMI_JIS_CD_NOMI";
    /** 区分マスタ.未使用MAWB表示.未使用MAWB表示 */
    public static final String MISHIYO_MAWB_HYOJI_MISHIYO_MAWB_HYOJI = "MISHIYO_MAWB_HYOJI_MISHIYO_MAWB_HYOJI";
    /** 区分マスタ.荷受人マスタ_旧住所区分.旧 */
    public static final String MS_NIUKENIN_KYU_JUSHO_KBN_KYU = "MS_NIUKENIN_KYU_JUSHO_KBN_KYU";
    /** 区分マスタ.荷受人マスタ_旧住所区分.不可 */
    public static final String MS_NIUKENIN_KYU_JUSHO_KBN_FUKA = "MS_NIUKENIN_KYU_JUSHO_KBN_FUKA";
    /** 区分マスタ.荷受人マスタ_エラー内容.使用不可住所 */
    public static final String MS_NIUKENIN_ERROR_NAIYO_SHIYO_FUKA_JUSHO = "MS_NIUKENIN_ERROR_NAIYO_SHIYO_FUKA_JUSHO";
    /** 区分マスタ.荷受人マスタ_エラー内容.要修正データ有 */
    public static final String MS_NIUKENIN_ERROR_NAIYO_YOSHUSEI_DATA_ARI = "MS_NIUKENIN_ERROR_NAIYO_YOSHUSEI_DATA_ARI";
    /** 区分マスタ.小計位置.上 */
    public static final String SUBTOTAL_POSITION_ABOVE = "SUBTOTAL_POSITION_ABOVE";
    /** 区分マスタ.小計位置.下 */
    public static final String SUBTOTAL_POSITION_BELOW = "SUBTOTAL_POSITION_BELOW";
    /** 区分マスタ.売上入力の個数を使用.使用する */
    public static final String URIAGE_NYURYOKU_KOSU_SHIYO_SHIYO_SURU = "URIAGE_NYURYOKU_KOSU_SHIYO_SHIYO_SURU";
    /** 区分マスタ.備考段組み.1列 */
    public static final String BIKO_DANGUMI1 = "BIKO_DANGUMI1";
    /** 区分マスタ.備考段組み.2列 */
    public static final String BIKO_DANGUMI2 = "BIKO_DANGUMI2";
    /** 区分マスタ.ハンディ持参区分.持参なし */
    public static final String HANDY_JISAN_KBN_JISAN_NASHI = "HANDY_JISAN_KBN_JISAN_NASHI";
    /** 区分マスタ.ハンディ持参区分.持参 */
    public static final String HANDY_JISAN_KBN_JISAN = "HANDY_JISAN_KBN_JISAN";
    /** 区分マスタ.ノーマル運賃重量増区分.増し */
    public static final String NORMAL_WEIGHT_INCREASE_TYPE_MASHI = "NORMAL_WEIGHT_INCREASE_TYPE_MASHI";
    /** 区分マスタ.状態区分.正常 */
    public static final String JOTAI_KBN_SEIJO = "JOTAI_KBN_SEIJO";
    /** 区分マスタ.状態区分.要修正 */
    public static final String JOTAI_KBN_YOSHUSEI = "JOTAI_KBN_YOSHUSEI";
    /** 区分マスタ.状態区分.エラー */
    public static final String JOTAI_KBN_ERROR = "JOTAI_KBN_ERROR";
    /** 区分マスタ.状態区分.スキップ */
    public static final String JOTAI_KBN_SKIP = "JOTAI_KBN_SKIP";
    /** 区分マスタ.状態区分.取込対象外 */
    public static final String JOTAI_KBN_TORIKOMI_TAISHOGAI = "JOTAI_KBN_TORIKOMI_TAISHOGAI";
    /** 区分マスタ.状態区分.判断不可 */
    public static final String JOTAI_KBN_HANDAN_FUKA = "JOTAI_KBN_HANDAN_FUKA";
    /** 区分マスタ.登録区分.新規 */
    public static final String TOROKU_KBN_SHINKI = "TOROKU_KBN_SHINKI";
    /** 区分マスタ.登録区分.変更 */
    public static final String TOROKU_KBN_HENKO = "TOROKU_KBN_HENKO";
    /** 区分マスタ.登録区分.削除 */
    public static final String TOROKU_KBN_SAKUJO = "TOROKU_KBN_SAKUJO";
    /** 区分マスタ.入力日付.1 */
    public static final String NYURYOKU_HIZUKE_1 = "NYURYOKU_HIZUKE_1";
    /** 区分マスタ.入力日付.2 */
    public static final String NYURYOKU_HIZUKE_2 = "NYURYOKU_HIZUKE_2";
    /** 区分マスタ.入力日付.3 */
    public static final String NYURYOKU_HIZUKE_3 = "NYURYOKU_HIZUKE_3";
    /** 区分マスタ.入力日付.4 */
    public static final String NYURYOKU_HIZUKE_4 = "NYURYOKU_HIZUKE_4";
    /** 区分マスタ.入力日付.5 */
    public static final String NYURYOKU_HIZUKE_5 = "NYURYOKU_HIZUKE_5";
    /** 区分マスタ.入力日付.6 */
    public static final String NYURYOKU_HIZUKE_6 = "NYURYOKU_HIZUKE_6";
    /** 区分マスタ.入力日付.7 */
    public static final String NYURYOKU_HIZUKE_7 = "NYURYOKU_HIZUKE_7";
    /** 区分マスタ.入力日付.8 */
    public static final String NYURYOKU_HIZUKE_8 = "NYURYOKU_HIZUKE_8";
    /** 区分マスタ.入力日付.9 */
    public static final String NYURYOKU_HIZUKE_9 = "NYURYOKU_HIZUKE_9";
    /** 区分マスタ.入力日付.10 */
    public static final String NYURYOKU_HIZUKE_10 = "NYURYOKU_HIZUKE_10";
    /** 区分マスタ.入力日付.11 */
    public static final String NYURYOKU_HIZUKE_11 = "NYURYOKU_HIZUKE_11";
    /** 区分マスタ.入力日付.12 */
    public static final String NYURYOKU_HIZUKE_12 = "NYURYOKU_HIZUKE_12";
    /** 区分マスタ.入力日付.13 */
    public static final String NYURYOKU_HIZUKE_13 = "NYURYOKU_HIZUKE_13";
    /** 区分マスタ.入力日付.14 */
    public static final String NYURYOKU_HIZUKE_14 = "NYURYOKU_HIZUKE_14";
    /** 区分マスタ.入力日付.15 */
    public static final String NYURYOKU_HIZUKE_15 = "NYURYOKU_HIZUKE_15";
    /** 区分マスタ.入力日付.16 */
    public static final String NYURYOKU_HIZUKE_16 = "NYURYOKU_HIZUKE_16";
    /** 区分マスタ.入力日付.17 */
    public static final String NYURYOKU_HIZUKE_17 = "NYURYOKU_HIZUKE_17";
    /** 区分マスタ.入力日付.18 */
    public static final String NYURYOKU_HIZUKE_18 = "NYURYOKU_HIZUKE_18";
    /** 区分マスタ.入力日付.19 */
    public static final String NYURYOKU_HIZUKE_19 = "NYURYOKU_HIZUKE_19";
    /** 区分マスタ.入力日付.20 */
    public static final String NYURYOKU_HIZUKE_20 = "NYURYOKU_HIZUKE_20";
    /** 区分マスタ.入力日付.21 */
    public static final String NYURYOKU_HIZUKE_21 = "NYURYOKU_HIZUKE_21";
    /** 区分マスタ.入力日付.22 */
    public static final String NYURYOKU_HIZUKE_22 = "NYURYOKU_HIZUKE_22";
    /** 区分マスタ.入力日付.23 */
    public static final String NYURYOKU_HIZUKE_23 = "NYURYOKU_HIZUKE_23";
    /** 区分マスタ.入力日付.24 */
    public static final String NYURYOKU_HIZUKE_24 = "NYURYOKU_HIZUKE_24";
    /** 区分マスタ.入力日付.25 */
    public static final String NYURYOKU_HIZUKE_25 = "NYURYOKU_HIZUKE_25";
    /** 区分マスタ.入力日付.26 */
    public static final String NYURYOKU_HIZUKE_26 = "NYURYOKU_HIZUKE_26";
    /** 区分マスタ.入力日付.27 */
    public static final String NYURYOKU_HIZUKE_27 = "NYURYOKU_HIZUKE_27";
    /** 区分マスタ.入力日付.28 */
    public static final String NYURYOKU_HIZUKE_28 = "NYURYOKU_HIZUKE_28";
    /** 区分マスタ.入力日付.29 */
    public static final String NYURYOKU_HIZUKE_29 = "NYURYOKU_HIZUKE_29";
    /** 区分マスタ.入力日付.30 */
    public static final String NYURYOKU_HIZUKE_30 = "NYURYOKU_HIZUKE_30";
    /** 区分マスタ.入力日付.31 */
    public static final String NYURYOKU_HIZUKE_31 = "NYURYOKU_HIZUKE_31";
    /** 区分マスタ.入力日付.99（月末） */
    public static final String NYURYOKU_HIZUKE_99_GETSUMATSU = "NYURYOKU_HIZUKE_99_GETSUMATSU";
    /** 区分マスタ.見積りシミュレーション実行ステータス.待機中 */
    public static final String SIM_JIKKO_STATUS_TAIKICHU = "SIM_JIKKO_STATUS_TAIKICHU";
    /** 区分マスタ.見積りシミュレーション実行ステータス.実行中 */
    public static final String SIM_JIKKO_STATUS_JIKKOCHU = "SIM_JIKKO_STATUS_JIKKOCHU";
    /** 区分マスタ.見積りシミュレーション実行ステータス.完了 */
    public static final String SIM_JIKKO_STATUS_KANRYO = "SIM_JIKKO_STATUS_KANRYO";
    /** 区分マスタ.消費税計算単位.明細単位 */
    public static final String SHOHIZEI_KEISAN_TANI_MEISAI = "SHOHIZEI_KEISAN_TANI_MEISAI";
    /** 区分マスタ.消費税計算単位.合算後 */
    public static final String SHOHIZEI_KEISAN_TANI_GASSAN_GO = "SHOHIZEI_KEISAN_TANI_GASSAN_GO";
    /** 区分マスタ.重量区分.実重量 */
    public static final String JURYO_KBN_JITSU_JURO = "JURYO_KBN_JITSU_JURO";
    /** 区分マスタ.重量区分.容積重量 */
    public static final String JURYO_KBN_YOSEKI_JURO = "JURYO_KBN_YOSEKI_JURO";
    /** 区分マスタ.重量区分.大きい重量を使用 */
    public static final String JURYO_KBN_OKI_JURO_SHIYO = "JURYO_KBN_OKI_JURO_SHIYO";
    /** 区分マスタ.ロジ売上計算単位.明細単位 */
    public static final String LOGI_URIAGE_KEISAN_TANI_MEISAI = "LOGI_URIAGE_KEISAN_TANI_MEISAI";
    /** 区分マスタ.ロジ売上計算単位.数量合算単位 */
    public static final String LOGI_URIAGE_KEISAN_TANI_SURYO_GASSAN = "LOGI_URIAGE_KEISAN_TANI_SURYO_GASSAN";
    /** 区分マスタ.送り状マスタ参照.荷受人マスタ */
    public static final String OKURIJOU_SANSYO_NIUKENIN = "OKURIJOU_SANSYO_NIUKENIN";
    /** 区分マスタ.送り状マスタ参照.荷送人マスタ */
    public static final String OKURIJOU_SANSYO_NIOKURININ = "OKURIJOU_SANSYO_NIOKURININ";
    /** 区分マスタ.送り状マスタ参照.記事マスタ */
    public static final String OKURIJOU_SANSYO_KIJI = "OKURIJOU_SANSYO_KIJI";
    /** 区分マスタ.送り状マスタ参照.品名マスタ */
    public static final String OKURIJOU_SANSYO_HIMMEI = "OKURIJOU_SANSYO_HIMMEI";
    /** 区分マスタ.申請ステータス（一覧）.未申請 */
    public static final String SHINSEI_STATUS_ICHIRAN_MI_SHINSEI = "SHINSEI_STATUS_ICHIRAN_MI_SHINSEI";
    /** 区分マスタ.申請ステータス（一覧）.承認待ち */
    public static final String SHINSEI_STATUS_ICHIRAN_SHONIN_MACHI = "SHINSEI_STATUS_ICHIRAN_SHONIN_MACHI";
    /** 区分マスタ.申請ステータス（一覧）.承認済み */
    public static final String SHINSEI_STATUS_ICHIRAN_SHONIN_ZUMI = "SHINSEI_STATUS_ICHIRAN_SHONIN_ZUMI";
    /** 区分マスタ.申請ステータス（一覧）.差戻し */
    public static final String SHINSEI_STATUS_ICHIRAN_SASHIMODOSHI = "SHINSEI_STATUS_ICHIRAN_SASHIMODOSHI";
    /** 区分マスタ.申請ステータス（一覧）.申請取消 */
    public static final String SHINSEI_STATUS_ICHIRAN_SHINSEI_TORIKESHI = "SHINSEI_STATUS_ICHIRAN_SHINSEI_TORIKESHI";
    /** 区分マスタ.申請ステータス（一覧）.適用終了 */
    public static final String SHINSEI_STATUS_ICHIRAN_TEKIYO_SHURYO = "SHINSEI_STATUS_ICHIRAN_TEKIYO_SHURYO";
    /** 区分マスタ.申請ステータス（一覧）.削除 */
    public static final String SHINSEI_STATUS_ICHIRAN_SAKUJO = "SHINSEI_STATUS_ICHIRAN_SAKUJO";
    /** 区分マスタ.申請状況.未申請 */
    public static final String SHINSEI_JOKYO_MI_SHINSEI = "SHINSEI_JOKYO_MI_SHINSEI";
    /** 区分マスタ.申請状況.承認待ち */
    public static final String SHINSEI_JOKYO_SHONIN_MACHI = "SHINSEI_JOKYO_SHONIN_MACHI";
    /** 区分マスタ.申請状況.承認済 */
    public static final String SHINSEI_JOKYO_SHONIN_ZUMI = "SHINSEI_JOKYO_SHONIN_ZUMI";
    /** 区分マスタ.申請状況.差戻し */
    public static final String SHINSEI_JOKYO_SASHIMODOSHI = "SHINSEI_JOKYO_SASHIMODOSHI";
    /** 区分マスタ.サブ組織表示用キャプション.サブ組織を含む */
    public static final String SUB_SOSHIKI_HYOJI_YO_SUB_SOSHIKI_WO_HUKUMU = "SUB_SOSHIKI_HYOJI_YO_SUB_SOSHIKI_WO_HUKUMU";
    /** 区分マスタ.承認状況自動実行.Axis処理 */
    public static final String SHONIN_JOKYO_JIDO_JIKKO_AXIS_SHORI = "SHONIN_JOKYO_JIDO_JIKKO_AXIS_SHORI";
    /** 区分マスタ.承認状況自動実行.自動実行 */
    public static final String SHONIN_JOKYO_JIDO_JIKKO_JIDO_JIKKO = "SHONIN_JOKYO_JIDO_JIKKO_JIDO_JIKKO";

    /** システムマスタ.コードグループ.cuscmn */
    public static final String SYS_CDGROUP_CUSCMN = "cuscmn";
    /** システムマスタ.コードグループ.unccmn */
    public static final String SYS_CDGROUP_UNCCMN = "unccmn";
    /** システムマスタ.コードグループ.system */
    public static final String SYS_CDGROUP_SYSTEM = "system";
    /** システムマスタ.コードグループ.lgn011 */
    public static final String SYS_CDGROUP_LGN011 = "lgn011";
    /** システムマスタ.コードグループ.lgn021 */
    public static final String SYS_CDGROUP_LGN021 = "lgn021";
        /** システムマスタ.コードグループ.lgn031 */
    public static final String SYS_CDGROUP_LGN031 = "lgn031";
    /** システムマスタ.コードグループ.pro018 */
    public static final String SYS_CDGROUP_PRO018 = "pro018";
    /** システムマスタ.コードグループ.pro019 */
    public static final String SYS_CDGROUP_PRO019 = "pro019";
    /** システムマスタ.コードグループ.procmn */
    public static final String SYS_CDGROUP_PROCMN = "procmn";
    /** システムマスタ.コードグループ.mst251 */
    public static final String SYS_CDGROUP_MST251 = "mst251";
    /** システムマスタ.コードグループ.top001 */
    public static final String SYS_CDGROUP_TOP001 = "top001";
    /** システムマスタ.コードグループ.unc051 */
    public static final String SYS_CDGROUP_UNC051 = "unc051";
    /** システムマスタ.コードグループ.unc061 */
    public static final String SYS_CDGROUP_UNC061 = "unc061";
    /** システムマスタ.コードグループ.pro017 */
    public static final String SYS_CDGROUP_PRO017 = "pro017";
    /** システムマスタ.コードグループ.pro016 */
    public static final String SYS_CDGROUP_PRO016 = "pro016";
    /** システムマスタ.コードグループ.mst172 */
    public static final String SYS_CDGROUP_MST172 = "mst172";
    /** システムマスタ.コードグループ.stc011 */
    public static final String SYS_CDGROUP_STC011 = "stc011";
    /** システムマスタ.コードグループ.stc031 */
    public static final String SYS_CDGROUP_STC031 = "stc031";
    /** システムマスタ.コードグループ.mst461 */
    public static final String SYS_CDGROUP_MST461 = "mst461";
    /** システムマスタ.コードグループ.est021 */
    public static final String SYS_CDGROUP_EST021 = "est021";
    /** システムマスタ.コードグループ.est022 */
    public static final String SYS_CDGROUP_EST022 = "est022";
    /** システムマスタ.コードグループ.mst031 */
    public static final String SYS_CDGROUP_MST031 = "mst031";
    /** システムマスタ.コードグループ.mst091 */
    public static final String SYS_CDGROUP_MST091 = "mst091";
    /** システムマスタ.コードグループ.mst131 */
    public static final String SYS_CDGROUP_MST131 = "mst131";
    /** システムマスタ.コードグループ.mst171 */
    public static final String SYS_CDGROUP_MST171 = "mst171";
    /** システムマスタ.コードグループ.mst361 */
    public static final String SYS_CDGROUP_MST361 = "mst361";
    /** システムマスタ.コードグループ.mst362 */
    public static final String SYS_CDGROUP_MST362 = "mst362";
    /** システムマスタ.コードグループ.mst363 */
    public static final String SYS_CDGROUP_MST363 = "mst363";

    /** システムマスタ.コードグループ.ロジの顧客コードの先頭1文字を設定 */
    public static final String SYS_CD_LOJI_KOKYAKU_SENTOU = "loji_kokyaku_sentou";
    /** システムマスタ.コードグループ.その他請求の顧客コードの先頭1文字を設定 */
    public static final String SYS_CD_SONOTA_SEIKYU_KOKYAKU_SENTOU = "sonota_seikyu_kokyaku_sentou";
    /** システムマスタ.コードグループ.とりまとめ請求の顧客コードの先頭1文字を設定 */
    public static final String SYS_CD_TORIMATOME_SEIKYU_KOKYAKU_SENTOU = "torimatome_seikyu_kokyaku_sentou";
    /** システムマスタ.コードグループ.一見の顧客コードの先頭1文字を設定 */
    public static final String SYS_CD_ICHIGEN_KOKYAKU_SENTOU = "ichigen_kokyaku_sentou";
    /** システムマスタ.コードグループ.社内便の顧客コードの先頭1文字を設定 */
    public static final String SYS_CD_SYANAIBIN_SENTOU = "syanaibin_sentou";
    /** システムマスタ.コードグループ.着払代引未収の顧客コードの先頭3文字を設定 */
    public static final String SYS_CD_DAIBIKI_MISYU_KOKYAKU_SENTOU = "daibiki_misyu_kokyaku_sentou";
    /** システムマスタ.コードグループ.条件外未収 請求回数 「過去12ヶ月」×「月当たりの締回数」 */
    public static final String SYS_CD_JYOKENGAI_SEIKYUKAISU = "jyokengai_seikyukaisu";
    /** システムマスタ.コードグループ.条件外未収 条件外回数 表示しきい値 */
    public static final String SYS_CD_JYOKENGAI_JYOKENGAI_KAISU_SHIKI = "jyokengai_jyokengai_kaisu_shiki";
    /** システムマスタ.コードグループ.条件外未収 自社責任のランク */
    public static final String SYS_CD_JYOKENGAI_JISHASEKININ = "jyokengai_jishasekinin";
    /** システムマスタ.コードグループ.顧客マスタの備考１の使用　0:使用不可　1:使用可 */
    public static final String SYS_CD_KOKYAKU_BIKO_1_USE = "kokyaku_biko_1_use";
    /** システムマスタ.コードグループ.顧客マスタの備考２の使用　0:使用不可　1:使用可 */
    public static final String SYS_CD_KOKYAKU_BIKO_2_USE = "kokyaku_biko_2_use";
    /** システムマスタ.コードグループ.顧客マスタの備考３の使用　0:使用不可　1:使用可 */
    public static final String SYS_CD_KOKYAKU_BIKO_3_USE = "kokyaku_biko_3_use";
    /** システムマスタ.コードグループ.顧客マスタの備考４の使用　0:使用不可　1:使用可 */
    public static final String SYS_CD_KOKYAKU_BIKO_4_USE = "kokyaku_biko_4_use";
    /** システムマスタ.コードグループ.顧客マスタの備考５の使用　0:使用不可　1:使用可 */
    public static final String SYS_CD_KOKYAKU_BIKO_5_USE = "kokyaku_biko_5_use";
    /** システムマスタ.コードグループ.顧客マスタの備考６の使用　0:使用不可　1:使用可 */
    public static final String SYS_CD_KOKYAKU_BIKO_6_USE = "kokyaku_biko_6_use";
    /** システムマスタ.コードグループ.顧客マスタの備考７の使用　0:使用不可　1:使用可 */
    public static final String SYS_CD_KOKYAKU_BIKO_7_USE = "kokyaku_biko_7_use";
    /** システムマスタ.コードグループ.顧客マスタの備考８の使用　0:使用不可　1:使用可 */
    public static final String SYS_CD_KOKYAKU_BIKO_8_USE = "kokyaku_biko_8_use";
    /** システムマスタ.コードグループ.顧客マスタの備考９の使用　0:使用不可　1:使用可 */
    public static final String SYS_CD_KOKYAKU_BIKO_9_USE = "kokyaku_biko_9_use";
    /** システムマスタ.コードグループ.顧客マスタの備考１０の使用　0:使用不可　1:使用可 */
    public static final String SYS_CD_KOKYAKU_BIKO_10_USE = "kokyaku_biko_10_use";
    /** システムマスタ.コードグループ.背景色　完了 */
    public static final String SYS_CD_BG_COLOR_COMPLETE = "bg_color_complete";
    /** システムマスタ.コードグループ.背景色　ポイント */
    public static final String SYS_CD_BG_COLOR_POINTED = "bg_color_pointed";
    /** システムマスタ.コードグループ.背景色　選択 */
    public static final String SYS_CD_BG_COLOR_SELECTED = "bg_color_selected";
    /** システムマスタ.コードグループ.背景色　マウスオバー */
    public static final String SYS_CD_BG_COLOR_MOUSEOVER = "bg_color_mouseover";
    /** システムマスタ.コードグループ.背景色　注意 */
    public static final String SYS_CD_BG_COLOR_WARNING = "bg_color_warning";
    /** システムマスタ.コードグループ.背景色　エラー */
    public static final String SYS_CD_BG_COLOR_ERROR = "bg_color_error";
    /** システムマスタ.コードグループ.文字色　完了 */
    public static final String SYS_CD_TEXT_LIST_COMPLETE = "text_list_complete";
    /** システムマスタ.コードグループ.文字色　ポイント */
    public static final String SYS_CD_TEXT_COLOR_POINTED = "text_color_pointed";
    /** システムマスタ.コードグループ.文字色　選択 */
    public static final String SYS_CD_TEXT_COLOR_SELECTED = "text_color_selected";
    /** システムマスタ.コードグループ.文字色　マウスオーバー */
    public static final String SYS_CD_TEXT_COLOR_MOUSEOVER = "text_color_mouseover";
    /** システムマスタ.コードグループ.文字色　注意 */
    public static final String SYS_CD_TEXT_COLOR_WARNING = "text_color_warning";
    /** システムマスタ.コードグループ.文字色　エラー */
    public static final String SYS_CD_TEXT_COLOR_ERROR = "text_color_error";
    /** システムマスタ.コードグループ.背景色　通常 */
    public static final String SYS_CD_BG_COLOR_NORMAL = "bg_color_normal";
    /** システムマスタ.コードグループ.背景色　読取専用 */
    public static final String SYS_CD_BG_COLOR_READONLY = "bg_color_readonly";
    /** システムマスタ.コードグループ.背景色　必須 */
    public static final String SYS_CD_BG_COLOR_NECESSARY = "bg_color_necessary";
    /** システムマスタ.コードグループ.背景色　変更済み */
    public static final String SYS_CD_BG_COLOR_EDITED = "bg_color_edited";
    /** システムマスタ.コードグループ.文字色　通常 */
    public static final String SYS_CD_TEXT_COLOR_NORMAL = "text_color_normal";
    /** システムマスタ.コードグループ.文字色　読取専用 */
    public static final String SYS_CD_TEXT_COLOR_READONLY = "text_color_readonly";
    /** システムマスタ.コードグループ.文字色　必須 */
    public static final String SYS_CD_TEXT_COLOR_NECESSARY = "text_color_necessary";
    /** システムマスタ.コードグループ.文字色　変更済み */
    public static final String SYS_CD_TEXT_COLOR_EDITED = "text_color_edited";
    /** システムマスタ.コードグループ.スキャン未確定の時間超過の基準となる時間(h) */
    public static final String SYS_CD_ELAPSED_TIME = "elapsed_time";
    /** システムマスタ.コードグループ.売上漏れの基準となるトレース */
    public static final String SYS_CD_STANDARD_TRACE = "standard_trace";
    /** システムマスタ.コードグループ.顧客コードが特定できない場合に売上を立てる営業所 */
    public static final String SYS_CD_DEFAULT_SALES_OFFICE = "default_sales_office";
    /** システムマスタ.コードグループ.請求後、訂正可能な期間(日数) */
    public static final String SYS_CD_SAISHIME_ENABLE_PERIOD = "saishime_enable_period";
    /** システムマスタ.コードグループ.請求後、訂正不可となる閾値の日数 */
    public static final String SYS_CD_SALES_CORRECT_DISABLE_PERIOD = "sales_correct_disable_period";
    /** システムマスタ.コードグループ.料金計算時の切り上げ閾値 */
    public static final String SYS_CD_THRESHOLD_VALUE = "threshold_value";
    /** システムマスタ.コードグループ.切り上げ単位(閾値未満) */
    public static final String SYS_CD_CEIL_UNIT_UNDER_THRESHOLD = "ceil_unit_under_threshold";
    /** システムマスタ.コードグループ.切り上げ単位(閾値以上) */
    public static final String SYS_CD_CEIL_UNIT_THRESHOULD_OR_OVER = "ceil_unit_threshould_or_over";
    /** システムマスタ.コードグループ.容積重量の換算地 */
    public static final String SYS_CD_CONVERSION_OF_WEIGHT = "conversion_of_weight";
    /** システムマスタ.コードグループ.D4手配カラムの表示有無 */
    public static final String SYS_CD_FLG_DISPLAY_D4_COLUMN = "flg_display_d4_column";
    /** システムマスタ.コードグループ.パスワード有効期限の残日数 */
    public static final String SYS_CD_DAYS_BEFORE_PASSWORD_EXPIRATION = "days_before_password_expiration";
    /** システムマスタ.コードグループ.超過基準時間（h) */
    public static final String SYS_CD_CHOKA_KIJUN_JIKAN = "choka_kijun_jikan";
    /** システムマスタ.コードグループ.売上漏れ対象トレース */
    public static final String SYS_CD_URIAGE_MORE_TAISHOU_TRACE = "uriage_more_taishou_trace";
    /** システムマスタ.コードグループ.送り状No背景色　読取不可（赤色） */
    public static final String SYS_CD_BG_COLOR_UNREADABLE = "bg_color_unreadable";
    /** システムマスタ.コードグループ.送り状No背景色　複数バーコード有（青色） */
    public static final String SYS_CD_BG_COLOR_MULTIPLE_BARCODES = "bg_color_multiple_barcodes";
    /** システムマスタ.コードグループ.送り状No背景色　重複（黄色） */
    public static final String SYS_CD_BG_COLOR_OVERLAP = "bg_color_overlap";
    /** システムマスタ.コードグループ.送り状No最低桁数 */
    public static final String SYS_CD_OKURIJO_NO_MIN_NUM_DIGIT = "okurijo_no_min_num_digit";
    /** システムマスタ.コードグループ.スキャン重複防止期間 */
    public static final String SYS_CD_SCAN_JUFUKU_BOSHI_KIKAN = "scan_jufuku_boshi_kikan";
    /** システムマスタ.コードグループ.荷受人発行コード自動採番時に使用するプレフィックス */
    public static final String SYS_CD_NIUKENIN_CODE_PREFIX = "niukenin_code_prefix";
    /** システムマスタ.コードグループ.荷送人発行コード自動採番時に使用するプレフィックス */
    public static final String SYS_CD_NIOKURININ_CODE_PREFIX = "niokurinin_code_prefix";
    /** システムマスタ.コードグループ.仕入確定可能稼働日数 */
    public static final String SYS_CD_SHIIRE_KAKUTEI_KANO_KADO_NISSU = "shiire_kakutei_kano_kado_nissu";
    /** システムマスタ.コードグループ.支払確定可能稼働日数 */
    public static final String SYS_CD_SHIHARAI_KAKUTEI_KANO_KADO_NISSU = "shiharai_kakutei_kano_kado_nissu";
    /** システムマスタ.コードグループ.カレンダー警告日数 */
    public static final String SYS_CD_CALENDAR_KEIKOKU_NISSU = "calendar_keikoku_nissu";
    /** システムマスタ.コードグループ.売上締日 */
    public static final String SYS_CD_URIAGE_SHIMEBI = "uriage_shimebi";
    /** システムマスタ.コードグループ.入金締日 */
    public static final String SYS_CD_NYUKIN_SHIMEBI = "nyukin_shimebi";
    /** システムマスタ.コードグループ.設定済一覧で何か月前までの情報を取得するか */
    public static final String SYS_CD_SETTEISUMI_ICHIRAN_MAE = "setteisumi_ichiran_mae";
    /** システムマスタ.コードグループ.設定済一覧で何か月後までの情報を取得するか */
    public static final String SYS_CD_SETTEISUMI_ICHIRAN_USHIRO = "setteisumi_ichiran_ushiro";
    /** システムマスタ.コードグループ.ゲストユーザコード（判断用ダミーコード） */
    public static final String SYS_CD_GUEST_USER_CODE = "guest_user_code";
    /** システムマスタ.コードグループ.システム日付から値を加算した日付を売上の締処理対象とする */
    public static final String SYS_CD_TOKUBETU_SHIME_KIJUN_PERIOD = "tokubetu_shime_kijun_period";
    /** システムマスタ.コードグループ.表示最大件数 */
    public static final String SYS_CD_DISP_MAX_ROWS = "disp_max_rows";
    /** システムマスタ.コードグループ.取得最大件数 */
    public static final String SYS_CD_MAX_ROWS = "max_rows";
    /** システムマスタ.コードグループ.ダウンロード最大件数 */
    public static final String SYS_CD_DOWNLOAD_MAX_ROWS = "download_max_rows";
    /** システムマスタ.コードグループ.CSVのみダウンロード最大件数 */
    public static final String SYS_CD_CSV_DOWNLOAD_MAX_ROWS = "csv_download_max_rows";
    /** システムマスタ.コードグループ.ページ毎最大件数 */
    public static final String SYS_CD_PAGE_MAX_ROWS = "page_max_rows";
    /** システムマスタ.コードグループ.検索時、全営業所データを表示するか。 */
    public static final String SYS_CD_ALL_EIGYOSHO_SEARCH = "all_eigyosho_search";
    /** システムマスタ.ページ初期選択件数 */
    public static final String SYS_CD_DEFAULT_SELECT_ROWS = "default_select_rows";
    /** システムマスタ.ページプルダウン値 */
    public static final String SYS_CD_SELECT_OPTION_ROWS = "select_option_rows";
    /** システムマスタ.コードグループ.適用開始日に過去に遡って設定できる最大月数 */
    public static final String SYS_CD_KAKO_MAX_TEKIYO = "kako_max_tekiyo";
    /** システムマスタ.コードグループ.パスワード誤入力を許容する回数 */
    public static final String SYS_CD_PASSWORD_ERROR_MAX_KAISU = "password_error_max_kaisu";
    /** システムマスタ.コードグループ.メールアドレス不一致を許容する回数 */
    public static final String SYS_CD_MAILADDRESS_FUITCHI_MAX_KAISU = "mailaddress_fuitchi_max_kaisu";
    /** システムマスタ.コードグループ.メールによるパスワード初期化申請をロックする期間。 */
    public static final String SYS_CD_MAIL_APP_LOCK_DATE = "mail_app_lock_date";

}
