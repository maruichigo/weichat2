/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common;

import java.lang.reflect.InvocationTargetException;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 共通申請画面
 *
 * @author 雷珍 (MBP)
 * @version 2019/03/20 新規作成
 */
@javax.faces.bean.ManagedBean(name = "dem012")
@ViewScoped
@Data
public class Dem012Bean extends AbstractBean {

    /**
     * 画面URL
     */
    private String url;
    
    /**
     *
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authorityConfBean;

    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

     /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(
            new Object() {}.getClass().getEnclosingClass().getName());
    
    /**
     * コンストラクタ
     */
    public Dem012Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId クリックされたメニューID（メニューからの遷移以外はNULL）
     * @param prevScreen 遷移元の画面
     * @param backFlag 戻るフラグ（前画面へボタンからの遷移以外はFALSE）
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {

        try {
            // パンくず追加
            breadBean.push("共通申請画面", Cnst.SCREEN.DEM012_SCREEN.name(), this);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * メニュークリック処理
     *
     * @param menuId メニューID
     * @param nextScreenId 遷移先画面ID
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreenId) {
        try {
            // パンくずを削除する
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移を行う
        url = forward(nextScreenId, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック処理
     *
     * @param nextScreenId 遷移先画面ID
     * @param breadIndex パンくずのインデックス
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreenId, int breadIndex) {

        try {
            // パンくずを削除する
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        
        // 画面遷移を行う
        url = forward(nextScreenId, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック処理
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        // 遷移先の画面URL
        return authorityConfBean.logout();
    }
}
