
package jp.co.kintetsuls.beans.login;

import java.io.IOException;
import javax.faces.bean.ManagedProperty;
import jp.co.kintetsuls.exception.LogicException;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.beans.common.ApplicationBean;
import jp.co.kintetsuls.beans.common.SessionBean;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.sharedsys.beans.session.MenuBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import jp.co.kintetsuls.service.common.AuthorityService;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.kintetsuls.service.common.MenuService;
import jp.co.kintetsuls.service.LoginService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import jp.co.sharedsys.beans.base.BaseBean;

@javax.faces.bean.ManagedBean(name = "loginBean")
@javax.faces.bean.RequestScoped
@lombok.Data
public class LoginBean extends BaseBean {
    private String userCd;
    private String password;

    @ManagedProperty(value = "#{appBean}")
    private ApplicationBean appBean;
    @ManagedProperty(value = "#{sessionBean}")
    private SessionBean sessionBean;
    @ManagedProperty(value = "#{menuBean}")
    private MenuBean menuBean;
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;
    private RestfullService rest;
    private MenuService menu;

    private static final Logger logger = LogManager.getLogger(new Object(){}.getClass().getEnclosingClass().getName());
    
    public String login() throws SystemException, LogicException {

        try {
            // ログイン情報取得を呼ぶ
            ServiceInterfaceBean sib = new LoginService().getLoginInfo(authConfBean, rest, userCd, password);
            if (sib.getStatusCode() != ServiceInterfaceBean.PROCESS_STATUS_SUCCESS){
                //sib.getMessages()の値をメッセージに代入してください。
                return "";
            }

//            // 権限取得を呼ぶ
//            AuthorityService authService = new AuthorityService();
//            sib = authService.getAuthority(userCd, rest, authConfBean);
//            if (sib.getStatusCode() != ServiceInterfaceBean.PROCESS_STATUS_SUCCESS){
//                //sib.getMessages()の値をメッセージに代入してください。
//                return "";
//            }
//
//            
//            // Menu取得を呼ぶ
//            MenuService menuService = new MenuService();
//            sib = menuService.getMenu(userCd, rest, menuBean);
//            if (sib.getStatusCode() != ServiceInterfaceBean.PROCESS_STATUS_SUCCESS){
//                //sib.getMessages()の値をメッセージに代入してください。
//                return "";
//            }

        } catch (SystemException | IOException ex) {
            logger.error(ex.getMessage(), ex);
            throw new SystemException(ex);
        }

        //正常だった場合はTOPページへ遷移を行う
        return forward(Cnst.SCREEN.TOP_SCREEN.name(), null, null, false);
    }

    @Override
    public void init(String menuId, String prevScreen, boolean backFlg) {

    }

    @Override
    public String menuClick(String menuId, String nextScreen) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public String logoutClick() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    
}
