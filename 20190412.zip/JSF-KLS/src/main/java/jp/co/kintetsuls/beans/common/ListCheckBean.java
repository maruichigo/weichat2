/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.kintetsuls.utils.DateUtils;
import lombok.Data;
import org.apache.commons.lang3.math.NumberUtils;

/**
 * 一覧データの単項目チェック共通処理Bean
 * 
 * @author zf (MBP)
 * @version 2019/2/21 新規作成
 */
@ManagedBean(name = "listCheckBean")
@ViewScoped
@Data
public class ListCheckBean implements Serializable {

    private static final long serialVersionUID = 1L;
    
    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;

    /**
     * 画面共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * チェック項目名
     */
    private String name;

    /**
     * チェック項目タイプ
     */
    private String dataType;
    
    /**
     * チェックタイプ
     */
    private String checkType;
    
    /**
     * パラメータ1
     */
    private String param1;
    
    /**
     * パラメータ2
     */
    private String param2;
    
    /**
     * パラメータ3
     */
    private String param3;
    
    public ListCheckBean() {
        
    }
    
    public ListCheckBean(String name, String dataType) {
        this.name = name;
        this.dataType = dataType;
    }
    
    public ListCheckBean(String name, String dataType, String checkType) {
        this.name = name;
        this.dataType = dataType;
        this.checkType = checkType;
    }
    
    public ListCheckBean(String name, String dataType, String checkType, String param1) {
        this.name = name;
        this.dataType = dataType;
        this.checkType = checkType;
        this.param1 = param1;
    }
    
    public ListCheckBean(String name, String dataType, String checkType, String param1, String param2) {
        this.name = name;
        this.dataType = dataType;
        this.checkType = checkType;
        this.param1 = param1;
        this.param2 = param2;
    }
    
    public ListCheckBean(String name, String dataType, String checkType, String param1, String param2, String param3) {
        this.name = name;
        this.dataType = dataType;
        this.checkType = checkType;
        this.param1 = param1;
        this.param2 = param2;
        this.param3 = param3;
    }

    /**
     * 一覧データの単項目チェック
     * 
     * @param datas 一覧データ
     * @param checks チェック
     * @return エラーメッセージリスト
     */
    public List<MessageModuleBean> check(List<Map<String, Object>> datas, List<ListCheckBean> checks) {
        return this.check(datas, checks, true);
    }

    /**
     * 一覧データの単項目チェック
     * 
     * @param datas 一覧データ
     * @param checks チェック
     * @param latestFlg 最終メッセージのみを表示する
     * @return エラーメッセージリスト
     */
    public List<MessageModuleBean> check(List<Map<String, Object>> datas, List<ListCheckBean> checks, boolean latestFlg) {

        List<MessageModuleBean> msgList = new ArrayList<>();
        pageCommonBean.resetIchiranColColor(datas);
        
        for (Map<String, Object> data : datas) {
            Map colorMap = new HashMap();
            for (ListCheckBean checkDto : checks) {
                String dataValue = getData(data, checkDto);
                switch(checkDto.getCheckType()) {
                    // 必須チェック
                    case StndConsIF.LIST_CHECK_NOT_NULL:
                        if (CheckUtils.isEmpty(dataValue)) {
                            MessageModuleBean message = messagePropertyBean.createMessageModule(
                                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003, checkDto.getParam1());
                            msgList.add(message);
                            // 色を設定
                            colorMap.put(checkDto.getName(), StndConsIF.COLOR_ERROR);
                        }
                        break;
                    case StndConsIF.LIST_CHECK_NUMBER:
                        if (!CheckUtils.isEmpty(dataValue)) {
                            if (!CheckUtils.isNumber(dataValue)) {
                                MessageModuleBean message = messagePropertyBean.createMessageModule(
                                        MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0010, checkDto.getParam1());
                                msgList.add(message);
                                // 色を設定
                                colorMap.put(checkDto.getName(), StndConsIF.COLOR_ERROR);
                            }
                        }
                        break;
                    case StndConsIF.LIST_CHECK_DATE:
                        if (!CheckUtils.isEmpty(dataValue)) {
                            try {
                                DateUtils.parse(dataValue, StndConsIF.DF_YYYY_MM_DD);
                            } catch (SystemException e) {
                                MessageModuleBean message = messagePropertyBean.createMessageModule(
                                        MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0007, checkDto.getParam1());
                                msgList.add(message);
                                // 色を設定
                                colorMap.put(checkDto.getName(), StndConsIF.COLOR_ERROR);
                            }
                        }
                        break;
                    case StndConsIF.LIST_CHECK_SIZE:
                        int size = NumberUtils.toInt(checkDto.getParam2());
                        if (!CheckUtils.isEmpty(dataValue) && dataValue.getBytes().length != size) {
                            MessageModuleBean message = messagePropertyBean.createMessageModule(
                                    MessagePropertyBean.SEVERITY_ERROR, 
                                    MessageCnst.COME0001, checkDto.getParam1(), checkDto.getParam2());
                            msgList.add(message);
                            // 色を設定
                            colorMap.put(checkDto.getName(), StndConsIF.COLOR_ERROR);
                        }
                        break;
                    case StndConsIF.LIST_CHECK_MAX_SIZE:
                        int maxSize = NumberUtils.toInt(checkDto.getParam2());
                        if (!CheckUtils.isEmpty(dataValue) && dataValue.getBytes().length > maxSize) {
                            MessageModuleBean message = messagePropertyBean.createMessageModule(
                                    MessagePropertyBean.SEVERITY_ERROR, 
                                    MessageCnst.COME0002, checkDto.getParam1(), checkDto.getParam2());
                            msgList.add(message);
                            // 色を設定
                            colorMap.put(checkDto.getName(), StndConsIF.COLOR_ERROR);
                        }
                        break;
                    case StndConsIF.LIST_CHECK_MIN_SIZE:
                        int minSize = NumberUtils.toInt(checkDto.getParam2());
                        if (!CheckUtils.isEmpty(dataValue) && dataValue.getBytes().length < minSize) {
                            MessageModuleBean message = messagePropertyBean.createMessageModule(
                                    MessagePropertyBean.SEVERITY_ERROR, 
                                    MessageCnst.COME0016, checkDto.getParam1(), checkDto.getParam2());
                            msgList.add(message);
                            // 色を設定
                            colorMap.put(checkDto.getName(), StndConsIF.COLOR_ERROR);
                        }
                        break;
                    case StndConsIF.LIST_CHECK_IS_HALF:
                        if(!CheckUtils.isEmpty(dataValue) &&  dataValue.getBytes().length != dataValue.length()){
                            MessageModuleBean message = messagePropertyBean.createMessageModule(
                                    MessagePropertyBean.SEVERITY_ERROR, 
                                    MessageCnst.COME0007, checkDto.getParam1(), checkDto.getParam2());
                            msgList.add(message);
                            // 色を設定
                            colorMap.put(checkDto.getName(), StndConsIF.COLOR_ERROR);
                        }
                        break;
                    case StndConsIF.LIST_CHECK_INTEGER_MAXE_SIZE:
                        if (!CheckUtils.isEmpty(dataValue)) {
                            int integerSize = 0;
                            if (dataValue.contains(".")) {
                                 integerSize = dataValue.split("\\.")[0].length();
                            } else {
                                integerSize = dataValue.length();
                            }
                            if (integerSize > Integer.parseInt(checkDto.getParam2())) {
                                 MessageModuleBean message = messagePropertyBean.createMessageModule(
                                    MessagePropertyBean.SEVERITY_ERROR, 
                                    MessageCnst.COME0002, checkDto.getParam1(), checkDto.getParam2());
                            msgList.add(message);
                            // 色を設定
                            colorMap.put(checkDto.getName(), StndConsIF.COLOR_ERROR);
                            }
                        }
                        break;
                    case StndConsIF.LIST_CHECK_DECIMAL_MAXE_SIZE:
                        if (!CheckUtils.isEmpty(dataValue)) {
                            int decimalSize = 0;
                            if (dataValue.contains(".")) {
                                 decimalSize = dataValue.split("\\.")[1].length();
                                 if (decimalSize > Integer.parseInt(checkDto.getParam2())) {
                                    MessageModuleBean message = messagePropertyBean.createMessageModule(
                                       MessagePropertyBean.SEVERITY_ERROR, 
                                       MessageCnst.COME0002, checkDto.getParam1(), checkDto.getParam2());
                                   msgList.add(message);
                                   // 色を設定
                                   colorMap.put(checkDto.getName(), StndConsIF.COLOR_ERROR);
                                }
                            }
                        }
                        break;
                    case StndConsIF.LIST_CHECK_MIN_NUMBER:
                        Double minNumber = NumberUtils.toDouble(checkDto.getParam2());
                        if (!CheckUtils.isEmpty(dataValue) && NumberUtils.toDouble(dataValue) < minNumber) {
                            MessageModuleBean message = messagePropertyBean.createMessageModule(
                                    MessagePropertyBean.SEVERITY_ERROR, 
                                    MessageCnst.COME0024, checkDto.getParam1(), checkDto.getParam2());
                            msgList.add(message);
                            // 色を設定
                            colorMap.put(checkDto.getName(), StndConsIF.COLOR_ERROR);
                        }
                        break;
                    default:
                        break;
                }
            }
            if (!colorMap.isEmpty()) {
                pageCommonBean.setIchiranRowColorByName(data, colorMap);
            }
        }

        // メッセージを設定
        if (!msgList.isEmpty()) {
            if (latestFlg) {
                List<MessageModuleBean> msgListLast = new ArrayList<>();
                msgListLast.add(msgList.get(msgList.size() - 1));
                messagePropertyBean.messageList(msgListLast);
            } else {
                messagePropertyBean.messageList(msgList);
            }
        }
        return msgList;
    }
    
    /**
     * データを取得
     * 
     * @param data データ
     * @param checkDto チェックBEAN
     * @return データ
     */
    private String getData(Map<String, Object> data, ListCheckBean checkDto) {
        
        String name = checkDto.getName();
        
        if (!data.containsKey(name)) {
            return null;
        }
        switch (checkDto.getDataType()) {
            case StndConsIF.DATA_TYPE_STRING:
                if (data.get(name) == null) {
                    return null;
                }
                return data.get(name).toString();
            case StndConsIF.DATA_TYPE_INT:
                if (data.get(name) == null) {
                    return null;
                }
                return data.get(name).toString();
            case StndConsIF.DATA_TYPE_BIGDECIMAL:
                if (data.get(name) == null) {
                    return null;
                }
                return data.get(name).toString();
            case StndConsIF.DATA_TYPE_CALENDAR:
                if (data.get(name) == null) {
                    return null;
                }
                return data.get(name).toString();
            case StndConsIF.DATA_TYPE_LONG:
                if (data.get(name) == null) {
                    return null;
                }
                return data.get(name).toString();
            case StndConsIF.DATA_TYPE_STRINGS:
                if (data.get(name) == null || ((String[])data.get(name)).length == 0) {
                    return null;
                }
                return data.get(name).toString();
            case StndConsIF.DATA_TYPE_AUTO_COMP_OPTION_BEAN:
                if (data.get(name) == null ) {
                    return null;
                }
                return ((AutoCompOptionBean)data.get(name)).getValue();
            default:
                return null;
        }
    }

}
