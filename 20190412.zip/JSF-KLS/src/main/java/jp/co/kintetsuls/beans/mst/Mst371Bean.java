/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.cnst.SysMsg;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.kintetsuls.service.general.property.ExternalServiceProperty;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 *
 * @author 
 */
@javax.faces.bean.ManagedBean(name = "mst371")
@ViewScoped
@Data
public class Mst371Bean extends BaseBean {
    
    private final String strTitle = "付帯料金項目マスタ";
    private String url;     // URL
    
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;
    
    private RestfullService rest;
    
    private static final Logger logger = LogManager.getLogger(new Object(){}.getClass().getEnclosingClass().getName());
    //売上区分
    private final String conUriageKbn[] = {"輸送／その他売上","その他請求"};
    private final String conSedaiKensakuJoken[] = {"現在適用","未来適用","終了予定","適用終了","適用日指定"};
    private final String conShiyoKbn[] = {"集荷営業所","配達営業所","チャーター起点","売上","発券営業所","車両管理","配達伝票出力営業所"};
    private String kokyakuShubetsu;
    private String kokyakuCd;
    private String kokyakuMei;
    private String kokyakuStatus;
    private String seikyuEigyoCd;
    private String seikyuEigyoMei;
    private String hojinGroupCd;
    private String hojinGroupMei;

    /**
     * コンストラクタ
     */
    public Mst371Bean() {

    }
    
    /**
     * 初期処理（処理）
     * @param menuId
     * @param prevScreen
     * @param backFlag
     */      
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag){
        try {
            // パンくず追加
            breadBean.push("顧客一覧画面", SCREEN.CUS011_SCREEN.name(), this);
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }
    }
    
    /**
     * メニュークリック（処理）
     * @param menuId
     * @param nextScreen
     * @return 
     */    
    @Override
    public String menuClick(String menuId, String nextScreen){
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }

        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
    }
    
    /**
     * パンくずクリック（処理）
     * @return 
     */   
    @Override
    public String breadClumClick(String nextScreen, int breadIndex){
        
        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }        
        url = forward(nextScreen, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     * @return 
     */   
    @Override
    public String logoutClick(){
        return authConfBean.logout();
    }
    
    /**
     * 画面遷移処理（顧客マスタメンテナンス画面へ）
     * @return 
     * @throws java.lang.IllegalAccessException 
     * @throws java.lang.reflect.InvocationTargetException 
     */     
    public String buttonClick() throws IllegalAccessException, InvocationTargetException {
        
        // 画面遷移
        url = forward(SCREEN.CUS012_SCREEN.name(), null, SCREEN.CUS011_SCREEN.name(), false);
        return url;
    }   
    
    public List<String> completeText(String query) {
        List<String> tantoEigyosho = new ArrayList();
        
        tantoEigyosho.add("営業所００１");
        tantoEigyosho.add("営業所００２");
        tantoEigyosho.add("営業所００３");
        tantoEigyosho.add("営業所００４");
        tantoEigyosho.add("営業所００５");
        
        return tantoEigyosho;
    }
    
    /**
     * 検索条件クリア
     */
    public void clear(){
        kokyakuShubetsu = "";
        kokyakuStatus = "";
        kokyakuCd="";
        seikyuEigyoCd = "";
        seikyuEigyoMei = "";
        hojinGroupCd = "";
        hojinGroupMei = "";
    }
    
    /**
     * 検索ボタン押下イベント
     */
    public void search(){
        logger.debug("test", "search()");

        // 顧客マスタ検索し、取得した値を画面項目にセット
        ServiceInterfaceBean res = getKokyakuList();

        // 戻りSIBのステータスチェック、エラー処理
        if (res == null || res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR){
            
            // ToDo:各画面の仕様に従いメッセージ表示などのエラー処理を追加してください
            
            
        }        
    }

    /**
     * DBから顧客情報を取得する
     */    
    private ServiceInterfaceBean getKokyakuList(){
        ServiceInterfaceBean req = new ServiceInterfaceBean();
        
        req.setFunctionCode(ExternalServiceProperty.getInstance().getProperty("cus011-get-kokyaku-detail"));

        //parameter
        Map<String, Object> params = new HashMap<>();
        params.put("kokyakuCd", kokyakuCd);
        String requestData = JSONUtil.makeJSONString(params);
        req.setJson(requestData);

        //JAX-RS接続を実行(SQL側のチェック処理など未実装。)
        rest = RestfullService.getInstance();
        ServiceInterfaceBean res = null;
        try {
            res = rest.request(req);
        } catch (Exception ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
            return res;
        }

        if (res == null || res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR){
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return res;
        }

        Map<String, Object> result;
        try {
            ObjectMapper mapper = new ObjectMapper();
            result = mapper.readValue(res.getJson(), new TypeReference<Map<String, Object>>(){});

        } catch (IOException ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
            return res;
        }

        // 取得値の格納
        /*
        tekiyoKaishibi = FormatUtil.jsonStringToDate((String)result.get("tekiyoKaishibi"));
        tekiyoMei = (String)result.get("tekiyoMei");
        status = (String) result.get("shinseiStatusCd");
        kokyakuShubetsu = (String) result.get("kokyakuShubetsu");
        kokyakuKbn = (String)result.get("kokyakuKbn");
        kokyakuMei1 = (String) result.get("kokyakuKanjiMei1");
        kokyakuMei2 = (String) result.get("kokyakuKanjiMei2");
        kokyakuMei3 = (String) result.get("kokyakuKanjiMei3");
        kokyakuMei4 = (String) result.get("kokyakuKanjiMei4");
        kokyakuMei = (String) result.get("kokyakuMei");
*/
        
        return res;
    }
    
}
