/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.sample;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.Size;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.KbnBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.UpLoadFileDataModel;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.exception.SystemException;
import lombok.Data;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;

/**
 *
 * @author yinyanxu
 */
@javax.faces.bean.ManagedBean(name = "samplebean")
@ViewScoped
@Data
public class SampleBean extends BaseBean {

    @ManagedProperty(value = "#{autoComplete}")
    private AutoCompleteBean autoCompleteBean;
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;
    @ManagedProperty(value = "#{kbnBean}")
    private KbnBean kbnBean;
    // アップロードファイル
    private ArrayList<UpLoadFileDataModel> upLoadFileStream = new ArrayList<>();
    private UploadedFile file;
    // 画面からアップロードされたファイルの格納先
    private List<File> uploadFiles;
    private List<String> tmpFileList = new ArrayList<>();
    private String url;     // URL

    @Size(min = 2, max = 9)
    private String s1;

    private String s2;

    private String s3;

    private Date dateTime1;

    private Date dateTime2;

    private Integer int1;

    private Integer int2;

    private AutoCompOptionBean a1;
    private AutoCompOptionBean jisCodeEmpty;
    private AutoCompOptionBean jisCodeNotEmpty;
    private AutoCompOptionBean shimukechiCodeEmpty;
    private AutoCompOptionBean shimukechiCodeNotEmpty;
    private AutoCompOptionBean jisCd;
    private AutoCompOptionBean autoCompleteSingle;
    private AutoCompOptionBean kbnTest1;
    private AutoCompOptionBean kbnTest2;
    private AutoCompOptionBean kbnTest3;

    private String autoCalender;
    private Date dateautoCalender;
    private String maxdate;
    private String mindate;
    private boolean autoCalenderDis = false;
    private List<String> dateList = new ArrayList<>();
    private String kokyakuCd;
    
    private static final Logger logger = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    /**
     * sample for tag km:multCheckBox default checked setting for item where
     * value is "1" or "2".
     */
    private String[] checkedItems = null;
    private String[] checkedItemsSedai = {"02", "03"};
    private String[] checkedItemsSedai05 = {"05"};
    private String[] checkedItemsSakujyo = {"1"};

    private String yuubinNo;
    private String yuubinNoTodofuken;
    private String yuubinNoTodofuken2;
    private String yuubinNoTodofuken3;

    public void init() {
        checkedItems = new String[]{kbnBean.getKbnCdOfKeyCd(MsCnst.RITO_KANNAI_HAISO_RITO_FUKUMU), kbnBean.getKbnCdOfKeyCd(MsCnst.RITO_KANNAI_HAISO_RITO_JUSHO_TOROKU_ARI)};
        autoCompleteViewBean.initSample("a1", "");
        // 市区町村の場合、市区町村コードを初期表示する
        jisCodeEmpty = autoCompleteViewBean.initAddr("JIS_CODE1", null);
        jisCodeNotEmpty = autoCompleteViewBean.initAddr("JIS_CODE2", "01001");
        jisCd = autoCompleteViewBean.initAddr("jisCd", "01001");
        // 仕向地の場合、仕向地コードを初期表示する
        shimukechiCodeEmpty = autoCompleteViewBean.initAddr2("SHIMUKECHI_CODE1", null);
        shimukechiCodeNotEmpty = autoCompleteViewBean.initAddr2("SHIMUKECHI_CODE2", "0100101");
        // 初期値がない場合
//        a2 = autoCompleteViewBean.initAddr("JIS_CODE", null);
        
        // select初期値設定 Start
        s2 = "02";
        // select初期値設定 End

        // autoCompleteSingle初期化ソース　Start
        autoCompleteSingle = autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_MS_TODOFUKEN, "03");
        // autoCompleteSingle初期化ソース　End
        
        // 区分マスタ取得
        autoCompleteViewBean.getMsKbn("YUSOURIAGE_SET_SAKI");
        autoCompleteViewBean.getMsKbn("PROOF_YOU_SHUYAKU_KOMOKU");
        autoCompleteViewBean.getMsKbn("TAX_TYPE");
//        autoCompleteViewBean.getComMsDatasByKbnKey(MsCnst.COM_GET_VW_FUTAI_RYOKIN_KOMOKU2, MsCnst.SALES_TYPE_YUSO_URIAGE);
        autoCompleteViewBean.getComMsDatasByVal(MsCnst.COM_GET_VW_FUTAI_RYOKIN_KOMOKU2, "9");
    }

    public void doOnthing() {

        // autoCompleteSingle返却処理ソース　Start
        AutoCompOptionBean selectedData = autoCompleteSingle;
        // autoCompleteSingle返却処理ソース　End
    }

    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            breadBean.push("TOP", "TOP_SCREEN", this);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }
    }

    /**
     * メニュークリック（処理）
     *
     * @param menuId
     * @param nextScreen
     * @return
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {
        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック（処理）
     *
     * @return
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {
        return url;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return
     */
    @Override
    public String logoutClick() {
        return getAuthConfBean().logout();
    }
    
    public List<String> autoCalenderList (String key) {
        return dateList;
    }

    

    public void autoSeidaiSelect() {
        if (!(autoCalender == null || autoCalender.isEmpty())) {
        }
    }

    public void autoCalendSelect() {
        SimpleDateFormat myFmt1 = new SimpleDateFormat("yyyy/MM/dd");
        autoCalender = myFmt1.format(dateautoCalender);
    }

    public void kokyakuChange() {
        if (!(kokyakuCd == null || kokyakuCd.isEmpty())) {
            if (kokyakuCd.equals("001")) {
                List<String> list = new ArrayList<>();
                list.add("2019/03/01");
                list.add("2019/03/02");
                list.add("2019/03/03");
                list.add("2019/03/04");
                dateList = list;
            } else if (kokyakuCd.equals("002")) {
                List<String> list = new ArrayList<>();
                list.add("2019/03/05");
                list.add("2019/03/06");
                list.add("2019/03/07");
                list.add("2019/03/08");
                dateList = list;
            } else if (kokyakuCd.equals("003")) {
                List<String> list = new ArrayList<>();
                list.add("2019/03/09");
                list.add("2019/03/10");
                list.add("2019/03/11");
                list.add("2019/03/12");
                dateList = list;
            }
        }
    }

    public void yuubinNoSelect() {
        yuubinNoTodofuken = "01";
        yuubinNoTodofuken2 = yuubinNo + "町";
        yuubinNoTodofuken3 = "003室";
    }    
    
    /**
     * ファイルアップロード(PrimeFacesのファイルアップロードを使用)
     * @param event
     * @throws java.io.IOException
     */
    public void fileUpload(FileUploadEvent event) throws IOException, Exception {

        UpLoadFileDataModel upModel = new UpLoadFileDataModel();
        InputStream inputStr = null;
        String fileName;

        FacesContext context = FacesContext.getCurrentInstance();
        HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest();
        String rootPath = request.getRealPath("/");
        
        try{
            // ファイル情報を取得(マルチ対応)
            List<UploadedFile> uploadFiles = new LinkedList<UploadedFile>();
            uploadFiles.add(event.getFile());
            File fileTmp = null;
            
            // アップロードしたファイル数分対応
            for(int i=0; i<uploadFiles.size(); i++) {
                // ストリーム情報を取得
                fileName = FilenameUtils.getName(uploadFiles.get(i).getFileName());
                inputStr = uploadFiles.get(i).getInputstream();
                upModel.setFileStream(inputStr);
                upModel.setFilePath(fileName);
                upLoadFileStream.add(upModel);
                 File destFile = new File(rootPath + "fileTmp\\", upModel.getFilePath());
                 FileUtils.copyInputStreamToFile(upModel.getFileStream(), destFile);

                setUploadFiles(new ArrayList<>());
                getUploadFiles().add(fileTmp);
            }   
        }catch(Exception ex){
            messagePropertyBean.message(MessagePropertyBean.SEVERITY_FATAL, ex.getMessage());
            throw new SystemException(ex);  
        }
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, "正常アップロード完了");
    }    

    public void uploadComplete() {
        tmpFileList.clear();
        FacesContext context = FacesContext.getCurrentInstance();
        HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest();
        String rootPath = request.getRealPath("/");
        File tmpFile = new File(rootPath + "fileTmp\\");
        File[] tmpFiles = tmpFile.listFiles();
        if (tmpFile != null) {
            for (File f : tmpFiles) {
                tmpFileList.add(f.getName());
            }
        }
    }

    
}
