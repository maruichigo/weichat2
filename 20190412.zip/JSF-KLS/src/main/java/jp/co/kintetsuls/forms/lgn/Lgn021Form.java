/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.lgn;

import java.io.Serializable;
import javax.faces.bean.ViewScoped;
import lombok.Data;

/**
 * パスワード変更 フォーム
 *
 * @author 曾鳳(MBP)
 * @version 2019/1/29 新規作成
 */
@javax.faces.bean.ManagedBean(name = "lgn021Form")
@ViewScoped
@Data
public class Lgn021Form implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * モード(1:変更モード, 2:初期化モード)
     */
    private String mode;

    /**
     * ユーザコード
     */
    private String hyoDtlUserCd;

    /**
     * 現在のパスワード
     */
    private String hyoDtlGenzaiPassword;

    /**
     * 現在のパスワードVisabled
     */
    private Boolean hyoDtlGenzaiPasswordVisabled;

    /**
     * 新しいパスワード
     */
    private String hyoDtlNewPassword;

    /**
     * 新しいパスワード(確認)
     */
    private String hyoDtlNewPasswordKakunin;

    /**
     * パスワード誤入力回数
     */
    private Integer passErrorMaxKaisu;

}
