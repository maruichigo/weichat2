/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.edi;

import jp.co.kintetsuls.beans.trn.*;
import jp.co.kintetsuls.beans.mst.*;
import jp.co.kintetsuls.beans.mst.*;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.util.FormatUtil;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.cnst.SysMsg;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.kintetsuls.service.general.property.ExternalServiceProperty;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 *
 * @author y_kamata
 */
@javax.faces.bean.ManagedBean(name = "edi021")
@ViewScoped
@Data
public class Edi021Bean extends BaseBean {
    
    private final String strTitle = "顧客EDI設定";
    private String url;     // URL
    
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;
    
    private RestfullService rest;
    
    private static final Logger logger = LogManager.getLogger(new Object(){}.getClass().getEnclosingClass().getName());
    
    private final String conRadio1[] = {"アップロード","顧客EDI","外部I/F","バッチ/F"};
    private final String conRadio2[] = {"トレース送信","請求情報送信","その他"};
    private final String conRadio3[] = {"平文","ZIP圧縮","暗号化ZIP"};
    private final String conRadio4[] = {"固定","ランダム"};
    private final String conRadio5[] = {"別メール","送付なし"};
    private final String conRadio6[] = {"固定長","CSV","TSV","Excel"};
    private final String conRadio7[] = {"毎日","指定日","指定曜日"};
    private final String conRadio8[] = {"土曜日送信","日曜日送信","祝日送信","KLS休日送信"};
    private final String conRadio9[] = {"料金報告(日次)","料金報告(任意)","締め請求データ(通常)","締め請求データ(任意)"};
    private final String conSelect1[] = {"To","CC","BCC"};
    private final String conSelect2[] = {"日","月","火","水","木"};
    
    
    @Getter
    @Setter
    private String conEigyoshoCd;
    
    @Getter
    @Setter
    private String conShiiresakiCdAxis;
    

    /**
     * コンストラクタ
     */
    public Edi021Bean() {

    }
    
    /**
     * 初期処理（処理）
     * @param menuId
     * @param prevScreen
     * @param backFlag
     */      
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag){
        try {
            // パンくず追加
            breadBean.push("顧客EDI設定画面", SCREEN.TRN051_SCREEN.name(), this);
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }
    }
    
    /**
     * メニュークリック（処理）
     * @param menuId
     * @param nextScreen
     * @return 
     */    
    @Override
    public String menuClick(String menuId, String nextScreen){
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }

        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
    }
    
    /**
     * パンくずクリック（処理）
     * @return 
     */   
    @Override
    public String breadClumClick(String nextScreen, int breadIndex){
        
        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }        
        url = forward(nextScreen, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     * @return 
     */   
    @Override
    public String logoutClick(){
        return authConfBean.logout();
    }
    
    /**
     * 画面遷移処理（顧客マスタメンテナンス画面へ）
     * @return 
     * @throws java.lang.IllegalAccessException 
     * @throws java.lang.reflect.InvocationTargetException 
     */     
    public String buttonClick() throws IllegalAccessException, InvocationTargetException {
        
        // 画面遷移
        url = forward(SCREEN.CUS012_SCREEN.name(), null, SCREEN.CUS011_SCREEN.name(), false);
        return url;
    }   
    
    public List<String> completeText(String query) {
        List<String> tantoEigyosho = new ArrayList();
        
        tantoEigyosho.add("営業所００１");
        tantoEigyosho.add("営業所００２");
        tantoEigyosho.add("営業所００３");
        tantoEigyosho.add("営業所００４");
        tantoEigyosho.add("営業所００５");
        
        return tantoEigyosho;
    }
    
    /**
     * 検索条件クリア
     */
    public void clear(){
    }
    

    
}
