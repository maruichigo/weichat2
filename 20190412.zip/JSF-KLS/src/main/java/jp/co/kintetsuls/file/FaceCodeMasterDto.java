/*
 * Copyright (C) 2014 MBP Corporation All Rights Reserved .
 

 */
package jp.co.kintetsuls.file;

import java.io.Serializable;
import lombok.Data;

/**
 *
 * @author heqi
 */
@Data
public class FaceCodeMasterDto implements Serializable {

    private String code;
    private String value;

    public FaceCodeMasterDto() {
        code = null;
        value = null;
    }

    public FaceCodeMasterDto(String _code, String _value) {
        code = _code;
        value = _value;
    }

    public String getCodeWithValue() {
        return (this.code + "：" + this.value).trim();
    }

}
