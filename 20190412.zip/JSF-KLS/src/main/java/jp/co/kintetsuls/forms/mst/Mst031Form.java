/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mst;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.annotation.DateCheck;
import jp.co.kintetsuls.beans.common.annotation.MaxSizeCheck;
import jp.co.kintetsuls.beans.common.annotation.NotEmpty;
import jp.co.kintetsuls.beans.common.annotation.SelectOne;
import lombok.Data;

/**
 * 住所マスタ フォーム
 *
 * @author 曾鳳(MBP)
 * @version 2019/1/29 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst031Form")
@ViewScoped
@Data
public class Mst031Form implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 都道府県
     */
    private String conTodofuken;

    /**
     * 都道府県Disabled
     */
    private boolean conTodofukenDisabled;

    /**
     * JISコード
     */
    private AutoCompOptionBean conJisCd;

    /**
     * JISコードDisabled
     */
    private boolean conJisCdDisabled;

    /**
     * JIS住所
     */
    private String conJisJusho;

    /**
     * JISコードのみ検索
     */
    private String[] conJisCdNomiKensaku;

    /**
     * JISコードのみ検索Disabled
     */
    private boolean conJisCdNomiKensakuDisabled;

    /**
     * 漢字住所
     */
    @MaxSizeCheck(name = "漢字住所", maxSize = 20)
    private String conKanjiJusho;

    /**
     * 漢字住所Disabled
     */
    private boolean conKanjiJushoDisabled;

    /**
     * JISチェック結果
     */
    private String[] conJisCheckKekka;

    /**
     * JISチェック結果Disabled
     */
    private boolean conJisCheckKekkaDisabled;

    /**
     * 世代検索条件
     */
    @NotEmpty(name = "世代検索条件")
    private String[] conSedaiKensakuJoken;

    /**
     * 世代検索条件Disabled
     */
    private boolean conSedaiKensakuJokenDisabled;

    /**
     * 適用日
     */
    @DateCheck(name = "適用日")
    private String conTekiyoBi;

    /**
     * 削除済のみ検索
     */
    private String[] conSakujoZumiNomiKensaku;

    /**
     * 離島/館内配送
     */
    private String[] conRitoKannaiHaiso;

    /**
     * 離島/館内配送Disabled
     */
    private boolean conRitoKannaiHaisoDisabled;

    /**
     * 管轄営業所
     */
    @SelectOne(name = "管轄営業所")
    private AutoCompOptionBean conKankatsuEigyoshoCd;

    /**
     * 管轄営業所Disabled
     */
    private boolean conKankatsuEigyoshoCdDisabled;

    /**
     * 適用名
     */
    private String conTekiyoMei;

    /**
     * 適用名Disabled
     */
    private boolean conTekiyoMeiDisabled;

    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;

    /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;

    /**
     * 選択された結果
     */
    private List<Map<String, Object>> selectedSearchResult;

    /**
     * 検索Visabled
     */
    private boolean btnSearchVisible;

    /**
     * 検索条件変更Visabled
     */
    private boolean btnSearchChangeVisible;

}
