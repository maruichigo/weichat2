/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mwb;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiListCol;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mwb.Mwb041Form;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * MAWB状況照会画面
 *
 * @author 廖鈺 (MBP)
 * @version 2019/2/02 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mwb041")
@ViewScoped
@Data
public class Mwb041Bean extends AbstractBean {

    /**
     * タイトル
     */
    private final String TITLE_NAME = "MAWB状況照会";
    
    /**
     * 画面URL
     */
    private String url;

    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

    /**
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authorityConfBean;

    /**
     * ファイルダウンロード
     */
    @ManagedProperty(value = "#{fileBean}")
    private FileBean fileBean;

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;

    /**
     * 画面フォーム
     */
    @ManagedProperty(value = "#{mwb041Form}")
    private Mwb041Form mwb041Form;

    /**
     * 画面共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * 検索シーケンス処理共通
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;

    /**
     * 履歴一覧処理共通
     */
    @ManagedProperty(value = "#{rirekisyosai}")
    private RirekiSyosaiBean rirekiSyosaiBean;
    
    /**
     * 一覧単項目チェック共通
     */
    @ManagedProperty(value = "#{listCheckBean}")
    private ListCheckBean listCheckBean;

    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(
            new Object() {}.getClass().getEnclosingClass().getName());

    /**
     * スクリーンコード：MWB041
     */
    private static final String SC_CD_MWB041 = "MWB041_SCREEN";

    /**
     * 定数：検索件数取得ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH_KENSU = "mwb041_count";

    /**
     * 定数：検索ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH = "mwb041_search";

    /**
     * 定数：存在チェックファンクションコード
     */
    private static final String FUNC_CODE_UPDATE_CHECK = "mwb041_update_check";

    /**
     * 定数：実績MAWB番号登更新ファンクションコード
     */
    private static final String FUNC_CODE_UPDATE = "mwb041_update";

    /**
     * 定数：一覧のデータテーブルID
     */
    private static final String DATA_TABLE_ID = "tablesorter_mwb041";

    /**
     * 定数：画面項目保持キー
     */
    private static final String CONST_MWB041_FORM = "mwb041Form";

    /**
     * 定数：MasterInfo取得キー
     */
    private static final String CONST_MWB041_MASTER = "mwb041";
    
    /**
     * 定数：再検索ボタン取得キー
     */
    private static final String CONST_MWB041_SEARCH = "search_mwb041";    
    

    /**
     * 履歴テーブル検索キー
     */
    private Map<String, Object> rirekiSearchKey;

    /**
     * ワーク.メッセージリスト
     */
    List<MessageModuleBean> msgList = new ArrayList<>();

    /**
     * コンストラクタ
     */
    public Mwb041Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId　メニューID
     * @param prevScreen 遷移元画面ID
     * @param backFlag 戻るフラグ
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
      
        try {
            
            // パンくず追加
            breadBean.push(TITLE_NAME, SCREEN.MWB041_SCREEN.name(), this);

            // マスタ内容取得
            pageCommonBean.getMasterInfo(CONST_MWB041_MASTER);

            // 検索シーケンス処理ため初期化
            searchHelpBean.regSearchHelp(DATA_TABLE_ID,
                    s -> {return getRecordCount(false);},
                    s -> {search();return null;},
                    //画面関連項目チェック
                    s -> {
                        if (!searchCheck()) {
                            return "FALSE";
                        } else {
                            return "TRUE";
                        }
                    });
            searchHelpBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);

            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO, new AutoCompOptionBean("全て", "all"));

            // 前回の記録をクリアする
            this.clear();
            mwb041Form.setSearchResult(null);
            mwb041Form.setSearchResultSelectable(null);
            mwb041Form.setSelectedSearchResult(null);
            
            // 戻ってきた場合
            Mwb041Form preForm = (Mwb041Form) pageCommonBean.getPageInfo(CONST_MWB041_FORM);
            if (backFlag && preForm != null) {
                PageCommonBean.simpleCopy(preForm, mwb041Form);
                // 再検索を実施する
                pageCommonBean.searchAgain(CONST_MWB041_SEARCH);
            } else {
                // 進んできた場合
                Flash flash = pageCommonBean.getPageParam();
                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_MWB041_FORM) != null) {
                    PageCommonBean.simpleCopy(flash.get(CONST_MWB041_FORM), mwb041Form);
                    // 再検索を実施する
                    pageCommonBean.searchAgain(CONST_MWB041_SEARCH);
                }
            }

            // ダウンロードシーケンス初期化
            fileBean.setDataSize(DATA_TABLE_ID,(id -> {return getRecordCount(true);}));
            fileBean.setSearchResult(DATA_TABLE_ID, (id -> {return getSearchResult();})); 
            fileBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);
            fileBean.setTilte(TITLE_NAME);
            fileBean.setSubFlg(false);
            fileBean.regDownloadFucntion(DATA_TABLE_ID, getHeader(),(id -> {return getResultList(true);}));
            fileBean.regBeforeDownFucntion(DATA_TABLE_ID, (comment -> {return beforeDown(comment); }));

            // component初期化とユーザ権限により制御設定
            pageCommonBean.setAuthControll(mwb041Form, SC_CD_MWB041, true);

            // 初期はデータを編集不可にする
            mwb041Form.setBtnEditeDisabled(true);

        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }
    
    /**
     * 検索入力項目チェック
     *
     * @return 正常／異常
     */
    public boolean searchCheck() {
        
        boolean checked = true;
        // MAWB番号 7DRチェック
        if (!"".equals(mwb041Form.getConMawbBango()) && !sevenDRCheck(mwb041Form.getConMawbBango())) {
            messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0007,
                        "searchForm:mawbBango:mawbBangoInput",
                        "MAWB番号");
            mwb041Form.setConMawbBango(null);
            checked = false;
        }
        
        // 相関チェック FROMとTOが逆転していないかチェックを行う。
        if (!dateChecked(mwb041Form.getConTosaiHizukeFrom(), mwb041Form.getConTosaiHizukeTo())) {
            messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0008,
                        "searchForm:tosaiHizukeFrom:tosaiHizukeFromDate",
                        "搭載日付");
            messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0008,
                        "searchForm:tosaiHizukeTo:tosaiHizukeToDate");
            mwb041Form.setConTosaiHizukeFrom(null);
            mwb041Form.setConTosaiHizukeTo(null);
            checked = false;
        }
        
        return checked;
    }

    /**
     * カウント処理
     * @param downloadFlg ダウンロードフラグ
     * @return 取得件数
     */
    public long getRecordCount(boolean downloadFlg) {

        // 前回の記録をクリアする
        Map<String, Object> mapRec = new LinkedHashMap();
        mapRec.put("hideFlg", "hideRow");
        List<Map<String, Object>> mapList = new ArrayList();
        mapList.add(mapRec);
        mwb041Form.setSearchResult(mapList);
        mwb041Form.setSearchResultSelectable(new ReportListDataModel(mwb041Form.getSearchResult()));
        mwb041Form.setSelectedSearchResult(null);
        
        // 検索初期はデータを編集不可にする
        mwb041Form.setBtnEditeDisabled(true);
        
        // パラメータを設定
        Map<String, Object> params = getParamas(downloadFlg);

        // レコード件数を取得する
        long recordCount = getResultListKensu(downloadFlg);
        
        if (!downloadFlg) {

            // 検索部のステータスを変更する
            pageCommonBean.setSerchConDisabled(mwb041Form);
            // 参照モードにする
            pageCommonBean.setEditFlg(false);

            // 検索条件保存
            pageCommonBean.savePageInfo(CONST_MWB041_FORM, mwb041Form);
        }
        
        return recordCount;
        
    }

    /**
     * 検索処理
     * 
     */
    public void search() {
        
        // 選択リストを初期化する
        mwb041Form.setSelectedSearchResult(new ArrayList<>());
        mwb041Form.setSearchResultSelectable(null);

        // 検索を行う
        List<Map<String, Object>> recordList = getResultList(false);
        
        if (recordList != null && recordList.size() > 0) {
            mwb041Form.setSearchMotoList(new HashMap<>());
            for (Map<String, Object> rec : recordList) {
                mwb041Form.getSearchMotoList().put(rec.get("listMawbBango").toString(), 
                        rec.get("listMawbBango").toString() + this.objectToStringOrBlank(
                                rec.get("listKoguchiOkurijoNo")));
            }
        }
        
        fileBean.setDataList(recordList);

        // 取得した値を画面項目にセットする
        pageCommonBean.setDatalist(DATA_TABLE_ID, recordList);
        
        if(recordList != null && recordList.size() > 0) {
            mwb041Form.setSearchResultSelectable(new ReportListDataModel(recordList));
        }

        // 検索部のステータス変更
        pageCommonBean.setSerchConDisabled(mwb041Form);
        
        // 有効データを編集可にする
        mwb041Form.setBtnEditeDisabled(false);

        // 検索条件保存
        pageCommonBean.savePageInfo(CONST_MWB041_FORM, mwb041Form);

        // 参照モードにする
        pageCommonBean.setEditFlg(false);
    }

    /**
     * 検索条件変更処理
     *
     */
    public void searchChange() {
        
        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mwb041Form);
        
        pageCommonBean.executeScript("conHyojiJyokenSentaku()");
    }

    /**
     * クリア処理
     * 
     */
    public void clear() {
        
        // 検索部の条件クリア
        // 配布先営業所コード
        mwb041Form.setConHaifusakiEigyoshoCd(null);
        // 発券営業所コード
        mwb041Form.setConHakkenEigyoshoCd(null);
        // 表示条件選択
        mwb041Form.setConHyojiJyokenSentaku(null);
        // 航空会社
        mwb041Form.setConKokuGaisha(null);
        // MAWB番号
        mwb041Form.setConMawbBango(null);
        // 搭載日付From
        mwb041Form.setConTosaiHizukeFrom(null);
        // 搭載日付To
        mwb041Form.setConTosaiHizukeTo(null);
        
        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mwb041Form);
        pageCommonBean.setBtnSearchChangeVisible(false);
        pageCommonBean.setBtnSearchVisible(Boolean.TRUE);
    }

    /**
     * 更新処理
     *
     */
    public void update() {
        
        // エラーメッセージを格納する変数の初期化を行う
        msgList = new ArrayList();
        
        // 更新一覧リストの初期化を行う
        List<Map<String, Object>> koshinIchiranList = new ArrayList();
        
        if (!checkJsfParamas(mwb041Form.getSelectedSearchResult())) {
            return;
        }

        boolean dataChangeFlg = false ;
        
        // 変更チェック
        for (Map<String, Object> rec : mwb041Form.getSearchResultSelectable().getDatasource()) {
            if (!mwb041Form.getSearchMotoList().get(rec.get("listMawbBango").toString()).equals(
                    rec.get("listMawbBango").toString() + this.objectToStringOrBlank(
                            rec.get("listKoguchiOkurijoNo")))) {
                
                dataChangeFlg = true;
                
                koshinIchiranList.add(rec);
                
               
            }
        }
        
        if(!dataChangeFlg) {
            MessageModuleBean message = messagePropertyBean.createMessageModule(
                        MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MWBE0011);
            msgList.add(message);

            messagePropertyBean.messageList(msgList);
                
            return;
        }
        
        // 更新一覧リストの 更新処理
        if (koshinIchiranList.size() > 0) {
            
            // 更新処理を行う
            int status = updateResultList(koshinIchiranList);
            
            // エラーの場合、処理終了
            if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
                 return;
            }
            // 更新の後に再度検索する
            pageCommonBean.searchAgain(CONST_MWB041_SEARCH);
        }
                
        // 一覧の配色定義をなくす
        pageCommonBean.resetIchiranColColor(mwb041Form.getSelectedSearchResult());

        // メッセージを設定する
        MessageModuleBean message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, "更新");
        msgList.add(message);

        messagePropertyBean.messageList(msgList);
        
        // ログ出力を行う
        LOGGER.info("更新 " + mwb041Form.getSelectedSearchResult().size() + " 件");
    }
    
    /**
     * メニュークリック処理
     *
     * @param menuId メニューID
     * @param nextScreenId 遷移先画面ID
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreenId) {
        try {
            // パンくずを削除する
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移を行う
        url = forward(nextScreenId, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック処理
     *
     * @param nextScreenId 遷移先画面ID
     * @param breadIndex パンくずのインデックス
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreenId, int breadIndex) {

        try {
            // パンくずを削除する
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        
        // 画面遷移を行う
        url = forward(nextScreenId, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック処理
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authorityConfBean.logout();
    }

    /**
     * ダウンロード理由を記録する処理
     *
     * @param comment 理由コメント
     * @return 正常／異常
     * @throws Exception
     */
    public boolean beforeDown(String comment) throws Exception {
        
        // ダウンロード理由を記録する
        System.out.println(comment);
        
        return true;
    }

    /**
     * CSVファイルのタイトルを設定する処理
     *
     * @return 画面タイトル
     */
    public List<CSVDto> getHeader() {
        
        // CSVファイルのタイトルを設定する
        List<CSVDto> header = new ArrayList<>();
        // 航空会社
        header.add(new CSVDto("航空会社", "listKokuGaishaCd"));
        // MAWB番号
        header.add(new CSVDto("MAWB番号", "listMawbBango"));
        // 搭載日付
        header.add(new CSVDto("搭載日付", "listTosaiHizuke"));
        // 搭載便名
        header.add(new CSVDto("搭載便名", "listTosaiBinMei"));
        // 施策適用日付
        header.add(new CSVDto("施策適用日付", "listShisakuTekiyoHizuke"));
        // 施策適用便名
        header.add(new CSVDto("施策適用便名", "listShisakuTekiyoBinMei"));
        // 出発地空港
        header.add(new CSVDto("出発地空港", "listShuppatsuchiKukoCd"));
        // 到着地空港
        header.add(new CSVDto("到着地空港", "listTochakuchiKukoCd"));
        // 搭載重量(Kg)
        header.add(new CSVDto("搭載重量(Kg)", "listTosaiJuryo"));
        // 適用重量(Kg)
        header.add(new CSVDto("適用重量(Kg)", "listTekiyoJuryo"));
        // 最低搭載重量(Kg)
        header.add(new CSVDto("最低搭載重量(Kg)", "listSaiteTosaiJuryo"));
        // 一般運賃
        header.add(new CSVDto("一般運賃", "listIppanUnchin"));
        // 適用運賃
        header.add(new CSVDto("適用運賃", "listTekiyoUnchin"));
        // 代理店手数料
        header.add(new CSVDto("代理店手数料", "listDairitenTesuryo"));
        // 支払金額
        header.add(new CSVDto("支払金額", "listShiharaiKingakuZeikomi"));
        // 小口送り状No
        header.add(new CSVDto("小口送り状No", "listKoguchiOkurijoNo"));
        // 品目明細コード
        header.add(new CSVDto("品目明細コード", "listHimmokuMeisaiCd"));
        // 運賃種別
        header.add(new CSVDto("運賃種別", "listUnchinShubetsu"));
        // 施策番号
        header.add(new CSVDto("施策番号", "listShisakuBango"));
        // 施策適用基準
        header.add(new CSVDto("施策適用基準", "listShisakuTekiyoKijyun"));
        // 施策レート
        header.add(new CSVDto("施策レート", "listShisakuRate"));
        // 発券営業所
        header.add(new CSVDto("発券営業所", "listHakkenEigyosho"));
        // 配布先営業所
        header.add(new CSVDto("配布先営業所", "listHaifusakiEigyosho"));
        // 修正区分
        header.add(new CSVDto("修正区分", "listShuseiKubun"));
        // 使用区分
        header.add(new CSVDto("使用区分", "listShiyoKubun"));

        // 取得値を返却する
        return header;
    }
    
    /**
     * ダウンロード検査結果取得
     * 
     * @return 検索結果
     */
    public List<Map<String, Object>> getSearchResult() {
        return mwb041Form.getSearchResult();
    }
    
    /**
     * アップロード
     * 
     * @return 遷移先画面のURL
     */
    public String upload() {
        
        // flash初期化
        Flash flash = pageCommonBean.getPageParam();
        
        // flashにアップロード機能コードを設定する
        flash.put("uploadFunctionCd", TITLE_NAME);
        
        // アップロードを画面へ遷移する
        url = forward(Cnst.SCREEN.UPLOAD_SCREEN.name(), null, Cnst.SCREEN.UPLOAD_SCREEN.name(), false);
        return url;
    }

    /**
     * 更新履歴を表示処理
     *
     */
    public void rirekiIchiran() {

        // 履歴テーブル検索キーを設定する
        rirekiSearchKey = new HashMap();

        // 選択されたレコードを取得する
        rirekiSearchKey = mwb041Form.getSelectedSearchResult().get(0);
        
        // 履歴テーブルタイトルを設定する
        rirekiSyosaiBean.setRirekiTitle(TITLE_NAME);

        // 履歴タイトルを設定する
        rirekiSyosaiBean.setListColName(new ArrayList<>(Arrays.asList("バージョン情報", "航空会社", "MAWB番号", "搭載日付", "搭載便名",
                "施策適用日付", "施策適用便名", "出発地空港", "到着地空港", "搭載重量(Kg)", "適用重量(Kg)",
                "最低搭載重量(Kg)", "一般運賃", "適用運賃", "代理店手数料", "支払金額", "小口送り状No", "品目明細コード",
                "運賃種別", "施策番号", "施策適用基準", "施策レート", "発券営業所", "配布先営業所", "修正区分",
                "使用区分", "修正日付")));

        // 履歴beanの項目物理名を設定する
        List<String> colValue = new ArrayList<>(Arrays.asList("listMawbDataVersion", "listKokuGaishaCd", "listMawbBango",
                "listTosaiHizuke", "listTosaiBinMei", "listShisakuTekiyoHizuke", "listShisakuTekiyoBinMei",
                "listShuppatsuchiKukoCd", "listTochakuchiKukoCd", "listTosaiJuryo", "listTekiyoJuryo",
                "listSaiteTosaiJuryo", "listIppanUnchin", "listTekiyoUnchin", "listDairitenTesuryo",
                "listShiharaiKingakuZeikomi", "listKoguchiOkurijoNo", "listHimmokuMeisaiCd", "listUnchinShubetsu",
                "listShisakuBango", "listShisakuTekiyoKijyun", "listShisakuRate", "listHakkenEigyosho",
                "listHaifusakiEigyosho", "listShuseiKubun", "listShiyoKubun", "listSaishuOperationKoshinNichiji"));
        List<String> colAlign = new ArrayList<>(Arrays.asList("center", "center", "center",
                "center", "center", "center", "center", "center",
                "center", "right", "right",
                "right", "right", "right",
                "right", "right", "left",
                "left", "left", "left", "left",
                "right", "center", "center", "center", "center", "center"));
        List<RirekiListCol> listCol = new ArrayList<>();
        for (int i = 0; i < colValue.size(); i++) {
           RirekiListCol col = new RirekiListCol();
           col.setColValue(colValue.get(i));
           col.setColAlign(colAlign.get(i));
           listCol.add(col);
        }
        rirekiSyosaiBean.setListCol(listCol);
        // 履歴データを設定する
        rirekiSyosaiBean.setListColColor("1");
        // 履歴テーブルを検索する
        rirekiSyosaiBean.searchList("2", "MWB041_SEARCH_RIREKI", rirekiSearchKey);

    }
    
    /**
     * 一覧の単項目チェック処理
     * 
     * @param params 画面一覧パラメータ
     * @return チェックの結果
     */
    private boolean checkJsfParamas(List<Map<String, Object>> params) {

        List<ListCheckBean> checks = new ArrayList<>();
        checks.add(new ListCheckBean("listKoguchiOkurijoNo", 
                StndConsIF.DATA_TYPE_INT, StndConsIF.LIST_CHECK_MAX_SIZE, "小口送り状No", "13"));
        List<MessageModuleBean> checkMsgList = listCheckBean.check(params, checks, true);

        if (!checkMsgList.isEmpty()) {
            return false;
        }
        return true;
    }

    /**
     * DBから検索件数を取得する
     * 
     */
    private long getResultListKensu(boolean downloadFlg) {

        // パラメータ
        Map<String, Object> params = getParamas(downloadFlg);
        
        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH_KENSU);

        // 検索件数を返却する
        return Long.valueOf(res.getJson());
    }

    /**
     * DBから検索情報を取得する
     * 
     */
    private List<Map<String, Object>> getResultList(boolean downloadFlg) {

        // パラメータ
        Map<String, Object> params = getParamas(downloadFlg);
        
        try {
             // DBをアクセス
            ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH);
            ObjectMapper mapper = new ObjectMapper();
            mwb041Form.setSearchResult(mapper.readValue(res.getJson(), List.class));

        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
        // 検索結果一覧データ
        List<Map<String, Object>> searchResultList = new ArrayList();
        
        // 適用開始日フォーマット
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        
        for(Map<String, Object> result : mwb041Form.getSearchResult()) {
            
            // 適用開始日
            if(result.get("listTosaiHizuke") != null) {
                result.replace("listTosaiHizuke", 
                    dateFormat.format(new Date(Long.valueOf(result.get("listTosaiHizuke").toString()))));
            }
            if(result.get("listShisakuTekiyoHizuke") != null) {
                // 適用開始日
                result.replace("listShisakuTekiyoHizuke", 
                    dateFormat.format(new Date(Long.valueOf(result.get("listShisakuTekiyoHizuke").toString()))));
            }
            searchResultList.add(result);
        }
        
        // ダウンロードリストを設定する
        mwb041Form.setDownloadResult(searchResultList);
        // 検索情報を返却する
        return mwb041Form.getSearchResult();
    }

    /**
     * DBから実績MAWB番号情報を更新する処理
     *
     */
    private int updateResultList(List<Map<String, Object>> dataChangeList) {

        // 重複、存在チェック
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.accsessDBWithList(
                dataChangeList, FUNC_CODE_UPDATE_CHECK);

        // エラーの場合、処理を終了
        if (serviceInterfaceBean.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            messagePropertyBean.message(serviceInterfaceBean.getMessages().get(0)[0],
                    serviceInterfaceBean.getMessages().get(0)[1],
                    serviceInterfaceBean.getMessages().get(0)[2],
                    serviceInterfaceBean.getTableName());

            return serviceInterfaceBean.getStatusCode();
        }

        // 新一覧リストの内容を処理する
        serviceInterfaceBean = pageCommonBean.accsessDBWithList(
                dataChangeList, FUNC_CODE_UPDATE);

        return serviceInterfaceBean.getStatusCode();
    }

    /**
     * 7DRチェック
     *
     * @param value チェック項目
     * @return チェック結果
     */
    private boolean sevenDRCheck(Object value) {
        
        boolean isFormat = false;
        
        if (value != null && value.toString().length() == 8) {
            Pattern pattern = Pattern.compile("[0-9]*");
            Matcher isNum = pattern.matcher(value.toString());
           if( !isNum.matches() ){
               return isFormat;
           }
            // MAWB番号の上7桁
            int maeNumber = Integer.valueOf(value.toString().substring(0, 7));
            // MAWB番号の下1桁
            int lastNumber = Integer.valueOf(value.toString().substring(7, 8));
            // 1)MAWB番号の上7桁を7で割り、余りを求める。(余り = 7DR)
            int mod = maeNumber % 7;
            // 2)7DRと、MAWB番号の下1桁が一致するかをチェックする。
            if (mod == lastNumber) {
                isFormat = true;
            }
        }

        return isFormat;
    }

    /**
     * 相関チェック
     *
     * @param fromDate 搭載日付FROM
     * @param toDate 搭載日付TO
     * @return チェック結果
     */
    private boolean dateChecked(String fromDate, String toDate) {
        
        // FROMとTOが逆転FLG
        boolean isRightRangeOrNull = true;
        
        if (fromDate != null && toDate != null) {
            // FROMとTOが逆転していないかチェックを行う。
            int compareIndex = toDate.compareTo(fromDate);
            // FROMとTOが逆転していない
            if (!(compareIndex > 0 || compareIndex == 0)) {
                isRightRangeOrNull = false;
            }
        }
        return isRightRangeOrNull;
    }
    
    private String objectToStringOrBlank(Object o) {
        if (o == null) {
            return "";
        }
        return o.toString();
    }    
    
    /**
     * パラメータを設定する
     * 
     * @param downloadFlg ダウンロードフラグ
     * @return 検索結果パラメータ
     */
    private Map<String, Object> getParamas(boolean downloadFlg) {
        
        // パラメータを設定する
        Map<String, Object> params = new HashMap<>();
        
        // 画面フォームを取得する
        Mwb041Form tempForm = mwb041Form;
        if (downloadFlg) {
            // メモ画面フォームを取得する
            tempForm = (Mwb041Form)pageCommonBean.getPageInfo(CONST_MWB041_FORM);
        }
        
        // 全営業所検索
        if (pageCommonBean.getMasterInfo().getAllEigyoshoSearch() != null) {
            params.put("allEigyoshoSearch", pageCommonBean.getMasterInfo().getAllEigyoshoSearch());
        }
        // ログインユーザー所属営業所
        params.put("loginUserShozokuEigyosho", authorityConfBean.getLoginUserShozokuEigyosho());
        // 発券営業所コード
        params.put("conHakkenEigyoshoCd", tempForm.getConHakkenEigyoshoCd().getValue());
        // 航空会社
        params.put("conKokuGaisha", tempForm.getConKokuGaisha());
        // 配布先営業所コード
        if (tempForm.getConHaifusakiEigyoshoCd() != null) {
            params.put("conHaifusakiEigyoshoCd", tempForm.getConHaifusakiEigyoshoCd().getValue());
        }
        // MAWB番号
        params.put("conMawbBango", tempForm.getConMawbBango());
        // 搭載日付From
        params.put("conTosaiHizukeFrom", tempForm.getConTosaiHizukeFrom());
        // 搭載日付To
        params.put("conTosaiHizukeTo", tempForm.getConTosaiHizukeTo());
        // 表示条件選択
        params.put("conHyojiJyokenSentaku", tempForm.getConHyojiJyokenSentaku());

        return params;
    }
    
}
