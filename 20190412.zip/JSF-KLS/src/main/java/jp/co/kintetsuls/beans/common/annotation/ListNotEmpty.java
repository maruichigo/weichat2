/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;
import jp.co.kintetsuls.beans.common.annotation.validator.ListNotEmptyValidator;

/**
 * Checkboxの必須選択チェック
 * 
 * @author zf (MBP)
 * @version 2019/3/7 新規作成
 */
@Documented
@Constraint(validatedBy = {ListNotEmptyValidator.class})
@Target({java.lang.annotation.ElementType.METHOD, java.lang.annotation.ElementType.FIELD, java.lang.annotation.ElementType.ANNOTATION_TYPE, java.lang.annotation.ElementType.CONSTRUCTOR, java.lang.annotation.ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
public @interface ListNotEmpty {

    public String name() default "";

    public String message() default "{COME0011}";
    
    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

}
