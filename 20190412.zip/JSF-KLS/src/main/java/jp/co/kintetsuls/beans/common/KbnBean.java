/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.PostConstruct;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.cnst.SysMsg;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.kintetsuls.service.general.property.ExternalServiceProperty;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * E2コード定義取得Bean
 *
 * @author zf (MBP)
 * @version 2019/2/21 新規作成
 */
@ManagedBean(name = "kbnBean", eager = true)
@ApplicationScoped
@Data
public class KbnBean {

    private static final Logger logger = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    /**
     * E2コード定義モード
     */
    @ManagedProperty(value = "#{kbnModuleBean}")
    private List<KbnModuleBean> kbnModuleBeanList;

    @PostConstruct
    public void init() {

        // DBをアクセス
        ServiceInterfaceBean res = getDBInfo("common-get-ms-kbn");
        kbnModuleBeanList = new ArrayList<>();

        if (res != null) {
            ObjectMapper mapper = new ObjectMapper();
            try {
                List<Map<String, Object>> searchResult = mapper.readValue(res.getJson(), List.class);
                KbnModuleBean kbnModuleBean;
                for (Map<String, Object> rstMap : searchResult) {
                    kbnModuleBean = new KbnModuleBean();
                    // 区分グループコード
                    kbnModuleBean.setKbnGroupCd((String) rstMap.get("kbnGroupCd"));
                    // 区分グループ名
                    kbnModuleBean.setKbnGroupMei((String) rstMap.get("kbnGroupMei"));
                    // 区分コード
                    kbnModuleBean.setKbnCd((String) rstMap.get("kbnCd"));
                    // 並び順
                    kbnModuleBean.setNarabijun((Integer) rstMap.get("narabijun"));
                    // 区分名
                    kbnModuleBean.setKbnMei((String) rstMap.get("kbnMei"));
                    // 区分キー
                    kbnModuleBean.setKbnKey((String) rstMap.get("kbnKey"));
                    kbnModuleBeanList.add(kbnModuleBean);
                }
            } catch (IOException ex) {
                logger.error(ex.getMessage(), ex);
            }
        }
    }

    /**
     * 全て区分情報を取得する
     *
     * @return 全て区分情報
     */
    public List<KbnModuleBean> getAllKbns() {
        return kbnModuleBeanList;
    }

    /**
     * 区分グループコードより区分情報を取得する
     *
     * @param kbnGroupCd 区分グループコード
     * @param dispNoneCodes 非表示キーコード
     * @return 区分情報
     */
    public List<KbnModuleBean> getKbnsOfGroupCd(String kbnGroupCd, String... dispNoneCodes) {

        List<KbnModuleBean> result = new ArrayList<>();

        result = kbnModuleBeanList.stream()
                .filter((KbnModuleBean sub) -> kbnGroupCd.equals(sub.getKbnGroupCd()))
                .collect(Collectors.toList());
        
        // 非表示キーコードよりリストから削除する
        for (String code : dispNoneCodes) {
            KbnModuleBean dto = this.getKbnInfoOfKeyCd(code);
            result.remove(dto);
        }

        // ソート処理
        result.sort((a, b) -> a.getNarabijun() - b.getNarabijun());

        return result;
    }

    /**
     * 区分グループコードより区分AUTOCOMPLETE情報を取得する
     *
     * @param kbnGroupCd 区分グループコード
     * @return 区分AUTOCOMPLETE情報
     */
    public List<AutoCompOptionBean> getKbnsAutoCompOfGroupCd(String kbnGroupCd) {

        List<AutoCompOptionBean> result = new ArrayList();
        List<KbnModuleBean> list = this.getKbnsOfGroupCd(kbnGroupCd);

        list.stream().map((dto) -> {
            AutoCompOptionBean autoDto = new AutoCompOptionBean();
            autoDto.setLabel(dto.getKbnMei());
            autoDto.setValue(dto.getKbnCd());
            return autoDto;
        }).forEachOrdered((autoDto) -> {
            result.add(autoDto);
        });

        return result;
    }

    /**
     * 区分グループコードより区分AUTOCOMPLETE情報を取得する（区分名用）
     *
     * @param kbnGroupCd 区分グループコード
     * @return 区分AUTOCOMPLETE情報
     */
    public List<AutoCompOptionBean> getKbnMeiAutoCompOfGroupCd(String kbnGroupCd) {
        List<AutoCompOptionBean> result = new ArrayList();
        List<KbnModuleBean> list = this.getKbnsOfGroupCd(kbnGroupCd);

        list.stream().map((dto) -> {
            AutoCompOptionBean autoDto = new AutoCompOptionBean();
            autoDto.setValue(dto.getKbnMei());
            return autoDto;
        }).forEachOrdered((autoDto) -> {
            result.add(autoDto);
        });
        
        return result;
    }

    /**
     * コードキーより区分情報を取得する
     *
     * @param keyCd コードキー
     * @return 区分情報
     */
    public KbnModuleBean getKbnInfoOfKeyCd(String keyCd) {

        List<KbnModuleBean> retList = kbnModuleBeanList.stream()
                .filter((KbnModuleBean sub) -> keyCd.equals(sub.getKbnKey()))
                .collect(Collectors.toList());
        if (retList != null && retList.size() > 0) {
            return retList.get(0);
        }
        return null;
    }

    /**
     * コードキーより区分コードを取得する
     *
     * @param keyCd コードキー
     * @return 区分コード
     */
    public String getKbnCdOfKeyCd(String keyCd) {

        List<KbnModuleBean> retList = kbnModuleBeanList.stream()
                .filter((KbnModuleBean sub) -> keyCd.equals(sub.getKbnKey()))
                .collect(Collectors.toList());
        if (retList != null && retList.size() > 0) {
            return retList.get(0).getKbnCd();
        }
        return null;
    }

    /**
     * コードキーよりコード名を取得する
     *
     * @param keyCd コードキー
     * @return コード名
     */
    public String getKbnMeiOfKeyCd(String keyCd) {

        List<KbnModuleBean> retList = kbnModuleBeanList.stream()
                .filter((KbnModuleBean sub) -> keyCd.equals(sub.getKbnKey()))
                .collect(Collectors.toList());
        if (retList != null && retList.size() > 0) {
            return retList.get(0).getKbnMei();
        }
        return null;
    }

    /**
     * DBアクセス用
     *
     * @param functionCode
     * @return ServiceInterfaceBean
     */
    private ServiceInterfaceBean getDBInfo(String functionCode) {

        ServiceInterfaceBean req = new ServiceInterfaceBean();
        req.setFunctionCode(ExternalServiceProperty.getInstance().getProperty(functionCode));
        String requestData = JSONUtil.makeJSONString(null);
        req.setJson(requestData);

        //JAX-RS接続を実行(SQL側のチェック処理など未実装。)
        RestfullService rest = RestfullService.getInstance();
        ServiceInterfaceBean res = null;
        try {
            res = rest.request(req);
        } catch (Exception ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
            return null;
        }

        if (res == null || res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return null;
        }

        // 戻りSIBのステータスチェック、エラー処理
        if (res == null || res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            // ToDo:各画面の仕様に従いメッセージ表示などのエラー処理を追加してください
        }
        return res;
    }

}
