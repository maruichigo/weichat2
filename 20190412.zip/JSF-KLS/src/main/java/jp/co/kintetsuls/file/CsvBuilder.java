package jp.co.kintetsuls.file;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.utils.BeanUtils;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.kintetsuls.utils.DateUtils;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.utils.FileUtils;

/**
 * CSV ファイルを作成
 *
 * @author 
 */
public class CsvBuilder   {
public static final String CSV_ENCODE = StndConsIF.KYOTU_ENCODE_UTF8;
 public static final String   FILE_STORE_FOLDER_TEMP = "\\temp";

    /**
     *
     * csvファイル保存
     */
    public static  String saveCsvInfo(List<CSVDto> header, List<Object> body) throws Exception {

        List<String> csvheader = new ArrayList<String>();
        List<String> csvbody = null;

        CSVTokenizer csv = CSVTokenizer.getInstance();

        for (CSVDto d : header) {
            csvheader.add(d.getTitle());
        }
        csv.addHeader(csvheader);


        for (Object o : body) {

            csvbody = new ArrayList<String>();
            for (CSVDto d : header) {
                csvbody.add(BeanUtils.getDataAsString(o, d.getName()));
            }
            csv.add(csvbody);
        }

        byte[] bycsv = csv.toByteArray(CSV_ENCODE);

        String filename =  DateUtils.format(DateUtils.getSysDate(), StndConsIF.DF_YYYYMMDDHHMMSS);
        String filepath = FileUtils.getAbsolutePath(FILE_STORE_FOLDER_TEMP);
        FileUtils.doUpload(bycsv, filename + ".csv", filepath);

        return filename + ".csv";
    }

    
    
    /**
     *
     * csvファイル保存
     */
    public static  String saveCsvInfofromMap(List<CSVDto> header, List<Map<String,Object>> body) throws Exception {

        List<String> csvheader = new ArrayList<String>();
        List<String> csvbody = null;

        CSVTokenizer csv = CSVTokenizer.getInstance();

        for (CSVDto d : header) {
            csvheader.add(d.getTitle());
        }
        csv.addHeader(csvheader);

        for (Map o : body) {

            csvbody = new ArrayList<String>();
            for (CSVDto d : header) {
                csvbody.add(BeanUtils.objectToString(o.get(d.getName())));
            }
            csv.add(csvbody);
        }

        byte[] bycsv = csv.toByteArray(CSV_ENCODE);

        String filename =  DateUtils.format(DateUtils.getSysDate(), StndConsIF.DF_YYYYMMDDHHMMSS);
        String filepath = FileUtils.getAbsolutePath(FILE_STORE_FOLDER_TEMP);
        FileUtils.doUpload(bycsv, filename + ".csv", filepath);

        return filename + ".csv";
    }
    /**
     *
     * zipファイル保存
     */
    public String saveZipInfo(List<CSVDto> header, List<Map> body) throws Exception {

        List<String> csvheader = new ArrayList<String>();
        List<String> csvbody = null;

        CSVTokenizer csv = CSVTokenizer.getInstance();

        for (CSVDto d : header) {
            csvheader.add(d.getTitle());
        }
        csv.addHeader(csvheader);

        for (Object o : body) {
            csvbody = new ArrayList<String>();
            for (CSVDto d : header) {
                String tmp = BeanUtils.getDataAsString(o, d.getName(), d.getFomart());
                if (d.getCodeMasterList() != null) {
                    for (FaceCodeMasterDto codeMasterDto : d.getCodeMasterList()) {
                        if (CheckUtils.isEqual(codeMasterDto.getCode(), tmp)) {
                            tmp = codeMasterDto.getValue();
                            break;
                        }
                    }
                }
                csvbody.add(tmp);
            }
            csv.add(csvbody);

        }

        byte[] bycsv = csv.toByteArray(CSV_ENCODE);

        String filename =  DateUtils.format(DateUtils.getSysDate(), StndConsIF.DF_YYYYMMDDHHMMSS);
        String filepath = FileUtils.getAbsolutePath(FILE_STORE_FOLDER_TEMP);
        FileUtils.doUpload(bycsv, filename + ".csv", filepath);

        List<String> files = new ArrayList<>();
        files.add(filepath + StndConsIF.FS + filename + ".csv");

        return filename + ".zip";
    }

}
