/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mst;

import java.util.List;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.annotation.DateCheck;
import jp.co.kintetsuls.beans.common.annotation.NotNull;
import lombok.Data;

/**
 * 営業日カレンダー フォーム
 *
 * @author 曾鳳 (MBP)
 * @version 2019/4/6 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst461Form")
@ViewScoped
@Data
public class Mst461Form {

    /**
     * 編集ボタン状態（true:非活性、false:活性）
     */
    private boolean mode;

    /**
     * 検索年月
     */
    @NotNull(name = "検索年月")
    @DateCheck(message = "{COME0004}", pattern = "yyyy/MM")
    private String conKensakuNengetsu;

    /**
     * 検索年月Disabled
     */
    private boolean conKensakuNengetsuDisabled;
    
    /**
     * カレンダー情報(先頭空白と末尾空白がない)
     */
    private List<Map<String, Object>> calendarNoNullList;

    /**
     * カレンダー情報
     */
    private List<Map<String, Object>> calendarList;

    /**
     * 設定済一覧情報
     */
    private List<Map<String, Object>> setteisumiList;
    
    /**
     * ワーク.売上締日
     */
    private String uriageShimebi;
    
    /**
     * ワーク.入金締日
     */
    private String nyukinShimebi;
    
    /**
     * ワーク.設定済一覧前
     */
    private String setteisumiIchiranMae;
    
    /**
     * ワーク.設定済一覧後
     */
    private String setteisumiIchiranUshiro;
    
    /**
     * ワーク.カレンダー警告日数
     */
    private String calendarKeikokuNissu;

}