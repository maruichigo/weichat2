/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.org.apache.xpath.internal.operations.Mod;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.KbnBean;
import jp.co.kintetsuls.beans.common.KbnModuleBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiListCol;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst131Form;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 仕入先マスタ一覧
 *
 * @author MBP劉 (MBP)
 * @version 2019/1/24 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst131")
@ViewScoped
@Data
public class Mst131Bean extends AbstractBean {

    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * 画面共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommon;

    /**
     * 画面フォーム
     */
    @ManagedProperty(value = "#{mst131Form}")
    private Mst131Form form;

    /**
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    /**
     * ファイルダウンロード
     */
    @ManagedProperty(value = "#{fileBean}")
    private FileBean fileBean;

    /**
     * 検索シーケンス処理共通
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messageProperty;

    /**
     * 履歴一覧処理共通
     */
    @ManagedProperty(value = "#{rirekisyosai}")
    private RirekiSyosaiBean rirekiSyosaiBean;

    /**
     * E2コード定義取得Bean
     */
    @ManagedProperty(value = "#{kbnBean}")
    private KbnBean kbnBean;

    /**
     * 画面タイトル
     */
    private final String TITLE = "仕入先マスタ一覧";

    /**
     * ダウンロードファイル名
     */
    private final static String FILE_NAME = "仕入先マスタ一覧";

    /**
     * 画面URL
     */
    private String url;

    /**
     * 件数検索
     */
    private static final String SEARCH_COUNT_FUNC_CODE = "mst131-get-count";

    /**
     * 仕入先マスタ一覧検索
     */
    private static final String SEARCH_FUNC_CODE = "mst131-get-detail";

    /**
     * 定数：一覧のDataTableのID.
     */
    private static final String DATA_TABLE_ID = "tablesorter_mst131";

    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    /**
     * 定数：営業所取得
     */
    private static final String SC_CD_MST131 = "MST131_SCREEN";

    /**
     * 定数：画面項目保持key.
     */
    private static final String CONST_MST131_FORM = "mst131Form";

    /**
     * 定数：MasterInfo取得key.
     */
    private static final String CONST_MST131_MASTER = "mst131";

    // メッセージリスト
    List<MessageModuleBean> msgList = new ArrayList<>();

    /**
     * 履歴テーブル検索キー
     */
    private Map<String, Object> rirekiSearchKey;

    /**
     * 定数：行削除ファンクションコード
     */
    private static final String FUNC_CODE_DELETE_ROW = "mst131-delete-row-detail";

    /**
     * 仕入先マスタ更新
     */
    private static final String MST_KOUSHIN_STRING = "mst131-do-koushin";

    /**
     * 定数：再検索Button取得キー
     */
    private static final String CONST_MST131_SEARCH = "search_mst131";

    /**
     * コンストラクタ
     */
    public Mst131Bean() {
    }

    /**
     * 初期処理（処理）
     *
     * @param menuId
     * @param prevScreen
     * @param backFlag
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {

            // パンくず追加
            breadBean.push(TITLE, SCREEN.MST131_SCREEN.name(), this);

            // マスタ内容取得
            pageCommon.getMasterInfo(CONST_MST131_MASTER);

            // 検索シーケンス処理ため初期化
            searchHelpBean.regSearchHelp(DATA_TABLE_ID,
                    s -> {
                        return count(false);
                    },
                    s -> {
                        search();
                        return null;
                    },
                    s -> {
                        return searchCheck();
                    });
            searchHelpBean.getSettings().put(DATA_TABLE_ID, pageCommon);
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(都道府県リスト)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_MS_TODOFUKEN);
            //DBからマスタの内容を取得し、該当する項目の選択肢に設定する(営業所取得リスト)
            // 管轄営業所コード:オペレーションユーザ.営業所コード TODO
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO,
                    new AutoCompOptionBean("全て", "all"), authConfBean.getDefaultEigyosho());

            // 初期値を設定する
            setInitData();

            // 前回の記録をクリアする
            this.clear();
            form.setSearchResult(null);
            form.setSearchResultSelectable(null);
            form.setSelectedSearchResult(null);

            // 戻ってきた場合
            Mst131Form preForm = (Mst131Form) pageCommon.getPageInfo(CONST_MST131_FORM);
            if (backFlag && preForm != null) {
                PageCommonBean.simpleCopy(preForm, form);
                // 再検索を実施する
                pageCommon.searchAgain(CONST_MST131_SEARCH);
                // 進んできた場合
            } else {
                Flash flash = pageCommon.getPageParam();
                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_MST131_FORM) != null) {
                    PageCommonBean.simpleCopy(flash.get(CONST_MST131_FORM), form);
                    // 再検索を実施する
                    pageCommon.searchAgain(CONST_MST131_SEARCH);
                }
            }

            // ダウンロードシーケンス初期化
            fileBean.setDataSize(DATA_TABLE_ID, (id -> {
                return count(true);
            }));

            fileBean.getSettings().put(DATA_TABLE_ID, pageCommon);

            fileBean.setSubFlg(true);

            fileBean.setTilte(FILE_NAME);

            fileBean.regDownloadFucntion(DATA_TABLE_ID, getHeader(),
                    (id -> {
                        return getShiireSakiList(true);
                    }));

            fileBean.regBeforeDownFucntion(DATA_TABLE_ID,
                    (comment -> {
                        return beforeDown(comment);
                    }));
            fileBean.setSearchResult(DATA_TABLE_ID, (id -> {
                        return getSearchResult();
                    }));
            // component初期化とユーザ権限により制御を設定する
            pageCommon.setAuthControll(form, SC_CD_MST131, true);

            // 初期はデータを編集不可にする
            form.setBtnEditeDisabled(true);

        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * 検索時のチェック処理
     *
     * @return チェック結果
     */
    public String searchCheck() {

        if (form.getConSedaiKensakuJoken() != null && form.getConSedaiKensakuJoken().size() > 0) {
            // 世代検索条件で適用日指定が選択されている場合
            if (kbnBean.getKbnCdOfKeyCd(MsCnst.SEDAI_KENSAKU_JOKEN_TEKIYO_HI_SHITEI).equals(
                    form.getConSedaiKensakuJoken().get(form.getConSedaiKensakuJoken().size() - 1))) {

                if (form.getConTekiyoBi() == null) {
                    messageProperty.message(
                            MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0028, "適用日指定", "適用日");
                    return "FALSE";
                }
            }
        }
        return "TRUE";
    }

    /**
     * ダンロドへーだ設定
     *
     * @return ダンロドへーだ
     */
    public List<CSVDto> getHeader() {

        // CSVファイルのタイトルを設定
        List<CSVDto> header = new ArrayList<>();
        header.add(new CSVDto("管轄区分", "listKankatsuKbn"));
        header.add(new CSVDto("営業所名称", "listEigyoshoMei"));
        header.add(new CSVDto("仕入先コード", "listShiiresakiCd"));
        header.add(new CSVDto("仕入先名称", "listShiiresakiMeisho"));
        header.add(new CSVDto("適用開始日", "listTekiyoKaishibi"));
        header.add(new CSVDto("仕入先住所", "listShiiresakiJusho"));
        header.add(new CSVDto("仕入先コード(SS)", "listSsShiiresakiCd"));
        header.add(new CSVDto("航空会社", "listKokuGaishaFlg"));
        header.add(new CSVDto("代理店", "listDairitenFlg"));
        header.add(new CSVDto("幹線業者", "listKansenGyoshaFlg"));
        header.add(new CSVDto("中継業者", "listChukeiGyoshaFlg"));
        header.add(new CSVDto("チャーター業者", "listCharterGyoshaFlg"));
        header.add(new CSVDto("その他", "listSonotaFlg"));
        header.add(new CSVDto("最終使用日", "listSaishuShiyobi"));
        header.add(new CSVDto("ステータス", "listShinseiStatus"));
        return header;
    }

    /**
     * カウント処理
     *
     * @return 検索件数
     */
    public Long count(boolean downloadFlg) {

        // 前回の記録をクリアする 
        Map<String, Object> mapRec = new LinkedHashMap(); 
        mapRec.put("hideFlg", "hideRow"); 
        List<Map<String, Object>> mapList = new ArrayList(); 
        mapList.add(mapRec); 
        form.setSearchResult(mapList);
        form.setSearchResultSelectable(new ReportListDataModel(form.getSearchResult()));
        form.setSelectedSearchResult(null);
        // レコード件数を取得する
        long recordCount = getShiireSakiListKensu(downloadFlg);
        // 検索部のステータスを変更する
        pageCommon.setSerchConDisabled(form);
        // サブ検索条件フラグ設定
        fileBean.setSubFlg(subSearchConHad());

        if (!downloadFlg) {
            // 検索条件保存
            pageCommon.savePageInfo(CONST_MST131_FORM, form);
        }
        return recordCount;
    }

    /**
     * 申請 TODO
     */
    public void shinsei() {

        //入力チェック
        if (inputNullCheck()) {
            return;
        }
        //申請処理呼び出し
        Map<String, Object> param = new HashMap<>();
        param.put("selectData", form.getSelectedSearchResult());
        ServiceInterfaceBean res = pageCommon.getDBInfo(param, "mst131-get-shinsei");
    }

    /**
     * 申請ステータス更新 TODO
     */
    public void kouShin() {

        //入力チェック
        if (inputNullCheck()) {
            return;
        }
        // 受け取った申請ステータスが最終承認以外の場合
        Map<String, Object> paramsMap = new HashMap<>();
        // SHIIRESAKI_CD
        paramsMap.put("conShiiresakiCd", form.getConShiiresakiCd());
        // TEKIYO_KAISHIBI
        paramsMap.put("conTekiyoBi", form.getConTekiyoBi());
        // TEKIYO_FLG
        paramsMap.put("listHTekiyoFlg", form.getListHTekiyoFlg());

        // 受け取った申請ステータスが最終承認の場合
        Map<String, Object> sakujyoparamsMap = new HashMap<>();
        // SHIIRESAKI_CD
        sakujyoparamsMap.put("conShiiresakiCd", form.getConShiiresakiCd());
        // TEKIYO_KAISHIBI
        sakujyoparamsMap.put("conTekiyoBi", form.getConTekiyoBi());
        // TEKIYO_FLG
        sakujyoparamsMap.put("listHTekiyoFlg", "1");
        // メッセージを設定する
        messageProperty.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0007, "更新");
        pageCommon.getDBInfo(paramsMap, MST_KOUSHIN_STRING);
    }

    /**
     * 検索処理
     */
    public void search(){
        // 選択リストを初期化する
        form.setSelectedSearchResult(new ArrayList<>());

        // 仕入先マスタ検索を行う
        List<Map<String, Object>> recordList = getShiireSakiList(false);
        
        fileBean.setDataList(recordList);

        // 取得した値を画面項目にセットする
        pageCommon.setDatalist(DATA_TABLE_ID, recordList);
        form.setSearchResultSelectable(new ReportListDataModel(recordList));

        // 検索部のステータスを変更する
        pageCommon.setSerchConDisabled(form);

        // 参照モードにする
        pageCommon.setEditFlg(false);
    }

    /**
     * DBから仕入先マスタ情報を取得する
     *
     * @return 仕入先マスタ情報
     */
    public List<Map<String, Object>> getShiireSakiList(boolean downloadFlg) {
        // 検索条件設定
        Map<String, Object> paramsMap = setParam(downloadFlg);
        // DBをアクセス
        ServiceInterfaceBean res = pageCommon.getDBInfo(paramsMap, SEARCH_FUNC_CODE);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        try {
            ObjectMapper mapper = new ObjectMapper();
            form.setSearchResult(mapper.readValue(res.getJson(), List.class));
            
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
        // 検索結果一覧データ
        List<Map<String, Object>> searchResultList = form.getSearchResult();
        for (Map<String, Object> map : searchResultList) {
            if (map.get("listTekiyoKaishibi") != null && map.get("listTekiyoKaishibi") != "") {
                map.replace("listTekiyoKaishibi",
                    dateFormat.format(new Date(Long.valueOf(map.get("listTekiyoKaishibi").toString()))));
            }
            if (map.get("listSaishuShiyobi") != null && map.get("listSaishuShiyobi") != "") {
                map.replace("listSaishuShiyobi",
                    dateFormat.format(new Date(Long.valueOf(map.get("listSaishuShiyobi").toString()))));
            }
        }
        form.setSearchResult(searchResultList);
        return form.getSearchResult();
    }
    
    /**
     * ドンロドデータ
     *
     * @param comment ドンロド内容
     * @throws Exception
     * @return
     */
    public boolean beforeDown(String comment) throws Exception {
        System.out.println(comment);
        return true;
    }

    /**
     * メニュークリック（処理）
     *
     * @param menuId
     * @param nextScreen
     * @return
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック（処理）
     *
     * @param nextScreen 次の画面
     * @param breadIndex パン屑のINDEX
     * @return
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        url = forward(nextScreen, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return
     */
    @Override
    public String logoutClick() {
        return authConfBean.logout();
    }

    /**
     * 画面遷移処理（顧客マスタメンテナンス画面へ）
     *
     * @return
     * @throws java.lang.IllegalAccessException
     * @throws java.lang.reflect.InvocationTargetException
     */
    public String buttonClick() throws IllegalAccessException, InvocationTargetException, SystemException {

        // 画面遷移
        Map<String, Object> map = new HashMap<>();
        setMst131Param(map);
        url = forward(SCREEN.MST132_SCREEN.name(), null, SCREEN.CUS011_SCREEN.name(), false);
        return url;
    }

    /**
     * 検索条件変更処理
     */
    public void searchChange() {

        // 検索部のステータス変更
        pageCommon.setSerchConEnabled(form);

    }
    
    /**
     * クリア処理
     */
    public void clear() {

        // 検索部の条件クリア
        form.setConTodofuken(null);
        form.setConSakujoSumiNomi(null);
        form.setConKankatsuKbn(null);
        form.setConJusho(null);
        form.setConKaishaMei(null);
        form.setConKanaMeisho(null);
        form.setConMishiyoKikanNen(0);
        form.setConMishiyoKikanTsuki(0);
        form.setConSedaiKensakuJoken(null);
        form.setConShiiresakiCd(null);
        form.setConShiiresakiMei(null);
        form.setConShinseiJokyo(null);
        form.setConShitenEigyoshoMei(null);
        form.setConShiyoKbn(null);
        form.setConSsShiiresakiCd(null);
        form.setConSsShiiresakiMei(null);
        form.setConTekiyoBi(null);
        form.setConTodofukenCd(null);

        // 初期値を設定する
        setInitData();

        // 検索部のステータス変更
        pageCommon.setSerchConEnabled(form);
        pageCommon.setBtnSearchChangeVisible(false);
        pageCommon.setBtnSearchVisible(Boolean.TRUE);
    }

    /**
     * 更新履歴を表示処理
     */
    public void rirekiIchiran() {

        // 履歴テーブル検索キーを設定する
        rirekiSearchKey = new HashMap();

        // 選択されたレコードを取得する
        Map<String, Object> selectedRecord = form.getSelectedSearchResult().get(0);
        // 仕入先コード
        rirekiSearchKey.put("conShiiresakiCd", selectedRecord.get("listShiiresakiCd"));
        // 削除済のみ
        if (selectedRecord.get("listShinseiStatus") != null) {
            if ("削除".equals(selectedRecord.get("listShinseiStatus").toString().trim())) {
                        rirekiSearchKey.put("conSakujoSumiNomi", "1");
            }
        }
        // 適用開始日
        rirekiSearchKey.put("conTekiyoBi", selectedRecord.get("listTekiyoKaishibi"));
        //未使用期間（年）
        rirekiSearchKey.put("conMishiyoKikanNen", form.getConMishiyoKikanNen());
        //未使用期間（月）
        rirekiSearchKey.put("conMishiyoKikanTsuki", form.getConMishiyoKikanTsuki());
        // 履歴タイトルを設定する
        rirekiSyosaiBean.setListColName(
                new ArrayList<>(Arrays.asList(
                        "バージョン情報", "管轄区分", "営業所名称", "仕入先コード", "仕入先名称",
                        "適用開始日", "仕入先住所", "仕入先コード(SS)", "航空会社",
                        "代理店", "幹線業者", "中継業者", "チャーター業者", "その他", "最終使用日", "ステータス")));

        // 履歴beanの項目物理名を設定する
        List<String> colValue = new ArrayList<>(Arrays.asList(
                "listHShiiresakiDataVersion", "listKankatsuKbn", "listEigyoshoMei", "listShiiresakiCd",
                "listShiiresakiMeisho", "listTekiyoKaishibi", "listShiiresakiJusho", "listSsShiiresakiCd",
                "listKokuGaishaFlg", "listDairitenFlg", "listKansenGyoshaFlg", "listChukeiGyoshaFlg",
                "listCharterGyoshaFlg", "listSonotaFlg", "listSaishuShiyobi", "listShinseiStatus"));
        List<String> colAlign = new ArrayList<>(Arrays.asList(
                "left", "left", "left", "left", "left", "left", "center", "left", "left", "center", "left", "left",
                "left", "left", "left", "center"
        ));

        List<RirekiListCol> listCol = new ArrayList<>();
        for (int i = 0; i < colValue.size(); i++) {
            RirekiListCol col = new RirekiListCol();
            col.setColValue(colValue.get(i));
            col.setColAlign(colAlign.get(i));
            listCol.add(col);
        }
        rirekiSyosaiBean.setListCol(listCol);
        // 履歴テーブルを検索する
        rirekiSyosaiBean.searchList("2", "MST131_SEARCH_RIREKI", rirekiSearchKey);
    }

    /**
     * DBから仕入先マスタ情報を削除する処理
     *
     * @param recordList レコードリスト
     * @return ステータスコード
     */
    public void deleteShimukeList() {

        if (inputNullCheck()) {
            return ;
        }
        // DBをアクセス
        ServiceInterfaceBean serviceInterfaceBean = pageCommon.accsessDBWithList(form.getSelectedSearchResult(), FUNC_CODE_DELETE_ROW);
        // ステータスコードを返却する
        if (serviceInterfaceBean != null) {
            messageProperty.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COME0029,serviceInterfaceBean.getMessages().get(0)[2]);
            return ;
        }
        search();

    }

   /**
     * 入力チェック処理
     *
     * @return
     */
    public boolean inputNullCheck() {
        if (form.getSelectedSearchResult().isEmpty() || form.getSelectedSearchResult().size() < 1) {
            MessageModuleBean message
                    = messageProperty.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
            msgList.add(message);
            messageProperty.messageList(msgList);
            return true;
        }
        return false;
    }

        /**
     * 詳細コンテキストメニュー／詳細ボタンクリック処理
     * 
     * @param buttonFlg 詳細ボタンクリックフラグ(true:詳細ボタンクリック)
     * @return 遷移先の画面URL
     * @throws IllegalAccessException
     * @throws InvocationTargetException 
     * @throws SystemException 
     */
    public String detailClick(boolean buttonFlg)
            throws IllegalAccessException, InvocationTargetException, SystemException {
        
        // 詳細ボタンクリックの場合、チェックを行う
        if (buttonFlg) {
            // 未選択、または、複数選択の場合はエラー
            if (form.getSelectedSearchResult() == null ||
                    form.getSelectedSearchResult().isEmpty() ||
                    form.getSelectedSearchResult().size() > 1) {
                messageProperty.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
                return null;
            } else if (form.getSelectedSearchResult() != null &&
                    form.getSelectedSearchResult().size() == 1) {
                // 選択されたレコードを取得する
                Map<String, Object> selectedRecord = form.getSelectedSearchResult().get(0);
                Map<String, Object> map = new HashMap<>();
                map.put("kankaKbn", selectedRecord.get("listKankatsuKbn"));
                // 管轄営業所コード
                map.put("eigyoshoCd", selectedRecord.get("listHEigyoshoCd"));
                map.put("eigyoshoMei", selectedRecord.get("listEigyoshoMei"));
                map.put("status", selectedRecord.get("listShinseiStatus"));
                map.put("shiiresakiCd", selectedRecord.get("listShiiresakiCd"));
                map.put("kaishiBi", selectedRecord.get("listTekiyoKaishibi"));
                map.put("teikiyoMei", selectedRecord.get("listShiiresakiMeisho"));
                map.put("tekiyoshuryo", selectedRecord.get("listSaishuShiyobi"));
                map.put("moveMode", "2");
                setMst131Param(map);
                // パラメータを設定する
            }
        }

        // 画面遷移
        url = forward(SCREEN.MST132_SCREEN.name(), null, SCREEN.MST131_SCREEN.name(), false);
        return url;
    }
 
    /**
     * 仕入先コードクッリク
     * @param kankatsuKbn
     * @param kankatsuEigyoshoCd
     * @param kankatsuEigyoshoMei
     * @param ShoninStatus
     * @param shiiresakiCd
     * @param tekiyoKaishibi
     * @param tekiyoMei
     * @param tekiyoShuryo
     * @throws SystemException
     * @return url
     */
    public String linkClick(String kankatsuKbn, String kankatsuEigyoshoCd,
            String kankatsuEigyoshoMei, String ShoninStatus, String shiiresakiCd,
            String tekiyoKaishibi, String tekiyoMei, String tekiyoShuryo) throws SystemException{
        Map<String, Object> map = new HashMap<>();
        map.put("kankaKbn", kankatsuKbn);
        map.put("eigyoshoCd", kankatsuEigyoshoCd);
        map.put("eigyoshoMei", kankatsuEigyoshoMei);
        map.put("status", ShoninStatus);
        map.put("shiiresakiCd", shiiresakiCd);
        map.put("kaishiBi", tekiyoKaishibi);
        map.put("teikiyoMei", tekiyoMei);
        map.put("tekiyoshuryo", tekiyoShuryo);
        map.put("moveMode", "3");
        setMst131Param(map);
        url = forward(SCREEN.MST132_SCREEN.name(), null, SCREEN.MST131_SCREEN.name(), false);
        return url;
    
    }

    private void setMst131Param(Map<String, Object> params) throws SystemException {

        Mst131Form mst131Form = new Mst131Form();
        Flash flash = pageCommon.getPageParam();
        flash.put("param", params);

    }
    
    /**
     * 検索件数を取得する
     *
     * @return 検索件数
     */
    private Long getShiireSakiListKensu(boolean downloadFlg) {

        // 検索条件設定
        Map<String, Object> paramsMap = setParam(downloadFlg);
        // DBをアクセス
        ServiceInterfaceBean res = pageCommon.getDBInfo(paramsMap, SEARCH_COUNT_FUNC_CODE);

        return Long.valueOf(res.getJson());
    }

    /**
     * 検索条件の設定
     *
     * @return 検索条件
     */
    private Map<String, Object> setParam(boolean downloadFlg) {
        // パラメータ
        Map<String, Object> params = new HashMap<>();
        Mst131Form tempForm = form;
        if (downloadFlg) {
            tempForm = (Mst131Form)pageCommon.getPageInfo(CONST_MST131_FORM);
        }
        // 都道府県コード
        if (tempForm.getConTodofuken() != null) {
            params.put("conTodofukenCd", tempForm.getConTodofuken().getValue());
        }
        params.put("conKankatsuKbn", tempForm.getConKankatsuKbn());
        // 管轄営業所コード
        if (tempForm.getKankatsuEigyosho() == null) {
            params.put("conKankatsuEigyoshoCd", "");
        } else {
            params.put("conKankatsuEigyoshoCd", tempForm.getKankatsuEigyosho().getValue());
        }
        // SS仕入先コード
        params.put("conSsShiiresakiCd", tempForm.getConSsShiiresakiCd());
        // 仕入先コード
        params.put("conShiiresakiCd", tempForm.getConShiiresakiCd());
        // 会社名
        params.put("conKaishaMei", tempForm.getConKaishaMei());
        // 支店/営業所名
        params.put("conShitenEigyoshoMei", tempForm.getConShitenEigyoshoMei());
        // 仕入先名
        params.put("conShiiresakiMei", tempForm.getConShiiresakiMei());
        // 使用区分
        params.put("conShiyoKbn", tempForm.getConShiyoKbn());
        // 世代検索条件
        params.put("conSedaiKensakuJoken", tempForm.getConSedaiKensakuJoken());
        // 適用日
        params.put("conTekiyoBi", tempForm.getConTekiyoBi());
        // 削除済のみ
        if (tempForm.getConSakujoSumiNomi() == null || tempForm.getConSakujoSumiNomi().isEmpty()) {
            params.put("conSakujoSumiNomi", "");
        } else {
            params.put("conSakujoSumiNomi", tempForm.getConSakujoSumiNomi().get(0));
        }
        // カナ名称
        params.put("conKanaMeisho", tempForm.getConKanaMeisho());
        // 申請状況
        params.put("conShinseiJokyo", tempForm.getConShinseiJokyo());
        // 住所
        params.put("conJusho", tempForm.getConJusho());
        // 未使用期間（年）
        params.put("conMishiyoKikanNen", tempForm.getConMishiyoKikanNen());
        // 未使用期間（月）
        params.put("conMishiyoKikanTsuki", tempForm.getConMishiyoKikanTsuki());
        // 削除
        params.put("conSakuJyo", kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_SAKUJO").getKbnMei());
        // 適用終了
        params.put("conTeikiyouShuryo", kbnBean.getKbnInfoOfKeyCd("SHINSEI_STATUS_ICHIRAN_TEKIYO_SHURYO").getKbnMei());
        return params;
    }

    /**
     * サブ検索条件入力判断
     *
     * @return true:入力あり/false:入力しない
     */
    private boolean subSearchConHad() {

        // カナ名称
        if (!CheckUtils.isEmpty(form.getConKanaMeisho())) {
            return true;
        }
        // 世代検索条件
        if (form.getConSedaiKensakuJoken() != null && form.getConSedaiKensakuJoken().size() > 0) {
            return true;
        }
        // 適用日
        if (form.getConTekiyoBi() != null && !"".equals(form.getConTekiyoBi())) {
            return true;
        }
        // 削除のみ
        if (form.getConSakujoSumiNomi() != null && form.getConSakujoSumiNomi().size() > 0) {
            return true;
        }
        // 申請状況
        if (form.getConShinseiJokyo() != null && form.getConShinseiJokyo().size() > 0) {
            return true;
        }
        // 都道府県
        if (form.getConTodofukenCd() != null && !form.getConTodofukenCd().isEmpty()) {
            return true;
        }
        // 住所
        if (form.getConJusho() != null && !form.getConJusho().isEmpty()) {
            return true;
        }
        // 未使用期間（年）
        if (form.getConMishiyoKikanNen() != 0 && form.getConMishiyoKikanNen() > 0) {
            return true;
        }
        // 未使用期間（月）
        if (form.getConMishiyoKikanTsuki() != 0 && form.getConMishiyoKikanTsuki() > 0) {
            return true;
        }
        return false;
    }

    /**
     * 初期値を設定する
     */
    private void setInitData() {
        // 管轄区分:全社
        List<String> initKankatsuKbn = new ArrayList();
        initKankatsuKbn.add(kbnBean.getKbnCdOfKeyCd(MsCnst.KANKATSU_KBN_ZENSHA));
        form.setConKankatsuKbn(initKankatsuKbn);

        // 世代検索条件:"現在適用","未来適用"にチェック
        List<String> initSedaiKensakuJoken = new ArrayList();
        initSedaiKensakuJoken.add(kbnBean.getKbnCdOfKeyCd(MsCnst.SEDAI_KENSAKU_JOKEN_GENZAI_TEKIYO));
        initSedaiKensakuJoken.add(kbnBean.getKbnCdOfKeyCd(MsCnst.SEDAI_KENSAKU_JOKEN_MIRAI_TEKIYO));
        form.setConSedaiKensakuJoken(initSedaiKensakuJoken);

        // 申請状況:全てチェックあり
        List<KbnModuleBean> shinseiJokyoList = kbnBean.getKbnsOfGroupCd(MsCnst.SHINSEI_JOKYO);
        List<String> initShinseiJokyo = new ArrayList();
        for (int i = 0; i < shinseiJokyoList.size(); i++) {
            initShinseiJokyo.add(shinseiJokyoList.get(i).getKbnCd());
        }
        form.setConShinseiJokyo(initShinseiJokyo);
    }
    
    /**
     * 検索結果取得
     * @return 検索結果
     */
    public List<Map<String, Object>> getSearchResult(){
        return form.getSearchResult();
    }

}
