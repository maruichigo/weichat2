/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.sample;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.SessionScoped;
import javax.faces.event.AjaxBehaviorEvent;
import lombok.Data;
import org.primefaces.component.themeswitcher.ThemeSwitcher;

/**
 *
 * @author yinyanxu
 */
@javax.faces.bean.ManagedBean(name = "themeBean")
@SessionScoped
@Data
public class ThemeBean implements Serializable{

//    private List<Theme> themes;
    private List<String> themes;
    private String theme = "omega";

    public void setTheme(String theme) {
        this.theme = theme;
    }

    @PostConstruct
    public void init() {

        themes = new ArrayList<>();
//        themes.add(new Theme(0, "afternoon", "afternoon"));
//        themes.add(new Theme(1, "afterwork", "afterwork"));
//        themes.add(new Theme(2, "black-tie", "black-tie"));
//        themes.add(new Theme(3, "blitzer", "blitzer"));
//        themes.add(new Theme(4, "bluesky", "bluesky"));
//        themes.add(new Theme(5, "bootstrap", "bootstrap"));
//        themes.add(new Theme(6, "casablanca", "casablanca"));
//        themes.add(new Theme(7, "cruze", "cruze"));
//        themes.add(new Theme(8, "cupertino", "cupertino"));
//        themes.add(new Theme(9, "dark-hive", "dark-hive"));
//        themes.add(new Theme(10, "dot-luv", "dot-luv"));
//        themes.add(new Theme(11, "eggplant", "eggplant"));
//        themes.add(new Theme(12, "excite-bike", "excite-bike"));
//        themes.add(new Theme(13, "flick", "flick"));
//        themes.add(new Theme(14, "glass-x", "glass-x"));
//        themes.add(new Theme(15, "home", "home"));
//        themes.add(new Theme(16, "hot-sneaks", "hot-sneaks"));
//        themes.add(new Theme(17, "humanity", "humanity"));
//        themes.add(new Theme(18, "le-frog", "le-frog"));
//        themes.add(new Theme(19, "midnight", "midnight"));
//        themes.add(new Theme(20, "mint-choc", "mint-choc"));
//        themes.add(new Theme(21, "overcast", "overcast"));
//        themes.add(new Theme(22, "pepper-grinder", "pepper-grinder"));
//        themes.add(new Theme(23, "redmond", "redmond"));
//        themes.add(new Theme(24, "rocket", "rocket"));
//        themes.add(new Theme(25, "sam", "sam"));
//        themes.add(new Theme(26, "smoothness", "smoothness"));
//        themes.add(new Theme(27, "south-street", "south-street"));
//        themes.add(new Theme(28, "start", "start"));
//        themes.add(new Theme(29, "sunny", "sunny"));
//        themes.add(new Theme(30, "swanky-purse", "swanky-purse"));
//        themes.add(new Theme(31, "themes-project", "themes-project"));
//        themes.add(new Theme(32, "trontastic", "trontastic"));
//        themes.add(new Theme(33, "ui-darkness", "ui-darkness"));
//        themes.add(new Theme(34, "ui-lightness", "ui-lightness"));
//        themes.add(new Theme(35, "vader", "vader"));

        themes.add("afternoon");
        themes.add("afterwork");
        themes.add("black-tie");
        themes.add("blitzer");
        themes.add("bluesky");
        themes.add("bootstrap");
        themes.add("casablanca");
        themes.add("cruze");
        themes.add("cupertino");
        themes.add("dark-hive");
        themes.add("dot-luv");
        themes.add("eggplant");
        themes.add("excite-bike");
        themes.add("flick");
        themes.add("glass-x");
        themes.add("home");
        themes.add("hot-sneaks");
        themes.add("humanity");
        themes.add("le-frog");
        themes.add("midnight");
        themes.add("mint-choc");
        themes.add("overcast");
        themes.add("pepper-grinder");
        themes.add("redmond");
        themes.add("rocket");
        themes.add("sam");
        themes.add("smoothness");
        themes.add("south-street");
        themes.add("start");
        themes.add("sunny");
        themes.add("swanky-purse");
        themes.add("themes-project");
        themes.add("trontastic");
        themes.add("ui-darkness");
        themes.add("ui-lightness");
        themes.add("vader");

    }

    public void saveTheme(AjaxBehaviorEvent ajax) {
        setTheme((String) ((ThemeSwitcher) ajax.getSource()).getValue());
    }

}
