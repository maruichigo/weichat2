package jp.co.kintetsuls.service.general.property;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import javax.faces.context.FacesContext;
import jp.co.kintetsuls.service.general.property.ServiceCnst;

public class ExternalServiceProperty {

    private static ExternalServiceProperty instance = null;
    private static Properties prop = null;

    private ExternalServiceProperty() {
        String homeDir = FacesContext.getCurrentInstance().getExternalContext().getInitParameter(ServiceCnst.CONF_HOME);
        String configFile = homeDir + ServiceCnst.PROP_SERVICE;
        String configFile2 = homeDir + ServiceCnst.AD_SERVICE;
        prop = new Properties();
        try {
            prop.load(new FileInputStream(configFile));
            prop.load(new FileInputStream(configFile2));
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }
    }

    public static ExternalServiceProperty getInstance() {
        if (instance == null) {
            instance = new ExternalServiceProperty();
        }
        return instance;
    }

    public String getProperty(String key){
        return prop.getProperty(key);
    }
}