/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common.annotation.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import jp.co.kintetsuls.beans.common.annotation.NumberRange;

/**
 * 半角数字範囲チェック
 *
 * @author zf (MBP)
 * @version 2019/3/7 新規作成
 */
public class NumberRangeValidator implements ConstraintValidator<NumberRange, Object> {

    private int minValue;
    private int maxValue;

    @Override
    public void initialize(NumberRange constraintAnnotation) {
        this.minValue = constraintAnnotation.minValue();
        this.maxValue = constraintAnnotation.maxValue();
    }

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext context) {
        if (value == null || "".equals(value.toString())) {
            return true;
        }
        int val = Integer.valueOf(value.toString());
        if (val < minValue || val > maxValue) {
            return false;
        }
        return true;
    }

}
