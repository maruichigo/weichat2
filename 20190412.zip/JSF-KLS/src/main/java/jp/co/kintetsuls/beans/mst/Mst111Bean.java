/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiListCol;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst111Form;
import jp.co.kintetsuls.utils.DateUtils;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * ルートマスタ
 *
 * @author 黄義輝 (MBP)
 * @version 2019/03/19 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst111")
@ViewScoped
@Data
public class Mst111Bean extends AbstractBean{

    /**
     * ダウンロードファイル名
     */
    private final static String FILE_NAME = "ルートマスタ一覧";

    /**
     * タイトル
     */
    private final String TITLE = "ルートマスタ";   

    /**
     * 画面URL
     */
    private String url;    

    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

    /**
     * 一覧のAutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoComplete}")
    private AutoCompleteBean autoCompleteBean;

    /**
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authorityConfBean;

    /**
     * ファイルダウンロード
     */
    @ManagedProperty(value = "#{fileBean}")
    private FileBean fileBean;

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;

    /**
     * 画面フォーム
     */
    @ManagedProperty(value = "#{mst111Form}")
    private Mst111Form mst111Form;

    /**
     * 画面共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * 検索シーケンス処理共通
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;

    /**
     * 履歴一覧処理共通
     */
    @ManagedProperty(value = "#{rirekisyosai}")
    private RirekiSyosaiBean rirekiSyosaiBean;

    /**
     * 一覧単項目チェック共通
     */
    @ManagedProperty(value = "#{listCheckBean}")
    private ListCheckBean listCheckBean;

    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(
            new Object() {}.getClass().getEnclosingClass().getName());

    /**
     * スクリーンコード：MST111
     */
    private static final String SC_CD_MST111 = "MST111_SCREEN";

    /**
     * 定数：検索FUNC_CODE.
     */
    private static final String FUNC_CODE_SEARCH = "mst111-get-route-detail";

    /**
     * 定数：検索件数取得FUNC_CODE.
     */
    private static final String FUNC_CODE_SEARCH_KENSU = "mst111-get-route-kensu";

    /**
     * 定数：登録更新FUNC_CODE.
     */
    private static final String FUNC_CODE_INSERT_UPDATE_CHECK = "mst111-insert-update-check";

    /**
     * 定数：登録更新チェックFUNC_CODE.
     */
    private static final String FUNC_CODE_INSERT_UPDATE = "mst111-insert-update";

    /**
     * 定数：削除の存在チェックFUNC_CODE.
     */
    private static final String FUNC_CODE_DELETE_EXIST = "mst111-delete-exist";

    /**
     * 定数：行削除FUNC_CODE.
     */
    private static final String FUNC_CODE_DELETE_ROW = "mst111-delete-row-detail";

    /**
     * 定数：拠点コード関連表情報を取得FUNC_CODE.
     */
    private static final String FUNC_CODE_SEARCH_KYOTENKANOROSHINE = "mst111-search-kyotenkanOroshine";

    /**
     * 定数：一覧のDataTableのID.
     */
    private static final String DATA_TABLE_ID = "tablesorter_mst111";

    /**
     * 定数：画面項目保持key.
     */
    private static final String CONST_MST111_FORM = "mst111Form";

    /**
     * 定数：MasterInfo取得key.
     */
    private static final String CONST_MST111_MASTER = "mst111";

    /**
     * 定数：再検索Button取得キー
     */
    private static final String CONST_MST111_SEARCH = "search_mst111";  

    /**
     * 履歴テーブル検索キー.
     */
    private Map<String, Object> rirekiSearchKey;

    /**
     * ワーク.メッセージリスト
     */
    List<MessageModuleBean> msgList = new ArrayList<>();

    /**
     * コンストラクタ
     */
    public Mst111Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId メニューID
     * @param prevScreen 遷移元画面ID
     * @param backFlag 戻るフラグ
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {

            // パンくず追加
            breadBean.push(TITLE, SCREEN.MST111_SCREEN.name(), this);

            // マスタ内容取得
            pageCommonBean.getMasterInfo(CONST_MST111_MASTER);

            // 検索シーケンス処理ため初期化
            searchHelpBean.regSearchHelp(DATA_TABLE_ID,
                    s -> {return getRecordCount(false);},
                    s -> {search(); return null;},
                    null);

            searchHelpBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);

            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する
            // 発地リスト
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_HATSUCHI_KENSAKU_JOKEN);
            // 着地リスト
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_CHAKUCHI_KENSAKU_JOKEN);

            // 経由地選択フラグ false
            mst111Form.setSelectedKeiyuchiFlag("false");

            // 前回の記録をクリアする
            this.clear();
            mst111Form.setSearchResult(null);
            mst111Form.setSearchResultSelectable(null);
            mst111Form.setSelectedSearchResult(null);

            // 戻ってきた場合
            Mst111Form preForm = (Mst111Form) pageCommonBean.getPageInfo(CONST_MST111_FORM);
            if (backFlag && preForm != null) {
                PageCommonBean.simpleCopy(preForm, mst111Form);
                // 再検索を実施する
                pageCommonBean.searchAgain(CONST_MST111_SEARCH);
            // 進んできた場合
            } else {
                Flash flash = pageCommonBean.getPageParam();
                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_MST111_FORM) != null) {
                    PageCommonBean.simpleCopy(flash.get(CONST_MST111_FORM), mst111Form);
                    // 再検索を実施する
                    pageCommonBean.searchAgain(CONST_MST111_SEARCH);
                }
            }

            // ダウンロードシーケンス初期化
            fileBean.setDataSize(DATA_TABLE_ID, (id -> {return getRecordCount(true);}));

            fileBean.setSearchResult(DATA_TABLE_ID, (id -> {return getSearchResult();})); 

            fileBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);

            fileBean.setSubFlg(false);

            fileBean.setTilte(FILE_NAME);

            fileBean.regDownloadFucntion(DATA_TABLE_ID, getHeader(),
                    (id -> {return getRouteList(true);}));

            fileBean.regBeforeDownFucntion(DATA_TABLE_ID,
                    (comment -> {return beforeDown(comment);}));

            // 行更新また削除するために共通処理へ登録
            pageCommonBean.regDelFucntion(DATA_TABLE_ID,
                    (dataList -> (this.delRows(dataList))));

            // component初期化とユーザ権限により制御設定
            pageCommonBean.setAuthControll(mst111Form, SC_CD_MST111, true);
            
            // 初期はデータを編集不可にする
            mst111Form.setBtnEditeDisabled(true);

        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * カウント処理
     *
     * @param downloadFlg ダウンロードフラグ
     * @return レコード件数
     */
    public Long getRecordCount(boolean downloadFlg) {

        // 前回の記録をクリアする
        Map<String, Object> mapRec = new LinkedHashMap();
        mapRec.put("hideFlg", "hideRow");
        List<Map<String, Object>> mapList = new ArrayList();
        mapList.add(mapRec);
        mst111Form.setSearchResult(mapList);
        mst111Form.setSearchResultSelectable(new ReportListDataModel(mst111Form.getSearchResult()));
        mst111Form.setSelectedSearchResult(null);

        // 検索初期はデータを編集不可にする
        mst111Form.setBtnEditeDisabled(true);

        // レコード件数を取得する
        long kensu = getRouteListKensu(downloadFlg);

        if (!downloadFlg) {

            // 検索部のステータスを変更する
            pageCommonBean.setSerchConDisabled(mst111Form);

            // 参照モードにする
            pageCommonBean.setEditFlg(false);

            // 検索条件保存
            pageCommonBean.savePageInfo(CONST_MST111_FORM, mst111Form);

        }

        return kensu;
    }

    /**
     * 検索処理
     *
     */
    public void search() {

        // 選択リストを初期化
        mst111Form.setSelectedSearchResult(new ArrayList<>());
        mst111Form.setSearchResultSelectable(null);

        // ルートマスタ検索し、取得した値を画面項目にセット
        List<Map<String, Object>> recordList = getRouteList(false);
        
        if (recordList == null || recordList.isEmpty()) {
            return;
        }

        // 配色定義を設定する
        setIchiranColor(recordList);

        fileBean.setDataList(recordList);

        // 取得した値を画面項目にセットする
        pageCommonBean.setDatalist(DATA_TABLE_ID, recordList);
        mst111Form.setSearchResultSelectable(new ReportListDataModel(recordList));
        
        // 検索部のステータスを変更する
        pageCommonBean.setSerchConDisabled(mst111Form);

        // 削除済のみのチェック状態より、明細データを編集可／不可にする
        if (mst111Form.getConSakujoSumiNomi() == null || mst111Form.getConSakujoSumiNomi().length == 0) {
            // 削除済みデータを編集可にする
            mst111Form.setBtnEditeDisabled(false);
        } else {
            // 削除済みデータを編集不可にする
            mst111Form.setBtnEditeDisabled(true);
        }

        // 参照モードにする
        pageCommonBean.setEditFlg(false);
    }

    /**
     * 配色定義の設定処理
     *
     * @param recordList レコードリスト
     */
    public void setIchiranColor(List<Map<String, Object>> recordList) {

        // 配色定義の判定
        
    }

    /**
     * 検索条件変更処理
     *
     */
    public void searchChange() {

        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mst111Form);
    }

    /**
     * クリア処理
     *
     */
    public void clear() {

        // 検索部の条件クリア
        // 発地
        mst111Form.setConHatsuchi(null);
        // 着地
        mst111Form.setConChakuchi(null);
        // デフォルトルート検索
        mst111Form.setConDefaultRouteKensaku(null);
        // 削除済のみ
        mst111Form.setConSakujoSumiNomi(null);

        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mst111Form);
        pageCommonBean.setBtnSearchChangeVisible(false);
        pageCommonBean.setBtnSearchVisible(Boolean.TRUE);
    }

    /**
     * 更新処理
     *
     */
    public void update() {

        // エラーメッセージを格納する変数の初期化を行う
        msgList = new ArrayList();

        // 行選択チェック
        if (mst111Form.getSelectedSearchResult() == null || mst111Form.getSelectedSearchResult().isEmpty()) {

            MessageModuleBean message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
            msgList.add(message);

            messagePropertyBean.messageList(msgList);
            return;
        }

        // 登録一覧リストの初期化を行う
        List<Map<String, Object>> torokuIchiranList = new ArrayList();

        // 更新一覧リストの初期化を行う
        List<Map<String, Object>> koshinIchiranList = new ArrayList();  

        // 単項目チェック処理
        if (!checkJsfParamas(mst111Form.getSelectedSearchResult())) {
            return;
        }

        // 登録更新情報設定処理
        mst111Form.getSelectedSearchResult().forEach((rec) -> {
            // ルートマスタ一覧.カレント行 = 登録対象
            if (rec.get(StndConsIF.CONST_ADD_ROW_KEY) != null) {
                // 登録データワークにデータを設定する
                torokuIchiranList.add(rec);
            } else {
                // 更新データワークにデータを設定する
                koshinIchiranList.add(rec);
            }
        });

        // 登録一覧リストと更新一覧リストの登録処理
        if (torokuIchiranList.size() > 0 || koshinIchiranList.size() > 0) {

            // 登録・更新処理を行う
            int status = insertUpdateRouteList();

            // エラーの場合、処理終了
            if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
                return;
            }

            // 登録の後に再度検索する
            pageCommonBean.searchAgain(CONST_MST111_SEARCH);
        }

        // 一覧の配色定義をなくす
        pageCommonBean.resetIchiranColColor(mst111Form.getSelectedSearchResult());

        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, "更新");

        // ログ出力を行う
        LOGGER.info("更新 " + mst111Form.getSelectedSearchResult().size() + " 件");
    }

    /**
     * 一覧の単項目チェック処理
     * 
     * @param params 画面一覧パラメータ
     * @return チェックの結果
     */
    private boolean checkJsfParamas(List<Map<String, Object>> params) {

        List<ListCheckBean> checks = new ArrayList<>();

        checks.add(new ListCheckBean("listHatsuchiCd", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "発地コード"));
        checks.add(new ListCheckBean("listChakuchiCd", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "着地コード"));
        checks.add(new ListCheckBean("listYusenjuni", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "優先順位"));
        checks.add(new ListCheckBean("listYusenjuni", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NUMBER, "優先順位"));
        checks.add(new ListCheckBean("listYusenjuni", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "優先順位", "2"));
        checks.add(new ListCheckBean("listYusenjuni", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MIN_SIZE, "優先順位", "1"));
        checks.add(new ListCheckBean("listRouteMei", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "ルート名称"));
        checks.add(new ListCheckBean("listRouteMei", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "ルート名称", "40"));
        List<MessageModuleBean> checkMsgList = listCheckBean.check(params, checks, true);

        return checkMsgList.isEmpty();
    }

    /**
     * 更新履歴を表示処理
     *
     */
    public void rirekiIchiran() {

        // 履歴テーブル検索キー設定
        rirekiSearchKey = new HashMap();

        // 選択されたレコードを取得する
        Map<String, Object> selectRec = mst111Form.getSelectedSearchResult().get(0);

        // FROM拠点コード
        rirekiSearchKey.put("listHatsuchiCd", selectRec.get("listHatsuchiCd"));
        // TO拠点コード
        rirekiSearchKey.put("listChakuchiCd", selectRec.get("listChakuchiCd"));
        // ルート枝番
        rirekiSearchKey.put("listRouteEdaban", selectRec.get("listRouteEdaban"));

        // 履歴タイトル設定
        rirekiSyosaiBean.setListColName(new ArrayList<>(Arrays.asList("バージョン情報", "発地コード", "発地名称",
                "着地コード", "着地地名称", "優先順位", "経由地１コード", "経由地１名称", "経由地２コード",
                "経由地２名称", "経由地３コード", "経由地３名称", "ルート名", "ルート枝番")));

        // 履歴beanの項目物理名設定
        List<String> colValue = new ArrayList<>(Arrays.asList("listRouteDataVersion", "listHatsuchiCd",
                "listHatsuchiMeisho", "listChakuchiCd", "listChakuchiMeisho", "listYusenjuni",
                "listKeiyuchi1Cd", "listKeiyuchi1Meisho", "listKeiyuchi2Cd", "listKeiyuchi2Meisho",
                "listKeiyuchi3Cd", "listKeiyuchi3Meisho", "listRouteMei", "listRouteEdaban"));

        List<String> colAlign = new ArrayList<>(Arrays.asList("center", "left", "left", "left", "left", "right",
                "left", "left", "left", "left", "left", "left", "left", "left"));

        List<RirekiListCol> listCol = new ArrayList<>();

        RirekiListCol col = null;
        for (int i = 0; i < colValue.size(); i++) {
            col = new RirekiListCol();
            col.setColValue(colValue.get(i));
            col.setColAlign(colAlign.get(i));
            listCol.add(col);
        }
        rirekiSyosaiBean.setListCol(listCol);

        // 履歴テーブル検索する
        rirekiSyosaiBean.searchList("2", "MST111_SEARCH_RIREKI", rirekiSearchKey);
    }
 
    /**
     * メニュークリック処理
     *
     * @param menuId メニューID
     * @param nextScreenId 遷移先画面ID
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreenId) {
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移を行う
        url = forward(nextScreenId, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック処理
     *
     * @param nextScreenId 遷移先画面ID
     * @param breadIndex パンくずのインデックス
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreenId, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        url = forward(nextScreenId, null, null, true);
        return url;
    }

    /**
     * ログアウトクリック処理
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authorityConfBean.logout();
    }

    /**
     * 発地コード取得Autocomplete一覧を取得する処理
     * 
     * @param key 検索キー
     * @return Autocompleteリスト
     */    
    public List<String> getAutoCompForHatsuchiCdList(String key) {
        return autoCompleteBean.getStringListByKey(MsCnst.COM_GET_HATSUCHI_ICHIRAN, key);
    }

    /**
     * 着地コード取得Autocomplete一覧を取得する処理
     * 
     * @param key 検索キー
     * @return Autocompleteリスト
     */    
    public List<String> getAutoCompForChakuchiCdList(String key) {
        return autoCompleteBean.getStringListByKey(MsCnst.COM_GET_CHAKUCHI_ICHIRAN, key);
    }

    /**
     * 発地コードによって，経由地1コードAutocomplete一覧を取得する処理
     * 
     * @param key 発地コード
     * @return Autocompleteリスト
     */    
    public List<AutoCompOptionBean> getAutoCompForKeiyuchi1CdList(String key) {

        // 循環DataTable該当行の情報を取得する
        Map<String, Object> rowMap = pageCommonBean.getEvaluateExpression("result");

        // FROM拠点コード
        String fromKyotenCd = "";
        if (rowMap != null && rowMap.get("listHatsuchiCd") != null) {

            fromKyotenCd = rowMap.get("listHatsuchiCd").toString();
        }

        return getAutoCompForKeiyuchi(fromKyotenCd, key);
    }
    
    /**
     * 経由地1コードによって，経由地2コードAutocomplete一覧を取得する処理
     * 
     * @param key 発地コード
     * @return Autocompleteリスト
     */    
    public List<AutoCompOptionBean> getAutoCompForKeiyuchi2CdList(String key) {

        // 循環DataTable該当行の情報を取得する
        Map<String, Object> rowMap = pageCommonBean.getEvaluateExpression("result");

        // FROM拠点コード
        String fromKyotenCd = "";
        if (rowMap != null && rowMap.get("listKeiyuchi1Cd") != null) {

            fromKyotenCd = rowMap.get("listKeiyuchi1Cd").toString();
        }

        return getAutoCompForKeiyuchi(fromKyotenCd, key);
    }
    
    /**
     * 経由地2コードによって，経由地3コードAutocomplete一覧を取得する処理
     * 
     * @param key 発地コード
     * @return Autocompleteリスト
     */    
    public List<AutoCompOptionBean> getAutoCompForKeiyuchi3CdList(String key) {

        // 循環DataTable該当行の情報を取得する
        Map<String, Object> rowMap = pageCommonBean.getEvaluateExpression("result");

        // FROM拠点コード
        String fromKyotenCd = "";
        if (rowMap != null && rowMap.get("listKeiyuchi2Cd") != null) {

            fromKyotenCd = rowMap.get("listKeiyuchi2Cd").toString();
        }

        return getAutoCompForKeiyuchi(fromKyotenCd, key);
    }

    /**
     * FROM拠点コードとTO拠点コードによって，経由地コード取得Autocomplete取得する処理
     * 
     * @param fromKyotenCd FROM拠点コード
     * @param toKyotenCd TO拠点コード
     * @return Autocompleteリスト
     */    
    public List<AutoCompOptionBean> getAutoCompForKeiyuchi(String fromKyotenCd, String toKyotenCd) {

        // ワーク.拠点コード関連表リスト
        List<Map<String,Object>> kanrenhyoList = getKyotenkanOroshineList();

        Map params = new HashMap();

        // システム日付
        params.put("sysDate", DateUtils.format(DateUtils.getSysDate(), StndConsIF.DF_YYYY_MM_DD));

         // ワーク.経由地1リスト
        List<AutoCompOptionBean> keiyuchiList = autoCompleteBean.getValueLabelFromDB(
                MsCnst.COM_GET_ALL_VW_EIGYOSHO, params, null);

        // ワーク.選択肢リスト
        List<AutoCompOptionBean> sentakushiList = new ArrayList<>();

        // 経由地1 != ""の場合
        if (toKyotenCd != null && !"".equals(toKyotenCd)) {

            // ワーク.経由地1リストの件数分繰り返す。
            for (AutoCompOptionBean keiyuchiListBean : keiyuchiList) {

                // 入力パラメータ.経由地2が、経由地2情報.コードに前方一致すること
                // or 入力パラメータ.経由地2が、経由地2情報.名称に前方一致すること
                if (keiyuchiListBean.getValue().equals(toKyotenCd)
                        || keiyuchiListBean.getValue().startsWith(toKyotenCd)
                        || keiyuchiListBean.getLabel().equals(toKyotenCd)
                        || keiyuchiListBean.getLabel().startsWith(toKyotenCd)) {
                    for (Map<String, Object> kanrenhyoMap : kanrenhyoList) {

                        // 経由地2 = ワーク.拠点コード関連表リスト.TO拠点コード
                        // AND 対象行の経由地1コード = ワーク.拠点コード関連表リスト.FROM拠点コード
                        if (kanrenhyoMap.get("komToKyotenCd") != null
                                && kanrenhyoMap.get("komToKyotenCd").toString().equals(keiyuchiListBean.getValue())
                                && kanrenhyoMap.get("komFromKyotenCd") != null
                                && kanrenhyoMap.get("komFromKyotenCd").toString().equals(fromKyotenCd)) {

                            // ワーク.経由地2リストの内容を、ワーク.選択肢リストに追加する。
                            sentakushiList.add(keiyuchiListBean);
                        }
                    }
                }
            }
        } else {

            // ワーク.経由地2リストの内容を、ワーク.選択肢リストに追加する。
            sentakushiList.addAll(keiyuchiList);
        }

        return sentakushiList;
    }

    /**
     * AUTOCOMPLETE選択時コードと名称の設定処理
     * 
     * @param list 明細リスト
     * @param unKey UNIQUE_KEY
     * @param option 選択されたAUTOCOMPLETEデータ
     * @param colCodeName 設定先コード
     * @param colNameName 設定先名称
     */
    public void setListCodeName(List<Map<String, Object>> list,
            String unKey, AutoCompOptionBean option,String colCodeName, String colNameName) {

        for (Map<String, Object>  rec : list) {
            if (unKey.equals(rec.get("UNIQUE_KEY"))) {
                if (option == null) {
                    rec.put(colCodeName, "");
                    rec.put(colNameName, "");
                } else {
                    rec.put(colCodeName, option.getValue());
                    rec.put(colNameName, option.getLabel());
                }
            }
        }
    }

    /**
     * CSVファイルのタイトルを設定する処理
     * 
     * @return 画面タイトル
     */
    public List<CSVDto> getHeader() {

        List<CSVDto> header = new ArrayList<>();
        header.add(new CSVDto("発地コード", "listHatsuchiCd"));
        header.add(new CSVDto("発地名称", "listHatsuchiMeisho"));
        header.add(new CSVDto("着地コード", "listChakuchiCd"));
        header.add(new CSVDto("着地地名称", "listChakuchiMeisho"));
        header.add(new CSVDto("優先順位", "listYusenjuni"));
        header.add(new CSVDto("経由地１コード", "listKeiyuchi1Cd"));
        header.add(new CSVDto("経由地１名称", "listKeiyuchi1Meisho"));
        header.add(new CSVDto("経由地２コード", "listKeiyuchi2Cd"));
        header.add(new CSVDto("経由地２名称", "listKeiyuchi2Meisho"));
        header.add(new CSVDto("経由地３コード", "listKeiyuchi3Cd"));
        header.add(new CSVDto("経由地３名称", "listKeiyuchi3Meisho"));
        header.add(new CSVDto("ルート名", "listRouteMei"));

        // 取得値を返却する
        return header;
    }

    /**
     * 業務削除処理ファンクション領域
     *
     */
    public void delRowsFunc() {

        pageCommonBean.getSelectedDatasList().put(DATA_TABLE_ID, mst111Form.getSelectedSearchResult());
        pageCommonBean.delRows(DATA_TABLE_ID);

    }

    /**
     * 業務削除処理
     *
     * @param recordList レコードリスト
     * @return 正常／異常
     */
    public Boolean delRows(List<Map<String, Object>> recordList) {

        // エラーメッセージを格納する変数の初期化
        msgList = new ArrayList<>();

        // 行選択チェック
        if (recordList.isEmpty()) {
            MessageModuleBean message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0011, "選択");
            msgList.add(message);
            return false;
        }

        // 存在チェック
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(recordList, FUNC_CODE_DELETE_EXIST);

        // エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {

            MessageModuleBean message = messagePropertyBean.createMessageModule(
                    res.getMessages().get(0)[0],
                    res.getMessages().get(0)[1],
                    res.getMessages().get(0)[2],
                    TITLE);
            msgList.add(message);
            messagePropertyBean.messageList(msgList);

            return false;
        }

        // 削除実施
        int status = deleteRouteList(recordList);

        // エラーの場合、処理を終了
        if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            return false;
        }

        // 画面レコード削除
        mst111Form.getSearchResult().removeAll(recordList);

        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, "削除");

        // ログ出力
        LOGGER.info("削除 " + recordList.size() + " 件");

        return true;
    }

    /**
     * ダウンロード理由を記録する処理
     *
     * @param comment 理由コメント
     * @return 正常／異常
     * @throws Exception
     */
    public boolean beforeDown(String comment) throws Exception {

        // ダウンロード理由を記録する
        System.out.println(comment);

        return true;
    }

    /**
     * アップロード
     * 
     * @return 遷移先画面のURL
     */
    public String upload() {

        // flash初期化
        Flash flash = pageCommonBean.getPageParam();

        // flashにアップロード機能コードを設定する
        flash.put("uploadFunctionCd", TITLE);

        // アップロード画面へ遷移
        url = forward(Cnst.SCREEN.UPLOAD_SCREEN.name(), null, Cnst.SCREEN.UPLOAD_SCREEN.name(), false);
        return url;
    }

    /**
     * DBからルートマスタ検索件数を取得する
     * 
     * @param downloadFlg ダウンロードフラグ
     */
    private long getRouteListKensu(boolean downloadFlg) {

        // パラメータを設定する
        Map<String, Object> params = new HashMap<>();

        Mst111Form tempForm = mst111Form;
        if (downloadFlg) {
            tempForm = (Mst111Form)pageCommonBean.getPageInfo(CONST_MST111_FORM);
        }

        // 発地
        if (tempForm.getConHatsuchi() != null) {
            params.put("conHatsuchi", tempForm.getConHatsuchi().getValue());
        } else {
            params.put("conHatsuchi", null);
        }
         // 着地
        if (tempForm.getConChakuchi() != null) {
            params.put("conChakuchi", tempForm.getConChakuchi().getValue());
        } else {
            params.put("conChakuchi", null);
        }

        // デフォルトルート検索
        params.put("conDefaultRouteKensaku", tempForm.getConDefaultRouteKensaku());

        // 削除済のみ
        params.put("conSakujoSumiNomi", tempForm.getConSakujoSumiNomi());

        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH_KENSU);

        return Long.valueOf(res.getJson());
    }

    /**
     * ダウンロード用検索結果取得
     * 
     * @return 検索結果
     */
    private List<Map<String, Object>> getSearchResult() {
        return mst111Form.getSearchResult();
    }

    /**
     * DBからルートマスタ情報を取得する
     * 
     * @param downloadFlg ダウンロードフラグ
     * @return ルートマスタ情報リスト
     */
    private List<Map<String, Object>> getRouteList(boolean downloadFlg) {

        // パラメータ
        Map<String, Object> params = new HashMap<>();

        Mst111Form tempForm = mst111Form;
        if (downloadFlg) {
            tempForm = (Mst111Form)pageCommonBean.getPageInfo(CONST_MST111_FORM);
        }

        // 発地
        if (tempForm.getConHatsuchi() != null) {
            params.put("conHatsuchi", tempForm.getConHatsuchi().getValue());
        } else {
            params.put("conHatsuchi", null);
        }

        // 着地
        if (tempForm.getConChakuchi() != null) {
            params.put("conChakuchi", tempForm.getConChakuchi().getValue());
        } else {
            params.put("conChakuchi", null);
        }

        // デフォルトルート検索
        params.put("conDefaultRouteKensaku", tempForm.getConDefaultRouteKensaku());

        // 削除済のみ
        params.put("conSakujoSumiNomi", tempForm.getConSakujoSumiNomi());

        try {

            // DBをアクセス
            ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH);
            ObjectMapper mapper = new ObjectMapper();
            mst111Form.setSearchResult(mapper.readValue(res.getJson(), List.class));

        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }

        Object listKyotenCObj = null;
        String listKyotenCStr = null;

        for (Map<String, Object> record : mst111Form.getSearchResult()) {

            // 発地
            listKyotenCObj = record.get("listHatsuchiCd");
            listKyotenCStr = "";
            if (listKyotenCObj != null) {
                listKyotenCStr = listKyotenCObj.toString();
            }
            record.put("listHatsuchi",
                    autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_HATSUCHI_ICHIRAN, listKyotenCStr));

            // 着地
            listKyotenCObj = record.get("listChakuchiCd");
            listKyotenCStr = "";
            if (listKyotenCObj != null) {
                listKyotenCStr = listKyotenCObj.toString();
            }
            record.put("listChakuchi",
                    autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_CHAKUCHI_ICHIRAN, listKyotenCStr));
            
            // 経由地１
            listKyotenCObj = record.get("listKeiyuchi1Cd");
            listKyotenCStr = "";
            if (listKyotenCObj != null) {
                listKyotenCStr = listKyotenCObj.toString();
            }
            record.put("listKeiyuchi1",
                    autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_ALL_VW_EIGYOSHO, listKyotenCStr));
            
            // 経由地2
            listKyotenCObj = record.get("listKeiyuchi2Cd");
            listKyotenCStr = "";
            if (listKyotenCObj != null) {
                listKyotenCStr = listKyotenCObj.toString();
            }
            record.put("listKeiyuchi2",
                    autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_ALL_VW_EIGYOSHO, listKyotenCStr));
            
            // 経由地3
            listKyotenCObj = record.get("listKeiyuchi3Cd");
            listKyotenCStr = "";
            if (listKyotenCObj != null) {
                listKyotenCStr = listKyotenCObj.toString();
            }
            record.put("listKeiyuchi3",
                    autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_ALL_VW_EIGYOSHO, listKyotenCStr));

        }

        // らルートマスタ情報を返却する
        return mst111Form.getSearchResult();
    }

    /**
     * DBから拠点コード関連表情報を取得する
     * 
     */
    private List<Map<String, Object>> getKyotenkanOroshineList() {

        List<Map<String, Object>> kyotenkanOroshineListMap = new ArrayList<>();

        try {

            // DBをアクセス
            ServiceInterfaceBean res = pageCommonBean.getDBInfo(new HashMap<>(), FUNC_CODE_SEARCH_KYOTENKANOROSHINE);

            ObjectMapper mapper = new ObjectMapper();
            kyotenkanOroshineListMap = mapper.readValue(res.getJson(), List.class);
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }

        // 拠点コード関連表情報を返却する
        return kyotenkanOroshineListMap;
    }

    /**
     * DBへルートマスタを登録また更新する
     * 
     */
    private int insertUpdateRouteList() {

        // 更新、登録チェック
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(
                mst111Form.getSelectedSearchResult(), FUNC_CODE_INSERT_UPDATE_CHECK);

        // エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            messagePropertyBean.message(
                            res.getMessages().get(0)[0],
                            res.getMessages().get(0)[1],
                            res.getMessages().get(0)[2],
                            res.getTableName());
            return res.getStatusCode();
        }

        // 登録一覧リストと更新一覧リストの内容処理する
        res = pageCommonBean.accsessDBWithList(mst111Form.getSelectedSearchResult(), FUNC_CODE_INSERT_UPDATE);

        return res.getStatusCode();
    }

    /**
     * DBからルートマスタ情報を削除する
     * 
     * @param recordList レコードリスト
     * @return ステータスコード
     */
    private int deleteRouteList(List<Map<String, Object>> recordList) {

        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(recordList, FUNC_CODE_DELETE_ROW);

        return res.getStatusCode();
    }

}