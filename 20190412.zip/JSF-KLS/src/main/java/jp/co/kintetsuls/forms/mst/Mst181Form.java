/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mst;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.annotation.SelectOne;
import lombok.Data;

/**
 *記事マスタフォーム
 * 
 * @author xiehangyu (MBP)
 * @version 2019/3/12 新規作成
 */
@ManagedBean(name = "mst181Form")
@ViewScoped
@Data
public class Mst181Form  implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    /** 営業所コード*/
    @SelectOne(name = "営業所コード")
    private AutoCompOptionBean conEigyoshoCd;
    
    /** 顧客コード*/
    @SelectOne(name = "顧客コード")
    private AutoCompOptionBean conKokyakuCd;
    
    /**
     * 営業所コードDisabled
     */
    private boolean conEigyoshoCdDisabled;
    
    /**
     * 顧客コードDisabled
     */
    private boolean conKokyakuCdDisabled;
    
    /**
     * 検索Visabled
     */
    private boolean btnSearchVisible;

    /**
     * 検索条件変更Visabled
     */
    private boolean btnSearchChangeVisible;
    
    /**
     * 編集Disabled
     */
    private boolean btnEditeDisabled;
    
    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;

     /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;    

     /**
     * 選択された結果
     */
    private List<Map<String, Object>> selectedSearchResult;

}
