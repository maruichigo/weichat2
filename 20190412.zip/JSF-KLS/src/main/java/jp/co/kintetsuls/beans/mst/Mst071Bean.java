/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiListCol;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst071Form;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.service.common.AuthorityService;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 集約コードマスタ画面
 *
 * @author 许博 (MBP)
 * @version 2019/1/28 新規作成
 */
@ManagedBean(name = "mst071")
@ViewScoped
@Data
public class Mst071Bean extends AbstractBean {

    /**
     * タイトル
     */
    private final String TITLE = "集約コードマスタ";

    /**
     * ダウンロードファイル名
     */
    private final static String FILE_NAME = "集約コードマスタ一覧";

    /**
     * 画面URL
     */
    private String url;

    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

    /**
     * 画面フォーム
     */
    @ManagedProperty(value = "#{mst071Form}")
    private Mst071Form mst071Form;

    /**
     * 画面共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * 検索シーケンス処理共通
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;

    /**
     * ファイルダウンロード
     */
    @ManagedProperty(value = "#{fileBean}")
    private FileBean fileBean;

    /**
     * 履歴一覧処理共通
     */
    @ManagedProperty(value = "#{rirekisyosai}")
    private RirekiSyosaiBean rirekiSyosai;

    /**
     * 一覧単項目チェック共通
     */
    @ManagedProperty(value = "#{listCheckBean}")
    private ListCheckBean listCheckBean;

    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(
            new Object() {}.getClass().getEnclosingClass().getName());

    /**
     * スクリーンコード：MST071
     */
    private static final String SC_CD_MST071 = "MST071_SCREEN";

    /**
     * 定数：一覧のデータテーブルID
     */
    private static final String DATA_TABLE_ID = "tablesorter_mst071";

    /**
     * 定数：検索件数取得ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH_KENSU = "mst071-get-shuyakucd-kensu";

    /**
     * 定数：検索ファンクションコード
     */
    private static final String FUNC_CODE_SEARCH = "mst071-get-shuyakucd-detail";

    /**
     * 定数：登録の重複件数取得ファンクションコード
     */
    private static final String FUNC_CODE_INSERT_UPDATE_CHECK = "mst071-insert-update-check";

    /**
     * 定数：削除の存在チェックファンクションコード
     */
    private static final String FUNC_CODE_DELETE_EXIST = "mst071-delete-exist";

    /**
     * 定数：登録更新ファンクションコード
     */
    private static final String FUNC_CODE_INSERT_UPDATE = "mst071-insert-update";

    /**
     * 定数：行削除ファンクションコード
     */
    private static final String FUNC_CODE_DELETE_ROW = "mst071-delete-row-detail";

    /**
     * 定数：画面項目保持キー
     */
    private static final String CONST_MST071_FORM = "mst071Form";

    /**
     * 定数：MasterInfo取得キー
     */
    private static final String CONST_MST071_MASTER = "mst071";

    /**
     * 定数：再検索Button取得キー
     */
    private static final String CONST_MST071_SEARCH = "search_mst071";

    /**
     * 履歴テーブル検索キー
     */
    private Map<String, Object> rirekiSearchKey;

    /**
     * ワーク.メッセージリスト
     */
    List<MessageModuleBean> msgList = new ArrayList<>();

    /**
     * コンストラクタ
     */
    public Mst071Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId メニューID
     * @param prevScreen 遷移元画面ID
     * @param backFlag 戻るフラグ
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {

            // パンくずを追加する
            breadBean.push(TITLE, SCREEN.MST071_SCREEN.name(), this);

            // システムマスタ取得する
            pageCommonBean.getMasterInfo(CONST_MST071_MASTER);

            // 検索シーケンス処理ため初期化する
            searchHelpBean.regSearchHelp(DATA_TABLE_ID,
                    s -> {return getRecordCount(false);},
                    s -> {search(); return null;},
                    s -> {return eigyoshoCheck();});
            searchHelpBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);

            // AutoCompleteを初期化する
            if (authConfBean.isHonsha()) {
                autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO, new AutoCompOptionBean("全て", "all"),
                        StndConsIF.HONSHAKBN_HONSHA);
            } else {
                autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO, new AutoCompOptionBean("全て", "all"),
                        StndConsIF.HONSHAKBN_EIGYOSHO);
            }
            
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_MS_SHUYAKU_CD);

            // 前回の記録をクリアする
            this.clear();
            mst071Form.setSearchResult(null);
            mst071Form.setSearchResultSelectable(null);
            mst071Form.setSelectedSearchResult(null);

            // 戻ってきた場合
            Mst071Form preForm = (Mst071Form) pageCommonBean.getPageInfo(CONST_MST071_FORM);
            if (backFlag && preForm != null) {
                PageCommonBean.simpleCopy(preForm, mst071Form);
                // 再検索を実施する
                pageCommonBean.searchAgain(CONST_MST071_SEARCH);
                // 進んできた場合
            } else {
                Flash flash = pageCommonBean.getPageParam();
                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_MST071_FORM) != null) {
                    // 検索パラメータがある場合、再検索に設定する
                    PageCommonBean.simpleCopy(flash.get(CONST_MST071_FORM), mst071Form);
                    // 再検索を実施する
                    pageCommonBean.searchAgain(CONST_MST071_SEARCH);
                }
            }

            // ダウンロードシーケンスを初期化する
            fileBean.setDataSize(DATA_TABLE_ID, (id -> {return getRecordCount(true);}));

            fileBean.setSearchResult(DATA_TABLE_ID, (id -> {return getSearchResult();}));

            fileBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);

            fileBean.setSubFlg(false);

            fileBean.setTilte(FILE_NAME);

            fileBean.regDownloadFucntion(DATA_TABLE_ID, getHeader(), (id -> {return getShuyakuCdList(true);}));

            fileBean.regBeforeDownFucntion(DATA_TABLE_ID, (comment -> {return beforeDown(comment);}));

            // 行更新また削除するために共通処理へ登録する
            pageCommonBean.regDelFucntion(DATA_TABLE_ID, (dataList -> (this.delRows(dataList))));

            // component初期化とユーザ権限により制御を設定する
            pageCommonBean.setAuthControll(mst071Form, SC_CD_MST071, true);

            // 初期はデータを編集不可にする
            mst071Form.setBtnEditeDisabled(true);
            
            mst071Form.setConHonsha(authConfBean.isHonsha());

        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

    }

    /**
     * カウント処理
     *
     * @param downloadFlg ダウンロードフラグ
     * @return 取得件数
     */
    public Long getRecordCount(boolean downloadFlg) {

        // 前回の記録をクリアする
        Map<String, Object> mapRec = new LinkedHashMap();
        mapRec.put("hideFlg", "hideRow");
        List<Map<String, Object>> mapList = new ArrayList();
        mapList.add(mapRec);
        mst071Form.setSearchResult(mapList);
        mst071Form.setSearchResultSelectable(new ReportListDataModel(mst071Form.getSearchResult()));
        mst071Form.setSelectedSearchResult(null);

        // 検索初期はデータを編集不可にする
        mst071Form.setBtnEditeDisabled(true);

        // レコード件数を取得する
        long recordCount = getShuyakuCdListCount();

        if (!downloadFlg) {
        
        // 検索部のステータスを変更する
        pageCommonBean.setSerchConDisabled(mst071Form);

        // 参照モードにする
        pageCommonBean.setEditFlg(false);

        // 検索条件保存
        pageCommonBean.savePageInfo(CONST_MST071_FORM, mst071Form);
        
        }
        
        return recordCount;
    }

    /**
     * 検索処理
     */
    public void search() {

        // 選択リストを初期化する
        mst071Form.setSelectedSearchResult(new ArrayList<>());
        mst071Form.setSearchResultSelectable(null);

        // 集約コードマスタ検索を行う
        List<Map<String, Object>> recordList = getShuyakuCdList(false);

        fileBean.setDataList(recordList);

        // 取得した値を画面項目にセットする
        pageCommonBean.setDatalist(DATA_TABLE_ID, recordList);
        
        if(recordList != null){
           mst071Form.setSearchResultSelectable(new ReportListDataModel(recordList)); 
        }
 
        // 検索部のステータスを変更する
        pageCommonBean.setSerchConDisabled(mst071Form);

        // 削除済のみのチェック状態より、明細データを編集可／不可にする
        if (mst071Form.getConSakujoNomiKensaku() == null || mst071Form.getConSakujoNomiKensaku().length == 0) {
            // 削除済みデータを編集可にする
            mst071Form.setBtnEditeDisabled(false);
        } else {
            // 削除済みデータを編集不可にする
            mst071Form.setBtnEditeDisabled(true);
        }
        
        // 参照モードにする
        pageCommonBean.setEditFlg(false);
    }

    /**
     * 検索条件変更処理
     */
    public void searchChange() {

        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mst071Form);
    }

    /**
     * クリア処理
     */
    public void clear() {

        // 検索部の条件クリア
        mst071Form.setConShuyakuKbn(null);
        mst071Form.setConShuyakuCd(null);
        mst071Form.setConShuyakuCdMei(null);
        mst071Form.setConEigyoshoCd(null);
        mst071Form.setConSakujoNomiKensaku(null);
        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mst071Form);
        pageCommonBean.setBtnSearchChangeVisible(false);
        pageCommonBean.setBtnSearchVisible(Boolean.TRUE);
    }

    /**
     * 更新処理
     */
    public void update() {

        // エラーメッセージを格納する変数の初期化を行う
        msgList = new ArrayList<>();

        // 行選択チェックを行う
        if (mst071Form.getSelectedSearchResult() == null || mst071Form.getSelectedSearchResult().isEmpty()) {

            MessageModuleBean message = messagePropertyBean.createMessageModule(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0029);
            msgList.add(message);

            messagePropertyBean.messageList(msgList);
            return;
        }

        // 登録一覧リストの初期化を行う
        List<Map<String, Object>> torokuIchiranList = new ArrayList<>();

        // 更新一覧リストの初期化を行う
        List<Map<String, Object>> koshinIchiranList = new ArrayList<>();

        // 登録更新情報設定処理
        // 単項目チェック処理
        if (!checkJsfParamas(mst071Form.getSelectedSearchResult())) {
            return;
        }

        Mst071Form temp = (Mst071Form) pageCommonBean.getPageInfo(CONST_MST071_FORM);
        
        for (Map<String, Object> record : mst071Form.getSelectedSearchResult()) {
            // 集約コードマスタ一覧.カレント行 = 登録対象の場合
            if (record.get(StndConsIF.CONST_ADD_ROW_KEY) != null) {
                // 営業所コードを設定する
                if (mst071Form.getConEigyoshoCd() == null) {
                    record.put("listEigyoshoCd", "DEF");
                } else {
                    record.put("listEigyoshoCd", temp.getConEigyoshoCd().getValue());
                }
                // 集約区分を設定する
                record.put("listShuyakuKbn", temp.getConShuyakuKbn());
                // 登録データワークにデータを設定する
                torokuIchiranList.add(record);
                // 集約コードマスタ一覧.カレント行 ≠ 登録対象の場合
            } else {
                // 更新データワークにデータを設定する
                koshinIchiranList.add(record);
            }
        }

        // 登録・更新処理を行う
        int status = insertUpdateShuyakuList();

        // エラーの場合、処理終了
        if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            return;
        }

        // 再検索を実施する
        pageCommonBean.searchAgain(CONST_MST071_SEARCH);

        // 一覧の配色定義をなくす
        pageCommonBean.resetIchiranColColor(mst071Form.getSelectedSearchResult());

        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0007, "更新");

        // ログ出力を行う
        LOGGER.info("更新 " + mst071Form.getSelectedSearchResult().size() + " 件");
    }

    /**
     * 業務削除処理ファンクション領域
     */
    public void delRowsFunc() {

        pageCommonBean.getSelectedDatasList().put(DATA_TABLE_ID, mst071Form.getSelectedSearchResult());
        pageCommonBean.delRows(DATA_TABLE_ID);

    }

    /**
     * 業務削除処理
     *
     * @param datas
     * @return
     */
    public Boolean delRows(List<Map<String, Object>> datas) {

        // エラーメッセージを格納する変数の初期化する
        msgList = new ArrayList<>();

        // 行選択チェックを行う
        if (datas.isEmpty()) {
            MessageModuleBean message = messagePropertyBean.createMessageModule(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0029);
            msgList.add(message);
            return false;
        }

        // 存在チェックを行う
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(datas, FUNC_CODE_DELETE_EXIST);

        // エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {

            MessageModuleBean message = messagePropertyBean.createMessageModule(res.getMessages().get(0)[0],
                    res.getMessages().get(0)[1]);
            msgList.add(message);
            messagePropertyBean.messageList(msgList);
            return false;
        }

        // 削除処理を行う
        int status = deleteShuyakuCdList(datas);

        // エラーの場合、処理を終了
        if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            return false;
        }

        // 画面レコード削除
        mst071Form.getSearchResult().removeAll(datas);

        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0004, "削除");

        // ログ出力を行う
        LOGGER.info("削除 " + datas.size() + " 件");
        return true;
    }

    /**
     * メニュークリック（処理）
     *
     * @param menuId メニューID
     * @param nextScreenId 遷移先画面ID
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreenId) {
        try {
            // パンくずを削除する
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移を行う
        url = forward(nextScreenId, menuId, null, false);
        return url;
    }

    /**
     * CSVファイルのタイトルを設定する処理
     *
     * @return 画面タイトル
     */
    public List<CSVDto> getHeader() {

        // CSVファイルのタイトルを設定する
        List<CSVDto> header = new ArrayList<>();
        header.add(new CSVDto("集約コード", "listShuyakuCd"));
        header.add(new CSVDto("集約コード名称", "listShuyakuCdMei"));
        header.add(new CSVDto("備考", "listBiko"));
        header.add(new CSVDto("設定数", "listSetteisu"));

        // 取得値を返却する
        return header;
    }

    /**
     * ダウンロード理由を記録する処理
     *
     * @param comment 理由コメント
     * @return 正常／異常
     * @throws Exception
     */
    public boolean beforeDown(String comment) throws Exception {

        // ダウンロード理由を記録する
        System.out.println(comment);

        return true;
    }

    /**
     * 更新履歴を表示処理
     */
    public void rirekiIchiran() {

        //履歴テーブル検索キーを設定する
        rirekiSearchKey = new HashMap();

        // 選択されたレコードを取得する
        Map<String, Object> selectRec = mst071Form.getSelectedSearchResult().get(0);
        //検索パラメータを設定する
        if (mst071Form.getConEigyoshoCd() != null) {
            rirekiSearchKey.put("listEigyoshoCd", mst071Form.getConEigyoshoCd().getValue());
        }
        rirekiSearchKey.put("listShuyakuKbn", mst071Form.getConShuyakuKbn());
        rirekiSearchKey.put("listShuyakuCd", selectRec.get("listShuyakuCd"));

        //履歴タイトルを設定する
        rirekiSyosai.setListColName(
                new ArrayList<>(Arrays.asList("バージョン情報", "集約コード", "集約コード名称", "備考", "設定数")));

        //履歴テーブル物理カラムを設定する
        List<String> colValue = new ArrayList<>(Arrays.asList(
                "listDataVersion", "listShuyakuCd", "listShuyakuCdMei", "listBiko",
                "listSetteisu"
        ));
        List<String> colAlign = new ArrayList<>(Arrays.asList(
                "center", "left", "left", "left", "right"
        ));
        List<RirekiListCol> listCol = new ArrayList<>();
        for (int i = 0; i < colValue.size(); i++) {
            RirekiListCol col = new RirekiListCol();
            col.setColValue(colValue.get(i));
            col.setColAlign(colAlign.get(i));
            listCol.add(col);
        }
        rirekiSyosai.setListCol(listCol);

        // 履歴テーブルを検索する
        rirekiSyosai.searchList("2", "MST071_GET_SHUYAKU_RIREKI", rirekiSearchKey);
    }

    /**
     * パンくずクリック処理
     *
     * @param nextScreenId 遷移先画面ID
     * @param breadIndex パンくずのインデックス
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreenId, int breadIndex) {

        try {
            // パンくずを削除する
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移を行う
        url = forward(nextScreenId, null, null, true);
        return url;
    }

    /**
     * ログアウトクリック処理
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authConfBean.logout();
    }

    /**
     * アップロード
     *
     * @return 遷移先画面のURL
     */
    public String upload() {

        // flash初期化
        Flash flash = pageCommonBean.getPageParam();

        // flashにアップロード機能コードを設定する
        flash.put("uploadFunctionCd", TITLE);

        // アップロードを画面へ遷移
        url = forward(Cnst.SCREEN.UPLOAD_SCREEN.name(), null, Cnst.SCREEN.UPLOAD_SCREEN.name(), false);
        return url;
    }

    /**
     * ダウンロード検査結果取得
     *
     * @return 検索結果
     */
    public List<Map<String, Object>> getSearchResult() {
        return mst071Form.getSearchResult();
    }
    
    /**
     * 営業所区分選択チェック
     *
     * @return チェック結果
     */
    public String eigyoshoCheck() {
        // 集約区分で集約コード（営業所）が選択されている場合
        if ("1".equals(mst071Form.getConShuyakuKbn())) {
            // 営業所コードが選択されているかチェックを行う
            if (mst071Form.getConEigyoshoCd() != null && mst071Form.getConEigyoshoCd().getValue() == "") {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MSTE0045);
                return "FALSE";
            } else if(mst071Form.getConEigyoshoCd() == null){
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MSTE0045);
                return "FALSE";
            }
            // 集約区分で集約コード（営業所）以外が選択されている場合
        } else {
            // 営業所コードが選択されていないかチェックを行う
            if (mst071Form.getConEigyoshoCd() != null && mst071Form.getConEigyoshoCd().getValue() != null) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MSTE0046);
                return "FALSE";
            }
        }
        return "TRUE";
    }

    /**
     * 一覧の単項目チェック処理
     *
     * @param params 画面一覧パラメータ
     * @return チェックの結果
     */
    private boolean checkJsfParamas(List<Map<String, Object>> params) {

        List<ListCheckBean> checks = new ArrayList<>();
        checks.add(new ListCheckBean("listShuyakuCd",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "集約コード", "10"));
        checks.add(new ListCheckBean("listShuyakuCd",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_IS_HALF, "集約コード"));
        checks.add(new ListCheckBean("listShuyakuCdMei",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "集約コード名称", "100"));
        checks.add(new ListCheckBean("listBiko",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "備考", "100"));
        List<MessageModuleBean> checkMsgList = listCheckBean.check(params, checks, true);

        if (!checkMsgList.isEmpty()) {
            return false;
        }
        return true;
    }

    /**
     * DBから集約コードマスタ情報を取得する
     *
     * @param downloadFlg ダウンロードフラグ
     * @return 集約コードマスタ情報取得結果
     */
    private List<Map<String, Object>> getShuyakuCdList(boolean downloadFlg) {

        // パラメータを設定する
        Map<String, Object> params = new HashMap<>();

        // 集約コードが空白以外の場合
        if (mst071Form.getConShuyakuCd() != null) {
            params.put("conShuyakuCd", mst071Form.getConShuyakuCd().getValue());
        }
        // 営業所コードが空白以外の場合
        if (mst071Form.getConEigyoshoCd() != null) {
            params.put("conEigyoshoCd", mst071Form.getConEigyoshoCd().getValue());
        }
        // 集約区分
        params.put("conShuyakuKbn", mst071Form.getConShuyakuKbn());
        // 集約コード名称
        params.put("conShuyakuCdMeisho", mst071Form.getConShuyakuCdMei());
        // 削除のみ検索
        params.put("conSakujoNomiKensaku", mst071Form.getConSakujoNomiKensaku());

        try {
            // DBをアクセスする
            ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH);
            ObjectMapper mapper = new ObjectMapper();
            mst071Form.setSearchResult(mapper.readValue(res.getJson(), List.class));
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }

        // 集約コードマスタ情報を返却する
        return mst071Form.getSearchResult();
    }

    /**
     * DBから集約コードマスタ検索件数を取得する処理
     *
     * @return 検索件数取得結果
     */
    private Long getShuyakuCdListCount() {

        // パラメータを設定する
        Map<String, Object> params = new HashMap<>();

        // 集約コードが空白以外の場合
        if (mst071Form.getConShuyakuCd() != null) {
            params.put("conShuyakuCd", mst071Form.getConShuyakuCd().getValue());
        }
        // 営業所コードが空白以外の場合
        if (mst071Form.getConEigyoshoCd() != null) {
            params.put("conEigyoshoCd", mst071Form.getConEigyoshoCd().getValue());
        }
        // 集約区分
        params.put("conShuyakuKbn", mst071Form.getConShuyakuKbn());
        // 集約コード名称
        params.put("conShuyakuCdMeisho", mst071Form.getConShuyakuCdMei());
        // 削除のみ検索
        params.put("conSakujoNomiKensaku", mst071Form.getConSakujoNomiKensaku());

        // DBをアクセスする
        ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH_KENSU);

        // 検索件数を返却する
        return Long.valueOf(res.getJson());
    }

    /**
     * DBへ集約コードマスタを登録また更新する処理
     *
     * @return 登録また更新状態
     */
    private int insertUpdateShuyakuList() {

        // 重複、存在チェックを行う
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(
                mst071Form.getSelectedSearchResult(), FUNC_CODE_INSERT_UPDATE_CHECK);

        // エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            messagePropertyBean.message(res.getMessages().get(0)[0],
                    res.getMessages().get(0)[1]);

            return res.getStatusCode();
        }

        // 登録一覧リストと更新一覧リストの内容を処理する
        res = pageCommonBean.accsessDBWithList(mst071Form.getSelectedSearchResult(), FUNC_CODE_INSERT_UPDATE);

        // ステータスコードを返却する
        return res.getStatusCode();
    }

    /**
     * DBから集約コードマスタ情報を削除する処理
     *
     * @param datas レコードリスト
     * @return ステータスコード
     */
    private int deleteShuyakuCdList(List<Map<String, Object>> datas) {

        // DBをアクセスする
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(datas, FUNC_CODE_DELETE_ROW);

        // ステータスコードを返却する
        return res.getStatusCode();
    }

    
}
