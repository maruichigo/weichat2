/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.stc;

import java.io.Serializable;

/**
 *
 * @author liuchengjiang
 */
public class Document implements Serializable{
    /** 仕入区分 */
    private String shireKbn;
    /** 経費負担額合計 */
    private String kinCount;
    /** うち非課税額合計 */
    private String kakusaiCount;
    /** 消費税（外税）合計 */
    private String shohiTaxCount;
    /** 仕入額合計 */
    private String shiregakuCount;

    public Document(String shireKbn, String kinCount, String kakusaiCount, String shohiTaxCount, String shiregakuCount) {
        this.shireKbn = shireKbn;
        this.kinCount = kinCount;
        this.kakusaiCount = kakusaiCount;
        this.shohiTaxCount = shohiTaxCount;
        this.shiregakuCount = shiregakuCount;
    }
    public String getShireKbn() {
        return shireKbn;
    }

    public void setShireKbn(String shireKbn) {
        this.shireKbn = shireKbn;
    }

    public String getKinCount() {
        return kinCount;
    }

    public void setKinCount(String kinCount) {
        this.kinCount = kinCount;
    }

    public String getKakusaiCount() {
        return kakusaiCount;
    }

    public void setKakusaiCount(String kakusaiCount) {
        this.kakusaiCount = kakusaiCount;
    }

    public String getShohiTaxCount() {
        return shohiTaxCount;
    }

    public void setShohiTaxCount(String shohiTaxCount) {
        this.shohiTaxCount = shohiTaxCount;
    }

    public String getShiregakuCount() {
        return shiregakuCount;
    }

    public void setShiregakuCount(String shiregakuCount) {
        this.shiregakuCount = shiregakuCount;
    }
    
}
