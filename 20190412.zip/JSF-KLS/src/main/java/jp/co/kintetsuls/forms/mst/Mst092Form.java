/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mst;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.annotation.NotNull;
import jp.co.kintetsuls.beans.common.annotation.DateCheck;
import lombok.Data;

/**
 * 仕入予定詳細フォーム
 *
 * @author 廖鈺 (MBP)
 * @version 2019/2/02 新規作成
 */
@ManagedBean(name = "mst092Form")
@ViewScoped
@Data
public class Mst092Form implements  Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 営業所コード value
     */
    private AutoCompOptionBean conEigyoshoCd;
    
    /**
     * 営業所コード Disabled
     */
    private boolean conEigyoshoCdDisabled;
    
    /**
     * 仕入先コード value
     */
    private AutoCompOptionBean conShiiresakiCd;

    /**
     * 仕入先コード（Axis) Disabled
     */
    private boolean conShiiresakiCdDisabled;
    
    /**
     *  仕入区分 value 
     */
    private AutoCompOptionBean conShiireKbn;
    
    /**
     * 仕入区分 Disabled
     */
    private boolean conShiireKbnDisabled;
    
    /**
     * 適用開始日
     */
    private String conTekiyoKaishibi;
   
    /**
     * 適用開始日 Disabled
     */
    private boolean conTekiyoKaishibiDisabled;
    
    /**
     * 適用開始日（退避用）
     */
    private Date conTekiyoKaishibiTaihi;
    
    /**
     * 適用名
     */
    private String conTekiyoMei;
    
    /**
     * 適用名 Disabled
     */
    private boolean conTekiyoMeiDisabled;
    
    /**
     * 適用終了
     */
    private String[] conTekiyoShuryo;
    
    /**
     * 適用終了 Disabled
     */
    private boolean conTekiyoShuryoDisabled;
    
    /**
     * 単位
     */
    private String conTani;
    
    /**
     * 単位 Disabled
     */
    private boolean conTaniDisabled;
    
    /**
     * 単価
     */
    private String conTanka;
    
    /**
     * 単価 Disabled
     */
    private boolean conTankaDisabled;
    
    /**
     * 検索Visabled
     */
    private boolean btnSearchVisible;
    
    /**
     * 編集Disabled
     */
    private boolean btnEditeDisabled;

    /**
     * 検索条件変更Visabled
     */
    private boolean btnSearchChangeVisible;

    /***
     * 件数
     */
    private int kanSu;
    
    /**
     * リスト曜日別仕入額_月
     */
    private BigDecimal listYobibetuShiiregakuGetuyo = new BigDecimal("0");
    
    /**
     * リスト曜日別仕入額_火
     */
    private BigDecimal listYobibetuShiiregakuKayo = new BigDecimal("0");
    
    /**
     * リスト曜日別仕入額_水
     */
    private BigDecimal listYobibetuShiiregakuSuiyo = new BigDecimal("0");
    
    /**
     * リスト曜日別仕入額_木
     */
    private BigDecimal listYobibetuShiiregakuMokuyo = new BigDecimal("0");
    
    /**
     * リスト曜日別仕入額_金
     */
    private BigDecimal listYobibetuShiiregakuKinyo = new BigDecimal("0");
    
    /**
     * リスト曜日別仕入額_土
     */
    private BigDecimal listYobibetuShiiregakuDoyo = new BigDecimal("0");
    
    /**
     * リスト曜日別仕入額_日祝
     */
    private BigDecimal listYobibetuShiiregakuNichiSuku = new BigDecimal("0");
    
    /**
     * リスト適用終了日
     */
    private String listTekiyoShuryobi;
    
    /**
     * リスト仕入予定データバージョン
     */
    private String listShiireYoteiDataVersion;
    
    /**
     * 履歴テーブル検索キー
     */
    private Map<String, Object> rirekiSearchKey;
    
    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;
    
     /**
     * 検索結果仕入予定マスタ一覧選択できる
     */
    private ReportListDataModel searchResultMsShiireYotel;

    /**
     * 検索結果仕入予定明細マスタ一覧選択できる
     */
    private ReportListDataModel searchResultMsShiireYotelMeisai;
    
    /**
     * 選択された結果
     */
    private List<Map<String, String>> selectedSearchResult;
    
    /**
     * 計算選択された結果
     */
    private Map<String, String> calSearchResult;
    
    /**
     * 税率結果
     */
    private Map<String, String> zeiRitsuResult;
    
    /**
     * 仕入予定マスタテーブルVisabled
     */
    private Boolean shiireYoteiRendered = false;
    
    /**
     * 仕入予定明細テーブルVisabled
     */
    private Boolean shiireYoteiMeisaiRendered = false;

}
