package jp.co.kintetsuls.beans.common;

import java.io.FileInputStream;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.List;
import java.util.Properties;
import javax.annotation.PostConstruct;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.faces.application.FacesMessage;
import jp.co.kintetsuls.service.general.property.ExternalServiceProperty;

@ManagedBean(name = "messagePropertyBean", eager = true)
@ApplicationScoped
public class MessagePropertyBean {

    public static final String IP_HOME = "conf-directory";

    // 定数：INFO(SEVERITY_INFO).
    public static final String SEVERITY_INFO = "INFO";

    // 定数：WARN(SEVERITY_WARN).
    public static final String SEVERITY_WARN = "WARN";

    // 定数：ERROR(SEVERITY_ERROR).
    public static final String SEVERITY_ERROR = "ERROR";

    // 定数：FATAL(SEVERITY_FATAL).
    public static final String SEVERITY_FATAL = "FATAL";

    private static Properties prop = null;

    @PostConstruct
    public void init() {
        String homeDir = FacesContext.getCurrentInstance().getExternalContext().getInitParameter(IP_HOME);
        String configFile = homeDir + "/message_JP.properties";

        prop = new Properties();
        try {
            prop.load(new FileInputStream(configFile));
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }
    }

    public String getProperty(String key) {
        return prop.getProperty(key);
    }

    public String getProperty(String key, Object... args) {
        return MessageFormat.format(prop.getProperty(key), args);
    }

    /**
     * 1行メッセージを格納する。置換文字なし
     *
     * @param level INFO,WARN,ERROR,FATAL INFO(通常)/WARN(注意)/ERROR(警告)/FATAL(異常)
     * @param summary 協調メッセージ
     */
    public void message(String level, String summary) {
        FacesContext context = FacesContext.getCurrentInstance();
        context.getExternalContext().getFlash().setKeepMessages(true);
        addMessage(context, getFaceMessage(level, summary, this.getProperty(summary)));
    }

    /**
     * 1行メッセージを格納する。置換文字あり
     *
     * @param level INFO,WARN,ERROR,FATAL INFO(通常)/WARN(注意)/ERROR(警告)/FATAL(異常)
     * @param summary 協調メッセージ
     * @param args 置換文字内容
     */
    public void message(String level, String summary, Object... args) {
        FacesContext context = FacesContext.getCurrentInstance();
        context.getExternalContext().getFlash().setKeepMessages(true);
        addMessage(context, getFaceMessage(level, summary, this.getProperty(summary, args)));
    }

    /**
     * 1行メッセージを格納する。置換文字なし
     *
     * @param level INFO,WARN,ERROR,FATAL INFO(通常)/WARN(注意)/ERROR(警告)/FATAL(異常)
     * @param summary 協調メッセージ
     * @param msgAreaId 出力したいアリア指定
     */
    public void messageToArea(String level, String summary,String msgAreaId) {
        FacesContext context = FacesContext.getCurrentInstance();
        context.getExternalContext().getFlash().setKeepMessages(true);
        addMessage(context, getFaceMessage(level, summary, this.getProperty(summary)),msgAreaId);
    }

    /**
     * 1行メッセージを格納する。置換文字あり
     *
     * @param level INFO,WARN,ERROR,FATAL INFO(通常)/WARN(注意)/ERROR(警告)/FATAL(異常)
     * @param summary 協調メッセージ
     * @param msgAreaId 出力したいアリア指定
     * @param args 置換文字内容
     */
    public void messageToArea(String level, String summary,String msgAreaId, Object... args) {
        FacesContext context = FacesContext.getCurrentInstance();
        context.getExternalContext().getFlash().setKeepMessages(true);
        addMessage(context, getFaceMessage(level, summary, this.getProperty(summary, args)),msgAreaId);
    }    
    
    
    /**
     * メッセージを格納する。置換文字あり
     *
     * @param level INFO,WARN,ERROR,FATAL INFO(通常)/WARN(注意)/ERROR(警告)/FATAL(異常)
     * @param summary 協調メッセージ
     * @param text 置換文字内容
     */
    public void messageForList(String level, String summary, String text) {
        FacesContext context = FacesContext.getCurrentInstance();
        context.getExternalContext().getFlash().setKeepMessages(true);
        addMessage(context, getFaceMessage(level, summary, text));
    }    
    
    /**
     * メッセージを作成する。置換文字なし
     *
     * @param level INFO,WARN,ERROR,FATAL INFO(通常)/WARN(注意)/ERROR(警告)/FATAL(異常)
     * @param summary 協調メッセージ
     * @return MessageModuleBean
     */
    public MessageModuleBean createMessageModule(String level, String summary) {
        MessageModuleBean message = new MessageModuleBean();
        message.setSeverity(level);
        message.setMessageId(summary);
        return message;
    }

    /**
     * メッセージを作成する。置換文字あり
     *
     * @param level INFO,WARN,ERROR,FATAL INFO(通常)/WARN(注意)/ERROR(警告)/FATAL(異常)
     * @param summary 協調メッセージ
     * @param args 置換文字内容
     * @return MessageModuleBean
     */
    public MessageModuleBean createMessageModule(String level, String summary, Object... args) {
        MessageModuleBean message = new MessageModuleBean();
        message.setSeverity(level);
        message.setMessageId(summary);
        message.setText(this.getProperty(summary, args));
        return message;
    }

    /**
     * 複数メッセージを格納する。
     *
     * @param messageList メッセージリスト
     */
    public void messageList(List<MessageModuleBean> messageList) {

        if (messageList != null && messageList.size() > 0) {
            for (MessageModuleBean message : messageList) {
                if (message.getText() == null) {
                    this.message(message.getSeverity(), message.getMessageId());
                } else {
                    this.messageForList(message.getSeverity(), message.getMessageId(), message.getText());
                }
            }
        }
    }

    /**
     * facesMessageを生成
     *
     * @param level INFO,WARN,ERROR,FATAL
     * @param summary 協調メッセージ
     * @param message メッセージ内容
     * @return
     */
    private static FacesMessage getFaceMessage(String level, String summary, String message) {
        FacesMessage.Severity severity = getMsgIcon(level);
        return new FacesMessage(severity, summary, message);
    }

    /**
     * メッセージleveliconを返却
     *
     * @param level INFO,WARN,ERROR,FATAL INFO(通常)/WARN(注意)/ERROR(警告)/FATAL(異常)
     * @return Severity
     */
    public static FacesMessage.Severity getMsgIcon(String level) {
        switch (level) {
            case "通常":
            case SEVERITY_INFO:
                return FacesMessage.SEVERITY_INFO;
            case "注意":
            case SEVERITY_WARN:
                return FacesMessage.SEVERITY_WARN;
            case "警告":
            case SEVERITY_ERROR:
                return FacesMessage.SEVERITY_ERROR;
            case "異常":
            case SEVERITY_FATAL:
                return FacesMessage.SEVERITY_FATAL;
            default:
                return FacesMessage.SEVERITY_INFO;
        }
    }

    /**
     * メッセージレベルによって処理を出力先を決定
     *
     * @param context
     * @param fmsg
     */
    private static void addMessage(FacesContext context, FacesMessage fmsg) {
        if (fmsg.getSeverity() == FacesMessage.SEVERITY_INFO) {
            //growl!
            context.addMessage("growl", fmsg);
        } else {
            //message!
            context.addMessage("message", fmsg);
        }
    }

    /**
     * メッセージレベルによって処理をユーザ設定で出力先を決定
     *
     * @param context
     * @param fmsg
     */
    private static void addMessage(FacesContext context, FacesMessage fmsg, String msgAreaId) {
        context.addMessage(msgAreaId, fmsg);
    }
    
    /**
     * Properties情報を取得する
     * 
     * @param key 取得キー
     * @return Properties情報
     */
    public String getProperties(String key) {
        return ExternalServiceProperty.getInstance().getProperty(key);
    }
    
}
