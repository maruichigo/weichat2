/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.unc;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.AutoCompleteBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.cnst.SysMsg;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.file.CsvBuilder;
import jp.co.kintetsuls.file.FileDto;
import jp.co.kintetsuls.forms.mst.Mst501Form;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.kintetsuls.service.general.property.ExternalServiceProperty;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 仕向地名マスタ画面
 *
 * @author MaLei (MBP)
 * @version 2019/1/24 新規作成
 */
@javax.faces.bean.ManagedBean(name = "unc041")
@ViewScoped
@Data
public class Unc041Bean extends AbstractBean {

    private final String strTitle = "入金入力訂正画面";
    private String url;     // URL

    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    @ManagedProperty(value = "#{autoComplete}")
    private AutoCompleteBean autoCompleteBean;

    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    @ManagedProperty(value = "#{fileBean}")
    private FileBean fileBean;

    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messageProperty;

    @ManagedProperty(value = "#{mst501Form}")
    private Mst501Form form;

    private static final Logger logger = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    private RestfullService rest;

    /**
     * メッセージID：COME0029.
     */
    private static final String MSG_ID_COME0029 = "COME0029";

    /**
     * 定数：検索FUNC_CODE.
     */
    private static final String SEARCH_FUNC_CODE = "mst501-get-shimuke-detail";

    /**
     * 定数：SAKUJO_FLG.
     */
    private static final String CONST_SAKUJO_FLG = "SAKUJO_FLG";

    /**
     * 定数：0文字列.
     */
    private static final String CONST_ZERO_STRING = "0";

    /**
     * 定数：COM_GET_MS_TODOFUKEN.
     */
    private static final String CONST_COM_GET_MS_TODOFUKEN = "COM_GET_MS_TODOFUKEN";

    @Getter
    @Setter
    private List<Unc051Model> searchResult;

    @Getter
    @Setter
    private Unc051Model selectSearchResult;

    /**
     * コンストラクタ
     */
    public Unc041Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId
     * @param prevScreen
     * @param backFlag
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            // AutoCompleteを初期化する
            Map params = new HashMap();
            params.put(CONST_SAKUJO_FLG, CONST_ZERO_STRING);
            autoCompleteBean.initAutoComplete(CONST_COM_GET_MS_TODOFUKEN, params);
//            fileBean.regDownloadFucntion("tablesorter_mst501", (id -> {
//                return getDownloadFilePath(id);
//            }));

            // パンくず追加
            breadBean.push("仕向地名マスタ一覧画面", SCREEN.MST501_SCREEN.name(), this);
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }
    }

    /**
     * 検索処理
     *
     */
    public void search() {

        // 仕向地名マスタ検索し、取得した値を画面項目にセット
        List<Unc051Model> res = getShimukeList();
    }

    /**
     * 更新処理
     *
     */
    public void update() {

        // 入力チェック
        if (form.getSelectedSearchResult().isEmpty()) {
            messageProperty.message(MessagePropertyBean.SEVERITY_ERROR, MSG_ID_COME0029);
        }

    }

    /**
     * DBから仕向地名マスタ情報を取得する
     */
    private List<Unc051Model> getShimukeList() {

        List<Unc051Model> list = new ArrayList<>();
        Unc051Model model1 = new Unc051Model();
        SimpleDateFormat smf = new SimpleDateFormat("YYYY/MM/DD");
        model1.setEigyoshoCd("000001");
        model1.setEigyoshoName("東京営業所");
        model1.setSeikyusakiCd("00001");
        model1.setSeikyusakiName("請求先名A");
        model1.setSeikyushoNo("100003-001");
        model1.setShiDate("2017/09/30");
        model1.setSeikyuKin(new BigDecimal("100000"));
        model1.setNyuKin(BigDecimal.ZERO);
        model1.setZankoukuKin(new BigDecimal("100000"));
        model1.setNyuKinDate("2017/10/05");
        model1.setNyuKinhou("集金");
        model1.setJyoukenGai("0");
        model1.setLastAuther("山田 太郎");
        list.add(model1);

        Unc051Model model2 = new Unc051Model();
        model2.setEigyoshoCd("000001");
        model2.setEigyoshoName("東京営業所");
        model2.setSeikyusakiCd("00001");
        model2.setSeikyusakiName("請求先名A");
        model2.setSeikyushoNo("100002-001");
        model2.setShiDate("2017/08/31");
        model2.setSeikyuKin(new BigDecimal("200000"));
        model2.setNyuKin(new BigDecimal("200000"));
        model2.setZankoukuKin(BigDecimal.ZERO);
        model2.setNyuKinDate("2017/09/05");
        model2.setNyuKinhou("集金");
        model2.setJyoukenGai("0");
        model2.setLastAuther("山田 太郎");
        list.add(model2);

        Unc051Model model3 = new Unc051Model();
        model3.setEigyoshoCd("000001");
        model3.setEigyoshoName("東京営業所");
        model3.setSeikyusakiCd("00002");
        model3.setSeikyusakiName("請求先名A");
        model3.setSeikyushoNo("100001-001");
        model3.setShiDate("2017/07/31");
        model3.setSeikyuKin(new BigDecimal("300000"));
        model3.setNyuKin(new BigDecimal("300000"));
        model3.setZankoukuKin(BigDecimal.ZERO);
        model3.setNyuKinDate("2017/08/05");
        model3.setNyuKinhou("集金");
        model3.setJyoukenGai("0");
        model3.setLastAuther("山田 太郎");
        list.add(model3);

        Unc051Model model4 = new Unc051Model();
        model4.setEigyoshoCd("000001");
        model4.setEigyoshoName("東京営業所");
        model4.setSeikyusakiCd("00002");
        model4.setSeikyusakiName("請求先名D");
        model4.setSeikyushoNo("100004-001");
        model4.setShiDate("2017/09/31");
        model4.setSeikyuKin(new BigDecimal("400000"));
        model4.setNyuKin(new BigDecimal("400000"));
        model4.setZankoukuKin(BigDecimal.ZERO);
        model4.setNyuKinDate("2017/08/05");
        model4.setNyuKinhou("集金");
        model4.setJyoukenGai("0");
        model4.setLastAuther("山田 太郎");
        list.add(model4);

        Unc051Model model5 = new Unc051Model();
        model5.setEigyoshoCd("000001");
        model5.setEigyoshoName("東京営業所");
        model5.setSeikyusakiCd("00003");
        model5.setSeikyusakiName("請求先名E");
        model5.setSeikyushoNo("100005-001");
        model5.setShiDate("2017/09/20");
        model5.setSeikyuKin(new BigDecimal("500000"));
        model5.setNyuKin(new BigDecimal("500000"));
        model5.setZankoukuKin(BigDecimal.ZERO);
        model5.setNyuKinDate("2017/08/05");
        model5.setNyuKinhou("振込");
        model5.setJyoukenGai("1");
        model5.setLastAuther("山田 太郎");
        list.add(model5);

        Unc051Model model6 = new Unc051Model();
        model6.setEigyoshoCd("000001");
        model6.setEigyoshoName("東京営業所");
        model6.setSeikyusakiCd("00003");
        model6.setSeikyusakiName("請求先名F");
        model6.setSeikyushoNo("100006-001");
        model6.setShiDate("2017/09/20");
        model6.setSeikyuKin(new BigDecimal("500000"));
        model6.setNyuKin(new BigDecimal("500000"));
        model6.setZankoukuKin(BigDecimal.ZERO);
        model6.setNyuKinDate("2017/08/05");
        model6.setNyuKinhou("振込");
        model6.setJyoukenGai("1");
        model6.setLastAuther("山田 太郎");
        list.add(model6);
        this.searchResult = list;
        return this.searchResult;
    }

    /**
     * メニュークリック（処理）
     *
     * @param menuId
     * @param nextScreen
     * @return
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }

        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック（処理）
     *
     * @return
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }
        url = forward(nextScreen, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return
     */
    @Override
    public String logoutClick() {
        return authConfBean.logout();
    }

    /**
     * 画面遷移処理（顧客マスタメンテナンス画面へ）
     *
     * @return
     * @throws java.lang.IllegalAccessException
     * @throws java.lang.reflect.InvocationTargetException
     */
    public String buttonClick() throws IllegalAccessException, InvocationTargetException {

        // 画面遷移
        url = forward(SCREEN.CUS012_SCREEN.name(), null, SCREEN.CUS011_SCREEN.name(), false);
        return url;
    }

    /**
     * @return the strTitle
     */
    public String getStrTitle() {
        return strTitle;
    }

    /**
     * CSV作成ファイル
     *
     * @return
     */
//    @Override
//    public FileDto getDownloadFilePath(String id) throws Exception {
//        List<CSVDto> header = new ArrayList<>();
//        header.add(new CSVDto("都道府県コード", "listTodofukenCd"));
//
//        header.add(new CSVDto("都道府県名", "listTodofukenMei"));
//        header.add(new CSVDto("仕向地名コード", "listShimukeChiMeiCd"));
//        header.add(new CSVDto("仕向地名", "listShimukeChiMei"));
//        header.add(new CSVDto("備考", "listBiko"));
//
//        List<Map<String, Object>> body = getShimukeList();
//
//        String saveFile = CsvBuilder.saveCsvInfofromMap(header, body);
//        return new FileDto("", CsvBuilder.FILE_STORE_FOLDER_TEMP + StndConsIF.FS + saveFile);
//
//    }
}
