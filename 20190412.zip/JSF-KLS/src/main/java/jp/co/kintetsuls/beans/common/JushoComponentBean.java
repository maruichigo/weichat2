package jp.co.kintetsuls.beans.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.cnst.SysMsg;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.service.general.RestfullService;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 住所用コンポーネントBean
 *
 * @author yang.x (MBP)
 * @version 2019/2/27 新規作成
 */
@ManagedBean(name = "jushoComponent")
@ViewScoped
@Data
public class JushoComponentBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private static final Logger logger = LogManager.getLogger(
            new Object() {}.getClass().getEnclosingClass().getName());

    private RestfullService rest;

    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messageProperty;

    // 部品パラメータ・Bean属性表示フラグ
    private boolean isParam;

    private Map<String, Object> searchResult;

    // ワーク.メッセージリスト
    List<MessageModuleBean> msgList = new ArrayList<>();

    // 定数：JushoComponentを取得XML指定.
    private static final String COMMON_GET_SHINJUSHO_INFO = "COMMON_GET_SHINJUSHO_INFO";

    // 住所のmaxlength（40バイト）
    private static final int JUSHO_MAX_LENGTH = 40;

    // 日本語漢字エンコード
    private static final String KANJI_CODE = "[\u2E80-\u2EF3|\u2F00-\u2FD5|\u3400-\u3FFF|\u4000-\u4DB5|\u4E00-\u9FFF|\uF900-\uFA6D]+";

    /**
     * コンストラクタ
     */
    public JushoComponentBean() {
        isParam = true;
        searchResult = new HashMap();
    }

    public boolean isIsParam() {
        return isParam;
    }

    public void setIsParam(boolean isParam) {
        this.isParam = isParam;
    }

    /**
     * 新JISコードに対する住所情報を取得する
     *
     * @param jisCd 新JISコード
     * @param tekiyoKaishibi 適用開始日
     * @param jusho1 住所1
     * @param jusho2 住所2
     * @param jusho3 住所3
     * @param jusho4 住所4
     * @param jisCdId JISコードid
     * @return 新JISコードに対する住所情報
     */
    public void getShinJushoInfo(String jisCd, String tekiyoKaishibi, String jusho1, String jusho2, String jusho3, String jusho4, String jisCdId) {
        // 新JISコードが5桁以外の場合、処理しない
        if (jisCd == null || jisCd.length() != 5) {
            return;
        }
        ServiceInterfaceBean req = new ServiceInterfaceBean();

        req.setFunctionCode(COMMON_GET_SHINJUSHO_INFO);

        // 検索条件設定
        Map<String, Object> params = new HashMap<>();
        params.put("jisCd", jisCd);
        params.put("tekiyoKaishibi", tekiyoKaishibi);
        String requestData = JSONUtil.makeJSONString(params);
        req.setJson(requestData);

        // DB接続
        rest = RestfullService.getInstance();
        ServiceInterfaceBean res = null;
        try {
            res = rest.request(req);
        } catch (Exception ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
            return;
        }

        if (res == null || res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return;
        }

        Map<String, Object> result = new HashMap();
        try {
            ObjectMapper mapper = new ObjectMapper();
            // 新JISコードに対する住所情報を取得する
            List<Map<String, Object>> findResult = mapper.readValue(res.getJson(), List.class);

            // 取得した件数が0件の場合、処理しない
            if (findResult.isEmpty()) {
                return;
            }

            String shinJusho = (String) findResult.get(0).get("JUSHO");

            // 新住所情報で旧住所情報を置き換える
            if (!shinJusho.isEmpty()) {
                // 旧住所1の漢字部分をJISコードマスタに登録されている新JISの漢字に置き換える
                String shinJusho1 = shinJusho + getKanjiIgaiJusho(jusho1);
                String clearJusho1 = getClearJusho(shinJusho1);
                // メッセージエリアにリアされた文字列を表示する
                if (!clearJusho1.isEmpty()) {
                    result.put("jusho1", shinJusho1.substring(0, shinJusho1.length() - clearJusho1.length()));
                    MessageModuleBean message = messageProperty.createMessageModule(MessagePropertyBean.SEVERITY_WARN, "COMI0015", clearJusho1); // TODO メッセージID確認中 QA16502
                    msgList.add(message);

                } else {
                    result.put("jusho1", shinJusho1);
                }

                // 置き換える際に新JISの漢字が40バイトを超える場合、40バイトを超えた分は、住所１の旧住所以降の文字列も含め、住所２の先頭に挿入する。
                if (!clearJusho1.isEmpty()) {
                    String shinJusho2 = clearJusho1 + jusho2;
                    String clearJusho2 = getClearJusho(shinJusho2);
                    // メッセージエリアにリアされた文字列を表示する
                    if (!clearJusho1.isEmpty()) {
                        result.put("jusho2", shinJusho2.substring(0, shinJusho2.length() - clearJusho2.length()));
                        MessageModuleBean message = messageProperty.createMessageModule(MessagePropertyBean.SEVERITY_WARN, "COMI0016", clearJusho2); // TODO メッセージID確認中 QA16502
                        msgList.add(message);
                    }
                } else {
                    result.put("jusho2", jusho2);
                }

            } else {
                result.put("jusho1", jusho1);
                result.put("jusho2", jusho2);
            }
            result.put("jisCd", autoCompleteViewBean.initAddr(jisCdId, jisCd));
            result.put("jusho3", jusho3);
            result.put("jusho4", jusho4);

            // 新JISコードの住所情報を設定する
            result.put("shinJisCd", (String) findResult.get(0).get("SHINJISCD"));
            result.put("kyuJushoFlg", (String) findResult.get(0).get("KYUJUSHOFLG"));
            result.put("shiyoFukaFlg", (String) findResult.get(0).get("SHIYOFUKAFLG"));

            // 実行結果設定
            this.searchResult = result;
            isParam = false;
        } catch (IOException ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
        }
    }

    /**
     * 住所の漢字部分以外の住所情報を取得する
     *
     * @param jusho 住所
     * @return 漢字部分以外の住所情報
     */
    private String getKanjiIgaiJusho(String jusho) {
        String kanjiIgaiJusho = jusho.replaceFirst(KANJI_CODE, "");;
        return kanjiIgaiJusho;
    }

    /**
     * 40バイトを超える分の住所情報を取得する
     *
     * @param jusho 住所
     * @return 40バイトを超える分の住所情報
     */
    private String getClearJusho(String jusho) {
        byte[] jushoByte = jusho.getBytes();
        String result = "";
        if (jushoByte.length <= JUSHO_MAX_LENGTH) {
            return result;
        }
        try {
            byte[] shinJushoByte = new byte[jushoByte.length - JUSHO_MAX_LENGTH];
            for (int i = 0, j = JUSHO_MAX_LENGTH; j < jushoByte.length; i++, j++) {
                shinJushoByte[i] = jushoByte[j];
            }
            result = new String(shinJushoByte, "SJIS");
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }
        return result;
    }
}
