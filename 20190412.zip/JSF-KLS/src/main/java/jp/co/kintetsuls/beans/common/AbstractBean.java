/*
 * Copyright (C) 2014 MBP Corporation All Rights Reserved .
 */
package jp.co.kintetsuls.beans.common;

import java.io.Serializable;
import java.util.ArrayList;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import jp.co.kintetsuls.exception.ApplicationException;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.exception.ValidateException;
import jp.co.kintetsuls.file.FileDto;
import jp.co.kintetsuls.validation.ValErrorDto;
import jp.co.sharedsys.beans.base.BaseBean;

/**
 * Controllerの基本タイプ
 *
 * @author
 */
public abstract class AbstractBean  extends BaseBean implements Serializable {

    public static FacesContext facesContext = FacesContext.getCurrentInstance();
    /**
     * エラーメッセージリスト
     */
    private ArrayList<ValErrorDto> errorMessages = new ArrayList<>();

    /**
     * @return 呼出時点でエラーが設定されている場合 true
     */
    protected Boolean hasError() {
        return errorMessages != null && errorMessages.size() > 0;
    }

    /**
     * 処理でエラーが発生したメッセージを設定する。
     * <p>
     * 処理でエラーが発生した場合にエラー内容に対応する項目名とメッセージを設定する。
     * </p>
     *
     * @param _message メッセージ
     * @param _tagert
     */
    protected void addErrorMessage(String _message, String _tagert) {
        errorMessages.add(new ValErrorDto(_message, _tagert));
    }

    /**
     * 処理でエラーが発生したメッセージを設定する。
     * <p>
     * 処理でエラーが発生した場合にエラー内容に対応する項目名とメッセージを設定する。
     * </p>
     *
     *
     */
    protected void clearErrorMessage() {
        errorMessages.clear();
    }

    /**
     * チェック処理終了 チェックエラーが発生する場合、ウェブ層処理を終了する
     *
     * @param _errorMessage
     * @param _tagert
     * @throws ValidateException　ウェブ層バリデーション例外をスローする
     */
    protected void checkErrorEnd(String _errorMessage, String _tagert) throws Exception {
        errorMessages.add(new ValErrorDto(_errorMessage, _tagert));
        ArrayList<ValErrorDto> errorMessages_ = errorMessages;
        errorMessages = new ArrayList<>();
//        throw new ValidateException("ウェブ層処理でチェックエラーが発生しました。", errorMessages_);
        throw new SystemException("ウェブ層処理でチェックエラーが発生しました。");

    }

    protected void checkErrorEnd() throws ValidateException {
        if (hasError()) {
            ArrayList<ValErrorDto> errorMessages_ = errorMessages;
            errorMessages = new ArrayList<>();
            throw new ValidateException("ウェブ層処理でチェックエラーが発生しました。", errorMessages_);
        }
    }

    /**
     * チェック処理終了 チェックエラーが発生する場合、ウェブ層処理を終了する
     *
     * @param errorMessage
     * @throws ValidateException　ウェブ層バリデーション例外をスローする
     */
    protected void errorEnd(String errorMessage) throws ValidateException {
        ArrayList<String> errorMessages = new ArrayList<>();
        errorMessages.add(errorMessage);
        throw new ApplicationException("ウェブ層処理でウェブ例外が発生しました。", errorMessages);

    }

    protected void addMessage(String id, String message) {
        FacesContext.getCurrentInstance().addMessage(id, new FacesMessage(FacesMessage.SEVERITY_INFO, message, message));
    }

    /**
     * ファイルパス
     *
     */
    public FileDto getDownloadFilePath(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
