/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mwb;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.annotation.DateCheck;
import jp.co.kintetsuls.beans.common.annotation.HalfNumber;
import jp.co.kintetsuls.beans.common.annotation.MaxSizeCheck;
import jp.co.kintetsuls.beans.mwb.Mwb011MawbBangoBean;
import lombok.Data;
import org.primefaces.model.TreeNode;

/**
 * MAWB一覧フォーム
 *
 * @author 尹明龍(MBP)
 * @version 2019/2/11 新規作成
 */
@ManagedBean(name = "mwb011Form")
@ViewScoped
@Data
public class Mwb011Form implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     * 定数：SqlId
     */
    public static final String CONST_CON_SQL_ID = "conSqlId";  
    /**
     * 定数：発券営業所コード
     */
    public static final String CONST_CON_HAKKEN_EIGYOSHO_CD = "conHakkenEigyoshoCd";
    /**
     * 定数：航空会社コード
     */
    public static final String CONST_CON_KOKU_GAISHA_CD = "conKokuGaishaCd";
    /**
     * 定数：配布日付From
     */
    public static final String CONST_CON_HAIFU_HIZUKE_FROM = "conHaifuHizukeFrom";
    /**
     * 定数：配布日付To
     */
    public static final String CONST_CON_HAIFU_HIZUKE_TO = "conHaifuHizukeTo";
    /**
     * 定数：配布先営業所コード
     */
    public static final String CONST_CON_HAIFUSAKI_EIGYOSHO_CD = "conHaifusakiEigyoshoCd";
    /**
     * 定数：MAWB番号
     */
    public static final String CONST_CON_MAWB_BANGO = "conMawbBango";  
    /**
     * 定数：登録MAWB番号From
     */
    public static final String CONST_CON_KAISHI_MAWB_BANGO = "conTorokuMawbBangoFrom";
    /**
     * 定数：登録MAWB番号To
     */
    public static final String CONST_CON_SHURYO_MAWB_BANGO = "conTorokuMawbBangoTo";
    
    /**
     * パラメータ名：発券営業所コード(登録MAWB番号)
     */
    public static final String PARAM_NAME_BNG_HAKKEN_EIGYOSHO_CD = "bngTrkListHHakkenEigyoshoCd";
    /**
     * パラメータ名：航空会社コード(登録MAWB番号)
     */
    public static final String PARAM_NAME_BNG_KOKU_GAISHA_CD = "bngTrkListKokuGaishaCd";
    /**
     * パラメータ名：MAWB登録ID(登録MAWB番号)
     */
    public static final String PARAM_NAME_BNG_MAWB_TOROKU_ID = "bngTrkListHMawbTorokuId";
    /**
     * パラメータ名：受入日付(MAWB番号登録)
     */
    public static final String PARAM_NAME_BNG_UKEIRE_HIZUKE = "bngTrkListUkeireHizuke";
    /**
     * パラメータ名：登録MAWB番号From(MAWB番号登録)
     */
    public static final String PARAM_NAME_BNG_TOROKU_MAWB_BANGO_FROM = "bngTrkListHTorokuMawbBangoFrom";
    /**
     * パラメータ名：登録MAWB番号To(MAWB番号登録)
     */
    public static final String PARAM_NAME_BNG_TOROKU_MAWB_BANGO_TO = "bngTrkListHTorokuMawbBangoTo";
    /**
     * パラメータ名：登録MAWB番号From(MAWB番号登録)
     */
    public static final String PARAM_NAME_BNG_SAITOROKU_MAWB_BANGO_FROM = "bngTrkListTorokuMawbBangoFrom";
    /**
     * パラメータ名：登録MAWB番号To(MAWB番号登録)
     */
    public static final String PARAM_NAME_BNG_SAITOROKU_MAWB_BANGO_TO = "bngTrkListTorokuMawbBangoTo";
    
    /**
     * パラメータ名：発券営業所コード(配布MAWB番号)
     */
    public static final String PARAM_NAME_HIF_HAKKEN_EIGYOSHO_CD = "hifTrkListHHakkenEigyoshoCd";
    /**
     * パラメータ名：航空会社コード(配布MAWB番号)
     */
    public static final String PARAM_NAME_HIF_KOKU_GAISHA_CD = "hifTrkListKokuGaishaCd";
    /**
     * パラメータ名：MAWB登録ID(配布MAWB番号)
     */
    public static final String PARAM_NAME_HIF_MAWB_TOROKU_ID = "hifTrkListHMawbTorokuId";
    /**
     * パラメータ名：配布先営業所コード(配布MAWB番号)
     */
    public static final String PARAM_NAME_HIF_HAIFUSAKI_EIGYOSHO_CD = "hifTrkListHHaifuEigyoshoCd";
    /**
     * パラメータ名：MAWB配布ID(配布MAWB番号)
     */
    public static final String PARAM_NAME_HIF_MAWB_HAIFU_ID = "hifTrkListHMawbHaifuId";
    /**
     * パラメータ名：新MAWB登録ID(配布MAWB番号)
     */
    public static final String PARAM_NAME_HIF_NEW_MAWB_TOROKU_ID = "newMawbTorokuId";
    /**
     * パラメータ名：配布MAWB番号From(配布MAWB番号)
     */
    public static final String PARAM_NAME_HIF_HAIFU_MAWB_BANGO_FROM = "hifTrkListHaifuMawbBangoFrom";
    /**
     * パラメータ名：配布MAWB番号To(配布MAWB番号)
     */
    public static final String PARAM_NAME_HIF_HAIFU_MAWB_BANGO_TO = "hifTrkListHaifuMawbBangoTo";
    /**
     * パラメータ名：再配布先営業所コード
     */
    public static final String PARAM_NAME_HIF_SAIHAIFUSAKI_EIGYOSHO_CD = "hifTrkListSaihaifusakiEigyoshoCd";
    /**
     * パラメータ名：再配布MAWB番号From(配布MAWB番号)
     */
    public static final String PARAM_NAME_HIF_SAIHAIFU_MAWB_BANGO_FROM = "hifTrkListSaihaifuMawbBangoFrom";
    /**
     * パラメータ名：再配布MAWB番号From(配布MAWB番号)
     */
    public static final String PARAM_NAME_HIF_SAIHAIFU_MAWB_BANGO_TO = "hifTrkListSaihaifuMawbBangoTo";
    /**
     * パラメータ名：再配布日付
     */
    public static final String PARAM_NAME_HIF_SAIHAIFU_HIZUKE = "hifTrkListSaihaifuHizuke";
    /**
     * パラメータ名：再配布形式
     */
    public static final String PARAM_NAME_HIF_SAIHAIFU_KEISHIKI = "hifTrkListSaihaifuKeishiki";
    /**
     * パラメータ名：MAWB番号選択
     */
    public static final String PARAM_NAME_HIF_SENTAKU_SELECT_MAWB_BANGO = "hifTrkListHSaihaifMawbCheckList";
    
    /**
     * 発券営業所
     */
    private AutoCompOptionBean conHakkenEigyosho;
    /**
     * 発券営業所Disabled
     */
    private boolean conHakkenEigyoshoDisabled;

    /**
     * 航空会社コード
     */
    private AutoCompOptionBean conKokuGaishaCd;
    /**
     * 航空会社コードDisabled
     */
    private boolean conKokuGaishaCdDisabled;
   
    /**
     * 配布年月日From
     */
    @DateCheck(name = "配布日付開始")
    private String conHaifuHizukeFrom;
    /**
     * 配布年月日To
     */
    @DateCheck(name = "配布年月日終了")
    private String conHaifuHizukeTo;
    /**
     * 配布年月日FromDisabled
     */
    private boolean conHaifuHizukeFromDisabled;
    /**
     * 配布年月日ToDisabled
     */
    private boolean conHaifuHizukeToDisabled;
    
    /**
     * 未使用MAWB表示
     */
    private String[] conMishiyoMawbHyoji;
    /**
     * 未使用MAWB表示Disabled
     */
    private boolean conMishiyoMawbHyojiDisabled;
    
    /**
     * 配布先営業所
     */
    private AutoCompOptionBean conHaifusakiEigyosho;
    /**
     * 配布先営業所Disabled
     */
    private boolean conHaifusakiEigyoshoDisabled;

    /**
     * MAWB番号
     */
    @MaxSizeCheck(name = "MAWB番号", maxSize = 8)
    @HalfNumber(name = "MAWB番号")
    private String conMawbBango;
    /**
     * 配布先営業所Disabled
     */
    private boolean conMawbBangoDisabled;
    
    /**
     * 検索結果件数
     */
    private int searchResultCount;
    
    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;
    /**
     * 編集用一覧データ
     */
    private Mwb011MawbBangoBean mawbBean;
    /**
     *  編集用一覧データ (treenode)
     */
    private TreeNode root;
    
    /**
     * 選択された結果
     */
    private TreeNode selectedNode;
    /**
     * 選択されたMAWB番号
     */
    private Mwb011MawbBangoBean selectedBean;
    
    /**
     * 検索条件Disabled
     */
    private boolean conKensakuDisabled;
    
    /**
     * 検索Visabled
     */
    private boolean btnSearchVisible;

    /**
     * 検索条件変更Visabled
     */
    private boolean btnSearchChangeVisible;
    
}
