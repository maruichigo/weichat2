package jp.co.kintetsuls.beans.common;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.exception.FunctionCust;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.file.CsvBuilder;
import jp.co.kintetsuls.file.ExcelBuilder;
import jp.co.kintetsuls.file.FileDto;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.kintetsuls.utils.DateUtils;
import jp.co.kintetsuls.utils.FileUtils;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.primefaces.PrimeFaces;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

/**
 * ファイル操作Bean
 *
 * @author
 */
@ManagedBean(name = "fileBean")
@ViewScoped
@Data
public class FileBean extends AbstractBean {

    private final Map<String, FunctionCust<String, List>> downLoadFunctionList = new HashMap();

    private final Map<String, FunctionCust<String, List>> getSearchResultFunctionList = new HashMap();
    
    private final Map<String, FunctionCust<String, Boolean>> beforDownFunctionList = new HashMap();

    private final Map<String, FunctionCust<String, Long>> checkSizeFunctionList = new HashMap();
    
    private List<Map<String, Object>> dataList;
    
    private List<CSVDto> headerList;
    
    private String tilte = "";
    
    private boolean splitButtonSta = true;
    
    private boolean excelButtonSta = false;

    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;
    
    private static final String SAVE_COMMENT_FUNCTION = "download-comment-save";
    /**
     * 存在フラグ
     */
    private boolean subFlg;

    private final Map<String, PageCommonBean> settings = new HashMap();

    private String comment;

    /**
     * 検索件数
     *
     */
    private String kensu;
    
    /**
    * 拡張子
    *
    */
    private String kakuChoushi;

    public Object returnNull() {
        System.out.println("returnNull called");
        return null;

    }

    /**
     * ファイルダウンロード
     *
     */
    public StreamedContent getDownloadFile(String id , String type, String btype) throws Exception {
        

        // DataTable連動
        List<Map<String, Object>> body = null;
        String mode = getCheckResult(id);
        if ("1".equals(mode)) {
            body = getSearchResultFunctionList.get(id).apply("");
        } else {
            if (!downLoadFunctionList.containsKey(id)) {
                return null;
            }
            List<Map<String, Object>> data = downLoadFunctionList.get(id).apply("");
            body = data;
        }
        
        FileDto file = null;
        
        if ("excel".equals(type)) {
            String saveFile = ExcelBuilder.saveExcelInfoMap(headerList, body);
            file = new FileDto("", CsvBuilder.FILE_STORE_FOLDER_TEMP + StndConsIF.FS + saveFile);
        } else {
            String saveFile = CsvBuilder.saveCsvInfofromMap(headerList, body);
            file = new FileDto("", CsvBuilder.FILE_STORE_FOLDER_TEMP + StndConsIF.FS + saveFile);
        }

        if (file == null) {
            return null;
        }
        String downloadFilePath = file.getFilePath();
        String downloadFileName = file.getFileName();
        if (CheckUtils.isEmpty(downloadFilePath)) {
            return null;
        }
        if (CheckUtils.isEmpty(downloadFileName)) {
            downloadFileName = tilte + "_" + FileUtils.getFileName(downloadFilePath);
        }

        InputStream stream = new FileInputStream(FileUtils.getAbsolutePath(downloadFilePath));
        if (comment != null && !"".equals(comment)) {
            dbSave(comment, id, downloadFileName);  
        }
        StreamedContent fileOut = new DefaultStreamedContent(stream, FileUtils.getContentType(downloadFileName), downloadFileName);
        return fileOut;

    }

    @Override
    public void init(String menuId, String prevScreen, boolean backFlg) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String menuClick(String menuId, String nextScreen) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String logoutClick() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * 業務ダウンロード方法を設定する。
     *
     * @param id
     * @param delFunction
     */
    public void regDownloadFucntion(String id, List<CSVDto> header,
            FunctionCust<String, List> downloadFunction) {
        downLoadFunctionList.put(id, downloadFunction);
        this.headerList = header;

    }
    
    public String getCheckResult(String id) throws Exception {
        PageCommonBean setting = settings.get(id);
        List<Map<String, Object>> data = getSearchResultFunctionList.get(id).apply("");
        if (data.size() == 1 && "hideRow".equals(data.get(0).get("hideFlg"))) {
            return "0";
        }             
        if (data.size() <= Integer.valueOf(setting.getMasterInfo().getMaxRows())) {
                return "1";
            }
        return "0";
    }
    
    public void regBeforeDownFucntion(String id,
            FunctionCust<String, Boolean> beforeDownFucntion) {
        beforDownFunctionList.put(id, beforeDownFucntion);

    }

    public void setDataSize(String id, FunctionCust<String, Long> checkSizeFunction) {
        checkSizeFunctionList.put(id, checkSizeFunction);
    }

    public void setSearchResult(String id, FunctionCust<String, List> searchResultFuction) {
        getSearchResultFunctionList.put(id, searchResultFuction);
    }
    public void beforeDown(String id, String type) throws Exception {

        // 拡張子
        kakuChoushi = "." + type;
        PrimeFaces pf = PrimeFaces.current();
        Long cheLong;
        List<Map<String, Object>> searchResult = new ArrayList<>();
        if (!beforDownFunctionList.containsKey(id)) {
            return;
        }
        if (checkSizeFunctionList.containsKey(id)) {
            String mode = getCheckResult(id);
            if ("1".equals(mode)) {
                searchResult = getSearchResultFunctionList.get(id).apply("");
                int size = searchResult.size();
                kensu = String.valueOf(size);
                cheLong = (long)size;
            } else {
                cheLong = checkSizeFunctionList.get(id).apply("");
                kensu = cheLong.toString();
            }
            pf.executeScript("getCSV ('" + checkSizeRe(id,cheLong) + "', '" + type + "')");
        }

    }

 
    
     private String checkSizeRe(String id, Long size) {

        PageCommonBean setting = settings.get(id);
        Integer msxRows = Integer.valueOf(setting.getMasterInfo().getMaxRows());
        Integer downloadMaxRows = Integer.valueOf(setting.getMasterInfo().getDownloadMaxRows());
        String allEigyoshoSearch = setting.getMasterInfo().getAllEigyoshoSearch();
        if (msxRows >= size && size > 0) {
            if ("0".equals(allEigyoshoSearch)) {
                if (!subFlg) {
                    return "F";
                } else {
                    return "G";
                }
            } else {
                if (!subFlg) {
                    return "H";
                } else {
                    return "I";
                }
            }
        }
        if (msxRows < size && size <= downloadMaxRows) {
            if ("0".equals(allEigyoshoSearch)) {
                if (!subFlg) {
                    return "J";
                } else {
                    return "K";
                }
            } else {
                if (!subFlg) {
                    return "L";
                } else {
                    return "M";
                }
            }
        }
        if (size > downloadMaxRows) {
            if (!subFlg) {
                return "N";
            } else {
                return "O";
            }
        } else {
            return "E";
        }
    }
     
     public void changeButtonStatas(String kbn) {
         if ("E".equals(kbn)) {
            splitButtonSta = true;
            return;
         }
         splitButtonSta = false;
         if ("D".equals(kbn)) {
             excelButtonSta = true;
         } else {
             excelButtonSta = false;
         }
     }
     
     public void saveComment(String id) {
        PrimeFaces pf = PrimeFaces.current();

         if (comment == null || "".equals(comment.trim())) {
             return;
         } else {
            pf.executeScript("downLoadFile()");
         }
     }
     
     public void dbSave(String comment, String id, String fileName){
        Map<String, Object> params = new HashMap<>();
        // 画面Id
        params.put("gamenId", id);
        // コメント
        params.put("comment", comment);
        // 検索件数
        params.put("kensu", kensu);
        
        // ファイル名前
        params.put("filename", fileName);
        // DBへ情報登録
        pageCommonBean.getDBInfo(params, SAVE_COMMENT_FUNCTION);
        
     }
}