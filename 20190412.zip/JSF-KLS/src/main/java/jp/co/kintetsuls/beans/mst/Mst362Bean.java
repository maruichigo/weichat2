/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Level;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import javax.faces.event.AjaxBehaviorEvent;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.KbnBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst362Form;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.kintetsuls.utils.DateUtils;
import jp.co.kintetsuls.utils.NumberUtils;
import jp.co.kintetsuls.utils.StrUtils;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 月額自動請求マスタ(その他請求)画面
 *
 * @author 呉俊 (MBP)
 * @version 2019/1/24 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst362")
@ViewScoped
@Data
public class Mst362Bean extends AbstractBean {

    private final String titleName = "月額自動請求マスタ(その他請求)";

    /**
     * パンくず名
     */
    private final String TITLE = "その他請求自動入力マスタ";   
    
    /**
     * ダウンロード名
     */
    private final String FILE_NAME = "月額自動請求マスタ(その他請求)一覧";   
    
    /**
     * 画面URL
     */
    private String url;
    
    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

    /**
     *
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authorityConfBean;

    /**
     * ログインユーザー情報
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;
    
    /**
     * ファイルダウンロード
     */
    @ManagedProperty(value = "#{fileBean}")
    private FileBean fileBean;

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;

    /**
     * 画面項目保持
     */
    @ManagedProperty(value = "#{mst362Form}")
    private Mst362Form mst362Form;

    /**
     * 共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * 検索シーケンス処理共通
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;

    /**
     * 履歴一覧処理共通
     */
    @ManagedProperty(value = "#{rirekisyosai}")
    private RirekiSyosaiBean rirekiSyosaiBean;

    /**
     * 一覧単項目チェック共通
     */
    @ManagedProperty(value = "#{listCheckBean}")
    private ListCheckBean listCheckBean;
    
    /**
     * kbnBean
     */
    @ManagedProperty(value = "#{kbnBean}")
    private KbnBean kbnBean;
    
     /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(
            new Object() {}.getClass().getEnclosingClass().getName());

    /**
     * ScreenCode：MST362.
     */
    private static final String SC_CD_MST362 = "MST362_SCREEN";
    
    /**
     * 定数：行削除FUNC_CODE.
     */
    private static final String DELETE_ROW_FUNC_CODE = "mst362_delete";    
    
    /**
     * 定数：行削除チェック.
     */
    private static final String MST362_DELETE_CHECK = "mst362_delete_check";  
    
    /**
     * 定数：検索件数取得FUNC_CODE.
     */
    private static final String FUNC_CODE_SEARCH_KENSU = "mst362_kensu";
    
    /**
     * 定数：検索FUNC_CODE.
     */
    private static final String SEARCH_FUNC_CODE = "mst362_search";
    
    /**
     * 定数：登録の重複チェックファンクションコード
     */
    private static final String FUNC_CODE_INSERT_UPDATE_CHECK = "mst362-insert-update-check";
    
    /**
     * 定数：登録.更新FUNC_CODE.
     */
    private static final String FUNC_CODE_INSERT_UPDATE = "mst362-insert-update-shinsei";
    
    /**
     * 定数：SHINSEI_DELETE_FUNC_CODE.
     */
    private static final String SHINSEI_DELETE_FUNC_CODE = "mst362_shinsei_delete";
    
    /**
     * 定数：SHINSEI_UPDATE_FUNC_CODE.
     */
    private static final String SHINSEI_UPDATE_FUNC_CODE = "mst362_shinsei_update";
    
    /**
     * 定数：画面項目保持key.
     */
    private static final String CONST_MST362_FORM = "mst362Form";

    /**
     * 定数：MasterInfo取得key.
     */
    private static final String CONST_MST362_MASTER = "mst362";
    
    /**
     * 定数：一覧のDataTableのID.
     */
    private static final String DATA_TABLE_ID = "tablesorter_mst362";
    
    /**
     * 定数：再検索Button取得キー
     */
    private static final String CONST_MST362_SEARCH = "search_mst362"; 

    /**
     * 履歴テーブル検索キー.
     */
    private Map<String, Object> rirekiSearchKey;

    // ワーク.メッセージリスト
    List<MessageModuleBean> msgList = new ArrayList<>();
    
    /**
     * コンストラクタ
     */
    public Mst362Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId
     * @param prevScreen
     * @param backFlag
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            // パンくず追加
            breadBean.push(titleName, SCREEN.MST362_SCREEN.name(), this);
            
            // マスタ内容取得
            pageCommonBean.getMasterInfo(CONST_MST362_MASTER);
            
            // 検索シーケンス処理を初期化する
            searchHelpBean.regSearchHelp(DATA_TABLE_ID,
                    s -> {return getRecordCount(false);},
                    s -> {search(); return null;},
                    s -> {return checkParamas();});
            searchHelpBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);
            
            // ワーク.営業所リスト
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO, new AutoCompOptionBean("全て", "all"));
            
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(営業所リスト)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO);

            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(顧客リスト)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_KOKYAKU);
            
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(料金項目1)
            autoCompleteViewBean.getComMsDatasByVal(MsCnst.COM_GET_VW_FUTAI_RYOKIN_KOMOKU1, "T");
            
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(単位リスト)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_MS_TANI);
            
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(料金項目2)
            autoCompleteViewBean.getComMsDatasByVal(MsCnst.COM_GET_VW_FUTAI_RYOKIN_KOMOKU2, "T");
            
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(入力日付)
            autoCompleteViewBean.getMsKbn(MsCnst.NYURYOKU_HIZUKE);

            // 前回の記録をクリアする
            this.clear();
            mst362Form.setSearchResult(null);
            mst362Form.setSearchResultSelectable(null);
            mst362Form.setSelectedSearchResult(null);
            
            // 戻ってきた場合
            Mst362Form preForm = (Mst362Form) pageCommonBean.getPageInfo(CONST_MST362_FORM);
            if (backFlag && preForm != null) {
                PageCommonBean.simpleCopy(preForm, mst362Form);
                // 再検索を実施する
                pageCommonBean.searchAgain(CONST_MST362_SEARCH);
            } else {
                // 進んできた場合
                Flash flash = pageCommonBean.getPageParam();
                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_MST362_FORM) != null) {
                    PageCommonBean.simpleCopy(flash.get(CONST_MST362_FORM), mst362Form);
                    // 再検索を実施する
                    pageCommonBean.searchAgain(CONST_MST362_SEARCH);
                }
            }
            
            // ダウンロードシーケンスを初期化する
            fileBean.setDataSize(DATA_TABLE_ID,
                    (id -> {return getRecordCount(true);}));
            
            fileBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);
            
            fileBean.setSubFlg(false);

            fileBean.setTilte(FILE_NAME);
            
            fileBean.regDownloadFucntion(DATA_TABLE_ID, getHeader() ,
                    (id -> {return getGetsuGaku(true);}));
            
            fileBean.regBeforeDownFucntion(DATA_TABLE_ID,
                    (comment -> {return beforeDown(comment);}));

            fileBean.setSearchResult(DATA_TABLE_ID, 
                    (id -> {return getSearchResult();})); 
            
            // 行更新また削除するために共通処理へ登録する
            pageCommonBean.regDelFucntion(DATA_TABLE_ID,
                    (dataList -> (this.delRows(dataList))));

            // component初期化とユーザ権限により制御を設定する
            pageCommonBean.setAuthControll(mst362Form, SC_CD_MST362, true);

            mst362Form.setConDisabled(false);
            // 初期はデータを編集不可にする
            mst362Form.setBtnEditeDisabled(true);
            
            // 世代検索条件を初期化する
            mst362Form.setConSedaiKensakuJoken(new String[]{"01","02"});

            //　申請状況
            mst362Form.setConShinseiJokyo(new String[]{"01","02","03","04","05"});
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        
    }

    /**
     * 検索パラメータチェック
     * 
     * @return チェックの結果
     */
    public String checkParamas() {
        
        // 世代検索チェック
        if (mst362Form.getConSedaiKensakuJoken() != null && mst362Form.getConSedaiKensakuJoken().length > 0) {
            // 世代検索条件で適用日指定が選択されている場合
            if (kbnBean.getKbnCdOfKeyCd(MsCnst.SEDAI_KENSAKU_JOKEN_TEKIYO_HI_SHITEI).equals(
                    mst362Form.getConSedaiKensakuJoken()[mst362Form.getConSedaiKensakuJoken().length - 1])) {
                
                if (mst362Form.getConTekiyoBi() == null) {
                    messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0028,
                        "searchForm:sk:skc:sedaiKensaku_sedaiKensakuCalendar",
                        "適用日指定", "適用日");
                    return "FALSE";
                }
            }
        }
        return "TRUE";
    }
    
    /**
     * カウント処理
     *
     * @param downloadFlg ダウンロードフラグ
     * @return 取得件数
     */
    public Long getRecordCount(boolean downloadFlg) {

        // 前回の記録をクリアする
        Map<String, Object> mapRec = new LinkedHashMap();
        mapRec.put(StndConsIF.CONST_ZERO_STRING, true);
        List<Map<String, Object>> mapList = new ArrayList();
        mapList.add(mapRec);
        mst362Form.setSearchResult(mapList);
        mst362Form.setSearchResultSelectable(new ReportListDataModel(mst362Form.getSearchResult()));
        mst362Form.setSelectedSearchResult(null);
        
        // 検索初期はデータを編集不可にする
        mst362Form.setBtnEditeDisabled(true);
        
        // 件数取得処理
        long kensu = getGetsuGakuKensu(downloadFlg);

        // サブ検索条件フラグ設定
        fileBean.setSubFlg(subSearchConHad());
        
        if (!downloadFlg) {

            // 検索部のステータスを変更する
            mst362Form.setConDisabled(true);

            // 参照モードにする
            pageCommonBean.setEditFlg(false);

            // 検索条件保存
            pageCommonBean.savePageInfo(CONST_MST362_FORM, mst362Form);
        }

        return kensu;
    }
    
    /**
     * サブ検索条件入力判断
     * 
     * @return true:入力あり/false:入力しない
     */
    private boolean subSearchConHad() {
        
        // 適用名
        if (!CheckUtils.isEmpty(mst362Form.getConTekiyoMei())) {
            return true;
        }
        // 世代検索条件
        if (mst362Form.getConSedaiKensakuJoken() != null && mst362Form.getConSedaiKensakuJoken().length > 0) {
            return true;
        }
        // 適用日
        if (mst362Form.getConTekiyoBi() != null) {
            return true;
        }
        // 削除のみ
        if (mst362Form.getConSakujoNomiKensaku()!= null && mst362Form.getConSakujoNomiKensaku().length > 0) {
            return true;
        }

        return false;
    }
    
    /**
     * 検索処理
     *
     */
    public void search() {
        
        // 選択リストを初期化
        mst362Form.setSelectedSearchResult(new ArrayList<>());
        mst362Form.setSearchResultSelectable(null);

        // 月額自動請求マスタ検索し、取得した値を画面項目にセット
        List<Map<String, Object>> res = getGetsuGaku(false);
        
        // 配色定義を設定する
        setIchiranColor(res);
        
        fileBean.setDataList(res);

        // 取得した値を画面項目にセット
        pageCommonBean.setDatalist(DATA_TABLE_ID, res);
        
        try {
            mst362Form.setSearchResultSelectable(new ReportListDataModel(res));
        } catch (Exception e) {
            java.util.logging.Logger.getLogger(Mst291Bean.class.getName()).log(Level.SEVERE, null, e);
        }
        
        // 検索部のステータス変更
        pageCommonBean.setSerchConDisabled(mst362Form);
        
        // 削除済のみのチェック状態より、明細データを編集可／不可にする
        if (mst362Form.getConSakujoNomiKensaku()== null || mst362Form.getConSakujoNomiKensaku().length == 0) {
            // 削除済みデータを編集可にする
            mst362Form.setBtnEditeDisabled(false);
        } else {
            // 削除済みデータを編集不可にする
            mst362Form.setBtnEditeDisabled(true);
        }

        // 検索条件保存
        pageCommonBean.savePageInfo(CONST_MST362_FORM, mst362Form);
        
        // 参照モードにする
        pageCommonBean.setEditFlg(false);
    }

    /**
     * 配色定義を設定する処理
     *
     * @param recordList レコードリスト
     */
    public void setIchiranColor(List<Map<String, Object>> recordList) {

        // 配色定義の判定を行う
        
    }
    
    /**
     * 検索条件変更処理
     *
     */
    public void searchChange() {

        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mst362Form);
    }

    /**
     * クリア処理
     *
     */
    public void clear() {

        // 検索部の条件クリア
        // 営業所コード
        mst362Form.setConEigyoshoCd(null);
        // 顧客コード
        mst362Form.setConKokyakuCd(null);
        // 料金項目1
        mst362Form.setConRyokinKomoku1(null);
        // 料金項目2
        mst362Form.setConRyokinKomoku2(null);
        // 適用名
        mst362Form.setConTekiyoMei(null);
        // 世代検索条件を初期化する
        mst362Form.setConSedaiKensakuJoken(new String[]{"01","02"});
        // 適用日
        mst362Form.setConTekiyoBi(null);
        // 削除済のみ
        mst362Form.setConSakujoNomiKensaku(null);
        // 申請状況
        mst362Form.setConShinseiJokyo(new String[]{"01","02","03","04","05"});
        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mst362Form);
        pageCommonBean.setBtnSearchChangeVisible(false);
        pageCommonBean.setBtnSearchVisible(Boolean.TRUE);
    }
    
    /**
     * 更新処理
     *
     */
    public void update() {
        // エラーメッセージを格納する変数の初期化を行う
        msgList = new ArrayList();
        MessageModuleBean message = null;
        List<Map<String, Object>> datas = mst362Form.getSelectedSearchResult();
        
        // 行選択チェックを行う
        if (datas == null || datas.isEmpty()) {
            message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
            msgList.add(message);
            
            messagePropertyBean.messageList(msgList);
            return;
        }
        
        // 単項目チェック処理
        if (!checkJsfParamas(mst362Form.getSelectedSearchResult())) {
            return;
        }

        // 必須チェック
        for (int i = 0; i < datas.size(); i++) {
            // 単位・単価・数量・金額
            if (!CheckUtils.isEmpty(StrUtils.defaultString(datas.get(i).get("listTani"))) 
                    && !CheckUtils.isEmpty(StrUtils.defaultString(datas.get(i).get("listTanka"))) 
                    && !CheckUtils.isEmpty(StrUtils.defaultString(datas.get(i).get("listSuryo")))) {
                if (CheckUtils.isEmpty(StrUtils.defaultString(datas.get(i).get("listKingaku")))) {
                    message = messagePropertyBean.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0050, "単位・単価・数量", "金額");
                    msgList.add(message);
                }
            } 
            // 単位・単価・数量・金額
            if (CheckUtils.isEmpty(StrUtils.defaultString(datas.get(i).get("listTani"))) 
                    || CheckUtils.isEmpty(StrUtils.defaultString(datas.get(i).get("listTanka"))) 
                    || CheckUtils.isEmpty(StrUtils.defaultString(datas.get(i).get("listSuryo")))) {
                if (!CheckUtils.isEmpty(StrUtils.defaultString(datas.get(i).get("listKingaku")))) {
                    message = messagePropertyBean.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0050, "単位・単価・数量", "金額");
                    msgList.add(message);
                }
            } 
            // 終了チェック 適用終了日が入力済みの場合
            if (!CheckUtils.isEmpty(StrUtils.defaultString(datas.get(i).get("listTekiyoShuryobi")))) {
                if (!Boolean.valueOf(StrUtils.defaultString(datas.get(i).get("listShuryoFlg")))) {
                    message = messagePropertyBean.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0041, "終了する場合、適用終了日");
                    msgList.add(message);
                }
            } 
            // 適用終了日 終了チェックが選択済みの場合
            if (CheckUtils.isEmpty(StrUtils.defaultString(datas.get(i).get("listTekiyoShuryobi")))) {
                if (Boolean.valueOf(StrUtils.defaultString(datas.get(i).get("listShuryoFlg")))) {
                    message = messagePropertyBean.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0048, "終了しない場合、適用終了日");
                    msgList.add(message);
                }
            }
            // 入力日付範囲チェック
            if (CheckUtils.isInRange(NumberUtils.toInt(StrUtils.defaultString(datas.get(i).get("listNyuryokuHizuke"))), 1, 31)) {
                
            } else {
                if (NumberUtils.toInt(StrUtils.defaultString(datas.get(i).get("listNyuryokuHizuke"))) == 99) {
                    
                } else {
                    message = messagePropertyBean.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0054, "入力日付", "1～31、99(月末)");
                    msgList.add(message);
                }
            }
            
        }
        
        if (!msgList.isEmpty()) {
            messagePropertyBean.messageList(msgList);
            return;
        }
        
        // 登録・更新処理を行う
        int status = insertUpdateShinsei();

        // エラーの場合、処理終了
        if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            return;
        }

    }
    
    /**
     * 一覧の単項目チェック処理
     * 
     * @param params 画面一覧パラメータ
     * @return チェックの結果
     */
    private boolean checkJsfParamas(List<Map<String, Object>> params) {

        List<ListCheckBean> checks = new ArrayList<>();
        /**
        * 顧客コードチェック
        */
        checks.add(new ListCheckBean("listKokyakuCd", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "顧客コード"));
        /**
        * 料金項目1チェック
        */
        checks.add(new ListCheckBean("listRyokinKomoku1", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "料金項目1"));
        /**
        * 料金項目2チェック
        */
        checks.add(new ListCheckBean("listRyokinKomoku2",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "料金項目2"));
        /**
        * 入力日付チェック
        */
        checks.add(new ListCheckBean("listNyuryokuHizuke",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "入力日付"));
        /**
        * 適用開始日チェック
        */
        checks.add(new ListCheckBean("listTekiyoKaishibi",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "適用開始日"));
        /**
        * 単価チェック
        */
        checks.add(new ListCheckBean("listTanka",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "単価", "10"));
        /**
        * 数量チェック
        */
        checks.add(new ListCheckBean("listSuryo",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "数量", "9"));
        /**
        * 金額チェック
        */
        checks.add(new ListCheckBean("listKingaku",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "金額", "10"));
        /**
        * 適用名チェック
        */
        checks.add(new ListCheckBean("listTekiyoMei",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "適用名", "40"));
        List<MessageModuleBean> checkMsgList = listCheckBean.check(params, checks, true);

        if (!checkMsgList.isEmpty()) {
            return false;
        }
        return true;
    }

    /**
     * 月額自動請求マスタの登録申請
     * 
     * @return
     */
    private int insertUpdateShinsei() {

        // 重複チェック
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(
                mst362Form.getSelectedSearchResult(), FUNC_CODE_INSERT_UPDATE_CHECK);
        
        // エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            messagePropertyBean.message(res.getMessages().get(0)[0],
                    res.getMessages().get(0)[1],
                    res.getMessages().get(0)[2],
                    res.getTableName());

            return res.getStatusCode();
        }
        
        // 登録一覧リストと更新一覧リストの内容処理する
        res = pageCommonBean.accsessDBWithList(
                mst362Form.getSelectedSearchResult(), FUNC_CODE_INSERT_UPDATE);

        return res.getStatusCode();
    }
    
    /**
     * 月額自動請求マスタの申請ステータス更新
     * 
     * @param datas　データリスト
     * @param shinseiFlg
     */
    public void shinseiUpdate(List<Map<String, Object>> datas, String shinseiFlg) {

        // パラメータ
        Map<String, Object> params = new HashMap<>();

        params.put("datas", datas);
        // 目前没有共同画面，只能设定一个shinseiFlg来判断是否是承认了
        params.put("shinseiFlg", shinseiFlg);
        
        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, SHINSEI_UPDATE_FUNC_CODE);
    }

    /**
     * 月額自動請求マスタの未申請データ削除
     * 
     * @param datas　データリスト
     */
    public void shinseiDelete(List<Map<String, Object>> datas) {
        
        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(datas, SHINSEI_DELETE_FUNC_CODE);
    }

    /**
     * 月額自動請求マスタ検索件数を取得する
     * 
     */
    private long getGetsuGakuKensu(boolean downloadFlg) {

        if (downloadFlg) {
            mst362Form = (Mst362Form)pageCommonBean.getPageInfo(CONST_MST362_FORM);
        }
        
        // パラメータ
        Map<String, Object> params = new HashMap<>();

        //世代検索条件に変換 
        String[] conSedaiKensakuJoken = new String[5];
        List conSedaiKensakuJokenList = Arrays.asList(mst362Form.getConSedaiKensakuJoken());
        for (int i = 1; i < 6; i++) {
            if (conSedaiKensakuJokenList.isEmpty()) {
                conSedaiKensakuJoken[i - 1] = "0";
            } else {
                //循环リスト 比較値して値をつける
                for (Object object : conSedaiKensakuJokenList) {
                    if (i == Integer.valueOf(String.valueOf(object))) {
                        conSedaiKensakuJoken[i - 1] = "1";
                        break;
                    } else {
                        conSedaiKensakuJoken[i - 1] = "0";
                    }
                }
            }
        }
        
        //申請状況検索条件に変換 
        List conShinseiJokyoList = Arrays.asList(mst362Form.getConShinseiJokyo());
        String[] conShinseiJokyo = {"", "", "", "", ""};
        if (conShinseiJokyoList != null) {
            if (conShinseiJokyoList.contains("01")) {
                conShinseiJokyo[0] = "01";
                params.put("conShinseiJokyo", conShinseiJokyo);
            }
            if (conShinseiJokyoList.contains("02")) {
                conShinseiJokyo[1] = "02";
                params.put("conShinseiJokyo", conShinseiJokyo);
            }
            if (conShinseiJokyoList.contains("03")) {
                conShinseiJokyo[2] = "03";
                params.put("conShinseiJokyo", conShinseiJokyo);
            }
            if (conShinseiJokyoList.contains("04")) {
                conShinseiJokyo[3] = "04";
                params.put("conShinseiJokyo", conShinseiJokyo);
            }
            if (conShinseiJokyoList.contains("05")) {
                conShinseiJokyo[4] = "05";
                params.put("conShinseiJokyo", conShinseiJokyo);
            }
        }
        
        /**
        * 営業所コード
        */
        if (mst362Form.getConEigyoshoCd() != null) {
            params.put("conEigyoshoCd", mst362Form.getConEigyoshoCd().getValue());
        } else {
            params.put("conEigyoshoCd", "");
        }
        
        /**
        * 顧客コード
        */
        if (mst362Form.getConKokyakuCd() != null) {
            params.put("conKokyakuCd", mst362Form.getConKokyakuCd().getValue());
        } else {
            params.put("conKokyakuCd", "");
        }
        
        /**
        * 料金項目1
        */
        if (mst362Form.getConRyokinKomoku1() != null) {
            params.put("conRyokinKomoku1", mst362Form.getConRyokinKomoku1().getValue());
        } else {
            params.put("conRyokinKomoku1", "");
        }
        
        /**
        * 料金項目2
        */
        if (mst362Form.getConRyokinKomoku2() != null) {
            params.put("conRyokinKomoku2", mst362Form.getConRyokinKomoku2().getValue());
        } else {
            params.put("conRyokinKomoku2", "");
        }
        
        /**
        * 適用名
        */
        params.put("conTekiyoMei", mst362Form.getConTekiyoMei());
        /**
        * 世代検索
        */
        params.put("conSedaiKensakuJoken", conSedaiKensakuJoken);
        
        /**
        * 料金項目2チェック
        */
        try {
            if (conSedaiKensakuJokenList.contains("05")) {
                if (mst362Form.getConTekiyoBi() != null) {
                    params.put("conTekiyoBi", DateUtils.format(mst362Form.getConTekiyoBi(), StndConsIF.DF_YYYY_MM_DD));
                } else {
                    params.put("conTekiyoBi", null);
                }
            }
        } catch (SystemException ex) {
            java.util.logging.Logger.getLogger(Mst362Bean.class.getName()).log(Level.SEVERE, null, ex);
        }
        // ログインユーザー所属営業所
        params.put("loginUserShozokuEigyosho", authConfBean.getLoginUserShozokuEigyosho());
        /**
        * 削除済のみ
        */
        params.put("conSakujoNomiKensaku", mst362Form.getConSakujoNomiKensaku());
        /**
        * 申請状況
        */
        params.put("conShinseiJokyo", conShinseiJokyo);
        
        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH_KENSU);

        return Long.valueOf(res.getJson());
    }
    
    /**
     * 月額自動請求マスタ情報を取得する
     * @param downloadFlg ダウンロードフラグ
     */
    private List<Map<String, Object>> getGetsuGaku(boolean downloadFlg) {

        if (downloadFlg) {
            mst362Form = (Mst362Form)pageCommonBean.getPageInfo(CONST_MST362_FORM);
        }
        
        // パラメータ
        Map<String, Object> params = new HashMap<>();
        
        //世代検索条件に変換 
        String[] conSedaiKensakuJoken = new String[5];
        List conSedaiKensakuJokenList = Arrays.asList(mst362Form.getConSedaiKensakuJoken());
        for (int i = 1; i < 6; i++) {
            if (conSedaiKensakuJokenList.isEmpty()) {
                conSedaiKensakuJoken[i - 1] = "0";
            } else {
                //循环リスト 比較値して値をつける
                for (Object object : conSedaiKensakuJokenList) {
                    if (i == Integer.valueOf(String.valueOf(object))) {
                        conSedaiKensakuJoken[i - 1] = "1";
                        break;
                    } else {
                        conSedaiKensakuJoken[i - 1] = "0";
                    }
                }
            }
        }
        
        //申請状況検索条件に変換 
        List conShinseiJokyoList = Arrays.asList(mst362Form.getConShinseiJokyo());
        String[] conShinseiJokyo = {"", "", "", "", ""};
        if (conShinseiJokyoList != null) {
            if (conShinseiJokyoList.contains("01")) {
                conShinseiJokyo[0] = "01";
                params.put("conShinseiJokyo", conShinseiJokyo);
            }
            if (conShinseiJokyoList.contains("02")) {
                conShinseiJokyo[1] = "02";
                params.put("conShinseiJokyo", conShinseiJokyo);
            }
            if (conShinseiJokyoList.contains("03")) {
                conShinseiJokyo[2] = "03";
                params.put("conShinseiJokyo", conShinseiJokyo);
            }
            if (conShinseiJokyoList.contains("04")) {
                conShinseiJokyo[3] = "04";
                params.put("conShinseiJokyo", conShinseiJokyo);
            }
            if (conShinseiJokyoList.contains("05")) {
                conShinseiJokyo[4] = "05";
                params.put("conShinseiJokyo", conShinseiJokyo);
            }
        }
        
        /**
        * 営業所コード
        */
        if (mst362Form.getConEigyoshoCd() != null) {
            params.put("conEigyoshoCd", mst362Form.getConEigyoshoCd().getValue());
        } else {
            params.put("conEigyoshoCd", "");
        }
        
        /**
        * 顧客コード
        */
        if (mst362Form.getConKokyakuCd() != null) {
            params.put("conKokyakuCd", mst362Form.getConKokyakuCd().getValue());
        } else {
            params.put("conKokyakuCd", "");
        }
        
        /**
        * 料金項目1
        */
        if (mst362Form.getConRyokinKomoku1() != null) {
            params.put("conRyokinKomoku1", mst362Form.getConRyokinKomoku1().getValue());
        } else {
            params.put("conRyokinKomoku1", "");
        }
        
        /**
        * 料金項目2
        */
        if (mst362Form.getConRyokinKomoku2() != null) {
            params.put("conRyokinKomoku2", mst362Form.getConRyokinKomoku2().getValue());
        } else {
            params.put("conRyokinKomoku2", "");
        }

        /**
        * 適用名
        */
        params.put("conTekiyoMei", mst362Form.getConTekiyoMei());
        /**
        * 世代検索
        */
        params.put("conSedaiKensakuJoken", conSedaiKensakuJoken);
        
        /**
        * 適用日
        */
        try {
            if (conSedaiKensakuJokenList.contains("05")) {
                if (mst362Form.getConTekiyoBi() != null) {
                    params.put("conTekiyoBi", DateUtils.format(mst362Form.getConTekiyoBi(), StndConsIF.DF_YYYY_MM_DD));
                } else {
                    params.put("conTekiyoBi", null);
                }
            }
        } catch (SystemException ex) {
            java.util.logging.Logger.getLogger(Mst362Bean.class.getName()).log(Level.SEVERE, null, ex);
        }
        // ログインユーザー所属営業所
        params.put("loginUserShozokuEigyosho", authConfBean.getLoginUserShozokuEigyosho());
        /**
        * 削除済のみ
        */
        params.put("conSakujoNomiKensaku", mst362Form.getConSakujoNomiKensaku());
        /**
        * 申請状況
        */
        params.put("conShinseiJokyo", conShinseiJokyo);
        
        try {
            // DBをアクセス
            ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, SEARCH_FUNC_CODE);
            ObjectMapper mapper = new ObjectMapper();
            mst362Form.setSearchResult(mapper.readValue(res.getJson(), List.class));

        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
        return mst362Form.getSearchResult();
    }
    
    /**
     * 更新履歴を表示処理
     *
     */
    public void rirekiIchiran() {

        //履歴テーブル検索キー設定
        rirekiSearchKey = new HashMap();
        
        // 選択されたレコードを取得する
        Map<String, Object> selectRec = mst362Form.getSelectedSearchResult().get(0);
        /**
        * 顧客コード
        */
        rirekiSearchKey.put("listKokyakuCd", selectRec.get("listKokyakuCd"));
        /**
        * 料金項目1
        */
        rirekiSearchKey.put("listRyokinKomoku1", selectRec.get("listRyokinKomoku1"));
        /**
        * 料金項目2
        */
        rirekiSearchKey.put("listRyokinKomoku2", selectRec.get("listRyokinKomoku2"));
        /**
        * 入力日付
        */
        rirekiSearchKey.put("listNyuryokuHizuke", selectRec.get("listNyuryokuHizuke"));
        /**
        * 休日計上
        */
        rirekiSearchKey.put("listKyujitsuKeijo", selectRec.get("listKyujitsuKeijo"));
        /**
        * 適用開始日
        */
        rirekiSearchKey.put("listTekiyoKaishibi", selectRec.get("listTekiyoKaishibi"));
        
        //履歴タイトル設定
        rirekiSyosaiBean.setListColName(
                new ArrayList<>(Arrays.asList(
                        "顧客コード", "顧客名", "料金項目1", "料金項目名1", "料金項目2",
                        "料金項目名2","入力日付", "休日計上", "適用開始日", "単価","単位",
                        "数量", "金額", "適用名", "適用終了日", "申請状況")));

        //履歴テーブル物理カラム設定
        rirekiSyosaiBean.setListColValue(
                new ArrayList<>(Arrays.asList(
                        "listKokyakuCd", "listKokyakuMei", "listRyokinKomoku1",
                        "listRyokinKomoku1Mei", "listRyokinKomoku2", "listRyokinKomoku2Mei",
                        "listNyuryokuHizuke", "listKyujitsuKeijo", "listTekiyoKaishibi", 
                        "listTanka", "listTani", "listSuryo","listKingaku", "listTekiyoMei", 
                        "listTekiyoShuryobi", "listShinseiJokyo")));

        //履歴テーブル検索する
        rirekiSyosaiBean.searchList("2", "MST362_SEARCH_VW_JIDOSEIKYU_KOMOKU_SONOTA_SEIKYU_RIREKI", rirekiSearchKey);

    }
    
    /**
     * メニュークリック処理
     *
     * @param menuId メニューID
     * @param nextScreenId 遷移先画面ID
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreenId) {
        try {
            // パンくずを削除する
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移を行う
        url = forward(nextScreenId, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック処理
     *
     * @param nextScreenId 遷移先画面ID
     * @param breadIndex パンくずのインデックス
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreenId, int breadIndex) {

        try {
            // パンくずを削除する
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        
        // 画面遷移を行う
        url = forward(nextScreenId, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック処理
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authorityConfBean.logout();
    }

    /**
     * 画面遷移処理（顧客マスタメンテナンス画面へ）
     *
     * @return 遷移先の画面URL
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     */
    public String buttonClick() throws IllegalAccessException, InvocationTargetException {

        // 画面遷移を行う
        url = forward(SCREEN.CUS012_SCREEN.name(), null, SCREEN.CUS011_SCREEN.name(), false);
        return url;
    }

    /**
     * 画面タイトルを取得する処理
     * 
     * @return 画面タイトル
     */
    public String getTitleName() {
        return titleName;
    }

    /**
     * CSVファイルのタイトルを設定する処理
     * 
     * @return 画面タイトル
     */
    public List<CSVDto> getHeader() {
        // CSVファイルのタイトルを設定
        List<CSVDto> header = new ArrayList<>();
        /**
        * 顧客コード
        */
        header.add(new CSVDto("顧客コード", "listKokyakuCd"));
        /**
        * 顧客名
        */
        header.add(new CSVDto("顧客名", "listKokyakuMei"));
        /**
        * 料金項目1
        */
        header.add(new CSVDto("料金項目1", "listRyokinKomoku1"));
        /**
        * 料金項目名1
        */
        header.add(new CSVDto("料金項目名1", "listRyokinKomoku1Mei"));
        /**
        * 料金項目2
        */
        header.add(new CSVDto("料金項目2", "listRyokinKomoku2"));
        /**
        * 料金項目名2
        */
        header.add(new CSVDto("料金項目名2", "listRyokinKomoku2Mei"));
        /**
        * 入力日付
        */
        header.add(new CSVDto("入力日付", "listNyuryokuHizuke"));
        /**
        * 休日計上
        */
        header.add(new CSVDto("休日計上", "listKyujitsuKeijo"));
        /**
        * 適用開始日
        */
        header.add(new CSVDto("適用開始日", "listTekiyoKaishibi"));
        /**
        * 単価
        */
        header.add(new CSVDto("単価", "listTanka"));
        /**
        * 単位
        */
        header.add(new CSVDto("単位", "listTani"));
        /**
        * 数量
        */
        header.add(new CSVDto("数量", "listSuryo"));
        /**
        * 金額
        */
        header.add(new CSVDto("金額", "listKingaku"));
        /**
        * 適用名
        */
        header.add(new CSVDto("適用名", "listTekiyoMei"));
        /**
        * 適用終了日
        */
        header.add(new CSVDto("適用終了日", "listTekiyoShuryobi"));
        /**
        * 申請状況
        */
        header.add(new CSVDto("申請状況", "listShinseiJokyo"));
        return header;
    }
   
    /**
     * 業務削除処理ファンクション領域
     *
     */
    public void delRowsFunc() {
        // エラーメッセージを格納する変数を初期化する
        msgList = new ArrayList<>();

        // 行選択チェック
        if (mst362Form.getSelectedSearchResult().isEmpty()) {
            MessageModuleBean message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0011, "選択");
            msgList.add(message);
        }
        
        if (!msgList.isEmpty()) {
            messagePropertyBean.messageList(msgList);
            return;
        }
        
        pageCommonBean.getSelectedDatasList().put(DATA_TABLE_ID, mst362Form.getSelectedSearchResult());
        pageCommonBean.delRows(DATA_TABLE_ID);

    }
    
    /**
     * 業務削除処理
     *
     * @param recordList レコードリスト
     * @return 正常／異常
     */
    public Boolean delRows(List<Map<String, Object>> recordList) {
        // エラーメッセージを格納する変数を初期化する
        msgList = new ArrayList<>();
        MessageModuleBean message = null;
        
        // 単項目チェック処理
        if (!checkJsfParamas(mst362Form.getSelectedSearchResult())) {
            return false;
        }
        
        for (int i = 0; i < recordList.size(); i++) {
            
            // 単位・単価・数量・金額
            if (!CheckUtils.isEmpty(StrUtils.defaultString(recordList.get(i).get("listTani"))) 
                    && !CheckUtils.isEmpty(StrUtils.defaultString(recordList.get(i).get("listTanka"))) 
                    && !CheckUtils.isEmpty(StrUtils.defaultString(recordList.get(i).get("listSuryo")))) {
                if (CheckUtils.isEmpty(StrUtils.defaultString(recordList.get(i).get("listKingaku")))) {
                    message = messagePropertyBean.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0050, "単位・単価・数量", "金額");
                    msgList.add(message);
                }
            } 
            // 終了チェック 適用終了日が入力済みの場合
            if (!CheckUtils.isEmpty(StrUtils.defaultString(recordList.get(i).get("listTekiyoShuryobi")))) {
                if (!Boolean.valueOf(StrUtils.defaultString(recordList.get(i).get("listShuryoFlg")))) {
                    message = messagePropertyBean.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0041, "終了する場合、適用終了日");
                    msgList.add(message);
                }
            } 
            // 適用終了日 終了チェックが選択済みの場合
            if (CheckUtils.isEmpty(StrUtils.defaultString(recordList.get(i).get("listTekiyoShuryobi")))) {
                if (Boolean.valueOf(StrUtils.defaultString(recordList.get(i).get("listShuryoFlg")))) {
                    message = messagePropertyBean.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0048, "終了しない場合、適用終了日");
                    msgList.add(message);
                }
            }
            // 入力日付範囲チェック
            if (CheckUtils.isInRange(NumberUtils.toInt(StrUtils.defaultString(recordList.get(i).get("listNyuryokuHizuke"))), 1, 31)) {
                
            } else {
                if (NumberUtils.toInt(StrUtils.defaultString(recordList.get(i).get("listNyuryokuHizuke"))) == 99) {
                    
                } else {
                    message = messagePropertyBean.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0054, "入力日付", "1～31、99(月末)");
                    msgList.add(message);
                }
            }
            
            // 適用終了日が適用開始日より過去日付の場合。
            try {
                if (!CheckUtils.isEmpty(StrUtils.defaultString(recordList.get(i).get("listTekiyoShuryobi")))) {
                    if (CheckUtils.isLessThan(DateUtils.parse(StrUtils.defaultString(recordList.get(i).get("listTekiyoShuryobi")), "EEE MMM dd HH:mm:ss z yyyy", Locale.US),
                        DateUtils.parse(StrUtils.defaultString(recordList.get(i).get("listTekiyoKaishibi")), StndConsIF.DF_TIMESTAMP))) {
                        message = messagePropertyBean.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0053, "適用終了日", "適用開始日");
                        msgList.add(message);
                    }
                }
                
            } catch (SystemException ex) {
                java.util.logging.Logger.getLogger(Mst362Bean.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
         
        if (!msgList.isEmpty()) {
            messagePropertyBean.messageList(msgList);
            return false;
        }
        
        // 存在チェック
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(recordList, MST362_DELETE_CHECK);
        
        // エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            
            // 存在しない場合は画面から削除しない
            mst362Form.getSearchResult().addAll(recordList);
            
            message = messagePropertyBean.createMessageModule(
                    res.getMessages().get(0)[0], 
                    res.getMessages().get(0)[1],
                    res.getMessages().get(0)[2],
                    res.getTableName());
            msgList.add(message);
            
            messagePropertyBean.messageList(msgList);
            return false;
        }
        
        // 削除処理を行う
        int status = deleteShinsei(recordList);
        
        // エラーの場合、処理を終了
        if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            return false;
        }

        try {
            // 画面レコード削除
            mst362Form.getSearchResult().removeAll(recordList);
        } catch (Exception e) {
            java.util.logging.Logger.getLogger(Mst362Bean.class.getName()).log(Level.SEVERE, null, e);
        }
        
        return true;
    }

    /**
     * DBから仕向地名マスタ情報を削除する
     * 
     * @param datas データリスト
     * @return ステータスコード 
     */
    private int deleteShinsei(List<Map<String, Object>> datas) {

        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(datas, DELETE_ROW_FUNC_CODE);

        // ステータスコードを返却する
        return res.getStatusCode();
    }    
    
    /**
     * ダウンロード理由を記録する処理
     *
     * @param comment 理由コメント
     * @return 正常／異常
     * @throws Exception
     */
    public boolean beforeDown(String comment) throws Exception {
        
        // ダウンロード理由を記録する
        System.out.println(comment);
        
        return true;
    }
     
    /**
     * 検索結果を取得する
     * 
     * @return 検索結果
     */
    private List<Map<String, Object>> getSearchResult() {
        return mst362Form.getSearchResult();
    }
    
    /**
     * 終了チェック
     * @param event 
     */
    public void shuryoubiCheck(AjaxBehaviorEvent event) {
        mst362Form.getSearchResultSelectable();
        mst362Form.getSelectedSearchResult();
    }
    
    /**
     * 申請画面
     * 
     * @return 遷移先画面のURL
     */
    public String shinsei() {

        // アップロード画面へ遷移
        url = forward(SCREEN.DEM012_SCREEN.name(), null, SCREEN.MST362_SCREEN.name(), false);
        return url;
    }
}
