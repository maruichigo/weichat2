/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.faces.bean.ViewScoped;
import lombok.Data;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;

/**
 *
 * @author malei
 */
@javax.faces.bean.ManagedBean(name = "fileFtpToDataspider")
@ViewScoped
@Data
public class FileFtpToDataspider {

    /**
     * ftpサーバアドレス.
     */
    private String hostname = "127.0.0.1";

    /**
     * ftpサーバポート.
     */
    private Integer port = 21;

    /**
     * ftpユーザ.
     */
    private String username = "root";

    /**
     * ftpパスワード.
     */
    private String password = "password";

    /**
     * ftpクライエント.
     */
    private FTPClient ftpClient = null;

    
    /**
     * ftpサーバ初期化
     */
    private void initFtpClient() {
        ftpClient = new FTPClient();
        ftpClient.setControlEncoding("utf-8");
        try {
            System.out.println("connecting...ftpサーバ:" + this.hostname + ":" + this.port);
            ftpClient.connect(hostname, port); //ftpサーバへ接続
            ftpClient.login(username, password); //ftpサーバ登録
            int replyCode = ftpClient.getReplyCode(); //サーバ登録成功か否か
            if (!FTPReply.isPositiveCompletion(replyCode)) {
                System.out.println("connect failed...ftpサーバ:" + this.hostname + ":" + this.port);
            }
            System.out.println("connect successfu...ftpサーバ:" + this.hostname + ":" + this.port);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * ファイルアップロード(絶対パス)
     *
     * @param pathname ftpサーバにファイル保存パス
     * @param fileName ftpサーバにファイル保存名
     * @param originfilename アップロードオリジナルファイル（绝对地址）
     *
     * @return
     */
    public boolean uploadFtpFileWithPath(String pathname, String fileName, String originfilename) {
        boolean flag = false;
        InputStream inputStream = null;
        try {

            //ftpサーバ初期化
            initFtpClient();

            System.out.println("アップロード開始");
            inputStream = new FileInputStream(new File(originfilename));
            initFtpClient();
            ftpClient.setFileType(ftpClient.BINARY_FILE_TYPE);
            CreateDirecroty(pathname);
            ftpClient.makeDirectory(pathname);
            ftpClient.changeWorkingDirectory(pathname);
            ftpClient.storeFile(fileName, inputStream);
            inputStream.close();
            ftpClient.logout();
            flag = true;
            System.out.println("アップロード成功");
        } catch (Exception e) {
            System.out.println("アップロード失敗");
            e.printStackTrace();
        } finally {
            if (ftpClient.isConnected()) {
                try {
                    ftpClient.disconnect();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (null != inputStream) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return true;
    }

    /**
     * ファイルアップロード(InputStream)
     *
     * @param pathname ftpサーバにファイル保存パス
     * @param fileName ftpサーバにファイル保存名
     * @param originfilename アップロードオリジナルファイル（inputStream）
     *
     * @return
     */
    public boolean uploadFtpFileWithInputStream(String pathname, String fileName, InputStream inputStream) {
        boolean flag = false;
        try {
 
            //ftpサーバ初期化
            initFtpClient();

            System.out.println("アップロード開始");
            initFtpClient();
            ftpClient.setFileType(FTPClient.BINARY_FILE_TYPE);
            CreateDirecroty(pathname);
            ftpClient.makeDirectory(pathname);
            ftpClient.changeWorkingDirectory(pathname);
            ftpClient.storeFile(fileName, inputStream);
            inputStream.close();
            ftpClient.logout();
            flag = true;
            System.out.println("アップロード成功");
        } catch (Exception e) {
            System.out.println("アップロード失敗");
            e.printStackTrace();
        } finally {
            if (ftpClient.isConnected()) {
                try {
                    ftpClient.disconnect();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (null != inputStream) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return true;
    }

    // リモートフォルダ作成
    private boolean CreateDirecroty(String remote) throws IOException {
        boolean success = true;
        String directory = remote + "/";

        if (!directory.equalsIgnoreCase("/") && !changeWorkingDirectory(new String(directory))) {
            int start = 0;
            int end = 0;
            if (directory.startsWith("/")) {
                start = 1;
            } else {
                start = 0;
            }
            end = directory.indexOf("/", start);
            String path = "";
            String paths = "";
            while (true) {
                String subDirectory = new String(remote.substring(start, end).getBytes("Shift-JIS"), "iso-8859-1");
                path = path + "/" + subDirectory;
                if (!existFile(path)) {
                    if (makeDirectory(subDirectory)) {
                        changeWorkingDirectory(subDirectory);
                    } else {
                        System.out.println("フォルダ作成[" + subDirectory + "]失敗");
                        changeWorkingDirectory(subDirectory);
                    }
                } else {
                    changeWorkingDirectory(subDirectory);
                }

                paths = paths + "/" + subDirectory;
                start = end + 1;
                end = directory.indexOf("/", start);
                // フォルダ作成が完了か
                if (end <= start) {
                    break;
                }
            }
        }
        return success;
    }

    //フォルダを変更
    private boolean changeWorkingDirectory(String directory) {
        boolean flag = true;
        try {
            flag = ftpClient.changeWorkingDirectory(directory);
            if (flag) {
                System.out.println("フォルダ" + directory + " 変更成功！");

            } else {
                System.out.println("フォルダ" + directory + " 変更失敗！フォルダを作成");
            }
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
        return flag;
    }

    //ftpサーバファイル存在判断    
    private boolean existFile(String path) throws IOException {
        boolean flag = false;
        FTPFile[] ftpFileArr = ftpClient.listFiles(path);
        if (ftpFileArr.length > 0) {
            flag = true;
        }
        return flag;
    }

    //フォルダ作成
    private boolean makeDirectory(String dir) {
        boolean flag = true;
        try {
            flag = ftpClient.makeDirectory(dir);
            if (flag) {
                System.out.println("フォルダ作成" + dir + " 成功！");

            } else {
                System.out.println("フォルダ作成" + dir + " 失敗！");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

}
