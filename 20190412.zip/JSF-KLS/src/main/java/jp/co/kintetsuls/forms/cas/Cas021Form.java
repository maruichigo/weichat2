/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.cas;

import java.util.List;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.forms.common.LabelValueForm;
import lombok.Data;

/**
 * 現金回収管理台帳 フォーム
 *
 * @author 作成者 (MBP)
 * @version 2019/1/29 新規作成
 */
@javax.faces.bean.ManagedBean(name = "cas021Form")
@ViewScoped
@Data
public class Cas021Form {

    /**
     * 営業所
     */
    private String k11;

    /**
     * 営業所名
     */
    private String k12;

    /**
     * 集荷日
     */
    private String k13;

    /**
     * 支払区分
     */
    private String k14;

    /**
     * 状態
     */
    private String k15;

    /**
     * 領収書発行ドライバー
     */
    private String k16;

    /**
     * 領収書発行ドライバー名
     */
    private String k17;

    /**
     * 領収書複数発行のみ
     */
    private String k18;

    /**
     * 現金出納簿対象月
     */
    private String k30;

    /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;

    /**
     * 選択された結果
     */
    private List<Map<String, String>> selectedSearchResult;

    /**
     * 項番
     */
    private String k49;

    /**
     * 領収書No.
     */
    private String k50;

    /**
     * 支払区分
     */
    private String k51;

    /**
     * 領収書金額
     */
    private String k52;

    /**
     * 領収書発行日時
     */
    private String k53;

    /**
     * 領収書発行ドライバー
     */
    private String k54;

    /**
     * HTシリアルNo
     */
    private String k55;

    /**
     * 状態
     */
    private String k56;

}
