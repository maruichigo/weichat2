package jp.co.kintetsuls.service;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.beans.login.LoginBean;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.kintetsuls.service.general.property.ExternalServiceProperty;
import jp.co.kintetsuls.common.cnst.SysMsg;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.utils.StrUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * ログインサービスサンプル
 * 
 * @author 
 */
//TODO 実際の実装に合わせていただけますようお願いします。
public class LoginService {

    private static final Logger logger = LogManager.getLogger(new Object(){}.getClass().getEnclosingClass().getName());
    
    /**
     * ログイン取得サンプル
     * @param authConfBean session Scope
     * @param rest         restfullS ervice
     * @param userCd       form Input data
     * @param password     form Input data
     * @return
     * @throws SystemException
     * @throws IOException 
     */
    public ServiceInterfaceBean getLoginInfo(AuthorityConfBean authConfBean, RestfullService rest, String userCd ,String password) throws SystemException, IOException{
        ServiceInterfaceBean req = new ServiceInterfaceBean();

        //入力チェック
        if("".equals(userCd)) {
            req.addMessage("WARN", "警告", SysMsg.WRNREQ);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return req;
        }

        authConfBean.setUserCd(userCd);

        req.setFunctionCode("USER_LOGIN");

        //parameter
        Map<String, Object> params = new HashMap<>();
        params.put("userCd", userCd);
        String requestData = JSONUtil.makeJSONString(params);
        req.setJson(requestData);

        //JAX-RS接続を実行(SQL側のチェック処理など未実装。)
        rest = RestfullService.getInstance();
        ServiceInterfaceBean res = rest.request(req);

        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR){
            return res;
        }

        List<Map<String, Object>> list;
        try {
            list = rest.jsonResMapList(res);
        } catch (IOException ex) {
            req.addMessage("WARN", "警告", SysMsg.ERRRTN);
            req.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            logger.error(ex.getMessage(), ex);
            return res;
        }

        // 取得したログイン情報をAuthorityConfBeanに格納する
        // ToDo:以下の情報は実際のログイン機能作成時に取得するように対応願います。
        String username = (String)list.get(0).get("USER_MEI");
        authConfBean.setUserName(username);
        authConfBean.setUserDepartment("システム開発部");
        // ログインユーザー所属営業所
        List<String> loginUserShozokuEigyosho = new ArrayList();
        for (Map<String, Object> data : list) {
            String eigyosho = StrUtils.defaultString(data.get("ACCESS_KANO_SOSHIKI_CD"));
            loginUserShozokuEigyosho.add(eigyosho);
            // デフォルト営業所
            if ("1".equals(StrUtils.defaultString(data.get("DEFAULT_SHOZOKU_FLG")))) {
                authConfBean.setDefaultEigyosho(eigyosho);
            }
        }
        authConfBean.setLoginUserShozokuEigyosho(loginUserShozokuEigyosho);

        return res;
    }
}
