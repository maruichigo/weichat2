/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.forms.common;

import javax.faces.bean.ViewScoped;
import lombok.Data;

/**
 *
 * @author zengfeng
 */
@javax.faces.bean.ManagedBean(name = "labelValueForm")
@ViewScoped
@Data
public class LabelValueForm {
    private String label;
    private String value;
}
