/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.KbnBean;
import jp.co.kintetsuls.beans.common.KbnModuleBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiListCol;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mst.Mst301Form;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.kintetsuls.utils.DateUtils;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * ロジ料金項目マスタBEAN
 * 
 * @author 尹彥旭（MBP）
 * @version 2019/1/24 新規作成
 */
@ManagedBean(name = "mst301")
@ViewScoped
@Data
public class Mst301Bean extends AbstractBean {
    
    /**
     * 画面title
     */
    private final String TITLE = "ロジ料金項目マスタ";

    /**
     * ダウンロードファイル名
     */
    private final static String FILE_NAME = "ロジ料金項目マスタ一覧";

    /**
     * 画面URL
     */
    private String url;
    
    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    /**
     * ロジ料金項目マスタ
     */
    private List<Map<String, Object>> searchResult;
    
    /**
     * 画面フォーム
     */
    @ManagedProperty(value = "#{mst301Form}")
    private Mst301Form form;
    
    /**
     * 画面共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommon;
    
    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;
    
    /**
     * listチェック
     */
    @ManagedProperty(value = "#{listCheckBean}")
    private ListCheckBean listCheckBean;

    /**
     * 検索シーケンス処理共通
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;
    
    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;
    
    /**
     * 一覧のAutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoComplete}")
    private AutoCompleteBean autoCompleteBean;

    /**
     * kbnBean
     */
    @ManagedProperty(value = "#{kbnBean}")
    private KbnBean kbnBean;
    
    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;
    
    /**
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    /**
     * ファイルダウンロード
     */
    @ManagedProperty(value = "#{fileBean}")
    private FileBean fileBean;

    /**
     * 履歴一覧処理共通
     */
    @ManagedProperty(value = "#{rirekisyosai}")
    private RirekiSyosaiBean rirekiSyosaiBean;
   
    /**
     * 履歴テーブル検索キー
     */
    private Map<String, Object> rirekiSearchKey;
    
    /**
     * ワーク.メッセージリスト
     */
    List<MessageModuleBean> msgList = new ArrayList<>();

    /**
     * 定数：一覧のDataTableのID.
     */
    private static final String DATA_TABLE_ID = "tablesorter_mst301";

    /**
     * 定数：画面項目保持key.
     */
    private static final String CONST_MST301_FORM = "mst301Form";

    /**
     * 定数：MST301_SEARCH
     */
    private static final String MST301_SEARCH = "mst301_search";

    /**
     * 定数：MST301_INSERTUPDATE
     */
    private static final String MST301_INSERTUPDATE = "mst301_insertupdate";

    /**
     * 定数：MST301_DELETE
     */
    private static final String MST301_DELETE = "mst301_delete";

    /**
     * 定数：MST301_CHECKDELETE
     */
    private static final String MST301_CHECK_DELETE = "mst301_check_delete";

    /**
     * 定数：MST301_CHECKUPDATE
     */
    private static final String MST301_CHECK_UPDATE = "mst301_check_update";

    /**
     * 定数：MST301_COUNT
     */
    private static final String MST301_COUNT = "mst301_count";

    /**
     * 定数：MasterInfo取得キー
     */
    private static final String CONST_MST301_MASTER = "mst301";

    /**
     * 定数：再検索Button取得キー
     */
    private static final String CONST_MST301_SEARCH = "search_mst301";
    
    /**
     * コンストラクタ
     */
    public Mst301Bean() {

    }
    
    /**
     * 初期化
     * @param menuId　メニューID
     * @param prevScreen 遷移元画面ID
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlg) {
        try {

            // パンくず追加
            breadBean.push(TITLE, Cnst.SCREEN.MST301_SCREEN.name(), this);
            
            //システムマスタ取得する
            pageCommon.getMasterInfo(CONST_MST301_MASTER);
            
            //検索シーケンス処理を初期化する
            searchHelpBean.regSearchHelp(DATA_TABLE_ID,
                    s -> {return count(false);},
                    s -> { search();return null;},
                    s -> {return checkParamas();});
            searchHelpBean.getSettings().put(DATA_TABLE_ID, pageCommon);
            
            // ダウンロードシーケンス初期化
            fileBean.setDataSize(DATA_TABLE_ID, (id -> {
                return count(true);
            }));
            fileBean.getSettings().put(DATA_TABLE_ID, pageCommon);
            fileBean.setTilte(FILE_NAME);
            fileBean.regDownloadFucntion(DATA_TABLE_ID, getHeader(), (id -> {
                return getRyokinList(true);
            }));
            fileBean.regBeforeDownFucntion(DATA_TABLE_ID, (comment -> {
                return beforeDown(comment);
            }));
            fileBean.setSearchResult(DATA_TABLE_ID, (id -> {return getSearchResult();})); 

            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_SHORI_KAMOKU_CD);
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_HOJO_KAMOKU_CD);
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_OROSHI_KAMOKU_CD);
            // 卸値計算パターン
            form.setOroshiKeisanPattern(kbnBean.getKbnsOfGroupCd(MsCnst.OROSHI_KEISAN_PATTERN));
            // 小数点区分
            form.setShosutenKbnList(kbnBean.getKbnsOfGroupCd(MsCnst.DECIMAL_TYPE));
            // 世代検索条件リスト
            form.setConSedaiKensakuJokenLabelValueList(kbnBean.getKbnsOfGroupCd(MsCnst.SEDAI_KENSAKU_JOKEN));
            // 輸送売上セット先
            form.setTaxType(kbnBean.getKbnsOfGroupCd(MsCnst.TAX_TYPE));
            // 料金項目明細区分
            form.setYusouriageSetSaki(kbnBean.getKbnsOfGroupCd(MsCnst.YUSOURIAGE_SET_SAKI));
            // 料金項目明細区分
            form.setRyokinKomokuMeisaiKbn(kbnBean.getKbnsOfGroupCd(MsCnst.RYOKIN_KOMOKU_MEISAI_KBN));

            form.setConDisabled(false);
            // 初期はデータを編集不可にする
            form.setBtnEditeDisabled(true);
            // 行更新また削除するために共通処理へ登録
            pageCommon.regDelFucntion(DATA_TABLE_ID, (dataList -> (this.delete())));

            // 前回の記録をクリアする
            this.clear();
            form.setSearchResult(null);
            form.setSearchResultSelectable(null);
            form.setSelectedSearchResult(null);
            
            form.setConSedaiKensakuJoken(new String[]{kbnBean.getKbnCdOfKeyCd(MsCnst.SEDAI_KENSAKU_JOKEN_GENZAI_TEKIYO),
                    kbnBean.getKbnCdOfKeyCd(MsCnst.SEDAI_KENSAKU_JOKEN_MIRAI_TEKIYO)});

            // 戻ってきた場合
            Mst301Form preForm = (Mst301Form) pageCommon.getPageInfo(CONST_MST301_FORM);
            if (backFlg && preForm != null) {
                PageCommonBean.simpleCopy(preForm, form);
                // 再検索を実施する
                pageCommon.searchAgain(CONST_MST301_SEARCH);
                // 進んできた場合
            } else {
                Flash flash = pageCommon.getPageParam();
                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_MST301_FORM) != null) {
                    PageCommonBean.simpleCopy(flash.get(CONST_MST301_FORM), form);
                    // 再検索を実施する
                    pageCommon.searchAgain(CONST_MST301_SEARCH);
                }
            }
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * カウント処理
     * 
     * @param downloadFlg ダウンロードフラグ
     * @return 検索件数
     */
    public Long count(boolean downloadFlg) {
        
        // 前回の記録をクリアする
        Map<String, Object> mapRec = new LinkedHashMap();
        mapRec.put("hideFlg", "hideRow");
        List<Map<String, Object>> mapList = new ArrayList();
        mapList.add(mapRec);
        form.setSearchResult(mapList);
        form.setSearchResultSelectable(new ReportListDataModel(form.getSearchResult()));
        form.setSelectedSearchResult(null);

        // 検索初期はデータを編集不可にする
        form.setBtnEditeDisabled(true);
        
        // パラメータを設定
        Map<String, Object> params = getParamas(downloadFlg);
        // DBをアクセス
        ServiceInterfaceBean res = pageCommon.getDBInfo(params, MST301_COUNT);
        // 件数を取得
        Long kensu = Long.valueOf(res.getJson());
        
        // サブ検索条件フラグ設定
        fileBean.setSubFlg(subSearchConHad());

        if (!downloadFlg) {

            // 検索部のステータスを変更する
            form.setConDisabled(true);

            // 参照モードにする
            pageCommon.setEditFlg(false);

            // 検索条件保存
            pageCommon.savePageInfo(CONST_MST301_FORM, form);
        }

        return kensu;
    }

    /**
     * メニュークリック（処理）
     *
     * @param menuId 画面Id
     * @param nextScreen 遷移先の画面Id
     * @return 遷移先の画面url
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {
        
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック処理
     *
     * @param nextScreen 遷移先画面ID
     * @param breadIndex パンくずのインデックス
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        url = forward(nextScreen, null, null, true);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     * 
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authConfBean.logout();
    }

    /**
     * 検索処理
     */
    public void search() {

        // 選択リストを初期化する
        form.setSelectedSearchResult(new ArrayList<>());
        form.setSearchResultSelectable(null);

        // ロジ料金項目マスタ情報を取得する
        List<Map<String, Object>> res = getRyokinList(false);
        if (res == null) {
            return;
        }
        // 検索条件を編集可にする
        form.setBtnEditeDisabled(false);
        
        // 明細データを設定する
        form.setSearchResult(res);
        form.setSearchResultSelectable(new ReportListDataModel(res));
        pageCommon.setDatalist(DATA_TABLE_ID, res);
        
        fileBean.setDataList(res);

        // 参照モードにする
        pageCommon.setEditFlg(false);
    }
    
    /**
     * クリア処理
     */
    public void clear() {

        // 検索部の条件クリア
        form.setConRyokinKomoku1Cd(null);
        // 料金項目2コード
        form.setConRyokinKomoku2Cd(null);
        // 料金項目1名称
        form.setConRyokinKomoku1Mei(null);
        // 料金項目2名称
        form.setConRyokinKomoku2Mei(null);
        // 処理科目コード
        form.setConSyoriKamoku(null);
        // 補助科目コード
        form.setConHojoKamoku(null);
        // 卸値計算パターン
        form.setConOroshineKeisanPattern(null);
        // 適用名
        form.setConTekiyoMei(null);
        // 世代検索条件
        form.setConSedaiKensakuJoken(new String[]{kbnBean.getKbnCdOfKeyCd(MsCnst.SEDAI_KENSAKU_JOKEN_GENZAI_TEKIYO),
                    kbnBean.getKbnCdOfKeyCd(MsCnst.SEDAI_KENSAKU_JOKEN_MIRAI_TEKIYO)});
        // 適用日
        form.setConTekiyoBi(null);
        // 削除のみ検索
        form.setConSakujoNomiKensaku(null);

        // 検索部のステータス変更
        form.setConDisabled(false);
        pageCommon.setBtnSearchChangeVisible(false);
        pageCommon.setBtnSearchVisible(true);

    }

    /**
     * 検索条件変更処理
     */
    public void searchChange() {

        // 検索部のステータスを変更する
        form.setConDisabled(false);
    }

    /**
     * 更新履歴を表示処理
     */
    public void rirekiIchiran() {
        
        // 履歴テーブル検索キーを設定する
        rirekiSearchKey = new HashMap();
        
        // 選択されたレコードを取得する
        Map<String, Object> selectParamsMap = form.getSelectedSearchResult().get(0);
        // 料金項目1コード
        rirekiSearchKey.put("listRyokinkomoku1Cd", selectParamsMap.get("listRyokinkomoku1Cd"));
        // 料金項目2コード
        rirekiSearchKey.put("listRyokinkomoku2Cd", selectParamsMap.get("listRyokinkomoku2Cd"));
        // 適用開始日
        rirekiSearchKey.put("listTekiyoKaishibi", selectParamsMap.get("listTekiyoKaishibi"));

        // 履歴タイトルを設定する
        rirekiSyosaiBean.setListColName(
                new ArrayList<>(Arrays.asList(
                        "バージョン情報","料金項目1コード","料金項目1名称","料金項目2コード","料金項目2名称",
                        "適用開始日","値引不可", "小数点区分","税区分","スポット追加可能","売上セット先",
                        "卸値計算パターン","処理科目コード","処理科目名称",
                        "補助科目コード","補助科目名称","適用名","適用終了日")));

        // 履歴beanの項目物理名を設定する
        List<String> colValue = new ArrayList<>(Arrays.asList(
                        "listLogiRyokinKomokuDataVersion","listRyokinkomoku1Cd","listRyokinkomoku1Mei",
                        "listRyokinkomoku2Cd","listRyokinkomoku2Mei","listTekiyoKaishibi","listNebikiHuka",
                        "listShosutenKbn","listZeiKbn","listSpotTuikaKano","listUriageSetSaki",
                        "listOroshineKeisanPattern","listShorikamokuCd","listShorikamokuMei","listHojokamokuCd",
                        "listHojokamokuMei","listTeikiyoMei","listTekiyoShuryobi"));
        
        List<String> colAlign = new ArrayList<>(Arrays.asList(
                "left", "left", "left", "left", "left", "left", "center", "left", "left", "center", "left", "left",
                "left", "left", "left", "left", "left", "center"));
        List<RirekiListCol> listCol = new ArrayList<>();
        for (int i = 0; i < colValue.size(); i++) {
           RirekiListCol col = new RirekiListCol();
           col.setColValue(colValue.get(i));
           col.setColAlign(colAlign.get(i));
           listCol.add(col);
        }
        rirekiSyosaiBean.setListCol(listCol);
        
        // 履歴テーブルを検索する
        rirekiSyosaiBean.searchList("2", "MST301_SEARCH_RIREKI", rirekiSearchKey);
    }

    /**
     * 更新処理
     */
    public void update() {

        msgList = new ArrayList();
        
        // パラメータを設定する
        List<Map<String, Object>> params = form.getSelectedSearchResult();

        //行選択チェックを行う
        if (form.getSelectedSearchResult() == null || form.getSelectedSearchResult().isEmpty()) {

            MessageModuleBean message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
            msgList.add(message);

            messagePropertyBean.messageList(msgList);
            return;
        }
        
        // jsfチェック処理
        if (!checkJsfParamas(params)) {
            form.setSelectedSearchResult(params);
            return;
        }
        
        for (Map<String, Object> map : params) {
            // 適用開始日
            if (map.get("listTekiyoKaishibi") != null && "java.util.Date".equals(
                    map.get("listTekiyoKaishibi").getClass().getName())) {
                map.put("listTekiyoKaishibi", DateUtils.format((Date) map.get("listTekiyoKaishibi"), "yyyy/MM/dd"));
            }
            // 適用終了日
            if (map.get("listTekiyoShuryobi") != null && "java.util.Date".equals(
                    map.get("listTekiyoShuryobi").getClass().getName())) {
                map.put("listTekiyoShuryobi", DateUtils.format((Date) map.get("listTekiyoShuryobi"), "yyyy/MM/dd"));
            }
        }

        // 例外処理
        ServiceInterfaceBean res = pageCommon.accsessDBWithList(params, MST301_CHECK_UPDATE);
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            messagePropertyBean.message(res.getMessages().get(0)[0], res.getMessages().get(0)[1]);
            return;
        }
        
        // 一覧の配色定義をなくす
        pageCommon.resetIchiranColColor(form.getSelectedSearchResult());
        
        // 更新
        pageCommon.accsessDBWithList(params, MST301_INSERTUPDATE);

        // 再検索を実施する
        pageCommon.searchAgain(CONST_MST301_SEARCH);

        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, "更新");
    }

    /**
     * 削除処理
     * 
     * @return 処理結果
     */
    public boolean delete() {

        msgList = new ArrayList();
        List<Map<String, Object>> selectParams = form.getSelectedSearchResult();
        
        // 行選択チェック
        if (selectParams.isEmpty()) {
            MessageModuleBean message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
            msgList.add(message);
            return false;
        }

        // パラメータを設定する
        List<Map<String, Object>> params = new ArrayList<>();
        for (Map<String, Object> map : selectParams) {
            if (map.get("addFlg") == null) {
                params.add(map);
            }
        }
        
        // 存在チェック
        ServiceInterfaceBean res = pageCommon.accsessDBWithList(params, MST301_CHECK_DELETE);
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            if (MessageCnst.MSTE0109.equals(res.getMessages().get(0)[1])) {
                messagePropertyBean.message(res.getMessages().get(0)[0], res.getMessages().get(0)[1], "ロジ料金項目");
            } else {
                messagePropertyBean.message(res.getMessages().get(0)[0], res.getMessages().get(0)[1]);
            }
            return false;
        }
        pageCommon.accsessDBWithList(params, MST301_DELETE);

        // 画面レコード削除
        form.getSearchResult().removeAll(selectParams);
        
        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, "削除");
        
        // ログ出力
        LOGGER.info("削除 " + selectParams.size() + " 件");
        return true;
    }

    /**
     * 業務削除処理ファンクション領域
     *
     */
    public void delRowsFunc() {

        pageCommon.getSelectedDatasList().put(DATA_TABLE_ID, form.getSelectedSearchResult());
        pageCommon.delRows(DATA_TABLE_ID);
    }
    
    /**
     * ダウンロードダイアログ
     *
     * @param comment コメント
     * @return boolean ダウンロードの結果
     * @throws java.lang.Exception 例外
     */
    public boolean beforeDown(String comment) throws Exception {
        System.out.println(comment);
        return true;
    }

    /**
     * ダウンロータイトルを設定
     * 
     * @return CSVファイルのタイトル
     */
    public List<CSVDto> getHeader() {
        
        // CSVファイルのタイトルを設定
        List<CSVDto> header = new ArrayList<>();
        header.add(new CSVDto("料金項目1コード", "listRyokinkomoku1Cd"));
        header.add(new CSVDto("料金項目1名称", "listRyokinkomoku1Mei"));
        header.add(new CSVDto("料金項目2コード", "listRyokinkomoku2Cd"));
        header.add(new CSVDto("料金項目2名称", "listRyokinkomoku2Mei"));
        header.add(new CSVDto("適用開始日", "listTekiyoKaishibi"));
        header.add(new CSVDto("値引不可", "listNebikiHuka"));
        header.add(new CSVDto("小数点区分", "listShosutenKbn"));
        header.add(new CSVDto("税区分", "listZeiKbn"));
        header.add(new CSVDto("スポット追加可能", "listSpotTuikaKano"));
        header.add(new CSVDto("売上セット先", "listUriageSetSaki"));
        header.add(new CSVDto("卸値計算パターン", "listOroshineKeisanPattern"));
        header.add(new CSVDto("卸科目コード", "listOroshikomokuCd"));
        header.add(new CSVDto("卸科目名称", "listOroshikomokuMei"));
        header.add(new CSVDto("処理科目コード", "listShorikamokuCd"));
        header.add(new CSVDto("処理科目名称", "listShorikamokuMei"));
        header.add(new CSVDto("補助科目コード", "listHojokamokuCd"));
        header.add(new CSVDto("補助科目名称", "listHojokamokuMei"));
        header.add(new CSVDto("適用名", "listTeikiyoMei"));
        header.add(new CSVDto("適用終了日", "listTekiyoShuryobi"));
        return header;
    }

    /**
     * 検索パラメータチェック
     * 
     * @return チェックの結果
     */
    public String checkParamas() {
        
        if (form.getConSedaiKensakuJoken() != null && form.getConSedaiKensakuJoken().length > 0) {
            // 世代検索条件で適用日指定が選択されている場合
            if (kbnBean.getKbnCdOfKeyCd(MsCnst.SEDAI_KENSAKU_JOKEN_TEKIYO_HI_SHITEI).equals(
                    form.getConSedaiKensakuJoken()[form.getConSedaiKensakuJoken().length - 1])) {
                
                if (form.getConTekiyoBi() == null) {
                    messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0028,
                        "searchForm:sk:skc:sedaiKensaku_sedaiKensakuCalendar",
                        "適用日指定", "適用日");
                    return "FALSE";
                }
            }
        }
        return "TRUE";
    }
    
    /**
     * AUTOCOMPLETE選択時コードと名称の設定処理
     * 
     * @param list 明細リスト
     * @param unKey UNIQUE_KEY
     * @param option 選択されたAUTOCOMPLETEデータ
     * @param colCodeName 設定先コード
     * @param colNameName 設定先名称
     */
    public void setListCodeName(List<Map<String, Object>> list,
            String unKey, AutoCompOptionBean option,String colCodeName, String colNameName) {
        
        for (Map<String, Object>  rec : list) {
            if (unKey.equals(rec.get("UNIQUE_KEY"))) {
                if (option == null) {
                    rec.put(colCodeName, "");
                    rec.put(colNameName, "");
                } else {
                    rec.put(colCodeName, option.getValue());
                    rec.put(colNameName, option.getLabel());
                }
            }
        }
        
    }
    
    /**
     * パラメータを設定する
     * 
     * @param downloadFlg ダウンロードフラグ
     * @return 検索結果パラメータ
     */
    private Map<String, Object> getParamas(boolean downloadFlg) {
        
        // パラメータを設定する
        Map<String, Object> params = new HashMap<>();
        
        Mst301Form tempForm = form;
        if (downloadFlg) {
            tempForm = (Mst301Form)pageCommon.getPageInfo(CONST_MST301_FORM);
        }
        
        // 料金項目1コード
        if (tempForm.getConRyokinKomoku1Cd() != null) {
            params.put("conRyokinkomoku1Cd", tempForm.getConRyokinKomoku1Cd());
        }
        // 料金項目1名称
        if (tempForm.getConRyokinKomoku1Mei() != null) {
            params.put("conRyokinkomoku1Mei", tempForm.getConRyokinKomoku1Mei());
        }
        // 料金項目2コード
        if (tempForm.getConRyokinKomoku2Cd() != null) {
            params.put("conRyokinkomoku2Cd", tempForm.getConRyokinKomoku2Cd());
        }
        // 料金項目2名称
        if (tempForm.getConRyokinKomoku2Mei() != null) {
            params.put("conRyokinkomoku2Mei", tempForm.getConRyokinKomoku2Mei());
        }
        // 処理科目
        if (tempForm.getConSyoriKamoku() != null) {
            params.put("conShorikamokuCd", tempForm.getConSyoriKamoku().getValue());
        } else {
            params.put("conShorikamokuCd", "");
        }
        // 補助科目
        if (tempForm.getConHojoKamoku() != null) {
            params.put("conHojokamokuCd", tempForm.getConHojoKamoku().getValue());
        } else {
            params.put("conHojokamokuCd", "");
        }
        // 卸値計算パターン
        if (tempForm.getConOroshineKeisanPattern() != null) {
            params.put("conOroshineKeisanPattern", tempForm.getConOroshineKeisanPattern());
        }
        // 適用名
        if (tempForm.getConTekiyoMei() != null) {
            params.put("conTekiyoMei", tempForm.getConTekiyoMei());
        }
        // 世代検索条件
        List<String> conSedaiKensakuJoken = new ArrayList<>();
        List<String> gamenSedaiKensakuJoken = new ArrayList<>();
        for(String arr : tempForm.getConSedaiKensakuJoken()) {
            gamenSedaiKensakuJoken.add(arr);
        }
        List<KbnModuleBean> sedaiKensakuJokenLabelValueList = tempForm.getConSedaiKensakuJokenLabelValueList();

        // 世代検索条件のパラメータを設定する
        for (int i = 0; i < sedaiKensakuJokenLabelValueList.size(); i++) {
            if (gamenSedaiKensakuJoken.contains(sedaiKensakuJokenLabelValueList.get(i).getKbnCd())) {
                conSedaiKensakuJoken.add("1");
            } else {
                conSedaiKensakuJoken.add("0");
            }
        }
        params.put("conSedaiKensakuJoken", conSedaiKensakuJoken);
        // 適用日
        if (tempForm.getConTekiyoBi() != null) {
            params.put("conTekiyoBi", tempForm.getConTekiyoBi());
        }
        // 削除のみ検索
        if (tempForm.getConSakujoNomiKensaku().length > 0) {
            params.put("conSakujoSumiNomi", "1");
        } else {
            params.put("conSakujoSumiNomi", "0");
        }
        return params;
    }

    /**
     * jsfチェック処理
     * 
     * @param params 画面一覧パラメータ
     * @return チェックの結果
     */
    private boolean checkJsfParamas(List<Map<String, Object>> params) {

        List<ListCheckBean> checks = new ArrayList<>();
        checks.add(new ListCheckBean("listRyokinkomoku1Cd", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "料金項目1コード"));
        checks.add(new ListCheckBean("listRyokinkomoku1Cd",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NUMBER, "料金項目1コード"));
        checks.add(new ListCheckBean("listRyokinkomoku1Mei",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "料金項目1名称"));
        checks.add(new ListCheckBean("listRyokinkomoku2Cd", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "料金項目2コード"));
        checks.add(new ListCheckBean("listRyokinkomoku2Cd", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NUMBER, "料金項目2コード"));
        checks.add(new ListCheckBean("listRyokinkomoku2Mei", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "料金項目2名称"));
        checks.add(new ListCheckBean("listTekiyoKaishibi", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "適用開始日"));
        checks.add(new ListCheckBean("listShosutenKbn",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "小数点区分"));
        checks.add(new ListCheckBean("listZeiKbn",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "税区分"));
        checks.add(new ListCheckBean("listShorikamokuCd", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "処理科目コード"));
        checks.add(new ListCheckBean("listShorikamokuCd", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NUMBER, "処理科目コード"));
        checks.add(new ListCheckBean("listShorikamokuMei", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "処理科目名称"));
        checks.add(new ListCheckBean("listHojokamokuCd", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "補助科目コード"));
        checks.add(new ListCheckBean("listHojokamokuCd", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NUMBER, "補助科目コード"));
        checks.add(new ListCheckBean("listHojokamokuMei", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "補助科目名称"));
        checks.add(new ListCheckBean("listTeikiyoMei",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "適用名"));
        List<MessageModuleBean> msgList = listCheckBean.check(params, checks);

        if (msgList != null && !msgList.isEmpty()) {
            return false;
        }
        return true;
    }

    /**
     * ロジ料金項目マスタ情報を取得する
     *
     * @param downloadFlg ダウンロードフラグ
     * @return ロジ料金項目マスタ情報リスト
     */
    private List<Map<String, Object>> getRyokinList(boolean downloadFlg) {

        Map<String, Object> params = getParamas(downloadFlg);
        try {
            // DBをアクセス
            ServiceInterfaceBean res = pageCommon.getDBInfo(params, MST301_SEARCH);
            ObjectMapper mapper = new ObjectMapper();
            this.searchResult = mapper.readValue(res.getJson(), List.class);

        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
        
        for (Map<String, Object> record : searchResult) {
            // 卸科目
            Object listOroshikomokuCdObj = record.get("listOroshikomokuCd");
            String listOroshikomokuCdStr = "";
            if (listOroshikomokuCdObj != null) {
                listOroshikomokuCdStr = listOroshikomokuCdObj.toString();
            }
            record.put("listOroshikomoku",
                    autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_OROSHI_KAMOKU_CD, listOroshikomokuCdStr));
            // 処理科目
            Object listShorikamokuCdObj = record.get("listShorikamokuCd");
            String listShorikamokuCdStr = "";
            if (listShorikamokuCdObj != null) {
                listShorikamokuCdStr = listShorikamokuCdObj.toString();
            }
            record.put("listShorikamoku",
                    autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_SHORI_KAMOKU_CD, listShorikamokuCdStr));
            // 補助科目
            Object listHojokamokuCdObj = record.get("listHojokamokuCd");
            String listHojokamokuCdStr = "";
            if (listHojokamokuCdObj != null) {
                listHojokamokuCdStr = listHojokamokuCdObj.toString();
            }
            record.put("listHojokamoku",
                    autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_HOJO_KAMOKU_CD, listHojokamokuCdStr));
        }

        return this.searchResult;
    }

    /**
     * サブ検索条件入力判断
     * 
     * @return true:入力あり/false:入力しない
     */
    private boolean subSearchConHad() {
        
        // 適用名
        if (!CheckUtils.isEmpty(form.getConTekiyoMei())) {
            return true;
        }
        // 世代検索条件
        if (form.getConSedaiKensakuJoken() != null && form.getConSedaiKensakuJoken().length > 0) {
            return true;
        }
        // 適用日
        if (form.getConTekiyoBi() != null) {
            return true;
        }
        // 削除のみ
        if (form.getConSakujoNomiKensaku() != null && form.getConSakujoNomiKensaku().length > 0) {
            return true;
        }

        return false;
    }
    
    /**
     * 検索結果を取得する
     * 
     * @return 検索結果
     */
    private List<Map<String, Object>> getSearchResult() {
        return form.getSearchResult();
    }

}
