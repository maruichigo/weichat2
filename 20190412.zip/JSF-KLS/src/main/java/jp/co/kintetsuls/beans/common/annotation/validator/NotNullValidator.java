/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common.annotation.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import jp.co.kintetsuls.beans.common.annotation.NotNull;

/**
 * 必須チェック
 * 
 * @author zf (MBP)
 * @version 2019/3/7 新規作成
 */
public class NotNullValidator implements ConstraintValidator<NotNull, Object> { 

    @Override
    public void initialize(NotNull constraintAnnotation) {
    }

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext context) {
        return !(value == null || "".equals(value.toString()));
    }
    
}
