/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.lgn;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import javax.naming.AuthenticationException;
import javax.naming.NamingException;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import jp.co.kintetsuls.beans.common.DirContextBean;
import jp.co.kintetsuls.beans.common.MasterInfoBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.SystemMasterBean;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.forms.lgn.Lgn011Form;
import jp.co.kintetsuls.forms.lgn.Lgn021Form;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * パスワード変更画面
 *
 * @author 曾鳳(MBP)
 * @version 2019/1/29 新規作成
 */
@javax.faces.bean.ManagedBean(name = "lgn021")
@ViewScoped
@Data
public class Lgn021Bean extends BaseBean {

    /**
     * タイトル
     */
    private final String TITLE = "パスワード変更";
    
    /**
     * 画面URL
     */
    private String url;

    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * ログインユーザー情報
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;

    /**
     * パスワード変更 フォーム
     */
    @ManagedProperty(value = "#{lgn021Form}")
    private Lgn021Form lgn021Form;

    /**
     * ログイン フォーム
     */
    @ManagedProperty(value = "#{lgn011Form}")
    private Lgn011Form lgn011Form;

    /**
     * マスタ情報BEAN
     */
    @ManagedProperty(value = "#{masterInfo}")
    private MasterInfoBean masterInfo;

    /**
     * システムマスタ情報BEAN
     */
    @ManagedProperty(value = "#{systemMasterBean}")
    private SystemMasterBean systemMasterBean;
    
    /**
     * 共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * ADサーバ接続BEAN
     */
    @ManagedProperty(value = "#{dirContextBean}")
    private DirContextBean dirContextBean;
    
    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    /**
     * 定数：ワンタイムパスワードログイン取得キー
     */
    private static final String CONST_ONETIME_PASS_LOGIN = "onetimePassLogin";    
    
    /**
     * 定数：パスワード誤入力回数登録更新処理
     */
    private static final String LGN021_UPDATE = "lgn021-update";

    /**
     * コンストラクタ
     */
    public Lgn021Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId クリックされたメニューID（メニューからの遷移以外はNULL）
     * @param prevScreen 遷移元の画面
     * @param backFlag 戻るフラグ（前画面へボタンからの遷移以外はFALSE）
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {

        try {
            // パンくず追加
            breadBean.push(TITLE, SCREEN.LGN021_SCREEN.name(), this);
            
            // ワーク.パスワード誤入力最大回数
            lgn021Form.setPassErrorMaxKaisu(Integer.valueOf(systemMasterBean.getSysValByCdAndKanriGroup(
                MsCnst.SYS_CD_PASSWORD_ERROR_MAX_KAISU, MsCnst.SYS_CDGROUP_LGN021, MsCnst.SYS_CDGROUP_SYSTEM)));
            
            // メニューからの遷移か、TOP画面からの遷移の場合、モードを変更モードとする。
            if (!CheckUtils.isEmpty(menuId) || CheckUtils.isEqual(Cnst.SCREEN.TOP011_SCREEN.name(), prevScreen)) {
                
                // ワーク.モード
                lgn021Form.setMode("1");
            } else if (Cnst.SCREEN.LGN011_SCREEN.name().equals(prevScreen)) {
                // ログイン画面からの遷移の場合、パラメータの取得を行う
                Flash flash = pageCommonBean.getPageParam();
                // ワーク.ワンタイムパスワードログイン = ワーク.画面遷移パラメータ.ワンタイムパスワードログイン
                String onetimePassLogin = flash.get(CONST_ONETIME_PASS_LOGIN).toString();

                // ワンタイムパスワード未使用時の場合、モードを変更モードとする
                if ("0".equals(onetimePassLogin)) {
                    lgn021Form.setMode("1");
                } else if ("1".equals(onetimePassLogin)) {
                    // ワンタイムパスワード使用時の場合、モードを初期化モードとする
                    lgn021Form.setMode("2");
                }
            }
            
            // 下記の項目を表示する
            // ユーザーコード = ログイン情報.ユーザーコード
            lgn021Form.setHyoDtlUserCd(authConfBean.getUserCd());
            // 現在のパスワード = 空白
            lgn021Form.setHyoDtlGenzaiPassword(null);
            // 新しいパスワード = 空白
            lgn021Form.setHyoDtlNewPassword(null);
            // 新しいパスワード(確認) = 空白
            lgn021Form.setHyoDtlNewPasswordKakunin(null);
            
            if ("1".equals(lgn021Form.getMode())) {
                // ワーク.モード = 1(変更モード)の場合
                // 現在のパスワード
                lgn021Form.setHyoDtlGenzaiPasswordVisabled(true);
            } else {
                // 現在のパスワード
                lgn021Form.setHyoDtlGenzaiPasswordVisabled(false);
            }
            
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * 変更処理
     * 
     * @return 遷移先URL
     */
    public String update() {

        // ワーク.モード = 1(変更モード)の場合
        if ("1".equals(lgn021Form.getMode())) {

            // 入力チェック
            if (checkChange()) {
                return "";
            }

            // ADサーバログイン
            try {
                // 入力された「現在のパスワード」を使用し、ADサーバログイン処理を行う
                // 接続用コンテキストを作成する
                DirContext ctx = dirContextBean.initialDirContext(
                        lgn021Form.getHyoDtlUserCd(), lgn021Form.getHyoDtlGenzaiPassword());
                // 接続成功した場合
                ctx.close();
                // パスワードチェック処理を終了する
            } catch (AuthenticationException ex) {
                // 接続に失敗した場合(AuthenticationException発生時)
                // パスワード誤入力回数登録更新
                Map<String, Object> params = new HashMap<>();
                params.put("userCd", lgn021Form.getHyoDtlUserCd());
                params.put("mode", "1");
                ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, LGN021_UPDATE);
                
                // 取得結果.回数
                int kaisu = Integer.valueOf(res.getJson());
                
                // 取得結果.件数 + 1 <= ワーク.パスワード誤入力最大回数 の場合
                if (kaisu + 1 <= lgn021Form.getPassErrorMaxKaisu()) {
                    
                    messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR,
                            MessageCnst.LGNE0002, "lgn021Form:hyoDtlErrorMessage");
                    return "";
                } else {
                    // 取得結果.件数 + 1 > ワーク.パスワード誤入力最大回数 の場合
                    // エラーメッセージ表示を行い、ログイン(Lgn011)への遷移を行う
                    pageCommonBean.executeScript("km.showConfirmDialog('lgne0003Dialog')");
                    return "";
                }
            } catch (NamingException e) {
                // システムエラーが発生した場合(AuthenticationException以外のException発生時)
                messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR,
                        MessageCnst.COMF0002, "lgn021Form:hyoDtlErrorMessage");
                return "";
            }
        } else {
            // ワーク.モード = 2(初期化モード)の場合
            
            // 入力チェック
            if (checkInit()) {
                return "";
            }
        }
        
        // 入力された「新しいパスワード」を使用し、ADサーバのパスワード更新処理を行う
        if (!updatePassword()) {
            return "";
        }

        // パスワード誤入力回数初期化
        Map<String, Object> params = new HashMap<>();
        params.put("userCd", lgn021Form.getHyoDtlUserCd());
        params.put("mode", "2");
        pageCommonBean.getDBInfo(params, LGN021_UPDATE);
        
        // パスワード更新後、画面遷移を行う
        // ワーク.モード = 1(変更モード)の場合
        if ("1".equals(lgn021Form.getMode())) {
            
            // TOP(Top011)への遷移を行う。
            url = forward(SCREEN.TOP011_SCREEN.name(), null, SCREEN.LGN021_SCREEN.name(), false);
            return url;
        } else {
            // ワーク.モード = 2(初期化モード)の場合
            // ログアウト処理を行い、ログイン(Lgn011)への遷移を行う。
            return authConfBean.logout();
        }
    }
    
    /**
     * ログイン(Lgn011)への遷移処理
     * 
     * @return 遷移先の画面URL
     */
    public String gotoLgn011() {
        url = forward(SCREEN.LGN011_SCREEN.name(), null, SCREEN.LGN021_SCREEN.name(), false);
        return url;
    }

    /**
     * メニュークリック（処理）
     *
     * @param menuId クリックされたメニューID（メニューからの遷移以外はNULL）
     * @param nextScreen 遷移先の画面
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移
        url = forward(nextScreen, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック（処理）
     *
     * @param nextScreen 遷移先の画面
     * @param breadIndex 選択されたパンくずのIndex
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        url = forward(nextScreen, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authConfBean.logout();
    }
    
    /**
     * 変更モードのチェック処理
     * 
     * @return チェック結果
     */
    private Boolean checkChange() {
        
        Boolean errFlg = false;

        // 現在のパスワード:入力必須チェック
        if (CheckUtils.isEmpty(lgn021Form.getHyoDtlGenzaiPassword())) {
            messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0003, "lgn021Form:genzaiPassw:hyoDtlGenzaiPassword", "現在のパスワード");
            errFlg = true;
        }
        // 新しいパスワード:入力必須チェック
        if (CheckUtils.isEmpty(lgn021Form.getHyoDtlNewPassword())) {
            messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0003, "lgn021Form:newPassw:hyoDtlNewPassword", "新しいパスワード");
            errFlg = true;
        }
        // 新しいパスワード(確認):入力必須チェック
        if (CheckUtils.isEmpty(lgn021Form.getHyoDtlNewPasswordKakunin())) {
            messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003,
                    "lgn021Form:newPasswKakunin:hyoDtlNewPasswordKakunin", "新しいパスワード(確認)");
            errFlg = true;
        }
        // パスワード一致チェック:新しいパスワードと新しいパスワード(確認)が完全一致するかのチェック
        if (!CheckUtils.isEqual(lgn021Form.getHyoDtlNewPassword(), lgn021Form.getHyoDtlNewPasswordKakunin())) {
            messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.LGNE0001,
                    "lgn021Form:newPasswKakunin:hyoDtlNewPasswordKakunin");
            errFlg = true;
        }

        return errFlg;
    }
    
    /**
     * 初期化モードのチェック処理
     * 
     * @return チェック結果
     */
    private Boolean checkInit() {
        
        Boolean errFlg = false;

        // 新しいパスワード:入力必須チェック
        if (CheckUtils.isEmpty(lgn021Form.getHyoDtlNewPassword())) {
            messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0003, "lgn021Form:newPassw:hyoDtlNewPassword", "新しいパスワード");
            errFlg = true;
        }
        // 新しいパスワード(確認):入力必須チェック
        if (CheckUtils.isEmpty(lgn021Form.getHyoDtlNewPasswordKakunin())) {
            messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003,
                    "lgn021Form:newPasswKakunin:hyoDtlNewPasswordKakunin", "新しいパスワード(確認)");
            errFlg = true;
        }
        // パスワード一致チェック:新しいパスワードと新しいパスワード(確認)が完全一致するかのチェック
        if (!CheckUtils.isEqual(lgn021Form.getHyoDtlNewPassword(), lgn021Form.getHyoDtlNewPasswordKakunin())) {
            messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.LGNE0001,
                    "lgn021Form:newPasswKakunin:hyoDtlNewPasswordKakunin");
            errFlg = true;
        }

        return errFlg;
    }
    
    /**
     * LDAPパスワード更新処理
     */
    private Boolean updatePassword() {
        
        // バインドユーザ
        String bindUser = messagePropertyBean.getProperties(StndConsIF.BIND_USER);
        // バインドユーザのパスワード
        String bindUserPassword = messagePropertyBean.getProperties(StndConsIF.BIND_USER_PASSWORD);
        try {
            
            // LDAP接続処理
            DirContext ctx = dirContextBean.initialDirContext(bindUser, bindUserPassword);

            // パスワードの暗号化を行う
            String password = lgn021Form.getHyoDtlNewPassword();
            //クォーテーションで囲んだパス生成
            String quotedPassword = "\"" + password + "\"";

            char unicodePwd[] = quotedPassword.toCharArray();
            byte pwdArray[] = new byte[unicodePwd.length * 2];
            for (int i = 0; i < unicodePwd.length; i++) {
                pwdArray[i * 2 + 1] = (byte) (unicodePwd[i] >>> 8);
                pwdArray[i * 2 + 0] = (byte) (unicodePwd[i] & 0xff);
            }

            // 暗号化したパスワードをModificationItemクラスの配列オブジェクトに代入する
            ModificationItem[] mods = new ModificationItem[2];
            mods[0] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new BasicAttribute("unicodePwd", pwdArray));
            mods[1] = new ModificationItem(
                    DirContext.REPLACE_ATTRIBUTE, new BasicAttribute("userParameters", password));

            // ユーザーコード（"CN=...,DC=..."のような形式）
            String userCd = lgn021Form.getHyoDtlUserCd();

            // 対象ユーザ－のdnを指定し、パスワードの更新を行う
            ctx.modifyAttributes(userCd, mods);

            ctx.close();
        } catch (NamingException e) {
            // パスワードの更新に失敗した場合
            messagePropertyBean.messageToArea(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.LGNE0004, "lgn021Form:hyoDtlErrorMessage");
            return false;
        }
        return true;
    }
    
}
