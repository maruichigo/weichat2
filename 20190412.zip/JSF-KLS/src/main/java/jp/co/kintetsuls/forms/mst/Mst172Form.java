/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mst;

import java.io.Serializable;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.annotation.FullWidthKatakanaCheck;
import jp.co.kintetsuls.beans.common.annotation.HalfEisu;
import jp.co.kintetsuls.beans.common.annotation.HalfEisuKigou;
import jp.co.kintetsuls.beans.common.annotation.HalfNumber;
import jp.co.kintetsuls.beans.common.annotation.MaxSizeCheck;
import jp.co.kintetsuls.beans.common.annotation.NotNull;
import jp.co.kintetsuls.beans.common.annotation.SizeCheck;
import jp.co.kintetsuls.beans.common.annotation.MaxByteCheck;
import jp.co.kintetsuls.beans.common.annotation.ZipCode;
import lombok.Data;

/**
 * 荷受人/荷送人マスタ フォーム
 * 
 * @author 许博 (MBP)
 * @version 2019/3/26 新規作成
 */
@ManagedBean(name = "mst172Form")
@ViewScoped
@Data
public class Mst172Form implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 荷受人/荷送人モード(1:荷受人モード/2:荷送人モード)
     */
    private String conNiukeNiokurininMode;
    
    /**
     * 参照/編集/新規モード(0:参照/1:編集/2:新規モード)
     */
    private String conSanshoHenshuShinkiMode;
    
    /**
     * 顧客コード
     */
    @SizeCheck(name = "顧客コード", message = "{COME0001}",size = 6) 
    @HalfEisu(name = "顧客コード",message = "{COME0010}")
    @NotNull(name = "顧客コード", message = "{COME0003}")
    private String dtlKokyakuCd;
    
    /**
     * 顧客コードDisabled
     */
    private boolean dtlKokyakuCdDisabled;
    
    /**
     * 顧客名
     */
    private String dtlKokyakuMei;
    
    /**
     * 営業所コード
     */
    private String dtlEigyoshoCd;
    
    /**
     * 営業所名称
     */
    private String dtlEigyoshoMei;
    
    /**
     * 荷受人発行コード
     */
    @MaxSizeCheck(name = "荷受人発行コード",message = "{COME0002}",maxSize = 20)
    @HalfNumber(name = "荷受人発行コード",message = "{COME0010}")
    private String dtlNiukeninHakkoCd;
    
    /**
     * 荷送人発行コード
     */
    @MaxSizeCheck(name = "荷送人発行コード",message = "{COME0002}",maxSize = 20)
    @HalfNumber(name = "荷送人発行コード",message = "{COME0010}")
    private String dtlNiokurininHakkoCd;
    
    /**
     * 荷受人名称1
     */
    @NotNull(name = "荷受人名称1", message = "{COME0003}")
    @MaxByteCheck(name = "荷受人名称1",message = "{COME0019}",maxByte = 40)
    private String dtlNiukeninMei1;
    
    /**
     * 荷受人名称2
     */
    @MaxByteCheck(name = "荷受人名称2",message = "{COME0019}",maxByte = 40)
    private String dtlNiukeninMei2;
    
    /**
     * 荷受人名称3
     */
    @MaxByteCheck(name = "荷受人名称3",message = "{COME0019}",maxByte = 40)
    private String dtlNiukeninMei3;
    
    /**
     * 荷受人名称4
     */
    @MaxByteCheck(name = "荷受人名称4",message = "{COME0019}",maxByte = 40)
    private String dtlNiukeninMei4;
    
    /**
     * 荷受人略称
     */
    @NotNull(name = "荷受人略称", message = "{COME0003}")
    @MaxByteCheck(name = "荷受人略称",message = "{COME0019}",maxByte = 5)
    private String dtlNiukeninRyaku;
    
    /**
     * 荷受人カナ名称
     */
    @MaxByteCheck(name = "荷受人カナ名称",message = "{COME0019}",maxByte = 40)  
    @FullWidthKatakanaCheck(name = "荷受人カナ名称",message = "{COME0010}")
    private String dtlNiukeninKana;
    
    /**
     * 荷送人名称1
     */
    @NotNull(name = "荷送人名称1", message = "{COME0003}")
    @MaxByteCheck(name = "荷送人名称1",message = "{COME0019}",maxByte = 40)
    private String dtlNiokurininMei1;
    
    /**
     * 荷送人名称2
     */
    @MaxByteCheck(name = "荷送人名称2",message = "{COME0019}",maxByte = 40)
    private String dtlNiokurininMei2;
                                
    /**
     * 荷送人名称3
     */
    @MaxByteCheck(name = "荷送人名称3",message = "{COME0019}",maxByte = 40)
    private String dtlNiokurininMei3;
    
    /**
     * 荷送人名称4
     */
    @MaxByteCheck(name = "荷送人名称4",message = "{COME0019}",maxByte = 40)
    private String dtlNiokurininMei4;
    
    /**
     * 荷送人略称
     */
    @NotNull(name = "荷送人略称", message = "{COME0003}")
    @MaxByteCheck(name = "荷送人略称",message = "{COME0019}",maxByte = 5)
    private String dtlNiokurininRyaku;
    
    /**
     * 荷送人カナ名称
     */
    @MaxByteCheck(name = "荷送人カナ名称",message = "{COME0019}",maxByte = 40) 
    @FullWidthKatakanaCheck(name = "荷送人カナ名称",message = "{COME0010}")
    private String dtlNiokurininKana;
    
    /**
     * 英文登録あり
     */
    private String[] dtlEibunTorokuAri;
    
    /**
     * 英文表示フラグ(true:表示、false:非表示)
     */
    private boolean dtlEiMei;
    
    /**
     * 荷受人名称(英文)1
     */
    @NotNull(name = "荷受人名称(英文)1", message = "{COME0003}")
    @MaxSizeCheck(name = "荷受人名称(英文)1",message = "{COME0002}",maxSize = 40)
    @HalfEisuKigou(name = "荷受人名称(英文)1",message = "{COME0010}")
    private String dtlNiukeninEiMei1;
    
    /**
     * 荷受人名称(英文)2
     */
    @MaxSizeCheck(name = "荷受人名称(英文)2",message = "{COME0002}",maxSize = 40)
    @HalfEisuKigou(name = "荷受人名称(英文)2",message = "{COME0010}")
    private String dtlNiukeninEiMei2;
    
    /**
     * 荷受人名称(英文)3
     */
    @MaxSizeCheck(name = "荷受人名称(英文)3",message = "{COME0002}",maxSize = 40)
    @HalfEisuKigou(name = "荷受人名称(英文)3",message = "{COME0010}")
    private String dtlNiukeninEiMei3;
    
    /**
     * 荷受人名称(英文)4
     */
    @MaxSizeCheck(name = "荷受人名称(英文)4",message = "{COME0002}",maxSize = 40)
    @HalfEisuKigou(name = "荷受人名称(英文)4",message = "{COME0010}")
    private String dtlNiukeninEiMei4;
    
    /**
     * 荷受人略称(英文)
     */
    @NotNull(name = "荷受人略称(英文)", message = "{COME0003}")
    @MaxSizeCheck(name = "荷受人略称(英文)",message = "{COME0002}",maxSize = 10)
    @HalfEisuKigou(name = "荷受人略称(英文)",message = "{COME0010}")
    private String dtlNiukeninEiRyaku;
    
    /**
     * 荷送人名称(英文)1
     */
    @NotNull(name = "荷送人名称(英文)1", message = "{COME0003}")
    @MaxSizeCheck(name = "荷送人名称(英文)1",message = "{COME0002}",maxSize = 40)
    @HalfEisuKigou(name = "荷送人名称(英文)1",message = "{COME0010}")
    private String dtlNiokurininEiMei1;
    
    /**
     * 荷送人名称(英文)2
     */
    @MaxSizeCheck(name = "荷送人名称(英文)2",message = "{COME0002}",maxSize = 40)
    @HalfEisuKigou(name = "荷送人名称(英文)2",message = "{COME0010}")
    private String dtlNiokurininEiMei2;
    
    /**
     * 荷送人名称(英文)3
     */
    @MaxSizeCheck(name = "荷送人名称(英文)3",message = "{COME0002}",maxSize = 40)
    @HalfEisuKigou(name = "荷送人名称(英文)3",message = "{COME0010}")
    private String dtlNiokurininEiMei3;
    
    /**
     * 荷送人名称(英文)4
     */
    @MaxSizeCheck(name = "荷送人名称(英文)4",message = "{COME0002}",maxSize = 40)
    @HalfEisuKigou(name = "荷送人名称(英文)4",message = "{COME0010}")
    private String dtlNiokurininEiMei4;
    
    /**
     * 荷送人略称(英文)
     */
    @NotNull(name = "荷送人略称(英文)", message = "{COME0003}")
    @MaxSizeCheck(name = "荷送人略称(英文)",message = "{COME0002}",maxSize = 10)
    @HalfEisuKigou(name = "荷送人略称(英文)",message = "{COME0010}")
    private String dtlNiokurininEiRyaku;
    
    /**
     * 旧住所フラグ
     */
    private String dtlKyuJushoFlg;
    
    /**
     * 使用不可フラグ
     */
    private String dtlShiyoFukaFlg;
    
    /**
     * 新住所反映
     */
    private String dtlShinJushoHanei;
    
    /**
     * 適用開始日
     */
    private String dtlTekiyoKaishibi;

    /**
     * 新JISコード
     */
    private String dtlShinJisCd;
    
    /**
     * 郵便番号
     */
    @ZipCode(name = "郵便番号", message = "{COME0010}")
    private String dtlYubinBango;
    
    /**
     * JISコード
     */
    @NotNull(name = "JISコード", message = "{COME0003}")
    @SizeCheck(name = "JISコード",message = "{COME0001}",size = 5)
    @HalfNumber(name = "JISコード", message = "{COME0010}")
    private AutoCompOptionBean dtlJisCd;
    
    /**
     * JISコード参照モード
     */
    private String dtlJisCdRead;
    
    /**
     * 荷受人住所1
     */
    @NotNull(name = "荷受人住所1", message = "{COME0003}")
    @MaxByteCheck(name = "荷受人住所1",message = "{COME0019}",maxByte = 40)
    private String dtlNiukeninJusho1;
    
    /**
     * 荷受人住所2
     */
    @MaxByteCheck(name = "荷受人住所2",message = "{COME0019}",maxByte = 40)
    private String dtlNiukeninJusho2;
    
    /**
     * 荷受人住所3
     */
    @MaxByteCheck(name = "荷受人住所3",message = "{COME0019}",maxByte = 40)
    private String dtlNiukeninJusho3;
    
    /**
     * 荷受人住所4
     */
    @MaxByteCheck(name = "荷受人住所4",message = "{COME0019}",maxByte = 40)
    private String dtlNiukeninJusho4;
    
    /**
     * 荷受人電話番号
     */
    @MaxSizeCheck(name = "荷受人電話番号",message = "{COME0002}",maxSize = 15)
    @HalfEisuKigou(name = "荷受人電話番号",message = "{COME0010}")
    private String dtlNiukeninTel;
    
    /**
     * 荷送人住所1
     */
    @NotNull(name = "荷送人住所1", message = "{COME0003}")
    @MaxByteCheck(name = "荷送人住所1",message = "{COME0019}",maxByte = 40)
    private String dtlNiokurininJusho1;
    
    /**
     * 荷送人住所2
     */
    @MaxByteCheck(name = "荷送人住所2",message = "{COME0019}",maxByte = 40)
    private String dtlNiokurininJusho2;
    
    /**
     * 荷送人住所3
     */
    @MaxByteCheck(name = "荷送人住所3",message = "{COME0019}",maxByte = 40)
    private String dtlNiokurininJusho3;
    
    /**
     * 荷送人住所4
     */
    @MaxByteCheck(name = "荷送人住所4",message = "{COME0019}",maxByte = 40)
    private String dtlNiokurininJusho4;
    
    /**
     * 荷送人電話番号
     */
    @MaxSizeCheck(name = "荷送人電話番号",message = "{COME0002}",maxSize = 15)
    @HalfEisuKigou(name = "荷送人電話番号",message = "{COME0010}")
    private String dtlNiokurininTel;
    
    /**
     * 仕向地コード
     */
    @NotNull(name = "仕向地コード", message = "{COME0003}")
    @SizeCheck(name = "仕向地コード",message = "{COME0001}",size = 7)
    @HalfEisu(name = "仕向地コード",message = "{COME0010}")
    private AutoCompOptionBean dtlShimukechiCd;
    
    /**
     * 仕向地名
     */
    private String dtlShimukechiMei;
    
    /**
     * 配達営業所
     */
    @SizeCheck(name = "配達営業所",message = "{COME0001}",size = 3)
    @HalfNumber(name = "配達営業所",message = "{COME0010}")
    @NotNull(name = "配達営業所", message = "{COME0003}")
    private AutoCompOptionBean dtlHaitatsuEigyoshoCd;
    
    /**
     * 配達営業所名
     */
    private String dtlHaitatsuEigyoshoMei;
    
    /**
     * 荷受人住所(英文)1
     */
    @NotNull(name = "荷受人住所(英文)1", message = "{COME0003}")
    @MaxSizeCheck(name = "荷受人住所(英文)1",message = "{COME0002}",maxSize = 40)
    @HalfEisuKigou(name = "荷受人住所(英文)1",message = "{COME0010}")
    private String dtlNiukeninEiJusho1;
    
    /**
     * 荷受人住所(英文)2
     */
    @MaxSizeCheck(name = "荷受人住所(英文)2",message = "{COME0002}",maxSize = 40)
    @HalfEisuKigou(name = "荷受人住所(英文)2",message = "{COME0010}")
    private String dtlNiukeninEiJusho2;
    
    /**
     * 荷受人住所(英文)3
     */
    @MaxSizeCheck(name = "荷受人住所(英文)3",message = "{COME0002}",maxSize = 40)
    @HalfEisuKigou(name = "荷受人住所(英文)3",message = "{COME0010}")
    private String dtlNiukeninEiJusho3;
    
    /**
     * 荷受人住所(英文)4
     */
    @MaxSizeCheck(name = "荷受人住所(英文)4",message = "{COME0002}",maxSize = 40)
    @HalfEisuKigou(name = "荷受人住所(英文)4",message = "{COME0010}")
    private String dtlNiukeninEiJusho4;
    
    /**
     * 荷送人住所(英文)1
     */
    @NotNull(name = "荷送人住所(英文)1", message = "{COME0003}")
    @MaxSizeCheck(name = "荷送人住所(英文)1",message = "{COME0002}",maxSize = 40)
    @HalfEisuKigou(name = "荷送人住所(英文)1",message = "{COME0010}")
    private String dtlNiokurininEiJusho1;
    
    /**
     * 荷送人住所(英文)2
     */
    @MaxSizeCheck(name = "荷送人住所(英文)2",message = "{COME0002}",maxSize = 40)
    @HalfEisuKigou(name = "荷送人住所(英文)2",message = "{COME0010}")
    private String dtlNiokurininEiJusho2;
    
    /**
     * 荷送人住所(英文)3
     */
    @MaxSizeCheck(name = "荷送人住所(英文)3",message = "{COME0002}",maxSize = 40)
    @HalfEisuKigou(name = "荷送人住所(英文)3",message = "{COME0010}")
    private String dtlNiokurininEiJusho3;
    
    /**
     * 荷送人住所(英文)4
     */ 
    @MaxSizeCheck(name = "荷送人住所(英文)4",message = "{COME0002}",maxSize = 40)
    @HalfEisuKigou(name = "荷送人住所(英文)4",message = "{COME0010}")
    private String dtlNiokurininEiJusho4;
    
    /**
     * 検索キー
     */
    @MaxSizeCheck(name = "検索キー",message = "{COME0002}",maxSize = 40)
    @HalfEisu(name = "検索キー",message = "{COME0010}")
    private String dtlKensakuKey;
    
    /**
     * 記事1コード
     */
    private AutoCompOptionBean dtlKiji1Cd;
    
    /**
     * 記事1内容
     */
    @MaxByteCheck(name = "記事1内容",message = "{COME0019}",maxByte = 40)
    private String dtlKiji1Naiyo;
    
    /**
     * 記事2コード
     */
    private AutoCompOptionBean dtlKiji2Cd;
    
    /**
     * 記事2内容
     */
    @MaxByteCheck(name = "記事2内容",message = "{COME0019}",maxByte = 40)
    private String dtlKiji2Naiyo;
    
    /**
     * 記事3コード
     */
    private AutoCompOptionBean dtlKiji3Cd;
    
    /**
     * 記事3内容
     */
    @MaxByteCheck(name = "記事3内容",message = "{COME0019}",maxByte = 40)
    private String dtlKiji3Naiyo;
    
    /**
     * 記事4コード
     */
    private AutoCompOptionBean dtlKiji4Cd;
    
    /**
     * 記事4内容
     */
    @MaxByteCheck(name = "記事4内容",message = "{COME0019}",maxByte = 40)
    private String dtlKiji4Naiyo;
    
    /**
     * 記事5コード
     */
    private AutoCompOptionBean dtlKiji5Cd;
    
    /**
     * 記事5内容
     */
    @MaxByteCheck(name = "記事5内容",message = "{COME0019}",maxByte = 40)
    private String dtlKiji5Naiyo;
    
    /**
     * メモ
     */
    @MaxByteCheck(name = "メモ",message = "{COME0019}",maxByte = 100)
    private String dtlMemo;
    
    /**
     * 最終使用日
     */
    private String dtlSaishuShiyobi;
    
    /**
     * 荷受人更新カウンタ
     */
    private int niukeninKoshinCounter;
    
    /**
     * 荷送人更新カウンタ
     */
    private int niokurininKoshinCounter;
    
    /**
     * 荷受人更新ユーザーID
     */
    private String niukeninKoshinUserCd;
    
    /**
     * 荷送人更新ユーザーID
     */
    private String niokurininKoshinUserCd;
    
    /**
     * 荷受人マスタデータバージョン
     */
    private String niukeninDataVersion;
    
    /**
     * 荷送人マスタデータバージョン
     */
    private String niokurininDataVersion;

    /**
     * 検索結果一覧データ
     */
    private Map<String, Object> searchResult;
    
    /**
     * 履歴取得キー
     */
    private Map<String, Object> rirekiSearchKey;

    public void eiMeiSelect() {
        if(dtlEibunTorokuAri != null && dtlEibunTorokuAri.length > 0){
            dtlEiMei = true;
        }else{
            dtlEiMei = false;
        };
    }
}
