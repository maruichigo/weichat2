/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mwb;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.beans.common.TemplateBean;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.file.CSVDto;
import jp.co.kintetsuls.forms.mwb.Mwb031Form;
import jp.co.kintetsuls.utils.DateUtils;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * VOID入力画面
 *
 * @author 許 彭戈ヤン (MBP)
 * @version 2019/1/29 新規作成
 */
@ManagedBean(name = "mwb031")
@ViewScoped
@Data
public class Mwb031Bean extends AbstractBean {

    /**
     * タイトル
     */
    private final String TITLE = "VOID入力";

    /**
     * ダウンロードファイル名
     */
    private final String FILE_NAME = "VOID運送情報報告書";

    /**
     * 画面URL
     */
    private String url;

    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

    /**
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    /**
     * ファイルダウンロード
     */
    @ManagedProperty(value = "#{templeteBean}")
    private TemplateBean templeteBean;

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messageProperty;

    /**
     * 画面フォーム
     */
    @ManagedProperty(value = "#{mwb031Form}")
    private Mwb031Form mwb031Form;
    
    /**
     * 画面フォーム
     */
    @ManagedProperty(value = "#{mwb031Form}")
    private Mwb031Form templateForm;

    /**
     * 画面共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * 検索シーケンス処理共通
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;

    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(
            new Object() {}.getClass().getEnclosingClass().getName());

    /**
     * スクリーンコード：MWB031
     */
    private static final String SC_CD_MWB031 = "MWB031_SCREEN";

    /**
     * 定数：検索件数
     */
    private static final String FUNC_CODE_SEARCH_COUNT = "mwb031-search-count";

    /**
     * 定数：検索結果
     */
    private static final String FUNC_CODE_SEARCH = "mwb031-search";

    /**
     * 定数：配布先営業所取得
     */
    private static final String FUNC_CODE_GET_HAIFUSAKI_EIGYOSHO = "mwb031-get-haifu-saki-eigyosho";

    /**
     * 定数：登録処理
     */
    private static final String FUNC_CODE_INSERT = "mwb031-insert";

    /**
     * 定数：VOID取消
     */
    private static final String FUNC_CODE_VOID_TORIKESHI = "mwb031-void-torikeshi";

    /**
     * 定数：再検索Button取得キー
     */
    private static final String CONST_MWB031_SEARCH = "search_mwb031";

    /**
     * 定数：画面項目保持キー
     */
    private static final String CONST_MWB031_FORM = "mwb031Form";

    /**
     * 定数：MasterInfo取得キー
     */
    private static final String CONST_MWB031_MASTER = "mwb031";

    /**
     * 定数：一覧のデータテーブルID
     */
    private static final String DATA_TABLE_ID = "tablesorter_mwb031";

    /**
     * 文字列：選択登録
     */
    private static final String SELECT_TOROKU = "1";

    /**
     * 文字列：選択検索
     */
    private static final String SELECT_SEARCH = "2";

    /**
     * 文字列：日付フォマート
     */
    private static final String DATE_FORMAT = "yyyy/MM/dd";

    /**
     * 文字列：VOID年月フォマート
     */
    private static final String VOID_DATE_FORMAT = "yyyy/MM";

    /**
     * 文字列：VOID登録
     */
    private static final String VOID_TOROKU = "VOID登録";

    /**
     * 文字列：VOID取消
     */
    private static final String VOID_CANCEL = "VOID取消";

    /**
     * 文字列：MAWB番号
     */
    private static final String MAWB_BANGO = "MAWB番号";

    /**
     * メッセージリスト
     */
    List<MessageModuleBean> msgList = new ArrayList<>();
    
    /**
     * 登録と削除結果リスト
     */
    List<Map<String, Object>> resultList = new ArrayList<>();
    

    /**
     * コンストラクタ
     */
    public Mwb031Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId　メニューID
     * @param prevScreen 遷移元画面ID
     * @param backFlag 戻るフラグ
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            // パンくず追加
            breadBean.push(TITLE, Cnst.SCREEN.MWB031_SCREEN.name(), this);

            // システムマスタ取得する
            pageCommonBean.getMasterInfo(CONST_MWB031_MASTER);

            // 初期値設定
            mwb031Form.setConSelectSagyoKubun(SELECT_TOROKU);
            mwb031Form.setJokenTitle("登録条件");

            // VOID日付初期値取得
            Date sysdate = new Date();
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DATE_FORMAT);
            String dateFormat = simpleDateFormat.format(sysdate);
            mwb031Form.setConInsertVoidHizuke(dateFormat);

            // 検索シーケンス処理を初期化する
            searchHelpBean.regSearchHelp(DATA_TABLE_ID,
                    s -> {return getRecordCount(false);},
                    s -> {search(); return null;},
                    s -> {if (!searchCheck()) {
                            return "FALSE";
                        } else {
                        return "TRUE";}});
            searchHelpBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);

            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(航空会社リスト)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_MS_KOKU_GAISHA);

            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(営業所リスト)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_VW_EIGYOSHO, new AutoCompOptionBean("全て", "all"));

            // 前回の記録をクリアする
            this.searchClear();
            this.torokuClear();
            mwb031Form.setSearchResult(null);
            mwb031Form.setSearchResultSelectable(null);
            mwb031Form.setSelectedSearchResult(null);

            // 戻ってきた場合
            Mwb031Form preForm = (Mwb031Form) pageCommonBean.getPageInfo(CONST_MWB031_FORM);
            if (backFlag && preForm != null) {
                // 検索パラメータがある場合、再検索に設定する
                PageCommonBean.simpleCopy(preForm, mwb031Form);
                // 再検索を実施する
                pageCommonBean.searchAgain(CONST_MWB031_SEARCH);
                // 進んできた場合
            } else {
                Flash flash = pageCommonBean.getPageParam();
                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_MWB031_FORM) != null) {
                    PageCommonBean.simpleCopy(flash.get(CONST_MWB031_FORM), mwb031Form);
                    // 再検索を実施する
                    pageCommonBean.searchAgain(CONST_MWB031_SEARCH);
                }
            }

            // ダウンロードシーケンス初期化
            templeteBean.setDataSize(DATA_TABLE_ID, (id -> {return getRecordCount(true);}));
            templeteBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);
            templeteBean.setSubFlg(false);
            templeteBean.setTilte(FILE_NAME);
            templeteBean.regDownloadFucntion(DATA_TABLE_ID, getHeader(), (id -> {return getVOIDList(true);}));
            templeteBean.regBeforeDownFucntion(DATA_TABLE_ID, (comment -> {return beforeDown(comment); }));
            templeteBean.setSearchResult(DATA_TABLE_ID, (id -> {return getSearchResult();}));

            // component初期化とユーザ権限により制御を設定する
            pageCommonBean.setAuthControll(mwb031Form, SC_CD_MWB031, true);

        } catch (IllegalAccessException | InvocationTargetException | ParseException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    /**
     * メニュークリック処理
     *
     * @param menuId メニューID
     * @param nextScreenId 遷移先画面ID
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreenId) {
        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移
        url = forward(nextScreenId, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック処理
     *
     * @param nextScreenId 遷移先画面ID
     * @param breadIndex パンくずのインデックス
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreenId, int breadIndex) {
        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        url = forward(nextScreenId, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック処理
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {

        return authConfBean.logout();
    }
    
    /**
     * カウント処理
     * 
     * @param downloadFlg ダウンロードフラグ
     * @return 検索件数
     */
    public Long getRecordCount(boolean downloadFlg) {
        
        // 前回の記録をクリアする
        Map<String, Object> mapRec = new LinkedHashMap();
        mapRec.put("hideFlg", "hideRow");
        List<Map<String, Object>> mapList = new ArrayList();
        mapList.add(mapRec);
        mwb031Form.setSearchResult(mapList);
        mwb031Form.setSearchResultSelectable(new ReportListDataModel(mwb031Form.getSearchResult()));
        mwb031Form.setSelectedSearchResult(null);
        
        // パラメータを設定
        Map<String, Object> params = getParamas(downloadFlg);
        // DBをアクセス
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH_COUNT);
        // 件数を取得
        Long kensu = Long.valueOf(serviceInterfaceBean.getJson());
        
        if (!downloadFlg) {

            // 検索部のステータスを変更する
            pageCommonBean.setSerchConDisabled(mwb031Form);

            // 検索条件保存
            pageCommonBean.savePageInfo(CONST_MWB031_FORM, mwb031Form);
        }
        return kensu;
    }

    /**
     * 検索処理
     *
     * @throws java.text.ParseException
     */
    public void search() throws ParseException {

        // 選択リストを初期化する
        mwb031Form.setSelectedSearchResult(new ArrayList<>());
        mwb031Form.setSearchResultSelectable(null);

        // VOID入力検索を行う
        List<Map<String, Object>> recordList = getVOIDList(false);

        // 配色定義を設定する
        templeteBean.setDataList(recordList);      

        // DBをアクセスする
        pageCommonBean.setDatalist(DATA_TABLE_ID, recordList);    
        if(recordList != null && recordList.size() > 0) {
           mwb031Form.setSearchResultSelectable(new ReportListDataModel(recordList));
        }
        mwb031Form.setSearchResult(recordList);
        
        // 検索部のステータスを変更する
        pageCommonBean.setSerchConDisabled(mwb031Form);
        

        // 検索条件を保存する
        pageCommonBean.savePageInfo(CONST_MWB031_FORM, mwb031Form);

    }
    
     /**
     * 検索処理チェック
     * 
     * @return 正常/異常
     */
    public boolean searchCheck() {
        
        // チェックフラグ
        boolean checkFlg = true;
        
        // 発券営業所チェック
        if(mwb031Form.getConSearchHakkenEigyoshoCd() == null) {
            messageProperty.messageToArea(MessagePropertyBean.SEVERITY_ERROR, 
                    MessageCnst.COME0003, "searchForm:eigyoshoSearch:eigyoshoSearchText", "発券営業所" );
           checkFlg = false;
        } else if(mwb031Form.getConSearchHakkenEigyoshoCd().getValue().trim().isEmpty()) {
            messageProperty.messageToArea(MessagePropertyBean.SEVERITY_ERROR, 
                    MessageCnst.COME0003, "searchForm:eigyoshoSearch:eigyoshoSearchText", "発券営業所" );
            checkFlg = false;
        }
         // 航空会社チェック
        if(mwb031Form.getConSearchKokuGaishaLetterCd() == null) {
            messageProperty.messageToArea(MessagePropertyBean.SEVERITY_ERROR, 
                    MessageCnst.COME0003, "searchForm:airCompanySearch:airCompanySearchText", "航空会社" );
            checkFlg = false;
        } else if (mwb031Form.getConSearchKokuGaishaLetterCd().getValue().trim().isEmpty()) {
            messageProperty.messageToArea(MessagePropertyBean.SEVERITY_ERROR, 
                    MessageCnst.COME0003, "searchForm:airCompanySearch:airCompanySearchText", "航空会社" );
            checkFlg = false;
        }
        // VOID年月チェック
        if (mwb031Form.getConSearchVoidNengetsu() == null) {
            messageProperty.messageToArea(MessagePropertyBean.SEVERITY_ERROR,
                    MessageCnst.COME0003, "searchForm:VOIDDateSearch:VOIDDateSearchText", "VOID年月");
            checkFlg = false;
        } else {
            try {
                DateUtils.parse(mwb031Form.getConSearchVoidNengetsu(), "yyyy/MM");
            } catch (SystemException ex) {
                messageProperty.messageToArea(MessagePropertyBean.SEVERITY_ERROR,
                        MessageCnst.COME0010, "searchForm:VOIDDateSearch:VOIDDateSearchText", "VOID年月");
                checkFlg = false;
            }
        }
        
        return checkFlg;
    }

    /**
     * 検索条件変更処理
     *
     */
    public void searchChange() {

        // 検索部のステータスを変更する
        mwb031Form.setConSelectSagyoKubun(SELECT_SEARCH);
        pageCommonBean.setSerchConEnabled(mwb031Form);

    }

    /**
     * 検索クリア
     *
     */
    public void searchClear() {

        // 検索部の条件クリア
        mwb031Form.setConSearchHakkenEigyoshoCd(null);
        mwb031Form.setConSearchKokuGaishaLetterCd(null);
        mwb031Form.setConSearchVoidNengetsu(null);

        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mwb031Form);
        pageCommonBean.setBtnSearchChangeVisible(false);
        pageCommonBean.setBtnSearchVisible(Boolean.TRUE);
        mwb031Form.setConSelectSagyoKubun(SELECT_SEARCH);
        
    }



    /**
     * 登録処理
     *
     */
    public void toroku() {

        // エラーメッセージを格納する変数の初期化を行う
        msgList = new ArrayList();
        boolean error = false;

       // 航空会社必須チェック
        if (mwb031Form.getConInsertKokuGaishaLetterCd() == null) {
            // エラーの場合、処理終了
            messageProperty.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003,
                    "searchForm:letterCd:airCompanyToroku", "航空会社" );
            error = true;
        }
        
        // MAWB番号必須チェック
        if (mwb031Form.getConInsertMawbBango() == null || "".equals(mwb031Form.getConInsertMawbBango().trim())) {
            // エラーの場合、処理終了
            messageProperty.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003,
                    "searchForm:MAWBNo:MAWBNoInput", MAWB_BANGO );
            error = true;
            
            //  7DRチェック
        } else if (!sevenDRCheck(mwb031Form.getConInsertMawbBango())) {
            // エラーの場合、処理終了
            messageProperty.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0007,
                    "searchForm:MAWBNo:MAWBNoInput", MAWB_BANGO );
            error = true;
        }
        
        // 理由必須チェック
        if (mwb031Form.getConInsertRiyu()== null || "".equals(mwb031Form.getConInsertRiyu().trim())) {          
            messageProperty.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003,
                    "searchForm:riyu:riyuInput", "理由" );
            error = true;
        }
        
        if (error) {
            return;
        }

        // 登録・更新処理を行う
        List<Map<String, Object>> serviceInterfaceBean = voidToroku();

        // 登録結果なし場合
        if (serviceInterfaceBean == null) {
            messageProperty.messageList(msgList);
            // 登録結果あり場合
        } else {
            setTorokuIchiranColor(serviceInterfaceBean);
            resultList.addAll(0, serviceInterfaceBean);
            pageCommonBean.setDatalist(DATA_TABLE_ID, resultList);
            mwb031Form.setSearchResultSelectable(new ReportListDataModel(resultList));

            MessageModuleBean message =  messageProperty.createMessageModule(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, VOID_TOROKU);
            msgList.add(message);
            messageProperty.messageList(msgList);
        }
    }
    
    /**
     * 登録配色定義を設定する処理
     *
     * @param recordList レコードリスト
     */
    public void setTorokuIchiranColor(List<Map<String, Object>> recordList) {
        // 配色定義の判定を行う
        int row = 0;
        // 検索レコード分でループする
        if (recordList != null && recordList.size() > 0) {
            for (Map<String, Object> record : recordList) {
                if (row == 0) {
                }
            }
        }
    }

    /**
     * VOID取消
     *
     */
    public void voidTorikeshi() {

        // エラーメッセージを格納する変数の初期化を行う
        msgList = new ArrayList();
        
        int errorCount = 0;
        
        // 航空会社必須チェック
        if (mwb031Form.getConInsertKokuGaishaLetterCd() == null) {
            // エラーの場合、処理終了
            messageProperty.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003,
                    "searchForm:letterCd:airCompanyToroku" ,"航空会社");
            errorCount++;
        }
        
        // MAWB番号必須チェック
        if (mwb031Form.getConInsertMawbBango() == null || "".equals(mwb031Form.getConInsertMawbBango().trim())) {
            // エラーの場合、処理終了
            messageProperty.messageToArea(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0003,
                    "searchForm:MAWBNo:MAWBNoInput" ,"MAWB番号");
            errorCount++;
        } 
        
        
        
        if(errorCount != 0) {
            return;
        }
        
        // 削除処理を行う
        List<Map<String, Object>> serviceInterfaceBean = voidDelete();

        // 取消チェック
        if (serviceInterfaceBean == null || serviceInterfaceBean.isEmpty()) {
            // エラーあり場合
             MessageModuleBean message = messageProperty.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.MWBE0002, mwb031Form.getConInsertMawbBango());
             msgList.add(message);
             messageProperty.messageList(msgList);
            // エラーなし場合
        } else {
            setTorikeshiIchiranColor(serviceInterfaceBean);
            resultList.addAll(0, serviceInterfaceBean);

            // 取消結果を設定する
            pageCommonBean.setDatalist(DATA_TABLE_ID, resultList);
            mwb031Form.setSearchResultSelectable(new ReportListDataModel(resultList));
            MessageModuleBean message = messageProperty.createMessageModule(
                    MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0011, VOID_CANCEL);
            msgList.add(message);
            messageProperty.messageList(msgList);
        }
    }
    
    /**
     * 削除配色定義を設定する処理
     *
     * @param recordList レコードリスト
     */
    public void setTorikeshiIchiranColor(List<Map<String, Object>> recordList) {
        // 配色定義の判定を行う
        int row = 0;
        // 検索レコード分でループする
        if (recordList != null && recordList.size() > 0) {
            for (Map<String, Object> record : recordList) {
                if (row == 0) {
                    pageCommonBean.setIchiranRowColor(record, "1");
                }
            }
        }
    }

    /**
     * 配布先営業所取得
     *
     */
    public void haifuSakiEigyosho() {

        // 配布先営業所取得
        Map<String, Object> serviceInterfaceBean = getHaifuSakiEigyosho(mwb031Form.getConInsertMawbBango());

        // MAWB番号対応配布先営業所なし場合
        if (serviceInterfaceBean == null || serviceInterfaceBean.isEmpty()) {

            // エラーメッセージを表示する
            messageProperty.message(MessagePropertyBean.SEVERITY_WARN, MessageCnst.COMF0002);

            // 配布先営業所コードを設定する
            mwb031Form.setConInsertHaifusakiEigyoshoCd("");

            // 配布先営業所名を設定する
            mwb031Form.setConInsertHaifusakiEigyoshoMei("");

            // 作業区分を設定する
            mwb031Form.setConSelectSagyoKubun(SELECT_TOROKU);

            // MAWB番号対応配布先営業所あり場合
        } else {

            // 配布先営業所コードを設定する
            mwb031Form.setConInsertHaifusakiEigyoshoCd(serviceInterfaceBean.get("HAIFUSAKI_EIGYOSHO_CD").toString());

            // 配布先営業所名を設定する
            mwb031Form.setConInsertHaifusakiEigyoshoMei(serviceInterfaceBean.get("EIGYOSHO_MEI").toString());

            // 作業区分を設定する
            mwb031Form.setConSelectSagyoKubun(SELECT_TOROKU);
        }
    }
    
     /**
     * 配布先営業所取得
     *
     */
    public void displayChange() {
        if ("1".equals(mwb031Form.getConSelectSagyoKubun())) {
            mwb031Form.setJokenTitle("登録条件");
        } else {
            mwb031Form.setJokenTitle("検索条件");
        }     
    }

    /**
     * 登録クリア
     *
     * @throws java.text.ParseException
     */
    public void torokuClear() throws ParseException {

        // 作業区分を「登録」設定する
        mwb031Form.setConSelectSagyoKubun(SELECT_TOROKU);

        // VOID日付を取得する
        Date sysdate = new Date();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DATE_FORMAT);
        String dateFormat = simpleDateFormat.format(sysdate);

        // 登録部の条件をクリアする
        mwb031Form.setConInsertKokuGaishaLetterCd(null);
        mwb031Form.setConInsertMawbBango(null);
        mwb031Form.setConInsertHaifusakiEigyoshoCd(null);
        mwb031Form.setConInsertHaifusakiEigyoshoMei(null);
        mwb031Form.setConInsertVoidHizuke(dateFormat);

        mwb031Form.setConInsertRiyu(null);

    }

    /**
     * ダウンロード理由を記録する処理
     *
     * @param comment 理由コメント
     * @return 正常／異常
     * @throws Exception
     */
    public boolean beforeDown(String comment) throws Exception {

        // ダウンロード理由を記録する
        System.out.println(comment);

        return true;
    }

    /**
     * CSVファイルのタイトルを設定する処理
     *
     * @return 画面タイトル
     */
    public List<CSVDto> getHeader() {

        // CSVファイルのタイトルを設定する
        List<CSVDto> header = new ArrayList<>();

        // 航空会社
        header.add(new CSVDto("航空会社", "listKokuGaisha"));
        // MAWB番号
        header.add(new CSVDto("MAWB番号", "listMawbBango"));
        // 発券営業所
        header.add(new CSVDto("発券営業所", "listHakkenEigyosho"));
        // 配布先営業所
        header.add(new CSVDto("配布先営業所", "listHaifusakiEigyosho"));
        // VOID日付
        header.add(new CSVDto("VOID日付", "listVoidHizuke"));
        // 理由
        header.add(new CSVDto("理由", "listRiyu"));

        // 取得値を返却する
        return header;
    }

    /**
     * 7DRチェック
     *
     * @param value MAWB番号
     * @return チェック結果
     */
    private boolean sevenDRCheck(Object value) {
        boolean isFormat = false;
        if (value != null && value.toString().length() == 8) {
            // MAWB番号の上7桁
            int maeNumber = Integer.valueOf(value.toString().substring(0, 7));
            // MAWB番号の下1桁
            int lastNumber = Integer.valueOf(value.toString().substring(7, 8));
            // MAWB番号の上7桁を7で割り、余りを求める。(余り = 7DR)
            int mod = maeNumber % 7;
            // 7DRと、MAWB番号の下1桁が一致するかをチェックする。
            if (mod == lastNumber) {
                isFormat = true;
            }
        }
        return isFormat;
    }
    
    
    
    /**
     * パラメータを設定する
     * 
     * @param downloadFlg ダウンロードフラグ
     * @return 検索結果パラメータ
     */
    private Map<String, Object> getParamas(boolean downloadFlg) {
        
        // パラメータを設定する
        Map<String, Object> params = new HashMap<>();
        
        Mwb031Form tempForm = mwb031Form;
        
        if (downloadFlg) {
            tempForm = (Mwb031Form)pageCommonBean.getPageInfo(CONST_MWB031_FORM);
        }
        
        // 全営業所検索
        if (pageCommonBean.getMasterInfo().getAllEigyoshoSearch() != null) {
            params.put("allEigyoshoSearch", pageCommonBean.getMasterInfo().getAllEigyoshoSearch());
        }
        // ログインユーザー所属営業所
        params.put("loginUserShozokuEigyosho", authConfBean.getLoginUserShozokuEigyosho());
        
        // 発券営業所
        params.put("conSearchHakkenEigyoshoCd", tempForm.getConSearchHakkenEigyoshoCd().getValue());

        // VOID年月
        params.put("conSearchVoidNengetsu", tempForm.getConSearchVoidNengetsu());

        // 航空会社リターコード
        params.put("conSearchKokuGaishaLetterCd", tempForm.getConSearchKokuGaishaLetterCd().getValue());
        
             
        // 発券営業所
        if (tempForm.getConSearchHakkenEigyoshoCd() != null) {
            params.put("conSearchHakkenEigyoshoCd", tempForm.getConSearchHakkenEigyoshoCd().getValue());
        }
        // VOID年月
        if (tempForm.getConSearchVoidNengetsu()!= null) {
            params.put("conSearchVoidNengetsu", tempForm.getConSearchVoidNengetsu());
        }
        // 航空会社リターコード
        if (tempForm.getConSearchKokuGaishaLetterCd()!= null) {
            params.put("conSearchKokuGaishaLetterCd", tempForm.getConSearchKokuGaishaLetterCd().getValue());
        }
        templateForm = tempForm;
        return params;
    }



    /**
     * DBから検索結果取得
     *
     * @return 検索結果
     */
    private List<Map<String, Object>> getVOIDList(boolean downloadFlg) throws ParseException {

        // 検索条件
        Map<String, Object> params = getParamas(downloadFlg);

        try {
            // DBをアクセスする
            ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH);
            ObjectMapper mapper = new ObjectMapper();
            mwb031Form.setSearchResult(mapper.readValue(serviceInterfaceBean.getJson(), List.class));
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
        templeteBean.setMwb031Form(templateForm);
        // 検索結果を返却する
        return mwb031Form.getSearchResult();

    }

    /**
     * DBから配布先営業所取得
     *
     * @param MawbBango MAWB番号
     * @return 配布先営業所
     */
    private Map<String, Object> getHaifuSakiEigyosho(String MawbBango) {

        // 検索条件
        Map<String, Object> params = new HashMap<>();

        // MAWB番号
        params.put("conInsertMawbBango", MawbBango);

        // DBをアクセスする
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, FUNC_CODE_GET_HAIFUSAKI_EIGYOSHO);

        // 検索結果なしの場合
        if (serviceInterfaceBean.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            return null;
            // 検索結果ありの場合
        } else {
            ObjectMapper mapper = new ObjectMapper();

            try {
                mwb031Form.setSingleResult(mapper.readValue(serviceInterfaceBean.getJson(), Map.class));
            } catch (IOException ex) {
                LOGGER.error(ex.getMessage(), ex);
                return null;
            }
            return mwb031Form.getSingleResult();
        }
    }

    /**
     * DBへVOID入力を登録する処理
     *
     * @return 登録結果
     */
    private List<Map<String, Object>> voidToroku() {

        // 登録パラメータ
        Map<String, Object> param = new HashMap<>();

        // 航空会社リターコード
        param.put("conInsertKokuGaishaLetterCd", mwb031Form.getConInsertKokuGaishaLetterCd().getValue());

        // MAWB番号
        param.put("conInsertMawbBango", mwb031Form.getConInsertMawbBango());

        // 配布先営業所コード
        param.put("conInsertHaifusakiEigyoshoCd", mwb031Form.getConInsertHaifusakiEigyoshoCd());

        // VOID日付
        param.put("conInsertVoidHizuke", mwb031Form.getConInsertVoidHizuke());

        // 理由
        param.put("conInsertRiyu", mwb031Form.getConInsertRiyu());

        // DBをアクセスする
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(param, FUNC_CODE_INSERT);

        ObjectMapper mapper = new ObjectMapper();

        // エラーの場合
        if (ServiceInterfaceBean.PROCESS_STATUS_ERROR == serviceInterfaceBean.getStatusCode()) {
            for (int i = 0; i < serviceInterfaceBean.getMessages().size(); i++) {
                MessageModuleBean message = messageProperty.createMessageModule(
                        serviceInterfaceBean.getMessages().get(i)[0],
                        serviceInterfaceBean.getMessages().get(i)[1],
                        serviceInterfaceBean.getMessages().get(i)[2]);
                msgList.add(message);
            }
            return null;
            // エラーなしの場合
        } else {
            try {
                mwb031Form.setSearchResult(mapper.readValue(serviceInterfaceBean.getJson(), List.class));
            } catch (IOException ex) {
                LOGGER.error(ex.getMessage(), ex);
                return null;
            }
            return mwb031Form.getSearchResult();
        }
    }

    /**
     * DBデータ物理削除
     *
     * @return 削除結果
     */
    private List<Map<String, Object>> voidDelete() {
        Map<String, Object> params = new HashMap<>();

        // 航空会社リターコード
        params.put("conInsertKokuGaishaLetterCd", mwb031Form.getConInsertKokuGaishaLetterCd().getValue());

        // MAWB番号
        params.put("conInsertMawbBango", mwb031Form.getConInsertMawbBango());

        // 配布先営業所コード
        params.put("conInsertHaifusakiEigyoshoCd", mwb031Form.getConInsertHaifusakiEigyoshoCd());

        // DBをアクセスする
        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, FUNC_CODE_VOID_TORIKESHI);

        ObjectMapper mapper = new ObjectMapper();

        // 検索結果ない場合
        if (serviceInterfaceBean == null || serviceInterfaceBean.getJson().isEmpty()) {
            return null;

            // 検索結果あり場合
        } else {
            try {
                mwb031Form.setSearchResult(mapper.readValue(serviceInterfaceBean.getJson(), List.class));
            } catch (IOException ex) {
                LOGGER.error(ex.getMessage(), ex);
                return null;
            }
            // 検索結果を設定する
            return getSearchResult();
        }

    }
    
    private List<Map<String, Object>> getSearchResult(){
        return mwb031Form.getSearchResult();               
    }
}
