/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mst;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.annotation.NotEmpty;
import jp.co.kintetsuls.beans.common.annotation.NotNull;
import lombok.Data;

/**
 * 仕入予定一覧フォーム
 *
 * @author 廖鈺 (MBP)
 * @version 2019/1/24 新規作成
 */
@ManagedBean(name = "mst091Form")
@ViewScoped
@Data
public class Mst091Form implements  Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 営業所コード value
     */
    private AutoCompOptionBean conEigyoshoCd;
    
    /**
     * 営業所コード Disabled
     */
    private boolean conEigyoshoCdDisabled;
    
    /**
     * 仕入先コード（Axis) value
     */
    private AutoCompOptionBean conShiiresakiCdAxis;

    /**
     * 仕入先コード（Axis) Disabled
     */
    private boolean conShiiresakiCdAxisDisabled;
    
    /**
     *仕入先コード(SS)value
     */
    private String conShiiresakiCdSS;
    
    /**
     * 仕入先コード(SS) Disabled
     */
    private boolean conShiiresakiCdSSDisabled;
    
    /**
     *  仕入区分 value 
     */
    private AutoCompOptionBean conShiireKbn;
    
    /**
     * 仕入区分 Disabled
     */
    private boolean conShiireKbnDisabled;
    
    /**
     * 世代検索条件
     */
    @NotEmpty(name = "世代検索条件")
    private String[] conSedaiKensakuJoken;
    
    /**
     * 世代検索条件 Disabled
     */
    private boolean conSedaiKensakuJokenDisabled;
    
    /**
     * 適用日
     */
    @NotNull(message = "{COME0028}", checkTime = "適用日指定選択時", name = "適用日")
    private String conTekiyobi;
    
    /**
     * 適用日 Disabled
     */
    private boolean conTekiyobiDisabled;
    
    /**
     * 削除済のみ
     */
    private String[] conSakujoSumiNomi;
    
    /**
     * 削除済のみ Disabled
     */
    private boolean conSakujoSumiNomiDisabled;
    
    /**
     * 編集Disabled
     */
    private boolean btnEditeDisabled;

    /***
     * 件数
     */
    private long kensu;
    
    /**
     * 検索結果一覧データ
     */
    private List<Map<String, Object>> searchResult;

    /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;

    /**
     * 選択された結果
     */
    private List<Map<String, Object>> selectedSearchResult;
    
    /**
     * リンクされた結果
     */
    private Map<String, Object> linkSearchResult;

}
