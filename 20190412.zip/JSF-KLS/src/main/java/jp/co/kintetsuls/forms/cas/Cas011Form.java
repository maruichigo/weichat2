/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.cas;

import java.util.List;
import java.util.Map;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.forms.common.LabelValueForm;
import lombok.Data;

/**
 * 現金回収入力 フォーム
 *
 * @author 作成者 (MBP)
 * @version 2019/1/29 新規作成
 */
@javax.faces.bean.ManagedBean(name = "cas011Form")
@ViewScoped
@Data
public class Cas011Form {

    /**
     * 営業所
     */
    private String k11;

    /**
     * 営業所名
     */
    private String k12;

    /**
     * 回収日
     */
    private String k13;

    /**
     * 入金件数
     */
    private String k19;

    /**
     * 合計金額
     */
    private String k20;

    /**
     * 検索結果一覧選択できる
     */
    private ReportListDataModel searchResultSelectable;

    /**
     * 選択された結果
     */
    private List<Map<String, String>> selectedSearchResult;


}
