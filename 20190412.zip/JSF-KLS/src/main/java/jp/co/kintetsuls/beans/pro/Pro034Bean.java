/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.beans.pro;

import java.util.Date;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.cnst.Cnst;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.sharedsys.beans.base.BaseBean;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * ロジ元データ修正
 *
 * @author xupenggeyang
 */
@ManagedBean(name = "pro034")
@ViewScoped
@Data
public class Pro034Bean extends BaseBean {

    String TITLE = "ロジ元データ修正";

    private String url;

    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    private RestfullService rest;

    private static final Logger logger = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    private String kokyakuCd = "test";

    private String kokyakuMei = "test";

    private String requestKomoku1 = "";

    private String requestKomoku2 = "";

    private String requestKomoku3 = "";
    
    private Date dateFrom = new Date();
    
    private Date dateTo = new Date();
    
    private String tanka = "";
    
    private String tani = "";

    @Override
    public void init(String menuId, String prevScreen, boolean backFlg) {
        try {
            // パンくず追加
            breadBean.push("ロジ元データ修正", Cnst.SCREEN.PRO034_SCREEN.name(), this);
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }
    }

    @Override
    public String menuClick(String menuId, String nextScreen) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String logoutClick() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
