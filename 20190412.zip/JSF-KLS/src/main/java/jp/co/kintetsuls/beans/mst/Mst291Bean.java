/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.mst;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Level;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.Flash;
import jp.co.kintetsuls.beans.common.AbstractBean;
import jp.co.kintetsuls.beans.common.AutoCompleteViewBean;
import jp.co.kintetsuls.beans.common.FileBean;
import jp.co.kintetsuls.beans.common.ListCheckBean;
import jp.co.kintetsuls.beans.common.MessageModuleBean;
import jp.co.kintetsuls.beans.common.MessagePropertyBean;
import jp.co.kintetsuls.beans.common.PageCommonBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.RirekiSyosaiBean;
import jp.co.kintetsuls.beans.common.SearchHelpBean;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.file.CSVDto;

import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.forms.mst.Mst291Form;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.kintetsuls.utils.DateUtils;
import jp.co.kintetsuls.utils.NumberUtils;
import jp.co.kintetsuls.utils.StrUtils;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 料金項目マスタ一覧画面
 *
 * @author 呉俊 (MBP)
 * @version 2019/1/24 新規作成
 */
@javax.faces.bean.ManagedBean(name = "mst291")
@ViewScoped
@Data
public class Mst291Bean extends AbstractBean {

    private final String titleName = "料金項目マスタ一覧";
    
    /**
     * パンくず名とCSVタイトル
     */
    private final String TITLE = "料金項目マスタ";   
    
    /**
     * 画面URL
     */
    private String url;

    /**
     * パンくずリスト
     */
    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;
    
     /**
     *
     * ユーザ権限
     */
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authorityConfBean;

    /**
     * ファイルダウンロード
     */
    @ManagedProperty(value = "#{fileBean}")
    private FileBean fileBean;

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messagePropertyBean;

    /**
     * 画面項目保持
     */
    @ManagedProperty(value = "#{mst291Form}")
    private Mst291Form mst291Form;

    /**
     * 共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * 検索シーケンス処理共通
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;

    /**
     * 履歴一覧処理共通
     */
    @ManagedProperty(value = "#{rirekisyosai}")
    private RirekiSyosaiBean rirekiSyosaiBean;

    /**
     * 一覧単項目チェック共通
     */
    @ManagedProperty(value = "#{listCheckBean}")
    private ListCheckBean listCheckBean;
    
    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(
            new Object() {}.getClass().getEnclosingClass().getName());
    
    /**
     * ScreenCode：MST291.
     */
    private static final String SC_CD_MST291 = "MST291_SCREEN";
    
    /**
     * 定数：一覧のDataTableのID.
     */
    private static final String DATA_TABLE_ID = "tablesorter_mst291";
    
    /**
     * 定数：検索FUNC_CODE.
     */
    private static final String SEARCH_FUNC_CODE = "mst291_search";
            
    /**
     * 定数：更新FUNC_CODE.
     */
    private static final String FUNC_CODE_INSERT_UPDATE = "mst291_update";
    
    /**
     * 定数：登録の重複チェックファンクションコード
     */
    private static final String FUNC_CODE_INSERT_UPDATE_CHECK = "mst291-insert-update-check";
    
    /**
     * 定数：行削除FUNC_CODE.
     */
    private static final String MST291_DELETE = "mst291_delete";    
    
    /**
     * 定数：削除の存在チェックファンクションコード
     */
    private static final String FUNC_CODE_DELETE_EXIST = "mst291-delete-exist";
    
     /**
     * 定数：検索件数取得FUNC_CODE.
     */
    private static final String FUNC_CODE_SEARCH_KENSU = "mst291_kensu";
    
    /**
     * 定数：画面項目保持key.
     */
    private static final String CONST_MST291_FORM = "mst291Form";
    
     /**
     * 定数：MasterInfo取得key.
     */
    private static final String CONST_MST291_MASTER = "mst291";

    /**
     * 定数：再検索Button取得キー
     */
    private static final String CONST_MST291_SEARCH = "search_mst291"; 
    
    /**
     * 履歴テーブル検索キー.
     */
    private Map<String, Object> rirekiSearchKey;

    // ワーク.メッセージリスト
    List<MessageModuleBean> msgList = new ArrayList<>(); 
    
    /**
     * コンストラクタ
     */
    public Mst291Bean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId
     * @param prevScreen
     * @param backFlag
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {
        try {
            
            // パンくず追加
            breadBean.push(TITLE, SCREEN.MST291_SCREEN.name(), this);
 
            // マスタ内容取得
            pageCommonBean.getMasterInfo(CONST_MST291_MASTER);
            
            // 検索シーケンス処理を初期化する
            searchHelpBean.regSearchHelp(DATA_TABLE_ID,
                    s -> {return getRecordCount();},
                    s -> {search(); return null;},
                    null);
            searchHelpBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);
 
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(料金項目グループマスタ取得)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_MS_RYOKIN_KOMOKU_GROUP);
            
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(処理科目コード取得)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_SHORI_KAMOKU_CD);
            
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(補助科目コード取得)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_HOJO_KAMOKU_CD);
            
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(卸計上箇所)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_OROSHI_KEIJO_KASHO);
            
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(卸科目コード取得)共通マスタ式样书中命名已修改(后台尚未修改)
            autoCompleteViewBean.getComMsDatas(MsCnst.COM_GET_OROSHI_KAMOKU_CD);
            
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(輸送売上セット先)
            autoCompleteViewBean.getMsKbn(MsCnst.YUSOURIAGE_SET_SAKI);
           
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(プルーフ用集約項目)
            autoCompleteViewBean.getMsKbn(MsCnst.PROOF_YOU_SHUYAKU_KOMOKU);
            
            // DBからマスタの内容を取得し、該当する項目の選択肢に設定する(税区分)
            autoCompleteViewBean.getMsKbn(MsCnst.TAX_TYPE);
            
            // 前回の記録をクリアする
            this.clear();
            mst291Form.setSearchResult(null);
            mst291Form.setSearchResultSelectable(null);
            mst291Form.setSelectedSearchResult(null);
            
            // 戻ってきた場合
            Mst291Form preForm = (Mst291Form) pageCommonBean.getPageInfo(CONST_MST291_FORM);
            if (backFlag && preForm != null) {
                PageCommonBean.simpleCopy(preForm, mst291Form);
                // 再検索を実施する
                pageCommonBean.searchAgain(CONST_MST291_SEARCH);
            } else {
                // 進んできた場合
                Flash flash = pageCommonBean.getPageParam();
                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_MST291_FORM) != null) {
                    PageCommonBean.simpleCopy(flash.get(CONST_MST291_FORM), mst291Form);
                    // 再検索を実施する
                    pageCommonBean.searchAgain(CONST_MST291_SEARCH);
                }
            }
            
            // ダウンロードシーケンスを初期化する
            fileBean.setDataSize(DATA_TABLE_ID,
                    (id -> {return getRecordCount();}));
            
            fileBean.getSettings().put(DATA_TABLE_ID, pageCommonBean);
            
            fileBean.setSubFlg(false);

            fileBean.setTilte(titleName);
            
            fileBean.regDownloadFucntion(DATA_TABLE_ID, getHeader() ,
                    (id -> {return getRyokinList();}));
            
            fileBean.regBeforeDownFucntion(DATA_TABLE_ID,
                    (comment -> {return beforeDown(comment);}));
            
            // 行更新また削除するために共通処理へ登録する
            pageCommonBean.regDelFucntion(DATA_TABLE_ID,
                    (dataList -> (this.delRows(dataList))));

            // component初期化とユーザ権限により制御設定
            pageCommonBean.setAuthControll(mst291Form, SC_CD_MST291, true);
            
            // 初期はデータを編集不可にする
            mst291Form.setBtnEditeDisabled(true);

            // 世代検索条件を初期化する
            mst291Form.setConSedaiKensakuJoken(new String[]{"01","02"});
            
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

    }
    
    /**
     * カウント処理
     *
     * @return 取得件数
     */
    public Long getRecordCount() {

        // 前回の記録をクリアする
        Map<String, Object> mapRec = new LinkedHashMap();
        mapRec.put(StndConsIF.CONST_ZERO_STRING, true);
        List<Map<String, Object>> mapList = new ArrayList();
        mapList.add(mapRec);
        mst291Form.setSearchResult(mapList);
        mst291Form.setSearchResultSelectable(new ReportListDataModel(mst291Form.getSearchResult()));
        mst291Form.setSelectedSearchResult(null);
        
        // 検索初期はデータを編集不可にする
        mst291Form.setBtnEditeDisabled(true);
        
        // 件数取得処理
        long recordCount = getShimukeListKensu();

        // 検索部のステータスを変更する
        pageCommonBean.setSerchConDisabled(mst291Form);
        // 参照モードにする
        pageCommonBean.setEditFlg(false);
        
        // 検索条件保存
        pageCommonBean.savePageInfo(CONST_MST291_FORM, mst291Form);

        return recordCount;
    }

    /**
     * 検索処理
     *
     */
    public void search() {
        
        // 選択リストを初期化
        mst291Form.setSelectedSearchResult(new ArrayList<>());
        mst291Form.setSearchResultSelectable(null);

        // 世代検索条件で(適用日指定)が選択されている場合 (共通してまだチェック方式を提供していません。)
        if (Arrays.asList(mst291Form.getConSedaiKensakuJoken()).contains("05")) {
            // 適用日の入力が行われているかチェックを行う。
            if (mst291Form.getConTekiyoBi() == null) {
                messagePropertyBean.message(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0028,"適用日指定","適用日");
                return;
            }
        }
        
        // 料金項目マスタ検索し、取得した値を画面項目にセット
        List<Map<String, Object>> res = getRyokinList();
        
        fileBean.setDataList(res);

        // 取得した値を画面項目にセット
        pageCommonBean.setDatalist(DATA_TABLE_ID, res);

        try {
            mst291Form.setSearchResultSelectable(new ReportListDataModel(res));
        } catch (Exception e) {
            java.util.logging.Logger.getLogger(Mst291Bean.class.getName()).log(Level.SEVERE, null, e);
        }
        
        // 検索部のステータス変更
        pageCommonBean.setSerchConDisabled(mst291Form);
        
        // 削除済のみのチェック状態より、明細データを編集可／不可にする
        if (mst291Form.getConSakujoNomiKensaku()== null || mst291Form.getConSakujoNomiKensaku().length == 0) {
            // 削除済みデータを編集可にする
            mst291Form.setBtnEditeDisabled(false);
        } else {
            // 削除済みデータを編集不可にする
            mst291Form.setBtnEditeDisabled(true);
        }
        
        // 検索条件保存
        pageCommonBean.savePageInfo(CONST_MST291_FORM, mst291Form);
        
        // 参照モードにする
        pageCommonBean.setEditFlg(false);
    }
    
    /**
     * 検索条件変更処理
     *
     */
    public void searchChange() {

        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mst291Form);
    }

    /**
     * クリア処理
     *
     */
    public void clear() {

        // 検索部の条件クリア
        mst291Form.setConRyokinKomokuCd(null);
        mst291Form.setConRyokinKomokuMeisho(null);
        mst291Form.setConRyokinKomokuGroup(null);
        mst291Form.setConSyoriKamoku(null);
        mst291Form.setConTekiyoMei(null);
        // 世代検索条件を初期化する
        mst291Form.setConSedaiKensakuJoken(new String[]{"01","02"});
        mst291Form.setConTekiyoBi(null);
        mst291Form.setConSakujoNomiKensaku(null);  
        mst291Form.setConHojoKamoku(null);
        mst291Form.setConYusoUriageSetSaki(null);
        mst291Form.setConProofYouShuyakuKomoku(null);
        // 検索部のステータス変更
        pageCommonBean.setSerchConEnabled(mst291Form);
        pageCommonBean.setBtnSearchChangeVisible(false);
        pageCommonBean.setBtnSearchVisible(Boolean.TRUE);
    }
    
    /**
     * 更新処理
     *
     */
    public void update() {
        // エラーメッセージを格納する変数の初期化を行う
        msgList = new ArrayList();
        MessageModuleBean message = null; 
        List<Map<String, Object>> datas = mst291Form.getSelectedSearchResult();
        
        // 行選択チェックを行う
        if (datas == null || datas.isEmpty()) {
            message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
            msgList.add(message);
            
            messagePropertyBean.messageList(msgList);
            return;
        }
        
        // 単項目チェック処理
        if (!checkJsfParamas(mst291Form.getSelectedSearchResult())) {
            return;
        }
        
        // エラーメッセージを格納する変数の初期化を行う
        msgList = new ArrayList();
        
        for (int i = 0; i < datas.size(); i++) {
            if (!StrUtils.objectToString(datas.get(i).get("listTekiyoKaishibi")).isEmpty()) { 
                // 適用開始日日付フォーマットチェック(共通してまだチェック方式を提供していません。)
                if (!datas.get(i).containsKey("addFlg")) {
                    if (!DateUtils.isDate(StrUtils.objectToString(datas.get(i).get("listTekiyoKaishibi")), StndConsIF.DF_TIMESTAMP)) {
                        message = messagePropertyBean.createMessageModule(
                                MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0004, "適用開始日");
                        msgList.add(message);
                    }  
                } else {
                    try {
                        DateUtils.parse(StrUtils.objectToString(datas.get(i).get("listTekiyoKaishibi")), "EEE MMM dd HH:mm:ss z yyyy", Locale.US);
                    } catch (SystemException ex) {
                        message = messagePropertyBean.createMessageModule(
                                MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0004, "適用開始日");
                        msgList.add(message);
                    }
                }
            }
          
            // 適用終了日日付フォーマットチェック (共通してまだチェック方式を提供していません。)
            if (!StrUtils.defaultString(datas.get(i).get("listTekiyoShuryobi")).isEmpty()) {
                try {
                    DateUtils.parse(StrUtils.objectToString(datas.get(i).get("listTekiyoShuryobi")), "EEE MMM dd HH:mm:ss z yyyy", Locale.US);
                } catch (SystemException ex) {
                    message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0004, "適用終了日");
                    msgList.add(message);
                }
            }

            // 終了チェック 入力必須チェック 適用終了日が入力済みの場合 (共通してまだチェック方式を提供していません。)
            if (!CheckUtils.isEmpty(StrUtils.defaultString(datas.get(i).get("listTekiyoShuryobi")))) {
                if (!Boolean.valueOf(StrUtils.defaultString(datas.get(i).get("listShuryoFlg")))) {
                    message = messagePropertyBean.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0041, "終了する場合、適用終了日");
                    msgList.add(message);
                }
            } 
            // 適用終了日 入力必須チェック　終了チェックが選択済みの場合 (共通してまだチェック方式を提供していません。)
            if (CheckUtils.isEmpty(StrUtils.defaultString(datas.get(i).get("listTekiyoShuryobi")))) {
                if (Boolean.valueOf(StrUtils.defaultString(datas.get(i).get("listShuryoFlg")))) {
                    message = messagePropertyBean.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0048, "終了しない場合、適用終了日");
                    msgList.add(message);
                }
            }
        }
  
        if (!msgList.isEmpty()) {
            messagePropertyBean.messageList(msgList);
            return;
        }
        
        // 登録・更新処理を行う
        int status = insertUpdateRyokinList();

        // エラーの場合、処理終了
        if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            return;
        }

        // 一覧の配色定義をなくす
        pageCommonBean.resetIchiranColColor(mst291Form.getSelectedSearchResult());

        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0007, "更新");
        
        // ログ出力を行う
        LOGGER.info("更新 " + mst291Form.getSelectedSearchResult().size() + " 件");

    }
    
    /**
     * 一覧の単項目チェック処理
     * 
     * @param params 画面一覧パラメータ
     * @return チェックの結果
     */
    private boolean checkJsfParamas(List<Map<String, Object>> params) {

        List<ListCheckBean> checks = new ArrayList<>();
        checks.add(new ListCheckBean("listRyokinKomokuCd", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "料金項目コード"));
        checks.add(new ListCheckBean("listRyokinKomokuCd", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_SIZE, "料金項目コード", "3"));
        checks.add(new ListCheckBean("listRyokinKomokuMeisho",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "料金項目名称"));
        checks.add(new ListCheckBean("listRyokinKomokuMeisho",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "料金項目名称", "40"));
        checks.add(new ListCheckBean("listTekiyoKaishibi",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "適用開始日"));
        checks.add(new ListCheckBean("listRyokinKomokuGroupCd",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "料金項目グループコード"));
        checks.add(new ListCheckBean("listOroshiKeijoKasho", 
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "卸計上箇所"));
        checks.add(new ListCheckBean("listTekiyoMei",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NOT_NULL, "適用名")); 
        checks.add(new ListCheckBean("listGroupNaiHyojijun",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "グループ内表示順", "2"));
        checks.add(new ListCheckBean("listGroupNaiHyojijun",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NUMBER, "グループ内表示順"));
        checks.add(new ListCheckBean("listOroshineritsu",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "卸値率", "5"));
        checks.add(new ListCheckBean("listOroshineritsu",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_NUMBER, "卸値率"));
        checks.add(new ListCheckBean("listTekiyoMei",
                StndConsIF.DATA_TYPE_STRING, StndConsIF.LIST_CHECK_MAX_SIZE, "適用名", "40"));
        List<MessageModuleBean> checkMsgList = listCheckBean.check(params, checks, true);

        if (!checkMsgList.isEmpty()) {
            return false;
        }
        return true;
    }
    
    /**
     *料金項目マスタ情報を更新する
     * 
     * @return
     */
    private int insertUpdateRyokinList() {

        // 重複、存在チェック
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(
                mst291Form.getSelectedSearchResult(), FUNC_CODE_INSERT_UPDATE_CHECK);

        // エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            messagePropertyBean.message(res.getMessages().get(0)[0],
                    res.getMessages().get(0)[1],
                    res.getMessages().get(0)[2],
                    res.getTableName());

            return res.getStatusCode();
        }
        
        // 登録一覧リストと更新一覧リストの内容処理する
        res = pageCommonBean.accsessDBWithList(
                mst291Form.getSelectedSearchResult(), FUNC_CODE_INSERT_UPDATE);

        return res.getStatusCode();
    }

    /**
     * 更新履歴を表示処理
     *
     */
    public void rirekiIchiran() {

        //履歴テーブル検索キー設定
        rirekiSearchKey = new HashMap();
        
        // 選択されたレコードを取得する
        Map<String, Object> selectRec = mst291Form.getSelectedSearchResult().get(0);
        rirekiSearchKey.put("listRyokinKomokuCd", selectRec.get("listRyokinKomokuCd"));
        rirekiSearchKey.put("listTekiyoKaishibi", selectRec.get("listTekiyoKaishibi"));
       
        //履歴タイトル設定
        rirekiSyosaiBean.setListColName(
                new ArrayList<>(Arrays.asList(
                        "料金項目コード", "料金項目名称", "適用開始日", "料金項目グループコード", 
                        "料金項目グループ名称", "グループ内表示順", "税区分", "輸送売上セット先",
                        "プルーフ用集約項目", "明細区分", "卸値率(%)", "卸計上箇所", "計上箇所名称",
                        "処理科目コード", "処理科目名称", "補助科目コード", "補助科目名称", "明細項目",
                        "固定項目", "適用名", "適用終了日", "卸値率設定可能フラグ", "固定項目フラグ")));

        //履歴beanの項目物理名設定
        rirekiSyosaiBean.setListColValue(new ArrayList<>(Arrays.asList(
                        "listRyokinKomokuCd", "listRyokinKomokuMeisho", "listTekiyoKaishibi", 
                        "listRyokinKomokuGroupCd", "listRyokinKomokuGruopMeisho", "listGroupNaiHyojijun",
                        "listZeiKbn", "listYusoUriageSetSaki", "listProofYouShuyakuKomoku", "listMeisaiKbn",
                        "listOroshineritsu", "listOroshiKeijoKasho", "listOroshiKeijoKashoMeisho",
                        "listShoriKamokuCd", "listShoriKamokuMeisho", "listHojoKamokuCd", "listHojoKamokuMeisho",
                        "listMeisaiKomokuMei", "listKoteiKomoku", "listTekiyoMei", "listTekiyoShuryobi",
                        "listOroshineritsuSetteiKanoFlg", "listKoteiKomokuFlg")));

        //履歴テーブル検索する
        rirekiSyosaiBean.searchList("2", "MST291_RIREKI", rirekiSearchKey);

    }
    
    /**
     *料金項目マスタ情報を取得する
     */
    private List<Map<String, Object>> getRyokinList() {

        // パラメータ
        Map<String, Object> params = new HashMap<>();
        
        // 処理科目コード
        if (mst291Form.getConSyoriKamoku() != null) { 
            params.put("conSyoriKamoku", mst291Form.getConSyoriKamoku().getValue()); 
        } else {
            params.put("conSyoriKamoku", ""); 
        }
        
        // 料金項目グループコード
        if (mst291Form.getConRyokinKomokuGroup() != null) { 
            params.put("conRyokinKomokuGroup", mst291Form.getConRyokinKomokuGroup().getValue()); 
        } else {
            params.put("conRyokinKomokuGroup", ""); 
        }

        // 補助科目コード
        if (mst291Form.getConHojoKamoku() != null) { 
            params.put("conHojoKamoku", mst291Form.getConHojoKamoku().getValue()); 
        } else {
            params.put("conHojoKamoku", ""); 
        }
        
        // 輸送売上セット先
        if (mst291Form.getConYusoUriageSetSaki() != null) { 
            params.put("conYusoUriageSetSaki", NumberUtils.toInt(mst291Form.getConYusoUriageSetSaki().getValue())); 
        } else {
            params.put("conYusoUriageSetSaki", 0); 
        }
        
        // プルーフ用集約項目
        if (mst291Form.getConProofYouShuyakuKomoku() != null) { 
            params.put("conProofYouShuyakuKomoku", mst291Form.getConProofYouShuyakuKomoku().getValue()); 
        } else {
            params.put("conProofYouShuyakuKomoku", ""); 
        }
        
        //世代検索条件に変換 
        String[] conSedaiKensakuJoken = new String[5];
        List conSedaiKensakuJokenList = Arrays.asList(mst291Form.getConSedaiKensakuJoken());
        for (int i = 1; i < 6; i++) {
            if (conSedaiKensakuJokenList.isEmpty()) {
                conSedaiKensakuJoken[i - 1] = "0";
            } else {
                //循环リスト 比較値して値をつける
                for (Object object : conSedaiKensakuJokenList) {
                    if (i == Integer.valueOf(String.valueOf(object))) {
                        conSedaiKensakuJoken[i - 1] = "1";
                        break;
                    } else {
                        conSedaiKensakuJoken[i - 1] = "0";
                    }
                }
            }
        }

        // 適用日
        params.put("conTekiyoBi", DateUtils.format(mst291Form.getConTekiyoBi(), StndConsIF.DF_YYYY_MM_DD));
        // 料金項目コード
        params.put("conRyokinKomokuCd", mst291Form.getConRyokinKomokuCd());
        // 料金項目名称
        params.put("conRyokinKomokuMeisho", mst291Form.getConRyokinKomokuMeisho());
        // 世代検索
        params.put("conSedaiKensakuJoken", conSedaiKensakuJoken);
        // 適用名
        params.put("conTekiyoMei", mst291Form.getConTekiyoMei());
        // 削除のみ検索
        params.put("conSakujoNomiKensaku", mst291Form.getConSakujoNomiKensaku());
        
        try {
            // DBをアクセス
            ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, SEARCH_FUNC_CODE);
            ObjectMapper mapper = new ObjectMapper();
            mst291Form.setSearchResult(mapper.readValue(res.getJson(), List.class));

        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
        return mst291Form.getSearchResult();
    }

    /**
     * DBから仕向地名マスタ検索件数を取得する
     */
    private long getShimukeListKensu() {

        // パラメータ
        Map<String, Object> params = new HashMap<>();

        // 処理科目コード
        if (mst291Form.getConSyoriKamoku() != null) { 
            params.put("conSyoriKamoku", mst291Form.getConSyoriKamoku().getValue()); 
        } else {
            params.put("conSyoriKamoku", ""); 
        }
        
        // 料金項目グループコード
        if (mst291Form.getConRyokinKomokuGroup() != null) { 
            params.put("conRyokinKomokuGroup", mst291Form.getConRyokinKomokuGroup().getValue()); 
        } else {
            params.put("conRyokinKomokuGroup", ""); 
        }

        // 補助科目コード
        if (mst291Form.getConHojoKamoku() != null) { 
            params.put("conHojoKamoku", mst291Form.getConHojoKamoku().getValue()); 
        } else {
            params.put("conHojoKamoku", ""); 
        }
        
        // 輸送売上セット先
        if (mst291Form.getConYusoUriageSetSaki() != null) { 
            params.put("conYusoUriageSetSaki", NumberUtils.toInt(mst291Form.getConYusoUriageSetSaki().getValue())); 
        } else {
            params.put("conYusoUriageSetSaki", 0); 
        }
        
        // プルーフ用集約項目
        if (mst291Form.getConProofYouShuyakuKomoku() != null) { 
            params.put("conProofYouShuyakuKomoku", mst291Form.getConProofYouShuyakuKomoku().getValue()); 
        } else {
            params.put("conProofYouShuyakuKomoku", ""); 
        }
        
        //世代検索条件に変換 
        String[] conSedaiKensakuJoken = new String[5];
        List conSedaiKensakuJokenList = Arrays.asList(mst291Form.getConSedaiKensakuJoken());
        for (int i = 1; i < 6; i++) {
            if (conSedaiKensakuJokenList.isEmpty()) {
                conSedaiKensakuJoken[i - 1] = "0";
            } else {
                //循环リスト 比較値して値をつける
                for (Object object : conSedaiKensakuJokenList) {
                    if (i == Integer.valueOf(String.valueOf(object))) {
                        conSedaiKensakuJoken[i - 1] = "1";
                        break;
                    } else {
                        conSedaiKensakuJoken[i - 1] = "0";
                    }
                }
            }
        }
        
        // 適用日
        params.put("conTekiyoBi", DateUtils.format(mst291Form.getConTekiyoBi(), StndConsIF.DF_YYYY_MM_DD));
        // 料金項目コード
        params.put("conRyokinKomokuCd", mst291Form.getConRyokinKomokuCd());
        // 料金項目名称
        params.put("conRyokinKomokuMeisho", mst291Form.getConRyokinKomokuMeisho());
        // 世代検索
        params.put("conSedaiKensakuJoken", conSedaiKensakuJoken);
        // 適用名
        params.put("conTekiyoMei", mst291Form.getConTekiyoMei());
        // 削除のみ検索
        params.put("conSakujoNomiKensaku", mst291Form.getConSakujoNomiKensaku());
        
        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.getDBInfo(params, FUNC_CODE_SEARCH_KENSU);

        return Long.valueOf(res.getJson());
    }
    
    /**
     * メニュークリック処理
     *
     * @param menuId // メニューID
     * @param nextScreenId // 遷移先画面ID
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreenId) {
        try {
            // パンくずを削除する
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        // 画面遷移を行う
        url = forward(nextScreenId, menuId, null, false);
        return url;
    }

    /**
     * パンくずクリック処理
     *
     * @param nextScreenId // 遷移先画面ID
     * @param breadIndex // パンくずのインデックス
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreenId, int breadIndex) {

        try {
            // パンくずを削除する
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        
        // 画面遷移を行う
        url = forward(nextScreenId, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authorityConfBean.logout();
    }

    /**
     * 画面遷移処理（顧客マスタメンテナンス画面へ）
     *
     * @return
     * @throws java.lang.IllegalAccessException
     * @throws java.lang.reflect.InvocationTargetException
     */
    public String buttonClick() throws IllegalAccessException, InvocationTargetException {

        // 画面遷移
        url = forward(SCREEN.CUS012_SCREEN.name(), null, SCREEN.CUS011_SCREEN.name(), false);
        return url;
    }

    /**
     * 画面タイトルを取得する処理
     * 
     * @return 画面タイトル
     */
    public String getTitleName() {
        return titleName;
    }

    public List<CSVDto> getHeader() {
        // CSVファイルのタイトルを設定
        List<CSVDto> header = new ArrayList<>();
        
        header.add(new CSVDto("料金項目コード", "listRyokinKomokuCd"));
        header.add(new CSVDto("料金項目名称", "listRyokinKomokuMeisho"));
        header.add(new CSVDto("適用開始日", "listTekiyoKaishibi"));
        header.add(new CSVDto("料金項目グループコード", "listRyokinKomokuGroupCd"));
        header.add(new CSVDto("料金項目グループ名称", "listRyokinKomokuGruopMeisho"));
        header.add(new CSVDto("グループ内表示順", "listGroupNaiHyojijun"));
        header.add(new CSVDto("税区分", "listZeiKbn"));
        header.add(new CSVDto("輸送売上セット先", "listYusoUriageSetSaki"));
        header.add(new CSVDto("プルーフ用集約項目", "listProofYouShuyakuKomoku"));
        header.add(new CSVDto("明細区分", "listMeisaiKbn"));
        header.add(new CSVDto("卸値率(%)", "listOroshineritsu"));
        header.add(new CSVDto("卸計上箇所", "listOroshiKeijoKasho"));
        header.add(new CSVDto("計上箇所名称", "listOroshiKeijoKashoMeisho"));
        header.add(new CSVDto("処理科目コード", "listShoriKamokuCd"));
        header.add(new CSVDto("処理科目名称", "listShoriKamokuMeisho"));
        header.add(new CSVDto("補助科目コード", "listHojoKamokuCd"));
        header.add(new CSVDto("補助科目名称", "listHojoKamokuMeisho"));
        header.add(new CSVDto("明細項目", "listMeisaiKomokuMei"));
        header.add(new CSVDto("固定項目", "listKoteiKomoku"));
        header.add(new CSVDto("適用名", "listTekiyoMei"));
        header.add(new CSVDto("適用終了日", "listTekiyoShuryobi"));
        header.add(new CSVDto("卸値率設定可能フラグ", "listOroshineritsuSetteiKanoFlg"));
        header.add(new CSVDto("固定項目フラグ", "listKoteiKomokuFlg"));
        return header;
    }
    
    /**
     * 業務削除処理ファンクション領域
     *
     */
    public void delRowsFunc() {

        pageCommonBean.getSelectedDatasList().put(DATA_TABLE_ID, mst291Form.getSelectedSearchResult());
        pageCommonBean.delRows(DATA_TABLE_ID);

    }
    
    /**
     * 業務削除処理
     *
     * @param recordList レコードリスト
     * @return 正常／異常
     */
    public Boolean delRows(List<Map<String, Object>> recordList) {
        // エラーメッセージを格納する変数を初期化する
        msgList = new ArrayList<>();
        
        // 行選択チェック
        if (recordList.isEmpty()) {
            MessageModuleBean message = messagePropertyBean.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0013);
            msgList.add(message);
            
            messagePropertyBean.messageList(msgList);
            return false;
        }
        
        // 固定項目フラグチェック、存在チェック
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(recordList, FUNC_CODE_DELETE_EXIST);
        
        // エラーの場合、処理を終了
        if (res.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            
            // 存在しない場合は画面から削除しない
            mst291Form.getSearchResult().addAll(recordList);
            
            MessageModuleBean message = messagePropertyBean.createMessageModule(
                    res.getMessages().get(0)[0], 
                    res.getMessages().get(0)[1],
                    res.getMessages().get(0)[2],
                    res.getTableName());
            msgList.add(message);
            
            messagePropertyBean.messageList(msgList);
            return false;
        }
        
        // 削除処理を行う
        int status = deleteShimukeList(recordList);
        
        // エラーの場合、処理を終了
        if (status == ServiceInterfaceBean.PROCESS_STATUS_ERROR) {
            return false;
        }
        
        try {
            // 画面レコード削除
            mst291Form.getSearchResult().removeAll(recordList);
        } catch (Exception e) {
            java.util.logging.Logger.getLogger(Mst291Bean.class.getName()).log(Level.SEVERE, null, e);
        }
        
        // メッセージを設定する
        messagePropertyBean.message(MessagePropertyBean.SEVERITY_INFO, MessageCnst.COMI0004, "削除");
        
        // ログ出力
        LOGGER.info("削除 " + recordList.size() + " 件");
        
        return true;
    }

    /**
     * DBから料金項目マスタ情報を削除する
     * 
     * @param datas ダークリスト
     * @return ステータスコード     */
    private int deleteShimukeList(List<Map<String, Object>> datas) {

        // DBをアクセス
        ServiceInterfaceBean res = pageCommonBean.accsessDBWithList(datas, MST291_DELETE);

        // ステータスコードを返却する
        return res.getStatusCode();
    }    
    
    /**
     * ダウンロード理由を記録する処理
     *
     * @param comment 理由コメント
     * @return 正常／異常
     * @throws Exception
     */
    public boolean beforeDown(String comment) throws Exception {
        
        // ダウンロード理由を記録する
        System.out.println(comment);
        
        return true;
    }
    
}
