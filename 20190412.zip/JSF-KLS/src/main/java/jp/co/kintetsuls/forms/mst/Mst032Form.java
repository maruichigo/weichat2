/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.forms.mst;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import jp.co.kintetsuls.beans.common.AutoCompOptionBean;
import jp.co.kintetsuls.beans.common.ReportListDataModel;
import jp.co.kintetsuls.beans.common.annotation.DateCheck;
import jp.co.kintetsuls.beans.common.annotation.NotNull;
import jp.co.kintetsuls.beans.common.annotation.SelectOne;
import lombok.Data;

/**
 * 住所マスタ詳細画面
 *
 * @author 張誠 (MBP)
 * @version 2019/1/30 新規作成
 */
@ManagedBean(name = "mst032Form")
@ViewScoped
@Data
public class Mst032Form implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * JISコード
     */
    @SelectOne(name = "JISコード", message = "{COME0003}")
    private AutoCompOptionBean conJisCd;
    /**
     * JISコード（退避用）
     */
    private String conJisCdTaihi;

    /**
     * 適用開始日
     */
    @NotNull(name = "適用開始日")
    @DateCheck(name = "適用開始日")
    private String conTekiyoKaishibi;

    /**
     * 適用開始日（退避用）
     */
    private Date conTekiyoKaishibiTaihi;

    /**
     * システム日付
     */
    private Date tekiyoKaishibiSysDate;
    
    /**
     * 適用名
     */
    private String conTekiyoMei;

    /**
     * 適用名（退避用）
     */
    private String conTekiyoMeiTaihi;

    /**
     * 適用終了
     */
    private String conTekiyoShuryo[];

    /**
     * 適用終了（退避用）
     */
    private String conTekiyoShuryoTaihi;

    /**
     * 住所基本情報
     */
    private Map<String, Object> resultJusho;

    /**
     * チェック実行日時
     */
    private String jisChkDtlCheckJikkoHizuke;

    /**
     * チェック結果
     */
    private String jisChkDtlCheckKekka;

    /**
     * ステータス変更日時
     */
    private String jisChkDtlStatusHenkoHizuke;

    /**
     * 漢字住所（都道府県）
     */
    private String jshDtlKanjiJushoTodofukenMei;
    /**
     * 漢字住所（市区町村）
     */
    private String jshDtlKanjiJushoShikuchosonMei;

    /**
     * 変更漢字住所（都道府県）
     */
    private String jshDtlHenkoKanjiJushoTodofukenMei;

    /**
     * 変更漢字住所（市区町村）
     */
    private String jshDtlHenkoKanjiJushoShikuchosonMei;

    /**
     * カナ住所（都道府県）
     */
    private String jshDtlKanaJushoTodofukenMei;

    /**
     * カナ住所（市区町村）
     */
    private String jshDtlKanaJushoShikuchosonMei;

    /**
     * 変更カナ住所（都道府県）
     */
    private String jshDtlHenkoKanaJushoTodofukenMei;

    /**
     * 変更カナ住所（市区町村）
     */
    private String jshDtlHenkoKanaJushoShikuchosonMei;

    /**
     * 英語住所（都道府県）
     */
    private String jshDtlEigoJushoTodofukenMei;

    /**
     * 英語住所（市区町村）
     */
    private String jshDtlEigoJushoShikuchosonMei;

    /**
     * 離島有無
     */
    private String[] jshDtlRitoUmuFlg;

    /**
     * 離島件数
     */
    private String jshDtlRitoKensu;

    /**
     * 館内配送件数
     */
    private String jshDtlKannaiHaisoKensu;

    /**
     * HTコメント(100バイト)
     */
    private String jshDtlHtComment1;

    /**
     * HTコメント(200バイト)
     */
    private String jshDtlHtComment2;

    /**
     * 旧住所区分
     */
    private String[] kyjshDtlKyuJushoKubun;

    /**
     * 新JISコード
     */
    private AutoCompOptionBean kyjshDtlShinJisCd;

    /**
     * 旧住所コメント
     */
    private String kyjshDtlKyuJushoComment;

    /**
     * 旧住所コメント制御
     */
    private boolean kyjshDtlKyuJushoCommentEditFlg;

    /**
     * 更新日時
     */
    private String kshnDtlkoshinNichiji;

    /**
     * 更新者
     */
    private String kshnDtlUser;

    /**
     * 住所詳細リスト検索結果一覧選択できる
     */
    private ReportListDataModel listJushoSelectable;

    /**
     * 住所詳細リスト選択された結果
     */
    private List<Map<String, Object>> listJushoSelectedResult;

    /**
     * 離島詳細リスト検索結果一覧選択できる
     */
    private ReportListDataModel listRitoSelectable;

    /**
     * 離島詳細リスト選択された結果
     */
    private List<Map<String, Object>> listRitoSelectedResult;

    /**
     * 館内配送詳細リスト検索結果一覧選択できる
     */
    private ReportListDataModel listKannaiSelectable;

    /**
     * 館内配送詳細リスト選択された結果
     */
    private List<Map<String, Object>> listKannaiSelectedResult;

    /**
     * 変換情報
     */
    private Map<String, Object> henkanJoho;

    /**
     * 変換情報リスト検索結果一覧選択できる
     */
    private ReportListDataModel listHenkanSelectable;

    /**
     * 変換情報リスト選択された結果
     */
    private List<Map<String, Object>> listHenkanSelectedResult;

    /**
     * 施設表示名情報
     */
    private Map<String, Object> shisetsuJoho;

    /**
     * 施設表示名情報リスト検索結果一覧選択できる
     */
    private ReportListDataModel listShisetsuSelectable;

    /**
     * 施設表示名情報リスト選択された結果
     */
    private List<Map<String, Object>> listShisetsuSelectedResult;
    
     /**
     * EDI住所チェック結果メッセージ
     */
    private String ediJushoMsg;
}
