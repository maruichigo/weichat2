/*
 * Copyright (C) 2014 MBP Corporation All Rights Reserved .
 */
package jp.co.kintetsuls.utils;

import jp.co.kintetsuls.cnst.StndConsIF;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.TreeMap;
import jp.co.kintetsuls.exception.SystemException;
import org.primefaces.json.JSONObject;

/**
 * ＤＢ反射処理。
 *
 * @author hq
 */
public class BeanUtils {

    /**
     * obj1のデータを obj2に設定します
     *
     * @param obj1
     * @param obj2
     * @throws java.lang.Exception
     * @return Object
     */
    public static Object CopyBeanToBean(Object obj1, Object obj2) throws Exception {
        return CopyBeanToBean(obj1, obj2, true);
    }

    /**
     * obj1のデータを obj2に設定します
     *
     * @param _objGet
     * @param _objSet
     * @param _allowNull　NULL　のデータもコピーします。
     * @throws java.lang.Exception
     * @return Object
     */
    public static Object CopyBeanToBean(Object _objGet, Object _objSet, boolean _allowNull) throws Exception {
        return CopyBeanToBean(_objGet, _objSet, _allowNull, null);
    }

    public static Object CopyBeanToBean(Object _objGet, Object _objSet, boolean _allowNull, List<String> exList) throws Exception {
        if (_objGet == null) {
            return _objSet;
        }
        Method[] methodsGet = _objGet.getClass().getMethods();
        Method[] methodsSet = _objSet.getClass().getMethods();
        String methodGetName;
        String methodGetFix;
        String methodSetName;
        String methodSetFix;
        for (Method methodGet : methodsGet) {
            int i = 0;
            methodGetName = methodGet.getName();
            methodGetFix = methodGetName.substring(3, methodGetName.length());
            if (methodGetName.startsWith("get")) {
                if (!_allowNull && (methodGet.invoke(_objGet, new Object[0])  == null)) {
                    continue;
                }
                if (CheckUtils.isEqual(methodGetFix, "SerialVersionUID")
                        || CheckUtils.isEqual(methodGetFix, "Class")
                        //                        || CheckUtils.isEqual(methodGetFix, "Version")
                        || StrUtils.endsWith(methodGetFix, "RegisterUserId")
                        || StrUtils.endsWith(methodGetFix, "RegisterDatetime")
                        || StrUtils.endsWith(methodGetFix, "ModifyUserId")
                        || StrUtils.endsWith(methodGetFix, "ModifyDatetime")
                        || StrUtils.endsWith(methodGetFix, "List")
                        || StrUtils.endsWith(methodGetFix, "Out")) {
                    continue;
                }
                if (exList != null) {
                    boolean flg = false;
                    for (String tmp : exList) {
                        if (CheckUtils.isEqual(StrUtils.lowerFirst(methodGetFix), tmp)) {
                            flg = true;
                            break;
                        }
                    }
                    if (flg) {
                        continue;
                    }
                }
                for (Method methodSet : methodsSet) {
                    methodSetName = methodSet.getName();
                    methodSetFix = methodSetName.substring(3, methodSetName.length());
                    if (methodSetName.startsWith("set")) {
                        if (methodSetFix.equals(methodGetFix)) {
//                            LogUtils.debug("copy data: " + methodSetName);
                            Object[] objs1 = new Object[0];
                            Object[] objs2 = new Object[1];
                            objs2[0] = methodGet.invoke(_objGet, objs1);
                            methodSet.invoke(_objSet, objs2);
                        }
                    }
                }
            }
        }
        return _objSet;
    }

   

    /**
     * 項目名前の値のタイプを取得。
     *
     * @param _obj
     * @param _dateName
     * @throws java.lang.Exception
     * @return
     */
    public static String getDateType(Object _obj, String _dateName) throws Exception {
        Method[] methodList = _obj.getClass().getMethods();

        for (Method method : methodList) {

            String methodName = method.getName();

            if (CheckUtils.isEqual(methodName, "get" + StrUtils.upperMidFirst(_dateName))) {
                String returnType = method.getGenericReturnType().toString();
                if (CheckUtils.isEqual(returnType, "class java.lang.String")) {
                    return StndConsIF.DATA_TYPE_STRING;
                }
                if (CheckUtils.isEqual(returnType, "class java.math.BigDecimal")) {
                    return StndConsIF.DATA_TYPE_BIGDECIMAL;
                }
                if (CheckUtils.isEqual(returnType, "class java.util.Date")) {
                    return StndConsIF.DATA_TYPE_CALENDAR;
                }
                if (CheckUtils.isEqual(returnType, "int")) {
                    return StndConsIF.DATA_TYPE_INT;
                }
                if (CheckUtils.isEqual(returnType, "class java.lang.Integer")) {
                    return StndConsIF.DATA_TYPE_INT;
                }
                if (CheckUtils.isEqual(returnType, "long")) {
                    return StndConsIF.DATA_TYPE_LONG;
                }

            }

        }
        return null;
    }

    public static boolean isDataNull(Object _obj) throws Exception {
        return isDataNullSub(_obj, _obj.getClass());
    }

    public static boolean isDataNullSub(Object _obj, Class objClass) throws Exception {
        Field[] fieldList;

        fieldList = objClass.getDeclaredFields();
        for (Field field : fieldList) {
            String fieldName = field.getName();

            boolean accessible = field.isAccessible();
            field.setAccessible(true);
//                String returnType = method.getGenericReturnType().toString();
            Object result = field.get(_obj);
            field.setAccessible(accessible);
            String returnType = field.getGenericType().toString();
            if (CheckUtils.isEqual("serialVersionUID", fieldName)
                    || CheckUtils.isEqual("version", fieldName)) {
                continue;
            }
            if (result == null) {
                continue;
            }
            if (CheckUtils.isEqual(returnType, "class java.lang.String")) {
                if (CheckUtils.isEmpty((String) result)) {
                    continue;
                } else {
                    System.out.println(fieldName);
                    return false;
                }
            } else {
                System.out.println(fieldName);
                return false;
            }

        }

        if (objClass.getSuperclass() != null) {
            return isDataNullSub(_obj, objClass.getSuperclass());
        }
        return true;
    }

    /**
     * 項目名前の値を取得。 データ名は"_"を変改対象にする為、getメソッドでは"_"を使用しないでください
     *
     * @param _obj
     * @param _dateName
     * @throws java.lang.Exception
     * @return
     */
    public static Object getDate(Object _obj, String _dateName) throws Exception {
        return getDateSub(_obj, _obj.getClass(), _dateName);
    }

    public static Object getDateSub(Object _obj, Class objClass, String _dateName) throws Exception {
        Field[] fieldList = objClass.getFields();
        for (Field field : fieldList) {

            String fieldName = field.getName();
            if (CheckUtils.isEqual(fieldName, StrUtils.upperMid(_dateName))) {
//                String returnType = method.getGenericReturnType().toString();
                return field.get(_obj);
            }

        }
        fieldList = objClass.getDeclaredFields();
        for (Field field : fieldList) {

            String fieldName = field.getName();

            if (CheckUtils.isEqual(fieldName, StrUtils.upperMid(_dateName))) {
                boolean accessible = field.isAccessible();
                field.setAccessible(true);
//                String returnType = method.getGenericReturnType().toString();
                Object result = field.get(_obj);
                field.setAccessible(accessible);
                return result;
            }

        }
        Method[] methodList = objClass.getMethods();

        for (Method method : methodList) {

            String methodName = method.getName();

            if (CheckUtils.isEqual(methodName, "get" + StrUtils.upperMidFirst(_dateName))) {
//                String returnType = method.getGenericReturnType().toString();

                Object[] objs = new Object[0];
                return method.invoke(_obj, objs);
            }

        }

        if (objClass.getSuperclass() != null) {
            return getDateSub(_obj, objClass.getSuperclass(), _dateName);
        }
        return null;
    }

    /**
     * 項目名前の値を設定。 データ名は"_"を変改対象にする為、setメソッドでは"_"を使用しないでください
     *
     * @param _obj
     * @param _dateName
     * @param _value
     * @throws java.lang.Exception
     */
    public static void setData(Object _obj, String _dateName, Object _value) throws Exception {
        Method[] methodList = _obj.getClass().getMethods();
        if (_value instanceof Byte) {
            _value = ((Byte) _value).intValue();
        }
        if (_value instanceof BigInteger) {
            _value = ((BigInteger) _value).longValue();
        }

        for (Method method : methodList) {

            String methodName = method.getName();
            Object[] argList = {_value};
            if (CheckUtils.isEqual(methodName, "set" + StrUtils.upperMidFirst(_dateName))) {
//                String returnType = method.getGenericReturnType().toString();
                method.invoke(_obj, argList);

            }

        }
    }

    /**
     * 項目名前の値を取得,文字列で戻します。
     *
     * @param _obj
     * @param _dateName
     * @throws java.lang.Exception
     * @return
     */
    public static String getDataAsString(Object _obj, String _dateName) throws Exception {
        return getDataAsString(_obj, _dateName, "");
    }

    public static String getDataAsString(Object _obj, String _dateName, String _format) throws Exception {

        Field[] fieldList = _obj.getClass().getDeclaredFields();
        for (Field field : fieldList) {

            String fieldName = field.getName();
            boolean accessible = field.isAccessible();
            field.setAccessible(true);

            if (CheckUtils.isEqual(fieldName, _dateName)) {
                String returnType = field.getGenericType().toString();

                Object[] objs = new Object[0];
                Object result = field.get(_obj);
                field.setAccessible(accessible);

//                Object  result = fieldName.getClass().toString();
                if (result == null) {
                    return null;
                }

                if (CheckUtils.isEqual(returnType, "class java.lang.String")) {
                    return (String) result;

                }
                if (CheckUtils.isEqual(returnType, "class java.math.BigDecimal")) {
                    return StrUtils.defaultString((BigDecimal) result);

                }
                if (CheckUtils.isEqual(returnType, "class java.util.Date")) {
                    if (CheckUtils.isEmpty(_format)) {
                        return DateUtils.format((Date) result, StndConsIF.DF_YYYY_MM_DD_HH_MM_SS_SSS);
                    } else {
                        return DateUtils.format((Date) result, _format);
                    }

                }
                if (CheckUtils.isEqual(returnType, "int")) {
                    return StrUtils.defaultString((int) result);

                }
                if (CheckUtils.isEqual(returnType, "class java.lang.Integer")) {
                    return StrUtils.defaultString((int) result);

                }
                if (CheckUtils.isEqual(returnType, "long")) {
                    return StrUtils.defaultString((long) result);

                }
                if (CheckUtils.isEqual(returnType, "class java.lang.Boolean")) {
                    return StrUtils.defaultString((boolean) result);
                }
                if (CheckUtils.isEqual(returnType, "java.lang.Double")) {
                    return StrUtils.defaultString((double) _obj);
                }
                if (CheckUtils.isEqual(returnType, "java.util.List<java.lang.String>")) {
                    String str = "[";
                    for (String temp : (List<String>) result) {
                        str += temp + ",";
                    }
                    return ((List<String>) result).isEmpty() ? "" : str.substring(0, str.length() - 1) + "]";
                }
            }

        }
        return null;
    }

    public static String objectToString(Object _obj) throws Exception {

        if (_obj == null) {
            return "";
        }
        String returnType = _obj.getClass().getName();

        if (CheckUtils.isEqual(returnType, "java.lang.String")) {
            return (String) _obj;

        }
        if (CheckUtils.isEqual(returnType, "java.math.BigDecimal")) {
            return StrUtils.defaultString((BigDecimal) _obj);
        }
        if (CheckUtils.isEqual(returnType, "java.util.Date")) {
            return DateUtils.format((Date) _obj, StndConsIF.DF_YYYY_MM_DD_HH_MM_SS_SSS);

        }
        if (CheckUtils.isEqual(returnType, "int")) {
            return StrUtils.defaultString((int) _obj);

        }
        if (CheckUtils.isEqual(returnType, "java.lang.Integer")) {
            return StrUtils.defaultString((int) _obj);

        }

        if (CheckUtils.isEqual(returnType, "long")) {
            return StrUtils.defaultString((long) _obj);

        }
        if (CheckUtils.isEqual(returnType, "java.lang.Long")) {
            return StrUtils.defaultString((long) _obj);

        }
        if (CheckUtils.isEqual(returnType, "java.lang.Double")) {
            return StrUtils.defaultString((double) _obj);

        }
        return null;
    }

    /**
     * 項目名前の値を設定,文字列から変形。
     *
     * @param _obj
     * @param _dateName
     * @param _value
     * @throws java.lang.Exception
     *
     */
    public static void setDataAsString(Object _obj, String _dateName, String _value) throws Exception {
        setDataSubAsString(_obj, _obj.getClass(), _dateName, _value);

    }

    public static void setDataSubAsString(Object _obj, Class objClass, String _dateName, String _value) throws Exception {
        Field[] fieldList = objClass.getDeclaredFields();
        for (Field field : fieldList) {

            String fieldName = field.getName();
            if (CheckUtils.isEqual(fieldName, _dateName)) {
//                String returnType = method.getGenericReturnType().toString();
//                return field.set(_obj ,);
                if (field.toGenericString().contains("final ")) {
                    System.out.println("final prop unset " + _dateName);
                    return;
                }

                String returnType = field.getGenericType().toString();
                Object objs2;
                if (CheckUtils.isEqual(returnType, "class java.lang.String")) {
                    objs2 = _value;
                    boolean accessible = field.isAccessible();
                    field.setAccessible(true);
                    field.set(_obj, objs2);
                    field.setAccessible(accessible);
                    return;
                }
                if (CheckUtils.isEqual(returnType, "class java.math.BigDecimal")) {
                    objs2 = NumberUtils.toBigDecimal(_value);
                    boolean accessible = field.isAccessible();
                    field.setAccessible(true);
                    field.set(_obj, objs2);
                    field.setAccessible(accessible);

                    return;
                }
                if (CheckUtils.isEqual(returnType, "class java.util.Date")) {
                    objs2 = DateUtils.parse(_value, StndConsIF.DF_YYYY_MM_DD_HH_MM_SS_SSS);
                    boolean accessible = field.isAccessible();
                    field.setAccessible(true);
                    field.set(_obj, objs2);
                    field.setAccessible(accessible);
                    return;

                }
                if (CheckUtils.isEqual(returnType, "int")) {
                    objs2 = NumberUtils.toInt(_value);
                    boolean accessible = field.isAccessible();
                    field.setAccessible(true);
                    field.set(_obj, objs2);
                    field.setAccessible(accessible);

                    return;
                }
                if (CheckUtils.isEqual(returnType, "class java.lang.Integer")) {
                    objs2 = NumberUtils.toInt(_value);
                    boolean accessible = field.isAccessible();
                    field.setAccessible(true);
                    field.set(_obj, objs2);
                    field.setAccessible(accessible);
                    return;
                }
                if (CheckUtils.isEqual(returnType, "long")) {
                    objs2 = NumberUtils.toLong(_value);
                    boolean accessible = field.isAccessible();
                    field.setAccessible(true);
                    field.set(_obj, objs2);
                    field.setAccessible(accessible);
                    return;
                }
                if (CheckUtils.isEqual(returnType, "class java.lang.Boolean")) {
                    if (CheckUtils.isEqual(_value, "true")) {
                        objs2 = true;
                    } else {
                        objs2 = false;
                    }
                    boolean accessible = field.isAccessible();
                    field.setAccessible(true);
                    field.set(_obj, objs2);
                    field.setAccessible(accessible);
                    return;
                }
                if (CheckUtils.isEqual(returnType, "java.util.List<java.lang.String>")) {
                    String str = _value.substring(1, _value.length() - 1);
                    String[] arr = str.split(",");
                    List<String> result = new ArrayList<>();
                    for (String temp : arr) {
                        result.add(temp);
                    }
                    objs2 = result;
                    boolean accessible = field.isAccessible();
                    field.setAccessible(true);
                    field.set(_obj, objs2);
                    field.setAccessible(accessible);
                    return;
                }
            }

        }
        if (objClass.getSuperclass() != null) {
            setDataSubAsString(_obj, objClass.getSuperclass(), _dateName, _value);
            return;
        }
        System.out.println("prop unset " + _dateName);
    }

  

    /**
     * 対象の属性名をリストで返す
     *
     * @param _objGet
     *
     * @return
     */
    public static List<String> getMethodNameList(Object _objGet) {
        return getMethodNameList(_objGet, "", "get", true);
    }

    /**
     * 対象の属性名をリストで返す
     *
     * @param _objGet
     * @param exitPropList ","で分割項目、ある場合は読み飛ばす。
     *
     * @return
     */
    public static List<String> getMethodNameList(Object _objGet, String exitPropList) {
        return getMethodNameList(_objGet, exitPropList, "get", true);
    }

    /**
     * 対象の属性名をリストで返す
     *
     * @param _objGet
     * @param exitPropList ","で分割項目、ある場合は読み飛ばす。
     * @param prFix
     * @param deafultExit
     * @return
     */
    public static List<String> getMethodNameList(Object _objGet, String exitPropList, String prFix, boolean deafultExit) {
        List<String> methodName = new ArrayList<>();

        Method[] methodsGet = _objGet.getClass().getMethods();

        String methodGetName;
        String methodGetFix;
        String[] exitPropListS = null;
        if (!CheckUtils.isEmpty(exitPropList)) {
            exitPropListS = exitPropList.split(",");
        }

        for (Method methodGet : methodsGet) {
            methodGetName = methodGet.getName();
            if (methodGetName.startsWith(prFix)) {
                if (!CheckUtils.isEmpty(prFix)) {
                    methodGetFix = methodGetName.substring(prFix.length(), methodGetName.length());
                } else {
                    methodGetFix = methodGetName;
                }
                if (CheckUtils.isEmpty(methodGetFix)) {
                    continue;
                }
                if (CheckUtils.isEqual(methodGetFix, "SerialVersionUID")
                        || CheckUtils.isEqual(methodGetFix, "Class")
                        || StrUtils.endsWith(methodGetFix, "Out")
                        || StrUtils.endsWith(methodGetFix, "NotNullFlg")) {
                    continue;
                }
                if (deafultExit) {
                    if (CheckUtils.isEqual(methodGetFix, "CreatedUser")
                            || CheckUtils.isEqual(methodGetFix, "CreatedDate")
                            || CheckUtils.isEqual(methodGetFix, "LastModifiedUser")
                            || CheckUtils.isEqual(methodGetFix, "LastModifiedDate")
                            || StrUtils.endsWith(methodGetFix, "DeletedFlag")) {
                        continue;
                    }
                }
                if (exitPropListS != null) {
                    boolean exitFlg = false;
                    for (String exitProp : exitPropListS) {
                        if (CheckUtils.isEqual(methodGetFix, StrUtils.upperMidFirst(exitProp))) {
                            exitFlg = true;
                            break;
                        }
                    }
                    if (exitFlg) {
                        continue;
                    }
                }
                methodName.add(methodGetFix);
            }
        }
        return methodName;
    }

    /**
     * 対象の属性名をリストで返す
     *
     * @param _objGet
     *
     * @return
     * @throws java.lang.Exception
     */
//    public static List<String> getMethodNameListSort(Object _objGet) throws Exception {
//        return getMethodNameListSort(_objGet, "", "get", true);
//    }

    /**
     * 対象の属性名をリストで返す
     *
     * @param _objGet
     * @param exitPropList ","で分割項目、ある場合は読み飛ばす。
     *
     * @return
     */
//    public static List<String> getMethodNameListSort(Object _objGet, String exitPropList) throws Exception {
//        return getMethodNameListSort(_objGet, exitPropList, "get", true);
//    }

//    /**
//     * 対象の属性名をリストで返す
//     *
//     * @param _objGet
//     * @param exitPropList ","で分割項目、ある場合は読み飛ばす。
//     * @param prFix
//     * @param deafultExit
//     * @return
//     * @throws java.lang.Exception
//     */
//    public static List<String> getMethodNameListSort(Object _objGet, String exitPropList, String prFix, boolean deafultExit) throws Exception {
//        List<String> methodName = new ArrayList<>();
//        TreeMap<String, String> treeMap = new TreeMap<>(new Comparator<String>() {
//            @Override
//            public int compare(String o1, String o2) {
//                return o1.compareTo(o2);
//            }
//        });
//        Method[] methodsGet = _objGet.getClass().getMethods();
//
//        String methodGetName;
//        String methodGetFix;
//        String[] exitPropListS = null;
//        if (!CheckUtils.isEmpty(exitPropList)) {
//            exitPropListS = exitPropList.split(",");
//        }
//        int index = 0;
//        for (Method methodGet : methodsGet) {
//            methodGetName = methodGet.getName();
//            if (methodGetName.startsWith(prFix)) {
//                if (!CheckUtils.isEmpty(prFix)) {
//                    methodGetFix = methodGetName.substring(prFix.length(), methodGetName.length());
//                } else {
//                    methodGetFix = methodGetName;
//                }
//                if (CheckUtils.isEmpty(methodGetFix)) {
//                    continue;
//                }
//                if (CheckUtils.isEqual(methodGetFix, "SerialVersionUID")
//                        || CheckUtils.isEqual(methodGetFix, "Class")
//                        || StrUtils.endsWith(methodGetFix, "Out")
//                        || StrUtils.endsWith(methodGetFix, "NotNullFlg")) {
//                    continue;
//                }
//                if (deafultExit) {
//                    if (CheckUtils.isEqual(methodGetFix, "CreatedUser")
//                            || CheckUtils.isEqual(methodGetFix, "CreatedDate")
//                            || CheckUtils.isEqual(methodGetFix, "LastModifiedUser")
//                            || CheckUtils.isEqual(methodGetFix, "LastModifiedDate")
//                            || StrUtils.endsWith(methodGetFix, "DeletedFlag")) {
//                        continue;
//                    }
//                }
//                if (exitPropListS != null) {
//                    boolean exitFlg = false;
//                    for (String exitProp : exitPropListS) {
//                        if (CheckUtils.isEqual(methodGetFix, StrUtils.upperMidFirst(exitProp))) {
//                            exitFlg = true;
//                            break;
//                        }
//                    }
//                    if (exitFlg) {
//                        continue;
//                    }
//                }
//                ColumnProperty columnProperty = getColumnProperty(methodGet);
//                index++;
//                int sort = 99999;
//                if (columnProperty != null) {
//                    sort = columnProperty.order();
//
//                }
//                treeMap.put(
//                        StrUtils.leftPad(StrUtils.defaultString(sort), 5, "0")
//                        + StrUtils.leftPad(StrUtils.defaultString(index), 5, "0"),
//                        methodGetFix);
////                methodName.add(methodGetFix);
//            }
//        }
//        for (String temp : treeMap.values()) {
//            methodName.add(temp);
//        }
//        return methodName;
//    }

    public static Object runMethod(Object _objGet, String methodName, Object... params) throws Exception {
        Method[] methodsGet = _objGet.getClass().getMethods();
        for (Method methodGet : methodsGet) {
            String methodGetName = methodGet.getName();
            if (CheckUtils.isEqual(methodGetName, methodName)) {
                return methodGet.invoke(_objGet, params);
            }
        }
        throw new SystemException("method not found :" + methodName);
    }

//    /**
//     * getAnnotation Information
//     *
//     * @param method
//     * @param clazz
//     * @return
//     * @throws Exception
//     */
//    public static ColumnProperty getColumnProperty(Method method) throws Exception {
//        ColumnProperty comAnn = method.getAnnotation(ColumnProperty.class);
//        if (comAnn != null) {
//            return comAnn;
//        } else {
//            String varFieldName = getFieldNameByMethodName(method
//                    .getName());
//            try {
//                Field field = method.getDeclaringClass().getDeclaredField(varFieldName);
//                comAnn = field.getAnnotation(ColumnProperty.class);
//                if (field != null && comAnn != null) {
//                    return comAnn;
//                }
//            } catch (Exception e) {
////                LogUtils.debug("miss Column " + varFieldName);
//            }
//        }
//        return comAnn;
//    }

    /**
     * is methodName query fieldName
     *
     * @param methodName
     * @return String
     */
    public static String getFieldNameByMethodName(String methodName) {

        if (methodName.startsWith("get")) {
            String varFieldName = methodName.substring(3);
            String varUpToLower = StrUtils.lowerFirst(varFieldName);
            if (!("".equals(varUpToLower))) {
                return varUpToLower;
            }
        } else if (methodName.startsWith("is")) {
            String varFieldName = methodName.substring(2);
            String varUpToLower = StrUtils.lowerFirst(varFieldName);
            if (!("".equals(varUpToLower))) {
                return varUpToLower;
            }
        }
        return null;
    }

    /**
     * @param clazz The class to introspect
     * @return the first generic declaration, or Object.class if cannot be
     * determined
     */
    @SuppressWarnings("unchecked")
    public static <T> Class<T> getClassGenricType(final Class clazz) {
        return getClassGenricType(clazz, 0);
    }

    /**
     *
     * @param clazz clazz The class to introspect
     * @param index the Index of the generic ddeclaration,start from 0.
     * @return the index generic declaration, or Object.class if cannot be
     * determined
     */
    public static Class getClassGenricType(final Class clazz, final int index) {

        Type genType = clazz.getGenericSuperclass();

        if (!(genType instanceof ParameterizedType)) {
            return Object.class;
        }

        Type[] params = ((ParameterizedType) genType).getActualTypeArguments();

        if (index >= params.length || index < 0) {
            return Object.class;
        }
        if (!(params[index] instanceof Class)) {
            return Object.class;
        }

        return (Class) params[index];
    }

    public static void jsonToDto(JSONObject data, Object target) throws Exception {
        if (target == null) {
            return;
        }
        for (String key : data.keySet()) {

            setDataAsString(target, key, data.getString(key));

        }
    }

    public static void dtoToJson(Object data, JSONObject target) throws Exception {
        dtoToJsonSub(data, data.getClass(), target);
    }

    public static void dtoToJsonSub(Object data, Class objClass, JSONObject target) throws Exception {
        if (target == null) {
            target = new JSONObject();
        }
        for (Field tmp : data.getClass().getDeclaredFields()) {
            if (target.has(tmp.getName())) {
                continue;
            }
            String value = getDataAsString(data, tmp.getName());
            if (!CheckUtils.isEmpty(value)) {
                target.put(tmp.getName(), value);
            }

        }
        if (objClass.getSuperclass() != null) {
            dtoToJsonSub(data, objClass.getSuperclass(), target);
        }
    }

    public static void main(String args[]) throws Exception {
//        DataAccessDto dataAccessDto01 = new DataAccessDto();
//        System.out.println(isDataNull(dataAccessDto01));
//        dataAccessDto01.setDeleteFlag(1);
//        dataAccessDto01.setGroupName("3");
//        System.out.println(isDataNull(dataAccessDto01));
//        dtoToJson(dataAccessDto01, target01);
//        
//
//        JSONObject target02 = new JSONObject();
//        DataAccessDto dataAccessDto02 = new DataAccessDto();
//        jsonToDto(target01, dataAccessDto02);
//        dtoToJson(dataAccessDto02, target02);
//        System.out.print(target02.toString());
    }
}
