/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common.annotation.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import jp.co.kintetsuls.beans.common.annotation.NumericCheck;
import jp.co.kintetsuls.utils.CheckUtils;

/**
 * 数値チェック
 * 
 * @author zf (MBP)
 * @version 2019/3/7 新規作成
 */
public class NumericCheckValidator implements ConstraintValidator<NumericCheck, String> { 

    @Override
    public void initialize(NumericCheck constraintAnnotation) {
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (CheckUtils.isEmpty(value)) {
            return true;
        }
        if (!CheckUtils.isNumber(value)) {
            return false;
        }
        return true;
    }
    
}
