/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.beans.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import javax.servlet.http.HttpServletRequest;
import jp.co.kintetsuls.cnst.Cnst.SCREEN;
import jp.co.kintetsuls.cnst.MessageCnst;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.exception.SystemException;
import jp.co.kintetsuls.forms.common.UploadForm;
import jp.co.kintetsuls.service.general.RestfullService;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.kintetsuls.utils.StrUtils;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import jp.co.sharedsys.beans.session.BreadCrumbBean;
import lombok.Data;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;

/**
 * 共通アップロード画面
 *
 * @author MaLei (MBP)
 * @version 2019/03/11 新規作成
 */
@javax.faces.bean.ManagedBean(name = "upload")
@ViewScoped
@Data
public class UploadBean extends AbstractBean {

    /**
     * 画面タイトル
     */
    private final String titleName = "共通アップロード";

    /**
     * 遷移用URL
     */
    private String url;

    @ManagedProperty(value = "#{breadBean}")
    private BreadCrumbBean breadBean;

    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    private static final Logger logger = LogManager.getLogger(new Object() {
    }.getClass().getEnclosingClass().getName());

    @ManagedProperty(value = "#{uploadForm}")
    private UploadForm uploadForm;

    private RestfullService rest;

    /**
     * 画面共通作業
     */
    @ManagedProperty(value = "#{pageCommon}")
    private PageCommonBean pageCommonBean;

    /**
     * 共通作業
     */
    @ManagedProperty(value = "#{searchHelpBean}")
    private SearchHelpBean searchHelpBean;

    /**
     * AutoCompleteリスト作成
     */
    @ManagedProperty(value = "#{autoCompleteViewBean}")
    private AutoCompleteViewBean autoCompleteViewBean;

    /**
     * メッセージ出力
     */
    @ManagedProperty(value = "#{messagePropertyBean}")
    private MessagePropertyBean messageProperty;

    /**
     * ftpでdataSpiderと連携
     */
    @ManagedProperty(value = "#{fileFtpToDataspider}")
    private FileFtpToDataspider fileFtpToDataspider;
    
    // ワーク.メッセージリスト
    List<MessageModuleBean> msgList = new ArrayList<>();

    /**
     * ScreenCode：UPLOAD.
     */
    private static final String SC_CD_UPLOAD = "UPLOAD_SCREEN";

    /**
     * マスタ情報.
     */
    private MasterInfoBean masterInfo;

    /**
     * 定数：MasterInfo取得key.
     */
    private static final String CONST_UPLOAD_MASTER = "upload";

    /**
     * 定数：画面項目保持key.
     */
    private static final String CONST_UPLOAD_FORM = "uploadForm";

    /**
     * 定数：テーブルアップロードFUNC_CODE.
     */
    private static final String FUNC_CODE_FILE_UPLOAD = "upload_file";

    /**
     * 定数：検索FUNC_CODE.
     */
    private static final String FUNC_CODE_CHECK = "upload_check";

    /**
     * ログ出力
     */
    private static final Logger LOGGER = LogManager.getLogger(
            new Object() {}.getClass().getEnclosingClass().getName());
    
    // アップロードファイル
    private ArrayList<UpLoadFileDataModel> upLoadFileStream = new ArrayList<>();
    private UploadedFile file;
    // 画面からアップロードされたファイルの格納先
    private List<File> uploadFiles;
    private List<String> tmpFileList = new ArrayList<>();

    public void upload() {
        if (file != null) {
            FacesMessage message = new FacesMessage("Succesful", file.getFileName() + " is uploaded.");
            FacesContext.getCurrentInstance().addMessage(null, message);
        }
    }

    public void handleFileUpload(FileUploadEvent event) {
        FacesMessage msg = new FacesMessage("Succesful", event.getFile().getFileName() + " is uploaded.");
        FacesContext.getCurrentInstance().addMessage(null, msg);
    }

    /**
     * コンストラクタ
     */
    public UploadBean() {

    }

    /**
     * 初期処理（処理）
     *
     * @param menuId クリックされたメニューID（メニューからの遷移以外はNULL）
     * @param prevScreen 遷移元の画面
     * @param backFlag 戻るフラグ（前画面へボタンからの遷移以外はFALSE）
     */
    @Override
    public void init(String menuId, String prevScreen, boolean backFlag) {

        try {
            // パンくず追加
            breadBean.push("共通アップロード画面", SCREEN.UPLOAD_SCREEN.name(), this);

            // マスタ内容取得
            pageCommonBean.getMasterInfo(CONST_UPLOAD_MASTER);

            // 戻ってきた場合
            UploadForm preForm = (UploadForm) pageCommonBean.getPageInfo(CONST_UPLOAD_FORM);
            if (backFlag) {
                PageCommonBean.simpleCopy(preForm, uploadForm);
                // 進んできた場合
            } else {
                Flash flash = pageCommonBean.getPageParam();
                // 検索パラメータがある場合、再検索に設定する
                if (flash != null && flash.get(CONST_UPLOAD_FORM) != null) {
                    PageCommonBean.simpleCopy(flash.get(CONST_UPLOAD_FORM), uploadForm);
                }
            }
            
            // component初期化とユーザ権限により制御設定
            pageCommonBean.setAuthControll(uploadForm, SC_CD_UPLOAD, true);

            uploadForm.setConCheckButtonDisabled(true);
            uploadForm.setConTourokuButtonDisabled(true);
            
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }

    }

    /**
     * ファイルアップロード(PrimeFacesのファイルアップロードを使用)
     *
     * @param event
     * @throws java.io.IOException
     */
    public void fileUpload(FileUploadEvent event) throws IOException, Exception {

        UpLoadFileDataModel upModel = new UpLoadFileDataModel();
        InputStream inputStr = null;
        InputStreamReader isr = null;
        BufferedReader br = null;
        FileInputStream fis = null;
        String fileName;

        FacesContext context = FacesContext.getCurrentInstance();
        HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest();
        String rootPath = request.getRealPath("/");

        try {
            // ファイル情報を取得(マルチ対応)
            List<UploadedFile> uploadFiles = new LinkedList<UploadedFile>();
            uploadFiles.add(event.getFile());
            
            // アップロードしたファイル数分対応
            for (int i = 0; i < uploadFiles.size(); i++) {
                // ストリーム情報を取得
                fileName = FilenameUtils.getName(uploadFiles.get(i).getFileName());
                inputStr = uploadFiles.get(i).getInputstream();
                upModel.setFileStream(inputStr);
                upModel.setFilePath(fileName);
                upLoadFileStream.add(upModel);
                File destFile = new File(rootPath + "fileTmp\\", upModel.getFilePath());
                FileUtils.copyInputStreamToFile(upModel.getFileStream(), destFile);
                
                fis=new FileInputStream(destFile.getPath());
                isr = new InputStreamReader(fis, "UTF-8");
                br = new BufferedReader(isr);
                String line = "";
                String[] arrs = null;
                int row = 0;
                List<Map<String,Object>> uploadRecList = new ArrayList<>();
                while ((line = br.readLine()) != null) {
                    line = line.replace("\"", "");
                    arrs = line.split(",");
                    if (row == 0) {
                        uploadForm.setHeaderSt(new ArrayList<String>(Arrays.asList(arrs)));
                    } else {
                        Map<String,Object> uploadRec = new HashMap();
                        if (arrs != null && arrs.length > 0) {
                            if (uploadForm.getHeaderSt().size() != arrs.length) {
                                messageProperty.message(MessagePropertyBean.SEVERITY_FATAL, (row + 1) + "行目に項目数は不正です！");
                                return;
                            }
                            for (int n = 0; n < arrs.length; n++) {
                                uploadRec.put(uploadForm.getHeaderSt().get(n), arrs[n]);
                            }
                            uploadRecList.add(uploadRec);
                        }
                    }
                    //System.out.println(arrs[0] + " : " + arrs[1] + " : " + arrs[2]);
                    row++;
                }
                uploadForm.setUploadResultSelectable(new ReportListDataModel(uploadRecList));
                uploadForm.setConCheckButtonDisabled(false);
            }
        } catch (Exception ex) {
            messageProperty.message(MessagePropertyBean.SEVERITY_FATAL, ex.getMessage());
            throw new SystemException(ex);
        } finally {
            if (fis != null) {
                fis.close();
            }
            if (br != null) {
                br.close();
            }
            if (isr != null) {
                isr.close();
            }
        }
        messageProperty.message(MessagePropertyBean.SEVERITY_INFO, "正常アップロード完了");
    }

    /**
     * ファイルアップの中身をチェックする
     *
     * @throws java.io.IOException
     */
    public void fileCheck() throws IOException, Exception {

        // データ選択チェックを行う
        if (uploadForm.getDataSelect() == null ||  uploadForm.getDataSelect().isEmpty()) {
            messageProperty.message(MessagePropertyBean.SEVERITY_ERROR,"COME0003","データ選択");
            return;
        }
        
        // パラメータ
        Map<String, Object> params = new HashMap<>();

        // アップロード対象テーブル
        params.put("tblName", uploadForm.getDataSelect());

        uploadForm.setConCheckButtonDisabled(true);
        uploadForm.setConTourokuButtonDisabled(false);
        
        // テーブル構造リスト
        List<Map> tableColMapList;
        try {
            // DBをアクセスする
            ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.getDBInfo(params, FUNC_CODE_CHECK);
            ObjectMapper mapper = new ObjectMapper();
            tableColMapList = mapper.readValue(serviceInterfaceBean.getJson(), List.class);
            String notNull = "";
            String dataType = "";
            Integer dataLength = 0;

            if (tableColMapList != null && tableColMapList.size() > 0) {
                List<Map<String, Object>> recMapList = uploadForm.getUploadResultSelectable().getDatasource();

                if (tableColMapList.size() != uploadForm.getHeaderSt().size()) {
                    messageProperty.message(MessagePropertyBean.SEVERITY_ERROR, "ファイルカラム数と指定テーブルカラム数は不一致です！");
                    uploadForm.setConCheckButtonDisabled(false);
                    uploadForm.setConTourokuButtonDisabled(true);
                    return;
                }
                
                for (Map<String, Object> recMap : recMapList) {
                    Map tempMapNullColor = new HashMap();
                    Map tempMapNullTooltips = new HashMap();
                    Map tempMapLongColor = new HashMap();
                    Map tempMapLongTooltips = new HashMap();
                    for (String key : recMap.keySet()) {
                        for (Map tableColMap : tableColMapList) {
                            if (tableColMap.get("COLUMN_NAME").equals(key)) {
                                notNull = (String) tableColMap.get("NULLABLE");
                                dataLength = (Integer) tableColMap.get("DATA_LENGTH");
                                dataType = (String) tableColMap.get("DATA_TYPE");
                                break;
                            }
                        }
                        // 必須チェック
                        if (notNull.equals("N") && CheckUtils.isEmpty(StrUtils.defaultString(recMap.get(key)).trim())) {
                            tempMapNullColor.put(key, "5");
                            tempMapNullTooltips.put(key + "_blank", true);
                            recMap.put(key, "blankCol;");
                        }
                        // サイズチェック
                        if (!"blankCol;".equals(recMap.get(key))) {
                            if (!"DATE".equals(dataType) && StrUtils.defaultString(recMap.get(key)).trim().getBytes("utf-8").length > dataLength) {
                                tempMapLongColor.put(key, "5");
                                tempMapLongTooltips.put(key + "_tooLong", true);
                            } else if (StrUtils.defaultString(recMap.get(key)).trim().getBytes().length > 19) {
                                tempMapLongColor.put(key, "5");
                                tempMapLongTooltips.put(key + "_tooLong", true);
                            }
                        }
                    }

                    if (tempMapNullColor.size() > 0 || tempMapLongColor.size() > 0) {
                        if (tempMapNullColor.size() > 0) {
                            tempMapNullColor.put("CHECK_STATUS", "5");
                            pageCommonBean.setIchiranRowColorByName(recMap, tempMapNullColor);
                            recMap.putAll(tempMapNullTooltips);
                        }
                        if (tempMapLongColor.size() > 0) {
                            tempMapLongColor.put("CHECK_STATUS", "5");
                            pageCommonBean.setIchiranRowColorByName(recMap, tempMapLongColor);
                            recMap.putAll(tempMapLongTooltips);
                        }
                        recMap.put("CHECK_STATUS", "エラー");
                        uploadForm.setConCheckButtonDisabled(false);
                        uploadForm.setConTourokuButtonDisabled(true);
                    } else {
                        recMap.put("CHECK_STATUS", "正常");
                    }
                }
               messageProperty.message(MessagePropertyBean.SEVERITY_INFO,"COMI0011", "チェック");
            } else {
               messageProperty.message(MessagePropertyBean.SEVERITY_ERROR, "指定したアップロード対象テーブル「" + uploadForm.getDataSelect() + "」は存在しません！");
            }
            
        } catch (IOException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

    }
    
    /**
     * ファイルをDataspiderへ伝送する
     *
     */
    public void fileToDataspider() {
        
        // ファイルアップロード(絶対パス)
//        fileFtpToDataspider.uploadFtpFileWithPath("/","mail.csv","D:\\mail.csv");

        // 行選択チェックを行う
        if (uploadForm.getSelectedSearchResult() == null || uploadForm.getSelectedSearchResult().isEmpty()) {

            MessageModuleBean message = messageProperty.createMessageModule(
                    MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
            msgList.add(message);

            messageProperty.messageList(msgList);
            return;
        }

        ServiceInterfaceBean serviceInterfaceBean = pageCommonBean.uploadDBWithList(
                uploadForm.getSelectedSearchResult(), FUNC_CODE_FILE_UPLOAD, uploadForm.getDataSelect());
        
        if (serviceInterfaceBean.getStatusCode() == ServiceInterfaceBean.PROCESS_STATUS_SUCCESS) {
            messageProperty.message(MessagePropertyBean.SEVERITY_INFO, serviceInterfaceBean.getMessages().get(0)[2]);
            List<Map<String, Object>> bodyList = uploadForm.getUploadResultSelectable().getDatasource();
            bodyList.removeAll(uploadForm.getSelectedSearchResult());
            uploadForm.getSelectedSearchResult().clear();
            if (bodyList.isEmpty()) {
                uploadForm.setUploadResultSelectable(null);
            }
        } else {
            messageProperty.message(MessagePropertyBean.SEVERITY_ERROR, "テーブル登録が失敗しました！");
        }
        
    }

    /**
     * パラメータ作成
     *
     * @return パラメータ
     */
    public Map<String, Object> getParams() {

        //パラメータ
        Map<String, Object> params = new HashMap<>();

        return params;
    }

    /**
     * メニュークリック（処理）
     *
     * @param menuId クリックされたメニューID（メニューからの遷移以外はNULL）
     * @param nextScreen 遷移先の画面
     * @return 遷移先の画面URL
     */
    @Override
    public String menuClick(String menuId, String nextScreen) {

        // 行選択チェック
        if (uploadForm.getSelectedSearchResult().isEmpty()) {

            MessageModuleBean message = messageProperty.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
            msgList.add(message);

            messageProperty.messageList(msgList);
            return null;
        }

        try {
            // パンくずの削除
            breadBean.pop(1);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }

        return url;
    }

    /**
     * パンくずクリック（処理）
     *
     * @param nextScreen 遷移先の画面
     * @param breadIndex 選択されたパンくずのIndex
     * @return 遷移先の画面URL
     */
    @Override
    public String breadClumClick(String nextScreen, int breadIndex) {

        try {
            // パンくずの削除
            breadBean.pop(breadIndex);
        } catch (IllegalAccessException | InvocationTargetException ex) {
            logger.error(ex.getMessage(), ex);
        }
        url = forward(nextScreen, null, null, false);
        return url;
    }

    /**
     * ログアウトクリック（処理）
     *
     * @return 遷移先の画面URL
     */
    @Override
    public String logoutClick() {
        return authConfBean.logout();
    }

    /**
     * 画面遷移処理
     *
     * @param actionFlg 処理フラグ
     * @return 遷移先の画面URL
     * @throws java.lang.IllegalAccessException
     * @throws java.lang.reflect.InvocationTargetException
     */
    public String buttonClick(String actionFlg) throws IllegalAccessException, InvocationTargetException {

        // TODO 入力チェック
        // 行選択チェック
        if (uploadForm.getSelectedSearchResult().isEmpty()) {

            MessageModuleBean message = messageProperty.createMessageModule(MessagePropertyBean.SEVERITY_ERROR, MessageCnst.COME0029);
            msgList.add(message);

            messageProperty.messageList(msgList);
            return null;
        }
        return url;
    }

    /**
     * タイトル取得
     *
     * @return タイトル
     */
    public String getTitleName() {
        return titleName;
    }
}
