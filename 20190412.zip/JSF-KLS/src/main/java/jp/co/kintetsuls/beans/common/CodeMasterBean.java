package jp.co.kintetsuls.beans.common;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import jp.co.kintetsuls.cnst.MsCnst;
import jp.co.kintetsuls.cnst.StndConsIF;
import jp.co.kintetsuls.file.FaceCodeMasterDto;
import jp.co.kintetsuls.utils.DateUtils;
import jp.co.sharedsys.beans.session.AuthorityConfBean;
import lombok.Data;

/**
 *
 * @author tdm
 */
@ManagedBean(name = "codeMasterBean")
@SessionScoped
@Data
public class CodeMasterBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @ManagedProperty(value = "#{autoComplete}")
    private AutoCompleteBean autoCompleteBean;
    
    @ManagedProperty(value = "#{authConfBean}")
    private AuthorityConfBean authConfBean;

    @ManagedProperty(value = "#{kbnBean}")
    private KbnBean kbnBean;

    /**
     * 共通マスタ取得
     * 
     * @param name Function_code
     * @param param パラメータ
     * @return 共通マスタリスト
     */
    public List<FaceCodeMasterDto> getComMsDatas(String name, String param) {

        return this.getComMsDatas(name, param, false);
    }
    
    /**
     * 共通マスタ取得
     * 
     * @param name Function_code
     * @param param パラメータ
     * @param honshaFlg 本社フラグ
     * @return 共通マスタリスト
     */
    public List<FaceCodeMasterDto> getComMsDatas(String name, String param, boolean honshaFlg) {

        Map params = new HashMap();
        // ログインユーザーコードの取得について
        params.put("loginuserCd", authConfBean.getUserCd());
        // システム日付
        params.put("sysDate", DateUtils.format(DateUtils.getSysDate(), StndConsIF.DF_YYYY_MM_DD));
        
        String key = name;
        
        // 区分マスタ取得、付帯料金項目1取得、または、付帯料金項目2取得の特別処理
        if (MsCnst.COM_GET_MS_KBN.equals(name) || 
                MsCnst.COM_GET_VW_FUTAI_RYOKIN_KOMOKU1.equals(name) || 
                MsCnst.COM_GET_VW_FUTAI_RYOKIN_KOMOKU2.equals(name)) {
            if (param != null) {
                key = name.concat("_").concat(param);
                
                if (MsCnst.COM_GET_MS_KBN.equals(name)) {
                    params.put("kbnGroupCd", param);
                } else {
                    params.put("uriageKbn", kbnBean.getKbnCdOfKeyCd(param));
                    params.put("KBN_KEY", param);
                }
            }
        }
        autoCompleteBean.initAutoComplete(name, params);
        
        List<FaceCodeMasterDto> list = convAutoCompToFaceCode(autoCompleteBean.getSearchResultMap().get(key));
        
        // 集約コードの場合
        if ("SHUYAKU_CD_KBN".equals(param)) {
            if (!honshaFlg) {
                // 本社でないの場合
                // 集約コード(営業所)のみ選択可能
                list = new ArrayList<>();
                FaceCodeMasterDto dto = new FaceCodeMasterDto();
                KbnModuleBean kbnInfo = kbnBean.getKbnInfoOfKeyCd(MsCnst.SHUYAKU_CD_KBN_SHUYAKU_CD_EIGYOSHO);
                dto.setCode(kbnInfo.getKbnCd());
                dto.setValue(kbnInfo.getKbnMei());
                list.add(dto);
            }
        }
        return list;
    }
    
    /**
     * AutoCompOptionBeanからFaceCodeMasterDtoへ変換する
     * 
     * @param autoCompList
     * @return 
     */
    private List<FaceCodeMasterDto> convAutoCompToFaceCode(List<AutoCompOptionBean> autoCompList) {
        List<FaceCodeMasterDto> result = new ArrayList<>();
        autoCompList.stream().map((autoComp) -> {
            FaceCodeMasterDto dto = new FaceCodeMasterDto();
            dto.setCode(autoComp.getValue());
            dto.setValue(autoComp.getLabel());
            return dto;
        }).forEachOrdered((dto) -> {
            result.add(dto);
        });
        return result;
    }
    
//    @EJB
//    CommonService commonService;
//    public List<FaceCodeMasterDto> getDictTypeList() throws Exception {
//
//        return commonService.getDictTypeList();
//    }
    public List<FaceCodeMasterDto> getDictList(String code) throws Exception {
        List<FaceCodeMasterDto> result = new ArrayList<>();
        result.add(new FaceCodeMasterDto("", ""));
        result.add(new FaceCodeMasterDto("1", "A"));
        result.add(new FaceCodeMasterDto("2", "B"));
        result.add(new FaceCodeMasterDto("3", "C"));
        result.add(new FaceCodeMasterDto("4", "D"));

        return result;//        return getDictList(code, StndConsIF.BLANK_FLG_FALSE);
    }

//    public List<FaceCodeMasterDto> getDictList(String code, String blankFlg) throws Exception {
//
//        return commonService.getDictList(code, blankFlg);
//    }
//
//    public List<FaceCodeMasterDto> getDictListDouble(String code, String code1) throws Exception {
//        return getDictListDouble(code, code1, StndConsIF.BLANK_FLG_FALSE);
//
//    }
//
//    public List<FaceCodeMasterDto> getDictListDouble(String code, String code1, String blankFlg) throws Exception {
//        return commonService.getDictListDouble(code, code1, blankFlg);
//    }
//
//    public List<FaceCodeMasterDto> getDictListRelation(String relationType, String relationCode) throws Exception {
//        return getDictListRelation(relationType, relationCode, StndConsIF.BLANK_FLG_FALSE);
//    }
//
//    public List<FaceCodeMasterDto> getDictListRelation(String relationType, String relationCode, String blankFlg) throws Exception {
//        return commonService.getDictTypeListRelation(relationType, relationCode, blankFlg);
//    }
//
//    public String getDictStr(String type, String code) throws Exception {
//        return commonService.getDictStr(type, code);
//    }
//
//    public String getDictStrList01(String type, List<String> codeList) throws Exception {
//
//        String result = "";
//        if (codeList == null) {
//            return "";
//        }
//        for (String tmp : codeList) {
//            if (!CheckUtils.isEmpty(result)) {
//                result += ",";
//            }
//            result += commonService.getDictStr(type, tmp);
//        }
//        return result;
//    }
//
//    public String getInsuranceGroupTypeName(String type) throws Exception {
//        return commonService.getInsuranceGroupTypeName(type);
//    }
//
//    public String getInsuranceTypeName(String insuranceTypeShowCd, String insuranceGroupTypeCd, String insuranceTypeCd) throws Exception {
//        return commonService.getInsuranceTypeName(insuranceTypeShowCd, insuranceGroupTypeCd, insuranceTypeCd);
//    }
//
//    public String getUserName(Integer userId) throws Exception {
//        return commonService.getUserName(userId);
//    }
//
//    public String getDictStrS(List<FaceCodeMasterDto> data, String code) throws Exception {
//        if (data == null || CheckUtils.isEmpty(code)) {
//
//            return code;
//
//        }
//        for (FaceCodeMasterDto tmp : data) {
//            if (CheckUtils.isEqual(tmp.getCode(), code)) {
//                return tmp.getValue();
//            }
//        }
//        return "";
//    }
//
//    public String getDictStrList(List<FaceCodeMasterDto> data, List<String> code) {
//        String result = "";
//        if ((data == null) || (data.isEmpty())) {
//            return "";
//        }
//        if ((code == null) || (code.isEmpty())) {
//            return "";
//        }
//        for (FaceCodeMasterDto tmp : data) {
//            if (code.contains(tmp.getCode())) {
//                if (!CheckUtils.isEmpty(result)) {
//                    result = result + ",";
//                }
//                result = result + tmp.getValue();
//            }
//        }
//
//        return result;
//
//    }
//
//
//    public String getSqlDataStr(String sqlId, String code) throws Exception {
//        if (StrUtils.getStringLength(sqlId) == 2) {
//            sqlId = "extpro00" + sqlId;
//        }
//        return commonService.SqlDataStr(sqlId, code);
//    }
//
//    public String getSqlDataDlgUrl(String sqlId, String tid) throws Exception {
//        HashMap<String, String> params = new HashMap<>();
//        params.put("sqlId", sqlId);
//        params.put("tid", tid);
//        return this.redirect("com90002", params);
//    }
//
//    public String getDictStrMapList(List<CodeListDto> data) {
//        String result = "";
//        if ((data == null) || (data.isEmpty())) {
//            return "";
//        }
//        for (CodeListDto tmp : data) {
//            for (FaceCodeMasterDto temp : tmp.getDtoList()) {
//                if (tmp.getIdList() != null && tmp.getIdList().contains(temp.getCode())) {
//                    if (!CheckUtils.isEmpty(result)) {
//                        result = result + ",";
//                    }
//                    result = result + temp.getValue();
//                }
//            }
//        }
//        return result;
//    }
}
