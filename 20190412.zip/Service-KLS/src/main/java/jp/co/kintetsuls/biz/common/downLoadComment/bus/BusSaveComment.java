/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.biz.common.downLoadComment.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Map;
import javax.annotation.Resource;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.common.shinseiDatasakusei.dao.DataShinseiDao;
import jp.co.kintetsuls.biz.table.dao.TrKyotsuShinseiDao;
import jp.co.kintetsuls.biz.table.dao.TrKyotsuShinseiMeisaiDao;
import jp.co.kintetsuls.biz.table.dao.TrShinseiDao;
import jp.co.kintetsuls.biz.table.dao.TrShinseiShosaiDao;
import jp.co.kintetsuls.biz.table.model.TrKyotsuShinsei;
import jp.co.kintetsuls.biz.table.model.TrKyotsuShinseiMeisai;
import jp.co.kintetsuls.biz.table.model.TrShinsei;
import jp.co.kintetsuls.biz.table.model.TrShinseiShosai;
import jp.co.kintetsuls.common.SystemColumn;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

/**
 *
 * @author liuchengjiang
 */
@Component("SAVE_COMMENT")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class BusSaveComment  extends BaseBus {

    /** 申請データDAO */
    @Autowired(required=true)
    @Resource(shareable=true)
    protected DataShinseiDao dataShinseiDao;
    
     /** 申請テーブルDAO */
    @Autowired(required=true)
    @Resource(shareable=true)
    protected TrShinseiDao shinseiDao;

    /** 申請詳細テーブルDAO */
    @Autowired(required=true)
    @Resource(shareable=true)
    protected TrShinseiShosaiDao trShinseiShosaiDao;
    
    /** 共通申請テーブルDAO */
    @Autowired(required=true)
    @Resource(shareable=true)
    protected TrKyotsuShinseiDao trKyotsuShinseiDao;
    
    /** 共通申請明細テーブルDAO */
    @Autowired(required=true)
    @Resource(shareable=true)
    protected TrKyotsuShinseiMeisaiDao trKyotsuShinseiMeisaiDao;
    
    private static final String GET_SEQUENCE = "getShinseiIdSeq";
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, Object> paramMap = objectMapper.readValue(serviceInterfaceBean.getJson(), Map.class);
        //共通申請テーブル
        TrKyotsuShinsei kyotsuShinsei = new TrKyotsuShinsei();
        // システムカラム
        kyotsuShinsei = SystemColumn.systemColumnSet(1, kyotsuShinsei, serviceInterfaceBean);
        // 申請ID
        kyotsuShinsei.setShinseiId(dataShinseiDao.getSequence(GET_SEQUENCE).toString());
        // 申請種別コード
        kyotsuShinsei.setShinseiShubetsuCd("19");
        // 申請営業所コード
        kyotsuShinsei.setShinseiEigyoshoCd(serviceInterfaceBean.getDefaultEigyosho());
        // 申請者コード
        kyotsuShinsei.setShinseishaCd(serviceInterfaceBean.getUserCd());
        // 申請日時
        kyotsuShinsei.setShinseiNichiji(DateUtils.getSysDate());
        // 申請コメント
        kyotsuShinsei.setShinseiComment(paramMap.get("comment").toString());
        // 削除フラグ
        kyotsuShinsei.setSakujoFlg("0");
        trKyotsuShinseiDao.insert(kyotsuShinsei);
        
        // 共通申請明細
        TrKyotsuShinseiMeisai trKyotsuShinseiMeisai = new TrKyotsuShinseiMeisai();
        // システムカラム
        trKyotsuShinseiMeisai = SystemColumn.systemColumnSet(1, trKyotsuShinseiMeisai, serviceInterfaceBean);
        // 申請ID
        trKyotsuShinseiMeisai.setShinseiId(kyotsuShinsei.getShinseiId());
        // 共通申請明細NO
        trKyotsuShinseiMeisai.setKyotsuShinseiMeisaiNo(Long.valueOf("1"));
        // 申請種別コード
        trKyotsuShinseiMeisai.setShinseiShubetsuCd("19");
        // 表示用キー情報
        trKyotsuShinseiMeisai.setHyojiyoKeyJoho(paramMap.get("gamenId").toString());
        // キー情報
        trKyotsuShinseiMeisai.setKeyJoho(serviceInterfaceBean.getUserCd() + "," + paramMap.get("gamenId").toString());
        // 表示項目３
        trKyotsuShinseiMeisai.setHyojiKomoku3(paramMap.get("filename").toString());
        // 表示項目４
        trKyotsuShinseiMeisai.setHyojiKomoku4(paramMap.get("kensu").toString());
        // 表示項目５
        String kakouChouShi = paramMap.get("filename").toString();
        String [] kamoku5 = kakouChouShi.split("\\.");
        if (kamoku5.length > 1) {
            trKyotsuShinseiMeisai.setHyojiKomoku5(kamoku5[1]);
        }
        // 表示項目６
        trKyotsuShinseiMeisai.setHyojiKomoku6(serviceInterfaceBean.getUserCd() + "," +
                paramMap.get("kensu").toString());
        // 申請理由
        trKyotsuShinseiMeisai.setShinseiRiyu(paramMap.get("comment").toString());
        // 削除フラグ
        trKyotsuShinseiMeisai.setSakujoFlg("0");
        trKyotsuShinseiMeisaiDao.insert(trKyotsuShinseiMeisai);
        
        
        // 申請
        TrShinsei trShinsei = new TrShinsei();
        trShinsei = SystemColumn.systemColumnSet(1, trShinsei, serviceInterfaceBean);
        // 申請ID
        trShinsei.setShinseiId(kyotsuShinsei.getShinseiId());
        // 申請種別コード
        trShinsei.setShinseiShubetsuCd("19");
        // 申請日
        trShinsei.setShinseiBi(DateUtils.getSysDate());
        // 申請ステータス
        trShinsei.setShinseiStatus("04");
        // 至急フラグ
        trShinsei.setShikyuFlg("0");
        shinseiDao.insert(trShinsei);
        
        
        // 申請詳細(1レコード目)
        TrShinseiShosai trshinseiShosai = new TrShinseiShosai();
        trshinseiShosai = SystemColumn.systemColumnSet(1, trshinseiShosai, serviceInterfaceBean);
        // 申請ID
        trshinseiShosai.setShinseiId(kyotsuShinsei.getShinseiId());
        // 申請詳細NO
        trshinseiShosai.setShinseiShosaiNo(1);
        // 承認状況結果
        trshinseiShosai.setShoninJokyoKekka("01");
        // ユーザーコード
        trshinseiShosai.setUserCd(serviceInterfaceBean.getUserCd());
        // 営業所コード
        trshinseiShosai.setEigyoshoCd(serviceInterfaceBean.getDefaultEigyosho());
        // 更新日
        trshinseiShosai.setKoshinBi(DateUtils.getSysDate());
        // 申請コメント
        trshinseiShosai.setShinseiComment(paramMap.get("comment").toString());
        // 削除フラグ
        trshinseiShosai.setSakujoFlg("0");
        trShinseiShosaiDao.insert(trshinseiShosai);
        
        
        // 申請詳細(2レコード目)
        TrShinseiShosai trshinseiShosai1 = new TrShinseiShosai();
        trshinseiShosai1 = SystemColumn.systemColumnSet(1, trshinseiShosai1, serviceInterfaceBean);
        // 申請ID
        trshinseiShosai1.setShinseiId(kyotsuShinsei.getShinseiId());
        // 申請詳細NO
        trshinseiShosai1.setShinseiShosaiNo(2);
        // 承認状況結果
        trshinseiShosai1.setShoninJokyoKekka("05");
        // 更新日
        trshinseiShosai1.setKoshinBi(DateUtils.getSysDate());
        // 削除フラグ
        trshinseiShosai1.setSakujoFlg("0");
        trShinseiShosaiDao.insert(trshinseiShosai1);
    }
    
}
