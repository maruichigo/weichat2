/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.common.masterinfo.bus;

import java.util.List;
import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;

import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.table.dao.MsKbnDao;
import jp.co.kintetsuls.biz.table.model.MsKbn;
import jp.co.kintetsuls.common.json.JSONUtil;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 区分マスタ内容取得処理クラス
 * 
 * @author zf (MBP)
 * @version 2019/2/21 新規作成
 */
@Component("COMMON_GET_MS_KBN")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ComKbnBus extends BaseBus {

    // Dao定義
    @Autowired(required=true)
    @Resource(shareable=true)
    protected MsKbnDao msKbnDao;
    
    public List<MsKbn> kbnList;

    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception{
        
        kbnList = msKbnDao.findAll();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(kbnList));
    }
}