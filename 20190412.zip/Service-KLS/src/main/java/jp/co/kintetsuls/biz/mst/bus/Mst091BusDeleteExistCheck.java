/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.mst.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import java.util.Map;
import jp.co.kintetsuls.common.cnst.MessageCnst;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.common.versionCheck.bus.BusVersionCheck;
import jp.co.kintetsuls.biz.mst.dao.Mst091Dao;
import jp.co.kintetsuls.common.cnst.MessageCnst;

/**
 * 仕入予定一覧削除存在チェック処理
 *
 * @author 廖鈺 (MBP)
 * @version 2019/1/24 新規作成
 */
@Component("MST091_DELETE_EXIST_CHECK")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Mst091BusDeleteExistCheck extends BaseBus {

    /**
     * DAO定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected Mst091Dao mst091Dao;

    /**
     * バージョンチェック(排他)
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected BusVersionCheck busVersionCheck;

    /**
     * 文字列：仕入予定明細マスタ
     */
    private static final String SHIIRE_YOTEI_MEISAI_MASTER = "仕入予定明細マスタ";

    /**
     * 文字列：仕入予定マスタ
     */
    private static final String SHIIRE_YOTEI_MASTER = "仕入予定マスタ";

    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {

        // 削除一覧リスト
        Map param = null;
        
        // 適用開始日フォーマット
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");

        // パラメータを解析する
        ObjectMapper mapper = new ObjectMapper();
        List<Map<String, Object>> recordList = mapper.readValue(serviceInterfaceBean.getJson(), List.class);

        // 仕入予定明細マスタ検索
        int count = 0;
        for (Map<String, Object> record : recordList) {

            // 削除一覧リスト作成
            param = new HashMap();

            // 営業所コード
            param.put("listEigyoshoCd", record.get("listEigyoshoCd"));
            // 仕入先コード
            param.put("listShiiresakiCd", record.get("listShiiresakiCd"));
            // 仕入区分コード
            param.put("listShiireKbnCd", record.get("listShiireKbnCd"));
            // 適用開始日
            param.put("listTekiyoKaisibi", record.get("listTekiyoKaisibi"));

            // 仕入予定明細マスタ存在チェック処理
            if (0 == mst091Dao.findFromMsShiireYotelMeisai(param)) {
                count++;
                serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                serviceInterfaceBean.setJson(JSONUtil.makeJSONString(count));
                // エラーメッセージを表示させ、処理を終了
                serviceInterfaceBean.addMessage("ERROR", MessageCnst.COME0043, "仕入予定明細データ");
                serviceInterfaceBean.setTableName(SHIIRE_YOTEI_MEISAI_MASTER);

                return;
            }

            // 明細NO検索を処理する
            List<Map<String, Object>> resultList = mst091Dao.findMeiSaiNo(param);

            for (Map<String, Object> result : resultList) {
                // 営業所コード
                param.put("EIGYOSHO_CD", record.get("listEigyoshoCd"));
                // 仕入先コード
                param.put("SHIIRESAKI_CD", record.get("listShiiresakiCd"));
                // 仕入区分コード
                param.put("SHIIRE_KBN_CD", record.get("listShiireKbnCd").toString());
                // 適用開始日
                param.put("TEKIYO_KAISHIBI", dateFormat.parse(record.get("listTekiyoKaisibi").toString()));
                // 明細NO
                param.put("MEISAI_NO", result.get("listMeisaiNo").toString());
                // 更新ユーザーID
                param.put("koushinUserCd", record.get("koushinUserCd"));
                // 更新カウンタ
                param.put("koushinCounter", record.get("koushinCounter"));
                // テーブル名
                param.put("tblName", "MS_SHIIRE_YOTEI_MEISAI");
                // バージョンチェック(排他)
                if (!busVersionCheck.checkVersion(param)) {
                    serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                    serviceInterfaceBean.setJson(JSONUtil.makeJSONString(count));
                    // エラーメッセージを表示させ、処理を終了
                    serviceInterfaceBean.addMessage("WARN", MessageCnst.COME0014, "仕入予定明細データ");
                    serviceInterfaceBean.setTableName(SHIIRE_YOTEI_MEISAI_MASTER);
                    return;
                }
            }

            // 仕入予定マスタ存在チェック
            param = new HashMap();

            // 営業所コード
            param.put("listEigyoshoCd", record.get("listEigyoshoCd"));
            // 仕入先コード
            param.put("listShiiresakiCd", record.get("listShiiresakiCd"));
            // 仕入区分コード
            param.put("listShiireKbnCd", record.get("listShiireKbnCd"));
            // 適用開始日
            param.put("listTekiyoKaisibi", record.get("listTekiyoKaisibi"));

            // 仕入予定マスタ存在チェック処理
            if (0 == mst091Dao.findFromMsShiireYotel(param)) {

                count++;
                serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                serviceInterfaceBean.setJson(JSONUtil.makeJSONString(count));
                // エラーメッセージを表示させ、処理を終了
                serviceInterfaceBean.addMessage("ERROR", MessageCnst.COME0043, "仕入予定データ");
                serviceInterfaceBean.setTableName(SHIIRE_YOTEI_MASTER);

                return;
            }

            // 営業所コード
            param.put("EIGYOSHO_CD", record.get("listEigyoshoCd"));
            // 仕入先コード
            param.put("SHIIRESAKI_CD", record.get("listShiiresakiCd"));
            // 仕入区分コード
            param.put("SHIIRE_KBN_CD", record.get("listShiireKbnCd").toString());
            // 適用開始日
            param.put("TEKIYO_KAISHIBI", dateFormat.parse(record.get("listTekiyoKaisibi").toString()));
            // 更新ユーザーID
            param.put("koushinUserCd", record.get("koushinUserCd"));
            // 更新カウンタ
            param.put("koushinCounter", record.get("koushinCounter"));
            // テーブル名
            param.put("tblName", "MS_SHIIRE_YOTEI");
            // バージョンチェック(排他)
            if (!busVersionCheck.checkVersion(param)) {
                serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                serviceInterfaceBean.setJson(JSONUtil.makeJSONString(count));
                // エラーメッセージを表示させ、処理を終了
                serviceInterfaceBean.addMessage("WARN", MessageCnst.COME0014, "仕入予定データ");
                serviceInterfaceBean.setTableName(SHIIRE_YOTEI_MASTER);
                return;
            }
        }
    }
}
