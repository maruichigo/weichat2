package jp.co.kintetsuls.biz.common.menu.model;

import java.io.Serializable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/** 
 * メニューマスタクラス
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "menuItem")
public class MenuItem implements Serializable{

    private static final long serialVersionUID = 8965633291910057625L;

    @NotNull
    @Size(max = 6)
    private String menuId;

    private String menuName;
    private String screenId;
    
    /**メニューIDの取得
     * @return メニューID
     */
    @XmlElement(name = "menuId")
    public String getMenuId() {
        return menuId;
    }
    /**メニューIDの設定
     * @param menuId メニューID
     */
    public void setMenuId(String menuId) {
        this.menuId = menuId;
    }
    /** メニュー名の取得
     * @return menuName
     */
    @XmlElement(name = "menuName")
    public String getMenuName() {
        return menuName;
    }
    /** メニュー名の設定
     * @param menuName メニュー名
     */
    public void setMenuName(String menuName) {
        this.menuName = menuName;
    }
    /** 機能コードの取得
    * @return screenId
     */
    public String getScreenId() {
        return screenId;
    }
    /** 機能コードの設定
     * @param screenId 機能コード
     */
    public void setScreenId(String screenId) {
        this.screenId = screenId;
    }
}
