/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.biz.common.shinseiDatasakusei.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.common.shinseiDatasakusei.dao.DataShinseiDao;
import jp.co.kintetsuls.biz.table.dao.TrKyotsuShinseiDao;
import jp.co.kintetsuls.biz.table.dao.TrKyotsuShinseiMeisaiDao;
import jp.co.kintetsuls.biz.table.dao.TrShinseiDao;
import jp.co.kintetsuls.biz.table.dao.TrShinseiShosaiDao;
import jp.co.kintetsuls.biz.table.model.TrKyotsuShinsei;
import jp.co.kintetsuls.biz.table.model.TrKyotsuShinseiMeisai;
import jp.co.kintetsuls.biz.table.model.TrShinsei;
import jp.co.kintetsuls.common.SystemColumn;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

/**
 *
 * @author liuchengjiang
 */
@Component("SHINSEIDATA_SAKUSEI")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class BusShinseiDatasakusei extends BaseBus{
    
    /** 申請データDAO */
    @Autowired(required=true)
    @Resource(shareable=true)
    protected DataShinseiDao dataShinseiDao;
    
    /** 申請テーブルDAO */
    @Autowired(required=true)
    @Resource(shareable=true)
    protected TrShinseiDao shinseiDao;

    /** 申請詳細テーブルDAO */
    @Autowired(required=true)
    @Resource(shareable=true)
    protected TrShinseiShosaiDao trShinseiShosaiDao;
    
    /** 共通申請テーブルDAO */
    @Autowired(required=true)
    @Resource(shareable=true)
    protected TrKyotsuShinseiDao trKyotsuShinseiDao;
    
    /** 共通申請明細テーブルDAO */
    @Autowired(required=true)
    @Resource(shareable=true)
    protected TrKyotsuShinseiMeisaiDao trKyotsuShinseiMeisaiDao;
    

    private static final String GET_SEQUENCE = "getShinseiIdSeq";
    
    
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        List<Map<String, String>> list = mapper.readValue(serviceInterfaceBean.getJson(), List.class);
        int shinseiMeisaiNo = 1;
        for (Map<String, String> map : list) { 
            String checkFlg = sonzaiCheck(map);
            // データが存在する場合
            if ("1".equals(checkFlg)) {
                tblKoushin(map,serviceInterfaceBean);
            } else{
                // データが存在しない場合
                tblInsert(map, serviceInterfaceBean, shinseiMeisaiNo);
                shinseiMeisaiNo++;
            }
        }
    }
    
    /**
     * 更新処理
     * @param params 更新パラメタ
     * @param serviceInterfaceBean ServiceInterfaceBean
     */
    public void tblKoushin(Map<String, String> params, ServiceInterfaceBean serviceInterfaceBean){
        //共通申請テーブル
        TrKyotsuShinsei kyotsuShinsei = new TrKyotsuShinsei();
        // システムカラム
        kyotsuShinsei = SystemColumn.systemColumnSet(2, kyotsuShinsei, serviceInterfaceBean);
        // 申請日時
        kyotsuShinsei.setShinseiNichiji(DateUtils.getSysDate());
        // 共通申請テーブル更新
        trKyotsuShinseiDao.updateById(kyotsuShinsei, kyotsuShinsei);

        //共通申請明細テーブル
        TrKyotsuShinseiMeisai trKyotsuShinseiMeisai = new TrKyotsuShinseiMeisai();
        //システムカラム
        trKyotsuShinseiMeisai = SystemColumn.systemColumnSet(2, trKyotsuShinseiMeisai, serviceInterfaceBean);
        
        if (!params.isEmpty()) {
            //表示項目１
            trKyotsuShinseiMeisai.setHyojiKomoku1(params.get("hyoujiKomoKu1"));
            // 表示項目2
            trKyotsuShinseiMeisai.setHyojiKomoku2(params.get("hyoujiKomoKu2"));
            // 表示項目3
            trKyotsuShinseiMeisai.setHyojiKomoku3(params.get("hyoujiKomoKu3"));
            // 表示項目4
            trKyotsuShinseiMeisai.setHyojiKomoku4(params.get("hyoujiKomoKu4"));
            // 表示項目5
            trKyotsuShinseiMeisai.setHyojiKomoku5(params.get("hyoujiKomoKu5"));
            // 表示項目6
            trKyotsuShinseiMeisai.setHyojiKomoku6(params.get("hyoujiKomoKu6"));
        }
        //共通申請明細更新
        trKyotsuShinseiMeisaiDao.updateById(trKyotsuShinseiMeisai, trKyotsuShinseiMeisai);
        //申請テーブル
        TrShinsei trShinsei = new TrShinsei();
        trShinsei = SystemColumn.systemColumnSet(2, trShinsei, serviceInterfaceBean);
        // 申請ID
        trShinsei.setShinseiId(dataShinseiDao.getSequence(GET_SEQUENCE).toString());
        // 申請種別コード
        trShinsei.setShinseiShubetsuCd(params.get("shinseiShuBeitsuCd"));
        //申請日
        trShinsei.setShinseiBi(DateUtils.getSysDate());
        // 申請ステータス
        trShinsei.setShinseiStatus("01");
        // 現段階アクティビティNO
        trShinsei.setGenDankaiActivityNo(1);
        // 至急フラグ
        trShinsei.setShikyuFlg("0");
    }
    
    /**
     * 登録処理
     * @param params 登録パラメタ
     * @param serviceInterfaceBean ServiceInterfaceBean
     * @param kyoTsushinseiNo 共通申請明細No
     */
    public void tblInsert(Map<String, String> params,
            ServiceInterfaceBean serviceInterfaceBean, int kyoTsushinseiNo){
        
        
        //申請テーブル
        TrShinsei trShinsei = new TrShinsei();
        trShinsei = SystemColumn.systemColumnSet(1, trShinsei, serviceInterfaceBean);
        // 申請ID
        trShinsei.setShinseiId(dataShinseiDao.getSequence(GET_SEQUENCE).toString());
        // 申請種別コード
        trShinsei.setShinseiShubetsuCd(params.get("shinseiShuBeitsuCd"));
        // 申請日
        trShinsei.setShinseiBi(DateUtils.getSysDate());
        // 申請ステータス
        trShinsei.setShinseiStatus("01");
        // 現段階アクティビティNO
        trShinsei.setGenDankaiActivityNo(1);
        // 至急フラグ
        trShinsei.setShikyuFlg("0");
        // 削除フラグ
        trShinsei.setSakujoFlg("0");
        // 申請テーブルに登録
        shinseiDao.insert(trShinsei);
        
        
        // 共通申請テーブル
        TrKyotsuShinsei trKyotsuShinsei = new TrKyotsuShinsei();
        // システムカラム
        trKyotsuShinsei = SystemColumn.systemColumnSet(1, trKyotsuShinsei, serviceInterfaceBean);
        // 申請ID
        trKyotsuShinsei.setShinseiId(trShinsei.getShinseiId());
        if (!params.isEmpty()) {
            // 申請種別コード
            trKyotsuShinsei.setShinseiShubetsuCd(params.get("shinseiShuBeitsuCd"));
        }
        // 申請営業所コード
        trKyotsuShinsei.setShinseiEigyoshoCd(serviceInterfaceBean.getDefaultEigyosho());
        // 申請者コード
        trKyotsuShinsei.setShinseishaCd(serviceInterfaceBean.getUserCd());
        // 申請日時
        trKyotsuShinsei.setShinseiNichiji(DateUtils.getSysDate());
        // 申請コメント
        trKyotsuShinsei.setShinseiComment("");
        // ラベル情報
        trKyotsuShinsei.setLabelJoho("");
        // ラベル内容
        trKyotsuShinsei.setLabelNaiyo("");
        // メール受取フラグ
        trKyotsuShinsei.setMailUketoriFlg("");
        // 削除フラグ
        trKyotsuShinsei.setSakujoFlg("0");
        // 共通申請テーブル登録
        trKyotsuShinseiDao.insert(trKyotsuShinsei);

        // 共通申請明細テーブル
        TrKyotsuShinseiMeisai trKyotsuShinseiMeisai = new TrKyotsuShinseiMeisai();
        //システムカラム
        trKyotsuShinseiMeisai = SystemColumn.systemColumnSet(1, trKyotsuShinseiMeisai, serviceInterfaceBean);
        //申請ID
        trKyotsuShinseiMeisai.setShinseiId(trKyotsuShinsei.getShinseiId());
        // 共通申請明細NO
        trKyotsuShinseiMeisai.setKyotsuShinseiMeisaiNo(Long.valueOf(kyoTsushinseiNo));
        // 申請種別コード
        trKyotsuShinseiMeisai.setShinseiShubetsuCd(trKyotsuShinsei.getShinseiShubetsuCd());
        if(!params.isEmpty()){
            // 表示用キー情報
            trKyotsuShinseiMeisai.setHyojiyoKeyJoho(params.get("hyoJikeyJoho"));
            // キー情報
            trKyotsuShinseiMeisai.setKeyJoho(params.get("keyJoho"));
            //表示項目１
            trKyotsuShinseiMeisai.setHyojiKomoku1(params.get("hyoujiKomoKu1"));
            // 表示項目2
            trKyotsuShinseiMeisai.setHyojiKomoku2(params.get("hyoujiKomoKu2"));
            // 表示項目3
            trKyotsuShinseiMeisai.setHyojiKomoku3(params.get("hyoujiKomoKu3"));
            // 表示項目4
            trKyotsuShinseiMeisai.setHyojiKomoku4(params.get("hyoujiKomoKu4"));
            // 表示項目5
            trKyotsuShinseiMeisai.setHyojiKomoku5(params.get("hyoujiKomoKu5"));
            // 表示項目6
            trKyotsuShinseiMeisai.setHyojiKomoku6(params.get("hyoujiKomoKu6"));
        }
        // 申請理由
        trKyotsuShinseiMeisai.setShinseiRiyu("");
        // 削除フラグ
        trKyotsuShinseiMeisai.setSakujoFlg("0");
        // 共通申請明細テーブルに登録
        trKyotsuShinseiMeisaiDao.insert(trKyotsuShinseiMeisai);

    }
    
    

    /**
     * 申請データの存在チェック
     * @param checkParam パラメタ
     * @return チェック結果
     */
    public String sonzaiCheck(Map<String, String> checkParam){
        List<Map<String, Object>> checkResult = dataShinseiDao.sonzaiCheck(checkParam);
        if (!checkResult.isEmpty()) {
            return "1";
        }
        return "2";
    }
}
