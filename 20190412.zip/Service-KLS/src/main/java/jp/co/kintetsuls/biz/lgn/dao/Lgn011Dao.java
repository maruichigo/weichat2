/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.lgn.dao;

import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.biz.lgn.model.Lgn011Def;
import jp.co.kintetsuls.biz.base.dao.BaseDao;
import org.springframework.stereotype.Repository;

/**
 * ログインDAO
 *
 * @author 黄華（MBP）
 * @version 2019/1/24 新規作成
 */
@Repository
public class Lgn011Dao extends BaseDao<Lgn011Def> {

    /**
     * お知らせを取得する
     *
     * @param searchCriteria 検索条件
     * @return お知らせ情報
     */
    public List<Map<String, String>> findInform(Map<String, Object> searchCriteria) {
        return getSqlSession().selectList("lgn011.findInform", searchCriteria);
    }

    /**
     * ユーザー件数取得
     *
     * @param searchCriteria 検索条件
     * @return ユーザー件数
     */
    public int countUser(Map<String, Object> searchCriteria) {
        return getSqlSession().selectOne("lgn011.countToMap", searchCriteria);
    }

}
