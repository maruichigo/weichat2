/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.lgn.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import java.util.Map;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.base.dao.BaseDao;
import jp.co.kintetsuls.biz.table.dao.TrPasswordGoNyuryokuKaisuDao;
import jp.co.kintetsuls.biz.table.model.TrPasswordGoNyuryokuKaisu;
import jp.co.kintetsuls.common.SystemColumn;
import jp.co.kintetsuls.common.cnst.StndConsIF;

/**
 * パスワード誤入力回数登録更新処理
 * 
 * @author 曾鳳（MBP）
 * @version 2019/3/21 新規作成
 */
@Component("LGN021_UPDATE")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Lgn021BusUpdate extends BaseBus {

    /**
     * Dao定義
     */
    @Autowired(required=true)
    @Resource(shareable=true)
    protected TrPasswordGoNyuryokuKaisuDao trPasswordGoNyuryokuKaisuDao;

    /**
     * パスワード誤入力回数登録更新処理
     * 
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception 
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception{

        // パラメータを取得する
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
        // 回数
        int kaisu = 0;
        // モード
        String mode = params.get("mode").toString();

        // テーブルに登録されているパスワード誤入力回数の取得を行う
        TrPasswordGoNyuryokuKaisu trPasswordGoNyuryokuKaisu = new TrPasswordGoNyuryokuKaisu();
        trPasswordGoNyuryokuKaisu.setUserCd(params.get("userCd").toString());
        TrPasswordGoNyuryokuKaisu searchResult = trPasswordGoNyuryokuKaisuDao.findById(trPasswordGoNyuryokuKaisu);

        // パスワード誤入力回数更新/登録処理
        if ("1".equals(mode)) {

            // 取得結果1件の場合
            if (searchResult != null) {
                // パスワード誤入力回数更新
                kaisu = searchResult.getKaisu();
                // 回数 = 回数+1
                searchResult.setKaisu(searchResult.getKaisu() + 1);
                // システムカラム
                searchResult = SystemColumn.systemColumnSet(2, searchResult, serviceInterfaceBean);

                List<Map<String, TrPasswordGoNyuryokuKaisu>> updateList = new ArrayList<>();
                Map<String, TrPasswordGoNyuryokuKaisu> updateMap = new HashMap<>();
                updateMap.put(BaseDao.UPDATE_BEAN_UPD, searchResult);
                updateMap.put(BaseDao.UPDATE_BEAN_CRT, searchResult);
                updateList.add(updateMap);

                trPasswordGoNyuryokuKaisuDao.updateById(updateList);
            } else {
                // 取得結果0件の場合
                // パスワード誤入力回数登録
                TrPasswordGoNyuryokuKaisu insertEntity = new TrPasswordGoNyuryokuKaisu();
                // ユーザーコード
                insertEntity.setUserCd(params.get("userCd").toString());
                // 回数 = 1
                insertEntity.setKaisu(1);
                // 削除フラグ
                insertEntity.setSakujoFlg(StndConsIF.CONST_ZERO_STRING);
                // システムカラム
                insertEntity = SystemColumn.systemColumnSet(1, insertEntity, serviceInterfaceBean);

                trPasswordGoNyuryokuKaisuDao.insert(insertEntity);
            }

            // 回数を設定する
            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(kaisu));
            serviceInterfaceBean.addMessage("INFO", "情報", "方法");
        } else {
            // パスワード誤入力回数初期化処理
            // 回数 = 0
            searchResult.setKaisu(0);
            // システムカラム
            searchResult = SystemColumn.systemColumnSet(2, searchResult, serviceInterfaceBean);

            List<Map<String, TrPasswordGoNyuryokuKaisu>> updateList = new ArrayList<>();
            Map<String, TrPasswordGoNyuryokuKaisu> updateMap = new HashMap<>();
            updateMap.put(BaseDao.UPDATE_BEAN_UPD, searchResult);
            updateMap.put(BaseDao.UPDATE_BEAN_CRT, searchResult);
            updateList.add(updateMap);

            trPasswordGoNyuryokuKaisuDao.updateById(updateList);
        }
    }
}