package jp.co.kintetsuls.biz.common.autocomplete.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;

import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.common.jushocomponent.dao.ComGetJushoInfoDao;
import jp.co.kintetsuls.common.cnst.StndConsIF;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 新住所情報取得Bus
 *
 * @author yang.x (MBP)
 * @version 2019/2/27 新規作成
 */
@Component("COMMON_GET_SHINJUSHO_INFO")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ComGetJushoInfoBus extends BaseBus {

    // Dao定義
    @Autowired(required = true)
    @Resource(shareable = true)
    protected ComGetJushoInfoDao comGetJushoInfoDao;
    private Map<String, Object> params = null;

    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        //init
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

        // 検索条件設定(日付変換)
        if(!((String)params.get("tekiyoKaishibi")).isEmpty()){
            params.put("tekiyoKaishibi", DateUtils.parse((String)params.get("tekiyoKaishibi"), StndConsIF.DF_YYYY_MM_DD));
        }
        
       List<Map<String, Object>> result = comGetJushoInfoDao.getShinjushoInfo(params);
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));

    }
}
