package jp.co.kintetsuls.biz.base.dao;

import java.lang.reflect.Field;
import java.util.Map;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.beans.factory.annotation.Autowired;

public abstract class BaseDao<T> extends SqlSessionDaoSupport{
	
	public static final String UPDATE_BEAN_CRT = "crt";
	public static final String UPDATE_BEAN_UPD = "upd";
	public static final String NULL_UPDATE_COL = "nullUpdCol";
	public static final String NULL_CRITERIA_COL = "nullCrtCol";
	public static final String NOT_NULL_CRITERIA_COL = "notNullCrtCol";
	
    @Autowired
    @Override
    public void setSqlSessionFactory(SqlSessionFactory sqlSessionFactory) {
        super.setSqlSessionFactory(sqlSessionFactory);
    }

    /**
     * 登録する時に空項目を設定
     *
     * @param def
     * @param entity 
     */
    public void setNullCol(Object def, Map<String, Object> entity) {
        
        Class c = def.getClass();
        Field[] f = c.getDeclaredFields();
        
        for (Field fie : f) {
            fie.setAccessible(true);
            if (entity.get(fie.getName()) == null) {
                entity.put(fie.getName(), "");
            }
        }
    }    
    
}
