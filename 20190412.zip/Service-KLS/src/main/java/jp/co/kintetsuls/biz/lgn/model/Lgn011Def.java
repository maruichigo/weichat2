/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.lgn.model;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * ログインのDef
 *
 * @author 黄華（MBP）
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "lgn011")
public class Lgn011Def implements Serializable {

    private static final long serialVersionUID = 8225066323266434396L;

    /**
     * ユーザーコード
     */
    private String hyoDtlUserCd;

    /**
     * パスワード誤入力最大回数
     */
    private String hyoDtlPasswordGoNyuryokuSaidaiKaisu;

    /**
     * 緊急度
     */
    private String osrDtlListKinkyudo;

    /**
     * 登録者情報(メッセージ通知日時)
     */
    private String osrDtlListNichiji;

    /**
     * 登録者情報(メッセージ作成者)
     */
    private String osrDtlListUserMei;

    /**
     * お知らせ メッセージ
     */
    private String osrDtlListMessage;

    /**
     * 誤入力回数チェックフラグ
     */
    private String mailShinseiLockFlg;
    
    /**
     * 遷移先画面ID
     */
    private String hyoDtlSeniSakiGamenId;

    @XmlElement(name = "osrDtlListMessage")
    public String getOsrDtlListMessage() {
        return osrDtlListMessage;
    }

    public void setOsrDtlListMessage(String osrDtlListMessage) {
        this.osrDtlListMessage = osrDtlListMessage;
    }

    public String getHyoDtlSeniSakiGamenId() {
        return hyoDtlSeniSakiGamenId;
    }

    public void setHyoDtlSeniSakiGamenId(String hyoDtlSeniSakiGamenId) {
        this.hyoDtlSeniSakiGamenId = hyoDtlSeniSakiGamenId;
    }

    @XmlElement(name = "mailShinseiLockFlg")
    public String getMailShinseiLockFlg() {
        return mailShinseiLockFlg;
    }

    public void setMailShinseiLockFlg(String mailShinseiLockFlg) {
        this.mailShinseiLockFlg = mailShinseiLockFlg;
    }

    @XmlElement(name = "hyoDtlUserCd")
    public String getHyoDtlUserCd() {
        return hyoDtlUserCd;
    }

    public void setHyoDtlUserCd(String hyoDtlUserCd) {
        this.hyoDtlUserCd = hyoDtlUserCd;
    }

    @XmlElement(name = "hyoDtlPasswordGoNyuryokuSaidaiKaisu")
    public String getHyoDtlPasswordGoNyuryokuSaidaiKaisu() {
        return hyoDtlPasswordGoNyuryokuSaidaiKaisu;
    }

    public void setHyoDtlPasswordGoNyuryokuSaidaiKaisu(String hyoDtlPasswordGoNyuryokuSaidaiKaisu) {
        this.hyoDtlPasswordGoNyuryokuSaidaiKaisu = hyoDtlPasswordGoNyuryokuSaidaiKaisu;
    }

    @XmlElement(name = "osrDtlListKinkyudo")
    public String getOsrDtlListKinkyudo() {
        return osrDtlListKinkyudo;
    }

    public void setOsrDtlListKinkyudo(String osrDtlListKinkyudo) {
        this.osrDtlListKinkyudo = osrDtlListKinkyudo;
    }

    @XmlElement(name = "osrDtlListNichiji")
    public String getOsrDtlListNichiji() {
        return osrDtlListNichiji;
    }

    public void setOsrDtlListNichiji(String osrDtlListNichiji) {
        this.osrDtlListNichiji = osrDtlListNichiji;
    }

    @XmlElement(name = "osrDtlListUserMei")
    public String getOsrDtlListUserMei() {
        return osrDtlListUserMei;
    }

    public void setOsrDtlListUserMei(String osrDtlListUserMei) {
        this.osrDtlListUserMei = osrDtlListUserMei;
    }
    
}
