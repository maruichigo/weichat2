package jp.co.kintetsuls.biz.cus.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.sql.Date;

import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;

import java.util.Map;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.cus.dao.Cus012Dao;
import jp.co.kintetsuls.biz.cus.model.Cus012;
import jp.co.kintetsuls.common.cnst.SysMsg;

/**
 * 顧客マスタ情報取得処理
 */
@Component("CUS012_GET_KOKYAKU_DETAIL")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Cus012BusSearch extends BaseBus {

    // Dao定義
    @Autowired(required=true)
    @Resource(shareable=true)
    protected Cus012Dao cus012Dao;
    private Map<String, Object> params = null;

    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception{
        //init
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

        // 必須チェック:顧客コード
        if(!params.containsKey("kokyakuCd") || params.get("kokyakuCd").toString().length() < 6){
            String msg = SysMsg.WRNREQ;
            serviceInterfaceBean.addMessage("WARN", "警告", msg);
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return;
        }

        // 日付けの型変換
        if(params.containsKey("tekiyoKaishibi") && params.get("tekiyoKaishibi") != null && !params.get("tekiyoKaishibi").toString().isEmpty()){
            params.put("tekiyoKaishibi", Date.valueOf(params.get("tekiyoKaishibi").toString()));
        }else{
            params.put("tekiyoKaishibi", null);
        }
        
        //顧客マスタ検索
        Cus012 result = cus012Dao.getKokyakuDetail(params);
        if (result == null){
            String msg = SysMsg.WRNNODATA;
            serviceInterfaceBean.addMessage("WARN", "警告", msg);
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return;
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        
        serviceInterfaceBean.addMessage("INFO", "情報", "方法");
    }
}