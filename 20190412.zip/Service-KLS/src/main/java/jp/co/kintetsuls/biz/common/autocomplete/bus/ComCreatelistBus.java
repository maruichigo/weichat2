package jp.co.kintetsuls.biz.common.autocomplete.bus;


import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;

import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.common.autocomplete.dao.ComCreateListDao;
import jp.co.kintetsuls.biz.common.autocomplete.model.ComCreateListDef;
import jp.co.kintetsuls.common.cnst.SysMsg;
import jp.co.kintetsuls.common.json.JSONUtil;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * AutoComplete処理クラス
 */
@Component("COMMON_GET_CREATE_LIST")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ComCreatelistBus extends BaseBus {

    // Dao定義
    @Autowired(required=true)
    @Resource(shareable=true)
    protected ComCreateListDao comCreateListDao;
    private Map<String, Object> params = null;

    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception{
        //init
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

        if(!params.containsKey("listId")){
            String msg = SysMsg.WRNDATA;
            serviceInterfaceBean.addMessage("WARN", "警告", msg);
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return;
        }

        Map sqlParams = (Map) params.get("params");
        if (sqlParams == null || sqlParams.size() == 0) {
            List<ComCreateListDef> comList = comCreateListDao.getStringList((String) params.get("listId"));
            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(comList));
        } else {
            List<ComCreateListDef> comList = comCreateListDao.getStringList((String) params.get("listId"),sqlParams);
            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(comList));
        }
		
    }
}