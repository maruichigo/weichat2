package jp.co.kintetsuls.biz.mst.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import java.util.Map;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.base.dao.BaseDao;
import jp.co.kintetsuls.biz.mst.dao.Mst032Dao;
import jp.co.kintetsuls.biz.table.dao.MsJisHenkanJohoDao;
import jp.co.kintetsuls.biz.table.dao.MsJushoDao;
import jp.co.kintetsuls.biz.table.dao.MsJushoKannaihaisoDao;
import jp.co.kintetsuls.biz.table.dao.MsJushoRitoDao;
import jp.co.kintetsuls.biz.table.dao.MsShimukeChiHenkanJohoDao;
import jp.co.kintetsuls.biz.table.dao.MsShisetsuHyojiMeiJohoDao;
import jp.co.kintetsuls.biz.table.model.MsJisHenkanJoho;
import jp.co.kintetsuls.biz.table.model.MsJusho;
import jp.co.kintetsuls.biz.table.model.MsJushoKannaihaiso;
import jp.co.kintetsuls.biz.table.model.MsJushoRito;
import jp.co.kintetsuls.biz.table.model.MsShimukeChiHenkanJoho;
import jp.co.kintetsuls.biz.table.model.MsShisetsuHyojiMeiJoho;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.biz.common.versionCheck.bus.BusVersionCheck;
import jp.co.kintetsuls.common.cnst.MessageCnst;

/**
 * 住所詳細機能関連情報削除処理
 *
 * @author 張誠 (MBP)
 * @version 2019/1/29 新規作成
 */
@Component("MST032_DELETE")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Mst032BusDelete extends BaseBus {

    /**
     * Mst032Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected Mst032Dao mst032Dao;

    /**
     * JIS変換情報Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsJisHenkanJohoDao jisHenkanJohoDao;

    /**
     * 仕向地変換情報Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsShimukeChiHenkanJohoDao shimukeChiHenkanJohoDao;

    /**
     * 施設表示名情報Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsShisetsuHyojiMeiJohoDao shisetsuHyojiMeiJohoDao;

    /**
     * 館内配送情報Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsJushoKannaihaisoDao jushoKannaihaisoDao;

    /**
     * 館内配送情報Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsJushoRitoDao jushoRitoDao;

    /**
     * 住所詳細情報Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsJushoDao jushoDao;

    /**
     * バージョンチェック(排他)
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected BusVersionCheck busVersionCheck;

    /**
     * パラメータ
     */
    private Map<String, Object> params = null;

    /**
     * JISコード
     */
    private String jisCd;

    /**
     * 適用開始日
     */
    private Date tekiyoKaishibi;

    /**
     * 更新ユーザー
     */
    private String userCd;

    /**
     * 更新日時
     */
    private Date koshinData;

    /**
     * 更新端末
     */
    private String koshinTammatsu;

    /**
     * 更新営業所
     */
    private String koshinEigyosho;

    /**
     * 最終オペレーションユーザー
     */
    private String saishuOperationUser;

    /**
     * 最終オペレーション更新日時
     */
    private Date saishuOperationKoshinNichiji;

    /**
     * 住所詳細機能関連情報削除処理
     *
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

        // 共通用項目設定
        // JISコード
        jisCd =  params.get("conJisCd").toString();
        // 適用開始日
        long time_long = Long.valueOf( params.get("conTekiyoKaishibi").toString());
        tekiyoKaishibi = new Date(time_long);
        // 更新ユーザー
        userCd = params.get("userCd").toString();
        // 更新日時
        koshinData = new Date();
        // 更新端末
        koshinTammatsu = serviceInterfaceBean.getTammatsu();
        // 更新営業所
        koshinEigyosho = serviceInterfaceBean.getDefaultEigyosho();
        // 最終オペレーションユーザー
        saishuOperationUser = serviceInterfaceBean.getUserCd();
        // 最終オペレーション更新日時
        saishuOperationKoshinNichiji = koshinData;

        String mstFlg =  params.get("mstFlg").toString();
        // パラメータ判定
        if (null != mstFlg) {
            if ("jusho".equals(mstFlg)) {
                // 住所情報削除
                jushoDel(serviceInterfaceBean);
            } else if ("rito".equals(mstFlg)) {
                // 離島情報削除
                ritoJohoDel(serviceInterfaceBean);
            } else if ("kannai".equals(mstFlg)) {
                // 館内配送情報削除
                kannaiHaisoJohoDel(serviceInterfaceBean);
            } else if ("jis".equals(mstFlg)) {
                // JIS変換情報削除
                JisHenkanJohoDel(serviceInterfaceBean);
            } else if ("shimuke".equals(mstFlg)) {
                // 仕向地変換情報削除
                shimukeHenkanJohoDel(serviceInterfaceBean);
            } else if ("shisetsu".equals(mstFlg)) {
                // 施設表示名情報削除
                shisetsuJohoDel(serviceInterfaceBean);
            }
        }
    }

    /**
     * JIS変換情報削除
     *
     * @param serviceInterfaceBean JSFからの通信情報
     */
    private void JisHenkanJohoDel(ServiceInterfaceBean serviceInterfaceBean) {

        // 削除リスト取得
        List<Map<String, Object>> dataList = (List<Map<String, Object>>) params.get("dataList");
        // 更新項目初期化
        MsJisHenkanJoho upd;
        // 更新条件初期化
        MsJisHenkanJoho crt;
        Map msJisHenkanJohoMap;
        // 削除処理を行う
        if (!dataList.isEmpty()) {
            // パラメタリスト
            List<Map<String, MsJisHenkanJoho>> msJisHenkanJohoMapList = new ArrayList<>();
            Iterator<Map<String, Object>> ite = dataList.iterator();
            while (ite.hasNext()) {
                msJisHenkanJohoMap = new HashMap<>();
                Map<String, Object> i = ite.next();
                // 更新項目初期化
                upd = new MsJisHenkanJoho();
                // データバージョン
                upd.setJushoJisDataVersion(Integer.parseInt(i.get("hnknDtlListJushoJisDataVer").toString()) + 1);
                // 行削除フラグ
                upd.setSakujoFlg("1");
                // 更新ユーザー
                upd.setKoshinUser(userCd);
                // 更新日時
                upd.setKoshinNichiji(koshinData);
                // 更新端末
                upd.setKoshinTammatsu(koshinTammatsu);
                // 更新営業所
                upd.setKoshinEigyosho(koshinEigyosho);
                // 最終オペレーションユーザー
                upd.setSaishuOperationUser(saishuOperationUser);
                // 最終オペレーション更新日時
                upd.setSaishuOperationKoshinNichiji(saishuOperationKoshinNichiji);
                // 更新項目設定
                msJisHenkanJohoMap.put(BaseDao.UPDATE_BEAN_UPD, upd);

                // 更新条件初期化
                crt = new MsJisHenkanJoho();
                // JISコード
                crt.setJisCd(jisCd);
                // 適用開始日
                crt.setTekiyoKaishibi(tekiyoKaishibi);
                // JIS変換情報シーケンス
                crt.setJisHenkanJohoSeq(Integer.parseInt(i.get("hnknDtlListHHenkanJohoSeq").toString()));
                // 更新条件設定
                msJisHenkanJohoMap.put(BaseDao.UPDATE_BEAN_CRT, crt);
                // パラメタリスト設定
                msJisHenkanJohoMapList.add(msJisHenkanJohoMap);

                // バージョンチェック(排他)
                Map<String, Object> paraMap = new HashMap<>();
                // JISコード
                paraMap.put("JIS_CD", jisCd);
                // 適用開始日
                paraMap.put("TEKIYO_KAISHIBI", tekiyoKaishibi);
                // JIS変換情報シーケンス
                paraMap.put("JIS_HENKAN_JOHO_SEQ", i.get("hnknDtlListHHenkanJohoSeq"));
                // 更新ユーザーID
                paraMap.put("koushinUserCd", i.get("hnknDtlListKoushinUserCd"));
                // 更新カウンタ
                paraMap.put("koushinCounter", i.get("hnknDtlListKoushinCounter"));
                // 変換情報住所
                paraMap.put("msgJusho", i.get("hnknDtlListHenkanJohoJusho"));
                // テーブル名
                paraMap.put("tblName", "MS_JIS_HENKAN_JOHO");
                boolean haitaFlg = haitaCheckVersion(serviceInterfaceBean, paraMap);
                if (!haitaFlg) {
                    return;
                }
            }
            // マスタ削除
            if (msJisHenkanJohoMapList.size() > 0) {
                jisHenkanJohoDao.updateById(msJisHenkanJohoMapList);
            }
        }
    }

    /**
     * 仕向地変換情報削除
     *
     * @param serviceInterfaceBean JSFからの通信情報
     */
    private void shimukeHenkanJohoDel(ServiceInterfaceBean serviceInterfaceBean) {
        // 仕向地コード
        String shimukeChiCd =  params.get("hnknDtlShimukeChiCd").toString();
        // 削除リスト取得
        List<Map<String, Object>> dataList = (List<Map<String, Object>>) params.get("dataList");
        // 削除処理を行う
        if (!dataList.isEmpty()) {
            // パラメタリスト
            List<Map<String, MsShimukeChiHenkanJoho>> msShimukeChiHenkanJohoMapList = new ArrayList<>();
            // 更新項目初期化
            MsShimukeChiHenkanJoho upd;
            // 更新条件初期化
            MsShimukeChiHenkanJoho crt;
            Map msShimukeChiHenkanJohoMap;
            Iterator<Map<String, Object>> ite = dataList.iterator();
            while (ite.hasNext()) {
                msShimukeChiHenkanJohoMap = new HashMap<>();
                Map<String, Object> i = ite.next();
                // 更新項目初期化
                upd = new MsShimukeChiHenkanJoho();
                // データバージョン
                upd.setJushoJisDataVersion(Integer.parseInt(i.get("hnknDtlListJushoJisDataVer").toString()) + 1);
                // 行削除フラグ
                upd.setSakujoFlg("1");
                // 更新ユーザー
                upd.setKoshinUser(userCd);
                // 更新日時
                upd.setKoshinNichiji(koshinData);
                // 更新端末
                upd.setKoshinTammatsu(koshinTammatsu);
                // 更新営業所
                upd.setKoshinEigyosho(koshinEigyosho);
                // 最終オペレーションユーザー
                upd.setSaishuOperationUser(saishuOperationUser);
                // 最終オペレーション更新日時
                upd.setSaishuOperationKoshinNichiji(saishuOperationKoshinNichiji);
                // 更新項目設定
                msShimukeChiHenkanJohoMap.put(BaseDao.UPDATE_BEAN_UPD, upd);

                // 更新条件初期化
                crt = new MsShimukeChiHenkanJoho();
                // JISコード
                crt.setJisCd(jisCd);
                // 適用開始日
                crt.setTekiyoKaishibi(tekiyoKaishibi);
                // 仕向地コード
                crt.setShimukeChiCd(shimukeChiCd);
                // JIS変換情報シーケンス
                crt.setShimukeChiHenkanJohoSeq(Integer.parseInt(i.get("hnknDtlListHHenkanJohoSeq").toString()));
                // 更新条件設定
                msShimukeChiHenkanJohoMap.put(BaseDao.UPDATE_BEAN_CRT, crt);
                msShimukeChiHenkanJohoMapList.add(msShimukeChiHenkanJohoMap);

                // バージョンチェック(排他)
                Map<String, Object> paraMap = new HashMap<>();
                // JISコード
                paraMap.put("JIS_CD", jisCd);
                // 適用開始日
                paraMap.put("TEKIYO_KAISHIBI", tekiyoKaishibi);
                // 仕向地コード
                paraMap.put("SHIMUKE_CHI_CD", shimukeChiCd);
                // JIS変換情報シーケンス
                paraMap.put("SHIMUKE_CHI_HENKAN_JOHO_SEQ", i.get("hnknDtlListHHenkanJohoSeq"));
                // 更新ユーザーID
                paraMap.put("koushinUserCd", i.get("hnknDtlListKoushinUserCd"));
                // 更新カウンタ
                paraMap.put("koushinCounter", i.get("hnknDtlListKoushinCounter"));
                // 変換情報住所
                paraMap.put("msgJusho", i.get("hnknDtlListHenkanJohoJusho"));
                // テーブル名
                paraMap.put("tblName", "MS_SHIMUKE_CHI_HENKAN_JOHO");
                boolean haitaFlg = haitaCheckVersion(serviceInterfaceBean, paraMap);
                if (!haitaFlg) {
                    return;
                }
            }
            // マスタ削除
            if (msShimukeChiHenkanJohoMapList.size() > 0) {
                shimukeChiHenkanJohoDao.updateById(msShimukeChiHenkanJohoMapList);
            }
        }
    }

    /**
     * 施設表示名情報削除
     *
     * @param serviceInterfaceBean JSFからの通信情報
     */
    private void shisetsuJohoDel(ServiceInterfaceBean serviceInterfaceBean) {

        // 住所館内配送シーケンス
        int haisoSeq = Integer.parseInt(params.get("khDtlListHJushoKannaihaisoSeq").toString());

        // 削除リスト取得
        List<Map<String, Object>> dataList = (List<Map<String, Object>>) params.get("dataList");
        // 削除処理を行う
        if (!dataList.isEmpty()) {
            // パラメタリスト
            List<Map<String, MsShisetsuHyojiMeiJoho>> msShisetsuHyojiMeiJohoMapList = new ArrayList<>();
            // 更新項目初期化
            MsShisetsuHyojiMeiJoho upd;
            // 更新条件初期化
            MsShisetsuHyojiMeiJoho crt;
            Map msShisetsuHyojiMeiJohoMap;
            Iterator<Map<String, Object>> ite = dataList.iterator();
            while (ite.hasNext()) {
                msShisetsuHyojiMeiJohoMap = new HashMap<>();
                Map<String, Object> i = ite.next();
                // 更新項目初期化
                upd = new MsShisetsuHyojiMeiJoho();
                // データバージョン
                upd.setJushoJisDataVersion(Integer.parseInt(i.get("shstDtlListJushoJisDataVer").toString()) + 1);
                // 行削除フラグ
                upd.setSakujoFlg("1");
                // 更新ユーザー
                upd.setKoshinUser(userCd);
                // 更新日時
                upd.setKoshinNichiji(koshinData);
                // 更新端末
                upd.setKoshinTammatsu(koshinTammatsu);
                // 更新営業所
                upd.setKoshinEigyosho(koshinEigyosho);
                // 最終オペレーションユーザー
                upd.setSaishuOperationUser(saishuOperationUser);
                // 最終オペレーション更新日時
                upd.setSaishuOperationKoshinNichiji(saishuOperationKoshinNichiji);
                // 更新項目設定
                msShisetsuHyojiMeiJohoMap.put(BaseDao.UPDATE_BEAN_UPD, upd);

                // 更新条件初期化
                crt = new MsShisetsuHyojiMeiJoho();
                // JISコード
                crt.setJisCd(jisCd);
                // 適用開始日
                crt.setTekiyoKaishibi(tekiyoKaishibi);
                // 住所館内配送シーケンス
                crt.setJushoKannaihaisoSeq(haisoSeq);
                // 施設表示名シーケンス
                crt.setShisetsuHyojiMeiSeq(Integer.parseInt(i.get("shstDtlListHShisetsuHyojiMeiSeq").toString()));
                // 更新条件設定
                msShisetsuHyojiMeiJohoMap.put(BaseDao.UPDATE_BEAN_CRT, crt);
                msShisetsuHyojiMeiJohoMapList.add(msShisetsuHyojiMeiJohoMap);

                // バージョンチェック(排他)
                Map<String, Object> paraMap = new HashMap<>();
                // JISコード
                paraMap.put("JIS_CD", jisCd);
                // 適用開始日
                paraMap.put("TEKIYO_KAISHIBI", tekiyoKaishibi);
                // 住所館内配送シーケンス
                paraMap.put("JUSHO_KANNAIHAISO_SEQ", haisoSeq);
                // 施設表示名シーケンス
                paraMap.put("SHISETSU_HYOJI_MEI_SEQ", i.get("shstDtlListHShisetsuHyojiMeiSeq"));
                // 更新ユーザーID
                paraMap.put("koushinUserCd", i.get("shstDtlListKoushinUserCd"));
                // 更新カウンタ
                paraMap.put("koushinCounter", i.get("shstDtlListKoushinCounter"));
                // 表示名
                paraMap.put("msgJusho", i.get("shstDtlListHyojiMei"));
                // テーブル名
                paraMap.put("tblName", "MS_SHISETSU_HYOJI_MEI_JOHO");
                boolean haitaFlg = haitaCheckVersion(serviceInterfaceBean, paraMap);
                if (!haitaFlg) {
                    return;
                }
            }
            // マスタ削除
            if (msShisetsuHyojiMeiJohoMapList.size() > 0) {
                shisetsuHyojiMeiJohoDao.updateById(msShisetsuHyojiMeiJohoMapList);
            }
        }
    }

    /**
     * 館内配送情報削除
     *
     * @param serviceInterfaceBean JSFからの通信情報
     */
    private void kannaiHaisoJohoDel(ServiceInterfaceBean serviceInterfaceBean) {
        // 削除リスト取得
        List<Map<String, Object>> dataList = (List<Map<String, Object>>) params.get("dataList");
        // 削除処理を行う
        if (!dataList.isEmpty()) {
            // 施設表示名情報削除
            // パラメタリスト
            List<Map<String, MsShisetsuHyojiMeiJoho>> msShisetsuHyojiMeiJohoList = new ArrayList<>();
            // 館内配送情報削除
            // パラメタリスト
            List<Map<String, MsJushoKannaihaiso>> msJushoKannaihaisoMapList = new ArrayList<>();
            // 施設表示名情報更新項目
            MsShisetsuHyojiMeiJoho shisetsuUpd;
            // 施設表示名情報更新条件
            MsShisetsuHyojiMeiJoho shisetsuCrt;
            Map msShisetsuHyojiMeiJohoMap;

            // 更新項目初期化
            MsJushoKannaihaiso kannaiUpd;
            // 更新条件初期化
            MsJushoKannaihaiso kannaiCrt;
            Map msJushoKannaihaisoMap;

            Iterator<Map<String, Object>> ite = dataList.iterator();
            while (ite.hasNext()) {
                msShisetsuHyojiMeiJohoMap = new HashMap<>();
                Map<String, Object> i = ite.next();
                // 施設表示名情報削除     
                // 更新項目初期化
                shisetsuUpd = new MsShisetsuHyojiMeiJoho();
                // 更新ユーザー
                shisetsuUpd.setKoshinUser(userCd);
                // 更新日時
                shisetsuUpd.setKoshinNichiji(koshinData);
                // 更新端末
                shisetsuUpd.setKoshinTammatsu(koshinTammatsu);
                // 更新営業所
                shisetsuUpd.setKoshinEigyosho(koshinEigyosho);
                // 最終オペレーションユーザー
                shisetsuUpd.setSaishuOperationUser(saishuOperationUser);
                // 最終オペレーション更新日時
                shisetsuUpd.setSaishuOperationKoshinNichiji(saishuOperationKoshinNichiji);
                // 更新項目設定
                msShisetsuHyojiMeiJohoMap.put(BaseDao.UPDATE_BEAN_UPD, shisetsuUpd);

                // 更新条件初期化
                shisetsuCrt = new MsShisetsuHyojiMeiJoho();
                // JISコード
                shisetsuCrt.setJisCd(jisCd);
                // 適用開始日
                shisetsuCrt.setTekiyoKaishibi(tekiyoKaishibi);
                // 住所館内配送シーケンス
                shisetsuCrt.setJushoKannaihaisoSeq(Integer.parseInt(i.get("khDtlListHJushoKannaihaisoSeq").toString()));
                // 更新条件設定
                msShisetsuHyojiMeiJohoMap.put(BaseDao.UPDATE_BEAN_CRT, shisetsuCrt);
                msShisetsuHyojiMeiJohoList.add(msShisetsuHyojiMeiJohoMap);

                // 館内配送情報削除     
                msJushoKannaihaisoMap = new HashMap<>();
                // 更新項目初期化
                kannaiUpd = new MsJushoKannaihaiso();
                // データバージョン
                shisetsuUpd.setJushoJisDataVersion(Integer.parseInt(i.get("khDtlListJushoJisDataVer").toString()) + 1);
                // 行削除フラグ
                kannaiUpd.setSakujoFlg("1");
                // 更新ユーザー
                kannaiUpd.setKoshinUser(userCd);
                // 更新日時
                kannaiUpd.setKoshinNichiji(koshinData);
                // 更新端末
                kannaiUpd.setKoshinTammatsu(koshinTammatsu);
                // 更新営業所
                kannaiUpd.setKoshinEigyosho(koshinEigyosho);
                // 最終オペレーションユーザー
                kannaiUpd.setSaishuOperationUser(saishuOperationUser);
                // 最終オペレーション更新日時
                kannaiUpd.setSaishuOperationKoshinNichiji(saishuOperationKoshinNichiji);
                // 更新項目設定
                msJushoKannaihaisoMap.put(BaseDao.UPDATE_BEAN_UPD, kannaiUpd);

                // 更新条件初期化
                kannaiCrt = new MsJushoKannaihaiso();
                // JISコード
                kannaiCrt.setJisCd(jisCd);
                // 適用開始日
                kannaiCrt.setTekiyoKaishibi(tekiyoKaishibi);
                // 住所館内配送シーケンス
                kannaiCrt.setJushoKannaihaisoSeq(Integer.parseInt(i.get("khDtlListHJushoKannaihaisoSeq").toString()));
                // 更新条件設定
                msJushoKannaihaisoMap.put(BaseDao.UPDATE_BEAN_CRT, kannaiCrt);
                msJushoKannaihaisoMapList.add(msJushoKannaihaisoMap);

                // バージョンチェック(住所館内配送マスタ排他)
                Map<String, Object> paraMap = new HashMap<>();
                // JISコード
                paraMap.put("JIS_CD", jisCd);
                // 適用開始日
                paraMap.put("TEKIYO_KAISHIBI", tekiyoKaishibi);
                // 住所館内配送シーケンス
                paraMap.put("JUSHO_KANNAIHAISO_SEQ", i.get("khDtlListHJushoKannaihaisoSeq"));
                // 更新ユーザーID
                paraMap.put("koushinUserCd", i.get("khDtlListKoushinUserCd"));
                // 更新カウンタ
                paraMap.put("koushinCounter", i.get("khDtlListKoushinCounter"));
                // 施設名+住所
                paraMap.put("msgJusho", objectToString(i.get("khDtlListShisetsuMei"))
                        + objectToString(i.get("khDtlListJusho")));
                // テーブル名
                paraMap.put("tblName", "MS_JUSHO_KANNAIHAISO");
                boolean haitaFlg = haitaCheckVersion(serviceInterfaceBean, paraMap);
                if (!haitaFlg) {
                    return;
                }
            }
            // 施設名表示名マスタ一括削除
            if (msShisetsuHyojiMeiJohoList.size() > 0) {
                mst032Dao.shisetsuHyojiMeiJohoSoftDeleteByColumn(msShisetsuHyojiMeiJohoList);
            }
            // 住所館内配送マスタ削除
            if (msJushoKannaihaisoMapList.size() > 0) {
                jushoKannaihaisoDao.updateById(msJushoKannaihaisoMapList);
            }
        }
    }

    /**
     * 離島情報削除
     *
     * @param serviceInterfaceBean JSFからの通信情報
     */
    private void ritoJohoDel(ServiceInterfaceBean serviceInterfaceBean) {
        // 削除リスト取得
        List<Map<String, Object>> dataList = (List<Map<String, Object>>) params.get("dataList");
        // 削除処理を行う
        if (!dataList.isEmpty()) {
            // パラメタリスト
            List<Map<String, MsJushoRito>> msJushoRitoMapList = new ArrayList<>();
            // 更新項目初期化
            MsJushoRito upd;
            // 更新条件初期化
            MsJushoRito crt;
            Map msJushoRitoMap;
            Iterator<Map<String, Object>> ite = dataList.iterator();
            while (ite.hasNext()) {

                Map<String, Object> i = ite.next();
                // 離島情報削除   
                msJushoRitoMap = new HashMap<>();
                // 更新項目初期化
                upd = new MsJushoRito();
                // データバージョン
                upd.setJushoJisDataVersion(Integer.parseInt(i.get("rtDtlListJushoJisDataVer").toString()) + 1);
                // 行削除フラグ
                upd.setSakujoFlg("1");
                // 更新ユーザー
                upd.setKoshinUser(userCd);
                // 更新日時
                upd.setKoshinNichiji(koshinData);
                // 更新端末
                upd.setKoshinTammatsu(koshinTammatsu);
                // 更新営業所
                upd.setKoshinEigyosho(koshinEigyosho);
                // 最終オペレーションユーザー
                upd.setSaishuOperationUser(saishuOperationUser);
                // 最終オペレーション更新日時
                upd.setSaishuOperationKoshinNichiji(saishuOperationKoshinNichiji);
                // 更新項目設定
                msJushoRitoMap.put(BaseDao.UPDATE_BEAN_UPD, upd);

                // 更新条件初期化
                crt = new MsJushoRito();
                // JISコード
                crt.setJisCd(jisCd);
                // 適用開始日
                crt.setTekiyoKaishibi(tekiyoKaishibi);
                // 住所離島シーケンス
                crt.setJushoRitoSeq(Integer.parseInt(i.get("rtDtlListHJushoRitoSeq").toString()));
                // 更新条件設定
                msJushoRitoMap.put(BaseDao.UPDATE_BEAN_CRT, crt);
                msJushoRitoMapList.add(msJushoRitoMap);

                // バージョンチェック(排他)
                Map<String, Object> paraMap = new HashMap<>();
                // JISコード
                paraMap.put("JIS_CD", jisCd);
                // 適用開始日
                paraMap.put("TEKIYO_KAISHIBI", tekiyoKaishibi);
                // 住所離島シーケンス
                paraMap.put("JUSHO_RITO_SEQ", i.get("rtDtlListHJushoRitoSeq"));
                // 更新ユーザーID
                paraMap.put("koushinUserCd", i.get("rtDtlListKoushinUserCd"));
                // 更新カウンタ
                paraMap.put("koushinCounter", i.get("rtDtlListKoushinCounter"));
                // 島名+住所
                paraMap.put("msgJusho", objectToString(i.get("rtDtlListShimaMei"))
                        + objectToString(i.get("rtDtlListJusho")));
                // テーブル名
                paraMap.put("tblName", "MS_JUSHO_RITO");
                boolean haitaFlg = haitaCheckVersion(serviceInterfaceBean, paraMap);
                if (!haitaFlg) {
                    return;
                }
            }
            //住所離島マスタ削除
            if (msJushoRitoMapList.size() > 0) {
                jushoRitoDao.updateById(msJushoRitoMapList);
            }
        }
    }

    /**
     * 住所情報削除
     *
     * @param serviceInterfaceBean JSFからの通信情報
     */
    private void jushoDel(ServiceInterfaceBean serviceInterfaceBean) {

        // 削除リスト取得
        List<Map<String, Object>> dataList = (List<Map<String, Object>>) params.get("dataList");
        // 削除処理を行う
        if (!dataList.isEmpty()) {
            // JIS変換情報
            List<Map<String, MsJisHenkanJoho>> msJisHenkanJohoMapList = new ArrayList<>();
            // 仕向地変換情報
            List<Map<String, MsShimukeChiHenkanJoho>> msShimukeChiHenkanJohoMapList = new ArrayList<>();
            // 住所マスタ
            List<Map<String, MsJusho>> msJushoMapList = new ArrayList<>();

            // JIS変換情報の場合 
            Map msJisHenkanJohoMap;
            // 更新項目
            MsJisHenkanJoho jisUpd;
            // 更新条件
            MsJisHenkanJoho jisCrt;
            // 仕向地変換情報の場合 
            Map msShimukeChiHenkanJohoMaoMap;
            // 更新項目
            MsShimukeChiHenkanJoho shimukeChiUpd;
            // 更新条件初期化
            MsShimukeChiHenkanJoho shimukeChiCrt;
            Iterator<Map<String, Object>> ite = dataList.iterator();
            while (ite.hasNext()) {
                Map<String, Object> i = ite.next();
                if ("00".equals(i.get("jshDtlListHShimukeChiCd").toString())) {
                    msJisHenkanJohoMap = new HashMap<>();
                    // 更新項目
                    jisUpd = new MsJisHenkanJoho();
                    // 更新ユーザー
                    jisUpd.setKoshinUser(userCd);
                    // 更新日時
                    jisUpd.setKoshinNichiji(koshinData);
                    // 更新端末
                    jisUpd.setKoshinTammatsu(koshinTammatsu);
                    // 更新営業所
                    jisUpd.setKoshinEigyosho(koshinEigyosho);
                    // 最終オペレーションユーザー
                    jisUpd.setSaishuOperationUser(saishuOperationUser);
                    // 最終オペレーション更新日時
                    jisUpd.setSaishuOperationKoshinNichiji(saishuOperationKoshinNichiji);
                    // 更新項目設定
                    msJisHenkanJohoMap.put(BaseDao.UPDATE_BEAN_UPD, jisUpd);
                    // 更新条件
                    jisCrt = new MsJisHenkanJoho();
                    // JISコード
                    jisCrt.setJisCd(jisCd);
                    // 適用開始日
                    jisCrt.setTekiyoKaishibi(tekiyoKaishibi);
                    // 更新条件設定
                    msJisHenkanJohoMap.put(BaseDao.UPDATE_BEAN_CRT, jisCrt);
                    // パラメタリスト設定
                    msJisHenkanJohoMapList.add(msJisHenkanJohoMap);

                } else {
                    // 仕向地変換情報の場合 
                    msShimukeChiHenkanJohoMaoMap = new HashMap<>();
                    // 更新項目
                    shimukeChiUpd = new MsShimukeChiHenkanJoho();
                    // 更新ユーザー
                    shimukeChiUpd.setKoshinUser(userCd);
                    // 更新日時
                    shimukeChiUpd.setKoshinNichiji(koshinData);
                    // 更新端末
                    shimukeChiUpd.setKoshinTammatsu(koshinTammatsu);
                    // 更新営業所
                    shimukeChiUpd.setKoshinEigyosho(koshinEigyosho);
                    // 最終オペレーションユーザー
                    shimukeChiUpd.setSaishuOperationUser(saishuOperationUser);
                    // 最終オペレーション更新日時
                    shimukeChiUpd.setSaishuOperationKoshinNichiji(saishuOperationKoshinNichiji);
                    // 更新項目設定
                    msShimukeChiHenkanJohoMaoMap.put(BaseDao.UPDATE_BEAN_UPD, shimukeChiUpd);

                    // 更新条件初期化
                    shimukeChiCrt = new MsShimukeChiHenkanJoho();
                    // JISコード
                    shimukeChiCrt.setJisCd(jisCd);
                    // 適用開始日
                    shimukeChiCrt.setTekiyoKaishibi(tekiyoKaishibi);
                    // 仕向地コード
                    shimukeChiCrt.setShimukeChiCd(i.get("jshDtlListJisCd").toString()
                            + i.get("jshDtlListHShimukeChiCd").toString());
                    // 更新条件設定
                    msShimukeChiHenkanJohoMaoMap.put(BaseDao.UPDATE_BEAN_CRT, shimukeChiCrt);
                    msShimukeChiHenkanJohoMapList.add(msShimukeChiHenkanJohoMaoMap);

                }

                //住所マスタ削除 
                Map msJushoMap = new HashMap<>();
                // 更新項目初期化
                MsJusho upd = new MsJusho();
                // データバージョン
                upd.setJushoJisDataVersion(Integer.parseInt(i.get("jshDtlListJushoJisDataVer").toString()) + 1);
                // 行削除フラグ
                upd.setSakujoFlg("1");
                // 更新ユーザー
                upd.setKoshinUser(userCd);
                // 更新日時
                upd.setKoshinNichiji(koshinData);
                // 更新端末
                upd.setKoshinTammatsu(koshinTammatsu);
                // 更新営業所
                upd.setKoshinEigyosho(koshinEigyosho);
                // 最終オペレーションユーザー
                upd.setSaishuOperationUser(saishuOperationUser);
                // 最終オペレーション更新日時
                upd.setSaishuOperationKoshinNichiji(saishuOperationKoshinNichiji);
                // 更新項目設定
                msJushoMap.put(BaseDao.UPDATE_BEAN_UPD, upd);

                // 更新条件初期化
                MsJusho crt = new MsJusho();
                // JISコード
                crt.setJisCd(jisCd);
                // 適用開始日
                crt.setTekiyoKaishibi(tekiyoKaishibi);
                // 仕向地コード
                crt.setShimukeChiCd(i.get("jshDtlListJisCd").toString() + i.get("jshDtlListHShimukeChiCd").toString());
                // 更新条件設定
                msJushoMap.put(BaseDao.UPDATE_BEAN_CRT, crt);
                msJushoMapList.add(msJushoMap);

                // バージョンチェック(住所マスタ削除排他)
                Map<String, Object> paraMap = new HashMap<>();
                // JISコード
                paraMap.put("JIS_CD", jisCd);
                // 適用開始日
                paraMap.put("TEKIYO_KAISHIBI", tekiyoKaishibi);
                // 仕向地コード
                paraMap.put("SHIMUKE_CHI_CD", i.get("jshDtlListJisCd").toString()
                        + i.get("jshDtlListHShimukeChiCd").toString());
                // 更新ユーザーID
                paraMap.put("koushinUserCd", i.get("jshDtlListKoushinUserCd"));
                // 更新カウンタ
                paraMap.put("koushinCounter", i.get("jshDtlListKoushinCounter"));
                // 仕向地コード
                paraMap.put("msgJusho", i.get("jshDtlListJisCd").toString()
                        + i.get("jshDtlListHShimukeChiCd").toString());
                // テーブル名
                paraMap.put("tblName", "MS_JUSHO");
                boolean haitaFlg = haitaCheckVersion(serviceInterfaceBean, paraMap);
                if (!haitaFlg) {
                    return;
                }
            }

            // JIS変換情報マスタ削除
            if (msJisHenkanJohoMapList.size() > 0) {
                mst032Dao.jisHenkanJohoSoftDeleteByColumn(msJisHenkanJohoMapList);
            }
            // 仕向地変換情報マスタ削除
            if (msShimukeChiHenkanJohoMapList.size() > 0) {
                mst032Dao.shimukeChiHenkanJohoSoftDeleteByColumn(msShimukeChiHenkanJohoMapList);
            }
            // 住所マスタ削除
            if (msJushoMapList.size() > 0) {
                jushoDao.updateById(msJushoMapList);
            }
        }
    }

    /**
     * バージョン排他チェック
     *
     * @param serviceInterfaceBean JSFからの通信情報
     * @param paraMap 各テーブル排他用パラメータ
     * @return 排他チェック結果
     */
    private boolean haitaCheckVersion(ServiceInterfaceBean serviceInterfaceBean, Map<String, Object> paraMap) {
        // バージョンチェック(排他)
        if (!busVersionCheck.checkVersion(paraMap)) {
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(1));
            // エラーメッセージを表示させ、処理を終了
            serviceInterfaceBean.addMessage("WARN", MessageCnst.COME0014,
                    paraMap.get("msgJusho").toString());
            serviceInterfaceBean.setTableName(paraMap.get("tblName").toString());
            return false;
        }
        return true;
    }
}
