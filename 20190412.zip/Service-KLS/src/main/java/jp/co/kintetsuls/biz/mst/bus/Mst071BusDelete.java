/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.mst.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.base.dao.BaseDao;
import jp.co.kintetsuls.biz.table.dao.MsShuyakuCdDao;
import jp.co.kintetsuls.biz.table.model.MsShuyakuCd;
import jp.co.kintetsuls.common.SystemColumn;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.utils.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

/**
 * 集約コードマスタ行削除処理
 *
 * @author 许博 (MBP)
 * @version 2019/2/25 新規作成
 */
@Component("MST071_DELETE_ROW_DETAIL")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Mst071BusDelete extends BaseBus {

    /**
     * DAO定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsShuyakuCdDao msShuyakuCdDao;

    /**
     * 集約コードマスタ削除処理
     *
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        
        // 更新レコード
        Map koshinMap = null;
        
        // 集約コードマスタエンティティ
        MsShuyakuCd entity = null;
        
        // パラメータを解析する
        ObjectMapper mapper = new ObjectMapper();
        List<Map<String, Object>> recordList = mapper.readValue(serviceInterfaceBean.getJson(), List.class);

        // 削除一覧リストを生成する
        List<Map<String, MsShuyakuCd>> sakujyoIchiranList = new ArrayList();
        
        // 削除一覧履歴リストを初期化する
        List<MsShuyakuCd> sakujyoIchiranRirekiList = new ArrayList();

        // 集約コードマスタの削除処理を行う
        if (recordList != null && recordList.size() > 0) {
            // 削除一覧リスト作成
            for (Map<String, Object> record : recordList) {
                koshinMap = new HashMap();
                entity = new MsShuyakuCd();
                // システムカラムを設定する
                entity = SystemColumn.systemColumnSet(2, entity, serviceInterfaceBean);
                
                entity.setEigyoshoCd(objectToString(record.get("listEigyoshoCd")));
                entity.setShuyakuKbn(objectToString(record.get("listShuyakuKbn")));
                entity.setShuyakuCd(objectToString(record.get("listShuyakuCd")));
                entity.setShuyakuCdMeisho(objectToString(record.get("listShuyakuCdMeisho")));
                entity.setBiko(objectToString(record.get("listBiko")));
                entity.setSakujoFlg("1");
                entity.setShuyakuCdDataVersion(NumberUtils.toInt(objectToString(record.get("listDataVersion"))) + 1);
                koshinMap.put(BaseDao.UPDATE_BEAN_CRT, entity);
                koshinMap.put(BaseDao.UPDATE_BEAN_UPD, entity);

                sakujyoIchiranList.add(koshinMap);
                sakujyoIchiranRirekiList.add(entity);
            }
        }

        // 削除処理を行う
        if (sakujyoIchiranList.size() > 0) {
            msShuyakuCdDao.updateById(sakujyoIchiranList);
            msShuyakuCdDao.createRirekiById(sakujyoIchiranRirekiList);
        }

    }
}
