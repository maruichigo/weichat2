package jp.co.kintetsuls.biz.base.bus;

import org.springframework.context.annotation.Scope;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

@Scope(value = WebApplicationContext.SCOPE_REQUEST)
public abstract class BaseBus implements IBaseBus {
    protected WebApplicationContext wac;
    
    public BaseBus (){
        //SpringDataでリポジトリを使ってDBへのアクセスを自動で作成する
        SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
    }

    @Override
    public void setWebApplicationContext(WebApplicationContext wac){
        this.wac = wac;
    }
    
    public String objectToString(Object o) {
        if (o == null) {
            return null;
        }
        return o.toString();
    }
    
    public String objectToStringOrBlank(Object o) {
        if (o == null) {
            return "";
        }
        return o.toString();
    }
}