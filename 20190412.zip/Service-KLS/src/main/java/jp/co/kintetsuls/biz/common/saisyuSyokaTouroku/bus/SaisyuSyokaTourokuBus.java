package jp.co.kintetsuls.biz.common.saisyuSyokaTouroku.bus;

import java.util.Date;
import javax.annotation.Resource;

import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.biz.table.dao.TrShiyoJohoKanriDao;
import jp.co.kintetsuls.biz.table.model.TrShiyoJohoKanri;
import jp.co.kintetsuls.common.SystemColumn;
import jp.co.kintetsuls.common.cnst.StndConsIF;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

/**
 * 最終使用日登録処理
 * 
 * @author 黄義輝 (MBP)
 * @version 2019/03/18 新規作成
 */
@Component
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class SaisyuSyokaTourokuBus {

    /**
     * 使用情報管理テーブルDao定義
     */
    @Autowired(required=true)
    @Resource(shareable=true)
    protected TrShiyoJohoKanriDao trShiyoJohoKanriDao;

    /**
     * 使用情報管理テーブル
     */
    TrShiyoJohoKanri trShiyoJohoKanri;

    /**
     * 最終使用日登録処理
     * 
     * @param serviceInterfaceBean 共通情報
     * @param trShiyoJohoKanri 最終使用日情報
     * @throws Exception 
     */
    public void saisyuSyokaTouroku(ServiceInterfaceBean serviceInterfaceBean, TrShiyoJohoKanri trShiyoJohoKanri) throws Exception{

        if (trShiyoJohoKanri != null) {

            // 使用情報検索
            TrShiyoJohoKanri trShiyoJohoKanrResult = trShiyoJohoKanriDao.findById(trShiyoJohoKanri);

            // 使用情報を登録する場合
            if (trShiyoJohoKanrResult == null) {
                // システムカラム
                trShiyoJohoKanri = SystemColumn.systemColumnSet(StndConsIF.SYSCOL_INSERT, trShiyoJohoKanri, serviceInterfaceBean);
                // 使用日付
                trShiyoJohoKanri.setShiyoHizuke(new Date());
                // 削除フラグ
                trShiyoJohoKanri.setSakujoFlg("0");
                // 使用情報を登録
                trShiyoJohoKanriDao.insert(trShiyoJohoKanri);

            } else {
                // 使用情報を更新する場合
                // システムカラム
                trShiyoJohoKanrResult = SystemColumn.systemColumnSet(StndConsIF.SYSCOL_UPDATE, trShiyoJohoKanrResult, serviceInterfaceBean);
                // 使用日付
                trShiyoJohoKanrResult.setShiyoHizuke(new Date());
                // 使用情報を登録
                trShiyoJohoKanriDao.updateById(trShiyoJohoKanri, trShiyoJohoKanrResult);

            }
        }
    }

    /**
     * Objectタイプ変換 Stringタイプ
     * 
     * @param obj Objectタイ
     * @return Stringタイプ
     */
    public String objectToString(Object obj) {
        if (obj == null) {
            return null;
        }
        return obj.toString();
    }
}