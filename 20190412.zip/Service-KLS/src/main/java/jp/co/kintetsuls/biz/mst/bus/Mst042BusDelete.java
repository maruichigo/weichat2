package jp.co.kintetsuls.biz.mst.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import java.util.Map;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.base.dao.BaseDao;
import jp.co.kintetsuls.biz.common.versionCheck.bus.BusVersionCheck;
import jp.co.kintetsuls.biz.mst.dao.Mst042Dao;
import jp.co.kintetsuls.biz.table.dao.MsEigyoshoDao;
import jp.co.kintetsuls.biz.table.dao.MsEigyoshoGroupDao;
import jp.co.kintetsuls.biz.table.dao.MsEigyoshoOroshiTankaDao;
import jp.co.kintetsuls.biz.table.model.MsEigyosho;
import jp.co.kintetsuls.biz.table.model.MsEigyoshoGroup;
import jp.co.kintetsuls.biz.table.model.MsEigyoshoOroshiTanka;
import jp.co.kintetsuls.common.SystemColumn;
import jp.co.kintetsuls.common.cnst.MessageCnst;
import jp.co.kintetsuls.common.cnst.StndConsIF;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.kintetsuls.utils.StrUtils;

/**
 * 営業所マスタ詳細の削除処理
 *
 * @author 雷珍 (MBP)
 * @version 2019/3/6 新規作成
 */
@Component("MST042_DELETE")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Mst042BusDelete extends BaseBus {

     /**
     * バージョンチェック(排他)
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected BusVersionCheck busVersionCheck;
    
    /**
     * 営業所マスタ詳細Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected Mst042Dao mst042Dao;

    /**
     * 営業所マスタDao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsEigyoshoDao msEigyoshoDao;

    /**
     * 営業所卸単価マスタDao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsEigyoshoOroshiTankaDao msEigyoshoOroshiTankaDao;

    /**
     * 営業所グループマスタDao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsEigyoshoGroupDao msEigyoshoGroupDao;

    /**
     * パラメータ
     */
    private Map<String, Object> params = null;

    /**
     * 営業所コード
     */
    private String eigyoshoCd;
    
    /**
     * 適用開始日
     */
    private Date tekiyoKaishibi;
    
    /**
     * 適用終了日
     */
    private Date tekiyoShuryobi;
    
     /**
     * 適用開始日(排他メッセージ用)
     */
    private String msgTekiyoKaishibi;
    
    /**
     * エラーフラグ
     */
    private boolean errorFlg = false;
    
    /**
     * 営業所マスタ詳細の削除処理
     *
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        // パラメータを取得する
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

        // 営業所マスタ基本情報
        Map<String, Object> eigyoshoDeleteInfo = (Map<String, Object>) params.get("eigyoshoDeleteInfo");
        
        // 共通用項目設定
        // 営業所コード
        eigyoshoCd = StrUtils.defaultString(eigyoshoDeleteInfo.get("conEigyoshoCd"));
        // 適用開始日
        long tekiyoKaishibiTime = Long.valueOf(StrUtils.defaultString(eigyoshoDeleteInfo.get("conTekiyoKaishibi")));
        tekiyoKaishibi = new Date(tekiyoKaishibiTime);
        SimpleDateFormat sdf = new SimpleDateFormat(StndConsIF.DF_YYYY_MM_DD);
        msgTekiyoKaishibi = sdf.format(tekiyoKaishibi);
        
        // 適用終了日
        if (!CheckUtils.isEmpty(StrUtils.defaultString(eigyoshoDeleteInfo.get("conTekiyoShuryobi")))) {
            long tekiyoShuryobiTime = Long.valueOf(StrUtils.defaultString(eigyoshoDeleteInfo.get("conTekiyoShuryobi")));
            tekiyoShuryobi =  new Date(tekiyoShuryobiTime);
        }
        
        // 削除/論理削除対象
        String deleteKbn = StrUtils.defaultString(params.get("deleteKbn"));
        
        // 営業所マスタ削除処理
        msEigyoshoDelete(serviceInterfaceBean, eigyoshoDeleteInfo, deleteKbn);
        
        // 論理削除の場合
        if (CheckUtils.isEqual(deleteKbn, "RonriSakujo") && !errorFlg) {
            // 卸単価情報_更新一覧リスト
            List<Map<String, Object>> eigyoshoOroshiTankaDelList = 
                    (List<Map<String, Object>>) params.get("eigyoshoOroshiTankaDeleteList");

            if (eigyoshoOroshiTankaDelList.size() > 0) {
                // 営業所卸単価マスタ削除処理
                msEigyoshoOroshiTankaDelete(serviceInterfaceBean, eigyoshoOroshiTankaDelList);
            }

            // 営業所グループ情報_更新一覧リスト
            List<Map<String, Object>> eigyoshoGroupDelList = 
                    (List<Map<String, Object>>) params.get("eigyoshoGroupDeleteList");
            if (eigyoshoGroupDelList.size() > 0) {
                // 営業所グループマスタ削除処理
                msEigyoshoGroupDelete(serviceInterfaceBean, eigyoshoGroupDelList);
            }
        }
    }

    /**
     * 営業所マスタ_削除処理
     * 
     * @param serviceInterfaceBean JSFからの通信情報
     * @param eigyoshoDeleteInfo 営業所マスタ削除情報
     * @param deleteKbn 削除/論理削除対象
     */
    private void msEigyoshoDelete(ServiceInterfaceBean serviceInterfaceBean, 
            Map<String, Object> eigyosyo, String deleteKbn) {
        
        // テーブル「営業所マスタ」削除用
        List<Map<String, MsEigyosho>> msEigyoshoList = new ArrayList<>();
        
        // 更新一覧履歴リストを初期化する
        List<MsEigyosho> koshinIchiranRirekiList = new ArrayList();    
        
        // 営業所マスタのパラメータ設定
        Map msEigyoshoMap = new HashMap<>();

        // 削除項目
        MsEigyosho msEigyosho = new MsEigyosho();

        // バージョンチェック(排他)
        Map param = new HashMap();
        // 営業所コード
        param.put("EIGYOSHO_CD", eigyoshoCd);
        // 適用開始日
        param.put("TEKIYO_KAISHIBI", tekiyoKaishibi);
        // 更新ユーザーID
        param.put("koushinUserCd", StrUtils.defaultString(eigyosyo.get("kshnDtlUser")));
        // 更新カウンタ
        param.put("koushinCounter", StrUtils.defaultString(eigyosyo.get("dtlKoshinCounter")));
        // テーブル名：営業所マスタ
        param.put("tblName", "MS_EIGYOSHO"); 
        // バージョンチェック(排他)
        if (!busVersionCheck.checkVersion(param)) {
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(1));
            // エラーメッセージを表示させ、処理を終了
            serviceInterfaceBean.addMessage("WARN", MessageCnst.COME0014,
                    eigyoshoCd.concat(msgTekiyoKaishibi));
            serviceInterfaceBean.setTableName("営業所マスタ");
            errorFlg = true;
            return;
        }

        msEigyosho = SystemColumn.systemColumnSet(StndConsIF.SYSCOL_UPDATE, 
                    msEigyosho, serviceInterfaceBean);
        
        // 削除ボタン押下
        if (!CheckUtils.isEqual(deleteKbn, "RonriSakujo")) {
            // 適用終了日
            msEigyosho.setTekiyoShuryobi(tekiyoShuryobi);
        } else {
            // 論理削除ボタン押下
            // 削除フラグ
            msEigyosho.setSakujoFlg("1");
        }
        // 営業所データバージョン
        if (eigyosyo.get("dtlEigyoshoDataVersion") != null 
                && eigyosyo.get("dtlEigyoshoDataVersion") != "") {
            msEigyosho.setEigyoshoDataVersion(Integer.parseInt(
                StrUtils.defaultString(eigyosyo.get("dtlEigyoshoDataVersion"))) + 1);

        }
        // 削除条件を設定する        
        // 営業所コード
        msEigyosho.setEigyoshoCd(eigyoshoCd);
        // 適用開始日
        msEigyosho.setTekiyoKaishibi(tekiyoKaishibi);
        
        // 削除項目設定
        msEigyoshoMap.put(BaseDao.UPDATE_BEAN_UPD, msEigyosho);
        // 削除条件設定
        msEigyoshoMap.put(BaseDao.UPDATE_BEAN_CRT, msEigyosho);
        // 営業所マスタ削除データ設定
        msEigyoshoList.add(msEigyoshoMap);
        koshinIchiranRirekiList.add(msEigyosho);
        
        // 営業所マスタ削除
        msEigyoshoDao.updateById(msEigyoshoList);
        msEigyoshoDao.createRirekiById(koshinIchiranRirekiList);
    }

    /**
     * 営業所卸単価マスタ_削除処理
     * 
     * @param serviceInterfaceBean JSFからの通信情報
     * @param eigyoshoOroshiTankaDelList 営業所卸単価削除情報リスト
     */
    private void msEigyoshoOroshiTankaDelete(ServiceInterfaceBean serviceInterfaceBean,
            List<Map<String, Object>> eigyoshoOroshiTankaDelList) {
        
        // テーブル「営業所卸単価マスタ」削除用
        List<Map<String, MsEigyoshoOroshiTanka>> msEigyoshoOroshiTankaList = new ArrayList<>();
        
        // 更新一覧履歴リストを初期化する
        List<MsEigyoshoOroshiTanka> koshinIchiranRirekiList = new ArrayList();    

        for (Map<String, Object> eigyosyoOrs : eigyoshoOroshiTankaDelList) {
            Map msEigyoshoOroshiTankaMap = new HashMap<>();
             
            // 営業所卸単価マスタのパラメータ設定
            MsEigyoshoOroshiTanka msEigyoshoOroshiTanka = new MsEigyoshoOroshiTanka();
            // 営業所コード
            msEigyoshoOroshiTanka.setEigyoshoCd(eigyoshoCd);
            // 適用開始日
            msEigyoshoOroshiTanka.setTekiyoKaishibi(tekiyoKaishibi);
            // 伝票種別コード
            msEigyoshoOroshiTanka.setDempyoShubetsuCd(StrUtils.defaultString(
                    eigyosyoOrs.get("orsDtlListHDempyoShubetsuCd")));
            // デフォルト使用フラグ
            String defaultshiyoFlg = StrUtils.defaultString(eigyosyoOrs.get("orsDtlListDefaultShiyo"));
            if (CheckUtils.isEqual(defaultshiyoFlg, "true")) {
                // 1:デフォルト
                msEigyoshoOroshiTanka.setDefaultShiyoFlg("1");
            } else {
                // 0:デフォルトではない
                msEigyoshoOroshiTanka.setDefaultShiyoFlg("0");
            }
            // 集荷卸単価
            if (eigyosyoOrs.get("orsDtlListShukaOroshiTanka") != null
                    && eigyosyoOrs.get("orsDtlListShukaOroshiTanka") != "") {
                msEigyoshoOroshiTanka.setShukaOroshiTanka(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListShukaOroshiTanka"))));
            }
            // 集荷卸最低額
            if (eigyosyoOrs.get("orsDtlListShukaOroshiSaiteiGaku") != null
                    && eigyosyoOrs.get("orsDtlListShukaOroshiSaiteiGaku") != "") {
                msEigyoshoOroshiTanka.setShukaOroshiSaiteiGaku(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListShukaOroshiSaiteiGaku"))));
            }
            // 集荷卸計上先営業所コード
            msEigyoshoOroshiTanka.setShukaOroshiKeijoEighoshoCd(
                    StrUtils.defaultString(eigyosyoOrs.get("orsDtlListShukaOroshiKeijoEighoshoCd")));
            // 発送母船卸単価
            if (eigyosyoOrs.get("orsDtlListHsoBosenTanka") != null
                    && eigyosyoOrs.get("orsDtlListHsoBosenTanka") != "") {
                msEigyoshoOroshiTanka.setHsoBosenTanka(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListHsoBosenTanka"))));
            }
            // 発送母船卸最低額
            if (eigyosyoOrs.get("orsDtlListHsoBosenSaiteiGaku") != null
                    && eigyosyoOrs.get("orsDtlListHsoBosenSaiteiGaku") != "") {
                msEigyoshoOroshiTanka.setHsoBosenSaiteiGaku(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListHsoBosenSaiteiGaku"))));
            }
            // 発送母船卸計上先営業所コード
            msEigyoshoOroshiTanka.setHsoBosenKeijoEighoshoCd(
                    StrUtils.defaultString(eigyosyoOrs.get("orsDtlListHsoBosenKeijoEighoshoCd")));
            // 到着母船卸単価
            if (eigyosyoOrs.get("orsDtlListTckBosenTanka") != null
                    && eigyosyoOrs.get("orsDtlListTckBosenTanka") != "") {
                msEigyoshoOroshiTanka.setTckBosenTanka(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListTckBosenTanka"))));
            }
            // 到着母船卸最低額
            if (eigyosyoOrs.get("orsDtlListTckBosenSaiteiGaku") != null
                    && eigyosyoOrs.get("orsDtlListTckBosenSaiteiGaku") != "") {
                msEigyoshoOroshiTanka.setTckBosenSaiteiGaku(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListTckBosenSaiteiGaku"))));
            }
            // 到着母船卸計上先営業所コード
            msEigyoshoOroshiTanka.setTckBosenKeijoEighoshoCd(
                    StrUtils.defaultString(eigyosyoOrs.get("orsDtlListTckBosenKeijoEighoshoCd")));
            // 仕分卸単価
            if (eigyosyoOrs.get("orsDtlListSwkOroshiTanka") != null
                    && eigyosyoOrs.get("orsDtlListSwkOroshiTanka") != "") {
                msEigyoshoOroshiTanka.setShiwakeOroshiTanka(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListSwkOroshiTanka"))));
            }
            // 仕分卸最低額
            if (eigyosyoOrs.get("orsDtlListSwkOroshiSaiteiGaku") != null
                    && eigyosyoOrs.get("orsDtlListSwkOroshiSaiteiGaku") != "") {
                msEigyoshoOroshiTanka.setShiwakeOroshiSaiteiGaku(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListSwkOroshiSaiteiGaku"))));
            }
            // 仕分卸計上先営業所コード
            msEigyoshoOroshiTanka.setShiwakeOroshiKeijoEighoshoCd(
                    StrUtils.defaultString(eigyosyoOrs.get("orsDtlListSwkOroshiKeijoEighoshoCd")));
            // 配達卸単価
            if (eigyosyoOrs.get("orsDtlListHttOroshiTanka") != null
                    && eigyosyoOrs.get("orsDtlListHttOroshiTanka") != "") {
                msEigyoshoOroshiTanka.setHttOroshiTanka(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListHttOroshiTanka"))));
            }
            // 配達卸最低額
            if (eigyosyoOrs.get("orsDtlListHttOroshiSaiteiGaku") != null
                    && eigyosyoOrs.get("orsDtlListHttOroshiSaiteiGaku") != "") {
                msEigyoshoOroshiTanka.setHttOroshiSaiteiGaku(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListHttOroshiSaiteiGaku"))));
            }
            // 配達卸計上先営業所コード
            msEigyoshoOroshiTanka.setHttOroshiKeijoEighoshoCd(
                    StrUtils.defaultString(eigyosyoOrs.get("orsDtlListHttOroshiKeijoEighoshoCd")));
            // システムカラムの設定
            msEigyoshoOroshiTanka = SystemColumn.systemColumnSet(StndConsIF.SYSCOL_UPDATE, 
                    msEigyoshoOroshiTanka, serviceInterfaceBean);
            // 削除フラグ
            msEigyoshoOroshiTanka.setSakujoFlg("1");
            
            // 営業所データバージョン
            if (eigyosyoOrs.get("orsEigyoshoDataVersion") != null 
                    && eigyosyoOrs.get("orsEigyoshoDataVersion") != "") {
                msEigyoshoOroshiTanka.setEigyoshoDataVersion(Integer.parseInt(
                    StrUtils.defaultString(eigyosyoOrs.get("orsEigyoshoDataVersion"))) + 1);
            
            }
            // 削除項目設定
            msEigyoshoOroshiTankaMap.put(BaseDao.UPDATE_BEAN_UPD, msEigyoshoOroshiTanka);
            // 削除条件設定
            msEigyoshoOroshiTankaMap.put(BaseDao.UPDATE_BEAN_CRT, msEigyoshoOroshiTanka);
            // 営業所卸単価マスタ削除データ設定
            msEigyoshoOroshiTankaList.add(msEigyoshoOroshiTankaMap);
            koshinIchiranRirekiList.add(msEigyoshoOroshiTanka);
        }
        
        // 営業所卸単価マスタ削除
        msEigyoshoOroshiTankaDao.updateById(msEigyoshoOroshiTankaList);
        msEigyoshoOroshiTankaDao.createRirekiById(koshinIchiranRirekiList);
    }

    /**
     * 営業所グループマスタ_削除処理
     * 
     * @param serviceInterfaceBean JSFからの通信情報
     * @param eigyoshoGroupDelList 営業所グループ削除情報リスト
     */
    private void msEigyoshoGroupDelete(ServiceInterfaceBean serviceInterfaceBean,
            List<Map<String, Object>> eigyoshoGroupDelList) {
       
        // テーブル「営業所グループマスタ」削除用
        List<Map<String, MsEigyoshoGroup>> msEigyoshoGroupList = new ArrayList<>();
        
        // 更新一覧履歴リストを初期化する
        List<MsEigyoshoGroup> koshinIchiranRirekiList = new ArrayList();    

        for (Map<String, Object> eigyosyoGroup : eigyoshoGroupDelList) {
            Map msEigyoshoGroupMap = new HashMap<>();
             
            // 営業所グループマスタのパラメータ設定
            MsEigyoshoGroup msEigyoshoGroup = new MsEigyoshoGroup();
            
             // 営業所コード
            msEigyoshoGroup.setEigyoshoCd(eigyoshoCd);
            // 適用開始日
            msEigyoshoGroup.setTekiyoKaishibi(tekiyoKaishibi);
            // 営業所グループシーケンス
            if (eigyosyoGroup.get("egrpDtlListEigyoshoGroupSeq") != null 
                    && eigyosyoGroup.get("egrpDtlListEigyoshoGroupSeq") != "") {
                msEigyoshoGroup.setEigyoshoGroupSeq(Integer.parseInt(
                    StrUtils.defaultString(eigyosyoGroup.get("egrpDtlListEigyoshoGroupSeq"))));
            }
            // 営業所データバージョン
            if (eigyosyoGroup.get("egrpEigyoshoDataVersion") != null 
                    && eigyosyoGroup.get("egrpEigyoshoDataVersion") != "") {
                msEigyoshoGroup.setEigyoshoDataVersion(Integer.parseInt(
                    StrUtils.defaultString(eigyosyoGroup.get("egrpEigyoshoDataVersion"))) + 1);
            
            }
            // 上位営業所コード
            msEigyoshoGroup.setJoiEigyoshoCd(
                    StrUtils.defaultString(eigyosyoGroup.get("egrpDtlListJoiEigyoshoCd")));
            // 組織分類コード
            String mainSoshikiFlg = StrUtils.defaultString(eigyosyoGroup.get("egrpDtlListMainSoshiki"));
            if (CheckUtils.isEqual(mainSoshikiFlg, "true")) {
                // 1:メイン
                msEigyoshoGroup.setSoshikiBunruiCd("1");
            } else {
                // 2:サブ
                msEigyoshoGroup.setSoshikiBunruiCd("2");
            }
            // サブ組織名
            msEigyoshoGroup.setSubSoshikiMei(
                    StrUtils.defaultString(eigyosyoGroup.get("egrpDtlListSubSoshikiMei")));
            // 削除フラグ
            msEigyoshoGroup.setSakujoFlg("1");
            // システムカラムの設定
            msEigyoshoGroup = SystemColumn.systemColumnSet(StndConsIF.SYSCOL_UPDATE, 
                    msEigyoshoGroup, serviceInterfaceBean);
            
            // 削除項目設定
            msEigyoshoGroupMap.put(BaseDao.UPDATE_BEAN_UPD, msEigyoshoGroup);
            // 削除条件設定
            msEigyoshoGroupMap.put(BaseDao.UPDATE_BEAN_CRT, msEigyoshoGroup);
            // 営業所グループマスタ削除設定
            msEigyoshoGroupList.add(msEigyoshoGroupMap);
            koshinIchiranRirekiList.add(msEigyoshoGroup);
        }
        
        // 営業所グループマスタ削除
        msEigyoshoGroupDao.updateById(msEigyoshoGroupList);
        msEigyoshoGroupDao.createRirekiById(koshinIchiranRirekiList);
        
    }
}