/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.lgn.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.HashMap;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import java.util.Map;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.common.shinseiDatasakusei.dao.DataShinseiDao;
import jp.co.kintetsuls.biz.lgn.dao.Lgn031Dao;
import jp.co.kintetsuls.biz.lgn.model.Lgn031Def;
import jp.co.kintetsuls.biz.table.dao.MsShinseiShubetsuDao;
import jp.co.kintetsuls.biz.table.dao.TrPasswordShokikaShinseiShosaiDao;
import jp.co.kintetsuls.biz.table.dao.TrShinseiDao;
import jp.co.kintetsuls.biz.table.dao.TrShinseiShosaiDao;
import jp.co.kintetsuls.biz.table.model.MsShinseiShubetsu;
import jp.co.kintetsuls.biz.table.model.TrPasswordShokikaShinseiShosai;
import jp.co.kintetsuls.biz.table.model.TrShinsei;
import jp.co.kintetsuls.biz.table.model.TrShinseiShosai;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.kintetsuls.utils.DateUtils;

/**
 * 申請処理
 *
 * @author 黄義輝 (MBP)
 * @version 2019/04/01 新規作成
 */
@Component("LGN031_DOAPPLY")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Lgn031BusDoapply extends BaseBus {

    /**
     * Lgn031Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected Lgn031Dao lgn031Dao;

    /**
     * 申請データDAO
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected DataShinseiDao dataShinseiDao;

    /**
     * 申請種別Dao
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsShinseiShubetsuDao msShinseiShubetsuDao;

    /**
     * パスワード初期化申請詳細Dao
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected TrPasswordShokikaShinseiShosaiDao trPasswordShokikaShinseiShosaiDao;
      
    /**
     * 申請Dao
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected TrShinseiDao trShinseiDao;

    /**
     * 申請詳細Dao
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected TrShinseiShosaiDao trShinseiShosaiDao;

    /**
     * 申請詳細定義
     */
    protected TrShinseiShosai trShinseiShosai;

    /**
     * 申請定義
     */
    protected TrShinsei trShinsei;

    /**
     * パスワード初期化申請詳細定義
     */
    protected TrPasswordShokikaShinseiShosai trPasswordShokikaShinseiShosai;

    /**
     * 申請種別定義
     */
    protected MsShinseiShubetsu msShinseiShubetsu;

    /**
     * 申請シーケンス
     */
    private static final String GET_SEQUENCE = "getShinseiIdSeq";

    /**
     * 申請処理
     * 
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception　異常
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {

        // パラメータを解析する
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> param = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

        // ワーク.申請ID
        String shinseiId = "";

        // ワーク.申請種別コード  
        String shinseiShubetsuCd = "";

        // 申請プロセスアクティビティ情報
        List<Lgn031Def> shinseiProcessActivityJoho;

        // シーケンスから、申請IDを取得する
        shinseiId = dataShinseiDao.getSequence(GET_SEQUENCE).toString();

        Map<String, Object> result = new HashMap<>();

        // ワーク.申請ID設定
        result.put("shinseiId", shinseiId);

        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));

        // 申請種別情報を取得する。
        msShinseiShubetsu = new MsShinseiShubetsu();
        msShinseiShubetsu.setShinseiShubetsuButuriMei("PASSWORD_SHOKIKA");
        List<MsShinseiShubetsu> msShinseiShubetsuResultList = msShinseiShubetsuDao.findByColumn(msShinseiShubetsu);
        
        // 正常に取得された場合
        if (msShinseiShubetsuResultList != null && !msShinseiShubetsuResultList.isEmpty()) {
            // ワーク.申請種別コード設定
            shinseiShubetsuCd = msShinseiShubetsuResultList.get(0).getShinseiShubetsuCd();
        }

        // ワーク.ユーザーコード
        String hyoDtlUserCd = objectToString(param.get("hyoDtlUserCd"));
        // ワーク.通知方法
        String hyoDtlTsuchiHoho = objectToString(param.get("hyoDtlTsuchiHoho"));
        // ワーク.電話番号
        String hyoDtlTelBango = objectToString(param.get("hyoDtlTelBango"));
        // ワーク.連絡先担当者名
        String hyoDtlRenrakusakiTantoshaMei = objectToString(param.get("hyoDtlRenrakusakiTantoshaMei"));
        // ワーク.メールアドレス
        String hyoDtlMailAddress = objectToString(param.get("hyoDtlMailAddress"));
        // ワーク.申請理由
        String hyoDtlShinseiRiyu = objectToString(param.get("hyoDtlShinseiRiyu"));

        // 全段階の申請プロセスアクティビティ情報を取得する
        Map paramMap = new HashMap();
        // ワーク.申請種別コード設定
        paramMap.put("shinseiShubetsuCd", shinseiShubetsuCd);
        // ワーク.通知方法
        paramMap.put("hyoDtlTsuchiHoho", hyoDtlTsuchiHoho);

        // 申請プロセスアクティビティ情報を取得する。
        shinseiProcessActivityJoho
                = lgn031Dao.findForShinseiProcessActivityTeigiInfo(paramMap);

        // パスワード初期化申請詳細に登録を行う。
        trPasswordShokikaShinseiShosai = new TrPasswordShokikaShinseiShosai();

        // 申請ID
        trPasswordShokikaShinseiShosai.setShinseiId(shinseiId);
        // ユーザコード
        trPasswordShokikaShinseiShosai.setUserCd(hyoDtlUserCd);
        // 通知方法
        trPasswordShokikaShinseiShosai.setTsuchiHoho(hyoDtlTsuchiHoho);

        // 通知方法 = メールの場合
        if (hyoDtlTsuchiHoho != null && ("1").equals(hyoDtlTsuchiHoho)) {
            // メールアドレス
            trPasswordShokikaShinseiShosai.setMailAddress(hyoDtlMailAddress);
        } else {
            // 電話番号
            trPasswordShokikaShinseiShosai.setTelBango(hyoDtlTelBango);
            // 連絡先
            trPasswordShokikaShinseiShosai.setRenrakusaki(hyoDtlRenrakusakiTantoshaMei);
        }

        // 申請理由
        trPasswordShokikaShinseiShosai.setShinseiRiyu(hyoDtlShinseiRiyu);
        // 本人確認済フラグ
        trPasswordShokikaShinseiShosai.setHonninKakuninSumiFlg("0");
        // パスワード変更フラグ
        trPasswordShokikaShinseiShosai.setPasswordHenkoFlg("0");
        // 削除フラグ
        trPasswordShokikaShinseiShosai.setSakujoFlg("0");
        // 登録日時
        trPasswordShokikaShinseiShosai.setTorokuNichiji(DateUtils.getSysDate());
        // 更新カウンタ
        trPasswordShokikaShinseiShosai.setKoshinCounter(Long.parseLong("0"));
        // 登録端末
        trPasswordShokikaShinseiShosai.setTorokuTammatsu(serviceInterfaceBean.getTammatsu());
        // 最終オペレーション更新日時
        trPasswordShokikaShinseiShosai.setSaishuOperationKoshinNichiji(DateUtils.getSysDate());

        if (CheckUtils.isEmpty(serviceInterfaceBean.getUserCd())) {
            // ログインフラグ
            trPasswordShokikaShinseiShosai.setLoginFlg("0");
            // 登録ユーザー
            trPasswordShokikaShinseiShosai.setTorokuUser(hyoDtlUserCd);
            // 登録営業所
            trPasswordShokikaShinseiShosai.setTorokuEigyosho(getUserDefaultEigyosho(hyoDtlUserCd));
            // 最終オペレーションユーザー
            trPasswordShokikaShinseiShosai.setSaishuOperationUser(hyoDtlUserCd);
        } else {
            // ログインフラグ
            trPasswordShokikaShinseiShosai.setLoginFlg("1");
            // 登録ユーザー
            trPasswordShokikaShinseiShosai.setTorokuUser(serviceInterfaceBean.getUserCd());
            // 登録営業所
            trPasswordShokikaShinseiShosai.setTorokuEigyosho(serviceInterfaceBean.getDefaultEigyosho());
            // 最終オペレーションユーザー
            trPasswordShokikaShinseiShosai.setSaishuOperationUser(serviceInterfaceBean.getUserCd());
        }

        // パスワード初期化申請詳細登録
        trPasswordShokikaShinseiShosaiDao.insert(trPasswordShokikaShinseiShosai);

        // 申請登録
        trShinsei = new TrShinsei();
        // 申請ID
        trShinsei.setShinseiId(shinseiId);
        // 申請種別コード
        trShinsei.setShinseiShubetsuCd(shinseiShubetsuCd);
        // 申請日
        trShinsei.setShinseiBi(DateUtils.getSysDate());

        if (hyoDtlTsuchiHoho != null && ("1").equals(hyoDtlTsuchiHoho)) {
            // 申請ステータス
            trShinsei.setShinseiStatus("04");
        } else {
            // 申請ステータス
            trShinsei.setShinseiStatus("02");
            // 現段階アクティビティNO
            if (shinseiProcessActivityJoho != null
                    && !shinseiProcessActivityJoho.isEmpty()
                    && shinseiProcessActivityJoho.get(0) != null
                    && !CheckUtils.isEmpty(shinseiProcessActivityJoho.get(0).getTsugiShinseiProcessActivityNo())) {
                trShinsei.setGenDankaiActivityNo(
                        Integer.parseInt(objectToString(
                                shinseiProcessActivityJoho.get(0).getTsugiShinseiProcessActivityNo())));
            }
        }

        // 至急申請フラグ
        trShinsei.setShikyuFlg("0");
        // 削除フラグ
        trShinsei.setSakujoFlg("0");
        // 登録日時
        trShinsei.setTorokuNichiji(DateUtils.getSysDate());
        // 更新カウンタ
        trShinsei.setKoshinCounter(Long.parseLong("0"));
        // 登録端末
        trShinsei.setTorokuEigyosho(hyoDtlTelBango);
        // 最終オペレーション更新日時
        trShinsei.setSaishuOperationKoshinNichiji(DateUtils.getSysDate());

        if (CheckUtils.isEmpty(serviceInterfaceBean.getUserCd())) {
            // 登録ユーザー
            trShinsei. setTorokuUser(hyoDtlUserCd);
            // 登録営業所
            trShinsei.setTorokuEigyosho(getUserDefaultEigyosho(hyoDtlUserCd));
            // 最終オペレーションユーザー
            trShinsei.setSaishuOperationUser(hyoDtlUserCd);
        } else {
            // 登録ユーザー
            trShinsei.setTorokuUser(serviceInterfaceBean.getUserCd());
            // 登録営業所
            trShinsei.setTorokuEigyosho(serviceInterfaceBean.getDefaultEigyosho());
            // 最終オペレーションユーザー
            trShinsei.setSaishuOperationUser(serviceInterfaceBean.getUserCd());
        }

        // 申請登録
        trShinseiDao.insert(trShinsei);

        // 申請詳細登録
        if (shinseiProcessActivityJoho != null && !shinseiProcessActivityJoho.isEmpty()) {
            for (Lgn031Def shinseiProcessActivityJohoDef : shinseiProcessActivityJoho) {

                trShinseiShosai = new TrShinseiShosai();

                // 申請ID
                trShinseiShosai.setShinseiId(shinseiId);
                // 申請詳細NO
                trShinseiShosai.setShinseiShosaiNo(getShinseiShosaiNoMax(shinseiId) + 1);
                // 申請プロセスアクティビティNO
                if (!CheckUtils.isEmpty(shinseiProcessActivityJohoDef.getShinseiProcessActivityNo())) {
                    trShinseiShosai.setShinseiProcessActivityNo(
                            Integer.valueOf(shinseiProcessActivityJohoDef.getShinseiProcessActivityNo()));
                }

                // ステータス更新日時
                trShinseiShosai.setKoshinBi(DateUtils.getSysDate());
                // 削除フラグ
                trShinseiShosai.setSakujoFlg("0");
                // 登録日時
                trShinseiShosai.setTorokuNichiji(DateUtils.getSysDate());
                // 更新カウンタ
                trShinseiShosai.setKoshinCounter(Long.parseLong("0"));
                // 登録端末
                trShinseiShosai.setTorokuEigyosho(hyoDtlTelBango);
                // 最終オペレーション更新日時
                trShinseiShosai.setSaishuOperationKoshinNichiji(DateUtils.getSysDate());

                // 通知方法 = メールの場合
                if (hyoDtlTsuchiHoho != null && ("1").equals(hyoDtlTsuchiHoho)) {
                    // ワーク.アクティビティ区分 = 1
                    if (("1").equals(shinseiProcessActivityJohoDef.getActivityKbn())) {
                        // 承認状況結果
                        trShinseiShosai.setShoninJokyoKekka("01");
                        // 申請コメント
                        trShinseiShosai.setShinseiComment(hyoDtlShinseiRiyu);

                    } else {
                        if (CheckUtils.isEmpty(shinseiProcessActivityJohoDef.getTsugiShinseiProcessActivityNo())) {
                            // 承認状況結果
                            trShinseiShosai.setShoninJokyoKekka("03");
                        } else {
                            // 承認状況結果
                            trShinseiShosai.setShoninJokyoKekka("02");
                        }
                    }

                    // ワーク.アクティビティ区分 = 1 AND ログイン情報.ユーザーコード IS NULL
                    if (("1").equals(shinseiProcessActivityJohoDef.getActivityKbn())
                            && CheckUtils.isEmpty(serviceInterfaceBean.getUserCd())) {
                        // ユーザコード
                        trShinseiShosai.setUserCd(hyoDtlUserCd);
                        // 営業所コード
                        trShinseiShosai.setEigyoshoCd(getUserDefaultEigyosho(hyoDtlUserCd));

                    } else if (("1").equals(shinseiProcessActivityJohoDef.getActivityKbn())
                            && !CheckUtils.isEmpty(serviceInterfaceBean.getUserCd())) {
                        // ユーザコード
                        trShinseiShosai.setUserCd(serviceInterfaceBean.getUserCd());
                        // 営業所コード
                        trShinseiShosai.setEigyoshoCd(serviceInterfaceBean.getDefaultEigyosho());
                    }

                } else {

                    // 承認状況結果
                    trShinseiShosai.setShoninJokyoKekka("01");
                    // 申請コメント
                    trShinseiShosai.setShinseiComment(hyoDtlShinseiRiyu);

                    if (CheckUtils.isEmpty(serviceInterfaceBean.getUserCd())) {
                        // ユーザコード
                        trShinseiShosai.setUserCd(hyoDtlUserCd);
                        // 営業所コード
                        trShinseiShosai.setEigyoshoCd(getUserDefaultEigyosho(hyoDtlUserCd));
                    } else {
                        // ユーザコード
                        trShinseiShosai.setUserCd(serviceInterfaceBean.getUserCd());
                        // 営業所コード
                        trShinseiShosai.setEigyoshoCd(serviceInterfaceBean.getDefaultEigyosho());
                    } 
                }

                if (CheckUtils.isEmpty(serviceInterfaceBean.getUserCd())) {
                    // 登録ユーザー
                    trShinseiShosai.setTorokuUser(hyoDtlUserCd);
                    // 登録営業所
                    trShinseiShosai.setTorokuEigyosho(getUserDefaultEigyosho(hyoDtlUserCd));
                    // 最終オペレーションユーザー
                    trShinseiShosai.setSaishuOperationUser(hyoDtlUserCd);
                } else {
                    // 登録ユーザー
                    trShinseiShosai.setTorokuUser(serviceInterfaceBean.getUserCd());
                    // 登録営業所
                    trShinseiShosai.setTorokuEigyosho(serviceInterfaceBean.getDefaultEigyosho());
                    // 最終オペレーションユーザー
                    trShinseiShosai.setSaishuOperationUser(serviceInterfaceBean.getUserCd());
                }

                // 申請詳細登録(申請(メール))
                trShinseiShosaiDao.insert(trShinseiShosai);

                // 通知方法 = 電話の場合
                if (hyoDtlTsuchiHoho != null && ("2").equals(hyoDtlTsuchiHoho)) {
                    return;
                }
            }
        }

    }

    /**
     * 申請ID毎の申請詳細NOの最大値
     * 
     * @param shinseiId 申請ID
     * @return 申請ID毎の申請詳細NOの最大値
     */
    private int getShinseiShosaiNoMax(String shinseiId) {
        Map paramMap = new HashMap();

        paramMap.put("shinseiId", shinseiId);
        
        return lgn031Dao.countShinseiShosaiNoMax(paramMap);

    }

    /**
     * ワーク.ユーザーコードに入力されたユーザーのデフォルト所属箇所取得方法
     * 
     * @param hyoDtlUserCd ワーク.ユーザーコード
     * @return ユーザーのデフォルト所属箇所
     */
    private String getUserDefaultEigyosho(String hyoDtlUserCd) {
        Map paramMap = new HashMap();

        paramMap.put("hyoDtlUserCd", hyoDtlUserCd);
        
        List<Lgn031Def> userDefaultEigyoshoInfo = lgn031Dao.findForUserDefaultEigyosho(paramMap);
        
        String userDefaultEigyosho = "";

        if (userDefaultEigyoshoInfo != null && !userDefaultEigyoshoInfo.isEmpty()) {
            userDefaultEigyosho = objectToString(userDefaultEigyoshoInfo.get(0).getAccessKanoSoshikiCd());
        }

        return userDefaultEigyosho;

    }

}