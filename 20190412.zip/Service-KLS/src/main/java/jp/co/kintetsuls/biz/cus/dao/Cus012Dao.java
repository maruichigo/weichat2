package jp.co.kintetsuls.biz.cus.dao;

import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.biz.base.dao.BaseDao;
import jp.co.kintetsuls.biz.cus.model.Cus012;
import org.apache.ibatis.executor.BatchResult;
import org.springframework.stereotype.Component;

/** ユーザーテーブル処理クラス
 */
@Component
public class Cus012Dao extends BaseDao<Cus012> {

    public Cus012 getKokyakuDetail(Map<String,Object> entity) {
        return getSqlSession().selectOne("cus012.getKokyakuDetail", entity);
    }

    public List<Cus012> getKokyakuMap(Map<String,Object> entity) {
        return getSqlSession().selectList("cus012.getKokyakuMap", entity);
    }

    public int insertKokyakuData(Map<String, Object> entity) {
        getSqlSession().insert("cus012.insertKokyakuData", entity);
        List<BatchResult> batchResultList = getSqlSession().flushStatements();  // DBフラッシュする
        getSqlSession().clearCache();       // キャッシュをクリアする
        
        return batchResultList.get(0).getParameterObjects().size();
    }
    
    public int insertKokyakuMemo(Map<String, Object> entity) {
        getSqlSession().insert("cus012.insertKokyakuMemo", entity);
        List<BatchResult> batchResultList = getSqlSession().flushStatements();  // DBフラッシュする
        getSqlSession().clearCache();       // キャッシュをクリアする
        
        return batchResultList.get(0).getParameterObjects().size();
    }
    
    public int updateKokyakuData(Map<String, Object> entity) {
        getSqlSession().update("cus012.updateKokyakuData", entity);
        List<BatchResult> batchResultList = getSqlSession().flushStatements();  // DBフラッシュする
        getSqlSession().clearCache();       // キャッシュをクリアする
        
        return batchResultList.get(0).getParameterObjects().size();
    }

    public int updateKokyakuMemo(Map<String, Object> entity) {
        getSqlSession().update("cus012.updateKokyakuMemo", entity);
        List<BatchResult> batchResultList = getSqlSession().flushStatements();  // DBフラッシュする
        getSqlSession().clearCache();       // キャッシュをクリアする
        
        return batchResultList.get(0).getParameterObjects().size();
    }

    public int logicalDeleteKokyakuData(Map<String, Object> entity) {
        getSqlSession().update("cus012.logicalDeleteKokyakuData", entity);
        List<BatchResult> batchResultList = getSqlSession().flushStatements();  // DBフラッシュする
        getSqlSession().clearCache();       // キャッシュをクリアする
        
        return batchResultList.get(0).getParameterObjects().size();
    }
    
}
