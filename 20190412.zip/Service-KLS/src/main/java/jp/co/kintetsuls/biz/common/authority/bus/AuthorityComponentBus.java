package jp.co.kintetsuls.biz.common.authority.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import jp.co.kintetsuls.biz.common.authority.dao.AuthorityComponentDao;
import jp.co.kintetsuls.biz.common.authority.model.AuthorityComponent;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;

import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.common.cnst.SysMsg;
import jp.co.kintetsuls.common.json.JSONUtil;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * 利用可能機能取得処理クラス
 * 
 */
@Component("COMMON_GET_AUTHORITY_COMPONENT")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class AuthorityComponentBus extends BaseBus {

    // Dao定義
    @Autowired(required=true)
    @Resource(shareable=true)
    protected AuthorityComponentDao authCompDao;
    private Map<String, Object> params = null;

    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception{
        //init
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

        if(!params.containsKey("userCd")){
            String msg = SysMsg.WRNDATA;
            serviceInterfaceBean.addMessage("WARN", "警告", msg);
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return;
        }

		// 権限の取得
		List<AuthorityComponent> compList = authCompDao.getAuthorityComponent(serviceInterfaceBean.getUserCd());
		serviceInterfaceBean.setJson(JSONUtil.makeJSONString(compList));

    }
}