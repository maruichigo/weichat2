package jp.co.kintetsuls.biz.common.menu.dao;

import java.util.List;
import jp.co.kintetsuls.biz.common.menu.model.ParentMenu;
import jp.co.kintetsuls.biz.base.dao.BaseDao;
import org.springframework.stereotype.Component;

/** メニューテーブル処理クラス
 */
@Component
public class MenuDao extends BaseDao<ParentMenu> {

    public List<ParentMenu> getAvailableMenu(String userCd){
    	return getSqlSession().selectList("menu.getAvailableMenu", userCd);
    }

}
