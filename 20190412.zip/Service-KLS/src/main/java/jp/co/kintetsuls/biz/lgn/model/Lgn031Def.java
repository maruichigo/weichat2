/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.lgn.model;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/** 
 * パスワード初期化 model
 *
 * @author 黄義輝 (MBP)
 * @version 2019/03/19 新規作成
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "lgn031")
public class Lgn031Def implements Serializable{

    private static final long serialVersionUID = 8225066323266434396L;

    /**
     * ユーザーコード
     */
    private String userCd;

    /**
     * 営業所コード
     */
    private String eigyoshoCd;

    /**
     * 申請種別コード
     */
    private String shinseiShubetsuCd;

    /**
     * 申請プロセスアクティビティNO
     */
    private String shinseiProcessActivityNo;

    /**
     * 最終承認者フラグ
     */
    private String saishuShoninShaFlg;

    /** 
     * ユーザー名
     */ 
    private String userMei;

    /** 
     * 適用開始日
     */ 
    private String tekiyoKaishibi;

    /** 
     * 通知方法
     */ 
    private String tsuchiHoho;

    /** 
     * 電話番号
     */ 
    private String telBango;

    /** 
     * 連絡先
     */ 
    private String renrakusaki;

    /** 
     * メールアドレス
     */ 
    private String mailAddress;

    /** 
     *申請理由
     */ 
    private String shinseiRiyu;

    /** 
     * 営業所名
     */ 
    private String eigyoshoMei;

    /** 
     * ロール名
     */ 
    private String roleMei;

    /** 
     * 申請回数
     */ 
    private String shinseiKaisu;

    /** 
     * パスワード誤入力回数
     */ 
    private String passwordGoNyuryokuKaisu;

    /** 
     *本人連絡
     */ 
    private String honninRenraku;

    /** 
     * パスワード変更
     */ 
    private String passwordHenko;

    /** 
     * ワーク.進行状況アイコン
     */ 
    private String shinkouJyoukyouIcon;

    /** 
     * 種別
     */ 
    private String shubetsu;

    /** 
     * 箇所
     */ 
    private String kasho;

    /** 
     * ワーク.ユーザーアイコン
     */ 
    private String userIcon;

    /** 
     * 名前
     */ 
    private String namae;

    /** 
     * 結果
     */ 
    private String kekka;

    /** 
     * 申請コメント
     */ 
    private String shinseiComment;
    
    /** 
     * 申請コメントDisabled;
     */ 
    private boolean shinseiCommentDisabled;;

    /** 
     * 日時
     */ 
    private String nichiji;

    /** 
     * 次申請プロセスアクティビティNO
     */ 
    private String tsugiShinseiProcessActivityNo;

    /** 
     * アクティビティ区分
     */ 
    private String activityKbn;
    
    /** 
     * 現段階アクティビティNO
     */ 
    private String genDankaiActivityNo;

    /** 
     * アクセス可能組織コード
     */ 
    private String accessKanoSoshikiCd;

    @XmlElement(name = "userCd")
    public String getUserCd() {
        return userCd;
    }

    public void setUserCd(String userCd) {
        this.userCd = userCd;
    }

    @XmlElement(name = "eigyoshoCd")
    public String getEigyoshoCd() {
        return eigyoshoCd;
    }

    public void setEigyoshoCd(String eigyoshoCd) {
        this.eigyoshoCd = eigyoshoCd;
    }

    @XmlElement(name = "shinseiShubetsuCd")
    public String getShinseiShubetsuCd() {
        return shinseiShubetsuCd;
    }

    public void setShinseiShubetsuCd(String shinseiShubetsuCd) {
        this.shinseiShubetsuCd = shinseiShubetsuCd;
    }

    @XmlElement(name = "shinseiProcessActivityNo")
    public String getShinseiProcessActivityNo() {
        return shinseiProcessActivityNo;
    }

    public void setShinseiProcessActivityNo(String shinseiProcessActivityNo) {
        this.shinseiProcessActivityNo = shinseiProcessActivityNo;
    }

    @XmlElement(name = "saishuShoninShaFlg")
    public String getSaishuShoninShaFlg() {
        return saishuShoninShaFlg;
    }

    public void setSaishuShoninShaFlg(String saishuShoninShaFlg) {
        this.saishuShoninShaFlg = saishuShoninShaFlg;
    }

    @XmlElement(name = "userMei")
    public String getUserMei() {
        return userMei;
    }

    public void setUserMei(String userMei) {
        this.userMei = userMei;
    }

    @XmlElement(name = "tekiyoKaishibi")
    public String getTekiyoKaishibi() {
        return tekiyoKaishibi;
    }

    public void setTekiyoKaishibi(String tekiyoKaishibi) {
        this.tekiyoKaishibi = tekiyoKaishibi;
    }

    @XmlElement(name = "tsuchiHoho")
    public String getTsuchiHoho() {
        return tsuchiHoho;
    }

    public void setTsuchiHoho(String tsuchiHoho) {
        this.tsuchiHoho = tsuchiHoho;
    }

    @XmlElement(name = "telBango")
    public String getTelBango() {
        return telBango;
    }

    public void setTelBango(String telBango) {
        this.telBango = telBango;
    }

    @XmlElement(name = "renrakusaki")
    public String getRenrakusaki() {
        return renrakusaki;
    }

    public void setRenrakusaki(String renrakusaki) {
        this.renrakusaki = renrakusaki;
    }

    @XmlElement(name = "mailAddress")
    public String getMailAddress() {
        return mailAddress;
    }

    public void setMailAddress(String mailAddress) {
        this.mailAddress = mailAddress;
    }

    @XmlElement(name = "shinseiRiyu")
    public String getShinseiRiyu() {
        return shinseiRiyu;
    }

    public void setShinseiRiyu(String shinseiRiyu) {
        this.shinseiRiyu = shinseiRiyu;
    }

    @XmlElement(name = "eigyoshoMei")
    public String getEigyoshoMei() {
        return eigyoshoMei;
    }

    public void setEigyoshoMei(String eigyoshoMei) {
        this.eigyoshoMei = eigyoshoMei;
    }

    @XmlElement(name = "roleMei")
    public String getRoleMei() {
        return roleMei;
    }

    public void setRoleMei(String roleMei) {
        this.roleMei = roleMei;
    }

    @XmlElement(name = "shinseiKaisu")
    public String getShinseiKaisu() {
        return shinseiKaisu;
    }

    public void setShinseiKaisu(String shinseiKaisu) {
        this.shinseiKaisu = shinseiKaisu;
    }

    @XmlElement(name = "passwordGoNyuryokuKaisu")
    public String getPasswordGoNyuryokuKaisu() {
        return passwordGoNyuryokuKaisu;
    }

    public void setPasswordGoNyuryokuKaisu(String passwordGoNyuryokuKaisu) {
        this.passwordGoNyuryokuKaisu = passwordGoNyuryokuKaisu;
    }

    @XmlElement(name = "honninRenraku")
    public String getHonninRenraku() {
        return honninRenraku;
    }

    public void setHonninRenraku(String honninRenraku) {
        this.honninRenraku = honninRenraku;
    }

    @XmlElement(name = "passwordHenko")
    public String getPasswordHenko() {
        return passwordHenko;
    }

    public void setPasswordHenko(String passwordHenko) {
        this.passwordHenko = passwordHenko;
    }

    @XmlElement(name = "shinkouJyoukyouIcon")
    public String getShinkouJyoukyouIcon() {
        return shinkouJyoukyouIcon;
    }

    public void setShinkouJyoukyouIcon(String shinkouJyoukyouIcon) {
        this.shinkouJyoukyouIcon = shinkouJyoukyouIcon;
    }

    @XmlElement(name = "shubetsu")
    public String getShubetsu() {
        return shubetsu;
    }

    public void setShubetsu(String shubetsu) {
        this.shubetsu = shubetsu;
    }

    @XmlElement(name = "kasho")
    public String getKasho() {
        return kasho;
    }

    public void setKasho(String kasho) {
        this.kasho = kasho;
    }

    @XmlElement(name = "userIcon")
    public String getUserIcon() {
        return userIcon;
    }

    public void setUserIcon(String userIcon) {
        this.userIcon = userIcon;
    }

    @XmlElement(name = "namae")
    public String getNamae() {
        return namae;
    }

    public void setNamae(String namae) {
        this.namae = namae;
    }

    @XmlElement(name = "kekka")
    public String getKekka() {
        return kekka;
    }

    public void setKekka(String kekka) {
        this.kekka = kekka;
    }

    @XmlElement(name = "shinseiComment")
    public String getShinseiComment() {
        return shinseiComment;
    }

    public void setShinseiComment(String shinseiComment) {
        this.shinseiComment = shinseiComment;
    }

    @XmlElement(name = "shinseiCommentDisabled")
    public boolean getShinseiCommentDisabled() {
        return shinseiCommentDisabled;
    }

    public void setShinseiCommentDisabled(boolean shinseiCommentDisabled) {
        this.shinseiCommentDisabled = shinseiCommentDisabled;
    }

    @XmlElement(name = "nichiji")
    public String getNichiji() {
        return nichiji;
    }

    public void setNichiji(String nichiji) {
        this.nichiji = nichiji;
    }

    @XmlElement(name = "tsugiShinseiProcessActivityNo")
    public String getTsugiShinseiProcessActivityNo() {
        return tsugiShinseiProcessActivityNo;
    }

    public void setTsugiShinseiProcessActivityNo(String tsugiShinseiProcessActivityNo) {
        this.tsugiShinseiProcessActivityNo = tsugiShinseiProcessActivityNo;
    }

    @XmlElement(name = "activityKbn")
    public String getActivityKbn() {
        return activityKbn;
    }

    public void setActivityKbn(String activityKbn) {
        this.activityKbn = activityKbn;
    }

    @XmlElement(name = "genDankaiActivityNo")
    public String getGenDankaiActivityNo() {
        return genDankaiActivityNo;
    }

    public void setGenDankaiActivityNo(String genDankaiActivityNo) {
        this.genDankaiActivityNo = genDankaiActivityNo;
    }

    @XmlElement(name = "accessKanoSoshikiCd")
    public String getAccessKanoSoshikiCd() {
        return accessKanoSoshikiCd;
    }

    public void setAccessKanoSoshikiCd(String accessKanoSoshikiCd) {
        this.accessKanoSoshikiCd = accessKanoSoshikiCd;
    }

}
