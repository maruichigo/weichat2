package jp.co.kintetsuls.biz.common.autocomplete.dao;

import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.biz.base.dao.BaseDao;
import jp.co.kintetsuls.biz.common.autocomplete.model.ComCreateListDef;
import org.springframework.stereotype.Component;

/* 
 * AutoComplete処理Daoクラス
 */
@Component
public class ComCreateListDao extends BaseDao<ComCreateListDef> {

    public List<ComCreateListDef> getStringList(String listId) {
        return getSqlSession().selectList("createList." + listId);
    }

    public List<ComCreateListDef> getStringList(String listId, Map params) {
        return getSqlSession().selectList("createList." + listId, params);
    }
    
}
