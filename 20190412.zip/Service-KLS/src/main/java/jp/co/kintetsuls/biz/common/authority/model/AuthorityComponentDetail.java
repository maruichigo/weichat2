/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.biz.common.authority.model;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "authorityComponentDetail")
public class AuthorityComponentDetail implements Serializable{
    
    private static final long serialVersionUID = 3144615551515151L;

    /** rptのコンポーネントname */
    private String componentName;
    /** 利用設定   0:利用不可(非表示), 1:表示のみ, 2:利用可能 */
    private int riyoSettei;

    public String getComponentName() {
        return componentName;
    }

    public void setComponentName(String componentName) {
        this.componentName = componentName;
    }

    public int getRiyoSettei() {
        return riyoSettei;
    }

    public void setRiyoSettei(int riyoSettei) {
        this.riyoSettei = riyoSettei;
    }
}
