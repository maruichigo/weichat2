package jp.co.kintetsuls.biz.cus.model;

import java.io.Serializable;
import java.sql.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import lombok.Data;

/**
 * Cus012用モデルクラス
 * @author Yuka Kobayashi
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "cus012")
@Data
public class Cus012 implements Serializable {

    private static final long serialVersionUID = 7013090829426790523L;
    
    private String kokyakuCd;
    private Date tekiyoKaishibi;
    private String tekiyoMei;
    private String shinseiStatusCd;
    private String kokyakuShubetsu;
    private String kokyakuKbn;
    private String kokyakuMeiKanji1;        
    private String kokyakuMeiKanji2;        
    private String kokyakuMeiKanji3;        
    private String kokyakuMeiKanji4;        
    private String kokyakuMei;
    
}
