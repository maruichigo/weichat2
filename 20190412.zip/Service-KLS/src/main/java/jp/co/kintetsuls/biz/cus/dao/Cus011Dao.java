package jp.co.kintetsuls.biz.cus.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.biz.base.dao.BaseDao;
import jp.co.kintetsuls.biz.cus.model.Cus011;
import org.springframework.stereotype.Component;
import org.apache.ibatis.executor.BatchResult;
import org.springframework.beans.factory.annotation.Value;

/** Cus011処理クラス
 */
@Component
public class Cus011Dao extends BaseDao<Cus011> {

	@Value("${dao.batch.size}")
	private String envBatchSize;

	@Value("${dao.batch.returnUpdateCounts}")
	private String returnUpdateCounts;

    // 検索処理
    public List<Cus011> getKokyakuList(Map<String,Object> entity) {
        return getSqlSession().selectList("cus011.getKokyakuList", entity);
    }

    // 登録処理
    public int insertKokyaku(List<Map<String, Object>> entity, Map<String, Object> selParams) {        
        int batchSize = Integer.parseInt(envBatchSize);
		int size = entity.size();
		int result = 0;

		List<BatchResult> batchResultListAll = null;
		if (isReturnUpdateCounts()) {
			batchResultListAll = new ArrayList<>();
		}
        
        for(int i=0; i <=size-1; i++){            
            entity.get(i).put("userCd", selParams.get("userCd"));
            getSqlSession().insert("cus011.insertKokyakuData", entity.get(i));
            
            if (((i+1) % batchSize == 0) || (i == (size-1))) {
                List<BatchResult> batchResultList = getSqlSession().flushStatements();  // DBフラッシュする
                getSqlSession().clearCache();       // キャッシュをクリアする
                
				if (isReturnUpdateCounts()) {
					batchResultListAll.addAll(batchResultList);
				}
            }
        } 
        
		if (isReturnUpdateCounts()) {
			result = sumUpdateCounts(batchResultListAll);
		}

		return result;
    } 
    
    
    // 更新処理
    public int updateKokyaku(List<Map<String, Object>> entity, Map<String, Object> selParams) {        
        int batchSize = Integer.parseInt(envBatchSize);
		int size = entity.size();
		int result = 0;

		List<BatchResult> batchResultListAll = null;
		if (isReturnUpdateCounts()) {
			batchResultListAll = new ArrayList<>();
		}
        
        for(int i=0; i<=size-1; i++){            
            entity.get(i).put("userCd", selParams.get("userCd"));
            getSqlSession().update("cus011.updateKokyakuData", entity.get(i));
            
            if (((i+1) % batchSize == 0) || (i == (size-1))) {
                List<BatchResult> batchResultList = getSqlSession().flushStatements();  // DBフラッシュする
                getSqlSession().clearCache();       // キャッシュをクリアする
                
				if (isReturnUpdateCounts()) {
					batchResultListAll.addAll(batchResultList);
				}
            }
        }
        
		if (isReturnUpdateCounts()) {
			result = sumUpdateCounts(batchResultListAll);
		}
		return result;
    } 
    
    // 削除処理
    public int deleteKokyaku(List<Map<String, Object>> entity, Map<String, Object> selParams) {
        int batchSize = Integer.parseInt(envBatchSize);
		int size = entity.size();
		int result = 0;

		List<BatchResult> batchResultListAll = null;
		if (isReturnUpdateCounts()) {
			batchResultListAll = new ArrayList<>();
		}
        
        for(int i=0; i <=size-1; i++){            
            entity.get(i).put("userCd", selParams.get("userCd"));
            getSqlSession().update("cus011.deleteKokyakuData", entity.get(i));
            
            if (((i+1) % batchSize == 0) || (i == (entity.size()-1))) {
                List<BatchResult> batchResultList = getSqlSession().flushStatements();  // DBフラッシュする
                getSqlSession().clearCache();       // キャッシュをクリアする
                
				if (isReturnUpdateCounts()) {
					batchResultListAll.addAll(batchResultList);
				}  
            }
        }
        
		if (isReturnUpdateCounts()) {
			result = sumUpdateCounts(batchResultListAll);
		}
		return result;
    }       
    
	private int sumUpdateCounts(List<BatchResult> batchResultList) {
		int result = 0;
		for (BatchResult batchResult : batchResultList) {
			int[] updateCounts = batchResult.getUpdateCounts();
			for (int updateCount : updateCounts) {
				result += updateCount;
			}
		}
		return result;
	}

	private boolean isReturnUpdateCounts() {
		return "true".equals(returnUpdateCounts);
	}    
}
