/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.biz.common.uploadFile.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.common.uploadCheck.dao.UploadCheckDao;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.cnst.SysMsg;
import jp.co.kintetsuls.common.json.JSONUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

/**
 *
 * @author Malei
 */
@Component("UPLOAD_FILE")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class BusUploadFile extends BaseBus{

    @Autowired(required=true)
    @Resource(shareable=true)
    protected UploadCheckDao uploadCheckDao;

    @Autowired(required=true)
    @Resource(shareable=true)
    protected UploadFileDao uploadFileDao;
    
    private Map<String, Object> params = null;

    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        
        // パラメータを解析する
        ObjectMapper mapper = new ObjectMapper();
        List<Map<String, Object>> recordList = mapper.readValue(serviceInterfaceBean.getJson(), List.class);
        
        // テーブル構造を取得
        List<Map> tableColMapList = new ArrayList<>();
        if (!serviceInterfaceBean.getTableName().isEmpty()) {
            //対象テーブルの構造取得
            tableColMapList = uploadCheckDao.getTableCol(serviceInterfaceBean.getTableName());
            
            if (tableColMapList.size() > 0) {
                
                List<String> sqlList = new ArrayList<>();
                
                for (Map record : recordList) {
                    StringBuilder tmpSt = new StringBuilder();
                    tmpSt.append("INTO ");
                    tmpSt.append(serviceInterfaceBean.getTableName());
                    tmpSt.append(" VALUES(");
                    for (Map tableColMap : tableColMapList) {
                        if ("NUMBER".equals(tableColMap.get("DATA_TYPE"))) {
                            tmpSt.append(record.get(tableColMap.get("COLUMN_NAME")));
                            tmpSt.append(",");
                        } else if ("DATE".equals(tableColMap.get("DATA_TYPE"))) {
                            tmpSt.append("to_date('");
                            tmpSt.append(record.get(tableColMap.get("COLUMN_NAME")));
                            tmpSt.append("', 'yyyy/mm/dd hh24:mi:ss'),");
                        } else {
                            tmpSt.append("'");
                            tmpSt.append(record.get(tableColMap.get("COLUMN_NAME")));
                            tmpSt.append("',");
                        }
                    }
                    tmpSt.append(")");
                    sqlList.add(tmpSt.toString().replace(",)", ")"));
                }
                
            int count = uploadFileDao.batchInsertTable(sqlList);
                // メッセージを表示させ、処理を終了
                serviceInterfaceBean.addMessage("INFO", "情報", "データ登録が完了しました！");
            } else {
                // メッセージを表示させ、処理を終了
                String msg = SysMsg.WRNDATA;
                serviceInterfaceBean.addMessage("WARN", "警告", msg);
                serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            }
            
        } else {
            // メッセージを表示させ、処理を終了
            String msg = SysMsg.WRNDATA;
            serviceInterfaceBean.addMessage("WARN", "警告", msg);
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
        }

    }
}
