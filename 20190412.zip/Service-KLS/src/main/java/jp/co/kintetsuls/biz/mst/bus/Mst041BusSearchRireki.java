/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.mst.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import java.util.Map;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.mst.dao.Mst041Dao;
import jp.co.kintetsuls.common.cnst.SysMsg;

/**
 * 営業所マスタ履歴情報取得処理
 * 
 * @author 雷新然 (MBP)
 * @version 2019/2/19 新規作成
 */
@Component("MST041_SEARCH_RIREKI")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Mst041BusSearchRireki extends BaseBus {

    /**
     * DAO定義
     */
    @Autowired(required=true)
    @Resource(shareable=true)
    protected Mst041Dao mst041Dao;

    /**
     * 営業所マスタ履歴情報取得処理
     * 
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception{
        
        // パラメータを解析する
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
	
	List<Map<String, String>> rirekiResultList = new ArrayList();

        // 営業所マスタ履歴情報を取得
        List<Map<String, String>> result = mst041Dao.findForSearchRireki(params);
       
        // データが取得できない場合
        if (result == null) {
            // メッセージを表示させ、処理を終了
            String msg = SysMsg.WRNDATA;
            serviceInterfaceBean.addMessage("WARN", "警告", msg);
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return;
        }
	
	Map<String, String> rirekiResult = null;
	for(Map<String, String> resultList : result) {
	  
	    rirekiResult = new HashMap();
	    
	    // 適用開始日フォーマット
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
	    // フォーマット
	    DecimalFormat decimalFormat = new DecimalFormat("#,###,###,###");
	    
            // 営業所コード
	    rirekiResult.put("rirekiEigyoshoCd", resultList.get("rirekiEigyoshoCd"));
            // 営業所名
	    rirekiResult.put("rirekiEigyoshoMei", resultList.get("rirekiEigyoshoMei"));
            // 適用開始日
	    if (resultList.get("rirekiSaishuShiyoHiduke") != null) {
		rirekiResult.put("rirekiTekiyoKaishibi", dateFormat.format(resultList.get("rirekiTekiyoKaishibi")));
	    }
	    // 住所
	    rirekiResult.put("rirekiJusho", resultList.get("rirekiJusho"));
            // 仕向地コード
	    rirekiResult.put("rirekiShimukeChiCd", resultList.get("rirekiShimukeChiCd"));
	    // 仕向地名
	    rirekiResult.put("rirekiShimukeChiMei", resultList.get("rirekiShimukeChiMei"));
            // 集荷営業所フラグ
	    rirekiResult.put("rirekiShukaEigyoshoFlg", resultList.get("rirekiShukaEigyoshoFlg"));
            // 配達営業所フラグ
	    rirekiResult.put("rirekiHaitatsuEigyoshoFlg", resultList.get("rirekiHaitatsuEigyoshoFlg"));
	    // チャーター起点フラグ
	    rirekiResult.put("rirekiCharterKitenFlg", resultList.get("rirekiCharterKitenFlg"));
            // 売上フラグ
	    rirekiResult.put("rirekiUriageFlg", resultList.get("rirekiUriageFlg"));
	    // 発券営業所フラグ
	    rirekiResult.put("rirekiHakkenEigyoshoFlg", resultList.get("rirekiHakkenEigyoshoFlg"));
	    // 車両管理フラグ
	    rirekiResult.put("rirekiSharyoKanriFlg", resultList.get("rirekiSharyoKanriFlg"));
            // 配達伝票出力営業所フラグ
	    rirekiResult.put("rirekiHaidenOutputEigyoshoFlg", resultList.get("rirekiHaidenOutputEigyoshoFlg"));
	    // 適用名
	    rirekiResult.put("rirekiTekiyoMei", resultList.get("rirekiTekiyoMei"));
	    // 終了
	    rirekiResult.put("rirekiShuryo", resultList.get("rirekiShuryo"));
            // 最終使用日付
	    if (resultList.get("rirekiSaishuShiyoHiduke") != null) {
	        rirekiResult.put("rirekiSaishuShiyoHiduke", dateFormat.format(
			resultList.get("rirekiSaishuShiyoHiduke")));
	    }
	    // バージョン情報
	    rirekiResult.put("rirekiDataVersion", decimalFormat.format(resultList.get("rirekiDataVersion")));
	    rirekiResultList.add(rirekiResult);
	}
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(rirekiResultList));
        
        // 正常終了の場合、メッセージを設定する
        serviceInterfaceBean.addMessage("INFO", "情報", "方法");
    }
}