/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.lgn.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import java.util.Map;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.base.dao.BaseDao;
import jp.co.kintetsuls.biz.table.dao.TrPasswordGoNyuryokuKaisuDao;
import jp.co.kintetsuls.biz.table.model.TrPasswordGoNyuryokuKaisu;
import jp.co.kintetsuls.common.SystemColumn;

/**
 * パスワード誤入力回数を初期化する
 * 
 * @author 黄華（MBP）
 * @version 2019/1/24 新規作成
 */
@Component("LGN011_INIT_PWDKAISU")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Lgn011BusInitPwdKaisu extends BaseBus {

    /**
     * Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected TrPasswordGoNyuryokuKaisuDao trPasswordGoNyuryokuKaisuDao;

    /**
     * パスワード誤入力回数を初期化する
     * 
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception 
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception{
        
        // パラメータ構築
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

        TrPasswordGoNyuryokuKaisu trPasswordGoNyuryokuKaisu = new TrPasswordGoNyuryokuKaisu();
        // ユーザーコード
        trPasswordGoNyuryokuKaisu.setUserCd(params.get("userCd").toString());
        // 回数 = 0
        trPasswordGoNyuryokuKaisu.setKaisu(0);
        // システムカラム
        trPasswordGoNyuryokuKaisu = SystemColumn.systemColumnSet(2, trPasswordGoNyuryokuKaisu, serviceInterfaceBean);

        List<Map<String, TrPasswordGoNyuryokuKaisu>> updateList = new ArrayList<>();
        Map<String, TrPasswordGoNyuryokuKaisu> updateMap = new HashMap<>();
        // 更新項目を設定する
        updateMap.put(BaseDao.UPDATE_BEAN_UPD, trPasswordGoNyuryokuKaisu);
        // 更新条件を設定する
        updateMap.put(BaseDao.UPDATE_BEAN_CRT, trPasswordGoNyuryokuKaisu);
        updateList.add(updateMap);

        trPasswordGoNyuryokuKaisuDao.updateById(updateList);
            
        serviceInterfaceBean.addMessage("INFO", "情報", "方法");
    }
}