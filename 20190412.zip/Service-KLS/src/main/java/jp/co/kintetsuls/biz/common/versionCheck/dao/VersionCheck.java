/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.biz.common.versionCheck.dao;

import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

/**
 *
 * @author liuchengjiang
 */
public interface VersionCheck {
    public List<String> getPrimerKey(@Param("searchParam")String searchParam);
    
    public int getKoushinVersion(@Param("param")Map<String, Object> param);
}
