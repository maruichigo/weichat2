package jp.co.kintetsuls.biz.common.masterinfo.bus;


import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;

import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.common.masterinfo.dao.ComMasterInfoDao;
import jp.co.kintetsuls.biz.common.masterinfo.model.ComMasterInfoDef;
import jp.co.kintetsuls.common.json.JSONUtil;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * マスタ内容処理クラス
 */
@Component("COMMON_GET_MSTER_INFO")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ComMasterInfoBus extends BaseBus {

    // Dao定義
    @Autowired(required=true)
    @Resource(shareable=true)
    protected ComMasterInfoDao comMasterInfoDao;
    private Map<String, Object> params = null;

    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception{
        //init
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

        Map sqlParams = (Map) params.get("params");
        if (sqlParams == null || sqlParams.size() == 0) {
            List<ComMasterInfoDef> comList = comMasterInfoDao.getStringList();
            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(comList));
        } else {
            List<ComMasterInfoDef> comList = comMasterInfoDao.getStringList(sqlParams);
            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(comList));
        }
		
    }
}