/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.biz.common.uploadFile.bus;

import jp.co.kintetsuls.biz.common.uploadCheck.dao.*;
import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.biz.base.dao.BaseDao;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Malei
 */
@Repository
@Component
public class UploadFileDao extends BaseDao<Object>{

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    /**
     * テーブル構造取得
     * 
     * @param searchParam
     * @return 
     */
    public int batchInsertTable(List<String> searchParam){
        return getSqlSession().insert("uploadCheck.batchInsertTable", searchParam);
    }

}
