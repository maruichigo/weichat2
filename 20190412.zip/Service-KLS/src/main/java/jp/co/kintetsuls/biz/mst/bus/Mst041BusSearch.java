package jp.co.kintetsuls.biz.mst.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import java.util.Map;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.mst.dao.Mst041Dao;
import jp.co.kintetsuls.common.cnst.SysMsg;

/**
 * 営業所マスタ情報取得処理
 *
 * @author 雷新然(MBP)
 * @version 2019/2/19 新規作成
 */
@Component("MST041_GET_EIGYOSHO_DETAIL")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Mst041BusSearch extends BaseBus {

    /**
     * DAO定義
     */
    @Autowired(required=true)
    @Resource(shareable=true)
    protected Mst041Dao mst041Dao;

    /**
     * 営業所マスタ情報取得処理
     * 
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception{
        
        // パラメータを解析する
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

	// 営業所マスタ情報取得
        List<Map<String, String>> recordList = mst041Dao.findForSearch(params);
        
        // データが取得できない場合
        if (recordList == null) {
            // メッセージを表示させ、処理を終了
            String msg = SysMsg.WRNDATA;
            serviceInterfaceBean.addMessage("WARN", "警告", msg);
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return;
        }
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(recordList));
        
        // 正常終了の場合、メッセージを設定する
        serviceInterfaceBean.addMessage("INFO", "情報", "方法");
    }
}