package jp.co.kintetsuls.biz.common.authority.dao;

import java.util.List;
import jp.co.kintetsuls.biz.common.authority.model.AuthorityComponent;
import jp.co.kintetsuls.biz.base.dao.BaseDao;
import org.springframework.stereotype.Component;

/** 利用可能コンポーネント処理クラス
 */
@Component
public class AuthorityComponentDao extends BaseDao<AuthorityComponent> {

    public List<AuthorityComponent> getAuthorityComponent(String userCd){
        return getSqlSession().selectList("authorityComponent.getAuthorityComponent", userCd);
    }

}
