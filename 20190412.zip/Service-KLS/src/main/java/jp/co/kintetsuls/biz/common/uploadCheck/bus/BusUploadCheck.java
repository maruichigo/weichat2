/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.biz.common.uploadCheck.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.common.uploadCheck.dao.UploadCheckDao;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

/**
 *
 * @author Malei
 */
@Component("UPLOAD_CHECK")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class BusUploadCheck extends BaseBus{

    @Autowired(required=true)
    @Resource(shareable=true)
    protected UploadCheckDao uploadCheckDao;

    private Map<String, Object> params = null;

    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
        String tblName = "";
        List<Map> resMap = new ArrayList<>();
        if (params.get("tblName") != null) {
            tblName = params.get("tblName").toString();
            //対象テーブルの構造取得
            resMap = uploadCheckDao.getTableCol(tblName);
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resMap));
    }
}
