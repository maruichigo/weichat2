package jp.co.kintetsuls.biz.common.authority.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import jp.co.kintetsuls.biz.common.authority.dao.AuthorityOfficeDao;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;

import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.common.json.JSONUtil;
import org.springframework.beans.factory.annotation.Autowired;

import jp.co.kintetsuls.common.cnst.SysMsg;

/**
 * アクセス可能組織取得処理クラス
 * 
 */
@Component("COMMON_GET_ACCESSIBLE_OFFICE")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class AuthorityOfficeBus extends BaseBus {

    // Dao定義
    @Autowired(required=true)
    @Resource(shareable=true)
    protected AuthorityOfficeDao authOfficeDao;
    private Map<String, Object> params = null;

    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception{
        //init
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

        if(!params.containsKey("userCd")){
            String msg = SysMsg.WRNDATA;
            serviceInterfaceBean.addMessage("WARN", "警告", msg);
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return;
        }

        // 営業所リストの取得
        //List<Office> list = officeDao.getAccessibleOffice(serviceInterfaceBean.getUserCd());
        List<Map<String, String>> list = authOfficeDao.getAccessibleOffice(serviceInterfaceBean.getUserCd());

        // デフォルト営業所の取得
        String defaultEigyosho = authOfficeDao.getDefaultEigyosho(serviceInterfaceBean.getUserCd());
        Map<String, String> defoffice = new HashMap<String, String>(){{ put("VALUE", defaultEigyosho); }};

        // listの0番目に追加(呼び出し元で分離)
        list.add(0, defoffice);
        // 格納返却
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(list));
    }
}