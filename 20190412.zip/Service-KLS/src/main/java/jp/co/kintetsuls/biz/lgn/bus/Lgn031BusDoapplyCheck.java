/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.lgn.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Date;
import java.util.HashMap;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import java.util.Map;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.base.dao.BaseDao;
import jp.co.kintetsuls.biz.lgn.dao.Lgn031Dao;
import jp.co.kintetsuls.biz.table.dao.TrMailAddressNgKaisuDao;
import jp.co.kintetsuls.biz.table.model.TrMailAddressNgKaisu;
import jp.co.kintetsuls.common.SystemColumn;
import jp.co.kintetsuls.common.cnst.MessageCnst;
import jp.co.kintetsuls.common.cnst.StndConsIF;
import jp.co.kintetsuls.utils.DateUtils;

/**
 * 存在チェック、相関チェック
 *
 * @author 黄義輝 (MBP)
 * @version 2019/04/01 新規作成
 */
@Component("LGN031_DOAPPLY_CHECK")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Lgn031BusDoapplyCheck extends BaseBus {

    /**
     * Lgn031Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected Lgn031Dao lgn031Dao;
    
    /**
     * メールアドレス不一致回数Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected TrMailAddressNgKaisuDao trMailAddressNgKaisuDao;

    /**
     * メールアドレス不一致回数定義
     */
    protected TrMailAddressNgKaisu trMailAddressNgKaisu;

    /**
     * 文字列：ユーザーマスタ
     */
    private static final String MS_USER = "ユーザーマスタ";

    /**
     * 存在チェック、相関チェック
     * 
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {

        // パラメータを解析する
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> param = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

        int count = 0;

        Map<String, Object> optionMap = null;

        // 通知方法
        String hyoDtlTsuchiHoho = objectToString(param.get("hyoDtlTsuchiHoho"));

        // ユーザーコードの存在チェック
        if (0 == lgn031Dao.countUserCdForDoapply(param)) {
            count++;
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(count));
            serviceInterfaceBean.addMessage("ERROR", MessageCnst.COME0006,
                    objectToString(param.get("hyoDtlUserCd")));
            serviceInterfaceBean.setTableName(MS_USER);
            return;
        }

        // 通知方法 = メールの場合
        if (hyoDtlTsuchiHoho != null && ("1").equals(hyoDtlTsuchiHoho)) {

            // メールアドレス不一致最大回数
            int mailAddressFuitchiKaisu = 0;
            if (param.get("mailAddressFuitchiKaisu") != null 
                    && !("").equals(param.get("mailAddressFuitchiKaisu"))) {
                mailAddressFuitchiKaisu = Integer.parseInt(objectToString(param.get("mailAddressFuitchiKaisu")));
            }

            // メール申請ロック期間
            Date mailShinseiLockKikan = null;
            if (param.get("mailShinseiLockKikan") != null && !("").equals(param.get("mailShinseiLockKikan"))) {
                mailShinseiLockKikan = DateUtils.addDays(
                        DateUtils.getSysDate(), Integer.valueOf(objectToString(param.get("mailShinseiLockKikan"))));
            } else {
                mailShinseiLockKikan = DateUtils.getSysDate();
            }

            trMailAddressNgKaisu = new TrMailAddressNgKaisu();

            // ワーク.ユーザーコード設定
            trMailAddressNgKaisu.setUserCd(objectToString(param.get("hyoDtlUserCd")));

            TrMailAddressNgKaisu trMailAddressNgKaisuResult = null;

            // ユーザーコードとメールアドレスの組み合わせが存在するかチェックを行う。
            if (0 == lgn031Dao.countUserCdMailAddressForDoapply(param)) {

                // ユーザーコードより，ユーザインフォ
                trMailAddressNgKaisuResult = trMailAddressNgKaisuDao.findById(trMailAddressNgKaisu);

                // 不一致回数登録処理
                if (trMailAddressNgKaisuResult == null) {

                    // システムカラムの設定
                    trMailAddressNgKaisu = SystemColumn.systemColumnSet(
                            StndConsIF.SYSCOL_INSERT, trMailAddressNgKaisu, serviceInterfaceBean);
                    // 不一致回数
                    trMailAddressNgKaisu.setFuitchiKaisu(1);


                    // メール申請ロックフラグ設定 メール申請ロック期間設定
                    if (2 > mailAddressFuitchiKaisu) {
                        trMailAddressNgKaisu.setMailShinseiLockFlg("1");
                        trMailAddressNgKaisu.setMailShinseiLockKikan(mailShinseiLockKikan);

                    } else{
                        trMailAddressNgKaisu.setMailShinseiLockFlg("0");
                        trMailAddressNgKaisu.setMailShinseiLockKikan(null);
                    }

                    // 削除フラグ
                    trMailAddressNgKaisu.setSakujoFlg("0");

                    // メールアドレス不一致回数登録処理
                    trMailAddressNgKaisuDao.insert(trMailAddressNgKaisu);

                // 不一致回数更新
                } else {

                    optionMap = new HashMap();

                    // システムカラムの設定
                    trMailAddressNgKaisu = SystemColumn.systemColumnSet(
                            StndConsIF.SYSCOL_UPDATE, trMailAddressNgKaisu, serviceInterfaceBean);

                    // 不一致回数
                    int fuitchiKaisu = 0;
                    if (trMailAddressNgKaisuResult.getFuitchiKaisu() != null) {
                        fuitchiKaisu = trMailAddressNgKaisuResult.getFuitchiKaisu() + 1;
                    }
                    trMailAddressNgKaisu.setFuitchiKaisu(fuitchiKaisu);

                    // メール申請ロックフラグ設定 メール申請ロック期間設定
                    if (fuitchiKaisu > mailAddressFuitchiKaisu) {
                        trMailAddressNgKaisu.setMailShinseiLockFlg("1");
                        trMailAddressNgKaisu.setMailShinseiLockKikan(mailShinseiLockKikan);

                    } else{
                        trMailAddressNgKaisu.setMailShinseiLockFlg("0");
                        trMailAddressNgKaisu.setMailShinseiLockKikan(null);
                        String[] nullUpdateCol = new String[1];
                        nullUpdateCol[0] = "MAIL_SHINSEI_LOCK_KIKAN";
                        optionMap.put(BaseDao.NULL_UPDATE_COL, nullUpdateCol);
                    }

                    // 削除フラグ
                    trMailAddressNgKaisu.setSakujoFlg("0");

                    // メールアドレス不一致回数の登録、もしくは更新を行う。 
                    trMailAddressNgKaisuDao.updateById(trMailAddressNgKaisu, trMailAddressNgKaisu, optionMap);

                }

                count++;
                serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                serviceInterfaceBean.setJson(JSONUtil.makeJSONString(count));

                if (("1").equals(trMailAddressNgKaisu.getMailShinseiLockFlg())) {
                    serviceInterfaceBean.addMessage("ERROR", MessageCnst.LGNE0006, null);

                }
                if (("0").equals(trMailAddressNgKaisu.getMailShinseiLockFlg())) {
                    serviceInterfaceBean.addMessage("ERROR", MessageCnst.LGNE0007, null);
                }
                return;
            }

            // メール申請がロックされているかチェックを行う。
            trMailAddressNgKaisuResult = trMailAddressNgKaisuDao.findById(trMailAddressNgKaisu);

            // メール申請ロックフラグ
            String mailShinseiLockFlg = null;

            if (trMailAddressNgKaisuResult != null) {

                // メール申請ロックフラグ
                mailShinseiLockFlg = trMailAddressNgKaisuResult.getMailShinseiLockFlg();
                // メール申請ロック期間 
                mailShinseiLockKikan = trMailAddressNgKaisuResult.getMailShinseiLockKikan();

            }

            // メール申請ロックフラグ = 1
            if (mailShinseiLockFlg != null
                    && ("1").equals(mailShinseiLockFlg)) {
                // メール申請ロック期間 >= SYSDATE
                if (mailShinseiLockKikan != null
                    && mailShinseiLockKikan.compareTo(DateUtils.getSysDate()) >= 0) {
                    count++;
                    serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                    serviceInterfaceBean.setJson(JSONUtil.makeJSONString(count));
                    serviceInterfaceBean.addMessage("ERROR", MessageCnst.LGNE0005, null);
                    return;

                }

                // メール申請ロック期間 < SYSDATE
                if (mailShinseiLockKikan != null
                    && mailShinseiLockKikan.compareTo(DateUtils.getSysDate()) < 0) {

                    optionMap = new HashMap();

                    trMailAddressNgKaisu= new TrMailAddressNgKaisu();

                    // ワーク.ユーザーコード設定
                    trMailAddressNgKaisu.setUserCd(objectToString(param.get("hyoDtlUserCd")));

                    // システムカラムの設定
                    trMailAddressNgKaisu = SystemColumn.systemColumnSet(
                            StndConsIF.SYSCOL_UPDATE, trMailAddressNgKaisu, serviceInterfaceBean);

                    // 不一致回数
                    trMailAddressNgKaisu.setFuitchiKaisu(0);
                    // メール申請ロックフラグ
                    trMailAddressNgKaisu.setMailShinseiLockFlg("0");
                    // メール申請ロック期間
                    trMailAddressNgKaisu.setMailShinseiLockKikan(null);
                    String[] nullUpdateCol = new String[1];
                    nullUpdateCol[0] = "MAIL_SHINSEI_LOCK_KIKAN";
                    optionMap.put(BaseDao.NULL_UPDATE_COL, nullUpdateCol);

                    // 削除フラグ
                    trMailAddressNgKaisu.setSakujoFlg("0");
                    // メールアドレス不一致回数の初期化を行う
                    trMailAddressNgKaisuDao.updateById(trMailAddressNgKaisu, trMailAddressNgKaisu, optionMap);
                }
            }
        }
    }
}