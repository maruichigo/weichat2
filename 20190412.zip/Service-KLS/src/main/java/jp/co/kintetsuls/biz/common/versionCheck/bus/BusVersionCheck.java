/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.biz.common.versionCheck.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.common.versionCheck.dao.VersionCheckDao;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

/**
 *
 * @author liuchengjiang
 */
@Component("VERSION_CHECK")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class BusVersionCheck extends BaseBus{
    @Autowired(required=true)
    @Resource(shareable=true)
    protected VersionCheckDao versionCheckDao;

    private Map<String, Object> params = null;
    
    public boolean checkVersion(Map<String, Object> paraMap){
        String tblName = "";
        List<String> keyList = new ArrayList<>();
        if (paraMap.get("tblName") != null) {
            tblName = paraMap.get("tblName").toString();
            //対象テブルの主キー取得
            keyList = versionCheckDao.getPrimerKey(tblName);
        }
        //渡すの主キーチェック
        for (String key : keyList) {
            if (!paraMap.containsKey(key)) {
                return false;
            }
        }
        Map<String, Object> searchParam = new HashMap<>();
        searchParam.put("primerKey", keyList);
        searchParam.put("tblName", paraMap.get("tblName"));
        searchParam.put("koushinCounter", paraMap.get("koushinCounter"));
        searchParam.put("koushinUserCd", paraMap.get("koushinUserCd"));
        for (String key : keyList) {
            searchParam.put(key, paraMap.get(key));
        }
        //paraMap.put("primerKey", keyList);
        int kensu = versionCheckDao.getKoushinVersion(searchParam);
        if (kensu > 0) {
            return true;
        }
        return false;
    }

    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
        boolean versioncheck = checkVersion(params);
        Map<String, Object> checkFlg = new HashMap<>();
        checkFlg.put("checkFlg", versioncheck);
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(checkFlg));
    }
}
