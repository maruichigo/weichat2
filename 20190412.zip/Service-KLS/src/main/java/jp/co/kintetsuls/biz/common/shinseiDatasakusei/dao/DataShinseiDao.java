/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.biz.common.shinseiDatasakusei.dao;

import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.biz.base.dao.BaseDao;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

/**
 *
 * @author liuchengjiang
 */
@Repository
@Component
public class DataShinseiDao extends BaseDao<Object>{
    @Autowired
    private SqlSessionFactory sqlSessionFactory;
    /**
     * 申請ID取得
     * @param sqlId 
     * @return 件数
     */
    public Integer getSequence(String sqlId) {
        return getSqlSession().selectOne("sequence." + sqlId);
    }
    
    /**
     * 存在チェック
     * @param paramsMap 存在パラメタ
     * @return チェック結果
     */
    public List<Map<String, Object>> sonzaiCheck(Map<String, String> paramsMap){
        return getSqlSession().selectList("sonzaiCheck", paramsMap);
    }
}
