package jp.co.kintetsuls.biz.mst.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import java.util.Map;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.base.dao.BaseDao;
import jp.co.kintetsuls.biz.common.versionCheck.bus.BusVersionCheck;
import jp.co.kintetsuls.biz.mst.dao.Mst042Dao;
import jp.co.kintetsuls.biz.table.dao.MsEigyoshoDao;
import jp.co.kintetsuls.biz.table.dao.MsEigyoshoGroupDao;
import jp.co.kintetsuls.biz.table.dao.MsEigyoshoOroshiTankaDao;
import jp.co.kintetsuls.biz.table.dao.MsEigyoshoOroshiTankaRirekiDao;
import jp.co.kintetsuls.biz.table.model.MsEigyosho;
import jp.co.kintetsuls.biz.table.model.MsEigyoshoGroup;
import jp.co.kintetsuls.biz.table.model.MsEigyoshoOroshiTanka;
import jp.co.kintetsuls.biz.table.model.MsEigyoshoOroshiTankaRireki;
import jp.co.kintetsuls.common.SystemColumn;
import jp.co.kintetsuls.common.cnst.MessageCnst;
import jp.co.kintetsuls.common.cnst.StndConsIF;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.kintetsuls.utils.StrUtils;

/**
 * 営業所マスタ詳細の登録/更新処理
 *
 * @author 雷珍 (MBP)
 * @version 2019/3/6 新規作成
 */
@Component("MST042_INSERT_UPDATE")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Mst042BusInsertUpdate extends BaseBus {

    /**
     * バージョンチェック(排他)
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected BusVersionCheck busVersionCheck;
    
    /**
     * 営業所マスタ詳細Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected Mst042Dao mst042Dao;

    /**
     * 営業所マスタDao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsEigyoshoDao msEigyoshoDao;

    /**
     * 営業所卸単価マスタDao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsEigyoshoOroshiTankaDao msEigyoshoOroshiTankaDao;
    
    /**
     * 営業所卸単価マスタ履歴Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsEigyoshoOroshiTankaRirekiDao msEigyoshoOroshiTankaRirekiDao;

    /**
     * 営業所グループマスタDao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsEigyoshoGroupDao msEigyoshoGroupDao;

    /**
     * パラメータ
     */
    private Map<String, Object> params = null;

    /**
     * 営業所コード
     */
    private String eigyoshoCd;
    
    /**
     * 適用開始日
     */
    private Date tekiyoKaishibi;
    
     /**
     * 適用開始日(排他メッセージ用)
     */
    private String msgTekiyoKaishibi;
    
    /**
     * エラーフラグ
     */
    private boolean errorFlg;
    
    /**
     * 営業所マスタ詳細の登録/更新処理
     *
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        // パラメータを取得する
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

        // 営業所マスタ_登録/更新処理
        if (CheckUtils.isEqual("0", StrUtils.defaultString(params.get("editKbn")))) {
            // 登録対象の場合
            msEigyoshoInsert(serviceInterfaceBean);
        } else if (CheckUtils.isEqual("1", StrUtils.defaultString(params.get("editKbn")))) {
            // 更新対象の場合
            msEigyoshoUpdate(serviceInterfaceBean);
        }
         
        if (!errorFlg) {
            // 営業所卸単価マスタ_登録/更新/削除処理
            // 卸単価情報_削除一覧リスト
            List<Map<String, Object>> eigyoshoOroshiTankaDelList = 
                    (List<Map<String, Object>>) params.get("eigyoshoOroshiTankaDelList");
            if (eigyoshoOroshiTankaDelList.size() > 0) {
                // 営業所卸単価マスタ削除
                msEigyoshoOroshiTankaDelete(serviceInterfaceBean,
                        eigyoshoOroshiTankaDelList);
            }

            // 卸単価情報_登録一覧リスト
            List<Map<String, Object>> eigyoshoOroshiTankaAddList = 
                    (List<Map<String, Object>>) params.get("eigyoshoOroshiTankaAddList");
            if (eigyoshoOroshiTankaAddList.size() > 0) {
                // 営業所卸単価マスタ登録
                msEigyoshoOroshiTankaInsert(serviceInterfaceBean, eigyoshoOroshiTankaAddList);
            }

            // 卸単価情報_更新一覧リスト
            List<Map<String, Object>> eigyoshoOroshiTankaUpdList = 
                    (List<Map<String, Object>>) params.get("eigyoshoOroshiTankaUpdList");
            if (eigyoshoOroshiTankaUpdList.size() > 0) {
                // 営業所卸単価マスタ更新
                msEigyoshoOroshiTankaUpdate(serviceInterfaceBean,
                        eigyoshoOroshiTankaUpdList);
            }

            // 営業所グループマスタ_登録/更新/削除処理
            // 営業所グループ情報_削除一覧リスト
            List<Map<String, Object>> eigyoshoGroupDelList = 
                    (List<Map<String, Object>>) params.get("eigyoshoGroupDelList");
            if (eigyoshoGroupDelList.size() > 0) {
                // 営業所グループマスタ削除
                msEigyoshoGroupDelete(serviceInterfaceBean,
                        eigyoshoGroupDelList);
            }

            // 営業所グループ情報_登録一覧リスト
            List<Map<String, Object>> eigyoshoGroupAddList = 
                    (List<Map<String, Object>>) params.get("eigyoshoGroupAddList");
            if (eigyoshoGroupAddList.size() > 0) {
                // 営業所グループマスタ登録
                msEigyoshoGroupInsert(serviceInterfaceBean, eigyoshoGroupAddList);
            }

            // 営業所グループ情報_更新一覧リスト
            List<Map<String, Object>> eigyoshoGroupUpdList = 
                    (List<Map<String, Object>>) params.get("eigyoshoGroupUpdList");
            if (eigyoshoGroupUpdList.size() > 0) {
                // 営業所グループマスタ更新
                msEigyoshoGroupUpdate(serviceInterfaceBean,
                        eigyoshoGroupUpdList);
            }
        }
    }

    /**
     * 営業所マスタ_登録処理
     * 
     * @param serviceInterfaceBean JSFからの通信情報
     */
    private void msEigyoshoInsert(ServiceInterfaceBean serviceInterfaceBean) {
        
        // 画面入力内容を取得する
        List<Map<String, Object>> eigyoshoInfo = (List<Map<String, Object>>) params.get("eigyoshoAddList");

        // テーブル「営業所マスタ」登録用
        List<MsEigyosho> msEigyoshoList = new ArrayList<>();
        
        for (Map<String, Object> eigyosyo : eigyoshoInfo) {
            // 住所
            StringBuffer jusho = new StringBuffer();
        
            // 営業所コード
            eigyoshoCd = StrUtils.defaultString(eigyosyo.get("conEigyoshoCd"));
            // 適用開始日
            long time_long = Long.valueOf(StrUtils.defaultString(eigyosyo.get("conTekiyoKaishibi")));
            tekiyoKaishibi = new Date(time_long);
            SimpleDateFormat sdf = new SimpleDateFormat(StndConsIF.DF_YYYY_MM_DD);
            msgTekiyoKaishibi = sdf.format(tekiyoKaishibi);
        
            // 営業所マスタのパラメータ設定
            MsEigyosho msEigyosho = new MsEigyosho();
            msEigyosho = SystemColumn.systemColumnSet(StndConsIF.SYSCOL_INSERT, msEigyosho, serviceInterfaceBean);
            
            // 住所編集: 画面.住所１～４を結合
            if (!CheckUtils.isEmpty(StrUtils.defaultString(eigyosyo.get("khnDtlJusho1")))) {
                // 住所１
                jusho.append(eigyosyo.get("khnDtlJusho1"));
            }
            if (!CheckUtils.isEmpty(StrUtils.defaultString(eigyosyo.get("khnDtlJusho2")))) {
                // 住所２
                jusho.append(eigyosyo.get("khnDtlJusho2"));
            }
            if (!CheckUtils.isEmpty(StrUtils.defaultString(eigyosyo.get("khnDtlJusho3")))) {
                // 住所３
                jusho.append(eigyosyo.get("khnDtlJusho3"));
            }
            if (!CheckUtils.isEmpty(StrUtils.defaultString(eigyosyo.get("khnDtlJusho4")))) {
                // 住所４
                jusho.append(eigyosyo.get("khnDtlJusho4"));
            }
            
            // 営業所コード
            msEigyosho.setEigyoshoCd(eigyoshoCd);
            // 適用開始日
            msEigyosho.setTekiyoKaishibi(tekiyoKaishibi);
            // 適用名
            msEigyosho.setTekiyoMei(StrUtils.defaultString(eigyosyo.get("conTekiyoMei")));
            // 営業所名
            msEigyosho.setEigyoshoMei(StrUtils.defaultString(eigyosyo.get("knrDtlEigyoshoMei")));
            // 営業所カナ名
            msEigyosho.setEigyoshoKanaMei(StrUtils.defaultString(eigyosyo.get("knrDtlEigyoshoKanaMei")));
            // 営業所略称
            msEigyosho.setEigyoshoRyakusho(StrUtils.defaultString(eigyosyo.get("knrDtlEigyoshoRyakusho")));
            // 英語表記
            msEigyosho.setEigoHyoki(StrUtils.defaultString(eigyosyo.get("knrDtlEigoHyoki")));
            // 集荷営業所フラグ
            msEigyosho.setShukaEigyoshoFlg(StrUtils.defaultString(eigyosyo.get("knrDtlShiyoShukaKbn")));
            // 配達営業所フラグ
            msEigyosho.setHaitatsuEigyoshoFlg(StrUtils.defaultString(eigyosyo.get("knrDtlShiyoHaitatsuKbn")));
            // 起点フラグ
            msEigyosho.setKitenFlg(StrUtils.defaultString(eigyosyo.get("knrDtlShiyoKitenKbn")));
            // 売上フラグ
            msEigyosho.setUriageFlg(StrUtils.defaultString(eigyosyo.get("knrDtlShiyoUriageKbn")));
            // 発券営業所フラグ
            msEigyosho.setHakkenEigyoshoFlg(StrUtils.defaultString(eigyosyo.get("knrDtlShiyoHakkenKbn")));
            // 車両管理フラグ
            msEigyosho.setSharyoKanriFlg(StrUtils.defaultString(eigyosyo.get("knrDtlShiyoSharyoKbn")));
            // 配達伝票出力営業所フラグ
            msEigyosho.setHaidenOutputEigyoshoFlg(StrUtils.defaultString(eigyosyo.get("knrDtlShiyoHaidenKbn")));
            // 送り状発行営業所コード
            msEigyosho.setOkurijoHakkoEigyoshoCd(StrUtils.defaultString(eigyosyo.get("knrDtlOkurijoHakkoEigyoshoCd")));
            // 経理変換先コード
            msEigyosho.setKeiriHenkansakiCd(StrUtils.defaultString(eigyosyo.get("knrDtlKeirisakiHenkanCd")));
            // 営業所種別コード
            msEigyosho.setEigyoshoShubetsuCd(StrUtils.defaultString(eigyosyo.get("knrDtlHEigyoshoShubetsuCd")));
            // 承認営業所区分コード
            msEigyosho.setShoninEigyoshoKbnCd(StrUtils.defaultString(eigyosyo.get("knrDtlHShoninEigyoshoKbnCd")));
            // 郵便番号
            msEigyosho.setYubinBango(StrUtils.defaultString(eigyosyo.get("khnDtlYubinBango")));
            // JISコード
            msEigyosho.setJisCd(StrUtils.defaultString(eigyosyo.get("khnDtlJisCd")));
            // 住所１
            msEigyosho.setJusho1(StrUtils.defaultString(eigyosyo.get("khnDtlJusho1")));
            // 住所２
            msEigyosho.setJusho2(StrUtils.defaultString(eigyosyo.get("khnDtlJusho2")));
            // 住所３
            msEigyosho.setJusho3(StrUtils.defaultString(eigyosyo.get("khnDtlJusho3")));
            // 住所４
            msEigyosho.setJusho4(StrUtils.defaultString(eigyosyo.get("khnDtlJusho4")));
            // 住所
            msEigyosho.setJusho(StrUtils.defaultString(jusho));
            // 空港コード
            msEigyosho.setKukoCd(StrUtils.defaultString(eigyosyo.get("khnDtlKukoCd")));
            // 仕向地コード
            msEigyosho.setShimukeChiCd(StrUtils.defaultString(eigyosyo.get("khnDtlShimukeChi")));
            // 集配地区コード
            msEigyosho.setShuhaiChiku(StrUtils.defaultString(eigyosyo.get("khnDtlShuhaiChikuCd")));
            // 電話番号１
            msEigyosho.setTelBango1(StrUtils.defaultString(eigyosyo.get("khnDtlTelBango1")));
            // 電話番号２
            msEigyosho.setTelBango2(StrUtils.defaultString(eigyosyo.get("khnDtlTelBango2")));
            // 社内電話番号
            msEigyosho.setShanaiTelBango(StrUtils.defaultString(eigyosyo.get("khnDtlShanaiTelBango")));
            // FAX番号
            msEigyosho.setFaxBango(StrUtils.defaultString(eigyosyo.get("khnDtlFaxBango")));
            // 銀行口座コード
            msEigyosho.setKaniGinkoCd(StrUtils.defaultString(eigyosyo.get("kzaDtlGinkoKozaCd")));
            // 仕立営業所コード
            msEigyosho.setShitateEigyoshoCd(StrUtils.defaultString(eigyosyo.get("orsDtlShitateEigyoshoCd")));
            // 他社中継卸値率
            if (eigyosyo.get("orsDtlTashaChukeiOroshineritsu") != null 
                    && eigyosyo.get("orsDtlTashaChukeiOroshineritsu") != "") {
                msEigyosho.setTashaChukeiOroshineritsu(Double.valueOf(
                        StrUtils.defaultString(eigyosyo.get("orsDtlTashaChukeiOroshineritsu"))));
            }
            // 一見顧客登録フラグ
            msEigyosho.setIchigenKokyakuTorokuFlg(StrUtils.defaultString(eigyosyo.get("dtlHIchigenKokyakuTorokuFlg")));
            // 社内便登録フラグ
            msEigyosho.setShanaiBinTorokuFlg(StrUtils.defaultString(eigyosyo.get("dtlHShanaiBinTorokuFlg")));
            // 着払代引登録フラグ
            msEigyosho.setChakubaraiDaibikiTorokuFlg(StrUtils.defaultString(
                    eigyosyo.get("dtlHChakubaraiDaibikiTorokuFlg")));
            // 削除フラグ
            msEigyosho.setSakujoFlg("0");
            // 営業所データバージョン
            msEigyosho.setEigyoshoDataVersion(1);
            // 営業所マスタ新規データ設定
            msEigyoshoList.add(msEigyosho);

        }
        
        // 営業所マスタ新規
        msEigyoshoDao.insert(msEigyoshoList);
        msEigyoshoDao.createRirekiById(msEigyoshoList);
    }
    
    /**
     * 営業所マスタ_更新処理
     * 
     * @param serviceInterfaceBean JSFからの通信情報
     */
    private void msEigyoshoUpdate(ServiceInterfaceBean serviceInterfaceBean) {
        
        // 画面入力内容を取得する
        List<Map<String, Object>> eigyoshoInfo = (List<Map<String, Object>>) params.get("eigyoshoUpdList");

        // テーブル「営業所マスタ」更新用
        List<Map<String, MsEigyosho>> msEigyoshoList = new ArrayList<>();
        
        // 更新一覧履歴リストを初期化する
        List<MsEigyosho> koshinIchiranRirekiList = new ArrayList();    
        
        for (Map<String, Object> eigyosyo : eigyoshoInfo) {
            // 住所
            StringBuffer jusho = new StringBuffer();
        
            // 営業所コード
            eigyoshoCd = StrUtils.defaultString(eigyosyo.get("conEigyoshoCd"));
            // 適用開始日
            long time_long = Long.valueOf(StrUtils.defaultString(eigyosyo.get("conTekiyoKaishibi")));
            tekiyoKaishibi = new Date(time_long);
            SimpleDateFormat sdf = new SimpleDateFormat(StndConsIF.DF_YYYY_MM_DD);
            msgTekiyoKaishibi = sdf.format(tekiyoKaishibi);
            
            // 営業所マスタのパラメータ設定
            Map msEigyoshoMap = new HashMap<>();
             
            // 更新項目
            MsEigyosho msEigyosho = new MsEigyosho();
            
            // バージョンチェック(排他)
            Map param = new HashMap();
            // 営業所コード
            param.put("EIGYOSHO_CD", eigyoshoCd);
            // 適用開始日
            param.put("TEKIYO_KAISHIBI", tekiyoKaishibi);
            // 更新ユーザーID
            param.put("koushinUserCd", StrUtils.defaultString(eigyosyo.get("kshnDtlUser")));
            // 更新カウンタ
            param.put("koushinCounter", StrUtils.defaultString(eigyosyo.get("dtlKoshinCounter")));
            // テーブル名：営業所マスタ
            param.put("tblName", "MS_EIGYOSHO"); 
            // バージョンチェック(排他)
            if (!busVersionCheck.checkVersion(param)) {
                serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                serviceInterfaceBean.setJson(JSONUtil.makeJSONString(1));
                // エラーメッセージを表示させ、処理を終了
                serviceInterfaceBean.addMessage("WARN", MessageCnst.COME0014,
                        eigyoshoCd.concat(msgTekiyoKaishibi));
                serviceInterfaceBean.setTableName("営業所マスタ");
                errorFlg = true;
                return;
            }
            
            // 住所編集: 画面.住所１～４を結合
            if (!CheckUtils.isEmpty(StrUtils.defaultString(eigyosyo.get("khnDtlJusho1")))) {
                // 住所１
                jusho.append(eigyosyo.get("khnDtlJusho1"));
            }
            if (!CheckUtils.isEmpty(StrUtils.defaultString(eigyosyo.get("khnDtlJusho2")))) {
                // 住所２
                jusho.append(eigyosyo.get("khnDtlJusho2"));
            }
            if (!CheckUtils.isEmpty(StrUtils.defaultString(eigyosyo.get("khnDtlJusho3")))) {
                // 住所３
                jusho.append(eigyosyo.get("khnDtlJusho3"));
            }
            if (!CheckUtils.isEmpty(StrUtils.defaultString(eigyosyo.get("khnDtlJusho4")))) {
                // 住所４
                jusho.append(eigyosyo.get("khnDtlJusho4"));
            }
            
            msEigyosho = SystemColumn.systemColumnSet(StndConsIF.SYSCOL_UPDATE, msEigyosho, serviceInterfaceBean);
            // 適用名
            msEigyosho.setTekiyoMei(StrUtils.defaultString(eigyosyo.get("conTekiyoMei")));
            // 営業所名
            msEigyosho.setEigyoshoMei(StrUtils.defaultString(eigyosyo.get("knrDtlEigyoshoMei")));
            // 営業所カナ名
            msEigyosho.setEigyoshoKanaMei(StrUtils.defaultString(eigyosyo.get("knrDtlEigyoshoKanaMei")));
            // 営業所略称
            msEigyosho.setEigyoshoRyakusho(StrUtils.defaultString(eigyosyo.get("knrDtlEigyoshoRyakusho")));
            // 英語表記
            msEigyosho.setEigoHyoki(StrUtils.defaultString(eigyosyo.get("knrDtlEigoHyoki")));
            // 集荷営業所フラグ
            msEigyosho.setShukaEigyoshoFlg(StrUtils.defaultString(eigyosyo.get("knrDtlShiyoShukaKbn")));
            // 配達営業所フラグ
            msEigyosho.setHaitatsuEigyoshoFlg(StrUtils.defaultString(eigyosyo.get("knrDtlShiyoHaitatsuKbn")));
            // 起点フラグ
            msEigyosho.setKitenFlg(StrUtils.defaultString(eigyosyo.get("knrDtlShiyoKitenKbn")));
            // 売上フラグ
            msEigyosho.setUriageFlg(StrUtils.defaultString(eigyosyo.get("knrDtlShiyoUriageKbn")));
            // 発券営業所フラグ
            msEigyosho.setHakkenEigyoshoFlg(StrUtils.defaultString(eigyosyo.get("knrDtlShiyoHakkenKbn")));
            // 車両管理フラグ
            msEigyosho.setSharyoKanriFlg(StrUtils.defaultString(eigyosyo.get("knrDtlShiyoSharyoKbn")));
            // 配達伝票出力営業所フラグ
            msEigyosho.setHaidenOutputEigyoshoFlg(StrUtils.defaultString(eigyosyo.get("knrDtlShiyoHaidenKbn")));
            // 送り状発行営業所コード
            msEigyosho.setOkurijoHakkoEigyoshoCd(StrUtils.defaultString(eigyosyo.get("knrDtlOkurijoHakkoEigyoshoCd")));
            // 経理変換先コード
            msEigyosho.setKeiriHenkansakiCd(StrUtils.defaultString(eigyosyo.get("knrDtlKeirisakiHenkanCd")));
            // 営業所種別コード
            msEigyosho.setEigyoshoShubetsuCd(StrUtils.defaultString(eigyosyo.get("knrDtlHEigyoshoShubetsuCd")));
            // 承認営業所区分コード
            msEigyosho.setShoninEigyoshoKbnCd(StrUtils.defaultString(eigyosyo.get("knrDtlHShoninEigyoshoKbnCd")));
            // 郵便番号
            msEigyosho.setYubinBango(StrUtils.defaultString(eigyosyo.get("khnDtlYubinBango")));
            // JISコード
            msEigyosho.setJisCd(StrUtils.defaultString(eigyosyo.get("khnDtlJisCd")));
            // 住所１
            msEigyosho.setJusho1(StrUtils.defaultString(eigyosyo.get("khnDtlJusho1")));
            // 住所２
            msEigyosho.setJusho2(StrUtils.defaultString(eigyosyo.get("khnDtlJusho2")));
            // 住所３
            msEigyosho.setJusho3(StrUtils.defaultString(eigyosyo.get("khnDtlJusho3")));
            // 住所４
            msEigyosho.setJusho4(StrUtils.defaultString(eigyosyo.get("khnDtlJusho4")));
            // 住所
            msEigyosho.setJusho(StrUtils.defaultString(jusho));
            // 空港コード
            msEigyosho.setKukoCd(StrUtils.defaultString(eigyosyo.get("khnDtlKukoCd")));
            // 仕向地コード
            msEigyosho.setShimukeChiCd(StrUtils.defaultString(eigyosyo.get("khnDtlShimukeChi")));
            // 集配地区コード
            msEigyosho.setShuhaiChiku(StrUtils.defaultString(eigyosyo.get("khnDtlShuhaiChikuCd")));
            // 電話番号１
            msEigyosho.setTelBango1(StrUtils.defaultString(eigyosyo.get("khnDtlTelBango1")));
            // 電話番号２
            msEigyosho.setTelBango2(StrUtils.defaultString(eigyosyo.get("khnDtlTelBango2")));
            // 社内電話番号
            msEigyosho.setShanaiTelBango(StrUtils.defaultString(eigyosyo.get("khnDtlShanaiTelBango")));
            // FAX番号
            msEigyosho.setFaxBango(StrUtils.defaultString(eigyosyo.get("khnDtlFaxBango")));
            // 銀行口座コード
            msEigyosho.setKaniGinkoCd(StrUtils.defaultString(eigyosyo.get("kzaDtlGinkoKozaCd")));
            // 仕立営業所コード
            msEigyosho.setShitateEigyoshoCd(StrUtils.defaultString(eigyosyo.get("orsDtlShitateEigyoshoCd")));
            // 他社中継卸値率
            if (eigyosyo.get("orsDtlTashaChukeiOroshineritsu") != null 
                    && eigyosyo.get("orsDtlTashaChukeiOroshineritsu") != "") {
                msEigyosho.setTashaChukeiOroshineritsu(Double.valueOf(
                        StrUtils.defaultString(eigyosyo.get("orsDtlTashaChukeiOroshineritsu"))));
            }
            // 一見顧客登録フラグ
            msEigyosho.setIchigenKokyakuTorokuFlg(StrUtils.defaultString(eigyosyo.get("dtlHIchigenKokyakuTorokuFlg")));
            // 社内便登録フラグ
            msEigyosho.setShanaiBinTorokuFlg(StrUtils.defaultString(eigyosyo.get("dtlHShanaiBinTorokuFlg")));
            // 着払代引登録フラグ
            msEigyosho.setChakubaraiDaibikiTorokuFlg(StrUtils.defaultString(
                    eigyosyo.get("dtlHChakubaraiDaibikiTorokuFlg")));
            // 削除フラグ
            msEigyosho.setSakujoFlg("0");
            
            // 営業所データバージョン
            if (eigyosyo.get("dtlEigyoshoDataVersion") != null 
                    && eigyosyo.get("dtlEigyoshoDataVersion") != "") {
                msEigyosho.setEigyoshoDataVersion(Integer.parseInt(
                    StrUtils.defaultString(eigyosyo.get("dtlEigyoshoDataVersion"))) + 1);
            
            }
            // 更新条件を設定する
            // 営業所コード
            msEigyosho.setEigyoshoCd(eigyoshoCd);
            // 適用開始日
            msEigyosho.setTekiyoKaishibi(tekiyoKaishibi);
            // 更新条件設定
            msEigyoshoMap.put(BaseDao.UPDATE_BEAN_CRT, msEigyosho);
            // 更新項目設定
            msEigyoshoMap.put(BaseDao.UPDATE_BEAN_UPD, msEigyosho);
            // 営業所マスタ更新データ設定
            msEigyoshoList.add(msEigyoshoMap);
            koshinIchiranRirekiList.add(msEigyosho);
        }
        
        // 営業所マスタ更新
        msEigyoshoDao.updateById(msEigyoshoList);
        msEigyoshoDao.createRirekiById(koshinIchiranRirekiList);
    }

    /**
     * 営業所卸単価マスタ_登録処理
     * 
     * @param serviceInterfaceBean JSFからの通信情報
     * @param eigyoshoOroshiTankaAddList 営業所卸単価登録情報リスト
     */
    private void msEigyoshoOroshiTankaInsert(ServiceInterfaceBean serviceInterfaceBean,
            List<Map<String, Object>> eigyoshoOroshiTankaAddList) {
       
        // テーブル「営業所卸単価マスタ」登録用
        List<MsEigyoshoOroshiTanka> msEigyoshoOroshiTankaList = 
                new ArrayList<>();
        
        // テーブル「営業所卸単価マスタ」履歴用
        List<MsEigyoshoOroshiTankaRireki> msEigyoshoOroshiTankaRirekiList = 
                new ArrayList<>();
       
        for (Map<String, Object> eigyosyoOrs : eigyoshoOroshiTankaAddList) {
            // 営業所卸単価マスタのパラメータ設定
            MsEigyoshoOroshiTanka msEigyoshoOroshiTanka = new MsEigyoshoOroshiTanka();
            msEigyoshoOroshiTanka = SystemColumn.systemColumnSet(StndConsIF.SYSCOL_INSERT, 
                    msEigyoshoOroshiTanka, serviceInterfaceBean);
            
            // 営業所コード
            msEigyoshoOroshiTanka.setEigyoshoCd(eigyoshoCd);
            // 適用開始日
            msEigyoshoOroshiTanka.setTekiyoKaishibi(tekiyoKaishibi);
            // 伝票種別コード
            msEigyoshoOroshiTanka.setDempyoShubetsuCd(StrUtils.defaultString(
                    eigyosyoOrs.get("orsDtlListHDempyoShubetsuCd")));
            // デフォルト使用フラグ
            String defaultshiyoFlg = StrUtils.defaultString(eigyosyoOrs.get("orsDtlListDefaultShiyo"));
            if (CheckUtils.isEqual(defaultshiyoFlg, "true")) {
                // 1:デフォルト
                msEigyoshoOroshiTanka.setDefaultShiyoFlg("1");
            } else {
                // 0:デフォルトではない
                msEigyoshoOroshiTanka.setDefaultShiyoFlg("0");
            }
            // 集荷卸単価
            if (eigyosyoOrs.get("orsDtlListShukaOroshiTanka") != null
                    && eigyosyoOrs.get("orsDtlListShukaOroshiTanka") != "") {
                msEigyoshoOroshiTanka.setShukaOroshiTanka(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListShukaOroshiTanka"))));
            }
            // 集荷卸最低額
            if (eigyosyoOrs.get("orsDtlListShukaOroshiSaiteiGaku") != null
                    && eigyosyoOrs.get("orsDtlListShukaOroshiSaiteiGaku") != "") {
                msEigyoshoOroshiTanka.setShukaOroshiSaiteiGaku(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListShukaOroshiSaiteiGaku"))));
            }
            // 集荷卸計上先営業所コード
            msEigyoshoOroshiTanka.setShukaOroshiKeijoEighoshoCd(
                    StrUtils.defaultString(eigyosyoOrs.get("orsDtlListShukaOroshiKeijoEighoshoCd")));
            // 発送母船卸単価
            if (eigyosyoOrs.get("orsDtlListHsoBosenTanka") != null
                    && eigyosyoOrs.get("orsDtlListHsoBosenTanka") != "") {
                msEigyoshoOroshiTanka.setHsoBosenTanka(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListHsoBosenTanka"))));
            }
            // 発送母船卸最低額
            if (eigyosyoOrs.get("orsDtlListHsoBosenSaiteiGaku") != null
                    && eigyosyoOrs.get("orsDtlListHsoBosenSaiteiGaku") != "") {
                msEigyoshoOroshiTanka.setHsoBosenSaiteiGaku(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListHsoBosenSaiteiGaku"))));
            }
            // 発送母船卸計上先営業所コード
            msEigyoshoOroshiTanka.setHsoBosenKeijoEighoshoCd(
                    StrUtils.defaultString(eigyosyoOrs.get("orsDtlListHsoBosenKeijoEighoshoCd")));
            // 到着母船卸単価
            if (eigyosyoOrs.get("orsDtlListTckBosenTanka") != null
                    && eigyosyoOrs.get("orsDtlListTckBosenTanka") != "") {
                msEigyoshoOroshiTanka.setTckBosenTanka(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListTckBosenTanka"))));
            }
            // 到着母船卸最低額
            if (eigyosyoOrs.get("orsDtlListTckBosenSaiteiGaku") != null
                    && eigyosyoOrs.get("orsDtlListTckBosenSaiteiGaku") != "") {
                msEigyoshoOroshiTanka.setTckBosenSaiteiGaku(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListTckBosenSaiteiGaku"))));
            }
            // 到着母船卸計上先営業所コード
            msEigyoshoOroshiTanka.setTckBosenKeijoEighoshoCd(
                    StrUtils.defaultString(eigyosyoOrs.get("orsDtlListTckBosenKeijoEighoshoCd")));
            // 仕分卸単価
            if (eigyosyoOrs.get("orsDtlListSwkOroshiTanka") != null
                    && eigyosyoOrs.get("orsDtlListSwkOroshiTanka") != "") {
                msEigyoshoOroshiTanka.setShiwakeOroshiTanka(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListSwkOroshiTanka"))));
            }
            // 仕分卸最低額
            if (eigyosyoOrs.get("orsDtlListSwkOroshiSaiteiGaku") != null
                    && eigyosyoOrs.get("orsDtlListSwkOroshiSaiteiGaku") != "") {
                msEigyoshoOroshiTanka.setShiwakeOroshiSaiteiGaku(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListSwkOroshiSaiteiGaku"))));
            }
            // 仕分卸計上先営業所コード
            msEigyoshoOroshiTanka.setShiwakeOroshiKeijoEighoshoCd(
                    StrUtils.defaultString(eigyosyoOrs.get("orsDtlListSwkOroshiKeijoEighoshoCd")));
            // 配達卸単価
            if (eigyosyoOrs.get("orsDtlListHttOroshiTanka") != null
                    && eigyosyoOrs.get("orsDtlListHttOroshiTanka") != "") {
                msEigyoshoOroshiTanka.setHttOroshiTanka(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListHttOroshiTanka"))));
            }
            // 配達卸最低額
            if (eigyosyoOrs.get("orsDtlListHttOroshiSaiteiGaku") != null
                    && eigyosyoOrs.get("orsDtlListHttOroshiSaiteiGaku") != "") {
                msEigyoshoOroshiTanka.setHttOroshiSaiteiGaku(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListHttOroshiSaiteiGaku"))));
            }
            // 配達卸計上先営業所コード
            msEigyoshoOroshiTanka.setHttOroshiKeijoEighoshoCd(
                    StrUtils.defaultString(eigyosyoOrs.get("orsDtlListHttOroshiKeijoEighoshoCd")));

            // 削除フラグ
            msEigyoshoOroshiTanka.setSakujoFlg("0");
            // 営業所データバージョン
            msEigyoshoOroshiTanka.setEigyoshoDataVersion(1);
            // 営業所卸単価マスタ新規データ設定
            msEigyoshoOroshiTankaList.add(msEigyoshoOroshiTanka);
            
            // 営業所卸単価マスタのパラメータ設定
            MsEigyoshoOroshiTankaRireki msEigyoshoOroshiTankaRireki 
                    = new MsEigyoshoOroshiTankaRireki();
            
            // 営業所コード
            msEigyoshoOroshiTankaRireki.setEigyoshoCd(eigyoshoCd);
            // 適用開始日
            msEigyoshoOroshiTankaRireki.setTekiyoKaishibi(tekiyoKaishibi);
            // 伝票種別コード
            msEigyoshoOroshiTankaRireki.setDempyoShubetsuCd(StrUtils.defaultString(
                    eigyosyoOrs.get("orsDtlListHDempyoShubetsuCd")));
            // 営業所データバージョン
            msEigyoshoOroshiTankaRireki.setEigyoshoDataVersion(1);
            
            msEigyoshoOroshiTankaRirekiList.add(msEigyoshoOroshiTankaRireki);
        }
        
        // 営業所卸単価マスタ削除
        msEigyoshoOroshiTankaDao.deleteById(msEigyoshoOroshiTankaList);
        msEigyoshoOroshiTankaRirekiDao.deleteById(msEigyoshoOroshiTankaRirekiList);
        
        // 営業所卸単価マスタ新規
        msEigyoshoOroshiTankaDao.insert(msEigyoshoOroshiTankaList);
        msEigyoshoOroshiTankaDao.createRirekiById(msEigyoshoOroshiTankaList);
    }
    
    /**
     * 営業所卸単価マスタ_更新処理
     * 
     * @param serviceInterfaceBean JSFからの通信情報
     * @param eigyoshoOroshiTankaUpdList 営業所卸単価更新情報リスト
     */
    private void msEigyoshoOroshiTankaUpdate(ServiceInterfaceBean serviceInterfaceBean,
            List<Map<String, Object>> eigyoshoOroshiTankaUpdList) {
        
        // テーブル「営業所卸単価マスタ」更新用
        List<Map<String, MsEigyoshoOroshiTanka>> msEigyoshoOroshiTankaList 
                = new ArrayList<>();
        
        // テーブル「営業所卸単価マスタ」履歴用
        List<MsEigyoshoOroshiTankaRireki> msEigyoshoOroshiTankaRirekiList = 
                new ArrayList<>();

        // 更新一覧履歴リストを初期化する
        List<MsEigyoshoOroshiTanka> koshinIchiranRirekiList = new ArrayList();    
        
        for (Map<String, Object> eigyosyoOrs : eigyoshoOroshiTankaUpdList) {
            Map msEigyoshoOroshiTankaMap = new HashMap<>();
             
            // 営業所卸単価マスタのパラメータ設定
            MsEigyoshoOroshiTanka msEigyoshoOroshiTanka = new MsEigyoshoOroshiTanka();
            
            msEigyoshoOroshiTanka = SystemColumn.systemColumnSet(StndConsIF.SYSCOL_UPDATE, 
                    msEigyoshoOroshiTanka, serviceInterfaceBean);
            // 営業所コード
            msEigyoshoOroshiTanka.setEigyoshoCd(eigyoshoCd);
            // 適用開始日
            msEigyoshoOroshiTanka.setTekiyoKaishibi(tekiyoKaishibi);
            // 伝票種別コード
            msEigyoshoOroshiTanka.setDempyoShubetsuCd(
                    StrUtils.defaultString(eigyosyoOrs.get("orsDtlListHDempyoShubetsuCd")));
            // デフォルト使用フラグ
            String defaultshiyoFlg = StrUtils.defaultString(eigyosyoOrs.get("orsDtlListDefaultShiyo"));
            if (CheckUtils.isEqual(defaultshiyoFlg, "true")) {
                // 1:デフォルト
                msEigyoshoOroshiTanka.setDefaultShiyoFlg("1");
            } else {
                // 0:デフォルトではない
                msEigyoshoOroshiTanka.setDefaultShiyoFlg("0");
            }
            // 集荷卸単価
            if (eigyosyoOrs.get("orsDtlListShukaOroshiTanka") != null
                    && eigyosyoOrs.get("orsDtlListShukaOroshiTanka") != "") {
                msEigyoshoOroshiTanka.setShukaOroshiTanka(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListShukaOroshiTanka"))));
            }
            // 集荷卸最低額
            if (eigyosyoOrs.get("orsDtlListShukaOroshiSaiteiGaku") != null
                    && eigyosyoOrs.get("orsDtlListShukaOroshiSaiteiGaku") != "") {
                msEigyoshoOroshiTanka.setShukaOroshiSaiteiGaku(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListShukaOroshiSaiteiGaku"))));
            }
            // 集荷卸計上先営業所コード
            msEigyoshoOroshiTanka.setShukaOroshiKeijoEighoshoCd(
                    StrUtils.defaultString(eigyosyoOrs.get("orsDtlListShukaOroshiKeijoEighoshoCd")));
            // 発送母船卸単価
            if (eigyosyoOrs.get("orsDtlListHsoBosenTanka") != null
                    && eigyosyoOrs.get("orsDtlListHsoBosenTanka") != "") {
                msEigyoshoOroshiTanka.setHsoBosenTanka(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListHsoBosenTanka"))));
            }
            // 発送母船卸最低額
            if (eigyosyoOrs.get("orsDtlListHsoBosenSaiteiGaku") != null
                    && eigyosyoOrs.get("orsDtlListHsoBosenSaiteiGaku") != "") {
                msEigyoshoOroshiTanka.setHsoBosenSaiteiGaku(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListHsoBosenSaiteiGaku"))));
            }
            // 発送母船卸計上先営業所コード
            msEigyoshoOroshiTanka.setHsoBosenKeijoEighoshoCd(
                    StrUtils.defaultString(eigyosyoOrs.get("orsDtlListHsoBosenKeijoEighoshoCd")));
            // 到着母船卸単価
            if (eigyosyoOrs.get("orsDtlListTckBosenTanka") != null
                    && eigyosyoOrs.get("orsDtlListTckBosenTanka") != "") {
                msEigyoshoOroshiTanka.setTckBosenTanka(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListTckBosenTanka"))));
            }
            // 到着母船卸最低額
            if (eigyosyoOrs.get("orsDtlListTckBosenSaiteiGaku") != null
                    && eigyosyoOrs.get("orsDtlListTckBosenSaiteiGaku") != "") {
                msEigyoshoOroshiTanka.setTckBosenSaiteiGaku(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListTckBosenSaiteiGaku"))));
            }
            // 到着母船卸計上先営業所コード
            msEigyoshoOroshiTanka.setTckBosenKeijoEighoshoCd(
                    StrUtils.defaultString(eigyosyoOrs.get("orsDtlListTckBosenKeijoEighoshoCd")));
            // 仕分卸単価
            if (eigyosyoOrs.get("orsDtlListSwkOroshiTanka") != null
                    && eigyosyoOrs.get("orsDtlListSwkOroshiTanka") != "") {
                msEigyoshoOroshiTanka.setShiwakeOroshiTanka(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListSwkOroshiTanka"))));
            }
            // 仕分卸最低額
            if (eigyosyoOrs.get("orsDtlListSwkOroshiSaiteiGaku") != null
                    && eigyosyoOrs.get("orsDtlListSwkOroshiSaiteiGaku") != "") {
                msEigyoshoOroshiTanka.setShiwakeOroshiSaiteiGaku(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListSwkOroshiSaiteiGaku"))));
            }
            // 仕分卸計上先営業所コード
            msEigyoshoOroshiTanka.setShiwakeOroshiKeijoEighoshoCd(
                    StrUtils.defaultString(eigyosyoOrs.get("orsDtlListSwkOroshiKeijoEighoshoCd")));
            // 配達卸単価
            if (eigyosyoOrs.get("orsDtlListHttOroshiTanka") != null
                    && eigyosyoOrs.get("orsDtlListHttOroshiTanka") != "") {
                msEigyoshoOroshiTanka.setHttOroshiTanka(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListHttOroshiTanka"))));
            }
            // 配達卸最低額
            if (eigyosyoOrs.get("orsDtlListHttOroshiSaiteiGaku") != null
                    && eigyosyoOrs.get("orsDtlListHttOroshiSaiteiGaku") != "") {
                msEigyoshoOroshiTanka.setHttOroshiSaiteiGaku(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListHttOroshiSaiteiGaku"))));
            }
            // 配達卸計上先営業所コード
            msEigyoshoOroshiTanka.setHttOroshiKeijoEighoshoCd(
                    StrUtils.defaultString(eigyosyoOrs.get("orsDtlListHttOroshiKeijoEighoshoCd")));
            // 削除フラグ
            msEigyoshoOroshiTanka.setSakujoFlg("0");
            
            // 営業所データバージョン
            if (eigyosyoOrs.get("orsEigyoshoDataVersion") != null 
                    && eigyosyoOrs.get("orsEigyoshoDataVersion") != "") {
                msEigyoshoOroshiTanka.setEigyoshoDataVersion(Integer.parseInt(
                    StrUtils.defaultString(eigyosyoOrs.get("orsEigyoshoDataVersion"))) + 1);
            
            }
            // 更新条件を設定する
            MsEigyoshoOroshiTanka msEigyoshoOroshiTankaCrt = new MsEigyoshoOroshiTanka();
            // 営業所コード
            msEigyoshoOroshiTankaCrt.setEigyoshoCd(eigyoshoCd);
            // 適用開始日
            msEigyoshoOroshiTankaCrt.setTekiyoKaishibi(tekiyoKaishibi);
            // 伝票種別コード
            msEigyoshoOroshiTankaCrt.setDempyoShubetsuCd(
                    StrUtils.defaultString(eigyosyoOrs.get("orsDtlListHDempyoShubetsuCdBak")));
            // 更新項目設定
            msEigyoshoOroshiTankaMap.put(BaseDao.UPDATE_BEAN_UPD, msEigyoshoOroshiTanka);
            // 更新条件設定
            msEigyoshoOroshiTankaMap.put(BaseDao.UPDATE_BEAN_CRT, msEigyoshoOroshiTankaCrt);
            // 営業所卸単価マスタ更新データ設定
            msEigyoshoOroshiTankaList.add(msEigyoshoOroshiTankaMap);
            koshinIchiranRirekiList.add(msEigyoshoOroshiTanka);
            
            // 営業所卸単価マスタのパラメータ設定
            MsEigyoshoOroshiTankaRireki msEigyoshoOroshiTankaRireki 
                    = new MsEigyoshoOroshiTankaRireki();
            
            // 営業所コード
            msEigyoshoOroshiTankaRireki.setEigyoshoCd(eigyoshoCd);
            // 適用開始日
            msEigyoshoOroshiTankaRireki.setTekiyoKaishibi(tekiyoKaishibi);
            // 伝票種別コード
            msEigyoshoOroshiTankaRireki.setDempyoShubetsuCd(StrUtils.defaultString(
                    eigyosyoOrs.get("orsDtlListHDempyoShubetsuCdBak")));
            // 営業所データバージョン
            if (eigyosyoOrs.get("orsEigyoshoDataVersion") != null 
                    && eigyosyoOrs.get("orsEigyoshoDataVersion") != "") {
                msEigyoshoOroshiTankaRireki.setEigyoshoDataVersion(Integer.parseInt(
                    StrUtils.defaultString(eigyosyoOrs.get("orsEigyoshoDataVersion"))) + 1);
            
            }
            
            msEigyoshoOroshiTankaRirekiList.add(msEigyoshoOroshiTankaRireki);
        }
        
        // 営業所卸単価マスタ削除
        msEigyoshoOroshiTankaRirekiDao.deleteById(msEigyoshoOroshiTankaRirekiList);
        
        // 営業所卸単価マスタ更新
        msEigyoshoOroshiTankaDao.updateById(msEigyoshoOroshiTankaList);
        msEigyoshoOroshiTankaDao.createRirekiById(koshinIchiranRirekiList);
    }

    /**
     * 営業所卸単価マスタ_削除処理
     * 
     * @param serviceInterfaceBean JSFからの通信情報
     * @param eigyoshoOroshiTankaDelList 営業所卸単価削除情報リスト
     */
    private void msEigyoshoOroshiTankaDelete(ServiceInterfaceBean serviceInterfaceBean,
            List<Map<String, Object>> eigyoshoOroshiTankaDelList) {
        
        // テーブル「営業所卸単価マスタ」削除用
        List<MsEigyoshoOroshiTanka> koshinIchiranRirekiList = new ArrayList();    

        for (Map<String, Object> eigyosyoOrs : eigyoshoOroshiTankaDelList) {
             
            // 営業所卸単価マスタのパラメータ設定
            MsEigyoshoOroshiTanka msEigyoshoOroshiTanka = new MsEigyoshoOroshiTanka();
            
            msEigyoshoOroshiTanka = SystemColumn.systemColumnSet(StndConsIF.SYSCOL_UPDATE, 
                    msEigyoshoOroshiTanka, serviceInterfaceBean);
            // 営業所コード
            msEigyoshoOroshiTanka.setEigyoshoCd(eigyoshoCd);
            // 適用開始日
            msEigyoshoOroshiTanka.setTekiyoKaishibi(tekiyoKaishibi);
            // 伝票種別コード
            msEigyoshoOroshiTanka.setDempyoShubetsuCd(
                    StrUtils.defaultString(eigyosyoOrs.get("orsDtlListHDempyoShubetsuCd")));
            // デフォルト使用フラグ
            String defaultshiyoFlg = StrUtils.defaultString(eigyosyoOrs.get("orsDtlListDefaultShiyo"));
            if (CheckUtils.isEqual(defaultshiyoFlg, "true")) {
                // 1:デフォルト
                msEigyoshoOroshiTanka.setDefaultShiyoFlg("1");
            } else {
                // 0:デフォルトではない
                msEigyoshoOroshiTanka.setDefaultShiyoFlg("0");
            }
            // 集荷卸単価
            if (eigyosyoOrs.get("orsDtlListShukaOroshiTanka") != null
                    && eigyosyoOrs.get("orsDtlListShukaOroshiTanka") != "") {
                msEigyoshoOroshiTanka.setShukaOroshiTanka(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListShukaOroshiTanka"))));
            }
            // 集荷卸最低額
            if (eigyosyoOrs.get("orsDtlListShukaOroshiSaiteiGaku") != null
                    && eigyosyoOrs.get("orsDtlListShukaOroshiSaiteiGaku") != "") {
                msEigyoshoOroshiTanka.setShukaOroshiSaiteiGaku(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListShukaOroshiSaiteiGaku"))));
            }
            // 集荷卸計上先営業所コード
            msEigyoshoOroshiTanka.setShukaOroshiKeijoEighoshoCd(
                    StrUtils.defaultString(eigyosyoOrs.get("orsDtlListShukaOroshiKeijoEighoshoCd")));
            // 発送母船卸単価
            if (eigyosyoOrs.get("orsDtlListHsoBosenTanka") != null
                    && eigyosyoOrs.get("orsDtlListHsoBosenTanka") != "") {
                msEigyoshoOroshiTanka.setHsoBosenTanka(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListHsoBosenTanka"))));
            }
            // 発送母船卸最低額
            if (eigyosyoOrs.get("orsDtlListHsoBosenSaiteiGaku") != null
                    && eigyosyoOrs.get("orsDtlListHsoBosenSaiteiGaku") != "") {
                msEigyoshoOroshiTanka.setHsoBosenSaiteiGaku(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListHsoBosenSaiteiGaku"))));
            }
            // 発送母船卸計上先営業所コード
            msEigyoshoOroshiTanka.setHsoBosenKeijoEighoshoCd(
                    StrUtils.defaultString(eigyosyoOrs.get("orsDtlListHsoBosenKeijoEighoshoCd")));
            // 到着母船卸単価
            if (eigyosyoOrs.get("orsDtlListTckBosenTanka") != null
                    && eigyosyoOrs.get("orsDtlListTckBosenTanka") != "") {
                msEigyoshoOroshiTanka.setTckBosenTanka(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListTckBosenTanka"))));
            }
            // 到着母船卸最低額
            if (eigyosyoOrs.get("orsDtlListTckBosenSaiteiGaku") != null
                    && eigyosyoOrs.get("orsDtlListTckBosenSaiteiGaku") != "") {
                msEigyoshoOroshiTanka.setTckBosenSaiteiGaku(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListTckBosenSaiteiGaku"))));
            }
            // 到着母船卸計上先営業所コード
            msEigyoshoOroshiTanka.setTckBosenKeijoEighoshoCd(
                    StrUtils.defaultString(eigyosyoOrs.get("orsDtlListTckBosenKeijoEighoshoCd")));
            // 仕分卸単価
            if (eigyosyoOrs.get("orsDtlListSwkOroshiTanka") != null
                    && eigyosyoOrs.get("orsDtlListSwkOroshiTanka") != "") {
                msEigyoshoOroshiTanka.setShiwakeOroshiTanka(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListSwkOroshiTanka"))));
            }
            // 仕分卸最低額
            if (eigyosyoOrs.get("orsDtlListSwkOroshiSaiteiGaku") != null
                    && eigyosyoOrs.get("orsDtlListSwkOroshiSaiteiGaku") != "") {
                msEigyoshoOroshiTanka.setShiwakeOroshiSaiteiGaku(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListSwkOroshiSaiteiGaku"))));
            }
            // 仕分卸計上先営業所コード
            msEigyoshoOroshiTanka.setShiwakeOroshiKeijoEighoshoCd(
                    StrUtils.defaultString(eigyosyoOrs.get("orsDtlListSwkOroshiKeijoEighoshoCd")));
            // 配達卸単価
            if (eigyosyoOrs.get("orsDtlListHttOroshiTanka") != null
                    && eigyosyoOrs.get("orsDtlListHttOroshiTanka") != "") {
                msEigyoshoOroshiTanka.setHttOroshiTanka(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListHttOroshiTanka"))));
            }
            // 配達卸最低額
            if (eigyosyoOrs.get("orsDtlListHttOroshiSaiteiGaku") != null
                    && eigyosyoOrs.get("orsDtlListHttOroshiSaiteiGaku") != "") {
                msEigyoshoOroshiTanka.setHttOroshiSaiteiGaku(Long.valueOf(StrUtils.defaultString(
                        eigyosyoOrs.get("orsDtlListHttOroshiSaiteiGaku"))));
            }
            // 配達卸計上先営業所コード
            msEigyoshoOroshiTanka.setHttOroshiKeijoEighoshoCd(
                    StrUtils.defaultString(eigyosyoOrs.get("orsDtlListHttOroshiKeijoEighoshoCd")));
            // 削除フラグ
            msEigyoshoOroshiTanka.setSakujoFlg("1");
            
            // 営業所データバージョン
            if (eigyosyoOrs.get("orsEigyoshoDataVersion") != null 
                    && eigyosyoOrs.get("orsEigyoshoDataVersion") != "") {
                msEigyoshoOroshiTanka.setEigyoshoDataVersion(Integer.parseInt(
                    StrUtils.defaultString(eigyosyoOrs.get("orsEigyoshoDataVersion"))) + 1);
            
            }
            // 営業所卸単価マスタ削除データ設定
            koshinIchiranRirekiList.add(msEigyoshoOroshiTanka);
        }
        
        // 営業所卸単価マスタ削除
        msEigyoshoOroshiTankaDao.deleteById(koshinIchiranRirekiList);
        msEigyoshoOroshiTankaDao.createRirekiById(koshinIchiranRirekiList);
    }

    /**
     * 営業所グループマスタ_削除処理
     * 
     * @param serviceInterfaceBean JSFからの通信情報
     * @param eigyoshoGroupDelList 営業所グループ削除情報リスト
     */
    private void msEigyoshoGroupDelete(ServiceInterfaceBean serviceInterfaceBean,
            List<Map<String, Object>> eigyoshoGroupDelList) {
       
        // テーブル「営業所グループマスタ」削除用
        List<MsEigyoshoGroup> koshinIchiranRirekiList = new ArrayList(); 

        for (Map<String, Object> eigyosyoGroup : eigyoshoGroupDelList) {
             
            // 営業所グループマスタのパラメータ設定
            MsEigyoshoGroup msEigyoshoGroup = new MsEigyoshoGroup();
            
            msEigyoshoGroup = SystemColumn.systemColumnSet(StndConsIF.SYSCOL_UPDATE, 
                    msEigyoshoGroup, serviceInterfaceBean);
            // 営業所コード
            msEigyoshoGroup.setEigyoshoCd(eigyoshoCd);
            // 適用開始日
            msEigyoshoGroup.setTekiyoKaishibi(tekiyoKaishibi);
            // 営業所グループシーケンス
            if (eigyosyoGroup.get("egrpDtlListEigyoshoGroupSeq") != null 
                    && eigyosyoGroup.get("egrpDtlListEigyoshoGroupSeq") != "") {
                msEigyoshoGroup.setEigyoshoGroupSeq(Integer.parseInt(
                StrUtils.defaultString(eigyosyoGroup.get("egrpDtlListEigyoshoGroupSeq"))));
            }
            // 上位営業所コード
            msEigyoshoGroup.setJoiEigyoshoCd(
                    StrUtils.defaultString(eigyosyoGroup.get("egrpDtlListJoiEigyoshoCd")));
            // 組織分類コード
            String mainSoshikiFlg = StrUtils.defaultString(eigyosyoGroup.get("egrpDtlListMainSoshiki"));
            if (CheckUtils.isEqual(mainSoshikiFlg, "true")) {
                // 1:メイン
                msEigyoshoGroup.setSoshikiBunruiCd("1");
            } else {
                // 2:サブ
                msEigyoshoGroup.setSoshikiBunruiCd("2");
            }
            // サブ組織名
            msEigyoshoGroup.setSubSoshikiMei(
                    StrUtils.defaultString(eigyosyoGroup.get("egrpDtlListSubSoshikiMei")));
            // 削除フラグ
            msEigyoshoGroup.setSakujoFlg("1");
            
            // 営業所データバージョン
            if (eigyosyoGroup.get("egrpEigyoshoDataVersion") != null 
                    && eigyosyoGroup.get("egrpEigyoshoDataVersion") != "") {
                msEigyoshoGroup.setEigyoshoDataVersion(Integer.parseInt(
                    StrUtils.defaultString(eigyosyoGroup.get("egrpEigyoshoDataVersion"))) + 1);
            
            }
            // 営業所グループマスタ削除設定
            koshinIchiranRirekiList.add(msEigyoshoGroup);
        }
        
        // 営業所グループマスタ削除
        msEigyoshoGroupDao.deleteById(koshinIchiranRirekiList);
        msEigyoshoGroupDao.createRirekiById(koshinIchiranRirekiList);
    }
    
    /**
     * 営業所グループマスタ_登録処理
     * 
     * @param serviceInterfaceBean JSFからの通信情報
     * @param eigyoshoGroupAddList 営業所グループ登録情報リスト
     */
    private void msEigyoshoGroupInsert(ServiceInterfaceBean serviceInterfaceBean,
            List<Map<String, Object>> eigyoshoGroupAddList) {
        // テーブル「営業所グループマスタ」登録用
        List<MsEigyoshoGroup> msEigyoshoGroupList = new ArrayList<>();
       
        for (Map<String, Object> eigyosyoGroup : eigyoshoGroupAddList) {
            // 営業所グループマスタのパラメータ設定
            MsEigyoshoGroup msEigyoshoGroup = new MsEigyoshoGroup();
            msEigyoshoGroup = SystemColumn.systemColumnSet(StndConsIF.SYSCOL_INSERT, 
                    msEigyoshoGroup, serviceInterfaceBean);
            
            // 営業所コード
            msEigyoshoGroup.setEigyoshoCd(eigyoshoCd);
            // 適用開始日
            msEigyoshoGroup.setTekiyoKaishibi(tekiyoKaishibi);
            // 営業所グループシーケンス
            if (eigyosyoGroup.get("egrpDtlListEigyoshoGroupSeq") != null 
                    && eigyosyoGroup.get("egrpDtlListEigyoshoGroupSeq") != "") {
                msEigyoshoGroup.setEigyoshoGroupSeq(Integer.parseInt(
                StrUtils.defaultString(eigyosyoGroup.get("egrpDtlListEigyoshoGroupSeq"))));
            }
            // 上位営業所コード
            msEigyoshoGroup.setJoiEigyoshoCd(
                    StrUtils.defaultString(eigyosyoGroup.get("egrpDtlListJoiEigyoshoCd")));
            // 組織分類コード
            String mainSoshikiFlg = StrUtils.defaultString(eigyosyoGroup.get("egrpDtlListMainSoshiki"));
            if (CheckUtils.isEqual(mainSoshikiFlg, "true")) {
                // 1:メイン
                msEigyoshoGroup.setSoshikiBunruiCd("1");
            } else {
                // 2:サブ
                msEigyoshoGroup.setSoshikiBunruiCd("2");
            }
            // サブ組織名
            msEigyoshoGroup.setSubSoshikiMei(
                    StrUtils.defaultString(eigyosyoGroup.get("egrpDtlListSubSoshikiMei")));
            // 削除フラグ
            msEigyoshoGroup.setSakujoFlg("0");
            // 営業所データバージョン
            msEigyoshoGroup.setEigyoshoDataVersion(1);
            // 営業所グループマスタ新規データ設定
            msEigyoshoGroupList.add(msEigyoshoGroup);
        }
        
        // 営業所グループマスタ新規
        msEigyoshoGroupDao.insert(msEigyoshoGroupList);
        msEigyoshoGroupDao.createRirekiById(msEigyoshoGroupList);
    }
    
    /**
     * 営業所グループマスタ_更新処理
     * 
     * @param serviceInterfaceBean JSFからの通信情報
     * @param eigyoshoGroupUpdList 営業所グループ更新情報リスト
     */
    private void msEigyoshoGroupUpdate(ServiceInterfaceBean serviceInterfaceBean,
            List<Map<String, Object>> eigyoshoGroupUpdList) {
       
        // テーブル「営業所グループマスタ」更新用
        List<Map<String, MsEigyoshoGroup>> msEigyoshoGroupList = new ArrayList<>();
        
        // 更新一覧履歴リストを初期化する
        List<MsEigyoshoGroup> koshinIchiranRirekiList = new ArrayList(); 

        for (Map<String, Object> eigyosyoGroup : eigyoshoGroupUpdList) {
            Map msEigyoshoGroupMap = new HashMap<>();
             
            // 営業所グループマスタのパラメータ設定
            MsEigyoshoGroup msEigyoshoGroup = new MsEigyoshoGroup();
            
            msEigyoshoGroup = SystemColumn.systemColumnSet(StndConsIF.SYSCOL_UPDATE, 
                    msEigyoshoGroup, serviceInterfaceBean);
            // 営業所コード
            msEigyoshoGroup.setEigyoshoCd(eigyoshoCd);
            // 適用開始日
            msEigyoshoGroup.setTekiyoKaishibi(tekiyoKaishibi);
            // 営業所グループシーケンス
            if (eigyosyoGroup.get("egrpDtlListEigyoshoGroupSeq") != null 
                    && eigyosyoGroup.get("egrpDtlListEigyoshoGroupSeq") != "") {
                msEigyoshoGroup.setEigyoshoGroupSeq(Integer.parseInt(
                StrUtils.defaultString(eigyosyoGroup.get("egrpDtlListEigyoshoGroupSeq"))));
            }
            // 上位営業所コード
            msEigyoshoGroup.setJoiEigyoshoCd(
                    StrUtils.defaultString(eigyosyoGroup.get("egrpDtlListJoiEigyoshoCd")));
            // 組織分類コード
            String mainSoshikiFlg = StrUtils.defaultString(eigyosyoGroup.get("egrpDtlListMainSoshiki"));
            if (CheckUtils.isEqual(mainSoshikiFlg, "true")) {
                // 1:メイン
                msEigyoshoGroup.setSoshikiBunruiCd("1");
            } else {
                // 2:サブ
                msEigyoshoGroup.setSoshikiBunruiCd("2");
            }
            // サブ組織名
            msEigyoshoGroup.setSubSoshikiMei(
                    StrUtils.defaultString(eigyosyoGroup.get("egrpDtlListSubSoshikiMei")));
            // 削除フラグ
            msEigyoshoGroup.setSakujoFlg("0");
            
            // 営業所データバージョン
            if (eigyosyoGroup.get("egrpEigyoshoDataVersion") != null 
                    && eigyosyoGroup.get("egrpEigyoshoDataVersion") != "") {
                msEigyoshoGroup.setEigyoshoDataVersion(Integer.parseInt(
                    StrUtils.defaultString(eigyosyoGroup.get("egrpEigyoshoDataVersion"))) + 1);
            
            }
            // 更新項目設定
            msEigyoshoGroupMap.put(BaseDao.UPDATE_BEAN_UPD, msEigyoshoGroup);
            // 更新条件設定
            msEigyoshoGroupMap.put(BaseDao.UPDATE_BEAN_CRT, msEigyoshoGroup);
            // 営業所グループマスタ更新設定
            msEigyoshoGroupList.add(msEigyoshoGroupMap);
            koshinIchiranRirekiList.add(msEigyoshoGroup);
        }
        
        // 営業所グループマスタ更新
        msEigyoshoGroupDao.updateById(msEigyoshoGroupList);
        msEigyoshoGroupDao.createRirekiById(koshinIchiranRirekiList);
    }
    
}