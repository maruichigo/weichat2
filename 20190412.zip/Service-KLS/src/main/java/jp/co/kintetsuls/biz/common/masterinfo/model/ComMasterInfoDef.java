package jp.co.kintetsuls.biz.common.masterinfo.model;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import lombok.Data;

/** 
 * Sample model
 * @author sharedsys
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "comMasterInfo")
@Data
public class ComMasterInfoDef implements Serializable{

    private static final long serialVersionUID = 8225066323266434396L;

    private String groupCd;
    private String cd;
    private String value;
}
