package jp.co.kintetsuls.biz.mst.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import java.util.Map;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.mst.dao.Mst032Dao;
import jp.co.kintetsuls.biz.mst.model.Mst032Def;
import jp.co.kintetsuls.biz.table.dao.MsJisCdDao;
import jp.co.kintetsuls.biz.table.dao.MsJisHenkanJohoDao;
import jp.co.kintetsuls.biz.table.dao.MsShimukeChiHenkanJohoDao;
import jp.co.kintetsuls.biz.table.dao.MsShisetsuHyojiMeiJohoDao;
import jp.co.kintetsuls.biz.table.model.MsJisCd;
import jp.co.kintetsuls.biz.table.model.MsJisHenkanJoho;
import jp.co.kintetsuls.biz.table.model.MsShimukeChiHenkanJoho;
import jp.co.kintetsuls.biz.table.model.MsShisetsuHyojiMeiJoho;
import jp.co.kintetsuls.common.cnst.SysMsg;

/**
 * 住所詳細機能関連情報取得処理
 *
 * @author 張誠 (MBP)
 * @version 2019/1/29 新規作成
 */
@Component("MST032_SEARCH")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Mst032BusSearch extends BaseBus {

    /**
     * 住所詳細情報Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected Mst032Dao mst032Dao;

    /**
     * JIS変換情報Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsJisHenkanJohoDao jisHenkanJohoDao;

    /**
     * 仕向地変換情報Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsShimukeChiHenkanJohoDao shimukeChiHenkanJohoDao;

    /**
     * 施設表示名情報Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsShisetsuHyojiMeiJohoDao shisetsuHyojiMeiJohoDao;

    /**
     * JISコードDao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsJisCdDao jisCdDao;

    /**
     * パラメータ
     */
    private Map<String, Object> params = null;

    /**
     * 住所詳細情報の検索処理
     *
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
        String mstFlg = params.get("mstFlg").toString();
        // パラメータ判定
        if (null != mstFlg) {
            if ("jusho".equals(mstFlg)) {
                // 住所情報検索
                getJushoJoho(serviceInterfaceBean);
            } else if ("henkan".equals(mstFlg)) {
                // 変換情報検索     
                getHenkanJoho(serviceInterfaceBean);
            } else if ("shisetsu".equals(mstFlg)) {
                // 施設表示名情報検索
                getShisetsuJoho(serviceInterfaceBean);
            } else if ("hkChk".equals(mstFlg)) {
                // 変換情報重複チェック
                henkanJohoCheck(serviceInterfaceBean);
            } else if ("shChk".equals(mstFlg)) {
                // 施設名表記情報重複チェック
                shisetsuMeiCheck(serviceInterfaceBean);
            } else if ("henko".equals(mstFlg)) {
                // 変更情報検索     
                getHenkoJoho(serviceInterfaceBean);
            }
        }
    }

    /**
     * 住所情報検索
     *
     * @param serviceInterfaceBean JSFからの通信情報
     */
    private void getJushoJoho(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        // 戻り値
        Map<String, Object> result = new HashMap<>();

        // 時間パラメータ変換
        long time_long = Long.valueOf(params.get("conTekiyoKaishibi").toString());
        Date date = new Date(time_long);
        params.put("conTekiyoKaishibi", date);        

        // 住所基本情報
        Mst032Def resultJusho = mst032Dao.findForJushoJoho(params);

        // 住所基本情報を戻り値に設定
        result.put("resultJusho", resultJusho);

        // リストワーク変数
        List<Map<String, Object>> resultList;
        // 住所詳細情報リスト取得
        resultList = mst032Dao.findForJushoList(params, "mst032.searchForJushoList");
        // データが取得できない場合
        if (resultList == null) {
            // メッセージを表示させ、処理を終了
            String msg = SysMsg.WRNDATA;
            serviceInterfaceBean.addMessage("WARN", "警告", msg);
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return;
        }
        // 住所詳細情報を戻り値に設定
        result.put("resultListJusho", resultList);

        // 離島詳細情報リスト取得
        resultList = mst032Dao.findForJushoList(params, "mst032.searchForRitoList");
        // データが取得できない場合
        if (resultList == null) {
            // メッセージを表示させ、処理を終了
            String msg = SysMsg.WRNDATA;
            serviceInterfaceBean.addMessage("WARN", "警告", msg);
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return;
        }
        // 離島詳細情報を戻り値に設定
        result.put("resultListRito", resultList);

        // 館内配送詳細情報リスト取得
        resultList = mst032Dao.findForJushoList(params, "mst032.searchForKannaiList");
        // データが取得できない場合
        if (resultList == null) {
            // メッセージを表示させ、処理を終了
            String msg = SysMsg.WRNDATA;
            serviceInterfaceBean.addMessage("WARN", "警告", msg);
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return;
        }
        // 館内配送詳細情報を戻り値に設定
        result.put("resultListKannai", resultList);

        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
    }

    /**
     * 変換情報検索
     *
     * @param serviceInterfaceBean JSFからの通信情報
     */
    private void getHenkanJoho(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
        // 時間パラメータ変換        
        long time_long = Long.valueOf(params.get("conTekiyoKaishibi").toString());
        Date date = new Date(time_long);
        params.put("conTekiyoKaishibi", date);

        String functionCode;
        // 仕向地コード(下2桁)
        String shimukeChiCd = params.get("jshDtlListHShimukeChiCd").toString();
        // 表示するポップアップの判定を実施する。
        if ("00".equals(shimukeChiCd)) {
            // JIS変換情報
            functionCode = "mst032.searchForJisHenkanList";
        } else {
            // 仕向地変換情報
            functionCode = "mst032.searchForShimukeHenkanList";
        }
        // 変換情報取得
        List<Map<String, Object>> result = mst032Dao.findForJushoList(params, functionCode);
        // データが取得できない場合
        if (result == null) {
            // メッセージを表示させ、処理を終了
            String msg = SysMsg.WRNDATA;
            serviceInterfaceBean.addMessage("WARN", "警告", msg);
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return;
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
    }

    /**
     * 施設名表記情報検索
     *
     * @param serviceInterfaceBean JSFからの通信情報
     */
    private void getShisetsuJoho(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
        // 適用開始日      
        long time_long = Long.valueOf(params.get("khDtlListHTekiyoKaishibi").toString());
        Date date = new Date(time_long);
        params.put("khDtlListHTekiyoKaishibi", date);
        // 施設名表記報取得
        List<Map<String, Object>> result = mst032Dao.findForJushoList(params, "mst032.searchForShisetsuList");
        // データが取得できない場合
        if (result == null) {
            // メッセージを表示させ、処理を終了
            String msg = SysMsg.WRNDATA;
            serviceInterfaceBean.addMessage("WARN", "警告", msg);
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return;
        }
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        //serviceInterfaceBean.addMessage("INFO", "情報", "方法");
    }

    /**
     * 施設名表記情報重複チェック
     *
     * @param serviceInterfaceBean JSFからの通信情報
     */
    private void shisetsuMeiCheck(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

        // JISコード 
        String jisCd = params.get("khDtlListHJisCd").toString();
        // 適用開始日
        long time_long = Long.valueOf(params.get("khDtlListHTekiyoKaishibi").toString());
        Date tekiyoKaishibi = new Date(time_long);
        // 住所館内配送シーケンス
        int haisoSeq = Integer.parseInt(params.get("khDtlListHJushoKannaihaisoSeq").toString());
        // チェックリスト取得
        List<Map<String, Object>> dataList = (List<Map<String, Object>>) params.get("dataList");

        // チェック処理を行う
        if (!dataList.isEmpty()) {
            List<MsShisetsuHyojiMeiJoho> result = null;
            Iterator<Map<String, Object>> ite = dataList.iterator();
            while (ite.hasNext()) {
                Map<String, Object> i = ite.next();
                String hyojiMei = i.get("shstDtlListHyojiMei").toString();
                // 既存データの場合
                if (i.get("shstDtlListHShisetsuHyojiMeiSeq") != null
                        && i.get("shstDtlListHShisetsuHyojiMeiSeq") != "") {
                    Map<String, Object> sqlParams = new HashMap<>();
                    // JISコード 
                    sqlParams.put("khDtlListHJisCd", jisCd);
                    // 適用開始日
                    sqlParams.put("khDtlListHTekiyoKaishibi", tekiyoKaishibi);
                    // 住所館内配送シーケンス
                    sqlParams.put("khDtlListHJushoKannaihaisoSeq", haisoSeq);
                    // 施設表示名シーケンス
                    sqlParams.put("shstDtlListHShisetsuHyojiMeiSeq", Integer.parseInt(
                            i.get("shstDtlListHShisetsuHyojiMeiSeq").toString()));
                    // 表示名
                    sqlParams.put("shstDtlListHyojiMei", hyojiMei);
                    // 表示名取得
                    result = mst032Dao.findShisetsuMei(sqlParams);
                } else {
                    // 検索条件初期化
                    MsShisetsuHyojiMeiJoho crt = new MsShisetsuHyojiMeiJoho();
                    // JISコード
                    crt.setJisCd(jisCd);
                    // 表示名
                    crt.setHyojiMei(hyojiMei);
                    // 削除フラグ
                    crt.setSakujoFlg("0");
                    // 表示名取得
                    result = shisetsuHyojiMeiJohoDao.findByColumn(crt);
                }
                if (result == null) {
                    String msg = SysMsg.WRNDATA;
                    serviceInterfaceBean.addMessage("WARN", "警告", msg);
                    serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                    return;
                } else {
                    if (result.size() > 0) {
                        break;
                    }
                }
            }
            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        }
    }

    /**
     * 変換情報重複チェック
     *
     * @param serviceInterfaceBean JSFからの通信情報
     */
    private void henkanJohoCheck(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

        // JISコード 
        String jisCd = params.get("hnknDtlJisCd").toString();
        // 適用開始日
        long time_long = Long.valueOf(params.get("conTekiyoKaishibi").toString());
        Date tekiyoKaishibi = new Date(time_long);
        // 仕向地コード
        String shimukeChiCd = params.get("hnknDtlShimukeChiCd").toString();
        // 仕向地コード(下2桁)
        String shimukeChiCdSimo = params.get("jshDtlListHShimukeChiCd").toString();
        // チェックリスト取得
        List<Map<String, Object>> dataList = (List<Map<String, Object>>) params.get("dataList");

        // チェック処理を行う
        if (!dataList.isEmpty()) {
            // JIS変換情報
            if ("00".equals(shimukeChiCdSimo)) {
                List<MsJisHenkanJoho> result = null;
                Iterator<Map<String, Object>> ite = dataList.iterator();
                while (ite.hasNext()) {
                    Map<String, Object> i = ite.next();
                    String henkanJusho = i.get("hnknDtlListHenkanJohoJusho").toString();
                    // 既存データの場合
                    if (i.get("hnknDtlListHHenkanJohoSeq") != null && i.get("hnknDtlListHHenkanJohoSeq") != "") {
                        Map<String, Object> sqlParams = new HashMap<>();
                        // JISコード 
                        sqlParams.put("hnknDtlJisCd", jisCd);
                        // 適用開始日
                        sqlParams.put("conTekiyoKaishibi", tekiyoKaishibi);
                        // 変換情報シーケンス
                        sqlParams.put("hnknDtlListHHenkanJohoSeq",
                                Integer.parseInt(i.get("hnknDtlListHHenkanJohoSeq").toString()));
                        // 変換情報住所
                        sqlParams.put("hnknDtlListHenkanJohoJusho", henkanJusho);
                        // 変換情報住所取得
                        result = mst032Dao.findJisHenkanJusho(sqlParams);
                    } else {
                        // 検索条件初期化
                        MsJisHenkanJoho crt = new MsJisHenkanJoho();
                        // JISコード
                        crt.setJisCd(jisCd);
                        // 適用開始日
                        crt.setTekiyoKaishibi(tekiyoKaishibi);
                        // 変換情報住所
                        crt.setHenkanJohoJusho(henkanJusho);
                        // 削除フラグ
                        crt.setSakujoFlg("0");
                        // 変換情報住所取得
                        result = jisHenkanJohoDao.findByColumn(crt);
                    }
                    if (result == null) {
                        String msg = SysMsg.WRNDATA;
                        serviceInterfaceBean.addMessage("WARN", "警告", msg);
                        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                        return;
                    } else {
                        if (result.size() > 0) {
                            break;
                        }
                    }
                }
                serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
            } else {
                // 仕向地変換情報
                List<MsShimukeChiHenkanJoho> result = null;
                Iterator<Map<String, Object>> ite = dataList.iterator();
                while (ite.hasNext()) {
                    Map<String, Object> i = ite.next();
                    String henkanJusho = i.get("hnknDtlListHenkanJohoJusho").toString();
                    // 既存データの場合
                    if (i.get("hnknDtlListHHenkanJohoSeq") != null && i.get("hnknDtlListHHenkanJohoSeq") != "") {
                        Map<String, Object> sqlParams = new HashMap<>();
                        // JISコード 
                        sqlParams.put("hnknDtlJisCd", jisCd);
                        // 適用開始日
                        sqlParams.put("conTekiyoKaishibi", tekiyoKaishibi);
                        // 仕向地コード
                        sqlParams.put("hnknDtlShimukeChiCd", shimukeChiCd);
                        // 変換情報シーケンス
                        sqlParams.put("hnknDtlListHHenkanJohoSeq", Integer.parseInt(
                                i.get("hnknDtlListHHenkanJohoSeq").toString()));
                        // 変換情報住所
                        sqlParams.put("hnknDtlListHenkanJohoJusho", henkanJusho);
                        // 変換情報住所取得
                        result = mst032Dao.findshimukeChiHenkanJusho(sqlParams);
                    } else {
                        // 検索条件初期化
                        MsShimukeChiHenkanJoho crt = new MsShimukeChiHenkanJoho();
                        // JISコード
                        crt.setJisCd(jisCd);
                        // 適用開始日
                        crt.setTekiyoKaishibi(tekiyoKaishibi);
                        // 仕向地コード
                        crt.setShimukeChiCd(shimukeChiCd);
                        // 変換情報住所
                        crt.setHenkanJohoJusho(henkanJusho);
                        // 削除フラグ
                        crt.setSakujoFlg("0");
                        // 変換情報住所取得
                        result = shimukeChiHenkanJohoDao.findByColumn(crt);
                    }
                    if (result == null) {
                        String msg = SysMsg.WRNDATA;
                        serviceInterfaceBean.addMessage("WARN", "警告", msg);
                        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                        return;
                    } else {
                        if (result.size() > 0) {
                            break;
                        }
                    }
                }
                serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
            }
        }
    }

    /**
     * 変更情報検索
     *
     * @param serviceInterfaceBean JSFからの通信情報
     */
    private void getHenkoJoho(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

        // JISコード 
        String jisCd = params.get("conJisCd").toString();

        // 時間パラメータ変換        
        long time_long = Long.valueOf(params.get("conTekiyoKaishibi").toString());
        Date tekiyoKaishibi = new Date(time_long);

        // 検索条件初期化
        MsJisCd crt = new MsJisCd();
        // JISコード
        crt.setJisCd(jisCd);
        // 適用開始日
        crt.setTekiyoKaishibi(tekiyoKaishibi);

        // 変更情報取得
        MsJisCd result = jisCdDao.findById(crt);
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
    }
}
