package jp.co.kintetsuls.biz.cus.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.sql.Date;

import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;

import java.util.Map;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.cus.dao.Cus012Dao;
import jp.co.kintetsuls.common.cnst.SysMsg;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * 顧客マスタ新規登録処理
 */
@Component("CUS012_INSERT_KOKYAKU_DATA")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Cus012BusInsert extends BaseBus {
    
    // Dao定義
    @Autowired(required=true)
    @Resource(shareable=true)
    protected Cus012Dao cus012Dao;
    private Map<String, Object> params = null;

    @Override
    @Transactional(propagation=Propagation.REQUIRED, rollbackFor=RuntimeException.class)
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception{
        //init
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

        // 必須チェック
        if(!params.containsKey("kokyakuCd")
                || !params.containsKey("tekiyoKaishibi")
                || !params.containsKey("kokyakuShubetsu")
                || !params.containsKey("kokyakuKbn")
                || !params.containsKey("kokyakuMeiKanji1")
                || !params.containsKey("kokyakuMei")
                || !params.containsKey("userCd")){
            String msg = SysMsg.WRNREQ;
            serviceInterfaceBean.addMessage("WARN", "警告", msg);
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return;
        }
        if(params.get("kokyakuCd") == null
                || params.get("tekiyoKaishibi") == null
                || params.get("kokyakuShubetsu") == null
                || params.get("kokyakuKbn") == null
                || params.get("kokyakuMeiKanji1") == null
                || params.get("kokyakuMei") == null
                || params.get("userCd") == null){
            String msg = SysMsg.WRNREQ;
            serviceInterfaceBean.addMessage("WARN", "警告", msg);
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return;
        }
        if(params.get("kokyakuCd").toString().length() < 6
                || params.get("tekiyoKaishibi").toString().isEmpty()
                || params.get("kokyakuShubetsu").toString().isEmpty()
                || params.get("kokyakuKbn").toString().isEmpty()
                || params.get("kokyakuMeiKanji1").toString().isEmpty()
                || params.get("kokyakuMei").toString().isEmpty()
                || params.get("userCd").toString().length() < 6){
            String msg = SysMsg.WRNREQ;
            serviceInterfaceBean.addMessage("WARN", "警告", msg);
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return;
        }

        // 日付け型変換
        params.put("tekiyoKaishibi", Date.valueOf(params.get("tekiyoKaishibi").toString()));

        int result = 0;
        
        //顧客マスタINSERT
        try{            
            result = cus012Dao.insertKokyakuData(params);
            if(result == 0){
                serviceInterfaceBean.addMessage("WARN", "警告", "顧客の新規登録が失敗しました。");  
                serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                return;
            }

            if(params.get("kokyakuCd").toString().endsWith("9")){
                throw new RuntimeException();
            }
            
            // サンプル用 顧客メモにINSERT
            result = cus012Dao.insertKokyakuMemo(params);
            if(result != ServiceInterfaceBean.PROCESS_STATUS_SUCCESS){
                throw new RuntimeException();
            }

        }catch(Exception e){
            serviceInterfaceBean.setStatusCode(result);
            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
            serviceInterfaceBean.addMessage("ERROR", "ERROR", "顧客の新規登録が失敗しました。");
            throw new RuntimeException();
        }

        serviceInterfaceBean.setStatusCode(result);
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        serviceInterfaceBean.addMessage("INFO", "INFO", "顧客の新規登録が完了しました。");
    
    }
}