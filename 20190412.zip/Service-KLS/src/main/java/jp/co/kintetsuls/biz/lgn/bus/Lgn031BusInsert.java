/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.lgn.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.HashMap;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import java.util.Map;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.base.dao.BaseDao;
import jp.co.kintetsuls.biz.lgn.dao.Lgn031Dao;
import jp.co.kintetsuls.biz.table.dao.TrShinseiDao;
import jp.co.kintetsuls.biz.table.dao.TrShinseiShosaiDao;
import jp.co.kintetsuls.biz.table.model.TrShinsei;
import jp.co.kintetsuls.biz.table.model.TrShinseiShosai;
import jp.co.kintetsuls.common.SystemColumn;
import jp.co.kintetsuls.common.cnst.StndConsIF;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.kintetsuls.utils.DateUtils;

/**
 * コメント登録処理
 *
 * @author 黄義輝 (MBP)
 * @version 2019/04/01 新規作成
 */
@Component("LGN031_INSERT")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Lgn031BusInsert extends BaseBus {

    /**
     * Lgn031Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected Lgn031Dao lgn031Dao;

    /**
     * 申請Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected TrShinseiDao trShinseiDao;

    /**
     * 申請定義
     */
    protected TrShinsei trShinsei;

    /**
     * 申請詳細Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected TrShinseiShosaiDao trShinseiShosaiDao;

    /**
     * 申請詳細定義
     */
    protected TrShinseiShosai trShinseiShosai;

    /**
     * コメント登録処理
     * 
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {

        // パラメータを解析する
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> param = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

        // ワーク.申請ID
        String shinseiId = objectToString(param.get("shinseiId"));

        // ワーク.コメント
        String shnDtlListComment = objectToString(param.get("shnDtlListComment"));

        // ワーク.承認者情報
        List<Map<String, Object>> shoninshaInfoList = null;
        if (param.get("shoninshaInfoList") != null) {
            shoninshaInfoList = (List)param.get("shoninshaInfoList");
        }

        // 承認可能アクティビティNO
        String shoninKanoActivityNo = "";
        if (shoninshaInfoList != null && !shoninshaInfoList.isEmpty()
                && shoninshaInfoList.get(0) != null) {
            shoninKanoActivityNo = objectToString(shoninshaInfoList.get(0).get("shinseiProcessActivityNo"));
        }

        Map<String, Object> optionMap = new HashMap<>();

        trShinsei = new TrShinsei();

        // ワーク.申請ID設定
        trShinsei.setShinseiId(shinseiId);
        // 承認可能アクティビティNO
        if (!CheckUtils.isEmpty(shoninKanoActivityNo)) {
            trShinsei.setGenDankaiActivityNo(Integer.valueOf(shoninKanoActivityNo));
        } else {
            trShinsei.setGenDankaiActivityNo(null);
            optionMap.put(BaseDao.NULL_CRITERIA_COL, new String[]{"GEN_DANKAI_ACTIVITY_NO"});
        }

        // 申請から、現段階アクティビティNOを取得する。
        List<TrShinsei> trShinseiResultList =  trShinseiDao.findByColumn(trShinsei, optionMap);

        // 申請詳細登録
        trShinseiShosai = new TrShinseiShosai();
        // システムカラム
        trShinseiShosai = SystemColumn.systemColumnSet(
                StndConsIF.SYSCOL_INSERT, trShinseiShosai, serviceInterfaceBean);
        // 申請ID
        trShinseiShosai.setShinseiId(shinseiId);
        // 申請詳細NO
        trShinseiShosai.setShinseiShosaiNo(getShinseiShosaiNoMax(shinseiId) + 1);
        // 申請プロセスアクティビティNO
        if (trShinseiResultList != null
                && !trShinseiResultList.isEmpty()
                && trShinseiResultList.get(0)!= null
                && trShinseiResultList.get(0).getGenDankaiActivityNo() != null) {
            trShinseiShosai.setShinseiProcessActivityNo(
                    trShinseiResultList.get(0).getGenDankaiActivityNo());
        }

        // 承認状況結果
        trShinseiShosai.setShoninJokyoKekka("06");
        // ユーザコード
        trShinseiShosai.setUserCd(serviceInterfaceBean.getUserCd());
        // 営業所コード
        trShinseiShosai.setEigyoshoCd(serviceInterfaceBean.getDefaultEigyosho());
        // ステータス更新日時
        trShinseiShosai.setKoshinBi(DateUtils.getSysDate());
        // 申請コメント
        trShinseiShosai.setShinseiComment(shnDtlListComment);
        // 削除フラグ
        trShinseiShosai.setSakujoFlg("0");

        // コメント登録処理
        trShinseiShosaiDao.insert(trShinseiShosai);
    }

    /**
     * 申請ID毎の申請詳細NOの最大値
     * 
     * @param shinseiId 申請ID
     * @return 申請ID毎の申請詳細NOの最大値
     */
    private int getShinseiShosaiNoMax(String shinseiId) {
        Map paramMap = new HashMap();

        paramMap.put("shinseiId", shinseiId);

        return lgn031Dao.countShinseiShosaiNoMax(paramMap);
    }
}