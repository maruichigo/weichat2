package jp.co.kintetsuls.biz.common.masterinfo.dao;

import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.biz.base.dao.BaseDao;
import jp.co.kintetsuls.biz.common.masterinfo.model.ComMasterInfoDef;
import org.springframework.stereotype.Component;

/* 
 * マスタ内容処理Daoクラス
 */
@Component
public class ComMasterInfoDao extends BaseDao<ComMasterInfoDef> {

    public List<ComMasterInfoDef> getStringList() {
        return getSqlSession().selectList("masterInfo.getAll");
    }

    public List<ComMasterInfoDef> getStringList(Map params) {
        return getSqlSession().selectList("masterInfo.getAll", params);
    }

}
