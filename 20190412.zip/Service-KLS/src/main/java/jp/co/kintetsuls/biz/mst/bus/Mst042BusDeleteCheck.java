/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.mst.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Date;
import java.util.List;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import java.util.Map;
import javax.annotation.Resource;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.table.dao.MsEigyoshoDao;
import jp.co.kintetsuls.biz.table.model.MsEigyosho;
import jp.co.kintetsuls.common.cnst.MessageCnst;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.kintetsuls.utils.StrUtils;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 営業所マスタ詳細の削除のチェック処理
 *
 * @author 雷珍 (MBP)
 * @version 2019/3/19 新規作成
 */
@Component("MST042_DELETE_CHECK")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Mst042BusDeleteCheck extends BaseBus {

    /**
     * 営業所マスタDAO定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsEigyoshoDao msEigyoshoDao;
    
    /**
     * 営業所マスタ詳細の削除チェック処理
     *
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {

        // パラメータを解析する
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
        // 時間パラメータ変換(適用開始日)
        long time_long = Long.valueOf(StrUtils.defaultString(params.get("conTekiyoKaishibi")));
        Date tekiyoKaishibiDate = new Date(time_long);
        
        // 存在チェック(営業所マスタ)
        // 検索条件
        MsEigyosho msEigyosho = new MsEigyosho();
        // 営業所コード
        msEigyosho.setEigyoshoCd(StrUtils.defaultString(params.get("conEigyoshoCd")));
        // 適用開始日
        msEigyosho.setTekiyoKaishibi(tekiyoKaishibiDate);
        // 適用名
        if (!CheckUtils.isEmpty(StrUtils.defaultString(params.get("conTekiyoMei")))) {
            msEigyosho.setTekiyoMei(StrUtils.defaultString(params.get("conTekiyoMei")));
        }
        // 営業所マスタ情報を取得する
        List<MsEigyosho> reEigyosho = msEigyoshoDao.findByColumn(msEigyosho);
        // 営業所存在チェック
        // 営業所コードが、営業所マスタに存在しない場合。
        if (reEigyosho.isEmpty()) {
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            // エラーメッセージを表示させ、処理を終了
            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(1));
            serviceInterfaceBean.addMessage("ERROR", 
                    MessageCnst.MSTE0009,
                    "該当のデータ");
            // 営業所マスタ
            serviceInterfaceBean.setTableName("営業所マスタ");
        }
    }
}