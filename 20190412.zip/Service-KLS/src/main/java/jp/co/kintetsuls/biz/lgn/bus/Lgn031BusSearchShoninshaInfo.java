/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.lgn.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import java.util.Map;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.lgn.dao.Lgn031Dao;

/**
 * 承認者情報の取得処理
 *
 * @author 黄義輝 (MBP)
 * @version 2019/04/01 新規作成
 */
@Component("LGN031_GET_SHONINSHAINFO_DETAIL")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Lgn031BusSearchShoninshaInfo extends BaseBus {

    /**
     * Lgn031Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected Lgn031Dao lgn031Dao;

    /**
     * 承認者情報取得処理
     * 
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {

        // パラメータを解析する
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

        // ログイン情報.ユーザーコード
        params.put("userCd", serviceInterfaceBean.getUserCd());

        // ログイン情報.デフォルト所属箇所コード
        params.put("eigyoshoCd", serviceInterfaceBean.getDefaultEigyosho());

        // 承認者情報の取得
        List<Map<String, String>> result = lgn031Dao.findForSearchShoninshaInfo(params);

        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));

    }
}