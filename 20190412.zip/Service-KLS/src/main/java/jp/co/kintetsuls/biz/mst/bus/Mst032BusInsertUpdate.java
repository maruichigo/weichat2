package jp.co.kintetsuls.biz.mst.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import java.util.Map;
import java.util.Map.Entry;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.base.dao.BaseDao;
import jp.co.kintetsuls.biz.common.versionCheck.bus.BusVersionCheck;
import jp.co.kintetsuls.biz.mst.dao.Mst032Dao;
import jp.co.kintetsuls.biz.table.dao.MsJisHenkanJohoDao;
import jp.co.kintetsuls.biz.table.dao.MsJushoDao;
import jp.co.kintetsuls.biz.table.dao.MsJushoJisDao;
import jp.co.kintetsuls.biz.table.dao.MsJushoKannaihaisoDao;
import jp.co.kintetsuls.biz.table.dao.MsJushoRitoDao;
import jp.co.kintetsuls.biz.table.dao.MsShimukeChiHenkanJohoDao;
import jp.co.kintetsuls.biz.table.dao.MsShisetsuHyojiMeiJohoDao;
import jp.co.kintetsuls.biz.table.model.MsJisHenkanJoho;
import jp.co.kintetsuls.biz.table.model.MsJusho;
import jp.co.kintetsuls.biz.table.model.MsJushoJis;
import jp.co.kintetsuls.biz.table.model.MsJushoKannaihaiso;
import jp.co.kintetsuls.biz.table.model.MsJushoRito;
import jp.co.kintetsuls.biz.table.model.MsShimukeChiHenkanJoho;
import jp.co.kintetsuls.biz.table.model.MsShisetsuHyojiMeiJoho;
import jp.co.kintetsuls.common.cnst.MessageCnst;
import jp.co.kintetsuls.common.json.JSONUtil;

/**
 * 住所詳細機能関連情報新規更新処理
 *
 * @author 張誠 (MBP)
 * @version 2019/2/26 新規作成
 */
@Component("MST032_INSERT_UPDATE")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Mst032BusInsertUpdate extends BaseBus {

    /**
     * Mst032Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected Mst032Dao mst032Dao;

    /**
     * 住所JISマスタDao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsJushoJisDao jushoJisDao;

    /**
     * 住所マスタDao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsJushoDao jushoDao;

    /**
     * JIS変換情報Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsJisHenkanJohoDao jisHenkanJohoDao;

    /**
     * 仕向地変換情報Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsShimukeChiHenkanJohoDao shimukeChiHenkanJohoDao;

    /**
     * 住所離島マスタDao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsJushoRitoDao jushoRitoDao;

    /**
     * 館内配送情報Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsJushoKannaihaisoDao jushoKannaihaisoDao;

    /**
     * 施設表示名情報Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsShisetsuHyojiMeiJohoDao shisetsuHyojiMeiJohoDao;

    /**
     * バージョンチェック(排他)
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected BusVersionCheck busVersionCheck;

    /**
     * パラメータ
     */
    private Map<String, Object> params = null;

    /**
     * JISコード
     */
    private String jisCd;

    /**
     * 適用開始日
     */
    private Date tekiyoKaishibi;

    /**
     * 適用開始日(排他メッセージ用)
     */
    private String msgTekiyoKaishibi;

    /**
     * 更新ユーザー
     */
    private String userCd;

    /**
     * 更新日時
     */
    private Date koshinData;

    /**
     * 更新端末
     */
    private String koshinTammatsu;

    /**
     * 更新営業所
     */
    private String koshinEigyosho;

    /**
     * 最終オペレーションユーザー
     */
    private String saishuOperationUser;

    /**
     * 最終オペレーション更新日時
     */
    private Date saishuOperationKoshinNichiji;

    /**
     * 住所詳細機能関連情報新規更新処理
     *
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

        // 共通用項目設定
        // JISコード
        jisCd = params.get("conJisCd").toString();
        // 適用開始日
        long time_long = Long.valueOf( params.get("conTekiyoKaishibi").toString());
        tekiyoKaishibi = new Date(time_long);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        msgTekiyoKaishibi = sdf.format(tekiyoKaishibi);
        // 更新ユーザー
        userCd = params.get("userCd").toString();
        // 更新日時
        koshinData = new Date();
        // 更新端末
        koshinTammatsu = serviceInterfaceBean.getTammatsu();
        // 更新営業所
        koshinEigyosho = serviceInterfaceBean.getDefaultEigyosho();
        // 最終オペレーションユーザー
        saishuOperationUser = serviceInterfaceBean.getUserCd();
        // 最終オペレーション更新日時
        saishuOperationKoshinNichiji = koshinData;

        // 住所基本情報更新フラグ
        String updFlg =  params.get("updFlg").toString();       
        // 住所JISマスタ
        if ("0".equals(updFlg)) {
            // 住所JISマスタ新規
            msJushoJisInsert();
        } else if ("1".equals(updFlg)) {
            // 住所JISマスタ更新
            msJushoJisUpdate(serviceInterfaceBean);
        }

        // 仕向地コード変更リスト取得
        List<Map<String, Object>> jushoHenkoList = (List<Map<String, Object>>) params.get("jushoHenkoList");
        if (jushoHenkoList.size() > 0) {
            // 仕向地コード変更処理
            shimukeChiCdHenkoSyori(serviceInterfaceBean, jushoHenkoList);
        }

        // 住所詳細リスト取得
        // 更新一覧リスト（住所詳細）
        List<Map<String, Object>> jushoUpdList = (List<Map<String, Object>>) params.get("jushoUpdList");
        if (jushoUpdList.size() > 0) {
            // 住所マスタ更新
            msJushoUpdate(serviceInterfaceBean, jushoUpdList);
        }
        // 登録一覧リスト（住所詳細）
        List<Map<String, Object>> jushoAddList = (List<Map<String, Object>>) params.get("jushoAddList");
        if (jushoAddList.size() > 0) {
            // 住所マスタ新規
            msJushoInsert(jushoAddList);
        }

        // 変換情報リスト取得
        // 変換情報更新処理
        Map<String, Object> henkanJohoListMap = (Map<String, Object>) params.get("henkanJohoListMap");
        if (henkanJohoListMap.size() > 0) {
            // 変換情報新規更新
            msHenkanJohoInsertUpdate(serviceInterfaceBean, henkanJohoListMap);
        }

        // 離島情報リスト取得
        // 更新一覧リスト（離島情報）
        List<Map<String, Object>> ritoUpdList = (List<Map<String, Object>>) params.get("ritoUpdList");
        if (ritoUpdList.size() > 0) {
            // 住所離島マスタ更新
            msJushoRitoUpdate(serviceInterfaceBean, ritoUpdList);
        }
        // 登録一覧リスト（離島情報）
        List<Map<String, Object>> ritoAddList = (List<Map<String, Object>>) params.get("ritoAddList");
        if (ritoAddList.size() > 0) {
            // 住所離島マスタ新規
            msJushoRitoInsert(ritoAddList);
        }

        // 住所館内配送マスタリスト取得
        // 更新一覧リスト（住所館内配送マスタ）
        List<Map<String, Object>> kannaiUpdList = (List<Map<String, Object>>) params.get("kannaiUpdList");
        if (kannaiUpdList.size() > 0) {
            // 住所離島マスタ更新
            msJushoKannaihaisoUpdate(serviceInterfaceBean, kannaiUpdList);
        }
        // 登録一覧リスト（住所館内配送マスタ）
        List<Map<String, Object>> kannaiAddList = (List<Map<String, Object>>) params.get("kannaiAddList");
        if (kannaiAddList.size() > 0) {
            // 住所離島マスタ新規
            msJushoKannaihaisoInsert(kannaiAddList);
        }

        // 施設表示名情報リスト取得
        Map<String, Object> shisetsuJohoListMap = (Map<String, Object>) params.get("shisetsuJohoListMap");
        // 施設表示名情報更新処理      
        if (shisetsuJohoListMap.size() > 0) {
            // 施設表示名情報新規更新
            msShisetsuHyojiMeiJohoInsertUpdate(serviceInterfaceBean, shisetsuJohoListMap);
        }
    }

    /**
     * 住所JISマスタ更新
     *
     * @param serviceInterfaceBean JSFからの通信情報
     */
    private void msJushoJisUpdate(ServiceInterfaceBean serviceInterfaceBean) {

        // 住所基本情報
        Map<String, Object> jushoJoho = (Map<String, Object>) params.get("jushoJoho");

        // 更新項目
        MsJushoJis upd = new MsJushoJis();

        // 漢字住所（市区町村）
        upd.setKanjiJusho(objectToString(jushoJoho.get("jshDtlKanjiJushoShikuchosonMei")));
        // カナ住所（市区町村）
        upd.setKanaJusho(objectToString(jushoJoho.get("jshDtlKanaJushoShikuchosonMei")));
        // 英語住所（都道府県）
        upd.setTodofukenEigoJusho(objectToString(jushoJoho.get("jshDtlEigoJushoTodofukenMei")));
        // 英語住所（市区町村）
        upd.setShikuchosonEigoJusho(objectToString(jushoJoho.get("jshDtlEigoJushoShikuchosonMei")));
        // 離島有無フラグ
        upd.setRitoUmuFlg(objectToString(jushoJoho.get("jshDtlRitoUmuFlg")));
        // HTコメント１
        upd.setHtComment1(objectToString(jushoJoho.get("jshDtlHtComment1")));
        // HTコメント２
        upd.setHtComment2(objectToString(jushoJoho.get("jshDtlHtComment2")));
        // 旧住所区分
        upd.setKyuJushoFlg(objectToString(jushoJoho.get("kyuJushoFlg")));
        // 旧住所コメント
        upd.setKyuJushoComment(objectToString(jushoJoho.get("kyjshDtlKyuJushoComment")));
        // 使用不可フラグ
        upd.setShiyoFukaFlg(objectToString(jushoJoho.get("shiyoFukaFlg")));
        // 新JISコード
        upd.setShinJisCd(objectToString(jushoJoho.get("kyjshDtlShinJisCd")));

        // データバージョン
        upd.setJushoJisDataVersion(Integer.parseInt(jushoJoho.get("kshnDtlJushoJisDataVer").toString()) + 1);
        // 更新ユーザー
        upd.setKoshinUser(userCd);
        // 更新日時
        upd.setKoshinNichiji(koshinData);
        // 更新端末
        upd.setKoshinTammatsu(koshinTammatsu);
        // 更新営業所
        upd.setKoshinEigyosho(koshinEigyosho);
        // 最終オペレーションユーザー
        upd.setSaishuOperationUser(saishuOperationUser);
        // 最終オペレーション更新日時
        upd.setSaishuOperationKoshinNichiji(saishuOperationKoshinNichiji);

        // 更新条件
        MsJushoJis crt = new MsJushoJis();
        // JISコード
        crt.setJisCd(jisCd);
        // 適用開始日
        crt.setTekiyoKaishibi(tekiyoKaishibi);

        // バージョンチェック(排他)
        Map<String, Object> paraMap = new HashMap<>();
        // JISコード
        paraMap.put("JIS_CD", jisCd);
        // 適用開始日
        paraMap.put("TEKIYO_KAISHIBI", tekiyoKaishibi);
        // 更新ユーザーID
        paraMap.put("koushinUserCd", jushoJoho.get("kshnDtlUser"));
        // 更新カウンタ
        paraMap.put("koushinCounter", jushoJoho.get("kshnDtlJisJushoCounter"));
        // エラー情報
        paraMap.put("msgJusho", jisCd + msgTekiyoKaishibi);
        // テーブル名
        paraMap.put("tblName", "MS_JUSHO_JIS");
        boolean haitaFlg = haitaCheckVersion(serviceInterfaceBean, paraMap);
        if (!haitaFlg) {
            return;
        }

        // 住所JISマスタ更新
        jushoJisDao.updateById(crt, upd);
    }

    /**
     * 住所JISマスタ新規
     *
     */
    private void msJushoJisInsert() {

        // 住所基本情報
        Map<String, Object> jushoJoho = (Map<String, Object>) params.get("jushoJoho");

        // 更新項目
        MsJushoJis upd = new MsJushoJis();

        // JISコード
        upd.setJisCd(jisCd);
        // 適用開始日
        upd.setTekiyoKaishibi(tekiyoKaishibi);
        // 適用名
        upd.setTekiyoMei(objectToString(params.get("conTekiyoMei")));
        // 漢字住所（市区町村）
        upd.setKanjiJusho(objectToString(jushoJoho.get("jshDtlKanjiJushoShikuchosonMei")));
        // カナ住所（市区町村）
        upd.setKanaJusho(objectToString(jushoJoho.get("jshDtlKanaJushoShikuchosonMei")));
        // 英語住所（都道府県）
        upd.setTodofukenEigoJusho(objectToString(jushoJoho.get("jshDtlEigoJushoTodofukenMei")));
        // 英語住所（市区町村）
        upd.setShikuchosonEigoJusho(objectToString(jushoJoho.get("jshDtlEigoJushoShikuchosonMei")));
        // 離島有無フラグ
        upd.setRitoUmuFlg(objectToString(jushoJoho.get("jshDtlRitoUmuFlg")));
        // HTコメント１
        upd.setHtComment1(objectToString(jushoJoho.get("jshDtlHtComment1")));
        // HTコメント２
        upd.setHtComment2(objectToString(jushoJoho.get("jshDtlHtComment2")));
        // 旧住所区分
        upd.setKyuJushoFlg(objectToString(jushoJoho.get("kyuJushoFlg")));
        // 旧住所コメント
        upd.setKyuJushoComment(objectToString(jushoJoho.get("kyjshDtlKyuJushoComment")));
        // 使用不可フラグ
        upd.setShiyoFukaFlg(objectToString(jushoJoho.get("shiyoFukaFlg")));
        // 新JISコード
        upd.setShinJisCd(objectToString(jushoJoho.get("kyjshDtlShinJisCd")));
        // 削除フラグ
        upd.setSakujoFlg("0");
        // データバージョン
        upd.setJushoJisDataVersion(1);
        // 更新カントー
        upd.setKoshinCounter(Long.valueOf("0"));
        // 登録ユーザー
        upd.setTorokuUser(userCd);
        // 登録日時
        upd.setTorokuNichiji(koshinData);
        // 登録端末
        upd.setTorokuTammatsu(koshinTammatsu);
        // 登録営業所
        upd.setTorokuEigyosho(koshinEigyosho);
        // 最終オペレーションユーザー
        upd.setSaishuOperationUser(saishuOperationUser);
        // 最終オペレーション更新日時
        upd.setSaishuOperationKoshinNichiji(saishuOperationKoshinNichiji);

        // 住所JISマスタ新規
        jushoJisDao.insert(upd);
    }

    /**
     * 仕向地コード変更処理
     *
     * @param serviceInterfaceBean JSFからの通信情報
     * @param jushoDataList 仕向地コード変更データリスト
     */
    private void shimukeChiCdHenkoSyori(ServiceInterfaceBean serviceInterfaceBean,
            List<Map<String, Object>> jushoDataList) {

        // 仕向地コード変更リスト
        Map<String, Object> henkanJohoListMap = (Map<String, Object>) params.get("henkanJohoListMap");

        // 住所マスタ一括追加
        List<MsJusho> msJushoListInsert = new ArrayList<>();
        // 住所マスタ一括削除
        List<MsJusho> msJushoListDelete = new ArrayList<>();

        // 仕向地変換情報マスタ一括追加
        List<MsShimukeChiHenkanJoho> msShimukeChiHenkanJohoListInsert = new ArrayList<>();
        // 仕向地変換情報マスタ一括削除
        List<MsShimukeChiHenkanJoho> msShimukeChiHenkanJohoListDelete = new ArrayList<>();

        // バージョンチェック(排他)
        Map<String, Object> paraMap;
        boolean haitaFlg;

        // 住所マスタ用
        MsJusho crtJusho;
        // 仕向地変換情報用（削除用：削除フラグが0と1のデータ）
        MsShimukeChiHenkanJoho crtShimukeChiHenkanJoho;
        // 仕向地変換情報用（編集用：削除フラグが0のデータ）
        MsShimukeChiHenkanJoho crtShimukeChiHenkanJohoFlg0;
        // 仕向地変換情報用（編集用：削除フラグが1のデータ）
        MsShimukeChiHenkanJoho crtShimukeChiHenkanJohoFlg1;
        Iterator<Map<String, Object>> iteJusho = jushoDataList.iterator();
        List<Map<String, Object>> shimukeChiHenkanJohoDataList;
        while (iteJusho.hasNext()) {
            // 住所マスタ用
            crtJusho = new MsJusho();
            // 仕向地変換情報用（削除用：削除フラグが0と1のデータ）
            crtShimukeChiHenkanJoho = new MsShimukeChiHenkanJoho();
            // 仕向地変換情報用（編集用：削除フラグが0のデータ）
            crtShimukeChiHenkanJohoFlg0 = new MsShimukeChiHenkanJoho();
            // 仕向地変換情報用（編集用：削除フラグが1のデータ）
            crtShimukeChiHenkanJohoFlg1 = new MsShimukeChiHenkanJoho();

            Map<String, Object> iJusho = iteJusho.next();
            // 仕向地コード取得
            String shimukeChiCdOld = objectToString(iJusho.get("jshDtlListJisCd"))
                    + objectToString(iJusho.get("jshDtlListHShimukeChiCd"));
            String shimukeChiCdNew = objectToString(iJusho.get("jshDtlListJisCd"))
                    + objectToString(iJusho.get("jshDtlListShimukeChiCd"));

            // バージョンチェック(排他)
            paraMap = new HashMap<>();
            // JISコード
            paraMap.put("JIS_CD", jisCd);
            // 適用開始日
            paraMap.put("TEKIYO_KAISHIBI", tekiyoKaishibi);
            // 仕向地コード
            paraMap.put("SHIMUKE_CHI_CD", shimukeChiCdOld);
            // 更新ユーザーID
            paraMap.put("koushinUserCd", iJusho.get("jshDtlListKoushinUserCd"));
            // 更新カウンタ
            paraMap.put("koushinCounter", iJusho.get("jshDtlListKoushinCounter"));
            // 仕向地コード
            paraMap.put("msgJusho", shimukeChiCdOld);
            // テーブル名
            paraMap.put("tblName", "MS_JUSHO");
            haitaFlg = haitaCheckVersion(serviceInterfaceBean, paraMap);
            if (!haitaFlg) {
                return;
            }

            // JISコード
            crtJusho.setJisCd(jisCd);
            crtShimukeChiHenkanJoho.setJisCd(jisCd);
            crtShimukeChiHenkanJohoFlg0.setJisCd(jisCd);
            crtShimukeChiHenkanJohoFlg1.setJisCd(jisCd);
            // 適用開始日
            crtJusho.setTekiyoKaishibi(tekiyoKaishibi);
            crtShimukeChiHenkanJoho.setTekiyoKaishibi(tekiyoKaishibi);
            crtShimukeChiHenkanJohoFlg0.setTekiyoKaishibi(tekiyoKaishibi);
            crtShimukeChiHenkanJohoFlg1.setTekiyoKaishibi(tekiyoKaishibi);
            // 仕向地コード
            crtJusho.setShimukeChiCd(shimukeChiCdOld);
            crtShimukeChiHenkanJoho.setShimukeChiCd(shimukeChiCdOld);
            crtShimukeChiHenkanJohoFlg0.setShimukeChiCd(shimukeChiCdOld);
            crtShimukeChiHenkanJohoFlg1.setShimukeChiCd(shimukeChiCdOld);
            // 行削除フラグ
            crtJusho.setSakujoFlg("0");
            crtShimukeChiHenkanJohoFlg0.setSakujoFlg("0");
            crtShimukeChiHenkanJohoFlg1.setSakujoFlg("1");
            // 住所マスタ一括削除条件設定
            msJushoListDelete.add(crtJusho);
            // 仕向地変換情報マスタ一括削除条件設定
            msShimukeChiHenkanJohoListDelete.add(crtShimukeChiHenkanJoho);

            // 住所マスタ検索
            MsJusho resJusho = jushoDao.findById(crtJusho);

            // 変更項目設定
            // 仕向地コード
            resJusho.setShimukeChiCd(shimukeChiCdNew);
            // 町字
            resJusho.setChoaza(objectToString(iJusho.get("jshDtlListChoaza")));
            // 町字カナ
            resJusho.setChoazaKana(objectToString(iJusho.get("jshDtlListChoazaKana")));
            // 町字英字
            resJusho.setChoazaEiji(objectToString(iJusho.get("jshDtlListChoazaEiji")));
            // 仕向地名コード
            resJusho.setShimukeChiMeiCd(objectToString(iJusho.get("jshDtlListShimukeChiMeiCd")));
            // 空港コード
            resJusho.setKukoCd(objectToString(iJusho.get("jshDtlListKukoCd")));
            // 集配地区コード
            resJusho.setShuhaiChiku(objectToString(iJusho.get("jshDtlListShuhaiChikuCd")));
            // 営業所コード
            resJusho.setEigyoshoCd(objectToString(iJusho.get("jshDtlListEigyoshoCd")));
            // 旧EDI住所フラグ
            boolean kyuEdiJushoFlg = Boolean.valueOf(iJusho.get("jshDtlListKyuEdiJushoFlg").toString());
            if (kyuEdiJushoFlg == true) {
                resJusho.setKyuEdiJushoFlg("1");
            } else {
                resJusho.setKyuEdiJushoFlg("0");
            }
            // 新EDI住所フラグ
            boolean shinEdiJushoFlg = Boolean.valueOf(iJusho.get("jshDtlListShinEdiJushoFlg").toString());
            if (shinEdiJushoFlg == true) {
                resJusho.setShinEdiJushoFlg("1");
            } else {
                resJusho.setShinEdiJushoFlg("0");
            }
            // 旧住所フラグ
            boolean kyuJushoFlg = Boolean.valueOf(iJusho.get("jshDtlListKyuJushoFlg").toString());
            if (kyuJushoFlg == true) {
                resJusho.setKyuJushoFlg("1");
            } else {
                resJusho.setKyuJushoFlg("0");
            }

            // 行削除フラグ
            resJusho.setSakujoFlg("0");
            // データバージョン
            resJusho.setJushoJisDataVersion(resJusho.getJushoJisDataVersion() + 1);
            // 更新カントー
            resJusho.setKoshinCounter(resJusho.getKoshinCounter() + 1);
            // 更新ユーザー
            resJusho.setKoshinUser(userCd);
            // 更新日時
            resJusho.setKoshinNichiji(koshinData);
            // 更新端末
            resJusho.setKoshinTammatsu(koshinTammatsu);
            // 更新営業所
            resJusho.setKoshinEigyosho(koshinEigyosho);
            // 最終オペレーションユーザー
            resJusho.setSaishuOperationUser(saishuOperationUser);
            // 最終オペレーション更新日時
            resJusho.setSaishuOperationKoshinNichiji(saishuOperationKoshinNichiji);

            // 住所マスタ一括追加データ設定
            msJushoListInsert.add(resJusho);

            // 関連の変更情報処理
            if (henkanJohoListMap.containsKey(shimukeChiCdOld)) {
                shimukeChiHenkanJohoDataList = (List<Map<String, Object>>) henkanJohoListMap.get(shimukeChiCdOld);
                Iterator<Map<String, Object>> iteHenkanJoho = shimukeChiHenkanJohoDataList.iterator();
                while (iteHenkanJoho.hasNext()) {
                    Map<String, Object> iHenkanJoho = iteHenkanJoho.next();
                    MsShimukeChiHenkanJoho resShimukeChiHenkanJoho = null;
                    // 仕向地変換情報マスタ検索
                    if (null == iHenkanJoho.get("addFlg")) {
                        crtShimukeChiHenkanJohoFlg0.setShimukeChiHenkanJohoSeq(
                                Integer.parseInt(iHenkanJoho.get("hnknDtlListHHenkanJohoSeq").toString()));
                        resShimukeChiHenkanJoho = shimukeChiHenkanJohoDao.findById(crtShimukeChiHenkanJohoFlg0);
                    }
                    if (resShimukeChiHenkanJoho != null) {
                        // 既存データ変更項目設定                                              
                        // データバージョン
                        resShimukeChiHenkanJoho.setJushoJisDataVersion(
                                resShimukeChiHenkanJoho.getJushoJisDataVersion() + 1);
                        // 更新カントー
                        resShimukeChiHenkanJoho.setKoshinCounter(resShimukeChiHenkanJoho.getKoshinCounter() + 1);
                        // 行削除フラグ
                        resShimukeChiHenkanJoho.setSakujoFlg(resShimukeChiHenkanJoho.getSakujoFlg());
                        // 更新ユーザー
                        resShimukeChiHenkanJoho.setKoshinUser(userCd);
                        // 更新日時
                        resShimukeChiHenkanJoho.setKoshinNichiji(koshinData);
                        // 更新端末
                        resShimukeChiHenkanJoho.setKoshinTammatsu(koshinTammatsu);
                        // 更新営業所
                        resShimukeChiHenkanJoho.setKoshinEigyosho(koshinEigyosho);
                    } else {
                        // 新規項目初期化
                        resShimukeChiHenkanJoho = new MsShimukeChiHenkanJoho();
                        // JISコード
                        resShimukeChiHenkanJoho.setJisCd(jisCd);
                        // 適用開始日
                        resShimukeChiHenkanJoho.setTekiyoKaishibi(tekiyoKaishibi);
                        // 行削除フラグ
                        resShimukeChiHenkanJoho.setSakujoFlg("0");
                        // データバージョン
                        resShimukeChiHenkanJoho.setJushoJisDataVersion(1);
                        // 更新カントー
                        resShimukeChiHenkanJoho.setKoshinCounter(Long.valueOf("0"));
                        // 登録ユーザー
                        resShimukeChiHenkanJoho.setTorokuUser(userCd);
                        // 登録日時
                        resShimukeChiHenkanJoho.setTorokuNichiji(koshinData);
                        // 登録端末
                        resShimukeChiHenkanJoho.setTorokuTammatsu(koshinTammatsu);
                        // 登録営業所
                        resShimukeChiHenkanJoho.setTorokuEigyosho(koshinEigyosho);
                    }
                    // 共通項目設定
                    // 仕向地コード
                    resShimukeChiHenkanJoho.setShimukeChiCd(shimukeChiCdNew);
                    // 変換情報住所
                    resShimukeChiHenkanJoho.setHenkanJohoJusho(
                            objectToString(iHenkanJoho.get("hnknDtlListHenkanJohoJusho")));
                    // 旧住所フラグ 
                    boolean henkanKyuJushoFlg = Boolean.valueOf(iHenkanJoho.get("hnknDtlListKyuJushoFlg").toString());
                    if (henkanKyuJushoFlg == true) {
                        resShimukeChiHenkanJoho.setKyuJushoFlg("1");
                    } else {
                        resShimukeChiHenkanJoho.setKyuJushoFlg("0");
                    }

                    // 最終オペレーションユーザー
                    resShimukeChiHenkanJoho.setSaishuOperationUser(saishuOperationUser);
                    // 最終オペレーション更新日時
                    resShimukeChiHenkanJoho.setSaishuOperationKoshinNichiji(saishuOperationKoshinNichiji);
                    // 仕向地変換情報マスタ一括新規データ設定
                    msShimukeChiHenkanJohoListInsert.add(resShimukeChiHenkanJoho);

                }
                // 削除フラグが1のデータを処理
                // 仕向地変換情報マスタ検索
                List<MsShimukeChiHenkanJoho> resShimukeChiHenkanJohoList
                        = shimukeChiHenkanJohoDao.findByColumn(crtShimukeChiHenkanJohoFlg1);
                for (MsShimukeChiHenkanJoho data : resShimukeChiHenkanJohoList) {
                    // 既存データ変更項目設定   
                    // 仕向地コード
                    data.setShimukeChiCd(shimukeChiCdNew);
                    // データバージョン
                    data.setJushoJisDataVersion(data.getJushoJisDataVersion() + 1);
                    // 更新カントー
                    data.setKoshinCounter(data.getKoshinCounter() + 1);
                    // 更新ユーザー
                    data.setKoshinUser(userCd);
                    // 更新日時
                    data.setKoshinNichiji(koshinData);
                    // 更新端末
                    data.setKoshinTammatsu(koshinTammatsu);
                    // 更新営業所
                    data.setKoshinEigyosho(koshinEigyosho);
                    // 行削除フラグ
                    data.setSakujoFlg(data.getSakujoFlg());
                    // 最終オペレーションユーザー
                    data.setSaishuOperationUser(saishuOperationUser);
                    // 最終オペレーション更新日時
                    data.setSaishuOperationKoshinNichiji(saishuOperationKoshinNichiji);
                    // 仕向地変換情報マスタ一括新規データ設定
                    msShimukeChiHenkanJohoListInsert.add(data);
                }
                // 処理したデータは変更情報から削除
                henkanJohoListMap.remove(shimukeChiCdOld);
            } else {
                // 仕向地変換情報マスタ検索
                List<MsShimukeChiHenkanJoho> resShimukeChiHenkanJohoList
                        = shimukeChiHenkanJohoDao.findByColumn(crtShimukeChiHenkanJoho);
                for (MsShimukeChiHenkanJoho data : resShimukeChiHenkanJohoList) {
                    // 既存データ変更項目設定   
                    // 仕向地コード
                    data.setShimukeChiCd(shimukeChiCdNew);
                    // データバージョン
                    data.setJushoJisDataVersion(data.getJushoJisDataVersion() + 1);
                    // 更新カントー
                    data.setKoshinCounter(data.getKoshinCounter() + 1);
                    // 更新ユーザー
                    data.setKoshinUser(userCd);
                    // 更新日時
                    data.setKoshinNichiji(koshinData);
                    // 更新端末
                    data.setKoshinTammatsu(koshinTammatsu);
                    // 更新営業所
                    data.setKoshinEigyosho(koshinEigyosho);
                    // 行削除フラグ
                    data.setSakujoFlg(data.getSakujoFlg());
                    // 最終オペレーションユーザー
                    data.setSaishuOperationUser(saishuOperationUser);
                    // 最終オペレーション更新日時
                    data.setSaishuOperationKoshinNichiji(saishuOperationKoshinNichiji);
                    // 仕向地変換情報マスタ一括新規データ設定
                    msShimukeChiHenkanJohoListInsert.add(data);
                }
            }
        }
        // 仕向地変換情報マスタ一括削除
        shimukeChiHenkanJohoDao.deleteByColumn(msShimukeChiHenkanJohoListDelete);
        // 住所マスタ一括削除
        jushoDao.deleteById(msJushoListDelete);

        // 住所マスタ一括追加
        jushoDao.insert(msJushoListInsert);
        // 仕向地変換情報マスタ一括追加
        mst032Dao.shimukeChiHenkanJohoInsert(msShimukeChiHenkanJohoListInsert);
    }

    /**
     * 住所マスタ更新
     *
     * @param serviceInterfaceBean JSFからの通信情報
     * @param jushoUpdList 住所詳細データ更新リスト
     */
    private void msJushoUpdate(ServiceInterfaceBean serviceInterfaceBean, List<Map<String, Object>> jushoUpdList) {

        // 住所マスタ一括更新
        List<Map<String, MsJusho>> msJushoMapList = new ArrayList<>();
        // 更新処理
        for (Map<String, Object> rec : jushoUpdList) {
            Map msJushoMap = new HashMap<>();
            // 更新項目
            MsJusho upd = new MsJusho();

            // 町字
            upd.setChoaza(objectToString(rec.get("jshDtlListChoaza")));
            // 町字カナ
            upd.setChoazaKana(objectToString(rec.get("jshDtlListChoazaKana")));
            // 町字英字
            upd.setChoazaEiji(objectToString(rec.get("jshDtlListChoazaEiji")));
            // 仕向地名コード
            upd.setShimukeChiMeiCd(objectToString(rec.get("jshDtlListShimukeChiMeiCd")));
            // 空港コード
            upd.setKukoCd(objectToString(rec.get("jshDtlListKukoCd")));
            // 集配地区コード
            upd.setShuhaiChiku(objectToString(rec.get("jshDtlListShuhaiChikuCd")));
            // 営業所コード
            upd.setEigyoshoCd(objectToString(rec.get("jshDtlListEigyoshoCd")));
            // 旧EDI住所フラグ
            boolean kyuEdiJushoFlg = Boolean.valueOf(rec.get("jshDtlListKyuEdiJushoFlg").toString());
            if (kyuEdiJushoFlg == true) {
                upd.setKyuEdiJushoFlg("1");
            } else {
                upd.setKyuEdiJushoFlg("0");
            }
            // 新EDI住所フラグ
            boolean shinEdiJushoFlg = Boolean.valueOf(rec.get("jshDtlListShinEdiJushoFlg").toString());
            if (shinEdiJushoFlg == true) {
                upd.setShinEdiJushoFlg("1");
            } else {
                upd.setShinEdiJushoFlg("0");
            }
            // 旧住所フラグ
            boolean kyuJushoFlg = Boolean.valueOf( rec.get("jshDtlListKyuJushoFlg").toString());
            if (kyuJushoFlg == true) {
                upd.setKyuJushoFlg("1");
            } else {
                upd.setKyuJushoFlg("0");
            }
            // データバージョン
            upd.setJushoJisDataVersion(Integer.parseInt(rec.get("jshDtlListJushoJisDataVer").toString()) + 1);
            // 更新ユーザー
            upd.setKoshinUser(userCd);
            // 更新日時
            upd.setKoshinNichiji(koshinData);
            // 更新端末
            upd.setKoshinTammatsu(koshinTammatsu);
            // 更新営業所
            upd.setKoshinEigyosho(koshinEigyosho);
            // 最終オペレーションユーザー
            upd.setSaishuOperationUser(saishuOperationUser);
            // 最終オペレーション更新日時
            upd.setSaishuOperationKoshinNichiji(saishuOperationKoshinNichiji);

            // 更新項目設定
            msJushoMap.put(BaseDao.UPDATE_BEAN_UPD, upd);
            // 更新条件
            MsJusho crt = new MsJusho();
            // JISコード
            crt.setJisCd(jisCd);
            // 適用開始日
            crt.setTekiyoKaishibi(tekiyoKaishibi);
            // 仕向地コード
            crt.setShimukeChiCd(objectToString(rec.get("jshDtlListJisCd"))
                    + objectToString(rec.get("jshDtlListHShimukeChiCd")));
            // 更新条件設定
            msJushoMap.put(BaseDao.UPDATE_BEAN_CRT, crt);
            msJushoMapList.add(msJushoMap);

            // バージョンチェック(排他)
            Map<String, Object> paraMap = new HashMap<>();
            // JISコード
            paraMap.put("JIS_CD", jisCd);
            // 適用開始日
            paraMap.put("TEKIYO_KAISHIBI", tekiyoKaishibi);
            // 仕向地コード
            paraMap.put("SHIMUKE_CHI_CD", objectToString(rec.get("jshDtlListJisCd"))
                    + objectToString(rec.get("jshDtlListHShimukeChiCd")));
            // 更新ユーザーID
            paraMap.put("koushinUserCd", rec.get("jshDtlListKoushinUserCd"));
            // 更新カウンタ
            paraMap.put("koushinCounter", rec.get("jshDtlListKoushinCounter"));
            // 仕向地コード
            paraMap.put("msgJusho", objectToString(rec.get("jshDtlListJisCd"))
                    + objectToString(rec.get("jshDtlListHShimukeChiCd")));
            // テーブル名
            paraMap.put("tblName", "MS_JUSHO");
            boolean haitaFlg = haitaCheckVersion(serviceInterfaceBean, paraMap);
            if (!haitaFlg) {
                return;
            }
        }
        // 住所マスタ更新
        jushoDao.updateById(msJushoMapList);
    }

    /**
     * 住所マスタ新規
     *
     * @param jushoAddList 住所詳細データ新規リスト
     */
    private void msJushoInsert(List<Map<String, Object>> jushoAddList) {

        // 住所マスタ一括追加
        List<MsJusho> msJushoList = new ArrayList<>();
        // 追加項目
        MsJusho upd;
        // 更新処理
        for (Map<String, Object> rec : jushoAddList) {
            // 追加項目
            upd = new MsJusho();
            // 仕向地コード取得
            String shimukeChiCd = objectToString(rec.get("jshDtlListJisCd"))
                    + objectToString(rec.get("jshDtlListShimukeChiCd"));
            // JISコード
            upd.setJisCd(jisCd);
            // 適用開始日
            upd.setTekiyoKaishibi(tekiyoKaishibi);
            // 仕向地コード
            upd.setShimukeChiCd(shimukeChiCd);
            // 町字
            upd.setChoaza(objectToString(rec.get("jshDtlListChoaza")));
            // 町字カナ
            upd.setChoazaKana(objectToString(rec.get("jshDtlListChoazaKana")));
            // 町字英字
            upd.setChoazaEiji(objectToString(rec.get("jshDtlListChoazaEiji")));
            // 都道府県コード
            upd.setTodofukenCd(objectToString(rec.get("jshDtlListJisCd")).substring(0, 2));
            // 仕向地名コード
            upd.setShimukeChiMeiCd(objectToString(rec.get("jshDtlListShimukeChiMeiCd")));
            // 空港コード
            upd.setKukoCd(objectToString(rec.get("jshDtlListKukoCd")));
            // 集配地区コード
            upd.setShuhaiChiku(objectToString(rec.get("jshDtlListShuhaiChikuCd")));
            // 営業所コード
            upd.setEigyoshoCd(objectToString(rec.get("jshDtlListEigyoshoCd")));
            // 旧EDI住所フラグ
            boolean kyuEdiJushoFlg = Boolean.valueOf(rec.get("jshDtlListKyuEdiJushoFlg").toString());
            if (kyuEdiJushoFlg == true) {
                upd.setKyuEdiJushoFlg("1");
            } else {
                upd.setKyuEdiJushoFlg("0");
            }
            // 新EDI住所フラグ
            boolean shinEdiJushoFlg = Boolean.valueOf(rec.get("jshDtlListShinEdiJushoFlg").toString());
            if (shinEdiJushoFlg == true) {
                upd.setShinEdiJushoFlg("1");
            } else {
                upd.setShinEdiJushoFlg("0");
            }
            // 旧住所フラグ
            boolean kyuJushoFlg = Boolean.valueOf(rec.get("jshDtlListKyuJushoFlg").toString());
            if (kyuJushoFlg == true) {
                upd.setKyuJushoFlg("1");
            } else {
                upd.setKyuJushoFlg("0");
            }
            // 削除フラグ
            upd.setSakujoFlg("0");
            // データバージョン
            upd.setJushoJisDataVersion(1);
            // 更新カントー
            upd.setKoshinCounter(Long.valueOf("0"));
            // 登録ユーザー
            upd.setTorokuUser(userCd);
            // 登録日時
            upd.setTorokuNichiji(koshinData);
            // 登録端末
            upd.setTorokuTammatsu(koshinTammatsu);
            // 登録営業所
            upd.setTorokuEigyosho(koshinEigyosho);
            // 最終オペレーションユーザー
            upd.setSaishuOperationUser(saishuOperationUser);
            // 最終オペレーション更新日時
            upd.setSaishuOperationKoshinNichiji(saishuOperationKoshinNichiji);

            // 追加データ設定
            msJushoList.add(upd);
        }
        // 住所マスタ更新
        jushoDao.insert(msJushoList);
    }

    /**
     * 変換情報新規更新
     *
     * @param serviceInterfaceBean JSFからの通信情報
     * @param henkanJohoListMap 住所変換情報データ新規リスト
     */
    private void msHenkanJohoInsertUpdate(ServiceInterfaceBean serviceInterfaceBean,
            Map<String, Object> henkanJohoListMap) {

        // JIS変換情報マスタ一括更新
        List<Map<String, MsJisHenkanJoho>> msJisHenkanJohosListUpdate = new ArrayList<>();
        // JIS変換情報マスタ一括追加
        List<MsJisHenkanJoho> msJisHenkanJohosListInsert = new ArrayList<>();

        // 仕向地変換情報マスタ一括更新
        List<Map<String, MsShimukeChiHenkanJoho>> msShimukeChiHenkanJohoListUpdate = new ArrayList<>();
        // 仕向地変換情報マスタ一括追加
        List<MsShimukeChiHenkanJoho> msShimukeChiHenkanJohoListInsert = new ArrayList<>();

        // バージョンチェック(排他)
        Map<String, Object> paraMap;

        for (Entry<String, Object> entry : henkanJohoListMap.entrySet()) {
            // 仕向地コードの取得
            String shimukeChiCd = entry.getKey();
            // 変換情報リスト取得
            List<Map<String, Object>> resList = (List<Map<String, Object>>) entry.getValue();
            if (resList.size() > 0) {
                Iterator<Map<String, Object>> ite = resList.iterator();
                while (ite.hasNext()) {
                    Map<String, Object> i = ite.next();
                    // 仕向地コード(下2桁)判定
                    if ("00".equals(shimukeChiCd.substring(shimukeChiCd.length() - 2, shimukeChiCd.length()))) {
                        // JIS変換情報処理
                        if ((null == i.get("addFlg") || "".equals(objectToString(i.get("addFlg"))))
                                && "UPD".equals(objectToString(i.get("setFlg")))) {
                            Map msJisHenkanJohoMap = new HashMap<>();
                            // 更新項目初期化
                            MsJisHenkanJoho upd = new MsJisHenkanJoho();
                            // 変換情報住所
                            upd.setHenkanJohoJusho(objectToString(i.get("hnknDtlListHenkanJohoJusho")));
                            // 旧住所フラグ 
                            boolean kyuJushoFlg = Boolean.valueOf(i.get("hnknDtlListKyuJushoFlg").toString());
                            if (kyuJushoFlg == true) {
                                upd.setKyuJushoFlg("1");
                            } else {
                                upd.setKyuJushoFlg("0");
                            }
                            // 削除フラグ
                            upd.setSakujoFlg(objectToString(i.get("hnknDtlListHSakujoFlg")));
                            // データバージョン
                            upd.setJushoJisDataVersion(Integer.parseInt(
                                    i.get("hnknDtlListJushoJisDataVer").toString()) + 1);
                            // 更新ユーザー
                            upd.setKoshinUser(userCd);
                            // 更新日時
                            upd.setKoshinNichiji(koshinData);
                            // 更新端末
                            upd.setKoshinTammatsu(koshinTammatsu);
                            // 更新営業所
                            upd.setKoshinEigyosho(koshinEigyosho);
                            // 最終オペレーションユーザー
                            upd.setSaishuOperationUser(saishuOperationUser);
                            // 最終オペレーション更新日時
                            upd.setSaishuOperationKoshinNichiji(saishuOperationKoshinNichiji);
                            // 更新項目設定
                            msJisHenkanJohoMap.put(BaseDao.UPDATE_BEAN_UPD, upd);

                            // 更新条件初期化
                            MsJisHenkanJoho crt = new MsJisHenkanJoho();
                            // JISコード
                            crt.setJisCd(jisCd);
                            // 適用開始日
                            crt.setTekiyoKaishibi(tekiyoKaishibi);
                            // JIS変換情報シーケンス
                            crt.setJisHenkanJohoSeq(Integer.parseInt(
                                    objectToString(i.get("hnknDtlListHHenkanJohoSeq"))));
                            // 更新条件設定
                            msJisHenkanJohoMap.put(BaseDao.UPDATE_BEAN_CRT, crt);

                            // JIS変換情報マスタ一括更新データ設定
                            msJisHenkanJohosListUpdate.add(msJisHenkanJohoMap);

                            // バージョンチェック(排他)
                            paraMap = new HashMap<>();
                            // JISコード
                            paraMap.put("JIS_CD", jisCd);
                            // 適用開始日
                            paraMap.put("TEKIYO_KAISHIBI", tekiyoKaishibi);
                            // JIS変換情報シーケンス
                            paraMap.put("JIS_HENKAN_JOHO_SEQ", i.get("hnknDtlListHHenkanJohoSeq"));
                            // 更新ユーザーID
                            paraMap.put("koushinUserCd", i.get("hnknDtlListKoushinUserCd"));
                            // 更新カウンタ
                            paraMap.put("koushinCounter", i.get("hnknDtlListKoushinCounter"));
                            // 変換情報住所
                            paraMap.put("msgJusho", i.get("hnknDtlListHenkanJohoJusho"));
                            // テーブル名
                            paraMap.put("tblName", "MS_JIS_HENKAN_JOHO");
                            boolean haitaFlg = haitaCheckVersion(serviceInterfaceBean, paraMap);
                            if (!haitaFlg) {
                                return;
                            }
                        } else if (null != i.get("addFlg")) {
                            // 更新項目初期化
                            MsJisHenkanJoho upd = new MsJisHenkanJoho();
                            // JISコード
                            upd.setJisCd(jisCd);
                            // 適用開始日
                            upd.setTekiyoKaishibi(tekiyoKaishibi);
                            // 変換情報住所
                            upd.setHenkanJohoJusho(objectToString(i.get("hnknDtlListHenkanJohoJusho")));
                            // 旧住所フラグ 
                            boolean kyuJushoFlg = Boolean.valueOf(i.get("hnknDtlListKyuJushoFlg").toString());
                            if (kyuJushoFlg == true) {
                                upd.setKyuJushoFlg("1");
                            } else {
                                upd.setKyuJushoFlg("0");
                            }
                            // 行削除フラグ
                            upd.setSakujoFlg("0");
                            // データバージョン
                            upd.setJushoJisDataVersion(1);
                            // 更新カントー
                            upd.setKoshinCounter(Long.valueOf("0"));
                            // 登録ユーザー
                            upd.setTorokuUser(userCd);
                            // 登録日時
                            upd.setTorokuNichiji(koshinData);
                            // 登録端末
                            upd.setTorokuTammatsu(koshinTammatsu);
                            // 登録営業所
                            upd.setTorokuEigyosho(koshinEigyosho);
                            // 最終オペレーションユーザー
                            upd.setSaishuOperationUser(saishuOperationUser);
                            // 最終オペレーション更新日時
                            upd.setSaishuOperationKoshinNichiji(saishuOperationKoshinNichiji);

                            // JIS変換情報マスタ一括新規データ設定
                            msJisHenkanJohosListInsert.add(upd);
                        }

                    } else {
                        // 仕向地変換情報処理
                        if ((null == i.get("addFlg") || "".equals(objectToString(i.get("addFlg"))))
                                && "UPD".equals(objectToString(i.get("setFlg")))) {
                            Map msShimukeChiHenkanJohoMap = new HashMap<>();
                            // 更新項目初期化
                            MsShimukeChiHenkanJoho upd = new MsShimukeChiHenkanJoho();
                            // 変換情報住所
                            upd.setHenkanJohoJusho(objectToString(i.get("hnknDtlListHenkanJohoJusho")));
                            // 旧住所フラグ 
                            boolean kyuJushoFlg = Boolean.valueOf(i.get("hnknDtlListKyuJushoFlg").toString());
                            if (kyuJushoFlg == true) {
                                upd.setKyuJushoFlg("1");
                            } else {
                                upd.setKyuJushoFlg("0");
                            }
                            // 削除フラグ
                            upd.setSakujoFlg(objectToString(i.get("hnknDtlListHSakujoFlg")));
                            // データバージョン
                            upd.setJushoJisDataVersion(Integer.parseInt(
                                    i.get("hnknDtlListJushoJisDataVer").toString()) + 1);
                            // 更新ユーザー
                            upd.setKoshinUser(userCd);
                            // 更新日時
                            upd.setKoshinNichiji(koshinData);
                            // 更新端末
                            upd.setKoshinTammatsu(koshinTammatsu);
                            // 更新営業所
                            upd.setKoshinEigyosho(koshinEigyosho);
                            // 最終オペレーションユーザー
                            upd.setSaishuOperationUser(saishuOperationUser);
                            // 最終オペレーション更新日時
                            upd.setSaishuOperationKoshinNichiji(saishuOperationKoshinNichiji);
                            // 更新項目設定
                            msShimukeChiHenkanJohoMap.put(BaseDao.UPDATE_BEAN_UPD, upd);

                            // 更新条件初期化
                            MsShimukeChiHenkanJoho crt = new MsShimukeChiHenkanJoho();
                            // JISコード
                            crt.setJisCd(jisCd);
                            // 適用開始日
                            crt.setTekiyoKaishibi(tekiyoKaishibi);
                            // 仕向地コード
                            crt.setShimukeChiCd(shimukeChiCd);
                            // JIS変換情報シーケンス
                            crt.setShimukeChiHenkanJohoSeq(Integer.parseInt(
                                    objectToString(i.get("hnknDtlListHHenkanJohoSeq"))));
                            // 更新条件設定
                            msShimukeChiHenkanJohoMap.put(BaseDao.UPDATE_BEAN_CRT, crt);

                            // 仕向地変換情報マスタ一括更新データ設定
                            msShimukeChiHenkanJohoListUpdate.add(msShimukeChiHenkanJohoMap);

                            // バージョンチェック(排他)
                            paraMap = new HashMap<>();
                            // JISコード
                            paraMap.put("JIS_CD", jisCd);
                            // 適用開始日
                            paraMap.put("TEKIYO_KAISHIBI", tekiyoKaishibi);
                            // 仕向地コード
                            paraMap.put("SHIMUKE_CHI_CD", shimukeChiCd);
                            // JIS変換情報シーケンス
                            paraMap.put("SHIMUKE_CHI_HENKAN_JOHO_SEQ", i.get("hnknDtlListHHenkanJohoSeq"));
                            // 更新ユーザーID
                            paraMap.put("koushinUserCd", i.get("hnknDtlListKoushinUserCd"));
                            // 更新カウンタ
                            paraMap.put("koushinCounter", i.get("hnknDtlListKoushinCounter"));
                            // 変換情報住所
                            paraMap.put("msgJusho", i.get("hnknDtlListHenkanJohoJusho"));
                            // テーブル名
                            paraMap.put("tblName", "MS_SHIMUKE_CHI_HENKAN_JOHO");
                            boolean haitaFlg = haitaCheckVersion(serviceInterfaceBean, paraMap);
                            if (!haitaFlg) {
                                return;
                            }
                        } else if (null != i.get("addFlg")) {
                            // 更新項目初期化
                            MsShimukeChiHenkanJoho upd = new MsShimukeChiHenkanJoho();
                            // JISコード
                            upd.setJisCd(jisCd);
                            // 適用開始日
                            upd.setTekiyoKaishibi(tekiyoKaishibi);
                            // 仕向地コード
                            upd.setShimukeChiCd(shimukeChiCd);
                            // 変換情報住所
                            upd.setHenkanJohoJusho(objectToString(i.get("hnknDtlListHenkanJohoJusho")));
                            // 旧住所フラグ 
                            boolean kyuJushoFlg = Boolean.valueOf(i.get("hnknDtlListKyuJushoFlg").toString());
                            if (kyuJushoFlg == true) {
                                upd.setKyuJushoFlg("1");
                            } else {
                                upd.setKyuJushoFlg("0");
                            }
                            // 行削除フラグ
                            upd.setSakujoFlg("0");
                            // データバージョン
                            upd.setJushoJisDataVersion(1);
                            // 更新カントー
                            upd.setKoshinCounter(Long.valueOf("0"));
                            // 登録ユーザー
                            upd.setTorokuUser(userCd);
                            // 登録日時
                            upd.setTorokuNichiji(koshinData);
                            // 登録端末
                            upd.setTorokuTammatsu(koshinTammatsu);
                            // 登録営業所
                            upd.setTorokuEigyosho(koshinEigyosho);
                            // 最終オペレーションユーザー
                            upd.setSaishuOperationUser(saishuOperationUser);
                            // 最終オペレーション更新日時
                            upd.setSaishuOperationKoshinNichiji(saishuOperationKoshinNichiji);

                            // 仕向地変換情報マスタ一括新規データ設定
                            msShimukeChiHenkanJohoListInsert.add(upd);
                        }
                    }
                }

            }
        }

        // JIS変換情報マスタ一括更新
        if (msJisHenkanJohosListUpdate.size() > 0) {
            jisHenkanJohoDao.updateById(msJisHenkanJohosListUpdate);
        }
        // JIS変換情報マスタ一括追加
        if (msJisHenkanJohosListInsert.size() > 0) {
            mst032Dao.jisHenkanJohoInsert(msJisHenkanJohosListInsert);
        }
        // 仕向地変換情報マスタ一括更新
        if (msShimukeChiHenkanJohoListUpdate.size() > 0) {
            shimukeChiHenkanJohoDao.updateById(msShimukeChiHenkanJohoListUpdate);
        }
        // 仕向地変換情報マスタ一括追加
        if (msShimukeChiHenkanJohoListInsert.size() > 0) {
            mst032Dao.shimukeChiHenkanJohoInsert(msShimukeChiHenkanJohoListInsert);
        }
    }

    /**
     * 住所離島マスタ更新
     *
     * @param serviceInterfaceBean JSFからの通信情報
     * @param ritoUpdList 住所離島データ更新リスト
     */
    private void msJushoRitoUpdate(ServiceInterfaceBean serviceInterfaceBean, List<Map<String, Object>> ritoUpdList) {

        // 住所離島マスタ一括更新
        List<Map<String, MsJushoRito>> msJushoRitoMapList = new ArrayList<>();
        // バージョンチェック(排他)
        Map<String, Object> paraMap;
        // 更新処理
        for (Map<String, Object> rec : ritoUpdList) {
            Map msJushoRitoMap = new HashMap<>();
            // 更新項目
            MsJushoRito upd = new MsJushoRito();
            // 離島住所
            upd.setRitoJusho(objectToString(rec.get("rtDtlListJusho")));
            // 島名
            upd.setShimaMei(objectToString(rec.get("rtDtlListShimaMei")));
            // 備考
            upd.setBiko(objectToString(rec.get("rtDtlListBiko")));
            // データバージョン
            upd.setJushoJisDataVersion(Integer.parseInt(rec.get("rtDtlListJushoJisDataVer").toString()) + 1);
            // 更新ユーザー
            upd.setKoshinUser(userCd);
            // 更新日時
            upd.setKoshinNichiji(koshinData);
            // 更新端末
            upd.setKoshinTammatsu(koshinTammatsu);
            // 更新営業所
            upd.setKoshinEigyosho(koshinEigyosho);
            // 最終オペレーションユーザー
            upd.setSaishuOperationUser(saishuOperationUser);
            // 最終オペレーション更新日時
            upd.setSaishuOperationKoshinNichiji(saishuOperationKoshinNichiji);

            // 更新項目設定
            msJushoRitoMap.put(BaseDao.UPDATE_BEAN_UPD, upd);
            // 更新条件
            MsJushoRito crt = new MsJushoRito();
            // JISコード
            crt.setJisCd(jisCd);
            // 適用開始日
            crt.setTekiyoKaishibi(tekiyoKaishibi);
            // 住所離島シーケンス
            crt.setJushoRitoSeq(Integer.parseInt(objectToString(rec.get("rtDtlListHJushoRitoSeq"))));
            // 更新条件設定
            msJushoRitoMap.put(BaseDao.UPDATE_BEAN_CRT, crt);
            msJushoRitoMapList.add(msJushoRitoMap);

            // バージョンチェック(排他)
            paraMap = new HashMap<>();
            // JISコード
            paraMap.put("JIS_CD", jisCd);
            // 適用開始日
            paraMap.put("TEKIYO_KAISHIBI", tekiyoKaishibi);
            // 住所離島シーケンス
            paraMap.put("JUSHO_RITO_SEQ", rec.get("rtDtlListHJushoRitoSeq"));
            // 更新ユーザーID
            paraMap.put("koushinUserCd", rec.get("rtDtlListKoushinUserCd"));
            // 更新カウンタ
            paraMap.put("koushinCounter", rec.get("rtDtlListKoushinCounter"));
            // 島名+住所
            paraMap.put("msgJusho", objectToString(rec.get("rtDtlListShimaMei"))
                    + objectToString(rec.get("rtDtlListJusho")));
            // テーブル名
            paraMap.put("tblName", "MS_JUSHO_RITO");
            boolean haitaFlg = haitaCheckVersion(serviceInterfaceBean, paraMap);
            if (!haitaFlg) {
                return;
            }
        }
        // 住所離島マスタ更新
        jushoRitoDao.updateById(msJushoRitoMapList);
    }

    /**
     * 住所離島マスタ新規
     *
     * @param ritoAddList 住所離島データ新規リスト
     */
    private void msJushoRitoInsert(List<Map<String, Object>> ritoAddList) {

        // 住所離島マスタ一括追加
        List< MsJushoRito> msJushoRitoList = new ArrayList<>();
        // 更新処理
        for (Map<String, Object> rec : ritoAddList) {
            // 更新項目
            MsJushoRito upd = new MsJushoRito();
            // JISコード
            upd.setJisCd(jisCd);
            // 適用開始日
            upd.setTekiyoKaishibi(tekiyoKaishibi);
            // 離島住所
            upd.setRitoJusho(objectToString(rec.get("rtDtlListJusho")));
            // 島名
            upd.setShimaMei(objectToString(rec.get("rtDtlListShimaMei")));
            // 備考
            upd.setBiko(objectToString(rec.get("rtDtlListBiko")));
            // 削除フラグ
            upd.setSakujoFlg("0");
            // データバージョン
            upd.setJushoJisDataVersion(1);
            // 更新カントー
            upd.setKoshinCounter(Long.valueOf("0"));
            // 登録ユーザー
            upd.setTorokuUser(userCd);
            // 登録日時
            upd.setTorokuNichiji(koshinData);
            // 登録端末
            upd.setTorokuTammatsu(koshinTammatsu);
            // 登録営業所
            upd.setTorokuEigyosho(koshinEigyosho);
            // 最終オペレーションユーザー
            upd.setSaishuOperationUser(saishuOperationUser);
            // 最終オペレーション更新日時
            upd.setSaishuOperationKoshinNichiji(saishuOperationKoshinNichiji);
            msJushoRitoList.add(upd);
        }
        // 住所離島マスタ新規
        mst032Dao.jushoRitoJohoInsert(msJushoRitoList);
    }

    /**
     * 住所館内配送マスタ更新
     *
     * @param serviceInterfaceBean JSFからの通信情報
     * @param kannaiUpdList 住所館内配送データ更新リスト
     */
    private void msJushoKannaihaisoUpdate(ServiceInterfaceBean serviceInterfaceBean,
            List<Map<String, Object>> kannaiUpdList) {

        // 住所館内配送マスタ一括更新
        List<Map<String, MsJushoKannaihaiso>> msJushoKannaihaisoMapList = new ArrayList<>();
        // バージョンチェック(排他)
        Map<String, Object> paraMap;
        // 更新処理
        for (Map<String, Object> rec : kannaiUpdList) {
            Map msJushoKannaihaisoMap = new HashMap<>();
            // 更新項目
            MsJushoKannaihaiso upd = new MsJushoKannaihaiso();
            // 施設名
            upd.setShisetsuMei(objectToString(rec.get("khDtlListShisetsuMei")));
            // 館内配送住所
            upd.setKannaihaisoJusho(objectToString(rec.get("khDtlListJusho")));
            // 備考
            upd.setBiko(objectToString(rec.get("khDtlListBiko")));
            // データバージョン
            upd.setJushoJisDataVersion(Integer.parseInt(rec.get("khDtlListJushoJisDataVer").toString()) + 1);
            // 更新ユーザー
            upd.setKoshinUser(userCd);
            // 更新日時
            upd.setKoshinNichiji(koshinData);
            // 更新端末
            upd.setKoshinTammatsu(koshinTammatsu);
            // 更新営業所
            upd.setKoshinEigyosho(koshinEigyosho);
            // 最終オペレーションユーザー
            upd.setSaishuOperationUser(saishuOperationUser);
            // 最終オペレーション更新日時
            upd.setSaishuOperationKoshinNichiji(saishuOperationKoshinNichiji);

            // 更新項目設定
            msJushoKannaihaisoMap.put(BaseDao.UPDATE_BEAN_UPD, upd);
            // 更新条件
            MsJushoKannaihaiso crt = new MsJushoKannaihaiso();
            // JISコード
            crt.setJisCd(jisCd);
            // 適用開始日
            crt.setTekiyoKaishibi(tekiyoKaishibi);
            // 住所館内配送シーケンス
            crt.setJushoKannaihaisoSeq(Integer.parseInt(objectToString(rec.get("khDtlListHJushoKannaihaisoSeq"))));
            // 更新条件設定
            msJushoKannaihaisoMap.put(BaseDao.UPDATE_BEAN_CRT, crt);
            msJushoKannaihaisoMapList.add(msJushoKannaihaisoMap);

            // バージョンチェック(排他)
            paraMap = new HashMap<>();
            // JISコード
            paraMap.put("JIS_CD", jisCd);
            // 適用開始日
            paraMap.put("TEKIYO_KAISHIBI", tekiyoKaishibi);
            // 住所館内配送シーケンス
            paraMap.put("JUSHO_KANNAIHAISO_SEQ", rec.get("khDtlListHJushoKannaihaisoSeq"));
            // 更新ユーザーID
            paraMap.put("koushinUserCd", rec.get("khDtlListKoushinUserCd"));
            // 更新カウンタ
            paraMap.put("koushinCounter", rec.get("khDtlListKoushinCounter"));
            // 施設名+住所
            paraMap.put("msgJusho", objectToString(rec.get("khDtlListShisetsuMei"))
                    + objectToString(rec.get("khDtlListJusho")));
            // テーブル名
            paraMap.put("tblName", "MS_JUSHO_KANNAIHAISO");
            boolean haitaFlg = haitaCheckVersion(serviceInterfaceBean, paraMap);
            if (!haitaFlg) {
                return;
            }
        }
        // 住所館内配送マスタ更新
        jushoKannaihaisoDao.updateById(msJushoKannaihaisoMapList);
    }

    /**
     * 住所館内配送マスタ新規
     *
     * @param kannaiUpdList 住所館内配送データ新規リスト
     */
    private void msJushoKannaihaisoInsert(List<Map<String, Object>> kannaiAddList) {

        // 住所館内配送マスタ一括追加
        List<MsJushoKannaihaiso> msJushoKannaihaisoList = new ArrayList<>();
        // 更新処理
        for (Map<String, Object> rec : kannaiAddList) {
            // 更新項目
            MsJushoKannaihaiso upd = new MsJushoKannaihaiso();
            // JISコード
            upd.setJisCd(jisCd);
            // 適用開始日
            upd.setTekiyoKaishibi(tekiyoKaishibi);
            // 施設名
            upd.setShisetsuMei(objectToString(rec.get("khDtlListShisetsuMei")));
            // 館内配送住所
            upd.setKannaihaisoJusho(objectToString(rec.get("khDtlListJusho")));
            // 備考
            upd.setBiko(objectToString(rec.get("khDtlListBiko")));
            // 削除フラグ
            upd.setSakujoFlg("0");
            // データバージョン
            upd.setJushoJisDataVersion(1);
            // 更新カントー
            upd.setKoshinCounter(Long.valueOf("0"));
            // 更新ユーザー
            upd.setTorokuUser(userCd);
            // 更新日時
            upd.setTorokuNichiji(koshinData);
            // 更新端末
            upd.setTorokuTammatsu(koshinTammatsu);
            // 更新営業所
            upd.setTorokuEigyosho(koshinEigyosho);
            // 最終オペレーションユーザー
            upd.setSaishuOperationUser(saishuOperationUser);
            // 最終オペレーション更新日時
            upd.setSaishuOperationKoshinNichiji(saishuOperationKoshinNichiji);

            msJushoKannaihaisoList.add(upd);
        }
        // 住所館内配送マスタ新規
        mst032Dao.jushoKannaiHaisoInsert(msJushoKannaihaisoList);
    }

    /**
     * 施設表示名情報マスタ更新
     *
     * @param serviceInterfaceBean JSFからの通信情報
     * @param shisetsuJohoListMap 施設表示名情報データ更新リスト
     */
    private void msShisetsuHyojiMeiJohoInsertUpdate(
            ServiceInterfaceBean serviceInterfaceBean, Map<String, Object> shisetsuJohoListMap) {

        // 施設表示名情報マスタ一括更新
        List<Map<String, MsShisetsuHyojiMeiJoho>> msShisetsuHyojiMeiJohoListUpdate = new ArrayList<>();
        // 施設表示名情報マスタ一括追加
        List<MsShisetsuHyojiMeiJoho> msShisetsuHyojiMeiJohoListInsert = new ArrayList<>();
        // バージョンチェック(排他)
        Map<String, Object> paraMap;
        for (Entry<String, Object> entry : shisetsuJohoListMap.entrySet()) {
            // キー取得
            String key = entry.getKey();
            // 住所館内配送シーケンス
            int haisoSeq = Integer.parseInt(key);

            // 施設表示名情報リスト取得
            List<Map<String, Object>> resList = (List<Map<String, Object>>) entry.getValue();
            if (resList.size() > 0) {
                Iterator<Map<String, Object>> ite = resList.iterator();
                while (ite.hasNext()) {
                    Map<String, Object> i = ite.next();
                    if ((null == i.get("addFlg") || "".equals(objectToString(i.get("addFlg"))))
                            && "UPD".equals(objectToString(i.get("setFlg")))) {
                        Map msShisetsuHyojiMeiJohoMap = new HashMap<>();
                        // 更新項目初期化
                        MsShisetsuHyojiMeiJoho upd = new MsShisetsuHyojiMeiJoho();
                        // 表示名
                        upd.setHyojiMei(objectToString(i.get("shstDtlListHyojiMei")));
                        // 削除フラグ
                        upd.setSakujoFlg(objectToString(i.get("shstDtlListHSakujoFlg")));
                        // データバージョン
                        upd.setJushoJisDataVersion(
                                Integer.parseInt(i.get("shstDtlListJushoJisDataVer").toString()) + 1);
                        // 更新ユーザー
                        upd.setKoshinUser(userCd);
                        // 更新日時
                        upd.setKoshinNichiji(koshinData);
                        // 更新端末
                        upd.setKoshinTammatsu(koshinTammatsu);
                        // 更新営業所
                        upd.setKoshinEigyosho(koshinEigyosho);
                        // 最終オペレーションユーザー
                        upd.setSaishuOperationUser(saishuOperationUser);
                        // 最終オペレーション更新日時
                        upd.setSaishuOperationKoshinNichiji(saishuOperationKoshinNichiji);
                        // 更新項目設定
                        msShisetsuHyojiMeiJohoMap.put(BaseDao.UPDATE_BEAN_UPD, upd);

                        // 更新条件初期化
                        MsShisetsuHyojiMeiJoho crt = new MsShisetsuHyojiMeiJoho();
                        // JISコード
                        crt.setJisCd(jisCd);
                        // 適用開始日
                        crt.setTekiyoKaishibi(tekiyoKaishibi);
                        // 住所館内配送シーケンス
                        crt.setJushoKannaihaisoSeq(haisoSeq);
                        // 施設表示名シーケンス
                        crt.setShisetsuHyojiMeiSeq(
                                Integer.parseInt(objectToString(i.get("shstDtlListHShisetsuHyojiMeiSeq"))));
                        // 更新条件設定
                        msShisetsuHyojiMeiJohoMap.put(BaseDao.UPDATE_BEAN_CRT, crt);

                        // 施設表示名情報マスタ一括更新データ設定
                        msShisetsuHyojiMeiJohoListUpdate.add(msShisetsuHyojiMeiJohoMap);

                        // バージョンチェック(排他)
                        paraMap = new HashMap<>();
                        // JISコード
                        paraMap.put("JIS_CD", jisCd);
                        // 適用開始日
                        paraMap.put("TEKIYO_KAISHIBI", tekiyoKaishibi);
                        // 住所館内配送シーケンス
                        paraMap.put("JUSHO_KANNAIHAISO_SEQ", haisoSeq);
                        // 施設表示名シーケンス
                        paraMap.put("SHISETSU_HYOJI_MEI_SEQ", i.get("shstDtlListHShisetsuHyojiMeiSeq"));
                        // 更新ユーザーID
                        paraMap.put("koushinUserCd", i.get("shstDtlListKoushinUserCd"));
                        // 更新カウンタ
                        paraMap.put("koushinCounter", i.get("shstDtlListKoushinCounter"));
                        // 表示名
                        paraMap.put("msgJusho", i.get("shstDtlListHyojiMei"));
                        // テーブル名
                        paraMap.put("tblName", "MS_SHISETSU_HYOJI_MEI_JOHO");
                        boolean haitaFlg = haitaCheckVersion(serviceInterfaceBean, paraMap);
                        if (!haitaFlg) {
                            return;
                        }
                    } else if (null != i.get("addFlg")) {
                        // 更新項目初期化
                        MsShisetsuHyojiMeiJoho upd = new MsShisetsuHyojiMeiJoho();
                        // JISコード
                        upd.setJisCd(jisCd);
                        // 適用開始日
                        upd.setTekiyoKaishibi(tekiyoKaishibi);
                        // 住所館内配送シーケンス
                        upd.setJushoKannaihaisoSeq(haisoSeq);
                        // 表示名
                        upd.setHyojiMei(objectToString(i.get("shstDtlListHyojiMei")));
                        // 削除フラグ
                        upd.setSakujoFlg("0");
                        // データバージョン
                        upd.setJushoJisDataVersion(1);
                        // 更新カントー
                        upd.setKoshinCounter(Long.valueOf("0"));
                        // 登録ユーザー
                        upd.setTorokuUser(userCd);
                        // 登録日時
                        upd.setTorokuNichiji(koshinData);
                        // 登録端末
                        upd.setTorokuTammatsu(koshinTammatsu);
                        // 登録営業所
                        upd.setTorokuEigyosho(koshinEigyosho);
                        // 最終オペレーションユーザー
                        upd.setSaishuOperationUser(saishuOperationUser);
                        // 最終オペレーション更新日時
                        upd.setSaishuOperationKoshinNichiji(saishuOperationKoshinNichiji);

                        // 施設表示名情報マスタ一括新規データ設定
                        msShisetsuHyojiMeiJohoListInsert.add(upd);
                    }
                }
            }
        }

        // 施設表示名情報マスタ一括更新
        if (msShisetsuHyojiMeiJohoListUpdate.size() > 0) {
            shisetsuHyojiMeiJohoDao.updateById(msShisetsuHyojiMeiJohoListUpdate);
        }
        // 施設表示名情報マスタ一括追加
        if (msShisetsuHyojiMeiJohoListInsert.size() > 0) {
            mst032Dao.shisetsuHyojiMeiJohoInsert(msShisetsuHyojiMeiJohoListInsert);
        }
    }

    /**
     * バージョン排他チェック
     *
     * @param serviceInterfaceBean JSFからの通信情報
     * @param paraMap 各テーブル排他用パラメータ
     * @return 排他チェック結果
     */
    private boolean haitaCheckVersion(ServiceInterfaceBean serviceInterfaceBean, Map<String, Object> paraMap) {
        // バージョンチェック(排他)
        if (!busVersionCheck.checkVersion(paraMap)) {
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(1));
            // エラーメッセージを表示させ、処理を終了
            serviceInterfaceBean.addMessage("WARN", MessageCnst.COME0014,
                    paraMap.get("msgJusho").toString());
            serviceInterfaceBean.setTableName(paraMap.get("tblName").toString());
            return false;
        }
        return true;
    }
}
