package jp.co.kintetsuls.biz.common.authority.dao;

import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.biz.common.authority.model.AuthorityOffice;
import jp.co.kintetsuls.biz.base.dao.BaseDao;
import org.springframework.stereotype.Component;

/** 利用可能機能権限処理クラス
 */
@Component
public class AuthorityOfficeDao extends BaseDao<AuthorityOffice> {

    public List<Map<String, String>> getAccessibleOffice(String userCd){
        return getSqlSession().selectList("office.getAccessibleOffice", userCd);
    }
    
    public String getDefaultEigyosho(String userCd){
        return getSqlSession().selectOne("office.getDefaultEigyosho", userCd);
    }

    public String getEigyoshoShubetsu(Map<String,Object> searchCriteria){
        return getSqlSession().selectOne("office.getEigyoshoShubetsu", searchCriteria);
    }
}
