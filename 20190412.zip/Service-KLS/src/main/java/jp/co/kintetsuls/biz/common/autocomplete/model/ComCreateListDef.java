package jp.co.kintetsuls.biz.common.autocomplete.model;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/** 
 * Sample model
 * @author sharedsys
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "createList")
public class ComCreateListDef implements Serializable{

    private static final long serialVersionUID = 8225066323266434396L;

    private String value;
    private String label;
    
    @XmlElement(name = "value")
    public String getValue() {
        return value;
    }
    public void setValue(String value) {
        this.value = value;
    }

    @XmlElement(name = "label")
    public String getLabel() {
        return label;
    }
    public void setLabel(String label) {
        this.label = label;
    }   
}
