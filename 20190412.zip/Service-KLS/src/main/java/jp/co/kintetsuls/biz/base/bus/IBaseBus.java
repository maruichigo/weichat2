/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.biz.base.bus;

import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import org.springframework.web.context.WebApplicationContext;

/**
 *
 * @author klsproj
 */
public interface IBaseBus {

    public WebApplicationContext wac = null;
    public void setWebApplicationContext (WebApplicationContext wac);
    
    void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception;
    
}
