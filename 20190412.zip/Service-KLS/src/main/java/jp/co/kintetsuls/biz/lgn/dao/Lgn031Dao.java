/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.lgn.dao;

import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.biz.base.dao.BaseDao;
import jp.co.kintetsuls.biz.lgn.model.Lgn031Def;
import org.springframework.stereotype.Repository;

/**
 * パスワード初期化 Dao
 *
 * @author 黄義輝 (MBP)
 * @version 2019/1/6 新規作成
 */
@Repository
public class Lgn031Dao extends BaseDao<Lgn031Def>{
    
    /**
     * 承認者情報の取得
     *
     * @param searchCriteria 検索条件
     * @return 実行結果
     */
    public List<Map<String, String>> findForSearchShoninshaInfo (Map<String, Object> searchCriteria) {
        return getSqlSession().selectList("lgn031.findToShoninshaInfoMap", searchCriteria);
    }

    /**
     * 申請情報取得
     *
     * @param searchCriteria 検索条件
     * @return 実行結果
     */
    public List<Lgn031Def> findForShinseiInfo (Map<String, Object> searchCriteria) {
        return getSqlSession().selectList("lgn031.findToShinseiInfoMap", searchCriteria);
    }

    /**
     * 承認状況取得
     *
     * @param searchCriteria 検索条件
     * @return 実行結果
     */
    public List<Lgn031Def> findForSyouninJyoukyou (Map<String, Object> searchCriteria) {
        return getSqlSession().selectList("lgn031.findToSyouninJyoukyouMap", searchCriteria);
    }

    /**
     * 次段階の申請プロセスアクティビティを取得
     *
     * @param searchCriteria 検索条件
     * @return 実行結果
     */
    public List<Lgn031Def> findForShinseiProcessActivityInfo (Map<String, Object> searchCriteria) {
        return getSqlSession().selectList("lgn031.findToShinseiProcessActivityMap", searchCriteria);
    }

    /**
     * 全段階の申請プロセスアクティビティ情報を取得する。
     *
     * @param searchCriteria 検索条件
     * @return 実行結果
     */
    public List<Lgn031Def> findForShinseiProcessActivityTeigiInfo (
            Map<String, Object> searchCriteria) {
        return getSqlSession().selectList("lgn031.findToShinseiProcessActivityTeigiMap", searchCriteria);
    }

    /**
     * 現段階アクティビティNOと、次申請プロセスアクティビティNOの取得を行う。
     *
     * @param searchCriteria 検索条件
     * @return 実行結果
     */
    public List<Lgn031Def> findForShoninInfo (Map<String, Object> searchCriteria) {
        return getSqlSession().selectList("lgn031.findToShoninInfoMap", searchCriteria);
    }

    /**
     * ワーク.ユーザーコードに入力されたユーザーのデフォルト所属箇所取得を行う。
     *
     * @param searchCriteria 検索条件
     * @return 実行結果
     */
    public List<Lgn031Def> findForUserDefaultEigyosho (Map<String, Object> searchCriteria) {
        return getSqlSession().selectList("lgn031.findToUserDefaultEigyoshoMap", searchCriteria);
    }

    /**
     * ユーザーコードの存在チェック
     * 
     * @param searchCriteria 検索条件
     * @return 実行結果
     */
    public int countUserCdForDoapply (Map<String, Object> searchCriteria) {
        return getSqlSession().selectOne("lgn031.countUserCdToInt", searchCriteria);
    }

    /**
     * ユーザーコードとメールアドレスの組み合わせが存在するかチェック
     * 
     * @param searchCriteria 検索条件
     * @return 実行結果
     */
    public int countUserCdMailAddressForDoapply (Map<String, Object> searchCriteria) {
        return getSqlSession().selectOne("lgn031.countUserCdMailAddressToInt", searchCriteria);
    }

    /**
     * 申請ID毎の申請詳細NOの最大値
     * 
     * @param searchCriteria 検索条件
     * @return 実行結果
     */
    public int countShinseiShosaiNoMax (Map<String, Object> searchCriteria) {
        return getSqlSession().selectOne("lgn031.countShinseiShosaiNoMaxToInt", searchCriteria);
    }

}