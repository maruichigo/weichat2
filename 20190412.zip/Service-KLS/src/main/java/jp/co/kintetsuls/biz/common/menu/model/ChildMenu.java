package jp.co.kintetsuls.biz.common.menu.model;

import java.io.Serializable;
import java.util.List;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/** 
 * メニューマスタクラス
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "childMenu")
public class ChildMenu implements Serializable{

    private static final long serialVersionUID = 8965633291910057625L;

    @Size(max = 20)
    private String childGroupId;

    private String childGroupName;

    private List<MenuItem> items;

    /**子メニューグループIDの取得
     * @return 子メニューグループID
     */
    @XmlElement(name = "childGroupId")
    public String getChildGroupId() {
        return childGroupId;
    }
    /**子メニューグループIDの設定
     * @param childGroupId 子メニューグループID
     */
    public void setChildGroupId(String childGroupId) {
        this.childGroupId = childGroupId;
    }
    /**子メニューグループ名の取得
     * @return 子メニューグループ名
     */
    @XmlElement(name = "childGroupName")
    public String getChildGroupName() {
        return childGroupName;
    }
    /**子メニューグループ名の設定
     * @param childGroupName 子メニューグループ名
     */
    public void setChildGroupName(String childGroupName) {
        this.childGroupName = childGroupName;
    }
    /**
     * 子メニューリストを取得する
     * @return 
     */
    public List<MenuItem> getItems() {
        return items;
    }
    /**
     * 子メニューリストを格納する
     * @param items 
     */
    public void setItems(List<MenuItem> items) {
        this.items = items;
    }
    
}
