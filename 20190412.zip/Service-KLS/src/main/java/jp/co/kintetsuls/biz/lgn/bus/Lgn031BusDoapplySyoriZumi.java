/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.lgn.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.HashMap;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import java.util.Map;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.lgn.dao.Lgn031Dao;
import jp.co.kintetsuls.biz.table.dao.TrShinseiShosaiDao;
import jp.co.kintetsuls.biz.table.model.TrShinseiShosai;
import jp.co.kintetsuls.common.SystemColumn;
import jp.co.kintetsuls.common.cnst.StndConsIF;
import jp.co.kintetsuls.utils.DateUtils;

/**
 * 申請詳細登録(処理完了)
 *
 * @author 黄義輝 (MBP)
 * @version 2019/04/01 新規作成
 */
@Component("LGN031_DOAPPLY_SYORIZUMI")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Lgn031BusDoapplySyoriZumi extends BaseBus {

    /**
     * Lgn031Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected Lgn031Dao lgn031Dao;

    /**
     * 申請詳細Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected TrShinseiShosaiDao trShinseiShosaiDao;

    /**
     * 申請詳細定義
     */
    protected TrShinseiShosai trShinseiShosai;

    /**
     * 申請詳細登録(処理完了)
     * 
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {

        // パラメータを解析する
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> param = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

        // ワーク.申請ID
        String shinseiId = "";

        shinseiId = objectToString(param.get("shinseiId"));

        // 5.申請詳細登録(処理完了)
        trShinseiShosai = new TrShinseiShosai();
        // システムカラム
        trShinseiShosai = SystemColumn.systemColumnSet(StndConsIF.SYSCOL_INSERT, trShinseiShosai, serviceInterfaceBean);
        // 申請ID
        trShinseiShosai.setShinseiId(shinseiId);
        // 申請詳細NO
        trShinseiShosai.setShinseiShosaiNo(getShinseiShosaiNoMax(shinseiId) + 1);
        // 承認状況結果
        trShinseiShosai.setShoninJokyoKekka("05");
        // ステータス更新日時
        trShinseiShosai.setKoshinBi(DateUtils.getSysDate());
        // 削除フラグ
        trShinseiShosai.setSakujoFlg("0");

        // 申請詳細登録(申請(処理完了))
        trShinseiShosaiDao.insert(trShinseiShosai);
    }

    /**
     * 申請ID毎の申請詳細NOの最大値
     * 
     * @param shinseiId 申請ID
     * @return 申請ID毎の申請詳細NOの最大値
     */
    private int getShinseiShosaiNoMax(String shinseiId) {
        Map paramMap = new HashMap();

        paramMap.put("shinseiId", shinseiId);
        
        return lgn031Dao.countShinseiShosaiNoMax(paramMap);

    }

}