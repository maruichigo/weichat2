/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.mst.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.mst.dao.Mst071Dao;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.cnst.MessageCnst;
import jp.co.kintetsuls.common.json.JSONUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

/**
 * 集約コードマスタ削除存在チェック処理
 *
 * @author 许博 (MBP)
 * @version 2019/2/12 新規作成
 */
@Component("MST071_DELETE_EXIST")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Mst071BusDeleteCheck extends BaseBus {

    /**
     * Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected Mst071Dao mst071Dao;
    
    /**
     * 文字列：集約コードマスタ
     */
    private static final String SHUYAKU_CD_MASTER = "集約コードマスタ";

    /**
     * 集約コードマスタ削除存在チェック処理
     *
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {

        // チェックパラメータ
        Map<String, Object> param = null;
        
        // パラメータを解析する
        ObjectMapper mapper = new ObjectMapper();
        List<Map<String, Object>> recordList = mapper.readValue(serviceInterfaceBean.getJson(), List.class);
        
        int count = 0;
        if (recordList != null && recordList.size() > 0) {
            
            for (Map<String, Object> record : recordList) { 
                param = new HashMap();
                //　集約コード
                param.put("listShuyakuCd", record.get("listShuyakuCd"));
                // 営業所コード
                param.put("listEigyoshoCd", record.get("listEigyoshoCd"));
                // 集約区分
                param.put("listShuyakuKbn", record.get("listShuyakuKbn"));

                // データが存在しない場合
                if (0 == mst071Dao.countForInsertUpdate(param)) {
                    count++;
                    serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                    serviceInterfaceBean.setJson(JSONUtil.makeJSONString(count));
                    // エラーメッセージを表示させ、処理を終了
                    serviceInterfaceBean.addMessage("ERROR", MessageCnst.MSTE0049, "");
                    serviceInterfaceBean.setTableName(SHUYAKU_CD_MASTER);
                    return;
                }
            }
        }
    }
}
