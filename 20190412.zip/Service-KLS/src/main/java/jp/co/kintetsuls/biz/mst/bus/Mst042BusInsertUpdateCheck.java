/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.mst.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import java.util.Map;
import javax.annotation.Resource;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.table.dao.MsEigyoshoDao;
import jp.co.kintetsuls.biz.table.dao.MsEigyoshoGroupDao;
import jp.co.kintetsuls.biz.table.dao.MsGinkoKozaDao;
import jp.co.kintetsuls.biz.table.dao.MsJisCdDao;
import jp.co.kintetsuls.biz.table.dao.MsJushoDao;
import jp.co.kintetsuls.biz.table.dao.MsKukoDao;
import jp.co.kintetsuls.biz.table.model.MsEigyosho;
import jp.co.kintetsuls.biz.table.model.MsEigyoshoGroup;
import jp.co.kintetsuls.biz.table.model.MsGinkoKoza;
import jp.co.kintetsuls.biz.table.model.MsJisCd;
import jp.co.kintetsuls.biz.table.model.MsJusho;
import jp.co.kintetsuls.biz.table.model.MsKuko;
import jp.co.kintetsuls.common.cnst.MessageCnst;
import jp.co.kintetsuls.common.json.JSONUtil;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.kintetsuls.utils.StrUtils;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 営業所マスタ詳細の登録/更新のチェック処理
 *
 * @author 雷珍 (MBP)
 * @version 2019/3/19 新規作成
 */
@Component("MST042_INSERT_UPDATE_CHECK")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Mst042BusInsertUpdateCheck extends BaseBus {

    /**
     * 営業所マスタDAO定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsEigyoshoDao msEigyoshoDao;
    
    /**
     * 営業所グループマスタDAO定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsEigyoshoGroupDao msEigyoshoGroupDao;
    
    /**
     * JISコードマスタDAO定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsJisCdDao msJisCdDao;
    
    /**
     * 空港マスタDAO定義 
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsKukoDao msKukoDao;
    
    /**
     * 住所マスタDAO定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsJushoDao msJushoDao;
    
    /**
     * 銀行口座マスタDAO定義  
     */      
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsGinkoKozaDao msGinkoKozaDao;
    
    /**
     * 文字列：テーブル営業所マスタ
     */
    private static final String EIGYOSHO = "営業所マスタ";
    
    /**
     * 文字列：営業所グループマスタ
     */
    private static final String EIGYOSHO_GROUP = "営業所グループマスタ";
    
    /**
     * 文字列：JISコードマスタ
     */
    private static final String JIS_CD = "JISコードマスタ";
    
    /**
     * 文字列：空港マスタ
     */
    private static final String KUKO = "空港マスタ";
    
    /**
     * 文字列：住所マスタ
     */
    private static final String JUSHO = "住所マスタ";
    
    /**
     * 文字列：銀行口座マスタ
     */
    private static final String GINKO_KOZA = "銀行口座マスタ";
    
     /**
     *  定数：登録/更新対象 = 0(登録)
     */
    private static final String SHINKI_FLG = "0";

    /**
     *  定数：登録/更新対象 = 1(更新)
     */
    private static final String UPDATE_FLG = "1";
    
    /**
     * 営業所マスタ詳細の登録/更新チェック処理
     *
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {

        // パラメータを解析する
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
        // 登録/更新対象
        String editKbn = StrUtils.defaultString(params.get("editKbn"));
        // 営業所コード
        String eigyoshoCd = StrUtils.defaultString(params.get("conEigyoshoCd"));
        // 時間パラメータ変換(適用開始日)
        long time_long = Long.valueOf(StrUtils.defaultString(params.get("conTekiyoKaishibi")));
        Date tekiyoKaishibiDate = new Date(time_long);
        // JISコード
        String jisCd = StrUtils.defaultString(params.get("khnDtlJisCd"));
        // 空港コード
        String kukoCd = StrUtils.defaultString(params.get("khnDtlKukoCd"));
        // 仕向地コード
        String shimukeChi = StrUtils.defaultString(params.get("khnDtlShimukeChi"));
        // 送り状発行営業所コード
        String okurijoHakkoEigyoshoCd = StrUtils.defaultString(params.get("knrDtlOkurijoHakkoEigyoshoCd"));
        // 銀行口座コード
        String ginkoKozaCd = StrUtils.defaultString(params.get("kzaDtlGinkoKozaCd"));
        // 仕立営業所コード
        String shitateEigyoshoCd = StrUtils.defaultString(params.get("orsDtlShitateEigyoshoCd"));
        // チェック対象：営業所グループ情報リスト
        List<Map<String, Object>> egrpList = (List<Map<String, Object>>) params.get("egrpList");
        // チェック対象：卸単価情報リスト
        List<Map<String, Object>> orsList = (List<Map<String, Object>>) params.get("orsList");
        
        // 重複/存在チェック(営業所マスタ)
        // 営業所マスタの検索条件
        MsEigyosho msEigyosho = new MsEigyosho();
        // 営業所コード
        msEigyosho.setEigyoshoCd(eigyoshoCd);
        // 適用開始日
        msEigyosho.setTekiyoKaishibi(tekiyoKaishibiDate);
        // 営業所マスタ情報を取得する
        List<MsEigyosho> reEigyosho = msEigyoshoDao.findByColumn(msEigyosho);
        // 登録対象の場合
        if (CheckUtils.isEqual(editKbn, SHINKI_FLG)) {
            // 重複チェック（登録）
            // 営業所コードが、既に営業所マスタに既に存在する場合。
            if (!reEigyosho.isEmpty()) {
                serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                // エラーメッセージを表示させ、処理を終了
                serviceInterfaceBean.setJson(JSONUtil.makeJSONString(1));
                serviceInterfaceBean.addMessage("ERROR", 
                        MessageCnst.MSTE0106,
                        "");
                // 営業所マスタ
                serviceInterfaceBean.setTableName(EIGYOSHO);
                return;
            }
            
        } else if (CheckUtils.isEqual(editKbn, UPDATE_FLG)) {
            // 存在チェック（更新）
            // 営業所コードが、営業所マスタに存在しない場合。
            if (reEigyosho.isEmpty()) {
                serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                // エラーメッセージを表示させ、処理を終了
                serviceInterfaceBean.setJson(JSONUtil.makeJSONString(1));
                serviceInterfaceBean.addMessage("ERROR", 
                        MessageCnst.MSTE0009,
                        "該当のデータ");
                // 営業所マスタ
                serviceInterfaceBean.setTableName(EIGYOSHO);
                return;
            }
        }
        
        // JIS存在チェック
        // JISコードマスタの検索条件
        MsJisCd msJisCd = new MsJisCd();
        // JISコード
        msJisCd.setJisCd(jisCd);
        // JISコードマスタ情報を取得する
        List<MsJisCd> reMsJisCd = msJisCdDao.findByColumn(msJisCd);
        // JISコードが、JISコードマスタに存在しない場合。
        if (reMsJisCd.isEmpty()) {
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            // エラーメッセージを表示させ、処理を終了
            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(1));
            serviceInterfaceBean.addMessage("ERROR", 
                    MessageCnst.MSTE0009,
                    "JISコード");
            // JISコードマスタ
            serviceInterfaceBean.setTableName(JIS_CD);
            return;
        }
        
        // 空港存在チェック
        // 空港マスタの検索条件
        MsKuko mskuko = new MsKuko();
        // 空港コード
        mskuko.setKukoLetterCd(kukoCd);
        // 空港マスタ情報を取得する
        List<MsKuko> resKuko = msKukoDao.findByColumn(mskuko);
        // 空港コードが、空港マスタに存在しない場合
        if (resKuko.isEmpty()) {
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            // エラーメッセージを表示させ、処理を終了
            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(1));
            serviceInterfaceBean.addMessage("ERROR", 
                    MessageCnst.MSTE0009,
                    "空港コード");
            // 空港マスタ
            serviceInterfaceBean.setTableName(KUKO);
            return;
        }
        
        // 仕向地存在チェック
        // 住所マスタの検索条件
        MsJusho msJusho = new MsJusho();
        // 仕向地コード
        msJusho.setShimukeChiCd(shimukeChi);
        // 住所マスタ情報を取得する
        List<MsJusho> resJusho = msJushoDao.findByColumn(msJusho);
        // 仕向地コードが、住所マスタに存在しない場合
        if (resJusho.isEmpty()) {
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            // エラーメッセージを表示させ、処理を終了
            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(1));
            serviceInterfaceBean.addMessage("ERROR", 
                    MessageCnst.MSTE0009,
                    "仕向地");
            // 住所マスタ
            serviceInterfaceBean.setTableName(JUSHO);
            return;
        }
        
        // 送り状発行営業所存在チェック
        if (!CheckUtils.isEmpty(okurijoHakkoEigyoshoCd)) {
            // 営業所マスタの検索条件
            msEigyosho = new MsEigyosho();
            // 送り状発行営業所コード
            msEigyosho.setEigyoshoCd(okurijoHakkoEigyoshoCd);
            // 営業所マスタ情報を取得する
            reEigyosho = msEigyoshoDao.findByColumn(msEigyosho);
            // 送り状発行営業所コードが、営業所マスタに存在しない場合
            if (reEigyosho.isEmpty()) {
                serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                // エラーメッセージを表示させ、処理を終了
                serviceInterfaceBean.setJson(JSONUtil.makeJSONString(1));
                serviceInterfaceBean.addMessage("ERROR", 
                        MessageCnst.MSTE0009,
                        "送り状発行営業所コード");
                // 営業所マスタ
                serviceInterfaceBean.setTableName(EIGYOSHO);
                return;
            }
        }
        
        // 銀行口座存在チェック
        if (!CheckUtils.isEmpty(ginkoKozaCd)) {
            // 銀行口座マスタの検索条件
            MsGinkoKoza msGinkoKoza = new MsGinkoKoza();
            // 銀行口座コード
            msGinkoKoza.setKaniGinkoCd(ginkoKozaCd);
            // 銀行口座マスタ情報を取得する
            List<MsGinkoKoza> resGinkoKoza = msGinkoKozaDao.findByColumn(msGinkoKoza);
            // 銀行口座コードが、銀行口座マスタに存在しない場合
            if (resGinkoKoza.isEmpty()) {
                serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                // エラーメッセージを表示させ、処理を終了
                serviceInterfaceBean.setJson(JSONUtil.makeJSONString(1));
                serviceInterfaceBean.addMessage("ERROR", 
                        MessageCnst.MSTE0009,
                        "銀行口座コード");
                // 銀行口座マスタ
                serviceInterfaceBean.setTableName(GINKO_KOZA);
                return;
            }
        }
        
        // 仕立営業所コード存在チェック
        if (!CheckUtils.isEmpty(shitateEigyoshoCd)) {
            // 営業所マスタの検索条件
            msEigyosho = new MsEigyosho();
            // 仕立営業所コード
            msEigyosho.setEigyoshoCd(shitateEigyoshoCd);
            // 営業所マスタ情報を取得する
            reEigyosho = msEigyoshoDao.findByColumn(msEigyosho);
            // 仕立営業所コードが、営業所マスタに存在しない場合
            if (reEigyosho.isEmpty()) {
                serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                // エラーメッセージを表示させ、処理を終了
                serviceInterfaceBean.setJson(JSONUtil.makeJSONString(1));
                serviceInterfaceBean.addMessage("ERROR", 
                        MessageCnst.MSTE0009,
                        "仕立営業所コード");
                // 営業所マスタ
                serviceInterfaceBean.setTableName(EIGYOSHO);
                return;
            }
        }
        
        // チェック対象：営業所グループ情報リスト
        if (egrpList != null && egrpList.size() > 0) {
            List<String> tableNames = new ArrayList<>();
            // 営業所マスタの検索条件
            MsEigyosho crtEigyosho;
            // 営業所グループマスタの検索条件
            MsEigyoshoGroup crtEigyoshoGroup;
            
            //　エラー件数
            int count = 0;
            for (Map<String, Object> record : egrpList) {
                
                if (!CheckUtils.isEqual(StrUtils.defaultString(record.get("hideFlg")), "hideRow")) {
                   // 上位営業所存在チェック
                   if (!CheckUtils.isEmpty(StrUtils.defaultString(record.get("egrpDtlListJoiEigyoshoCd")))) {
                        // 営業所マスタの検索条件
                        crtEigyosho = new MsEigyosho();
                        // 上位営業所コード
                        crtEigyosho.setEigyoshoCd(StrUtils.defaultString(record.get("egrpDtlListJoiEigyoshoCd")));
                        // 営業所マスタ情報を取得する
                        List<MsEigyosho> reEigyoshoList = msEigyoshoDao.findByColumn(crtEigyosho);
                        // 上位営業所コードが、営業所マスタに存在しない場合。
                        if (reEigyoshoList.isEmpty()) {
                            count++;
                            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                            // エラーメッセージを表示させ、処理を終了
                            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(count));
                            serviceInterfaceBean.addMessage("ERROR", 
                                    MessageCnst.MSTE0009,
                                    "上位営業所コード");
                            // 営業所マスタ
                            tableNames.add(EIGYOSHO);
                        }  
                   }

                   // サブ組織チェック
                   if (!CheckUtils.isEmpty(StrUtils.defaultString(record.get("egrpDtlListSubSoshikiMei")))) {
                        // 営業所グループマスタの検索条件
                        crtEigyoshoGroup = new MsEigyoshoGroup();
                        // サブ組織名
                        crtEigyoshoGroup.setSubSoshikiMei(
                                StrUtils.defaultString(record.get("egrpDtlListSubSoshikiMei")));
                        // 営業所グループマスタ情報を取得する
                        List<MsEigyoshoGroup> reEigyoshoGroupList = msEigyoshoGroupDao.findByColumn(crtEigyoshoGroup);
                        // サブ組織名が営業所グループマスタに存在し
                        if (!reEigyoshoGroupList.isEmpty()) {
                            // サブ組織存在フラグ
                            boolean isSubSoshikiFlg = false;
                            for (MsEigyoshoGroup eigyoshoGroup : reEigyoshoGroupList) {
                                if (CheckUtils.isEqual(eigyoshoGroup.getJoiEigyoshoCd(), 
                                        StrUtils.defaultString(record.get("egrpDtlListJoiEigyoshoCd")))) {
                                    // 上位営業所コードが対応するサブ組織に存在する
                                    isSubSoshikiFlg = true;
                                    break;
                                }
                            }
                            if (!isSubSoshikiFlg) {
                                // 上位営業所コードが対応するサブ組織に存在していない場合
                                count++;
                                serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                                // エラーメッセージを表示させ、処理を終了
                                serviceInterfaceBean.setJson(JSONUtil.makeJSONString(count));
                                serviceInterfaceBean.addMessage("ERROR", 
                                        MessageCnst.MSTE0009,
                                        StrUtils.defaultString(record.get("egrpDtlListSubSoshikiMei")).concat("に")
                                                .concat(StrUtils.defaultString(
                                                        record.get("egrpDtlListJoiEigyoshoCd"))));
                                // 営業所グループマスタ
                                tableNames.add(EIGYOSHO_GROUP);
                            }
                        }
                   }

                   // エラーの場合
                   if (count > 0) {
                       serviceInterfaceBean.setTableName(String.join(",", tableNames));
                       return;
                   }
                }
            }
        }
        
        // チェック対象：卸単価情報リスト
        if (orsList != null && orsList.size() > 0) {
            // 営業所マスタの検索条件
            MsEigyosho crtEigyosho;
            
            //　エラー件数
            int count = 0;
            for (Map<String, Object> record : orsList) {
                // 集荷卸計上先営業所存在チェック
                if (!CheckUtils.isEmpty(StrUtils.defaultString(record.get("orsDtlListShukaOroshiKeijoEighoshoCd")))) {
                    // 営業所マスタの検索条件
                    crtEigyosho = new MsEigyosho();
                    // 集荷卸計上先営業所コード
                    crtEigyosho.setEigyoshoCd(StrUtils.defaultString(
                            record.get("orsDtlListShukaOroshiKeijoEighoshoCd")));
                    // 営業所マスタ情報を取得する
                    List<MsEigyosho> reEigyoshoList = msEigyoshoDao.findByColumn(crtEigyosho);
                    // 集荷卸計上先営業所コードが、営業所マスタに存在しない場合
                    if (reEigyoshoList.isEmpty()) {
                        count++;
                        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                        // エラーメッセージを表示させ、処理を終了
                        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(count));
                        serviceInterfaceBean.addMessage("ERROR", 
                                MessageCnst.MSTE0009,
                                "集荷卸計上先営業所コード");
                    } 
                }
            
                // 発送母船卸計上先営業所存在チェック
                if (!CheckUtils.isEmpty(StrUtils.defaultString(record.get("orsDtlListHsoBosenKeijoEighoshoCd")))) {
                    // 営業所マスタの検索条件
                    crtEigyosho = new MsEigyosho();
                    // 発送母船卸計上先営業所コード
                    crtEigyosho.setEigyoshoCd(StrUtils.defaultString(record.get("orsDtlListHsoBosenKeijoEighoshoCd")));
                    // 営業所マスタ情報を取得する
                    List<MsEigyosho> hsoBosenList = msEigyoshoDao.findByColumn(crtEigyosho);
                    // 発送母船卸計上先営業所コードが、営業所マスタに存在しない場合
                    if (hsoBosenList.isEmpty()) {
                        count++;
                        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                        // エラーメッセージを表示させ、処理を終了
                        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(count));
                        serviceInterfaceBean.addMessage("ERROR", 
                                MessageCnst.MSTE0009,
                                "発送母船卸計上先営業所コード");
                    } 
                }
                
                // 到着母船卸計上先営業所存在チェック
                if (!CheckUtils.isEmpty(StrUtils.defaultString(record.get("orsDtlListTckBosenKeijoEighoshoCd")))) {
                    // 営業所マスタの検索条件
                    crtEigyosho = new MsEigyosho();
                    // 到着母船卸計上先営業所コード
                    crtEigyosho.setEigyoshoCd(StrUtils.defaultString(record.get("orsDtlListTckBosenKeijoEighoshoCd")));
                    // 営業所マスタ情報を取得する
                    List<MsEigyosho> tckBosenList = msEigyoshoDao.findByColumn(crtEigyosho);
                    // 到着母船卸計上先営業所コードが、営業所マスタに存在しない場合
                    if (tckBosenList.isEmpty()) {
                        count++;
                        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                        // エラーメッセージを表示させ、処理を終了
                        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(count));
                        serviceInterfaceBean.addMessage("ERROR", 
                                MessageCnst.MSTE0009,
                                "到着母船卸計上先営業所コード");
                    } 
                }
                
                // 仕分卸計上先営業所存在チェック
                if (!CheckUtils.isEmpty(StrUtils.defaultString(record.get("orsDtlListSwkOroshiKeijoEighoshoCd")))) {
                    // 営業所マスタの検索条件
                    crtEigyosho = new MsEigyosho();
                    // 仕分卸計上先営業所コード
                    crtEigyosho.setEigyoshoCd(StrUtils.defaultString(record.get("orsDtlListSwkOroshiKeijoEighoshoCd")));
                    // 営業所マスタ情報を取得する
                    List<MsEigyosho> swkOroshiList = msEigyoshoDao.findByColumn(crtEigyosho);
                    // 仕分卸計上先営業所コードが、営業所マスタに存在しない場合
                    if (swkOroshiList.isEmpty()) {
                        count++;
                        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                        // エラーメッセージを表示させ、処理を終了
                        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(count));
                        serviceInterfaceBean.addMessage("ERROR", 
                                MessageCnst.MSTE0009,
                                "仕分卸計上先営業所コード");
                    }
                }
                
                // 配達卸計上先営業所存在チェック
                if (!CheckUtils.isEmpty(StrUtils.defaultString(record.get("orsDtlListHttOroshiKeijoEighoshoCd")))) {
                    // 営業所マスタの検索条件
                    crtEigyosho = new MsEigyosho();
                    // 配達卸計上先営業所コード
                    crtEigyosho.setEigyoshoCd(StrUtils.defaultString(record.get("orsDtlListHttOroshiKeijoEighoshoCd")));
                    // 営業所マスタ情報を取得する
                    List<MsEigyosho> httOroshiList = msEigyoshoDao.findByColumn(crtEigyosho);
                    // 配達卸計上先営業所コードが、営業所マスタに存在しない場合
                    if (httOroshiList.isEmpty()) {
                        count++;
                        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                        // エラーメッセージを表示させ、処理を終了
                        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(count));
                        serviceInterfaceBean.addMessage("ERROR", 
                                MessageCnst.MSTE0009,
                                "配達卸計上先営業所コード");
                    } 
                }
                
                // エラーの場合
                if (count > 0) {
                    // 営業所マスタ
                    serviceInterfaceBean.setTableName(EIGYOSHO);
                    return;
                }
            }
        } 
    }
}