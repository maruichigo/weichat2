/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.lgn.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Map;
import javax.annotation.Resource;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.lgn.dao.Lgn011Dao;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

/**
 *ユーザー存在チェック
 * 
 * @author 黄華（MBP）
 * @version 2019/1/24 新規作成
 */
@Component("LGN011_CHECK_USERCD")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Lgn011BusUserCdCheck extends BaseBus{
    
    /**
     * Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected Lgn011Dao lgn011Dao;

    /**
     * ユーザー存在チェック
     * 
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception 
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception{

        // パラメータ構築
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

        // ユーザー件数取得
        int result = lgn011Dao.countUser(params);
        
        // 戻り値設定
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        serviceInterfaceBean.addMessage("INFO", "情報", "方法");
    }
}
