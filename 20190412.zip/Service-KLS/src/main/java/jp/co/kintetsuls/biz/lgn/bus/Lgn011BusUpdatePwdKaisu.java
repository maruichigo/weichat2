/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.lgn.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import java.util.Map;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.base.dao.BaseDao;
import jp.co.kintetsuls.biz.table.dao.TrPasswordGoNyuryokuKaisuDao;
import jp.co.kintetsuls.biz.table.model.TrPasswordGoNyuryokuKaisu;
import jp.co.kintetsuls.common.SystemColumn;
import jp.co.kintetsuls.common.cnst.StndConsIF;
import jp.co.kintetsuls.common.json.JSONUtil;

/**
 * パスワード誤入力回数を登録更新する
 * 
 * @author 黄華（MBP）
 * @version 2019/1/24 新規作成
 */
@Component("LGN011_UPDATE_PWDKAISU")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Lgn011BusUpdatePwdKaisu extends BaseBus {

    /**
     * Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected TrPasswordGoNyuryokuKaisuDao trPasswordGoNyuryokuKaisuDao;

    /**
     * パスワード誤入力回数を登録更新する
     * 
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception 
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception{

        // パラメータ構築
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
        // 回数
        int kaisu = 0;

        // テーブルに登録されているパスワード誤入力回数の取得を行う
        TrPasswordGoNyuryokuKaisu trPasswordGoNyuryokuKaisu = new TrPasswordGoNyuryokuKaisu();
        trPasswordGoNyuryokuKaisu.setUserCd(params.get("userCd").toString());
        TrPasswordGoNyuryokuKaisu searchResult = trPasswordGoNyuryokuKaisuDao.findById(trPasswordGoNyuryokuKaisu);

        // 取得結果1件の場合
        if (searchResult != null) {
            // パスワード誤入力回数更新
            // 回数
            kaisu = searchResult.getKaisu();
            // 回数 = 回数+1
            searchResult.setKaisu(searchResult.getKaisu() + 1);
            // システムカラム
            searchResult = SystemColumn.systemColumnSet(2, searchResult, serviceInterfaceBean);

            List<Map<String, TrPasswordGoNyuryokuKaisu>> updateList = new ArrayList<>();
            Map<String, TrPasswordGoNyuryokuKaisu> updateMap = new HashMap<>();
            updateMap.put(BaseDao.UPDATE_BEAN_UPD, searchResult);
            updateMap.put(BaseDao.UPDATE_BEAN_CRT, searchResult);
            updateList.add(updateMap);

            trPasswordGoNyuryokuKaisuDao.updateById(updateList);
        } else {
            // 取得結果0件の場合
            // パスワード誤入力回数登録
            TrPasswordGoNyuryokuKaisu insertEntity = new TrPasswordGoNyuryokuKaisu();
            // ユーザーコード
            insertEntity.setUserCd(params.get("userCd").toString());
            // 回数 = 1
            insertEntity.setKaisu(1);
            // 削除フラグ
            insertEntity.setSakujoFlg(StndConsIF.CONST_ZERO_STRING);
            // システムカラム
            insertEntity = SystemColumn.systemColumnSet(1, insertEntity, serviceInterfaceBean);

            trPasswordGoNyuryokuKaisuDao.insert(insertEntity);
        }

        // 回数を設定する
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(kaisu));
        serviceInterfaceBean.addMessage("INFO", "情報", "方法");
    }
}