/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.lgn.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.HashMap;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import java.util.Map;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.lgn.dao.Lgn031Dao;
import jp.co.kintetsuls.biz.lgn.model.Lgn031Def;
import jp.co.kintetsuls.biz.table.dao.MsUserDao;
import jp.co.kintetsuls.biz.table.model.MsUser;
import jp.co.kintetsuls.utils.StrUtils;

/**
 * 検索処理
 *
 * @author 黄義輝 (MBP)
 * @version 2019/04/01 新規作成
 */
@Component("LGN031_GET_DETAIL")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Lgn031BusSearch extends BaseBus {

    /**
     * Lgn031Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected Lgn031Dao lgn031Dao;

    /**
     * ユーザーDao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsUserDao msUserDao;

    /**
     * ユーザー定義
     */
    protected MsUser msUser;

    /**
     * 処理が完了した場合, 進行状況アイコン
     */
    private static final String SHONIN_JOKYO_SYORI_KANRYO = "shonin-jokyo-syori-kanryo";

    /**
     * 処理が途中で止まっている場合, 進行状況アイコン
     */
    private static final String SHONIN_JOKYO_GENZAI_SAGYO = "shonin-jokyo-genzai-sagyo";

    /**
     * 最終処理が完了した場合, 進行状況アイコン
     */
    private static final String SHONIN_JOKYO_END = "shonin-jokyo-end";

    /**
     * 申請ユーザーの場合, ユーザーアイコン
     */
    private static final String SHINSEI_USER = "shinsei-user";

    /**
     * ログインユーザーの場合, ユーザーアイコン
     */
    private static final String LOGIN_USER = "login-user";

    /**
     * 申請、ログインユーザー以外の場合, ユーザーアイコン
     */
    private static final String SHONIN_USER = "shonin-user";

    /**
     * Axisによる自動処理の場合, ユーザーアイコン
     */
    private static final String AUTO_PROCESS = "auto-process";

    /**
     * 検索処理
     * 
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {

        // パラメータを解析する
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

        // ワーク.承認者情報
        Map<String, Object> shoninshaInfo = (Map)params.get("shoninshaInfo");
        
        // ワーク.Axis処理
        String axisShoriName = StrUtils.defaultString(params.get("axisShori"));
        // ワーク.自動実行
        String jidoJikkoName = StrUtils.defaultString(params.get("jidoJikko"));

        // ワーク.承認者情報.最終承認者フラグ
        params.put("saishuShoninShaFlg", shoninshaInfo.get("saishuShoninShaFlg"));

        // 申請情報取得
        List<Lgn031Def> getShinseiInfoList = lgn031Dao.findForShinseiInfo(params);

        // 承認状況取得
        List<Lgn031Def> getSyouninJyoukyouList = lgn031Dao.findForSyouninJyoukyou(params);

        // 取得結果をワーク.承認状況に格納する。
        for (Lgn031Def syouninJyoukyouDef : getSyouninJyoukyouList) {

            // 申請コメントDisabled;
            syouninJyoukyouDef.setShinseiCommentDisabled(true);

            // 最終処理が完了した場合
            if (("処理完了").equals(syouninJyoukyouDef.getKekka())) {
                syouninJyoukyouDef.setShinkouJyoukyouIcon(SHONIN_JOKYO_END);
            // 処理完了  
            } else {
                syouninJyoukyouDef.setShinkouJyoukyouIcon(SHONIN_JOKYO_SYORI_KANRYO);
            }

            // ログインユーザー
            if (syouninJyoukyouDef.getUserCd() != null
                    && syouninJyoukyouDef.getUserCd().equals(serviceInterfaceBean.getUserCd())) {
                syouninJyoukyouDef.setUserIcon(LOGIN_USER);
            // 申請ユーザーの場合
            } else if (syouninJyoukyouDef.getShubetsu() != null
                    && ("申請").equals(syouninJyoukyouDef.getShubetsu()) ) {
                syouninJyoukyouDef.setUserIcon(SHINSEI_USER);
            // 自動実行処理の場合
            } else if (syouninJyoukyouDef.getNamae() != null
                    && ("自動実行").equals(syouninJyoukyouDef.getNamae()) 
                    && syouninJyoukyouDef.getKekka() != null
                    && ("処理完了").equals(syouninJyoukyouDef.getKekka())) {
                syouninJyoukyouDef.setUserIcon(AUTO_PROCESS);
            // 申請、ログインユーザー以外の場合
            } else {
                syouninJyoukyouDef.setUserIcon(SHONIN_USER);
            }
        }

        // 残申請プロセスアクティビティ取得
        // ワーク.承認状況の先頭のデータに対し、判定を行う。
        Lgn031Def syouninJyoukyouFirstDef = new Lgn031Def();
        if (getSyouninJyoukyouList != null && !getSyouninJyoukyouList.isEmpty()) {
            syouninJyoukyouFirstDef = getSyouninJyoukyouList.get(0);
        }
        // ワーク.次申請プロセスアクティビティNO IS NULL AND ワーク.種別 != ワーク.Axis処理
        if (syouninJyoukyouFirstDef != null 
                && syouninJyoukyouFirstDef.getTsugiShinseiProcessActivityNo() == null
                && !(axisShoriName).equals(syouninJyoukyouFirstDef.getShubetsu())) {
            
            Lgn031Def syouninJyoukyouFirstTsuikaDef = new Lgn031Def();
            // 進行状況アイコン
            syouninJyoukyouFirstTsuikaDef.setShinkouJyoukyouIcon(SHONIN_JOKYO_GENZAI_SAGYO);
            // 種別
            syouninJyoukyouFirstTsuikaDef.setShubetsu(axisShoriName);
            // ユーザーアイコン
            syouninJyoukyouFirstTsuikaDef.setUserIcon(AUTO_PROCESS);
            // 名前
            syouninJyoukyouFirstTsuikaDef.setNamae(jidoJikkoName);
            // 申請コメントDisabled
            syouninJyoukyouFirstTsuikaDef.setShinseiCommentDisabled(true);

            // 承認状況の先頭に追加する。
            if (getSyouninJyoukyouList != null) {
                getSyouninJyoukyouList.add(0, syouninJyoukyouFirstTsuikaDef);
            }
        }

        if (syouninJyoukyouFirstDef != null 
                && syouninJyoukyouFirstDef.getTsugiShinseiProcessActivityNo() != null) {
            
            Lgn031Def syouninJyoukyouFirstTsuikaDef = new Lgn031Def();
            // 進行状況アイコン
            syouninJyoukyouFirstTsuikaDef.setShinkouJyoukyouIcon(SHONIN_JOKYO_GENZAI_SAGYO);
            // 箇所
            syouninJyoukyouFirstTsuikaDef.setKasho(serviceInterfaceBean.getDefaultEigyosho());
            // ユーザーアイコン
            syouninJyoukyouFirstTsuikaDef.setUserIcon(LOGIN_USER);
            // 名前
            syouninJyoukyouFirstTsuikaDef.setNamae(getUserName(serviceInterfaceBean.getUserCd()));
            // 申請コメントDisabled
            syouninJyoukyouFirstTsuikaDef.setShinseiCommentDisabled(false);
            // 次申請プロセスアクティビティNO
            syouninJyoukyouFirstTsuikaDef.setTsugiShinseiProcessActivityNo(
                    syouninJyoukyouFirstDef.getTsugiShinseiProcessActivityNo());
            // 申請種別コード
            syouninJyoukyouFirstTsuikaDef.setShinseiShubetsuCd(syouninJyoukyouFirstDef.getShinseiShubetsuCd());

            // 承認状況の先頭に追加する。
            if (getSyouninJyoukyouList != null) {
                getSyouninJyoukyouList.add(0, syouninJyoukyouFirstTsuikaDef);
            }

            // ワーク.承認状況の先頭データの、ワーク.次申請プロセスアクティビティNOがNULLになるまで繰り返す。
            while (getSyouninJyoukyouList != null
                    && !getSyouninJyoukyouList.isEmpty()
                    && getSyouninJyoukyouList.get(0) != null
                    && getSyouninJyoukyouList.get(0).getTsugiShinseiProcessActivityNo() != null) {

                // 次段階の申請プロセスアクティビティを取得する。
                Map shinseiParams = new HashMap();
                shinseiParams.put("shinseiShubetsuCd", getSyouninJyoukyouList.get(0).getShinseiShubetsuCd());
                shinseiParams.put("tsugiShinseiProcessActivityNo",
                        getSyouninJyoukyouList.get(0).getTsugiShinseiProcessActivityNo());
                List<Lgn031Def> getShinseiProcessActivityInfoList
                        = lgn031Dao.findForShinseiProcessActivityInfo(shinseiParams);
                
                if (getShinseiProcessActivityInfoList != null
                        && !getShinseiProcessActivityInfoList.isEmpty()
                        && getShinseiProcessActivityInfoList.get(0) != null) {
                    
                    Lgn031Def shinseiProcessActivityInfo = getShinseiProcessActivityInfoList.get(0);

                    syouninJyoukyouFirstTsuikaDef = new Lgn031Def();
                    // 種別
                    syouninJyoukyouFirstTsuikaDef.setShubetsu(shinseiProcessActivityInfo.getShubetsu());
                    // 箇所
                    syouninJyoukyouFirstTsuikaDef.setKasho(shinseiProcessActivityInfo.getKasho());
                    // 名前
                    syouninJyoukyouFirstTsuikaDef.setNamae(shinseiProcessActivityInfo.getNamae());
                    // 結果
                    syouninJyoukyouFirstTsuikaDef.setKekka(shinseiProcessActivityInfo.getKekka());
                    // コメント
                    syouninJyoukyouFirstTsuikaDef.setShinseiComment(
                            shinseiProcessActivityInfo.getShinseiComment());
                    // 申請コメントDisabled
                    syouninJyoukyouFirstTsuikaDef.setShinseiCommentDisabled(true);
                    // 日時
                    syouninJyoukyouFirstTsuikaDef.setNichiji(shinseiProcessActivityInfo.getNichiji());
                    // 次申請プロセスアクティビティNO
                    syouninJyoukyouFirstTsuikaDef.setTsugiShinseiProcessActivityNo(
                            shinseiProcessActivityInfo.getTsugiShinseiProcessActivityNo());
                    // 申請種別コード
                    syouninJyoukyouFirstTsuikaDef.setShinseiShubetsuCd(
                            shinseiProcessActivityInfo.getShinseiShubetsuCd());
                    
                    getSyouninJyoukyouList.add(0, syouninJyoukyouFirstTsuikaDef);
                } else {
                    break;
                }
            }
            
            syouninJyoukyouFirstTsuikaDef = new Lgn031Def();
            // 種別
            syouninJyoukyouFirstTsuikaDef.setShubetsu(axisShoriName);
            // 申請コメントDisabled
            syouninJyoukyouFirstTsuikaDef.setShinseiCommentDisabled(true);

            // 承認状況の先頭に追加する。
            if (getSyouninJyoukyouList != null) {
                getSyouninJyoukyouList.add(0, syouninJyoukyouFirstTsuikaDef);
            }
        }

        Map<String, Object> result = new HashMap<>();
        // 申請情報取得
        result.put("getShinseiInfoList", getShinseiInfoList);
        // 承認状況取得
        result.put("getSyouninJyoukyouList", getSyouninJyoukyouList);
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
    }

    /**
     * ユーザーコードより，ユーザー名取得
     * @param userCd ユーザーコード
     * @return ユーザー名
     */
    private String getUserName(String userCd) {

        msUser = new MsUser();
        msUser.setUserCd(userCd);
        // ユーザー情報取得
        List<MsUser> msUserInfoList = msUserDao.findByColumn(msUser);

        if (msUserInfoList != null && !msUserInfoList.isEmpty()) {
            return msUserInfoList.get(0).getUserMei();
        }
        
        return null;
    }
}