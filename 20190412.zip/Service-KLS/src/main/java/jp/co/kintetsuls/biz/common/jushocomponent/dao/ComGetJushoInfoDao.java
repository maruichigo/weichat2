package jp.co.kintetsuls.biz.common.jushocomponent.dao;

import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.biz.base.dao.BaseDao;
import jp.co.kintetsuls.biz.common.autocomplete.model.ComCreateListDef;
import org.springframework.stereotype.Component;

/**
 * 新住所情報取得Dao
 *
 * @author yang.x (MBP)
 * @version 2019/2/27 新規作成
 */
@Component
public class ComGetJushoInfoDao extends BaseDao<ComCreateListDef> {

    /**
     * 新JISコードより新住所情報を取得する
     * @param searchCriteria 検索条件
     * @return 検索結果
     */
    public List<Map<String, Object>> getShinjushoInfo(Map<String, Object> searchCriteria) {
        return getSqlSession().selectList("comShinjushoInfo.getShinjushoInfo", searchCriteria);
    }

}
