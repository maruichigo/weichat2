package jp.co.kintetsuls.biz.mst.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import java.util.Map;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.mst.dao.Mst042Dao;
import jp.co.kintetsuls.common.cnst.StndConsIF;

/**
 * 営業所マスタ詳細の適用開始日取得処理
 *
 * @author 雷珍 (MBP)
 * @version 2019/3/6 新規作成
 */
@Component("MST042_GET_TEKIYO_KAISHIBI")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Mst042BusGetTekiyoKaishibi extends BaseBus {

    /**
     * 営業所マスタ詳細Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected Mst042Dao mst042Dao;

    /**
     * パラメータ
     */
    private Map<String, Object> params = null;

    /**
     * 営業所マスタ詳細の適用開始日取得処理
     *
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
        
         // 戻り値
        Map<String, Object> result = new HashMap<>();

        // 適用開始日情報を取得する
        List<Map<String, String>> resultTekiyoKaishibi = mst042Dao.searchForTekiyoKaishibi(params);
        
        // 適用開始日フォーマット
        SimpleDateFormat dateFormat = new SimpleDateFormat(StndConsIF.DF_YYYY_MM_DD);
            
        if (resultTekiyoKaishibi != null) {
            for(Map<String, String> res : resultTekiyoKaishibi) {
                // 適用開始日情報を戻り値に設定
                result.put("tekiyoKaishibi", dateFormat.format(res.get("TEKIYO_KAISHIBI")));
            }
        }
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
    }
}
