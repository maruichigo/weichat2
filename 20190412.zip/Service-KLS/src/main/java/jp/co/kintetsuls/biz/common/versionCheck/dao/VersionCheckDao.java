/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.biz.common.versionCheck.dao;

import java.util.List;
import java.util.Map;
import jp.co.kintetsuls.biz.base.dao.BaseDao;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

/**
 *
 * @author liuchengjiang
 */
@Repository
@Component
public class VersionCheckDao extends BaseDao<Object>{
    @Autowired
    private SqlSessionFactory sqlSessionFactory;
    /**
     * 主キー取得
     */
    public List<String> getPrimerKey(String searchParam){
        return getSqlSession().selectList("versionCheck.getPrimerKey", searchParam);
    }
    
    public int getKoushinVersion(Map<String, Object> searchParam){
        return getSqlSession().selectOne("versionCheck.checkstart", searchParam);
    }
    
}
