/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.mst.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import java.util.Map;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.table.dao.MsEigyoshoDao;
import jp.co.kintetsuls.biz.table.dao.MsJushoDao;
import jp.co.kintetsuls.biz.table.dao.MsJushoJisDao;
import jp.co.kintetsuls.biz.table.dao.MsKukoDao;
import jp.co.kintetsuls.biz.table.dao.MsShimukeChiMeiDao;
import jp.co.kintetsuls.biz.table.model.MsEigyosho;
import jp.co.kintetsuls.biz.table.model.MsJusho;
import jp.co.kintetsuls.biz.table.model.MsJushoJis;
import jp.co.kintetsuls.biz.table.model.MsKuko;
import jp.co.kintetsuls.biz.table.model.MsShimukeChiMei;
import jp.co.kintetsuls.common.cnst.MessageCnst;

/**
 * 住所情報詳細登録更新チェック処理
 *
 * @author 張誠 (MBP)
 * @version 2019/03/04 新規作成
 */
@Component("MST032_INSERT_UPDATE_CHECK")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Mst032BusInsertUpdateCheck extends BaseBus {

    /**
     * 住所JISマスタDAO定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsJushoJisDao jushoJisDao;

    /**
     * 住所マスタDAO定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsJushoDao jushoDao;

    /**
     * 仕向地名マスタDAO定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsShimukeChiMeiDao shimukeChiMeiDao;

    /**
     * 空港マスタDAO定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsKukoDao kukoDao;

    /**
     * 管轄営業所マスタDAO定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsEigyoshoDao eigyoshoDao;

    /**
     * 文字列：住所JISマスタ
     */
    private static final String JUSHO_JIS_MASTER = "住所JISマスタ";

    /**
     * 文字列：住所マスタ
     */
    private static final String JUSHO_MASTER = "住所マスタ";

    /**
     * 文字列：仕向地名マスタ
     */
    private static final String SHIMUKE_CHI_MEI_MASTER = "仕向地名マスタ";

    /**
     * 文字列：空港マスタ
     */
    private static final String KU_KO_MASTER = "空港マスタ";

    /**
     * 文字列：管轄営業所マスタ
     */
    private static final String EIGYOSHO_MASTER = "管轄営業所マスタ";

    /**
     * 住所詳細情報の登録更新チェック処理
     *
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {

        // パラメータを解析する
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

        // 更新フラグ
        String updFlg = params.get("updFlg").toString();
        // JISコード
        String jisCd = params.get("conJisCd").toString();
        // 適用開始日
        long time_long = Long.valueOf(params.get("conTekiyoKaishibi").toString());
        Date tekiyoKaishibi = new Date(time_long);

        // 検索条件
        MsJusho crtJusho;

        // 住所情報リスト取得
        List<Map<String, Object>> jushoList = (List<Map<String, Object>>) params.get("jushoList");
        if (jushoList != null && jushoList.size() > 0) {
            List<String> tableNames = new ArrayList<>();
            // 仕向地名コード検索条件
            MsShimukeChiMei crtShimuke;
            // 空港コード検索条件
            MsKuko crtkuko;
            // 営業所コード検索条件
            MsEigyosho crtEigyosho;
            int count = 0;
            for (Map<String, Object> record : jushoList) {
                // 仕向地名コード存在チェック
                // 検索条件
                crtShimuke = new MsShimukeChiMei();
                // 仕向地名コード
                crtShimuke.setShimukeChiMeiCd(objectToString(record.get("jshDtlListShimukeChiMeiCd")));
                List<MsShimukeChiMei> resShimuke = shimukeChiMeiDao.findByColumn(crtShimuke);
                if (resShimuke.isEmpty()) {
                    count++;
                    serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                    serviceInterfaceBean.setJson(JSONUtil.makeJSONString(count));
                    // エラーメッセージを表示させ、処理を終了
                    serviceInterfaceBean.addMessage("ERROR", MessageCnst.COME0006,
                            objectToString(record.get("jshDtlListShimukeChiMeiCd")));
                    tableNames.add(SHIMUKE_CHI_MEI_MASTER);
                }
                // 空港コード存在チェック
                // 検索条件
                crtkuko = new MsKuko();
                // 空港コード
                crtkuko.setKukoLetterCd(objectToString(record.get("jshDtlListKukoCd")));
                List<MsKuko> resKuko = kukoDao.findByColumn(crtkuko);
                if (resKuko.isEmpty()) {
                    count++;
                    serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                    serviceInterfaceBean.setJson(JSONUtil.makeJSONString(count));
                    // エラーメッセージを表示させ、処理を終了
                    serviceInterfaceBean.addMessage("ERROR", MessageCnst.COME0006,
                            objectToString(record.get("jshDtlListKukoCd")));
                    tableNames.add(KU_KO_MASTER);
                }
                // 営業所コード存在チェック
                // 検索条件
                crtEigyosho = new MsEigyosho();
                // 営業所コード
                crtEigyosho.setEigyoshoCd(objectToString(record.get("jshDtlListEigyoshoCd")));
                List<MsEigyosho> reEigyosho = eigyoshoDao.findByColumn(crtEigyosho);
                if (reEigyosho.isEmpty()) {
                    count++;
                    serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                    serviceInterfaceBean.setJson(JSONUtil.makeJSONString(count));
                    // エラーメッセージを表示させ、処理を終了
                    serviceInterfaceBean.addMessage("ERROR", MessageCnst.COME0006,
                            objectToString(record.get("jshDtlListEigyoshoCd")));
                    tableNames.add(EIGYOSHO_MASTER);
                }

                // 重複チェック(住所マスタ)と存在チェック(住所マスタ)
                crtJusho = new MsJusho();
                // JISコード
                crtJusho.setJisCd(jisCd);
                // 適用開始日
                crtJusho.setTekiyoKaishibi(tekiyoKaishibi);
                // 仕向地コード
                String shimukeChiCd = record.get("jshDtlListJisCd").toString()
                        + record.get("jshDtlListShimukeChiCd").toString();
                crtJusho.setShimukeChiCd(shimukeChiCd);
                // 住所マスタ検索
                MsJusho resJusho = jushoDao.findById(crtJusho);
                if (null != record.get("addFlg")
                        || (!record.get("jshDtlListShimukeChiCd").equals(record.get("jshDtlListHShimukeChiCd")))) {
                    if (resJusho != null) {
                        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                        // エラーメッセージを表示させ、処理を終了
                        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(count));
                        serviceInterfaceBean.addMessage("ERROR", MessageCnst.COME0018, shimukeChiCd);
                        serviceInterfaceBean.setTableName(JUSHO_MASTER);
                    }
                } else {
                    if (resJusho == null) {
                        serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                        // エラーメッセージを表示させ、処理を終了
                        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(count));
                        serviceInterfaceBean.addMessage("ERROR", MessageCnst.COME0006, shimukeChiCd);
                        serviceInterfaceBean.setTableName(JUSHO_MASTER);
                        return;
                    }
                }

                // エラーの場合
                if (count > 0) {
                    serviceInterfaceBean.setTableName(String.join(",", tableNames));
                    return;
                }
            }
        }

        // 重複チェック(住所JISマスタ)と存在チェック(住所JISマスタ)	
        // 検索条件
        MsJushoJis crtJushoJis = new MsJushoJis();
        // JISコード
        crtJushoJis.setJisCd(jisCd);
        // 適用開始日
        crtJushoJis.setTekiyoKaishibi(tekiyoKaishibi);
        // 住所JISマスタ検索
        if (!"".equals(updFlg)) {
            // 住所JISマスタ検索
            MsJushoJis resJushoJis = jushoJisDao.findById(crtJushoJis);
            // 新規の場合
            if ("0".equals(updFlg)) {
                if (resJushoJis != null) {
                    serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                    // エラーメッセージを表示させ、処理を終了
                    serviceInterfaceBean.setJson(JSONUtil.makeJSONString(1));
                    serviceInterfaceBean.addMessage("ERROR", MessageCnst.COME0018, jisCd);
                    serviceInterfaceBean.setTableName(JUSHO_JIS_MASTER);
                }
            } else {
                if (resJushoJis == null) {
                    serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                    // エラーメッセージを表示させ、処理を終了
                    serviceInterfaceBean.setJson(JSONUtil.makeJSONString(1));
                    serviceInterfaceBean.addMessage("ERROR", MessageCnst.COME0006, jisCd);
                    serviceInterfaceBean.setTableName(JUSHO_JIS_MASTER);
                }
            }
        }
    }
}
