package jp.co.kintetsuls.biz.mst.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import java.util.Map;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.mst.dao.Mst042Dao;
import jp.co.kintetsuls.biz.mst.model.Mst042Def;
import jp.co.kintetsuls.utils.StrUtils;

/**
 * 営業所マスタ詳細の検索取得処理
 *
 * @author 雷珍 (MBP)
 * @version 2019/3/6 新規作成
 */
@Component("MST042_SEARCH")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Mst042BusSearch extends BaseBus {

    /**
     * 営業所マスタ詳細情報Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected Mst042Dao mst042Dao;

    /**
     * パラメータ
     */
    private Map<String, Object> params = null;

    /**
     * 営業所マスタ詳細の検索取得処理
     *
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
        
        // 戻り値
        Map<String, Object> result = new HashMap<>();
        
        // 時間パラメータ変換(適用開始日)
        long time_long = Long.valueOf(StrUtils.defaultString(params.get("conTekiyoKaishibi")));
        Date date = new Date(time_long);
        params.put("conTekiyoKaishibi", date);
        
        // 営業所マスタ情報を取得する
        Mst042Def resultEigyosho = mst042Dao.searchForEigyosho(params);

        // 取得件数 = 0以外の場合
        if (resultEigyosho != null) {
            // 使用区分設定
            // 変数：使用区分
            List<String> shiyoKbnList = new ArrayList<String>();
            // 使用区分.集荷営業所の設定															
            if ("1".equals(resultEigyosho.getKnrDtlShiyoShukaKbn())) {
                // 実行結果.集荷営業所フラグが「1:集荷営業所業務可」の場合
                shiyoKbnList.add("1");
            }
            // 使用区分.配達営業所の設定															
            if ("1".equals(resultEigyosho.getKnrDtlShiyoHaitatsuKbn())) {
                // 実行結果.配達営業所フラグが「1:配達営業所業務可」の場合
                shiyoKbnList.add("2");
            }
            // 使用区分.チャーター起点の設定															
            if ("1".equals(resultEigyosho.getKnrDtlShiyoKitenKbn())) {
                // 実行結果.起点フラグが「1:配達起点」の場合
                shiyoKbnList.add("3");
            }
            // 使用区分.売上の設定															
            if ("1".equals(resultEigyosho.getKnrDtlShiyoUriageKbn())) {
                // 実行結果.売上計上フラグが「1:売上計上を行う」の場合
                shiyoKbnList.add("4");
            }
            // 使用区分.発券営業所の設定															
            if ("1".equals(resultEigyosho.getKnrDtlShiyoHakkenKbn())) {
                // 実行結果.発券営業所フラグが「1:発券営業所業務可」の場合
                shiyoKbnList.add("5");
            }
            // 使用区分.車両管理の設定															
            if ("1".equals(resultEigyosho.getKnrDtlShiyoSharyoKbn())) {
                // 実行結果.車両管理フラグが「1:車両管理を行う」の場合
                shiyoKbnList.add("6");
            }
            // 使用区分.配達伝票出力営業所の設定
            if ("1".equals(resultEigyosho.getKnrDtlShiyoHaidenKbn())) {
                // 実行結果.配達伝票出力営業所フラグが「1:配達伝票出力業務可能」の場合
                shiyoKbnList.add("7");
            }
            if (shiyoKbnList.isEmpty()) {
                // 画面．使用区分設定
                String[] knrDtlShiyoKbn = {"0", "0", "0", "0", "0", "0", "0"};
                resultEigyosho.setKnrDtlShiyoKbn(knrDtlShiyoKbn);
            } else {
                // 画面．使用区分設定
                resultEigyosho.setKnrDtlShiyoKbn(shiyoKbnList.toArray(new String[shiyoKbnList.size()]));
            }
            
            // 承認者情報を取得する
            List<Map<String, String>> resultShoninsha = mst042Dao.searchForShoninshaList(params);

            // 承認者情報を戻り値に設定
            result.put("resultShoninsha", resultShoninsha);

            // 営業所グループマスタ情報を取得する
            List<Map<String, String>> resultGroup = mst042Dao.searchForGroupList(params);

            // 営業所グループマスタ情報を戻り値に設定
            result.put("resultGroup", resultGroup);

            // 卸単価情報を取得する
            List<Map<String, String>> resultOroshiTanka = mst042Dao.searchForOroshiTankaList(params);

            // 卸単価情報を戻り値に設定
            result.put("resultOroshiTanka", resultOroshiTanka);
            
            // 最大の営業所グループシーケンスを取得する
            int maxSeqNo = mst042Dao.selectMaxSeqNo(params);
            // 最大の営業所グループシーケンス設定
            resultEigyosho.setMaxSeqNo(maxSeqNo);
        }
        
        // 営業所マスタ情報を戻り値に設定
        result.put("resultEigyosho", resultEigyosho);

        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
    }
}
