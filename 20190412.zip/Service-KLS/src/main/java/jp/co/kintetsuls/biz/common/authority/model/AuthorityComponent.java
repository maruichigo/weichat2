/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.biz.common.authority.model;

import java.io.Serializable;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "authorityComponent")
public class AuthorityComponent implements Serializable{
    
    private static final long serialVersionUID = 3144615551515151L;

    /** スクリーンコード */
    private String screenCode;
    
    /** コンポーネントのリスト */
    private List<AuthorityComponentDetail> components;

    public String getScreenCode() {
        return screenCode;
    }

    public void setScreenCode(String screenCode) {
        this.screenCode = screenCode;
    }

    public List<AuthorityComponentDetail> getComponents(){
        return components;
    }
    
    public void setComponents(List<AuthorityComponentDetail> components){
        this.components = components;
    }
    
}
