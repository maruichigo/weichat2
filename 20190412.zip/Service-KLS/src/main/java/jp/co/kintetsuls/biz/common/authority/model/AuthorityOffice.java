package jp.co.kintetsuls.biz.common.authority.model;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "office")
public class AuthorityOffice implements Serializable{

    private static final long serialVersionUID = 593779985832909L;

    /** 営業所コード */
    private String eigyoshoCd;
    /** 営業所名 */
    private String eigyoshoMei;
    /** 営業所種別 */
    private String eigyoshoShubetsu;
    

    public String getEigyoshoCd() {
        return eigyoshoCd;
    }

    public void setEigyoshoCd(String eigyoshoCd) {
        this.eigyoshoCd = eigyoshoCd;
    }

    public String getEigyoshoMei() {
        return eigyoshoMei;
    }

    public void setEigyoshoMei(String eigyoshoMei) {
        this.eigyoshoMei = eigyoshoMei;
    }

    public String getEigyoshoShubetsu() {
        return eigyoshoShubetsu;
    }

    public void setEigyoshoShubetsu(String eigyoshoShubetsu) {
        this.eigyoshoShubetsu = eigyoshoShubetsu;
    }
    
    
}
