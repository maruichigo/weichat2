/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.mst.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import java.util.Map;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.mst.dao.Mst042Dao;
import jp.co.kintetsuls.common.cnst.SysMsg;
import jp.co.kintetsuls.utils.CheckUtils;
import jp.co.kintetsuls.utils.StrUtils;

/**
 * 営業所マスタ詳細の履歴情報取得処理
 *
 * @author 雷珍 (MBP)
 * @version 2019/3/29 新規作成
 */
@Component("MST042_SEARCH_RIREKI")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Mst042BusSearchRireki extends BaseBus {

    /**
     * 営業所マスタ詳細Dao定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected Mst042Dao mst042Dao;

    /**
     * 営業所マスタ詳細履歴情報取得処理
     *
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {

        // パラメータを解析する
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
        // 履歴表示区分
        String searchFlg = StrUtils.defaultString(params.get("rirekiShowFlg"));
        // 検索結果
        List<Map<String, Object>> resultList = new ArrayList<>();
        // 営業所マスタ詳細履歴検索
        if(CheckUtils.isEqual(searchFlg, "1")) {
            // 履歴表示区分 = 1(適用開始日毎)の場合
            resultList = mst042Dao.findForSearchRireki(params); 
        } else {
            // 履歴表示区分 = 2(全更新履歴)
            resultList = mst042Dao.findForSearchRirekiAllUpdate(params); 
        }
        
        if (resultList == null) {
           // メッセージを表示させ、処理を終了
            String msg = SysMsg.WRNDATA;
            serviceInterfaceBean.addMessage("WARN", "警告", msg);
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return;
        } else {
            // 取得件数 = 0以外の場合
            // 変数：適用終了
            String[] tekiyoShuryoKbn;
            // 変数：使用区分
            List<String> shiyoKbnList = new ArrayList<String>();
            for (Map<String, Object> detail : resultList) {
                // 適用終了設定
                tekiyoShuryoKbn = new String[1];
                // 使用区分設定
                shiyoKbnList = new ArrayList<String>();
                
                // 適用終了設定
                if ("0".equals(detail.get("TEKIYO_SHURYO"))) {
                    // 適用終了設定しない																				
                    tekiyoShuryoKbn[0] = "0";
                } else {
                    // 適用終了設定します
                    tekiyoShuryoKbn[0] = "1";
                }
                // 使用区分を再設定する
                detail.remove("TEKIYO_SHURYO");
                detail.put("TEKIYO_SHURYO", tekiyoShuryoKbn);
                
                // 使用区分.集荷営業所の設定															
                if ("1".equals(detail.get("SHUKA_EIGYOSHO_FLG"))) {
                    // 実行結果.集荷営業所フラグが「1:集荷営業所業務可」の場合
                    shiyoKbnList.add("1");
                }
                // 使用区分.配達営業所の設定															
                if ("1".equals(detail.get("HAITATSU_EIGYOSHO_FLG"))) {
                    // 実行結果.配達営業所フラグが「1:配達営業所業務可」の場合
                    shiyoKbnList.add("2");
                }
                // 使用区分.チャーター起点の設定															
                if ("1".equals(detail.get("KITEN_FLG"))) {
                    // 実行結果.起点フラグが「1:配達起点」の場合
                    shiyoKbnList.add("3");
                }
                // 使用区分.売上の設定															
                if ("1".equals(detail.get("URIAGE_FLG"))) {
                    // 実行結果.売上計上フラグが「1:売上計上を行う」の場合
                    shiyoKbnList.add("4");
                }
                // 使用区分.発券営業所の設定															
                if ("1".equals(detail.get("HAKKEN_EIGYOSHO_FLG"))) {
                    // 実行結果.発券営業所フラグが「1:発券営業所業務可」の場合
                    shiyoKbnList.add("5");
                }
                // 使用区分.車両管理の設定															
                if ("1".equals(detail.get("SHARYO_KANRI_FLG"))) {
                    // 実行結果.車両管理フラグが「1:車両管理を行う」の場合
                    shiyoKbnList.add("6");
                }
                // 使用区分.配達伝票出力営業所の設定
                if ("1".equals(detail.get("HAIDEN_OUTPUT_EIGYOSHO_FLG"))) {
                    // 実行結果.配達伝票出力営業所フラグが「1:配達伝票出力業務可能」の場合
                    shiyoKbnList.add("7");
                }
                if (shiyoKbnList.isEmpty()) {
                    // 画面．使用区分設定
                    String[] knrDtlShiyoKbn = {"0", "0", "0", "0", "0", "0", "0"};
                    // 画面．使用区分設定
                    detail.put("SHI_YO_KBN", knrDtlShiyoKbn);
                } else {
                    // 画面．使用区分設定
                    detail.put("SHI_YO_KBN", shiyoKbnList.toArray(new String[shiyoKbnList.size()]));
                }
            }
        }
        
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
    }
}
