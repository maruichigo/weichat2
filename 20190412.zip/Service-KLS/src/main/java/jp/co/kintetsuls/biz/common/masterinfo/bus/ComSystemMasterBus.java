/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.common.masterinfo.bus;

import java.util.List;
import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;

import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.table.dao.MsSystemDao;
import jp.co.kintetsuls.biz.table.model.MsSystem;
import jp.co.kintetsuls.common.json.JSONUtil;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * システムマスタ内容取得処理クラス
 * 
 * @author zf (MBP)
 * @version 2019/2/25 新規作成
 */
@Component("COMMON_GET_SYSTEM_MASTER")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ComSystemMasterBus extends BaseBus {

    // Dao定義
    @Autowired(required=true)
    @Resource(shareable=true)
    protected MsSystemDao msSystemDao;
    
    public List<MsSystem> systemList;

    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception{
        
        systemList = msSystemDao.findAll();
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(systemList));
    }
}