/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.mst.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;

import java.util.Map;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.mst.dao.Mst031Dao;
import jp.co.kintetsuls.common.cnst.SysMsg;

/**
 * 住所マスタ情報取得処理
 *
 * @author 曾鳳(MBP)
 * @version 2019/2/14 新規作成
 */
@Component("MST031_GET_DETAIL")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Mst031BusSearch extends BaseBus {

    /**
     * Dao定義
     */
    @Autowired(required=true)
    @Resource(shareable=true)
    protected Mst031Dao mst031Dao;

    /**
     * 住所マスタ情報取得処理
     * 
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception 
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception{

        // パラメータを取得する
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

        List<Map<String, String>> result = mst031Dao.selectDetail(params);
        if (result == null){
            String msg = SysMsg.WRNDATA;
            serviceInterfaceBean.addMessage("WARN", "警告", msg);
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            return;
        }

        // 結果情報を設定する
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));

        // 正常終了の場合、メッセージを設定する
        serviceInterfaceBean.addMessage("INFO", "情報", "方法");
    }
}