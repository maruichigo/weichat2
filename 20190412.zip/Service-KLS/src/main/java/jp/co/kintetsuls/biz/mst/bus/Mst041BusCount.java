/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.mst.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import java.util.Map;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.mst.dao.Mst041Dao;

/**
 * 営業所マスタ情報件数を取得する処理
 * 
 * @author 雷新然 (MBP)
 * @version 2019/2/19 新規作成
 */
@Component("MST041_SEARCH_KENSU")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Mst041BusCount extends BaseBus {

    /**
     * DAO定義
     */
    @Autowired(required=true)
    @Resource(shareable=true)
    protected Mst041Dao mst041Dao;

    /**
     * 営業所マスタ情報件数を取得する処理
     * 
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        
        // パラメータを解析する 
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

        // 営業所マスタ情報件数を取得する
        int result = mst041Dao.countForSearch(params);
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
        
        // 正常終了の場合、メッセージを設定する
        serviceInterfaceBean.addMessage("INFO", "情報", "方法");
    }
}