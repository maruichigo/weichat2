/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.mst.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.base.dao.BaseDao;
import jp.co.kintetsuls.biz.table.dao.MsShuyakuCdDao;
import jp.co.kintetsuls.biz.table.model.MsShuyakuCd;
import jp.co.kintetsuls.common.SystemColumn;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.cnst.StndConsIF;
import jp.co.kintetsuls.utils.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

/**
 * 集約コードマスタ登録・更新処理
 *
 * @author 许博 (MBP)
 * @version 2019/2/12 新規作成
 */
@Component("MST071_INSERT_UPDATE")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Mst071BusInsertUpdate extends BaseBus {

    /**
     * DAO定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsShuyakuCdDao msShuyakuCdDao;

    /**
     * 集約コードマスタ登録・更新処理
     *
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        
        // 更新レコード
        Map koshinMap = null;
        
        // 集約コードマスタエンティティ
        MsShuyakuCd entity = null;
        
        // パラメータを解析する
        ObjectMapper mapper = new ObjectMapper();
        List<Map<String, Object>> recordList = mapper.readValue(serviceInterfaceBean.getJson(), List.class);

        // 登録一覧リストを初期化する
        List<MsShuyakuCd> torokuIchiranList = new ArrayList();

        // 更新一覧リストを初期化する
        List<Map<String, MsShuyakuCd>> koshinIchiranList = new ArrayList();

        // 更新一覧履歴リストを初期化する
        List<MsShuyakuCd> koshinIchiranRirekiList = new ArrayList();

        // 集約コードマスタ登録更新
        for (Map<String, Object> record : recordList) {
            // 更新一覧リスト作成
            entity = new MsShuyakuCd();     
            
            if (null != record.get("addFlg")) {
                // システムカラムを設定する
                entity = SystemColumn.systemColumnSet(StndConsIF.SYSCOL_INSERT, entity, serviceInterfaceBean);

                entity.setEigyoshoCd(objectToString(record.get("listEigyoshoCd")));
                entity.setShuyakuKbn(objectToString(record.get("listShuyakuKbn")));
                entity.setShuyakuCd(objectToString(record.get("listShuyakuCd")));
                entity.setShuyakuCdMeisho(objectToString(record.get("listShuyakuCdMei")));
                entity.setBiko(objectToString(record.get("listBiko")));
                entity.setShuyakuCdDataVersion(1);
                entity.setSakujoFlg("0");

                torokuIchiranList.add(entity);
            } else {
                koshinMap = new HashMap();
                // システムカラムを設定する
                entity = SystemColumn.systemColumnSet(StndConsIF.SYSCOL_UPDATE, entity, serviceInterfaceBean);
                entity.setEigyoshoCd(objectToString(record.get("listEigyoshoCd")));
                entity.setShuyakuKbn(objectToString(record.get("listShuyakuKbn")));
                entity.setShuyakuCd(objectToString(record.get("listShuyakuCd")));
                entity.setShuyakuCdMeisho(objectToString(record.get("listShuyakuCdMei")));
                entity.setBiko(objectToString(record.get("listBiko")));
                entity.setShuyakuCdDataVersion(NumberUtils.toInt(objectToString(record.get("listDataVersion"))) + 1);
                koshinMap.put(BaseDao.UPDATE_BEAN_CRT, entity);
                koshinMap.put(BaseDao.UPDATE_BEAN_UPD, entity);

                koshinIchiranList.add(koshinMap);
                koshinIchiranRirekiList.add(entity);
            }
        }

        // 登録を実施
        if (torokuIchiranList.size() > 0) {
            msShuyakuCdDao.insert(torokuIchiranList);
            msShuyakuCdDao.createRirekiById(torokuIchiranList);
        }

        // 更新を実施
        if (koshinIchiranList.size() > 0) {
            msShuyakuCdDao.updateById(koshinIchiranList);
            msShuyakuCdDao.createRirekiById(koshinIchiranRirekiList);
        }

    }
}
