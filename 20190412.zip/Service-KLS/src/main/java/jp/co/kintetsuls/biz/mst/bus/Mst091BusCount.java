/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.mst.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.json.JSONUtil;
import java.util.Map;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.mst.dao.Mst091Dao;

/** 
 * 仕入予定一覧件数を取得する処理
 *
 * @author 廖鈺 (MBP)
 * @version 2019/1/24 新規作成
 */
@Component("MST091_COUNT")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Mst091BusCount extends BaseBus {

    /**
     * DAO定義
     */
    @Autowired(required=true)
    @Resource(shareable=true)
    protected Mst091Dao mst091Dao;
    
    /**
     * 仕入予定一覧件数を取得する処理
     * 
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {
        
        // パラメータを解析する 
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

        // 仕入予定一覧情報件数を取得する
        long result = mst091Dao.countForSearch(params);
        serviceInterfaceBean.setJson(JSONUtil.makeJSONString(result));
    }
}
