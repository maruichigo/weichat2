package jp.co.kintetsuls.biz.common.sequence.dao;

import jp.co.kintetsuls.biz.base.dao.BaseDao;
import org.springframework.stereotype.Component;

/**
 * シーケンス取得Dao
 *
 * @author ZC (MBP)
 * @version 2019/03/01 新規作成
 */
@Component
public class SequenceDao extends BaseDao {

    public Integer getSequence(String sqlId) {
        return getSqlSession().selectOne("sequence." + sqlId);
    }

}
