package jp.co.kintetsuls.biz.cus.model;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import lombok.Data;

/**
 * Cus011用モデルクラス
 * @author Yuka Kobayashi
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "cus011")
@Data
public class Cus011 implements Serializable {

    private static final long serialVersionUID = 7013090829426790999L;

    private String id;
    private String kokyakuCd;
    private Date tekiyoKaishibi;
    private String kokyakuMei;   
    private String kokyakuKanaMeisho;
    private String jusho;
    private String telBango1;
    private String shinseiStatusCd;
    private String seikyuEigyoshoCd;
    private String hojinGroupCd;
    private String sakujoFlg;
    private String honTorokuShinseiKanoFlg;
    private String actionFlg;       // 0:更新なし 1:登録 2:更新
    private String errFlg;          // 0:エラーなし 1:エラーあり
    private String checkFlg;        // 0:チェックなし 1:チェックあり
    
}
