/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.kintetsuls.biz.cus.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.cus.dao.Cus011Dao;
import jp.co.kintetsuls.biz.cus.model.Cus011;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import jp.co.kintetsuls.common.cnst.SysMsg;
import jp.co.kintetsuls.common.json.JSONUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

/**
 * 顧客マスタ情報削除処理
 */
@Component("CUS011_DELETE_KOKYAKU_LIST")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Cus011BusDelete extends BaseBus  {

    // Dao定義
    @Autowired(required=true)
    @Resource(shareable=true)
    protected Cus011Dao cus011Dao;
    private Map<String, Map<String, Object>> params = null;
    private Map<String, Object> selParams = null;
    private List<Map<String, Object>> delParams = null;

    @Override
    @Transactional(propagation=Propagation.REQUIRED, rollbackFor=RuntimeException.class)
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception{
        //init
        ObjectMapper mapper = new ObjectMapper();
        int result = 0;
        
        try{  
            params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
            selParams = params.get("SEARCH");
            delParams = (List<Map<String, Object>>)params.get("DELETE");

            //顧客マスタ論理削除
            result = cus011Dao.deleteKokyaku(delParams, selParams);
            //削除対象が無かった場合は処理終了
            if(result == 0) {
                serviceInterfaceBean.addMessage("WARN", "警告", "削除対象がありませんでした。");  
                serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                return;
            }
            
            //顧客マスタ取得
            List<Cus011> getResult = cus011Dao.getKokyakuList(selParams);
            if (getResult == null){
                String msg = SysMsg.WRNDATA;
                serviceInterfaceBean.addMessage("WARN", "警告", msg);
                serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
                return;
            }
            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(getResult));

            serviceInterfaceBean.addMessage("INFO", "情報", "顧客の削除が完了しました。");   
        }catch(Exception e){
            serviceInterfaceBean.setStatusCode(ServiceInterfaceBean.PROCESS_STATUS_ERROR);
            serviceInterfaceBean.setJson(JSONUtil.makeJSONString(ServiceInterfaceBean.PROCESS_STATUS_ERROR));
            serviceInterfaceBean.addMessage("ERROR", "ERROR", "顧客の削除が失敗しました。");
            throw new RuntimeException();
        }

    }    
}
