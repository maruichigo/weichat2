/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.mst.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import java.util.Map;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.base.dao.BaseDao;
import jp.co.kintetsuls.biz.mst.dao.Mst091Dao;
import jp.co.kintetsuls.biz.table.dao.MsShiireYoteiDao;
import jp.co.kintetsuls.biz.table.dao.MsShiireYoteiMeisaiDao;
import jp.co.kintetsuls.biz.table.model.MsShiireYotei;
import jp.co.kintetsuls.biz.table.model.MsShiireYoteiMeisai;
import jp.co.kintetsuls.common.SystemColumn;
import jp.co.kintetsuls.common.cnst.StndConsIF;

/**
 * 仕入予定明細マスタ削除処理
 *
 * @author 廖鈺 (MBP)
 * @version 2019/1/25 新規作成
 */
@Component("MST091_DELETE")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Mst091BusDelete extends BaseBus {

    /**
     * DAO定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected Mst091Dao mst091Dao;

    /**
     * DAO定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsShiireYoteiMeisaiDao msShiireYoteiMeisaiDao;

    /**
     * DAO定義
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected MsShiireYoteiDao msShiireYoteiDao;

    /**
     * 仕入予定明細マスタ削除処理
     *
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {

        // 明細NO検索パラメータリスト
        Map param = null;
        // 削除一覧リスト
        Map koshinMap = null;
        // 適用開始日フォーマット
        Date tekiyoKaishibi = null;
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        // 仕入予定明細マスタ　エンティティ
        MsShiireYoteiMeisai entityMsShiireYoteiMeisai = null;
        // 仕入予定マスタ エンティティ
        MsShiireYotei entityMsShiireYotei = null;

        // パラメータを解析する
        ObjectMapper mapper = new ObjectMapper();
        List<Map<String, Object>> recordList = mapper.readValue(serviceInterfaceBean.getJson(), List.class);

        // 仕入予定マスタ削除一覧リストを生成する
        List<Map<String, MsShiireYotei>> shiireYoteiSakujyoIchiranList = new ArrayList();
        // 仕入予定マスタ削除一覧履歴リストを初期化する
        List<MsShiireYotei> shiireYoteiSakujyoIchiranRirekiList = new ArrayList();

        // 仕入予定明細マスタ削除一覧リストを生成する
        List<Map<String, MsShiireYoteiMeisai>> shiireYoteiMeisaiSakujyoIchiranList = new ArrayList();
        // 仕入予定明細マスタ削除一覧履歴リストを初期化する
        List<MsShiireYoteiMeisai> shiireYoteiMeisaiSakujyoIchiranRirekiList = new ArrayList();

        if (recordList != null && recordList.size() > 0) {
            for (Map<String, Object> record : recordList) {

                // 明細NO検索パラメータリスト作成
                param = new HashMap();

                // 営業所コード
                param.put("listEigyoshoCd", record.get("listEigyoshoCd"));
                // 仕入先コード
                param.put("listShiiresakiCd", record.get("listShiiresakiCd"));
                // 仕入区分コード
                param.put("listShiireKbnCd", record.get("listShiireKbnCd"));
                // 適用開始日
                param.put("listTekiyoKaisibi", record.get("listTekiyoKaisibi"));

                // 明細NO検索を処理する
                List<Map<String, Object>> resultList = mst091Dao.findMeiSaiNo(param);

                for (Map<String, Object> result : resultList) {
                    
                    // 削除一覧リスト作成
                    koshinMap = new HashMap();
                    // 適用開始日
                    tekiyoKaishibi = dateFormat.parse(record.get("listTekiyoKaisibi").toString());

                    // 仕入予定明細マスタ削除処理を行う
                    entityMsShiireYoteiMeisai = new MsShiireYoteiMeisai();
                    // システムカラム更新
                    entityMsShiireYoteiMeisai = SystemColumn.systemColumnSet(
                            StndConsIF.SYSCOL_UPDATE, entityMsShiireYoteiMeisai, serviceInterfaceBean);

                    // 営業所コード
                    entityMsShiireYoteiMeisai.setEigyoshoCd(objectToString(record.get("listEigyoshoCd")));
                    // 明細NO
                    entityMsShiireYoteiMeisai.setMeisaiNo(Integer.valueOf(result.get("listMeisaiNo").toString()));
                    // 仕入先コード
                    entityMsShiireYoteiMeisai.setShiiresakiCd(objectToString(record.get("listShiiresakiCd")));
                    // 仕入区分コード
                    entityMsShiireYoteiMeisai.setShiireKbnCd(objectToString(record.get("listShiireKbnCd")));
                    // 適用開始日
                    entityMsShiireYoteiMeisai.setTekiyoKaishibi(tekiyoKaishibi);
                    // 削除フラグ
                    entityMsShiireYoteiMeisai.setSakujoFlg("1");
                    // 仕入予定データバージョン
                    entityMsShiireYoteiMeisai.setShiireYoteiDataVersion(
                            Integer.valueOf(objectToString(record.get("listDataVersion"))) + 1);

                    // 削除一覧リストを設定する
                    koshinMap.put(BaseDao.UPDATE_BEAN_CRT, entityMsShiireYoteiMeisai);
                    koshinMap.put(BaseDao.UPDATE_BEAN_UPD, entityMsShiireYoteiMeisai);

                    // 仕入予定明細マスタ削除一覧リストを設定する
                    shiireYoteiMeisaiSakujyoIchiranList.add(koshinMap);
                    // 仕入予定明細マスタ削除一覧履歴リストを設定する
                    shiireYoteiMeisaiSakujyoIchiranRirekiList.add(entityMsShiireYoteiMeisai);

                }

                // 仕入予定マスタ削除処理を行う
                koshinMap = new HashMap();
                // 仕入予定明細マスタ削除処理を行う
                entityMsShiireYotei = new MsShiireYotei();

                // システムカラム更新
                entityMsShiireYotei = SystemColumn.systemColumnSet(
                        StndConsIF.SYSCOL_UPDATE, entityMsShiireYotei, serviceInterfaceBean);
                // 営業所コード
                entityMsShiireYotei.setEigyoshoCd(objectToString(record.get("listEigyoshoCd")));
                // 仕入先コード
                entityMsShiireYotei.setShiiresakiCd(objectToString(record.get("listShiiresakiCd")));
                // 仕入区分コード
                entityMsShiireYotei.setShiireKbnCd(objectToString(record.get("listShiireKbnCd")));
                // 適用開始日
                entityMsShiireYotei.setTekiyoKaishibi(tekiyoKaishibi);
                // 削除フラグ
                entityMsShiireYotei.setSakujoFlg("1");
                // 仕入予定データバージョン
                entityMsShiireYotei.setShiireYoteiDataVersion(
                        Integer.valueOf(objectToString(record.get("listDataVersion"))) + 1);

                // 削除一覧リストを設定する
                koshinMap.put(BaseDao.UPDATE_BEAN_CRT, entityMsShiireYotei);
                koshinMap.put(BaseDao.UPDATE_BEAN_UPD, entityMsShiireYotei);

                // 仕入予定マスタ削除一覧リストを設定する
                shiireYoteiSakujyoIchiranList.add(koshinMap);
                // 仕入予定マスタ削除一覧履歴リストを設定する
                shiireYoteiSakujyoIchiranRirekiList.add(entityMsShiireYotei);

            }

            // 仕入予定明細マスタ削除を実施
            if (shiireYoteiMeisaiSakujyoIchiranList.size() > 0) {

                msShiireYoteiMeisaiDao.updateById(shiireYoteiMeisaiSakujyoIchiranList);
                msShiireYoteiMeisaiDao.createRirekiById(shiireYoteiMeisaiSakujyoIchiranRirekiList);
            }

            // 仕入予定マスタ削除を実施
            if (shiireYoteiSakujyoIchiranList.size() > 0) {

                msShiireYoteiDao.updateById(shiireYoteiSakujyoIchiranList);
                msShiireYoteiDao.createRirekiById(shiireYoteiSakujyoIchiranRirekiList);
            }
        }
    }
}
