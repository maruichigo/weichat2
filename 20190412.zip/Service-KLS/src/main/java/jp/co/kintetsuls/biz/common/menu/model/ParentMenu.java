package jp.co.kintetsuls.biz.common.menu.model;

import java.io.Serializable;
import java.util.List;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/** 
 * メニューマスタクラス
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "parentMenu")
public class ParentMenu implements Serializable{

    private static final long serialVersionUID = 8965633291910057625L;

    @Size(max = 20)
    private String parentGroupId;

    private String parentGroupName;

    private List<ChildMenu> childs;
    
    /**親メニューグループIDの取得
     * @return 親メニューグループID
     */
    @XmlElement(name = "parentGroupId")
    public String getParentGroupId() {
        return parentGroupId;
    }
    /**親メニューグループIDの設定
     * @param parentGroupId 親メニューグループID
     */
    public void setParentGroupId(String parentGroupId) {
        this.parentGroupId = parentGroupId;
    }
    /**親メニューグループ名の取得
     * @return 親メニューグループ名
     */
    @XmlElement(name = "parentGroupName")
    public String getParentGroupName() {
        return parentGroupName;
    }
    /**親メニューグループ名の設定
     * @param parentGroupName 親メニューグループ名
     */
    public void setParentGroupName(String parentGroupName) {
        this.parentGroupName = parentGroupName;
    }
    /**
     * 子メニューリストを取得
     * @return 
     */
    public List<ChildMenu> getChilds() {
        return childs;
    }
    /**
     * 子メニューリストを設定
     * @param childs 
     */
    public void setChilds(List<ChildMenu> childs) {
        this.childs = childs;
    }
    
}
