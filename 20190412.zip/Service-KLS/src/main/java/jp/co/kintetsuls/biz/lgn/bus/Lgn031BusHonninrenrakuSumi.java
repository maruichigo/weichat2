/*
 * Copyright (c) Shared System Inc.
 */
package jp.co.kintetsuls.biz.lgn.bus;

import com.fasterxml.jackson.databind.ObjectMapper;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import jp.co.kintetsuls.common.bean.ServiceInterfaceBean;
import java.util.Map;
import jp.co.kintetsuls.biz.base.bus.BaseBus;
import jp.co.kintetsuls.biz.table.dao.TrPasswordShokikaShinseiShosaiDao;
import jp.co.kintetsuls.biz.table.model.TrPasswordShokikaShinseiShosai;
import jp.co.kintetsuls.common.SystemColumn;
import jp.co.kintetsuls.common.cnst.StndConsIF;

/**
 * 本人連絡済処理
 *
 * @author 黄義輝 (MBP)
 * @version 2019/04/01 新規作成
 */
@Component("LGN031_UPDATE_HONNINRENRAKUSUMI")
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Lgn031BusHonninrenrakuSumi extends BaseBus {

    /**
     * パスワード初期化申請詳細Dao
     */
    @Autowired(required = true)
    @Resource(shareable = true)
    protected TrPasswordShokikaShinseiShosaiDao trPasswordShokikaShinseiShosaiDao;

    /**
     * パスワード初期化申請詳細定義
     */
    protected TrPasswordShokikaShinseiShosai trPasswordShokikaShinseiShosai;

    /**
     * 本人連絡済処理
     * 
     * @param serviceInterfaceBean JSFからの通信情報
     * @throws Exception　異常
     */
    @Override
    public void process(ServiceInterfaceBean serviceInterfaceBean) throws Exception {

        // パラメータを解析する
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> param = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);

        // ワーク.ユーザーコード
        String hyoDtlUserCd = objectToString(param.get("hyoDtlUserCd"));
        // ワーク.申請ID
        String shinseiId = objectToString(param.get("shinseiId"));

        // パスワード初期化申請詳細に登録を行う。
        trPasswordShokikaShinseiShosai = new TrPasswordShokikaShinseiShosai();
        // システムカラム
        trPasswordShokikaShinseiShosai = SystemColumn.systemColumnSet(
                StndConsIF.SYSCOL_UPDATE, trPasswordShokikaShinseiShosai, serviceInterfaceBean);
        // 申請ID
        trPasswordShokikaShinseiShosai.setShinseiId(shinseiId);
        // ユーザコード
        trPasswordShokikaShinseiShosai.setUserCd(hyoDtlUserCd);
        // 本人確認済フラグ
        trPasswordShokikaShinseiShosai.setHonninKakuninSumiFlg("1");
        // パスワード初期化申請詳細登録
        trPasswordShokikaShinseiShosaiDao.updateById(trPasswordShokikaShinseiShosai, trPasswordShokikaShinseiShosai);

    }
}