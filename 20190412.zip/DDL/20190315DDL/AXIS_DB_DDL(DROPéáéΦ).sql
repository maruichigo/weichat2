﻿DROP TABLE MS_DB_ACCESS_KYOKA_MACHINE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_DB_ACCESS_KYOKA_MACHINE
(
    IP_ADDRESS                      VARCHAR2(16) NOT NULL,
    HOST_MEI                        VARCHAR2(20) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_DB_ACCESS_KYOKA_MACHINE
    ADD(CONSTRAINT PK_MS_DB_ACCESS_KYOKA_MACHINE PRIMARY KEY (IP_ADDRESS) USING INDEX)
/
DROP TABLE TR_DB_KANSA_LOG_ZENKAI_CHECK_TIME_STAMP CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_DB_KANSA_LOG_ZENKAI_CHECK_TIME_STAMP
(
    EXTENDED_TIMESTAMP              TIMESTAMP(6) WITH TIME ZONE NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
DROP TABLE TR_DB_KANSA_LOG_HOZON CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_DB_KANSA_LOG_HOZON
(
    OS_USERNAME_LOG                 VARCHAR2(255) NOT NULL,
    USERNAME_LOG                    VARCHAR2(30) NOT NULL,
    USERHOST_LOG                    VARCHAR2(128) NOT NULL,
    TERMINAL_LOG                    VARCHAR2(255),
    TIMESTAMP_LOG                   DATE NOT NULL,
    OWNER_LOG                       VARCHAR2(30),
    OBJ_NAME_LOG                    VARCHAR2(128),
    ACTION_LOG                      NUMBER,
    ACTION_NAME_LOG                 VARCHAR2(28),
    NEW_OWNER_LOG                   VARCHAR2(30),
    NEW_NAME_LOG                    VARCHAR2(128),
    OBJ_PRIVILEGE_LOG               VARCHAR2(16),
    SYS_PRIVILEGE_LOG               VARCHAR2(40),
    ADMIN_OPTION_LOG                VARCHAR2(1),
    GRANTEE_LOG                     VARCHAR2(30),
    AUDIT_OPTION_LOG                VARCHAR2(40),
    SES_ACTIONS_LOG                 VARCHAR2(19),
    LOGOFF_TIME_LOG                 DATE,
    LOGOFF_LREAD_LOG                NUMBER,
    LOGOFF_PREAD_LOG                NUMBER,
    LOGOFF_LWRITE_LOG               NUMBER,
    LOGOFF_DLOCK_LOG                VARCHAR2(40),
    COMMENT_TEXT_LOG                VARCHAR2(4000),
    SESSIONID_LOG                   NUMBER NOT NULL,
    ENTRYID_LOG                     NUMBER,
    STATEMENTID_LOG                 NUMBER,
    RETURNCODE_LOG                  NUMBER,
    PRIV_USED_LOG                   VARCHAR2(40),
    CLIENT_ID_LOG                   VARCHAR2(64),
    ECONTEXT_ID_LOG                 VARCHAR2(64),
    SESSION_CPU_LOG                 NUMBER,
    EXTENDED_TIMESTAMP_LOG          TIMESTAMP(6) WITH TIME ZONE NOT NULL,
    PROXY_SESSIONID_LOG             NUMBER,
    GLOBAL_UID_LOG                  VARCHAR2(32),
    INSTANCE_NUMBER_LOG             NUMBER,
    OS_PROCESS_LOG                  VARCHAR2(16),
    TRANSACTIONID_LOG               RAW(8),
    SCN_LOG                         NUMBER,
    SQL_BIND_LOG                    VARCHAR2(2000),
    SQL_TEXT_LOG                    VARCHAR2(2000),
    OBJ_EDITION_NAME_LOG            VARCHAR2(30),
    DBID_LOG                        NUMBER,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_DB_KANSA_LOG_HOZON
    ADD(CONSTRAINT PK_TR_DB_KANSA_LOG_HOZON PRIMARY KEY (OS_USERNAME_LOG, USERNAME_LOG, USERHOST_LOG, TIMESTAMP_LOG, SESSIONID_LOG) USING INDEX)
/
DROP TABLE TR_EDI_KOKYAKU_JOHO_SETTEI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_EDI_KOKYAKU_JOHO_SETTEI
(
    EDI_SETTEI_ID                   CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    EDI_SETTEI_DATA_VERSION         NUMBER(3,0) NOT NULL,
    KOKYAKU_CD                      CHAR(6),
    DAIHYOU_KOKYAKU_FLG             CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_EDI_KOKYAKU_JOHO_SETTEI
    ADD(CONSTRAINT PK_TR_EDI_KOKYAKU_JOHO_SETTEI PRIMARY KEY (EDI_SETTEI_ID, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE TR_EDI_KOKYAKU_JOHO_SETTEI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_EDI_KOKYAKU_JOHO_SETTEI_RIREKI
(
    EDI_SETTEI_ID                   CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    EDI_SETTEI_DATA_VERSION         NUMBER(3,0) NOT NULL,
    KOKYAKU_CD                      CHAR(6),
    DAIHYOU_KOKYAKU_FLG             CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_EDI_KOKYAKU_JOHO_SETTEI_RIREKI
    ADD(CONSTRAINT PK_TR_EDI_KOKYAKU_JOHO_SETTEI_RIREKI PRIMARY KEY (EDI_SETTEI_ID, TEKIYO_KAISHIBI, EDI_SETTEI_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_EDI_SHUBETSU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_EDI_SHUBETSU
(
    EDI_SHUBETSU_CD                 CHAR(2) NOT NULL,
    EDI_SHUBETSU                    VARCHAR2(40),
    SOUJUSHIN_SHUBETSU              CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_EDI_SHUBETSU
    ADD(CONSTRAINT PK_MS_EDI_SHUBETSU PRIMARY KEY (EDI_SHUBETSU_CD) USING INDEX)
/
DROP TABLE MS_EDI_SETTEI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_EDI_SETTEI
(
    EDI_SETTEI_ID                   CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    EDI_SETTEI_DATA_VERSION         NUMBER(3,0) NOT NULL,
    KBN_CD                          CHAR(1) NOT NULL,
    JIKKO_KEKKA_MAIL_TITLE          VARCHAR2(40),
    SYSTEM_MEISHO_CD                CHAR(3),
    BATCH_MEISHO_CD                 CHAR(8),
    KINOU_MEISHO_CD                 CHAR(10),
    EDI_IF_SHUBETSU_CD              CHAR(2),
    EDI_HYOJI_MEISHO                VARCHAR2(40),
    SCRIPT_ID                       VARCHAR2(8) NOT NULL,
    FILE_PATH                       VARCHAR2(512),
    FILE_MEI                        VARCHAR2(512),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TEKIYO_MEI                      VARCHAR2(40),
    TEKIYO_SHURYOBI                 DATE,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_EDI_SETTEI
    ADD(CONSTRAINT PK_MS_EDI_SETTEI PRIMARY KEY (EDI_SETTEI_ID, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE MS_EDI_SETTEI1_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_EDI_SETTEI1_RIREKI
(
    EDI_SETTEI_ID                   CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    EDI_SETTEI_DATA_VERSION         NUMBER(3,0) NOT NULL,
    KBN_CD                          CHAR(1) NOT NULL,
    JIKKO_KEKKA_MAIL_TITLE          VARCHAR2(40),
    SYSTEM_MEISHO_CD                CHAR(3),
    BATCH_MEISHO_CD                 CHAR(8),
    KINOU_MEISHO_CD                 CHAR(10),
    EDI_IF_SHUBETSU_CD              CHAR(2),
    EDI_HYOJI_MEISHO                VARCHAR2(40),
    SCRIPT_ID                       VARCHAR2(8) NOT NULL,
    FILE_PATH                       VARCHAR2(512),
    FILE_MEI                        VARCHAR2(512),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TEKIYO_MEI                      VARCHAR2(40),
    TEKIYO_SHURYOBI                 DATE,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_EDI_SETTEI1_RIREKI
    ADD(CONSTRAINT PK_MS_EDI_SETTEI_RIREKI PRIMARY KEY (EDI_SETTEI_ID, TEKIYO_KAISHIBI, EDI_SETTEI_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_EDI_SOSHIN_KANRI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_EDI_SOSHIN_KANRI
(
    OKURIJO_NO                      CHAR(13) NOT NULL,
    SHUKABI                         CHAR(8) NOT NULL,
    EDI_SOSHIN_HIZUKE               CHAR(8),
    EDI_SOSHIN_JIKAN                CHAR(6),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_EDI_SOSHIN_KANRI
    ADD(CONSTRAINT PK_TR_EDI_SOSHIN_KANRI PRIMARY KEY (OKURIJO_NO) USING INDEX)
/
DROP TABLE TR_GPS_LOG CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_GPS_LOG
(
    KEITAI_DENWA_BANGO              VARCHAR2(19) NOT NULL,
    NICHIJI                         DATE NOT NULL,
    TANTOSHA                        VARCHAR2(7) NOT NULL,
    SHABAN                          VARCHAR2(5) NOT NULL,
    COURSE                          VARCHAR2(8) NOT NULL,
    KEIDO                           NUMBER(9,6) NOT NULL,
    IDO                             NUMBER(8,6) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_GPS_LOG
    ADD(CONSTRAINT PK_TR_GPS_LOG PRIMARY KEY (KEITAI_DENWA_BANGO, NICHIJI, TANTOSHA, SHABAN, COURSE) USING INDEX)
/
DROP TABLE MS_JIS_CD CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_JIS_CD
(
    JIS_CD                          CHAR(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    JIS_CD_DATA_VERSION             NUMBER(3,0) NOT NULL,
    TODOFUKEN_CD                    CHAR(2),
    SHIKUCHOSON_MEI_KANJI           VARCHAR2(40),
    SHIKUCHOSON_MEI_KANA            VARCHAR2(40) NOT NULL,
    DUMMY_JIS_FLG                   CHAR(1) NOT NULL,
    SHINKI_ZIDO_TOROKUBI            DATE,
    HENKO_KEIKOKUBI                 DATE,
    HENKO_TODOFUKEN_MEI_KANJI       VARCHAR2(40),
    HENKO_TODOFUKEN_MEI_KANA        VARCHAR2(40),
    HENKO_SHIKUCHOSON_MEI_KANJI     VARCHAR2(40),
    HENKO_SHIKUCHOSON_MEI_KANA      VARCHAR2(40),
    SAKUJO_KEIKOKUBI                DATE,
    HENKO_KAKUNIN_SKIP_FLG          CHAR(1),
    SAKUJO_KAKUNIN_SKIP_FLG         CHAR(1),
    ZIDO_CHECKBI                    DATE,
    SAKUJO_ZIDO_CHECKBI             DATE,
    SHOKI_TOROKUBI                  DATE,
    SAISHU_KOSHINBI                 DATE,
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_JIS_CD
    ADD(CONSTRAINT PK_MS_JIS_CD PRIMARY KEY (JIS_CD, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE MS_JIS_CD_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_JIS_CD_RIREKI
(
    JIS_CD                          CHAR(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    JIS_CD_DATA_VERSION             NUMBER(3,0) NOT NULL,
    TODOFUKEN_CD                    CHAR(2),
    SHIKUCHOSON_MEI_KANJI           VARCHAR2(40),
    SHIKUCHOSON_MEI_KANA            VARCHAR2(40) NOT NULL,
    DUMMY_JIS_FLG                   CHAR(1) NOT NULL,
    SHINKI_ZIDO_TOROKUBI            DATE,
    HENKO_KEIKOKUBI                 DATE,
    HENKO_TODOFUKEN_MEI_KANJI       VARCHAR2(40),
    HENKO_TODOFUKEN_MEI_KANA        VARCHAR2(40),
    HENKO_SHIKUCHOSON_MEI_KANJI     VARCHAR2(40),
    HENKO_SHIKUCHOSON_MEI_KANA      VARCHAR2(40),
    SAKUJO_KEIKOKUBI                DATE,
    HENKO_KAKUNIN_SKIP_FLG          CHAR(1),
    SAKUJO_KAKUNIN_SKIP_FLG         CHAR(1),
    ZIDO_CHECKBI                    DATE,
    SAKUJO_ZIDO_CHECKBI             DATE,
    SHOKI_TOROKUBI                  DATE,
    SAISHU_KOSHINBI                 DATE,
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_JIS_CD_RIREKI
    ADD(CONSTRAINT PK_MS_JIS_CD_RIREKI PRIMARY KEY (JIS_CD, TEKIYO_KAISHIBI, JIS_CD_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_JIS_HENKAN_JOHO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_JIS_HENKAN_JOHO
(
    JIS_CD                          CHAR(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    JIS_HENKAN_JOHO_SEQ             NUMBER(3,0) NOT NULL,
    JUSHO_JIS_DATA_VERSION          NUMBER(3,0) NOT NULL,
    HENKAN_JOHO_JUSHO               VARCHAR2(40),
    KYU_JUSHO_FLG                   CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_JIS_HENKAN_JOHO
    ADD(CONSTRAINT PK_MS_JIS_HENKAN_JOHO PRIMARY KEY (JIS_CD, TEKIYO_KAISHIBI, JIS_HENKAN_JOHO_SEQ) USING INDEX)
/
DROP TABLE MS_JIS_HENKAN_JOHO_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_JIS_HENKAN_JOHO_RIREKI
(
    JIS_CD                          CHAR(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    JIS_HENKAN_JOHO_SEQ             NUMBER(3,0) NOT NULL,
    JUSHO_JIS_DATA_VERSION          NUMBER(3,0) NOT NULL,
    HENKAN_JOHO_JUSHO               VARCHAR2(40),
    KYU_JUSHO_FLG                   CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_JIS_HENKAN_JOHO_RIREKI
    ADD(CONSTRAINT PK_MS_JIS_HENKAN_JOHO_RIREKI PRIMARY KEY (JIS_CD, TEKIYO_KAISHIBI, JIS_HENKAN_JOHO_SEQ, JUSHO_JIS_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_KING_CD_HENKAN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KING_CD_HENKAN
(
    KOKUNAI_KASHO_KBN               VARCHAR2(3) NOT NULL,
    YUNYU_KASHO_CD                  VARCHAR2(15) NOT NULL,
    YUNYU_KOKYAKU_CD                VARCHAR2(15) NOT NULL,
    HAMBAI_KEITAI_KBN               VARCHAR2(1) NOT NULL,
    KING_CD_HENKAN_DATA_VERSION     NUMBER(3,0) NOT NULL,
    KOKYAKU_CD                      CHAR(6),
    YOBI_1                          VARCHAR2(3),
    YOBI_2                          VARCHAR2(3),
    YOBI_3                          VARCHAR2(3),
    YOBI_4                          VARCHAR2(3),
    YOBI_5                          VARCHAR2(3),
    YOBI_6                          VARCHAR2(3),
    YOBI_7                          VARCHAR2(3),
    YOBI_8                          VARCHAR2(3),
    YOBI_9                          VARCHAR2(3),
    YOBI_10                         VARCHAR2(3),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KING_CD_HENKAN
    ADD(CONSTRAINT PK_MS_KING_CD_HENKAN PRIMARY KEY (KOKUNAI_KASHO_KBN, YUNYU_KASHO_CD, YUNYU_KOKYAKU_CD, HAMBAI_KEITAI_KBN) USING INDEX)
/
DROP TABLE MS_KING_CD_HENKAN_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KING_CD_HENKAN_RIREKI
(
    KOKUNAI_KASHO_KBN               VARCHAR2(3) NOT NULL,
    YUNYU_KASHO_CD                  VARCHAR2(15) NOT NULL,
    YUNYU_KOKYAKU_CD                VARCHAR2(15) NOT NULL,
    HAMBAI_KEITAI_KBN               VARCHAR2(1) NOT NULL,
    KING_CD_HENKAN_DATA_VERSION     NUMBER(3,0) NOT NULL,
    KOKYAKU_CD                      CHAR(6),
    YOBI_1                          VARCHAR2(3),
    YOBI_2                          VARCHAR2(3),
    YOBI_3                          VARCHAR2(3),
    YOBI_4                          VARCHAR2(3),
    YOBI_5                          VARCHAR2(3),
    YOBI_6                          VARCHAR2(3),
    YOBI_7                          VARCHAR2(3),
    YOBI_8                          VARCHAR2(3),
    YOBI_9                          VARCHAR2(3),
    YOBI_10                         VARCHAR2(3),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KING_CD_HENKAN_RIREKI
    ADD(CONSTRAINT PK_MS_KING_CD_HENKAN_RIREKI PRIMARY KEY (KOKUNAI_KASHO_KBN, YUNYU_KASHO_CD, YUNYU_KOKYAKU_CD, HAMBAI_KEITAI_KBN, KING_CD_HENKAN_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_KING_BUMON_HENKAN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KING_BUMON_HENKAN
(
    BUMON_CD                        VARCHAR2(4) NOT NULL,
    INSATSU_KASHO                   VARCHAR2(5),
    HENKANYO_KASHO_CD               VARCHAR2(3),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KING_BUMON_HENKAN
    ADD(CONSTRAINT PK_MS_KING_BUMON_HENKAN PRIMARY KEY (BUMON_CD) USING INDEX)
/
DROP TABLE MS_KONG_KWE_CD_HENKAN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KONG_KWE_CD_HENKAN
(
    AXIS_KOKYAKU_CD                 CHAR(6) NOT NULL,
    KWE_KEIRI_MOKU_CD               CHAR(4) NOT NULL,
    KWE_FUTAN_KAMOKU_CD             CHAR(6),
    KWE_FUTAN_KASHO_MEISHO          VARCHAR2(40),
    FUTAN_KASHO_KEIRI_MOKU_CD       CHAR(4),
    KWE_BUMON_MEISHO                VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KONG_KWE_CD_HENKAN
    ADD(CONSTRAINT PK_MS_KONG_KWE_CD_HENKAN PRIMARY KEY (AXIS_KOKYAKU_CD, KWE_KEIRI_MOKU_CD) USING INDEX)
/
DROP TABLE MS_KWE_KAMOKU_CD CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KWE_KAMOKU_CD
(
    CD                              VARCHAR2(50) NOT NULL,
    KANJO_KAMOKU                    VARCHAR2(50),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KWE_KAMOKU_CD
    ADD(CONSTRAINT PK_MS_KWE_KAMOKU_CD PRIMARY KEY (CD) USING INDEX)
/
DROP TABLE MS_KWE_KEIRI_MOKU_CD CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KWE_KEIRI_MOKU_CD
(
    MOKU                            VARCHAR2(50) NOT NULL,
    KASHO_MEI                       VARCHAR2(50),
    BUMON                           VARCHAR2(50),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KWE_KEIRI_MOKU_CD
    ADD(CONSTRAINT PK_MS_KWE_KEIRI_MOKU_CD PRIMARY KEY (MOKU) USING INDEX)
/
DROP TABLE MS_KWE_HENKAN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KWE_HENKAN
(
    TOKUISAKI_CD                    CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    KWE_KEIRI_MOKU_CD               CHAR(4),
    KWE_FUTAN_KAMOKU_CD             CHAR(6),
    KWE_FUTAN_KASHO_MEISHO          VARCHAR2(40),
    FUTAN_KASHO_KEIRI_MOKU_CD       CHAR(4),
    KWE_BUMON_MEISHO                VARCHAR2(40),
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KWE_HENKAN
    ADD(CONSTRAINT PK_MS_KWE_HENKAN PRIMARY KEY (TOKUISAKI_CD, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE TR_NECL_SHUKKA_SHIJI_CHIKUSEKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_NECL_SHUKKA_SHIJI_CHIKUSEKI
(
    OKURIJO_NO                      CHAR(13),
    TOIAWASE_BANGO                  CHAR(13),
    HIMODUKE_OYAKO_KBN              CHAR(1),
    SHUKKA_SYSTEM_KEY_BANGO         VARCHAR2(20),
    SHUKKA_SYSTEM_SHARYO_BANGO      CHAR(10),
    UNHAISO_SHARYO_BANGO            CHAR(10),
    UNSO_SHUDAN                     CHAR(3),
    GYOSHA                          CHAR(15),
    HIKITORISAKI_GYOSHA_CD          CHAR(15),
    HAISOBI                         CHAR(8),
    HAISO_SHITEI_HI                 CHAR(8),
    HAISO_SHITEI_JIKAN              CHAR(4),
    HAISO_SHITEI_JIKAN_JOKEN        CHAR(2),
    KYOTEN_CD                       CHAR(15),
    NIOKURININ_HAKKO_CD             VARCHAR2(20),
    NIOKURININ_MEI                  VARCHAR2(60),
    NIOKURININ_BUSHO                VARCHAR2(60),
    NIOKURININ_JIS_JUSHO_CD         CHAR(6),
    NIOKURININ_YUBIN_BANGO          CHAR(7),
    NIOKURININ_TODOFUKEN            VARCHAR2(20),
    NIOKURININ_SHIKUCHOSON          VARCHAR2(80),
    NIOKURININ_BANCHI               VARCHAR2(100),
    NIOKURININ_TEL_BANGO            VARCHAR2(19),
    HATSU_TEN_CD                    CHAR(10),
    UNSO_HIYO_SEIKYU_BUMON_CD       CHAR(7),
    UNSO_HIYO_SEIKYU_MOTO_BUMON_CD  CHAR(5),
    SHUKKA_KYOTEN_CD                CHAR(4),
    NI_TODOKESAKI_CD                CHAR(20),
    NI_TODOKESAKI_MEI               VARCHAR2(60),
    NI_TODOKESAKI_BUSHO             VARCHAR2(60),
    NI_TODOKESAKI_TANTOSHA          VARCHAR2(20),
    NI_TODOKESAKI_JIS_JUSHO_CD      CHAR(6),
    NI_TODOKESAKI_YUBIN_BANGO       CHAR(7),
    NI_TODOKESAKI_TODOFUKEN         VARCHAR2(20),
    NI_TODOKESAKI_SHIKUCHOSON       VARCHAR2(80),
    NI_TODOKESAKI_BANCHI            VARCHAR2(100),
    NI_TODOKESAKI_TEL_BANGO         VARCHAR2(19),
    CHAKU_TEN_CD                    CHAR(10),
    NITODOKE_JOKEN_CD               CHAR(2),
    CHAKU_TEN_NIATSUKAI_SHIJI       CHAR(2),
    KIJI                            VARCHAR2(120),
    MOTOBARAI_CHAKUBARAI_KBN_CD     CHAR(2),
    JOKEN_KBN_CD                    CHAR(1),
    YUSO_SHUDAN_CD                  CHAR(2),
    GOKEI_KOSU                      NUMBER(3,0),
    GOKEI_YOSEKI                    NUMBER(4,0),
    GOKEI_JURYO                     NUMBER(9,0),
    HADAKA_JURYO                    NUMBER(4,0),
    JURYOBUTSU_JURYO                NUMBER(4,0),
    HAISO_KANRYO_HI                 CHAR(8),
    KANRYO_JIKOKU                   CHAR(4),
    HAIKAN_JURYOSHA_SHIMEI          VARCHAR2(40),
    HIYO_CD_1                       CHAR(5),
    KOSU_1                          NUMBER(4,0),
    KINGAKU_1                       NUMBER(10,0),
    HIYO_CD_2                       CHAR(5),
    KOSU_2                          NUMBER(4,0),
    KINGAKU_2                       NUMBER(10,0),
    KOMOKU_CD_3                     CHAR(5),
    KOSU_3                          NUMBER(4,0),
    KINGAKU_3                       NUMBER(10,0),
    KOMOKU_CD_4                     CHAR(5),
    KOSU_4                          NUMBER(4,0),
    KINGAKU_4                       NUMBER(10,0),
    KOMOKU_CD_5                     CHAR(5),
    KOSU_5                          NUMBER(4,0),
    KINGAKU_5                       NUMBER(10,0),
    KOMOKU_CD_6                     CHAR(5),
    KOSU_6                          NUMBER(4,0),
    KINGAKU_6                       NUMBER(10,0),
    KOMOKU_CD_7                     CHAR(5),
    KOSU_7                          NUMBER(4,0),
    KINGAKU_7                       NUMBER(10,0),
    KOMOKU_CD_8                     CHAR(5),
    KOSU_8                          NUMBER(4,0),
    KINGAKU_8                       NUMBER(10,0),
    KOMOKU_CD_9                     CHAR(5),
    KOSU_9                          NUMBER(4,0),
    KINGAKU_9                       NUMBER(10,0),
    KOMOKU_CD_10                    CHAR(5),
    KOSU_10                         NUMBER(4,0),
    KINGAKU_10                      NUMBER(10,0),
    KOMOKU_CD_11                    CHAR(5),
    KOSU_11                         NUMBER(4,0),
    KINGAKU_11                      NUMBER(10,0),
    KOMOKU_CD_12                    CHAR(5),
    KOSU_12                         NUMBER(4,0),
    KINGAKU_12                      NUMBER(10,0),
    KOMOKU_CD_13                    CHAR(5),
    KOSU_13                         NUMBER(4,0),
    KINGAKU_13                      NUMBER(10,0),
    KOMOKU_CD_14                    CHAR(5),
    KOSU_14                         NUMBER(4,0),
    KINGAKU_14                      NUMBER(10,0),
    KOMOKU_CD_15                    CHAR(5),
    KOSU_15                         NUMBER(4,0),
    KINGAKU_15                      NUMBER(10,0),
    KOMOKU_CD_16                    CHAR(5),
    KOSU_16                         NUMBER(4,0),
    KINGAKU_16                      NUMBER(10,0),
    KOMOKU_CD_17                    CHAR(5),
    KOSU_17                         NUMBER(4,0),
    KINGAKU_17                      NUMBER(10,0),
    KOMOKU_CD_18                    CHAR(5),
    KOSU_18                         NUMBER(4,0),
    KINGAKU_18                      NUMBER(10,0),
    KOMOKU_CD_19                    CHAR(5),
    KOSU_19                         NUMBER(4,0),
    KINGAKU_19                      NUMBER(10,0),
    KOMOKU_CD_20                    CHAR(5),
    KOSU_20                         NUMBER(4,0),
    KINGAKU_20                      NUMBER(10,0),
    SHUKA_UMU                       CHAR(2),
    MEISAI_KENSU                    NUMBER(2,0),
    CHIKUSEKI_SAKUSEI_HIZUKE        CHAR(15),
    NIWATASHI_SAKUSEI_HIZUKE        CHAR(15),
    HAIKAN_SAKUSEI_HIZUKE           CHAR(15),
    SHUKA_SAKUSEI_HIZUKE            CHAR(15),
    SEIKYU_HI_TSUGI_SAKUSEI_HIZUKE  CHAR(15),
    SEIKYU_GETSUJI_SAKUSEI_HIZUKE   CHAR(15),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
DROP TABLE TR_NECL_TOKUISAKI_KANRI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_NECL_TOKUISAKI_KANRI
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    KADO_KBN                        CHAR(2),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_NECL_TOKUISAKI_KANRI
    ADD(CONSTRAINT PK_TR_NECL_TOKUISAKI_KANRI PRIMARY KEY (KOKYAKU_CD) USING INDEX)
/
DROP TABLE MS_SS_SHIIRESAKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SS_SHIIRESAKI
(
    SS_SHIIRESAKI_CD                VARCHAR2(20) NOT NULL,
    SS_SHIIRESAKI_MEI               VARCHAR2(40) NOT NULL,
    SHIHARAI_HOHO                   CHAR(2),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SS_SHIIRESAKI
    ADD(CONSTRAINT PK_MS_SS_SHIIRESAKI PRIMARY KEY (SS_SHIIRESAKI_CD) USING INDEX)
/
DROP TABLE TP_OKURIJO_HAKKO_PTN_HYOJI_JUN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TP_OKURIJO_HAKKO_PTN_HYOJI_JUN
(
    USER_CD                         CHAR(7),
    KOKYAKU_CD                      CHAR(6),
    OKURIJO_HAKKO_PTN_ID            NUMBER(5,0),
    ZENTAI_HYOJI_JUN                NUMBER(7,0),
    KOKYAKU_BETSU_HYOJI_JUN         NUMBER(7,0),
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
DROP TABLE TR_VOID_SUMI_BANGO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_VOID_SUMI_BANGO
(
    MAWB_BANGO                      VARCHAR2(8) NOT NULL,
    KOKU_GAISHA_CD                  VARCHAR2(3) NOT NULL,
    HAKKEN_EIGYOSHO_CD              CHAR(3) NOT NULL,
    HAIFUSAKI_EIGYOSHO_CD           CHAR(3) NOT NULL,
    MAWB_TOROKU_ID                  NUMBER(5,0) NOT NULL,
    MAWB_HAIFU_ID                   NUMBER(5,0) NOT NULL,
    VOID_HIZUKE                     DATE NOT NULL,
    VOID_RIYU                       VARCHAR2(100),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_VOID_SUMI_BANGO
    ADD(CONSTRAINT PK_TR_VOID_SUMI_BANGO PRIMARY KEY (MAWB_BANGO, KOKU_GAISHA_CD, HAKKEN_EIGYOSHO_CD, HAIFUSAKI_EIGYOSHO_CD, MAWB_TOROKU_ID, MAWB_HAIFU_ID, VOID_HIZUKE) USING INDEX)
/
DROP TABLE WK_UPLOAD_FILE_LAYOUT CASCADE CONSTRAINTS PURGE
/
CREATE TABLE WK_UPLOAD_FILE_LAYOUT
(
    EDI_SETTEI_ID                   CHAR(6) NOT NULL,
    JIKKO_KAISHI_NICHIJI            DATE NOT NULL,
    UPLOAD_FILE_LAYOUT_SEQ          NUMBER(5,0) NOT NULL,
    GYO_BANGO                       NUMBER(10,0) NOT NULL,
    YOMIKOMI_ID                     NUMBER(10,0) NOT NULL,
    TOROKU_KBN                      CHAR(1),
    JOTAI_KBN                       CHAR(1),
    COLUMN1                         VARCHAR2(500),
    COLUMN2                         VARCHAR2(500),
    COLUMN3                         VARCHAR2(500),
    COLUMN4                         VARCHAR2(500),
    COLUMN5                         VARCHAR2(500),
    COLUMN6                         VARCHAR2(500),
    COLUMN7                         VARCHAR2(500),
    COLUMN8                         VARCHAR2(500),
    COLUMN9                         VARCHAR2(500),
    COLUMN10                        VARCHAR2(500),
    COLUMN11                        VARCHAR2(500),
    COLUMN12                        VARCHAR2(500),
    COLUMN13                        VARCHAR2(500),
    COLUMN14                        VARCHAR2(500),
    COLUMN15                        VARCHAR2(500),
    COLUMN16                        VARCHAR2(500),
    COLUMN17                        VARCHAR2(500),
    COLUMN18                        VARCHAR2(500),
    COLUMN19                        VARCHAR2(500),
    COLUMN20                        VARCHAR2(500),
    COLUMN21                        VARCHAR2(500),
    COLUMN22                        VARCHAR2(500),
    COLUMN23                        VARCHAR2(500),
    COLUMN24                        VARCHAR2(500),
    COLUMN25                        VARCHAR2(500),
    COLUMN26                        VARCHAR2(500),
    COLUMN27                        VARCHAR2(500),
    COLUMN28                        VARCHAR2(500),
    COLUMN29                        VARCHAR2(500),
    COLUMN30                        VARCHAR2(500),
    COLUMN31                        VARCHAR2(500),
    COLUMN32                        VARCHAR2(500),
    COLUMN33                        VARCHAR2(500),
    COLUMN34                        VARCHAR2(500),
    COLUMN35                        VARCHAR2(500),
    COLUMN36                        VARCHAR2(500),
    COLUMN37                        VARCHAR2(500),
    COLUMN38                        VARCHAR2(500),
    COLUMN39                        VARCHAR2(500),
    COLUMN40                        VARCHAR2(500),
    COLUMN41                        VARCHAR2(500),
    COLUMN42                        VARCHAR2(500),
    COLUMN43                        VARCHAR2(500),
    COLUMN44                        VARCHAR2(500),
    COLUMN45                        VARCHAR2(500),
    COLUMN46                        VARCHAR2(500),
    COLUMN47                        VARCHAR2(500),
    COLUMN48                        VARCHAR2(500),
    COLUMN49                        VARCHAR2(500),
    COLUMN50                        VARCHAR2(500),
    COLUMN51                        VARCHAR2(500),
    COLUMN52                        VARCHAR2(500),
    COLUMN53                        VARCHAR2(500),
    COLUMN54                        VARCHAR2(500),
    COLUMN55                        VARCHAR2(500),
    COLUMN56                        VARCHAR2(500),
    COLUMN57                        VARCHAR2(500),
    COLUMN58                        VARCHAR2(500),
    COLUMN59                        VARCHAR2(500),
    COLUMN60                        VARCHAR2(500),
    COLUMN61                        VARCHAR2(500),
    COLUMN62                        VARCHAR2(500),
    COLUMN63                        VARCHAR2(500),
    COLUMN64                        VARCHAR2(500),
    COLUMN65                        VARCHAR2(500),
    COLUMN66                        VARCHAR2(500),
    COLUMN67                        VARCHAR2(500),
    COLUMN68                        VARCHAR2(500),
    COLUMN69                        VARCHAR2(500),
    COLUMN70                        VARCHAR2(500),
    COLUMN71                        VARCHAR2(500),
    COLUMN72                        VARCHAR2(500),
    COLUMN73                        VARCHAR2(500),
    COLUMN74                        VARCHAR2(500),
    COLUMN75                        VARCHAR2(500),
    COLUMN76                        VARCHAR2(500),
    COLUMN77                        VARCHAR2(500),
    COLUMN78                        VARCHAR2(500),
    COLUMN79                        VARCHAR2(500),
    COLUMN80                        VARCHAR2(500),
    COLUMN81                        VARCHAR2(500),
    COLUMN82                        VARCHAR2(500),
    COLUMN83                        VARCHAR2(500),
    COLUMN84                        VARCHAR2(500),
    COLUMN85                        VARCHAR2(500),
    COLUMN86                        VARCHAR2(500),
    COLUMN87                        VARCHAR2(500),
    COLUMN88                        VARCHAR2(500),
    COLUMN89                        VARCHAR2(500),
    COLUMN90                        VARCHAR2(500),
    COLUMN91                        VARCHAR2(500),
    COLUMN92                        VARCHAR2(500),
    COLUMN93                        VARCHAR2(500),
    COLUMN94                        VARCHAR2(500),
    COLUMN95                        VARCHAR2(500),
    COLUMN96                        VARCHAR2(500),
    COLUMN97                        VARCHAR2(500),
    COLUMN98                        VARCHAR2(500),
    COLUMN99                        VARCHAR2(500),
    COLUMN100                       VARCHAR2(500),
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE WK_UPLOAD_FILE_LAYOUT
    ADD(CONSTRAINT PK_WK_UPLOAD_FILE_LAYOUT PRIMARY KEY (EDI_SETTEI_ID, JIKKO_KAISHI_NICHIJI, UPLOAD_FILE_LAYOUT_SEQ, GYO_BANGO) USING INDEX)
/
DROP TABLE WK_FILE_LAYOUT CASCADE CONSTRAINTS PURGE
/
CREATE TABLE WK_FILE_LAYOUT
(
    EDI_SETTEI_ID                   CHAR(6) NOT NULL,
    JIKKO_KAISHI_NICHIJI            DATE NOT NULL,
    FILE_LAYOUT_SEQ                 NUMBER(5,0) NOT NULL,
    GYO_BANGO                       NUMBER(10,0) NOT NULL,
    COLUMN1                         VARCHAR2(500),
    COLUMN2                         VARCHAR2(500),
    COLUMN3                         VARCHAR2(500),
    COLUMN4                         VARCHAR2(500),
    COLUMN5                         VARCHAR2(500),
    COLUMN6                         VARCHAR2(500),
    COLUMN7                         VARCHAR2(500),
    COLUMN8                         VARCHAR2(500),
    COLUMN9                         VARCHAR2(500),
    COLUMN10                        VARCHAR2(500),
    COLUMN11                        VARCHAR2(500),
    COLUMN12                        VARCHAR2(500),
    COLUMN13                        VARCHAR2(500),
    COLUMN14                        VARCHAR2(500),
    COLUMN15                        VARCHAR2(500),
    COLUMN16                        VARCHAR2(500),
    COLUMN17                        VARCHAR2(500),
    COLUMN18                        VARCHAR2(500),
    COLUMN19                        VARCHAR2(500),
    COLUMN20                        VARCHAR2(500),
    COLUMN21                        VARCHAR2(500),
    COLUMN22                        VARCHAR2(500),
    COLUMN23                        VARCHAR2(500),
    COLUMN24                        VARCHAR2(500),
    COLUMN25                        VARCHAR2(500),
    COLUMN26                        VARCHAR2(500),
    COLUMN27                        VARCHAR2(500),
    COLUMN28                        VARCHAR2(500),
    COLUMN29                        VARCHAR2(500),
    COLUMN30                        VARCHAR2(500),
    COLUMN31                        VARCHAR2(500),
    COLUMN32                        VARCHAR2(500),
    COLUMN33                        VARCHAR2(500),
    COLUMN34                        VARCHAR2(500),
    COLUMN35                        VARCHAR2(500),
    COLUMN36                        VARCHAR2(500),
    COLUMN37                        VARCHAR2(500),
    COLUMN38                        VARCHAR2(500),
    COLUMN39                        VARCHAR2(500),
    COLUMN40                        VARCHAR2(500),
    COLUMN41                        VARCHAR2(500),
    COLUMN42                        VARCHAR2(500),
    COLUMN43                        VARCHAR2(500),
    COLUMN44                        VARCHAR2(500),
    COLUMN45                        VARCHAR2(500),
    COLUMN46                        VARCHAR2(500),
    COLUMN47                        VARCHAR2(500),
    COLUMN48                        VARCHAR2(500),
    COLUMN49                        VARCHAR2(500),
    COLUMN50                        VARCHAR2(500),
    COLUMN51                        VARCHAR2(500),
    COLUMN52                        VARCHAR2(500),
    COLUMN53                        VARCHAR2(500),
    COLUMN54                        VARCHAR2(500),
    COLUMN55                        VARCHAR2(500),
    COLUMN56                        VARCHAR2(500),
    COLUMN57                        VARCHAR2(500),
    COLUMN58                        VARCHAR2(500),
    COLUMN59                        VARCHAR2(500),
    COLUMN60                        VARCHAR2(500),
    COLUMN61                        VARCHAR2(500),
    COLUMN62                        VARCHAR2(500),
    COLUMN63                        VARCHAR2(500),
    COLUMN64                        VARCHAR2(500),
    COLUMN65                        VARCHAR2(500),
    COLUMN66                        VARCHAR2(500),
    COLUMN67                        VARCHAR2(500),
    COLUMN68                        VARCHAR2(500),
    COLUMN69                        VARCHAR2(500),
    COLUMN70                        VARCHAR2(500),
    COLUMN71                        VARCHAR2(500),
    COLUMN72                        VARCHAR2(500),
    COLUMN73                        VARCHAR2(500),
    COLUMN74                        VARCHAR2(500),
    COLUMN75                        VARCHAR2(500),
    COLUMN76                        VARCHAR2(500),
    COLUMN77                        VARCHAR2(500),
    COLUMN78                        VARCHAR2(500),
    COLUMN79                        VARCHAR2(500),
    COLUMN80                        VARCHAR2(500),
    COLUMN81                        VARCHAR2(500),
    COLUMN82                        VARCHAR2(500),
    COLUMN83                        VARCHAR2(500),
    COLUMN84                        VARCHAR2(500),
    COLUMN85                        VARCHAR2(500),
    COLUMN86                        VARCHAR2(500),
    COLUMN87                        VARCHAR2(500),
    COLUMN88                        VARCHAR2(500),
    COLUMN89                        VARCHAR2(500),
    COLUMN90                        VARCHAR2(500),
    COLUMN91                        VARCHAR2(500),
    COLUMN92                        VARCHAR2(500),
    COLUMN93                        VARCHAR2(500),
    COLUMN94                        VARCHAR2(500),
    COLUMN95                        VARCHAR2(500),
    COLUMN96                        VARCHAR2(500),
    COLUMN97                        VARCHAR2(500),
    COLUMN98                        VARCHAR2(500),
    COLUMN99                        VARCHAR2(500),
    COLUMN100                       VARCHAR2(500),
    COLUMN101                       VARCHAR2(500),
    COLUMN102                       VARCHAR2(500),
    COLUMN103                       VARCHAR2(500),
    COLUMN104                       VARCHAR2(500),
    COLUMN105                       VARCHAR2(500),
    COLUMN106                       VARCHAR2(500),
    COLUMN107                       VARCHAR2(500),
    COLUMN108                       VARCHAR2(500),
    COLUMN109                       VARCHAR2(500),
    COLUMN110                       VARCHAR2(500),
    COLUMN111                       VARCHAR2(500),
    COLUMN112                       VARCHAR2(500),
    COLUMN113                       VARCHAR2(500),
    COLUMN114                       VARCHAR2(500),
    COLUMN115                       VARCHAR2(500),
    COLUMN116                       VARCHAR2(500),
    COLUMN117                       VARCHAR2(500),
    COLUMN118                       VARCHAR2(500),
    COLUMN119                       VARCHAR2(500),
    COLUMN120                       VARCHAR2(500),
    COLUMN121                       VARCHAR2(500),
    COLUMN122                       VARCHAR2(500),
    COLUMN123                       VARCHAR2(500),
    COLUMN124                       VARCHAR2(500),
    COLUMN125                       VARCHAR2(500),
    COLUMN126                       VARCHAR2(500),
    COLUMN127                       VARCHAR2(500),
    COLUMN128                       VARCHAR2(500),
    COLUMN129                       VARCHAR2(500),
    COLUMN130                       VARCHAR2(500),
    COLUMN131                       VARCHAR2(500),
    COLUMN132                       VARCHAR2(500),
    COLUMN133                       VARCHAR2(500),
    COLUMN134                       VARCHAR2(500),
    COLUMN135                       VARCHAR2(500),
    COLUMN136                       VARCHAR2(500),
    COLUMN137                       VARCHAR2(500),
    COLUMN138                       VARCHAR2(500),
    COLUMN139                       VARCHAR2(500),
    COLUMN140                       VARCHAR2(500),
    COLUMN141                       VARCHAR2(500),
    COLUMN142                       VARCHAR2(500),
    COLUMN143                       VARCHAR2(500),
    COLUMN144                       VARCHAR2(500),
    COLUMN145                       VARCHAR2(500),
    COLUMN146                       VARCHAR2(500),
    COLUMN147                       VARCHAR2(500),
    COLUMN148                       VARCHAR2(500),
    COLUMN149                       VARCHAR2(500),
    COLUMN150                       VARCHAR2(500),
    COLUMN151                       VARCHAR2(500),
    COLUMN152                       VARCHAR2(500),
    COLUMN153                       VARCHAR2(500),
    COLUMN154                       VARCHAR2(500),
    COLUMN155                       VARCHAR2(500),
    COLUMN156                       VARCHAR2(500),
    COLUMN157                       VARCHAR2(500),
    COLUMN158                       VARCHAR2(500),
    COLUMN159                       VARCHAR2(500),
    COLUMN160                       VARCHAR2(500),
    COLUMN161                       VARCHAR2(500),
    COLUMN162                       VARCHAR2(500),
    COLUMN163                       VARCHAR2(500),
    COLUMN164                       VARCHAR2(500),
    COLUMN165                       VARCHAR2(500),
    COLUMN166                       VARCHAR2(500),
    COLUMN167                       VARCHAR2(500),
    COLUMN168                       VARCHAR2(500),
    COLUMN169                       VARCHAR2(500),
    COLUMN170                       VARCHAR2(500),
    COLUMN171                       VARCHAR2(500),
    COLUMN172                       VARCHAR2(500),
    COLUMN173                       VARCHAR2(500),
    COLUMN174                       VARCHAR2(500),
    COLUMN175                       VARCHAR2(500),
    COLUMN176                       VARCHAR2(500),
    COLUMN177                       VARCHAR2(500),
    COLUMN178                       VARCHAR2(500),
    COLUMN179                       VARCHAR2(500),
    COLUMN180                       VARCHAR2(500),
    COLUMN181                       VARCHAR2(500),
    COLUMN182                       VARCHAR2(500),
    COLUMN183                       VARCHAR2(500),
    COLUMN184                       VARCHAR2(500),
    COLUMN185                       VARCHAR2(500),
    COLUMN186                       VARCHAR2(500),
    COLUMN187                       VARCHAR2(500),
    COLUMN188                       VARCHAR2(500),
    COLUMN189                       VARCHAR2(500),
    COLUMN190                       VARCHAR2(500),
    COLUMN191                       VARCHAR2(500),
    COLUMN192                       VARCHAR2(500),
    COLUMN193                       VARCHAR2(500),
    COLUMN194                       VARCHAR2(500),
    COLUMN195                       VARCHAR2(500),
    COLUMN196                       VARCHAR2(500),
    COLUMN197                       VARCHAR2(500),
    COLUMN198                       VARCHAR2(500),
    COLUMN199                       VARCHAR2(500),
    COLUMN200                       VARCHAR2(500),
    COLUMN201                       VARCHAR2(500),
    COLUMN202                       VARCHAR2(500),
    COLUMN203                       VARCHAR2(500),
    COLUMN204                       VARCHAR2(500),
    COLUMN205                       VARCHAR2(500),
    COLUMN206                       VARCHAR2(500),
    COLUMN207                       VARCHAR2(500),
    COLUMN208                       VARCHAR2(500),
    COLUMN209                       VARCHAR2(500),
    COLUMN210                       VARCHAR2(500),
    COLUMN211                       VARCHAR2(500),
    COLUMN212                       VARCHAR2(500),
    COLUMN213                       VARCHAR2(500),
    COLUMN214                       VARCHAR2(500),
    COLUMN215                       VARCHAR2(500),
    COLUMN216                       VARCHAR2(500),
    COLUMN217                       VARCHAR2(500),
    COLUMN218                       VARCHAR2(500),
    COLUMN219                       VARCHAR2(500),
    COLUMN220                       VARCHAR2(500),
    COLUMN221                       VARCHAR2(500),
    COLUMN222                       VARCHAR2(500),
    COLUMN223                       VARCHAR2(500),
    COLUMN224                       VARCHAR2(500),
    COLUMN225                       VARCHAR2(500),
    COLUMN226                       VARCHAR2(500),
    COLUMN227                       VARCHAR2(500),
    COLUMN228                       VARCHAR2(500),
    COLUMN229                       VARCHAR2(500),
    COLUMN230                       VARCHAR2(500),
    COLUMN231                       VARCHAR2(500),
    COLUMN232                       VARCHAR2(500),
    COLUMN233                       VARCHAR2(500),
    COLUMN234                       VARCHAR2(500),
    COLUMN235                       VARCHAR2(500),
    COLUMN236                       VARCHAR2(500),
    COLUMN237                       VARCHAR2(500),
    COLUMN238                       VARCHAR2(500),
    COLUMN239                       VARCHAR2(500),
    COLUMN240                       VARCHAR2(500),
    COLUMN241                       VARCHAR2(500),
    COLUMN242                       VARCHAR2(500),
    COLUMN243                       VARCHAR2(500),
    COLUMN244                       VARCHAR2(500),
    COLUMN245                       VARCHAR2(500),
    COLUMN246                       VARCHAR2(500),
    COLUMN247                       VARCHAR2(500),
    COLUMN248                       VARCHAR2(500),
    COLUMN249                       VARCHAR2(500),
    COLUMN250                       VARCHAR2(500),
    COLUMN251                       VARCHAR2(500),
    COLUMN252                       VARCHAR2(500),
    COLUMN253                       VARCHAR2(500),
    COLUMN254                       VARCHAR2(500),
    COLUMN255                       VARCHAR2(500),
    COLUMN256                       VARCHAR2(500),
    COLUMN257                       VARCHAR2(500),
    COLUMN258                       VARCHAR2(500),
    COLUMN259                       VARCHAR2(500),
    COLUMN260                       VARCHAR2(500),
    COLUMN261                       VARCHAR2(500),
    COLUMN262                       VARCHAR2(500),
    COLUMN263                       VARCHAR2(500),
    COLUMN264                       VARCHAR2(500),
    COLUMN265                       VARCHAR2(500),
    COLUMN266                       VARCHAR2(500),
    COLUMN267                       VARCHAR2(500),
    COLUMN268                       VARCHAR2(500),
    COLUMN269                       VARCHAR2(500),
    COLUMN270                       VARCHAR2(500),
    COLUMN271                       VARCHAR2(500),
    COLUMN272                       VARCHAR2(500),
    COLUMN273                       VARCHAR2(500),
    COLUMN274                       VARCHAR2(500),
    COLUMN275                       VARCHAR2(500),
    COLUMN276                       VARCHAR2(500),
    COLUMN277                       VARCHAR2(500),
    COLUMN278                       VARCHAR2(500),
    COLUMN279                       VARCHAR2(500),
    COLUMN280                       VARCHAR2(500),
    COLUMN281                       VARCHAR2(500),
    COLUMN282                       VARCHAR2(500),
    COLUMN283                       VARCHAR2(500),
    COLUMN284                       VARCHAR2(500),
    COLUMN285                       VARCHAR2(500),
    COLUMN286                       VARCHAR2(500),
    COLUMN287                       VARCHAR2(500),
    COLUMN288                       VARCHAR2(500),
    COLUMN289                       VARCHAR2(500),
    COLUMN290                       VARCHAR2(500),
    COLUMN291                       VARCHAR2(500),
    COLUMN292                       VARCHAR2(500),
    COLUMN293                       VARCHAR2(500),
    COLUMN294                       VARCHAR2(500),
    COLUMN295                       VARCHAR2(500),
    COLUMN296                       VARCHAR2(500),
    COLUMN297                       VARCHAR2(500),
    COLUMN298                       VARCHAR2(500),
    COLUMN299                       VARCHAR2(500),
    COLUMN300                       VARCHAR2(500),
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE WK_FILE_LAYOUT
    ADD(CONSTRAINT PK_WK_FILE_LAYOUT PRIMARY KEY (EDI_SETTEI_ID, JIKKO_KAISHI_NICHIJI, FILE_LAYOUT_SEQ, GYO_BANGO) USING INDEX)
/
DROP TABLE MS_UPLOAD_FILE_TEIGI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_UPLOAD_FILE_TEIGI
(
    UPLOAD_KINO_CD                  CHAR(9) NOT NULL,
    UPLOAD_CD                       VARCHAR2(20) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    EDI_SETTEI_ID                   CHAR(6) NOT NULL,
    DATA_FILE_MEI                   VARCHAR2(256) NOT NULL,
    FILE_SHUBETSU                   CHAR(1) NOT NULL,
    ICHIJI_HOZONYO_WORK_TABLE_MEI   VARCHAR2(50) NOT NULL,
    FILE_YOMIKOMIYO_DS_SCRIPT_URL   VARCHAR2(256) NOT NULL,
    ICHIJI_HOZONYO_DS_SCRIPT_URL    VARCHAR2(256) NOT NULL,
    HONTOROKUYO_DS_SCRIPT_URL       VARCHAR2(512) NOT NULL,
    FILE_HEADER_GYO_NO_UMU          CHAR(1) NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_UPLOAD_FILE_TEIGI
    ADD(CONSTRAINT PK_MS_UPLOAD_FILE_TEIGI PRIMARY KEY (UPLOAD_KINO_CD, UPLOAD_CD, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE MS_UPLOAD_KINO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_UPLOAD_KINO
(
    UPLOAD_KINO_CD                  CHAR(9) NOT NULL,
    UPLOAD_KINO_MEISHO              VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_UPLOAD_KINO
    ADD(CONSTRAINT PK_MS_UPLOAD_KINO PRIMARY KEY (UPLOAD_KINO_CD) USING INDEX)
/
DROP TABLE TR_UPLOAD_MOTO_DATA CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_UPLOAD_MOTO_DATA
(
    YOMIKOMI_ID                     NUMBER(10,0) NOT NULL,
    GYO_BANGO                       NUMBER(10,0) NOT NULL,
    GYO_NAIYO                       VARCHAR2(4000),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_UPLOAD_MOTO_DATA
    ADD(CONSTRAINT PK_TR_UPLOAD_MOTO_DATA PRIMARY KEY (YOMIKOMI_ID, GYO_BANGO) USING INDEX)
/
DROP TABLE TR_OKYAKUSAMA_KANRI_NO_MEISAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_OKYAKUSAMA_KANRI_NO_MEISAI
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    OKYAKUSAMA_KANRI_NO             VARCHAR2(20) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(18,0) NOT NULL,
    OKURIJO_NO                      CHAR(13) NOT NULL,
    KOKYAKU_CD                      CHAR(6),
    OKURIJO_SEQ                     NUMBER(18,0) NOT NULL,
    OYA_FLG                         CHAR(1) NOT NULL,
    OKURIJO_INJI_FLG                CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_OKYAKUSAMA_KANRI_NO_MEISAI
    ADD(CONSTRAINT PK_TR_OKYAKUSAMA_KANRI_NO_MEISAI PRIMARY KEY (URIAGE_ID, OKYAKUSAMA_KANRI_NO, URIAGE_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_OKYAKUSAMA_KANRI_NO_MEISAI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_OKYAKUSAMA_KANRI_NO_MEISAI_RIREKI
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    OKYAKUSAMA_KANRI_NO             VARCHAR2(20) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(3,0) NOT NULL,
    OKURIJO_NO                      CHAR(13),
    KOKYAKU_CD                      CHAR(6),
    OKURIJO_SEQ                     NUMBER(18,0),
    OYA_FLG                         CHAR(1) NOT NULL,
    OKURIJO_INJI_FLG                CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_OKYAKUSAMA_KANRI_NO_MEISAI_RIREKI
    ADD(CONSTRAINT PK_TR_OKYAKUSAMA_KANRI_NO_MEISAI_RIREKI PRIMARY KEY (URIAGE_ID, URIAGE_DATA_VERSION, OKYAKUSAMA_KANRI_NO) USING INDEX)
/
DROP TABLE MS_CALENDER_SETTEI_JOKYO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_CALENDER_SETTEI_JOKYO
(
    NENGETSU                        CHAR(6) NOT NULL,
    SHONIN_STATUS                   CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_CALENDER_SETTEI_JOKYO
    ADD(CONSTRAINT PK_MS_CALENDER_SETTEI_JOKYO PRIMARY KEY (NENGETSU) USING INDEX)
/
DROP TABLE TR_CLIENA_VERSION_KANRI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CLIENA_VERSION_KANRI
(
    TAMMATSU_ID                     VARCHAR2(20) NOT NULL,
    VERSION_JOHO                    VARCHAR2(20) NOT NULL,
    KOSHIN_HIZUKE                   CHAR(8) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CLIENA_VERSION_KANRI
    ADD(CONSTRAINT PK_TR_CLIENA_VERSION_KANRI PRIMARY KEY (TAMMATSU_ID) USING INDEX)
/
DROP TABLE TR_KESHI_KOMI_BANK_WEB_WORK CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_KESHI_KOMI_BANK_WEB_WORK
(
    TORIKOMI_ID                     NUMBER(18,0) NOT NULL,
    REMBAN                          NUMBER(6,0) NOT NULL,
    TAISHAKU_KBN_CD_VAL             VARCHAR2(512),
    TAISHAKU_KBN                    VARCHAR2(512),
    TOKUISAKI_CD                    VARCHAR2(512),
    TOKUISAKI_MEI                   VARCHAR2(512),
    KINYU_KIKAN_CD                  VARCHAR2(512),
    NYUKIN_KOZA_TENBAN              VARCHAR2(512),
    NYUKIN_KOZA_KAMOKU              VARCHAR2(512),
    NYUKIN_KOZA_BANGO               VARCHAR2(512),
    NYUKINBI                        VARCHAR2(512),
    KISANBI                         VARCHAR2(512),
    KICHOBI                         VARCHAR2(512),
    NYUKIN_GAKU                     NUMBER(10,0),
    KANA_MEI                        VARCHAR2(512),
    SHIMUKE_GINKO_MEI               VARCHAR2(512),
    SHIMUKE_TEN_MEI                 VARCHAR2(512),
    UCHI_TATEN_KEN_KINGAKU          NUMBER(10,0),
    TORIHIKI_KAMOKU_CD              VARCHAR2(512),
    TORIHIKI_KAMOKU_MEI             VARCHAR2(512),
    NYUKIN_KAMOKU_CD_1              VARCHAR2(512),
    NYUKIN_KAMOKU_MEI_1             VARCHAR2(512),
    NYUKIN_KAMOKU_CD_2              VARCHAR2(512),
    NYUKIN_KAMOKU_MEI_2             VARCHAR2(512),
    SEIKYU_KINGAKU                  NUMBER(10,0),
    SEIKYU_KAMOKU_CD_1              VARCHAR2(512),
    SEIKYU_KAMOKU_CD_2              VARCHAR2(512),
    SEIKYU_COMMENT                  VARCHAR2(512),
    KESHIKOMI_ID                    VARCHAR2(512),
    KESHIKOMI_USER                  VARCHAR2(512),
    KESHIKOMI_NICHIJI               VARCHAR2(512),
    KEIRI_RENKEI_FILE_OUTPUT_DATE   DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_KESHI_KOMI_BANK_WEB_WORK
    ADD(CONSTRAINT PK_TR_KESHI_KOMI_BANK_WEB_WORK PRIMARY KEY (TORIKOMI_ID, REMBAN) USING INDEX)
/
DROP TABLE TR_KESHI_KOMI_BANK_WEB_TORIKOMI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_KESHI_KOMI_BANK_WEB_TORIKOMI_RIREKI
(
    TORIKOMI_ID                     NUMBER(18,0) NOT NULL,
    TORIKOMI_NICHIJI                DATE,
    FILE_MEI                        VARCHAR2(512),
    TORIKOMI_SHA_CD                 CHAR(7),
    TORIKESHI_FLG                   CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_KESHI_KOMI_BANK_WEB_TORIKOMI_RIREKI
    ADD(CONSTRAINT PK_TR_KESHI_KOMI_BANK_WEB_TORIKOMI_RIREKI PRIMARY KEY (TORIKOMI_ID) USING INDEX)
/
DROP TABLE MS_COMMENT CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_COMMENT
(
    JIS_CD_1                        CHAR(2) NOT NULL,
    JIS_CD_2                        CHAR(3) NOT NULL,
    COMMENT_1                       VARCHAR2(100),
    COMMENT_2                       VARCHAR2(200),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_COMMENT
    ADD(CONSTRAINT PK_MS_COMMENT PRIMARY KEY (JIS_CD_1, JIS_CD_2) USING INDEX)
/
DROP TABLE MS_SUB_MENU_GROUP CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SUB_MENU_GROUP
(
    SUB_MENU_GROUP_ID               VARCHAR2(20) NOT NULL,
    SUB_MENU_GROUP_MEI              VARCHAR2(40),
    OYA_MENU_GROUP_ID               VARCHAR2(20) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SUB_MENU_GROUP
    ADD(CONSTRAINT PK_MS_SUB_MENU_GROUP PRIMARY KEY (SUB_MENU_GROUP_ID) USING INDEX)
/
DROP TABLE MS_SUB_MENU_GROUP_HYOJI_JUN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SUB_MENU_GROUP_HYOJI_JUN
(
    MENU_PATTERN_ID                 CHAR(6) NOT NULL,
    SUB_MENU_GROUP_ID               VARCHAR2(20) NOT NULL,
    HYOJI_JUN                       NUMBER(3,0),
    SAKUJO_FLG                      CHAR(1),
    TOROKU_USER                     VARCHAR2(8),
    TOROKU_NICHIJI                  DATE,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0),
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE,
    MENU_GROUP_ID                   VARCHAR2(20) NOT NULL
)
/
ALTER TABLE MS_SUB_MENU_GROUP_HYOJI_JUN
    ADD(CONSTRAINT PK_SUB_MS_MENU_GROUP_HYOJI_JUN PRIMARY KEY (SUB_MENU_GROUP_ID, MENU_PATTERN_ID) USING INDEX)
/
DROP TABLE MS_SYSTEM_IF_SHUBETSU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SYSTEM_IF_SHUBETSU
(
    SYSTEM_MEISHO_CD                CHAR(3) NOT NULL,
    SYSTEM_IF_SHUBETSU_CD           CHAR(3) NOT NULL,
    SYSTEM_IF_SHUBETSU              VARCHAR2(40),
    SOUJUSHIN_SHUBETSU              CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SYSTEM_IF_SHUBETSU
    ADD(CONSTRAINT PK_MS_SYSTEM_IF_SHUBETSU PRIMARY KEY (SYSTEM_MEISHO_CD, SYSTEM_IF_SHUBETSU_CD) USING INDEX)
/
DROP TABLE MS_SYSTEM CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SYSTEM
(
    CD_GROUP                        VARCHAR2(10) NOT NULL,
    CD                              VARCHAR2(50) NOT NULL,
    VAL                             VARCHAR2(100),
    SETSUMEI                        VARCHAR2(100),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SYSTEM
    ADD(CONSTRAINT PK_MS_SYSTEM PRIMARY KEY (CD_GROUP, CD) USING INDEX)
/
DROP TABLE MS_SYSTEM_MESSAGE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SYSTEM_MESSAGE
(
    MESSAGE_ID                      VARCHAR2(8) NOT NULL,
    MESSAGE_SHUBETSU                CHAR(1) NOT NULL,
    MESSAGE_BUN                     VARCHAR2(512),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SYSTEM_MESSAGE
    ADD(CONSTRAINT PK_MS_SYSTEM_MESSAGE PRIMARY KEY (MESSAGE_ID) USING INDEX)
/
DROP TABLE MS_SYSTEM_MEISHO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SYSTEM_MEISHO
(
    SYSTEM_MEISHO_CD                CHAR(3) NOT NULL,
    SYSTEM_MEISHO                   VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SYSTEM_MEISHO
    ADD(CONSTRAINT PK_MS_SYSTEM_MEISHO PRIMARY KEY (SYSTEM_MEISHO_CD) USING INDEX)
/
DROP TABLE TR_SCAN_DATA CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SCAN_DATA
(
    SCAN_DATA_SEQ                   NUMBER(10,0) NOT NULL,
    SCAN_KASHO                      VARCHAR2(5) NOT NULL,
    SCAN_TAMMATSU                   VARCHAR2(60) NOT NULL,
    SHUKA_EIGYOSHO_CD               VARCHAR2(5) NOT NULL,
    SCAN_ID                         VARCHAR2(10) NOT NULL,
    SCAN_NICHIJI                    DATE NOT NULL,
    SCAN_USER                       CHAR(7) NOT NULL,
    OKURIJO_NO                      CHAR(13),
    OKURIJO_GAZO_OMOTE              VARCHAR2(255),
    OKURIJO_GAZO_OMOTE_ANGLE        NUMBER(3,0),
    OKURIJO_GAZO_URA                VARCHAR2(255),
    OKURIJO_GAZO_URA_ANGLE          NUMBER(3,0),
    SHIYO_GAZO_KBN                  CHAR(1),
    YOMITORI_SEIKO_FLG              CHAR(1) NOT NULL,
    YOMITORI_BANGO_1                VARCHAR2(20),
    YOMITORI_BANGO_2                VARCHAR2(20),
    YOMITORI_BANGO_3                VARCHAR2(20),
    YOMITORI_BANGO_4                VARCHAR2(20),
    YOMITORI_BANGO_5                VARCHAR2(20),
    SENBETSU_BARCODE                VARCHAR2(10) NOT NULL,
    KATA                            VARCHAR2(7) NOT NULL,
    SCAN_JUFUKU_KBN                 CHAR(1) NOT NULL,
    UPLOAD_NICHIJI                  DATE NOT NULL,
    SHUSEI_FLG                      CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SCAN_DATA
    ADD(CONSTRAINT PK_TR_SCAN_DATA PRIMARY KEY (SCAN_DATA_SEQ) USING INDEX)
/
DROP TABLE MS_SCRIPT CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SCRIPT
(
    SCRIPT_ID                       VARCHAR2(8) NOT NULL,
    JIKKO_SCRIPT_MEI                VARCHAR2(40),
    JIKKO_SCRIPT_PATH               VARCHAR2(512),
    SCRIPT_KBN                      CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SCRIPT
    ADD(CONSTRAINT PK_MS_SCRIPT PRIMARY KEY (SCRIPT_ID) USING INDEX)
/
DROP TABLE TR_SONOTA_SEIKYU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SONOTA_SEIKYU
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(3,0) NOT NULL,
    AKA_KURO_KBN                    CHAR(1) NOT NULL,
    SAISIN_URIAGE_FLG               CHAR(1),
    SEIKYU_KEIJO_NO                 CHAR(6) NOT NULL,
    SEIKYU_HIZUKE                   CHAR(8) NOT NULL,
    KEIRI_KEIJOBI                   CHAR(8),
    ORIGINAL_KEIRI_KEIJO_HI         CHAR(8),
    KOKYAKU_CD                      CHAR(6),
    SEIKYUSAKI_CD                   CHAR(6),
    KEIYAKUSAKI_CD                  CHAR(6),
    HANBAI_EIGYOSHO                 VARCHAR2(5),
    SEIKYU_EIGYOSHO                 VARCHAR2(5),
    TANKA                           NUMBER(10,0),
    TANI                            VARCHAR2(20),
    SURYO                           NUMBER(9,0),
    KINGAKU                         NUMBER(10,0),
    SYOUHIZEI_KINGAKU               NUMBER(10,0) NOT NULL,
    SEIKYUKINGAKU                   NUMBER(10,0) NOT NULL,
    SEIKYUSYO_BIKO                  VARCHAR2(100),
    NYURYOKUSHA_MEMO                VARCHAR2(512),
    SHIME_TAISHO_KBN                CHAR(1) NOT NULL,
    SHIME_JOKYO_KBN                 CHAR(1) NOT NULL,
    SHIMEBI                         CHAR(8) NOT NULL,
    IF_RENKEI_JOKYO_FLG             CHAR(1) NOT NULL,
    IF_RENKEI_TAISHO_FLG            CHAR(1) NOT NULL,
    DATA_MOTO                       CHAR(2),
    AKA_KURO_FLG                    CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SONOTA_SEIKYU
    ADD(CONSTRAINT PK_TR_SONOTA_SEIKYU PRIMARY KEY (SEIKYU_KEIJO_NO, URIAGE_ID, URIAGE_DATA_VERSION, AKA_KURO_KBN) USING INDEX)
/
DROP TABLE TR_SONOTA_SEIKYU_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SONOTA_SEIKYU_RIREKI
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(3,0) NOT NULL,
    SEIKYU_KEIJO_NO                 CHAR(6) NOT NULL,
    SEIKYU_HIZUKE                   CHAR(8) NOT NULL,
    KEIRI_KEIJOBI                   CHAR(8),
    ORIGINAL_KEIRI_KEIJO_HI         CHAR(8),
    KOKYAKU_CD                      CHAR(6),
    SEIKYUSAKI_CD                   CHAR(6),
    KEIYAKUSAKI_CD                  CHAR(6),
    HANBAI_EIGYOSHO                 VARCHAR2(5),
    SEIKYU_EIGYOSHO                 VARCHAR2(5),
    TANKA                           NUMBER(9,0),
    TANI                            VARCHAR2(20),
    SURYO                           NUMBER(9,0),
    KINGAKU                         NUMBER(10,0),
    SYOUHIZEI_KINGAKU               NUMBER(10,0) NOT NULL,
    SEIKYUKINGAKU                   NUMBER(10,0) NOT NULL,
    SEIKYUSYO_BIKO                  VARCHAR2(100),
    NYURYOKUSYA_MEMO                VARCHAR2(512),
    SHIME_TAISHO_KBN                CHAR(1) NOT NULL,
    SHIME_JOKYO_KBN                 CHAR(1) NOT NULL,
    SHIMEBI                         CHAR(8) NOT NULL,
    IF_RENKEI_JOKYO_FLG             CHAR(1) NOT NULL,
    IF_RENKEI_TAISHO_FLG            CHAR(1) NOT NULL,
    DATA_MOTO                       CHAR(2),
    AKA_KURO_FLG                    CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SONOTA_SEIKYU_RIREKI
    ADD(CONSTRAINT PK_TR_SONOTA_SEIKYU_RIREKI PRIMARY KEY (SEIKYU_KEIJO_NO, URIAGE_ID, URIAGE_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_SONOTA_URIAGE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SONOTA_URIAGE
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(3,0) NOT NULL,
    AKA_KURO_KBN                    CHAR(1) NOT NULL,
    SAISIN_URIAGE_FLG               CHAR(1),
    KOKYAKU_CD                      CHAR(6),
    DEMPYO_SHUBETSU_CD              CHAR(2) NOT NULL,
    URIAGEBI_FROM                   DATE NOT NULL,
    URIAGEBI_TO                     DATE NOT NULL,
    KEIRI_KEIJOBI                   CHAR(8) NOT NULL,
    ORIGINAL_KEIRI_KEIJO_HI         DATE,
    SEIKYUSHO_KISAIBI               DATE NOT NULL,
    ODAIMOKU                        VARCHAR2(40),
    SEIKYUSHO_BIKO_1                VARCHAR2(40),
    SEIKYUSHO_BIKO_2                VARCHAR2(40),
    SEIKYUSAKI_CD                   CHAR(6),
    DAISANSHA_HARAI_CD              CHAR(6),
    KEIYAKUSAKI_CD                  CHAR(6),
    HANBAI_EIGYOSHO                 VARCHAR2(5),
    SEIKYU_EIGYOSHO                 VARCHAR2(5),
    MEISAI_KEI                      NUMBER(9,0) NOT NULL,
    NEBIKI_KINGAKU                  NUMBER(10,0),
    WARIMODOSHI_KINGAKU             NUMBER(10,0),
    KAZEI_TAISHO_KINGAKU            NUMBER(10,0),
    SHOHIZEI_KINGAKU                NUMBER(10,0) NOT NULL,
    UCHIZEI_KINGAKU                 NUMBER(10,0),
    HIKAZEI_KINGAKU                 NUMBER(10,0),
    SEIKYU_KINGAKU                  NUMBER(10,0) NOT NULL,
    URIAGE_COMMENT                  VARCHAR2(1024),
    SONOTA_URIAGE_DATA_VERSION      NUMBER(3,0) NOT NULL,
    IF_RENKEI_JOKYO_FLG             CHAR(1),
    IF_RENKEI_TAISHO_FLG            CHAR(1),
    SHIME_TAISHO_KBN                CHAR(1) NOT NULL,
    SHIME_JOKYO_KBN                 CHAR(1) NOT NULL,
    SHIMEBI                         CHAR(8) NOT NULL,
    DATA_MOTO                       CHAR(2) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SONOTA_URIAGE
    ADD(CONSTRAINT PK_TR_SONOTA_URIAGE PRIMARY KEY (URIAGE_ID, URIAGE_DATA_VERSION, AKA_KURO_KBN) USING INDEX)
/
DROP TABLE TR_SONOTA_URIAGE_MEISAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SONOTA_URIAGE_MEISAI
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(3,0) NOT NULL,
    AKA_KURO_KBN                    CHAR(1) NOT NULL,
    MEISAI_NO                       NUMBER(5,0) NOT NULL,
    KEIYAKU_ID                      NUMBER(6,0),
    RYOKINHYO_NO                    CHAR(7),
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    RYOKIN_KOMOKU_1_CD              VARCHAR2(2),
    RYOKIN_KOMOKU_2_CD              VARCHAR2(3),
    HYOJI_MEI                       VARCHAR2(40),
    TANKA                           NUMBER(10,0) NOT NULL,
    SURYO                           NUMBER(9,0),
    KINGAKU                         NUMBER(10,0),
    NEBIKI_KINGAKU                  NUMBER(10,0) NOT NULL,
    SHOKEI                          NUMBER(10,0) NOT NULL,
    KAZEI_TAISHO_KINGAKU            NUMBER(10,0),
    SHOHIZEI_GAKU                   NUMBER(10,0),
    UCHIZEI_KINGAKU                 NUMBER(10,0),
    HIKAZEI_KINGAKU                 NUMBER(10,0),
    SEIKYU_KINGAKU                  NUMBER(10,0) NOT NULL,
    WARIMODOSHI_KINGAKU             NUMBER(10,0),
    OROSHINE                        NUMBER(10,0) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SONOTA_URIAGE_MEISAI
    ADD(CONSTRAINT PK_TR_SONOTA_URIAGE_MEISAI PRIMARY KEY (URIAGE_ID, MEISAI_NO, URIAGE_DATA_VERSION, AKA_KURO_KBN) USING INDEX)
/
DROP TABLE TR_SONOTA_URIAGE_MEISAI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SONOTA_URIAGE_MEISAI_RIREKI
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(3,0) NOT NULL,
    MEISAI_EDABAN                   NUMBER(3,0) NOT NULL,
    KEIYAKU_ID                      NUMBER(6,0),
    RYOKINHYO_NO                    CHAR(7),
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    RYOKIN_KOMOKU_1_CD              VARCHAR2(2),
    RYOKIN_KOMOKU_2_CD              VARCHAR2(3),
    HYOJI_MEI                       VARCHAR2(40),
    TANKA                           NUMBER(10,0),
    SURYO                           NUMBER(9,0),
    KINGAKU                         NUMBER(10,0),
    NEBIKI_GAKU                     NUMBER(10,0) NOT NULL,
    SHOKEI                          NUMBER(10,0) NOT NULL,
    KAZEI_TAISHO_KINGAKU            NUMBER(10,0),
    SHOHIZEI_GAKU                   NUMBER(10,0) NOT NULL,
    UCHIZEI_KINGAKU                 NUMBER(10,0),
    HIKAZEI_KINGAKU                 NUMBER(10,0),
    SEIKYU_KINGAKU                  NUMBER(10,0),
    WARIMODOSHI_KINGAKU             NUMBER(10,0),
    OROSHINE                        NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SONOTA_URIAGE_MEISAI_RIREKI
    ADD(CONSTRAINT PK_TR_SONOTA_URIAGE_MEISAI_RIREKI PRIMARY KEY (URIAGE_ID, MEISAI_EDABAN, URIAGE_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_SONOTA_URIAGE_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SONOTA_URIAGE_RIREKI
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(3,0) NOT NULL,
    KOKYAKU_CD                      CHAR(6),
    DEMPYO_SHUBETSU_CD              CHAR(2) NOT NULL,
    URIAGEBI_FROM                   DATE NOT NULL,
    URIAGEBI_TO                     DATE NOT NULL,
    KEIRI_KEIJOBI                   CHAR(8) NOT NULL,
    ORIGINAL_KEIRI_KEIJO_HI         DATE,
    SEIKYUSHO_KISAIBI               DATE NOT NULL,
    ODAIMOKU                        VARCHAR2(40),
    SEIKYUSHO_BIKO_1                VARCHAR2(40),
    SEIKYUSHO_BIKO_2                VARCHAR2(40),
    SEIKYUSAKI_CD                   CHAR(6),
    DAISANSHA_HARAI_CD              CHAR(6),
    KEIYAKUSAKI_CD                  CHAR(6),
    HANBAI_EIGYOSHO                 VARCHAR2(5),
    SEIKYU_EIGYOSHO                 VARCHAR2(5),
    MEISAI_KEI                      NUMBER(9,0) NOT NULL,
    NEBIKI_KINGAKU                  NUMBER(10,0),
    WARIMODOSHI_KINGAKU             NUMBER(10,0),
    KAZEI_TAISHO_KINGAKU            NUMBER(10,0),
    SHOHIZEI_KINGAKU                NUMBER(10,0),
    UCHIZEI_KINGAKU                 NUMBER(10,0),
    HIKAZEI_KINGAKU                 NUMBER(10,0) NOT NULL,
    SEIKYU_KINGAKU                  NUMBER(10,0),
    URIAGE_COMMENT                  VARCHAR2(1024),
    IF_RENKEI_JOKYO_FLG             CHAR(1),
    IF_RENKEI_TAISHO_FLG            CHAR(1),
    SHIME_TAISHO_KBN                CHAR(1) NOT NULL,
    SHIME_JOKYO_KBN                 CHAR(1) NOT NULL,
    SHIMEBI                         CHAR(8) NOT NULL,
    DATA_MOTO                       CHAR(2) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SONOTA_URIAGE_RIREKI
    ADD(CONSTRAINT PK_TR_SONOTA_URIAGE_RIREKI PRIMARY KEY (URIAGE_ID, URIAGE_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_CHARTER_OROSHINE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_CHARTER_OROSHINE
(
    KYORI_TEI                       NUMBER(5,0) NOT NULL,
    SHASHU_CD                       CHAR(2) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    TEKIYO_MEI                      VARCHAR2(40),
    INTIME_OROSHINE                 NUMBER(10,0) NOT NULL,
    ONTIME_OROSHINE                 NUMBER(10,0) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_CHARTER_OROSHINE
    ADD(CONSTRAINT PK_MS_CHARTER_OROSHINE PRIMARY KEY (KYORI_TEI, SHASHU_CD, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE TR_CHARTER_SHIJI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CHARTER_SHIJI
(
    OKURIJO_NO                      CHAR(13) NOT NULL,
    SHUKABI                         CHAR(8) NOT NULL,
    CHARTER_KBN                     CHAR(1) NOT NULL,
    IN_TIME_ON_TIME_KBN             CHAR(1),
    YUSO_KYORI                      NUMBER(5,0),
    POWER_GATE_UMU_FLG              CHAR(1) NOT NULL,
    AIR_SUS_UMU_FLG                 CHAR(1) NOT NULL,
    KUCHO_UMU_FLG                   CHAR(1) NOT NULL,
    HAITATSU_DO_IN_FLG              CHAR(1) NOT NULL,
    OFUKU_FLG                       CHAR(1) NOT NULL,
    YAKAN_SOCHO_FLG                 CHAR(1) NOT NULL,
    SHINYA_FLG                      CHAR(1) NOT NULL,
    KYUJITSU_FLG                    CHAR(1) NOT NULL,
    JISAN_KAISHU_FLG                CHAR(1) NOT NULL,
    SAGYO_JIKAN                     NUMBER(4,0),
    SHARYO_RYUCHI_FLG               CHAR(1) NOT NULL,
    JOSHU_NINZU                     NUMBER(2,0) NOT NULL,
    IRAIMOTO_EIGYOSHO_CD            VARCHAR2(5) NOT NULL,
    CHARTER_GYOSHA_DAIRITEN_CD      CHAR(5),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CHARTER_SHIJI
    ADD(CONSTRAINT PK_TR_CHARTER_SHIJI PRIMARY KEY (OKURIJO_NO, CHARTER_KBN, SHUKABI) USING INDEX)
/
DROP TABLE MS_CHARTER_SHUBETSU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_CHARTER_SHUBETSU
(
    CHARTER_SHUBETSU_CD             CHAR(1) NOT NULL,
    CHARTER_SHUBETSU_MEI            VARCHAR2(20) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_CHARTER_SHUBETSU
    ADD(CONSTRAINT PK_MS_CHARTER_SHUBETSU PRIMARY KEY (CHARTER_SHUBETSU_CD) USING INDEX)
/
DROP TABLE TR_CHARTER_JOSHU_RYOKIN_OROSHI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CHARTER_JOSHU_RYOKIN_OROSHI
(
    SHASHU_CD                       CHAR(2) NOT NULL,
    JIKAN                           NUMBER(3,0) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    OROSHINE_50KM_INAI              NUMBER(10,0),
    OROSHINE_50KM_KOE               NUMBER(10,0),
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CHARTER_JOSHU_RYOKIN_OROSHI
    ADD(CONSTRAINT PK_TR_CHARTER_JOSHU_RYOKIN_OROSHI PRIMARY KEY (SHASHU_CD, JIKAN, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE TR_CHARTER_URINE_MEISAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CHARTER_URINE_MEISAI
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(18,0) NOT NULL,
    AKA_KURO_KBN                    CHAR(1) NOT NULL,
    CHARTER_RYOKIN_KBN              CHAR(1) NOT NULL,
    CHARTER_KBN                     CHAR(1) NOT NULL,
    CHARTER_SHUBETSU                VARCHAR2(40) NOT NULL,
    JOKEN                           VARCHAR2(80) NOT NULL,
    SURYO                           NUMBER(9,0),
    URINE                           NUMBER(10,0) NOT NULL,
    TENYURYOKU_URINE                NUMBER(10,0),
    NEBIKI_KINGAKU                  NUMBER(10,0),
    WARIMODOSHI_KINGAKU             NUMBER(10,0),
    KAZEI_TAISHO_KINGAKU            NUMBER(10,0),
    SHOHIZEI_KINGAKU                NUMBER(10,0),
    UCHIZEI_KINGAKU                 NUMBER(10,0),
    HIKAZEI_KINGAKU                 NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CHARTER_URINE_MEISAI
    ADD(CONSTRAINT PK_TR_CHARTER_URINE_MEISAI PRIMARY KEY (URIAGE_ID, URIAGE_DATA_VERSION, AKA_KURO_KBN, CHARTER_RYOKIN_KBN) USING INDEX)
/
DROP TABLE TR_CHARTER_URINE_MEISAI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CHARTER_URINE_MEISAI_RIREKI
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    RYOKIN_KOMOKU_CD                CHAR(3) NOT NULL,
    CHARTER_RYOKIN_KBN              CHAR(1) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(18,0) NOT NULL,
    CHARTER_KBN                     CHAR(1) NOT NULL,
    CHARTER_SHUBETSU                VARCHAR2(40) NOT NULL,
    JOKEN                           VARCHAR2(80) NOT NULL,
    SURYO                           NUMBER(9,0),
    URINE                           NUMBER(10,0) NOT NULL,
    TENYURYOKU_URINE                NUMBER(10,0),
    NEBIKI_KINGAKU                  NUMBER(10,0),
    WARIMODOSHI_KINGAKU             NUMBER(10,0),
    KAZEI_TAISHO_KINGAKU            NUMBER(10,0),
    SHOHIZEI_KINGAKU                NUMBER(10,0),
    UCHIZEI_KINGAKU                 NUMBER(10,0),
    HIKAZEI_KINGAKU                 NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CHARTER_URINE_MEISAI_RIREKI
    ADD(CONSTRAINT PK_TR_CHARTER_URINE_MEISAI_RIREKI PRIMARY KEY (URIAGE_ID, RYOKIN_KOMOKU_CD, CHARTER_RYOKIN_KBN, URIAGE_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_CHARTER_FUTAI_JOHO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CHARTER_FUTAI_JOHO
(
    OKURIJO_NO                      CHAR(13) NOT NULL,
    CHARTER_SHUBETSU_CD             VARCHAR2(10) NOT NULL,
    SHUKABI                         CHAR(8) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CHARTER_FUTAI_JOHO
    ADD(CONSTRAINT PK_TR_CHARTER_FUTAI_JOHO PRIMARY KEY (OKURIJO_NO, CHARTER_SHUBETSU_CD, SHUKABI) USING INDEX)
/
DROP TABLE TR_CHARTER_FUTAI_RYOKIN_MITSUMORI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CHARTER_FUTAI_RYOKIN_MITSUMORI
(
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    CHARTER_FUTAI_RYOKIN_KOMOKU_CD  CHAR(3),
    HYOJI_MEI                       VARCHAR2(40),
    TANKA                           NUMBER(10,0),
    TANI                            VARCHAR2(20),
    SHOSUTEN_KBN                    CHAR(1),
    BIKO                            VARCHAR2(100),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CHARTER_FUTAI_RYOKIN_MITSUMORI
    ADD(CONSTRAINT PK_TR_CHARTER_FUTAI_RYOKIN_MITSUMORI PRIMARY KEY (MITSUMORI_NO, MEISAI_GYO_NO, MITSUMORI_TEIAN_NO) USING INDEX)
/
DROP TABLE TR_CHARTER_FUTAI_RYOKIN_MITSUMORI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CHARTER_FUTAI_RYOKIN_MITSUMORI_RIREKI
(
    SIMULATION_ID                   CHAR(9) NOT NULL,
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    CHARTER_FUTAI_RYOKIN_KOMOKU_CD  CHAR(3),
    HYOJI_MEI                       VARCHAR2(40),
    TANKA                           NUMBER(10,0),
    TANI                            VARCHAR2(20),
    SHOSUTEN_KBN                    CHAR(1),
    BIKO                            VARCHAR2(100),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CHARTER_FUTAI_RYOKIN_MITSUMORI_RIREKI
    ADD(CONSTRAINT PK_TR_CHARTER_FUTAI_RYOKIN_MITSUMORI_RIREKI PRIMARY KEY (MITSUMORI_TEIAN_NO, MITSUMORI_NO, MEISAI_GYO_NO, SIMULATION_ID) USING INDEX)
/
DROP TABLE TR_CHARTER_FUTAI_RYOKINHYO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CHARTER_FUTAI_RYOKINHYO
(
    KEIYAKU_ID                      NUMBER(6,0) NOT NULL,
    RYOKINHYO_NO                    CHAR(7) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    CHARTER_FUTAI_RYOKIN_KOMOKU_CD  CHAR(3),
    HYOJI_MEI                       VARCHAR2(40),
    TANKA                           NUMBER(10,0),
    TANI                            VARCHAR2(20),
    SHOSUTEN_KBN                    CHAR(1),
    BIKO                            VARCHAR2(100),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CHARTER_FUTAI_RYOKINHYO
    ADD(CONSTRAINT PK_TR_CHARTER_FUTAI_RYOKINHYO PRIMARY KEY (RYOKINHYO_NO, MEISAI_GYO_NO, KEIYAKU_ID) USING INDEX)
/
DROP TABLE TR_CHARTER_RYOKIN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CHARTER_RYOKIN
(
    KEIYAKU_ID                      NUMBER(6,0) NOT NULL,
    RYOKINHYO_NO                    CHAR(7) NOT NULL,
    KIHON_HAITATSU_DO_IN_WARIMASHI  NUMBER(3,0),
    KIHON_OFUKU_WARIMASHI           NUMBER(3,0),
    KIHON_YAKAN_SOCHO_WARIMASHI     NUMBER(3,0),
    KIHON_SHINYA_WARIMASHI          NUMBER(3,0),
    KIHON_KYUJITSU_WARIMASHI        NUMBER(3,0),
    KIHON_JISAN_KAISHU_WARIMASHI    NUMBER(3,0),
    JOSHURYO_50KM_INAI_SAISHO_1JIKAN NUMBER(10,0),
    JOSHURYO_50KM_INAI_IKO_30FUN    NUMBER(10,0),
    JOSHURYO_50KM_KOE_SAISHO_1JIKAN NUMBER(10,0),
    JOSHURYO_50KM_KOE_IKO_30FUN     NUMBER(10,0),
    JOSHURYO_YAKAN_SOCHO            NUMBER(10,0),
    JOSHURYO_SHINYA                 NUMBER(10,0),
    JOSHURYO_KYUJITSU               NUMBER(10,0),
    SHUKA_CHARTER_NEBIKI_UMU        CHAR(1),
    HAITATSU_CHARTER_NEBIKI_UMU     CHAR(1),
    CHOKUSO_CHARTER_NEBIKI_UMU      CHAR(1),
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CHARTER_RYOKIN
    ADD(CONSTRAINT PK_TR_CHARTER_RYOKIN PRIMARY KEY (RYOKINHYO_NO, KEIYAKU_ID) USING INDEX)
/
DROP TABLE TR_CHARTER_RYOKIN_MITSUMORI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CHARTER_RYOKIN_MITSUMORI
(
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    KIHON_HAITATSU_DO_IN_WARIMASHI  NUMBER(3,0),
    KIHON_OFUKU_WARIMASHI           NUMBER(3,0),
    KIHON_YAKAN_SOCHO_WARIMASHI     NUMBER(3,0),
    KIHON_SHINYA_WARIMASHI          NUMBER(3,0),
    KIHON_KYUJITSU_WARIMASHI        NUMBER(3,0),
    KIHON_JISAN_KAISHU_WARIMASHI    NUMBER(3,0),
    JOSHURYO_50KM_INAI_SAISHO_1JIKAN NUMBER(10,0),
    JOSHURYO_50KM_INAI_IKO_30FUN    NUMBER(10,0),
    JOSHURYO_50KM_KOE_SAISHO_1JIKAN NUMBER(10,0),
    JOSHURYO_50KM_KOE_IKO_30FUN     NUMBER(10,0),
    JOSHURYO_YAKAN_SOCHO            NUMBER(10,0),
    JOSHURYO_SHINYA                 NUMBER(10,0),
    JOSHURYO_KYUJITSU               NUMBER(10,0),
    SHUKA_CHARTER_NEBIKI_UMU        CHAR(1),
    HAITATSU_CHARTER_NEBIKI_UMU     CHAR(1),
    CHOKUSO_CHARTER_NEBIKI_UMU      CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CHARTER_RYOKIN_MITSUMORI
    ADD(CONSTRAINT PK_TR_CHARTER_RYOKIN_MITSUMORI PRIMARY KEY (MITSUMORI_NO, MITSUMORI_TEIAN_NO) USING INDEX)
/
DROP TABLE TR_CHARTER_RYOKIN_MITSUMORI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CHARTER_RYOKIN_MITSUMORI_RIREKI
(
    SIMULATION_ID                   CHAR(9) NOT NULL,
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    KIHON_HAITATSU_DO_IN_WARIMASHI  NUMBER(3,0),
    KIHON_OFUKU_WARIMASHI           NUMBER(3,0),
    KIHON_YAKAN_SOCHO_WARIMASHI     NUMBER(3,0),
    KIHON_SHINYA_WARIMASHI          NUMBER(3,0),
    KIHON_KYUJITSU_WARIMASHI        NUMBER(3,0),
    KIHON_JISAN_KAISHU_WARIMASHI    NUMBER(3,0),
    JOSHURYO_50KM_INAI_SAISHO_1JIKAN NUMBER(10,0),
    JOSHURYO_50KM_INAI_IKO_30FUN    NUMBER(10,0),
    JOSHURYO_50KM_KOE_SAISHO_1JIKAN NUMBER(10,0),
    JOSHURYO_50KM_KOE_IKO_30FUN     NUMBER(10,0),
    JOSHURYO_YAKAN_SOCHO            NUMBER(10,0),
    JOSHURYO_SHINYA                 NUMBER(10,0),
    JOSHURYO_KYUJITSU               NUMBER(10,0),
    SHUKA_CHARTER_NEBIKI_UMU        CHAR(1),
    HAITATSU_CHARTER_NEBIKI_UMU     CHAR(1),
    CHOKUSO_CHARTER_NEBIKI_UMU      CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CHARTER_RYOKIN_MITSUMORI_RIREKI
    ADD(CONSTRAINT PK_TR_CHARTER_RYOKIN_MITSUMORI_RIREKI PRIMARY KEY (MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID) USING INDEX)
/
DROP TABLE MS_CHARTER_RYOKIN_KOMOKU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_CHARTER_RYOKIN_KOMOKU
(
    RYOKIN_KOMOKU_CD                CHAR(3) NOT NULL,
    RYOKIN_KOMOKU_MEISHO            VARCHAR2(40),
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    CHARTER_RYOKIN_KOMOKU_DATA_VERSION NUMBER(3,0) NOT NULL,
    MEISAI_KBN                      CHAR(1) NOT NULL,
    NEBIKIFUKA_FLG                  CHAR(1) NOT NULL,
    SHOSUTEN_KBN                    CHAR(1) NOT NULL,
    SEIGYO_KBN                      CHAR(1) NOT NULL,
    ZEI_KBN                         CHAR(1) NOT NULL,
    YUSO_URIAGE_SET_SAKI            CHAR(2) NOT NULL,
    OROSHI_TANKA                    NUMBER(9,0),
    OROSHINE_RITSU                  NUMBER(4,1),
    OROSHI_KOMOKU_CD                CHAR(2),
    SHORI_KAMOKU_CD                 CHAR(4),
    HOJO_KAMOKU_CD                  CHAR(2),
    TEKIYO_MEI                      VARCHAR2(40),
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_CHARTER_RYOKIN_KOMOKU
    ADD(CONSTRAINT UK_MS_CHARTER_FUTAI_RYOKIN_KOMOKU UNIQUE (RYOKIN_KOMOKU_CD) USING INDEX)
/
ALTER TABLE MS_CHARTER_RYOKIN_KOMOKU
    ADD(CONSTRAINT PK_MS_CHARTER_RYOKIN_KOMOKU PRIMARY KEY (RYOKIN_KOMOKU_CD, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE MS_CHARTER_RYOKIN_KOMOKU_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_CHARTER_RYOKIN_KOMOKU_RIREKI
(
    RYOKIN_KOMOKU_CD                CHAR(3) NOT NULL,
    RYOKIN_KOMOKU_MEISHO            VARCHAR2(40),
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    OROSHI_KOMOKU_CD                CHAR(2),
    CHARTER_RYOKIN_KOMOKU_DATA_VERSION NUMBER(3,0) NOT NULL,
    MEISAI_KBN                      CHAR(1) NOT NULL,
    NEBIKIFUKA_FLG                  CHAR(1) NOT NULL,
    SHOSUTEN_KBN                    CHAR(1) NOT NULL,
    SEIGYO_KBN                      CHAR(1) NOT NULL,
    ZEI_KBN                         CHAR(1) NOT NULL,
    YUSO_URIAGE_SET_SAKI            CHAR(2) NOT NULL,
    OROSHI_TANKA                    NUMBER(9,0),
    OROSHINE_RITSU                  NUMBER(4,1),
    SHORI_KAMOKU_CD                 CHAR(4),
    HOJO_KAMOKU_CD                  CHAR(2),
    TEKIYO_MEI                      VARCHAR2(40),
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_CHARTER_RYOKIN_KOMOKU_RIREKI
    ADD(CONSTRAINT IX_MS_CHARTER_RYOKIN_KOMOKU_RIREKI UNIQUE (RYOKIN_KOMOKU_CD) USING INDEX)
/
ALTER TABLE MS_CHARTER_RYOKIN_KOMOKU_RIREKI
    ADD(CONSTRAINT PK_MS_CHARTER_RYOKIN_KOMOKU_RIREKI PRIMARY KEY (RYOKIN_KOMOKU_CD, TEKIYO_KAISHIBI, CHARTER_RYOKIN_KOMOKU_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_CHARTER_RYOKIN_JIKAN_WARIMASHI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CHARTER_RYOKIN_JIKAN_WARIMASHI
(
    KEIYAKU_ID                      NUMBER(6,0) NOT NULL,
    RYOKINHYO_NO                    CHAR(7) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    SHASHU_CD                       CHAR(2) NOT NULL,
    RYOKIN                          NUMBER(10,0),
    RYOKIN_KBN                      CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CHARTER_RYOKIN_JIKAN_WARIMASHI
    ADD(CONSTRAINT PK_TR_CHARTER_RYOKIN_JIKAN_WARIMASHI PRIMARY KEY (MEISAI_GYO_NO, SHASHU_CD, RYOKINHYO_NO, KEIYAKU_ID) USING INDEX)
/
DROP TABLE TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_OROSHINE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_OROSHINE
(
    SHASHU_CD                       CHAR(2) NOT NULL,
    JIKAN                           NUMBER(3,0) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    OROSHINE                        NUMBER(10,0),
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_OROSHINE
    ADD(CONSTRAINT PK_TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_OROSHINE PRIMARY KEY (SHASHU_CD, JIKAN, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_MITSUMORI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_MITSUMORI
(
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    SHASHU_CD                       CHAR(2) NOT NULL,
    RYOKIN                          NUMBER(10,0),
    RYOKIN_KBN                      CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_MITSUMORI
    ADD(CONSTRAINT PK_TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_MITSUMORI PRIMARY KEY (MEISAI_GYO_NO, SHASHU_CD, MITSUMORI_NO, MITSUMORI_TEIAN_NO) USING INDEX)
/
DROP TABLE TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_MITSUMORI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_MITSUMORI_RIREKI
(
    SIMULATION_ID                   CHAR(9) NOT NULL,
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    SHASHU_CD                       CHAR(2) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    RYOKIN                          NUMBER(10,0),
    RYOKIN_KBN                      CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_MITSUMORI_RIREKI
    ADD(CONSTRAINT PK_TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_MITSUMORI_RIREKI PRIMARY KEY (MITSUMORI_TEIAN_NO, MITSUMORI_NO, SHASHU_CD, MEISAI_GYO_NO, SIMULATION_ID) USING INDEX)
/
DROP TABLE TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_JIKANTAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_JIKANTAI
(
    KEIYAKU_ID                      NUMBER(6,0) NOT NULL,
    RYOKINHYO_NO                    CHAR(7) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    MASHI_KBN                       CHAR(1),
    JIKAN                           NUMBER(3,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_JIKANTAI
    ADD(CONSTRAINT PK_TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_JIKANTAI PRIMARY KEY (MEISAI_GYO_NO, RYOKINHYO_NO, KEIYAKU_ID) USING INDEX)
/
DROP TABLE TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_JIKANTAI_MITSUMORI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_JIKANTAI_MITSUMORI
(
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    MASHI_KBN                       CHAR(1),
    JIKAN                           NUMBER(3,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_JIKANTAI_MITSUMORI
    ADD(CONSTRAINT PK_TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_JIKANTAI_MITSUMORI PRIMARY KEY (MEISAI_GYO_NO, MITSUMORI_NO, MITSUMORI_TEIAN_NO) USING INDEX)
/
DROP TABLE TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_JIKANTAI_MITSUMORI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_JIKANTAI_MITSUMORI_RIREKI
(
    SIMULATION_ID                   CHAR(9) NOT NULL,
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    MASHI_KBN                       CHAR(1),
    JIKAN                           NUMBER(3,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_JIKANTAI_MITSUMORI_RIREKI
    ADD(CONSTRAINT PK_TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_JIKANTAI_MITSUMORI_RIREKI PRIMARY KEY (SIMULATION_ID, MITSUMORI_TEIAN_NO, MITSUMORI_NO, MEISAI_GYO_NO) USING INDEX)
/
DROP TABLE TR_CHARTER_RYOKIN_SHASHUBETSU_WARIMASHI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CHARTER_RYOKIN_SHASHUBETSU_WARIMASHI
(
    KEIYAKU_ID                      NUMBER(6,0) NOT NULL,
    RYOKINHYO_NO                    CHAR(7) NOT NULL,
    SHASHU_CD                       CHAR(2) NOT NULL,
    POWER_GATE_WARIMASHI_KBN        CHAR(1),
    POWER_GATE_WARIMASHI_RYO        NUMBER(10,0),
    POWER_GATE_SAITEI_RYOKIN        NUMBER(10,0),
    AIR_SUS_WARIMASHI_KBN           CHAR(1),
    AIR_SUS_WARIMASHI_RYO           NUMBER(10,0),
    AIR_SUS_SAITEI_RYOKIN           NUMBER(10,0),
    KUCHO_WARIMASHI_KBN             CHAR(1),
    KUCHO_WARIMASHI_RYO             NUMBER(10,0),
    KUCHO_SAITEI_RYOKIN             NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CHARTER_RYOKIN_SHASHUBETSU_WARIMASHI
    ADD(CONSTRAINT PK_TR_CHARTER_RYOKIN_SHASHUBETSU_WARIMASHI PRIMARY KEY (SHASHU_CD, RYOKINHYO_NO, KEIYAKU_ID) USING INDEX)
/
DROP TABLE TR_CHARTER_RYOKIN_SHASHUBETSU_WARIMASHI_MITSUMORI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CHARTER_RYOKIN_SHASHUBETSU_WARIMASHI_MITSUMORI
(
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    SHASHU_CD                       CHAR(2) NOT NULL,
    POWER_GATE_WARIMASHI_KBN        CHAR(1),
    POWER_GATE_WARIMASHI_RYO        NUMBER(10,0),
    POWER_GATE_SAITEI_RYOKIN        NUMBER(10,0),
    AIR_SUS_WARIMASHI_KBN           CHAR(1),
    AIR_SUS_WARIMASHI_RYO           NUMBER(10,0),
    AIR_SUS_SAITEI_RYOKIN           NUMBER(10,0),
    KUCHO_WARIMASHI_KBN             CHAR(1),
    KUCHO_WARIMASHI_RYO             NUMBER(10,0),
    KUCHO_SAITEI_RYOKIN             NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CHARTER_RYOKIN_SHASHUBETSU_WARIMASHI_MITSUMORI
    ADD(CONSTRAINT PK_TR_CHARTER_RYOKIN_SHASHUBETSU_WARIMASHI_MITSUMORI PRIMARY KEY (SHASHU_CD, MITSUMORI_NO, MITSUMORI_TEIAN_NO) USING INDEX)
/
DROP TABLE TR_CHARTER_RYOKIN_SHASHUBETSU_WARIMASHI_MITSUMORI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CHARTER_RYOKIN_SHASHUBETSU_WARIMASHI_MITSUMORI_RIREKI
(
    SIMULATION_ID                   CHAR(9) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    SHASHU_CD                       CHAR(2) NOT NULL,
    POWER_GATE_WARIMASHI_KBN        CHAR(1),
    POWER_GATE_WARIMASHI_RYO        NUMBER(10,0),
    POWER_GATE_SAITEI_RYOKIN        NUMBER(10,0),
    AIR_SUS_WARIMASHI_KBN           CHAR(1),
    AIR_SUS_WARIMASHI_RYO           NUMBER(10,0),
    AIR_SUS_SAITEI_RYOKIN           NUMBER(10,0),
    KUCHO_WARIMASHI_KBN             CHAR(1),
    KUCHO_WARIMASHI_RYO             NUMBER(10,0),
    KUCHO_SAITEI_RYOKIN             NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CHARTER_RYOKIN_SHASHUBETSU_WARIMASHI_MITSUMORI_RIREKI
    ADD(CONSTRAINT PK_TR_CHARTER_RYOKIN_SHASHUBETSU_WARIMASHI_MITSUMORI_RIREKI PRIMARY KEY (MITSUMORI_NO, MITSUMORI_TEIAN_NO, SHASHU_CD, SIMULATION_ID) USING INDEX)
/
DROP TABLE TR_CHARTER_RYOKIN_YUSORYO_KYORI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CHARTER_RYOKIN_YUSORYO_KYORI
(
    KEIYAKU_ID                      NUMBER(6,0) NOT NULL,
    RYOKINHYO_NO                    CHAR(7) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    KYORI                           NUMBER(5,0),
    MASHI_KBN                       CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CHARTER_RYOKIN_YUSORYO_KYORI
    ADD(CONSTRAINT PK_TR_CHARTER_RYOKIN_YUSORYO_KYORI PRIMARY KEY (MEISAI_GYO_NO, RYOKINHYO_NO, KEIYAKU_ID) USING INDEX)
/
DROP TABLE TR_CHARTER_RYOKIN_YUSORYO_KYORI_MITSUMORI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CHARTER_RYOKIN_YUSORYO_KYORI_MITSUMORI
(
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    KYORI                           NUMBER(5,0),
    MASHI_KBN                       CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CHARTER_RYOKIN_YUSORYO_KYORI_MITSUMORI
    ADD(CONSTRAINT PK_TR_CHARTER_RYOKIN_YUSORYO_KYORI_MITSUMORI PRIMARY KEY (MEISAI_GYO_NO, MITSUMORI_NO, MITSUMORI_TEIAN_NO) USING INDEX)
/
DROP TABLE TR_CHARTER_RYOKIN_YUSORYO_KYORI_MITSUMORI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CHARTER_RYOKIN_YUSORYO_KYORI_MITSUMORI_RIREKI
(
    SIMULATION_ID                   CHAR(9) NOT NULL,
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    KYORI                           NUMBER(5,0),
    MASHI_KBN                       CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CHARTER_RYOKIN_YUSORYO_KYORI_MITSUMORI_RIREKI
    ADD(CONSTRAINT PK_TR_CHARTER_RYOKIN_YUSORYO_KYORI_MITSUMORI_RIREKI PRIMARY KEY (SIMULATION_ID, MITSUMORI_TEIAN_NO, MITSUMORI_NO, MEISAI_GYO_NO) USING INDEX)
/
DROP TABLE TR_CHARTER_RYOKIN_YUSO_RYOKINHYO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CHARTER_RYOKIN_YUSO_RYOKINHYO
(
    KEIYAKU_ID                      NUMBER(6,0) NOT NULL,
    RYOKINHYO_NO                    CHAR(7) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    SHASHU_CD                       CHAR(2) NOT NULL,
    IN_TIME_RYOKIN                  NUMBER(10,0),
    ON_TIME_RYOKIN                  NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CHARTER_RYOKIN_YUSO_RYOKINHYO
    ADD(CONSTRAINT PK_TR_CHARTER_RYOKIN_YUSO_RYOKINHYO PRIMARY KEY (MEISAI_GYO_NO, SHASHU_CD, RYOKINHYO_NO, KEIYAKU_ID) USING INDEX)
/
DROP TABLE TR_CHARTER_RYOKIN_YUSORYO_MITSUMORI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CHARTER_RYOKIN_YUSORYO_MITSUMORI
(
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    SHASHU_CD                       CHAR(2) NOT NULL,
    IN_TIME_RYOKIN                  NUMBER(10,0),
    ON_TIME_RYOKIN                  NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CHARTER_RYOKIN_YUSORYO_MITSUMORI
    ADD(CONSTRAINT PK_TR_CHARTER_RYOKIN_YUSORYO_MITSUMORI PRIMARY KEY (MEISAI_GYO_NO, SHASHU_CD, MITSUMORI_NO, MITSUMORI_TEIAN_NO) USING INDEX)
/
DROP TABLE TR_CHARTER_RYOKIN_YUSORYO_MITSUMORI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_CHARTER_RYOKIN_YUSORYO_MITSUMORI_RIREKI
(
    SIMULATION_ID                   CHAR(9) NOT NULL,
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    SHASHU_CD                       CHAR(2) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    IN_TIME_RYOKIN                  NUMBER(10,0),
    ON_TIME_RYOKIN                  NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_CHARTER_RYOKIN_YUSORYO_MITSUMORI_RIREKI
    ADD(CONSTRAINT PK_TR_CHARTER_RYOKIN_YUSORYO_MITSUMORI_RIREKI PRIMARY KEY (MITSUMORI_TEIAN_NO, MITSUMORI_NO, SHASHU_CD, MEISAI_GYO_NO, SIMULATION_ID) USING INDEX)
/
DROP TABLE MS_TRACE_KBN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_TRACE_KBN
(
    TRACE_SHUBETSU                  CHAR(2) NOT NULL,
    TRACE_JOTAI_KBN                 CHAR(2) NOT NULL,
    TRACE_SHUBETSU_MEISHO           VARCHAR2(20),
    TRACE_JOTAI_KBN_MEISHO          VARCHAR2(20),
    JOTAI_CD                        VARCHAR2(10),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_TRACE_KBN
    ADD(CONSTRAINT PK_MS_TRACE_KBN PRIMARY KEY (TRACE_SHUBETSU, TRACE_JOTAI_KBN) USING INDEX)
/
DROP TABLE TR_TRACE_SETTEI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_TRACE_SETTEI
(
    EDI_SETTEI_ID                   CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    EDI_SETTEI_DATA_VERSION         NUMBER(3,0) NOT NULL,
    SHUKA                           CHAR(1),
    SHUKA_KO                        CHAR(1),
    TSUMIKOMI                       CHAR(1),
    TOCHAKU                         CHAR(1),
    MOCHIDASHI                      CHAR(1),
    HOKAN                           CHAR(1),
    FUZAI_MOCHI_KAERI               CHAR(1),
    UKETORI_KYOHI                   CHAR(1),
    KOKYAKU_SHIJI                   CHAR(1),
    HAIKAN                          CHAR(1),
    SCRIPT_ID                       VARCHAR2(8),
    FILE_TYPE                       CHAR(1),
    ZERO_KENJI_SOSHIN_SETTEI        CHAR(1),
    JIKKO_TIMMING_KBN               CHAR(1),
    DOYOBI_SOSHIN_FLG               CHAR(1),
    NICHIYOBI_SOSHIN_FLG            CHAR(1),
    SHUKUJITSU_SOSHIN_FLG           CHAR(1),
    KLS_KYUJITSU_SOSHIN_FLG         CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_TRACE_SETTEI
    ADD(CONSTRAINT PK_TR_TRACE_SETTEI PRIMARY KEY (EDI_SETTEI_ID, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE TR_TRACE_SETTEI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_TRACE_SETTEI_RIREKI
(
    EDI_SETTEI_ID                   CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    EDI_SETTEI_DATA_VERSION         NUMBER(3,0) NOT NULL,
    SHUKA                           CHAR(1),
    SHUKA_KO                        CHAR(1),
    TSUMIKOMI                       CHAR(1),
    TOCHAKU                         CHAR(1),
    MOCHIDASHI                      CHAR(1),
    HOKAN                           CHAR(1),
    FUZAI_MOCHI_KAERI               CHAR(1),
    UKETORI_KYOHI                   CHAR(1),
    KOKYAKU_SHIJI                   CHAR(1),
    HAIKAN                          CHAR(1),
    SCRIPT_ID                       VARCHAR2(8),
    FILE_TYPE                       CHAR(1),
    ZERO_KENJI_SOSHIN_SETTEI        CHAR(1),
    JIKKO_TIMMING_KBN               CHAR(1),
    DOYOBI_SOSHIN_FLG               CHAR(1),
    NICHIYOBI_SOSHIN_FLG            CHAR(1),
    SHUKUJITSU_SOSHIN_FLG           CHAR(1),
    KLS_KYUJITSU_SOSHIN_FLG         CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_TRACE_SETTEI_RIREKI
    ADD(CONSTRAINT PK_TR_TRACE_SETTEI_RIREKI PRIMARY KEY (EDI_SETTEI_ID, TEKIYO_KAISHIBI, EDI_SETTEI_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_TRACE_SETTEI_JIKKO_TIMMING CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_TRACE_SETTEI_JIKKO_TIMMING
(
    EDI_SETTEI_ID                   CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TRACE_SETTEI_SEQ                NUMBER(7,0) NOT NULL,
    EDI_SETTEI_DATA_VERSION         NUMBER(3,0) NOT NULL,
    JIKKO_TIMMING_HI                VARCHAR2(2),
    JIKKO_TIMMING_YOBI              VARCHAR2(2),
    JIKKO_TIMMING_JIKAN_1           DATE,
    JIKKO_TIMMING_JIKAN_2           DATE,
    JIKKO_TIMMING_JIKAN_3           DATE,
    JIKKO_TIMMING_JIKAN_4           DATE,
    JIKKO_TIMMING_JIKAN_5           DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_TRACE_SETTEI_JIKKO_TIMMING
    ADD(CONSTRAINT PK_TR_TRACE_SETTEI_JIKKO_TIMMING PRIMARY KEY (EDI_SETTEI_ID, TRACE_SETTEI_SEQ, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE TR_TRACE_SETTEI_JIKKO_TIMMING_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_TRACE_SETTEI_JIKKO_TIMMING_RIREKI
(
    EDI_SETTEI_ID                   CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TRACE_SETTEI_SEQ                NUMBER(7,0) NOT NULL,
    EDI_SETTEI_DATA_VERSION         NUMBER(3,0) NOT NULL,
    JIKKO_TIMMING_HI                VARCHAR2(2),
    JIKKO_TIMMING_YOBI              VARCHAR2(2),
    JIKKO_TIMMING_JIKAN_1           DATE,
    JIKKO_TIMMING_JIKAN_2           DATE,
    JIKKO_TIMMING_JIKAN_3           DATE,
    JIKKO_TIMMING_JIKAN_4           DATE,
    JIKKO_TIMMING_JIKAN_5           DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_TRACE_SETTEI_JIKKO_TIMMING_RIREKI
    ADD(CONSTRAINT PK_TR_TRACE_SETTEI_JIKKO_TIMMING_RIREKI PRIMARY KEY (EDI_SETTEI_ID, TEKIYO_KAISHIBI, TRACE_SETTEI_SEQ, EDI_SETTEI_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_NORMAL_UNCHIN_MITSUMORI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_NORMAL_UNCHIN_MITSUMORI
(
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    SHUKA_RYOKINHYO                 VARCHAR2(10),
    HAITATSU_RYOKINHYO              VARCHAR2(10),
    KOKU_RYOKINHYO                  VARCHAR2(8),
    KOKU_RYOKINHYO_TEKIYO_KAISHIBI  DATE,
    TORIATSUKAI_TESURYO             NUMBER(10,0),
    TSUSHIN_RYO                     NUMBER(10,0),
    CHAKUBARAI_TESURYO              NUMBER(10,0),
    SHUKA_RYOKINHYO_NEBIKI_UMU      CHAR(1),
    HAITATSU_RYOKINHYO_NEBIKI_UMU   CHAR(1),
    KOKU_RYOKINHYO_NEBIKI_UMU       CHAR(1),
    TORIATSUKAI_TESURYO_NEBIKI_UMU  CHAR(1),
    KOKYAKU_SHUKA_RYOKIN_FLG        CHAR(1),
    EIGYOSHODOME_RYOKIN_KASAN_FLG   CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_NORMAL_UNCHIN_MITSUMORI
    ADD(CONSTRAINT PK_TR_NORMAL_UNCHIN_MITSUMORI PRIMARY KEY (MITSUMORI_NO, MITSUMORI_TEIAN_NO) USING INDEX)
/
DROP TABLE TR_NORMAL_UNCHIN_MITSUMORI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_NORMAL_UNCHIN_MITSUMORI_RIREKI
(
    SIMULATION_ID                   CHAR(9) NOT NULL,
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    SHUKA_RYOKINHYO                 VARCHAR2(10),
    HAITATSU_RYOKINHYO              VARCHAR2(10),
    KOKU_RYOKINHYO                  VARCHAR2(8),
    KOKU_RYOKINHYO_TEKIYO_KAISHIBI  DATE,
    TORIATSUKAI_TESURYO             NUMBER(10,0),
    TSUSHIN_RYO                     NUMBER(10,0),
    CHAKUBARAI_TESURYO              NUMBER(10,0),
    SHUKA_RYOKINHYO_NEBIKI_UMU      CHAR(1),
    HAITATSU_RYOKINHYO_NEBIKI_UMU   CHAR(1),
    KOKU_RYOKINHYO_NEBIKI_UMU       CHAR(1),
    TORIATSUKAI_TESURYO_NEBIKI_UMU  CHAR(1),
    KOKYAKU_SHUKA_RYOKIN_FLG        CHAR(1),
    EIGYOSHODOME_RYOKIN_KASAN_FLG   CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_NORMAL_UNCHIN_MITSUMORI_RIREKI
    ADD(CONSTRAINT PK_TR_NORMAL_UNCHIN_MITSUMORI_RIREKI PRIMARY KEY (MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID) USING INDEX)
/
DROP TABLE TR_NORMAL_UNCHINHYO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_NORMAL_UNCHINHYO
(
    KEIYAKU_ID                      NUMBER(6,0) NOT NULL,
    RYOKINHYO_NO                    CHAR(7) NOT NULL,
    SHUKA_RYOKINHYO                 VARCHAR2(10),
    HAITATSU_RYOKINHYO              VARCHAR2(10),
    KOKU_RYOKINHYO                  VARCHAR2(8),
    KOKU_RYOKINHYO_TEKIYO_KAISHIBI  DATE,
    TORIATSUKAI_TESURYO             NUMBER(10,0),
    TSUSHIN_RYO                     NUMBER(10,0),
    CHAKUBARAI_TESURYO              NUMBER(10,0),
    SHUKA_RYOKINHYO_NEBIKI_UMU      CHAR(1),
    HAITATSU_RYOKINHYO_NEBIKI_UMU   CHAR(1),
    KOKU_RYOKINHYO_NEBIKI_UMU       CHAR(1),
    TORIATSUKAI_TESURYO_NEBIKI_UMU  CHAR(1),
    KOKYAKU_SHUKA_RYOKIN_FLG        CHAR(1),
    EIGYOSHODOME_RYOKIN_KASAN_FLG   CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_NORMAL_UNCHINHYO
    ADD(CONSTRAINT PK_TR_NORMAL_UNCHINHYO PRIMARY KEY (RYOKINHYO_NO, KEIYAKU_ID) USING INDEX)
/
DROP TABLE TR_PASSWORD_GO_NYURYOKU_KAISU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_PASSWORD_GO_NYURYOKU_KAISU
(
    USER_CD                         CHAR(7) NOT NULL,
    KAISU                           NUMBER(3,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_PASSWORD_GO_NYURYOKU_KAISU
    ADD(CONSTRAINT PK_TR_PASSWORD_GO_NYURYOKU_KAISU PRIMARY KEY (USER_CD) USING INDEX)
/
DROP TABLE TR_PASSWORD_SHOKIKA_SHINSEI_SHOSAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_PASSWORD_SHOKIKA_SHINSEI_SHOSAI
(
    SHINSEI_ID                      VARCHAR2(6) NOT NULL,
    USER_CD                         CHAR(7) NOT NULL,
    TSUCHI_HOHO                     VARCHAR2(1),
    MAIL_ADDRESS                    VARCHAR2(50),
    TEL_BANGO                       VARCHAR2(19),
    RENRAKUSAKI                     VARCHAR2(20),
    SHINSEI_RIYU                    VARCHAR2(512),
    HONNIN_KAKUNIN_SUMI_FLG         VARCHAR2(1),
    PASSWORD_HENKO_FLG              VARCHAR2(1),
    LOGIN_FLG                       CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_PASSWORD_SHOKIKA_SHINSEI_SHOSAI
    ADD(CONSTRAINT PK_TR_PASSWORD_SHOKIKA_SHINSEI_SHOSAI PRIMARY KEY (SHINSEI_ID, USER_CD) USING INDEX)
/
DROP TABLE TR_PACK_RYOKIN_MITSUMORI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_PACK_RYOKIN_MITSUMORI
(
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    UNCHIN_KEISAN_PTN               CHAR(2),
    HATSU_CHAKU_DO_JUSHO            CHAR(1),
    OFUKU_DO_RYOKIN                 CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_PACK_RYOKIN_MITSUMORI
    ADD(CONSTRAINT PK_TR_PACK_RYOKIN_MITSUMORI PRIMARY KEY (MITSUMORI_NO, MITSUMORI_TEIAN_NO) USING INDEX)
/
DROP TABLE TR_PACK_RYOKIN_MITSUMORI_TATENE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_PACK_RYOKIN_MITSUMORI_TATENE
(
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    JURYO                           NUMBER(10,0),
    KOSU                            NUMBER(10,0),
    HIMMOKU                         VARCHAR2(40),
    MASHI_KBN                       CHAR(1),
    MASHI_IKICHI                    NUMBER(10,0),
    MASHI_ZOBUN                     NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_PACK_RYOKIN_MITSUMORI_TATENE
    ADD(CONSTRAINT PK_TR_PACK_RYOKIN_MITSUMORI_TATENE PRIMARY KEY (MEISAI_GYO_NO, MITSUMORI_NO, MITSUMORI_TEIAN_NO) USING INDEX)
/
DROP TABLE TR_PACK_RYOKIN_MITSUMORI_TATENE_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_PACK_RYOKIN_MITSUMORI_TATENE_RIREKI
(
    SIMULATION_ID                   CHAR(9) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    JURYO                           NUMBER(10,0),
    KOSU                            NUMBER(10,0),
    HIMMOKU                         VARCHAR2(40),
    MASHI_KBN                       CHAR(1),
    MASHI_IKICHI                    NUMBER(10,0),
    MASHI_ZOBUN                     NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_PACK_RYOKIN_MITSUMORI_TATENE_RIREKI
    ADD(CONSTRAINT PK_TR_PACK_RYOKIN_MITSUMORI_TATENE_RIREKI PRIMARY KEY (MEISAI_GYO_NO, MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID) USING INDEX)
/
DROP TABLE TR_PACK_RYOKIN_MITSUMORI_CHIIKI_SETTEI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_PACK_RYOKIN_MITSUMORI_CHIIKI_SETTEI
(
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    UNCHIN_RANK                     NUMBER(4,0) NOT NULL,
    HOTCHI_CHAKU_CHIKU_KBN          CHAR(1) NOT NULL,
    CHIIKI_MEI                      VARCHAR2(20),
    INSATSUYO_MEISHO_1              VARCHAR2(20),
    INSATSUYO_MEISHO_2              VARCHAR2(20),
    INSATSUYO_MEISHO_3              VARCHAR2(20),
    INSATSUYO_MEISHO_4              VARCHAR2(20),
    INSATSUYO_MEISHO_5              VARCHAR2(20),
    INSATSUYO_MEISHO_6              VARCHAR2(20),
    INSATSUYO_MEISHO_7              VARCHAR2(20),
    INSATSUYO_MEISHO_8              VARCHAR2(20),
    HYOJI_JUN                       NUMBER(3,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_PACK_RYOKIN_MITSUMORI_CHIIKI_SETTEI
    ADD(CONSTRAINT PK_TR_PACK_RYOKIN_MITSUMORI_CHIIKI_SETTEI PRIMARY KEY (MITSUMORI_TEIAN_NO, MITSUMORI_NO, UNCHIN_RANK, HOTCHI_CHAKU_CHIKU_KBN) USING INDEX)
/
DROP TABLE TR_PACK_RYOKIN_MITSUMORI_CHIIKI_SETTEI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_PACK_RYOKIN_MITSUMORI_CHIIKI_SETTEI_RIREKI
(
    SIMULATION_ID                   CHAR(9) NOT NULL,
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    UNCHIN_RANK                     NUMBER(4,0) NOT NULL,
    HOTCHI_CHAKU_CHIKU_KBN          CHAR(1) NOT NULL,
    CHIIKI_MEI                      VARCHAR2(20),
    INSATSUYO_MEISHO_1              VARCHAR2(20),
    INSATSUYO_MEISHO_2              VARCHAR2(20),
    INSATSUYO_MEISHO_3              VARCHAR2(20),
    INSATSUYO_MEISHO_4              VARCHAR2(20),
    INSATSUYO_MEISHO_5              VARCHAR2(20),
    INSATSUYO_MEISHO_6              VARCHAR2(20),
    INSATSUYO_MEISHO_7              VARCHAR2(20),
    INSATSUYO_MEISHO_8              VARCHAR2(20),
    HYOJI_JUN                       NUMBER(3,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_PACK_RYOKIN_MITSUMORI_CHIIKI_SETTEI_RIREKI
    ADD(CONSTRAINT PK_TR_PACK_RYOKIN_MITSUMORI_CHIIKI_SETTEI_RIREKI PRIMARY KEY (SIMULATION_ID, MITSUMORI_TEIAN_NO, MITSUMORI_NO, UNCHIN_RANK, HOTCHI_CHAKU_CHIKU_KBN) USING INDEX)
/
DROP TABLE TR_PACK_RYOKIN_MITSUMORI_CHIIKI_MEISAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_PACK_RYOKIN_MITSUMORI_CHIIKI_MEISAI
(
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    UNCHIN_RANK                     NUMBER(4,0) NOT NULL,
    JIS_CD                          CHAR(5) NOT NULL,
    HYOJI_JUN                       NUMBER(3,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE,
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    HOTCHI_CHAKU_CHIKU_KBN          CHAR(1) NOT NULL
)
/
ALTER TABLE TR_PACK_RYOKIN_MITSUMORI_CHIIKI_MEISAI
    ADD(CONSTRAINT PK_TR_PACK_RYOKIN_MITSUMORI_CHIIKI_MEISAI PRIMARY KEY (MITSUMORI_NO, UNCHIN_RANK, JIS_CD, MITSUMORI_TEIAN_NO, HOTCHI_CHAKU_CHIKU_KBN) USING INDEX)
/
DROP TABLE TR_PACK_RYOKIN_MITSUMORI_CHIIKI_MEISAI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_PACK_RYOKIN_MITSUMORI_CHIIKI_MEISAI_RIREKI
(
    SIMULATION_ID                   CHAR(9) NOT NULL,
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    UNCHIN_RANK                     NUMBER(4,0) NOT NULL,
    HOTCHI_CHAKU_CHIKU_KBN          CHAR(1) NOT NULL,
    JIS_CD                          CHAR(5) NOT NULL,
    HYOJI_JUN                       NUMBER(3,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_PACK_RYOKIN_MITSUMORI_CHIIKI_MEISAI_RIREKI
    ADD(CONSTRAINT PK_TR_PACK_RYOKIN_MITSUMORI_CHIIKI_MEISAI_RIREKI PRIMARY KEY (SIMULATION_ID, MITSUMORI_TEIAN_NO, MITSUMORI_NO, UNCHIN_RANK, JIS_CD, HOTCHI_CHAKU_CHIKU_KBN) USING INDEX)
/
DROP TABLE TR_PACK_RYOKIN_MITSUMORI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_PACK_RYOKIN_MITSUMORI_RIREKI
(
    SIMULATION_ID                   CHAR(9) NOT NULL,
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    UNCHIN_KEISAN_PTN               CHAR(2),
    HATSU_CHAKU_DO_JUSHO            CHAR(1),
    OFUKU_DO_RYOKIN                 CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_PACK_RYOKIN_MITSUMORI_RIREKI
    ADD(CONSTRAINT PK_TR_PACK_RYOKIN_MITSUMORI_RIREKI PRIMARY KEY (MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID) USING INDEX)
/
DROP TABLE TR_PACK_RYOKIN_MITSUMORI_RYOKIN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_PACK_RYOKIN_MITSUMORI_RYOKIN
(
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    HIKITORI_CHAKUCHI_RANK          NUMBER(4,0) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    KINGAKU                         NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE,
    UNCHIN_RANK                     NUMBER(4,0) NOT NULL,
    HOTCHI_CHAKU_CHIKU_KBN          CHAR(1) NOT NULL
)
/
ALTER TABLE TR_PACK_RYOKIN_MITSUMORI_RYOKIN
    ADD(CONSTRAINT PK_TR_PACK_RYOKIN_MITSUMORI_RYOKIN PRIMARY KEY (MITSUMORI_TEIAN_NO, MITSUMORI_NO, HIKITORI_CHAKUCHI_RANK, MEISAI_GYO_NO, UNCHIN_RANK, HOTCHI_CHAKU_CHIKU_KBN) USING INDEX)
/
DROP TABLE TR_PACK_RYOKIN_MITSUMORI_RYOKIN_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_PACK_RYOKIN_MITSUMORI_RYOKIN_RIREKI
(
    SIMULATION_ID                   CHAR(9) NOT NULL,
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    UNCHIN_RANK                     NUMBER(4,0) NOT NULL,
    HOTCHI_CHAKU_CHIKU_KBN          CHAR(1) NOT NULL,
    HIKITORI_CHAKUCHI_RANK          NUMBER(4,0) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    KINGAKU                         NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_PACK_RYOKIN_MITSUMORI_RYOKIN_RIREKI
    ADD(CONSTRAINT PK_TR_PACK_RYOKIN_MITSUMORI_RYOKIN_RIREKI PRIMARY KEY (SIMULATION_ID, MITSUMORI_TEIAN_NO, MITSUMORI_NO, UNCHIN_RANK, HOTCHI_CHAKU_CHIKU_KBN, MEISAI_GYO_NO, HIKITORI_CHAKUCHI_RANK) USING INDEX)
/
DROP TABLE TR_PACK_RYOKINHYO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_PACK_RYOKINHYO
(
    KEIYAKU_ID                      NUMBER(6,0) NOT NULL,
    RYOKINHYO_NO                    CHAR(7) NOT NULL,
    UNCHIN_KEISAN_PTN               CHAR(2),
    HATSU_CHAKU_DO_JUSHO            CHAR(1),
    OFUKU_DO_RYOKIN                 CHAR(1),
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_PACK_RYOKINHYO
    ADD(CONSTRAINT PK_TR_PACK_RYOKINHYO PRIMARY KEY (RYOKINHYO_NO, KEIYAKU_ID) USING INDEX)
/
DROP TABLE TR_PACK_RYOKINHYO_TATENE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_PACK_RYOKINHYO_TATENE
(
    KEIYAKU_ID                      NUMBER(6,0) NOT NULL,
    RYOKINHYO_NO                    CHAR(7) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    JURYO                           NUMBER(10,0),
    KOSU                            NUMBER(10,0),
    HIMMOKU                         VARCHAR2(40),
    MASHI_KBN                       CHAR(1),
    MASHI_IKICHI                    NUMBER(10,0),
    MASHI_ZOBUN                     NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_PACK_RYOKINHYO_TATENE
    ADD(CONSTRAINT PK_TR_PACK_RYOKINHYO_TATENE PRIMARY KEY (MEISAI_GYO_NO, RYOKINHYO_NO, KEIYAKU_ID) USING INDEX)
/
DROP TABLE TR_PACK_RYOKINHYO_CHIIKI_SETTEI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_PACK_RYOKINHYO_CHIIKI_SETTEI
(
    RYOKINHYO_NO                    CHAR(7) NOT NULL,
    UNCHIN_RANK                     NUMBER(4,0) NOT NULL,
    HOTCHI_CHAKU_CHIKU_KBN          CHAR(1) NOT NULL,
    CHIIKI_MEI                      VARCHAR2(20),
    INSATSUYO_MEISHO_1              VARCHAR2(20),
    INSATSUYO_MEISHO_2              VARCHAR2(20),
    INSATSUYO_MEISHO_3              VARCHAR2(20),
    INSATSUYO_MEISHO_4              VARCHAR2(20),
    INSATSUYO_MEISHO_5              VARCHAR2(20),
    INSATSUYO_MEISHO_6              VARCHAR2(20),
    INSATSUYO_MEISHO_7              VARCHAR2(20),
    INSATSUYO_MEISHO_8              VARCHAR2(20),
    HYOJI_JUN                       NUMBER(3,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE,
    KEIYAKU_ID                      NUMBER(6,0) NOT NULL
)
/
ALTER TABLE TR_PACK_RYOKINHYO_CHIIKI_SETTEI
    ADD(CONSTRAINT PK_TR_PACK_RYOKINHYO_CHIIKI_SETTEI PRIMARY KEY (RYOKINHYO_NO, UNCHIN_RANK, HOTCHI_CHAKU_CHIKU_KBN, KEIYAKU_ID) USING INDEX)
/
DROP TABLE TR_PACK_RYOKINHYO_CHIIKI_MEISAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_PACK_RYOKINHYO_CHIIKI_MEISAI
(
    RYOKINHYO_NO                    CHAR(7) NOT NULL,
    UNCHIN_RANK                     NUMBER(4,0) NOT NULL,
    HOTCHI_CHAKU_CHIKU_KBN          CHAR(1) NOT NULL,
    JIS_CD                          CHAR(5) NOT NULL,
    HYOJI_JUN                       NUMBER(3,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE,
    KEIYAKU_ID                      NUMBER(6,0) NOT NULL
)
/
ALTER TABLE TR_PACK_RYOKINHYO_CHIIKI_MEISAI
    ADD(CONSTRAINT PK_TR_PACK_RYOKINHYO_CHIIKI_MEISAI PRIMARY KEY (RYOKINHYO_NO, UNCHIN_RANK, HOTCHI_CHAKU_CHIKU_KBN, JIS_CD, KEIYAKU_ID) USING INDEX)
/
DROP TABLE TR_PACK_RYOKINHYO_RYOKIN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_PACK_RYOKINHYO_RYOKIN
(
    RYOKINHYO_NO                    CHAR(7) NOT NULL,
    UNCHIN_RANK                     NUMBER(4,0) NOT NULL,
    HOTCHI_CHAKU_CHIKU_KBN          CHAR(1) NOT NULL,
    HIKITORI_CHAKUCHI_RANK          NUMBER(4,0) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    KINGAKU                         NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE,
    KEIYAKU_ID                      NUMBER(6,0) NOT NULL
)
/
ALTER TABLE TR_PACK_RYOKINHYO_RYOKIN
    ADD(CONSTRAINT PK_TR_PACK_RYOKINHYO_RYOKIN PRIMARY KEY (RYOKINHYO_NO, UNCHIN_RANK, HOTCHI_CHAKU_CHIKU_KBN, HIKITORI_CHAKUCHI_RANK, MEISAI_GYO_NO, KEIYAKU_ID) USING INDEX)
/
DROP TABLE MS_BATCH_MEISHO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_BATCH_MEISHO
(
    BATCH_MEISHO_CD                 CHAR(8) NOT NULL,
    BATCH_MEISHO                    VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_BATCH_MEISHO
    ADD(CONSTRAINT PK_MS_BATCH_MEISHO PRIMARY KEY (BATCH_MEISHO_CD) USING INDEX)
/
DROP TABLE MS_PRINTER_TRAY CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_PRINTER_TRAY
(
    PRINTER_ID                      NUMBER(3,0) NOT NULL,
    TRAY_ID                         NUMBER(3,0) NOT NULL,
    TRAY_MEI                        VARCHAR2(100) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_PRINTER_TRAY
    ADD(CONSTRAINT PK_MS_PRINTER_TRAY PRIMARY KEY (PRINTER_ID, TRAY_ID) USING INDEX)
/
DROP TABLE MS_PRINTER CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_PRINTER
(
    PRINTER_ID                      NUMBER(3,0) NOT NULL,
    PRINTER_MEI                     VARCHAR2(20) NOT NULL,
    SETCHI_EIGYOSHO                 VARCHAR2(3) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_PRINTER
    ADD(CONSTRAINT PK_MS_PRINTER PRIMARY KEY (PRINTER_ID, SAKUJO_FLG) USING INDEX)
/
DROP TABLE TR_PROOF_CHECK_SONOTA_SEIKYU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_PROOF_CHECK_SONOTA_SEIKYU
(
    URIAGE_ID                       NUMBER(15,0) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(3,0) NOT NULL,
    SEIKYU_KEIJO_NO                 CHAR(6) NOT NULL,
    KOKYAKU_CD                      CHAR(6),
    SEIKYUSAKI_CD                   CHAR(6) NOT NULL,
    DATA_MOTO                       CHAR(2) NOT NULL,
    HENKO_SUMI_FLG                  CHAR(1) NOT NULL,
    KOSHINBI                        CHAR(8) NOT NULL,
    PROOF_STATUS                    CHAR(1) NOT NULL,
    SEIKYU_HIZUKE                   CHAR(8) NOT NULL,
    NYURYOKUSHA_MEMO                VARCHAR2(512),
    TANKA                           NUMBER(10,0),
    SURYO                           NUMBER(9,0),
    KAZEI_TAISHO_KINGAKU            NUMBER(10,0) NOT NULL,
    SHOHIZEI_KINGAKU                NUMBER(10,0) NOT NULL,
    UCHIZEI_KINGAKU                 NUMBER(10,0) NOT NULL,
    HIKAZEI_MENZEI                  NUMBER(10,0) NOT NULL,
    URIAGE_GOKEI                    NUMBER(10,0) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_PROOF_CHECK_SONOTA_SEIKYU
    ADD(CONSTRAINT PK_TR_PROOF_CHECK_SONOTA_SEIKYU PRIMARY KEY (SEIKYU_KEIJO_NO, URIAGE_ID, URIAGE_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_PROOF_CHECK_SONOTA_URIAGE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_PROOF_CHECK_SONOTA_URIAGE
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(3,0) NOT NULL,
    KOKYAKU_CD                      CHAR(6),
    STATUS                          CHAR(1) NOT NULL,
    KOSHINBI                        CHAR(8) NOT NULL,
    CHEKUBI                         CHAR(8) NOT NULL,
    URIAGE_HI_FROM                  DATE NOT NULL,
    URIAGE_HI_TO                    DATE NOT NULL,
    KEIRI_KEIJOBI                   CHAR(8) NOT NULL,
    DATA_MOTO                       CHAR(2) NOT NULL,
    ODAIMOKU                        VARCHAR2(40),
    SEIKYUSAKI_CD                   CHAR(6) NOT NULL,
    DEMPYO_SHUBETSU_CD              CHAR(2) NOT NULL,
    KAZEI_TAISHO_GAKU               NUMBER(10,0),
    SHOHIZEI_GAKU                   NUMBER(10,0),
    UCHI_ZEI_KINGAKU                NUMBER(10,0),
    HIKAZEI_MENZEI                  NUMBER(10,0),
    SEIKYU_KINGAKU                  NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_PROOF_CHECK_SONOTA_URIAGE
    ADD(CONSTRAINT PK_TR_PROOF_CHECK_SONOTA_URIAGE PRIMARY KEY (URIAGE_ID, URIAGE_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_PROOF_CHECK_LOGI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_PROOF_CHECK_LOGI
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(3,0) NOT NULL,
    MEISAI_ID                       NUMBER(3,0) NOT NULL,
    KOKYAKU_CD                      CHAR(6),
    SEIKYUSAKI_CD                   CHAR(6) NOT NULL,
    DATA_MOTO                       CHAR(2) NOT NULL,
    HENKO_SUMI_FLG                  CHAR(1) NOT NULL,
    KOSHINBI                        CHAR(8) NOT NULL,
    PROOF_STATUS                    CHAR(1) NOT NULL,
    CHECKBI                         CHAR(8) NOT NULL,
    SAGYOBI                         CHAR(8) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(5,0) NOT NULL,
    SAGYO_MEMO                      VARCHAR2(200),
    LOGI_MOTO_SURYO                 NUMBER(4,0),
    SURYO                           NUMBER(9,0),
    KAZEI_TAISHO_GAKU               NUMBER(10,0) NOT NULL,
    SHOHIZEI_GAKU                   NUMBER(10,0) NOT NULL,
    UCHI_ZEI_KINGAKU                NUMBER(10,0) NOT NULL,
    HIKAZEI_MENZEI                  NUMBER(10,0) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_PROOF_CHECK_LOGI
    ADD(CONSTRAINT PK_TR_PROOF_CHECK_LOGI PRIMARY KEY (URIAGE_ID, URIAGE_DATA_VERSION, MEISAI_ID) USING INDEX)
/
DROP TABLE TR_PROOF_CHECK_YUSO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_PROOF_CHECK_YUSO
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(18,0) NOT NULL,
    KOKYAKU_CD                      CHAR(6),
    STATUS                          CHAR(1) NOT NULL,
    KOSHINBI                        CHAR(8) NOT NULL,
    CHECKBI                         CHAR(8) NOT NULL,
    SHUKABI                         CHAR(8) NOT NULL,
    OKURIJO_NO                      CHAR(13),
    SHIHARAI_HOHO                   CHAR(2),
    SHUKA_SHIJI                     CHAR(1) NOT NULL,
    HAITATSU_SHIJI                  CHAR(1) NOT NULL,
    NIUKENIN_CD                     CHAR(6) NOT NULL,
    RITO_FLG                        CHAR(1) NOT NULL,
    KANNAIHAISO_FLG                 CHAR(1) NOT NULL,
    OROSHINE_KOSHIN_FLG             CHAR(1) NOT NULL,
    NIOKURININ_CD                   CHAR(6) NOT NULL,
    DATA_MOTO                       CHAR(2) NOT NULL,
    HENKO_SUMI_FLG                  CHAR(1) NOT NULL,
    SHUKA_EIGYOSHO_CD               VARCHAR2(5) NOT NULL,
    HAITATSU_EIGYOSHO_CD            VARCHAR2(5) NOT NULL,
    SEIKYUSAKI_CD                   CHAR(6) NOT NULL,
    DEMPYO_SHUBETSU_CD              CHAR(2) NOT NULL,
    YUSO_HOHO_CD                    CHAR(2) NOT NULL,
    TASHA_CHUKEI_FLG                CHAR(1) NOT NULL,
    KOSU                            NUMBER(4,0) NOT NULL,
    JURYO                           NUMBER(8,1),
    PACK_UNCHIN                     NUMBER(9,0),
    MEISAI_SONOTA                   NUMBER(9,0),
    SHUKA_RYO                       NUMBER(9,0),
    KAZEI_TAISHO_GAKU               NUMBER(9,0),
    KOKU_RYO                        NUMBER(9,0),
    SHOHIZEI_GAKU                   NUMBER(9,0),
    HAITATSU_RYO                    NUMBER(9,0),
    UCHI_ZEI_KINGAKU                NUMBER(9,0),
    SHUKA_CHOKUSO_CHARTER_RYO       NUMBER(9,0),
    HIKAZEI_MENZEI                  NUMBER(9,0),
    HAITATSU_CHARTER_RYO            NUMBER(9,0),
    GOKEI                           NUMBER(9,0),
    DAIBIKI_KINGAKU                 NUMBER(9,0),
    HORYU_HIZUKE                    DATE,
    DAISANSHA_HARAI_FLG             CHAR(1),
    HIKITORI_YUSO_FLG               CHAR(1),
    CHOKUSO_CHARTER_SHIYO_FLG       CHAR(1),
    SHUKA_CHARTER_SHIYO_FLG         CHAR(1),
    HAITATSU_CHARTER_SHIYO_FLG      CHAR(1),
    OROSHI_ICON_HYOJI_FLG           CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_PROOF_CHECK_YUSO
    ADD(CONSTRAINT PK_TR_PROOF_CHECK_YUSO PRIMARY KEY (URIAGE_ID, URIAGE_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_PROOF_YO_SHUYAKU_KOMOKU_CD CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_PROOF_YO_SHUYAKU_KOMOKU_CD
(
    PROOF_YO_SHUYAKU_KOMOKU_CD      CHAR(2) NOT NULL,
    PROOF_YO_SHUYAKU_KOMOKU_MEI     VARCHAR2(20) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_PROOF_YO_SHUYAKU_KOMOKU_CD
    ADD(CONSTRAINT PK_MS_PROOF_YO_SHUYAKU_KOMOKU_CD PRIMARY KEY (PROOF_YO_SHUYAKU_KOMOKU_CD) USING INDEX)
/
DROP TABLE MS_FLOOR CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_FLOOR
(
    SHISETSU_CD                     CHAR(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    FLOOR_CD                        VARCHAR2(6) NOT NULL,
    SHISETSU_DATA_VERSION           NUMBER(3,0) NOT NULL,
    FLOOR_MEI                       VARCHAR2(20) NOT NULL,
    JIMUSHO_TSUBOSU                 NUMBER(9,0),
    JIMUSHO_TSUBO_TANKA             NUMBER(10,0),
    SHISETSU_TSUBOSU                NUMBER(9,0),
    SHISETSU_TSUBO_TANKA            NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE,
    TEKIYO_FLG                      CHAR(1) NOT NULL
)
/
ALTER TABLE MS_FLOOR
    ADD(CONSTRAINT PK_MS_FLOOR PRIMARY KEY (SHISETSU_CD, TEKIYO_KAISHIBI, FLOOR_CD, TEKIYO_FLG) USING INDEX)
/
DROP TABLE MS_FLOOR_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_FLOOR_RIREKI
(
    SHISETSU_CD                     CHAR(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    FLOOR_CD                        VARCHAR2(6) NOT NULL,
    SHISETSU_DATA_VERSION           NUMBER(3,0) NOT NULL,
    FLOOR_MEI                       VARCHAR2(20) NOT NULL,
    JIMUSHO_TSUBOSU                 NUMBER(9,0),
    JIMUSHO_TSUBO_TANKA             NUMBER(10,0),
    SHISETSU_TSUBOSU                NUMBER(9,0),
    SHISETSU_TSUBO_TANKA            NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE,
    TEKIYO_FLG                      CHAR(1) NOT NULL
)
/
ALTER TABLE MS_FLOOR_RIREKI
    ADD(CONSTRAINT PK_MS_FLOOR_RIREKI PRIMARY KEY (SHISETSU_CD, TEKIYO_KAISHIBI, FLOOR_CD, SHISETSU_DATA_VERSION, TEKIYO_FLG) USING INDEX)
/
DROP TABLE TR_MANIFESTO_NO_KANRI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_MANIFESTO_NO_KANRI
(
    ITAKU_NENGAPPI                  CHAR(8) NOT NULL,
    ITAKU_JIKAN                     CHAR(6) NOT NULL,
    ITAKUSAKI_CD                    VARCHAR2(5) NOT NULL,
    OKURIJO_NO                      CHAR(13) NOT NULL,
    MANIFESTO_NO                    CHAR(10),
    MANIFESTO_HIKIWATASHIBI         CHAR(8),
    URIAGE_ID                       NUMBER(18,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE,
    AKA_KURO_KBN                    CHAR(1) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(3,0) NOT NULL
)
/
ALTER TABLE TR_MANIFESTO_NO_KANRI
    ADD(CONSTRAINT PK_TR_MANIFESTO_NO_KANRI PRIMARY KEY (ITAKU_NENGAPPI, ITAKU_JIKAN, ITAKUSAKI_CD, OKURIJO_NO) USING INDEX)
/
DROP TABLE TR_MAIL_ADDRESS_NG_KAISU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_MAIL_ADDRESS_NG_KAISU
(
    USER_CD                         CHAR(7) NOT NULL,
    FUITCHI_KAISU                   NUMBER(3,0),
    MAIL_SHINSEI_LOCK_FLG           CHAR(1) NOT NULL,
    MAIL_SHINSEI_LOCK_KIKAN         DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_MAIL_ADDRESS_NG_KAISU
    ADD(CONSTRAINT PK_TR_MAIL_ADDRESS_NG_KAISU PRIMARY KEY (USER_CD) USING INDEX)
/
DROP TABLE MS_MESSAGE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_MESSAGE
(
    MESSAGE_ID                      VARCHAR2(8) NOT NULL,
    MESSAGE_DATA_VERSION            NUMBER(3,0) NOT NULL,
    SOSHIN_MOTO_SYSTEM              VARCHAR2(3) NOT NULL,
    MESSAGE_MEI                     VARCHAR2(40),
    MESSAGE_SHUBETSU                CHAR(2),
    MESSAGE_YUKO_MUKO               CHAR(1),
    TSUCHI_AREA_HYOJI               CHAR(1),
    KINKYU_LEVEL                    CHAR(1),
    TSUCHI_AREA_LIMIT_KBN           CHAR(1),
    TSUCHI_AREA_LIMIT_DAY           VARCHAR2(2),
    TSUCHI_AREA_LIMIT_TIME          VARCHAR2(4),
    TSUCHI_AREA_PERIOD_KBN          CHAR(1),
    TSUCHI_AREA_PERIOD_TIME         VARCHAR2(2),
    SENNISAKI_GAMEN                 VARCHAR2(200),
    TAIO_DATA_KEY_NAME              CHAR(6),
    DEFAULT_TITLE                   VARCHAR2(40),
    DEFAULT_HOMBUN                  VARCHAR2(360),
    BIKO                            VARCHAR2(1000),
    TAIO_YOHI                       CHAR(1),
    T_TSUCHI_AREA_HYOJI             CHAR(1),
    T_KINKYU_LEVEL                  CHAR(1),
    T_TSUCHI_AREA_LIMIT_KBN         VARCHAR2(1),
    T_TSUCHI_AREA_LIMIT_DAY         VARCHAR2(2),
    T_TSUCHI_AREA_LIMIT_TIME        CHAR(4),
    T_TSUCHI_AREA_PERIOD_KBN        VARCHAR2(1),
    T_TSUCHI_AREA_PERIOD_TIME       VARCHAR2(2),
    T_DEFAULT_TITLE                 VARCHAR2(40) NOT NULL,
    T_DEFAULT_HOMBUN                VARCHAR2(360),
    SOSHINSAKI_KBN                  CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_MESSAGE
    ADD(CONSTRAINT PK_MS_MESSAGE PRIMARY KEY (MESSAGE_ID) USING INDEX)
/
DROP TABLE MS_MESSAGE_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_MESSAGE_RIREKI
(
    MESSAGE_ID                      VARCHAR2(8) NOT NULL,
    MESSAGE_DATA_VERSION            NUMBER(3,0) NOT NULL,
    SOSHIN_MOTO_SYSTEM              VARCHAR2(3) NOT NULL,
    MESSAGE_MEI                     VARCHAR2(40),
    MESSAGE_SHUBETSU                CHAR(2),
    MESSAGE_YUKO_MUKO               CHAR(1),
    TSUCHI_AREA_HYOJI               CHAR(1),
    KINKYU_LEVEL                    CHAR(1),
    TSUCHI_AREA_LIMIT_KBN           CHAR(1),
    TSUCHI_AREA_LIMIT_DAY           VARCHAR2(2),
    TSUCHI_AREA_LIMIT_TIME          VARCHAR2(4),
    TSUCHI_AREA_PERIOD_KBN          CHAR(1),
    TSUCHI_AREA_PERIOD_TIME         VARCHAR2(2),
    SENNISAKI_GAMEN                 VARCHAR2(200),
    TAIO_DATA_KEY_NAME              CHAR(6),
    DEFAULT_TITLE                   VARCHAR2(40),
    DEFAULT_HOMBUN                  VARCHAR2(360),
    BIKO                            VARCHAR2(1000),
    TAIO_YOHI                       CHAR(1),
    T_TSUCHI_AREA_HYOJI             CHAR(1),
    T_KINKYU_LEVEL                  CHAR(1),
    T_TSUCHI_AREA_LIMIT_KBN         VARCHAR2(1),
    T_TSUCHI_AREA_LIMIT_DAY         VARCHAR2(2),
    T_TSUCHI_AREA_LIMIT_TIME        CHAR(4),
    T_TSUCHI_AREA_PERIOD_KBN        VARCHAR2(1),
    T_TSUCHI_AREA_PERIOD_TIME       VARCHAR2(2),
    T_DEFAULT_TITLE                 VARCHAR2(40) NOT NULL,
    T_DEFAULT_HOMBUN                VARCHAR2(360),
    SOSHINSAKI_KBN                  CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_MESSAGE_RIREKI
    ADD(CONSTRAINT PK_MS_MESSAGE_RIREKI PRIMARY KEY (MESSAGE_ID, MESSAGE_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_MESSAGE_SOSHINJOGAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_MESSAGE_SOSHINJOGAI
(
    MESSAGE_ID                      VARCHAR2(8) NOT NULL,
    MESSAGE_SOSHIN_JOGAI_SEQ        NUMBER(5,0) NOT NULL,
    MESSAGE_DATA_VERSION            NUMBER(3,0) NOT NULL,
    EIGYOSHO_CD                     CHAR(3),
    USER_CD                         CHAR(7),
    ROLE_CD                         VARCHAR2(20),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_MESSAGE_SOSHINJOGAI
    ADD(CONSTRAINT PK_MS_MESSAGE_SOSHINJOGAI PRIMARY KEY (MESSAGE_ID, MESSAGE_SOSHIN_JOGAI_SEQ) USING INDEX)
/
DROP TABLE MS_MESSAGE_SOSHINJOGAI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_MESSAGE_SOSHINJOGAI_RIREKI
(
    MESSAGE_ID                      VARCHAR2(8) NOT NULL,
    MESSAGE_SOSHIN_JOGAI_SEQ        NUMBER(5,0) NOT NULL,
    MESSAGE_DATA_VERSION            NUMBER(3,0) NOT NULL,
    EIGYOSHO_CD                     CHAR(3),
    USER_CD                         CHAR(7),
    ROLE_CD                         VARCHAR2(20),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_MESSAGE_SOSHINJOGAI_RIREKI
    ADD(CONSTRAINT PK_MS_MESSAGE_SOSHINJOGAI_RIREKI PRIMARY KEY (MESSAGE_ID, MESSAGE_SOSHIN_JOGAI_SEQ, MESSAGE_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_MESSAGE_SOSHINSAKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_MESSAGE_SOSHINSAKI
(
    MESSAGE_ID                      VARCHAR2(8) NOT NULL,
    MESSAGE_SOSHIN_SAKI_SEQ         NUMBER(5,0) NOT NULL,
    MESSAGE_DATA_VERSION            NUMBER(3,0) NOT NULL,
    EIGYOSHO_CD                     CHAR(3),
    USER_CD                         CHAR(7),
    ROLE_CD                         VARCHAR2(20),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_MESSAGE_SOSHINSAKI
    ADD(CONSTRAINT PK_MS_MESSAGE_SOSHINSAKI PRIMARY KEY (MESSAGE_ID, MESSAGE_SOSHIN_SAKI_SEQ) USING INDEX)
/
DROP TABLE MS_MESSAGE_SOSHINSAKI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_MESSAGE_SOSHINSAKI_RIREKI
(
    MESSAGE_ID                      VARCHAR2(8) NOT NULL,
    MESSAGE_SOSHIN_SAKI_SEQ         NUMBER(5,0) NOT NULL,
    MESSAGE_DATA_VERSION            NUMBER(3,0) NOT NULL,
    EIGYOSHO_CD                     CHAR(3),
    USER_CD                         CHAR(7),
    ROLE_CD                         VARCHAR2(20),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_MESSAGE_SOSHINSAKI_RIREKI
    ADD(CONSTRAINT PK_MS_MESSAGE_SOSHINSAKI_RIREKI PRIMARY KEY (MESSAGE_ID, MESSAGE_SOSHIN_SAKI_SEQ, MESSAGE_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_MESSAGE_HAISHIN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_MESSAGE_HAISHIN
(
    USER_CD                         CHAR(7) NOT NULL,
    HAISHIN_NICHIJI                 DATE NOT NULL,
    HAISHIN_REMBAN                  NUMBER(9,0) NOT NULL,
    MESSAGE_ID                      VARCHAR2(8),
    KIDOKU_NICHIJI                  DATE,
    HAISHIN_SHURYO_NICHIJI          DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_MESSAGE_HAISHIN
    ADD(CONSTRAINT PK_TR_MESSAGE_HAISHIN PRIMARY KEY (USER_CD, HAISHIN_NICHIJI, HAISHIN_REMBAN) USING INDEX)
/
DROP TABLE MS_MENU_GROUP CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_MENU_GROUP
(
    MENU_GROUP_ID                   VARCHAR2(20) NOT NULL,
    MENU_GROUP_MEI                  VARCHAR2(40),
    ICON_GAZO_PATH                  VARCHAR2(512),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_MENU_GROUP
    ADD(CONSTRAINT PK_MS_MENU_GROUP PRIMARY KEY (MENU_GROUP_ID) USING INDEX)
/
DROP TABLE MS_MENU_GROUP_HYOJI_JUN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_MENU_GROUP_HYOJI_JUN
(
    MENU_PATTERN_ID                 CHAR(6) NOT NULL,
    MENU_GROUP_ID                   VARCHAR2(20) NOT NULL,
    HYOJI_JUN                       NUMBER(3,0),
    SAKUJO_FLG                      CHAR(1),
    TOROKU_USER                     VARCHAR2(8),
    TOROKU_NICHIJI                  DATE,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0),
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_MENU_GROUP_HYOJI_JUN
    ADD(CONSTRAINT PK_MS_MENU_GROUP_HYOJI_JUN PRIMARY KEY (MENU_PATTERN_ID, MENU_GROUP_ID) USING INDEX)
/
DROP TABLE MS_MENU_PATTERN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_MENU_PATTERN
(
    MENU_PATTERN_ID                 CHAR(6) NOT NULL,
    MENU_PATTERN_MEI                VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1),
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHJI                   DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_MENU_PATTERN
    ADD(CONSTRAINT PK_MS_MENU_PATTERN PRIMARY KEY (MENU_PATTERN_ID) USING INDEX)
/
DROP TABLE MS_MENU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_MENU
(
    MENU_ID                         CHAR(6) NOT NULL,
    MENU_MEI                        VARCHAR2(40) NOT NULL,
    KINO_CD                         VARCHAR2(20),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_MENU
    ADD(CONSTRAINT PK_MS_MENU PRIMARY KEY (MENU_ID) USING INDEX)
/
DROP TABLE MS_MENU_HYOJI_JUN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_MENU_HYOJI_JUN
(
    SUB_MENU_GROUP_ID               VARCHAR2(20) NOT NULL,
    HYOJI_JUN                       NUMBER(3,0),
    SAKUJO_FLG                      CHAR(1),
    TOROKU_USER                     VARCHAR2(8),
    TOROKU_NICHIJI                  DATE,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0),
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE,
    MENU_ID                         CHAR(6) NOT NULL,
    MENU_PATTERN_ID                 CHAR(6) NOT NULL
)
/
ALTER TABLE MS_MENU_HYOJI_JUN
    ADD(CONSTRAINT PK_MS_MENU_HYOJI_JUN PRIMARY KEY (MENU_ID, MENU_PATTERN_ID) USING INDEX)
/
DROP TABLE MS_USER_KINO_GROUP_PATTERN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_USER_KINO_GROUP_PATTERN
(
    USER_CD                         CHAR(7) NOT NULL,
    KINO_GROUP_PATTERN_CD           VARCHAR2(20) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_USER_KINO_GROUP_PATTERN
    ADD(CONSTRAINT PK_MS_USER_KINO_GROUP_PATTERN PRIMARY KEY (USER_CD, KINO_GROUP_PATTERN_CD) USING INDEX)
/
DROP TABLE MS_USER_ACCESS_KANO_SOSHIKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_USER_ACCESS_KANO_SOSHIKI
(
    USER_CD                         CHAR(7) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    ACCESS_KANO_SOSHIKI_CD          VARCHAR2(3) NOT NULL,
    USER_DATA_VERSION               NUMBER(3,0) NOT NULL,
    READER_FLG                      CHAR(1) NOT NULL,
    DEFAULT_SHOZOKU_FLG             CHAR(1) NOT NULL,
    SHOZOKU_KAISHIBI                DATE NOT NULL,
    SHOZOKU_SHURYOBI                DATE,
    BIKO                            VARCHAR2(80),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_USER_ACCESS_KANO_SOSHIKI
    ADD(CONSTRAINT PK_MS_USER_ACCESS_KANO_SOSHIKI PRIMARY KEY (USER_CD, TEKIYO_KAISHIBI, TEKIYO_FLG, ACCESS_KANO_SOSHIKI_CD, SHOZOKU_KAISHIBI) USING INDEX)
/
DROP TABLE MS_USER_ACCESS_KANO_SOSHIKI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_USER_ACCESS_KANO_SOSHIKI_RIREKI
(
    USER_CD                         CHAR(7) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    ACCESS_KANO_SOSHIKI_CD          VARCHAR2(3) NOT NULL,
    USER_DATA_VERSION               NUMBER(3,0) NOT NULL,
    READER_FLG                      CHAR(1) NOT NULL,
    DEFAULT_SHOZOKU_FLG             CHAR(1) NOT NULL,
    SHOZOKU_KAISHIBI                DATE NOT NULL,
    SHOZOKU_SHURYOBI                DATE,
    BIKO                            VARCHAR2(80),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE,
    TEKIYO_FLG                      CHAR(1) NOT NULL
)
/
ALTER TABLE MS_USER_ACCESS_KANO_SOSHIKI_RIREKI
    ADD(CONSTRAINT PK_MS_USER_ACCESS_KANO_SOSHIKI_RIREKI PRIMARY KEY (USER_CD, TEKIYO_KAISHIBI, ACCESS_KANO_SOSHIKI_CD, USER_DATA_VERSION, SHOZOKU_KAISHIBI, TEKIYO_FLG) USING INDEX)
/
DROP TABLE MS_USER CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_USER
(
    USER_CD                         CHAR(7) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    TEKIYO_MEI                      VARCHAR2(40) NOT NULL,
    USER_DATA_VERSION               NUMBER(3,0) NOT NULL,
    USER_MEI                        VARCHAR2(80) NOT NULL,
    USER_KANA_MEI                   VARCHAR2(160),
    USER_MEI_EIJI                   VARCHAR2(80),
    MAIL_ADDRESS                    VARCHAR2(80),
    EIGYOSHO_USER_FLG               CHAR(1) NOT NULL,
    DRIVER_FLG                      CHAR(1) NOT NULL,
    SHOZOKU_KASHO_CD                VARCHAR2(5) NOT NULL,
    BIKO_1                          VARCHAR2(40),
    BIKO_2                          VARCHAR2(40),
    BIKO_3                          VARCHAR2(40),
    BIKO_4                          VARCHAR2(40),
    SHINSEI_STATUS                  CHAR(2) NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_USER
    ADD(CONSTRAINT PK_MS_USER PRIMARY KEY (USER_CD, TEKIYO_KAISHIBI, TEKIYO_FLG) USING INDEX)
/
DROP TABLE MS_USER_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_USER_RIREKI
(
    USER_CD                         CHAR(7) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    TEKIYO_MEI                      VARCHAR2(40) NOT NULL,
    USER_DATA_VERSION               NUMBER(3,0) NOT NULL,
    USER_MEI                        VARCHAR2(80) NOT NULL,
    USER_KANA_MEI                   VARCHAR2(160),
    USER_MEI_EIJI                   VARCHAR2(80),
    MAIL_ADDRESS                    VARCHAR2(80),
    EIGYOSHO_USER_FLG               CHAR(1) NOT NULL,
    DRIVER_FLG                      CHAR(1) NOT NULL,
    SHOZOKU_KASHO_CD                VARCHAR2(5) NOT NULL,
    BIKO_1                          VARCHAR2(40),
    BIKO_2                          VARCHAR2(40),
    BIKO_3                          VARCHAR2(40),
    BIKO_4                          VARCHAR2(40),
    SHINSEI_STATUS                  CHAR(2) NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_USER_RIREKI
    ADD(CONSTRAINT PK_MS_USER_RIREKI PRIMARY KEY (USER_CD, TEKIYO_KAISHIBI, TEKIYO_FLG, USER_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_USER_ROLE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_USER_ROLE
(
    USER_CD                         CHAR(7) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    USER_DATA_VERSION               NUMBER(3,0) NOT NULL,
    ROLE_CD                         VARCHAR2(20) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE,
    TEKIYO_FLG                      CHAR(1) NOT NULL
)
/
ALTER TABLE MS_USER_ROLE
    ADD(CONSTRAINT PK_MS_USER_ROLE PRIMARY KEY (USER_CD, TEKIYO_KAISHIBI, TEKIYO_FLG) USING INDEX)
/
DROP TABLE MS_USER_ROLE_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_USER_ROLE_RIREKI
(
    USER_CD                         CHAR(7) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    USER_DATA_VERSION               NUMBER(3,0) NOT NULL,
    ROLE_CD                         VARCHAR2(20) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE,
    TEKIYO_FLG                      CHAR(1) NOT NULL
)
/
ALTER TABLE MS_USER_ROLE_RIREKI
    ADD(CONSTRAINT PK_MS_USER_ROLE_RIREKI PRIMARY KEY (USER_CD, TEKIYO_KAISHIBI, USER_DATA_VERSION, TEKIYO_FLG) USING INDEX)
/
DROP TABLE TR_USER_SETTEI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_USER_SETTEI
(
    USER_CD                         CHAR(7) NOT NULL,
    MENU_PATTERN_ID                 CHAR(6) NOT NULL,
    THEME_CD                        VARCHAR2(30) NOT NULL,
    TOOLTIP_HYOJI_FLG               CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_USER_SETTEI
    ADD(CONSTRAINT PK_TR_USER_SETTEI PRIMARY KEY (USER_CD) USING INDEX)
/
DROP TABLE TR_UNIT_JOHO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_UNIT_JOHO
(
    OKURIJO_NO                      CHAR(13) NOT NULL,
    EDABAN                          VARCHAR2(3) NOT NULL,
    HOKOKU_TEN                      VARCHAR2(5) NOT NULL,
    SCAN_HIZUKE                     CHAR(8) NOT NULL,
    SCAN_JIKAN                      CHAR(6),
    HHT_BANGO                       CHAR(15),
    JUGYOIN_BANGO                   CHAR(7),
    SHABAN                          CHAR(5),
    UNIT_NO                         VARCHAR2(20) NOT NULL,
    OKURIJO_NO_NYURYOKU_MOTO_FLG    CHAR(1),
    DATA_MOTO                       CHAR(2),
    HASSEI_NICHIJI                  DATE,
    URIAGE_ID                       NUMBER(18,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_UNIT_JOHO
    ADD(CONSTRAINT PK_TR_UNIT_JOHO PRIMARY KEY (OKURIJO_NO, EDABAN, HOKOKU_TEN, SCAN_HIZUKE) USING INDEX)
/
DROP TABLE MS_READ_TIME CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_READ_TIME
(
    YUBIN_BANGO                     CHAR(7) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TANTO_EIGYOSHO_CD               CHAR(3),
    YUSO_HOHO_CD                    CHAR(2),
    GOSHA_CD                        VARCHAR2(5),
    YOKUCHAKU_YOTEIBI_KBN           CHAR(1),
    TOCHAKU_JIKANTAI_KBN            CHAR(1),
    TOCHAKU_JIKANTAI_SHITEI_FROM    VARCHAR2(2),
    TOCHAKU_JIKANTAI_SHITEI_TO      VARCHAR2(2),
    YOKUCHAKU_KAHI                  CHAR(1),
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_READ_TIME
    ADD(CONSTRAINT PK_MS_READ_TIME PRIMARY KEY (YUBIN_BANGO, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE MS_ROUTE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_ROUTE
(
    FROM_KYOTEN_CD                  VARCHAR2(5) NOT NULL,
    TO_KYOTEN_CD                    VARCHAR2(5) NOT NULL,
    ROUTE_EDABAN                    VARCHAR2(2) NOT NULL,
    ROUTE_DATA_VERSION              NUMBER(3,0) NOT NULL,
    ROUTE_MEI                       VARCHAR2(40) NOT NULL,
    KEIYUCHI_KYOTEN_CD_1            VARCHAR2(3),
    KEIYUCHI_KYOTEN_CD_2            VARCHAR2(3),
    KEIYUCHI_KYOTEN_CD_3            VARCHAR2(3),
    YUSEN_JUNI                      NUMBER(2,0) NOT NULL,
    BIKO                            VARCHAR2(400),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_ROUTE
    ADD(CONSTRAINT PK_MS_ROUTE PRIMARY KEY (FROM_KYOTEN_CD, TO_KYOTEN_CD, ROUTE_EDABAN) USING INDEX)
/
DROP TABLE MS_ROUTE_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_ROUTE_RIREKI
(
    FROM_KYOTEN_CD                  VARCHAR2(5) NOT NULL,
    TO_KYOTEN_CD                    VARCHAR2(5) NOT NULL,
    ROUTE_EDABAN                    VARCHAR2(2) NOT NULL,
    ROUTE_DATA_VERSION              NUMBER(3,0) NOT NULL,
    ROUTE_MEI                       VARCHAR2(40) NOT NULL,
    KEIYUCHI_KYOTEN_CD_1            VARCHAR2(3),
    KEIYUCHI_KYOTEN_CD_2            VARCHAR2(3),
    KEIYUCHI_KYOTEN_CD_3            VARCHAR2(3),
    YUSEN_JUNI                      NUMBER(2,0) NOT NULL,
    BIKO                            VARCHAR2(400),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_ROUTE_RIREKI
    ADD(CONSTRAINT PK_MS_ROUTE_RIREKI PRIMARY KEY (FROM_KYOTEN_CD, TO_KYOTEN_CD, ROUTE_EDABAN, ROUTE_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_ROLE_KINO_GROUP_PATTERN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_ROLE_KINO_GROUP_PATTERN
(
    ROLE_CD                         VARCHAR2(20) NOT NULL,
    KINO_GROUP_PATTERN_CD           VARCHAR2(20) NOT NULL,
    ROLE_KINO_GROUP_DATA_VERSION    NUMBER(3,0) NOT NULL,
    BIKO_1                          VARCHAR2(2),
    BIKO_2                          VARCHAR2(2),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_ROLE_KINO_GROUP_PATTERN
    ADD(CONSTRAINT PK_MS_ROLE_KINO_GROUP_PATTERN PRIMARY KEY (ROLE_CD, KINO_GROUP_PATTERN_CD) USING INDEX)
/
DROP TABLE MS_ROLE_KINO_GROUP_PATTERN_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_ROLE_KINO_GROUP_PATTERN_RIREKI
(
    ROLE_CD                         VARCHAR2(20) NOT NULL,
    KINO_GROUP_PATTERN_CD           VARCHAR2(20) NOT NULL,
    ROLE_KINO_GROUP_DATA_VERSION    NUMBER(3,0) NOT NULL,
    BIKO_1                          VARCHAR2(2),
    BIKO_2                          VARCHAR2(2),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_ROLE_KINO_GROUP_PATTERN_RIREKI
    ADD(CONSTRAINT PK_MS_ROLE_KINO_GROUP_PATTERN_RIREKI PRIMARY KEY (ROLE_CD, KINO_GROUP_PATTERN_CD, ROLE_KINO_GROUP_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_ROLE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_ROLE
(
    ROLE_CD                         VARCHAR2(20) NOT NULL,
    ROLE_MEI                        VARCHAR2(40) NOT NULL,
    MAIN_ROLE_FLG                   CHAR(1) NOT NULL,
    HYOJI_SEIGEN_FLG                CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_ROLE
    ADD(CONSTRAINT PK_MS_ROLE PRIMARY KEY (ROLE_CD) USING INDEX)
/
DROP TABLE MS_LOCATION CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_LOCATION
(
    SHISETSU_CD                     CHAR(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    FLOOR_CD                        VARCHAR2(6) NOT NULL,
    HOKAN_SHUBETSU_CD               VARCHAR2(6) NOT NULL,
    SHISETSU_DATA_VERSION           NUMBER(3,0) NOT NULL,
    HOKAN_SHUBETSU_MEI              VARCHAR2(40) NOT NULL,
    TSUBOSU                         NUMBER(9,0),
    OROSHINE                        NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE,
    TEKIYO_FLG                      CHAR(1) NOT NULL
)
/
ALTER TABLE MS_LOCATION
    ADD(CONSTRAINT IX_MS_LOCATION UNIQUE (SHISETSU_CD, FLOOR_CD, HOKAN_SHUBETSU_CD) USING INDEX)
/
ALTER TABLE MS_LOCATION
    ADD(CONSTRAINT PK_MS_LOCATION PRIMARY KEY (SHISETSU_CD, TEKIYO_KAISHIBI, FLOOR_CD, HOKAN_SHUBETSU_CD, TEKIYO_FLG) USING INDEX)
/
DROP TABLE MS_LOCATION_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_LOCATION_RIREKI
(
    SHISETSU_CD                     CHAR(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    FLOOR_CD                        VARCHAR2(6) NOT NULL,
    HOKAN_SHUBETSU_CD               VARCHAR2(6) NOT NULL,
    SHISETSU_DATA_VERSION           NUMBER(3,0) NOT NULL,
    HOKAN_SHUBETSU_MEI              VARCHAR2(40) NOT NULL,
    TSUBOSU                         NUMBER(9,0),
    OROSHINE                        NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE,
    TEKIYO_FLG                      CHAR(1) NOT NULL
)
/
ALTER TABLE MS_LOCATION_RIREKI
    ADD(CONSTRAINT IX_MS_LOCATION_RIREKI UNIQUE (SHISETSU_CD, FLOOR_CD, HOKAN_SHUBETSU_CD) USING INDEX)
/
ALTER TABLE MS_LOCATION_RIREKI
    ADD(CONSTRAINT PK_MS_LOCATION_RIREKI PRIMARY KEY (SHISETSU_CD, TEKIYO_KAISHIBI, FLOOR_CD, HOKAN_SHUBETSU_CD, SHISETSU_DATA_VERSION, TEKIYO_FLG) USING INDEX)
/
DROP TABLE TR_LOGI_MOTO_DATA CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_LOGI_MOTO_DATA
(
    LOGI_MOTO_FILE_ID               NUMBER(9,0) NOT NULL,
    FILE_MEI                        VARCHAR2(512) NOT NULL,
    HOZON_SAKI_URL                  VARCHAR2(100) NOT NULL,
    TORIKOMIBI                      CHAR(8) NOT NULL,
    TORIKOMI_JIKOKU                 CHAR(8),
    KOKYAKU_CD                      CHAR(6),
    SHISETSU_CD                     CHAR(5) NOT NULL,
    MEMO                            VARCHAR2(200),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_LOGI_MOTO_DATA
    ADD(CONSTRAINT PK_TR_LOGI_MOTO_DATA PRIMARY KEY (LOGI_MOTO_FILE_ID) USING INDEX)
/
DROP TABLE TR_LOGI_MOTO_DATA_MEISAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_LOGI_MOTO_DATA_MEISAI
(
    LOGI_MOTO_FILE_ID               NUMBER(9,0) NOT NULL,
    LOGI_MOTO_MEISAI_NO             NUMBER(5,0) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(5,0) NOT NULL,
    SAGYOBI                         CHAR(6) NOT NULL,
    SURYO                           NUMBER(9,0) NOT NULL,
    KINGAKU                         NUMBER(10,0),
    MEISAI_ID                       NUMBER(3,0) NOT NULL,
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    BIKO_1                          VARCHAR2(200),
    BIKO_2                          VARCHAR2(200),
    BIKO_3                          VARCHAR2(200),
    BIKO_4                          VARCHAR2(200),
    BIKO_5                          VARCHAR2(200),
    BIKO_6                          VARCHAR2(200),
    BIKO_7                          VARCHAR2(200),
    BIKO_8                          VARCHAR2(200),
    BIKO_9                          VARCHAR2(200),
    BIKO_10                         VARCHAR2(200),
    BIKO_11                         VARCHAR2(200),
    BIKO_12                         VARCHAR2(200),
    BIKO_13                         VARCHAR2(200),
    BIKO_14                         VARCHAR2(200),
    BIKO_15                         VARCHAR2(200),
    BIKO_16                         VARCHAR2(200),
    BIKO_17                         VARCHAR2(200),
    BIKO_18                         VARCHAR2(200),
    BIKO_19                         VARCHAR2(200),
    BIKO_20                         VARCHAR2(200),
    BIKO_21                         VARCHAR2(200),
    BIKO_22                         VARCHAR2(200),
    BIKO_23                         VARCHAR2(200),
    BIKO_24                         VARCHAR2(200),
    BIKO_25                         VARCHAR2(200),
    BIKO_26                         VARCHAR2(200),
    BIKO_27                         VARCHAR2(200),
    BIKO_28                         VARCHAR2(200),
    BIKO_29                         VARCHAR2(200),
    BIKO_30                         VARCHAR2(200),
    BIKO_31                         VARCHAR2(200),
    BIKO_32                         VARCHAR2(200),
    BIKO_33                         VARCHAR2(200),
    BIKO_34                         VARCHAR2(200),
    BIKO_35                         VARCHAR2(200),
    BIKO_36                         VARCHAR2(200),
    BIKO_37                         VARCHAR2(200),
    BIKO_38                         VARCHAR2(200),
    BIKO_39                         VARCHAR2(200),
    BIKO_40                         VARCHAR2(200),
    BIKO_41                         VARCHAR2(200),
    BIKO_42                         VARCHAR2(200),
    BIKO_43                         VARCHAR2(200),
    BIKO_44                         VARCHAR2(200),
    BIKO_45                         VARCHAR2(200),
    BIKO_46                         VARCHAR2(200),
    BIKO_47                         VARCHAR2(200),
    BIKO_48                         VARCHAR2(200),
    BIKO_49                         VARCHAR2(200),
    BIKO_50                         VARCHAR2(200),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_LOGI_MOTO_DATA_MEISAI
    ADD(CONSTRAINT PK_TR_LOGI_MOTO_DATA_MEISAI PRIMARY KEY (LOGI_MOTO_MEISAI_NO, LOGI_MOTO_FILE_ID) USING INDEX)
/
DROP TABLE TR_LOGI_MOTO_BIKO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_LOGI_MOTO_BIKO
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    BIKO_NO                         NUMBER(2,0) NOT NULL,
    BIKO_MEI                        VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE,
    LOGI_RYOKINHYO_DATA_VERSION     NUMBER(3,0) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(5,0) NOT NULL,
    TEKIYO_FLG                      CHAR(1) DEFAULT 0 NOT NULL
)
/
ALTER TABLE TR_LOGI_MOTO_BIKO
    ADD(CONSTRAINT PK_TR_LOGI_MOTO_BIKO PRIMARY KEY (KOKYAKU_CD, TEKIYO_KAISHIBI, BIKO_NO, MEISAI_GYO_NO, TEKIYO_FLG) USING INDEX)
/
DROP TABLE TR_LOGI_MOTO_BIKO_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_LOGI_MOTO_BIKO_RIREKI
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    BIKO_NO                         NUMBER(2,0) NOT NULL,
    BIKO_MEI                        VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE,
    LOGI_RYOKINHYO_DATA_VERSION     NUMBER(3,0) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(5,0) NOT NULL,
    TEKIYO_FLG                      CHAR(1) DEFAULT 0 NOT NULL
)
/
ALTER TABLE TR_LOGI_MOTO_BIKO_RIREKI
    ADD(CONSTRAINT PK_TR_LOGI_MOTO_BIKO_RIREKI PRIMARY KEY (KOKYAKU_CD, TEKIYO_KAISHIBI, BIKO_NO, LOGI_RYOKINHYO_DATA_VERSION, MEISAI_GYO_NO, TEKIYO_FLG) USING INDEX)
/
DROP TABLE TR_LOGI_URIAGE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_LOGI_URIAGE
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(18,0) NOT NULL,
    AKA_KURO_KBN                    CHAR(1) NOT NULL,
    SAISIN_URIAGE_FLG               CHAR(1),
    KOKYAKU_CD                      CHAR(6),
    SEIKYUSAKI_CD                   CHAR(6),
    KEIYAKUSAKI_CD                  CHAR(6),
    HANBAI_EIGYOSHO                 VARCHAR2(5),
    SEIKYU_EIGYOSHO                 VARCHAR2(5),
    MEISAI_GYO_NO                   NUMBER(5,0) NOT NULL,
    SEIKYU_KOMOKU1                  VARCHAR2(50),
    SEIKYU_KOMOKU2                  VARCHAR2(50),
    SEIKYU_KOMOKU3                  VARCHAR2(50),
    SURYO                           NUMBER(9,0),
    KINGAKU                         NUMBER(10,0),
    NEBIKI_KINGAKU                  NUMBER(10,0),
    KAZEI_TAISHO_KINGAKU            NUMBER(10,0),
    SHOHIZEI_KINGAKU                NUMBER(10,0) NOT NULL,
    UCHIZEI_KINGAKU                 NUMBER(10,0),
    HIKAZEI_KINGAKU                 NUMBER(10,0),
    SEIKYU_KINGAKU                  NUMBER(10,0) NOT NULL,
    OROSHINE                        NUMBER(10,0),
    ARARI                           NUMBER(10,0),
    SAIDAICHI_FLG                   CHAR(1) NOT NULL,
    SAISHOCHI_FLG                   CHAR(1) NOT NULL,
    SEIKYUSHO_BIKO                  VARCHAR2(100),
    SPOT_TSUIKA_FLG                 CHAR(1) NOT NULL,
    SHIME_TAISHO_KBN                CHAR(1) NOT NULL,
    SHIME_JOKYO_KBN                 CHAR(1) NOT NULL,
    SHIMEBI                         CHAR(8) NOT NULL,
    AKA_KURO_FLG                    CHAR(1) NOT NULL,
    AKA_KURO_SHIMEBI                DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_LOGI_URIAGE
    ADD(CONSTRAINT PK_TR_LOGI_URIAGE PRIMARY KEY (URIAGE_ID, URIAGE_DATA_VERSION, AKA_KURO_KBN) USING INDEX)
/
DROP TABLE TR_LOGI_URIAGE_MEISAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_LOGI_URIAGE_MEISAI
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    MEISAI_ID                       NUMBER(3,0) NOT NULL,
    SHINSEI_STATUS                  CHAR(2) NOT NULL,
    ORIGINAL_KEIRI_KEIJO_HI         CHAR(8),
    URIAGE_DATA_VERSION             NUMBER(3,0) NOT NULL,
    SAGYOBI                         CHAR(8) NOT NULL,
    SHURYOBI                        CHAR(8),
    DATA_MOTO                       CHAR(2) NOT NULL,
    SAGYOSHA                        VARCHAR2(50) NOT NULL,
    SAGYO_SHOSAI                    VARCHAR2(100),
    LOGI_MOTO_SURYO                 NUMBER(4,0),
    LOGI_MOTO_KINGAKU               NUMBER(10,0) NOT NULL,
    SURYO                           NUMBER(9,0),
    KINGAKU                         NUMBER(10,0),
    NEBIKI_GAKU                     NUMBER(10,0),
    KAZEI_TAISHO_KINGAKU            NUMBER(10,0),
    SHOHIZEI_KINGAKU                NUMBER(10,0),
    UCHIZEI_KINGAKU                 NUMBER(10,0),
    HIKAZEI_KINGAKU                 NUMBER(10,0),
    SEIKYU_KINGAKU                  NUMBER(10,0) NOT NULL,
    OROSHINE                        NUMBER(10,0),
    ARARI                           NUMBER(10,0),
    SAGYO_MEMO                      VARCHAR2(200),
    BIKO_1                          VARCHAR2(200),
    BIKO_2                          VARCHAR2(200),
    IF_RENKEI_JOKYO_FLG             CHAR(1) NOT NULL,
    IF_RENKEI_TAISHO_FLG            CHAR(1) NOT NULL,
    KEIRI_KEIJOBI                   CHAR(8),
    HENKO_FLG                       CHAR(1) NOT NULL,
    YOKUGETSU_AKA_KURO_FLG          CHAR(1) NOT NULL,
    AKA_KURO_SHIMEBI                DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_LOGI_URIAGE_MEISAI
    ADD(CONSTRAINT IX_TR_LOGI_URIAGE_MEISAI UNIQUE (MEISAI_ID) USING INDEX)
/
ALTER TABLE TR_LOGI_URIAGE_MEISAI
    ADD(CONSTRAINT PK_TR_LOGI_URIAGE_MEISAI PRIMARY KEY (URIAGE_ID, MEISAI_ID, SHINSEI_STATUS) USING INDEX)
/
DROP TABLE TR_LOGI_URIAGE_MEISAI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_LOGI_URIAGE_MEISAI_RIREKI
(
    MEISAI_ID                       NUMBER(3,0) NOT NULL,
    SHINSEI_STATUS                  CHAR(2) NOT NULL,
    ORIGINAL_KEIRI_KEIJO_HI         CHAR(8),
    SAGYOBI                         CHAR(8) NOT NULL,
    SHURYOBI                        CHAR(8),
    DATA_MOTO                       CHAR(2) NOT NULL,
    SAGYOSHA                        VARCHAR2(50) NOT NULL,
    SAGYO_SHOSAI                    VARCHAR2(100),
    LOGI_MOTO_SURYO                 NUMBER(4,0),
    LOGI_MOTO_KINGAKU               NUMBER(10,0),
    SURYO                           NUMBER(9,0),
    KINGAKU                         NUMBER(10,0),
    NEBIKI_KINGAKU                  NUMBER(10,0),
    KAZEI_TAISHO_KINGAKU            NUMBER(10,0),
    SHOHIZEI_KINGAKU                NUMBER(10,0),
    UCHIZEI_KINGAKU                 NUMBER(10,0),
    HIKAZEI_KINGAKU                 NUMBER(10,0),
    SEIKYU_KINGAKU                  NUMBER(10,0),
    OROSHINE                        NUMBER(10,0),
    ARARI                           NUMBER(10,0),
    SAGYO_MEMO                      VARCHAR2(200),
    BIKO_1                          VARCHAR2(200),
    BIKO_2                          VARCHAR2(200),
    KEIRI_KEIJOBI                   CHAR(8),
    IF_RENKEI_JOKYO_FLG             CHAR(1) NOT NULL,
    IF_RENKEI_TAISHO_FLG            CHAR(1) NOT NULL,
    HENKO_FLG                       CHAR(1) NOT NULL,
    AKA_KURO_FLG                    CHAR(1) NOT NULL,
    AKA_KURO_SHIMEBI                DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_LOGI_URIAGE_MEISAI_RIREKI
    ADD(CONSTRAINT PK_TR_LOGI_URIAGE_MEISAI_RIREKI PRIMARY KEY (MEISAI_ID, SHINSEI_STATUS) USING INDEX)
/
DROP TABLE TR_LOGI_URIAGE_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_LOGI_URIAGE_RIREKI
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(18,0) NOT NULL,
    KOKYAKU_CD                      CHAR(6),
    SEIKYUSAKI_CD                   CHAR(6),
    KEIYAKUSAKI_CD                  CHAR(6),
    HANBAI_EIGYOSHO                 VARCHAR2(5),
    SEIKYU_EIGYOSHO                 VARCHAR2(5),
    MEISAI_GYO_NO                   NUMBER(5,0) NOT NULL,
    SEIKYU_KOMOKU1                  VARCHAR2(50),
    SEIKYU_KOMOKU2                  VARCHAR2(50),
    SEIKYU_KOMOKU3                  VARCHAR2(50),
    SURYO                           NUMBER(9,0),
    KINGAKU                         NUMBER(10,0),
    NEBIKI_KINGAKU                  NUMBER(10,0),
    KAZEI_TAISHO_KINGAKU            NUMBER(10,0),
    SHOHIZEI_KINGAKU                NUMBER(10,0) NOT NULL,
    UCHIZEI_KINGAKU                 NUMBER(10,0),
    HIKAZEI_KINGAKU                 NUMBER(10,0),
    SEIKYU_KINGAKU                  NUMBER(10,0) NOT NULL,
    OROSHINE                        NUMBER(10,0),
    ARARI                           NUMBER(10,0),
    SAIDAICHI_FLG                   CHAR(1) NOT NULL,
    SAISHOCHI_FLG                   CHAR(1) NOT NULL,
    SEIKYUSHO_BIKO                  VARCHAR2(100),
    SPOT_TSUIKA_FLG                 CHAR(1) NOT NULL,
    SHIME_TAISHO_KBN                CHAR(1) NOT NULL,
    SHIME_JOKYO_KBN                 CHAR(1) NOT NULL,
    SHIMEBI                         CHAR(8) NOT NULL,
    AKA_KURO_FLG                    CHAR(1) NOT NULL,
    AKA_KURO_SHIMEBI                DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_LOGI_URIAGE_RIREKI
    ADD(CONSTRAINT PK_TR_LOGI_URIAGE_RIREKI PRIMARY KEY (URIAGE_ID, URIAGE_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_LOGI_RYOKIN_KOMOKU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_LOGI_RYOKIN_KOMOKU
(
    RYOKIN_KOMOKU_1_CD              CHAR(2) NOT NULL,
    RYOKIN_KOMOKU_1_MEISHO          VARCHAR2(40),
    RYOKIN_KOMOKU_2_CD              CHAR(3) NOT NULL,
    RYOKIN_KOMOKU_2_MEISHO          VARCHAR2(40),
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    LOGI_RYOKIN_KOMOKU_DATA_VERSION NUMBER(3,0) NOT NULL,
    NEBIKIFUKA_FLG                  CHAR(1),
    SHOSUTEN_KBN                    CHAR(1),
    ZEI_KBN                         CHAR(1),
    SPOT_TSUIKA_FLG                 CHAR(1),
    URIAGE_SET_SAKI                 VARCHAR2(2),
    OROSHINE_SETTEI                 VARCHAR2(2),
    OROSHI_KOMOKU_CD                CHAR(2),
    SHORI_KAMOKU_CD                 CHAR(4),
    HOJO_KAMOKU_CD                  CHAR(2),
    TEKIYO_MEI                      VARCHAR2(40),
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_LOGI_RYOKIN_KOMOKU
    ADD(CONSTRAINT IX_MS_LOGI_RYOKIN_KOMOKU UNIQUE (RYOKIN_KOMOKU_1_CD, RYOKIN_KOMOKU_2_CD) USING INDEX)
/
ALTER TABLE MS_LOGI_RYOKIN_KOMOKU
    ADD(CONSTRAINT PK_MS_LOGI_RYOKIN_KOMOKU PRIMARY KEY (RYOKIN_KOMOKU_1_CD, RYOKIN_KOMOKU_2_CD, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE MS_LOGI_RYOKIN_KOMOKU_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_LOGI_RYOKIN_KOMOKU_RIREKI
(
    RYOKIN_KOMOKU_1_CD              CHAR(2) NOT NULL,
    RYOKIN_KOMOKU_1_MEISHO          VARCHAR2(40),
    RYOKIN_KOMOKU_2_CD              CHAR(3) NOT NULL,
    RYOKIN_KOMOKU_2_MEISHO          VARCHAR2(40),
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    OROSHI_KOMOKU_CD                CHAR(2),
    LOGI_RYOKIN_KOMOKU_DATA_VERSION NUMBER(3,0) NOT NULL,
    NEBIKIFUKA_FLG                  CHAR(1),
    SHOSUTEN_KBN                    CHAR(1),
    ZEI_KBN                         CHAR(1),
    SPOT_TSUIKA_FLG                 CHAR(1),
    URIAGE_SET_SAKI                 VARCHAR2(2),
    OROSHINE_SETTEI                 VARCHAR2(2),
    SHORI_KAMOKU_CD                 CHAR(4),
    HOJO_KAMOKU_CD                  CHAR(2),
    TEKIYO_MEI                      VARCHAR2(40),
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_LOGI_RYOKIN_KOMOKU_RIREKI
    ADD(CONSTRAINT IX_MS_LOGI_RYOKIN_KOMOKU_RIREKI UNIQUE (RYOKIN_KOMOKU_1_CD, RYOKIN_KOMOKU_2_CD) USING INDEX)
/
ALTER TABLE MS_LOGI_RYOKIN_KOMOKU_RIREKI
    ADD(CONSTRAINT PK_MS_LOGI_RYOKIN_KOMOKU_RIREKI PRIMARY KEY (RYOKIN_KOMOKU_1_CD, RYOKIN_KOMOKU_2_CD, TEKIYO_KAISHIBI, LOGI_RYOKIN_KOMOKU_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_LOGI_RYOKINHYO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_LOGI_RYOKINHYO
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) DEFAULT 0 NOT NULL,
    SHINSEI_STATUS                  CHAR(1) NOT NULL,
    SHINSEI_ID                      VARCHAR2(6),
    TEKIYO_MEI                      VARCHAR2(40),
    NEBIKI_WARIMDS_TAISHO_FLG       CHAR(1) NOT NULL,
    NEBIKI_WARIMDS_KBN              CHAR(1),
    NEBIKI_WARIMDS_GAKU             NUMBER(10,0),
    NEBIKI_WARIMDS_TANI_KBN         CHAR(2) NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE,
    LOGI_RYOKINHYO_DATA_VERSION     NUMBER(3,0) NOT NULL
)
/
ALTER TABLE TR_LOGI_RYOKINHYO
    ADD(CONSTRAINT PK_TR_LOGI_RYOKINHYO PRIMARY KEY (KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG) USING INDEX)
/
DROP TABLE TR_LOGI_RYOKINHYO_SHOKEI_GROUP CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_LOGI_RYOKINHYO_SHOKEI_GROUP
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    SHOKEI_GROUP_ID                 CHAR(3) NOT NULL,
    SHOKEI_GROUP_MEI                VARCHAR2(40) NOT NULL,
    SHOKEI_HYOJI_FLG                CHAR(1) NOT NULL,
    MEISAI_HYOJI_FLG                CHAR(1) NOT NULL,
    SHOKEI_ICHI                     CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE,
    LOGI_RYOKINHYO_DATA_VERSION     NUMBER(3,0) NOT NULL,
    TEKIYO_FLG                      CHAR(1) DEFAULT 0 NOT NULL
)
/
ALTER TABLE TR_LOGI_RYOKINHYO_SHOKEI_GROUP
    ADD(CONSTRAINT PK_TR_LOGI_RYOKINHYO_SHOKEI_GROUP PRIMARY KEY (KOKYAKU_CD, TEKIYO_KAISHIBI, SHOKEI_GROUP_ID, TEKIYO_FLG) USING INDEX)
/
DROP TABLE TR_LOGI_RYOKINHYO_SHOKEI_GROUP_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_LOGI_RYOKINHYO_SHOKEI_GROUP_RIREKI
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    SHOKEI_GROUP_ID                 CHAR(3) NOT NULL,
    SHOKEI_GROUP_MEI                VARCHAR2(40) NOT NULL,
    SHOKEI_HYOJI_FLG                CHAR(1) NOT NULL,
    MEISAI_HYOJI_FLG                CHAR(1) NOT NULL,
    SHOKEI_ICHI                     CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE,
    LOGI_RYOKINHYO_DATA_VERSION     NUMBER(3,0) NOT NULL,
    TEKIYO_FLG                      CHAR(1) DEFAULT 0 NOT NULL
)
/
ALTER TABLE TR_LOGI_RYOKINHYO_SHOKEI_GROUP_RIREKI
    ADD(CONSTRAINT PK_TR_LOGI_RYOKINHYO_SHOKEI_GROUP_RIREKI PRIMARY KEY (KOKYAKU_CD, TEKIYO_KAISHIBI, SHOKEI_GROUP_ID, LOGI_RYOKINHYO_DATA_VERSION, TEKIYO_FLG) USING INDEX)
/
DROP TABLE TR_LOGI_RYOKINHYO_MEISAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_LOGI_RYOKINHYO_MEISAI
(
    MEISAI_GYO_NO                   NUMBER(5,0) NOT NULL,
    RYOKIN_KOMOKU_1_CD              CHAR(2) NOT NULL,
    HYOJI_MEISHO_1                  VARCHAR2(40),
    RYOKIN_KOMOKU_2_CD              CHAR(3) NOT NULL,
    HYOJI_MEISHO_2                  VARCHAR2(40),
    HYOJI_MEISHO_3                  VARCHAR2(40),
    HYOJI_FLG                       CHAR(1) NOT NULL,
    SHOKEI_GROUP_ID                 CHAR(3),
    SHISETSU_CD                     CHAR(5) NOT NULL,
    FLOOR_CD                        VARCHAR2(6) NOT NULL,
    HOKAN_SHUBETSU_CD               VARCHAR2(6) NOT NULL,
    JIPPI_NYURYOKU_FLG              CHAR(1) NOT NULL,
    TANKA                           NUMBER(9,0),
    TANI                            VARCHAR2(20),
    SHOSUTEN_KBN                    CHAR(1) NOT NULL,
    NEBIKI_TAISHO_FLG               CHAR(1) NOT NULL,
    SURYO                           NUMBER(9,0),
    KINGAKU                         NUMBER(9,0),
    KEIJOBI                         VARCHAR2(2),
    SHURYOBI                        VARCHAR2(2),
    SAIDAI_SURYO                    NUMBER(9,0),
    SAISHO_SURYO                    NUMBER(9,0),
    SAIDAI_KINGAKU                  NUMBER(9,0),
    SAISHO_KINGAKU                  NUMBER(9,0),
    SEIKYUSHO_BIKO                  VARCHAR2(40),
    NYURYOKU_MEMO                   VARCHAR2(400),
    SAGYO_RANK                      CHAR(1),
    SHOYO_JIKAN                     NUMBER(3,0),
    OROSHI_TANKA                    NUMBER(9,0),
    OROSHINE_RITSU                  NUMBER(4,1),
    OROSHINE                        NUMBER(9,0),
    ARARI                           NUMBER(9,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE,
    LOGI_RYOKINHYO_DATA_VERSION     NUMBER(3,0) NOT NULL,
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) DEFAULT 0 NOT NULL
)
/
ALTER TABLE TR_LOGI_RYOKINHYO_MEISAI
    ADD(CONSTRAINT PK_TR_LOGI_RYOKINHYO_MEISAI PRIMARY KEY (MEISAI_GYO_NO, KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG) USING INDEX)
/
DROP TABLE TR_LOGI_RYOKINHYO_MEISAI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_LOGI_RYOKINHYO_MEISAI_RIREKI
(
    MEISAI_GYO_NO                   NUMBER(5,0) NOT NULL,
    RYOKIN_KOMOKU_1_CD              CHAR(2) NOT NULL,
    HYOJI_MEISHO_1                  VARCHAR2(40),
    RYOKIN_KOMOKU_2_CD              CHAR(3) NOT NULL,
    HYOJI_MEISHO_2                  VARCHAR2(40),
    HYOJI_MEISHO_3                  VARCHAR2(40),
    HYOJI_FLG                       CHAR(1) NOT NULL,
    SHOKEI_GROUP_ID                 CHAR(3),
    SHISETSU_CD                     CHAR(5) NOT NULL,
    FLOOR_CD                        VARCHAR2(6) NOT NULL,
    HOKAN_SHUBETSU_CD               VARCHAR2(6) NOT NULL,
    JIPPI_NYURYOKU_FLG              CHAR(1) NOT NULL,
    TANKA                           NUMBER(9,0),
    TANI                            VARCHAR2(20),
    SHOSUTEN_KBN                    CHAR(1) NOT NULL,
    NEBIKI_TAISHO_FLG               CHAR(1) NOT NULL,
    SURYO                           NUMBER(9,0),
    KINGAKU                         NUMBER(9,0),
    KEIJOBI                         VARCHAR2(2),
    SHURYOBI                        VARCHAR2(2),
    SAIDAI_SURYO                    NUMBER(9,0),
    SAISHO_SURYO                    NUMBER(9,0),
    SAIDAI_KINGAKU                  NUMBER(9,0),
    SAISHO_KINGAKU                  NUMBER(9,0),
    SEIKYUSHO_BIKO                  VARCHAR2(40),
    NYURYOKU_MEMO                   VARCHAR2(400),
    SAGYO_RANK                      CHAR(1),
    SHOYO_JIKAN                     NUMBER(3,0),
    OROSHI_TANKA                    NUMBER(9,0),
    OROSHINE_RITSU                  NUMBER(4,1),
    OROSHINE                        NUMBER(9,0),
    ARARI                           NUMBER(9,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE,
    LOGI_RYOKINHYO_DATA_VERSION     NUMBER(3,0) NOT NULL,
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) DEFAULT 0 NOT NULL
)
/
ALTER TABLE TR_LOGI_RYOKINHYO_MEISAI_RIREKI
    ADD(CONSTRAINT PK_TR_LOGI_RYOKINHYO_MEISAI_RIREKI PRIMARY KEY (MEISAI_GYO_NO, LOGI_RYOKINHYO_DATA_VERSION, KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG) USING INDEX)
/
DROP TABLE TR_LOGI_RYOKINHYO_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_LOGI_RYOKINHYO_RIREKI
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) DEFAULT 0 NOT NULL,
    LOGI_RYOKINHYO_DATA_VERSION     NUMBER(3,0) NOT NULL,
    SHINSEI_STATUS                  CHAR(1) NOT NULL,
    SHINSEI_ID                      VARCHAR2(6),
    TEKIYO_MEI                      VARCHAR2(40),
    NEBIKI_WARIMDS_TAISHO_FLG       CHAR(1) NOT NULL,
    NEBIKI_WARIMDS_KBN              CHAR(1),
    NEBIKI_WARIMDS_GAKU             NUMBER(10,0),
    NEBIKI_WARIMDS_TANI_KBN         CHAR(2) NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_LOGI_RYOKINHYO_RIREKI
    ADD(CONSTRAINT PK_TR_LOGI_RYOKINHYO_RIREKI PRIMARY KEY (KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG, LOGI_RYOKINHYO_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_INSATSU_KANRI_DATA CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_INSATSU_KANRI_DATA
(
    CHOHYO_ID                       NUMBER(6,0) NOT NULL,
    YOSHI_ID                        NUMBER(3,0) NOT NULL,
    INSATSU_ID                      NUMBER(12,0) NOT NULL,
    INSATSU_TAISHO_DATA_KEY         VARCHAR2(64) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_INSATSU_KANRI_DATA
    ADD(CONSTRAINT PK_INSATSU_KANRI_DATA PRIMARY KEY (CHOHYO_ID, YOSHI_ID, INSATSU_ID, INSATSU_TAISHO_DATA_KEY) USING INDEX)
/
DROP TABLE MS_INSATSU_SETTEI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_INSATSU_SETTEI
(
    USER_CD                         CHAR(7) NOT NULL,
    CHOHYO_GROUP_ID                 VARCHAR2(40) NOT NULL,
    CHOHYO_ID                       VARCHAR2(40) NOT NULL,
    PRINTER_KBN                     CHAR(1) NOT NULL,
    PRINTER_ID                      NUMBER(3,0) NOT NULL,
    YOSHI_ID                        VARCHAR2(3) NOT NULL,
    TRAY_ID                         NUMBER(3,0) NOT NULL,
    HIDARI_YOHAKU                   NUMBER(3,0),
    UE_YOHAKU                       NUMBER(3,0),
    PREV_HYOJI                      CHAR(1) NOT NULL,
    INSATSU_DAILOG_HYOJI            CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_INSATSU_SETTEI
    ADD(CONSTRAINT PK_MS_INSATSU_SETTEI PRIMARY KEY (USER_CD, CHOHYO_GROUP_ID, CHOHYO_ID) USING INDEX)
/
DROP TABLE MS_EIGYOSHO_GROUP CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_EIGYOSHO_GROUP
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    EIGYOSHO_GROUP_SEQ              NUMBER(3,0) NOT NULL,
    JOI_EIGYOSHO_CD                 CHAR(3),
    EIGYOSHO_DATA_VERSION           NUMBER(3,0) NOT NULL,
    SOSHIKI_BUNRUI_CD               CHAR(1),
    SUB_SOSHIKI_MEI                 VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_EIGYOSHO_GROUP
    ADD(CONSTRAINT PK_MS_EIGYOSHO_GROUP PRIMARY KEY (EIGYOSHO_CD, TEKIYO_KAISHIBI, EIGYOSHO_GROUP_SEQ) USING INDEX)
/
DROP TABLE MS_EIGYOSHO_GROUP_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_EIGYOSHO_GROUP_RIREKI
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    EIGYOSHO_DATA_VERSION           NUMBER(3,0) NOT NULL,
    EIGYOSHO_GROUP_SEQ              NUMBER(3,0) NOT NULL,
    JOI_EIGYOSHO_CD                 CHAR(3),
    SOSHIKI_BUNRUI_CD               CHAR(1),
    SUB_SOSHIKI_MEI                 VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_EIGYOSHO_GROUP_RIREKI
    ADD(CONSTRAINT PK_MS_EIGYOSHO_GROUP_RIREKI PRIMARY KEY (EIGYOSHO_CD, TEKIYO_KAISHIBI, EIGYOSHO_DATA_VERSION, EIGYOSHO_GROUP_SEQ) USING INDEX)
/
DROP TABLE MS_EIGYOSHO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_EIGYOSHO
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    EIGYOSHO_DATA_VERSION           NUMBER(3,0) NOT NULL,
    TEKIYO_MEI                      VARCHAR2(40),
    EIGYOSHO_MEI                    VARCHAR2(40) NOT NULL,
    EIGYOSHO_KANA_MEI               VARCHAR2(40),
    EIGYOSHO_RYAKUSHO               VARCHAR2(40),
    EIGO_HYOKI                      VARCHAR2(40),
    SHUKA_EIGYOSHO_FLG              CHAR(1) NOT NULL,
    HAITATSU_EIGYOSHO_FLG           CHAR(1) NOT NULL,
    KITEN_FLG                       CHAR(1) NOT NULL,
    URIAGE_FLG                      CHAR(1) NOT NULL,
    HAKKEN_EIGYOSHO_FLG             CHAR(1) NOT NULL,
    SHARYO_KANRI_FLG                CHAR(1) NOT NULL,
    HAIDEN_OUTPUT_EIGYOSHO_FLG      CHAR(1) NOT NULL,
    OKURIJO_HAKKO_EIGYOSHO_CD       CHAR(3),
    KEIRI_HENKANSAKI_CD             CHAR(3),
    EIGYOSHO_SHUBETSU_CD            CHAR(1) NOT NULL,
    SHONIN_EIGYOSHO_KBN_CD          CHAR(1) NOT NULL,
    YUBIN_BANGO                     CHAR(7),
    JIS_CD                          CHAR(5),
    JUSHO_1                         VARCHAR2(40),
    JUSHO_2                         VARCHAR2(40),
    JUSHO_3                         VARCHAR2(40),
    JUSHO_4                         VARCHAR2(40),
    JUSHO                           VARCHAR2(160),
    KUKO_CD                         CHAR(3),
    SHIMUKE_CHI_CD                  CHAR(7),
    SHUHAI_CHIKU                    CHAR(1),
    TEL_BANGO_1                     VARCHAR2(19),
    TEL_BANGO_2                     VARCHAR2(19),
    SHANAI_TEL_BANGO                VARCHAR2(19),
    FAX_BANGO                       VARCHAR2(19),
    KANI_GINKO_CD                   CHAR(3),
    SHITATE_EIGYOSHO_CD             CHAR(3),
    TASHA_CHUKEI_OROSHINERITSU      NUMBER(4,1),
    ICHIGEN_KOKYAKU_TOROKU_FLG      CHAR(1) NOT NULL,
    SHANAI_BIN_TOROKU_FLG           CHAR(1) NOT NULL,
    CHAKUBARAI_DAIBIKI_TOROKU_FLG   CHAR(1) NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_EIGYOSHO
    ADD(CONSTRAINT PK_MS_EIGYOSHO PRIMARY KEY (EIGYOSHO_CD, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE MS_EIGYOSHO_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_EIGYOSHO_RIREKI
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    EIGYOSHO_DATA_VERSION           NUMBER(3,0) NOT NULL,
    TEKIYO_MEI                      VARCHAR2(40),
    EIGYOSHO_MEI                    VARCHAR2(40) NOT NULL,
    EIGYOSHO_KANA_MEI               VARCHAR2(40),
    EIGYOSHO_RYAKUSHO               VARCHAR2(40),
    EIGO_HYOKI                      VARCHAR2(40),
    SHUKA_EIGYOSHO_FLG              CHAR(1) NOT NULL,
    HAITATSU_EIGYOSHO_FLG           CHAR(1) NOT NULL,
    KITEN_FLG                       CHAR(1) NOT NULL,
    URIAGE_FLG                      CHAR(1) NOT NULL,
    HAKKEN_EIGYOSHO_FLG             CHAR(1) NOT NULL,
    SHARYO_KANRI_FLG                CHAR(1) NOT NULL,
    HAIDEN_OUTPUT_EIGYOSHO_FLG      CHAR(1) NOT NULL,
    OKURIJO_HAKKO_EIGYOSHO_CD       CHAR(3),
    KEIRI_HENKANSAKI_CD             CHAR(3),
    EIGYOSHO_SHUBETSU_CD            CHAR(1) NOT NULL,
    SHONIN_EIGYOSHO_KBN_CD          CHAR(1) NOT NULL,
    YUBIN_BANGO                     CHAR(7),
    JIS_CD                          CHAR(5),
    JUSHO_1                         VARCHAR2(40),
    JUSHO_2                         VARCHAR2(40),
    JUSHO_3                         VARCHAR2(40),
    JUSHO_4                         VARCHAR2(40),
    JUSHO                           VARCHAR2(160),
    KUKO_CD                         CHAR(3),
    SHIMUKE_CHI_CD                  CHAR(7),
    SHUHAI_CHIKU                    CHAR(1),
    TEL_BANGO_1                     VARCHAR2(19),
    TEL_BANGO_2                     VARCHAR2(19),
    SHANAI_TEL_BANGO                VARCHAR2(19),
    FAX_BANGO                       VARCHAR2(19),
    KANI_GINKO_CD                   CHAR(3),
    SHITATE_EIGYOSHO_CD             CHAR(3),
    TASHA_CHUKEI_OROSHINERITSU      NUMBER(4,1),
    ICHIGEN_KOKYAKU_TOROKU_FLG      CHAR(1) NOT NULL,
    SHANAI_BIN_TOROKU_FLG           CHAR(1) NOT NULL,
    CHAKUBARAI_DAIBIKI_TOROKU_FLG   CHAR(1) NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_EIGYOSHO_RIREKI
    ADD(CONSTRAINT PK_MS_EIGYOSHO_RIREKI PRIMARY KEY (EIGYOSHO_CD, TEKIYO_KAISHIBI, EIGYOSHO_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_EIGYOSHO_OROSHI_TANKA CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_EIGYOSHO_OROSHI_TANKA
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    DEMPYO_SHUBETSU_CD              CHAR(2) NOT NULL,
    EIGYOSHO_DATA_VERSION           NUMBER(3,0) NOT NULL,
    DEFAULT_SHIYO_FLG               CHAR(1) NOT NULL,
    SHUKA_OROSHI_TANKA              NUMBER(10,0),
    SHUKA_OROSHI_SAITEI_GAKU        NUMBER(10,0),
    SHUKA_OROSHI_KEIJO_EIGHOSHO_CD  CHAR(3),
    HSO_BOSEN_TANKA                 NUMBER(10,0),
    HSO_BOSEN_SAITEI_GAKU           NUMBER(10,0),
    HSO_BOSEN_KEIJO_EIGHOSHO_CD     CHAR(3),
    TCK_BOSEN_TANKA                 NUMBER(10,0),
    TCK_BOSEN_SAITEI_GAKU           NUMBER(10,0),
    TCK_BOSEN_KEIJO_EIGHOSHO_CD     CHAR(3),
    SHIWAKE_OROSHI_TANKA            NUMBER(10,0) NOT NULL,
    SHIWAKE_OROSHI_SAITEI_GAKU      NUMBER(10,0),
    SHIWAKE_OROSHI_KEIJO_EIGHOSHO_CD CHAR(3),
    HTT_OROSHI_TANKA                NUMBER(10,0),
    HTT_OROSHI_SAITEI_GAKU          NUMBER(10,0),
    HTT_OROSHI_KEIJO_EIGHOSHO_CD    CHAR(3),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_EIGYOSHO_OROSHI_TANKA
    ADD(CONSTRAINT PK_MS_EIGYOSHO_OROSHI_TANKA PRIMARY KEY (EIGYOSHO_CD, TEKIYO_KAISHIBI, DEMPYO_SHUBETSU_CD) USING INDEX)
/
DROP TABLE MS_EIGYOSHO_OROSHI_TANKA_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_EIGYOSHO_OROSHI_TANKA_RIREKI
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    DEMPYO_SHUBETSU_CD              CHAR(2) NOT NULL,
    EIGYOSHO_DATA_VERSION           NUMBER(3,0) NOT NULL,
    DEFAULT_SHIYO_FLG               CHAR(1) NOT NULL,
    SHUKA_OROSHI_TANKA              NUMBER(10,0),
    SHUKA_OROSHI_SAITEI_GAKU        NUMBER(10,0),
    SHUKA_OROSHI_KEIJO_EIGHOSHO_CD  CHAR(3),
    HSO_BOSEN_TANKA                 NUMBER(10,0),
    HSO_BOSEN_SAITEI_GAKU           NUMBER(10,0),
    HSO_BOSEN_KEIJO_EIGHOSHO_CD     CHAR(3),
    TCK_BOSEN_TANKA                 NUMBER(10,0),
    TCK_BOSEN_SAITEI_GAKU           NUMBER(10,0),
    TCK_BOSEN_KEIJO_EIGHOSHO_CD     CHAR(3),
    SHIWAKE_OROSHI_TANKA            NUMBER(10,0) NOT NULL,
    SHIWAKE_OROSHI_SAITEI_GAKU      NUMBER(10,0),
    SHIWAKE_OROSHI_KEIJO_EIGHOSHO_CD CHAR(3),
    HTT_OROSHI_TANKA                NUMBER(10,0),
    HTT_OROSHI_SAITEI_GAKU          NUMBER(10,0),
    HTT_OROSHI_KEIJO_EIGHOSHO_CD    CHAR(3),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_EIGYOSHO_OROSHI_TANKA_RIREKI
    ADD(CONSTRAINT PK_MS_EIGYOSHO_OROSHI_TANKA_RIREKI PRIMARY KEY (EIGYOSHO_CD, TEKIYO_KAISHIBI, DEMPYO_SHUBETSU_CD, EIGYOSHO_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_EIGYOSHO_HENKAN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_EIGYOSHO_HENKAN
(
    KASHO_CD                        VARCHAR2(5) NOT NULL,
    EIGYOSHO_CD                     VARCHAR2(5) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_EIGYOSHO_HENKAN
    ADD(CONSTRAINT PK_MS_EIGYOSHO_HENKAN PRIMARY KEY (KASHO_CD) USING INDEX)
/
DROP TABLE MS_EIGYOBI_CALENDER CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_EIGYOBI_CALENDER
(
    NENGAPPI                        DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    KYUJITSU_FLG                    CHAR(1) NOT NULL,
    NICHIYO_FLG                     CHAR(1) NOT NULL,
    SHUKUJITSU_FLG                  CHAR(1) NOT NULL,
    SHUKUJITSU_MEISHO               VARCHAR2(20),
    URIAGE_SHIMEBI_FLG              CHAR(1) NOT NULL,
    NYUKIN_SHIMEBI_FLG              CHAR(1) NOT NULL,
    SHINSEI_STATUS                  CHAR(2) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_EIGYOBI_CALENDER
    ADD(CONSTRAINT PK_MS_EIGYOBI_CALENDER PRIMARY KEY (NENGAPPI, TEKIYO_FLG) USING INDEX)
/
DROP TABLE MS_OROSHI_KOMOKU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_OROSHI_KOMOKU
(
    OROSHI_KOMOKU_CD                CHAR(2) NOT NULL,
    OROSHI_KOMOKU_MEISHO            VARCHAR2(30) NOT NULL,
    OROSHI_BUMPAI_KEKKA_HYOJI_FLG   CHAR(1) NOT NULL,
    SHORI_KAMOKU_CD                 CHAR(4) NOT NULL,
    HOJO_KAMOKU_CD                  CHAR(2) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_OROSHI_KOMOKU
    ADD(CONSTRAINT PK_MS_OROSHI_KOMOKU PRIMARY KEY (OROSHI_KOMOKU_CD) USING INDEX)
/
DROP TABLE TR_OROSHINE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_OROSHINE
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(18,0) NOT NULL,
    URIAGE_MEISAI_KBN               CHAR(1) NOT NULL,
    AKA_KURO_KBN                    CHAR(1) NOT NULL,
    MEISAI_ID                       VARCHAR2(3) NOT NULL,
    SAISIN_OROSHINE_FLG             CHAR(1) NOT NULL,
    KEIRI_KEIJO_HI                  DATE NOT NULL,
    OROSHIMOTO_EIGYOSHO             VARCHAR2(5) NOT NULL,
    HANBAI_EIGYOSHO                 VARCHAR2(5) NOT NULL,
    OROSHI_KOMOKU_CD                CHAR(2) NOT NULL,
    OROSHINE                        NUMBER(9,0),
    IF_RENKEI_FLG                   CHAR(1),
    IF_RENKEI_STATS                 CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_OROSHINE
    ADD(CONSTRAINT PK_MS_CHARTER_OROSHINE1 PRIMARY KEY (URIAGE_ID, URIAGE_DATA_VERSION, URIAGE_MEISAI_KBN, AKA_KURO_KBN, MEISAI_ID) USING INDEX)
/
DROP TABLE TR_OROSHINE_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_OROSHINE_RIREKI
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(18,0) NOT NULL,
    URIAGE_MEISAI_KBN               CHAR(1) NOT NULL,
    MEISAI_ID                       VARCHAR2(3) NOT NULL,
    KEIRI_KEIJO_HI                  DATE NOT NULL,
    OROSHI_KEIJOKASYO_CD            CHAR(5) NOT NULL,
    OROSHI_KOMOKU_CD                CHAR(2) NOT NULL,
    SHORI_KAMOKU_CD                 CHAR(4) NOT NULL,
    HOJO_KAMOKU_CD                  CHAR(2) NOT NULL,
    OROSHINE                        NUMBER(9,0) NOT NULL,
    IF_RENKEI_FLG                   CHAR(1),
    IF_RENKEI_STATS                 CHAR(1),
    SAKUJO_FLG                      CHAR(1),
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8) NOT NULL,
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0),
    TOROKU_TAMMATSU                 VARCHAR2(45) NOT NULL,
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_OROSHINE_RIREKI
    ADD(CONSTRAINT PK_MS_OROSHINE1 PRIMARY KEY (URIAGE_ID, URIAGE_DATA_VERSION, URIAGE_MEISAI_KBN, MEISAI_ID, KEIRI_KEIJO_HI) USING INDEX)
/
DROP TABLE TR_OROSHI_BUMPAI_KEKKA CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_OROSHI_BUMPAI_KEKKA
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    MEISAI_ID                       NUMBER(3,0) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(3,0) NOT NULL,
    OKURIJO_NO                      CHAR(13),
    OROSHI_KOMOKU_CD                CHAR(2),
    OROSHIMOTO_EIGYOSHO             VARCHAR2(5),
    KINGAKU                         NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_OROSHI_BUMPAI_KEKKA
    ADD(CONSTRAINT PK_TR_OROSHI_BUMPAI_KEKKA PRIMARY KEY (URIAGE_ID, MEISAI_ID, URIAGE_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_OROSHI_BUMPAI_KEKKA_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_OROSHI_BUMPAI_KEKKA_RIREKI
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(3,0) NOT NULL,
    MEISAI_ID                       NUMBER(3,0) NOT NULL,
    OKURIJO_NO                      CHAR(13),
    OROSHI_KOMOKU_CD                CHAR(2),
    OROSHIMOTO_EIGYOSHO             VARCHAR2(5),
    KINGAKU                         NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_OROSHI_BUMPAI_KEKKA_RIREKI
    ADD(CONSTRAINT PK_TR_OROSHI_BUMPAI_KEKKA_RIREKI PRIMARY KEY (URIAGE_ID, MEISAI_ID, URIAGE_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_NIFUDA_SAI_HAKKO_JISSEKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_NIFUDA_SAI_HAKKO_JISSEKI
(
    YOKYU_EIGYOSHO_CD               VARCHAR2(5) NOT NULL,
    YOKYU_ID                        NUMBER(7,0) NOT NULL,
    YOKYU_ID_EDABAN                 NUMBER(3,0) NOT NULL,
    NIFUDA_SAI_HAKKO_SEQ            NUMBER(5,0) NOT NULL,
    OKURIJO_NO                      CHAR(13) NOT NULL,
    OKURIJO_NO_EDABAN               VARCHAR2(3) NOT NULL,
    HAKKO_EIGYOSHO_CD               VARCHAR2(5),
    HAKKO_NICHIJI                   DATE,
    HAKKOSHA                        CHAR(7),
    HAKKO_TAMMATSU                  VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_NIFUDA_SAI_HAKKO_JISSEKI
    ADD(CONSTRAINT PK_TR_NIFUDA_SAI_HAKKO_JISSEKI PRIMARY KEY (YOKYU_EIGYOSHO_CD, YOKYU_ID, YOKYU_ID_EDABAN, NIFUDA_SAI_HAKKO_SEQ, OKURIJO_NO, OKURIJO_NO_EDABAN) USING INDEX)
/
DROP TABLE MS_NIUKENIN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_NIUKENIN
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    NIUKENIN_HAKKO_CD               VARCHAR2(20) NOT NULL,
    NIUKENIN_DATA_VERSION           NUMBER(3,0) NOT NULL,
    NIUKENIN_MEISHO_1               VARCHAR2(40),
    NIUKENIN_MEISHO_2               VARCHAR2(40),
    NIUKENIN_MEISHO_3               VARCHAR2(40),
    NIUKENIN_MEISHO_4               VARCHAR2(40),
    NIUKENIN_RYAKUSHO               VARCHAR2(5),
    NIUKENIN_KANA_MEISHO            VARCHAR2(40),
    NIUKENIN_EIBUN_MEISHO_1         VARCHAR2(40),
    NIUKENIN_EIBUN_MEISHO_2         VARCHAR2(40),
    NIUKENIN_EIBUN_MEISHO_3         VARCHAR2(40),
    NIUKENIN_EIBUN_MEISHO_4         VARCHAR2(40),
    NIUKENIN_EIBUN_RYAKUSHO         VARCHAR2(10),
    YUBIN_BANGO                     CHAR(7),
    JIS_CD                          CHAR(5),
    JUSHO_1                         VARCHAR2(40),
    JUSHO_2                         VARCHAR2(40),
    JUSHO_3                         VARCHAR2(40),
    JUSHO_4                         VARCHAR2(40),
    TEL_BANGO                       VARCHAR2(19),
    SHIMUKE_CHI_CD                  CHAR(7),
    HAITATSU_EIGYOSHO_CD            VARCHAR2(5),
    EIBUN_JUSHO_1                   VARCHAR2(40),
    EIBUN_JUSHO_2                   VARCHAR2(40),
    EIBUN_JUSHO_3                   VARCHAR2(40),
    EIBUN_JUSHO_4                   VARCHAR2(40),
    KENSAKU_KEY                     VARCHAR2(40),
    KIJI_RAN_1_CD                   CHAR(3),
    KIJI_RAN_1                      VARCHAR2(40),
    KIJI_RAN_2_CD                   CHAR(3),
    KIJI_RAN_2                      VARCHAR2(40),
    KIJI_RAN_3_CD                   CHAR(3),
    KIJI_RAN_3                      VARCHAR2(40),
    KIJI_RAN_4_CD                   CHAR(3),
    KIJI_RAN_4                      VARCHAR2(40),
    KIJI_RAN_5_CD                   CHAR(3),
    KIJI_RAN_5                      VARCHAR2(40),
    MEMO                            VARCHAR2(100),
    ERROR_NAIYO_KBN                 CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_NIUKENIN
    ADD(CONSTRAINT PK_MS_NIUKENIN PRIMARY KEY (KOKYAKU_CD, NIUKENIN_HAKKO_CD) USING INDEX)
/
DROP TABLE MS_NIUKENIN_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_NIUKENIN_RIREKI
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    NIUKENIN_HAKKO_CD               VARCHAR2(20) NOT NULL,
    NIUKENIN_DATA_VERSION           NUMBER(3,0) NOT NULL,
    NIUKENIN_MEISHO_1               VARCHAR2(40),
    NIUKENIN_MEISHO_2               VARCHAR2(40),
    NIUKENIN_MEISHO_3               VARCHAR2(40),
    NIUKENIN_MEISHO_4               VARCHAR2(40),
    NIUKENIN_RYAKUSHO               VARCHAR2(5),
    NIUKENIN_KANA_MEISHO            VARCHAR2(40),
    NIUKENIN_EIBUN_MEISHO_1         VARCHAR2(40),
    NIUKENIN_EIBUN_MEISHO_2         VARCHAR2(40),
    NIUKENIN_EIBUN_MEISHO_3         VARCHAR2(40),
    NIUKENIN_EIBUN_MEISHO_4         VARCHAR2(40),
    NIUKENIN_EIBUN_RYAKUSHO         VARCHAR2(10),
    YUBIN_BANGO                     CHAR(7),
    JIS_CD                          CHAR(5),
    JUSHO_1                         VARCHAR2(40),
    JUSHO_2                         VARCHAR2(40),
    JUSHO_3                         VARCHAR2(40),
    JUSHO_4                         VARCHAR2(40),
    TEL_BANGO                       VARCHAR2(19),
    SHIMUKE_CHI_CD                  CHAR(7),
    HAITATSU_EIGYOSHO_CD            VARCHAR2(5),
    EIBUN_JUSHO_1                   VARCHAR2(40),
    EIBUN_JUSHO_2                   VARCHAR2(40),
    EIBUN_JUSHO_3                   VARCHAR2(40),
    EIBUN_JUSHO_4                   VARCHAR2(40),
    KENSAKU_KEY                     VARCHAR2(40),
    KIJI_RAN_1_CD                   CHAR(3),
    KIJI_RAN_1                      VARCHAR2(40),
    KIJI_RAN_2_CD                   CHAR(3),
    KIJI_RAN_2                      VARCHAR2(40),
    KIJI_RAN_3_CD                   CHAR(3),
    KIJI_RAN_3                      VARCHAR2(40),
    KIJI_RAN_4_CD                   CHAR(3),
    KIJI_RAN_4                      VARCHAR2(40),
    KIJI_RAN_5_CD                   CHAR(3),
    KIJI_RAN_5                      VARCHAR2(40),
    MEMO                            VARCHAR2(100),
    ERROR_NAIYO_KBN                 CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_NIUKENIN_RIREKI
    ADD(CONSTRAINT PK_MS_NIUKENIN_RIREKI PRIMARY KEY (KOKYAKU_CD, NIUKENIN_HAKKO_CD, NIUKENIN_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_NIOKURININ CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_NIOKURININ
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    NIOKURININ_HAKKO_CD             VARCHAR2(20) NOT NULL,
    NIOKURININ_DATA_VERSION         NUMBER(3,0) NOT NULL,
    NIOKURININ_MEISHO_1             VARCHAR2(40),
    NIOKURININ_MEISHO_2             VARCHAR2(40),
    NIOKURININ_MEISHO_3             VARCHAR2(40),
    NIOKURININ_MEISHO_4             VARCHAR2(40),
    NIOKURININ_RYAKUSHO             VARCHAR2(5),
    NIOKURININ_KANA_MEISHO          VARCHAR2(40),
    NIOKURININ_EIBUN_MEISHO_1       VARCHAR2(40),
    NIOKURININ_EIBUN_MEISHO_2       VARCHAR2(40),
    NIOKURININ_EIBUN_MEISHO_3       VARCHAR2(40),
    NIOKURININ_EIBUN_MEISHO_4       VARCHAR2(40),
    NIOKURININ_EIBUN_RYAKUSHO       VARCHAR2(10),
    YUBIN_BANGO                     CHAR(7),
    JIS_CD                          CHAR(5),
    JUSHO_1                         VARCHAR2(40),
    JUSHO_2                         VARCHAR2(40),
    JUSHO_3                         VARCHAR2(40),
    JUSHO_4                         VARCHAR2(40),
    TEL_BANGO                       VARCHAR2(19),
    EIBUN_JUSHO_1                   VARCHAR2(40),
    EIBUN_JUSHO_2                   VARCHAR2(40),
    EIBUN_JUSHO_3                   VARCHAR2(40),
    EIBUN_JUSHO_4                   VARCHAR2(40),
    KENSAKU_KEY                     VARCHAR2(40),
    KIJI_RAN_1_CD                   CHAR(3),
    KIJI_RAN_1                      VARCHAR2(40),
    KIJI_RAN_2_CD                   CHAR(3),
    KIJI_RAN_2                      VARCHAR2(40),
    KIJI_RAN_3_CD                   CHAR(3),
    KIJI_RAN_3                      VARCHAR2(40),
    KIJI_RAN_4_CD                   CHAR(3),
    KIJI_RAN_4                      VARCHAR2(40),
    KIJI_RAN_5_CD                   CHAR(3),
    KIJI_RAN_5                      VARCHAR2(40),
    MEMO                            VARCHAR2(100),
    ERROR_NAIYO_KBN                 CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_NIOKURININ
    ADD(CONSTRAINT PK_MS_NIOKURININ PRIMARY KEY (KOKYAKU_CD, NIOKURININ_HAKKO_CD) USING INDEX)
/
DROP TABLE MS_NIOKURININ_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_NIOKURININ_RIREKI
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    NIOKURININ_HAKKO_CD             VARCHAR2(20) NOT NULL,
    NIOKURININ_DATA_VERSION         NUMBER(3,0) NOT NULL,
    NIOKURININ_MEISHO_1             VARCHAR2(40),
    NIOKURININ_MEISHO_2             VARCHAR2(40),
    NIOKURININ_MEISHO_3             VARCHAR2(40),
    NIOKURININ_MEISHO_4             VARCHAR2(40),
    NIOKURININ_RYAKUSHO             VARCHAR2(5),
    NIOKURININ_KANA_MEISHO          VARCHAR2(40),
    NIOKURININ_EIBUN_MEISHO_1       VARCHAR2(40),
    NIOKURININ_EIBUN_MEISHO_2       VARCHAR2(40),
    NIOKURININ_EIBUN_MEISHO_3       VARCHAR2(40),
    NIOKURININ_EIBUN_MEISHO_4       VARCHAR2(40),
    NIOKURININ_EIBUN_RYAKUSHO       VARCHAR2(10),
    YUBIN_BANGO                     CHAR(7),
    JIS_CD                          CHAR(5),
    JUSHO_1                         VARCHAR2(40),
    JUSHO_2                         VARCHAR2(40),
    JUSHO_3                         VARCHAR2(40),
    JUSHO_4                         VARCHAR2(40),
    TEL_BANGO                       VARCHAR2(19),
    EIBUN_JUSHO_1                   VARCHAR2(40),
    EIBUN_JUSHO_2                   VARCHAR2(40),
    EIBUN_JUSHO_3                   VARCHAR2(40),
    EIBUN_JUSHO_4                   VARCHAR2(40),
    KENSAKU_KEY                     VARCHAR2(40),
    KIJI_RAN_1_CD                   CHAR(3),
    KIJI_RAN_1                      VARCHAR2(40),
    KIJI_RAN_2_CD                   CHAR(3),
    KIJI_RAN_2                      VARCHAR2(40),
    KIJI_RAN_3_CD                   CHAR(3),
    KIJI_RAN_3                      VARCHAR2(40),
    KIJI_RAN_4_CD                   CHAR(3),
    KIJI_RAN_4                      VARCHAR2(40),
    KIJI_RAN_5_CD                   CHAR(3),
    KIJI_RAN_5                      VARCHAR2(40),
    MEMO                            VARCHAR2(100),
    ERROR_NAIYO_KBN                 CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_NIOKURININ_RIREKI
    ADD(CONSTRAINT PK_MS_NIOKURININ_RIREKI PRIMARY KEY (KOKYAKU_CD, NIOKURININ_HAKKO_CD, NIOKURININ_DATA_VERSION) USING INDEX)
/
DROP TABLE "TR_NIWATASHI_KAKUNIN_JOHO-K" CASCADE CONSTRAINTS PURGE
/
CREATE TABLE "TR_NIWATASHI_KAKUNIN_JOHO-K"
(
    TOKUISAKI_CD                    VARCHAR2(6) NOT NULL,
    DATA_SAKUSEI_HIZUKE             CHAR(8) NOT NULL,
    DATA_SAKUSEI_JIKAN              CHAR(6) NOT NULL,
    UNSO_IRAI_BANGO                 VARCHAR2(20) NOT NULL,
    OKURIJO_NO                      CHAR(13) NOT NULL,
    OKURIJO_HAKKO_UMU_KBN           VARCHAR2(1) NOT NULL,
    EIGYOTEN_TOME_KBN               VARCHAR2(1) NOT NULL,
    UNSO_SHUDAN_CD                  VARCHAR2(2) NOT NULL,
    UNSO_SERVICE_CD                 VARCHAR2(2) NOT NULL,
    UNSO_ROOT_CD                    VARCHAR2(2) NOT NULL,
    SHARYO_SHUBETSU                 VARCHAR2(2) NOT NULL,
    SHARYO_BANGO                    VARCHAR2(5) NOT NULL,
    HAITATSU_NICHIJI_SERVICE_CD     VARCHAR2(2) NOT NULL,
    SHUKA_KIBOBI                    CHAR(8) NOT NULL,
    CHAKUNI_SHITEI_HIZUKE           CHAR(8) NOT NULL,
    CHAKUNI_SHITEI_JIKOKU_MADE      CHAR(4) NOT NULL,
    SHUKKABI                        VARCHAR2(8) NOT NULL,
    NIOKURININ_HAKKO_CD             VARCHAR2(20) NOT NULL,
    NIOKURININ_MEI_KANJI            VARCHAR2(40) NOT NULL,
    NIOKURININ_BUMON_CD             VARCHAR2(1) NOT NULL,
    NIOKURININ_BUMON_MEI_KANJI      VARCHAR2(40) NOT NULL,
    NIOKURININ_JUSHO_CD             VARCHAR2(5) NOT NULL,
    NIOKURININ_JUSHO_KANJI_1        VARCHAR2(40) NOT NULL,
    NIOKURININ_JUSHO_KANJI_2        VARCHAR2(40) NOT NULL,
    NIOKURININ_JUSHO_KANJI_3        VARCHAR2(40) NOT NULL,
    NIOKURININ_YUBIN_BANGO          VARCHAR2(7) NOT NULL,
    NIOKURININ_TANTOSHA_KANJI       VARCHAR2(40) NOT NULL,
    NIOKURININ_TEL_BANGO            VARCHAR2(19) NOT NULL,
    NIUKENIN_HAKKO_CD               VARCHAR2(20) NOT NULL,
    NIUKENIN_MEI_KANJI              VARCHAR2(40) NOT NULL,
    NIUKENIN_BUMON_CD               VARCHAR2(1) NOT NULL,
    NIUKENIN_BUMON_MEI_KANJI        VARCHAR2(40) NOT NULL,
    NIUKENIN_JUSHO_CD               VARCHAR2(5) NOT NULL,
    NIUKENIN_JUSHO_KANJI_1          VARCHAR2(40) NOT NULL,
    NIUKENIN_JUSHO_KANJI_2          VARCHAR2(40) NOT NULL,
    NIUKENIN_JUSHO_KANJI_3          VARCHAR2(40) NOT NULL,
    NIUKENIN_YUBIN_BANGO            VARCHAR2(7) NOT NULL,
    NIUKENIN_TANTOSHA_KANJI         VARCHAR2(40) NOT NULL,
    NIUKENIN_TEL_BANGO              VARCHAR2(19) NOT NULL,
    UNSO_JIGYOSHA_CD                VARCHAR2(12) NOT NULL,
    UNSO_JIGYOSHA_HATSU_TEN_CD      VARCHAR2(5) NOT NULL,
    UNSO_JIGYOSHA_CHAKU_TEN_CD      VARCHAR2(5) NOT NULL,
    UNCHIN_SEIKYUSAKI_CD            VARCHAR2(6) NOT NULL,
    SHUKKA_BASHO_CD                 VARCHAR2(6) NOT NULL,
    SHUKKA_BASHO_MEI_KANJI          VARCHAR2(40) NOT NULL,
    SHUKKA_BASHO_BUMON_CD           VARCHAR2(1) NOT NULL,
    SHUKKA_BASHO_BUMON_MEI_KANJI    VARCHAR2(40) NOT NULL,
    SHUKKA_BASHO_JUSHO_CD           VARCHAR2(5) NOT NULL,
    SHUKKA_BASHO_JUSHO_KANJI_1      VARCHAR2(40) NOT NULL,
    SHUKKA_BASHO_JUSHO_KANJI_2      VARCHAR2(40) NOT NULL,
    SHUKKA_BASHO_JUSHO_KANJI_3      VARCHAR2(40) NOT NULL,
    SHUKKA_BASHO_YUBIN_BANGO        VARCHAR2(7) NOT NULL,
    SHUKKA_BASHO_TANTOSHA_KANJI     VARCHAR2(40) NOT NULL,
    SHUKKA_BASHO_TEL_BANGO          VARCHAR2(19) NOT NULL,
    NI_TODOKESAKI_CD                VARCHAR2(20) NOT NULL,
    NI_TODOKESAKI_MEI_KANJI         VARCHAR2(40) NOT NULL,
    NI_TODOKESAKI_BUMON_CD          VARCHAR2(1) NOT NULL,
    NI_TODOKESAKI_BUMON_MEI_KANJI   VARCHAR2(40) NOT NULL,
    NI_TODOKESAKI_JUSHO_CD          VARCHAR2(5) NOT NULL,
    NI_TODOKESAKI_JUSHO_KANJI_1     VARCHAR2(40) NOT NULL,
    NI_TODOKESAKI_JUSHO_KANJI_2     VARCHAR2(40) NOT NULL,
    NI_TODOKESAKI_JUSHO_KANJI_3     VARCHAR2(40) NOT NULL,
    NI_TODOKESAKI_YUBIN_BANGO       VARCHAR2(7) NOT NULL,
    NI_TODOKESAKI_TANTOSHA_KANJI    VARCHAR2(40) NOT NULL,
    NI_TODOKESAKI_TEL_BANGO         VARCHAR2(19) NOT NULL,
    SHUKA_TANTOSHA_CD               VARCHAR2(7) NOT NULL,
    UNSO_KOMPO_SOU_KOSU             NUMBER(3,0) NOT NULL,
    UNSO_KOMPO_SOU_JURYO            NUMBER(8,0) NOT NULL,
    UNSO_KOMPO_SOU_YOSEKI           NUMBER(4,0) NOT NULL,
    KIHON_UNCHIN                    NUMBER(10,0) NOT NULL,
    UNCHIN_FUTAI_RYOKIN             NUMBER(21,0) NOT NULL,
    HOKEN_KINGAKU                   NUMBER(10,0) NOT NULL,
    HOKEN_RYO                       NUMBER(10,0) NOT NULL,
    DAIBIKI_TESURYO                 NUMBER(10,0) NOT NULL,
    SHINA_DAIKIN                    NUMBER(21,0) NOT NULL,
    UNCHIN_SOGOKEI_KAZEI            NUMBER(21,0) NOT NULL,
    UNCHIN_SOGOKEI_HIKAZEI          NUMBER(10,0) NOT NULL,
    MOTOBARAI_CHAKUBARAI_KBN        VARCHAR2(2) NOT NULL,
    MOCHIKOMI_KBN                   VARCHAR2(1) NOT NULL,
    BIKO                            VARCHAR2(250) NOT NULL,
    SHIMUKE_CHI_CD                  CHAR(7) NOT NULL,
    GOSHA_CD                        VARCHAR2(5) NOT NULL,
    EDI_KBN                         NUMBER(2,0) NOT NULL,
    TOROKU_EIGYOSHO_CD              VARCHAR2(5) NOT NULL,
    HAKKO_EIGYOSHO_CD               VARCHAR2(5) NOT NULL,
    OKURIJO_EDI_FLG                 CHAR(1) NOT NULL,
    URIAGE_EDI_FLG                  CHAR(1) NOT NULL,
    ERROR_FLG                       CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
DROP TABLE TR_KANREN_FILE_KANRI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_KANREN_FILE_KANRI
(
    OKURIJO_NO                      CHAR(13) NOT NULL,
    SHUKABI                         CHAR(6) NOT NULL,
    EDABAN                          CHAR(3) NOT NULL,
    KAKUNO_PATH                     VARCHAR2(512) NOT NULL,
    FILE_MEI                        VARCHAR2(512) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_KANREN_FILE_KANRI
    ADD(CONSTRAINT PK_TR_KANREN_FILE_KANRI PRIMARY KEY (OKURIJO_NO, SHUKABI, EDABAN) USING INDEX)
/
DROP TABLE MS_KINO_GROUP_PATTERN_RIYO_KANO_KINO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KINO_GROUP_PATTERN_RIYO_KANO_KINO
(
    KINO_GROUP_PATTERN_CD           VARCHAR2(20) NOT NULL,
    KINO_CD                         VARCHAR2(20) NOT NULL,
    RIYO_SETTEI                     CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KINO_GROUP_PATTERN_RIYO_KANO_KINO
    ADD(CONSTRAINT PK_MS_KINO_GROUP_PATTERN_RIYO_KANO_KINO PRIMARY KEY (KINO_GROUP_PATTERN_CD, KINO_CD) USING INDEX)
/
DROP TABLE MS_KINO_GROUP_PATTERN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KINO_GROUP_PATTERN
(
    KINO_GROUP_PATTERN_CD           VARCHAR2(20) NOT NULL,
    KINO_GROUP_PATTERN_MEI          VARCHAR2(40) NOT NULL,
    KINO_GROUP_CD                   VARCHAR2(20) NOT NULL,
    SAKUJO_FLG                      CHAR(1) DEFAULT 0 NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KINO_GROUP_PATTERN
    ADD(CONSTRAINT PK_MS_KINO_GROUP_PATTERN PRIMARY KEY (KINO_GROUP_PATTERN_CD) USING INDEX)
/
DROP TABLE MS_KINO_GROUP CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KINO_GROUP
(
    KINO_GROUP_CD                   VARCHAR2(20) NOT NULL,
    KINO_GROUP_SHUBETSU_CD          VARCHAR2(20) NOT NULL,
    KINO_GROUP_MEI                  VARCHAR2(40) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KINO_GROUP
    ADD(CONSTRAINT PK_MS_KINO_GROUP PRIMARY KEY (KINO_GROUP_CD) USING INDEX)
/
DROP TABLE MS_KINO_GROUP_SHUBETSU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KINO_GROUP_SHUBETSU
(
    KINO_GROUP_SHUBETSU_CD          VARCHAR2(20) NOT NULL,
    KINO_GROUP_SHUBETSU_MEI         VARCHAR2(40) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KINO_GROUP_SHUBETSU
    ADD(CONSTRAINT PK_MS_KINO_GROUP_SHUBETSU PRIMARY KEY (KINO_GROUP_SHUBETSU_CD) USING INDEX)
/
DROP TABLE MS_KINO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KINO
(
    KINO_CD                         VARCHAR2(20) NOT NULL,
    KINO_SHUBETSU                   VARCHAR2(10) NOT NULL,
    KINO_MEI                        VARCHAR2(100) NOT NULL,
    OYA_KINO_CD                     VARCHAR2(20),
    COMPONENT_NAME                  VARCHAR2(50),
    SHINSEI_TAISHO_FLG              CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KINO
    ADD(CONSTRAINT PK_MS_KINO PRIMARY KEY (KINO_CD) USING INDEX)
/
DROP TABLE MS_KIJI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KIJI
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    KIJI_CD                         CHAR(3) NOT NULL,
    KIJI_DATA_VERSION               NUMBER(3,0) NOT NULL,
    KIJI_NAIYO                      VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KIJI
    ADD(CONSTRAINT PK_MS_KIJI PRIMARY KEY (EIGYOSHO_CD, KOKYAKU_CD, KIJI_CD) USING INDEX)
/
DROP TABLE MS_KIJI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KIJI_RIREKI
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    KIJI_CD                         CHAR(3) NOT NULL,
    KIJI_DATA_VERSION               NUMBER(3,0) NOT NULL,
    KIJI_NAIYO                      VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KIJI_RIREKI
    ADD(CONSTRAINT PK_MS_KIJI_RIREKI PRIMARY KEY (EIGYOSHO_CD, KOKYAKU_CD, KIJI_CD, KIJI_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_KYOTENKAN_OROSHINE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KYOTENKAN_OROSHINE
(
    FROM_KYOTEN_CD                  VARCHAR2(5) NOT NULL,
    TO_KYOTEN_CD                    VARCHAR2(5) NOT NULL,
    YUSO_HOHO_CD                    CHAR(2) NOT NULL,
    KYOTENKAN_OROSHINE_DATA_VERSION NUMBER(3,0) NOT NULL,
    TANKA                           NUMBER(10,0),
    OROSHI_SHUBETSU                 VARCHAR2(1),
    KEIJO_SAKI                      VARCHAR2(5),
    DEFAULT_FLG                     CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KYOTENKAN_OROSHINE
    ADD(CONSTRAINT PK_MS_KYOTENKAN_OROSHINE PRIMARY KEY (FROM_KYOTEN_CD, TO_KYOTEN_CD, YUSO_HOHO_CD) USING INDEX)
/
DROP TABLE MS_KYOTENKAN_OROSHINE_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KYOTENKAN_OROSHINE_RIREKI
(
    FROM_KYOTEN_CD                  VARCHAR2(5) NOT NULL,
    TO_KYOTEN_CD                    VARCHAR2(5) NOT NULL,
    YUSO_HOHO_CD                    CHAR(2) NOT NULL,
    KYOTENKAN_OROSHINE_DATA_VERSION NUMBER(3,0) NOT NULL,
    TANKA                           NUMBER(10,0),
    OROSHI_SHUBETSU                 VARCHAR2(1),
    KEIJO_SAKI                      VARCHAR2(5),
    DEFAULT_FLG                     CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KYOTENKAN_OROSHINE_RIREKI
    ADD(CONSTRAINT PK_MS_KYOTENKAN_OROSHINE_RIREKI PRIMARY KEY (FROM_KYOTEN_CD, TO_KYOTEN_CD, YUSO_HOHO_CD, KYOTENKAN_OROSHINE_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_KYOTSU_SHINSEI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_KYOTSU_SHINSEI
(
    SHINSEI_ID                      VARCHAR2(6) NOT NULL,
    SHINSEI_SHUBETSU_CD             CHAR(2) NOT NULL,
    SHINSEI_EIGYOSHO_CD             VARCHAR2(5) NOT NULL,
    SHINSEISHA_CD                   CHAR(7) NOT NULL,
    SHINSEI_NICHIJI                 DATE NOT NULL,
    SHINSEI_COMMENT                 VARCHAR2(80),
    LABEL_JOHO                      VARCHAR2(40),
    LABEL_NAIYO                     VARCHAR2(80),
    MAIL_UKETORI_FLG                CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_KYOTSU_SHINSEI
    ADD(CONSTRAINT PK_TR_KYOTSU_SHINSEI PRIMARY KEY (SHINSEI_ID) USING INDEX)
/
DROP TABLE MS_KYOTSU_SHINSEI_KOMOKU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KYOTSU_SHINSEI_KOMOKU
(
    SHINSEI_SHUBETSU_CD             CHAR(2) NOT NULL,
    HYOJI_KOMOKU_1                  VARCHAR2(256),
    TO_LINK_GAMEN_ID_1              VARCHAR2(32),
    HYOJI_KOMOKU_2                  VARCHAR2(256),
    TO_LINK_GAMEN_ID_2              VARCHAR2(32),
    HYOJI_KOMOKU_3                  VARCHAR2(256),
    TO_LINK_GAMEN_ID_3              VARCHAR2(32),
    HYOJI_KOMOKU_4                  VARCHAR2(256),
    TO_LINK_GAMEN_ID_4              VARCHAR2(32),
    HYOJI_KOMOKU_5                  VARCHAR2(256),
    TO_LINK_GAMEN_ID_5              VARCHAR2(32),
    HYOJI_KOMOKU_6                  VARCHAR2(256),
    TO_LINK_GAMEN_ID_6              VARCHAR2(32),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KYOTSU_SHINSEI_KOMOKU
    ADD(CONSTRAINT PK_MS_KYOTSU_SHINSEI_KOMOKU PRIMARY KEY (SHINSEI_SHUBETSU_CD) USING INDEX)
/
DROP TABLE TR_KYOTSU_SHINSEI_MEISAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_KYOTSU_SHINSEI_MEISAI
(
    SHINSEI_ID                      VARCHAR2(6) NOT NULL,
    KYOTSU_SHINSEI_MEISAI_NO        NUMBER(13,0) NOT NULL,
    SHINSEI_SHUBETSU_CD             CHAR(2) NOT NULL,
    HYOJIYO_KEY_JOHO                VARCHAR2(256),
    KEY_JOHO                        VARCHAR2(256),
    HYOJI_KOMOKU_1                  VARCHAR2(256) NOT NULL,
    HYOJI_KOMOKU_2                  VARCHAR2(256),
    HYOJI_KOMOKU_3                  VARCHAR2(256),
    HYOJI_KOMOKU_4                  VARCHAR2(256),
    HYOJI_KOMOKU_5                  VARCHAR2(256),
    HYOJI_KOMOKU_6                  VARCHAR2(256),
    SHINSEI_RIYU                    VARCHAR2(512),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_KYOTSU_SHINSEI_MEISAI
    ADD(CONSTRAINT PK_TR_KYOTSU_SHINSEI_MEISAI PRIMARY KEY (SHINSEI_ID, KYOTSU_SHINSEI_MEISAI_NO) USING INDEX)
/
DROP TABLE MS_GINKO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_GINKO
(
    KINYU_KIKAN_CD                  VARCHAR2(4) NOT NULL,
    SHITEN_CD                       CHAR(3) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    KINYU_KIKAN_MEISHO              VARCHAR2(40),
    SHITEN_MEISHO                   VARCHAR2(40),
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_GINKO
    ADD(CONSTRAINT PK_MS_GINKO PRIMARY KEY (KINYU_KIKAN_CD, SHITEN_CD, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE MS_GINKO_KOZA CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_GINKO_KOZA
(
    KANI_GINKO_CD                   CHAR(3) NOT NULL,
    GINKO_KOZA_MEI                  VARCHAR2(60),
    KINYU_KIKAN_CD                  VARCHAR2(4) NOT NULL,
    KINYU_KIKAN_MEI                 VARCHAR2(60),
    SHITEN_CD                       CHAR(3) NOT NULL,
    SHITEN_MEI                      VARCHAR2(40),
    KOZA_SHUBETSU_CD                CHAR(2) NOT NULL,
    KOZA_BANGO                      VARCHAR2(7) NOT NULL,
    KOZA_MEIGI                      VARCHAR2(40),
    KEIRI_KAMOKU_CD                 CHAR(6),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_GINKO_KOZA
    ADD(CONSTRAINT PK_MS_GINKO_KOZA PRIMARY KEY (KANI_GINKO_CD) USING INDEX)
/
DROP TABLE MS_KBN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KBN
(
    KBN_GROUP_CD                    VARCHAR2(50) NOT NULL,
    KBN_GROUP_MEI                   VARCHAR2(256),
    KBN_CD                          VARCHAR2(30) NOT NULL,
    NARABIJUN                       NUMBER(3,0) NOT NULL,
    KBN_MEI                         VARCHAR2(256),
    KBN_KEY                         VARCHAR2(100) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KBN
    ADD(CONSTRAINT PK_MS_KBN PRIMARY KEY (KBN_GROUP_CD, KBN_CD) USING INDEX)
/
DROP TABLE MS_KUKO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KUKO
(
    KUKO_NO                         NUMBER(3,0) NOT NULL,
    KUKO_LETTER_CD                  CHAR(3) NOT NULL,
    KUKO_MEI                        VARCHAR2(40),
    KLS_LETTER_CD                   CHAR(3),
    NARABIJUN                       NUMBER(3,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KUKO
    ADD(CONSTRAINT PK_MS_KUKO PRIMARY KEY (KUKO_NO) USING INDEX)
/
DROP TABLE TR_KEIYAKU_MASTER CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_KEIYAKU_MASTER
(
    KEIYAKU_ID                      NUMBER(6,0) NOT NULL,
    MITSUMORI_TEIAN_NO              CHAR(6),
    KOKYAKU_CD                      CHAR(6),
    TEIAN_MEI                       VARCHAR2(100),
    DEMPYO_SHUBETSU_CD              CHAR(2),
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    MOTO_CHAKU_HIKITORI_KBN         CHAR(2),
    NEBIKI_WARIMDS_UMU_FLG          CHAR(1),
    SHINSEI_ID                      VARCHAR2(6),
    SINSEI_SHUBETSU                 CHAR(2),
    MITSUMORI_NO_PACK               CHAR(7),
    MITSUMORI_NO_NORMAL             CHAR(7),
    MITSUMORI_NO_CHARTER            CHAR(7),
    MITSUMORI_NO_FUTAI              CHAR(7),
    MITSUMORI_STATUS_CD             CHAR(2),
    SAISHIN_FLG                     CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_KEIYAKU_MASTER
    ADD(CONSTRAINT PK_TR_KEIYAKU_MASTER PRIMARY KEY (KEIYAKU_ID) USING INDEX)
/
DROP TABLE MS_KEIRIKAMOKU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KEIRIKAMOKU
(
    SHORI_KAMOKU_CD                 CHAR(4) NOT NULL,
    SHORI_KAMOKU_MEISHO             VARCHAR2(40),
    HOJO_KAMOKU_CD                  CHAR(2) NOT NULL,
    HOJO_KAMOKU_MEISHO              VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KEIRIKAMOKU
    ADD(CONSTRAINT PK_MS_KEIRKAMOKU PRIMARY KEY (SHORI_KAMOKU_CD, HOJO_KAMOKU_CD) USING INDEX)
/
DROP TABLE TR_GETSUMATSU_ZANDAKA CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_GETSUMATSU_ZANDAKA
(
    HOJIN_BANGO                     CHAR(13) NOT NULL,
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    SEIKYUSAKI_CD                   VARCHAR2(6) NOT NULL,
    TAISHO_TSUKI                    CHAR(6) NOT NULL,
    ZANDAKA_ZENGETSU_KURIKOSHI      NUMBER(21,0) NOT NULL,
    ZANDAKA_4_KAGETSU_IZEN          NUMBER(21,0) NOT NULL,
    ZANDAKA_3_KAGETSUMAE            NUMBER(21,0) NOT NULL,
    ZANDAKA_2_KAGETSUMAE            NUMBER(21,0) NOT NULL,
    ZANDAKA_1_KAGETSUMAE            NUMBER(21,0) NOT NULL,
    TOGETSU_HASSEI_KINGAKU          NUMBER(21,0) NOT NULL,
    ZANDAKA_YOKUGETSU_KURIKOSHI     NUMBER(21,0) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_GETSUMATSU_ZANDAKA
    ADD(CONSTRAINT PK_TR_GETSUMATSU_ZANDAKA_EIGYOSHO_BETSU1 PRIMARY KEY (HOJIN_BANGO, EIGYOSHO_CD, SEIKYUSAKI_CD, TAISHO_TSUKI) USING INDEX)
/
DROP TABLE TR_GETSUMATSU_ZANDAKA_EIGYOSHO_BETSU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_GETSUMATSU_ZANDAKA_EIGYOSHO_BETSU
(
    EIGYOSHO_CD                     VARCHAR2(5) NOT NULL,
    SEIKYUSAKI_CD                   CHAR(6) NOT NULL,
    TAISHO_TSUKI                    CHAR(6) NOT NULL,
    ZANDAKA_ZENGETSU_KURIKOSHI      NUMBER(10,0) NOT NULL,
    ZANDAKA_4_KAGETSU_IZEN          NUMBER(10,0) NOT NULL,
    ZANDAKA_3_KAGETSU_MAE           NUMBER(10,0) NOT NULL,
    ZANDAKA_2_KAGETSU_MAE           NUMBER(10,0) NOT NULL,
    ZANDAKA_1_KAGETSU_MAE           NUMBER(10,0) NOT NULL,
    TOGETSU_HASSEI_KINGAKU          NUMBER(10,0) NOT NULL,
    ZANDAKA_YOKUGETSU_KURIKOSHI     NUMBER(10,0) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_GETSUMATSU_ZANDAKA_EIGYOSHO_BETSU
    ADD(CONSTRAINT PK_TR_GETSUMATSU_ZANDAKA_EIGYOSHO_BETSU PRIMARY KEY (EIGYOSHO_CD, SEIKYUSAKI_CD, TAISHO_TSUKI) USING INDEX)
/
DROP TABLE TR_MITSUMORI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_MITSUMORI
(
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    MITSUMORI_SHURUI_KBN            CHAR(2),
    TOROKU_KBN                      CHAR(1),
    MITSUMORI_MEMO                  VARCHAR2(100),
    NEBIKI_WARIMDS_TAISHO_FLG       CHAR(1),
    NEBIKI_WARIMDS_KBN              CHAR(2),
    NEBIKI_WARIMDS_GAKU             NUMBER(10,0),
    NEBIKI_WARIMDS_TANI_KBN         CHAR(2),
    MITSUMORI_TITLE                 VARCHAR2(100),
    DANGUMI                         CHAR(1),
    BIKO_1                          VARCHAR2(2000),
    BIKO_2                          VARCHAR2(2000),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_MITSUMORI
    ADD(CONSTRAINT PK_TR_MITSUMORI PRIMARY KEY (MITSUMORI_NO, MITSUMORI_TEIAN_NO) USING INDEX)
/
DROP TABLE TR_MITSUMORI_SIM CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_MITSUMORI_SIM
(
    SIMULATION_ID                   CHAR(9) NOT NULL,
    MITSUMORI_TEIAN_NO              CHAR(6),
    PACK_MITSUMORI_NO               CHAR(7),
    NORMAL_UNCHIN_MITSUMORI_NO      CHAR(7),
    FUTAI_RYOKIN_MITSUMORI_NO       CHAR(7),
    CHARTER_MITSUMORI_NO            CHAR(7),
    DATA_KBN                        CHAR(1),
    YOKYU_NICHIJI                   DATE,
    YOKYU_SHA_ID                    CHAR(7),
    YOKYU_EIGYOSHO_CD               CHAR(3),
    JIKKO_STATUS                    CHAR(1),
    RIEKIRITSU                      NUMBER(3,0),
    JISSEKI_DATA_KOKYAKU_CD         CHAR(6),
    JISSEKI_DATA_KIKAN_FROM         DATE,
    JISSEKI_DATA_KIKAN_TO           DATE,
    SIM_MEMO                        VARCHAR2(100),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_MITSUMORI_SIM
    ADD(CONSTRAINT PK_TR_MITSUMORI_SIM PRIMARY KEY (SIMULATION_ID) USING INDEX)
/
DROP TABLE TR_MITSUMORI_SIM_DATA CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_MITSUMORI_SIM_DATA
(
    SIMULATION_ID                   CHAR(9) NOT NULL,
    EDABAN                          CHAR(8) NOT NULL,
    HOTCHI                          CHAR(6),
    CHAKUCHI                        CHAR(6),
    KOSU                            NUMBER(10,0),
    JURYO_KG                        NUMBER(10,0),
    SHUKA_SHASHU                    CHAR(2),
    SHUKA_POWER_GATE                CHAR(1),
    SHUKA_AIR_SUS                   CHAR(1),
    SHUKA_JOSHU_NINZU               NUMBER(10,0),
    SHUKA_JOSHU_JIKAN_H             NUMBER(10,0),
    HAITATSU_SHASHU                 CHAR(2),
    HAITATSU_POWER_GATE             CHAR(1),
    HAITATSU_AIR_SUS                CHAR(1),
    HAITATSU_JOSHU_NINZU            NUMBER(10,0),
    HAITATSU_JOSHU_JIKAN_H          NUMBER(10,0),
    CHOKUSO_SHASHU                  CHAR(2),
    CHOKUSO_POWER_GATE              CHAR(1),
    CHOKUSO_AIR_SUS                 CHAR(1),
    CHOKUSO_JOSHU_NINZU             NUMBER(10,0),
    CHOKUSO_JOSHU_JIKAN_H           NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_MITSUMORI_SIM_DATA
    ADD(CONSTRAINT PK_TR_MITSUMORI_SIM_DATA PRIMARY KEY (SIMULATION_ID, EDABAN) USING INDEX)
/
DROP TABLE TR_MITSUMORI_SIM_IRAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_MITSUMORI_SIM_IRAI
(
    SIMULATION_ID                   CHAR(9) NOT NULL,
    STATUS                          CHAR(1) DEFAULT 1 NOT NULL,
    SAKUJO_FLG                      CHAR(1),
    TOROKU_USER                     CHAR(6) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     CHAR(6),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_KAUNTA                   NUMBER(10,0) NOT NULL,
    TOROKU_TANMATU                  VARCHAR2(45),
    KOSHIN_TANMATU                  VARCHAR2(45),
    TOROKU_EIGYOSHO                 CHAR(3),
    KOSHIN_EIGYOSHO                 CHAR(3)
)
/
ALTER TABLE TR_MITSUMORI_SIM_IRAI
    ADD(CONSTRAINT PK_TR_MITSUMORI_SIM_IRAI PRIMARY KEY (SIMULATION_ID) USING INDEX)
/
DROP TABLE TR_MITSUMORI_SIM_KEKKA_SHUKEI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_MITSUMORI_SIM_KEKKA_SHUKEI
(
    SIMULATION_ID                   CHAR(9) NOT NULL,
    UNCHIN_KBN                      CHAR(2) NOT NULL,
    KENSU                           NUMBER(21,0),
    KOSU                            NUMBER(10,0),
    RYOKIN_SHIN                     NUMBER(21,0),
    RYOKIN_KYU                      NUMBER(21,0),
    RYOKIN_SAGAKU                   NUMBER(21,0),
    NEBIKI_ATO_SHIN                 NUMBER(21,0),
    NEBIKI_ATO_KYU                  NUMBER(21,0),
    NEBIKI_ATO_SAGAKU               NUMBER(21,0),
    OROSHINE                        NUMBER(10,0),
    ARARI_SHIN                      NUMBER(21,0),
    ARARI_KYU                       NUMBER(21,0),
    ARARI_SAGAKU                    NUMBER(21,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_MITSUMORI_SIM_KEKKA_SHUKEI
    ADD(CONSTRAINT PK_TR_MITSUMORI_SIM_KEKKA_SHUKEI PRIMARY KEY (SIMULATION_ID) USING INDEX)
/
DROP TABLE TR_MITSUMORI_SIM_KEKKA_MEISAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_MITSUMORI_SIM_KEKKA_MEISAI
(
    SIMULATION_ID                   CHAR(9) NOT NULL,
    EDABAN                          NUMBER(8,0) NOT NULL,
    HIZUKE                          DATE,
    HOTCHI                          CHAR(6),
    CHAKUCHI                        CHAR(6),
    KOSU                            NUMBER(10,0),
    JURYO                           NUMBER(10,0),
    HIMMOKU                         VARCHAR2(40),
    RYOKIN_SHIN                     NUMBER(10,0),
    RYOKIN_KYU                      NUMBER(10,0),
    NEBIKI_ATO_RYOKIN_SHIN          NUMBER(10,0),
    NEBIKI_ATO_RYOKIN_KYU           NUMBER(10,0),
    OROSHINE                        NUMBER(10,0),
    UNCHIN_KBN                      CHAR(1),
    PACK_RYOKIN_SHIN                NUMBER(10,0),
    PACK_RYOKIN_KYU                 NUMBER(10,0),
    KOKU_RYOKIN_SHIN                NUMBER(10,0),
    KOKU_RYOKIN_KYU                 NUMBER(10,0),
    SHUKA_RYOKIN_SHIN               NUMBER(10,0),
    SHUKA_RYOKIN_KYU                NUMBER(10,0),
    HAITATSU_RYOKIN_SHIN            NUMBER(10,0),
    HAITATSU_RYOKIN_KYU             NUMBER(10,0),
    YUSORYO_NEBIKI_ATO_SHIN         NUMBER(10,0),
    YUSORYO_NEBIKI_ATO_KYU          NUMBER(10,0),
    YUSORYO_OROSHINE                NUMBER(10,0),
    FUTAI_RYOKIN_SHIN               NUMBER(10,0),
    FUTAI_RYOKIN_KYU                NUMBER(10,0),
    SHUKA_CHARTER_SHIN              NUMBER(10,0),
    SHUKA_CHARTER_KYU               NUMBER(10,0),
    SHUKA_CHARTER_NEBIKI_ATO_SHIN   NUMBER(10,0),
    SHUKA_CHARTER_NEBIKI_ATO_KYU    NUMBER(10,0),
    SHUKA_CHARTER_OROSHINE          NUMBER(10,0),
    HAITATSU_CHARTER_SHIN           NUMBER(10,0),
    HAITATSU_CHARTER_KYU            NUMBER(10,0),
    HAITATSU_CHARTER_NEBIKI_ATO_SHIN NUMBER(10,0),
    HAITATSU_CHARTER_NEBIKI_ATO_KYU NUMBER(10,0),
    HAITATSU_CHARTER_OROSHINE       NUMBER(10,0),
    CHOKUSO_CHARTER_SHIN            NUMBER(10,0),
    CHOKUSO_CHARTER_KYU             NUMBER(10,0),
    CHOKUSO_CHARTER_NEBIKI_ATO_SHIN NUMBER(10,0),
    CHOKUSO_CHARTER_NEBIKI_ATO_KYU  NUMBER(10,0),
    CHOKUSO_CHARTER_OROSHINE        NUMBER(10,0),
    ERROR_FLG                       CHAR(1) DEFAULT 0 NOT NULL,
    ERROR_NAIYO                     VARCHAR2(255),
    SAKUJO_FLG                      CHAR(1) DEFAULT 0 NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_MITSUMORI_SIM_KEKKA_MEISAI
    ADD(CONSTRAINT PK_TR_MITSUMORI_SIM_KEKKA_MEISAI PRIMARY KEY (EDABAN, SIMULATION_ID) USING INDEX)
/
DROP TABLE TR_MITSUMORI_SIM_KEKKA_RYOKINHYO_BUNSEKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_MITSUMORI_SIM_KEKKA_RYOKINHYO_BUNSEKI
(
    SIMULATION_ID                   CHAR(9) NOT NULL,
    CHIIKI_EDABAN                   NUMBER(2,0) NOT NULL,
    JURYO_EDABAN                    NUMBER(3,0) NOT NULL,
    CHAKU_CHIIKI                    NUMBER(4,0) NOT NULL,
    UNCHIN_KBN                      CHAR(1),
    CHIIKI_RANK                     NUMBER(4,0),
    CHIIKI_MEISHO                   VARCHAR2(20),
    JURYOTAI                        VARCHAR2(20),
    KOSUTAI                         VARCHAR2(20),
    HIMMOKU                         VARCHAR2(40),
    KENSU                           NUMBER(10,0),
    KOSU                            NUMBER(10,0),
    URIAGE                          NUMBER(21,0),
    ARARI                           NUMBER(10,0),
    ERROR_FLG                       CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_MITSUMORI_SIM_KEKKA_RYOKINHYO_BUNSEKI
    ADD(CONSTRAINT PK_TR_MITSUMORI_SIM_KEKKA_RYOKINHYO_BUNSEKI PRIMARY KEY (SIMULATION_ID, CHIIKI_EDABAN, JURYO_EDABAN, CHAKU_CHIIKI) USING INDEX)
/
DROP TABLE MS_MITSUMORI_STATUS CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_MITSUMORI_STATUS
(
    MITSUMORI_STATUS_CD             CHAR(2) NOT NULL,
    MITSUMORI_STATUS_MEI            VARCHAR2(20) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_MITSUMORI_STATUS
    ADD(CONSTRAINT PK_MS_MITSUMORI_STATUS PRIMARY KEY (MITSUMORI_STATUS_CD) USING INDEX)
/
DROP TABLE TR_MITSUMORI_TEIAN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_MITSUMORI_TEIAN
(
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    KOKYAKU_CD                      CHAR(6),
    TEIAN_MEI                       VARCHAR2(100),
    DEMPYO_SHUBETSU_CD              CHAR(2),
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    RYOKINHYO_TEKIYO_SHURYOBI       DATE,
    MOTO_CHAKU_HIKITORI_KBN         CHAR(2),
    NEBIKI_WARIMDS_UMU_FLG          CHAR(1),
    SHINSEI_ID                      VARCHAR2(6),
    SINSEI_SHUBETSU                 CHAR(2),
    MITSUMORI_NO_PACK               CHAR(7),
    MITSUMORI_NO_NORMAL             CHAR(7),
    MITSUMORI_NO_CHARTER            CHAR(7),
    MITSUMORI_NO_FUTAI              CHAR(7),
    MITSUMORI_STATUS_CD             CHAR(2),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_MITSUMORI_TEIAN
    ADD(CONSTRAINT PK_TR_MITSUMORI_TEIAN PRIMARY KEY (MITSUMORI_TEIAN_NO) USING INDEX)
/
DROP TABLE TR_MITSUMORI_TEIAN_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_MITSUMORI_TEIAN_RIREKI
(
    SIMULATION_ID                   CHAR(9) NOT NULL,
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    KOKYAKU_CD                      CHAR(6),
    TEIAN_MEI                       VARCHAR2(100),
    DEMPYO_SHUBETSU_CD              CHAR(2),
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    RYOKINHYO_TEKIYO_SHURYOBI       DATE,
    MOTO_CHAKU_HIKITORI_KBN         CHAR(2),
    NEBIKI_WARIMDS_UMU_FLG          CHAR(1),
    SHINSEI_ID                      VARCHAR2(6),
    SINSEI_SHUBETSU                 CHAR(2),
    MITSUMORI_NO_PACK               CHAR(7),
    MITSUMORI_NO_NORMAL             CHAR(7),
    MITSUMORI_NO_CHARTER            CHAR(7),
    MITSUMORI_NO_FUTAI              CHAR(7),
    MITSUMORI_STATUS_CD             CHAR(2),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_MITSUMORI_TEIAN_RIREKI
    ADD(CONSTRAINT PK_TR_MITSUMORI_TEIAN_RIREKI PRIMARY KEY (MITSUMORI_TEIAN_NO, SIMULATION_ID) USING INDEX)
/
DROP TABLE MS_MITSUMORI_BIKO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_MITSUMORI_BIKO
(
    BIKO_ID                         NUMBER(3,0) NOT NULL,
    MITSUMORI_SHURUI_KBN            CHAR(2),
    BIKO_SHUTSURYOKUSAKI            CHAR(2),
    BIKO_TITLE                      VARCHAR2(100) NOT NULL,
    BIKO                            VARCHAR2(2000) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_MITSUMORI_BIKO
    ADD(CONSTRAINT PK_MS_MITSUMORI_BIKO PRIMARY KEY (BIKO_ID) USING INDEX)
/
DROP TABLE TR_MITSUMORI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_MITSUMORI_RIREKI
(
    SIMULATION_ID                   CHAR(9) NOT NULL,
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    MITSUMORI_SHURUI_KBN            CHAR(2),
    TOROKU_KBN                      CHAR(1),
    MITSUMORI_MEMO                  VARCHAR2(100),
    NEBIKI_WARIMDS_TAISHO_FLG       CHAR(1),
    NEBIKI_WARIMDS_KBN              CHAR(2),
    NEBIKI_WARIMDS_GAKU             NUMBER(10,0),
    NEBIKI_WARIMDS_TANI_KBN         CHAR(2),
    MITSUMORI_TITLE                 VARCHAR2(100),
    DANGUMI                         CHAR(1),
    BIKO_1                          VARCHAR2(2000),
    BIKO_2                          VARCHAR2(2000),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_MITSUMORI_RIREKI
    ADD(CONSTRAINT PK_TR_MITSUMORI_RIREKI PRIMARY KEY (MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID) USING INDEX)
/
DROP TABLE MS_MITSUMORISHO_INFO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_MITSUMORISHO_INFO
(
    MITSUMORI_SHURUI_KBN            CHAR(2) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    INFORMATION                     VARCHAR2(300),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_MITSUMORISHO_INFO
    ADD(CONSTRAINT PK_MS_MITSUMORISHO_INFO PRIMARY KEY (TEKIYO_KAISHIBI, MITSUMORI_SHURUI_KBN) USING INDEX)
/
DROP TABLE TR_GEMPYO_DATA_RENKEI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_GEMPYO_DATA_RENKEI_RIREKI
(
    SHORI_HIZUKE                    CHAR(8) NOT NULL,
    OKURIJO_NO                      CHAR(13),
    SEIKYUSAKI_CD                   CHAR(6),
    KEIJOBI                         CHAR(2),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
DROP TABLE TR_GEMPYO_H_DATA CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_GEMPYO_H_DATA
(
    RECORD_KBN                      CHAR(1) NOT NULL,
    OKURIJO_NO                      CHAR(13),
    SEIKYUSAKI_CD                   CHAR(6),
    KEIJOBI                         CHAR(8),
    AKA_KURO_KBN                    CHAR(1) NOT NULL,
    SHUKABI                         CHAR(8),
    NIOKURININ_HAKKO_CD             VARCHAR2(20),
    NIOKURININ_MEISHO_1             VARCHAR2(40),
    NIOKURININ_MEISHO_2             VARCHAR2(40),
    NIOKURININ_MEISHO_3             VARCHAR2(40),
    NIOKURININ_JIS_CD               CHAR(5),
    NIOKURININ_JUSHO_MEISHO_1       VARCHAR2(40),
    NIOKURININ_JUSHO_MEISHO_2       VARCHAR2(40),
    NIOKURININ_JUSHO_MEISHO_3       VARCHAR2(40),
    NIOKURININ_TEL_BANGO            VARCHAR2(19),
    NIUKENIN_MEISHO_1               VARCHAR2(40),
    NIUKENIN_MEISHO_2               VARCHAR2(40),
    NIUKENIN_MEISHO_3               VARCHAR2(40),
    NIUKENIN_JIS_CD                 CHAR(5),
    NIUKENIN_JUSHO_MEISHO_1         VARCHAR2(40),
    NIUKENIN_JUSHO_MEISHO_2         VARCHAR2(40),
    NIUKENIN_JUSHO_MEISHO_3         VARCHAR2(40),
    NIUKENIN_TEL_BANGO              VARCHAR2(19),
    SHUKA_EIGYOSHO_CD               VARCHAR2(5),
    HAITATSU_EIGYOSHO_CD            VARCHAR2(5),
    SHIHARAI_HOHO                   CHAR(2),
    KEIYAKU_KEITAI                  CHAR(2),
    UNCHIN_FUTAN                    CHAR(2),
    YUSO_SHUDAN                     CHAR(2),
    YUSO_HOHO_CD                    CHAR(2),
    HAITATSU_HOHO                   CHAR(2),
    KOSU                            NUMBER(3,0),
    JURYO                           NUMBER(6,0),
    KOKYAKU_KANRI_BANGO             CHAR(30),
    UNSO_RYOKIN                     NUMBER(10,0),
    KOKU_UNCHIN                     NUMBER(10,0),
    SHUKA_RYO                       NUMBER(10,0),
    TORIATSUKAI_RYO                 NUMBER(10,0),
    HAITATSU_RYO                    NUMBER(10,0),
    NEBIKI_GAKU                     NUMBER(10,0),
    JUKA_KONPORYO                   NUMBER(10,0),
    TSUSHIN_RYO                     NUMBER(10,0),
    HOTCHI_CHARTER_RYO              NUMBER(9,0),
    HOTCHI_SONOTA                   NUMBER(9,0),
    CHAKUCHI_CHARTER_RYO            NUMBER(10,0),
    CHAKUCHI_SONOTA                 NUMBER(9,0),
    CHARTER_RYOKIN                  NUMBER(10,0),
    WARIMASHI_RYOKIN                NUMBER(10,0),
    WARIBIKI_RYOKIN                 NUMBER(10,0),
    SEIKYU_KINGAKU                  NUMBER(10,0),
    KAZEI_KBN                       CHAR(1),
    SHOHIZEI                        NUMBER(10,0),
    HOKEN_KINGAKU                   NUMBER(10,0),
    KWE_KEIRI_MOKU_CD               CHAR(4),
    KWE_FUTAN_KAMOKU_CD             CHAR(6),
    KWE_FUTAN_KASHO_MEISHO          VARCHAR2(40),
    FUTAN_KASHO_KEIRI_MOKU_CD       CHAR(4),
    KWE_BUMON_MEISHO                VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
DROP TABLE TR_GEMPYO_H_DATA_ERROR CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_GEMPYO_H_DATA_ERROR
(
    SHORI_HIZUKE                    CHAR(8) NOT NULL,
    RECORD_KBN                      CHAR(1) NOT NULL,
    OKURIJO_NO                      CHAR(13),
    SEIKYUSAKI_CD                   CHAR(6),
    KEIJOBI                         CHAR(8),
    AKA_KURO_KBN                    CHAR(1) NOT NULL,
    SHUKABI                         CHAR(8),
    NIOKURININ_HAKKO_CD             VARCHAR2(20),
    NIOKURININ_MEISHO_1             VARCHAR2(40),
    NIOKURININ_MEISHO_2             VARCHAR2(40),
    NIOKURININ_MEISHO_3             VARCHAR2(40),
    NIOKURININ_JIS_CD               CHAR(5),
    NIOKURININ_JUSHO_MEISHO_1       VARCHAR2(40),
    NIOKURININ_JUSHO_MEISHO_2       VARCHAR2(40),
    NIOKURININ_JUSHO_MEISHO_3       VARCHAR2(40),
    NIOKURININ_TEL_BANGO            VARCHAR2(19),
    NIUKENIN_MEISHO_1               VARCHAR2(40),
    NIUKENIN_MEISHO_2               VARCHAR2(40),
    NIUKENIN_MEISHO_3               VARCHAR2(40),
    NIUKENIN_JIS_CD                 CHAR(5),
    NIUKENIN_JUSHO_MEISHO_1         VARCHAR2(40),
    NIUKENIN_JUSHO_MEISHO_2         VARCHAR2(40),
    NIUKENIN_JUSHO_MEISHO_3         VARCHAR2(40),
    NIUKENIN_TEL_BANGO              VARCHAR2(19),
    SHUKA_EIGYOSHO_CD               VARCHAR2(5),
    HAITATSU_EIGYOSHO_CD            VARCHAR2(5),
    SHIHARAI_HOHO                   CHAR(2),
    KEIYAKU_KEITAI                  CHAR(2),
    UNCHIN_FUTAN                    CHAR(2),
    YUSO_SHUDAN                     CHAR(2),
    YUSO_HOHO_CD                    CHAR(2),
    HAITATSU_HOHO                   CHAR(2),
    KOSU                            NUMBER(3,0),
    JURYO                           NUMBER(6,0),
    KOKYAKU_KANRI_BANGO             CHAR(30),
    UNSO_RYOKIN                     NUMBER(10,0),
    KOKU_UNCHIN                     NUMBER(10,0),
    SHUKA_RYO                       NUMBER(10,0),
    TORIATSUKAI_RYO                 NUMBER(10,0),
    HAITATSU_RYO                    NUMBER(10,0),
    NEBIKI_GAKU                     NUMBER(10,0),
    JUKA_KONPORYO                   NUMBER(10,0),
    TSUSHIN_RYO                     NUMBER(10,0),
    HOTCHI_CHARTER_RYO              NUMBER(9,0),
    HOTCHI_SONOTA                   NUMBER(9,0),
    CHAKUCHI_CHARTER_RYO            NUMBER(10,0),
    CHAKUCHI_SONOTA                 NUMBER(9,0),
    CHARTER_RYOKIN                  NUMBER(10,0),
    WARIMASHI_RYOKIN                NUMBER(10,0),
    WARIBIKI_RYOKIN                 NUMBER(10,0),
    SEIKYU_KINGAKU                  NUMBER(10,0),
    KAZEI_KBN                       CHAR(1),
    SHOHIZEI                        NUMBER(10,0),
    HOKEN_KINGAKU                   NUMBER(10,0),
    KWE_KEIRI_MOKU_CD               CHAR(4),
    KWE_FUTAN_KAMOKU_CD             CHAR(6),
    KWE_FUTAN_KASHO_MEISHO          VARCHAR2(40),
    FUTAN_KASHO_KEIRI_MOKU_CD       CHAR(4),
    KWE_BUMON_MEISHO                VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
DROP TABLE TR_GEMPYO_MEISAI_DATA CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_GEMPYO_MEISAI_DATA
(
    RECORD_KBN                      CHAR(1) NOT NULL,
    HIMMEI_MEISAI_KBN               CHAR(1),
    HIMMEI_MEISAI_CD                CHAR(2),
    MEISAI_KOMOKU_MEI               VARCHAR2(100),
    KINGAKU                         NUMBER(10,0),
    KAZEI_KBN                       CHAR(1),
    SHOHIZEI                        NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
DROP TABLE TR_GEMPYO_MEISAI_DATA_ERROR CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_GEMPYO_MEISAI_DATA_ERROR
(
    SHORI_HIZUKE                    CHAR(8) NOT NULL,
    RECORD_KBN                      CHAR(1) NOT NULL,
    HIMMEI_MEISAI_KBN               CHAR(1),
    HIMMEI_MEISAI_CD                CHAR(2),
    MEISAI_KOMOKU_MEI               VARCHAR2(100),
    KINGAKU                         NUMBER(10,0),
    KAZEI_KBN                       CHAR(1),
    SHOHIZEI                        NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
DROP TABLE TR_GENKIN_KAISHU_KANRI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_GENKIN_KAISHU_KANRI
(
    EIGYOSHO_CD                     CHAR(5) NOT NULL,
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(18,0) NOT NULL,
    KAISYU_HI                       DATE,
    OKURIJO_NO                      CHAR(13),
    KOKYAKU_CD                      CHAR(6),
    SHIHARAI_HOHO                   CHAR(2),
    TASHA_CHAKUBARAI_FLG            CHAR(1),
    KAISHU_STATUS                   CHAR(1),
    YOTEI_KINGAKU                   NUMBER(9,0),
    KAISYU_KINGAKU                  NUMBER(9,0),
    SHUKA_EIGYOSHO_CD               VARCHAR2(5) NOT NULL,
    IF_RENKEI_JOKYO_FLG             CHAR(1) NOT NULL,
    IF_RENKEI_TAISHO_FLG            CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_GENKIN_KAISHU_KANRI
    ADD(CONSTRAINT PK_TR_GENKIN_SUITO1 PRIMARY KEY (EIGYOSHO_CD, URIAGE_ID, URIAGE_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_GENKIN_KAISHU_KANRI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_GENKIN_KAISHU_KANRI_RIREKI
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(18,0) NOT NULL,
    KAISHU_STATUS_KOSHIN_NICHIJI    DATE NOT NULL,
    KAISYU_HI                       DATE,
    OKURIJO_NO                      CHAR(13),
    KOKYAKU_CD                      CHAR(6),
    SHIHARAI_HOHO                   CHAR(2),
    TASHA_CHAKUBARAI_FLG            CHAR(1),
    KAISHU_STATUS                   CHAR(1),
    YOTEI_KINGAKU                   NUMBER(9,0),
    KAISYU_KINGAKU                  NUMBER(9,0),
    SHUKA_EIGYOSHO_CD               VARCHAR2(5),
    IF_RENKEI_JOKYO_FLG             CHAR(1) NOT NULL,
    IF_RENKEI_TAISHO_FLG            CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7) NOT NULL,
    SAISHU_OPERATION_KOSHIN_NICHIJ  DATE NOT NULL
)
/
ALTER TABLE TR_GENKIN_KAISHU_KANRI_RIREKI
    ADD(CONSTRAINT PK_GENKIN_KAISHU_KANRI1 PRIMARY KEY (URIAGE_ID, URIAGE_DATA_VERSION, KAISHU_STATUS_KOSHIN_NICHIJI) USING INDEX)
/
DROP TABLE TR_GENKIN_SUITO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_GENKIN_SUITO
(
    EIGYOSHO_CD                     VARCHAR2(5) NOT NULL,
    GENKIN_SUITO_SEQ                NUMBER(8,0),
    URIAGE_ID                       NUMBER(18,0),
    SEIKYU_ID                       NUMBER(18,0),
    SEIKYUSHO_NO                    VARCHAR2(6),
    SEIKYUSHO_EDABAN                NUMBER(3,0),
    TAISHOBI                        CHAR(8) NOT NULL,
    TAISHO_KOKYAKU_CD               CHAR(6) NOT NULL,
    TEKIYO                          VARCHAR2(200),
    NYUKIN_KBN                      CHAR(1) NOT NULL,
    NYUKIN_KINGAKU                  NUMBER(10,0) NOT NULL,
    SHUKKIN_KBN                     CHAR(1) NOT NULL,
    SHUKKIN_KINGAKU                 NUMBER(10,0) NOT NULL,
    ZANDAKA                         NUMBER(10,0) NOT NULL,
    NYUKIN_ID                       NUMBER(18,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_GENKIN_SUITO
    ADD(CONSTRAINT PK_TR_GENKIN_SUITO PRIMARY KEY (EIGYOSHO_CD) USING INDEX)
/
DROP TABLE MS_KOKYAKU_TORIMATOME_SEIKYU_KO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KOKYAKU_TORIMATOME_SEIKYU_KO
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    TORIMATOME_SEIKYU_MOTO_CD       CHAR(6) NOT NULL,
    TORIMATOME_SEIKYU_DATA_VERSION  NUMBER(3,0) NOT NULL,
    HYOJI_MEI                       VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KOKYAKU_TORIMATOME_SEIKYU_KO
    ADD(CONSTRAINT PK_MS_KOKYAKU_TORIMATOME_SEIKYU_KO PRIMARY KEY (KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG, TORIMATOME_SEIKYU_MOTO_CD) USING INDEX)
/
DROP TABLE MS_KOKYAKU_TORIMATOME_SEIKYU_KO_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KOKYAKU_TORIMATOME_SEIKYU_KO_RIREKI
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    TORIMATOME_SEIKYU_MOTO_CD       CHAR(6) NOT NULL,
    TORIMATOME_SEIKYU_DATA_VERSION  NUMBER(3,0) NOT NULL,
    HYOJI_MEI                       VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KOKYAKU_TORIMATOME_SEIKYU_KO_RIREKI
    ADD(CONSTRAINT PK_MS_KOKYAKU_TORIMATOME_SEIKYU_KO_RIREKI PRIMARY KEY (KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG, TORIMATOME_SEIKYU_MOTO_CD, TORIMATOME_SEIKYU_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_KOKYAKU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KOKYAKU
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    KOKYAKU_DATA_VERSION            NUMBER(3,0) NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    TEKIYO_MEI                      VARCHAR2(40),
    SHINSEI_STATUS                  CHAR(2) NOT NULL,
    KOKYAKU_SHUBETSU                CHAR(2),
    KOKYAKU_KBN                     CHAR(2),
    KOKYAKU_MEI_KANJI_1             VARCHAR2(40) NOT NULL,
    KOKYAKU_MEI_KANJI_2             VARCHAR2(40),
    KOKYAKU_MEI_KANJI_3             VARCHAR2(40),
    KOKYAKU_MEI_KANJI_4             VARCHAR2(40),
    KOKYAKU_MEI                     VARCHAR2(160) NOT NULL,
    KOKYAKU_KANA_MEISHO             VARCHAR2(40),
    KANA_RYAKUSHO                   VARCHAR2(20),
    YUBIN_BANGO                     CHAR(7),
    JIS_CD                          CHAR(5),
    SHUKA_CHIKU                     CHAR(1),
    JUSHO_1                         VARCHAR2(40),
    JUSHO_2                         VARCHAR2(40),
    JUSHO_3                         VARCHAR2(40),
    JUSHO_4                         VARCHAR2(40),
    JUSHO                           VARCHAR2(160),
    TEL_BANGO_1                     VARCHAR2(19),
    TEL_BANGO_2                     VARCHAR2(19),
    FAX_BANGO                       VARCHAR2(19),
    GYOSHU_CD                       CHAR(2) NOT NULL,
    TOROKU_NENGAPPI                 CHAR(8),
    TORIHIKI_KAISHIBI               CHAR(8),
    OKYAKUSAMA_TANTOSHA             VARCHAR2(40),
    OKYAKUSAMA_YAKUSHOKU            VARCHAR2(40),
    OKYAKUSAMA_BUSHO                VARCHAR2(40),
    FUKU_OKYAKUSAMA_TANTOSHA        VARCHAR2(40),
    FUKU_OKYAKUSAMA_BUSHO           VARCHAR2(40),
    FUKU_OKYAKUSAMA_YAKUSHOKU       VARCHAR2(40),
    TANTO_EIGYOSHO_CD               CHAR(3) NOT NULL,
    TOSHA_TANTOSHA_CD               CHAR(7),
    KEIYAKUSAKI_CD                  CHAR(6),
    SEIKYUSAKI_CD                   CHAR(6),
    HOJIN_BANGO                     VARCHAR2(13),
    HOJIN_GROUP_SETTEI_DATA_VERSION NUMBER(3,0),
    YOSHIN_COMMENT                  VARCHAR2(300),
    KIGYO_SHUYAKU_CD_DATA_VERSION   NUMBER(3,0),
    SHUYAKU_CD_EIGYO_DATA_VERSION   NUMBER(3,0),
    SHUYAKU_CD_HONBU_DATA_VERSION   NUMBER(3,0),
    SHUYAKU_CD_SONOTA_DATA_VERSION  NUMBER(3,0),
    OKURIJOU_SANSYO_OYA_KOKYAKU_CD  CHAR(6),
    OKURIJOU_SANSYO_NIUKENIN        CHAR(1),
    OKURIJOU_SANSYO_NIOKURININ      CHAR(1),
    OKURIJOU_SANSYO_KIJI            CHAR(1),
    OKURIJOU_SANSYO_HIMMEI          CHAR(1),
    KWE_FURIKAESAKI_KEIRI_CD        VARCHAR2(12),
    KWE_FUTANSAKI_GYOMU_CD          VARCHAR2(4),
    KWE_KAMOKU_CD                   VARCHAR2(6),
    KWE_YUSYUTUNYU_KBN              CHAR(2),
    KWE_FUTAN_KASHO_MEISHO          VARCHAR2(40),
    URIAGE_NYURYOKU_DEFAULT_GAMEN   CHAR(2),
    URIAGE_NYURYOKU_MEMO            VARCHAR2(512),
    KAZEI_MENZEI_FLG                CHAR(2) NOT NULL,
    JURYO_KBN                       CHAR(2),
    MAEUKEKIN_KEIJOBI               CHAR(8),
    LOGI_URIAGE_KEISAN_TANI         CHAR(2),
    BIKO_1                          VARCHAR2(40),
    BIKO_2                          VARCHAR2(40),
    BIKO_3                          VARCHAR2(40),
    BIKO_4                          VARCHAR2(40),
    BIKO_5                          VARCHAR2(40),
    BIKO_6                          VARCHAR2(40),
    BIKO_7                          VARCHAR2(40),
    BIKO_8                          VARCHAR2(40),
    BIKO_9                          VARCHAR2(40),
    BIKO_10                         VARCHAR2(40),
    SEIKYU_EIGYOSHO_CD              CHAR(3),
    SEIKYUSHO_FORM                  CHAR(2),
    YUSO_SEIKYUSHO_RYOKIN_PTN       CHAR(2) NOT NULL,
    SEIKYUSHO_NARABIJUN             CHAR(2),
    SHOKEI_UMU                      CHAR(2),
    SHOHIZEI_KEISAN_TANI            CHAR(2),
    JUSHO_MEISHO_NO_HYOJI           CHAR(2),
    TEKIYO_RAN_1                    CHAR(2),
    TEKIYO_RAN_2                    CHAR(2),
    WEB_SEIKYUSHO_RIYO              CHAR(2),
    CSV_DL_KAHI                     CHAR(2),
    SEIKYU_KIJUN                    CHAR(2),
    SEIKYUSHO_CHECK                 CHAR(2),
    KAKUNIN_MAIL_ADDRESS_MAIN       VARCHAR2(128),
    KAKUNIN_MAIL_ADDRESS_CC         VARCHAR2(128),
    KAKUNIN_MAIL_ADDRESS_BCC        VARCHAR2(128),
    NYUKIN_TOIAWASE_HOHO            VARCHAR2(200),
    GETSUMATSU_DONICHI_NYUKIN       CHAR(2),
    TOIAWASE_TEL_BANGO              VARCHAR2(19),
    NYUKIN_MEI                      VARCHAR2(40),
    SHIHARAI_HOHO                   CHAR(2),
    TSUKI_SHIMEBI_1                 VARCHAR2(2),
    TSUKI_SHIMEBI_1_SHIHARAI_SITE   CHAR(2),
    TSUKI_SHIMEBI_1_NYUKINBI        VARCHAR2(2),
    TSUKI_SHIMEBI_2                 VARCHAR2(2),
    TSUKI_SHIMEBI_2_SHIHARAI_SITE   CHAR(2),
    TSUKI_SHIMEBI_2_NYUKINBI        VARCHAR2(2),
    TSUKI_SHIMEBI_3                 VARCHAR2(2),
    TSUKI_SHIMEBI_3_SHIHARAI_SITE   CHAR(2),
    TSUKI_SHIMEBI_3_NYUKINBI        VARCHAR2(2),
    TSUKI_SHIMEBI_4                 VARCHAR2(2),
    TSUKI_SHIMEBI_4_SHIHARAI_SITE   CHAR(2),
    TSUKI_SHIMEBI_4_NYUKINBI        VARCHAR2(2),
    TSUKI_SHIMEBI_5                 VARCHAR2(2),
    TSUKI_SHIMEBI_5_SHIHARAI_SITE   CHAR(2),
    TSUKI_SHIMEBI_5_NYUKINBI        VARCHAR2(2),
    TSUKI_SHIMEBI_6                 VARCHAR2(2),
    TSUKI_SHIMEBI_6_SHIHARAI_SITE   CHAR(2),
    TSUKI_SHIMEBI_6_NYUKINBI        VARCHAR2(2),
    KESSAMBI_SHIME_1                VARCHAR2(2),
    KESSAMBI_SHIME_1_SHIHARAI_SITE  CHAR(2),
    KESSAMBI_SHIME_1_NYUKINBI       VARCHAR2(2),
    KESSAMBI_SHIME_2                VARCHAR2(2),
    KESSAMBI_SHIME_2_SHIHARAI_SITE  CHAR(2),
    KESSAMBI_SHIME_2_NYUKINBI       VARCHAR2(2),
    KESSAMBI_SHIME_3                VARCHAR2(2),
    KESSAMBI_SHIME_3_SHIHARAI_SITE  CHAR(2),
    KESSAMBI_SHIME_3_NYUKINBI       VARCHAR2(2),
    KESSAMBI_SHIME_4                VARCHAR2(2),
    KESSAMBI_SHIME_4_SHIHARAI_SITE  CHAR(2),
    KESSAMBI_SHIME_4_NYUKINBI       VARCHAR2(2),
    KOZA_JOHO                       CHAR(1),
    KANI_GINKO_CD                   CHAR(3),
    OKURIJO_NO_FROM                 CHAR(6),
    OKURIJO_NO_TO                   CHAR(6),
    DEN_MARU_TOROKU                 CHAR(2),
    DEN_MARU_OKURIJO_NO_FROM        CHAR(6),
    DEN_MARU_OKURIJO_NO_TO          CHAR(6),
    BIKO_1_SHIYO_FLG                CHAR(1),
    BIKO_1_BIKO_MEI                 VARCHAR2(20),
    BIKO_2_SHIYO_FLG                CHAR(1),
    BIKO_2_BIKO_MEI                 VARCHAR2(20),
    BIKO_3_SHIYO_FLG                CHAR(1),
    BIKO_3_BIKO_MEI                 VARCHAR2(20),
    IKAN_MOTO_EIGYOSHO_CD           CHAR(3),
    IKAN_MOTO_EIGYOSHO_SHURYOBI     DATE,
    IKAN_MOTO_EIGYOSHO_CD_2         CHAR(3),
    IKAN_MOTO_EIGYOSHO_2_SHURYOBI   DATE,
    HON_TOROKU_SHINSEI_KANO_FLG     CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KOKYAKU
    ADD(CONSTRAINT キー UNIQUE (KOKYAKU_CD) USING INDEX)
/
ALTER TABLE MS_KOKYAKU
    ADD(CONSTRAINT PK_MS_KOKYAKU PRIMARY KEY (KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG) USING INDEX)
/
DROP TABLE MS_KOKYAKU_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KOKYAKU_RIREKI
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    KOKYAKU_DATA_VERSION            NUMBER(3,0) NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    TEKIYO_MEI                      VARCHAR2(40),
    SHINSEI_STATUS                  CHAR(2) NOT NULL,
    KOKYAKU_SHUBETSU                CHAR(2),
    KOKYAKU_KBN                     CHAR(2),
    KOKYAKU_MEI_KANJI_1             VARCHAR2(40) NOT NULL,
    KOKYAKU_MEI_KANJI_2             VARCHAR2(40),
    KOKYAKU_MEI_KANJI_3             VARCHAR2(40),
    KOKYAKU_MEI_KANJI_4             VARCHAR2(40),
    KOKYAKU_MEI                     VARCHAR2(160) NOT NULL,
    KOKYAKU_KANA_MEISHO             VARCHAR2(40),
    KANA_RYAKUSHO                   VARCHAR2(20),
    YUBIN_BANGO                     CHAR(7),
    JIS_CD                          CHAR(5),
    SHUKA_CHIKU                     CHAR(1),
    JUSHO_1                         VARCHAR2(40),
    JUSHO_2                         VARCHAR2(40),
    JUSHO_3                         VARCHAR2(40),
    JUSHO_4                         VARCHAR2(40),
    JUSHO                           VARCHAR2(160),
    TEL_BANGO_1                     VARCHAR2(19),
    TEL_BANGO_2                     VARCHAR2(19),
    FAX_BANGO                       VARCHAR2(19),
    GYOSHU_CD                       CHAR(2) NOT NULL,
    TOROKU_NENGAPPI                 CHAR(8),
    TORIHIKI_KAISHIBI               CHAR(8),
    OKYAKUSAMA_TANTOSHA             VARCHAR2(40),
    OKYAKUSAMA_YAKUSHOKU            VARCHAR2(40),
    OKYAKUSAMA_BUSHO                VARCHAR2(40),
    FUKU_OKYAKUSAMA_TANTOSHA        VARCHAR2(40),
    FUKU_OKYAKUSAMA_BUSHO           VARCHAR2(40),
    FUKU_OKYAKUSAMA_YAKUSHOKU       VARCHAR2(40),
    TANTO_EIGYOSHO_CD               CHAR(3) NOT NULL,
    TOSHA_TANTOSHA_CD               CHAR(7),
    KEIYAKUSAKI_CD                  CHAR(6),
    SEIKYUSAKI_CD                   CHAR(6),
    HOJIN_BANGO                     VARCHAR2(13),
    HOJIN_GROUP_SETTEI_DATA_VERSION NUMBER(3,0),
    YOSHIN_COMMENT                  VARCHAR2(300),
    KIGYO_SHUYAKU_CD_DATA_VERSION   NUMBER(3,0),
    SHUYAKU_CD_EIGYO_DATA_VERSION   NUMBER(3,0),
    SHUYAKU_CD_HONBU_DATA_VERSION   NUMBER(3,0),
    SHUYAKU_CD_SONOTA_DATA_VERSION  NUMBER(3,0),
    OKURIJOU_SANSYO_OYA_KOKYAKU_CD  CHAR(6),
    OKURIJOU_SANSYO_NIUKENIN        CHAR(1),
    OKURIJOU_SANSYO_NIOKURININ      CHAR(1),
    OKURIJOU_SANSYO_KIJI            CHAR(1),
    OKURIJOU_SANSYO_HIMMEI          CHAR(1),
    KWE_FURIKAESAKI_KEIRI_CD        VARCHAR2(12),
    KWE_FUTANSAKI_GYOMU_CD          VARCHAR2(4),
    KWE_KAMOKU_CD                   VARCHAR2(6),
    KWE_YUSYUTUNYU_KBN              CHAR(2),
    KWE_FUTAN_KASHO_MEISHO          VARCHAR2(40),
    URIAGE_NYURYOKU_DEFAULT_GAMEN   CHAR(2),
    URIAGE_NYURYOKU_MEMO            VARCHAR2(512),
    KAZEI_MENZEI_FLG                CHAR(2) NOT NULL,
    JURYO_KBN                       CHAR(2),
    MAEUKEKIN_KEIJOBI               CHAR(8),
    LOGI_URIAGE_KEISAN_TANI         CHAR(2),
    BIKO_1                          VARCHAR2(40),
    BIKO_2                          VARCHAR2(40),
    BIKO_3                          VARCHAR2(40),
    BIKO_4                          VARCHAR2(40),
    BIKO_5                          VARCHAR2(40),
    BIKO_6                          VARCHAR2(40),
    BIKO_7                          VARCHAR2(40),
    BIKO_8                          VARCHAR2(40),
    BIKO_9                          VARCHAR2(40),
    BIKO_10                         VARCHAR2(40),
    SEIKYU_EIGYOSHO_CD              CHAR(3),
    SEIKYUSHO_FORM                  CHAR(2),
    YUSO_SEIKYUSHO_RYOKIN_PTN       CHAR(2) NOT NULL,
    SEIKYUSHO_NARABIJUN             CHAR(2),
    SHOKEI_UMU                      CHAR(2),
    SHOHIZEI_KEISAN_TANI            CHAR(2),
    JUSHO_MEISHO_NO_HYOJI           CHAR(2),
    TEKIYO_RAN_1                    CHAR(2),
    TEKIYO_RAN_2                    CHAR(2),
    WEB_SEIKYUSHO_RIYO              CHAR(2),
    CSV_DL_KAHI                     CHAR(2),
    SEIKYU_KIJUN                    CHAR(2),
    SEIKYUSHO_CHECK                 CHAR(2),
    KAKUNIN_MAIL_ADDRESS_MAIN       VARCHAR2(128),
    KAKUNIN_MAIL_ADDRESS_CC         VARCHAR2(128),
    KAKUNIN_MAIL_ADDRESS_BCC        VARCHAR2(128),
    NYUKIN_TOIAWASE_HOHO            VARCHAR2(200),
    GETSUMATSU_DONICHI_NYUKIN       CHAR(2),
    TOIAWASE_TEL_BANGO              VARCHAR2(19),
    NYUKIN_MEI                      VARCHAR2(40),
    SHIHARAI_HOHO                   CHAR(2),
    TSUKI_SHIMEBI_1                 VARCHAR2(2),
    TSUKI_SHIMEBI_1_SHIHARAI_SITE   CHAR(2),
    TSUKI_SHIMEBI_1_NYUKINBI        VARCHAR2(2),
    TSUKI_SHIMEBI_2                 VARCHAR2(2),
    TSUKI_SHIMEBI_2_SHIHARAI_SITE   CHAR(2),
    TSUKI_SHIMEBI_2_NYUKINBI        VARCHAR2(2),
    TSUKI_SHIMEBI_3                 VARCHAR2(2),
    TSUKI_SHIMEBI_3_SHIHARAI_SITE   CHAR(2),
    TSUKI_SHIMEBI_3_NYUKINBI        VARCHAR2(2),
    TSUKI_SHIMEBI_4                 VARCHAR2(2),
    TSUKI_SHIMEBI_4_SHIHARAI_SITE   CHAR(2),
    TSUKI_SHIMEBI_4_NYUKINBI        VARCHAR2(2),
    TSUKI_SHIMEBI_5                 VARCHAR2(2),
    TSUKI_SHIMEBI_5_SHIHARAI_SITE   CHAR(2),
    TSUKI_SHIMEBI_5_NYUKINBI        VARCHAR2(2),
    TSUKI_SHIMEBI_6                 VARCHAR2(2),
    TSUKI_SHIMEBI_6_SHIHARAI_SITE   CHAR(2),
    TSUKI_SHIMEBI_6_NYUKINBI        VARCHAR2(2),
    KESSAMBI_SHIME_1                VARCHAR2(2),
    KESSAMBI_SHIME_1_SHIHARAI_SITE  CHAR(2),
    KESSAMBI_SHIME_1_NYUKINBI       VARCHAR2(2),
    KESSAMBI_SHIME_2                VARCHAR2(2),
    KESSAMBI_SHIME_2_SHIHARAI_SITE  CHAR(2),
    KESSAMBI_SHIME_2_NYUKINBI       VARCHAR2(2),
    KESSAMBI_SHIME_3                VARCHAR2(2),
    KESSAMBI_SHIME_3_SHIHARAI_SITE  CHAR(2),
    KESSAMBI_SHIME_3_NYUKINBI       VARCHAR2(2),
    KESSAMBI_SHIME_4                VARCHAR2(2),
    KESSAMBI_SHIME_4_SHIHARAI_SITE  CHAR(2),
    KESSAMBI_SHIME_4_NYUKINBI       VARCHAR2(2),
    KOZA_JOHO                       CHAR(1),
    KANI_GINKO_CD                   CHAR(3),
    OKURIJO_NO_FROM                 CHAR(6),
    OKURIJO_NO_TO                   CHAR(6),
    DEN_MARU_TOROKU                 CHAR(2),
    DEN_MARU_OKURIJO_NO_FROM        CHAR(6),
    DEN_MARU_OKURIJO_NO_TO          CHAR(6),
    BIKO_1_SHIYO_FLG                CHAR(1),
    BIKO_1_BIKO_MEI                 VARCHAR2(20),
    BIKO_2_SHIYO_FLG                CHAR(1),
    BIKO_2_BIKO_MEI                 VARCHAR2(20),
    BIKO_3_SHIYO_FLG                CHAR(1),
    BIKO_3_BIKO_MEI                 VARCHAR2(20),
    DATASPIDER_SCRIPT_MEISHO        VARCHAR2(100),
    IKAN_MOTO_EIGYOSHO_CD           CHAR(3),
    IKAN_MOTO_EIGYOSHO_SHURYOBI     DATE,
    IKAN_MOTO_EIGYOSHO_CD_2         CHAR(3),
    IKAN_MOTO_EIGYOSHO_2_SHURYOBI   DATE,
    URIAGE_SAISHU_SHIYO_HI          DATE,
    SEIKYU_SAISHU_SHIYO_HI          DATE,
    UNCHIN_KEISAN_SAISHU_SHIYO_HI   DATE,
    HAIKAN_SAISHU_SHIYO_HI          DATE,
    JOKEN_GAI_MISHU_KAISU           VARCHAR2(3),
    TSUJO_KAISHU_KAISU              VARCHAR2(3),
    HON_TOROKU_SHINSEI_KANO_FLG     CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KOKYAKU_RIREKI
    ADD(CONSTRAINT IX_MS_KOKYAKU1 UNIQUE (KOKYAKU_CD) USING INDEX)
/
ALTER TABLE MS_KOKYAKU_RIREKI
    ADD(CONSTRAINT PK_MS_KOKYAKU_RIREKI PRIMARY KEY (KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG, KOKYAKU_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_KOKYAKU_MEMO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KOKYAKU_MEMO
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    MEMO_MEISAI_ID                  NUMBER(3,0) NOT NULL,
    KOKYAKU_MEMO_DATA_VERSION       NUMBER(3,0) NOT NULL,
    MEMO_HIZUKE                     DATE,
    BASHO                           VARCHAR2(40),
    SHIMEI                          VARCHAR2(40),
    JUYODO                          CHAR(2),
    MEMO                            VARCHAR2(256),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KOKYAKU_MEMO
    ADD(CONSTRAINT PK_MS_KOKYAKU_MEMO PRIMARY KEY (KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG, MEMO_MEISAI_ID) USING INDEX)
/
DROP TABLE MS_KOKYAKU_MEMO_FILE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KOKYAKU_MEMO_FILE
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    MEMO_MEISAI_ID                  NUMBER(3,0) NOT NULL,
    FILE_MEISAI_ID                  NUMBER(3,0) NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    KOKYAKU_MEMO_FILE_DATA_VERSION  NUMBER(3,0) NOT NULL,
    TEMPU_FILE                      VARCHAR2(256),
    TEMPU_FILE_MEI                  VARCHAR2(40),
    TEMPU_FILE_1_YUKO_KIGEN         CHAR(8),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KOKYAKU_MEMO_FILE
    ADD(CONSTRAINT PK_MS_KOKYAKU_MEMO_FILE PRIMARY KEY (KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG, MEMO_MEISAI_ID, FILE_MEISAI_ID) USING INDEX)
/
DROP TABLE MS_KOKYAKU_MEMO_FILE_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KOKYAKU_MEMO_FILE_RIREKI
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    MEMO_MEISAI_ID                  NUMBER(3,0) NOT NULL,
    FILE_MEISAI_ID                  NUMBER(3,0) NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    KOKYAKU_MEMO_DATA_VERSION       NUMBER(3,0) NOT NULL,
    KOKYAKU_MEMO_FILE_DATA_VERSION  NUMBER(3,0) NOT NULL,
    TEMPU_FILE                      VARCHAR2(256),
    TEMPU_FILE_MEI                  VARCHAR2(40),
    TEMPU_FILE_1_YUKO_KIGEN         CHAR(8),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KOKYAKU_MEMO_FILE_RIREKI
    ADD(CONSTRAINT PK_MS_KOKYAKU_MEMO_FILE_RIREKI PRIMARY KEY (KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG, MEMO_MEISAI_ID, FILE_MEISAI_ID, KOKYAKU_MEMO_DATA_VERSION, KOKYAKU_MEMO_FILE_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_KOKYAKU_MEMO_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KOKYAKU_MEMO_RIREKI
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    MEMO_MEISAI_ID                  NUMBER(3,0) NOT NULL,
    KOKYAKU_MEMO_DATA_VERSION       NUMBER(3,0) NOT NULL,
    MEMO_HIZUKE                     DATE,
    BASHO                           VARCHAR2(40),
    SHIMEI                          VARCHAR2(40),
    JUYODO                          CHAR(2),
    MEMO                            VARCHAR2(256),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KOKYAKU_MEMO_RIREKI
    ADD(CONSTRAINT PK_MS_KOKYAKU_MEMO_RIREKI PRIMARY KEY (KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG, MEMO_MEISAI_ID, KOKYAKU_MEMO_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_KOKYAKU_ATE_MAIL_SETTEI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_KOKYAKU_ATE_MAIL_SETTEI
(
    EDI_SETTEI_ID                   CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    EDI_SETTEI_DATA_VERSION         NUMBER(3,0) NOT NULL,
    KOKYAKU_ATE_MAIL_TITLE          VARCHAR2(80),
    KOKYAKU_ATE_MAIL_HOMBUN         VARCHAR2(2000),
    KOKYAKU_MEI_HYOJI_SETTEI        CHAR(1) NOT NULL,
    TEMPU_FILE_SETTEI               CHAR(1) NOT NULL,
    PASSWORD_SEISEI_HOSHIKI         CHAR(1) NOT NULL,
    TMP_PASSWORD                    VARCHAR2(20),
    PASSWORD_SOFU                   CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_KOKYAKU_ATE_MAIL_SETTEI
    ADD(CONSTRAINT PK_TR_KOKYAKU_ATE_MAIL_SETTEI PRIMARY KEY (EDI_SETTEI_ID, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE TR_KOKYAKU_ATE_MAIL_SETTEI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_KOKYAKU_ATE_MAIL_SETTEI_RIREKI
(
    EDI_SETTEI_ID                   CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    EDI_SETTEI_DATA_VERSION         NUMBER(3,0) NOT NULL,
    KOKYAKU_ATE_MAIL_TITLE          VARCHAR2(80),
    KOKYAKU_ATE_MAIL_HOMBUN         VARCHAR2(2000),
    KOKYAKU_MEI_HYOJI_SETTEI        CHAR(1) NOT NULL,
    TEMPU_FILE_SETTEI               CHAR(1) NOT NULL,
    PASSWORD_SEISEI_HOSHIKI         CHAR(1) NOT NULL,
    TMP_PASSWORD                    VARCHAR2(20),
    PASSWORD_SOFU                   CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_KOKYAKU_ATE_MAIL_SETTEI_RIREKI
    ADD(CONSTRAINT PK_TR_KOKYAKU_ATE_MAIL_SETTEI_RIREKI PRIMARY KEY (EDI_SETTEI_ID, TEKIYO_KAISHIBI, EDI_SETTEI_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_KOKYAKU_ATE_MAIL_SOSHINSAKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_KOKYAKU_ATE_MAIL_SOSHINSAKI
(
    EDI_SETTEI_ID                   CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    SOSHINSAKI_ADDRESS              VARCHAR2(80) NOT NULL,
    EDI_SETTEI_DATA_VERSION         NUMBER(3,0) NOT NULL,
    SOSHIN_KBN                      CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_KOKYAKU_ATE_MAIL_SOSHINSAKI
    ADD(CONSTRAINT PK_TR_KOKYAKU_ATE_MAIL_SOSHINSAKI PRIMARY KEY (EDI_SETTEI_ID, SOSHINSAKI_ADDRESS, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE TR_KOKYAKU_ATE_MAIL_SOSHINSAKI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_KOKYAKU_ATE_MAIL_SOSHINSAKI_RIREKI
(
    EDI_SETTEI_ID                   CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    SOSHINSAKI_ADDRESS              VARCHAR2(80) NOT NULL,
    EDI_SETTEI_DATA_VERSION         NUMBER(3,0) NOT NULL,
    SOSHIN_KBN                      CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_KOKYAKU_ATE_MAIL_SOSHINSAKI_RIREKI
    ADD(CONSTRAINT PK_TR_KOKYAKU_ATE_MAIL_SOSHINSAKI_RIREKI PRIMARY KEY (EDI_SETTEI_ID, TEKIYO_KAISHIBI, SOSHINSAKI_ADDRESS, EDI_SETTEI_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_KOKYAKU_KANREN_FILE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KOKYAKU_KANREN_FILE
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    FILE_MEISAI_ID                  NUMBER(3,0) NOT NULL,
    KANREN_FILE_DATA_VERSION        NUMBER(3,0) NOT NULL,
    KANREN_FILE                     VARCHAR2(256) NOT NULL,
    KANREN_FILE_MEI                 VARCHAR2(40),
    YUKO_KIGEN                      CHAR(8) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KOKYAKU_KANREN_FILE
    ADD(CONSTRAINT PK_MS_KOKYAKU_KANREN_FILE PRIMARY KEY (KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG, FILE_MEISAI_ID) USING INDEX)
/
DROP TABLE MS_KOKYAKU_KANREN_FILE_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KOKYAKU_KANREN_FILE_RIREKI
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    FILE_MEISAI_ID                  NUMBER(3,0) NOT NULL,
    KANREN_FILE_DATA_VERSION        NUMBER(3,0) NOT NULL,
    KANREN_FILE                     VARCHAR2(256) NOT NULL,
    KANREN_FILE_MEI                 VARCHAR2(40),
    YUKO_KIGEN                      CHAR(8) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KOKYAKU_KANREN_FILE_RIREKI
    ADD(CONSTRAINT PK_MS_KOKYAKU_KANREN_FILE_RIREKI PRIMARY KEY (KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG, FILE_MEISAI_ID, KANREN_FILE_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_KOKYAKU_SHUKA_RYOKIN_MITSUMORI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_KOKYAKU_SHUKA_RYOKIN_MITSUMORI
(
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    RYOKIN                          NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_KOKYAKU_SHUKA_RYOKIN_MITSUMORI
    ADD(CONSTRAINT PK_TR_KOKYAKU_SHUKA_RYOKIN_MITSUMORI PRIMARY KEY (MITSUMORI_NO, MEISAI_GYO_NO, MITSUMORI_TEIAN_NO) USING INDEX)
/
DROP TABLE TR_KOKYAKU_SHUKA_RYOKIN_MITSUMORI_JURYOTAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_KOKYAKU_SHUKA_RYOKIN_MITSUMORI_JURYOTAI
(
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    JURYO                           NUMBER(10,0),
    ZO_KBN                          CHAR(1),
    MASHI_IKICHI                    NUMBER(10,0),
    MASHI_ZOBUN                     NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_KOKYAKU_SHUKA_RYOKIN_MITSUMORI_JURYOTAI
    ADD(CONSTRAINT PK_TR_KOKYAKU_SHUKA_RYOKIN_MITSUMORI_JURYOTAI PRIMARY KEY (MITSUMORI_NO, MEISAI_GYO_NO, MITSUMORI_TEIAN_NO) USING INDEX)
/
DROP TABLE TR_KOKYAKU_SHUKA_RYOKIN_MITSUMORI_JURYOTAI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_KOKYAKU_SHUKA_RYOKIN_MITSUMORI_JURYOTAI_RIREKI
(
    SIMULATION_ID                   CHAR(9) NOT NULL,
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    JURYO                           NUMBER(10,0),
    ZO_KBN                          CHAR(1),
    MASHI_IKICHI                    NUMBER(10,0),
    MASHI_ZOBUN                     NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_KOKYAKU_SHUKA_RYOKIN_MITSUMORI_JURYOTAI_RIREKI
    ADD(CONSTRAINT PK_TR_KOKYAKU_SHUKA_RYOKIN_MITSUMORI_JURYOTAI_RIREKI PRIMARY KEY (MITSUMORI_TEIAN_NO, MITSUMORI_NO, MEISAI_GYO_NO, SIMULATION_ID) USING INDEX)
/
DROP TABLE TR_KOKYAKU_SHUKA_RYOKIN_MITSUMORI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_KOKYAKU_SHUKA_RYOKIN_MITSUMORI_RIREKI
(
    SIMULATION_ID                   CHAR(9) NOT NULL,
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    RYOKIN                          NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_KOKYAKU_SHUKA_RYOKIN_MITSUMORI_RIREKI
    ADD(CONSTRAINT PK_TR_KOKYAKU_SHUKA_RYOKIN_MITSUMORI_RIREKI PRIMARY KEY (MITSUMORI_TEIAN_NO, MITSUMORI_NO, MEISAI_GYO_NO, SIMULATION_ID) USING INDEX)
/
DROP TABLE TR_KOKYAKU_SHUKA_RYOKINHYO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_KOKYAKU_SHUKA_RYOKINHYO
(
    KEIYAKU_ID                      NUMBER(6,0) NOT NULL,
    RYOKINHYO_NO                    CHAR(7) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    RYOKIN                          NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_KOKYAKU_SHUKA_RYOKINHYO
    ADD(CONSTRAINT PK_TR_KOKYAKU_SHUKA_RYOKINHYO PRIMARY KEY (RYOKINHYO_NO, MEISAI_GYO_NO, KEIYAKU_ID) USING INDEX)
/
DROP TABLE TR_KOKYAKU_SHUKA_RYOKINHYO_JURYOTAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_KOKYAKU_SHUKA_RYOKINHYO_JURYOTAI
(
    KEIYAKU_ID                      NUMBER(6,0) NOT NULL,
    RYOKINHYO_NO                    CHAR(7) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    JURYO                           NUMBER(10,0),
    ZO_KBN                          CHAR(1),
    MASHI_IKICHI                    NUMBER(10,0),
    MASHI_ZOBUN                     NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_KOKYAKU_SHUKA_RYOKINHYO_JURYOTAI
    ADD(CONSTRAINT PK_TR_KOKYAKU_SHUKA_RYOKINHYO_JURYOTAI PRIMARY KEY (RYOKINHYO_NO, MEISAI_GYO_NO, KEIYAKU_ID) USING INDEX)
/
DROP TABLE MS_KOKYAKU_SHUYAKU_SETTEI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KOKYAKU_SHUYAKU_SETTEI
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    SHUYAKU_CD                      VARCHAR2(10) NOT NULL,
    SHUYAKU_KBN                     CHAR(1) NOT NULL,
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    KOKYAKU_SHUYAKU_DATA_VERSION    NUMBER(3,0) NOT NULL,
    SHUYAKU_CD_DATA_VERSION         NUMBER(3,0) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KOKYAKU_SHUYAKU_SETTEI
    ADD(CONSTRAINT PK_MS_KOKYAKU_SHUYAKU_SETTEI PRIMARY KEY (KOKYAKU_CD, SHUYAKU_CD, SHUYAKU_KBN, EIGYOSHO_CD) USING INDEX)
/
DROP TABLE MS_KOKYAKU_SHUYAKU_SETTEI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KOKYAKU_SHUYAKU_SETTEI_RIREKI
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    SHUYAKU_CD                      VARCHAR2(10) NOT NULL,
    SHUYAKU_KBN                     CHAR(1) NOT NULL,
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    KOKYAKU_SHUYAKU_DATA_VERSION    NUMBER(3,0) NOT NULL,
    SHUYAKU_CD_DATA_VERSION         NUMBER(3,0) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KOKYAKU_SHUYAKU_SETTEI_RIREKI
    ADD(CONSTRAINT PK_MS_KOKYAKU_SHUYAKU_SETTEI_RIREKI PRIMARY KEY (KOKYAKU_CD, SHUYAKU_CD, SHUYAKU_KBN, EIGYOSHO_CD, KOKYAKU_SHUYAKU_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_KOKYAKU_BETSU_RIYO_KANO_DEMPYO_SHUBETSU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KOKYAKU_BETSU_RIYO_KANO_DEMPYO_SHUBETSU
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    DEMPYO_SHUBETSU_CD              CHAR(2) NOT NULL,
    KOKYAKU_DEMPYO_SHUBETSU_DATA_VERSION NUMBER(3,0) NOT NULL,
    DEFAULT_FLG                     CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KOKYAKU_BETSU_RIYO_KANO_DEMPYO_SHUBETSU
    ADD(CONSTRAINT PK_MS_KOKYAKU_BETSU_RIYO_KANO_DEMPYO_SHUBETSU PRIMARY KEY (KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG, DEMPYO_SHUBETSU_CD) USING INDEX)
/
DROP TABLE MS_KOKYAKU_BETSU_RIYO_KANO_DEMPYO_SHUBETSU_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KOKYAKU_BETSU_RIYO_KANO_DEMPYO_SHUBETSU_RIREKI
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    DEMPYO_SHUBETSU_CD              CHAR(2) NOT NULL,
    KOKYAKU_DEMPYO_SHUBETSU_DATA_VERSION NUMBER(3,0) NOT NULL,
    DEFAULT_FLG                     CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KOKYAKU_BETSU_RIYO_KANO_DEMPYO_SHUBETSU_RIREKI
    ADD(CONSTRAINT PK_MS_KOKYAKU_BETSU_RIYO_KANO_DEMPYO_SHUBETSU_RIREKI PRIMARY KEY (KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG, DEMPYO_SHUBETSU_CD, KOKYAKU_DEMPYO_SHUBETSU_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_KOKYAKU_HENKAN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KOKYAKU_HENKAN
(
    KYU_KOKYAKU_CD                  VARCHAR2(8) NOT NULL,
    TOKUISAKI_CD                    CHAR(6),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KOKYAKU_HENKAN
    ADD(CONSTRAINT PK_MS_KOKYAKU_HENKAN PRIMARY KEY (KYU_KOKYAKU_CD) USING INDEX)
/
DROP TABLE MS_KOKU_UNCHINHYO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KOKU_UNCHINHYO
(
    KOKU_UNCHINHYO_CD               VARCHAR2(8) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    KOKU_UNCHINHYO_DATA_VERSION     NUMBER(3,0) NOT NULL,
    NENDO                           VARCHAR2(20),
    KOKU_UNCHINHYO_MEI              VARCHAR2(60),
    NARABIKAE_JUN_CD                CHAR(6),
    MEMO                            VARCHAR2(80),
    SHINKI_SHIYO_KAHI               CHAR(1),
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KOKU_UNCHINHYO
    ADD(CONSTRAINT PK_MS_KOKU_UNCHINHYO PRIMARY KEY (KOKU_UNCHINHYO_CD, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE MS_KOKU_UNCHINHYO_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KOKU_UNCHINHYO_RIREKI
(
    KOKU_UNCHINHYO_CD               VARCHAR2(8) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    KOKU_UNCHINHYO_DATA_VERSION     NUMBER(3,0) NOT NULL,
    NENDO                           VARCHAR2(20),
    KOKU_UNCHINHYO_MEI              VARCHAR2(60),
    NARABIKAE_JUN_CD                CHAR(6),
    MEMO                            VARCHAR2(80),
    SHINKI_SHIYO_KAHI               CHAR(1),
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KOKU_UNCHINHYO_RIREKI
    ADD(CONSTRAINT PK_MS_KOKU_UNCHINHYO_RIREKI PRIMARY KEY (KOKU_UNCHINHYO_CD, TEKIYO_KAISHIBI, KOKU_UNCHINHYO_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_KOKU_UNCHINHYO_MEISAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KOKU_UNCHINHYO_MEISAI
(
    KOKU_UNCHINHYO_CD               VARCHAR2(8) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    HATSU_KUKO_CD                   CHAR(3) NOT NULL,
    CHAKU_KUKO_CD                   CHAR(3) NOT NULL,
    UNCHIN_SHUBETSU                 CHAR(1) NOT NULL,
    JURYO_KBN                       CHAR(1) NOT NULL,
    JURYO                           NUMBER(4,0) NOT NULL,
    KOKU_UNCHINHYO_DATA_VERSION     NUMBER(3,0) NOT NULL,
    OFUKU_FLG                       CHAR(1) NOT NULL,
    KINGAKU                         NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KOKU_UNCHINHYO_MEISAI
    ADD(CONSTRAINT PK_MS_KOKU_UNCHINHYO_MEISAI PRIMARY KEY (HATSU_KUKO_CD, CHAKU_KUKO_CD, UNCHIN_SHUBETSU, JURYO_KBN, JURYO, KOKU_UNCHINHYO_CD, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE MS_KOKU_UNCHINHYO_MEISAI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KOKU_UNCHINHYO_MEISAI_RIREKI
(
    KOKU_UNCHINHYO_CD               VARCHAR2(8) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    HATSU_KUKO_CD                   CHAR(3) NOT NULL,
    CHAKU_KUKO_CD                   CHAR(3) NOT NULL,
    UNCHIN_SHUBETSU                 CHAR(1) NOT NULL,
    JURYO_KBN                       CHAR(1) NOT NULL,
    JURYO                           NUMBER(4,0) NOT NULL,
    KOKU_UNCHINHYO_DATA_VERSION     NUMBER(3,0) NOT NULL,
    OFUKU_FLG                       CHAR(1) NOT NULL,
    KINGAKU                         NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KOKU_UNCHINHYO_MEISAI_RIREKI
    ADD(CONSTRAINT PK_MS_KOKU_UNCHINHYO_MEISAI_RIREKI PRIMARY KEY (KOKU_UNCHINHYO_CD, TEKIYO_KAISHIBI, HATSU_KUKO_CD, CHAKU_KUKO_CD, UNCHIN_SHUBETSU, JURYO_KBN, JURYO, KOKU_UNCHINHYO_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_KOKU_GAISHA CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_KOKU_GAISHA
(
    KOKU_GAISHA_CD                  VARCHAR2(3) NOT NULL,
    KOKU_GAISHA_MEI                 VARCHAR2(40),
    DAIRITEN_TESURYO_RITSU          NUMBER(5,2),
    SS_SHIIRESAKI_CD                VARCHAR2(8),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_KOKU_GAISHA
    ADD(CONSTRAINT PK_MS_KOKU_GAISHA PRIMARY KEY (KOKU_GAISHA_CD) USING INDEX)
/
DROP TABLE MS_GOSHA CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_GOSHA
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    GOSHA_CD                        VARCHAR2(5) NOT NULL,
    GOSHA_DATA_VERSION              NUMBER(3,0) NOT NULL,
    GOSHA_MEI                       VARCHAR2(40),
    SHARYO_NO                       VARCHAR2(5),
    USER_CD                         CHAR(7),
    KAISHI_JIS_CD                   CHAR(5),
    KAISHI_JUSHO                    VARCHAR2(160),
    SHURYO_JIS_CD                   CHAR(5),
    SHURYO_JUSHO                    VARCHAR2(160),
    CHIZU_YOTEI_HYOJI_FLG           CHAR(1),
    HANDY_JISAN_KBN                 CHAR(1),
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    TEKIYO_MEI                      VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_GOSHA
    ADD(CONSTRAINT PK_MS_GOSHA PRIMARY KEY (EIGYOSHO_CD, GOSHA_CD, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE MS_GOSHA_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_GOSHA_RIREKI
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    GOSHA_CD                        VARCHAR2(5) NOT NULL,
    GOSHA_DATA_VERSION              NUMBER(3,0) NOT NULL,
    GOSHA_MEI                       VARCHAR2(40),
    SHARYO_NO                       VARCHAR2(5),
    USER_CD                         CHAR(7),
    KAISHI_JIS_CD                   CHAR(5),
    KAISHI_JUSHO                    VARCHAR2(160),
    SHURYO_JIS_CD                   CHAR(5),
    SHURYO_JUSHO                    VARCHAR2(160),
    CHIZU_YOTEI_HYOJI_FLG           CHAR(1),
    HANDY_JISAN_KBN                 CHAR(1),
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    TEKIYO_MEI                      VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_GOSHA_RIREKI
    ADD(CONSTRAINT PK_MS_GOSHA_RIREKI PRIMARY KEY (EIGYOSHO_CD, GOSHA_CD, GOSHA_DATA_VERSION, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE MS_GOSHA_SHIMUKE_CHI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_GOSHA_SHIMUKE_CHI
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    GOSHA_CD                        VARCHAR2(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    JIS_CD                          CHAR(5) NOT NULL,
    SHIMUKE_CHI_CD                  CHAR(7) NOT NULL,
    GOSHA_DATA_VERSION              NUMBER(3,0) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_GOSHA_SHIMUKE_CHI
    ADD(CONSTRAINT PK_MS_GOSHA_SHIMUKE_CHI PRIMARY KEY (EIGYOSHO_CD, GOSHA_CD, JIS_CD, SHIMUKE_CHI_CD, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE MS_GOSHA_SHIMUKE_CHI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_GOSHA_SHIMUKE_CHI_RIREKI
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    GOSHA_CD                        VARCHAR2(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    JIS_CD                          CHAR(5) NOT NULL,
    SHIMUKE_CHI_CD                  CHAR(7) NOT NULL,
    GOSHA_DATA_VERSION              NUMBER(3,0) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_GOSHA_SHIMUKE_CHI_RIREKI
    ADD(CONSTRAINT PK_MS_GOSHA_SHIMUKE_CHI_RIREKI PRIMARY KEY (EIGYOSHO_CD, GOSHA_CD, TEKIYO_KAISHIBI, JIS_CD, SHIMUKE_CHI_CD, GOSHA_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_SAGYO_RANK_OROSHINE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SAGYO_RANK_OROSHINE
(
    SAGYO_RANK                      CHAR(1) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    SAGYO_RANK_MEISHO               VARCHAR2(20),
    OROSHINE                        NUMBER(10,0) NOT NULL,
    TEKIYO_MEI                      VARCHAR2(40),
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SAGYO_RANK_OROSHINE
    ADD(CONSTRAINT PK_MS_SAGYO_RANK_OROSHINE PRIMARY KEY (SAGYO_RANK, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE MS_SHIMUKE_CHI_HENKAN_JOHO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHIMUKE_CHI_HENKAN_JOHO
(
    JIS_CD                          CHAR(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    SHIMUKE_CHI_CD                  CHAR(7) NOT NULL,
    SHIMUKE_CHI_HENKAN_JOHO_SEQ     NUMBER(3,0) NOT NULL,
    JUSHO_JIS_DATA_VERSION          NUMBER(3,0) NOT NULL,
    HENKAN_JOHO_JUSHO               VARCHAR2(40),
    KYU_JUSHO_FLG                   CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHIMUKE_CHI_HENKAN_JOHO
    ADD(CONSTRAINT PK_MS_SHIMUKE_CHI_HENKAN_JOHO PRIMARY KEY (JIS_CD, TEKIYO_KAISHIBI, SHIMUKE_CHI_CD, SHIMUKE_CHI_HENKAN_JOHO_SEQ) USING INDEX)
/
DROP TABLE MS_SHIMUKE_CHI_HENKAN_JOHO_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHIMUKE_CHI_HENKAN_JOHO_RIREKI
(
    JIS_CD                          CHAR(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    SHIMUKE_CHI_CD                  CHAR(7) NOT NULL,
    SHIMUKE_CHI_HENKAN_JOHO_SEQ     NUMBER(3,0) NOT NULL,
    JUSHO_JIS_DATA_VERSION          NUMBER(3,0) NOT NULL,
    HENKAN_JOHO_JUSHO               VARCHAR2(40),
    KYU_JUSHO_FLG                   CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHIMUKE_CHI_HENKAN_JOHO_RIREKI
    ADD(CONSTRAINT PK_MS_SHIMUKE_CHI_HENKAN_JOHO_RIREKI PRIMARY KEY (JIS_CD, TEKIYO_KAISHIBI, SHIMUKE_CHI_CD, SHIMUKE_CHI_HENKAN_JOHO_SEQ, JUSHO_JIS_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_SHIMUKE_CHI_MEI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHIMUKE_CHI_MEI
(
    TODOFUKEN_CD                    CHAR(2) NOT NULL,
    SHIMUKE_CHI_MEI_CD              VARCHAR2(4) NOT NULL,
    SHIMUKE_CHI_MEI_DATA_VERSION    NUMBER(3,0) NOT NULL,
    SHIMUKE_CHI_MEI                 VARCHAR2(8) NOT NULL,
    BIKO                            VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHIMUKE_CHI_MEI
    ADD(CONSTRAINT PK_MS_SHIMUKE_CHI_MEI PRIMARY KEY (TODOFUKEN_CD, SHIMUKE_CHI_MEI_CD) USING INDEX)
/
DROP TABLE MS_SHIMUKE_CHI_MEI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHIMUKE_CHI_MEI_RIREKI
(
    TODOFUKEN_CD                    CHAR(2) NOT NULL,
    SHIMUKE_CHI_MEI_CD              VARCHAR2(4) NOT NULL,
    SHIMUKE_CHI_MEI_DATA_VERSION    NUMBER(3,0) NOT NULL,
    SHIMUKE_CHI_MEI                 VARCHAR2(8) NOT NULL,
    BIKO                            VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHIMUKE_CHI_MEI_RIREKI
    ADD(CONSTRAINT PK_MS_SHIMUKE_CHI_MEI_RIREKI PRIMARY KEY (TODOFUKEN_CD, SHIMUKE_CHI_MEI_CD, SHIMUKE_CHI_MEI_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_SHIIRE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SHIIRE
(
    TAISHO_NENGETSU                 VARCHAR2(6) NOT NULL,
    EIGYOSHO_CD                     VARCHAR2(5) NOT NULL,
    SHIIRESAKI_CD                   VARCHAR2(5) NOT NULL,
    SHIIRE_KBN_CD                   CHAR(4) NOT NULL,
    SHIIRE_SEQ                      NUMBER(3,0) NOT NULL,
    SHIIRE_ID                       NUMBER(15,0) NOT NULL,
    SHIIRE_DATA_VERSION             NUMBER(3,0) NOT NULL,
    AKA_KURO_KBN                    CHAR(1) NOT NULL,
    KEIJO_KBN                       CHAR(1) NOT NULL,
    SHIIRE_KEIJO_HI                 DATE NOT NULL,
    KIKAN_FROM                      DATE,
    KIKAN_TO                        DATE,
    KANRI_NO                        VARCHAR2(20),
    KENSU                           NUMBER(10,0),
    KOSU                            NUMBER(6,0),
    JURYO                           NUMBER(6,1),
    KEIRI_FUTAN_GAKU                NUMBER(10,0),
    UCHI_HIKAZEI_GAKU               NUMBER(10,0),
    SHOHIZEI_SOTOZEI                NUMBER(10,0),
    SHIIRE_GAKU                     NUMBER(10,0),
    MEMO                            VARCHAR2(256),
    SHIIRE_MEISAI_KAKUTEI_FLG       CHAR(1),
    URIAGE_ID                       NUMBER(18,0),
    SHUSEIBI                        DATE,
    DATA_MOTO_KBN                   CHAR(2),
    IF_RENKEI_JOKYO_FLG             CHAR(1) NOT NULL,
    IF_RENKEI_TAISHO_FLG            CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SHIIRE
    ADD(CONSTRAINT PK_TR_SHIIRE PRIMARY KEY (TAISHO_NENGETSU, EIGYOSHO_CD, SHIIRESAKI_CD, SHIIRE_KBN_CD, SHIIRE_SEQ, SHIIRE_ID, AKA_KURO_KBN) USING INDEX)
/
DROP TABLE TR_SHIIRE_SHIHARAI_KANRI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SHIIRE_SHIHARAI_KANRI
(
    TAISHO_NENGETSU                 VARCHAR2(6) NOT NULL,
    EIGYOSHO_CD                     VARCHAR2(5) NOT NULL,
    EIGYOSHO_SHIIRE_KAKUTEIBI       DATE,
    EIGYOSHO_SHIIRE_K_USER_CD       CHAR(7),
    EIGYOSHO_SHIHARAI_KAKUTEIBI     DATE,
    EIGYOSHO_SHIHARAI_K_USER_CD     CHAR(7),
    KEIRI_SHIHARAI_KAKUTEIBI        DATE,
    KEIRI_SHIHARAI_KAKUTEI_USER_CD  CHAR(7),
    FILE_OUTPUT_DATE                DATE,
    FILE_SHUTSURYOKU_USER_CD        CHAR(7),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SHIIRE_SHIHARAI_KANRI
    ADD(CONSTRAINT PK_TR_SHIIRE_SHIHARAI_KANRI PRIMARY KEY (TAISHO_NENGETSU, EIGYOSHO_CD) USING INDEX)
/
DROP TABLE MS_SHIIRESAKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHIIRESAKI
(
    SHIIRESAKI_CD                   VARCHAR2(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    SHIIRESAKI_DATA_VERSION         NUMBER(3,0) NOT NULL,
    KANKATSU_KBN                    CHAR(1) NOT NULL,
    KANKATSU_EIGYOSHO_CD            CHAR(3) NOT NULL,
    TEKIYO_MEI                      VARCHAR2(40),
    SHIIRESAKI_MEI                  VARCHAR2(40),
    SHIIRESAKI_KANA                 VARCHAR2(40),
    HOJIN_BANGO_CD                  VARCHAR2(13),
    KOKU_GAISHA_FLG                 CHAR(1) NOT NULL,
    DAIRITEN_FLG                    CHAR(1) NOT NULL,
    KANSEN_GYOSHA_FLG               CHAR(1) NOT NULL,
    CHUKEI_GYOSHA_FLG               CHAR(1) NOT NULL,
    CHARTER_GYOSHA_FLG              CHAR(1) NOT NULL,
    SONOTA_FLG                      CHAR(1) NOT NULL,
    SS_SHIIRESAKI_CD                VARCHAR2(20),
    SS_KIGYO_CD                     VARCHAR2(8),
    SONOTA_SHIYO_EIGYOSHO_CD        CHAR(3),
    KAISHA_MEI                      VARCHAR2(40),
    KAISHA_MEI_KANA                 VARCHAR2(40),
    SHITEN_EIGYOSHO_MEI             VARCHAR2(40),
    SHITEN_EIGYOSHO_KANA            VARCHAR2(40),
    BUSHO_TANTOSHA_1                VARCHAR2(40),
    BUSHO_TANTOSHA_2                VARCHAR2(40),
    YUBIN_BANGO                     VARCHAR2(7),
    JIS_CD                          CHAR(5),
    JUSHO_1                         VARCHAR2(40),
    JUSHO_2                         VARCHAR2(40),
    JUSHO_3                         VARCHAR2(40),
    JUSHO_4                         VARCHAR2(40),
    KUKO_CD                         CHAR(3),
    SHIMUKE_CHI_CD                  CHAR(7),
    SHUHAI_CHIKU                    CHAR(1),
    TEL_BANGO_1                     VARCHAR2(19),
    TEL_BANGO_2                     VARCHAR2(19),
    FAX_BANGO                       VARCHAR2(19),
    KINYU_KIKAN_MEI                 VARCHAR2(60),
    SHITEN_MEI                      VARCHAR2(40),
    KOZA_SHUBETSU                   CHAR(1),
    KOZA_BANGO                      VARCHAR2(7),
    MEIGININ_MEI                    VARCHAR2(40),
    TESURYO_FUTAN                   CHAR(1),
    SHIHARAI_JOKEN                  CHAR(1),
    KAIKAKEKIN_CD                   CHAR(1),
    MEMO                            VARCHAR2(100),
    SHINSEI_STATUS                  CHAR(2) NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHIIRESAKI
    ADD(CONSTRAINT PK_MS_SHIIRESAKI PRIMARY KEY (SHIIRESAKI_CD, TEKIYO_KAISHIBI, TEKIYO_FLG) USING INDEX)
/
DROP TABLE MS_SHIIRESAKI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHIIRESAKI_RIREKI
(
    SHIIRESAKI_CD                   VARCHAR2(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    SHIIRESAKI_DATA_VERSION         NUMBER(3,0) NOT NULL,
    KANKATSU_KBN                    CHAR(1) NOT NULL,
    KANKATSU_EIGYOSHO_CD            CHAR(3) NOT NULL,
    TEKIYO_MEI                      VARCHAR2(40),
    SHIIRESAKI_MEI                  VARCHAR2(40),
    SHIIRESAKI_KANA                 VARCHAR2(40),
    HOJIN_BANGO_CD                  VARCHAR2(13),
    KOKU_GAISHA_FLG                 CHAR(1) NOT NULL,
    DAIRITEN_FLG                    CHAR(1) NOT NULL,
    KANSEN_GYOSHA_FLG               CHAR(1) NOT NULL,
    CHUKEI_GYOSHA_FLG               CHAR(1) NOT NULL,
    CHARTER_GYOSHA_FLG              CHAR(1) NOT NULL,
    SONOTA_FLG                      CHAR(1) NOT NULL,
    SS_SHIIRESAKI_CD                VARCHAR2(20),
    SS_KIGYO_CD                     VARCHAR2(8),
    SONOTA_SHIYO_EIGYOSHO_CD        CHAR(3),
    KAISHA_MEI                      VARCHAR2(40),
    KAISHA_MEI_KANA                 VARCHAR2(40),
    SHITEN_EIGYOSHO_MEI             VARCHAR2(40),
    SHITEN_EIGYOSHO_KANA            VARCHAR2(40),
    BUSHO_TANTOSHA_1                VARCHAR2(40),
    BUSHO_TANTOSHA_2                VARCHAR2(40),
    YUBIN_BANGO                     VARCHAR2(7),
    JIS_CD                          CHAR(5),
    JUSHO_1                         VARCHAR2(40),
    JUSHO_2                         VARCHAR2(40),
    JUSHO_3                         VARCHAR2(40),
    JUSHO_4                         VARCHAR2(40),
    KUKO_CD                         CHAR(3),
    SHIMUKE_CHI_CD                  CHAR(7),
    SHUHAI_CHIKU                    CHAR(1),
    TEL_BANGO_1                     VARCHAR2(19),
    TEL_BANGO_2                     VARCHAR2(19),
    FAX_BANGO                       VARCHAR2(19),
    KINYU_KIKAN_MEI                 VARCHAR2(60),
    SHITEN_MEI                      VARCHAR2(40),
    KOZA_SHUBETSU                   CHAR(1),
    KOZA_BANGO                      VARCHAR2(7),
    MEIGININ_MEI                    VARCHAR2(40),
    TESURYO_FUTAN                   CHAR(1),
    SHIHARAI_JOKEN                  CHAR(1),
    KAIKAKEKIN_CD                   CHAR(1),
    MEMO                            VARCHAR2(100),
    SHINSEI_STATUS                  CHAR(2) NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHIIRESAKI_RIREKI
    ADD(CONSTRAINT PK_MS_SHIIRESAKI_RIREKI PRIMARY KEY (SHIIRESAKI_CD, TEKIYO_KAISHIBI, TEKIYO_FLG, SHIIRESAKI_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_SHIIRE_YOTEI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHIIRE_YOTEI
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    SHIIRESAKI_CD                   VARCHAR2(5) NOT NULL,
    SHIIRE_KBN_CD                   CHAR(4) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    SHIIRE_YOTEI_DATA_VERSION       NUMBER(3,0) NOT NULL,
    TANI                            CHAR(1) NOT NULL,
    TANKA                           NUMBER(10,0) NOT NULL,
    YOBIBETSU_SHIIRE_GAKU_NISSHU    NUMBER(10,0),
    YOBIBETSU_SHIIRE_GAKU_GETSU     NUMBER(10,0),
    YOBIBETSU_SHIIRE_GAKU_KA        NUMBER(10,0),
    YOBIBETSU_SHIIRE_GAKU_SUI       NUMBER(10,0),
    YOBIBETSU_SHIIRE_GAKU_MOKU      NUMBER(10,0),
    YOBIBETSU_SHIIRE_GAKU_KIN       NUMBER(10,0),
    YOBIBETSU_SHIIRE_GAKU_DO        NUMBER(10,0),
    TEKIYO_MEI                      VARCHAR2(40),
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHIIRE_YOTEI
    ADD(CONSTRAINT PK_MS_SHIIRE_YOTEI PRIMARY KEY (EIGYOSHO_CD, SHIIRESAKI_CD, SHIIRE_KBN_CD, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE MS_SHIIRE_YOTEI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHIIRE_YOTEI_RIREKI
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    SHIIRESAKI_CD                   VARCHAR2(5) NOT NULL,
    SHIIRE_KBN_CD                   CHAR(4) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    SHIIRE_YOTEI_DATA_VERSION       NUMBER(3,0) NOT NULL,
    TANI                            CHAR(1) NOT NULL,
    TANKA                           NUMBER(10,0) NOT NULL,
    YOBIBETSU_SHIIRE_GAKU_NISSHU    NUMBER(10,0),
    YOBIBETSU_SHIIRE_GAKU_GETSU     NUMBER(10,0),
    YOBIBETSU_SHIIRE_GAKU_KA        NUMBER(10,0),
    YOBIBETSU_SHIIRE_GAKU_SUI       NUMBER(10,0),
    YOBIBETSU_SHIIRE_GAKU_MOKU      NUMBER(10,0),
    YOBIBETSU_SHIIRE_GAKU_KIN       NUMBER(10,0),
    YOBIBETSU_SHIIRE_GAKU_DO        NUMBER(10,0),
    TEKIYO_MEI                      VARCHAR2(40),
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHIIRE_YOTEI_RIREKI
    ADD(CONSTRAINT PK_MS_SHIIRE_YOTEI_RIREKI PRIMARY KEY (EIGYOSHO_CD, SHIIRESAKI_CD, SHIIRE_KBN_CD, TEKIYO_KAISHIBI, SHIIRE_YOTEI_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_SHIIRE_YOTEI_MEISAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHIIRE_YOTEI_MEISAI
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    SHIIRESAKI_CD                   VARCHAR2(5) NOT NULL,
    SHIIRE_KBN_CD                   CHAR(4) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    MEISAI_NO                       NUMBER(5,0) NOT NULL,
    SHIIRE_YOTEI_DATA_VERSION       NUMBER(3,0) NOT NULL,
    KANRI_NO                        VARCHAR2(20),
    KEIHI_FUTAN_GAKU                NUMBER(10,0),
    UCHI_HIKAZEI_GAKU               NUMBER(10,0),
    SHOHIZEI_SOTOZEI                NUMBER(10,0),
    SHIIRE_GAKU                     NUMBER(10,0),
    MEMO                            VARCHAR2(256),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHIIRE_YOTEI_MEISAI
    ADD(CONSTRAINT PK_MS_SHIIRE_YOTEI_MEISAI PRIMARY KEY (MEISAI_NO, EIGYOSHO_CD, SHIIRESAKI_CD, SHIIRE_KBN_CD, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE MS_SHIIRE_YOTEI_MEISAI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHIIRE_YOTEI_MEISAI_RIREKI
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    SHIIRESAKI_CD                   VARCHAR2(5) NOT NULL,
    SHIIRE_KBN_CD                   CHAR(4) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    MEISAI_NO                       NUMBER(5,0) NOT NULL,
    SHIIRE_YOTEI_DATA_VERSION       NUMBER(3,0) NOT NULL,
    KANRI_NO                        VARCHAR2(20),
    KEIHI_FUTAN_GAKU                NUMBER(10,0),
    UCHI_HIKAZEI_GAKU               NUMBER(10,0),
    SHOHIZEI_SOTOZEI                NUMBER(10,0),
    SHIIRE_GAKU                     NUMBER(10,0),
    MEMO                            VARCHAR2(256),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHIIRE_YOTEI_MEISAI_RIREKI
    ADD(CONSTRAINT PK_MS_SHIIRE_YOTEI_MEISAI_RIREKI PRIMARY KEY (EIGYOSHO_CD, SHIIRESAKI_CD, SHIIRE_KBN_CD, TEKIYO_KAISHIBI, MEISAI_NO, SHIIRE_YOTEI_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_SHIIRE_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SHIIRE_RIREKI
(
    TAISHO_NENGETSU                 VARCHAR2(6) NOT NULL,
    EIGYOSHO_CD                     VARCHAR2(5) NOT NULL,
    SHIIRESAKI_CD                   VARCHAR2(5) NOT NULL,
    SHIIRE_KBN_CD                   CHAR(4) NOT NULL,
    SHIIRE_SEQ                      NUMBER(3,0) NOT NULL,
    SHIIRE_ID                       NUMBER(15,0) NOT NULL,
    SHIIRE_DATA_VERSION             NUMBER(18,0) NOT NULL,
    KEIJO_KBN                       CHAR(1) NOT NULL,
    SHIIRE_KEIJO_HI                 DATE NOT NULL,
    KEIRI_KEIJO_HI                  DATE NOT NULL,
    KIKAN_FROM                      DATE,
    KIKAN_TO                        DATE,
    KANRI_NO                        VARCHAR2(20),
    KENSU                           NUMBER(10,0),
    KOSU                            NUMBER(6,0),
    JURYO                           NUMBER(6,1),
    KEIRI_FUTAN_GAKU                NUMBER(10,0),
    UCHI_HIKAZEI_GAKU               NUMBER(10,0),
    SHOHIZEI_SOTOZEI                NUMBER(10,0),
    SHIIRE_GAKU                     NUMBER(10,0),
    MEMO                            VARCHAR2(256),
    SHIIRE_MEISAI_KAKUTEI_FLG       CHAR(1),
    URIAGE_ID                       NUMBER(18,0),
    SHUSEIBI                        DATE,
    DATA_MOTO_KBN                   CHAR(2),
    IF_RENKEI_JOKYO_FLG             CHAR(1) NOT NULL,
    IF_RENKEI_TAISHO_FLG            CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SHIIRE_RIREKI
    ADD(CONSTRAINT PK_TR_SHIIRE_RIREKI PRIMARY KEY (TAISHO_NENGETSU, EIGYOSHO_CD, SHIIRESAKI_CD, SHIIRE_KBN_CD, SHIIRE_SEQ, SHIIRE_ID, SHIIRE_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_SHIIRE_RYOKIN_KOMOKU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHIIRE_RYOKIN_KOMOKU
(
    SHIIRE_KBN_CD                   CHAR(4) NOT NULL,
    SHIIRE_KBN_MEISHO               VARCHAR2(40),
    NYURYOKU_KANO_FLG               CHAR(1) NOT NULL,
    AP_SHUTSURYOKU_FLG              CHAR(1) NOT NULL,
    SHORI_KAMOKU_CD                 CHAR(4),
    HOJO_KAMOKU_CD                  CHAR(2),
    KANRI_BANGO_KOMOKU_MEISHO       VARCHAR2(40),
    KANRI_BANGO_KATA                CHAR(1),
    KANRI_BANGO_NAGASA              NUMBER(2,0),
    KANRI_BANGO_HISSU_FLG           CHAR(1),
    KIKAN_HISSU_FLG                 CHAR(1),
    KENSU_HISSU_FLG                 CHAR(1),
    KOSU_HISSU_FLG                  CHAR(1),
    JURYO_HISSU_FLG                 CHAR(1),
    KIKAN_KBN                       CHAR(1),
    MEMO_GET_SQL                    CLOB,
    URIAGE_TEISEI_HYOJI_FLG         CHAR(1) NOT NULL,
    SHIIRE_DATA_SAKUSEI_BATCH_FLG   CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHIIRE_RYOKIN_KOMOKU
    ADD(CONSTRAINT PK_MS_SHIIRE_RYOKIN_KOMOKU PRIMARY KEY (SHIIRE_KBN_CD) USING INDEX)
/
DROP TABLE TR_SHIWAKE_LABEL_HAKKO_JISSEKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SHIWAKE_LABEL_HAKKO_JISSEKI
(
    OKURIJO_NO                      CHAR(13) NOT NULL,
    OKURIJO_NO_EDABAN               VARCHAR2(3) NOT NULL,
    HHT_BANGO                       CHAR(15),
    HOKOKU_TEN                      VARCHAR2(5),
    JUGYOIN_BANGO                   CHAR(7),
    SHABAN                          CHAR(5),
    SHIMUKE_CHI_CD                  CHAR(7),
    YUSO_HOHO_CD                    CHAR(2),
    HAKKO_MAISU                     NUMBER(4,0),
    SCAN_HIZUKE                     CHAR(8),
    SCAN_JIKAN                      CHAR(6),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SHIWAKE_LABEL_HAKKO_JISSEKI
    ADD(CONSTRAINT PK_TR_SHIWAKE_LABEL_HAKKO_JISSEKI PRIMARY KEY (OKURIJO_NO_EDABAN, OKURIJO_NO) USING INDEX)
/
DROP TABLE MS_SHIYO_KINO_GROUP CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHIYO_KINO_GROUP
(
    SHIYO_KINO_GROUP_ID             CHAR(3) NOT NULL,
    SHIYO_GROUP_SHUBETSU            CHAR(2) NOT NULL,
    SHIYO_GROUP_MEI                 VARCHAR2(40) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHIYO_KINO_GROUP
    ADD(CONSTRAINT PK_MS_SHIYO_KINO_GROUP PRIMARY KEY (SHIYO_KINO_GROUP_ID) USING INDEX)
/
DROP TABLE TR_SHIYO_JOHO_KANRI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SHIYO_JOHO_KANRI
(
    KINO_ID                         VARCHAR2(8) NOT NULL,
    MASTER_TABLE_BUTSURIMEI         VARCHAR2(128) NOT NULL,
    KEY_JOHO                        VARCHAR2(65) NOT NULL,
    KOSHIN_SHA                      VARCHAR2(8) NOT NULL,
    SHIYO_HIZUKE                    DATE NOT NULL,
    SHIYO_KINO_GROUP_ID             CHAR(3) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SHIYO_JOHO_KANRI
    ADD(CONSTRAINT PK_TR_SHIYO_JOHO_KANRI PRIMARY KEY (KINO_ID, MASTER_TABLE_BUTSURIMEI, KEY_JOHO, KOSHIN_SHA) USING INDEX)
/
DROP TABLE TR_SHIHARAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SHIHARAI
(
    TAISHO_NENGETSU                 VARCHAR2(6) NOT NULL,
    DEMPYO_NO                       CHAR(8) NOT NULL,
    AKA_KURO_KBN                    CHAR(1) NOT NULL,
    KEIJOBI                         CHAR(2),
    EIGYOSHO_CD                     VARCHAR2(5),
    SHIIRESAKI_CD                   VARCHAR2(5),
    SHIIRE_KBN_CD                   CHAR(4),
    ZEI_SHORI_CD                    CHAR(3),
    SHIHARAI_HOHO                   CHAR(2),
    SHUKEI_KEIRI_FUTAN_GAKU         NUMBER(10,0),
    UCHI_HIKAZEI_GAKU_SHUKEI        NUMBER(10,0),
    SHUKEI_SHOHIZEI_GAIZEI          NUMBER(10,0),
    SHUKEI_SHIHARAI_GAKU            NUMBER(10,0),
    SEIKYU_KEIHI_FUTAN_GAKU         NUMBER(10,0),
    UCHI_HIKAZEI_GAKU_SEIKYU        NUMBER(10,0),
    SEIKYU_SHOHIZEI_GAIZEI          NUMBER(10,0),
    SEIKYU_SHIHARAI_GAKU            NUMBER(10,0),
    DATA_MOTO                       CHAR(2),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SHIHARAI
    ADD(CONSTRAINT PK_TR_SHIHARAI PRIMARY KEY (TAISHO_NENGETSU, DEMPYO_NO, AKA_KURO_KBN) USING INDEX)
/
DROP TABLE MS_SHIHARAI_HOHO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHIHARAI_HOHO
(
    MOTO_CHAKU_KBN                  CHAR(2),
    SHIHARAI_KBN                    CHAR(2) NOT NULL,
    SHIHARAI_KBN_MEI                VARCHAR2(20) NOT NULL,
    SEIKYUSAKI_SHITEI_KA_FLG        CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHIHARAI_HOHO
    ADD(CONSTRAINT PK_MS_SHIHARAI_HOHO PRIMARY KEY (SHIHARAI_KBN) USING INDEX)
/
DROP TABLE MS_SHISETSU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHISETSU
(
    SHISETSU_CD                     CHAR(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    SHISETSU_DATA_VERSION           NUMBER(3,0) NOT NULL,
    SHISETSU_MEI                    VARCHAR2(40),
    KANKATSU_EIGYOSHO_CD            CHAR(3),
    YUKO_TSUBOSU                    NUMBER(9,0),
    SHIIRE_NE                       NUMBER(10,0),
    YUBIN_BANGO                     VARCHAR2(7),
    JIS_CD                          CHAR(5),
    JUSHO_1                         VARCHAR2(40),
    JUSHO_2                         VARCHAR2(40),
    JUSHO_3                         VARCHAR2(40),
    JUSHO_4                         VARCHAR2(40),
    JUSHO                           VARCHAR2(160),
    TEL_BANGO                       VARCHAR2(19),
    SHIKICHI_MENSEKI                NUMBER(8,0),
    NOBEYUKA_MENSEKI                NUMBER(8,0),
    TEKIYO_MEI                      VARCHAR2(40),
    SHINSEI_STATUS                  CHAR(2) NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHISETSU
    ADD(CONSTRAINT PK_MS_SHISETSU PRIMARY KEY (SHISETSU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG) USING INDEX)
/
DROP TABLE MS_SHISETSU_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHISETSU_RIREKI
(
    SHISETSU_CD                     CHAR(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    SHISETSU_DATA_VERSION           NUMBER(3,0) NOT NULL,
    SHISETSU_MEI                    VARCHAR2(40),
    KANKATSU_EIGYOSHO_CD            CHAR(3),
    YUKO_TSUBOSU                    NUMBER(9,0),
    SHIIRE_NE                       NUMBER(10,0),
    YUBIN_BANGO                     VARCHAR2(7),
    JIS_CD                          CHAR(5),
    JUSHO_1                         VARCHAR2(40),
    JUSHO_2                         VARCHAR2(40),
    JUSHO_3                         VARCHAR2(40),
    JUSHO_4                         VARCHAR2(40),
    JUSHO                           VARCHAR2(160),
    TEL_BANGO                       VARCHAR2(19),
    SHIKICHI_MENSEKI                NUMBER(8,0),
    NOBEYUKA_MENSEKI                NUMBER(8,0),
    TEKIYO_MEI                      VARCHAR2(40),
    SHINSEI_STATUS                  CHAR(2) NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHISETSU_RIREKI
    ADD(CONSTRAINT PK_MS_SHISETSU_RIREKI PRIMARY KEY (SHISETSU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG, SHISETSU_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_SHISETSU_HYOJI_MEI_JOHO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHISETSU_HYOJI_MEI_JOHO
(
    JIS_CD                          CHAR(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    JUSHO_KANNAIHAISO_SEQ           NUMBER(3,0) NOT NULL,
    SHISETSU_HYOJI_MEI_SEQ          NUMBER(3,0) NOT NULL,
    JUSHO_JIS_DATA_VERSION          NUMBER(3,0) NOT NULL,
    HYOJI_MEI                       VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHISETSU_HYOJI_MEI_JOHO
    ADD(CONSTRAINT PK_MS_SHISETSU_HYOJI_MEI_JOHO PRIMARY KEY (JIS_CD, TEKIYO_KAISHIBI, JUSHO_KANNAIHAISO_SEQ, SHISETSU_HYOJI_MEI_SEQ) USING INDEX)
/
DROP TABLE MS_SHISETSU_HYOJI_MEI_JOHO_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHISETSU_HYOJI_MEI_JOHO_RIREKI
(
    JIS_CD                          CHAR(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    JUSHO_KANNAIHAISO_SEQ           NUMBER(3,0) NOT NULL,
    SHISETSU_HYOJI_MEI_SEQ          NUMBER(3,0) NOT NULL,
    JUSHO_JIS_DATA_VERSION          NUMBER(3,0) NOT NULL,
    HYOJI_MEI                       VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHISETSU_HYOJI_MEI_JOHO_RIREKI
    ADD(CONSTRAINT PK_MS_SHISETSU_HYOJI_MEI_JOHO_RIREKI PRIMARY KEY (JIS_CD, TEKIYO_KAISHIBI, JUSHO_KANNAIHAISO_SEQ, SHISETSU_HYOJI_MEI_SEQ, JUSHO_JIS_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_JITA_SHA_OKURIJO_NO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_JITA_SHA_OKURIJO_NO
(
    KLS_OKURIJO_NO                  CHAR(13) NOT NULL,
    HAKKO_NICHIJI                   DATE NOT NULL,
    DAIRITEN_CD                     VARCHAR2(5) NOT NULL,
    TASHA_OKURIJO_NO                CHAR(20) NOT NULL,
    OKURIJO_HAKKO_MOTO              VARCHAR2(20),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_JITA_SHA_OKURIJO_NO
    ADD(CONSTRAINT PK_TR_JITA_SHA_OKURIJO_NO PRIMARY KEY (KLS_OKURIJO_NO, HAKKO_NICHIJI) USING INDEX)
/
DROP TABLE MS_JIDO_SEIKYU_KOMOKU_SONOTA_SEIKYU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_JIDO_SEIKYU_KOMOKU_SONOTA_SEIKYU
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    RYOKIN_KOMOKU_1_CD              CHAR(2) NOT NULL,
    RYOKIN_KOMOKU_2_CD              CHAR(3) NOT NULL,
    NYURYOKU_HIZUKE                 VARCHAR2(2) NOT NULL,
    KYUJITSU_KEIJO_FLG              CHAR(1) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    JIDO_SEIKYU_KOMOKU_SONOTA_SEIKYU_DATA_VERSION NUMBER(3,0) NOT NULL,
    TANKA                           NUMBER(10,0),
    TANI                            CHAR(3),
    SURYO                           NUMBER(9,0),
    KINGAKU                         NUMBER(10,0),
    TEKIYO_MEI                      VARCHAR2(40),
    SHINSEI_STATUS                  CHAR(2) NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_JIDO_SEIKYU_KOMOKU_SONOTA_SEIKYU
    ADD(CONSTRAINT PK_MS_JIDO_SEIKYU_KOMOKU_SONOTA_SEIKYU PRIMARY KEY (KOKYAKU_CD, RYOKIN_KOMOKU_1_CD, RYOKIN_KOMOKU_2_CD, NYURYOKU_HIZUKE, KYUJITSU_KEIJO_FLG, TEKIYO_KAISHIBI, TEKIYO_FLG) USING INDEX)
/
DROP TABLE MS_JIDO_SEIKYU_KOMOKU_SONOTA_SEIKYU_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_JIDO_SEIKYU_KOMOKU_SONOTA_SEIKYU_RIREKI
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    RYOKIN_KOMOKU_1_CD              CHAR(2) NOT NULL,
    RYOKIN_KOMOKU_2_CD              CHAR(3) NOT NULL,
    NYURYOKU_HIZUKE                 VARCHAR2(2) NOT NULL,
    KYUJITSU_KEIJO_FLG              CHAR(1) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    JIDO_SEIKYU_KOMOKU_SONOTA_SEIKYU_DATA_VERSION NUMBER(3,0) NOT NULL,
    TANKA                           NUMBER(10,0),
    TANI                            CHAR(3),
    SURYO                           NUMBER(9,0),
    KINGAKU                         NUMBER(10,0),
    TEKIYO_MEI                      VARCHAR2(40),
    SHINSEI_STATUS                  CHAR(2) NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_JIDO_SEIKYU_KOMOKU_SONOTA_SEIKYU_RIREKI
    ADD(CONSTRAINT PK_MS_JIDO_SEIKYU_KOMOKU_SONOTA_SEIKYU_RIREKI PRIMARY KEY (KOKYAKU_CD, RYOKIN_KOMOKU_1_CD, RYOKIN_KOMOKU_2_CD, NYURYOKU_HIZUKE, KYUJITSU_KEIJO_FLG, TEKIYO_KAISHIBI, TEKIYO_FLG, JIDO_SEIKYU_KOMOKU_SONOTA_SEIKYU_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_JIDO_SEIKYU_KOMOKU_SONOTA_URIAGE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_JIDO_SEIKYU_KOMOKU_SONOTA_URIAGE
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    URIAGEBI_FROM                   VARCHAR2(2) NOT NULL,
    URIAGEBI_TO                     VARCHAR2(2) NOT NULL,
    KYUJITSU_KEIJO_FLG              CHAR(1) NOT NULL,
    JIDO_SEIKYU_KOMOKU_SONOTA_URIAGE_DATA_VERSION NUMBER(3,0) NOT NULL,
    ODAIMOKU                        VARCHAR2(40) NOT NULL,
    DEMPYO_SHUBETSU_CD              CHAR(2),
    RYOKIN_KOMOKU_CD                CHAR(3) NOT NULL,
    HYOJI_MEI                       VARCHAR2(40),
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    TANKA                           NUMBER(10,0),
    TANI                            CHAR(3),
    SURYO                           NUMBER(9,0),
    KINGAKU                         NUMBER(10,0),
    SEIKYUSHO_BIKO_1                VARCHAR2(40),
    SHINSEI_STATUS                  CHAR(2) NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    TEKIYO_MEI                      VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_JIDO_SEIKYU_KOMOKU_SONOTA_URIAGE
    ADD(CONSTRAINT PK_MS_JIDO_SEIKYU_KOMOKU_SONOTA_URIAGE PRIMARY KEY (KOKYAKU_CD, URIAGEBI_FROM, URIAGEBI_TO, KYUJITSU_KEIJO_FLG, RYOKIN_KOMOKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG) USING INDEX)
/
DROP TABLE MS_JIDO_SEIKYU_KOMOKU_SONOTA_URIAGE_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_JIDO_SEIKYU_KOMOKU_SONOTA_URIAGE_RIREKI
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    URIAGEBI_FROM                   VARCHAR2(2) NOT NULL,
    URIAGEBI_TO                     VARCHAR2(2) NOT NULL,
    KYUJITSU_KEIJO_FLG              CHAR(1) NOT NULL,
    JIDO_SEIKYU_KOMOKU_SONOTA_URIAGE_DATA_VERSION NUMBER(3,0) NOT NULL,
    ODAIMOKU                        VARCHAR2(40) NOT NULL,
    DEMPYO_SHUBETSU_CD              CHAR(2),
    RYOKIN_KOMOKU_CD                CHAR(3) NOT NULL,
    HYOJI_MEI                       VARCHAR2(40),
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    TANKA                           NUMBER(10,0),
    TANI                            CHAR(3),
    SURYO                           NUMBER(9,0),
    KINGAKU                         NUMBER(10,0),
    SEIKYUSHO_BIKO_1                VARCHAR2(40),
    SHINSEI_STATUS                  CHAR(2) NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    TEKIYO_MEI                      VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_JIDO_SEIKYU_KOMOKU_SONOTA_URIAGE_RIREKI
    ADD(CONSTRAINT PK_MS_JIDO_SEIKYU_KOMOKU_SONOTA_URIAGE_RIREKI PRIMARY KEY (KOKYAKU_CD, URIAGEBI_FROM, URIAGEBI_TO, KYUJITSU_KEIJO_FLG, JIDO_SEIKYU_KOMOKU_SONOTA_URIAGE_DATA_VERSION, RYOKIN_KOMOKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG) USING INDEX)
/
DROP TABLE MS_JIDO_SEIKYU_KOMOKU_YUSO_URIAGE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_JIDO_SEIKYU_KOMOKU_YUSO_URIAGE
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    RYOKIN_KOMOKU_CD                CHAR(3) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    JIDO_SEIKYU_KOMOKU_YUSO_URIAGE_DATA_VERSION NUMBER(3,0) NOT NULL,
    TANKA                           NUMBER(10,0),
    TANI                            VARCHAR2(3),
    SURYO                           NUMBER(9,0),
    URIAGE_KOSU_SHIYO_FLG           CHAR(1),
    KINGAKU                         NUMBER(10,0),
    TEKIYO_MEI                      VARCHAR2(40),
    SHINSEI_STATUS                  CHAR(2) NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_JIDO_SEIKYU_KOMOKU_YUSO_URIAGE
    ADD(CONSTRAINT PK_MS_JIDO_SEIKYU_KOMOKU_YUSO_URIAGE PRIMARY KEY (KOKYAKU_CD, RYOKIN_KOMOKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG) USING INDEX)
/
DROP TABLE MS_JIDO_SEIKYU_KOMOKU_YUSO_URIAGE_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_JIDO_SEIKYU_KOMOKU_YUSO_URIAGE_RIREKI
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    RYOKIN_KOMOKU_CD                CHAR(3) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    JIDO_SEIKYU_KOMOKU_YUSO_URIAGE_DATA_VERSION NUMBER(3,0) NOT NULL,
    TANKA                           NUMBER(10,0),
    TANI                            VARCHAR2(3),
    SURYO                           NUMBER(9,0),
    URIAGE_KOSU_SHIYO_FLG           CHAR(1),
    KINGAKU                         NUMBER(10,0),
    TEKIYO_MEI                      VARCHAR2(40),
    SHINSEI_STATUS                  CHAR(2) NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_JIDO_SEIKYU_KOMOKU_YUSO_URIAGE_RIREKI
    ADD(CONSTRAINT PK_MS_JIDO_SEIKYU_KOMOKU_YUSO_URIAGE_RIREKI PRIMARY KEY (KOKYAKU_CD, RYOKIN_KOMOKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG, JIDO_SEIKYU_KOMOKU_YUSO_URIAGE_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_JIKKO_KEKKA_COLUMN_KANRI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_JIKKO_KEKKA_COLUMN_KANRI
(
    TORIKOMI_TAISHO_TABLE_MEI       VARCHAR2(30) NOT NULL,
    JIKKO_KEKKA_COLUMN_SEQ          NUMBER(3,0) NOT NULL,
    COLUMN_MEI_BUTSURI              VARCHAR2(30),
    COLUMN_MEI_RONRI                VARCHAR2(60),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_JIKKO_KEKKA_COLUMN_KANRI
    ADD(CONSTRAINT PK_TR_JIKKO_KEKKA_COLUMN_KANRI PRIMARY KEY (TORIKOMI_TAISHO_TABLE_MEI, JIKKO_KEKKA_COLUMN_SEQ) USING INDEX)
/
DROP TABLE TR_JIKKO_KEKKA_MAIL_SOSHINSAKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_JIKKO_KEKKA_MAIL_SOSHINSAKI
(
    EDI_SETTEI_ID                   CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    JIKKO_KEKKA_MAIL_SOSHINSAKI_SEQ NUMBER(2,0) NOT NULL,
    EDI_SETTEI_DATA_VERSION         NUMBER(3,0) NOT NULL,
    SOSHINSAKI_ADDRESS              VARCHAR2(80),
    SHORI_KAISHIJI_SOSHIN_FLG       CHAR(1) NOT NULL,
    SEIJOJI_SOSHIN_FLG              CHAR(1) NOT NULL,
    ICHIBU_IJOJI_SOSHIN_FLG         CHAR(1) NOT NULL,
    IJO_SHURYO_JI_SOSHIN_FLG        CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_JIKKO_KEKKA_MAIL_SOSHINSAKI
    ADD(CONSTRAINT PK_TR_JIKKO_KEKKA_MAIL_SOSHINSAKI PRIMARY KEY (EDI_SETTEI_ID, TEKIYO_KAISHIBI, JIKKO_KEKKA_MAIL_SOSHINSAKI_SEQ) USING INDEX)
/
DROP TABLE TR_JIKKO_KEKKA_MAIL_SOSHINSAKI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_JIKKO_KEKKA_MAIL_SOSHINSAKI_RIREKI
(
    EDI_SETTEI_ID                   CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    JIKKO_KEKKA_MAIL_SOSHINSAKI_SEQ NUMBER(2,0) NOT NULL,
    EDI_SETTEI_DATA_VERSION         NUMBER(3,0) NOT NULL,
    SOSHINSAKI_ADDRESS              VARCHAR2(80),
    SHORI_KAISHIJI_SOSHIN_FLG       CHAR(1) NOT NULL,
    SEIJOJI_SOSHIN_FLG              CHAR(1) NOT NULL,
    ICHIBU_IJOJI_SOSHIN_FLG         CHAR(1) NOT NULL,
    IJO_SHURYO_JI_SOSHIN_FLG        CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_JIKKO_KEKKA_MAIL_SOSHINSAKI_RIREKI
    ADD(CONSTRAINT PK_TR_JIKKO_KEKKA_MAIL_SOSHINSAKI_RIREKI PRIMARY KEY (EDI_SETTEI_ID, TEKIYO_KAISHIBI, JIKKO_KEKKA_MAIL_SOSHINSAKI_SEQ, EDI_SETTEI_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_JISSEKI_MAWB_BANGO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_JISSEKI_MAWB_BANGO
(
    MAWB_BANGO                      VARCHAR2(8) NOT NULL,
    KOKU_GAISHA_CD                  VARCHAR2(3) NOT NULL,
    HAKKEN_EIGYOSHO_CD              CHAR(3) NOT NULL,
    HAIFUSAKI_EIGYOSHO_CD           CHAR(3) NOT NULL,
    MAWB_TOROKU_ID                  NUMBER(5,0) NOT NULL,
    MAWB_HAIFU_ID                   NUMBER(5,0) NOT NULL,
    MAWB_DATA_VERSION               NUMBER(3,0),
    TOSAI_HIZUKE                    DATE,
    TOSAI_BIN_MEI                   VARCHAR2(3),
    SHISAKU_TEKIYO_HIZUKE           DATE NOT NULL,
    SHISAKU_TEKIYO_BIN_MEI          VARCHAR2(3) NOT NULL,
    SHUPPATSUCHI_KUKO_CD            CHAR(3),
    TOCHAKUCHI_KUKO_CD              CHAR(3) NOT NULL,
    HIMMOKU_MEISAI_CD               VARCHAR2(2),
    KOSU                            NUMBER(4,0),
    TOSAI_JURYO                     NUMBER(7,1) NOT NULL,
    TEKIYO_JURYO                    NUMBER(7,1),
    SAITE_TOSAI_JURYO               NUMBER(7,1),
    IPPAN_UNCHIN                    NUMBER(10,0),
    TEKIYO_UNCHIN                   NUMBER(10,0) NOT NULL,
    DAIRITEN_TESURYO                NUMBER(10,0),
    SHIHARAI_KINGAKU_ZEIKOMI        NUMBER(10,0) NOT NULL,
    KOGUCHI_OKURIJO_NO              CHAR(13),
    BIKO                            VARCHAR2(40),
    UNCHIN_SHUBETSU                 VARCHAR2(2),
    SHISAKU_BANGO                   VARCHAR2(20),
    SHISAKU_TEKIYO_KIJUN            VARCHAR2(15),
    SHISAKU_RATE                    NUMBER(5,1),
    CONTAINER_NO_1                  VARCHAR2(6),
    CONTAINER_NO_2                  VARCHAR2(6),
    CONTAINER_NO_3                  VARCHAR2(6),
    CONTAINER_NO_4                  VARCHAR2(6),
    CONTAINER_NO_5                  VARCHAR2(6),
    CONTAINER_NO_6                  VARCHAR2(6),
    CONTAINER_NO_7                  VARCHAR2(6),
    CONTAINER_NO_8                  VARCHAR2(6),
    CONTAINER_NO_9                  VARCHAR2(6),
    CONTAINER_NO_10                 VARCHAR2(6),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_JISSEKI_MAWB_BANGO
    ADD(CONSTRAINT PK_TR_JISSEKI_MAWB_BANGO PRIMARY KEY (MAWB_BANGO, KOKU_GAISHA_CD, HAKKEN_EIGYOSHO_CD, HAIFUSAKI_EIGYOSHO_CD, MAWB_TOROKU_ID, MAWB_HAIFU_ID) USING INDEX)
/
DROP TABLE TR_JISSEKI_MAWB_BANGO_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_JISSEKI_MAWB_BANGO_RIREKI
(
    MAWB_BANGO                      VARCHAR2(8) NOT NULL,
    KOKU_GAISHA_CD                  VARCHAR2(3) NOT NULL,
    HAKKEN_EIGYOSHO_CD              CHAR(3) NOT NULL,
    HAIFUSAKI_EIGYOSHO_CD           CHAR(3) NOT NULL,
    MAWB_TOROKU_ID                  NUMBER(5,0) NOT NULL,
    MAWB_HAIFU_ID                   NUMBER(5,0) NOT NULL,
    MAWB_DATA_VERSION               NUMBER(3,0) NOT NULL,
    TOSAI_HIZUKE                    DATE,
    TOSAI_BIN_MEI                   VARCHAR2(3),
    SHISAKU_TEKIYO_HIZUKE           DATE NOT NULL,
    SHISAKU_TEKIYO_BIN_MEI          VARCHAR2(3) NOT NULL,
    SHUPPATSUCHI_KUKO_CD            CHAR(3),
    TOCHAKUCHI_KUKO_CD              CHAR(3) NOT NULL,
    HIMMOKU_MEISAI_CD               VARCHAR2(2),
    KOSU                            NUMBER(4,0),
    TOSAI_JURYO                     NUMBER(7,1) NOT NULL,
    TEKIYO_JURYO                    NUMBER(7,1),
    SAITE_TOSAI_JURYO               NUMBER(7,1),
    IPPAN_UNCHIN                    NUMBER(10,0),
    TEKIYO_UNCHIN                   NUMBER(10,0) NOT NULL,
    DAIRITEN_TESURYO                NUMBER(10,0),
    SHIHARAI_KINGAKU_ZEIKOMI        NUMBER(10,0) NOT NULL,
    KOGUCHI_OKURIJO_NO              CHAR(13),
    BIKO                            VARCHAR2(40),
    UNCHIN_SHUBETSU                 VARCHAR2(2),
    SHISAKU_BANGO                   VARCHAR2(20),
    SHISAKU_TEKIYO_KIJUN            VARCHAR2(15),
    SHISAKU_RATE                    NUMBER(5,1),
    CONTAINER_NO_1                  VARCHAR2(6),
    CONTAINER_NO_2                  VARCHAR2(6),
    CONTAINER_NO_3                  VARCHAR2(6),
    CONTAINER_NO_4                  VARCHAR2(6),
    CONTAINER_NO_5                  VARCHAR2(6),
    CONTAINER_NO_6                  VARCHAR2(6),
    CONTAINER_NO_7                  VARCHAR2(6),
    CONTAINER_NO_8                  VARCHAR2(6),
    CONTAINER_NO_9                  VARCHAR2(6),
    CONTAINER_NO_10                 VARCHAR2(6),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_JISSEKI_MAWB_BANGO_RIREKI
    ADD(CONSTRAINT PK_TR_JISSEKI_MAWB_BANGO_RIREKI PRIMARY KEY (MAWB_BANGO, KOKU_GAISHA_CD, HAKKEN_EIGYOSHO_CD, HAIFUSAKI_EIGYOSHO_CD, MAWB_TOROKU_ID, MAWB_HAIFU_ID, MAWB_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_SHASHIN_FUKA_JOHO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SHASHIN_FUKA_JOHO
(
    OKURIJO_NO                      CHAR(13) NOT NULL,
    OKURIJO_NO_EDABAN               VARCHAR2(3) NOT NULL,
    SHASHIN_FUKA_JOHO_SEQ           NUMBER(3,0) NOT NULL,
    HOKOKU_TEN                      VARCHAR2(5) NOT NULL,
    TRACE_SHUBETSU                  CHAR(2) NOT NULL,
    SHASHIN_FILE_MEI                VARCHAR2(200),
    SHASHIN_FILE_PASS_JOHO          VARCHAR2(512),
    KEITAI_DENWA_BANGO              VARCHAR2(19),
    MEMO                            VARCHAR2(200),
    SOSHIN_HIZUKE                   CHAR(8),
    SOSHIN_JIKAN                    CHAR(6),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SHASHIN_FUKA_JOHO
    ADD(CONSTRAINT PK_TR_SHASHIN_FUKA_JOHO PRIMARY KEY (OKURIJO_NO, OKURIJO_NO_EDABAN, SHASHIN_FUKA_JOHO_SEQ) USING INDEX)
/
DROP TABLE MS_SHASHU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHASHU
(
    SHASHU_CD                       CHAR(2) NOT NULL,
    SHASHU_MEI                      VARCHAR2(20) NOT NULL,
    POWER_GATE_RIMBO_KAHI_FLG       CHAR(1),
    POWER_GATE_UNIC_KAHI_FLG        CHAR(1),
    POWER_GATE_AIR_SUS_KAHI_FLG     CHAR(1),
    POWER_GATE_KUCHO_KAHI_FLG       CHAR(1),
    RIMBO_UNIC_KAHI_FLG             CHAR(1),
    RIMBO_AIR_SUS_KAHI_FLG          CHAR(1),
    RIMBO_KUCHO_KAHI_FLG            CHAR(1),
    UNIC_AIR_SUS_KAHI_FLG           CHAR(1),
    UNIC_KUCHO_KAHI_FLG             CHAR(1),
    AIR_SUS_KUCHO_KAHI_FLG          CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHASHU
    ADD(CONSTRAINT PK_MS_SHASHU PRIMARY KEY (SHASHU_CD) USING INDEX)
/
DROP TABLE MS_SHARYO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHARYO
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    SHARYO_NO                       VARCHAR2(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    SHARYO_DATA_VERSION             NUMBER(3,0) NOT NULL,
    SHARYO_MEISHO                   VARCHAR2(40),
    NUMBER_PLATE                    VARCHAR2(40),
    SHASHU_CD                       CHAR(2),
    ROCKET_FLG                      CHAR(1) NOT NULL,
    KYORYOKU_KAISHA_CD              CHAR(5),
    TEKIYO_MEI                      VARCHAR2(40),
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHARYO
    ADD(CONSTRAINT PK_MS_SHARYO PRIMARY KEY (SHARYO_NO, TEKIYO_KAISHIBI, EIGYOSHO_CD) USING INDEX)
/
DROP TABLE MS_SHARYO_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHARYO_RIREKI
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    SHARYO_NO                       VARCHAR2(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    SHARYO_DATA_VERSION             NUMBER(3,0) NOT NULL,
    SHARYO_MEISHO                   VARCHAR2(40),
    NUMBER_PLATE                    VARCHAR2(40),
    SHASHU_CD                       CHAR(2),
    ROCKET_FLG                      CHAR(1) NOT NULL,
    KYORYOKU_KAISHA_CD              CHAR(5),
    TEKIYO_MEI                      VARCHAR2(40),
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHARYO_RIREKI
    ADD(CONSTRAINT PK_MS_SHARYO_RIREKI PRIMARY KEY (EIGYOSHO_CD, SHARYO_NO, TEKIYO_KAISHIBI, SHARYO_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_JUSHIN_MESSAGE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_JUSHIN_MESSAGE
(
    MESSAGE_SERIAL_NO               NUMBER(18,0) NOT NULL,
    MESSAGE_SERIAL_NO_EDABAN        NUMBER(3,0) NOT NULL,
    MESSAGE_SHUBETSU                CHAR(2) NOT NULL,
    KINKYU_LEVEL                    CHAR(1) NOT NULL,
    MESSAGE_ID                      VARCHAR2(8),
    MESSAGE_TITLE                   VARCHAR2(40),
    MESSAGE_HOMBUN                  VARCHAR2(360),
    JUSHI_ERIA_HYOJI_KAHI           CHAR(1) NOT NULL,
    TAISHO_USER                     CHAR(7),
    TAISHO_SYSTEM                   VARCHAR2(20),
    SENISAKI_GAMEN_ID               VARCHAR2(10),
    TAISHO_DATA_KEY                 VARCHAR2(256),
    MESSAGE_SAKUSEISHA              CHAR(7),
    MESSAGE_TSUCHI_NICHIJI          DATE,
    MESSAGE_HYOJI_SHURYO_NICHIJI    DATE,
    MESSAGE_SOSHIN_MOTO_SYSTEM_CD   VARCHAR2(20),
    KIDOKU_FLG                      CHAR(1) NOT NULL,
    TAIO_SUMI_FLG                   CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_JUSHIN_MESSAGE
    ADD(CONSTRAINT PK_TR_JUSHIN_MESSAGE PRIMARY KEY (MESSAGE_SERIAL_NO, MESSAGE_SERIAL_NO_EDABAN) USING INDEX)
/
DROP TABLE TR_SHUKA_TRACE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SHUKA_TRACE
(
    OKURIJO_NO                      CHAR(13) NOT NULL,
    SHUKA_TEN                       VARCHAR2(5),
    SHUKA_NENGAPPI                  CHAR(8) NOT NULL,
    SHUKA_JIKAN                     CHAR(6),
    KOSU                            NUMBER(3,0),
    JURYO                           NUMBER(8,0),
    KICHOHIN_KBN                    CHAR(2) NOT NULL,
    SHABAN                          CHAR(5),
    DATA_MOTO                       CHAR(2),
    HASSEI_NICHIJI                  DATE,
    URIAGE_ID                       NUMBER(18,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SHUKA_TRACE
    ADD(CONSTRAINT PK_TR_SHUKA_TRACE PRIMARY KEY (OKURIJO_NO, SHUKA_NENGAPPI) USING INDEX)
/
DROP TABLE TR_SHUKA_TRACE_EDABAN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SHUKA_TRACE_EDABAN
(
    OKURIJO_NO                      CHAR(13) NOT NULL,
    EDABAN                          VARCHAR2(3) NOT NULL,
    SHUKA_TEN                       VARCHAR2(5),
    SHUKA_NENGAPPI                  CHAR(8) NOT NULL,
    SHUKA_JIKAN                     CHAR(6),
    HHT_BANGO                       CHAR(15),
    TANTOSHA                        CHAR(7),
    SHABAN                          CHAR(5),
    JURYO                           NUMBER(8,0),
    KEITAI_DENWA_BANGO              VARCHAR2(19),
    UNIT_NO                         VARCHAR2(20),
    OKURIJO_NO_NYURYOKU_MOTO_FLG    CHAR(1),
    HASSEI_NICHIJI                  DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SHUKA_TRACE_EDABAN
    ADD(CONSTRAINT PK_TR_SHUKA_TRACE_EDABAN PRIMARY KEY (OKURIJO_NO, EDABAN, SHUKA_NENGAPPI) USING INDEX)
/
DROP TABLE TR_SHUKA_LIST CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SHUKA_LIST
(
    GYOMU_HIZUKE                    VARCHAR2(8) NOT NULL,
    NYURYOKU_TEN                    VARCHAR2(5) NOT NULL,
    TANTOSHA                        CHAR(7) NOT NULL,
    SHABAN                          CHAR(5) NOT NULL,
    COURSE                          VARCHAR2(8) NOT NULL,
    SHUKA_LIST_GROUP_CD             VARCHAR2(6) NOT NULL,
    YOTEI_JISSEKI_KBN               CHAR(1) NOT NULL,
    SHUKA_LIST_SEQ                  NUMBER(5,0) NOT NULL,
    SHUKA_KBN                       VARCHAR2(1),
    SHUKASAKI_MEISHO                VARCHAR2(80),
    SHUKASAKI_JUSHO                 VARCHAR2(80),
    OKURIJO_NO                      CHAR(13),
    NYURYOKU_JIKOKU                 DATE,
    KEITAI_DENWA_BANGO              VARCHAR2(19),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SHUKA_LIST
    ADD(CONSTRAINT PK_TR_SHUKA_LIST PRIMARY KEY (GYOMU_HIZUKE, TANTOSHA, SHABAN, COURSE, NYURYOKU_TEN, SHUKA_LIST_GROUP_CD, YOTEI_JISSEKI_KBN, SHUKA_LIST_SEQ) USING INDEX)
/
DROP TABLE MS_SHUHAI_RYOKINHYO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHUHAI_RYOKINHYO
(
    SHUHAI_RYOKIN_HYO_CD            VARCHAR2(10) NOT NULL,
    RYOKIN_HYO_CATEGORY             NUMBER(4,0) NOT NULL,
    RYOKINHYO_MEISHO                VARCHAR2(40) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    MEMO                            VARCHAR2(40),
    NARABIKAE_JUN_CD                NUMBER(6,0) NOT NULL,
    SHINKI_SHIYO_KA_FLG             CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHUHAI_RYOKINHYO
    ADD(CONSTRAINT PK_MS_SHUHAI_RYOKINHYO PRIMARY KEY (SHUHAI_RYOKIN_HYO_CD, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE MS_SHUHAI_RYOKINHYO_MEISAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHUHAI_RYOKINHYO_MEISAI
(
    SHUHAI_RYOKIN_HYO_CD            VARCHAR2(10) NOT NULL,
    ZO_KBN                          CHAR(1) NOT NULL,
    JURYO                           VARCHAR2(2) NOT NULL,
    SHUHAI_CHIKU                    CHAR(1) NOT NULL,
    SHUHAI_RYO                      NUMBER(10,0),
    MOCHIKOMI_RYO                   NUMBER(8,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE,
    TEKIYO_KAISHIBI                 DATE NOT NULL
)
/
ALTER TABLE MS_SHUHAI_RYOKINHYO_MEISAI
    ADD(CONSTRAINT PK_MS_SHUHAI_RYOKINHYO_MEISAI PRIMARY KEY (SHUHAI_RYOKIN_HYO_CD, ZO_KBN, JURYO, SHUHAI_CHIKU, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE MS_SHUYAKU_CD CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHUYAKU_CD
(
    SHUYAKU_CD                      VARCHAR2(10) NOT NULL,
    SHUYAKU_CD_MEISHO               VARCHAR2(100) NOT NULL,
    SHUYAKU_KBN                     CHAR(1) NOT NULL,
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    SHUYAKU_CD_DATA_VERSION         NUMBER(3,0) NOT NULL,
    BIKO                            VARCHAR2(100),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHUYAKU_CD
    ADD(CONSTRAINT PK_MS_SHUYAKU_CD PRIMARY KEY (SHUYAKU_CD, SHUYAKU_KBN, EIGYOSHO_CD) USING INDEX)
/
DROP TABLE MS_SHUYAKU_CD_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHUYAKU_CD_RIREKI
(
    SHUYAKU_CD                      VARCHAR2(10) NOT NULL,
    SHUYAKU_CD_MEISHO               VARCHAR2(100) NOT NULL,
    SHUYAKU_KBN                     CHAR(1) NOT NULL,
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    SHUYAKU_CD_DATA_VERSION         NUMBER(3,0) NOT NULL,
    BIKO                            VARCHAR2(100),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHUYAKU_CD_RIREKI
    ADD(CONSTRAINT PK_MS_SHUYAKU_CD_RIREKI PRIMARY KEY (SHUYAKU_CD, SHUYAKU_KBN, EIGYOSHO_CD, SHUYAKU_CD_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_JUSHO_JIS CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_JUSHO_JIS
(
    JIS_CD                          CHAR(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    JUSHO_JIS_DATA_VERSION          NUMBER(3,0) NOT NULL,
    TEKIYO_MEI                      VARCHAR2(40),
    KANJI_JUSHO                     VARCHAR2(40),
    KANA_JUSHO                      VARCHAR2(40),
    TODOFUKEN_EIGO_JUSHO            VARCHAR2(40),
    SHIKUCHOSON_EIGO_JUSHO          VARCHAR2(40),
    RITO_UMU_FLG                    CHAR(1) NOT NULL,
    HT_COMMENT_1                    VARCHAR2(100),
    HT_COMMENT_2                    VARCHAR2(200),
    KYU_JUSHO_FLG                   CHAR(1) NOT NULL,
    SHIYO_FUKA_FLG                  CHAR(1) NOT NULL,
    SHIN_JIS_CD                     CHAR(5),
    KYU_JUSHO_COMMENT               VARCHAR2(40),
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_JUSHO_JIS
    ADD(CONSTRAINT PK_MS_JUSHO_JIS PRIMARY KEY (JIS_CD, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE MS_JUSHO_JIS_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_JUSHO_JIS_RIREKI
(
    JIS_CD                          CHAR(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    JUSHO_JIS_DATA_VERSION          NUMBER(3,0) NOT NULL,
    TEKIYO_MEI                      VARCHAR2(40),
    KANJI_JUSHO                     VARCHAR2(40),
    KANA_JUSHO                      VARCHAR2(40),
    TODOFUKEN_EIGO_JUSHO            VARCHAR2(40),
    SHIKUCHOSON_EIGO_JUSHO          VARCHAR2(40),
    RITO_UMU_FLG                    CHAR(1) NOT NULL,
    HT_COMMENT_1                    VARCHAR2(100),
    HT_COMMENT_2                    VARCHAR2(200),
    KYU_JUSHO_FLG                   CHAR(1) NOT NULL,
    SHIYO_FUKA_FLG                  CHAR(1) NOT NULL,
    SHIN_JIS_CD                     CHAR(5),
    KYU_JUSHO_COMMENT               VARCHAR2(40),
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_JUSHO_JIS_RIREKI
    ADD(CONSTRAINT PK_MS_JUSHO_JIS_RIREKI PRIMARY KEY (JIS_CD, TEKIYO_KAISHIBI, JUSHO_JIS_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_JUSHO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_JUSHO
(
    JIS_CD                          CHAR(5) NOT NULL,
    SHIMUKE_CHI_CD                  CHAR(7) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    JUSHO_JIS_DATA_VERSION          NUMBER(3,0) NOT NULL,
    CHOAZA                          VARCHAR2(40),
    CHOAZA_KANA                     VARCHAR2(40),
    CHOAZA_EIJI                     VARCHAR2(40),
    TODOFUKEN_CD                    CHAR(2),
    SHIMUKE_CHI_MEI_CD              VARCHAR2(4),
    KUKO_CD                         CHAR(3),
    SHUHAI_CHIKU                    CHAR(1),
    EIGYOSHO_CD                     VARCHAR2(5),
    KYU_EDI_JUSHO_FLG               CHAR(1) NOT NULL,
    SHIN_EDI_JUSHO_FLG              CHAR(1) NOT NULL,
    KYU_JUSHO_FLG                   CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_JUSHO
    ADD(CONSTRAINT PK_MS_JUSHO PRIMARY KEY (JIS_CD, SHIMUKE_CHI_CD, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE MS_JUSHO_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_JUSHO_RIREKI
(
    JIS_CD                          CHAR(5) NOT NULL,
    SHIMUKE_CHI_CD                  CHAR(7) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    JUSHO_JIS_DATA_VERSION          NUMBER(3,0) NOT NULL,
    CHOAZA                          VARCHAR2(40),
    CHOAZA_KANA                     VARCHAR2(40),
    CHOAZA_EIJI                     VARCHAR2(40),
    TODOFUKEN_CD                    CHAR(2),
    SHIMUKE_CHI_MEI_CD              VARCHAR2(4),
    KUKO_CD                         CHAR(3),
    SHUHAI_CHIKU                    CHAR(1),
    EIGYOSHO_CD                     VARCHAR2(5),
    KYU_EDI_JUSHO_FLG               CHAR(1) NOT NULL,
    SHIN_EDI_JUSHO_FLG              CHAR(1) NOT NULL,
    KYU_JUSHO_FLG                   CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_JUSHO_RIREKI
    ADD(CONSTRAINT PK_MS_JUSHO_RIREKI PRIMARY KEY (JIS_CD, SHIMUKE_CHI_CD, TEKIYO_KAISHIBI, JUSHO_JIS_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_JUSHO_KANNAIHAISO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_JUSHO_KANNAIHAISO
(
    JIS_CD                          CHAR(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    JUSHO_KANNAIHAISO_SEQ           NUMBER(3,0) NOT NULL,
    JUSHO_JIS_DATA_VERSION          NUMBER(3,0) NOT NULL,
    KANNAIHAISO_JUSHO               VARCHAR2(40),
    SHISETSU_MEI                    VARCHAR2(40),
    BIKO                            VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_JUSHO_KANNAIHAISO
    ADD(CONSTRAINT PK_MS_JUSHO_KANNAIHAISO PRIMARY KEY (JIS_CD, TEKIYO_KAISHIBI, JUSHO_KANNAIHAISO_SEQ) USING INDEX)
/
DROP TABLE MS_JUSHO_KANNAIHAISO_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_JUSHO_KANNAIHAISO_RIREKI
(
    JIS_CD                          CHAR(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    JUSHO_KANNAIHAISO_SEQ           NUMBER(3,0) NOT NULL,
    JUSHO_JIS_DATA_VERSION          NUMBER(3,0) NOT NULL,
    KANNAIHAISO_JUSHO               VARCHAR2(40),
    SHISETSU_MEI                    VARCHAR2(40),
    BIKO                            VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_JUSHO_KANNAIHAISO_RIREKI
    ADD(CONSTRAINT PK_MS_JUSHO_KANNAIHAISO_RIREKI PRIMARY KEY (JIS_CD, TEKIYO_KAISHIBI, JUSHO_KANNAIHAISO_SEQ, JUSHO_JIS_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_JUSHO_RITO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_JUSHO_RITO
(
    JIS_CD                          CHAR(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    JUSHO_RITO_SEQ                  NUMBER(3,0) NOT NULL,
    JUSHO_JIS_DATA_VERSION          NUMBER(3,0) NOT NULL,
    RITO_JUSHO                      VARCHAR2(40),
    SHIMA_MEI                       VARCHAR2(40),
    BIKO                            VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_JUSHO_RITO
    ADD(CONSTRAINT PK_MS_JUSHO_RITO PRIMARY KEY (JIS_CD, TEKIYO_KAISHIBI, JUSHO_RITO_SEQ) USING INDEX)
/
DROP TABLE MS_JUSHO_RITO_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_JUSHO_RITO_RIREKI
(
    JIS_CD                          CHAR(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    JUSHO_RITO_SEQ                  NUMBER(3,0) NOT NULL,
    JUSHO_JIS_DATA_VERSION          NUMBER(3,0) NOT NULL,
    RITO_JUSHO                      VARCHAR2(40),
    SHIMA_MEI                       VARCHAR2(40),
    BIKO                            VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_JUSHO_RITO_RIREKI
    ADD(CONSTRAINT PK_MS_JUSHO_RITO_RIREKI PRIMARY KEY (JIS_CD, TEKIYO_KAISHIBI, JUSHO_RITO_SEQ, JUSHO_JIS_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_SHOHIZEI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHOHIZEI
(
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    ZEI_RITSU                       NUMBER(3,1) NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHOHIZEI
    ADD(CONSTRAINT PK_MS_SHOHIZEI PRIMARY KEY (TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE TR_JOKEN_GAI_MISHU_RIYU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_JOKEN_GAI_MISHU_RIYU
(
    NYUKIN_YOTEIBI                  CHAR(8) NOT NULL,
    HENKOMAE_NYUKIN_YOTEIBI         CHAR(8),
    RIYU_TAISHO_HOHO                VARCHAR2(512),
    KOKYAKU_TEL_BANGO               VARCHAR2(19),
    KOKYAKU_TANTOSHA                VARCHAR2(200),
    KASHO_KAKUNIN_SHA               VARCHAR2(200),
    LOCK_FLG                        CHAR(1) NOT NULL,
    RANK_SHUBETSU                   CHAR(1),
    JOKEN_GAI_COMMENT               VARCHAR2(512),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_JOKEN_GAI_MISHU_RIYU
    ADD(CONSTRAINT PK_TR_JOKEN_GAI_MISHU_RIYU PRIMARY KEY (NYUKIN_YOTEIBI) USING INDEX)
/
DROP TABLE TT_JOKYO_KANRI_BATCH CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TT_JOKYO_KANRI_BATCH
(
    JIKKO_KAISHI_NICHIJI            DATE NOT NULL,
    JOKYO_KANRI_SEQ                 NUMBER(5,0) NOT NULL,
    SHORI_TAISHO_MEISHO             VARCHAR2(80),
    SHORI_JIKKO_KEKKA               VARCHAR2(20),
    SHORI_RECORD_KENSU              NUMBER(6,0),
    OK_KENSU                        NUMBER(6,0),
    YOSHUSEI_KENSU                  NUMBER(6,0),
    NG_KENSU                        NUMBER(6,0),
    SKIP_KENSU                      NUMBER(6,0),
    JIKKO_SHURYO_NICHIJI            DATE,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TT_JOKYO_KANRI_BATCH
    ADD(CONSTRAINT PK_TT_JOKYO_KANRI_BATCH PRIMARY KEY (JIKKO_KAISHI_NICHIJI, JOKYO_KANRI_SEQ) USING INDEX)
/
DROP TABLE TR_JOKYO_KANRI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_JOKYO_KANRI
(
    EDI_SETTEI_ID                   CHAR(6) NOT NULL,
    JIKKO_KAISHI_NICHIJI            DATE NOT NULL,
    JOKYO_KANRI_SEQ                 NUMBER(5,0) NOT NULL,
    SHORI_TAISHO_MEISHO             VARCHAR2(80),
    SHORI_JIKKO_KEKKA               VARCHAR2(20),
    SHORI_RECORD_KENSU              NUMBER(6,0),
    OK_KENSU                        NUMBER(6,0),
    YOSHUSEI_KENSU                  NUMBER(6,0),
    NG_KENSU                        NUMBER(6,0),
    SKIP_KENSU                      NUMBER(6,0),
    JIKKO_SHURYO_NICHIJI            DATE,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_JOKYO_KANRI
    ADD(CONSTRAINT PK_TR_JOKYO_KANRI PRIMARY KEY (EDI_SETTEI_ID, JIKKO_KAISHI_NICHIJI, JOKYO_KANRI_SEQ) USING INDEX)
/
DROP TABLE TR_JOKYO_KANRI_SHOSAI_UPLOAD CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_JOKYO_KANRI_SHOSAI_UPLOAD
(
    EDI_SETTEI_ID                   CHAR(6) NOT NULL,
    JIKKO_KAISHI_NICHIJI            DATE NOT NULL,
    JOKYO_KANRI_SEQ                 NUMBER(5,0) NOT NULL,
    JOKYO_KANRI_SHOSAI_SEQ          NUMBER(6,0) NOT NULL,
    SCRIPT_ID                       VARCHAR2(8),
    LOG_LEVEL                       VARCHAR2(10),
    MESSAGE_BUN                     VARCHAR2(512),
    ERROR_CD                        VARCHAR2(40),
    ERROR_HASSEI_GYO                NUMBER(6,0),
    ERROR_HASSEI_COLUMN             VARCHAR2(30),
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_JOKYO_KANRI_SHOSAI_UPLOAD
    ADD(CONSTRAINT PK_TR_JOKYO_KANRI_SHOSAI_UPLOAD PRIMARY KEY (EDI_SETTEI_ID, JIKKO_KAISHI_NICHIJI, JOKYO_KANRI_SEQ, JOKYO_KANRI_SHOSAI_SEQ) USING INDEX)
/
DROP TABLE TT_JOKYO_KANRI_SHOSAI_BATCH CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TT_JOKYO_KANRI_SHOSAI_BATCH
(
    JIKKO_KAISHI_NICHIJI            DATE NOT NULL,
    JOKYO_KANRI_SEQ                 NUMBER(5,0) NOT NULL,
    JOKYO_KANRI_SHOSAI_SEQ          NUMBER(6,0) NOT NULL,
    SCRIPT_ID                       VARCHAR2(8),
    LOG_LEVEL                       VARCHAR2(10),
    MESSAGE_BUN                     VARCHAR2(512),
    ERROR_CD                        VARCHAR2(40),
    ERROR_HASSEI_GYO                NUMBER(6,0),
    ERROR_HASSEI_COLUMN             VARCHAR2(30),
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TT_JOKYO_KANRI_SHOSAI_BATCH
    ADD(CONSTRAINT PK_TT_JOKYO_KANRI_SHOSAI_BATCH PRIMARY KEY (JIKKO_KAISHI_NICHIJI, JOKYO_KANRI_SEQ, JOKYO_KANRI_SHOSAI_SEQ) USING INDEX)
/
DROP TABLE TR_JOKYO_KANRI_SHOSAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_JOKYO_KANRI_SHOSAI
(
    EDI_SETTEI_ID                   CHAR(6) NOT NULL,
    JIKKO_KAISHI_NICHIJI            DATE NOT NULL,
    JOKYO_KANRI_SEQ                 NUMBER(5,0) NOT NULL,
    JOKYO_KANRI_SHOSAI_SEQ          NUMBER(6,0) NOT NULL,
    SCRIPT_ID                       VARCHAR2(8),
    LOG_LEVEL                       VARCHAR2(10),
    MESSAGE_BUN                     VARCHAR2(512),
    ERROR_CD                        VARCHAR2(40),
    ERROR_HASSEI_GYO                NUMBER(6,0),
    ERROR_HASSEI_COLUMN             VARCHAR2(30),
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_JOKYO_KANRI_SHOSAI
    ADD(CONSTRAINT PK_TR_JOKYO_KANRI_SHOSAI PRIMARY KEY (EDI_SETTEI_ID, JIKKO_KAISHI_NICHIJI, JOKYO_KANRI_SEQ, JOKYO_KANRI_SHOSAI_SEQ) USING INDEX)
/
DROP TABLE TR_JOTAI_HOZON CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_JOTAI_HOZON
(
    USER_CD                         CHAR(7) NOT NULL,
    EIGYOSHO_CD                     VARCHAR2(5) NOT NULL,
    GAMEN_CD                        VARCHAR2(10) NOT NULL,
    JOTAI_ID                        NUMBER(3,0) NOT NULL,
    JOTAI_MEI                       VARCHAR2(50) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_JOTAI_HOZON
    ADD(CONSTRAINT PK_TR_JOTAI_HOZON PRIMARY KEY (EIGYOSHO_CD, USER_CD, GAMEN_CD, JOTAI_ID) USING INDEX)
/
DROP TABLE TR_JOTAI_HOZON_MEISAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_JOTAI_HOZON_MEISAI
(
    USER_CD                         CHAR(7) NOT NULL,
    EIGYOSHO_CD                     VARCHAR2(5) NOT NULL,
    GAMEN_CD                        VARCHAR2(10) NOT NULL,
    JOTAI_ID                        NUMBER(3,0) NOT NULL,
    KENSAKU_ID                      VARCHAR2(10) NOT NULL,
    ATAI                            VARCHAR2(200),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_JOTAI_HOZON_MEISAI
    ADD(CONSTRAINT PK_TR_JOTAI_HOZON_MEISAI PRIMARY KEY (USER_CD, EIGYOSHO_CD, GAMEN_CD, JOTAI_ID, KENSAKU_ID) USING INDEX)
/
DROP TABLE TR_SHINSEI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SHINSEI
(
    SHINSEI_ID                      VARCHAR2(6) NOT NULL,
    SHINSEI_SHUBETSU_CD             CHAR(2) NOT NULL,
    SHINSEI_BI                      DATE NOT NULL,
    SHINSEI_STATUS                  CHAR(2) NOT NULL,
    GEN_DANKAI_ACTIVITY_NO          NUMBER(2,0),
    SHIKYU_FLG                      CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SHINSEI
    ADD(CONSTRAINT PK_TR_SHINSEI PRIMARY KEY (SHINSEI_ID) USING INDEX)
/
DROP TABLE MS_SHINSEI_PROCESS_ACTIVITY_TEIGI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHINSEI_PROCESS_ACTIVITY_TEIGI
(
    SHINSEI_SHUBETSU_CD             CHAR(2) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    SHINSEI_PROCESS_ACTIVITY_NO     NUMBER(2,0) NOT NULL,
    SHINSEI_PROCESS_DATA_VERSION    NUMBER(3,0) NOT NULL,
    SHINSEI_PROCESS_ACTIVITY_MEI    VARCHAR2(40),
    SHONIN_EIGYOSHO_KBN_CD          CHAR(1),
    SEKININ_KASHO_CD                CHAR(3),
    TSUGI_SHINSEI_PROCESS_ACTIVITY_NO NUMBER(2,0),
    ACTIVITY_KBN                    CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHINSEI_PROCESS_ACTIVITY_TEIGI
    ADD(CONSTRAINT PK_MS_SHINSEI_PROCESS_ACTIVITY_TEIGI PRIMARY KEY (SHINSEI_PROCESS_ACTIVITY_NO, TEKIYO_KAISHIBI, SHINSEI_SHUBETSU_CD) USING INDEX)
/
DROP TABLE MS_SHINSEI_PROCESS_ACTIVITY_TEIGI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHINSEI_PROCESS_ACTIVITY_TEIGI_RIREKI
(
    SHINSEI_SHUBETSU_CD             CHAR(2) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    SHINSEI_PROCESS_ACTIVITY_NO     NUMBER(2,0) NOT NULL,
    SHINSEI_PROCESS_DATA_VERSION    NUMBER(3,0) NOT NULL,
    SHINSEI_PROCESS_ACTIVITY_MEI    VARCHAR2(40),
    SHONIN_EIGYOSHO_KBN_CD          CHAR(1),
    SEKININ_KASHO_CD                CHAR(3),
    TSUGI_SHINSEI_PROCESS_ACTIVITY_NO NUMBER(2,0),
    ACTIVITY_KBN                    CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHINSEI_PROCESS_ACTIVITY_TEIGI_RIREKI
    ADD(CONSTRAINT PK_MS_SHINSEI_PROCESS_ACTIVITY_TEIGI_RIREKI PRIMARY KEY (SHINSEI_SHUBETSU_CD, TEKIYO_KAISHIBI, SHINSEI_PROCESS_ACTIVITY_NO, SHINSEI_PROCESS_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_SHINSEI_PROCESS_TEIGI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHINSEI_PROCESS_TEIGI
(
    SHINSEI_SHUBETSU_CD             CHAR(2) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    SHINSEI_PROCESS_DATA_VERSION    NUMBER(3,0) NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHINSEI_PROCESS_TEIGI
    ADD(CONSTRAINT PK_MS_SHINSEI_PROCESS_TEIGI PRIMARY KEY (TEKIYO_KAISHIBI, SHINSEI_SHUBETSU_CD) USING INDEX)
/
DROP TABLE MS_SHINSEI_PROCESS_TEIGI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHINSEI_PROCESS_TEIGI_RIREKI
(
    SHINSEI_SHUBETSU_CD             CHAR(2) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    SHINSEI_PROCESS_DATA_VERSION    NUMBER(3,0) NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHINSEI_PROCESS_TEIGI_RIREKI
    ADD(CONSTRAINT PK_MS_SHINSEI_PROCESS_TEIGI_RIREKI PRIMARY KEY (SHINSEI_SHUBETSU_CD, TEKIYO_KAISHIBI, SHINSEI_PROCESS_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_SHINSEI_SHUBETSU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SHINSEI_SHUBETSU
(
    SHINSEI_SHUBETSU_CD             CHAR(2) NOT NULL,
    SHINSEI_SHUBETSU_MEI            VARCHAR2(40) NOT NULL,
    SHINSEI_SHUBETSU_BUTURI_MEI     VARCHAR2(128) NOT NULL,
    KINO_CD                         VARCHAR2(20),
    HYOJI_JUN                       NUMBER(3,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SHINSEI_SHUBETSU
    ADD(CONSTRAINT PK_MS_SHINSEI_SHUBETSU PRIMARY KEY (SHINSEI_SHUBETSU_CD) USING INDEX)
/
DROP TABLE TR_SHINSEI_SHOSAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SHINSEI_SHOSAI
(
    SHINSEI_ID                      VARCHAR2(6) NOT NULL,
    SHINSEI_SHOSAI_NO               NUMBER(3,0) NOT NULL,
    SHINSEI_PROCESS_ACTIVITY_NO     NUMBER(2,0) NOT NULL,
    SHONIN_JOKYO_KEKKA              CHAR(2) NOT NULL,
    USER_CD                         CHAR(7),
    EIGYOSHO_CD                     CHAR(3),
    KOSHIN_BI                       DATE,
    SHINSEI_COMMENT                 VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SHINSEI_SHOSAI
    ADD(CONSTRAINT PK_TR_SHINSEI_SHOSAI PRIMARY KEY (SHINSEI_ID, SHINSEI_SHOSAI_NO) USING INDEX)
/
DROP TABLE TR_SEIKYU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SEIKYU
(
    SEIKYU_ID                       NUMBER(18,0) NOT NULL,
    SEIKYUSAKI_CD                   CHAR(6) NOT NULL,
    SEIKYUSHO_NO                    VARCHAR2(6) NOT NULL,
    SEIKYUSHO_EDABAN                NUMBER(3,0) NOT NULL,
    KO_SEIKYU_FLG                   CHAR(1) NOT NULL,
    OYA_SEIKYU_ID                   NUMBER(18,0),
    SHIMEBI                         CHAR(8) NOT NULL,
    SEIKYU_TAISHO_KIKAN_FROM        CHAR(8) NOT NULL,
    SEIKYU_TAISHO_KIKAN_TO          CHAR(8) NOT NULL,
    SHIHARAI_HOHO_CD                CHAR(2) NOT NULL,
    NYUKIN_YOTEIBI                  CHAR(8) NOT NULL,
    SEIKYU_KINGAKU                  NUMBER(10,0) NOT NULL,
    KAZEI_GOKEI                     NUMBER(10,0) NOT NULL,
    HIKAZEI_GOKEI                   NUMBER(10,0) NOT NULL,
    SHOHIZEI                        NUMBER(10,0) NOT NULL,
    DAIRITEN_FLG                    CHAR(1) NOT NULL,
    DAIRITEN_SEIKYU_ID              NUMBER(18,0),
    EDI_SOSHIN_FLG                  CHAR(1),
    SEIKYUSHO_KBN                   CHAR(1) NOT NULL,
    HAKKO_FLG                       CHAR(1) NOT NULL,
    SEIKYU_CHECKYOU_FLG             CHAR(1) NOT NULL,
    SEIKYU_CHECKZUMI_FLG            CHAR(1) NOT NULL,
    SEIKYU_CHECK_SHA_CD             VARCHAR2(7),
    SEIKYU_CHECK_DATE               DATE,
    WEB_KOKYAKU_KAKUNIN_FLG         CHAR(1) NOT NULL,
    WEB_KOKYAKU_SHA_CD              VARCHAR2(7),
    WEB_KOKYAKU_KAKUNIN_NICHIJI     DATE,
    SHIME_JOTAI_FLG                 CHAR(1) NOT NULL,
    SHIME_HOHO_FLG                  CHAR(1) NOT NULL,
    NYUKIN_KINGAKU                  NUMBER(10,0) NOT NULL,
    ZENKAI_SEIKYU_ZANDAKA           NUMBER(21,0) NOT NULL,
    SEIKYU_ZANDAKA                  NUMBER(21,0) NOT NULL,
    ERROR_KBN                       CHAR(1),
    KO_SEIKYU_KAZU                  NUMBER(5,0) NOT NULL,
    MEISAI_KAZU                     NUMBER(5,0) NOT NULL,
    TANTO_EIGYOSHO_CD               VARCHAR2(5) NOT NULL,
    SEIKYUSHO_OUTPUT_EIGYOSHO_CD    VARCHAR2(5) NOT NULL,
    SEIKYUSHO_SHUTSURYOKU_SHA_CD    CHAR(7),
    SEIKYUSHO_OUTPUT_DATE           DATE,
    SHOKAI_INSATSU_SHA_CD           CHAR(7),
    SHOKAI_INSATSU_NICHIJI          DATE,
    SAISHIN_INSATSU_SHA_CD          CHAR(7),
    SAISHIN_INSATSU_NICHIJI         DATE,
    INSATSUCHU_FLG                  CHAR(1) NOT NULL,
    KEIRI_RENKEI_SUMI_FLG           CHAR(1) NOT NULL,
    URIAGE_KBN                      CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SEIKYU
    ADD(CONSTRAINT PK_TR_SEIKYU PRIMARY KEY (SEIKYU_ID) USING INDEX)
/
DROP TABLE MS_SEIKYU_STATUS CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SEIKYU_STATUS
(
    SEIKYU_STATUS_CD                VARCHAR2(10) NOT NULL,
    SEIKYU_STATUS_MEI               VARCHAR2(20) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SEIKYU_STATUS
    ADD(CONSTRAINT PK_MS_SEIKYU_STATUS PRIMARY KEY (SEIKYU_STATUS_CD) USING INDEX)
/
DROP TABLE TR_SEIKYU_H_DATA CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SEIKYU_H_DATA
(
    RECORD_KBN                      CHAR(1) NOT NULL,
    KONG_YO_SEIKYUSHO_NO            CHAR(13),
    SEIKYUSAKI_CD                   CHAR(6),
    SHIMEBI                         CHAR(8),
    SEIKYUSAKI_TOKUISAKI_MEISHO_1   VARCHAR2(40),
    SEIKYUSAKI_TOKUISAKI_MEISHO_2   VARCHAR2(40),
    SEIKYUSAKI_TOKUISAKI_MEISHO_3   VARCHAR2(40),
    SEIKYUSAKI_TOKUISAKI_JUSHO_1    VARCHAR2(40),
    SEIKYUSAKI_TOKUISAKI_JUSHO_2    VARCHAR2(40),
    SEIKYUSAKI_TOKUISAKI_JUSHO_3    VARCHAR2(40),
    SEIKYUSAKI_TOKUISAKI_TEL_BANGO  VARCHAR2(19),
    SEIKYU_TAISHO_KIKAN_KAISHI      CHAR(8),
    SEIKYU_TAISHO_KIKAN_SHURYO      CHAR(8),
    KAZEI_KINGAKU                   NUMBER(10,0),
    HIKAZEI_KINGAKU                 NUMBER(10,0),
    SHOHIZEI_KINGAKU                NUMBER(10,0),
    SEIKYU_KINGAKU                  NUMBER(10,0),
    SEIKYU_EIGYOSHO_CD              VARCHAR2(5),
    MEISAI_KAZU                     NUMBER(5,0),
    NYUKIN_YOTEIBI                  CHAR(8),
    SHIHARAI_KBN                    CHAR(2),
    KWE_KEIRI_MOKU_CD               CHAR(4) NOT NULL,
    KWE_FUTAN_KAMOKU_CD             CHAR(6) NOT NULL,
    KWE_FUTAN_KASHO_MEISHO          VARCHAR2(40) NOT NULL,
    FUTAN_KASHO_KEIRI_MOKU_CD       CHAR(4),
    KWE_BUMON_MEISHO                VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
DROP TABLE TR_SEIKYU_H_DATA_ERROR CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SEIKYU_H_DATA_ERROR
(
    SHORI_HIZUKE                    CHAR(8) NOT NULL,
    RECORD_KBN                      CHAR(1) NOT NULL,
    KONG_YO_SEIKYUSHO_NO            CHAR(13),
    SEIKYUSAKI_CD                   CHAR(6),
    SHIMEBI                         CHAR(8),
    SEIKYUSAKI_TOKUISAKI_MEISHO_1   VARCHAR2(40),
    SEIKYUSAKI_TOKUISAKI_MEISHO_2   VARCHAR2(40),
    SEIKYUSAKI_TOKUISAKI_MEISHO_3   VARCHAR2(40),
    SEIKYUSAKI_TOKUISAKI_JUSHO_1    VARCHAR2(40),
    SEIKYUSAKI_TOKUISAKI_JUSHO_2    VARCHAR2(40),
    SEIKYUSAKI_TOKUISAKI_JUSHO_3    VARCHAR2(40),
    SEIKYUSAKI_TOKUISAKI_TEL_BANGO  VARCHAR2(19),
    SEIKYU_TAISHO_KIKAN_KAISHI      CHAR(8),
    SEIKYU_TAISHO_KIKAN_SHURYO      CHAR(8),
    KAZEI_KINGAKU                   NUMBER(10,0),
    HIKAZEI_KINGAKU                 NUMBER(10,0),
    SHOHIZEI_KINGAKU                NUMBER(10,0),
    SEIKYU_KINGAKU                  NUMBER(10,0),
    SEIKYU_EIGYOSHO_CD              VARCHAR2(5),
    MEISAI_KAZU                     NUMBER(5,0),
    NYUKIN_YOTEIBI                  CHAR(8),
    SHIHARAI_KBN                    CHAR(2),
    KWE_KEIRI_MOKU_CD               CHAR(4) NOT NULL,
    KWE_FUTAN_KAMOKU_CD             CHAR(6) NOT NULL,
    KWE_FUTAN_KASHO_MEISHO          VARCHAR2(40) NOT NULL,
    FUTAN_KASHO_KEIRI_MOKU_CD       CHAR(4),
    KWE_BUMON_MEISHO                VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
DROP TABLE MS_SEIKYUSHO_INFO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_SEIKYUSHO_INFO
(
    SEIKYUSHO_SHUBETSU              CHAR(1) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    SEIKYUSHO_SHUBETSU_MEI          VARCHAR2(40),
    INFORMATION                     VARCHAR2(160) NOT NULL,
    TEKIYO_MEI                      VARCHAR2(40),
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_SEIKYUSHO_INFO
    ADD(CONSTRAINT PK_MS_SEIKYUSHO_INFO PRIMARY KEY (TEKIYO_KAISHIBI, SEIKYUSHO_SHUBETSU) USING INDEX)
/
DROP TABLE TR_SEIKYUSHO_FILE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SEIKYUSHO_FILE
(
    SEIKYU_ID                       NUMBER(18,0) NOT NULL,
    SEIKYUSHO_EDABAN                NUMBER(3,0) NOT NULL,
    CHOHYO_ID                       NUMBER(6,0) NOT NULL,
    SEIKYU_FILE_MEI                 VARCHAR2(512),
    W3_RENKEISAKI_SEIKYU_FILE_MEI   VARCHAR2(512),
    WEB_SEIKYU_KBN                  VARCHAR2(1) NOT NULL,
    INSATSU_NICHIJI                 DATE,
    INSATSU_KAISU                   NUMBER(3,0),
    INSATSU_SHA_CD                  CHAR(7),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SEIKYUSHO_FILE
    ADD(CONSTRAINT PK_TR_SEIKYUSHO_FILE PRIMARY KEY (SEIKYU_ID, SEIKYUSHO_EDABAN) USING INDEX)
/
DROP TABLE TR_SEIKYUSHO_FILE_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SEIKYUSHO_FILE_RIREKI
(
    SEIKYU_ID                       NUMBER(18,0) NOT NULL,
    SEIKYUSHO_EDABAN                NUMBER(3,0) NOT NULL,
    CHOHYO_ID                       NUMBER(6,0) NOT NULL,
    SEIKYU_FILE_MEI                 VARCHAR2(512) NOT NULL,
    W3_RENKEISAKI_SEIKYU_FILE_MEI   VARCHAR2(512) NOT NULL,
    WEB_SEIKYU_KBN                  VARCHAR2(1) NOT NULL,
    INSATSU_NICHIJI                 DATE,
    INSATSU_KAISU                   NUMBER(3,0),
    INSATSU_SHA_CD                  CHAR(7),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SEIKYUSHO_FILE_RIREKI
    ADD(CONSTRAINT PK_TR_SEIKYUSHO_FILE_RIREKI PRIMARY KEY (SEIKYU_ID, SEIKYUSHO_EDABAN) USING INDEX)
/
DROP TABLE TR_SEIKYU_JOHO_SETTEI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SEIKYU_JOHO_SETTEI
(
    EDI_SETTEI_ID                   CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    EDI_SETTEI_DATA_VERSION         NUMBER(3,0) NOT NULL,
    SCRIPT_ID                       VARCHAR2(8),
    FILE_TYPE                       CHAR(1),
    ZERO_KENJI_SOSHIN_SETTEI        CHAR(1) NOT NULL,
    SOSHIN_KBN                      CHAR(1) NOT NULL,
    JIKKO_TIMMING_KBN               CHAR(1),
    DOYOBI_SOSHIN_FLG               CHAR(1) NOT NULL,
    NICHIYOBI_SOSHIN_FLG            CHAR(1) NOT NULL,
    SHUKUJITSU_SOSHIN_FLG           CHAR(1) NOT NULL,
    KLS_KYUJITSU_SOSHIN_FLG         CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SEIKYU_JOHO_SETTEI
    ADD(CONSTRAINT PK_TR_SEIKYU_JOHO_SETTEI PRIMARY KEY (EDI_SETTEI_ID, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE TR_SEIKYU_JOHO_SETTEI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SEIKYU_JOHO_SETTEI_RIREKI
(
    EDI_SETTEI_ID                   CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    EDI_SETTEI_DATA_VERSION         NUMBER(3,0) NOT NULL,
    SCRIPT_ID                       VARCHAR2(8),
    FILE_TYPE                       CHAR(1),
    ZERO_KENJI_SOSHIN_SETTEI        CHAR(1) NOT NULL,
    SOSHIN_KBN                      CHAR(1) NOT NULL,
    JIKKO_TIMMING_KBN               CHAR(1),
    DOYOBI_SOSHIN_FLG               CHAR(1) NOT NULL,
    NICHIYOBI_SOSHIN_FLG            CHAR(1) NOT NULL,
    SHUKUJITSU_SOSHIN_FLG           CHAR(1) NOT NULL,
    KLS_KYUJITSU_SOSHIN_FLG         CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SEIKYU_JOHO_SETTEI_RIREKI
    ADD(CONSTRAINT PK_TR_SEIKYU_JOHO_SETTEI_RIREKI PRIMARY KEY (EDI_SETTEI_ID, TEKIYO_KAISHIBI, EDI_SETTEI_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_SEIKYU_JOHO_SETTEI_JIKKO_TIMMING CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SEIKYU_JOHO_SETTEI_JIKKO_TIMMING
(
    EDI_SETTEI_ID                   CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    SEIKYU_JOHO_SETTEI_SEQ          NUMBER(7,0) NOT NULL,
    EDI_SETTEI_DATA_VERSION         NUMBER(3,0) NOT NULL,
    JIKKO_TIMMING_HI                VARCHAR2(2),
    JIKKO_TIMMING_YOBI              VARCHAR2(2),
    JIKKO_TIMMING_JIKAN_1           DATE,
    JIKKO_TIMMING_JIKAN_2           DATE,
    JIKKO_TIMMING_JIKAN_3           DATE,
    JIKKO_TIMMING_JIKAN_4           DATE,
    JIKKO_TIMMING_JIKAN_5           DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SEIKYU_JOHO_SETTEI_JIKKO_TIMMING
    ADD(CONSTRAINT PK_TR_SEIKYU_JOHO_SETTEI_JIKKO_TIMMING PRIMARY KEY (EDI_SETTEI_ID, SEIKYU_JOHO_SETTEI_SEQ, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE TR_SEIKYU_JOHO_SETTEI_JIKKO_TIMMING_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SEIKYU_JOHO_SETTEI_JIKKO_TIMMING_RIREKI
(
    EDI_SETTEI_ID                   CHAR(6) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    SEIKYU_JOHO_SETTEI_SEQ          NUMBER(7,0) NOT NULL,
    EDI_SETTEI_DATA_VERSION         NUMBER(3,0) NOT NULL,
    JIKKO_TIMMING_HI                VARCHAR2(2),
    JIKKO_TIMMING_YOBI              VARCHAR2(2),
    JIKKO_TIMMING_JIKAN_1           DATE,
    JIKKO_TIMMING_JIKAN_2           DATE,
    JIKKO_TIMMING_JIKAN_3           DATE,
    JIKKO_TIMMING_JIKAN_4           DATE,
    JIKKO_TIMMING_JIKAN_5           DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SEIKYU_JOHO_SETTEI_JIKKO_TIMMING_RIREKI
    ADD(CONSTRAINT PK_TR_SEIKYU_JOHO_SETTEI_JIKKO_TIMMING_RIREKI PRIMARY KEY (EDI_SETTEI_ID, TEKIYO_KAISHIBI, SEIKYU_JOHO_SETTEI_SEQ, EDI_SETTEI_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_SEIKYU_TAISHO_HAITA CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SEIKYU_TAISHO_HAITA
(
    SEIKYU_ID                       NUMBER(18,0) NOT NULL,
    HAITA_JISSHI_SHA_CD             CHAR(7) NOT NULL,
    HAITA_JISSHI_NICHIJI            DATE NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SEIKYU_TAISHO_HAITA
    ADD(CONSTRAINT PK_TR_SEIKYU_TAISHO_HAITA PRIMARY KEY (SEIKYU_ID) USING INDEX)
/
DROP TABLE TR_SEIKYU_MEISAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SEIKYU_MEISAI
(
    SEIKYU_ID                       NUMBER(18,0) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(6,0) NOT NULL,
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    SEIKYUSHO_NO                    VARCHAR2(6) NOT NULL,
    SEIKYUSHO_EDABAN                NUMBER(3,0) NOT NULL,
    URIAGE_KBN                      CHAR(1),
    OKURIJO_NO                      VARCHAR2(13),
    KOKYAKU_CD                      VARCHAR2(6),
    SEIKYUSAKI_CD                   CHAR(6),
    ERROR_JOHO                      VARCHAR2(20),
    SEKIYUSHO_KISAIUMU_FLG          CHAR(1),
    HIZUKE                          DATE,
    MOTOCHAKU_KBN                   VARCHAR2(2),
    ATESAKICHI_MEISHO               VARCHAR2(40),
    NIUKENIN_MEISHO                 VARCHAR2(40),
    HASSOCHI_MEISHO                 VARCHAR2(40),
    NIOKURININ_MEISHO               VARCHAR2(40),
    KOSU                            NUMBER(3,0),
    JURYO                           NUMBER(6,1),
    RYOKIN_KOMOKU_CODE1             CHAR(3),
    RYOKIN_KOMOKU_CODE2             CHAR(3),
    RYOKIN_KOMOKU_CODE3             CHAR(3),
    RYOKIN_KOMOKU_CODE4             CHAR(3),
    RYOKIN_KOMOKU_CODE5             CHAR(3),
    RYOKIN_KOMOKU_CODE6             CHAR(3),
    RYOKIN_KOMOKU_CODE7             CHAR(3),
    RYOKIN_KOMOKU_CODE8             CHAR(3),
    SHOHIZEI_KINGAKU                NUMBER(9,0),
    UCHIZEI_KINGAKU                 NUMBER(9,0),
    KAZEI_TAISHO_KINGAKU            NUMBER(9,0),
    HIKAZEI_KINGAKU                 NUMBER(9,0),
    SEIKYU_KINGAKU                  NUMBER(9,0),
    BIKO_KOMOKU1                    VARCHAR2(40),
    BIKO_KOMOKU2                    VARCHAR2(40),
    AKA_KURO_KBN                    CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJ  DATE
)
/
ALTER TABLE TR_SEIKYU_MEISAI
    ADD(CONSTRAINT PK_TR_SEIKYU_MEISAI_SONOTA_SEIKYU1 PRIMARY KEY (SEIKYU_ID, MEISAI_GYO_NO, URIAGE_ID) USING INDEX)
/
DROP TABLE TR_SEIKYU_MEISAI_SONOTA_SEIKYU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SEIKYU_MEISAI_SONOTA_SEIKYU
(
    SEIKYU_ID                       NUMBER(18,0) NOT NULL,
    SEIKYU_EDABAN                   NUMBER(3,0) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    SEIKYU_KEIJO_NO                 CHAR(6) NOT NULL,
    SEIKYU_HIZUKE                   CHAR(8) NOT NULL,
    SEIKYU_KOMOKU                   VARCHAR2(40),
    KOKYAKU_CD                      CHAR(6),
    TANKA                           NUMBER(10,0),
    TANI                            VARCHAR2(20),
    SURYO                           NUMBER(9,0),
    KINGAKU                         NUMBER(10,0),
    ZEI_KUBUN                       CHAR(1),
    SYOUHIZEI_KINGAKU               NUMBER(10,0) NOT NULL,
    SEIKYUSYO_BIKO                  VARCHAR2(100),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SEIKYU_MEISAI_SONOTA_SEIKYU
    ADD(CONSTRAINT PK_TR_SEIKYU_MEISAI_SONOTA_SEIKYU PRIMARY KEY (SEIKYU_ID, MEISAI_GYO_NO, SEIKYU_EDABAN, URIAGE_ID) USING INDEX)
/
DROP TABLE TR_SEIKYU_MEISAI_SONOTA_SEIKYU_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SEIKYU_MEISAI_SONOTA_SEIKYU_RIREKI
(
    SEIKYU_ID                       NUMBER(18,0) NOT NULL,
    SEIKYUSHO_EDABAN                NUMBER(3,0) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    URIAGE_ID                       NUMBER(18,0),
    SEIKYU_KEIJO_NO                 CHAR(6) NOT NULL,
    SEIKYU_HIZUKE                   CHAR(8) NOT NULL,
    KOKYAKU_CD                      CHAR(6),
    SEIKYU_KOMOKU                   VARCHAR2(40),
    TANKA                           NUMBER(10,0),
    TANI                            VARCHAR2(20),
    SURYO                           NUMBER(9,0),
    KINGAKU                         NUMBER(10,0),
    ZEI_KUBUN                       CHAR(1),
    SYOUHIZEI_KINGAKU               NUMBER(10,0) NOT NULL,
    SEIKYUSYO_BIKO                  VARCHAR2(100),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SEIKYU_MEISAI_SONOTA_SEIKYU_RIREKI
    ADD(CONSTRAINT PK_TR_SEIKYU_MEISAI_SONOTA_SEIKYU_RIREKI PRIMARY KEY (SEIKYU_ID, MEISAI_GYO_NO, SEIKYUSHO_EDABAN) USING INDEX)
/
DROP TABLE TR_SEIKYU_MEISAI_LOGI_URIAGE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SEIKYU_MEISAI_LOGI_URIAGE
(
    SEIKYU_ID                       NUMBER(18,0) NOT NULL,
    SEIKYU_MEISAI_GYO_NO            NUMBER(3,0) NOT NULL,
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    KOKYAKU_CD                      CHAR(6),
    MEISAI_GYO_NO                   NUMBER(5,0) NOT NULL,
    SEIKYU_KOMOKUMEI1               VARCHAR2(50),
    SEIKYU_KOMOKUMEI2               VARCHAR2(50),
    SEIKYU_KOMOKUMEI3               VARCHAR2(50),
    TANKA                           NUMBER(21,0),
    TANI                            VARCHAR2(10),
    SURYO                           NUMBER(9,0),
    KINGAKU                         NUMBER(10,0),
    ZEI_KUBUN                       CHAR(1),
    KAZEI_TAISHO_KINGAKU            NUMBER(10,0),
    SHOHIZEI_KINGAKU                NUMBER(10,0) NOT NULL,
    UCHIZEI_KINGAKU                 NUMBER(10,0),
    HIKAZEI_KINGAKU                 NUMBER(10,0),
    SEIKYU_KINGAKU                  NUMBER(10,0) NOT NULL,
    SEIKYUSHO_BIKO                  VARCHAR2(200),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SEIKYU_MEISAI_LOGI_URIAGE
    ADD(CONSTRAINT PK_TR_SEIKYU_MEISAI_LOGI_URIAGE PRIMARY KEY (SEIKYU_ID, SEIKYU_MEISAI_GYO_NO) USING INDEX)
/
DROP TABLE TR_SEIKYU_MEISAI_LOGI_URIAGE_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SEIKYU_MEISAI_LOGI_URIAGE_RIREKI
(
    SEIKYU_ID                       NUMBER(18,0) NOT NULL,
    SEIKYUSHO_EDABAN                NUMBER(3,0) NOT NULL,
    SEIKYU_MEISAI_GYO_NO            NUMBER(3,0) NOT NULL,
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    KOKYAKU_CD                      CHAR(6),
    MEISAI_GYO_NO                   NUMBER(5,0) NOT NULL,
    SEIKYU_KOMOKU1                  VARCHAR2(50),
    SEIKYU_KOMOKU2                  VARCHAR2(50),
    SEIKYU_KOMOKU3                  VARCHAR2(50),
    TANKA                           NUMBER(21,0),
    TANI                            VARCHAR2(10),
    SURYO                           NUMBER(9,0),
    KINGAKU                         NUMBER(10,0),
    ZEI_KUBUN                       CHAR(1),
    KAZEI_TAISHO_KINGAKU            NUMBER(10,0),
    SHOHIZEI_KINGAKU                NUMBER(10,0) NOT NULL,
    UCHIZEI_KINGAKU                 NUMBER(10,0),
    HIKAZEI_KINGAKU                 NUMBER(10,0),
    SEIKYU_KINGAKU                  NUMBER(10,0) NOT NULL,
    SEIKYUSHO_BIKO                  VARCHAR2(200),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SEIKYU_MEISAI_LOGI_URIAGE_RIREKI
    ADD(CONSTRAINT PK_TR_SEIKYU_MEISAI_LOGI_URIAGE_RIREKI PRIMARY KEY (SEIKYU_ID, SEIKYU_MEISAI_GYO_NO, SEIKYUSHO_EDABAN) USING INDEX)
/
DROP TABLE TR_SEIKYU_MEISAI_DATA CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SEIKYU_MEISAI_DATA
(
    RECORD_KBN                      CHAR(1) NOT NULL,
    KONG_YO_SEIKYUSHO_NO            CHAR(13),
    SEIKYUSAKI_CD                   CHAR(6),
    SHIMEBI                         CHAR(8),
    MEISAI_NO                       NUMBER(5,0),
    OKURIJO_NO                      CHAR(13),
    HENKO_KBN                       NUMBER(1,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
DROP TABLE TR_SEIKYU_MEISAI_DATA_ERROR CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SEIKYU_MEISAI_DATA_ERROR
(
    SHORI_HIZUKE                    CHAR(8) NOT NULL,
    RECORD_KBN                      CHAR(1) NOT NULL,
    KONG_YO_SEIKYUSHO_NO            CHAR(13),
    SEIKYUSAKI_CD                   CHAR(6),
    SHIMEBI                         CHAR(8),
    MEISAI_NO                       NUMBER(5,0),
    OKURIJO_NO                      CHAR(13),
    HENKO_KBN                       NUMBER(1,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
DROP TABLE TR_SEIKYU_MEISAI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SEIKYU_MEISAI_RIREKI
(
    SEIKYU_ID                       NUMBER(18,0) NOT NULL,
    SEIKYUSHO_EDABAN                NUMBER(3,0) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(6,0) NOT NULL,
    SEIKYUSHO_NO                    VARCHAR2(6) NOT NULL,
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    KOKYAKU_CD                      VARCHAR2(6),
    OKURIJO_NO                      VARCHAR2(13),
    SEIKYUSAKI_CD                   VARCHAR2(6),
    ERROR_JOHO                      VARCHAR2(20),
    SEKIYUSHO_KISAIUMU_FLG          CHAR(1),
    SEIKYU_KINGAKU                  NUMBER(9,0),
    SHOHIZEI_KINGAKU                NUMBER(9,0),
    UCHIZEI_KINGAKU                 NUMBER(9,0),
    HIKAZEI_KINGAKU                 NUMBER(9,0),
    KAZEI_TAISHO_KINGAKU            NUMBER(9,0),
    HIZUKE                          DATE,
    MOTOCHAKU_KBN                   VARCHAR2(2),
    ATESAKICHI_MEISHO               VARCHAR2(40),
    NIUKENIN_MEISHO                 VARCHAR2(40),
    HASSOCHI_MEISHO                 VARCHAR2(40),
    NIOKURININ_MEISHO               VARCHAR2(40),
    KOSU                            NUMBER(3,0),
    JURYO                           NUMBER(6,1),
    RYOKIN_KOMOKU_CODE1             CHAR(3),
    RYOKIN_KOMOKU_CODE2             CHAR(3),
    RYOKIN_KOMOKU_CODE3             CHAR(3),
    RYOKIN_KOMOKU_CODE4             CHAR(3),
    RYOKIN_KOMOKU_CODE5             CHAR(3),
    RYOKIN_KOMOKU_CODE6             CHAR(3),
    RYOKIN_KOMOKU_CODE7             CHAR(3),
    RYOKIN_KOMOKU_CODE8             CHAR(3),
    BIKO_KOMOKU1                    VARCHAR2(40),
    BIKO_KOMOKU2                    VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SEIKYU_MEISAI_RIREKI
    ADD(CONSTRAINT PK_TR_SEIKYU_MEISAI1 PRIMARY KEY (SEIKYU_ID, SEIKYUSHO_EDABAN, MEISAI_GYO_NO) USING INDEX)
/
DROP TABLE TR_SEIKYU_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SEIKYU_RIREKI
(
    SEIKYU_ID                       NUMBER(18,0) NOT NULL,
    SEIKYUSAKI_CD                   CHAR(6),
    SEIKYUSHO_NO                    VARCHAR2(6),
    SEIKYUSHO_EDABAN                NUMBER(3,0) NOT NULL,
    KO_SEIKYU_FLG                   CHAR(1) NOT NULL,
    OYA_SEIKYUSHO_NO                VARCHAR2(6),
    SHIMEBI                         CHAR(8) NOT NULL,
    SEIKYU_TAISHO_KIKAN_FROM        CHAR(8) NOT NULL,
    SEIKYU_TAISHO_KIKAN_TO          CHAR(8) NOT NULL,
    SHIHARAI_HOHO_CD                CHAR(2) NOT NULL,
    NYUKIN_YOTEIBI                  CHAR(8) NOT NULL,
    SEIKYU_KINGAKU                  NUMBER(10,0) NOT NULL,
    KAZEI_GOKEI                     NUMBER(10,0) NOT NULL,
    HIKAZEI_GOKEI                   NUMBER(10,0) NOT NULL,
    SHOHIZEI                        NUMBER(10,0) NOT NULL,
    DAIRITEN_FLG                    CHAR(1) NOT NULL,
    SEIKYUSHO_KBN                   CHAR(1) NOT NULL,
    HAKKO_FLG                       CHAR(1) NOT NULL,
    SEIKYU_CHECK_FLG                CHAR(1) NOT NULL,
    WEB_KOKYAKU_KAKUNIN_FLG         CHAR(1) NOT NULL,
    WEB_KOKYAKU_KAKUNIN_NICHIJI     DATE,
    SHIME_JOTAI_FLG                 CHAR(1) NOT NULL,
    SHIME_HOHO_FLG                  CHAR(1) NOT NULL,
    NYUKIN_SUMI_FLG                 CHAR(1) NOT NULL,
    NYUKIN_KINGAKU                  NUMBER(10,0) NOT NULL,
    ERROR_FLG                       CHAR(1) NOT NULL,
    KESHIKOMI_BANK_FILE_DL_FLG      CHAR(1),
    SHOKAI_K_BANK_FILE_DL_USER_CD   CHAR(7),
    SHOKAI_K_BANK_FILE_DL_NICHIJI   DATE,
    SAISHIN_K_BANK_FILE_DL_USER_CD  CHAR(7),
    SAISHIN_K_BANK_FILE_DL_NICHIJI  DATE,
    KO_SEIKYU_KAZU                  NUMBER(5,0) NOT NULL,
    MEISAI_KAZU                     NUMBER(5,0) NOT NULL,
    TANTO_EIGYOSHO_CD               VARCHAR2(5) NOT NULL,
    SEIKYUSHO_OUTPUT_EIGYOSHO_CD    VARCHAR2(5) NOT NULL,
    SEIKYUSHO_SHUTSURYOKU_SHA_CD    CHAR(7),
    SEIKYUSHO_OUTPUT_DATE           DATE,
    SAI_SHIME_JISSHI_SHA_CD         CHAR(7),
    SAI_SHIME_JISSHI_NICHIJI        DATE,
    TOKUBETSU_SHIME_JISSHI_SHA_CD   CHAR(7),
    TOKUBETSU_SHIME_JISSHI_NICHIJI  DATE,
    SHOKAI_INSATSU_SHA_CD           CHAR(7),
    SHOKAI_INSATSU_NICHIJI          DATE,
    SAISHIN_INSATSU_SHA_CD          CHAR(7),
    SAISHIN_INSATSU_NICHIJI         DATE,
    SAISHIN_NYUKINBI                CHAR(8),
    INSATSUCHU_FLG                  CHAR(1) NOT NULL,
    SAI_SHIME_TAISHO_FLG            CHAR(1) NOT NULL,
    KEIRI_RENKEI_SUMI_FLG           CHAR(1) NOT NULL,
    URIAGE_KBN                      CHAR(1) NOT NULL,
    SUPERSTREAM_RENKEI_FLG          CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SEIKYU_RIREKI
    ADD(CONSTRAINT PK_TR_SEIKYU_RIREKI PRIMARY KEY (SEIKYU_ID, SEIKYUSHO_EDABAN) USING INDEX)
/
DROP TABLE TR_SOGO_TRACE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SOGO_TRACE
(
    OKURIJO_NO                      CHAR(13) NOT NULL,
    NYURYOKU_TEN                    VARCHAR2(5) NOT NULL,
    TRACE_SHUBETSU                  CHAR(2) NOT NULL,
    NYURYOKU_NENGAPPI               CHAR(8) NOT NULL,
    NYURYOKU_JIKAN                  CHAR(6),
    KOSU                            NUMBER(3,0),
    TRACE_JOTAI_KBN                 CHAR(2),
    KICHOHIN_KBN                    CHAR(2),
    SHABAN                          CHAR(5),
    CHAKU_TEN                       VARCHAR2(5),
    FLIGHT_NO                       VARCHAR2(4),
    CONTAINER_NO                    VARCHAR2(6),
    AWB_NO                          VARCHAR2(8),
    SHIWAKE_CD                      CHAR(7),
    YUSO_HOHO_CD                    CHAR(2),
    ITAKU_NENGAPPI                  CHAR(8),
    ITAKU_JIKAN                     CHAR(6),
    ITAKUSAKI_CD                    VARCHAR2(5),
    MANIFESTO_JOGAI_FLG             CHAR(1),
    SHUSEI_KOSU                     NUMBER(3,0),
    BIKO_1                          VARCHAR2(40),
    BIKO_2                          VARCHAR2(40),
    DATA_MOTO                       CHAR(2),
    HASSEI_NICHIJI                  DATE,
    URIAGE_ID                       NUMBER(18,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SOGO_TRACE
    ADD(CONSTRAINT PK_TR_SOGO_TRACE PRIMARY KEY (OKURIJO_NO, NYURYOKU_TEN, TRACE_SHUBETSU, NYURYOKU_NENGAPPI) USING INDEX)
/
DROP TABLE TR_SOGO_TRACE_EDABAN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SOGO_TRACE_EDABAN
(
    OKURIJO_NO                      CHAR(13) NOT NULL,
    EDABAN                          VARCHAR2(3) NOT NULL,
    NYURYOKU_TEN                    VARCHAR2(5) NOT NULL,
    TRACE_SHUBETSU                  CHAR(2) NOT NULL,
    NYURYOKU_NENGAPPI               CHAR(8) NOT NULL,
    NYURYOKU_JIKAN                  CHAR(6),
    HHT_BANGO                       CHAR(15),
    TANTOSHA                        CHAR(7),
    SHABAN                          CHAR(5),
    CHAKU_TEN                       VARCHAR2(5),
    FLIGHT_NO                       VARCHAR2(4),
    CONTAINER_NO                    VARCHAR2(6),
    AWB_NO                          VARCHAR2(8),
    SHIWAKE_CD                      CHAR(7),
    YUSO_HOHO_CD                    CHAR(2),
    ITAKUSAKI_CD                    VARCHAR2(5),
    KEITAI_DENWA_BANGO              VARCHAR2(19),
    UNIT_NO                         VARCHAR2(20),
    OKURIJO_NO_NYURYOKU_MOTO_FLG    CHAR(1),
    HASSEI_NICHIJI                  DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SOGO_TRACE_EDABAN
    ADD(CONSTRAINT PK_TR_SOGO_TRACE_EDABAN PRIMARY KEY (OKURIJO_NO, EDABAN, NYURYOKU_TEN, TRACE_SHUBETSU, NYURYOKU_NENGAPPI) USING INDEX)
/
DROP TABLE TR_OKURIJO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_OKURIJO
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    OKURIJO_SEQ                     NUMBER(18,0) NOT NULL,
    OKURIJO_NO                      CHAR(13),
    SHUKABI                         CHAR(8),
    DEMPYO_SHUBETSU_CD              CHAR(2),
    YUSO_HOHO_CD                    CHAR(2),
    NIUKENIN_HAKKO_CD               VARCHAR2(20),
    NIUKENIN_TEL_BANGO              VARCHAR2(19),
    NIUKENIN_YUBIN_BANGO            CHAR(7),
    NIUKENIN_JIS_CD                 CHAR(5),
    NIUKENIN_JUSHO_1                VARCHAR2(40),
    NIUKENIN_JUSHO_2                VARCHAR2(40),
    NIUKENIN_JUSHO_3                VARCHAR2(40),
    NIUKENIN_JUSHO_4                VARCHAR2(40),
    NIUKENIN_MEISHO_1               VARCHAR2(40),
    NIUKENIN_MEISHO_2               VARCHAR2(40),
    NIUKENIN_MEISHO_3               VARCHAR2(40),
    NIUKENIN_MEISHO_4               VARCHAR2(40),
    HAITATSU_EIGYOSHO_CD            VARCHAR2(5),
    SHIMUKE_CHI_CD                  CHAR(7),
    SHIMUKE_CHI_MEI_CD              VARCHAR2(4),
    HIMMEI                          VARCHAR2(40),
    TOKKI_JIKO                      VARCHAR2(40),
    KIJI_RAN_1                      VARCHAR2(40),
    KIJI_RAN_2                      VARCHAR2(40),
    KIJI_RAN_3                      VARCHAR2(40),
    KIJI_RAN_4                      VARCHAR2(40),
    KIJI_RAN_5                      VARCHAR2(40),
    NIOKURININ_HAKKO_CD             VARCHAR2(20),
    NIOKURININ_TEL_BANGO            VARCHAR2(19),
    NIOKURININ_YUBIN_BANGO          CHAR(7),
    NIOKURININ_JIS_CD               CHAR(5),
    NIOKURININ_JUSHO_1              VARCHAR2(40),
    NIOKURININ_JUSHO_2              VARCHAR2(40),
    NIOKURININ_JUSHO_3              VARCHAR2(40),
    NIOKURININ_JUSHO_4              VARCHAR2(40),
    NIOKURININ_MEISHO_1             VARCHAR2(40),
    NIOKURININ_MEISHO_2             VARCHAR2(40),
    NIOKURININ_MEISHO_3             VARCHAR2(40),
    NIOKURININ_MEISHO_4             VARCHAR2(40),
    SHUKA_EIGYOSHO_CD               VARCHAR2(5),
    HAISO_SHIJI                     CHAR(1),
    HAITATSU_SHITEIBI               CHAR(8),
    HAITATSU_SHITEIJIKOKU           VARCHAR2(40),
    HAITATSU_SHITEIJIKOKU_CHU       CHAR(1),
    KOSU                            NUMBER(3,0),
    JURYO                           NUMBER(6,1),
    YOSEKI_JURYO                    NUMBER(9,1),
    OKYAKUSAMA_KANRI_NO             VARCHAR2(20),
    HIKITORI_FLG                    CHAR(1),
    YOKYU_EIGYOSHO_CD               VARCHAR2(5) NOT NULL,
    YOKYU_ID                        NUMBER(7,0) NOT NULL,
    YOKYU_ID_EDABAN                 NUMBER(3,0) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_OKURIJO
    ADD(CONSTRAINT PK_TR_OKURIJO PRIMARY KEY (KOKYAKU_CD, OKURIJO_SEQ) USING INDEX)
/
DROP TABLE TR_OKURIJO_URIAGE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_OKURIJO_URIAGE
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(18,0) NOT NULL,
    AKA_KURO_KBN                    CHAR(1) NOT NULL,
    OKURIJO_NO                      CHAR(13),
    SHUKABI                         CHAR(8),
    SAISIN_URIAGE_FLG               CHAR(1),
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    OKURIJO_SEQ                     NUMBER(18,0) NOT NULL,
    DEMPYO_SHUBETSU_CD              CHAR(2) NOT NULL,
    YUSO_HOHO_CD                    CHAR(2),
    NIUKENIN_HAKKO_CD               VARCHAR2(20),
    NIUKENIN_TEL_BANGO              VARCHAR2(19),
    NIUKENIN_YUBIN_BANGO            CHAR(7),
    NIUKENIN_JIS_CD                 CHAR(5),
    NIUKENIN_JUSHO                  VARCHAR2(160),
    NIUKENIN_JUSHO_1                VARCHAR2(40),
    NIUKENIN_JUSHO_2                VARCHAR2(40),
    NIUKENIN_JUSHO_3                VARCHAR2(40),
    NIUKENIN_JUSHO_4                VARCHAR2(40),
    NIUKENIN_MEISHO_1               VARCHAR2(40),
    NIUKENIN_MEISHO_2               VARCHAR2(40),
    NIUKENIN_MEISHO_3               VARCHAR2(40),
    NIUKENIN_MEISHO_4               VARCHAR2(40),
    HAITATSU_EIGYOSHO_CD            VARCHAR2(5),
    SHIMUKE_CHI_CD                  CHAR(7),
    SHIMUKE_CHI_MEI_CD              VARCHAR2(4),
    HIMMEI                          VARCHAR2(40),
    TOKKI_JIKO                      VARCHAR2(40),
    KIJI_RAN_1                      VARCHAR2(40),
    KIJI_RAN_2                      VARCHAR2(40),
    KIJI_RAN_3                      VARCHAR2(40),
    KIJI_RAN_4                      VARCHAR2(40),
    KIJI_RAN_5                      VARCHAR2(40),
    NIOKURININ_HAKKO_CD             VARCHAR2(20),
    NIOKURININ_TEL_BANGO            VARCHAR2(19),
    NIOKURININ_YUBIN_BANGO          CHAR(7),
    NIOKURININ_JIS_CD               CHAR(5),
    NIOKURININ_JUSHO                VARCHAR2(160),
    NIOKURININ_JUSHO_1              VARCHAR2(40),
    NIOKURININ_JUSHO_2              VARCHAR2(40),
    NIOKURININ_JUSHO_3              VARCHAR2(40),
    NIOKURININ_JUSHO_4              VARCHAR2(40),
    NIOKURININ_MEISHO_1             VARCHAR2(40),
    NIOKURININ_MEISHO_2             VARCHAR2(40),
    NIOKURININ_MEISHO_3             VARCHAR2(40),
    NIOKURININ_MEISHO_4             VARCHAR2(40),
    SHUKA_EIGYOSHO_CD               VARCHAR2(5),
    HAISO_SHIJI                     CHAR(1),
    HAITATSU_SHITEIBI               CHAR(8),
    HAITATSU_SHITEIJIKOKU           VARCHAR2(40),
    HAITATSU_SHITEIJIKOKU_CHUSHAKU  CHAR(1),
    KOSU                            NUMBER(3,0),
    JURYO                           NUMBER(6,1),
    YOSEKI_JURYO                    NUMBER(9,1),
    HIKITORI_FLG                    CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_OKURIJO_URIAGE
    ADD(CONSTRAINT PK_TR_OKURIJO_URIAGE PRIMARY KEY (URIAGE_ID, URIAGE_DATA_VERSION, AKA_KURO_KBN) USING INDEX)
/
DROP TABLE TR_OKURIJO_URIAGE_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_OKURIJO_URIAGE_RIREKI
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(18,0) NOT NULL,
    OKURIJO_NO                      CHAR(13),
    SHUKABI                         CHAR(8),
    KOKYAKU_CD                      CHAR(6),
    OKURIJO_SEQ                     NUMBER(18,0),
    DEMPYO_SHUBETSU_CD              CHAR(2),
    YUSO_HOHO_CD                    CHAR(2),
    NIUKENIN_HAKKO_CD               VARCHAR2(20),
    NIUKENIN_TEL_BANGO              VARCHAR2(19),
    NIUKENIN_YUBIN_BANGO            CHAR(7),
    NIUKENIN_JIS_CD                 CHAR(5),
    NIUKENIN_JUSHO_1                VARCHAR2(40),
    NIUKENIN_JUSHO_2                VARCHAR2(40),
    NIUKENIN_JUSHO_3                VARCHAR2(40),
    NIUKENIN_JUSHO_4                VARCHAR2(40),
    NIUKENIN_MEISHO_1               VARCHAR2(40),
    NIUKENIN_MEISHO_2               VARCHAR2(40),
    NIUKENIN_MEISHO_3               VARCHAR2(40),
    NIUKENIN_MEISHO_4               VARCHAR2(40),
    HAITATSU_EIGYOSHO_CD            VARCHAR2(5),
    SHIMUKE_CHI_CD                  CHAR(7),
    SHIMUKE_CHI_MEI_CD              VARCHAR2(4),
    HIMMEI                          VARCHAR2(40),
    TOKKI_JIKO                      VARCHAR2(40),
    KIJI_RAN_1                      VARCHAR2(40),
    KIJI_RAN_2                      VARCHAR2(40),
    KIJI_RAN_3                      VARCHAR2(40),
    KIJI_RAN_4                      VARCHAR2(40),
    KIJI_RAN_5                      VARCHAR2(40),
    NIOKURININ_HAKKO_CD             VARCHAR2(20),
    NIOKURININ_TEL_BANGO            VARCHAR2(19),
    NIOKURININ_YUBIN_BANGO          CHAR(7),
    NIOKURININ_JIS_CD               CHAR(5),
    NIOKURININ_JUSHO_1              VARCHAR2(40),
    NIOKURININ_JUSHO_2              VARCHAR2(40),
    NIOKURININ_JUSHO_3              VARCHAR2(40),
    NIOKURININ_JUSHO_4              VARCHAR2(40),
    NIOKURININ_MEISHO_1             VARCHAR2(40),
    NIOKURININ_MEISHO_2             VARCHAR2(40),
    NIOKURININ_MEISHO_3             VARCHAR2(40),
    NIOKURININ_MEISHO_4             VARCHAR2(40),
    SHUKA_EIGYOSHO_CD               VARCHAR2(5),
    HAISO_SHIJI                     CHAR(1),
    HAITATSU_SHITEIBI               CHAR(8),
    HAITATSU_SHITEIJIKOKU           VARCHAR2(40),
    HAITATSU_SHITEIJIKOKU_CHUSHAKU  CHAR(1),
    KOSU                            NUMBER(3,0),
    JURYO                           NUMBER(6,1),
    YOSEKI_JURYO                    NUMBER(9,1),
    HIKITORI_FLG                    CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_OKURIJO_URIAGE_RIREKI
    ADD(CONSTRAINT PK_TR_OKURIJO_URIAGE_RIREKI PRIMARY KEY (URIAGE_ID, URIAGE_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_OKURIJO_NO_SAIBAN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_OKURIJO_NO_SAIBAN
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    HAKKO_SAKI_KBN                  CHAR(1),
    SAISHU_HAKKO_OKURIJO_NO         CHAR(13),
    JUNKAN_KAISU                    NUMBER(6,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_OKURIJO_NO_SAIBAN
    ADD(CONSTRAINT PK_TR_OKURIJO_NO_SAIBAN PRIMARY KEY (KOKYAKU_CD) USING INDEX)
/
DROP TABLE TR_OKURIJO_GAZO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_OKURIJO_GAZO
(
    GAZO_ID                         NUMBER(18,0) NOT NULL,
    EIGYOSHO_CD                     VARCHAR2(5) NOT NULL,
    OKURIJO_NO                      CHAR(13) NOT NULL,
    SCAN_USER                       CHAR(7) NOT NULL,
    SCAN_NICHIJI                    DATE NOT NULL,
    UPLOAD_ID                       VARCHAR2(18) NOT NULL,
    UPLOAD_USER                     CHAR(7) NOT NULL,
    UPLOAD_JIKOKU                   DATE NOT NULL,
    TOROKU_GAZO                     CHAR(1) NOT NULL,
    GAZO_PATH_1                     VARCHAR2(512),
    GAZO_PATH_1_ANGLE               NUMBER(3,0),
    GAZO_PATH_2                     VARCHAR2(512),
    GAZO_PATH_2_ANGLE               NUMBER(3,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_OKURIJO_GAZO
    ADD(CONSTRAINT PK_TR_OKURIJO_GAZO PRIMARY KEY (GAZO_ID) USING INDEX)
/
DROP TABLE TR_OKURIJO_SAI_HAKKO_JISSEKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_OKURIJO_SAI_HAKKO_JISSEKI
(
    YOKYU_EIGYOSHO_CD               VARCHAR2(5) NOT NULL,
    YOKYU_ID                        NUMBER(7,0) NOT NULL,
    YOKYU_ID_EDABAN                 NUMBER(3,0) NOT NULL,
    OKURIJO_SAI_HAKKO_SEQ           NUMBER(5,0) NOT NULL,
    OKURIJO_NO                      CHAR(13) NOT NULL,
    SAI_HAKKO_KBN                   CHAR(1),
    HAKKO_EIGYOSHO_CD               VARCHAR2(5),
    HAKKO_NICHIJI                   DATE,
    HAKKOSHA                        CHAR(7),
    HAKKO_TAMMATSU                  VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_OKURIJO_SAI_HAKKO_JISSEKI
    ADD(CONSTRAINT PK_TR_OKURIJO_SAI_HAKKO_JISSEKI PRIMARY KEY (YOKYU_ID_EDABAN, OKURIJO_SAI_HAKKO_SEQ, OKURIJO_NO, YOKYU_EIGYOSHO_CD, YOKYU_ID) USING INDEX)
/
DROP TABLE TR_OKURIJO_HAKKO_PTN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_OKURIJO_HAKKO_PTN
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    OKURIJO_HAKKO_PTN_ID            NUMBER(5,0) NOT NULL,
    OKURIJO_HAKKO_PTN_MEISHO        VARCHAR2(40),
    DEMPYO_SHUBETSU_CD              CHAR(2),
    YUSO_HOHO_CD                    CHAR(2),
    NIFUDA_HAKKO_UMU                CHAR(1),
    NIOKURININ_HAKKO_CD             VARCHAR2(20),
    NIOKURININ_TEL_BANGO            VARCHAR2(19),
    NIOKURININ_MEISHO_1             VARCHAR2(40),
    NIOKURININ_MEISHO_2             VARCHAR2(40),
    NIOKURININ_MEISHO_3             VARCHAR2(40),
    NIOKURININ_MEISHO_4             VARCHAR2(40),
    NIOKURININ_YUBIN_BANGO          CHAR(7),
    NIOKURININ_JIS_CD               CHAR(5),
    NIOKURININ_JUSHO_1              VARCHAR2(40),
    NIOKURININ_JUSHO_2              VARCHAR2(40),
    NIOKURININ_JUSHO_3              VARCHAR2(40),
    NIOKURININ_JUSHO_4              VARCHAR2(40),
    SHUKA_EIGYOSHO_CD               VARCHAR2(5),
    HAITATSU_SHITEIBI               CHAR(8),
    HAITATSU_SHITEIJIKOKU           VARCHAR2(40),
    HAITATSU_SHITEIJIKOKU_CHUSHAKU  CHAR(1),
    KOSU                            NUMBER(3,0),
    KOSU_MIKAKUTEI_FLG              CHAR(1),
    JURYO                           NUMBER(6,1),
    YOSEKI_JURYO                    NUMBER(9,1),
    OKYAKUSAMA_KANRI_NO             VARCHAR2(20),
    HIKITORI_FLG                    CHAR(1),
    OKURIJO_LAYOUT_CD               CHAR(2),
    NIFUDA_LAYOUT_CD                CHAR(2),
    MEMO                            VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_OKURIJO_HAKKO_PTN
    ADD(CONSTRAINT PK_TR_OKURIJO_HAKKO_PTN PRIMARY KEY (OKURIJO_HAKKO_PTN_ID, KOKYAKU_CD) USING INDEX)
/
DROP TABLE TR_OKURIJO_HAKKO_PTN_ID_SAIBAN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_OKURIJO_HAKKO_PTN_ID_SAIBAN
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    SAISHU_OKURIJO_HAKKO_PTN_ID     NUMBER(5,0) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_OKURIJO_HAKKO_PTN_ID_SAIBAN
    ADD(CONSTRAINT PK_OKURIJO_HAKKO_PTN_ID_SAIBAN PRIMARY KEY (KOKYAKU_CD) USING INDEX)
/
DROP TABLE TR_OKURIJO_HAKKO_PTN_HYOJI_JUN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_OKURIJO_HAKKO_PTN_HYOJI_JUN
(
    USER_CD                         CHAR(7) NOT NULL,
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    OKURIJO_HAKKO_PTN_ID            NUMBER(5,0) NOT NULL,
    ZENTAI_HYOJI_JUN                NUMBER(7,0),
    KOKYAKU_BETSU_HYOJI_JUN         NUMBER(7,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_OKURIJO_HAKKO_PTN_HYOJI_JUN
    ADD(CONSTRAINT PK_TR_OKURIJO_HAKKO_PTN_HYOJI_JUN PRIMARY KEY (USER_CD, KOKYAKU_CD, OKURIJO_HAKKO_PTN_ID) USING INDEX)
/
DROP TABLE TR_OKURIJO_HAKKO_NIUKENIN_PTN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_OKURIJO_HAKKO_NIUKENIN_PTN
(
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    OKURIJO_HAKKO_PTN_ID            NUMBER(5,0) NOT NULL,
    NIUKENIN_HAKKO_CD               VARCHAR2(20) NOT NULL,
    NIUKENIN_TEL_BANGO              VARCHAR2(19),
    NIUKENIN_YUBIN_BANGO            CHAR(7),
    NIUKENIN_JIS_CD                 CHAR(5),
    NIUKENIN_JUSHO_1                VARCHAR2(40),
    NIUKENIN_JUSHO_2                VARCHAR2(40),
    NIUKENIN_JUSHO_3                VARCHAR2(40),
    NIUKENIN_JUSHO_4                VARCHAR2(40),
    NIUKENIN_MEISHO_1               VARCHAR2(40),
    NIUKENIN_MEISHO_2               VARCHAR2(40),
    NIUKENIN_MEISHO_3               VARCHAR2(40),
    NIUKENIN_MEISHO_4               VARCHAR2(40),
    SHIMUKE_CHI_CD                  CHAR(7),
    SHIMUKE_CHI_MEI_CD              VARCHAR2(4),
    HAITATSU_EIGYOSHO_CD            VARCHAR2(5),
    HIMMEI                          VARCHAR2(40),
    TOKKI_JIKO                      VARCHAR2(40),
    KIJI_RAN_1                      VARCHAR2(40),
    KIJI_RAN_2                      VARCHAR2(40),
    KIJI_RAN_3                      VARCHAR2(40),
    KIJI_RAN_4                      VARCHAR2(40),
    KIJI_RAN_5                      VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_OKURIJO_HAKKO_NIUKENIN_PTN
    ADD(CONSTRAINT PK_TR_OKURIJO_HAKKO_NIUKENIN_PTN PRIMARY KEY (KOKYAKU_CD, OKURIJO_HAKKO_PTN_ID, NIUKENIN_HAKKO_CD) USING INDEX)
/
DROP TABLE TR_OKURIJO_HAKKO_JISSEKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_OKURIJO_HAKKO_JISSEKI
(
    YOKYU_EIGYOSHO_CD               VARCHAR2(5) NOT NULL,
    YOKYU_ID                        NUMBER(7,0) NOT NULL,
    KOKYAKU_CD                      CHAR(6),
    OKURIJO_HAKKO_PTN_ID            NUMBER(5,0),
    SHUKABI                         DATE,
    DEMPYO_SHUBETSU_CD              CHAR(2),
    YUSO_HOHO_CD                    CHAR(2),
    OKURIJO_HAKKO_MAISU             NUMBER(4,0),
    HAKKO_EIGYOSHO_CD               VARCHAR2(5),
    NIFUDA_HAKKO_UMU                CHAR(1),
    NIOKURININ_HAKKO_CD             VARCHAR2(20),
    NIOKURININ_TEL_BANGO            VARCHAR2(19),
    NIOKURININ_MEISHO_1             VARCHAR2(40),
    NIOKURININ_MEISHO_2             VARCHAR2(40),
    NIOKURININ_MEISHO_3             VARCHAR2(40),
    NIOKURININ_MEISHO_4             VARCHAR2(40),
    NIOKURININ_YUBIN_BANGO          CHAR(7),
    NIOKURININ_JIS_CD               CHAR(5),
    NIOKURININ_JUSHO_1              VARCHAR2(40),
    NIOKURININ_JUSHO_2              VARCHAR2(40),
    NIOKURININ_JUSHO_3              VARCHAR2(40),
    NIOKURININ_JUSHO_4              VARCHAR2(40),
    SHUKA_EIGYOSHO_CD               VARCHAR2(5),
    HAISO_SHIJI                     CHAR(1),
    HAITATSU_SHITEIBI               CHAR(8),
    HAITATSU_SHITEIJIKOKU           VARCHAR2(40),
    HAITATSU_SHITEIJIKOKU_CHUSHAKU  CHAR(1),
    KOSU                            NUMBER(3,0),
    JURYO                           NUMBER(6,1),
    YOSEKI_JURYO                    NUMBER(9,1),
    HIKITORI_FLG                    CHAR(1),
    OKURIJO_LAYOUT_CD               CHAR(2),
    NIFUDA_LAYOUT_CD                CHAR(2),
    TOROKU_KBN                      CHAR(1),
    YOKYU_NICHIJI                   DATE,
    OKURIJO_HAKKO_KBN               CHAR(1),
    OKURIJO_HAKKO_EIGYOSHO_CD       VARCHAR2(5),
    OKURIJO_HAKKO_NICHIJI           DATE,
    OKURIJO_HAKKOSHA                CHAR(7),
    OKURIJO_HAKKO_TAMMATSU          VARCHAR2(60),
    NIFUDA_HAKKO_KBN                CHAR(1),
    NIFUDA_HAKKO_MAISU              NUMBER(10,0),
    NIFUDA_HAKKO_EIGYOSHO           VARCHAR2(5),
    NIFUDA_HAKKO_NICHIJI            DATE,
    NIFUDA_HAKKOSHA                 CHAR(7),
    NIFUDA_HAKKO_TAMMATSU           VARCHAR2(60),
    HAKKO_OKURIJO_NO_FROM           CHAR(13),
    HAKKO_OKURIJO_NO_TO             CHAR(13),
    OKYAKUSAMA_KANRI_NO             VARCHAR2(20),
    KOSU_MIKAKUTEI_FLG              CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_OKURIJO_HAKKO_JISSEKI
    ADD(CONSTRAINT PK_TR_OKURIJO_HAKKO_JISSEKI PRIMARY KEY (YOKYU_EIGYOSHO_CD, YOKYU_ID) USING INDEX)
/
DROP TABLE TR_OKURIJO_HAKKO_JISSEKI_SHOSAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_OKURIJO_HAKKO_JISSEKI_SHOSAI
(
    YOKYU_EIGYOSHO_CD               VARCHAR2(5) NOT NULL,
    YOKYU_ID                        NUMBER(7,0) NOT NULL,
    YOKYU_ID_EDABAN                 NUMBER(3,0) NOT NULL,
    HAKKO_MAISU                     NUMBER(4,0),
    NIUKENIN_HAKKO_CD               VARCHAR2(20),
    NIUKENIN_TEL_BANGO              VARCHAR2(19),
    NIUKENIN_YUBIN_BANGO            CHAR(7),
    NIUKENIN_JIS_CD                 CHAR(5),
    NIUKENIN_JUSHO_1                VARCHAR2(40),
    NIUKENIN_JUSHO_2                VARCHAR2(40),
    NIUKENIN_JUSHO_3                VARCHAR2(40),
    NIUKENIN_JUSHO_4                VARCHAR2(40),
    NIUKENIN_MEISHO_1               VARCHAR2(40),
    NIUKENIN_MEISHO_2               VARCHAR2(40),
    NIUKENIN_MEISHO_3               VARCHAR2(40),
    NIUKENIN_MEISHO_4               VARCHAR2(40),
    SHIMUKE_CHI_CD                  CHAR(7),
    HAITATSU_EIGYOSHO_CD            VARCHAR2(5),
    HIMMEI_CD                       CHAR(3),
    HIMMEI                          VARCHAR2(40),
    TOKKI_JIKO_CD                   CHAR(3),
    TOKKI_JIKO                      VARCHAR2(40),
    KIJI_RAN_1_CD                   CHAR(3),
    KIJI_RAN_1                      VARCHAR2(40),
    KIJI_RAN_2_CD                   CHAR(3),
    KIJI_RAN_2                      VARCHAR2(40),
    KIJI_RAN_3_CD                   CHAR(3),
    KIJI_RAN_3                      VARCHAR2(40),
    KIJI_RAN_4_CD                   CHAR(3),
    KIJI_RAN_4                      VARCHAR2(40),
    KIJI_RAN_5_CD                   CHAR(3),
    KIJI_RAN_5                      VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_OKURIJO_HAKKO_JISSEKI_SHOSAI
    ADD(CONSTRAINT PK_TR_OKURIJO_HAKKO_JISSEKI_SHOSAI PRIMARY KEY (YOKYU_ID_EDABAN, YOKYU_EIGYOSHO_CD, YOKYU_ID) USING INDEX)
/
DROP TABLE MS_DAIRI_SHONIN_USER CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_DAIRI_SHONIN_USER
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    USER_CD                         CHAR(7) NOT NULL,
    DAIRI_SHONINSHA_SETTEI_DATA_VERSION NUMBER(3,0) NOT NULL,
    TEIAN_SHINSEI                   CHAR(1) NOT NULL,
    RYOKIN_TOROKU_SHINSEI           CHAR(1) NOT NULL,
    URIAGE_SAKUJO                   CHAR(1) NOT NULL,
    SONOTA_SEIKYU_URIAGE_SAKUJO     CHAR(1) NOT NULL,
    GENKIN_KAISHU_SAKUJO            CHAR(1) NOT NULL,
    TRACE_SAKUJO                    CHAR(1) NOT NULL,
    SHIME_KAIJO                     CHAR(1) NOT NULL,
    LOGI_DATA_SAKUJO                CHAR(1) NOT NULL,
    SHUKIN_KAIJO                    CHAR(1) NOT NULL,
    PASSWORD_SHOKIKA                CHAR(1) NOT NULL,
    USER_MASTER                     CHAR(1) NOT NULL,
    KOKYAKU_MASTER                  CHAR(1) NOT NULL,
    SHIIRESAKI_MASTER               CHAR(1) NOT NULL,
    SHISETSU_MASTER                 CHAR(1) NOT NULL,
    GETSUGAKU_JIDO_SEIKYU_MASTER    CHAR(1) NOT NULL,
    EIGYOBI_CALENDER                CHAR(1) NOT NULL,
    LOGI_RYOKIN_HYO                 CHAR(1) NOT NULL,
    TAIRYO_DATA_DL                  CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_DAIRI_SHONIN_USER
    ADD(CONSTRAINT PK_MS_DAIRI_SHONIN_USER PRIMARY KEY (EIGYOSHO_CD, USER_CD) USING INDEX)
/
DROP TABLE MS_DAIRI_SHONIN_USER_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_DAIRI_SHONIN_USER_RIREKI
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    USER_CD                         CHAR(7) NOT NULL,
    DAIRI_SHONINSHA_SETTEI_DATA_VERSION NUMBER(3,0) NOT NULL,
    TEIAN_SHINSEI                   CHAR(1) NOT NULL,
    RYOKIN_TOROKU_SHINSEI           CHAR(1) NOT NULL,
    URIAGE_SAKUJO                   CHAR(1) NOT NULL,
    SONOTA_SEIKYU_URIAGE_SAKUJO     CHAR(1) NOT NULL,
    GENKIN_KAISHU_SAKUJO            CHAR(1) NOT NULL,
    TRACE_SAKUJO                    CHAR(1) NOT NULL,
    SHIME_KAIJO                     CHAR(1) NOT NULL,
    LOGI_DATA_SAKUJO                CHAR(1) NOT NULL,
    SHUKIN_KAIJO                    CHAR(1) NOT NULL,
    PASSWORD_SHOKIKA                CHAR(1) NOT NULL,
    USER_MASTER                     CHAR(1) NOT NULL,
    KOKYAKU_MASTER                  CHAR(1) NOT NULL,
    SHIIRESAKI_MASTER               CHAR(1) NOT NULL,
    SHISETSU_MASTER                 CHAR(1) NOT NULL,
    GETSUGAKU_JIDO_SEIKYU_MASTER    CHAR(1) NOT NULL,
    EIGYOBI_CALENDER                CHAR(1) NOT NULL,
    LOGI_RYOKIN_HYO                 CHAR(1) NOT NULL,
    TAIRYO_DATA_DL                  CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_DAIRI_SHONIN_USER_RIREKI
    ADD(CONSTRAINT PK_MS_DAIRI_SHONIN_USER_RIREKI PRIMARY KEY (EIGYOSHO_CD, USER_CD, DAIRI_SHONINSHA_SETTEI_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_DAIRITEN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_DAIRITEN
(
    DAIRITEN_CD                     VARCHAR2(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    DAIRITEN_DATA_VERSION           NUMBER(3,0) NOT NULL,
    TEKIYO_MEI                      VARCHAR2(40),
    DAIRITEN_MEI                    VARCHAR2(40) NOT NULL,
    DAIRITEN_KANA_MEI               VARCHAR2(40),
    DAIHYO_FLG                      CHAR(1),
    DAIRITEN_RYAKUSHO               VARCHAR2(20),
    EIGO_HYOUKI                     VARCHAR2(40),
    DAIHYO_CD                       VARCHAR2(5),
    SHUKA_TEN_FLG                   CHAR(1) NOT NULL,
    HAITATSU_TEN_FLG                CHAR(1) NOT NULL,
    CHARTER_KITEN_FLG               CHAR(1) NOT NULL,
    HAITATSU_SHUTURYOKUTEN_FLG      CHAR(1) NOT NULL,
    SHIIRESAKI_CD                   VARCHAR2(5),
    KOKYAKU_CD                      CHAR(6),
    KAISHA_MEI                      VARCHAR2(40),
    KAISHA_KANA_MEI                 VARCHAR2(40),
    SHITEN_MEI                      VARCHAR2(20),
    SHITEN_KANA_MEI                 VARCHAR2(20),
    BUSHO_TANTOSHA_1                VARCHAR2(40),
    BUSHO_TANTOSHA_2                VARCHAR2(40),
    YUBIN_BANGO                     VARCHAR2(5),
    JIS_CD                          CHAR(5),
    JUSHO_1                         VARCHAR2(40),
    JUSHO_2                         VARCHAR2(40),
    JUSHO_3                         VARCHAR2(40),
    JUSHO_4                         VARCHAR2(40),
    JUSHO                           VARCHAR2(160),
    KUKO_CD                         CHAR(3),
    SHIMUKE_CHI_CD                  CHAR(7),
    SHUHAI_CHIKU                    CHAR(1),
    TEL_BANGO_1                     VARCHAR2(19),
    TEL_BANGO_2                     VARCHAR2(19),
    FAX_BANGO                       VARCHAR2(19),
    KANI_GINKO_CD                   CHAR(3),
    SAIBAN_KINO_SHIYO_UMU           CHAR(1) NOT NULL,
    OKURIJO_KANRI_TANI              CHAR(1) NOT NULL,
    OKURIJO_CHECK_DIGIT             CHAR(2) NOT NULL,
    OKURIJO_BARCODE                 CHAR(2) NOT NULL,
    OKURIJO_START_STOP              CHAR(2) NOT NULL,
    NIFUDA_INJI_TAIKEI              CHAR(2) NOT NULL,
    NIFUDA_EDABAN_TAIKEI            CHAR(2) NOT NULL,
    NIFUDA_BARCODE                  CHAR(2) NOT NULL,
    NIFUDA_START_STOP               CHAR(2) NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_DAIRITEN
    ADD(CONSTRAINT PK_MS_DAIRITEN PRIMARY KEY (DAIRITEN_CD, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE MS_DAIRITEN_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_DAIRITEN_RIREKI
(
    DAIRITEN_CD                     VARCHAR2(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    DAIRITEN_DATA_VERSION           NUMBER(3,0) NOT NULL,
    TEKIYO_MEI                      VARCHAR2(40),
    DAIRITEN_MEI                    VARCHAR2(40) NOT NULL,
    DAIRITEN_KANA_MEI               VARCHAR2(40),
    DAIHYO_FLG                      CHAR(1),
    DAIRITEN_RYAKUSHO               VARCHAR2(20),
    EIGO_HYOUKI                     VARCHAR2(40),
    DAIHYO_CD                       VARCHAR2(5),
    SHUKA_TEN_FLG                   CHAR(1) NOT NULL,
    HAITATSU_TEN_FLG                CHAR(1) NOT NULL,
    CHARTER_KITEN_FLG               CHAR(1) NOT NULL,
    HAITATSU_SHUTURYOKUTEN_FLG      CHAR(1) NOT NULL,
    SHIIRESAKI_CD                   VARCHAR2(5),
    KOKYAKU_CD                      CHAR(6),
    KAISHA_MEI                      VARCHAR2(40),
    KAISHA_KANA_MEI                 VARCHAR2(40),
    SHITEN_MEI                      VARCHAR2(20),
    SHITEN_KANA_MEI                 VARCHAR2(20),
    BUSHO_TANTOSHA_1                VARCHAR2(40),
    BUSHO_TANTOSHA_2                VARCHAR2(40),
    YUBIN_BANGO                     VARCHAR2(5),
    JIS_CD                          CHAR(5),
    JUSHO_1                         VARCHAR2(40),
    JUSHO_2                         VARCHAR2(40),
    JUSHO_3                         VARCHAR2(40),
    JUSHO_4                         VARCHAR2(40),
    JUSHO                           VARCHAR2(160),
    KUKO_CD                         CHAR(3),
    SHIMUKE_CHI_CD                  CHAR(7),
    SHUHAI_CHIKU                    CHAR(1),
    TEL_BANGO_1                     VARCHAR2(19),
    TEL_BANGO_2                     VARCHAR2(19),
    FAX_BANGO                       VARCHAR2(19),
    KANI_GINKO_CD                   CHAR(3),
    SAIBAN_KINO_SHIYO_UMU           CHAR(1) NOT NULL,
    OKURIJO_KANRI_TANI              CHAR(1) NOT NULL,
    OKURIJO_CHECK_DIGIT             CHAR(2) NOT NULL,
    OKURIJO_BARCODE                 CHAR(2) NOT NULL,
    OKURIJO_START_STOP              CHAR(2) NOT NULL,
    NIFUDA_INJI_TAIKEI              CHAR(2) NOT NULL,
    NIFUDA_EDABAN_TAIKEI            CHAR(2) NOT NULL,
    NIFUDA_BARCODE                  CHAR(2) NOT NULL,
    NIFUDA_START_STOP               CHAR(2) NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_DAIRITEN_RIREKI
    ADD(CONSTRAINT PK_MS_DAIRITEN_RIREKI PRIMARY KEY (DAIRITEN_CD, TEKIYO_KAISHIBI, DAIRITEN_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_DAIRITEN_OKURIJO_NO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_DAIRITEN_OKURIJO_NO
(
    DAIRITEN_CD                     VARCHAR2(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    OKURIJO_NO_FROM                 CHAR(13) NOT NULL,
    DAIRITEN_DATA_VERSION           NUMBER(3,0) NOT NULL,
    OKURIJO_NO_TO                   CHAR(13),
    KURIKAESHI_SHIYO_FLG            CHAR(1) NOT NULL,
    SHUKAISU                        NUMBER(3,0) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_DAIRITEN_OKURIJO_NO
    ADD(CONSTRAINT PK_MS_DAIRITEN_OKURIJO_NO PRIMARY KEY (DAIRITEN_CD, TEKIYO_KAISHIBI, OKURIJO_NO_FROM) USING INDEX)
/
DROP TABLE MS_DAIRITEN_OKURIJO_NO_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_DAIRITEN_OKURIJO_NO_RIREKI
(
    DAIRITEN_CD                     VARCHAR2(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    OKURIJO_NO_FROM                 CHAR(13) NOT NULL,
    DAIRITEN_DATA_VERSION           NUMBER(3,0) NOT NULL,
    OKURIJO_NO_TO                   CHAR(13),
    KURIKAESHI_SHIYO_FLG            CHAR(1) NOT NULL,
    SHUKAISU                        NUMBER(3,0) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_DAIRITEN_OKURIJO_NO_RIREKI
    ADD(CONSTRAINT PK_MS_DAIRITEN_OKURIJO_NO_RIREKI PRIMARY KEY (DAIRITEN_CD, TEKIYO_KAISHIBI, OKURIJO_NO_FROM, DAIRITEN_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    SHIIRESAKI_CD                   VARCHAR2(5) NOT NULL,
    DEMPYO_SHUBETSU_CD              CHAR(2) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_DATA_VERSION NUMBER(3,0) NOT NULL,
    UNCHIN_KEISAN_PTN               CHAR(2),
    TEKIYO_MEI                      VARCHAR2(40),
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO
    ADD(CONSTRAINT IX_MS_DAIRITEN_CHUKEI_HAITATSU_RYOKIN UNIQUE (EIGYOSHO_CD, SHIIRESAKI_CD, DEMPYO_SHUBETSU_CD) USING INDEX)
/
ALTER TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO
    ADD(CONSTRAINT PK_MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO PRIMARY KEY (EIGYOSHO_CD, SHIIRESAKI_CD, DEMPYO_SHUBETSU_CD, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_RIREKI
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    SHIIRESAKI_CD                   VARCHAR2(5) NOT NULL,
    DEMPYO_SHUBETSU_CD              CHAR(2) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_DATA_VERSION NUMBER(3,0) NOT NULL,
    UNCHIN_KEISAN_PTN               CHAR(2),
    TEKIYO_MEI                      VARCHAR2(40),
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_RIREKI
    ADD(CONSTRAINT IX_MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_RIREKI UNIQUE (EIGYOSHO_CD, SHIIRESAKI_CD, DEMPYO_SHUBETSU_CD) USING INDEX)
/
ALTER TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_RIREKI
    ADD(CONSTRAINT PK_MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_RIREKI PRIMARY KEY (EIGYOSHO_CD, SHIIRESAKI_CD, DEMPYO_SHUBETSU_CD, TEKIYO_KAISHIBI, DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_DEFAULT_KANRI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_DEFAULT_KANRI
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    SHIIRESAKI_CD                   VARCHAR2(5) NOT NULL,
    DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_DATA_VERSION NUMBER(3,0) NOT NULL,
    DEFAULT_DEMPYO_SHUBETSU_CD      CHAR(2),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_DEFAULT_KANRI
    ADD(CONSTRAINT PK_MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_DEFAULT_KANRI PRIMARY KEY (EIGYOSHO_CD, SHIIRESAKI_CD) USING INDEX)
/
DROP TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_DEFAULT_KANRI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_DEFAULT_KANRI_RIREKI
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    SHIIRESAKI_CD                   VARCHAR2(5) NOT NULL,
    DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_DATA_VERSION NUMBER(3,0) NOT NULL,
    DEFAULT_DEMPYO_SHUBETSU_CD      CHAR(2),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_DEFAULT_KANRI_RIREKI
    ADD(CONSTRAINT PK_MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_DEFAULT_KANRI_RIREKI PRIMARY KEY (EIGYOSHO_CD, SHIIRESAKI_CD, DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_KINGAKU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_KINGAKU
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    SHIIRESAKI_CD                   VARCHAR2(5) NOT NULL,
    DEMPYO_SHUBETSU_CD              CHAR(2) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    KITEN_CHIIKI_CD                 VARCHAR2(5) NOT NULL,
    UNCHIN_RANK                     NUMBER(4,0) NOT NULL,
    TATENE_NO                       NUMBER(3,0) NOT NULL,
    DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_DATA_VERSION NUMBER(3,0) NOT NULL,
    KINGAKU                         NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_KINGAKU
    ADD(CONSTRAINT PK_MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_KINGAKU PRIMARY KEY (TEKIYO_KAISHIBI, EIGYOSHO_CD, SHIIRESAKI_CD, DEMPYO_SHUBETSU_CD, KITEN_CHIIKI_CD, UNCHIN_RANK, TATENE_NO) USING INDEX)
/
DROP TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_KINGAKU_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_KINGAKU_RIREKI
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    SHIIRESAKI_CD                   VARCHAR2(5) NOT NULL,
    DEMPYO_SHUBETSU_CD              CHAR(2) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    KITEN_CHIIKI_CD                 VARCHAR2(5) NOT NULL,
    UNCHIN_RANK                     NUMBER(4,0) NOT NULL,
    TATENE_NO                       NUMBER(3,0) NOT NULL,
    DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_DATA_VERSION NUMBER(3,0) NOT NULL,
    KINGAKU                         NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_KINGAKU_RIREKI
    ADD(CONSTRAINT PK_MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_KINGAKU_RIREKI PRIMARY KEY (EIGYOSHO_CD, SHIIRESAKI_CD, DEMPYO_SHUBETSU_CD, TEKIYO_KAISHIBI, KITEN_CHIIKI_CD, UNCHIN_RANK, TATENE_NO, DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_TATENE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_TATENE
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    SHIIRESAKI_CD                   VARCHAR2(5) NOT NULL,
    DEMPYO_SHUBETSU_CD              CHAR(2) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TATENE_NO                       NUMBER(3,0) NOT NULL,
    DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_DATA_VERSION NUMBER(3,0) NOT NULL,
    JURYO                           NUMBER(10,0),
    KOSU                            NUMBER(10,0),
    MASHI_KBN                       CHAR(1),
    MASHI_IKICHI                    NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_TATENE
    ADD(CONSTRAINT PK_MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_TATENE PRIMARY KEY (EIGYOSHO_CD, SHIIRESAKI_CD, DEMPYO_SHUBETSU_CD, TEKIYO_KAISHIBI, TATENE_NO) USING INDEX)
/
DROP TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_TATENE_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_TATENE_RIREKI
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    SHIIRESAKI_CD                   VARCHAR2(5) NOT NULL,
    DEMPYO_SHUBETSU_CD              CHAR(2) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TATENE_NO                       NUMBER(3,0) NOT NULL,
    DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_DATA_VERSION NUMBER(3,0) NOT NULL,
    JURYO                           NUMBER(10,0),
    KOSU                            NUMBER(10,0),
    MASHI_KBN                       CHAR(1),
    MASHI_IKICHI                    NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_TATENE_RIREKI
    ADD(CONSTRAINT PK_MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_TATENE_RIREKI PRIMARY KEY (EIGYOSHO_CD, SHIIRESAKI_CD, DEMPYO_SHUBETSU_CD, TEKIYO_KAISHIBI, TATENE_NO, DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_CHIIKI_SETTEI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_CHIIKI_SETTEI
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    SHIIRESAKI_CD                   VARCHAR2(5) NOT NULL,
    DEMPYO_SHUBETSU_CD              CHAR(2) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    KITEN_CHIIKI_CD                 VARCHAR2(5) NOT NULL,
    UNCHIN_RANK                     NUMBER(4,0) NOT NULL,
    DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_DATA_VERSION NUMBER(3,0) NOT NULL,
    HOTCHI_CHAKU_CHIKU_KBN          CHAR(1),
    CHIIKI_MEI                      VARCHAR2(20),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_CHIIKI_SETTEI
    ADD(CONSTRAINT PK_MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_CHIIKI_SETTEI PRIMARY KEY (EIGYOSHO_CD, SHIIRESAKI_CD, DEMPYO_SHUBETSU_CD, TEKIYO_KAISHIBI, KITEN_CHIIKI_CD, UNCHIN_RANK) USING INDEX)
/
DROP TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_CHIIKI_SETTEI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_CHIIKI_SETTEI_RIREKI
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    SHIIRESAKI_CD                   VARCHAR2(5) NOT NULL,
    DEMPYO_SHUBETSU_CD              CHAR(2) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    KITEN_CHIIKI_CD                 VARCHAR2(5) NOT NULL,
    UNCHIN_RANK                     NUMBER(4,0) NOT NULL,
    DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_DATA_VERSION NUMBER(3,0) NOT NULL,
    HOTCHI_CHAKU_CHIKU_KBN          CHAR(1),
    CHIIKI_MEI                      VARCHAR2(20),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_CHIIKI_SETTEI_RIREKI
    ADD(CONSTRAINT PK_MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_CHIIKI_SETTEI_RIREKI PRIMARY KEY (EIGYOSHO_CD, SHIIRESAKI_CD, DEMPYO_SHUBETSU_CD, TEKIYO_KAISHIBI, KITEN_CHIIKI_CD, UNCHIN_RANK, DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_CHIIKI_MEISAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_CHIIKI_MEISAI
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    SHIIRESAKI_CD                   VARCHAR2(5) NOT NULL,
    DEMPYO_SHUBETSU_CD              CHAR(2) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    KITEN_CHIIKI_CD                 VARCHAR2(5) NOT NULL,
    UNCHIN_RANK                     NUMBER(4,0) NOT NULL,
    DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_DATA_VERSION NUMBER(3,0) NOT NULL,
    JIS_CD                          CHAR(5),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_CHIIKI_MEISAI
    ADD(CONSTRAINT PK_MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_CHIIKI_MEISAI PRIMARY KEY (TEKIYO_KAISHIBI, EIGYOSHO_CD, SHIIRESAKI_CD, DEMPYO_SHUBETSU_CD, KITEN_CHIIKI_CD, UNCHIN_RANK) USING INDEX)
/
DROP TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_CHIIKI_MEISAI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_CHIIKI_MEISAI_RIREKI
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    SHIIRESAKI_CD                   VARCHAR2(5) NOT NULL,
    DEMPYO_SHUBETSU_CD              CHAR(2) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    KITEN_CHIIKI_CD                 VARCHAR2(5) NOT NULL,
    UNCHIN_RANK                     NUMBER(4,0) NOT NULL,
    DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_DATA_VERSION NUMBER(3,0) NOT NULL,
    JIS_CD                          CHAR(5),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_CHIIKI_MEISAI_RIREKI
    ADD(CONSTRAINT PK_MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_CHIIKI_MEISAI_RIREKI PRIMARY KEY (EIGYOSHO_CD, SHIIRESAKI_CD, DEMPYO_SHUBETSU_CD, TEKIYO_KAISHIBI, KITEN_CHIIKI_CD, UNCHIN_RANK, DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_DAIRITEN_SHIMEBI_SHIHARAI_SITE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_DAIRITEN_SHIMEBI_SHIHARAI_SITE
(
    DAIRITEN_CD                     VARCHAR2(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    DAIRITEN_SHIMEBI_SHIHARAI_SITE_SEQ NUMBER(3,0) NOT NULL,
    DAIRITEN_DATA_VERSION           NUMBER(3,0) NOT NULL,
    SHIMEBI                         VARCHAR2(2),
    SHIHARAI_SITE                   CHAR(2) NOT NULL,
    SHIHARAIBI                      VARCHAR2(2) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_DAIRITEN_SHIMEBI_SHIHARAI_SITE
    ADD(CONSTRAINT PK_MS_DAIRITEN_SHIMEBI_SHIHARAI_SITE PRIMARY KEY (DAIRITEN_CD, TEKIYO_KAISHIBI, DAIRITEN_SHIMEBI_SHIHARAI_SITE_SEQ) USING INDEX)
/
DROP TABLE MS_DAIRITEN_SHIMEBI_SHIHARAI_SITE_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_DAIRITEN_SHIMEBI_SHIHARAI_SITE_RIREKI
(
    DAIRITEN_CD                     VARCHAR2(5) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    DAIRITEN_SHIMEBI_SHIHARAI_SITE_SEQ NUMBER(3,0) NOT NULL,
    DAIRITEN_DATA_VERSION           NUMBER(3,0) NOT NULL,
    SHIMEBI                         VARCHAR2(2),
    SHIHARAI_SITE                   CHAR(2) NOT NULL,
    SHIHARAIBI                      VARCHAR2(2) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_DAIRITEN_SHIMEBI_SHIHARAI_SITE_RIREKI
    ADD(CONSTRAINT PK_MS_DAIRITEN_SHIMEBI_SHIHARAI_SITE_RIREKI PRIMARY KEY (DAIRITEN_CD, TEKIYO_KAISHIBI, DAIRITEN_SHIMEBI_SHIHARAI_SITE_SEQ, DAIRITEN_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_TANI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_TANI
(
    TANI_ID                         CHAR(2) NOT NULL,
    TANI                            VARCHAR2(20),
    SHOSUTEN_KBN                    CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_TANI
    ADD(CONSTRAINT PK_MS_TANI PRIMARY KEY (TANI_ID) USING INDEX)
/
DROP TABLE MS_CHOHYO_X_CHOHYO_GROUP CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_CHOHYO_X_CHOHYO_GROUP
(
    CHOHYO_ID                       VARCHAR2(40) NOT NULL,
    CHOHYO_GROUP_ID                 VARCHAR2(40) NOT NULL,
    SORT_JUN                        NUMBER(2,0) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) DEFAULT 0 NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_CHOHYO_X_CHOHYO_GROUP
    ADD(CONSTRAINT PK_MS_CHOHYO_X_CHOHYO_GROUP PRIMARY KEY (CHOHYO_ID, CHOHYO_GROUP_ID) USING INDEX)
/
DROP TABLE MS_CHOHYO_GROUP_ROLE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_CHOHYO_GROUP_ROLE
(
    ROLE_CD                         VARCHAR2(20) NOT NULL,
    CHOHYO_GROUP_ID                 VARCHAR2(40) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_CHOHYO_GROUP_ROLE
    ADD(CONSTRAINT PK_MS_CHOHYO_GROUP_ROLE PRIMARY KEY (ROLE_CD, CHOHYO_GROUP_ID) USING INDEX)
/
DROP TABLE MS_CHOHYO_GROUP CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_CHOHYO_GROUP
(
    CHOHYO_GROUP_ID                 VARCHAR2(40) NOT NULL,
    CHOHYO_GROUP_MEI                VARCHAR2(40),
    SHORI_ID                        VARCHAR2(10),
    BIKO                            VARCHAR2(100),
    GROUP_TANI_SETTEI_YO_FLG        CHAR(1) NOT NULL,
    DAIHYOU_CHOHYO_ID               VARCHAR2(40),
    DB_KOSHIN_SHORI_METHOD_MEI      VARCHAR2(128),
    PRINTER_HENKO_KBN               CHAR(1),
    PRINTERID_HENKO_KBN             CHAR(1),
    YOSHI_ID_HENKO_KBN              CHAR(1),
    TRAY_ID_HENKO_KBN               CHAR(1),
    HIDARI_YOHAKU_HENKO_KBN         CHAR(1),
    UE_YOHAKU_HENKO_KBN             CHAR(1),
    PREVIEW_HYOJI_HENKO_KBN         CHAR(1),
    INSATSU_DAILOG_HYOJI_HENKO_KBN  CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_CHOHYO_GROUP
    ADD(CONSTRAINT PK_MS_CHOHYO_GROUP PRIMARY KEY (CHOHYO_GROUP_ID, SAKUJO_FLG, TOROKU_USER) USING INDEX)
/
DROP TABLE MS_CHOHYO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_CHOHYO
(
    CHOHYO_ID                       VARCHAR2(40) NOT NULL,
    CHOHYO_GROUP_ID                 VARCHAR2(40) NOT NULL,
    CHOHYO_MEI                      VARCHAR2(20) NOT NULL,
    CHOHYO_TEMPLATE_FILE_PATH1      VARCHAR2(512) NOT NULL,
    CHOHYO_TEMPLATE_FILE_PATH2      VARCHAR2(512) NOT NULL,
    CHOHYO_TEMPLATE_FILE_PATH3      VARCHAR2(512) NOT NULL,
    CHOHYO_TEMPLATE_FILE_PATH4      VARCHAR2(512) NOT NULL,
    CHOHYO_TEMPLATE_FILE_PATH5      VARCHAR2(512) NOT NULL,
    CHOHYO_TEMPLATE_FILE_PATH6      VARCHAR2(512) NOT NULL,
    CHOHYO_TEMPLATE_FILE_PATH7      VARCHAR2(512) NOT NULL,
    CHOHYO_TEMPLATE_FILE_PATH8      VARCHAR2(512) NOT NULL,
    CHOHYO_TEMPLATE_FILE_PATH9      VARCHAR2(512) NOT NULL,
    CHOHYO_TEMPLATE_FILE_PATH10     VARCHAR2(512) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_CHOHYO
    ADD(CONSTRAINT PK_MS_CHOHYO PRIMARY KEY (CHOHYO_ID, CHOHYO_GROUP_ID) USING INDEX)
/
DROP TABLE MS_CHOHYO_YOSHI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_CHOHYO_YOSHI
(
    CHOHYO_ID                       VARCHAR2(40) NOT NULL,
    YOSHI_ID                        VARCHAR2(3) NOT NULL,
    YOSHI_SETTEI                    VARCHAR2(20) NOT NULL,
    SAMPLE_DATA_FILE_PATH           VARCHAR2(512) NOT NULL,
    SHUTSURYOKU_FILE_MEI            VARCHAR2(64) NOT NULL,
    SHUTSURYOKU_DOCUMENT_MEI        VARCHAR2(64) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_CHOHYO_YOSHI
    ADD(CONSTRAINT PK_MS_CHOHYO_YOSHI PRIMARY KEY (CHOHYO_ID, YOSHI_ID) USING INDEX)
/
DROP TABLE TR_SHIME_SHORI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SHIME_SHORI_RIREKI
(
    SHIME_SHORI_ID                  NUMBER(18,0) NOT NULL,
    SEIKYU_ID                       NUMBER(18,0) NOT NULL,
    SEIKYUSAKI_CD                   CHAR(6) NOT NULL,
    SHIMEBI                         CHAR(8) NOT NULL,
    SHIME_HANI_FROM                 CHAR(8) NOT NULL,
    SHIME_HANI_TO                   CHAR(8) NOT NULL,
    SHIME_TAISHO_FLG                CHAR(1) NOT NULL,
    SHIME_JIKKO_NICHIJI             DATE NOT NULL,
    SHIME_JIKKOSHA_CD               CHAR(7) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SHIME_SHORI_RIREKI
    ADD(CONSTRAINT PK_TR_SHIME_SHORI_RIREKI PRIMARY KEY (SHIME_SHORI_ID) USING INDEX)
/
DROP TABLE TR_SHIME_YOTEI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_SHIME_YOTEI
(
    SHIME_SHORI_ID                  NUMBER(18,0) NOT NULL,
    SEIKYUSAKI_CD                   CHAR(6) NOT NULL,
    TAISHO_SHIME_HANI_TO            CHAR(8) NOT NULL,
    TAISHO_SHIME_HANI_FROM          CHAR(8) NOT NULL,
    EIGYOSHO_CD                     VARCHAR2(5),
    SHIME_TAISHO_FLG                CHAR(1) NOT NULL,
    SEIKYU_ID                       NUMBER(18,0),
    SHIME_HOHO_FLG                  CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SHIME_YOTEI
    ADD(CONSTRAINT PK_TR_SHIME_YOTEI PRIMARY KEY (SEIKYUSAKI_CD, TAISHO_SHIME_HANI_TO, SHIME_SHORI_ID) USING INDEX)
/
DROP TABLE MS_DEMPYO_SHUBETSU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_DEMPYO_SHUBETSU
(
    DEMPYO_SHUBETSU_CD              CHAR(2) NOT NULL,
    DEMPYO_SHUBETSU_MEI             VARCHAR2(40) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_DEMPYO_SHUBETSU
    ADD(CONSTRAINT PK_MS_DEMPYO_SHUBETSU PRIMARY KEY (DEMPYO_SHUBETSU_CD) USING INDEX)
/
DROP TABLE TR_TOROKU_MAWB_BANGO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_TOROKU_MAWB_BANGO
(
    KOKU_GAISHA_CD                  VARCHAR2(3) NOT NULL,
    HAKKEN_EIGYOSHO_CD              CHAR(3) NOT NULL,
    MAWB_TOROKU_ID                  NUMBER(5,0) NOT NULL,
    UKETORIBI                       DATE NOT NULL,
    KAISHI_MAWB_BANGO               VARCHAR2(8) NOT NULL,
    SHURYO_MAWB_BANGO               VARCHAR2(8) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_TOROKU_MAWB_BANGO
    ADD(CONSTRAINT PK_TR_TOROKU_MAWB_BANGO PRIMARY KEY (KOKU_GAISHA_CD, HAKKEN_EIGYOSHO_CD, MAWB_TOROKU_ID) USING INDEX)
/
DROP TABLE MS_TODOFUKEN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_TODOFUKEN
(
    TODOFUKEN_CD                    CHAR(2) NOT NULL,
    TODOFUKEN_KANJI_MEI             VARCHAR2(40),
    TODOFUKEN_KANA_MEI              VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_TODOFUKEN
    ADD(CONSTRAINT PK_MS_TODOFUKEN PRIMARY KEY (TODOFUKEN_CD) USING INDEX)
/
DROP TABLE TR_NYUKIN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_NYUKIN
(
    NYUKIN_ID                       NUMBER(18,0) NOT NULL,
    NYUKIN_MEISAI_NO                NUMBER(6,0) NOT NULL,
    NYUKIN_SHIWAKE_ID               NUMBER(6,0) NOT NULL,
    KESHIKOMI_ID                    VARCHAR2(9),
    NYUKIN_KBN                      CHAR(1) NOT NULL,
    KINYU_KIKAN_CD                  VARCHAR2(4) NOT NULL,
    KOZA_BANGO                      VARCHAR2(7),
    NYURYOKU_EIGYOSHO_CD            VARCHAR2(5),
    NYUKINBI                        CHAR(8),
    NYUKIN_TOROKU_NICHIJI           DATE,
    TORIHIKI_KAMOKU_CD              CHAR(2),
    KINGAKU                         NUMBER(10,0),
    KAMOKU_1_CD                     VARCHAR2(8),
    KAMOKU_2_CD                     VARCHAR2(8),
    NYUKIN_COMMENT                  VARCHAR2(512),
    TORIKOMI_ID                     NUMBER(18,0),
    KEIRI_KEIJO_HI                  CHAR(8) NOT NULL,
    IF_RENKEI_JOKYO_FLG             CHAR(1) NOT NULL,
    IF_RENKEI_TAISHO_FLG            CHAR(1) NOT NULL,
    FURIKOMIJIN_MEI_KANA            VARCHAR2(32),
    KESHIKOMI_KBN                   CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_NYUKIN
    ADD(CONSTRAINT PK_TR_NYUKIN PRIMARY KEY (NYUKIN_ID, NYUKIN_MEISAI_NO, NYUKIN_SHIWAKE_ID) USING INDEX)
/
DROP TABLE TR_NYUKIN_SHIWAKE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_NYUKIN_SHIWAKE
(
    NYUKIN_ID                       NUMBER(18,0) NOT NULL,
    NYUKIN_MEISAI_ID                NUMBER(6,0) NOT NULL,
    KESHIKOMI_ID                    VARCHAR2(9),
    KINYU_KIKAN_CD                  CHAR(4) NOT NULL,
    KOZA_BANGO                      VARCHAR2(7) NOT NULL,
    KINGAKU                         NUMBER(21,0) NOT NULL,
    KAMOKU_1_CD                     VARCHAR2(4),
    KAMOKU_2_CD                     VARCHAR2(4),
    NYUURYOKU_EIGYOSHO_CD           CHAR(3),
    NYUKIN_COMMENT                  VARCHAR2(512),
    TORIKOMI_ID                     NUMBER(18,0),
    KEIRI_KEIJO_HI                  DATE NOT NULL,
    IF_RENKEI_JOKYO_FLG             CHAR(1) NOT NULL,
    IF_RENKEI_TAISHO_FLG            CHAR(1) NOT NULL,
    FURIKOMIJIN_MEI_KANA            VARCHAR2(32),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_NYUKIN_SHIWAKE
    ADD(CONSTRAINT PK_TR_NYUKIN_SHIWAKE PRIMARY KEY (NYUKIN_ID, NYUKIN_MEISAI_ID) USING INDEX)
/
DROP TABLE TR_NYUKIN_SHIWAKE_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_NYUKIN_SHIWAKE_RIREKI
(
    NYUKIN_SHIWAKE_ID               NUMBER(6,0) NOT NULL,
    SEIKYU_ID                       NUMBER(18,0),
    KESHIKOMI_ID                    VARCHAR2(9),
    KINYU_KIKAN_CD                  CHAR(4) NOT NULL,
    KOZA_BANGO                      VARCHAR2(7) NOT NULL,
    KINGAKU                         NUMBER(21,0) NOT NULL,
    KAMOKU_1_CD                     VARCHAR2(4),
    KAMOKU_2_CD                     VARCHAR2(4),
    NYUURYOKU_EIGYOSHO_CD           CHAR(3),
    NYUKIN_COMMENT                  VARCHAR2(512),
    TORIKOMI_ID                     NUMBER(18,0),
    KEIRI_KEIJO_HI                  DATE NOT NULL,
    IF_RENKEI_JOKYO_FLG             CHAR(1) NOT NULL,
    IF_RENKEI_TAISHO_FLG            CHAR(1) NOT NULL,
    FURIKOMIJIN_MEI_KANA            VARCHAR2(32),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_NYUKIN_SHIWAKE_RIREKI
    ADD(CONSTRAINT PK_TR_NYUKIN_SHIWAKE_RIREKI PRIMARY KEY (NYUKIN_SHIWAKE_ID) USING INDEX)
/
DROP TABLE TR_NYUKIN_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_NYUKIN_RIREKI
(
    NYUKIN_ID                       NUMBER(18,0) NOT NULL,
    NYUKIN_MEISAI_NO                NUMBER(6,0) NOT NULL,
    NYUKIN_SHIWAKE_ID               NUMBER(6,0) NOT NULL,
    KESHIKOMI_ID                    VARCHAR2(9),
    GINKO_CD                        CHAR(4),
    KOZA_BANGO                      CHAR(7),
    NYURYOKU_EIGYOSHO_CD            CHAR(3),
    NYUKINBI                        CHAR(8),
    NYUKIN_TOROKU_NICHIJI           DATE,
    TORIHIKI_KAMOKU_CD              VARCHAR2(4),
    KINGAKU                         NUMBER(21,0),
    KAMOKU_1_CD                     VARCHAR2(4),
    KAMOKU_2_CD                     VARCHAR2(6),
    NYUKIN_COMMENT                  VARCHAR2(512),
    TORIKOMI_ID                     NUMBER(18,0),
    KEIRI_KEIJO_HI                  CHAR(8) NOT NULL,
    IF_RENKEI_JOKYO_FLG             CHAR(1) NOT NULL,
    IF_RENKEI_TAISHO_FLG            CHAR(1) NOT NULL,
    FURIKOMIJIN_MEI_KANA            VARCHAR2(32),
    KESHIKOMI_KBN                   CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_NYUKIN_RIREKI
    ADD(CONSTRAINT PK_TR_NYUKIN1 PRIMARY KEY (NYUKIN_ID, NYUKIN_MEISAI_NO, NYUKIN_SHIWAKE_ID) USING INDEX)
/
DROP TABLE TR_HAITA CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_HAITA
(
    TABLE_ID                        VARCHAR2(20) NOT NULL,
    TABLE_ROWID                     VARCHAR2(10) NOT NULL,
    HAITA_KAISHI_NICHIJI            DATE,
    HAITA_USER                      CHAR(7),
    HAITA_PROGRAM                   VARCHAR2(20),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_HAITA
    ADD(CONSTRAINT PK_TR_HAITA PRIMARY KEY (TABLE_ID, TABLE_ROWID) USING INDEX)
/
DROP TABLE TR_HAIKAN_TRACE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_HAIKAN_TRACE
(
    OKURIJO_NO                      CHAR(13) NOT NULL,
    HAITATSU_TEN                    VARCHAR2(5) NOT NULL,
    HAITATSU_NENGAPPI               CHAR(8) NOT NULL,
    HAITATSU_JIKAN                  CHAR(6),
    KOSU                            NUMBER(3,0),
    TRACE_JOTAI_KBN                 CHAR(2),
    KICHOHIN_KBN                    CHAR(2),
    SHABAN                          CHAR(5),
    BIKO_1                          VARCHAR2(40),
    DATA_MOTO                       CHAR(2),
    HASSEI_NICHIJI                  DATE,
    URIAGE_ID                       NUMBER(18,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_HAIKAN_TRACE
    ADD(CONSTRAINT PK_TR_HAIKAN_TRACE PRIMARY KEY (OKURIJO_NO, HAITATSU_TEN, HAITATSU_NENGAPPI) USING INDEX)
/
DROP TABLE TR_HAIKAN_TRACE_EDABAN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_HAIKAN_TRACE_EDABAN
(
    OKURIJO_NO                      CHAR(13) NOT NULL,
    EDABAN                          VARCHAR2(3) NOT NULL,
    HAITATSU_TEN                    VARCHAR2(5) NOT NULL,
    HAITATSU_NENGAPPI               CHAR(8) NOT NULL,
    HAITATSU_JIKAN                  CHAR(6),
    HHT_BANGO                       CHAR(15),
    TANTOSHA                        CHAR(7),
    SHABAN                          CHAR(5),
    TRACE_JOTAI_KBN                 CHAR(2),
    NIUKENIN_MEI                    VARCHAR2(20),
    CHAKUBARAI_KINGAKU              NUMBER(10,0),
    DAIBIKI_KINGAKU                 NUMBER(10,0),
    RYOSHUSHO_NO                    CHAR(7),
    KEITAI_DENWA_BANGO              VARCHAR2(19),
    UNIT_NO                         VARCHAR2(20),
    KANNAIHAISO_KBN                 CHAR(1) NOT NULL,
    OKURIJO_NO_NYURYOKU_MOTO_FLG    CHAR(1),
    HASSEI_NICHIJI                  DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_HAIKAN_TRACE_EDABAN
    ADD(CONSTRAINT PK_TR_HAIKAN_TRACE_EDABAN PRIMARY KEY (OKURIJO_NO, EDABAN, HAITATSU_NENGAPPI, HAITATSU_TEN) USING INDEX)
/
DROP TABLE TR_HAITATSU_JUMBAN_TEXT CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_HAITATSU_JUMBAN_TEXT
(
    HT_SERIAL_NO                    CHAR(15) NOT NULL,
    SCAN_NICHIJI                    DATE NOT NULL,
    TANTOSHA                        CHAR(7) NOT NULL,
    SHABAN                          CHAR(5) NOT NULL,
    GOSHA_CD                        CHAR(5) NOT NULL,
    OKURIJO_NO                      CHAR(13) NOT NULL,
    JUMBAN                          NUMBER(3,0) NOT NULL,
    DENPYO_CHECK_FLG                CHAR(1) NOT NULL,
    KEITAI_DENWA_BANGO              VARCHAR2(19),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_HAITATSU_JUMBAN_TEXT
    ADD(CONSTRAINT PK_TR_HAITATSU_JUMBAN_TEXT PRIMARY KEY (HT_SERIAL_NO, SCAN_NICHIJI, TANTOSHA, SHABAN, GOSHA_CD, OKURIJO_NO, JUMBAN) USING INDEX)
/
DROP TABLE TR_HAIFU_MAWB_BANGO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_HAIFU_MAWB_BANGO
(
    KOKU_GAISHA_CD                  VARCHAR2(3) NOT NULL,
    HAKKEN_EIGYOSHO_CD              CHAR(3) NOT NULL,
    HAIFUSAKI_EIGYOSHO_CD           CHAR(3) NOT NULL,
    MAWB_TOROKU_ID                  NUMBER(5,0) NOT NULL,
    MAWB_HAIFU_ID                   NUMBER(5,0) NOT NULL,
    HAIFU_HIZUKE                    DATE NOT NULL,
    KAISHI_MAWB_HAIFU_BANGO         VARCHAR2(8) NOT NULL,
    SHURYO_MAWB_HAIFU_BANGO         VARCHAR2(8) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_HAIFU_MAWB_BANGO
    ADD(CONSTRAINT PK_TR_HAIFU_MAWB_BANGO PRIMARY KEY (KOKU_GAISHA_CD, HAKKEN_EIGYOSHO_CD, HAIFUSAKI_EIGYOSHO_CD, MAWB_TOROKU_ID, MAWB_HAIFU_ID) USING INDEX)
/
DROP TABLE MS_URIAGE_STATUS CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_URIAGE_STATUS
(
    URIAGE_STATUS_CD                VARCHAR2(10) NOT NULL,
    URIAGE_STATUS_MEI               VARCHAR2(20) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_URIAGE_STATUS
    ADD(CONSTRAINT PK_MS_URIAGE_STATUS PRIMARY KEY (URIAGE_STATUS_CD) USING INDEX)
/
DROP TABLE MS_HIMMEI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_HIMMEI
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    HIMMEI_CD                       CHAR(3) NOT NULL,
    HIMMEI_DATA_VERSION             NUMBER(3,0) NOT NULL,
    HIMMEI                          VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_HIMMEI
    ADD(CONSTRAINT PK_MS_HIMMEI PRIMARY KEY (EIGYOSHO_CD, KOKYAKU_CD, HIMMEI_CD) USING INDEX)
/
DROP TABLE MS_HIMMEI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_HIMMEI_RIREKI
(
    EIGYOSHO_CD                     CHAR(3) NOT NULL,
    KOKYAKU_CD                      CHAR(6) NOT NULL,
    HIMMEI_CD                       CHAR(3) NOT NULL,
    HIMMEI_DATA_VERSION             NUMBER(3,0) NOT NULL,
    HIMMEI                          VARCHAR2(40),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_HIMMEI_RIREKI
    ADD(CONSTRAINT PK_MS_HIMMEI_RIREKI PRIMARY KEY (EIGYOSHO_CD, KOKYAKU_CD, HIMMEI_CD, HIMMEI_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_FUTAI_RYOKIN_MITSUMORI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_FUTAI_RYOKIN_MITSUMORI
(
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    URIAGE_KBN                      CHAR(1),
    RYOKIN_KOMOKU_1_CD              CHAR(2),
    RYOKIN_KOMOKU_2_CD              CHAR(3),
    MEISAI_KBN                      CHAR(1),
    HYOJI_MEI                       VARCHAR2(40),
    TANKA                           NUMBER(10,0),
    TANI                            VARCHAR2(20),
    SHOSUTEN_KBN                    CHAR(1),
    BIKO                            VARCHAR2(100),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_FUTAI_RYOKIN_MITSUMORI
    ADD(CONSTRAINT PK_TR_FUTAI_RYOKIN_MITSUMORI PRIMARY KEY (MITSUMORI_NO, MEISAI_GYO_NO, MITSUMORI_TEIAN_NO) USING INDEX)
/
DROP TABLE TR_FUTAI_RYOKIN_MITSUMORI_NEBIKI_KOMOKU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_FUTAI_RYOKIN_MITSUMORI_NEBIKI_KOMOKU
(
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    URIAGE_KBN                      CHAR(1) NOT NULL,
    RYOKIN_KOMOKU_1_CD              CHAR(2) NOT NULL,
    RYOKIN_KOMOKU_2_CD              CHAR(3) NOT NULL,
    MEISAI_KBN                      CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_FUTAI_RYOKIN_MITSUMORI_NEBIKI_KOMOKU
    ADD(CONSTRAINT PK_TR_FUTAI_RYOKIN_MITSUMORI_NEBIKI_KOMOKU PRIMARY KEY (MITSUMORI_TEIAN_NO, MITSUMORI_NO, URIAGE_KBN, RYOKIN_KOMOKU_1_CD, RYOKIN_KOMOKU_2_CD, MEISAI_KBN) USING INDEX)
/
DROP TABLE TR_FUTAI_RYOKIN_MITSUMORI_NEBIKI_KOMOKU_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_FUTAI_RYOKIN_MITSUMORI_NEBIKI_KOMOKU_RIREKI
(
    SIMULATION_ID                   CHAR(9) NOT NULL,
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    URIAGE_KBN                      CHAR(1) NOT NULL,
    RYOKIN_KOMOKU_1_CD              CHAR(2) NOT NULL,
    RYOKIN_KOMOKU_2_CD              CHAR(3) NOT NULL,
    MEISAI_KBN                      CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_FUTAI_RYOKIN_MITSUMORI_NEBIKI_KOMOKU_RIREKI
    ADD(CONSTRAINT PK_TR_FUTAI_RYOKIN_MITSUMORI_NEBIKI_KOMOKU_RIREKI PRIMARY KEY (SIMULATION_ID, MITSUMORI_TEIAN_NO, MITSUMORI_NO, URIAGE_KBN, RYOKIN_KOMOKU_1_CD, RYOKIN_KOMOKU_2_CD, MEISAI_KBN) USING INDEX)
/
DROP TABLE TR_FUTAI_RYOKIN_MITSUMORI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_FUTAI_RYOKIN_MITSUMORI_RIREKI
(
    SIMULATION_ID                   CHAR(9) NOT NULL,
    MITSUMORI_TEIAN_NO              CHAR(6) NOT NULL,
    MITSUMORI_NO                    CHAR(7) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    URIAGE_KBN                      CHAR(1),
    RYOKIN_KOMOKU_1_CD              CHAR(2),
    RYOKIN_KOMOKU_2_CD              CHAR(3),
    MEISAI_KBN                      CHAR(1),
    HYOJI_MEI                       VARCHAR2(40),
    TANKA                           NUMBER(10,0),
    TANI                            VARCHAR2(20),
    SHOSUTEN_KBN                    CHAR(1),
    BIKO                            VARCHAR2(100),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_FUTAI_RYOKIN_MITSUMORI_RIREKI
    ADD(CONSTRAINT PK_TR_FUTAI_RYOKIN_MITSUMORI_RIREKI PRIMARY KEY (MITSUMORI_TEIAN_NO, MITSUMORI_NO, MEISAI_GYO_NO, SIMULATION_ID) USING INDEX)
/
DROP TABLE MS_FUTAI_RYOKIN_KOMOKU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_FUTAI_RYOKIN_KOMOKU
(
    URIAGE_KBN                      CHAR(1) NOT NULL,
    RYOKIN_KOMOKU_1_CD              CHAR(2) NOT NULL,
    RYOKIN_KOMOKU_1_MEISHO          VARCHAR2(40),
    RYOKIN_KOMOKU_2_CD              CHAR(3) NOT NULL,
    RYOKIN_KOMOKU_2_MEISHO          VARCHAR2(40),
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    MEISAI_KBN                      CHAR(1) NOT NULL,
    FUTAI_RYOKIN_KOMOKU_DATA_VERSION NUMBER(3,0) NOT NULL,
    NEBIKIFUKA_FLG                  CHAR(1),
    NEBIKIKAHI_SETSUMEI             VARCHAR2(80),
    SHOSUTEN_KBN                    CHAR(1),
    ZEI_KBN                         CHAR(1),
    YUSO_URIAGE_SET_SAKI            CHAR(2),
    OROSHINE_RITSU                  NUMBER(4,1),
    OROSHI_KEIJO_KASYO              VARCHAR2(5),
    OROSHI_KOMOKU_CD                CHAR(2),
    SHORI_KAMOKU_CD                 CHAR(4) NOT NULL,
    HOJO_KAMOKU_CD                  CHAR(2) NOT NULL,
    KEIRI_RENKEI_TAISHO_FLG         CHAR(1),
    TEKIYO_MEI                      VARCHAR2(40),
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_FUTAI_RYOKIN_KOMOKU
    ADD(CONSTRAINT IX_MS_FUTAI_RYOKIN_KOMOKU UNIQUE (URIAGE_KBN, RYOKIN_KOMOKU_2_CD, MEISAI_KBN, RYOKIN_KOMOKU_1_CD) USING INDEX)
/
ALTER TABLE MS_FUTAI_RYOKIN_KOMOKU
    ADD(CONSTRAINT PK_MS_FUTAI_RYOKIN_KOMOKU PRIMARY KEY (URIAGE_KBN, RYOKIN_KOMOKU_1_CD, RYOKIN_KOMOKU_2_CD, TEKIYO_KAISHIBI, MEISAI_KBN) USING INDEX)
/
DROP TABLE MS_FUTAI_RYOKIN_KOMOKU_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_FUTAI_RYOKIN_KOMOKU_RIREKI
(
    URIAGE_KBN                      CHAR(1) NOT NULL,
    RYOKIN_KOMOKU_1_CD              CHAR(2) NOT NULL,
    RYOKIN_KOMOKU_1_MEISHO          VARCHAR2(40),
    RYOKIN_KOMOKU_2_CD              CHAR(3) NOT NULL,
    RYOKIN_KOMOKU_2_MEISHO          VARCHAR2(40),
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    MEISAI_KBN                      CHAR(1) NOT NULL,
    OROSHI_KOMOKU_CD                CHAR(2),
    FUTAI_RYOKIN_KOMOKU_DATA_VERSION NUMBER(3,0) NOT NULL,
    NEBIKIFUKA_FLG                  CHAR(1),
    NEBIKIKAHI_SETSUMEI             VARCHAR2(80),
    SHOSUTEN_KBN                    CHAR(1),
    ZEI_KBN                         CHAR(1),
    YUSO_URIAGE_SET_SAKI            CHAR(2),
    OROSHINE_RITSU                  NUMBER(4,1),
    OROSHI_KEIJO_KASYO              VARCHAR2(5),
    SHORI_KAMOKU_CD                 CHAR(4) NOT NULL,
    HOJO_KAMOKU_CD                  CHAR(2) NOT NULL,
    KEIRI_RENKEI_TAISHO_FLG         CHAR(1),
    TEKIYO_MEI                      VARCHAR2(40),
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_FUTAI_RYOKIN_KOMOKU_RIREKI
    ADD(CONSTRAINT IX_MS_FUTAI_RYOKIN_KOMOKU_RIREKI UNIQUE (URIAGE_KBN, RYOKIN_KOMOKU_2_CD, MEISAI_KBN, RYOKIN_KOMOKU_1_CD) USING INDEX)
/
ALTER TABLE MS_FUTAI_RYOKIN_KOMOKU_RIREKI
    ADD(CONSTRAINT PK_MS_FUTAI_RYOKIN_KOMOKU_RIREKI PRIMARY KEY (URIAGE_KBN, RYOKIN_KOMOKU_1_CD, RYOKIN_KOMOKU_2_CD, TEKIYO_KAISHIBI, MEISAI_KBN, FUTAI_RYOKIN_KOMOKU_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_FUTAI_RYOKINHYO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_FUTAI_RYOKINHYO
(
    KEIYAKU_ID                      NUMBER(6,0) NOT NULL,
    RYOKINHYO_NO                    CHAR(7) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    URIAGE_KBN                      CHAR(1),
    RYOKIN_KOMOKU_1_CD              CHAR(2),
    RYOKIN_KOMOKU_2_CD              CHAR(3),
    MEISAI_KBN                      CHAR(1),
    HYOJI_MEI                       VARCHAR2(40),
    TANKA                           NUMBER(10,0),
    TANI                            VARCHAR2(20),
    SHOSUTEN_KBN                    CHAR(1),
    BIKO                            VARCHAR2(100),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_FUTAI_RYOKINHYO
    ADD(CONSTRAINT PK_TR_FUTAI_RYOKINHYO PRIMARY KEY (RYOKINHYO_NO, MEISAI_GYO_NO, KEIYAKU_ID) USING INDEX)
/
DROP TABLE TR_FUTAI_RYOKINHYO_NEBIKI_KOMOKU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_FUTAI_RYOKINHYO_NEBIKI_KOMOKU
(
    KEIYAKU_ID                      NUMBER(6,0) NOT NULL,
    RYOKINHYO_NO                    CHAR(7) NOT NULL,
    URIAGE_KBN                      CHAR(1) NOT NULL,
    RYOKIN_KOMOKU_1_CD              CHAR(2) NOT NULL,
    RYOKIN_KOMOKU_2_CD              CHAR(3) NOT NULL,
    MEISAI_KBN                      CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_FUTAI_RYOKINHYO_NEBIKI_KOMOKU
    ADD(CONSTRAINT PK_TR_FUTAI_RYOKINHYO_NEBIKI_KOMOKU PRIMARY KEY (URIAGE_KBN, RYOKIN_KOMOKU_1_CD, RYOKIN_KOMOKU_2_CD, MEISAI_KBN, RYOKINHYO_NO, KEIYAKU_ID) USING INDEX)
/
DROP TABLE MS_HOKEN_KBN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_HOKEN_KBN
(
    HOKEN_KBN                       CHAR(3) NOT NULL,
    HOKEN_MEISHO                    VARCHAR2(20) NOT NULL,
    HOKEN_KINGAKU                   NUMBER(10,0),
    HOKEN_RYO                       NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_HOKEN_KBN
    ADD(CONSTRAINT PK_MS_HOKEN_KBN PRIMARY KEY (HOKEN_KBN) USING INDEX)
/
DROP TABLE MS_HOJIN_GROUP CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_HOJIN_GROUP
(
    HOJIN_GROUP_CD                  VARCHAR2(10) NOT NULL,
    HOJIN_GROUP_DATA_VERSION        NUMBER(3,0),
    HOJIN_GROUP_MEISHO              VARCHAR2(100) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_HOJIN_GROUP
    ADD(CONSTRAINT PK_MS_HOJIN_GROUP PRIMARY KEY (HOJIN_GROUP_CD) USING INDEX)
/
DROP TABLE MS_HOJIN_GROUP_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_HOJIN_GROUP_RIREKI
(
    HOJIN_GROUP_CD                  VARCHAR2(10) NOT NULL,
    HOJIN_GROUP_DATA_VERSION        NUMBER(3,0) NOT NULL,
    HOJIN_GROUP_MEISHO              VARCHAR2(100) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_HOJIN_GROUP_RIREKI
    ADD(CONSTRAINT PK_MS_HOJIN_GROUP_RIREKI PRIMARY KEY (HOJIN_GROUP_CD, HOJIN_GROUP_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_HOJIN_GROUP_SETTEI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_HOJIN_GROUP_SETTEI
(
    HOJIN_GROUP_CD                  VARCHAR2(10) NOT NULL,
    HOJIN_BANGO                     VARCHAR2(13) NOT NULL,
    HOJIN_GROUP_SETTEI_DATA_VERSION NUMBER(3,0) NOT NULL,
    HOJIN_GROUP_DATA_VERSION        NUMBER(3,0) NOT NULL,
    HOJIN_BANGO_DATA_VERSION        NUMBER(3,0) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_HOJIN_GROUP_SETTEI
    ADD(CONSTRAINT PK_MS_HOJIN_GROUP_SETTEI PRIMARY KEY (HOJIN_GROUP_CD, HOJIN_BANGO) USING INDEX)
/
DROP TABLE MS_HOJIN_GROUP_SETTEI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_HOJIN_GROUP_SETTEI_RIREKI
(
    HOJIN_GROUP_CD                  VARCHAR2(10) NOT NULL,
    HOJIN_BANGO                     VARCHAR2(13) NOT NULL,
    HOJIN_GROUP_SETTEI_DATA_VERSION NUMBER(3,0) NOT NULL,
    HOJIN_GROUP_DATA_VERSION        NUMBER(3,0) NOT NULL,
    HOJIN_BANGO_DATA_VERSION        NUMBER(3,0) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_HOJIN_GROUP_SETTEI_RIREKI
    ADD(CONSTRAINT PK_MS_HOJIN_GROUP_SETTEI_RIREKI PRIMARY KEY (HOJIN_GROUP_CD, HOJIN_BANGO, HOJIN_GROUP_SETTEI_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_HOJIN_BANGO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_HOJIN_BANGO
(
    HOJIN_BANGO                     VARCHAR2(13) NOT NULL,
    HOJIN_BANGO_DATA_VERSION        NUMBER(3,0) NOT NULL,
    SHOGO_MATAHA_MEISHO             VARCHAR2(300),
    HOJIN_SHUBETSU                  VARCHAR2(3),
    KOKUNAI_SHOZAICHI_TODOFUKEN     VARCHAR2(20),
    KOKUNAI_SHOZAICHI_SHIKUCHOSON   VARCHAR2(40),
    KOKUNAI_SHOZAICHI_CHOMEBANCHI   VARCHAR2(600),
    TODOFUKEN_CD                    CHAR(2),
    SHIKUCHOSON_CD                  VARCHAR2(3),
    YUBIN_BANGO                     VARCHAR2(7),
    KOKUGAI_SHOZAICHI               VARCHAR2(600),
    SAIGO_SHORI_KBN                 VARCHAR2(2),
    SHOKEI_SAKI_HOJIN_BANGO         VARCHAR2(13),
    TORIHIKI_SHONIN_JOTAI           VARCHAR2(1),
    YOSHIN_GENDO_GAKU               NUMBER(10,0),
    YOSHIN_KIJUN_CHI                NUMBER(7,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_HOJIN_BANGO
    ADD(CONSTRAINT PK_MS_HOJIN_BANGO PRIMARY KEY (HOJIN_BANGO) USING INDEX)
/
DROP TABLE MS_HOJIN_BANGO_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_HOJIN_BANGO_RIREKI
(
    HOJIN_BANGO                     VARCHAR2(13) NOT NULL,
    HOJIN_BANGO_DATA_VERSION        NUMBER(3,0) NOT NULL,
    SHOGO_MATAHA_MEISHO             VARCHAR2(300),
    HOJIN_SHUBETSU                  VARCHAR2(3),
    KOKUNAI_SHOZAICHI_TODOFUKEN     VARCHAR2(20),
    KOKUNAI_SHOZAICHI_SHIKUCHOSON   VARCHAR2(40),
    KOKUNAI_SHOZAICHI_CHOMEBANCHI   VARCHAR2(600),
    TODOFUKEN_CD                    CHAR(2),
    SHIKUCHOSON_CD                  VARCHAR2(3),
    YUBIN_BANGO                     VARCHAR2(7),
    KOKUGAI_SHOZAICHI               VARCHAR2(600),
    SAIGO_SHORI_KBN                 VARCHAR2(2),
    SHOKEI_SAKI_HOJIN_BANGO         VARCHAR2(13),
    TORIHIKI_SHONIN_JOTAI           VARCHAR2(1),
    YOSHIN_GENDO_GAKU               NUMBER(10,0),
    YOSHIN_KIJUN_CHI                NUMBER(7,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_HOJIN_BANGO_RIREKI
    ADD(CONSTRAINT PK_MS_HOJIN_BANGO_RIREKI PRIMARY KEY (HOJIN_BANGO, HOJIN_BANGO_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_MISHU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_MISHU
(
    MISHUNO                         CHAR(13) NOT NULL,
    SEIKYU_ID                       NUMBER(18,0) NOT NULL,
    SEIKYUSAKI_CD                   VARCHAR2(6) NOT NULL,
    SEIKYUSHO_NO                    VARCHAR2(6) NOT NULL,
    SEIKYUSHO_EDABAN                NUMBER(3,0) NOT NULL,
    SEIKYU_KINGAKU                  NUMBER(21,0) NOT NULL,
    TANTO_EIGYOSHO_CD               CHAR(4) NOT NULL,
    SHIMEBI                         DATE,
    ORIGINAL_NYUKIN_YOTEIBI         DATE,
    K_BANK_FILE_DL_USER_CD          VARCHAR2(6) NOT NULL,
    K_BANK_FILE_DL_NICHIJI          DATE NOT NULL,
    NYUKIN_JOUKYOU_KBN              CHAR(1) NOT NULL,
    NYUKIN_TOROKU_NICHIJI           DATE,
    SAISHIN_NYUKIN_ID               NUMBER(18,0),
    NYUKIN_SOUGAKU                  NUMBER(21,0) NOT NULL,
    ZANDAKA_KINGAKU                 NUMBER(21,0),
    NYUKINBI                        CHAR(8),
    NYUKIN_HOHO                     CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_MISHU
    ADD(CONSTRAINT PK_TR_SEIKYUSHO_FILE1 PRIMARY KEY (MISHUNO, SEIKYU_ID) USING INDEX)
/
DROP TABLE TR_MISHU_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_MISHU_RIREKI
(
    MISHUNO                         CHAR(13) NOT NULL,
    MISHUNO_EDABAN                  CHAR(3) NOT NULL,
    SEIKYU_ID                       NUMBER(18,0) NOT NULL,
    SEIKYUSAKI_CD                   VARCHAR2(6) NOT NULL,
    SEIKYUSHO_NO                    VARCHAR2(6) NOT NULL,
    SEIKYUSHO_EDABAN                NUMBER(3,0) NOT NULL,
    SEIKYU_KINGAKU                  NUMBER(21,0) NOT NULL,
    TANTO_EIGYOSHO_CD               CHAR(4),
    SHIMEBI                         DATE,
    ORIGINAL_NYUKIN_YOTEIBI         DATE NOT NULL,
    K_BANK_FILE_DL_USER_CD          VARCHAR2(6) NOT NULL,
    K_BANK_FILE_DL_NICHIJI          DATE NOT NULL,
    NYUKIN_JOUKYOU_KBN              CHAR(1),
    NYUKIN_TOROKU_NICHIJI           DATE,
    SAISHIN_NYUKIN_ID               NUMBER(18,0) NOT NULL,
    NYUKIN_SOUGAKU                  NUMBER(21,0),
    ZANDAKA_KINGAKU                 NUMBER(21,0),
    NYUKINBI                        CHAR(8),
    NYUKIN_HOHO                     CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_MISHU_RIREKI
    ADD(CONSTRAINT PK_MISHU1 PRIMARY KEY (MISHUNO, MISHUNO_EDABAN, SEIKYU_ID) USING INDEX)
/
DROP TABLE TR_YUSO_SHIIRE_MEISAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_YUSO_SHIIRE_MEISAI
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(18,0) NOT NULL,
    AKA_KURO_KBN                    CHAR(1) NOT NULL,
    YUSO_SHIIRE_MEISAI_NO           NUMBER(3,0) NOT NULL,
    SHIIRE_KBN_CD                   CHAR(4) NOT NULL,
    SHIIRESAKI_CD                   VARCHAR2(5) NOT NULL,
    SHIIRE_KINGAKU                  NUMBER(10,0) NOT NULL,
    EIGYOSHO_CD                     VARCHAR2(5) NOT NULL,
    SHIIRE_COMMENT                  VARCHAR2(80),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_YUSO_SHIIRE_MEISAI
    ADD(CONSTRAINT PK_TR_YUSO_SHIIRE_MEISAI PRIMARY KEY (URIAGE_ID, YUSO_SHIIRE_MEISAI_NO, URIAGE_DATA_VERSION, AKA_KURO_KBN) USING INDEX)
/
DROP TABLE TR_YUSO_SHIIRE_MEISAI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_YUSO_SHIIRE_MEISAI_RIREKI
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(3,0) NOT NULL,
    YUSO_SHIIRE_MEISAI_NO           NUMBER(3,0) NOT NULL,
    SHIIRE_KBN_CD                   CHAR(4) NOT NULL,
    SHIIRESAKI_CD                   VARCHAR2(5) NOT NULL,
    SHIIRE_KINGAKU                  NUMBER(10,0) NOT NULL,
    EIGYOSHO_CD                     VARCHAR2(5) NOT NULL,
    SHIIRE_COMMENT                  VARCHAR2(80),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_YUSO_SHIIRE_MEISAI_RIREKI
    ADD(CONSTRAINT PK_TR_YUSO_SHIIRE_MEISAI_RIREKI PRIMARY KEY (URIAGE_ID, YUSO_SHIIRE_MEISAI_NO, URIAGE_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_YUSO_SEIKYUSHO_RYOKIN_PTN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_YUSO_SEIKYUSHO_RYOKIN_PTN
(
    YUSO_SEIKYUSHO_RYOKIN_PTN       CHAR(1) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    YUSO_SEIKYUSHO_RYOKIN_PTN_DATA_VERSION NUMBER(3,0) NOT NULL,
    YUSO_SEIKYUSHO_RYOKIN_PTN_MEI   VARCHAR2(40),
    YUSO_SEIKYUSHO_RYOKIN_KOMOKU_CD_1 CHAR(3),
    YUSO_SEIKYUSHO_RYOKIN_KOMOKU_CD_2 CHAR(3),
    YUSO_SEIKYUSHO_RYOKIN_KOMOKU_CD_3 CHAR(3),
    YUSO_SEIKYUSHO_RYOKIN_KOMOKU_CD_4 CHAR(3),
    YUSO_SEIKYUSHO_RYOKIN_KOMOKU_CD_5 CHAR(3),
    YUSO_SEIKYUSHO_RYOKIN_KOMOKU_CD_6 CHAR(3),
    YUSO_SEIKYUSHO_RYOKIN_KOMOKU_CD_7 CHAR(3),
    YUSO_SEIKYUSHO_RYOKIN_KOMOKU_CD_8 CHAR(3),
    NARABI_JUN                      NUMBER(2,0),
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_YUSO_SEIKYUSHO_RYOKIN_PTN
    ADD(CONSTRAINT PK_MS_YUSO_SEIKYUSHO_RYOKIN_PTN PRIMARY KEY (YUSO_SEIKYUSHO_RYOKIN_PTN, TEKIYO_KAISHIBI, TEKIYO_FLG) USING INDEX)
/
DROP TABLE MS_YUSO_SEIKYUSHO_RYOKIN_PTN_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_YUSO_SEIKYUSHO_RYOKIN_PTN_RIREKI
(
    YUSO_SEIKYUSHO_RYOKIN_PTN       CHAR(1) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_FLG                      CHAR(1) NOT NULL,
    YUSO_SEIKYUSHO_RYOKIN_PTN_DATA_VERSION NUMBER(3,0) NOT NULL,
    YUSO_SEIKYUSHO_RYOKIN_PTN_MEI   VARCHAR2(40),
    YUSO_SEIKYUSHO_RYOKIN_KOMOKU_CD_1 CHAR(3),
    YUSO_SEIKYUSHO_RYOKIN_KOMOKU_CD_2 CHAR(3),
    YUSO_SEIKYUSHO_RYOKIN_KOMOKU_CD_3 CHAR(3),
    YUSO_SEIKYUSHO_RYOKIN_KOMOKU_CD_4 CHAR(3),
    YUSO_SEIKYUSHO_RYOKIN_KOMOKU_CD_5 CHAR(3),
    YUSO_SEIKYUSHO_RYOKIN_KOMOKU_CD_6 CHAR(3),
    YUSO_SEIKYUSHO_RYOKIN_KOMOKU_CD_7 CHAR(3),
    YUSO_SEIKYUSHO_RYOKIN_KOMOKU_CD_8 CHAR(3),
    NARABI_JUN                      NUMBER(2,0),
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_YUSO_SEIKYUSHO_RYOKIN_PTN_RIREKI
    ADD(CONSTRAINT PK_MS_YUSO_SEIKYUSHO_RYOKIN_PTN_RIREKI PRIMARY KEY (YUSO_SEIKYUSHO_RYOKIN_PTN, TEKIYO_KAISHIBI, TEKIYO_FLG, YUSO_SEIKYUSHO_RYOKIN_PTN_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_YUSO_URIAGE CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_YUSO_URIAGE
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(18,0) NOT NULL,
    AKA_KURO_KBN                    CHAR(1) NOT NULL,
    SAISIN_URIAGE_FLG               CHAR(1),
    KOKYAKU_CD                      CHAR(6),
    OKURIJO_SEQ                     NUMBER(18,0) NOT NULL,
    OKURIJO_NO                      CHAR(13) NOT NULL,
    URIAGE_STATUS                   CHAR(1) NOT NULL,
    ERROR_JOHO                      VARCHAR2(20),
    KEIRI_KEIJOBI                   CHAR(8) NOT NULL,
    ORIGINAL_KEIRI_KEIJO_HI         CHAR(8),
    SHIHARAI_HOHO                   CHAR(2),
    MOTO_CHAKU_KBN                  CHAR(2),
    TASHA_CHUKEI_FLG                CHAR(1),
    HANBAI_EIGYOSHO                 VARCHAR2(5),
    SEIKYU_EIGYOSHO                 VARCHAR2(5),
    DAISANSHA_HARAI_FLG             CHAR(1) NOT NULL,
    DAISANSHA_HARAI_CD              CHAR(6),
    SEIKYUSAKI_CD                   CHAR(6),
    KEIYAKUSAKI_CD                  CHAR(6),
    CHAKUBARAI_SEIKYUSAKI_CD        CHAR(6),
    SEIKYU_JURYO                    NUMBER(8,1),
    BIKO_RAN                        VARCHAR2(40),
    SEIKYU_KINGAKU                  NUMBER(10,0),
    ARARI                           NUMBER(10,0),
    CHAKU_KUKO_CD                   CHAR(3),
    HAITATSU_SHIJI                  CHAR(1),
    KEIYU_KUKO_CD                   CHAR(3),
    HATSU_KUKO_CD                   CHAR(3),
    SHUKA_SHIJI                     CHAR(1),
    HOKEN_KBN                       CHAR(3),
    HOKEN_KINGAKU                   NUMBER(10,0),
    MAWB_KOGUCHI_FLG                CHAR(1) NOT NULL,
    HAITATSU_CHIKU                  CHAR(1),
    RITO_FLG                        CHAR(1) NOT NULL,
    KANNAIHAISO_FLG                 CHAR(1) NOT NULL,
    SHUKA_CHIKU                     CHAR(1),
    SEIKYUSHO_KISAIBI               CHAR(8),
    DATA_MOTO                       CHAR(2),
    URIAGE_NYURYOKU_FUYO_FLG        CHAR(1) NOT NULL,
    AKA_KURO_FLG                    CHAR(1) NOT NULL,
    SHIME_TAISHO_KBN                CHAR(1) NOT NULL,
    SHIME_JOKYO_KBN                 CHAR(1) NOT NULL,
    SHIMEBI                         CHAR(8) NOT NULL,
    URIAGE_COMMENT                  VARCHAR2(1024),
    GAZO_ID                         NUMBER(18,0),
    UNCHIN_KEISAN_KBN               CHAR(1) NOT NULL,
    UNCHIN_GOKEI                    NUMBER(10,0),
    MAEBARAI_KAISHU_KINGAKU         NUMBER(10,0),
    CHAKUBARAI_KAISHU_KINGAKU       NUMBER(10,0),
    DAIBIKI_KAISHU_KINGAKU          NUMBER(10,0),
    NEBIKI_KINGAKU                  NUMBER(10,0),
    WARIMODOSHI_KINGAKU             NUMBER(10,0),
    KAZEI_TAISHO_KINGAKU            NUMBER(10,0),
    SHOHIZEI_KINGAKU                NUMBER(10,0),
    UCHIZEI_KINGAKU                 NUMBER(10,0),
    HIKAZEI_KINGAKU                 NUMBER(10,0),
    IF_RENKEI_JOKYO_FLG             CHAR(1) NOT NULL,
    IF_RENKEI_TAISHO_FLG            CHAR(1) NOT NULL,
    DAIRITEN_CHUKEI_HAITATSU_RYO_KEISAN_KEKKA CHAR(2),
    SHIIRE_DATA_SAKUSEI_JOKYO_FLG   CHAR(1),
    SHIIRE_DATA_SAKUSEI_TAISHO_FLG  CHAR(1) NOT NULL,
    OROSHI_BUMPAI_KEISAN_KBN        CHAR(1) NOT NULL,
    OROSHI_BUMPAI_ROUTE_EDABAN      VARCHAR2(1),
    OROSHI_BUMPAI_ROUTE_KAISHIBI    DATE,
    HORYU_HIZUKE                    DATE,
    YUSO_RYOKIN_1                   NUMBER(9,0),
    YUSO_RYOKIN_2                   NUMBER(9,0) NOT NULL,
    YUSO_RYOKIN_3                   NUMBER(9,0) NOT NULL,
    YUSO_RYOKIN_4                   NUMBER(9,0) NOT NULL,
    YUSO_RYOKIN_5                   NUMBER(9,0),
    YUSO_RYOKIN_6                   NUMBER(9,0),
    YUSO_RYOKIN_7                   NUMBER(9,0) NOT NULL,
    YUSO_RYOKIN_8                   NUMBER(9,0),
    YUSO_RYOKIN_9                   NUMBER(9,0),
    YUSO_RYOKIN_10                  NUMBER(9,0),
    YUSO_RYOKIN_11                  NUMBER(9,0),
    YUSO_RYOKIN_12                  NUMBER(9,0),
    YUSO_RYOKIN_13                  NUMBER(9,0),
    YUSO_RYOKIN_14                  NUMBER(9,0),
    YUSO_RYOKIN_15                  NUMBER(9,0),
    YUSO_RYOKIN_16                  NUMBER(9,0),
    YUSO_RYOKIN_17                  NUMBER(9,0),
    YUSO_RYOKIN_18                  NUMBER(9,0),
    YUSO_RYOKIN_19                  NUMBER(9,0),
    YUSO_RYOKIN_20                  NUMBER(9,0),
    YUSO_RYOKIN_21                  NUMBER(9,0),
    YUSO_RYOKIN_22                  NUMBER(9,0),
    YUSO_RYOKIN_23                  NUMBER(9,0),
    YUSO_RYOKIN_24                  NUMBER(9,0),
    YUSO_RYOKIN_25                  NUMBER(9,0),
    YUSO_RYOKIN_26                  NUMBER(9,0),
    YUSO_RYOKIN_27                  NUMBER(9,0),
    YUSO_RYOKIN_28                  NUMBER(9,0),
    YUSO_RYOKIN_29                  NUMBER(9,0),
    YUSO_RYOKIN_30                  NUMBER(9,0),
    YUSO_RYOKIN_31                  NUMBER(9,0),
    YUSO_RYOKIN_32                  NUMBER(9,0),
    YUSO_RYOKIN_33                  NUMBER(9,0),
    YUSO_RYOKIN_34                  NUMBER(9,0),
    YUSO_RYOKIN_35                  NUMBER(9,0),
    YUSO_RYOKIN_36                  NUMBER(9,0),
    YUSO_RYOKIN_37                  NUMBER(9,0),
    YUSO_RYOKIN_38                  NUMBER(9,0),
    YUSO_RYOKIN_39                  NUMBER(9,0),
    YUSO_RYOKIN_40                  NUMBER(9,0),
    YUSO_RYOKIN_41                  NUMBER(9,0),
    YUSO_RYOKIN_42                  NUMBER(9,0),
    YUSO_RYOKIN_43                  NUMBER(9,0),
    YUSO_RYOKIN_44                  NUMBER(9,0),
    YUSO_RYOKIN_45                  NUMBER(9,0),
    YUSO_RYOKIN_46                  NUMBER(9,0),
    YUSO_RYOKIN_47                  NUMBER(9,0),
    YUSO_RYOKIN_48                  NUMBER(9,0),
    YUSO_RYOKIN_49                  NUMBER(9,0),
    YUSO_RYOKIN_50                  NUMBER(9,0),
    YUSO_RYOKIN_51                  NUMBER(9,0),
    YUSO_RYOKIN_52                  NUMBER(9,0),
    YUSO_RYOKIN_53                  NUMBER(9,0),
    YUSO_RYOKIN_54                  NUMBER(9,0),
    YUSO_RYOKIN_55                  NUMBER(9,0),
    YUSO_RYOKIN_56                  NUMBER(9,0),
    YUSO_RYOKIN_57                  NUMBER(9,0),
    YUSO_RYOKIN_58                  NUMBER(9,0),
    YUSO_RYOKIN_59                  NUMBER(9,0),
    YUSO_RYOKIN_60                  NUMBER(9,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_YUSO_URIAGE
    ADD(CONSTRAINT PK_TR_YUSO_URIAGE PRIMARY KEY (URIAGE_ID, URIAGE_DATA_VERSION, AKA_KURO_KBN) USING INDEX)
/
DROP TABLE TR_YUSO_URIAGE_FUTAI_RYOKIN CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_YUSO_URIAGE_FUTAI_RYOKIN
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(3,0),
    AKA_KURO_KBN                    CHAR(1),
    URIAGE_MEISAI_NO                NUMBER(3,0) NOT NULL,
    KEIYAKU_ID                      NUMBER(6,0) NOT NULL,
    RYOKINHYO_NO                    CHAR(7) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0) NOT NULL,
    RYOKIN_KOMOKU_1_CD              VARCHAR2(2),
    RYOKIN_KOMOKU_2_CD              VARCHAR2(3),
    HYOJI_MEI                       VARCHAR2(40),
    TANKA                           NUMBER(10,0),
    TANI                            VARCHAR2(20),
    SURYO                           NUMBER(9,0),
    KINGAKU                         NUMBER(10,0),
    SHOKEI                          NUMBER(10,0),
    NEBIKI_KINGAKU                  NUMBER(10,0),
    WARIMODOSHI_KINGAKU             NUMBER(10,0),
    KAZEI_TAISHO_KINGAKU            NUMBER(10,0),
    SHOHIZEI_KINGAKU                NUMBER(10,0) NOT NULL,
    UCHIZEI_KINGAKU                 NUMBER(10,0),
    HIKAZEI_KINGAKU                 NUMBER(10,0),
    TENYURYOKU_FLG                  CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_YUSO_URIAGE_FUTAI_RYOKIN
    ADD(CONSTRAINT PK_TR_YUSO_URIAGE_FUTAI_RYOKIN PRIMARY KEY (URIAGE_ID, URIAGE_MEISAI_NO) USING INDEX)
/
DROP TABLE TR_YUSO_URIAGE_FUTAI_RYOKIN_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_YUSO_URIAGE_FUTAI_RYOKIN_RIREKI
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(3,0) NOT NULL,
    URIAGE_MEISAI_NO                NUMBER(3,0) NOT NULL,
    KEIYAKU_ID                      NUMBER(6,0) NOT NULL,
    RYOKINHYO_NO                    CHAR(7) NOT NULL,
    MEISAI_GYO_NO                   NUMBER(3,0),
    RYOKIN_KOMOKU_1_CD              VARCHAR2(2),
    RYOKIN_KOMOKU_2_CD              VARCHAR2(3),
    HYOJI_MEI                       VARCHAR2(40),
    TANKA                           NUMBER(10,0),
    TANI                            VARCHAR2(20),
    SURYO                           NUMBER(9,0),
    KINGAKU                         NUMBER(10,0),
    SHOKEI                          NUMBER(10,0),
    NEBIKI_KINGAKU                  NUMBER(10,0),
    WARIMODOSHI_KINGAKU             NUMBER(10,0),
    KAZEI_TAISHO_KINGAKU            NUMBER(10,0),
    SHOHIZEI_KINGAKU                NUMBER(10,0) NOT NULL,
    UCHIZEI_KINGAKU                 NUMBER(10,0),
    HIKAZEI_KINGAKU                 NUMBER(10,0),
    TENYURYOKU_FLG                  CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE,
    YUSO_URIAGE_DATA_VERSION        NUMBER(3,0) NOT NULL
)
/
ALTER TABLE TR_YUSO_URIAGE_FUTAI_RYOKIN_RIREKI
    ADD(CONSTRAINT PK_TR_YUSO_URIAGE_FUTAI_RYOKIN_RIREKI PRIMARY KEY (URIAGE_ID, URIAGE_DATA_VERSION, URIAGE_MEISAI_NO, YUSO_URIAGE_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_YUSO_URIAGE_MEISAI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_YUSO_URIAGE_MEISAI
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    URIAGE_MEISAI_NO                NUMBER(3,0) NOT NULL,
    RYOKIN_KOMOKU_CD                CHAR(3) NOT NULL,
    KINGAKU                         NUMBER(10,0),
    SHOHIZEI_KINGAKU                NUMBER(10,0),
    NEBIKI_KINGAKU                  NUMBER(10,0),
    WARIMODOSHI_KINGAKU             NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_YUSO_URIAGE_MEISAI
    ADD(CONSTRAINT PK_TR_YUSO_URIAGE_MEISAI PRIMARY KEY (URIAGE_ID, URIAGE_MEISAI_NO, RYOKIN_KOMOKU_CD) USING INDEX)
/
DROP TABLE TR_YUSO_URIAGE_MEISAI_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_YUSO_URIAGE_MEISAI_RIREKI
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    URIAGE_DATA_VERSION             NUMBER(18,0) NOT NULL,
    URIAGE_MEISAI_NO                NUMBER(3,0) NOT NULL,
    RYOKIN_KOMOKU_CD                CHAR(3) NOT NULL,
    KINGAKU                         NUMBER(10,0),
    SHOHIZEI_KINGAKU                NUMBER(10,0) NOT NULL,
    NEBIKI_KINGAKU                  NUMBER(10,0),
    WARIMODOSHI_KINGAKU             NUMBER(10,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_YUSO_URIAGE_MEISAI_RIREKI
    ADD(CONSTRAINT PK_TR_YUSO_URIAGE_MEISAI_RIREKI PRIMARY KEY (URIAGE_ID, URIAGE_MEISAI_NO, URIAGE_DATA_VERSION, RYOKIN_KOMOKU_CD) USING INDEX)
/
DROP TABLE TR_YUSO_URIAGE_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_YUSO_URIAGE_RIREKI
(
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    YUSO_URIAGE_DATA_VERSION        NUMBER(3,0) NOT NULL,
    KOKYAKU_CD                      CHAR(6),
    OKURIJO_SEQ                     NUMBER(18,0) NOT NULL,
    OKURIJO_NO                      CHAR(13) NOT NULL,
    URIAGE_STATUS                   CHAR(1) NOT NULL,
    ERROR_JOHO                      VARCHAR2(20),
    KEIRI_KEIJOBI                   CHAR(8) NOT NULL,
    ORIGINAL_KEIRI_KEIJO_HI         CHAR(8),
    SHIHARAI_HOHO                   CHAR(2),
    MOTO_CHAKU_KBN                  CHAR(2),
    TASHA_CHUKEI_FLG                CHAR(1),
    HANBAI_EIGYOSHO                 VARCHAR2(5),
    SEIKYU_EIGYOSHO                 VARCHAR2(5),
    DAISANSHA_HARAI_FLG             CHAR(1) NOT NULL,
    DAISANSHA_HARAI_CD              CHAR(6),
    SEIKYUSAKI_CD                   CHAR(6),
    KEIYAKUSAKI_CD                  CHAR(6),
    CHAKUBARAI_SEIKYUSAKI_CD        CHAR(6),
    SEIKYU_JURYO                    NUMBER(8,0),
    BIKO_RAN                        VARCHAR2(40),
    SEIKYU_KINGAKU                  NUMBER(10,0),
    ARARI                           NUMBER(10,0),
    CHAKU_KUKO_CD                   CHAR(3),
    HAITATSU_SHIJI                  CHAR(1),
    KEIYU_KUKO_CD                   CHAR(3),
    HATSU_KUKO_CD                   CHAR(3),
    SHUKA_SHIJI                     CHAR(1),
    HOKEN_KBN                       CHAR(3),
    HOKEN_KINGAKU                   NUMBER(10,0),
    MAWB_KOGUCHI_FLG                CHAR(1) NOT NULL,
    HAITATSU_CHIKU                  CHAR(1),
    RITO_FLG                        CHAR(1) NOT NULL,
    KANNAIHAISO_FLG                 CHAR(1) NOT NULL,
    SHUKA_CHIKU                     CHAR(1),
    SEIKYUSHO_KISAIBI               CHAR(8),
    DATA_MOTO                       CHAR(2),
    URIAGE_NYURYOKU_FUYO_FLG        CHAR(1) NOT NULL,
    AKA_KURO_FLG                    CHAR(1) NOT NULL,
    SHIME_TAISHO_KBN                CHAR(1) NOT NULL,
    SHIME_JOKYO_KBN                 CHAR(1) NOT NULL,
    SHIMEBI                         CHAR(8) NOT NULL,
    URIAGE_COMMENT                  VARCHAR2(1024),
    GAZO_ID                         NUMBER(18,0),
    UNCHIN_KEISAN_KBN               CHAR(1) NOT NULL,
    UNCHIN_GOKEI                    NUMBER(10,0),
    MAEBARAI_KAISHU_KINGAKU         NUMBER(10,0),
    CHAKUBARAI_KAISHU_KINGAKU       NUMBER(10,0),
    DAIBIKI_KAISHU_KINGAKU          NUMBER(10,0),
    NEBIKI_KINGAKU                  NUMBER(10,0),
    WARIMODOSHI_KINGAKU             NUMBER(10,0),
    KAZEI_TAISHO_KINGAKU            NUMBER(10,0),
    SHOHIZEI_KINGAKU                NUMBER(10,0),
    UCHIZEI_KINGAKU                 NUMBER(10,0),
    HIKAZEI_KINGAKU                 NUMBER(10,0),
    IF_RENKEI_JOKYO_FLG             CHAR(1) NOT NULL,
    IF_RENKEI_TAISHO_FLG            CHAR(1) NOT NULL,
    DAIRITEN_CHUKEI_HAITATSU_RYO_KEISAN_KEKKA CHAR(2),
    SHIIRE_DATA_SAKUSEI_JOKYO_FLG   CHAR(1),
    SHIIRE_DATA_SAKUSEI_TAISHO_FLG  CHAR(1),
    OROSHI_BUMPAI_KEISAN_KBN        CHAR(1),
    OROSHI_BUMPAI_ROUTE_EDABAN      VARCHAR2(1),
    OROSHI_BUMPAI_ROUTE_KAISHIBI    DATE,
    HORYU_HIZUKE                    DATE,
    YUSO_RYOKIN_1                   NUMBER(9,0),
    YUSO_RYOKIN_2                   NUMBER(9,0) NOT NULL,
    YUSO_RYOKIN_3                   NUMBER(9,0) NOT NULL,
    YUSO_RYOKIN_4                   NUMBER(9,0) NOT NULL,
    YUSO_RYOKIN_5                   NUMBER(9,0),
    YUSO_RYOKIN_6                   NUMBER(9,0),
    YUSO_RYOKIN_7                   NUMBER(9,0) NOT NULL,
    YUSO_RYOKIN_8                   NUMBER(9,0),
    YUSO_RYOKIN_9                   NUMBER(9,0),
    YUSO_RYOKIN_10                  NUMBER(9,0),
    YUSO_RYOKIN_11                  NUMBER(9,0),
    YUSO_RYOKIN_12                  NUMBER(9,0),
    YUSO_RYOKIN_13                  NUMBER(9,0),
    YUSO_RYOKIN_14                  NUMBER(9,0),
    YUSO_RYOKIN_15                  NUMBER(9,0),
    YUSO_RYOKIN_16                  NUMBER(9,0),
    YUSO_RYOKIN_17                  NUMBER(9,0),
    YUSO_RYOKIN_18                  NUMBER(9,0),
    YUSO_RYOKIN_19                  NUMBER(9,0),
    YUSO_RYOKIN_20                  NUMBER(9,0),
    YUSO_RYOKIN_21                  NUMBER(9,0),
    YUSO_RYOKIN_22                  NUMBER(9,0),
    YUSO_RYOKIN_23                  NUMBER(9,0),
    YUSO_RYOKIN_24                  NUMBER(9,0),
    YUSO_RYOKIN_25                  NUMBER(9,0),
    YUSO_RYOKIN_26                  NUMBER(9,0),
    YUSO_RYOKIN_27                  NUMBER(9,0),
    YUSO_RYOKIN_28                  NUMBER(9,0),
    YUSO_RYOKIN_29                  NUMBER(9,0),
    YUSO_RYOKIN_30                  NUMBER(9,0),
    YUSO_RYOKIN_31                  NUMBER(9,0),
    YUSO_RYOKIN_32                  NUMBER(9,0),
    YUSO_RYOKIN_33                  NUMBER(9,0),
    YUSO_RYOKIN_34                  NUMBER(9,0),
    YUSO_RYOKIN_35                  NUMBER(9,0),
    YUSO_RYOKIN_36                  NUMBER(9,0),
    YUSO_RYOKIN_37                  NUMBER(9,0),
    YUSO_RYOKIN_38                  NUMBER(9,0),
    YUSO_RYOKIN_39                  NUMBER(9,0),
    YUSO_RYOKIN_40                  NUMBER(9,0),
    YUSO_RYOKIN_41                  NUMBER(9,0),
    YUSO_RYOKIN_42                  NUMBER(9,0),
    YUSO_RYOKIN_43                  NUMBER(9,0),
    YUSO_RYOKIN_44                  NUMBER(9,0),
    YUSO_RYOKIN_45                  NUMBER(9,0),
    YUSO_RYOKIN_46                  NUMBER(9,0),
    YUSO_RYOKIN_47                  NUMBER(9,0),
    YUSO_RYOKIN_48                  NUMBER(9,0),
    YUSO_RYOKIN_49                  NUMBER(9,0),
    YUSO_RYOKIN_50                  NUMBER(9,0),
    YUSO_RYOKIN_51                  NUMBER(9,0),
    YUSO_RYOKIN_52                  NUMBER(9,0),
    YUSO_RYOKIN_53                  NUMBER(9,0),
    YUSO_RYOKIN_54                  NUMBER(9,0),
    YUSO_RYOKIN_55                  NUMBER(9,0),
    YUSO_RYOKIN_56                  NUMBER(9,0),
    YUSO_RYOKIN_57                  NUMBER(9,0),
    YUSO_RYOKIN_58                  NUMBER(9,0),
    YUSO_RYOKIN_59                  NUMBER(9,0),
    YUSO_RYOKIN_60                  NUMBER(9,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_YUSO_URIAGE_RIREKI
    ADD(CONSTRAINT PK_TR_YUSO_URIAGE_RIREKI PRIMARY KEY (URIAGE_ID, YUSO_URIAGE_DATA_VERSION) USING INDEX)
/
DROP TABLE MS_YUSO_HOHO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_YUSO_HOHO
(
    YUSO_HOHO_CD                    CHAR(2) NOT NULL,
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    TEKIYO_SHURYOBI                 DATE,
    YUSO_HOHO_MEI                   VARCHAR2(20),
    YUSO_HOHO_HYOJI_MEI             VARCHAR2(10),
    YUSO_HOHO_RYAKUSHO              VARCHAR2(10),
    YUSO_SHUDAN_CD                  CHAR(1),
    LABEL_HYOJI_UMU_FLG             VARCHAR2(1) NOT NULL,
    HT_SHIYO_UMU_FLG                VARCHAR2(1) NOT NULL,
    HT_RIYO_KBN                     CHAR(1) NOT NULL,
    YUSO_URIAGE_RIYO_FLG            CHAR(1) NOT NULL,
    TASHA_CHUKEI_KBN                VARCHAR2(1) NOT NULL,
    KOGUCHI_FLG                     VARCHAR2(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_YUSO_HOHO
    ADD(CONSTRAINT PK_MS_YUSO_HOHO PRIMARY KEY (YUSO_HOHO_CD, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE MS_YUBIN_BANGO CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_YUBIN_BANGO
(
    YUBIN_BANGO                     VARCHAR2(7) NOT NULL,
    EDABAN                          NUMBER(4,0) NOT NULL,
    JUFUKU_KBN                      CHAR(1) NOT NULL,
    TODOFUKEN_MEI                   VARCHAR2(40),
    TODOFUKEN_KANA_MEI              VARCHAR2(40),
    SHIKUCHOSON_MEI                 VARCHAR2(20),
    SHIKUCHOSON_KANA_MEI            VARCHAR2(20),
    CHOIKI_MEI                      VARCHAR2(20),
    CHOIKI_KANA_MEI                 VARCHAR2(20),
    JIS_CD                          CHAR(5),
    TOROKU_NENGAPPI                 DATE,
    SAKUJO_YOTEIBI                  DATE,
    KOSHIN_FLG                      CHAR(1),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_YUBIN_BANGO
    ADD(CONSTRAINT PK_MS_YUBIN_BANGO PRIMARY KEY (YUBIN_BANGO, EDABAN, JUFUKU_KBN) USING INDEX)
/
DROP TABLE MS_RYOKIN_KOMOKU_GROUP CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_RYOKIN_KOMOKU_GROUP
(
    RYOKIN_KOMOKU_GROUP_CD          CHAR(2) NOT NULL,
    RYOKIN_KOMOKU_GROUP_MEI         VARCHAR2(40) NOT NULL,
    BIKO                            VARCHAR2(100) NOT NULL,
    UNCHIN_BOX_HYOJI_JUNJO          NUMBER(2,0) NOT NULL,
    KOTEI_GROUP_FLG                 CHAR(1) NOT NULL,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_RYOKIN_KOMOKU_GROUP
    ADD(CONSTRAINT PK_MS_RYOKIN_KOMOKU_GROUP PRIMARY KEY (RYOKIN_KOMOKU_GROUP_CD) USING INDEX)
/
DROP TABLE MS_RYOKIN_KOMOKU CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_RYOKIN_KOMOKU
(
    RYOKIN_KOMOKU_CD                CHAR(3) NOT NULL,
    RYOKIN_KOMOKU_MEISHO            VARCHAR2(40),
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    RYOKIN_KOMOKU_DATA_VERSION      NUMBER(3,0) NOT NULL,
    RYOKIN_KOMOKU_GROUP_CD          CHAR(2) NOT NULL,
    GROUP_NAI_HYOJIJUN              VARCHAR2(2) NOT NULL,
    ZEI_KBN                         CHAR(1) NOT NULL,
    YUSO_URIAGE_SET_SAKI            CHAR(2) NOT NULL,
    PROOF_YO_SHUYAKU_KOMOKU_CD      CHAR(2) NOT NULL,
    MEISAI_KBN                      CHAR(1) NOT NULL,
    OROSHINERITSU_SETTEI_KANO_FLG   CHAR(1) NOT NULL,
    OROSHINE_RITSU                  NUMBER(4,1),
    OROSHI_KEIJO_KASHO              VARCHAR2(5) NOT NULL,
    OROSHI_KOMOKU_CD                CHAR(2),
    SHORI_KAMOKU_CD                 CHAR(4) NOT NULL,
    HOJO_KAMOKU_CD                  CHAR(2) NOT NULL,
    MEISAI_KOMOKU                   CHAR(1),
    KOTEI_KOMOKU_FLG                CHAR(1) NOT NULL,
    KOTEI_KOMOKU_CD                 CHAR(2),
    UNCHIN_GOKEI_KEISAN_TAISHO_FLG  CHAR(1) NOT NULL,
    ZEI_KEISAN_TAISHO_FLG           CHAR(1) NOT NULL,
    TEKIYO_MEI                      VARCHAR2(40),
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_RYOKIN_KOMOKU
    ADD(CONSTRAINT IX_MS_RYOKIN_KOMOKU UNIQUE (RYOKIN_KOMOKU_CD) USING INDEX)
/
ALTER TABLE MS_RYOKIN_KOMOKU
    ADD(CONSTRAINT PK_MS_RYOKIN_KOMOKU PRIMARY KEY (RYOKIN_KOMOKU_CD, TEKIYO_KAISHIBI) USING INDEX)
/
DROP TABLE MS_RYOKIN_KOMOKU_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE MS_RYOKIN_KOMOKU_RIREKI
(
    RYOKIN_KOMOKU_CD                CHAR(3) NOT NULL,
    RYOKIN_KOMOKU_MEISHO            VARCHAR2(40),
    TEKIYO_KAISHIBI                 DATE NOT NULL,
    OROSHI_KOMOKU_CD                CHAR(2),
    RYOKIN_KOMOKU_DATA_VERSION      NUMBER(3,0) NOT NULL,
    RYOKIN_KOMOKU_GROUP_CD          CHAR(2) NOT NULL,
    GROUP_NAI_HYOJIJUN              VARCHAR2(2) NOT NULL,
    ZEI_KBN                         CHAR(1) NOT NULL,
    YUSO_URIAGE_SET_SAKI            CHAR(2) NOT NULL,
    PROOF_YO_SHUYAKU_KOMOKU_CD      CHAR(2) NOT NULL,
    MEISAI_KBN                      CHAR(1) NOT NULL,
    OROSHINERITSU_SETTEI_KANO_FLG   CHAR(1) NOT NULL,
    OROSHINE_RITSU                  NUMBER(4,1),
    OROSHI_KEIJO_KASHO              VARCHAR2(5) NOT NULL,
    SHORI_KAMOKU_CD                 CHAR(4) NOT NULL,
    HOJO_KAMOKU_CD                  CHAR(2) NOT NULL,
    MEISAI_KOMOKU                   CHAR(1),
    KOTEI_KOMOKU_FLG                CHAR(1) NOT NULL,
    KOTEI_KOMOKU_CD                 CHAR(2),
    UNCHIN_GOKEI_KEISAN_TAISHO_FLG  CHAR(1) NOT NULL,
    ZEI_KEISAN_TAISHO_FLG           CHAR(1) NOT NULL,
    TEKIYO_MEI                      VARCHAR2(40),
    TEKIYO_SHURYOBI                 DATE,
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE MS_RYOKIN_KOMOKU_RIREKI
    ADD(CONSTRAINT IX_MS_RYOKIN_KOMOKU_RIREKI UNIQUE (RYOKIN_KOMOKU_CD) USING INDEX)
/
ALTER TABLE MS_RYOKIN_KOMOKU_RIREKI
    ADD(CONSTRAINT PK_MS_RYOKIN_KOMOKU_RIREKI PRIMARY KEY (RYOKIN_KOMOKU_CD, TEKIYO_KAISHIBI, RYOKIN_KOMOKU_DATA_VERSION) USING INDEX)
/
DROP TABLE TR_RYOKINHYO_KAGAMI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_RYOKINHYO_KAGAMI
(
    KEIYAKU_ID                      NUMBER(6,0) NOT NULL,
    RYOKINHYO_NO                    CHAR(7) NOT NULL,
    RYOKIN_SHURUI_KBN               CHAR(2),
    TOROKU_KBN                      CHAR(1),
    MITSUMORI_MEMO                  VARCHAR2(100),
    NEBIKI_WARIMDS_TAISHO_FLG       CHAR(1),
    NEBIKI_WARIMDS_KBN              CHAR(1),
    NEBIKI_WARIMDS_GAKU             NUMBER(10,0),
    NEBIKI_WARIMDS_TANI_KBN         CHAR(2),
    MITSUMORI_TITLE                 VARCHAR2(100),
    DANGUMI                         CHAR(1),
    BIKO_1                          VARCHAR2(2000),
    BIKO_2                          VARCHAR2(2000),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_RYOKINHYO_KAGAMI
    ADD(CONSTRAINT PK_TR_RYOKINHYO_KAGAMI PRIMARY KEY (RYOKINHYO_NO, KEIYAKU_ID) USING INDEX)
/
DROP TABLE TR_RYOSHUSHO_HAKKO_RIREKI CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_RYOSHUSHO_HAKKO_RIREKI
(
    RYOSHUSHO_NO                    NUMBER(21,0) NOT NULL,
    EDABAN                          NUMBER(3,0) NOT NULL,
    URIAGE_ID                       NUMBER(18,0) NOT NULL,
    OKURIJO_NO                      CHAR(13),
    EIGYOSHO_CD                     VARCHAR2(5),
    HAKKO_NICHIJI                   DATE,
    RYOSHUSHO_KINGAKU               NUMBER(10,0),
    HAKKO_DRIVER_CD                 CHAR(7),
    HAKKO_SAKI_KOKYAKU_CD           CHAR(6),
    HT_SERIAL_BANGO                 VARCHAR2(15),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_RYOSHUSHO_HAKKO_RIREKI
    ADD(CONSTRAINT PK_TR_RYOSHUSHO_HAKKO_RIREKI PRIMARY KEY (RYOSHUSHO_NO, EDABAN, URIAGE_ID) USING INDEX)
/
DROP TABLE TR_RENKEI_KAISHU_DATA CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_RENKEI_KAISHU_DATA
(
    KAISHA_CD                       CHAR(5) NOT NULL,
    DEMPYO_HIZUKE                   CHAR(8) NOT NULL,
    DEMPYO_BANGO                    CHAR(6) NOT NULL,
    MEISAI_GYO_BANGO                NUMBER(3,0) NOT NULL,
    TAISHAKU_KBN                    CHAR(1) NOT NULL,
    KAMOKU_CD                       CHAR(4),
    HOJO_CD                         CHAR(2),
    BUMON_CD                        CHAR(3),
    KINO_CD_1                       CHAR(3),
    KINO_CD_2                       CHAR(1),
    KINO_CD_3                       CHAR(1),
    KINO_CD_4                       CHAR(1),
    SHIWAKE_KINGAKU                 NUMBER(10,0),
    ZEI_SHORI_CD                    CHAR(3),
    ZEI_NYURYOKU_KBN                CHAR(1),
    ZEI_GAKU                        NUMBER(1,0),
    GAIKA_CD                        CHAR(1),
    RATE_TYPE                       CHAR(1),
    KANSAN_RATE                     NUMBER(1,0),
    GAIKA_KINGAKU                   NUMBER(10,0),
    TEKIYO_1                        VARCHAR2(40),
    TEKIYO_2                        VARCHAR2(20),
    DEMPYO_G_CD                     CHAR(2),
    SYSTEM_KBN                      CHAR(2),
    TA_SYSTEM_DEMPYO_BANGO          CHAR(8),
    TA_SYSTEM__SYSTEM_KBN           CHAR(2),
    TA_SYSTEM_DEMPYO_G_CD           CHAR(2),
    AITE_KAMOKU_CD                  CHAR(4),
    AITE_HOJO_CD                    CHAR(2),
    NYURYOKU_USER_ID                CHAR(7),
    NYURYOKU_TAMMATSU_BANGO         CHAR(3),
    NYURYOKU_SYSTEM_HIZUKE          CHAR(8),
    SHONIN_USER_ID                  CHAR(7),
    SHONIN_TAMMATSU_BANGO           CHAR(3),
    SHONIN_SYSTEM_HIZUKE            CHAR(8),
    SHONIN_KBN                      CHAR(1),
    DEMPYO_KBN                      CHAR(1),
    HAIFU_KBN                       CHAR(1),
    SHONIN_LEVEL                    CHAR(1),
    TORIHIKISAKI_KBN                CHAR(1),
    TORIHIKISAKI_CD                 CHAR(5),
    YOBI_BUNJI_1                    CHAR(1),
    YOBI_BUNJI_2                    CHAR(1),
    YOBI_BUNJI_3                    CHAR(1),
    YOBI_BUNJI_4                    CHAR(1),
    YOBI_BUNJI_5                    CHAR(1),
    YOBI_BUNJI_6                    CHAR(1),
    YOBI_BUNJI_7                    CHAR(1),
    YOBI_BUNJI_8                    CHAR(1),
    YOBI_SUJI_1                     NUMBER(1,0),
    YOBI_SUJI_2                     NUMBER(1,0),
    YOBI_SUJI_3                     NUMBER(1,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
DROP TABLE TR_RENKEI_KAISHU_DATA_BK CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_RENKEI_KAISHU_DATA_BK
(
    KAKUNO_HIZUKE                   CHAR(16) NOT NULL,
    KAISHA_CD                       CHAR(5) NOT NULL,
    DEMPYO_HIZUKE                   CHAR(8) NOT NULL,
    DEMPYO_BANGO                    CHAR(6) NOT NULL,
    MEISAI_GYO_BANGO                NUMBER(3,0) NOT NULL,
    TAISHAKU_KBN                    CHAR(1) NOT NULL,
    KAMOKU_CD                       CHAR(4),
    HOJO_CD                         CHAR(2),
    BUMON_CD                        CHAR(3),
    KINO_CD_1                       CHAR(3),
    KINO_CD_2                       CHAR(1),
    KINO_CD_3                       CHAR(1),
    KINO_CD_4                       CHAR(1),
    SHIWAKE_KINGAKU                 NUMBER(10,0),
    ZEI_SHORI_CD                    CHAR(3),
    ZEI_NYURYOKU_KBN                CHAR(1),
    ZEI_GAKU                        NUMBER(1,0),
    GAIKA_CD                        CHAR(1),
    RATE_TYPE                       CHAR(1),
    KANSAN_RATE                     NUMBER(1,0),
    GAIKA_KINGAKU                   NUMBER(10,0),
    TEKIYO_1                        VARCHAR2(40),
    TEKIYO_2                        VARCHAR2(20),
    DEMPYO_G_CD                     CHAR(2),
    SYSTEM_KBN                      CHAR(2),
    TA_SYSTEM_DEMPYO_BANGO          CHAR(8),
    TA_SYSTEM__SYSTEM_KBN           CHAR(2),
    TA_SYSTEM_DEMPYO_G_CD           CHAR(2),
    AITE_KAMOKU_CD                  CHAR(4),
    AITE_HOJO_CD                    CHAR(2),
    NYURYOKU_USER_ID                CHAR(7),
    NYURYOKU_TAMMATSU_BANGO         CHAR(3),
    NYURYOKU_SYSTEM_HIZUKE          CHAR(8),
    SHONIN_USER_ID                  CHAR(7),
    SHONIN_TAMMATSU_BANGO           CHAR(3),
    SHONIN_SYSTEM_HIZUKE            CHAR(8),
    SHONIN_KBN                      CHAR(1),
    DEMPYO_KBN                      CHAR(1),
    HAIFU_KBN                       CHAR(1),
    SHONIN_LEVEL                    CHAR(1),
    TORIHIKISAKI_KBN                CHAR(1),
    TORIHIKISAKI_CD                 CHAR(5),
    YOBI_BUNJI_1                    CHAR(1),
    YOBI_BUNJI_2                    CHAR(1),
    YOBI_BUNJI_3                    CHAR(1),
    YOBI_BUNJI_4                    CHAR(1),
    YOBI_BUNJI_5                    CHAR(1),
    YOBI_BUNJI_6                    CHAR(1),
    YOBI_BUNJI_7                    CHAR(1),
    YOBI_BUNJI_8                    CHAR(1),
    YOBI_SUJI_1                     NUMBER(1,0),
    YOBI_SUJI_2                     NUMBER(1,0),
    YOBI_SUJI_3                     NUMBER(1,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
DROP TABLE TR_RENKEI_MISHU_DATA CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_RENKEI_MISHU_DATA
(
    KAISHA_CD                       CHAR(5) NOT NULL,
    DEMPYO_HIZUKE                   CHAR(8) NOT NULL,
    DEMPYO_BANGO                    CHAR(6) NOT NULL,
    MEISAI_GYO_BANGO                NUMBER(3,0) NOT NULL,
    TAISHAKU_KBN                    CHAR(1) NOT NULL,
    KAMOKU_CD                       CHAR(4),
    HOJO_CD                         CHAR(2),
    BUMON_CD                        CHAR(3),
    KINO_CD_1                       CHAR(3),
    KINO_CD_2                       CHAR(1),
    KINO_CD_3                       CHAR(1),
    KINO_CD_4                       CHAR(1),
    SHIWAKE_KINGAKU                 NUMBER(10,0),
    ZEI_SHORI_CD                    CHAR(3),
    ZEI_NYURYOKU_KBN                CHAR(1),
    ZEI_GAKU                        NUMBER(1,0),
    GAIKA_CD                        CHAR(1),
    RATE_TYPE                       CHAR(1),
    KANSAN_RATE                     NUMBER(1,0),
    GAIKA_KINGAKU                   NUMBER(10,0),
    TEKIYO_1                        VARCHAR2(40),
    TEKIYO_2                        VARCHAR2(20),
    DEMPYO_G_CD                     CHAR(2),
    SYSTEM_KBN                      CHAR(2),
    TA_SYSTEM_DEMPYO_BANGO          CHAR(8),
    TA_SYSTEM__SYSTEM_KBN           CHAR(2),
    TA_SYSTEM_DEMPYO_G_CD           CHAR(2),
    AITE_KAMOKU_CD                  CHAR(4),
    AITE_HOJO_CD                    CHAR(2),
    NYURYOKU_USER_ID                CHAR(7),
    NYURYOKU_TAMMATSU_BANGO         CHAR(3),
    NYURYOKU_SYSTEM_HIZUKE          CHAR(8),
    SHONIN_USER_ID                  CHAR(7),
    SHONIN_TAMMATSU_BANGO           CHAR(3),
    SHONIN_SYSTEM_HIZUKE            CHAR(8),
    SHONIN_KBN                      CHAR(1),
    DEMPYO_KBN                      CHAR(1),
    HAIFU_KBN                       CHAR(1),
    SHONIN_LEVEL                    CHAR(1),
    TORIHIKISAKI_KBN                CHAR(1),
    TORIHIKISAKI_CD                 CHAR(5),
    YOBI_BUNJI_1                    CHAR(1),
    YOBI_BUNJI_2                    CHAR(1),
    YOBI_BUNJI_3                    CHAR(1),
    YOBI_BUNJI_4                    CHAR(1),
    YOBI_BUNJI_5                    CHAR(1),
    YOBI_BUNJI_6                    CHAR(1),
    YOBI_BUNJI_7                    CHAR(1),
    YOBI_BUNJI_8                    CHAR(1),
    YOBI_SUJI_1                     NUMBER(1,0),
    YOBI_SUJI_2                     NUMBER(1,0),
    YOBI_SUJI_3                     NUMBER(1,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
DROP TABLE TR_RENKEI_MISHU_DATA_BK CASCADE CONSTRAINTS PURGE
/
CREATE TABLE TR_RENKEI_MISHU_DATA_BK
(
    KAKUNO_HIZUKE                   CHAR(16) NOT NULL,
    KAISHA_CD                       CHAR(5) NOT NULL,
    DEMPYO_HIZUKE                   CHAR(8) NOT NULL,
    DEMPYO_BANGO                    CHAR(6) NOT NULL,
    MEISAI_GYO_BANGO                NUMBER(3,0) NOT NULL,
    TAISHAKU_KBN                    CHAR(1) NOT NULL,
    KAMOKU_CD                       CHAR(4),
    HOJO_CD                         CHAR(2),
    BUMON_CD                        CHAR(3),
    KINO_CD_1                       CHAR(3),
    KINO_CD_2                       CHAR(1),
    KINO_CD_3                       CHAR(1),
    KINO_CD_4                       CHAR(1),
    SHIWAKE_KINGAKU                 NUMBER(10,0),
    ZEI_SHORI_CD                    CHAR(3),
    ZEI_NYURYOKU_KBN                CHAR(1),
    ZEI_GAKU                        NUMBER(1,0),
    GAIKA_CD                        CHAR(1),
    RATE_TYPE                       CHAR(1),
    KANSAN_RATE                     NUMBER(1,0),
    GAIKA_KINGAKU                   NUMBER(10,0),
    TEKIYO_1                        VARCHAR2(40),
    TEKIYO_2                        VARCHAR2(20),
    DEMPYO_G_CD                     CHAR(2),
    SYSTEM_KBN                      CHAR(2),
    TA_SYSTEM_DEMPYO_BANGO          CHAR(8),
    TA_SYSTEM__SYSTEM_KBN           CHAR(2),
    TA_SYSTEM_DEMPYO_G_CD           CHAR(2),
    AITE_KAMOKU_CD                  CHAR(4),
    AITE_HOJO_CD                    CHAR(2),
    NYURYOKU_USER_ID                CHAR(7),
    NYURYOKU_TAMMATSU_BANGO         CHAR(3),
    NYURYOKU_SYSTEM_HIZUKE          CHAR(8),
    SHONIN_USER_ID                  CHAR(7),
    SHONIN_TAMMATSU_BANGO           CHAR(3),
    SHONIN_SYSTEM_HIZUKE            CHAR(8),
    SHONIN_KBN                      CHAR(1),
    DEMPYO_KBN                      CHAR(1),
    HAIFU_KBN                       CHAR(1),
    SHONIN_LEVEL                    CHAR(1),
    TORIHIKISAKI_KBN                CHAR(1),
    TORIHIKISAKI_CD                 CHAR(5),
    YOBI_BUNJI_1                    CHAR(1),
    YOBI_BUNJI_2                    CHAR(1),
    YOBI_BUNJI_3                    CHAR(1),
    YOBI_BUNJI_4                    CHAR(1),
    YOBI_BUNJI_5                    CHAR(1),
    YOBI_BUNJI_6                    CHAR(1),
    YOBI_BUNJI_7                    CHAR(1),
    YOBI_BUNJI_8                    CHAR(1),
    YOBI_SUJI_1                     NUMBER(1,0),
    YOBI_SUJI_2                     NUMBER(1,0),
    YOBI_SUJI_3                     NUMBER(1,0),
    SAKUJO_FLG                      CHAR(1) NOT NULL,
    TOROKU_USER                     VARCHAR2(8) NOT NULL,
    TOROKU_NICHIJI                  DATE NOT NULL,
    KOSHIN_USER                     VARCHAR2(8),
    KOSHIN_NICHIJI                  DATE,
    KOSHIN_COUNTER                  NUMBER(10,0) NOT NULL,
    TOROKU_TAMMATSU                 VARCHAR2(45),
    KOSHIN_TAMMATSU                 VARCHAR2(45),
    TOROKU_EIGYOSHO                 VARCHAR2(3),
    KOSHIN_EIGYOSHO                 VARCHAR2(3),
    SAISHU_OPERATION_USER           CHAR(7),
    SAISHU_OPERATION_KOSHIN_NICHIJI DATE
)
/
ALTER TABLE TR_SEIKYUSHO_FILE
    ADD(CONSTRAINT FK_SEIKYU_SEIKYUSHO_FILE FOREIGN KEY(SEIKYU_ID) REFERENCES TR_SEIKYU (SEIKYU_ID))
/
ALTER TABLE TR_SHINSEI_SHOSAI
    ADD(CONSTRAINT FK_SHINSEI_SHINSEI_SHOSAI FOREIGN KEY(SHINSEI_ID) REFERENCES TR_SHINSEI (SHINSEI_ID))
/
ALTER TABLE TR_MITSUMORI_SIM_DATA
    ADD(CONSTRAINT FK_MITSUMORI_SIM_MITSUMORI_SIM_DATA FOREIGN KEY(SIMULATION_ID) REFERENCES TR_MITSUMORI_SIM (SIMULATION_ID))
/
ALTER TABLE TR_MITSUMORI_SIM_KEKKA_RYOKINHYO_BUNSEKI
    ADD(CONSTRAINT FK_MITSUMORI_SIM_MITSUMORI_SIM_KEKKA_RYOKINHYO_BUNSEKI FOREIGN KEY(SIMULATION_ID) REFERENCES TR_MITSUMORI_SIM (SIMULATION_ID))
/
ALTER TABLE TR_MITSUMORI_SIM_KEKKA_MEISAI
    ADD(CONSTRAINT FK_MITSUMORI_SIM_MITSUMORI_SIM_KEKKA_MEISAI FOREIGN KEY(SIMULATION_ID) REFERENCES TR_MITSUMORI_SIM (SIMULATION_ID))
/
ALTER TABLE TR_MITSUMORI_SIM_KEKKA_SHUKEI
    ADD(CONSTRAINT FK_MITSUMORI_SIM_MITSUMORI_SIM_KEKKA_SHUKEI FOREIGN KEY(SIMULATION_ID) REFERENCES TR_MITSUMORI_SIM (SIMULATION_ID))
/
ALTER TABLE MS_CHOHYO_GROUP_ROLE
    ADD(CONSTRAINT FK_FK_CHOHYO_GROUP_CHOHYO_GROUP_ROLE FOREIGN KEY(CHOHYO_GROUP_ID, SAKUJO_FLG, TOROKU_USER) REFERENCES MS_CHOHYO_GROUP (CHOHYO_GROUP_ID, SAKUJO_FLG, TOROKU_USER))
/
ALTER TABLE TR_PACK_RYOKINHYO_RYOKIN
    ADD(CONSTRAINT FK_PACK_RYOKINHYO_CHIIKI_SETTEI_PACK_RYOKINHYO_RYOKIN FOREIGN KEY(RYOKINHYO_NO, UNCHIN_RANK, HOTCHI_CHAKU_CHIKU_KBN, KEIYAKU_ID) REFERENCES TR_PACK_RYOKINHYO_CHIIKI_SETTEI (RYOKINHYO_NO, UNCHIN_RANK, HOTCHI_CHAKU_CHIKU_KBN, KEIYAKU_ID))
/
ALTER TABLE TR_PACK_RYOKINHYO_CHIIKI_MEISAI
    ADD(CONSTRAINT FK_PACK_RYOKINHYO_CHIIKI_SETTEI_PACK_RYOKINHYO_CHIIKI_MEISAI FOREIGN KEY(RYOKINHYO_NO, UNCHIN_RANK, HOTCHI_CHAKU_CHIKU_KBN, KEIYAKU_ID) REFERENCES TR_PACK_RYOKINHYO_CHIIKI_SETTEI (RYOKINHYO_NO, UNCHIN_RANK, HOTCHI_CHAKU_CHIKU_KBN, KEIYAKU_ID))
/
ALTER TABLE TR_MITSUMORI_RIREKI
    ADD(CONSTRAINT FK_MITSUMORI_TEIAN_RIREKI_MITSUMORI_RIREKI FOREIGN KEY(MITSUMORI_TEIAN_NO, SIMULATION_ID) REFERENCES TR_MITSUMORI_TEIAN_RIREKI (MITSUMORI_TEIAN_NO, SIMULATION_ID))
/
ALTER TABLE TR_NORMAL_UNCHIN_MITSUMORI_RIREKI
    ADD(CONSTRAINT FK_MITSUMORI_NORMAL_UNCHIN_MITSUMORI_RIREKI FOREIGN KEY(MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID) REFERENCES TR_MITSUMORI_RIREKI (MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID))
/
ALTER TABLE TR_CHARTER_RYOKIN_MITSUMORI_RIREKI
    ADD(CONSTRAINT FK_MITSUMORI_CHARTER_RYOKIN_MITSUMORI_RIREKI FOREIGN KEY(MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID) REFERENCES TR_MITSUMORI_RIREKI (MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID))
/
ALTER TABLE TR_PACK_RYOKIN_MITSUMORI_RYOKIN_RIREKI
    ADD(CONSTRAINT FK_PACK_RYOKIN_MITSUMORI_CHIIKI_SETTEI_RIREKI_PACK_RYOKIN_MITSUMORI_RYOKIN_RIREKI FOREIGN KEY(SIMULATION_ID, MITSUMORI_TEIAN_NO, MITSUMORI_NO, UNCHIN_RANK, HOTCHI_CHAKU_CHIKU_KBN) REFERENCES TR_PACK_RYOKIN_MITSUMORI_CHIIKI_SETTEI_RIREKI (SIMULATION_ID, MITSUMORI_TEIAN_NO, MITSUMORI_NO, UNCHIN_RANK, HOTCHI_CHAKU_CHIKU_KBN))
/
ALTER TABLE TR_PACK_RYOKIN_MITSUMORI_CHIIKI_MEISAI_RIREKI
    ADD(CONSTRAINT FK_PACK_RYOKIN_MITSUMORI_CHIIKI_SETTEI_RIREKI_PACK_RYOKIN_MITSUMORI_CHIIKI_MEISAI_RIREKI_PACK_RYOKIN_MITSUMORI_CHIIKI_MEISAI_RIR FOREIGN KEY(SIMULATION_ID, MITSUMORI_TEIAN_NO, MITSUMORI_NO, UNCHIN_RANK, HOTCHI_CHAKU_CHIKU_KBN) REFERENCES TR_PACK_RYOKIN_MITSUMORI_CHIIKI_SETTEI_RIREKI (SIMULATION_ID, MITSUMORI_TEIAN_NO, MITSUMORI_NO, UNCHIN_RANK, HOTCHI_CHAKU_CHIKU_KBN))
/
ALTER TABLE TR_KOKYAKU_SHUKA_RYOKIN_MITSUMORI_JURYOTAI_RIREKI
    ADD(CONSTRAINT FK_NORMAL_UNCHIN_MITSUMORI_RIREKI_KOKYAKU_SHUKA_RYOKIN_MITSUMORI_JURYOTAI_RIREKI FOREIGN KEY(MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID) REFERENCES TR_NORMAL_UNCHIN_MITSUMORI_RIREKI (MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID))
/
ALTER TABLE TR_FUTAI_RYOKIN_MITSUMORI_RIREKI
    ADD(CONSTRAINT FK_MITSUMORI_FUTAI_RYOKIN_MITSUMORI_RIREKI FOREIGN KEY(MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID) REFERENCES TR_MITSUMORI_RIREKI (MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID))
/
ALTER TABLE TR_MITSUMORI_TEIAN_RIREKI
    ADD(CONSTRAINT FK_MITSUMORI_SIM_MITSUMORI_TEIAN_RIREKI FOREIGN KEY(SIMULATION_ID) REFERENCES TR_MITSUMORI_SIM (SIMULATION_ID))
/
ALTER TABLE TR_KYOTSU_SHINSEI_MEISAI
    ADD(CONSTRAINT FK_KYOTSU_SHINSEI_KOMOKU_KYOTSU_SHINSEI_MEISAI FOREIGN KEY(SHINSEI_SHUBETSU_CD) REFERENCES MS_KYOTSU_SHINSEI_KOMOKU (SHINSEI_SHUBETSU_CD))
/
ALTER TABLE TR_SEIKYU_RIREKI
    ADD(CONSTRAINT FK_SEIKYU_SEIKYU_RIREKI FOREIGN KEY(SEIKYU_ID) REFERENCES TR_SEIKYU (SEIKYU_ID))
/
ALTER TABLE TR_JIKKO_KEKKA_MAIL_SOSHINSAKI
    ADD(CONSTRAINT FK_MS_EDI_SETTEI_JIKKO_KEKKA_MAIL_SOSHINSAKI FOREIGN KEY(EDI_SETTEI_ID, TEKIYO_KAISHIBI) REFERENCES MS_EDI_SETTEI (EDI_SETTEI_ID, TEKIYO_KAISHIBI))
/
ALTER TABLE TR_KOKYAKU_ATE_MAIL_SETTEI
    ADD(CONSTRAINT FK_MS_EDI_SETTEI_KOKYAKU_ATE_MAIL_SETTEI FOREIGN KEY(EDI_SETTEI_ID, TEKIYO_KAISHIBI) REFERENCES MS_EDI_SETTEI (EDI_SETTEI_ID, TEKIYO_KAISHIBI))
/
ALTER TABLE TR_KOKYAKU_ATE_MAIL_SOSHINSAKI
    ADD(CONSTRAINT FK_KOKYAKU_ATE_MAIL_SETTEI_KOKYAKU_ATE_MAIL_SOSHINSAKI FOREIGN KEY(EDI_SETTEI_ID, TEKIYO_KAISHIBI) REFERENCES TR_KOKYAKU_ATE_MAIL_SETTEI (EDI_SETTEI_ID, TEKIYO_KAISHIBI))
/
ALTER TABLE TR_SEIKYU_JOHO_SETTEI_JIKKO_TIMMING
    ADD(CONSTRAINT FK_SEIKYU_JOHO_SETTEI_SEIKYU_JOHO_SETTEI_JIKKO_TIMING FOREIGN KEY(EDI_SETTEI_ID, TEKIYO_KAISHIBI) REFERENCES TR_SEIKYU_JOHO_SETTEI (EDI_SETTEI_ID, TEKIYO_KAISHIBI))
/
ALTER TABLE TR_TRACE_SETTEI_JIKKO_TIMMING
    ADD(CONSTRAINT FK_TRACE_SETTEI_TRACE_SETTEI_JIKKO_TIMING FOREIGN KEY(EDI_SETTEI_ID, TEKIYO_KAISHIBI) REFERENCES TR_TRACE_SETTEI (EDI_SETTEI_ID, TEKIYO_KAISHIBI))
/
ALTER TABLE TR_TRACE_SETTEI
    ADD(CONSTRAINT FK_MS_EDI_SETTEI_TRACE_SETTEI FOREIGN KEY(EDI_SETTEI_ID, TEKIYO_KAISHIBI) REFERENCES MS_EDI_SETTEI (EDI_SETTEI_ID, TEKIYO_KAISHIBI))
/
ALTER TABLE TR_SEIKYU_JOHO_SETTEI
    ADD(CONSTRAINT FK_MS_EDI_SETTEI_SEIKYU_JOHO_SETTEI FOREIGN KEY(EDI_SETTEI_ID, TEKIYO_KAISHIBI) REFERENCES MS_EDI_SETTEI (EDI_SETTEI_ID, TEKIYO_KAISHIBI))
/
ALTER TABLE MS_SYSTEM_IF_SHUBETSU
    ADD(CONSTRAINT FK_MS_SYSTEM_MEISHO_ENTITY_16 FOREIGN KEY(SYSTEM_MEISHO_CD) REFERENCES MS_SYSTEM_MEISHO (SYSTEM_MEISHO_CD))
/
ALTER TABLE MS_JUSHO
    ADD(CONSTRAINT FK_JUSHO_JIS_JUSHO FOREIGN KEY(JIS_CD, TEKIYO_KAISHIBI) REFERENCES MS_JUSHO_JIS (JIS_CD, TEKIYO_KAISHIBI))
/
ALTER TABLE MS_JUSHO_RITO
    ADD(CONSTRAINT FK_JUSHO_MS_JUSHO_RITO FOREIGN KEY(JIS_CD, TEKIYO_KAISHIBI) REFERENCES MS_JUSHO_JIS (JIS_CD, TEKIYO_KAISHIBI))
/
ALTER TABLE MS_SHIMUKE_CHI_HENKAN_JOHO
    ADD(CONSTRAINT FK_JUSHO_MS_SHIMUKECHI_HENKAN_JOHO FOREIGN KEY(JIS_CD, TEKIYO_KAISHIBI) REFERENCES MS_JUSHO_JIS (JIS_CD, TEKIYO_KAISHIBI))
/
ALTER TABLE MS_JIS_HENKAN_JOHO
    ADD(CONSTRAINT FK_JUSHO_MS_JIS_HENKAN_JOHO FOREIGN KEY(JIS_CD, TEKIYO_KAISHIBI) REFERENCES MS_JUSHO_JIS (JIS_CD, TEKIYO_KAISHIBI))
/
ALTER TABLE MS_JUSHO_KANNAIHAISO
    ADD(CONSTRAINT FK_JUSHO_MS_JUSHO_KANNAI_HAISO FOREIGN KEY(JIS_CD, TEKIYO_KAISHIBI) REFERENCES MS_JUSHO_JIS (JIS_CD, TEKIYO_KAISHIBI))
/
ALTER TABLE MS_SHISETSU_HYOJI_MEI_JOHO
    ADD(CONSTRAINT FK_MS_JUSHO_KANNAI_HAISO_MS_SHISETSU_HYOJIMEI_JOHO FOREIGN KEY(JIS_CD, TEKIYO_KAISHIBI, JUSHO_KANNAIHAISO_SEQ) REFERENCES MS_JUSHO_KANNAIHAISO (JIS_CD, TEKIYO_KAISHIBI, JUSHO_KANNAIHAISO_SEQ))
/
ALTER TABLE MS_DAIRITEN_OKURIJO_NO
    ADD(CONSTRAINT FK_MS_DAIRITEN_DAIRITEN_OKURIJO_NO FOREIGN KEY(DAIRITEN_CD, TEKIYO_KAISHIBI) REFERENCES MS_DAIRITEN (DAIRITEN_CD, TEKIYO_KAISHIBI))
/
ALTER TABLE MS_ROLE_KINO_GROUP_PATTERN
    ADD(CONSTRAINT FK_ROLE_ROLE_KINO_GROUP_PATTERN FOREIGN KEY(ROLE_CD) REFERENCES MS_ROLE (ROLE_CD))
/
ALTER TABLE TR_SEIKYU_TAISHO_HAITA
    ADD(CONSTRAINT FK_SEIKYU_SEIKYU_TAISHO_HAITA FOREIGN KEY(SEIKYU_ID) REFERENCES TR_SEIKYU (SEIKYU_ID))
/
ALTER TABLE MS_UPLOAD_FILE_TEIGI
    ADD(CONSTRAINT FK_MS_KINO_MEISHO_MS_UPLOAD_FILE_TEIGI FOREIGN KEY(UPLOAD_KINO_CD) REFERENCES MS_UPLOAD_KINO (UPLOAD_KINO_CD))
/
ALTER TABLE TR_SEIKYU_MEISAI_SONOTA_SEIKYU_RIREKI
    ADD(CONSTRAINT FK_SEIKYU_RIREKI_SEIKYU_MEISAI_SONOTA_SEIKYU_RIREKI FOREIGN KEY(SEIKYU_ID, SEIKYUSHO_EDABAN) REFERENCES TR_SEIKYU_RIREKI (SEIKYU_ID, SEIKYUSHO_EDABAN))
/
ALTER TABLE TR_SEIKYU_MEISAI_LOGI_URIAGE_RIREKI
    ADD(CONSTRAINT FK_SEIKYU_RIREKI_SEIKYU_MEISAI_LOGI_URIAGE_RIREKI FOREIGN KEY(SEIKYU_ID, SEIKYUSHO_EDABAN) REFERENCES TR_SEIKYU_RIREKI (SEIKYU_ID, SEIKYUSHO_EDABAN))
/
ALTER TABLE MS_USER_ROLE
    ADD(CONSTRAINT FK_ROLE_USER_ROLE FOREIGN KEY(ROLE_CD) REFERENCES MS_ROLE (ROLE_CD))
/
ALTER TABLE MS_KINO_GROUP_PATTERN_RIYO_KANO_KINO
    ADD(CONSTRAINT FK_KINO_KINO_GROUP_RIYO_KANO_KINO FOREIGN KEY(KINO_CD) REFERENCES MS_KINO (KINO_CD))
/
ALTER TABLE MS_KINO
    ADD(CONSTRAINT FK_KINO_KINO FOREIGN KEY(OYA_KINO_CD) REFERENCES MS_KINO (KINO_CD))
/
ALTER TABLE TR_JOTAI_HOZON_MEISAI
    ADD(CONSTRAINT FK_JOTAI_HOZON_JOTAI_HOZON_MEISAI FOREIGN KEY(EIGYOSHO_CD, USER_CD, GAMEN_CD, JOTAI_ID) REFERENCES TR_JOTAI_HOZON (EIGYOSHO_CD, USER_CD, GAMEN_CD, JOTAI_ID))
/
ALTER TABLE MS_MENU
    ADD(CONSTRAINT FK_KINO_MENU FOREIGN KEY(KINO_CD) REFERENCES MS_KINO (KINO_CD))
/
ALTER TABLE TR_JOKYO_KANRI_SHOSAI_UPLOAD
    ADD(CONSTRAINT FK_JOKYO_KANRI_JOKYO_KANRI_SHOSAI_UPLOAD FOREIGN KEY(EDI_SETTEI_ID, JIKKO_KAISHI_NICHIJI, JOKYO_KANRI_SEQ) REFERENCES TR_JOKYO_KANRI (EDI_SETTEI_ID, JIKKO_KAISHI_NICHIJI, JOKYO_KANRI_SEQ))
/
ALTER TABLE TR_KYOTSU_SHINSEI
    ADD(CONSTRAINT FK_SHINSEI_KYOTSU_SHINSEI FOREIGN KEY(SHINSEI_ID) REFERENCES TR_SHINSEI (SHINSEI_ID))
/
ALTER TABLE TR_KYOTSU_SHINSEI_MEISAI
    ADD(CONSTRAINT FK_KYOTSU_SHINSEI_KYOTSU_SHINSEI_MEISAI FOREIGN KEY(SHINSEI_ID) REFERENCES TR_KYOTSU_SHINSEI (SHINSEI_ID))
/
ALTER TABLE TR_OKYAKUSAMA_KANRI_NO_MEISAI_RIREKI
    ADD(CONSTRAINT FK_YUSO_URIAGE_RIREKI_OKYAKUSAMA_KANRI_NO_MEISAI_RIREKI FOREIGN KEY(URIAGE_ID, URIAGE_DATA_VERSION) REFERENCES TR_YUSO_URIAGE_RIREKI (URIAGE_ID, YUSO_URIAGE_DATA_VERSION))
/
ALTER TABLE TR_OROSHI_BUMPAI_KEKKA_RIREKI
    ADD(CONSTRAINT FK_YUSO_URIAGE_RIREKI_OROSHI_BUNPAI_KEKKA_RIREKI FOREIGN KEY(URIAGE_ID, URIAGE_DATA_VERSION) REFERENCES TR_YUSO_URIAGE_RIREKI (URIAGE_ID, YUSO_URIAGE_DATA_VERSION))
/
ALTER TABLE TR_CHARTER_URINE_MEISAI_RIREKI
    ADD(CONSTRAINT FK_YUSO_URIAGE_RIREKI_CHARTER_URINE_MEISAI_RIREKI FOREIGN KEY(URIAGE_ID, URIAGE_DATA_VERSION) REFERENCES TR_YUSO_URIAGE_RIREKI (URIAGE_ID, YUSO_URIAGE_DATA_VERSION))
/
ALTER TABLE TR_YUSO_URIAGE_MEISAI_RIREKI
    ADD(CONSTRAINT FK_YUSO_URIAGE_RIREKI_YUSO_URIAGE_MEISAI_RIREKI FOREIGN KEY(URIAGE_ID, URIAGE_DATA_VERSION) REFERENCES TR_YUSO_URIAGE_RIREKI (URIAGE_ID, YUSO_URIAGE_DATA_VERSION))
/
ALTER TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_CHIIKI_SETTEI
    ADD(CONSTRAINT FK_MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_ENTITY_332 FOREIGN KEY(EIGYOSHO_CD, SHIIRESAKI_CD, DEMPYO_SHUBETSU_CD, TEKIYO_KAISHIBI) REFERENCES MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO (EIGYOSHO_CD, SHIIRESAKI_CD, DEMPYO_SHUBETSU_CD, TEKIYO_KAISHIBI))
/
ALTER TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_CHIIKI_MEISAI
    ADD(CONSTRAINT FK_MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_CHIIKI_SETTEI_ENTITY_333 FOREIGN KEY(EIGYOSHO_CD, SHIIRESAKI_CD, DEMPYO_SHUBETSU_CD, TEKIYO_KAISHIBI, KITEN_CHIIKI_CD, UNCHIN_RANK) REFERENCES MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_CHIIKI_SETTEI (EIGYOSHO_CD, SHIIRESAKI_CD, DEMPYO_SHUBETSU_CD, TEKIYO_KAISHIBI, KITEN_CHIIKI_CD, UNCHIN_RANK))
/
ALTER TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_TATENE
    ADD(CONSTRAINT FK_MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_ENTITY_334 FOREIGN KEY(EIGYOSHO_CD, SHIIRESAKI_CD, DEMPYO_SHUBETSU_CD, TEKIYO_KAISHIBI) REFERENCES MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO (EIGYOSHO_CD, SHIIRESAKI_CD, DEMPYO_SHUBETSU_CD, TEKIYO_KAISHIBI))
/
ALTER TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_KINGAKU
    ADD(CONSTRAINT FK_MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_CHIIKI_SETTEI_DAIRITEN_CHUKEI_HAITATSU_RYOKIN FOREIGN KEY(EIGYOSHO_CD, SHIIRESAKI_CD, DEMPYO_SHUBETSU_CD, TEKIYO_KAISHIBI, KITEN_CHIIKI_CD, UNCHIN_RANK) REFERENCES MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_CHIIKI_SETTEI (EIGYOSHO_CD, SHIIRESAKI_CD, DEMPYO_SHUBETSU_CD, TEKIYO_KAISHIBI, KITEN_CHIIKI_CD, UNCHIN_RANK))
/
ALTER TABLE MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_KINGAKU
    ADD(CONSTRAINT FK_MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_TATENE_MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO FOREIGN KEY(EIGYOSHO_CD, SHIIRESAKI_CD, DEMPYO_SHUBETSU_CD, TEKIYO_KAISHIBI, TATENE_NO) REFERENCES MS_DAIRITEN_CHUKEI_HAITATSU_RYOKINHYO_TATENE (EIGYOSHO_CD, SHIIRESAKI_CD, DEMPYO_SHUBETSU_CD, TEKIYO_KAISHIBI, TATENE_NO))
/
ALTER TABLE TR_YUSO_SHIIRE_MEISAI_RIREKI
    ADD(CONSTRAINT FK_YUSO_URIAGE_RIREKI_YUSO_SHIIRE_MEISAI_RIREKI FOREIGN KEY(URIAGE_ID, URIAGE_DATA_VERSION) REFERENCES TR_YUSO_URIAGE_RIREKI (URIAGE_ID, YUSO_URIAGE_DATA_VERSION))
/
ALTER TABLE MS_DAIRITEN_SHIMEBI_SHIHARAI_SITE
    ADD(CONSTRAINT FK_MS_DAIRITEN_MS_DAIRITEN_SHIMEBI_BARAI_SITE FOREIGN KEY(DAIRITEN_CD, TEKIYO_KAISHIBI) REFERENCES MS_DAIRITEN (DAIRITEN_CD, TEKIYO_KAISHIBI))
/
ALTER TABLE MS_KINO_GROUP
    ADD(CONSTRAINT FK_KINO_GROUP_SHUBETSU_KINO_GROUP FOREIGN KEY(KINO_GROUP_SHUBETSU_CD) REFERENCES MS_KINO_GROUP_SHUBETSU (KINO_GROUP_SHUBETSU_CD))
/
ALTER TABLE TR_PACK_RYOKIN_MITSUMORI_RIREKI
    ADD(CONSTRAINT FK_MITSUMORI_RIREKI_PACK_RYOKIN_MITSUMORI_RIREKI FOREIGN KEY(MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID) REFERENCES TR_MITSUMORI_RIREKI (MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID))
/
ALTER TABLE TR_FUTAI_RYOKIN_MITSUMORI_NEBIKI_KOMOKU_RIREKI
    ADD(CONSTRAINT FK_MITSUMORI_RIREKI_FUTAI_RYOKIN_MITSUMORI_NEBIKI_KOMOKU_RIREKI FOREIGN KEY(MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID) REFERENCES TR_MITSUMORI_RIREKI (MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID))
/
ALTER TABLE MS_KOKYAKU
    ADD(CONSTRAINT FK_HOJIN_BANGO_KOKYAKU FOREIGN KEY(HOJIN_BANGO) REFERENCES MS_HOJIN_BANGO (HOJIN_BANGO))
/
ALTER TABLE MS_KOKYAKU_MEMO
    ADD(CONSTRAINT FK_KOKYAKU_KOKYAKU_MEMO FOREIGN KEY(KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG) REFERENCES MS_KOKYAKU (KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG))
/
ALTER TABLE MS_KOKYAKU_KANREN_FILE
    ADD(CONSTRAINT FK_KOKYAKU_KOKYAKU_KANREN_FILE FOREIGN KEY(KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG) REFERENCES MS_KOKYAKU (KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG))
/
ALTER TABLE MS_KOKYAKU_MEMO_FILE
    ADD(CONSTRAINT FK_KOKYAKU_MEMO_KOKYAKU_MEMO_FILE FOREIGN KEY(KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG, MEMO_MEISAI_ID) REFERENCES MS_KOKYAKU_MEMO (KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG, MEMO_MEISAI_ID))
/
ALTER TABLE MS_HOJIN_GROUP_SETTEI
    ADD(CONSTRAINT FK_HOJIN_GROUP_HOJIN_GROUP_SETTEI FOREIGN KEY(HOJIN_GROUP_CD) REFERENCES MS_HOJIN_GROUP (HOJIN_GROUP_CD))
/
ALTER TABLE MS_HOJIN_GROUP_SETTEI
    ADD(CONSTRAINT FK_HOJIN_BANGO_HOJIN_GROUP_SETTEI FOREIGN KEY(HOJIN_BANGO) REFERENCES MS_HOJIN_BANGO (HOJIN_BANGO))
/
ALTER TABLE MS_KOKYAKU_BETSU_RIYO_KANO_DEMPYO_SHUBETSU
    ADD(CONSTRAINT FK_KOKYAKU_KOKYAKU_BETSU_RIYO_KANO_DEMPYO_SHUBETSU FOREIGN KEY(KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG) REFERENCES MS_KOKYAKU (KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG))
/
ALTER TABLE MS_RYOKIN_KOMOKU
    ADD(CONSTRAINT FK_MS_RYOKIN_KOMOKU_GROUP_MS_RYOKIN_KOMOKU FOREIGN KEY(RYOKIN_KOMOKU_GROUP_CD) REFERENCES MS_RYOKIN_KOMOKU_GROUP (RYOKIN_KOMOKU_GROUP_CD))
/
ALTER TABLE TR_JOKYO_KANRI_SHOSAI
    ADD(CONSTRAINT FK_JOKYO_KANRI_TABLE_JOKYO_KANRI_SHOSAI_TABLE FOREIGN KEY(EDI_SETTEI_ID, JIKKO_KAISHI_NICHIJI, JOKYO_KANRI_SEQ) REFERENCES TR_JOKYO_KANRI (EDI_SETTEI_ID, JIKKO_KAISHI_NICHIJI, JOKYO_KANRI_SEQ))
/
ALTER TABLE MS_USER_ROLE
    ADD(CONSTRAINT FK_USER_USER_ROLE FOREIGN KEY(USER_CD, TEKIYO_KAISHIBI, TEKIYO_FLG) REFERENCES MS_USER (USER_CD, TEKIYO_KAISHIBI, TEKIYO_FLG))
/
ALTER TABLE TR_PASSWORD_SHOKIKA_SHINSEI_SHOSAI
    ADD(CONSTRAINT FK_SHINSEI_PASSWORD_SHOKIKA_SHINSEI_SHOSAI FOREIGN KEY(SHINSEI_ID) REFERENCES TR_SHINSEI (SHINSEI_ID))
/
ALTER TABLE MS_MESSAGE_SOSHINSAKI
    ADD(CONSTRAINT FK_MS_MESSAGE_MESSAGE_HAISHINSAKI_MS_USER FOREIGN KEY(MESSAGE_ID) REFERENCES MS_MESSAGE (MESSAGE_ID))
/
ALTER TABLE MS_KOKYAKU_SHUYAKU_SETTEI
    ADD(CONSTRAINT FK_SHUYAKU_CD_KOKYAKU_SHUYAKU_SETTEI FOREIGN KEY(SHUYAKU_CD, SHUYAKU_KBN, EIGYOSHO_CD) REFERENCES MS_SHUYAKU_CD (SHUYAKU_CD, SHUYAKU_KBN, EIGYOSHO_CD))
/
ALTER TABLE TR_SEIKYU_MEISAI_SONOTA_SEIKYU
    ADD(CONSTRAINT FK_SEIKYU_SEIKYU_MEISAI_SONOTA_SEIKYU FOREIGN KEY(SEIKYU_ID) REFERENCES TR_SEIKYU (SEIKYU_ID))
/
ALTER TABLE TR_PACK_RYOKIN_MITSUMORI_TATENE_RIREKI
    ADD(CONSTRAINT FK_FK_PACK_RYOKIN_MITSUMORI_RIREKI_PACK_RYOKIN_MITSUMORI_TATENE_RIREKI FOREIGN KEY(MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID) REFERENCES TR_PACK_RYOKIN_MITSUMORI_RIREKI (MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID))
/
ALTER TABLE TR_EDI_KOKYAKU_JOHO_SETTEI
    ADD(CONSTRAINT FK_MS_EDI_SETTEI_TR_EDI_KOKYAKU_JOHO_SETTEI FOREIGN KEY(EDI_SETTEI_ID, TEKIYO_KAISHIBI) REFERENCES MS_EDI_SETTEI (EDI_SETTEI_ID, TEKIYO_KAISHIBI))
/
ALTER TABLE TT_JOKYO_KANRI_SHOSAI_BATCH
    ADD(CONSTRAINT FK_TT_JOKYO_KANRI_BATCH_TT_JOKYO_KANRI_SHOSAI_BATCH FOREIGN KEY(JIKKO_KAISHI_NICHIJI, JOKYO_KANRI_SEQ) REFERENCES TT_JOKYO_KANRI_BATCH (JIKKO_KAISHI_NICHIJI, JOKYO_KANRI_SEQ))
/
ALTER TABLE MS_MESSAGE_SOSHINJOGAI
    ADD(CONSTRAINT FK_MS_MESSAGE_MS_MESSAGE_SOSHINJOGAI FOREIGN KEY(MESSAGE_ID) REFERENCES MS_MESSAGE (MESSAGE_ID))
/
ALTER TABLE MS_PRINTER_TRAY
    ADD(CONSTRAINT FK_MS_PRINTER_MS_PRINTER_TRAY FOREIGN KEY(PRINTER_ID, SAKUJO_FLG) REFERENCES MS_PRINTER (PRINTER_ID, SAKUJO_FLG))
/
ALTER TABLE MS_KOKYAKU
    ADD(CONSTRAINT FK_MS_YUSO_SEIKYUSHO_RYOKIN_PTN_MS_KOKYAKU FOREIGN KEY(YUSO_SEIKYUSHO_RYOKIN_PTN, TEKIYO_KAISHIBI, TEKIYO_FLG) REFERENCES MS_YUSO_SEIKYUSHO_RYOKIN_PTN (YUSO_SEIKYUSHO_RYOKIN_PTN, TEKIYO_KAISHIBI, TEKIYO_FLG))
/
ALTER TABLE MS_KINO_GROUP_PATTERN
    ADD(CONSTRAINT FK_MS_KINO_GROUP_MS_KINO_GROUP_PATTERN FOREIGN KEY(KINO_GROUP_CD) REFERENCES MS_KINO_GROUP (KINO_GROUP_CD))
/
ALTER TABLE MS_USER_KINO_GROUP_PATTERN
    ADD(CONSTRAINT FK_MS_KINO_GROUP_PATTERN_MS_USER_KINO_GROUP FOREIGN KEY(KINO_GROUP_PATTERN_CD) REFERENCES MS_KINO_GROUP_PATTERN (KINO_GROUP_PATTERN_CD))
/
ALTER TABLE MS_ROLE_KINO_GROUP_PATTERN
    ADD(CONSTRAINT FK_MS_KINO_GROUP_PATTERN_MS_ROLE_KINO_GROUP FOREIGN KEY(KINO_GROUP_PATTERN_CD) REFERENCES MS_KINO_GROUP_PATTERN (KINO_GROUP_PATTERN_CD))
/
ALTER TABLE MS_KINO_GROUP_PATTERN_RIYO_KANO_KINO
    ADD(CONSTRAINT FK_MS_KINO_GROUP_PATTERN_MS_KINO_GROUP_RIYO_KANO_KINO FOREIGN KEY(KINO_GROUP_PATTERN_CD) REFERENCES MS_KINO_GROUP_PATTERN (KINO_GROUP_PATTERN_CD))
/
ALTER TABLE MS_MENU_GROUP_HYOJI_JUN
    ADD(CONSTRAINT FK_MS_MENU_PATTERN_MS_MENU_GROUP_HYOJI_JUN FOREIGN KEY(MENU_PATTERN_ID) REFERENCES MS_MENU_PATTERN (MENU_PATTERN_ID))
/
ALTER TABLE MS_MENU_GROUP_HYOJI_JUN
    ADD(CONSTRAINT FK_MS_MENU_GROUP_MS_MENU_GROUP_HYOJI_JUN FOREIGN KEY(MENU_GROUP_ID) REFERENCES MS_MENU_GROUP (MENU_GROUP_ID))
/
ALTER TABLE MS_SUB_MENU_GROUP_HYOJI_JUN
    ADD(CONSTRAINT FK_MS_SUB_MENU_GROUP_MS_SUB_MENU_GROUP_HYOJI_JUN FOREIGN KEY(SUB_MENU_GROUP_ID) REFERENCES MS_SUB_MENU_GROUP (SUB_MENU_GROUP_ID))
/
ALTER TABLE MS_MENU_HYOJI_JUN
    ADD(CONSTRAINT FK_MS_MENU_MS_MENU_HYOJI_JUN FOREIGN KEY(MENU_ID) REFERENCES MS_MENU (MENU_ID))
/
ALTER TABLE MS_MENU_HYOJI_JUN
    ADD(CONSTRAINT FK_MS_SUB_MENU_GROUP_HYOJI_JUN_MS_MENU_HYOJI_JUN FOREIGN KEY(SUB_MENU_GROUP_ID, MENU_PATTERN_ID) REFERENCES MS_SUB_MENU_GROUP_HYOJI_JUN (SUB_MENU_GROUP_ID, MENU_PATTERN_ID))
/
ALTER TABLE TR_USER_SETTEI
    ADD(CONSTRAINT FK_MS_MENU_PATTERN_TR_USER_SETTEI FOREIGN KEY(MENU_PATTERN_ID) REFERENCES MS_MENU_PATTERN (MENU_PATTERN_ID))
/
ALTER TABLE MS_SUB_MENU_GROUP_HYOJI_JUN
    ADD(CONSTRAINT FK_MS_MENU_GROUP_HYOJI_JUN_MS_SUB_MENU_GROUP_HYOJI_JUN FOREIGN KEY(MENU_PATTERN_ID, MENU_GROUP_ID) REFERENCES MS_MENU_GROUP_HYOJI_JUN (MENU_PATTERN_ID, MENU_GROUP_ID))
/
ALTER TABLE MS_SHINSEI_PROCESS_ACTIVITY_TEIGI
    ADD(CONSTRAINT FK_MS_SHINSEI_PROCESS_TEIGI_MS_SHINSEI_PROCESS_ACTIVITY_TEIGI FOREIGN KEY(TEKIYO_KAISHIBI, SHINSEI_SHUBETSU_CD) REFERENCES MS_SHINSEI_PROCESS_TEIGI (TEKIYO_KAISHIBI, SHINSEI_SHUBETSU_CD))
/
ALTER TABLE TR_CHARTER_RYOKIN_YUSORYO_KYORI_MITSUMORI_RIREKI
    ADD(CONSTRAINT FK_TR_CHARTER_RYOKIN_MITSUMORI_RIREKI_TR_CHARTER_RYOKIN_YUSORYO_KYORI_MITSUMORI_RIREKI FOREIGN KEY(MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID) REFERENCES TR_CHARTER_RYOKIN_MITSUMORI_RIREKI (MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID))
/
ALTER TABLE TR_CHARTER_RYOKIN_YUSORYO_MITSUMORI_RIREKI
    ADD(CONSTRAINT FK_TR_CHARTER_RYOKIN_YUSORYO_KYORI_MITSUMORI_RIREKI_TR_CHARTER_RYOKIN_YUSORYO_MITSUMORI_RIREKI FOREIGN KEY(SIMULATION_ID, MITSUMORI_TEIAN_NO, MITSUMORI_NO, MEISAI_GYO_NO) REFERENCES TR_CHARTER_RYOKIN_YUSORYO_KYORI_MITSUMORI_RIREKI (SIMULATION_ID, MITSUMORI_TEIAN_NO, MITSUMORI_NO, MEISAI_GYO_NO))
/
ALTER TABLE TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_JIKANTAI_MITSUMORI_RIREKI
    ADD(CONSTRAINT FK_TR_CHARTER_RYOKIN_MITSUMORI_RIREKI_TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_JIKANTAI_MITSUMORI_RIREKI FOREIGN KEY(MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID) REFERENCES TR_CHARTER_RYOKIN_MITSUMORI_RIREKI (MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID))
/
ALTER TABLE TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_MITSUMORI_RIREKI
    ADD(CONSTRAINT FK_TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_JIKANTAI_MITSUMORI_RIREKI_TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_MITSUMORI_RIREKI FOREIGN KEY(SIMULATION_ID, MITSUMORI_TEIAN_NO, MITSUMORI_NO, MEISAI_GYO_NO) REFERENCES TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_JIKANTAI_MITSUMORI_RIREKI (SIMULATION_ID, MITSUMORI_TEIAN_NO, MITSUMORI_NO, MEISAI_GYO_NO))
/
ALTER TABLE TR_CHARTER_RYOKIN_SHASHUBETSU_WARIMASHI_MITSUMORI_RIREKI
    ADD(CONSTRAINT FK_TR_CHARTER_RYOKIN_MITSUMORI_RIREKI_TR_CHARTER_RYOKIN_SHASHUBETSU_WARIMASHI_MITSUMORI_RIREKI FOREIGN KEY(MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID) REFERENCES TR_CHARTER_RYOKIN_MITSUMORI_RIREKI (MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID))
/
ALTER TABLE TR_CHARTER_FUTAI_RYOKIN_MITSUMORI_RIREKI
    ADD(CONSTRAINT FK_TR_CHARTER_RYOKIN_MITSUMORI_RIREKI_TR_CHARTER_FUTAI_RYOKIN_MITSUMORI_RIREKI FOREIGN KEY(MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID) REFERENCES TR_CHARTER_RYOKIN_MITSUMORI_RIREKI (MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID))
/
ALTER TABLE TR_PACK_RYOKINHYO_CHIIKI_SETTEI
    ADD(CONSTRAINT FK_TR_PACK_RYOKINHYO_TR_PACK_RYOKINHYO_CHIIKI_SETTEI FOREIGN KEY(RYOKINHYO_NO, KEIYAKU_ID) REFERENCES TR_PACK_RYOKINHYO (RYOKINHYO_NO, KEIYAKU_ID))
/
ALTER TABLE TR_PACK_RYOKIN_MITSUMORI_CHIIKI_SETTEI_RIREKI
    ADD(CONSTRAINT FK_TR_PACK_RYOKIN_MITSUMORI_RIREKI_TR_PACK_RYOKIN_MITSUMORI_CHIIKI_SETTEI_RIREKI FOREIGN KEY(MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID) REFERENCES TR_PACK_RYOKIN_MITSUMORI_RIREKI (MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID))
/
ALTER TABLE MS_EIGYOSHO_OROSHI_TANKA
    ADD(CONSTRAINT FK_MS_EIGYOSHO_MS_EIGYOSHO_OROSHI_TANKA FOREIGN KEY(EIGYOSHO_CD, TEKIYO_KAISHIBI) REFERENCES MS_EIGYOSHO (EIGYOSHO_CD, TEKIYO_KAISHIBI))
/
ALTER TABLE TR_MITSUMORI_SIM_IRAI
    ADD(CONSTRAINT FK_TR_MITSUMORI_SIM_TR_MITSUMORI_SIM_IRAI FOREIGN KEY(SIMULATION_ID) REFERENCES TR_MITSUMORI_SIM (SIMULATION_ID))
/
ALTER TABLE TR_CHARTER_URINE_MEISAI
    ADD(CONSTRAINT FK_TR_YUSO_URIAGE_TR_CHARTER_URINE_MEISAI FOREIGN KEY(URIAGE_ID, URIAGE_DATA_VERSION, AKA_KURO_KBN) REFERENCES TR_YUSO_URIAGE (URIAGE_ID, URIAGE_DATA_VERSION, AKA_KURO_KBN))
/
ALTER TABLE TR_YUSO_URIAGE_FUTAI_RYOKIN_RIREKI
    ADD(CONSTRAINT FK_TR_YUSO_URIAGE_RIREKI_TR_YUSO_URIAGE_FUTAI_RYOKIN_RIREKI FOREIGN KEY(URIAGE_ID, YUSO_URIAGE_DATA_VERSION) REFERENCES TR_YUSO_URIAGE_RIREKI (URIAGE_ID, YUSO_URIAGE_DATA_VERSION))
/
ALTER TABLE TR_OROSHINE
    ADD(CONSTRAINT FK_TR_YUSO_URIAGE_TR_OROSHINE FOREIGN KEY(URIAGE_ID, URIAGE_DATA_VERSION, AKA_KURO_KBN) REFERENCES TR_YUSO_URIAGE (URIAGE_ID, URIAGE_DATA_VERSION, AKA_KURO_KBN))
/
ALTER TABLE TR_OROSHINE_RIREKI
    ADD(CONSTRAINT FK_MS_OROSHI_KOMOKU_TR_OROSHINE_RIREKI FOREIGN KEY(OROSHI_KOMOKU_CD) REFERENCES MS_OROSHI_KOMOKU (OROSHI_KOMOKU_CD))
/
ALTER TABLE TR_OROSHINE
    ADD(CONSTRAINT FK_MS_OROSHI_KOMOKU_TR_OROSHINE FOREIGN KEY(OROSHI_KOMOKU_CD) REFERENCES MS_OROSHI_KOMOKU (OROSHI_KOMOKU_CD))
/
ALTER TABLE TR_YUSO_URIAGE_FUTAI_RYOKIN
    ADD(CONSTRAINT FK_TR_YUSO_URIAGE_TR_YUSO_URIAGE_FUTAI_RYOKIN FOREIGN KEY(URIAGE_ID, URIAGE_DATA_VERSION, AKA_KURO_KBN) REFERENCES TR_YUSO_URIAGE (URIAGE_ID, URIAGE_DATA_VERSION, AKA_KURO_KBN))
/
ALTER TABLE TR_SEIKYU_MEISAI
    ADD(CONSTRAINT FK_TR_SEIKYU_TR_SEIKYU_MEISAI FOREIGN KEY(SEIKYU_ID) REFERENCES TR_SEIKYU (SEIKYU_ID))
/
ALTER TABLE TR_SHIME_SHORI_RIREKI
    ADD(CONSTRAINT FK_TR_SEIKYU_TR_SHIME_SHORI_RIREKI FOREIGN KEY(SEIKYU_ID) REFERENCES TR_SEIKYU (SEIKYU_ID))
/
ALTER TABLE TR_SEIKYU_MEISAI_RIREKI
    ADD(CONSTRAINT FK_TR_SEIKYU_RIREKI_TR_SEIKYU_MEISAI_RIREKI FOREIGN KEY(SEIKYU_ID, SEIKYUSHO_EDABAN) REFERENCES TR_SEIKYU_RIREKI (SEIKYU_ID, SEIKYUSHO_EDABAN))
/
ALTER TABLE TR_MISHU
    ADD(CONSTRAINT FK_TR_SEIKYU_TR_MISHU FOREIGN KEY(SEIKYU_ID) REFERENCES TR_SEIKYU (SEIKYU_ID))
/
ALTER TABLE MS_KOKYAKU_TORIMATOME_SEIKYU_KO
    ADD(CONSTRAINT FK_MS_KOKYAKU_MS_KOKYAKU_TORIMATOME_SEIKYU_KO FOREIGN KEY(KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG) REFERENCES MS_KOKYAKU (KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG))
/
ALTER TABLE TR_KESHI_KOMI_BANK_WEB_WORK
    ADD(CONSTRAINT FK_TR_KESHI_KOMI_BANK_WEB_TORIKOMI_RIREKI_TR_KESHI_KOMI_BANK_WEB_WORK FOREIGN KEY(TORIKOMI_ID) REFERENCES TR_KESHI_KOMI_BANK_WEB_TORIKOMI_RIREKI (TORIKOMI_ID))
/
ALTER TABLE TR_GENKIN_SUITO
    ADD(CONSTRAINT FK_TR_SEIKYU_TR_GENKIN_SUITO FOREIGN KEY(SEIKYU_ID) REFERENCES TR_SEIKYU (SEIKYU_ID))
/
ALTER TABLE TR_MISHU_RIREKI
    ADD(CONSTRAINT FK_TR_MISHU_TR_MISHU_RIREKI FOREIGN KEY(MISHUNO, SEIKYU_ID) REFERENCES TR_MISHU (MISHUNO, SEIKYU_ID))
/
ALTER TABLE TR_NYUKIN_RIREKI
    ADD(CONSTRAINT FK_TR_NYUKIN_TR_NYUKIN_RIREKI FOREIGN KEY(NYUKIN_ID, NYUKIN_MEISAI_NO, NYUKIN_SHIWAKE_ID) REFERENCES TR_NYUKIN (NYUKIN_ID, NYUKIN_MEISAI_NO, NYUKIN_SHIWAKE_ID))
/
ALTER TABLE TR_HAIFU_MAWB_BANGO
    ADD(CONSTRAINT FK_TR_TOROKU_MAWB_BANGO_TR_HAIFU_MAWB_BANGO FOREIGN KEY(KOKU_GAISHA_CD, HAKKEN_EIGYOSHO_CD, MAWB_TOROKU_ID) REFERENCES TR_TOROKU_MAWB_BANGO (KOKU_GAISHA_CD, HAKKEN_EIGYOSHO_CD, MAWB_TOROKU_ID))
/
ALTER TABLE TR_JISSEKI_MAWB_BANGO_RIREKI
    ADD(CONSTRAINT FK_TR_JISSEKI_MAWB_BANGO_TR_JISSEKI_MAWB_BANGO_RIREKI FOREIGN KEY(MAWB_BANGO, KOKU_GAISHA_CD, HAKKEN_EIGYOSHO_CD, HAIFUSAKI_EIGYOSHO_CD, MAWB_TOROKU_ID, MAWB_HAIFU_ID) REFERENCES TR_JISSEKI_MAWB_BANGO (MAWB_BANGO, KOKU_GAISHA_CD, HAKKEN_EIGYOSHO_CD, HAIFUSAKI_EIGYOSHO_CD, MAWB_TOROKU_ID, MAWB_HAIFU_ID))
/
ALTER TABLE TR_VOID_SUMI_BANGO
    ADD(CONSTRAINT FK_TR_HAIFU_MAWB_BANGO_TR_VOID_SUMI_BANGO FOREIGN KEY(KOKU_GAISHA_CD, HAKKEN_EIGYOSHO_CD, HAIFUSAKI_EIGYOSHO_CD, MAWB_TOROKU_ID, MAWB_HAIFU_ID) REFERENCES TR_HAIFU_MAWB_BANGO (KOKU_GAISHA_CD, HAKKEN_EIGYOSHO_CD, HAIFUSAKI_EIGYOSHO_CD, MAWB_TOROKU_ID, MAWB_HAIFU_ID))
/
ALTER TABLE TR_JISSEKI_MAWB_BANGO
    ADD(CONSTRAINT FK_TR_HAIFU_MAWB_BANGO_TR_JISSEKI_MAWB_BANGO FOREIGN KEY(KOKU_GAISHA_CD, HAKKEN_EIGYOSHO_CD, HAIFUSAKI_EIGYOSHO_CD, MAWB_TOROKU_ID, MAWB_HAIFU_ID) REFERENCES TR_HAIFU_MAWB_BANGO (KOKU_GAISHA_CD, HAKKEN_EIGYOSHO_CD, HAIFUSAKI_EIGYOSHO_CD, MAWB_TOROKU_ID, MAWB_HAIFU_ID))
/
ALTER TABLE MS_SHIIRE_YOTEI_MEISAI
    ADD(CONSTRAINT FK_MS_SHIIRE_YOTEI_MS_SHIIRE_YOTEI_MEISAI FOREIGN KEY(EIGYOSHO_CD, SHIIRESAKI_CD, SHIIRE_KBN_CD, TEKIYO_KAISHIBI) REFERENCES MS_SHIIRE_YOTEI (EIGYOSHO_CD, SHIIRESAKI_CD, SHIIRE_KBN_CD, TEKIYO_KAISHIBI))
/
ALTER TABLE MS_SHIIRESAKI
    ADD(CONSTRAINT FK_MS_SS_SHIIRESAKI_MS_SHIIRESAKI FOREIGN KEY(SS_SHIIRESAKI_CD) REFERENCES MS_SS_SHIIRESAKI (SS_SHIIRESAKI_CD))
/
ALTER TABLE TR_SHIIRE
    ADD(CONSTRAINT FK_MS_SHIIRE_RYOKIN_KOMOKU_TR_SHIIRE FOREIGN KEY(SHIIRE_KBN_CD) REFERENCES MS_SHIIRE_RYOKIN_KOMOKU (SHIIRE_KBN_CD))
/
ALTER TABLE TR_SHIHARAI
    ADD(CONSTRAINT FK_TR_SHIIRE_SHIHARAI_KANRI_TR_SHIHARAI FOREIGN KEY(TAISHO_NENGETSU, EIGYOSHO_CD) REFERENCES TR_SHIIRE_SHIHARAI_KANRI (TAISHO_NENGETSU, EIGYOSHO_CD))
/
ALTER TABLE TR_SHIHARAI
    ADD(CONSTRAINT FK_MS_SHIIRE_RYOKIN_KOMOKU_TR_SHIHARAI FOREIGN KEY(SHIIRE_KBN_CD) REFERENCES MS_SHIIRE_RYOKIN_KOMOKU (SHIIRE_KBN_CD))
/
ALTER TABLE TR_MITSUMORI
    ADD(CONSTRAINT FK_TR_MITSUMORI_TEIAN_TR_MITSUMORI FOREIGN KEY(MITSUMORI_TEIAN_NO) REFERENCES TR_MITSUMORI_TEIAN (MITSUMORI_TEIAN_NO))
/
ALTER TABLE TR_CHARTER_RYOKIN_MITSUMORI
    ADD(CONSTRAINT FK_TR_MITSUMORI_TR_CHARTER_RYOKIN_MITSUMORI FOREIGN KEY(MITSUMORI_NO, MITSUMORI_TEIAN_NO) REFERENCES TR_MITSUMORI (MITSUMORI_NO, MITSUMORI_TEIAN_NO))
/
ALTER TABLE TR_FUTAI_RYOKIN_MITSUMORI
    ADD(CONSTRAINT FK_TR_MITSUMORI_TR_FUTAI_RYOKIN_MITSUMORI FOREIGN KEY(MITSUMORI_NO, MITSUMORI_TEIAN_NO) REFERENCES TR_MITSUMORI (MITSUMORI_NO, MITSUMORI_TEIAN_NO))
/
ALTER TABLE TR_FUTAI_RYOKIN_MITSUMORI_NEBIKI_KOMOKU
    ADD(CONSTRAINT FK_TR_MITSUMORI_TR_FUTAI_RYOKIN_MITSUMORI_NEBIKI_KOMOKU FOREIGN KEY(MITSUMORI_NO, MITSUMORI_TEIAN_NO) REFERENCES TR_MITSUMORI (MITSUMORI_NO, MITSUMORI_TEIAN_NO))
/
ALTER TABLE TR_CHARTER_FUTAI_RYOKIN_MITSUMORI
    ADD(CONSTRAINT FK_TR_CHARTER_RYOKIN_MITSUMORI_TR_CHARTER_FUTAI_RYOKIN_MITSUMORI FOREIGN KEY(MITSUMORI_NO, MITSUMORI_TEIAN_NO) REFERENCES TR_CHARTER_RYOKIN_MITSUMORI (MITSUMORI_NO, MITSUMORI_TEIAN_NO))
/
ALTER TABLE TR_CHARTER_RYOKIN_SHASHUBETSU_WARIMASHI_MITSUMORI
    ADD(CONSTRAINT FK_TR_CHARTER_RYOKIN_MITSUMORI_TR_CHARTER_RYOKIN_SHASHUBETSU_WARIMASHI_MITSUMORI FOREIGN KEY(MITSUMORI_NO, MITSUMORI_TEIAN_NO) REFERENCES TR_CHARTER_RYOKIN_MITSUMORI (MITSUMORI_NO, MITSUMORI_TEIAN_NO))
/
ALTER TABLE TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_JIKANTAI_MITSUMORI
    ADD(CONSTRAINT FK_TR_CHARTER_RYOKIN_MITSUMORI_TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_JIKANTAI_MITSUMORI FOREIGN KEY(MITSUMORI_NO, MITSUMORI_TEIAN_NO) REFERENCES TR_CHARTER_RYOKIN_MITSUMORI (MITSUMORI_NO, MITSUMORI_TEIAN_NO))
/
ALTER TABLE TR_CHARTER_RYOKIN_YUSORYO_KYORI_MITSUMORI
    ADD(CONSTRAINT FK_TR_CHARTER_RYOKIN_MITSUMORI_TR_CHARTER_RYOKIN_YUSORYO_KYORI_MITSUMORI FOREIGN KEY(MITSUMORI_NO, MITSUMORI_TEIAN_NO) REFERENCES TR_CHARTER_RYOKIN_MITSUMORI (MITSUMORI_NO, MITSUMORI_TEIAN_NO))
/
ALTER TABLE TR_PACK_RYOKIN_MITSUMORI
    ADD(CONSTRAINT FK_TR_MITSUMORI_TR_PACK_RYOKIN_MITSUMORI FOREIGN KEY(MITSUMORI_NO, MITSUMORI_TEIAN_NO) REFERENCES TR_MITSUMORI (MITSUMORI_NO, MITSUMORI_TEIAN_NO))
/
ALTER TABLE TR_NORMAL_UNCHIN_MITSUMORI
    ADD(CONSTRAINT FK_TR_MITSUMORI_TR_NORMAL_UNCHIN_MITSUMORI FOREIGN KEY(MITSUMORI_NO, MITSUMORI_TEIAN_NO) REFERENCES TR_MITSUMORI (MITSUMORI_NO, MITSUMORI_TEIAN_NO))
/
ALTER TABLE TR_PACK_RYOKIN_MITSUMORI_RYOKIN
    ADD(CONSTRAINT FK_TR_PACK_RYOKIN_MITSUMORI_TATENE_TR_PACK_RYOKIN_MITSUMORI_RYOKIN FOREIGN KEY(MEISAI_GYO_NO, MITSUMORI_NO, MITSUMORI_TEIAN_NO) REFERENCES TR_PACK_RYOKIN_MITSUMORI_TATENE (MEISAI_GYO_NO, MITSUMORI_NO, MITSUMORI_TEIAN_NO))
/
ALTER TABLE TR_PACK_RYOKIN_MITSUMORI_TATENE
    ADD(CONSTRAINT FK_TR_PACK_RYOKIN_MITSUMORI_TR_PACK_RYOKIN_MITSUMORI_TATENE FOREIGN KEY(MITSUMORI_NO, MITSUMORI_TEIAN_NO) REFERENCES TR_PACK_RYOKIN_MITSUMORI (MITSUMORI_NO, MITSUMORI_TEIAN_NO))
/
ALTER TABLE TR_CHARTER_RYOKIN_YUSORYO_MITSUMORI
    ADD(CONSTRAINT FK_TR_CHARTER_RYOKIN_YUSORYO_KYORI_MITSUMORI_TR_CHARTER_RYOKIN_YUSORYO_MITSUMORI FOREIGN KEY(MEISAI_GYO_NO, MITSUMORI_NO, MITSUMORI_TEIAN_NO) REFERENCES TR_CHARTER_RYOKIN_YUSORYO_KYORI_MITSUMORI (MEISAI_GYO_NO, MITSUMORI_NO, MITSUMORI_TEIAN_NO))
/
ALTER TABLE TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_MITSUMORI
    ADD(CONSTRAINT FK_TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_JIKANTAI_MITSUMORI_TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_MITSUMORI FOREIGN KEY(MEISAI_GYO_NO, MITSUMORI_NO, MITSUMORI_TEIAN_NO) REFERENCES TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_JIKANTAI_MITSUMORI (MEISAI_GYO_NO, MITSUMORI_NO, MITSUMORI_TEIAN_NO))
/
ALTER TABLE TR_SONOTA_URIAGE_MEISAI
    ADD(CONSTRAINT FK_TR_SONOTA_URIAGE_TR_SONOTA_URIAGE_MEISAI FOREIGN KEY(URIAGE_ID, URIAGE_DATA_VERSION, AKA_KURO_KBN) REFERENCES TR_SONOTA_URIAGE (URIAGE_ID, URIAGE_DATA_VERSION, AKA_KURO_KBN))
/
ALTER TABLE TR_SONOTA_URIAGE_MEISAI_RIREKI
    ADD(CONSTRAINT FK_TR_SONOTA_URIAGE_RIREKI_TR_SONOTA_URIAGE_MEISAI_RIREKI FOREIGN KEY(URIAGE_ID, URIAGE_DATA_VERSION) REFERENCES TR_SONOTA_URIAGE_RIREKI (URIAGE_ID, URIAGE_DATA_VERSION))
/
ALTER TABLE TR_RYOKINHYO_KAGAMI
    ADD(CONSTRAINT FK_TR_KEIYAKU_MASTER_TR_RYOKINHYO_KAGAMI FOREIGN KEY(KEIYAKU_ID) REFERENCES TR_KEIYAKU_MASTER (KEIYAKU_ID))
/
ALTER TABLE TR_CHARTER_RYOKIN
    ADD(CONSTRAINT FK_TR_RYOKINHYO_KAGAMI_TR_CHARTER_RYOKIN FOREIGN KEY(RYOKINHYO_NO, KEIYAKU_ID) REFERENCES TR_RYOKINHYO_KAGAMI (RYOKINHYO_NO, KEIYAKU_ID))
/
ALTER TABLE TR_FUTAI_RYOKINHYO_NEBIKI_KOMOKU
    ADD(CONSTRAINT FK_TR_RYOKINHYO_KAGAMI_TR_FUTAI_RYOKINHYO_NEBIKI_KOMOKU FOREIGN KEY(RYOKINHYO_NO, KEIYAKU_ID) REFERENCES TR_RYOKINHYO_KAGAMI (RYOKINHYO_NO, KEIYAKU_ID))
/
ALTER TABLE TR_FUTAI_RYOKINHYO
    ADD(CONSTRAINT FK_TR_RYOKINHYO_KAGAMI_TR_FUTAI_RYOKINHYO FOREIGN KEY(RYOKINHYO_NO, KEIYAKU_ID) REFERENCES TR_RYOKINHYO_KAGAMI (RYOKINHYO_NO, KEIYAKU_ID))
/
ALTER TABLE TR_PACK_RYOKINHYO
    ADD(CONSTRAINT FK_TR_RYOKINHYO_KAGAMI_TR_PACK_RYOKINHYO FOREIGN KEY(RYOKINHYO_NO, KEIYAKU_ID) REFERENCES TR_RYOKINHYO_KAGAMI (RYOKINHYO_NO, KEIYAKU_ID))
/
ALTER TABLE TR_CHARTER_RYOKIN_SHASHUBETSU_WARIMASHI
    ADD(CONSTRAINT FK_TR_CHARTER_RYOKIN_TR_CHARTER_RYOKIN_SHASHUBETSU_WARIMASHI FOREIGN KEY(RYOKINHYO_NO, KEIYAKU_ID) REFERENCES TR_CHARTER_RYOKIN (RYOKINHYO_NO, KEIYAKU_ID))
/
ALTER TABLE TR_CHARTER_FUTAI_RYOKINHYO
    ADD(CONSTRAINT FK_TR_CHARTER_RYOKIN_TR_CHARTER_FUTAI_RYOKINHYO FOREIGN KEY(RYOKINHYO_NO, KEIYAKU_ID) REFERENCES TR_CHARTER_RYOKIN (RYOKINHYO_NO, KEIYAKU_ID))
/
ALTER TABLE TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_JIKANTAI
    ADD(CONSTRAINT FK_TR_CHARTER_RYOKIN_TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_JIKANTAI FOREIGN KEY(RYOKINHYO_NO, KEIYAKU_ID) REFERENCES TR_CHARTER_RYOKIN (RYOKINHYO_NO, KEIYAKU_ID))
/
ALTER TABLE TR_CHARTER_RYOKIN_YUSORYO_KYORI
    ADD(CONSTRAINT FK_TR_CHARTER_RYOKIN_TR_CHARTER_RYOKIN_YUSORYO_KYORI FOREIGN KEY(RYOKINHYO_NO, KEIYAKU_ID) REFERENCES TR_CHARTER_RYOKIN (RYOKINHYO_NO, KEIYAKU_ID))
/
ALTER TABLE TR_CHARTER_RYOKIN_JIKAN_WARIMASHI
    ADD(CONSTRAINT FK_TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_JIKANTAI_TR_CHARTER_RYOKIN_JIKAN_WARIMASHI FOREIGN KEY(MEISAI_GYO_NO, RYOKINHYO_NO, KEIYAKU_ID) REFERENCES TR_CHARTER_RYOKIN_JIKAN_WARIMASHI_JIKANTAI (MEISAI_GYO_NO, RYOKINHYO_NO, KEIYAKU_ID))
/
ALTER TABLE TR_CHARTER_RYOKIN_YUSO_RYOKINHYO
    ADD(CONSTRAINT FK_TR_CHARTER_RYOKIN_YUSORYO_KYORI_TR_CHARTER_RYOKIN_YUSO_RYOKINHYO FOREIGN KEY(MEISAI_GYO_NO, RYOKINHYO_NO, KEIYAKU_ID) REFERENCES TR_CHARTER_RYOKIN_YUSORYO_KYORI (MEISAI_GYO_NO, RYOKINHYO_NO, KEIYAKU_ID))
/
ALTER TABLE TR_KOKYAKU_SHUKA_RYOKINHYO
    ADD(CONSTRAINT FK_TR_NORMAL_UNCHINHYO_TR_KOKYAKU_SHUKA_RYOKINHYO FOREIGN KEY(RYOKINHYO_NO, KEIYAKU_ID) REFERENCES TR_NORMAL_UNCHINHYO (RYOKINHYO_NO, KEIYAKU_ID))
/
ALTER TABLE MS_KOKU_UNCHINHYO_MEISAI
    ADD(CONSTRAINT FK_MS_KOKU_UNCHINHYO_MS_KOKU_UNCHINHYO_MEISAI FOREIGN KEY(KOKU_UNCHINHYO_CD, TEKIYO_KAISHIBI) REFERENCES MS_KOKU_UNCHINHYO (KOKU_UNCHINHYO_CD, TEKIYO_KAISHIBI))
/
ALTER TABLE MS_SHUHAI_RYOKINHYO_MEISAI
    ADD(CONSTRAINT FK_MS_SHUHAI_RYOKINHYO_MS_SHUHAI_RYOKINHYO_MEISAI FOREIGN KEY(SHUHAI_RYOKIN_HYO_CD, TEKIYO_KAISHIBI) REFERENCES MS_SHUHAI_RYOKINHYO (SHUHAI_RYOKIN_HYO_CD, TEKIYO_KAISHIBI))
/
ALTER TABLE TR_PACK_RYOKINHYO_RYOKIN
    ADD(CONSTRAINT FK_TR_PACK_RYOKINHYO_TATENE_TR_PACK_RYOKINHYO_RYOKIN FOREIGN KEY(MEISAI_GYO_NO, RYOKINHYO_NO, KEIYAKU_ID) REFERENCES TR_PACK_RYOKINHYO_TATENE (MEISAI_GYO_NO, RYOKINHYO_NO, KEIYAKU_ID))
/
ALTER TABLE TR_PACK_RYOKINHYO_TATENE
    ADD(CONSTRAINT FK_TR_PACK_RYOKINHYO_TR_PACK_RYOKINHYO_TATENE FOREIGN KEY(RYOKINHYO_NO, KEIYAKU_ID) REFERENCES TR_PACK_RYOKINHYO (RYOKINHYO_NO, KEIYAKU_ID))
/
ALTER TABLE TR_NORMAL_UNCHINHYO
    ADD(CONSTRAINT FK_TR_RYOKINHYO_KAGAMI_TR_NORMAL_UNCHINHYO FOREIGN KEY(RYOKINHYO_NO, KEIYAKU_ID) REFERENCES TR_RYOKINHYO_KAGAMI (RYOKINHYO_NO, KEIYAKU_ID))
/
ALTER TABLE TR_LOGI_RYOKINHYO
    ADD(CONSTRAINT FK_MS_KOKYAKU_TR_LOGI_RYOKINHYO FOREIGN KEY(KOKYAKU_CD) REFERENCES MS_KOKYAKU (KOKYAKU_CD))
/
ALTER TABLE MS_LOCATION
    ADD(CONSTRAINT FK_MS_FLOOR_MS_LOCATION FOREIGN KEY(SHISETSU_CD, TEKIYO_KAISHIBI, FLOOR_CD, TEKIYO_FLG) REFERENCES MS_FLOOR (SHISETSU_CD, TEKIYO_KAISHIBI, FLOOR_CD, TEKIYO_FLG))
/
ALTER TABLE MS_FLOOR
    ADD(CONSTRAINT FK_MS_SHISETSU_MS_FLOOR FOREIGN KEY(SHISETSU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG) REFERENCES MS_SHISETSU (SHISETSU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG))
/
ALTER TABLE TR_LOGI_MOTO_DATA_MEISAI
    ADD(CONSTRAINT FK_TR_LOGI_MOTO_DATA_TR_LOGI_MOTO_DATA_MEISAI FOREIGN KEY(LOGI_MOTO_FILE_ID) REFERENCES TR_LOGI_MOTO_DATA (LOGI_MOTO_FILE_ID))
/
ALTER TABLE TR_SEIKYU_MEISAI_LOGI_URIAGE
    ADD(CONSTRAINT FK_TR_SEIKYU_TR_SEIKYU_MEISAI_LOGI_URIAGE FOREIGN KEY(SEIKYU_ID) REFERENCES TR_SEIKYU (SEIKYU_ID))
/
ALTER TABLE MS_LOGI_RYOKIN_KOMOKU
    ADD(CONSTRAINT FK_MS_KEIRIKAMOKU_MS_LOGI_RYOKIN_KOMOKU FOREIGN KEY(SHORI_KAMOKU_CD, HOJO_KAMOKU_CD) REFERENCES MS_KEIRIKAMOKU (SHORI_KAMOKU_CD, HOJO_KAMOKU_CD))
/
ALTER TABLE TR_OKURIJO_SAI_HAKKO_JISSEKI
    ADD(CONSTRAINT FK_TR_OKURIJO_HAKKO_JISSEKI_TR_OKURIJO_SAI_HAKKO_JISSEKI FOREIGN KEY(YOKYU_EIGYOSHO_CD, YOKYU_ID) REFERENCES TR_OKURIJO_HAKKO_JISSEKI (YOKYU_EIGYOSHO_CD, YOKYU_ID))
/
ALTER TABLE TR_OKURIJO_HAKKO_JISSEKI
    ADD(CONSTRAINT FK_TR_OKURIJO_HAKKO_PTN_TR_OKURIJO_HAKKO_JISSEKI FOREIGN KEY(OKURIJO_HAKKO_PTN_ID, KOKYAKU_CD) REFERENCES TR_OKURIJO_HAKKO_PTN (OKURIJO_HAKKO_PTN_ID, KOKYAKU_CD))
/
ALTER TABLE TR_OKURIJO_HAKKO_NIUKENIN_PTN
    ADD(CONSTRAINT FK_TR_OKURIJO_HAKKO_PTN_TR_OKURIJO_HAKKO_NIUKENIN_PTN FOREIGN KEY(OKURIJO_HAKKO_PTN_ID, KOKYAKU_CD) REFERENCES TR_OKURIJO_HAKKO_PTN (OKURIJO_HAKKO_PTN_ID, KOKYAKU_CD))
/
ALTER TABLE TR_OKURIJO_HAKKO_PTN_HYOJI_JUN
    ADD(CONSTRAINT FK_TR_OKURIJO_HAKKO_PTN_TR_OKURIJO_HAKKO_PTN_HYOJI_JUN FOREIGN KEY(OKURIJO_HAKKO_PTN_ID, KOKYAKU_CD) REFERENCES TR_OKURIJO_HAKKO_PTN (OKURIJO_HAKKO_PTN_ID, KOKYAKU_CD))
/
ALTER TABLE TR_OKURIJO_HAKKO_JISSEKI_SHOSAI
    ADD(CONSTRAINT FK_TR_OKURIJO_HAKKO_JISSEKI_TR_OKURIJO_HAKKO_JISSEKI_SHOSAI FOREIGN KEY(YOKYU_EIGYOSHO_CD, YOKYU_ID) REFERENCES TR_OKURIJO_HAKKO_JISSEKI (YOKYU_EIGYOSHO_CD, YOKYU_ID))
/
ALTER TABLE TR_NIFUDA_SAI_HAKKO_JISSEKI
    ADD(CONSTRAINT FK_TR_OKURIJO_HAKKO_JISSEKI_TR_NIFUDA_SAI_HAKKO_JISSEKI FOREIGN KEY(YOKYU_EIGYOSHO_CD, YOKYU_ID) REFERENCES TR_OKURIJO_HAKKO_JISSEKI (YOKYU_EIGYOSHO_CD, YOKYU_ID))
/
ALTER TABLE TR_YUSO_SHIIRE_MEISAI
    ADD(CONSTRAINT FK_TR_YUSO_URIAGE_TR_YUSO_SHIIRE_MEISAI2 FOREIGN KEY(URIAGE_ID, URIAGE_DATA_VERSION, AKA_KURO_KBN) REFERENCES TR_YUSO_URIAGE (URIAGE_ID, URIAGE_DATA_VERSION, AKA_KURO_KBN))
/
ALTER TABLE TR_MANIFESTO_NO_KANRI
    ADD(CONSTRAINT FK_TR_YUSO_URIAGE_TR_MANIFESTO_NO_KANRI2 FOREIGN KEY(URIAGE_ID, URIAGE_DATA_VERSION, AKA_KURO_KBN) REFERENCES TR_YUSO_URIAGE (URIAGE_ID, URIAGE_DATA_VERSION, AKA_KURO_KBN))
/
ALTER TABLE MS_SHARYO
    ADD(CONSTRAINT FK_MS_EIGYOSHO_MS_SHARYO FOREIGN KEY(EIGYOSHO_CD, TEKIYO_KAISHIBI) REFERENCES MS_EIGYOSHO (EIGYOSHO_CD, TEKIYO_KAISHIBI))
/
ALTER TABLE MS_GOSHA
    ADD(CONSTRAINT FK_MS_EIGYOSHO_MS_GOSHA FOREIGN KEY(EIGYOSHO_CD, TEKIYO_KAISHIBI) REFERENCES MS_EIGYOSHO (EIGYOSHO_CD, TEKIYO_KAISHIBI))
/
ALTER TABLE MS_GOSHA_SHIMUKE_CHI
    ADD(CONSTRAINT FK_MS_GOSHA_MS_GOSHA_SHIMUKE_CHI FOREIGN KEY(EIGYOSHO_CD, GOSHA_CD, TEKIYO_KAISHIBI) REFERENCES MS_GOSHA (EIGYOSHO_CD, GOSHA_CD, TEKIYO_KAISHIBI))
/
ALTER TABLE TR_SHUKA_TRACE_EDABAN
    ADD(CONSTRAINT FK_TR_SHUKA_TRACE_TR_SHUKA_TRACE_EDABAN FOREIGN KEY(OKURIJO_NO, SHUKA_NENGAPPI) REFERENCES TR_SHUKA_TRACE (OKURIJO_NO, SHUKA_NENGAPPI))
/
ALTER TABLE TR_SOGO_TRACE_EDABAN
    ADD(CONSTRAINT FK_TR_SOGO_TRACE_TR_SOGO_TRACE_EDABAN FOREIGN KEY(OKURIJO_NO, NYURYOKU_TEN, TRACE_SHUBETSU, NYURYOKU_NENGAPPI) REFERENCES TR_SOGO_TRACE (OKURIJO_NO, NYURYOKU_TEN, TRACE_SHUBETSU, NYURYOKU_NENGAPPI))
/
ALTER TABLE TR_HAIKAN_TRACE_EDABAN
    ADD(CONSTRAINT FK_TR_HAIKAN_TRACE_TR_HAIKAN_TRACE_EDABAN FOREIGN KEY(OKURIJO_NO, HAITATSU_TEN, HAITATSU_NENGAPPI) REFERENCES TR_HAIKAN_TRACE (OKURIJO_NO, HAITATSU_TEN, HAITATSU_NENGAPPI))
/
ALTER TABLE MS_GOSHA
    ADD(CONSTRAINT FK_MS_SHARYO_MS_GOSHA FOREIGN KEY(SHARYO_NO, TEKIYO_KAISHIBI, EIGYOSHO_CD) REFERENCES MS_SHARYO (SHARYO_NO, TEKIYO_KAISHIBI, EIGYOSHO_CD))
/
ALTER TABLE MS_GOSHA_RIREKI
    ADD(CONSTRAINT FK_MS_GOSHA_MS_GOSHA_RIREKI FOREIGN KEY(EIGYOSHO_CD, GOSHA_CD, TEKIYO_KAISHIBI) REFERENCES MS_GOSHA (EIGYOSHO_CD, GOSHA_CD, TEKIYO_KAISHIBI))
/
ALTER TABLE MS_SHARYO_RIREKI
    ADD(CONSTRAINT FK_MS_SHARYO_MS_SHARYO_RIREKI FOREIGN KEY(SHARYO_NO, TEKIYO_KAISHIBI, EIGYOSHO_CD) REFERENCES MS_SHARYO (SHARYO_NO, TEKIYO_KAISHIBI, EIGYOSHO_CD))
/
ALTER TABLE MS_KOKYAKU_MEMO_FILE_RIREKI
    ADD(CONSTRAINT FK_MS_KOKYAKU_MEMO_RIREKI_MS_KOKYAKU_MEMO_FILE_RIREKI FOREIGN KEY(KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG, MEMO_MEISAI_ID, KOKYAKU_MEMO_DATA_VERSION) REFERENCES MS_KOKYAKU_MEMO_RIREKI (KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG, MEMO_MEISAI_ID, KOKYAKU_MEMO_DATA_VERSION))
/
ALTER TABLE TR_PACK_RYOKIN_MITSUMORI_RYOKIN_RIREKI
    ADD(CONSTRAINT FK_TR_PACK_RYOKIN_MITSUMORI_TATENE_RIREKI_TR_PACK_RYOKIN_MITSUMORI_RYOKIN_RIREKI FOREIGN KEY(MEISAI_GYO_NO, MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID) REFERENCES TR_PACK_RYOKIN_MITSUMORI_TATENE_RIREKI (MEISAI_GYO_NO, MITSUMORI_TEIAN_NO, MITSUMORI_NO, SIMULATION_ID))
/
ALTER TABLE TR_PACK_RYOKIN_MITSUMORI_CHIIKI_SETTEI
    ADD(CONSTRAINT FK_TR_MITSUMORI_TR_PACK_RYOKIN_MITSUMORI_CHIIKI_SETTEI FOREIGN KEY(MITSUMORI_NO, MITSUMORI_TEIAN_NO) REFERENCES TR_MITSUMORI (MITSUMORI_NO, MITSUMORI_TEIAN_NO))
/
ALTER TABLE TR_PACK_RYOKIN_MITSUMORI_CHIIKI_MEISAI
    ADD(CONSTRAINT FK_TR_PACK_RYOKIN_MITSUMORI_CHIIKI_SETTEI_TR_PACK_RYOKIN_MITSUMORI_CHIIKI_MEISAI FOREIGN KEY(MITSUMORI_TEIAN_NO, MITSUMORI_NO, UNCHIN_RANK, HOTCHI_CHAKU_CHIKU_KBN) REFERENCES TR_PACK_RYOKIN_MITSUMORI_CHIIKI_SETTEI (MITSUMORI_TEIAN_NO, MITSUMORI_NO, UNCHIN_RANK, HOTCHI_CHAKU_CHIKU_KBN))
/
ALTER TABLE TR_PACK_RYOKIN_MITSUMORI_RYOKIN
    ADD(CONSTRAINT FK_TR_PACK_RYOKIN_MITSUMORI_CHIIKI_SETTEI_TR_PACK_RYOKIN_MITSUMORI_RYOKIN FOREIGN KEY(MITSUMORI_TEIAN_NO, MITSUMORI_NO, UNCHIN_RANK, HOTCHI_CHAKU_CHIKU_KBN) REFERENCES TR_PACK_RYOKIN_MITSUMORI_CHIIKI_SETTEI (MITSUMORI_TEIAN_NO, MITSUMORI_NO, UNCHIN_RANK, HOTCHI_CHAKU_CHIKU_KBN))
/
ALTER TABLE TR_KOKYAKU_SHUKA_RYOKIN_MITSUMORI_JURYOTAI
    ADD(CONSTRAINT FK_TR_NORMAL_UNCHIN_MITSUMORI_TR_KOKYAKU_SHUKA_RYOKIN_MITSUMORI_JURYOTAI FOREIGN KEY(MITSUMORI_NO, MITSUMORI_TEIAN_NO) REFERENCES TR_NORMAL_UNCHIN_MITSUMORI (MITSUMORI_NO, MITSUMORI_TEIAN_NO))
/
ALTER TABLE TR_KOKYAKU_SHUKA_RYOKIN_MITSUMORI
    ADD(CONSTRAINT FK_TR_KOKYAKU_SHUKA_RYOKIN_MITSUMORI_JURYOTAI_TR_KOKYAKU_SHUKA_RYOKIN_MITSUMORI FOREIGN KEY(MITSUMORI_NO, MEISAI_GYO_NO, MITSUMORI_TEIAN_NO) REFERENCES TR_KOKYAKU_SHUKA_RYOKIN_MITSUMORI_JURYOTAI (MITSUMORI_NO, MEISAI_GYO_NO, MITSUMORI_TEIAN_NO))
/
ALTER TABLE TR_KOKYAKU_SHUKA_RYOKIN_MITSUMORI_RIREKI
    ADD(CONSTRAINT FK_TR_KOKYAKU_SHUKA_RYOKIN_MITSUMORI_JURYOTAI_RIREKI_TR_KOKYAKU_SHUKA_RYOKIN_MITSUMORI_RIREKI FOREIGN KEY(MITSUMORI_TEIAN_NO, MITSUMORI_NO, MEISAI_GYO_NO, SIMULATION_ID) REFERENCES TR_KOKYAKU_SHUKA_RYOKIN_MITSUMORI_JURYOTAI_RIREKI (MITSUMORI_TEIAN_NO, MITSUMORI_NO, MEISAI_GYO_NO, SIMULATION_ID))
/
ALTER TABLE TR_KOKYAKU_SHUKA_RYOKINHYO_JURYOTAI
    ADD(CONSTRAINT FK_TR_KOKYAKU_SHUKA_RYOKINHYO_TR_KOKYAKU_SHUKA_RYOKINHYO_JURYOTAI FOREIGN KEY(RYOKINHYO_NO, MEISAI_GYO_NO, KEIYAKU_ID) REFERENCES TR_KOKYAKU_SHUKA_RYOKINHYO (RYOKINHYO_NO, MEISAI_GYO_NO, KEIYAKU_ID))
/
ALTER TABLE TR_LOGI_RYOKINHYO_SHOKEI_GROUP
    ADD(CONSTRAINT FK_TR_LOGI_RYOKINHYO_TR_LOGI_RYOKINHYO_SHOKEI_GROUP FOREIGN KEY(KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG) REFERENCES TR_LOGI_RYOKINHYO (KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG))
/
ALTER TABLE TR_LOGI_RYOKINHYO_MEISAI
    ADD(CONSTRAINT FK_TR_LOGI_RYOKINHYO_TR_LOGI_RYOKINHYO_MEISAI FOREIGN KEY(KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG) REFERENCES TR_LOGI_RYOKINHYO (KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG))
/
ALTER TABLE TR_LOGI_RYOKINHYO_MEISAI
    ADD(CONSTRAINT FK_TR_LOGI_RYOKINHYO_SHOKEI_GROUP_TR_LOGI_RYOKINHYO_MEISAI FOREIGN KEY(KOKYAKU_CD, TEKIYO_KAISHIBI, SHOKEI_GROUP_ID, TEKIYO_FLG) REFERENCES TR_LOGI_RYOKINHYO_SHOKEI_GROUP (KOKYAKU_CD, TEKIYO_KAISHIBI, SHOKEI_GROUP_ID, TEKIYO_FLG))
/
ALTER TABLE TR_LOGI_MOTO_BIKO
    ADD(CONSTRAINT FK_TR_LOGI_RYOKINHYO_MEISAI_TR_LOGI_MOTO_BIKO FOREIGN KEY(MEISAI_GYO_NO, KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG) REFERENCES TR_LOGI_RYOKINHYO_MEISAI (MEISAI_GYO_NO, KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG))
/
ALTER TABLE TR_LOGI_RYOKINHYO_MEISAI_RIREKI
    ADD(CONSTRAINT FK_TR_LOGI_RYOKINHYO_RIREKI_TR_LOGI_RYOKINHYO_MEISAI_RIREKI FOREIGN KEY(KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG, LOGI_RYOKINHYO_DATA_VERSION) REFERENCES TR_LOGI_RYOKINHYO_RIREKI (KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG, LOGI_RYOKINHYO_DATA_VERSION))
/
ALTER TABLE TR_LOGI_RYOKINHYO_SHOKEI_GROUP_RIREKI
    ADD(CONSTRAINT FK_TR_LOGI_RYOKINHYO_RIREKI_TR_LOGI_RYOKINHYO_SHOKEI_GROUP_RIREKI FOREIGN KEY(KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG, LOGI_RYOKINHYO_DATA_VERSION) REFERENCES TR_LOGI_RYOKINHYO_RIREKI (KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG, LOGI_RYOKINHYO_DATA_VERSION))
/
ALTER TABLE TR_LOGI_RYOKINHYO_MEISAI_RIREKI
    ADD(CONSTRAINT FK_TR_LOGI_RYOKINHYO_SHOKEI_GROUP_RIREKI_TR_LOGI_RYOKINHYO_MEISAI_RIREKI FOREIGN KEY(KOKYAKU_CD, TEKIYO_KAISHIBI, SHOKEI_GROUP_ID, LOGI_RYOKINHYO_DATA_VERSION, TEKIYO_FLG) REFERENCES TR_LOGI_RYOKINHYO_SHOKEI_GROUP_RIREKI (KOKYAKU_CD, TEKIYO_KAISHIBI, SHOKEI_GROUP_ID, LOGI_RYOKINHYO_DATA_VERSION, TEKIYO_FLG))
/
ALTER TABLE TR_LOGI_MOTO_BIKO_RIREKI
    ADD(CONSTRAINT FK_TR_LOGI_RYOKINHYO_MEISAI_RIREKI_TR_LOGI_MOTO_BIKO_RIREKI FOREIGN KEY(MEISAI_GYO_NO, LOGI_RYOKINHYO_DATA_VERSION, KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG) REFERENCES TR_LOGI_RYOKINHYO_MEISAI_RIREKI (MEISAI_GYO_NO, LOGI_RYOKINHYO_DATA_VERSION, KOKYAKU_CD, TEKIYO_KAISHIBI, TEKIYO_FLG))
/
ALTER TABLE TR_LOGI_RYOKINHYO_MEISAI
    ADD(CONSTRAINT FK_MS_LOCATION_TR_LOGI_RYOKINHYO_MEISAI FOREIGN KEY(SHISETSU_CD, FLOOR_CD, HOKAN_SHUBETSU_CD) REFERENCES MS_LOCATION (SHISETSU_CD, FLOOR_CD, HOKAN_SHUBETSU_CD))
/
ALTER TABLE MS_USER_ACCESS_KANO_SOSHIKI
    ADD(CONSTRAINT FK_MS_USER_MS_USER_ACCESS_KANO_SOSHIKI FOREIGN KEY(USER_CD, TEKIYO_KAISHIBI, TEKIYO_FLG) REFERENCES MS_USER (USER_CD, TEKIYO_KAISHIBI, TEKIYO_FLG))
/
