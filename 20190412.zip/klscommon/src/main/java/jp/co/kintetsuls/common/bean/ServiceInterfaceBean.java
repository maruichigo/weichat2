package jp.co.kintetsuls.common.bean;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.Arrays;
import jp.co.kintetsuls.common.json.JSONUtil;

/**
 * 各プロジェクトのRestFullサービスの受け渡しクラス
 * ◆0.受信されるデータについて
 * serviceInterfaceBean.getUser(); ユーザーコード
 * serviceInterfaceBean.getAvailableEigyosho();担当営業所（リスト）
 * serviceInterfaceBean.getDefaultEigyosho();デフォルト営業所
 * serviceInterfaceBean.getTammatsu();端末
 * serviceInterfaceBean.getJson(); フォーム送信情報

 * ◆1.フォームパラメータを受信する場合
 * ObjectMapper mapper = new ObjectMapper();
 * params = mapper.readValue(serviceInterfaceBean.getJson(), Map.class);
 * →入力フォーム情報を取得する場合
 * String column1 = (String)params.get("column1");
 * →単一テーブル情報を取得する場合
 * List<Map<String, Object>> tabledata = (List<Map<String, Object>>)params.get("TABLEALL_NODE"); 
 * →単一テーブルの選択行情報を取得する場合
 * List<Map<String, Object>> tabledata = (List<Map<String, Object>>)params.get("SELECTED_NODE"); 
 * →callsqlにパラメータとして複数テーブルを追加し、取得する場合
 *  List<Map<String, String>> tabledata = (List<Map<String, String>>)params.get("tablekey1");
 * 
 * ◆2.通常の１テーブルデータ返却を行う場合
 * List<Map<String, String>> resultList = ((SampleDao) sampleDao).findForSearch(params);
 * serviceInterfaceBean.setJson(JSONUtil.makeJSONString(resultList));
 * 
 * ◆3.複数テーブル形式でデータを返却を行う場合
 * Map<String, List<Map<String, String>>> testListmap = new HashMap<>();
 * testListmap.put("tablekey1", resultList);
 * serviceInterfaceBean.setJsonResultList(testListmap);
 * 
 * ◆4.単一情報形式でデータを返却を行う場合
 * Map<String, String> testmap = new HashMap<String, String>();
 * testmap.put("column1", "data");
 * serviceInterfaceBean.setJsonResultMap(testmap);
 * 
 * ◆5.メッセージを返却する場合
 * serviceInterfaceBean.addMessage("INFO", "情報", "データの取得が完了しました。");
 * serviceInterfaceBean.addMessage("WARN, "注意", "反映する場合は確定ボタンを押下して下さい。");
 * serviceInterfaceBean.addMessage("ERROR", "警告", "XXXが必要な場合があります。");
 * serviceInterfaceBean.addMessage("FATAL", "異常", "異常が発生しました。");
 */
public class ServiceInterfaceBean {

    //============================================================
    // システムで使用
    //============================================================
    // システムエラー
    public static final int PROCESS_STATUS_SYSTEM_ERROR = -2;
    // 通常エラー(値の間違い、不正処理)
    public static final int PROCESS_STATUS_ERROR = -1;
    // 正常終了
    public static final int PROCESS_STATUS_SUCCESS = 1;

    private int statusCode = PROCESS_STATUS_SUCCESS;

    //============================================================
    // Service-KLSで使用
    //============================================================
    //ログインコード
    private String userCd = "";
    //担当営業所（リスト）
    private String availableEigyosho = "";
    //デフォルト営業所
    private String defaultEigyosho = "";
    
    //端末
    private String tammatsu = "";
    //サービスコード(applyto)
    private String functionCode = "";
    //フォーム送信情報/画面返却--標準情報
    private String json = "";
    //テーブルキー情報
    private String tableName = "";
    //画面返却-メッセージ情報
    private List<String[]> messages = new ArrayList<String[]>();
    //画面返却-複数テーブル情報
    private String jsonResultTableList = "";
    //画面返却-単一情報
    private String jsonResultMap = "";
    /**
     * ログインユーザー所属営業所 TODO
     */
    private List<String> loginUserShozokuEigyosho = new ArrayList<String>();

    /**
     * 画面返却-メッセージ情報を格納
     * @param level   INFO,WARN,ERROR,FATAL
     * @param summary 協調メッセージ(太字)
     * @param message メッセージ内容
     */
    public void addMessage(String level, String summary, String messageStr ) {
        String[] msg = { level, summary, messageStr };
        messages.add(msg);
    }
    public List<String[]> getMessages(){
        return messages;
    }

    /* 画面返却-複数テーブル情報を格納 */
    @JsonIgnore
    public void setJsonResultList(Map<String, List<Map<String, String>>> resultList) {
        List list = new ArrayList();
        list.add(resultList);
        this.jsonResultTableList = JSONUtil.makeJSONString(list);
    }

    /* 画面返却-単一情報を格納 */
    @JsonIgnore
    public void setJsonResultMap(Map<String, String> resultMap) {
       this.jsonResultMap = JSONUtil.makeJSONString(resultMap);
    }

    public String getUserCd() {
        return userCd;
    }
    public void setUserCd(String userCd) {
        this.userCd = userCd;
    }
    public String getAvailableEigyosho() {
        return availableEigyosho;
    }
    public void setAvailableEigyosho(String availableEigyosho) {
        this.availableEigyosho = availableEigyosho;
    }
    public String getDefaultEigyosho() {
        return defaultEigyosho;
    }
    public void setDefaultEigyosho(String defaultEigyosho) {
        this.defaultEigyosho = defaultEigyosho;
    }
    public String getTammatsu() {
        return tammatsu;
    }
    public void setTammatsu(String tammatsu) {
        this.tammatsu = tammatsu;
    }
    public String getFunctionCode() {
        return functionCode;
    }
    public void setFunctionCode(String funcId) {
        this.functionCode = funcId;
    }
    public String getJson() {
        return json;
    }
    public void setJson(String json) {
        this.json = json;
    }
    public String getTableName() {
        return tableName;
    }
    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
    public String getJsonResultTableList() {
        return jsonResultTableList;
    }
    public String getJsonResultMap() {
        return jsonResultMap;
    }

//    public List<String> getLoginUserShozokuEigyosho() {
//        return loginUserShozokuEigyosho;
//    }
//
//    public void setLoginUserShozokuEigyosho(List<String> loginUserShozokuEigyosho) {
//        this.loginUserShozokuEigyosho = loginUserShozokuEigyosho;
//    }
    
    

    public int getStatusCode() {
        return statusCode;
    }
    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }
}