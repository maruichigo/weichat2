package jp.co.kintetsuls.common.cnst;

/**
 * メッセージマスター取得前に表示する必要があるメッセージを格納。
 * 　　
 * @author 
 */
public class SysMsg {
    //TODO システムメッセージを取得前にエラーが発生した場合、メッセージをどうするかを決めていただく・
    /** ERROR: システム */
    public static final String ERRSYS = "システムエラーが発生しました。システム管理者にご連絡ください。";
    /** ERROR: パラメータ*/
    public static final String ERRPRM = "パラメーター(ServiceInterfaceBean)が不正です。";
    /** ERROR: JAX-RS接続 */
    public static final String ERRJAX = "JAX-RS接続に失敗しました。";
    public static final String ERRRTN = "サービス側から意図しないパラメータが返ってきています。";
    
    /** WARN: 必須項目入力*/
    public static final String WRNREQ = "必須項目が入力されていません。";
    /** ERROR: 情報が未登録 */
    public static final String WRNDATA = "情報が取得できませんでした。";
    /** WARN: 検索結果が0件 */
    public static final String WRNNODATA = "該当データは存在しません。";
}
